/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_crc.c
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.2
 * Date:   2026/09/17
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/24     1.1     fix input format, instance validation and transaction locking
 *     ANSILIC APPLICATION GROUP  2026/09/17     1.2     align the resource lock and the RTOS support with the architecture specification (sections 13 and 21):
 *                                                       lock the init / de-init as well (they change the handle
 *                                                       state), run the MSP callbacks outside the locked region
 *                                                       (LOCK-06) with the MSP init on the first initialization
 *                                                       only (MSP-04), move the MSP init before the register
 *                                                       programming so that the peripheral clock is enabled
 *                                                       before the first access, document every lock failure
 *                                                       return as a path where the lock is not held (LOCK-02),
 *                                                       give the lock helper a Timeout and a NULL mutex guard
 *                                                       (RTOS-11) and export it as CRC_LockHandle /
 *                                                       CRC_UnlockHandle, add the ARCH-CONST-09 state gate,
 *                                                       the busy state usage (STATE-03) and the error code
 *                                                       reporting (ARCH-CONST-10 / ERR-03)
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.0     build this module
 * Description:     This file provides firmware functions to manage the
 *                  functionalities of the Cyclic Redundancy Check (CRC)
 *                  computation unit:
 *                  - Initialization and de-initialization;
 *                  - CRC computation (single word / word / half-word /
 *                    byte blocks; calculate and accumulate);
 *                  - Peripheral control (reset, ID register, result
 *                    read-back, state reporting).
 */
#include "as32x601_hal.h"          /* module switch from as32x601_hal_conf.h */
#include "as32x601_hal_crc.h"      /* CRC HAL API and register macros        */

/* The HAL_CRC_MODULE_ENABLED switch is provided by the user configuration
 * file (as32x601_hal_conf.h, included above through as32x601_hal.h): the
 * whole implementation is compiled only while the module is enabled. */
#ifdef HAL_CRC_MODULE_ENABLED

/* Private function prototypes -----------------------------------------------*/

static uint32 CRC_HandleIsValid(const HAL_CRC_HandleTypeDef *hcrc);
static HAL_StatusTypeDef CRC_CheckState(HAL_CRC_HandleTypeDef *hcrc);

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Check whether a CRC handle and its instance are valid.
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
static uint32 CRC_HandleIsValid(const HAL_CRC_HandleTypeDef *hcrc)
{
    return ((hcrc != NULL_PTR) && IS_CRC_INSTANCE(hcrc->Instance));
}

/**
 * @brief  Check the handle state before a register access.
 * @note   ARCH-CONST-09: a handle that is busy with another operation
 *         rejects the call with HAL_BUSY, and a handle that was never
 *         initialized rejects it with HAL_ERROR (HAL_CRC_Init() is required
 *         first). The error state is recoverable, a new operation may be
 *         called directly.
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
static HAL_StatusTypeDef CRC_CheckState(HAL_CRC_HandleTypeDef *hcrc)
{
    if (hcrc->State == HAL_CRC_STATE_BUSY)
    {
        return HAL_BUSY;
    }

    if (hcrc->State == HAL_CRC_STATE_RESET)
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_CRC_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the acquisition is bounded by the Timeout parameter;
 *         HAL_MAX_DELAY waits forever.
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS, wait expired) /
 *         HAL_ERROR (RTOS, mutex not created) / HAL_BUSY (bare metal, the
 *         handle is already locked).
 */
HAL_StatusTypeDef CRC_LockHandle(HAL_CRC_HandleTypeDef *hcrc, uint32 Timeout)
{
#if (USE_RTOS == 1)
    if (hcrc->LockMutex == NULL_PTR)
    {
        /* The porting layer did not create the mutex (e.g. HAL_CRC_MspInit()
         * was not overridden): report it instead of calling the RTOS with a
         * NULL handle */
        return HAL_ERROR;
    }

    return HAL_MutexAcquire(hcrc->LockMutex, Timeout);
#else
    /* Prevent unused argument compilation warning: the bare-metal lock flag
     * either succeeds immediately or reports HAL_BUSY, it never waits */
    UNUSED(Timeout);

    if (hcrc->Lock == HAL_LOCKED)
    {
        return HAL_BUSY;
    }
    hcrc->Lock = HAL_LOCKED;
    return HAL_OK;
#endif /* USE_RTOS */
}

/**
 * @brief  Unlock the handle.
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @retval None
 */
void CRC_UnlockHandle(HAL_CRC_HandleTypeDef *hcrc)
{
#if (USE_RTOS == 1)
    (void)HAL_MutexRelease(hcrc->LockMutex);
#else
    hcrc->Lock = HAL_UNLOCKED;
#endif /* USE_RTOS */
}

static uint32 CRC_AccumulateFormatUnlocked(HAL_CRC_HandleTypeDef *hcrc,
                                           const void *pBuffer,
                                           uint32 BufferLength,
                                           uint32 InputDataFormat)
{
    uint32 index = 0U;

    switch (InputDataFormat)
    {
        case HAL_CRC_INPUTDATA_FORMAT_BYTES:
        {
            const uint8 *pData = (const uint8 *)pBuffer;
            for (index = 0U; index < BufferLength; index++)
            {
                hcrc->Instance->DR = pData[index];
            }
            break;
        }

        case HAL_CRC_INPUTDATA_FORMAT_HALFWORDS:
        {
            const uint16 *pData = (const uint16 *)pBuffer;
            for (index = 0U; index < BufferLength; index++)
            {
                hcrc->Instance->DR = pData[index];
            }
            break;
        }

        case HAL_CRC_INPUTDATA_FORMAT_WORDS:
        {
            const uint32 *pData = (const uint32 *)pBuffer;
            for (index = 0U; index < BufferLength; index++)
            {
                hcrc->Instance->DR = pData[index];
            }
            break;
        }

        default:
            hcrc->ErrorCode |= HAL_CRC_ERROR_INVALID_PARAM;
            hcrc->State = HAL_CRC_STATE_ERROR;
            return 0U;
    }

    return hcrc->Instance->DR;
}

/* Exported functions --------------------------------------------------------*/

/** @addtogroup CRC_Exported_Functions
  * @{
  */

/** @addtogroup CRC_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Fills each CRC_InitStruct member with its default value. (NON-BLOCKING)
 * @param  CRC_InitStruct: pointer to a CRC_InitTypeDef structure which will
 *         be initialized.
 * @retval None
 */
void HAL_CRC_StructInit(CRC_InitTypeDef *CRC_InitStruct)
{
    /* Check the parameter */
    if (CRC_InitStruct == NULL_PTR)
    {
        return;
    }

    /* CRC_InitStruct members default value */
    CRC_InitStruct->Size            = sizeof(CRC_InitTypeDef);  /*!< sizeof struct */
    CRC_InitStruct->Version         = CRC_INIT_VERSION;         /*!< V1            */
    CRC_InitStruct->CRC_Size       = CRC_SIZE_32B;          /*!< Data size           */
    CRC_InitStruct->CRC_OXOR       = CRC_OXOR_DISABLE;      /*!< Output XOR          */
    CRC_InitStruct->CRC_OReverse   = CRC_OREVERSE_NOT;      /*!< Output reversal     */
    CRC_InitStruct->CRC_IReverse   = CRC_IREVERSE_NONE;     /*!< Input reversal      */
    CRC_InitStruct->CRC_PolySize   = CRC_POLYSIZE_32B;      /*!< Polynomial size     */
    CRC_InitStruct->CRC_INIT       = 0x00000000U;           /*!< Initial value       */
    CRC_InitStruct->CRC_Poly       = CRC_POLY_32;           /*!< CRC-32 polynomial   */
    CRC_InitStruct->CRC_XOR        = 0x00000000U;           /*!< XOR value           */
    CRC_InitStruct->Reserved[0]    = 0U;                    /*!< Reserved for future use */
    CRC_InitStruct->Reserved[1]    = 0U;                    /*!< Reserved for future use */
}

/**
 * @brief  Initializes the CRC according to the specified parameters in the (NON-BLOCKING)
 *         CRC_InitStruct of the handle. (NON-BLOCKING)
 * @note   The CRC clock gating must be configured by the user in
 *         HAL_CRC_MspInit().
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR
 */
HAL_StatusTypeDef HAL_CRC_Init(HAL_CRC_HandleTypeDef *hcrc)
{
    uint32 tmpreg = 0U;

    /* Check the CRC peripheral handle and instance */
    if (CRC_HandleIsValid(hcrc) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_CRC_SIZE(hcrc->Init.CRC_Size));
    assert_param(IS_CRC_OXOR(hcrc->Init.CRC_OXOR));
    assert_param(IS_CRC_OREVERSE(hcrc->Init.CRC_OReverse));
    assert_param(IS_CRC_IREVERSE(hcrc->Init.CRC_IReverse));
    assert_param(IS_CRC_POLYSIZE(hcrc->Init.CRC_PolySize));
    assert_param(IS_CRC_INPUTDATA_FORMAT(hcrc->InputDataFormat));
    if ((IS_CRC_SIZE(hcrc->Init.CRC_Size) == 0U) ||
        (IS_CRC_OXOR(hcrc->Init.CRC_OXOR) == 0U) ||
        (IS_CRC_OREVERSE(hcrc->Init.CRC_OReverse) == 0U) ||
        (IS_CRC_IREVERSE(hcrc->Init.CRC_IReverse) == 0U) ||
        (IS_CRC_POLYSIZE(hcrc->Init.CRC_PolySize) == 0U) ||
        (IS_CRC_INPUTDATA_FORMAT(hcrc->InputDataFormat) == 0U))
    {
        /* ERR-01 / ERR-03 / ARCH-CONST-10: record why the configuration was
         * rejected. A busy state is preserved, so that a rejected call cannot
         * hide an operation that is still in flight. */
        hcrc->ErrorCode |= HAL_CRC_ERROR_INVALID_PARAM;
        if (hcrc->State != HAL_CRC_STATE_BUSY)
        {
            hcrc->State = HAL_CRC_STATE_ERROR;
        }
        return HAL_ERROR;
    }

    /* LOCK-06 / MSP-04: allocate the lock resource and run the low level
     * initialization BEFORE the handle is locked, and only on the first call
     * (avoid initializing the hardware twice). The MSP callback enables the
     * peripheral clock, so it has to run before the first register access
     * below: programming a clock gated peripheral would lose the whole
     * configuration. */
    if (hcrc->State == HAL_CRC_STATE_RESET)
    {
        hcrc->Lock = HAL_UNLOCKED;

        HAL_CRC_MspInit(hcrc);
    }

    /* Process locked */
    if (CRC_LockHandle(hcrc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state while configuring
     * (ARCH-CONST-10 / STATE-03) */
    hcrc->ErrorCode = HAL_CRC_ERROR_NONE;
    hcrc->State = HAL_CRC_STATE_BUSY;

    /* Configure the control register: data size, output XOR, output
     * reversal, input reversal and polynomial size in one read-modify-write
     * sequence */
    tmpreg = hcrc->Instance->CR;
    tmpreg &= ~((uint32)CRC_CR_SIZE);
    tmpreg |= (hcrc->Init.CRC_Size << CRC_CR_SIZE_Pos);
    tmpreg &= ~((uint32)CRC_CR_XOROUT);
    tmpreg |= (hcrc->Init.CRC_OXOR << CRC_CR_XOROUT_Pos);
    tmpreg &= ~((uint32)CRC_CR_REVOUT);
    tmpreg |= (hcrc->Init.CRC_OReverse << CRC_CR_REVOUT_Pos);
    tmpreg &= ~((uint32)CRC_CR_REVIN);
    tmpreg |= (hcrc->Init.CRC_IReverse << CRC_CR_REVIN_Pos);
    tmpreg &= ~((uint32)CRC_CR_POLYSIZE);
    tmpreg |= (hcrc->Init.CRC_PolySize << CRC_CR_POLYSIZE_Pos);
    hcrc->Instance->CR = tmpreg;

    /* Set the CRC initial vector */
    hcrc->Instance->INIT = hcrc->Init.CRC_INIT;

    /* Set the CRC generating polynomial */
    hcrc->Instance->POLY = hcrc->Init.CRC_Poly;

    /* Set the CRC XOR value */
    hcrc->Instance->XOR = hcrc->Init.CRC_XOR;

    hcrc->State = HAL_CRC_STATE_READY;

    /* Release Lock */
    CRC_UnlockHandle(hcrc);

    return HAL_OK;
}

/**
 * @brief  De-initializes the CRC peripheral. (NON-BLOCKING)
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR
 */
HAL_StatusTypeDef HAL_CRC_DeInit(HAL_CRC_HandleTypeDef *hcrc)
{
    /* Check the CRC peripheral handle and instance */
    if (CRC_HandleIsValid(hcrc) == 0U)
    {
        return HAL_ERROR;
    }

    /* Process locked */
    if (CRC_LockHandle(hcrc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state while tearing the handle
     * down (ARCH-CONST-10 / STATE-03) */
    hcrc->ErrorCode = HAL_CRC_ERROR_NONE;
    hcrc->State = HAL_CRC_STATE_BUSY;

    /* Reset the CRC unit */
    hcrc->Instance->CR = CRC_CR_RESET;

    /* The handle goes back to the reset state so that a following
     * HAL_CRC_Init() runs the low level initialization again */
    hcrc->State = HAL_CRC_STATE_RESET;

    /* Release Lock */
    CRC_UnlockHandle(hcrc);

    /* LOCK-06 / ARCH-CONST-04: the low level de-initialization runs OUTSIDE
     * the locked region, as the architecture specification requires for the
     * MSP callbacks ("MspDeInit is called after the unlock"). The override may
     * call other HAL APIs (e.g. HAL_GPIO_DeInit()), which is only allowed
     * while the handle lock is not held. */
    HAL_CRC_MspDeInit(hcrc);

    return HAL_OK;
}

/**
 * @brief  Initializes the CRC MSP. Weak empty function; the user implements
 *         the low level hardware initialization.
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_CRC_MspInit(HAL_CRC_HandleTypeDef *hcrc)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hcrc);
}

/**
 * @brief  De-initializes the CRC MSP. Weak empty function; the user
 *         implements the low level hardware de-initialization.
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_CRC_MspDeInit(HAL_CRC_HandleTypeDef *hcrc)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hcrc);
}

/**
  * @}
  */

/** @addtogroup CRC_Exported_Functions_Group2 CRC computation functions
  * @{
  */

/**
 * @brief  Computes the 32-bit CRC of a single data word. (NON-BLOCKING)
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @param  Data: data word to compute its CRC.
 * @retval uint32: 32-bit CRC value.
 */
uint32 HAL_CRC_CalcCRC(HAL_CRC_HandleTypeDef *hcrc, uint32 Data)
{
    uint32 result = 0U;

    if (CRC_HandleIsValid(hcrc) == 0U)
    {
        return 0U;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_CRC_Init() is
     * required first) */
    if (CRC_CheckState(hcrc) != HAL_OK)
    {
        return 0U;
    }

    /* Process locked */
    if (CRC_LockHandle(hcrc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return 0U;
    }

    /* ERR-03 / ARCH-CONST-10: a start operation clears the error code */
    hcrc->ErrorCode = HAL_CRC_ERROR_NONE;
    hcrc->State = HAL_CRC_STATE_BUSY;
    hcrc->Instance->DR = Data;
    result = hcrc->Instance->DR;
    hcrc->State = HAL_CRC_STATE_READY;
    CRC_UnlockHandle(hcrc);
    return result;
}

/**
 * @brief  Computes the 32-bit CRC of a buffer of data words (32-bit). (NON-BLOCKING)
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @param  pBuffer: pointer to the buffer containing the data to be computed.
 * @param  BufferLength: number of words in the buffer.
 * @retval uint32: 32-bit CRC value.
 */
uint32 HAL_CRC_CalcWordBlockCRC(HAL_CRC_HandleTypeDef *hcrc, uint32 *pBuffer, uint32 BufferLength)
{
    uint32 result = 0U;

    if ((CRC_HandleIsValid(hcrc) == 0U) || (pBuffer == NULL_PTR))
    {
        return 0U;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_CRC_Init() is
     * required first) */
    if (CRC_CheckState(hcrc) != HAL_OK)
    {
        return 0U;
    }

    /* Process locked */
    if (CRC_LockHandle(hcrc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return 0U;
    }

    /* ERR-03 / ARCH-CONST-10: a start operation clears the error code */
    hcrc->ErrorCode = HAL_CRC_ERROR_NONE;
    hcrc->State = HAL_CRC_STATE_BUSY;
    result = CRC_AccumulateFormatUnlocked(hcrc, pBuffer, BufferLength,
                                          HAL_CRC_INPUTDATA_FORMAT_WORDS);
    hcrc->State = (hcrc->State == HAL_CRC_STATE_ERROR) ? HAL_CRC_STATE_ERROR : HAL_CRC_STATE_READY;
    CRC_UnlockHandle(hcrc);
    return result;
}

/**
 * @brief  Computes the 32-bit CRC of a buffer of data half-words (16-bit). (NON-BLOCKING)
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @param  pBuffer: pointer to the buffer containing the data to be computed.
 * @param  BufferLength: number of half-words in the buffer.
 * @retval uint32: 32-bit CRC value.
 */
uint32 HAL_CRC_CalcHalfBlockCRC(HAL_CRC_HandleTypeDef *hcrc, uint16 *pBuffer, uint32 BufferLength)
{
    uint32 result = 0U;

    if ((CRC_HandleIsValid(hcrc) == 0U) || (pBuffer == NULL_PTR))
    {
        return 0U;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_CRC_Init() is
     * required first) */
    if (CRC_CheckState(hcrc) != HAL_OK)
    {
        return 0U;
    }

    /* Process locked */
    if (CRC_LockHandle(hcrc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return 0U;
    }

    /* ERR-03 / ARCH-CONST-10: a start operation clears the error code */
    hcrc->ErrorCode = HAL_CRC_ERROR_NONE;
    hcrc->State = HAL_CRC_STATE_BUSY;
    result = CRC_AccumulateFormatUnlocked(hcrc, pBuffer, BufferLength,
                                          HAL_CRC_INPUTDATA_FORMAT_HALFWORDS);
    hcrc->State = (hcrc->State == HAL_CRC_STATE_ERROR) ? HAL_CRC_STATE_ERROR : HAL_CRC_STATE_READY;
    CRC_UnlockHandle(hcrc);
    return result;
}

/**
 * @brief  Computes the 32-bit CRC of a buffer of data bytes (8-bit). (NON-BLOCKING)
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @param  pBuffer: pointer to the buffer containing the data to be computed.
 * @param  BufferLength: number of bytes in the buffer.
 * @retval uint32: 32-bit CRC value.
 */
uint32 HAL_CRC_CalcByteBlockCRC(HAL_CRC_HandleTypeDef *hcrc, uint8 *pBuffer, uint32 BufferLength)
{
    uint32 result = 0U;

    if ((CRC_HandleIsValid(hcrc) == 0U) || (pBuffer == NULL_PTR))
    {
        return 0U;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_CRC_Init() is
     * required first) */
    if (CRC_CheckState(hcrc) != HAL_OK)
    {
        return 0U;
    }

    /* Process locked */
    if (CRC_LockHandle(hcrc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return 0U;
    }

    /* ERR-03 / ARCH-CONST-10: a start operation clears the error code */
    hcrc->ErrorCode = HAL_CRC_ERROR_NONE;
    hcrc->State = HAL_CRC_STATE_BUSY;
    result = CRC_AccumulateFormatUnlocked(hcrc, pBuffer, BufferLength,
                                          HAL_CRC_INPUTDATA_FORMAT_BYTES);
    hcrc->State = (hcrc->State == HAL_CRC_STATE_ERROR) ? HAL_CRC_STATE_ERROR : HAL_CRC_STATE_READY;
    CRC_UnlockHandle(hcrc);
    return result;
}

/**
 * @brief  Computes the 32-bit CRC of a buffer of data in the configured (NON-BLOCKING)
 *         input data format, continuing from the current CRC value
 *         (accumulate mode). (NON-BLOCKING)
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @param  pBuffer: pointer to the buffer containing the data to be computed.
 * @param  BufferLength: number of elements (bytes / half-words / words
 *         according to the configured input data format).
 * @retval uint32: 32-bit CRC value.
 */
uint32 HAL_CRC_Accumulate(HAL_CRC_HandleTypeDef *hcrc, const void *pBuffer, uint32 BufferLength)
{
    uint32 result = 0U;

    if ((CRC_HandleIsValid(hcrc) == 0U) || (pBuffer == NULL_PTR))
    {
        return 0U;
    }
    if (IS_CRC_INPUTDATA_FORMAT(hcrc->InputDataFormat) == 0U)
    {
        hcrc->ErrorCode |= HAL_CRC_ERROR_INVALID_PARAM;
        hcrc->State = HAL_CRC_STATE_ERROR;
        return 0U;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_CRC_Init() is
     * required first) */
    if (CRC_CheckState(hcrc) != HAL_OK)
    {
        return 0U;
    }

    /* Process locked */
    if (CRC_LockHandle(hcrc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return 0U;
    }

    /* ERR-03 / ARCH-CONST-10: a start operation clears the error code */
    hcrc->ErrorCode = HAL_CRC_ERROR_NONE;
    hcrc->State = HAL_CRC_STATE_BUSY;
    result = CRC_AccumulateFormatUnlocked(hcrc, pBuffer, BufferLength,
                                          hcrc->InputDataFormat);
    hcrc->State = (hcrc->State == HAL_CRC_STATE_ERROR) ? HAL_CRC_STATE_ERROR : HAL_CRC_STATE_READY;
    CRC_UnlockHandle(hcrc);
    return result;
}

/**
 * @brief  Computes the 32-bit CRC of a buffer of data in the configured (NON-BLOCKING)
 *         input data format, resetting the CRC unit first (calculate mode). (NON-BLOCKING)
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @param  pBuffer: pointer to the buffer containing the data to be computed.
 * @param  BufferLength: number of elements (bytes / half-words / words
 *         according to the configured input data format).
 * @retval uint32: 32-bit CRC value.
 */
uint32 HAL_CRC_Calculate(HAL_CRC_HandleTypeDef *hcrc, const void *pBuffer, uint32 BufferLength)
{
    uint32 result = 0U;

    if ((CRC_HandleIsValid(hcrc) == 0U) || (pBuffer == NULL_PTR))
    {
        return 0U;
    }
    if (IS_CRC_INPUTDATA_FORMAT(hcrc->InputDataFormat) == 0U)
    {
        hcrc->ErrorCode |= HAL_CRC_ERROR_INVALID_PARAM;
        hcrc->State = HAL_CRC_STATE_ERROR;
        return 0U;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_CRC_Init() is
     * required first) */
    if (CRC_CheckState(hcrc) != HAL_OK)
    {
        return 0U;
    }

    /* Process locked */
    if (CRC_LockHandle(hcrc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return 0U;
    }

    /* ERR-03 / ARCH-CONST-10: a start operation clears the error code */
    hcrc->ErrorCode = HAL_CRC_ERROR_NONE;
    hcrc->State = HAL_CRC_STATE_BUSY;
    hcrc->Instance->CR = CRC_CR_RESET;
    result = CRC_AccumulateFormatUnlocked(hcrc, pBuffer, BufferLength,
                                          hcrc->InputDataFormat);
    hcrc->State = (hcrc->State == HAL_CRC_STATE_ERROR) ? HAL_CRC_STATE_ERROR : HAL_CRC_STATE_READY;
    CRC_UnlockHandle(hcrc);
    return result;
}

/**
  * @}
  */

/** @addtogroup CRC_Exported_Functions_Group3 Peripheral Control functions
  * @{
  */

/**
 * @brief  Resets the CRC computation unit (init registers to the configured (NON-BLOCKING)
 *         initial value). (NON-BLOCKING)
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @retval None
 */
void HAL_CRC_Reset(HAL_CRC_HandleTypeDef *hcrc)
{
    if (CRC_HandleIsValid(hcrc) == 0U)
    {
        return;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_CRC_Init() is
     * required first) */
    if (CRC_CheckState(hcrc) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (CRC_LockHandle(hcrc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    /* ERR-03 / ARCH-CONST-10: a start operation clears the error code */
    hcrc->ErrorCode = HAL_CRC_ERROR_NONE;
    hcrc->State = HAL_CRC_STATE_BUSY;
    hcrc->Instance->CR = CRC_CR_RESET;
    hcrc->State = HAL_CRC_STATE_READY;
    CRC_UnlockHandle(hcrc);
}

/**
 * @brief  Stores an 8-bit data in the independent data (ID) register. (NON-BLOCKING)
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @param  IDValue: 8-bit value to be stored in the ID register.
 * @retval None
 */
void HAL_CRC_SetIDRegister(HAL_CRC_HandleTypeDef *hcrc, uint8 IDValue)
{
    if (CRC_HandleIsValid(hcrc) == 0U)
    {
        return;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_CRC_Init() is
     * required first) */
    if (CRC_CheckState(hcrc) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (CRC_LockHandle(hcrc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    hcrc->Instance->IDR = IDValue;
    CRC_UnlockHandle(hcrc);
}

/**
 * @brief  Returns the 8-bit data stored in the independent data (ID) (NON-BLOCKING)
 *         register. (NON-BLOCKING)
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @retval uint8: 8-bit value of the ID register.
 */
uint8 HAL_CRC_GetIDRegister(HAL_CRC_HandleTypeDef *hcrc)
{
    uint8 idValue = 0U;

    if (CRC_HandleIsValid(hcrc) == 0U)
    {
        return 0U;
    }

    /* Process locked */
    if (CRC_LockHandle(hcrc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return 0U;
    }

    idValue = hcrc->Instance->IDR;
    CRC_UnlockHandle(hcrc);
    return idValue;
}

/**
 * @brief  Returns the current CRC value. (NON-BLOCKING)
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @retval uint32: 32-bit CRC value.
 */
uint32 HAL_CRC_GetCRC(HAL_CRC_HandleTypeDef *hcrc)
{
    uint32 crcValue = 0U;

    if (CRC_HandleIsValid(hcrc) == 0U)
    {
        return 0U;
    }

    /* Process locked */
    if (CRC_LockHandle(hcrc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return 0U;
    }

    crcValue = hcrc->Instance->DR;
    CRC_UnlockHandle(hcrc);
    return crcValue;
}

/**
 * @brief  Returns the CRC handle state. (NON-BLOCKING)
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @retval HAL_CRC_StateTypeDef: the current handle state.
 */
HAL_CRC_StateTypeDef HAL_CRC_GetState(HAL_CRC_HandleTypeDef *hcrc)
{
    /* Check the CRC peripheral handle */
    if (hcrc == NULL_PTR)
    {
        return HAL_CRC_STATE_RESET;
    }

    return hcrc->State;
}

/**
 * @brief  Returns the CRC error code. (NON-BLOCKING)
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @retval uint32: the CRC error code (HAL_CRC_ERROR_xxx).
 */
uint32 HAL_CRC_GetError(HAL_CRC_HandleTypeDef *hcrc)
{
    /* Check the CRC peripheral handle */
    if (hcrc == NULL_PTR)
    {
        return HAL_CRC_ERROR_NONE;
    }

    return hcrc->ErrorCode;
}

/**
  * @}
  */

/**
  * @}
  */

#endif /* HAL_CRC_MODULE_ENABLED */

/*****END OF FILE*****/
