/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):    Xiamen Guoke Anxin Technology Co., LTD
 * FileName:         as32x601_hal_iwdg.c
 * Author:           ANSILIC APPLICATION GROUP
 * Version:          V1.3
 * Date:             2026/09/20
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/24     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.1     add the module guard (HAL_IWDG_MODULE_ENABLED) around the whole implementation
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.2     put the as32x601_hal.h include first (module switch from the conf) before the module headers
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.3     bring the module up to the Medium level
 *                                                       of the architecture specification: add the
 *                                                       shared lock / state helpers, take the lock
 *                                                       and clear the error code in the operation
 *                                                       entry points, apply the busy / reset state
 *                                                       gate, add the run time parameter validation
 *                                                       in front of the first register access, add
 *                                                       the state and error reporting interfaces,
 *                                                       align the version of the four module files
 *                                                       and describe the module without referring
 *                                                       to an external implementation
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Independent Watchdog
 *                  (IWDG) peripheral:
 *                  - Initialization (HAL_IWDG_Init): prescaler number
 *                    (PSC.PSCNUM), reload / timeout value (TO.BVAL) and
 *                    divider number (DIV.DIVNUM) configuration;
 *                  - IO operation functions (HAL_IWDG_Refresh /
 *                    HAL_IWDG_GetCounter).
 *                  The chip-specific enable / lock control is provided by
 *                  this driver (HAL_IWDG_Cmd / HAL_IWDG_LockCmd).
 *                  The IWDG is clocked by the APB_BusS domain (32.768 kHz)
 *                  and has no SMU clock gate (the clock is always on), so
 *                  no MSP hook is provided.
 */
#include "as32x601_hal.h"           /* module switch from as32x601_hal_conf.h */
#include "as32x601_hal_iwdg.h"      /* IWDG HAL API and register macros         */

/* The HAL_IWDG_MODULE_ENABLED switch is provided by the user configuration
 * file (as32x601_hal_conf.h, included above through as32x601_hal.h): the
 * whole implementation is compiled only while the module is enabled. */
#ifdef HAL_IWDG_MODULE_ENABLED

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Check whether the IWDG handle and its instance are valid.
 * @param  hiwdg: pointer to a IWDG_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
uint32 IWDG_HandleIsValid(IWDG_HandleTypeDef *hiwdg)
{
    if (hiwdg == NULL_PTR)
    {
        return 0U;
    }

    if (IS_IWDG_ALL_INSTANCE(hiwdg->Instance) == 0U)
    {
        return 0U;
    }

    return 1U;
}

/**
 * @brief  Check whether the handle accepts a new operation.
 * @note   ARCH-CONST-09: a handle that is BUSY (an operation is ongoing in
 *         another context) rejects any other operation with HAL_BUSY, and a
 *         handle that is not initialized (RESET) requires HAL_IWDG_Init()
 *         first and is rejected with HAL_ERROR. The recoverable state ERROR
 *         accepts a new operation directly.
 * @param  hiwdg: pointer to a IWDG_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK (accepted) / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef IWDG_CheckState(IWDG_HandleTypeDef *hiwdg)
{
    if (hiwdg->State == HAL_IWDG_STATE_BUSY)
    {
        return HAL_BUSY;
    }

    if (hiwdg->State == HAL_IWDG_STATE_RESET)
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer. The
 *         bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; the value is passed to HAL_MutexAcquire() as
 *         is (RTOS ticks; HAL_MAX_DELAY means an infinite wait).
 * @param  hiwdg: pointer to a IWDG_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef IWDG_LockHandle(IWDG_HandleTypeDef *hiwdg, uint32 Timeout)
{
#if (USE_RTOS == 1)
    if (hiwdg->LockMutex == NULL_PTR)
    {
        /* The porting layer did not create the mutex: report it instead of
         * calling the RTOS with a NULL handle */
        return HAL_ERROR;
    }

    return HAL_MutexAcquire(hiwdg->LockMutex, Timeout);
#else
    /* Prevent unused argument compilation warning: the bare-metal lock flag
     * either succeeds immediately or reports HAL_BUSY, it never waits */
    UNUSED(Timeout);

    if (hiwdg->Lock == HAL_LOCKED)
    {
        return HAL_BUSY;
    }

    hiwdg->Lock = HAL_LOCKED;

    return HAL_OK;
#endif /* USE_RTOS */
}

/**
 * @brief  Unlock the handle.
 * @param  hiwdg: pointer to a IWDG_HandleTypeDef structure.
 * @retval None
 */
void IWDG_UnlockHandle(IWDG_HandleTypeDef *hiwdg)
{
#if (USE_RTOS == 1)
    (void)HAL_MutexRelease(hiwdg->LockMutex);
#else
    hiwdg->Lock = HAL_UNLOCKED;
#endif /* USE_RTOS */
}

/* Exported functions ---------------------------------------------------------*/

/** @defgroup IWDG_Exported_Functions IWDG Exported Functions
  * @{
  */

/** @defgroup IWDG_Exported_Functions_Group1 Initialization functions
  * @{
  */

/**
 * @brief  Initialize the IWDG: write the prescaler number, the divider and
 *         the reload / timeout values. (NON-BLOCKING)
 * @note   This function does not start the watchdog: the configuration
 *         enable bit (CFG.EN) is set afterwards by HAL_IWDG_Cmd() with
 *         IWDG_EN_CFG / ENABLE (or by the __HAL_IWDG_START() macro), so the
 *         sequence is: configure the three values, then start the watchdog.
 * @note   The configuration structure metafields (Size / Version), the
 *         reserved words and the three values are validated at run time: an
 *         invalid configuration is rejected with HAL_ERROR and
 *         HAL_IWDG_ERROR_INVALID_PARAM without taking the lock and without
 *         changing the handle state or touching a register.
 * @param  hiwdg: pointer to a IWDG_HandleTypeDef structure that contains
 *         the configuration information for IWDG.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (NULL pointer, invalid instance, invalid
 *         configuration).
 */
HAL_StatusTypeDef HAL_IWDG_Init(IWDG_HandleTypeDef *hiwdg)
{
    /* Check the IWDG handle and instance */
    if (IWDG_HandleIsValid(hiwdg) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_IWDG_ALL_INSTANCE(hiwdg->Instance));
    assert_param(IS_IWDG_PRESCALER(hiwdg->Init.Prescaler));
    assert_param(IS_IWDG_RELOAD(hiwdg->Init.Reload));
    assert_param(IS_IWDG_DIVIDER(hiwdg->Init.Divider));

    /* Run time parameter validation, so that the checks stay effective in a
     * build with the assertions disabled. The metafields of the
     * configuration structure (Size / Version, architecture spec section 22)
     * and the reserved words are validated as well. A rejected call neither
     * takes the lock nor changes the handle state nor touches a register. */
    if ((hiwdg->Init.Size != sizeof(IWDG_InitTypeDef)) ||
        (hiwdg->Init.Version != IWDG_INIT_VERSION) ||
        (IS_IWDG_PRESCALER(hiwdg->Init.Prescaler) == 0U) ||
        (IS_IWDG_RELOAD(hiwdg->Init.Reload) == 0U) ||
        (IS_IWDG_DIVIDER(hiwdg->Init.Divider) == 0U) ||
        (hiwdg->Init.Reserved[0] != 0U) ||
        (hiwdg->Init.Reserved[1] != 0U))
    {
        hiwdg->ErrorCode |= HAL_IWDG_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Allocate the lock resource before its first use, so that a handle that
     * was never initialized cannot report HAL_BUSY from a stale Lock field */
    if (hiwdg->State == HAL_IWDG_STATE_RESET)
    {
        hiwdg->Lock = HAL_UNLOCKED;
    }

    /* Process locked */
    if (IWDG_LockHandle(hiwdg, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hiwdg->ErrorCode = HAL_IWDG_ERROR_NONE;
    hiwdg->State = HAL_IWDG_STATE_BUSY;

    /* Disable the prescaler (PSC.EN cleared), update the prescaler number
       and re-enable the prescaler: the field can only be changed while the
       block is disabled */
    CLEAR_BIT(hiwdg->Instance->PSC, IWDG_PSC_EN);
    CLEAR_BIT(hiwdg->Instance->PSC, IWDG_PSC_PSCNUM);
    SET_BIT(hiwdg->Instance->PSC, ((uint32)(hiwdg->Init.Prescaler) << IWDG_PSC_PSCNUM_Pos));
    SET_BIT(hiwdg->Instance->PSC, IWDG_PSC_EN);

    /* Write the divider value */
    WRITE_REG(hiwdg->Instance->DIV, (uint32)(hiwdg->Init.Divider));

    /* Write the reload / timeout value */
    WRITE_REG(hiwdg->Instance->TO, (uint32)(hiwdg->Init.Reload));

    hiwdg->State = HAL_IWDG_STATE_READY;

    /* Release Lock */
    IWDG_UnlockHandle(hiwdg);

    return HAL_OK;
}

/**
  * @}
  */

/** @defgroup IWDG_Exported_Functions_Group2 IO operation functions
  * @{
  */

/**
 * @brief  Refresh the IWDG (reload the watchdog counter). (NON-BLOCKING)
 * @note   The chip IWDG counter is refreshed by writing the key value
 *         0x2F3E5D8A into the IWDG_CLR register.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_IWDG_Init() is required first).
 * @param  hiwdg: pointer to a IWDG_HandleTypeDef structure that contains
 *         the configuration information for IWDG.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_IWDG_Refresh(IWDG_HandleTypeDef *hiwdg)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the IWDG handle and instance */
    if (IWDG_HandleIsValid(hiwdg) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_IWDG_ALL_INSTANCE(hiwdg->Instance));

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_IWDG_Init() is
     * required first) */
    status = IWDG_CheckState(hiwdg);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (IWDG_LockHandle(hiwdg, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hiwdg->ErrorCode = HAL_IWDG_ERROR_NONE;
    hiwdg->State = HAL_IWDG_STATE_BUSY;

    /* Reload IWDG counter with the refresh key value */
    __HAL_IWDG_RELOAD_COUNTER(hiwdg);

    hiwdg->State = HAL_IWDG_STATE_READY;

    /* Release Lock */
    IWDG_UnlockHandle(hiwdg);

    return HAL_OK;
}

/**
 * @brief  Get the IWDG counter value. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock and applies no state gate, so
 *         it is callable from an interrupt context.
 * @param  hiwdg: pointer to a IWDG_HandleTypeDef structure that contains
 *         the configuration information for IWDG.
 * @retval The IWDG counter value (16-bit); 0 for an invalid handle or
 *         instance.
 */
uint16 HAL_IWDG_GetCounter(IWDG_HandleTypeDef *hiwdg)
{
    /* Check the IWDG handle and instance */
    if (IWDG_HandleIsValid(hiwdg) == 0U)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_IWDG_ALL_INSTANCE(hiwdg->Instance));

    /* Read-only interface: no lock and no state gate */
    return (uint16)(READ_REG(hiwdg->Instance->CNT) & IWDG_CNT_CNTNUM);
}

/**
  * @}
  */

/** @defgroup IWDG_Exported_Functions_Group3 State and error functions
  * @{
  */

/**
 * @brief  Return the IWDG handle state. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock and applies no state gate, so
 *         it is callable from an interrupt context.
 * @param  hiwdg: pointer to a IWDG_HandleTypeDef structure.
 * @retval HAL_IWDG_StateTypeDef: the current handle state
 *         (HAL_IWDG_STATE_RESET for an invalid handle or instance).
 */
HAL_IWDG_StateTypeDef HAL_IWDG_GetState(IWDG_HandleTypeDef *hiwdg)
{
    /* Check the IWDG handle and instance */
    if (IWDG_HandleIsValid(hiwdg) == 0U)
    {
        return HAL_IWDG_STATE_RESET;
    }

    return hiwdg->State;
}

/**
 * @brief  Return the IWDG error code. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock and applies no state gate, so
 *         it is callable from an interrupt context.
 * @param  hiwdg: pointer to a IWDG_HandleTypeDef structure.
 * @retval uint32: the IWDG error code (HAL_IWDG_ERROR_xxx), 0 for an invalid
 *         handle or instance.
 */
uint32 HAL_IWDG_GetError(IWDG_HandleTypeDef *hiwdg)
{
    /* Check the IWDG handle and instance */
    if (IWDG_HandleIsValid(hiwdg) == 0U)
    {
        return HAL_IWDG_ERROR_NONE;
    }

    return hiwdg->ErrorCode;
}

/**
  * @}
  */

/**
  * @}
  */

/* Private functions prototypes ---------------------------------------------*/

/* Exported functions ---------------------------------------------------------*/

/** @defgroup IWDG_Exported_Functions IWDG Exported Functions
  * @{
  */

/** @defgroup IWDG_Exported_Functions_Group1 Enable and lock functions
  * @{
  */

/**
 * @brief  Enable or disable the IWDG prescaler or configuration block. (NON-BLOCKING)
 * @note   The watchdog is effectively started when both the prescaler enable
 *         (PSC.EN, set by HAL_IWDG_Init) and the configuration enable (CFG.EN)
 *         are set.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not been
 *         initialized (HAL_IWDG_Init() is required first).
 * @param  hiwdg:    pointer to a IWDG_HandleTypeDef structure that contains
 *         the configuration information for IWDG.
 * @param  Enable:   specifies the IWDG block to enable / disable.
 *         This parameter can be:
 *            @arg IWDG_EN_PSC
 *            @arg IWDG_EN_CFG
 * @param  NewState: new state of the selected IWDG block (ENABLE or DISABLE).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_IWDG_Cmd(IWDG_HandleTypeDef *hiwdg, uint32 Enable, FunctionalState NewState)
{
    __IO uint32 *enreg_address;
    uint32 tmreg = 0;
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the IWDG handle and instance */
    if (IWDG_HandleIsValid(hiwdg) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_IWDG_ALL_INSTANCE(hiwdg->Instance));
    assert_param(IS_IWDG_EN(Enable));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Run time parameter validation, so that the checks stay effective in a
     * build with the assertions disabled; an invalid selector is rejected
     * before any register access */
    if ((IS_IWDG_ALL_INSTANCE(hiwdg->Instance) == 0U) ||
        (IS_IWDG_EN(Enable) == 0U) ||
        (IS_FUNCTIONAL_STATE(NewState) == 0U))
    {
        hiwdg->ErrorCode |= HAL_IWDG_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized */
    status = IWDG_CheckState(hiwdg);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (IWDG_LockHandle(hiwdg, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hiwdg->ErrorCode = HAL_IWDG_ERROR_NONE;
    hiwdg->State = HAL_IWDG_STATE_BUSY;

    /* Select the register and the enable bit of the requested block (the
       selector was validated above) */
    if (Enable == IWDG_EN_PSC)
    {
        enreg_address = &(hiwdg->Instance->PSC);
        tmreg = IWDG_PSC_EN;
    }
    else
    {
        enreg_address = &(hiwdg->Instance->CFG);
        tmreg = IWDG_CFG_EN;
    }

    if (NewState != DISABLE)
    {
        /* Enable the selected IWDG block */
        SET_BIT(*enreg_address, tmreg);
    }
    else
    {
        /* Disable the selected IWDG block */
        CLEAR_BIT(*enreg_address, tmreg);
    }

    hiwdg->State = HAL_IWDG_STATE_READY;

    /* Release Lock */
    IWDG_UnlockHandle(hiwdg);

    return HAL_OK;
}

/**
 * @brief  Lock or unlock the IWDG prescaler or configuration block. (NON-BLOCKING)
 * @note   A locked block rejects further writes of its registers.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not been
 *         initialized (HAL_IWDG_Init() is required first).
 * @param  hiwdg:    pointer to a IWDG_HandleTypeDef structure that contains
 *         the configuration information for IWDG.
 * @param  Lock:     specifies the IWDG block to lock / unlock.
 *         This parameter can be:
 *            @arg IWDG_LOCK_PSC
 *            @arg IWDG_LOCK_CFG
 * @param  NewState: new state of the selected IWDG lock (ENABLE or DISABLE).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_IWDG_LockCmd(IWDG_HandleTypeDef *hiwdg, uint32 Lock, FunctionalState NewState)
{
    __IO uint32 *enreg_address;
    uint32 tmreg = 0;
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the IWDG handle and instance */
    if (IWDG_HandleIsValid(hiwdg) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_IWDG_ALL_INSTANCE(hiwdg->Instance));
    assert_param(IS_IWDG_LOCK(Lock));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Run time parameter validation, so that the checks stay effective in a
     * build with the assertions disabled; an invalid selector is rejected
     * before any register access */
    if ((IS_IWDG_ALL_INSTANCE(hiwdg->Instance) == 0U) ||
        (IS_IWDG_LOCK(Lock) == 0U) ||
        (IS_FUNCTIONAL_STATE(NewState) == 0U))
    {
        hiwdg->ErrorCode |= HAL_IWDG_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized */
    status = IWDG_CheckState(hiwdg);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (IWDG_LockHandle(hiwdg, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hiwdg->ErrorCode = HAL_IWDG_ERROR_NONE;
    hiwdg->State = HAL_IWDG_STATE_BUSY;

    /* Select the register and the lock bit of the requested block (the
       selector was validated above) */
    if (Lock == IWDG_LOCK_PSC)
    {
        enreg_address = &(hiwdg->Instance->PSC);
        tmreg = IWDG_PSC_LOCK;
    }
    else
    {
        enreg_address = &(hiwdg->Instance->CFG);
        tmreg = IWDG_CFG_LOCK;
    }

    if (NewState != DISABLE)
    {
        /* Lock the selected IWDG block */
        SET_BIT(*enreg_address, tmreg);
    }
    else
    {
        /* Unlock the selected IWDG block */
        CLEAR_BIT(*enreg_address, tmreg);
    }

    hiwdg->State = HAL_IWDG_STATE_READY;

    /* Release Lock */
    IWDG_UnlockHandle(hiwdg);

    return HAL_OK;
}

/**
  * @}
  */

/**
  * @}
  */

#endif /* HAL_IWDG_MODULE_ENABLED */

/*****END OF FILE*****/
