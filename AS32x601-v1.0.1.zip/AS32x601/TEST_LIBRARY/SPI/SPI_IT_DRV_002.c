/**
 * @file    SPI_IT_DRV_002.c
 * @brief   HAL SPI integration test case 002 (slave select sweep).
 *
 * HAL library port of the original AS32x601 standard-library test case
 * SPI_IT_DRV_002.c, which drives SPI3 in master mode and lets the operator
 * choose the hardware slave select (SPI_Slave0 .. SPI_Slave3) on the console.
 * The port sweeps all four selections in one run. Only HAL library APIs are
 * used; the register read backs are there to document what was programmed.
 *
 * Tested functionality:
 *   HAL_SPI_StructInit()
 *   HAL_SPI_Init()
 *   HAL_SPI_NSSConfig()         (SPI_Slave0 .. SPI_Slave3)
 *   HAL_SPI_Transmit()          (blocking, 64 frames of 8 bit)
 *   HAL_SPI_ResetFIFO()
 *   HAL_SPI_GetState() / HAL_SPI_GetError()
 *   HAL_SPI_MspInit()           (overridden: clock gate, reset pulse, pins)
 *
 * Test procedure:
 *   For every slave select of the table (SPI_Slave0 .. SPI_Slave3):
 *     1. initialize SPI3 in master mode with the divider of the reference
 *        case (/512);
 *     2. reset both FIFOs and select that single slave line;
 *     3. read the selection back from the SSR register;
 *     4. transmit 64 frames and check the status / state / error code.
 *
 * Expected behaviour:
 *   - SSR carries exactly the requested selection bit and no other one;
 *   - every transmission completes with HAL_OK and the handle returns to
 *     READY with the error code NONE;
 *   - every check prints [PASS] and "summary : failures = 0";
 *   - an oscilloscope on the four chip select pins shows only the selected
 *     line going active (CS0 = PC10, CS1 = PC11, CS2 = PC12, CS3 = PD0) while
 *     the other three stay inactive.
 *
 * Note:
 *   - The chip drives the slave selects from the SSR register, so all four CS
 *     pins are mapped to the SPI alternate function (GPIO_MODE_AF_PP) here.
 *     The reference test case configured them as plain GPIO outputs instead
 *     (and never wrote the pins), so its slave select stayed inactive: the
 *     selection could not be observed on the pins with that configuration.
 *   - The reference case printed "Invalid input, please enter 0-8" for a wrong
 *     console character although it accepts 0..3 only; the sweep makes the
 *     message obsolete.
 *   - The received frames are discarded by HAL_SPI_Transmit() in master mode,
 *     so no peer is required for this case.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console: USART0 on GPIOD pin 8 (TX) / pin 9 (RX), 115200 8N1 */
#define TEST_BAUDRATE                   (115200U)

/* Device under test: SPI3 (as in the reference test case)
 *   CS0 = PC10   CS1 = PC11   CS2 = PC12   CS3 = PD0
 *   SCK = PD3    MOSI = PD1   MISO = PD2
 */
#define TEST_SPI                        SPI3
#define TEST_CS0_PORT                   GPIOC
#define TEST_CS0_PIN                    GPIO_PIN_10
#define TEST_CS0_SOURCE                 GPIO_PinSource10
#define TEST_CS1_PORT                   GPIOC
#define TEST_CS1_PIN                    GPIO_PIN_11
#define TEST_CS1_SOURCE                 GPIO_PinSource11
#define TEST_CS2_PORT                   GPIOC
#define TEST_CS2_PIN                    GPIO_PIN_12
#define TEST_CS2_SOURCE                 GPIO_PinSource12
#define TEST_CS3_PORT                   GPIOD
#define TEST_CS3_PIN                    GPIO_PIN_0
#define TEST_CS3_SOURCE                 GPIO_PinSource0
#define TEST_SCK_PORT                   GPIOD
#define TEST_SCK_PIN                    GPIO_PIN_3
#define TEST_SCK_SOURCE                 GPIO_PinSource3
#define TEST_MOSI_PORT                  GPIOD
#define TEST_MOSI_PIN                   GPIO_PIN_1
#define TEST_MOSI_SOURCE                GPIO_PinSource1
#define TEST_MISO_PORT                  GPIOD
#define TEST_MISO_PIN                   GPIO_PIN_2
#define TEST_MISO_SOURCE                GPIO_PinSource2
#define TEST_PIN_AF                     GPIO_AF_SPI3

/* Frame geometry, timeouts and the selection table */
#define TX_FRAME_COUNT                  (64U)
#define TRANSFER_TIMEOUT_MS             (1000U)
#define SLAVE_COUNT                     (4U)

/* Private variables ---------------------------------------------------------*/
static SPI_HandleTypeDef hspi_dev;              /*!< device under test      */
static HAL_SMU_HandleTypeDef hsmu_clk;          /*!< SMU handle (clock tree) */
static uint8 tx_data[TX_FRAME_COUNT];           /*!< transmit pattern        */
static volatile uint32 check_failures = 0U;     /*!< failed check counter    */

/* Slave select register value and the pin name it stands for */
static const uint32 slave_sel[SLAVE_COUNT] = {
    SPI_Slave0, SPI_Slave1, SPI_Slave2, SPI_Slave3
};
static const char * const slave_name[SLAVE_COUNT] = {
    "SPI_Slave0 (PC10)", "SPI_Slave1 (PC11)", "SPI_Slave2 (PC12)",
    "SPI_Slave3 (PD0)"
};

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void Check(const char *name, uint32 condition);
static void Summary(void);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    SPI_InitTypeDef spi_init;
    HAL_StatusTypeDef status;
    uint32 index;
    uint32 sel_index;
    uint32 ssr;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock tree */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART (USART0 on GPIOD pin 8 / pin 9) */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== SPI_IT_DRV_002 : slave select sweep (SPI3) ===\r\n");

    /* Transmit pattern: 0, 1, 2 .. 63 (as in the reference test case) */
    for (index = 0U; index < TX_FRAME_COUNT; index++)
    {
        tx_data[index] = (uint8)index;
    }

    /* Step 1: initialize the device under test (divider /512 of the reference
     * test case, master mode, 8 bit frames, Motorola mode 0, normal transfer) */
    __HAL_CLEAR_STRUCT(&hspi_dev);
    HAL_SPI_StructInit(&spi_init);
    spi_init.SPI_CLKDiv       = SPI_CLKDiv512;
    spi_init.SPI_Mode         = SPI_Mode_Master;
    spi_init.SPI_FrameSize    = SPI_FrameSize_8b;
    spi_init.SPI_MotorolaMode = SPI_Motorola_Mode0;
    spi_init.SPI_TransMode    = SPI_TransNor;

    hspi_dev.Instance = TEST_SPI;
    hspi_dev.Init     = spi_init;

    status = HAL_SPI_Init(&hspi_dev);
    Check("HAL_SPI_Init returns HAL_OK", (uint32)((status == HAL_OK) ? 1U : 0U));
    Check("state after init is READY",
          (uint32)((HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_READY) ? 1U : 0U));

    /* Reset both FIFOs and enable the peripheral, as the reference case does */
    HAL_SPI_ResetFIFO(&hspi_dev, SPI_RESETFIFO_TXANDRX);
    HAL_SPI_Cmd(&hspi_dev, SPI_ENABLE);
    Check("CR1 FIFO reset request is cleared again",
          (uint32)((((uint32)TEST_SPI->CR1 &
                     (SPI_CR1_RXRE | SPI_CR1_TXRE)) == 0U) ? 1U : 0U));
    Check("CR0.SPE is set after HAL_SPI_Cmd(ENABLE)",
          (uint32)((((uint32)TEST_SPI->CR0 & SPI_CR0_SPE) != 0U) ? 1U : 0U));

    for (sel_index = 0U; sel_index < SLAVE_COUNT; sel_index++)
    {
        printf("\r\n-- slave select %u : %s --\r\n",
               PRINT_U32(sel_index), slave_name[sel_index]);

        /* Step 2: select that single slave line */
        HAL_SPI_NSSConfig(&hspi_dev, slave_sel[sel_index], SPI_ENABLE);

        /* Step 3: the SSR register must carry exactly this selection */
        ssr = (uint32)TEST_SPI->SSR & SPI_SSR_SSR_Msk;
        printf("SSR          : 0x%02X (requested 0x%02X) %s\r\n",
               PRINT_U32(ssr), PRINT_U32(slave_sel[sel_index]),
               ((ssr == slave_sel[sel_index]) ? "[PASS]" : "[FAIL]"));
        if (ssr != slave_sel[sel_index])
        {
            check_failures++;
        }

        /* Step 4: transmit the pattern over the selected line */
        status = HAL_SPI_Transmit(&hspi_dev, tx_data, TX_FRAME_COUNT,
                                  TRANSFER_TIMEOUT_MS);
        Check("HAL_SPI_Transmit returns HAL_OK", (uint32)((status == HAL_OK) ? 1U : 0U));
        Check("state after the transfer is READY",
              (uint32)((HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_READY) ? 1U : 0U));
        Check("error code after the transfer is NONE",
              (uint32)((HAL_SPI_GetError(&hspi_dev) == HAL_SPI_ERROR_NONE) ? 1U : 0U));
        Check("the selection is still the requested one",
              (uint32)((((uint32)TEST_SPI->SSR & SPI_SSR_SSR_Msk) ==
                        slave_sel[sel_index]) ? 1U : 0U));

        /* Deselect before the next iteration, so the lines never overlap */
        HAL_SPI_NSSConfig(&hspi_dev, slave_sel[sel_index], SPI_DISABLE);
        Check("selection cleared again",
              (uint32)((((uint32)TEST_SPI->SSR & SPI_SSR_SSR_Msk) == 0U) ? 1U : 0U));
    }

    Summary();

    while (1)
    {
        delay_ms(1000U);
    }
}

/**
 * @brief  Report the result of one check.
 * @param  name: short description of the check.
 * @param  condition: 0 = FAIL, non zero = PASS.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("%-46s : [PASS]\r\n", name);
    }
    else
    {
        check_failures++;
        printf("%-46s : [FAIL]\r\n", name);
    }
}

/**
 * @brief  Print the accumulated failure counter.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(check_failures));
}

/**
 * @brief  MSP initialization of the device under test.
 * @note   Strong override of the weak driver callback: it runs on the first
 *         HAL_SPI_Init() call, before the handle lock is taken and before the
 *         first register access.
 * @param  hspi: SPI handle of the device under test.
 * @retval None
 */
void HAL_SPI_MspInit(SPI_HandleTypeDef *hspi)
{
    GPIO_InitTypeDef gpio;

    if (hspi->Instance != TEST_SPI)
    {
        return;
    }

    /* Peripheral clock gate and reset pulse */
    __HAL_SMU_SPI3_CLK_ENABLE();
    __HAL_SMU_SPI3_FORCE_RESET();
    __HAL_SMU_SPI3_RELEASE_RESET();

    /* Port clock gates used by this case */
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&gpio);
    gpio.Size         = sizeof(gpio);
    gpio.Version      = GPIO_INIT_VERSION;
    gpio.Pull         = GPIO_NOPULL;
    gpio.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    gpio.Alternate    = TEST_PIN_AF;

    /* The four chip select lines: driven by the SSR register, therefore mapped
     * to the SPI alternate function */
    gpio.Mode = GPIO_MODE_AF_PP;

    HAL_GPIO_PinAFConfig(TEST_CS0_PORT, TEST_CS0_SOURCE, TEST_PIN_AF);
    gpio.Pin = TEST_CS0_PIN;
    HAL_GPIO_Init(TEST_CS0_PORT, &gpio);

    HAL_GPIO_PinAFConfig(TEST_CS1_PORT, TEST_CS1_SOURCE, TEST_PIN_AF);
    gpio.Pin = TEST_CS1_PIN;
    HAL_GPIO_Init(TEST_CS1_PORT, &gpio);

    HAL_GPIO_PinAFConfig(TEST_CS2_PORT, TEST_CS2_SOURCE, TEST_PIN_AF);
    gpio.Pin = TEST_CS2_PIN;
    HAL_GPIO_Init(TEST_CS2_PORT, &gpio);

    HAL_GPIO_PinAFConfig(TEST_CS3_PORT, TEST_CS3_SOURCE, TEST_PIN_AF);
    gpio.Pin = TEST_CS3_PIN;
    HAL_GPIO_Init(TEST_CS3_PORT, &gpio);

    /* SCK and MOSI */
    HAL_GPIO_PinAFConfig(TEST_SCK_PORT, TEST_SCK_SOURCE, TEST_PIN_AF);
    gpio.Pin = TEST_SCK_PIN;
    HAL_GPIO_Init(TEST_SCK_PORT, &gpio);

    HAL_GPIO_PinAFConfig(TEST_MOSI_PORT, TEST_MOSI_SOURCE, TEST_PIN_AF);
    gpio.Pin = TEST_MOSI_PIN;
    HAL_GPIO_Init(TEST_MOSI_PORT, &gpio);

    /* MISO: alternate function input, floating */
    HAL_GPIO_PinAFConfig(TEST_MISO_PORT, TEST_MISO_SOURCE, TEST_PIN_AF);
    gpio.Pin  = TEST_MISO_PIN;
    gpio.Mode = GPIO_MODE_INPUT;
    HAL_GPIO_Init(TEST_MISO_PORT, &gpio);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the CLINT / CMU / MPU / USART integration tests.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef    SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the same set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls (PMU_CheckState) */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Clock tree order: dividers first (while the core still runs on FIRC),
       then the PLL and the switch to it */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
