/**
 * @file    DAC_IT_DRV_012.c
 * @brief   HAL DAC integration test case 012 (parameter validation).
 *
 * Extension case of the DAC integration test suite: it collects the parameter
 * validation of every interface of the driver and checks that a rejected call
 * neither changes the handle state nor touches the registers. The runtime
 * checks are the ones that stay in place when the assertions are disabled
 * (ERR-03), which is the configuration of this library by default.
 * Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_DAC_Init()                (7 invalid configurations)
 *   HAL_DAC_SetValue()            (data above 0xFF)
 *   HAL_DAC_ResetCmd()            (parameter above 1)
 *   HAL_DAC_ComparatorCmd()       (parameter above 1)
 *   HAL_DAC_ConfigComparator()    (NULL structure, invalid enable / hysteresis)
 *   every interface               (NULL handle)
 *   HAL_DAC_ERROR_INVALID_PARAM   (error code reporting)
 *
 * Test procedure:
 *   1. Initialize DAC0 and take a snapshot of its registers;
 *   2. Feed seven invalid initialization structures (wrong Size, wrong Version,
 *      enable = 2, mode = 2, reference = 2, divider = 0x100, NULL handle) and
 *      check that each one is rejected with INVALID_PARAM while the handle
 *      state and the registers stay untouched;
 *   3. Reject the out of range data values, the out of range control
 *      parameters and the invalid comparator configurations;
 *   4. Reject the NULL handle on every interface and check the read-back
 *      interfaces return their documented "invalid" values;
 *   5. Check that a valid call is still accepted afterwards, so a rejected call
 *      does not leave the module unusable.
 *
 * @note   The comparator mode field is covered by assert_param() only (the
 *         runtime validation checks the enable and the hysteresis fields), so
 *         this case does not feed an out of range mode: writing it would be
 *         undefined. The mode enumeration is checked by case 015 instead.
 *
 * Expected behaviour:
 *   - every invalid parameter is rejected with HAL_ERROR and sets
 *     HAL_DAC_ERROR_INVALID_PARAM;
 *   - a rejected call leaves the handle state and the registers unchanged;
 *   - the read-back interfaces return 0 / RESET for a NULL handle;
 *   - the module still works after the rejected calls;
 *   - every check prints [PASS] and "summary : failures = 0".
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define -----------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* DAC output pins and comparator input pins of this suite, taken from the
 * device IO map (ioDoc): DAC0_OUT = PE4, DAC1_OUT = PC13,
 * CMP0_P = PE2, CMP0_N = PE3. */
#define TEST_DAC0_PORT              GPIOE
#define TEST_DAC0_PIN               GPIO_PIN_4
#define TEST_DAC0_SOURCE            GPIO_PinSource4
#define TEST_DAC1_PORT              GPIOC
#define TEST_DAC1_PIN               GPIO_PIN_13
#define TEST_DAC1_SOURCE            GPIO_PinSource13
#define TEST_CMP_PORT               GPIOE
#define TEST_CMP_P_PIN              GPIO_PIN_2
#define TEST_CMP_N_PIN              GPIO_PIN_3
#define TEST_CMP_P_SOURCE           GPIO_PinSource2
#define TEST_CMP_N_SOURCE           GPIO_PinSource3

/* Private variables ---------------------------------------------------------*/
static volatile uint32 check_failures = 0U;  /*!< failed check counter        */
static HAL_SMU_HandleTypeDef hsmu_clk;       /*!< SMU handle (clock tree)     */
static DAC_HandleTypeDef hadac_dev;          /*!< DAC under test              */

/* MSP callback bookkeeping (defined with the callbacks at the end of the file) */
extern uint32 Dac_MspInitCount;
extern uint32 Dac_MspDeInitCount;
extern uint32 Dac_MspStateAtInit;
extern uint32 Dac_MspLockAtInit;
extern uint32 Dac_MspStateAtDeInit;

/* Private function prototypes -----------------------------------------------*/
/* Shared helpers of this suite (defined at the end of this file) */
void Check(const char *name, uint32 condition);
void Summary(void);
void SystemClock_Init(void);
void Dac_PeriphClockEnable(DAC_TypeDef *instance);
void Dac_PinConfig(DAC_TypeDef *instance);
void Dac_InitStruct_Default(DAC_InitTypeDef *p_init);
HAL_StatusTypeDef Dac_Config(DAC_TypeDef *instance, FunctionalState enable, uint32 divider);
HAL_StatusTypeDef Dac_ConfigComparator(DAC_HandleTypeDef *hdac, uint32 cmp_enable, uint32 cmp_mode, uint32 cmp_hys);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    DAC_InitTypeDef   dac_init;
    DAC_CMPConfTypeDef cmp_conf;
    DAC_HandleTypeDef bad_handle;
    uint32 ctrl_snap;
    uint32 dout_snap;
    uint32 cmpc_snap;
    uint32 state_snap;
    uint32 rejected;
    uint32 index;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== DAC_IT_DRV_012 : parameter validation ===\r\n");

    /* ---- Step 1: the baseline ---------------------------------------- */
    Check("HAL_DAC_Init() returns HAL_OK", (Dac_Config(DAC0, ENABLE, 0x1EU) == HAL_OK));
    Check("HAL_DAC_SetValue(0x80) returns HAL_OK",
          (HAL_DAC_SetValue(&hadac_dev, 0x80U) == HAL_OK));

    ctrl_snap  = (uint32)DAC0->CTRL;
    dout_snap  = (uint32)DAC0->DOUT;
    cmpc_snap  = (uint32)DAC0->CMP_CTRL;
    state_snap = (uint32)HAL_DAC_GetState(&hadac_dev);

    /* ---- Step 2: the invalid initialization structures --------------- */
    rejected = 0U;
    for (index = 0U; index < 6U; index++)
    {
        Dac_InitStruct_Default(&dac_init);

        switch (index)
        {
            case 0: dac_init.Size              = 0U;                  break;
            case 1: dac_init.Version           = 0U;                  break;
            case 2: dac_init.DAC_Enable        = 2U;                  break;
            case 3: dac_init.DAC_Mode          = 2U;                  break;
            case 4: dac_init.DAC_VrefMode      = 2U;                  break;
            default:dac_init.DAC_ClockDivider  = 0x100U;              break;
        }

        hadac_dev.Init      = dac_init;
        hadac_dev.ErrorCode = HAL_DAC_ERROR_NONE;
        if ((HAL_DAC_Init(&hadac_dev) == HAL_ERROR) &&
            ((HAL_DAC_GetError(&hadac_dev) & HAL_DAC_ERROR_INVALID_PARAM) != 0U))
        {
            rejected++;
        }
    }
    Check("the 6 invalid init structures are rejected with INVALID_PARAM", (rejected == 6U) ? 1U : 0U);
    Check("HAL_DAC_Init(NULL) is rejected", (HAL_DAC_Init(NULL_PTR) == HAL_ERROR));

    __HAL_CLEAR_STRUCT(&bad_handle);
    bad_handle.Instance = (DAC_TypeDef *)0x40000000UL;
    bad_handle.Init.Size    = sizeof(DAC_InitTypeDef);
    bad_handle.Init.Version = DAC_INIT_VERSION;
    Check("HAL_DAC_Init() with a foreign instance is rejected",
          (HAL_DAC_Init(&bad_handle) == HAL_ERROR));

    Check("the rejected initializations left the handle state unchanged",
          ((uint32)HAL_DAC_GetState(&hadac_dev) == state_snap) ? 1U : 0U);
    Check("the rejected initializations left the registers unchanged",
          (((uint32)DAC0->CTRL == ctrl_snap) && ((uint32)DAC0->DOUT == dout_snap) &&
           ((uint32)DAC0->CMP_CTRL == cmpc_snap)) ? 1U : 0U);

    /* ---- Step 3: the invalid data and control parameters ------------- */
    hadac_dev.ErrorCode = HAL_DAC_ERROR_NONE;
    Check("HAL_DAC_SetValue(0x100) is rejected with INVALID_PARAM",
          ((HAL_DAC_SetValue(&hadac_dev, 0x100U) == HAL_ERROR) &&
           ((HAL_DAC_GetError(&hadac_dev) & HAL_DAC_ERROR_INVALID_PARAM) != 0U)) ? 1U : 0U);
    Check("HAL_DAC_SetValue(0xFFFFFFFF) is rejected",
          (HAL_DAC_SetValue(&hadac_dev, 0xFFFFFFFFU) == HAL_ERROR));
    Check("the rejected data values left DAC_DOUT unchanged",
          ((uint32)DAC0->DOUT == dout_snap) ? 1U : 0U);

    hadac_dev.ErrorCode = HAL_DAC_ERROR_NONE;
    Check("HAL_DAC_ResetCmd(2) is rejected with INVALID_PARAM",
          ((HAL_DAC_ResetCmd(&hadac_dev, 2U) == HAL_ERROR) &&
           ((HAL_DAC_GetError(&hadac_dev) & HAL_DAC_ERROR_INVALID_PARAM) != 0U)) ? 1U : 0U);

    hadac_dev.ErrorCode = HAL_DAC_ERROR_NONE;
    Check("HAL_DAC_ComparatorCmd(2) is rejected with INVALID_PARAM",
          ((HAL_DAC_ComparatorCmd(&hadac_dev, 2U) == HAL_ERROR) &&
           ((HAL_DAC_GetError(&hadac_dev) & HAL_DAC_ERROR_INVALID_PARAM) != 0U)) ? 1U : 0U);

    /* ---- Step 4: the invalid comparator configurations --------------- */
    Check("a NULL comparator structure is rejected",
          (HAL_DAC_ConfigComparator(&hadac_dev, NULL_PTR) == HAL_ERROR));

    hadac_dev.ErrorCode = HAL_DAC_ERROR_NONE;
    HAL_DAC_CMPStructInit(&cmp_conf);
    cmp_conf.CMP_Enable = 2U;
    Check("an invalid comparator enable field is rejected with INVALID_PARAM",
          ((HAL_DAC_ConfigComparator(&hadac_dev, &cmp_conf) == HAL_ERROR) &&
           ((HAL_DAC_GetError(&hadac_dev) & HAL_DAC_ERROR_INVALID_PARAM) != 0U)) ? 1U : 0U);

    hadac_dev.ErrorCode = HAL_DAC_ERROR_NONE;
    HAL_DAC_CMPStructInit(&cmp_conf);
    cmp_conf.CMP_Hysteresis = 8U;
    Check("an invalid comparator hysteresis (8) is rejected with INVALID_PARAM",
          ((HAL_DAC_ConfigComparator(&hadac_dev, &cmp_conf) == HAL_ERROR) &&
           ((HAL_DAC_GetError(&hadac_dev) & HAL_DAC_ERROR_INVALID_PARAM) != 0U)) ? 1U : 0U);
    Check("the rejected comparator configurations left DAC_CMP_CTRL unchanged",
          ((uint32)DAC0->CMP_CTRL == cmpc_snap) ? 1U : 0U);

    /* ---- Step 5: the NULL handle on every interface ------------------ */
    Check("HAL_DAC_DeInit(NULL) is rejected", (HAL_DAC_DeInit(NULL_PTR) == HAL_ERROR));
    Check("HAL_DAC_Start(NULL) is rejected", (HAL_DAC_Start(NULL_PTR) == HAL_ERROR));
    Check("HAL_DAC_Stop(NULL) is rejected", (HAL_DAC_Stop(NULL_PTR) == HAL_ERROR));
    Check("HAL_DAC_SetValue(NULL) is rejected", (HAL_DAC_SetValue(NULL_PTR, 0x10U) == HAL_ERROR));
    Check("HAL_DAC_ResetCmd(NULL) is rejected", (HAL_DAC_ResetCmd(NULL_PTR, 1U) == HAL_ERROR));
    Check("HAL_DAC_ComparatorCmd(NULL) is rejected", (HAL_DAC_ComparatorCmd(NULL_PTR, 1U) == HAL_ERROR));
    Check("HAL_DAC_ConfigComparator(NULL) is rejected",
          (HAL_DAC_ConfigComparator(NULL_PTR, &cmp_conf) == HAL_ERROR));
    Check("HAL_DAC_GetValue(NULL) returns 0", (HAL_DAC_GetValue(NULL_PTR) == 0U) ? 1U : 0U);
    Check("HAL_DAC_GetComparatorResult(NULL) returns 0",
          (HAL_DAC_GetComparatorResult(NULL_PTR) == 0U) ? 1U : 0U);
    Check("HAL_DAC_GetError(NULL) returns 0", (HAL_DAC_GetError(NULL_PTR) == 0U) ? 1U : 0U);
    Check("HAL_DAC_GetState(NULL) returns RESET",
          (HAL_DAC_GetState(NULL_PTR) == HAL_DAC_STATE_RESET) ? 1U : 0U);

    /* ---- Step 6: the module still works ------------------------------ */
    Check("a valid data value is still accepted after the rejected calls",
          ((HAL_DAC_SetValue(&hadac_dev, 0x33U) == HAL_OK) &&
           ((uint32)DAC0->DOUT == 0x33U)) ? 1U : 0U);
    Check("a valid comparator configuration is still accepted",
          (Dac_ConfigComparator(&hadac_dev, DAC_CMP_ENABLE, DAC_CMP_MD_DACO,
                                DAC_CMP_HYS_0MV) == HAL_OK));
    Check("the state is still READY",
          (HAL_DAC_GetState(&hadac_dev) == HAL_DAC_STATE_READY) ? 1U : 0U);

    Summary();

    for (;;)
    {
        /* Keep the console alive for the observation */
        printf("state = %u, error = 0x%08X, CTRL = 0x%02X, DOUT = %u\r\n",
               PRINT_U32(HAL_DAC_GetState(&hadac_dev)),
               PRINT_U32(HAL_DAC_GetError(&hadac_dev)),
               PRINT_U32(DAC0->CTRL),
               PRINT_U32(DAC0->DOUT));
        delay_ms(2000U);
    }
}
/*****END OF FILE*****/

/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the other integration tests of this library:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2 and
 *         CANX2 by 8, which gives core 180 MHz, AXILiteBus1 (the DAC0 clock)
 *         and AXILiteBus2 (the DAC1 clock) 45 MHz and APB 22.5 MHz.
 * @note   Clock tree order: the dividers are written while the system clock
 *         is still the power on source (FIRC), then the PLL is configured and
 *         the system clock is switched to it. That last call programs the
 *         flash controller clock before the switch (the core keeps fetching
 *         from the flash) and updates SystemCoreClock afterwards.
 * @param  None
 * @retval None
 */
void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef    SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks of this suite (the DAC / comparator pins) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Enable the clock gate of a DAC instance and release its bus reset.
 * @note   The default MSP callbacks of the DAC driver are empty by design (the
 *         clock gate belongs to the application), therefore this suite performs
 *         the gate and bus reset handling itself. The macros drive
 *         SMU->ALB1CFGR (DAC0) / SMU->ALB2CFGR (DAC1), which is a different
 *         reset domain than the module reset bit DAC_CTRL.RESETN handled by
 *         HAL_DAC_ResetCmd().
 * @param  instance: DAC0 or DAC1
 * @retval None
 */
void Dac_PeriphClockEnable(DAC_TypeDef *instance)
{
    if (instance == DAC0)
    {
        __HAL_SMU_DAC0_CLK_ENABLE();
        __HAL_SMU_DAC0_FORCE_RESET();
        __HAL_SMU_DAC0_RELEASE_RESET();
    }
    else
    {
        __HAL_SMU_DAC1_CLK_ENABLE();
        __HAL_SMU_DAC1_FORCE_RESET();
        __HAL_SMU_DAC1_RELEASE_RESET();
    }
}

/**
 * @brief  Configure a group of pins as analog pins.
 * @note   Every pin of the mask is configured on its own, so that the
 *         multiplexer register of each pin is programmed with the "plain pin"
 *         alternate function before the pin is switched to the analog mode.
 * @param  port: GPIO port the pins belong to
 * @param  pins: pin mask (GPIO_PIN_x or a combination)
 * @retval None
 */
static void Gpio_AnalogConfig(GPIO_TypeDef *port, uint32 pins)
{
    GPIO_InitTypeDef gpio_init;
    uint32 i;
    uint32 pin;

    __HAL_CLEAR_STRUCT(&gpio_init);
    gpio_init.Size         = sizeof(gpio_init);
    gpio_init.Version      = GPIO_INIT_VERSION;
    gpio_init.Pull         = GPIO_NOPULL;
    gpio_init.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;
    gpio_init.Mode         = GPIO_MODE_ANALOG;
    gpio_init.Alternate    = GPIO_AF_Pin_x;

    for (i = 0U; i < 16U; i++)
    {
        pin = (uint32)(1UL << i);
        if ((pins & pin) != 0U)
        {
            HAL_GPIO_PinAFConfig(port, i, GPIO_AF_Pin_x);
            gpio_init.Pin = pin;
            (void)HAL_GPIO_Init(port, &gpio_init);
        }
    }
}

/**
 * @brief  Configure the analog pins of one DAC instance.
 * @note   DAC0 drives PE4 and uses the comparator inputs CMP0_P (PE2) and
 *         CMP0_N (PE3); DAC1 drives PC13. The pin map comes from the device IO
 *         map (ioDoc.xlsx, column "analog function").
 * @param  instance: DAC0 or DAC1
 * @retval None
 */
void Dac_PinConfig(DAC_TypeDef *instance)
{
    if (instance == DAC0)
    {
        Gpio_AnalogConfig(TEST_DAC0_PORT, TEST_DAC0_PIN);
        Gpio_AnalogConfig(TEST_CMP_PORT, TEST_CMP_P_PIN | TEST_CMP_N_PIN);
    }
    else
    {
        Gpio_AnalogConfig(TEST_DAC1_PORT, TEST_DAC1_PIN);
    }
}

/**
 * @brief  Fill a DAC init structure with the configuration of the reference
 *         test project (the baseline every case starts from).
 * @note   The structure meta fields (Size / Version) are filled by
 *         HAL_DAC_StructInit(), and the initialization interface validates
 *         them at run time, so this helper is the only place where the
 *         baseline is built.
 * @param  p_init: pointer to the init structure to fill
 * @retval None
 */
void Dac_InitStruct_Default(DAC_InitTypeDef *p_init)
{
    HAL_DAC_StructInit(p_init);

    p_init->DAC_Enable       = DISABLE;
    p_init->DAC_Mode         = DAC_OUTPUTBUFFER_ENABLE;
    p_init->DAC_VrefMode     = DAC_VREF_MD_VREFP;
    p_init->DAC_ClockDivider = 0x1EU;      /* the divider of the reference case */
}

/**
 * @brief  Configure and initialize one DAC instance.
 * @note   HAL_DAC_Init() does not release the module reset (DAC_CTRL.RESETN
 *         resets to 0), so HAL_DAC_ResetCmd() is called afterwards to release
 *         it: without that call HAL_DAC_Start() / HAL_DAC_SetValue() report
 *         HAL_ERROR. The clear+settle delay follows the sequence documented by
 *         the driver (release the reset, wait for the data path to settle).
 * @param  instance: DAC0 or DAC1
 * @param  enable: initial value of the DAC enable field (ENABLE / DISABLE)
 * @param  divider: clock divide ratio (1 to 0xFF)
 * @retval HAL status of HAL_DAC_Init()
 */
HAL_StatusTypeDef Dac_Config(DAC_TypeDef *instance, FunctionalState enable, uint32 divider)
{
    DAC_InitTypeDef dac_init;
    HAL_StatusTypeDef status;

    Dac_PinConfig(instance);

    __HAL_CLEAR_STRUCT(&hadac_dev);
    hadac_dev.Instance = instance;

    Dac_InitStruct_Default(&dac_init);
    dac_init.DAC_Enable       = enable;
    dac_init.DAC_ClockDivider = divider;
    hadac_dev.Init = dac_init;

    status = HAL_DAC_Init(&hadac_dev);
    if (status == HAL_OK)
    {
        (void)HAL_DAC_ResetCmd(&hadac_dev, 1U);
        delay_ms(20U);
    }

    return status;
}

/**
 * @brief  Configure the comparator of one DAC instance.
 * @param  hdac: DAC handle
 * @param  cmp_enable: DAC_CMP_ENABLE / DAC_CMP_DISABLE
 * @param  cmp_mode: DAC_CMP_MD_DACO / DAC_CMP_MD_CMP_P
 * @param  cmp_hys: DAC_CMP_HYS_xMV (0 to 7)
 * @retval HAL status of HAL_DAC_ConfigComparator()
 */
HAL_StatusTypeDef Dac_ConfigComparator(DAC_HandleTypeDef *hdac, uint32 cmp_enable,
                                       uint32 cmp_mode, uint32 cmp_hys)
{
    DAC_CMPConfTypeDef cmp_conf;

    HAL_DAC_CMPStructInit(&cmp_conf);
    cmp_conf.CMP_Enable     = cmp_enable;
    cmp_conf.CMP_Mode       = cmp_mode;
    cmp_conf.CMP_Hysteresis = cmp_hys;

    return HAL_DAC_ConfigComparator(hdac, &cmp_conf);
}

/* MSP callback bookkeeping -------------------------------------------------*/

uint32 Dac_MspInitCount    = 0U;   /*!< HAL_DAC_MspInit() call counter        */
uint32 Dac_MspDeInitCount  = 0U;   /*!< HAL_DAC_MspDeInit() call counter      */
uint32 Dac_MspStateAtInit  = 0xFFU;/*!< handle state observed in MspInit      */
uint32 Dac_MspLockAtInit   = 0xFFU;/*!< handle lock observed in MspInit       */
uint32 Dac_MspStateAtDeInit= 0xFFU;/*!< handle state observed in MspDeInit    */

/**
 * @brief  Initialize the low level hardware of the DAC (strong override of the
 *         weak callback of the driver).
 * @note   Records the call and the handle fields it observes, so that the
 *         cases can assert the MSP contract: the callback runs once per
 *         initialization, before the handle is locked (LOCK-06) and while the
 *         handle is still in the RESET state (MSP-04).
 * @param  hdac: DAC handle
 * @retval None
 */
void HAL_DAC_MspInit(DAC_HandleTypeDef *hdac)
{
    if (hdac == NULL_PTR)
    {
        return;
    }

    Dac_MspInitCount++;
    Dac_MspStateAtInit = (uint32)hdac->State;
    Dac_MspLockAtInit  = (uint32)hdac->Lock;

    Dac_PeriphClockEnable(hdac->Instance);
}

/**
 * @brief  De-initialize the low level hardware of the DAC (strong override of
 *         the weak callback of the driver).
 * @note   The callback runs after the handle has been unlocked (LOCK-06) and
 *         after the state has been set back to RESET.
 * @param  hdac: DAC handle
 * @retval None
 */
void HAL_DAC_MspDeInit(DAC_HandleTypeDef *hdac)
{
    if (hdac == NULL_PTR)
    {
        return;
    }

    Dac_MspDeInitCount++;
    Dac_MspStateAtDeInit = (uint32)hdac->State;

    if (hdac->Instance == DAC0)
    {
        __HAL_SMU_DAC0_FORCE_RESET();
        __HAL_SMU_DAC0_CLK_DISABLE();
    }
    else
    {
        __HAL_SMU_DAC1_FORCE_RESET();
        __HAL_SMU_DAC1_CLK_DISABLE();
    }
}
