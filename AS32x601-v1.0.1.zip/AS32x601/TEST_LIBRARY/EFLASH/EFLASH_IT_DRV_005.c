/**
 * @file    EFLASH_IT_DRV_005.c
 * @brief   HAL EFLASH integration test case 005 (full API self check).
 *
 * HAL library extension case (no reference standard-library counterpart).
 * Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_FLASH_StructInit() / Init() / DeInit() / MspInit() / MspDeInit()
 *   HAL_FLASH_Unlock() / Lock() / SetClockFrequency()
 *   HAL_FLASH_Program() / Read() / Erase() / EraseWriteProtection()
 *   HAL_FLASH_GetFlagStatus() / ClearFlagStatus() / ITConfig() / ClearITPendingBit()
 *   HAL_FLASH_GetError() / GetState()
 *   HAL_FLASH_Get/Set/ResetPFlashWriteProtection() and the D-Flash pair
 *   HAL_FLASH_GetECCErrorAddress() / ClearECCErrorAddress()
 *   HAL_FLASH_GetSECFlagStatus() / InputSECKEY()
 *   FLASH_HandleIsValid() / FLASH_CheckState() / FLASH_LockHandle() / FLASH_UnlockHandle()
 *
 * Test procedure:
 *   A. HAL_FLASH_StructInit() defaults and the exported version macros;
 *   B. initialization metadata: a wrong Size / Version / Reserved word and an
 *      out of range clock frequency are refused with HAL_FLASH_ERROR_PARAM and
 *      without any side effect (no MSP call, state still RESET);
 *   C. a successful initialization, the MSP contract (called once, before the
 *      lock, in the RESET state) and a repeated initialization;
 *   D. the state gate: every operation is refused on an uninitialized handle;
 *   E. the parameter matrix of Program / Read / Erase (alignment, zero length,
 *      null pointer, out of range address, invalid erase type) - a refused call
 *      must leave the handle READY;
 *   F. the D-Flash information region is not programmable;
 *   G. a programming request that crosses a 512 byte row boundary is split and
 *      stored correctly;
 *   H. the shared internal helpers and the write protection polarity;
 *   I. the exported macros agree with the functions;
 *   J. de-initialization (idempotent) and a re-initialization.
 *
 * Expected behaviour:
 *   every refusal returns the documented status and error code, the refused
 *   calls never reach the MSP callback nor change the state, the stored data is
 *   correct and "summary : failures = 0" is printed.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define -----------------------------------------------------------*/
#define TEST_BAUDRATE                  (115200U)      /*!< console baud rate   */
#define TEST_SECTOR                    (0x01100000U)  /*!< P-Flash test sector */
#define TEST_ROW                       (512U)         /*!< program row size    */
#define TEST_ROW_SPLIT_ADDR            (TEST_SECTOR + 0x00000808U)  /*!< 8 bytes into a row */
#define TEST_DFLASH_INFO               (0x02080000U)  /*!< not programmable    */
#define TEST_PATTERN_WORDS             (128U)         /*!< 512 bytes           */
#define TEST_ROUND_DELAY_MS            (2000U)        /*!< delay between runs  */

/* Private variables ---------------------------------------------------------*/
static volatile uint32 check_failures = 0U;   /*!< failed check counter        */
static HAL_SMU_HandleTypeDef hsmu_clk;        /*!< SMU handle (clock tree)     */
static HAL_FLASH_HandleTypeDef hflash_dev;    /*!< handle under test           */

/* MSP bookkeeping (written by the overrides at the end of this file) */
static uint32 msp_init_count   = 0U;          /*!< HAL_FLASH_MspInit() calls   */
static uint32 msp_deinit_count = 0U;          /*!< HAL_FLASH_MspDeInit() calls */
static uint32 msp_state_at_init = 0xFFFFFFFFU;/*!< state seen inside the MSP   */
static uint32 msp_lock_at_init  = 0xFFFFFFFFU;/*!< lock seen inside the MSP    */

static uint32 program_data[TEST_PATTERN_WORDS];
static uint32 read_data[TEST_PATTERN_WORDS];

/* Shared helpers of this suite (defined at the end of this file) */
void Check(const char *name, uint32 condition);
void Summary(void);
void SystemClock_Init(void);
void FillPattern(void);
uint32 BufferEquals(const uint32 *a, const uint32 *b, uint32 words);
uint32 BufferIsErased(const uint32 *buf, uint32 words);
HAL_StatusTypeDef Flash_InitHandle(HAL_FLASH_HandleTypeDef *h);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    FLASH_InitTypeDef      init;
    FLASH_EraseInitTypeDef erase;
    HAL_StatusTypeDef      status;
    uint32                 addr_error;
    uint32                 i;

    HAL_Init();
    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== EFLASH_IT_DRV_005 : full API self check ===\r\n");

    /* ---- A. structure defaults and version macros ------------------------- */
    __HAL_CLEAR_STRUCT(&init);
    HAL_FLASH_StructInit(&init);
    Check("StructInit fills Size with sizeof(FLASH_InitTypeDef)",
          (init.Size == (uint32)sizeof(FLASH_InitTypeDef)) ? 1U : 0U);
    Check("StructInit fills Version with FLASH_INIT_VERSION",
          (init.Version == FLASH_INIT_VERSION) ? 1U : 0U);
    Check("StructInit clears the clock frequency request",
          (init.ClockFreq == 0U) ? 1U : 0U);
    Check("StructInit clears both reserved words",
          ((init.Reserved[0] == 0U) && (init.Reserved[1] == 0U)) ? 1U : 0U);
    Check("FLASH_INIT_VERSION equals FLASH_INIT_V1", (FLASH_INIT_VERSION == FLASH_INIT_V1) ? 1U : 0U);
    Check("__HAL_FLASH_MODULE_VERSION is the 1.0 module version",
          (__HAL_FLASH_MODULE_VERSION == 0x0100U) ? 1U : 0U);
    Check("the command budget is finite", (HAL_FLASH_TIMEOUT_DEFAULT > 0U) &&
          (HAL_FLASH_TIMEOUT_DEFAULT < 0xFFFFFFFFU) ? 1U : 0U);

    /* HAL_FLASH_StructInit() must tolerate a null pointer */
    HAL_FLASH_StructInit(NULL_PTR);
    Check("StructInit(NULL) is a safe no-op", 1U);

    /* ---- B. metadata and clock validation (no side effect) ---------------- */
    __HAL_CLEAR_STRUCT(&hflash_dev);
    hflash_dev.Instance = EFLASH;
    HAL_FLASH_StructInit(&hflash_dev.Init);
    hflash_dev.Init.Size = 0U;
    status = HAL_FLASH_Init(&hflash_dev);
    Check("a wrong structure Size is refused", (status == HAL_ERROR) ? 1U : 0U);
    Check("the wrong Size records HAL_FLASH_ERROR_PARAM",
          ((HAL_FLASH_GetError(&hflash_dev) & HAL_FLASH_ERROR_PARAM) != 0U) ? 1U : 0U);
    Check("a refused initialization leaves the state RESET",
          (HAL_FLASH_GetState(&hflash_dev) == HAL_FLASH_STATE_RESET) ? 1U : 0U);
    Check("a refused initialization does not run the MSP callback",
          (msp_init_count == 0U) ? 1U : 0U);

    __HAL_CLEAR_STRUCT(&hflash_dev);
    hflash_dev.Instance = EFLASH;
    HAL_FLASH_StructInit(&hflash_dev.Init);
    hflash_dev.Init.Version = 0x0000U;
    status = HAL_FLASH_Init(&hflash_dev);
    Check("a wrong structure Version is refused", (status == HAL_ERROR) ? 1U : 0U);

    __HAL_CLEAR_STRUCT(&hflash_dev);
    hflash_dev.Instance = EFLASH;
    HAL_FLASH_StructInit(&hflash_dev.Init);
    hflash_dev.Init.Reserved[0] = 1U;
    status = HAL_FLASH_Init(&hflash_dev);
    Check("a non zero reserved word is refused", (status == HAL_ERROR) ? 1U : 0U);

    __HAL_CLEAR_STRUCT(&hflash_dev);
    hflash_dev.Instance = EFLASH;
    HAL_FLASH_StructInit(&hflash_dev.Init);
    hflash_dev.Init.ClockFreq = 0x10000U;
    status = HAL_FLASH_Init(&hflash_dev);
    Check("a clock frequency beyond the 16 bit field is refused",
          (status == HAL_ERROR) ? 1U : 0U);
    Check("still no MSP callback after the refused configurations",
          (msp_init_count == 0U) ? 1U : 0U);

    /* A wrong instance is refused as well */
    __HAL_CLEAR_STRUCT(&hflash_dev);
    hflash_dev.Instance = (FLASH_TypeDef *)0x40000000U;
    HAL_FLASH_StructInit(&hflash_dev.Init);
    status = HAL_FLASH_Init(&hflash_dev);
    Check("an instance that is not the EFLASH controller is refused",
          (status == HAL_ERROR) ? 1U : 0U);

    /* ---- C. successful initialization and the MSP contract ---------------- */
    __HAL_CLEAR_STRUCT(&hflash_dev);
    status = Flash_InitHandle(&hflash_dev);
    Check("a complete structure initializes the driver", (status == HAL_OK) ? 1U : 0U);
    Check("the initialization publishes the READY state",
          (HAL_FLASH_GetState(&hflash_dev) == HAL_FLASH_STATE_READY) ? 1U : 0U);
    Check("the MSP callback ran exactly once", (msp_init_count == 1U) ? 1U : 0U);
    Check("the MSP callback ran before the handle was locked",
          (msp_lock_at_init != (uint32)HAL_LOCKED) ? 1U : 0U);
    Check("the MSP callback ran in the RESET state",
          (msp_state_at_init == (uint32)HAL_FLASH_STATE_RESET) ? 1U : 0U);

    status = HAL_FLASH_Init(&hflash_dev);
    Check("a repeated initialization is accepted", (status == HAL_OK) ? 1U : 0U);
    Check("a repeated initialization does not run the MSP callback again",
          (msp_init_count == 1U) ? 1U : 0U);

    Check("FLASH_HandleIsValid accepts the bound handle",
          (FLASH_HandleIsValid(&hflash_dev) != 0U) ? 1U : 0U);
    Check("FLASH_HandleIsValid refuses a null handle",
          (FLASH_HandleIsValid(NULL_PTR) == 0U) ? 1U : 0U);
    Check("FLASH_CheckState accepts the READY handle",
          (FLASH_CheckState(&hflash_dev) == HAL_OK) ? 1U : 0U);

    /* ---- D. the state gate on an uninitialized handle --------------------- */
    status = HAL_FLASH_DeInit(&hflash_dev);
    Check("HAL_FLASH_DeInit returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("the de-initialization ran the MSP de-initialization once",
          (msp_deinit_count == 1U) ? 1U : 0U);
    Check("FLASH_CheckState refuses the de-initialized handle",
          (FLASH_CheckState(&hflash_dev) == HAL_ERROR) ? 1U : 0U);

    status = HAL_FLASH_Program(&hflash_dev, TEST_SECTOR, 512U, program_data);
    Check("Program is refused before initialization", (status == HAL_ERROR) ? 1U : 0U);
    status = HAL_FLASH_Read(&hflash_dev, TEST_SECTOR, 32U, read_data);
    Check("Read is refused before initialization", (status == HAL_ERROR) ? 1U : 0U);
    erase.TypeErase = FLASH_TYPEERASE_SECTORS;
    erase.Address   = TEST_SECTOR;
    erase.Length    = PFLASH_SECTOR_SIZE;
    status = HAL_FLASH_Erase(&hflash_dev, &erase, NULL_PTR);
    Check("Erase is refused before initialization", (status == HAL_ERROR) ? 1U : 0U);

    status = HAL_FLASH_DeInit(&hflash_dev);
    Check("a repeated DeInit is accepted (idempotent)", (status == HAL_OK) ? 1U : 0U);
    Check("the repeated DeInit does not run the MSP callback again",
          (msp_deinit_count == 1U) ? 1U : 0U);

    __HAL_CLEAR_STRUCT(&hflash_dev);
    status = Flash_InitHandle(&hflash_dev);
    Check("the handle can be initialized again after DeInit", (status == HAL_OK) ? 1U : 0U);
    Check("the second initialization ran the MSP callback again",
          (msp_init_count == 2U) ? 1U : 0U);

    /* ---- E. parameter matrix (a refused call keeps the handle READY) ------ */
    FillPattern();
    status = HAL_FLASH_Unlock(&hflash_dev);
    Check("HAL_FLASH_Unlock returns HAL_OK", (status == HAL_OK) ? 1U : 0U);

    status = HAL_FLASH_Program(&hflash_dev, TEST_SECTOR + 4U, 512U, program_data);
    Check("Program refuses an address that is not 8 byte aligned",
          (status == HAL_ERROR) ? 1U : 0U);
    status = HAL_FLASH_Program(&hflash_dev, TEST_SECTOR, 0U, program_data);
    Check("Program refuses a zero length", (status == HAL_ERROR) ? 1U : 0U);
    status = HAL_FLASH_Program(&hflash_dev, TEST_SECTOR, 12U, program_data);
    Check("Program refuses a length that is not a multiple of 8",
          (status == HAL_ERROR) ? 1U : 0U);
    status = HAL_FLASH_Program(&hflash_dev, TEST_SECTOR, 512U, NULL_PTR);
    Check("Program refuses a null buffer", (status == HAL_ERROR) ? 1U : 0U);
    Check("the refused Program calls keep the handle READY",
          (HAL_FLASH_GetState(&hflash_dev) == HAL_FLASH_STATE_READY) ? 1U : 0U);

    status = HAL_FLASH_Read(&hflash_dev, TEST_SECTOR + 2U, 32U, read_data);
    Check("Read refuses an address that is not 4 byte aligned",
          (status == HAL_ERROR) ? 1U : 0U);
    status = HAL_FLASH_Read(&hflash_dev, TEST_SECTOR, 0U, read_data);
    Check("Read refuses a zero length", (status == HAL_ERROR) ? 1U : 0U);
    status = HAL_FLASH_Read(&hflash_dev, TEST_SECTOR, 6U, read_data);
    Check("Read refuses a length that is not a multiple of 4",
          (status == HAL_ERROR) ? 1U : 0U);
    status = HAL_FLASH_Read(&hflash_dev, TEST_SECTOR, 32U, NULL_PTR);
    Check("Read refuses a null buffer", (status == HAL_ERROR) ? 1U : 0U);

    erase.TypeErase = 0x7FU;
    erase.Address   = TEST_SECTOR;
    erase.Length    = PFLASH_SECTOR_SIZE;
    status = HAL_FLASH_Erase(&hflash_dev, &erase, NULL_PTR);
    Check("Erase refuses an invalid erase type", (status == HAL_ERROR) ? 1U : 0U);

    erase.TypeErase = FLASH_TYPEERASE_SECTORS;
    erase.Address   = TEST_SECTOR;
    erase.Length    = 0U;
    status = HAL_FLASH_Erase(&hflash_dev, &erase, NULL_PTR);
    Check("Erase refuses a zero length", (status == HAL_ERROR) ? 1U : 0U);

    erase.TypeErase = FLASH_TYPEERASE_SECTORS;
    erase.Address   = 0x08000000U;
    erase.Length    = PFLASH_SECTOR_SIZE;
    status = HAL_FLASH_Erase(&hflash_dev, &erase, NULL_PTR);
    Check("Erase refuses an address outside the flash",
          (status == HAL_ERROR) ? 1U : 0U);
    Check("the out of range erase records the address error",
          ((HAL_FLASH_GetError(&hflash_dev) & HAL_FLASH_ERROR_ADDRESS) != 0U) ? 1U : 0U);

    erase.TypeErase = FLASH_TYPEERASE_SECTORS;
    erase.Address   = TEST_SECTOR + 0x100U;
    erase.Length    = PFLASH_SECTOR_SIZE;
    status = HAL_FLASH_Erase(&hflash_dev, &erase, NULL_PTR);
    Check("Erase refuses an address that is not sector aligned",
          (status == HAL_ERROR) ? 1U : 0U);

    status = HAL_FLASH_Erase(&hflash_dev, NULL_PTR, NULL_PTR);
    Check("Erase refuses a null request", (status == HAL_ERROR) ? 1U : 0U);
    Check("the refused Erase calls keep the handle READY",
          (HAL_FLASH_GetState(&hflash_dev) == HAL_FLASH_STATE_READY) ? 1U : 0U);

    /* ---- F. the D-Flash information region is not programmable ------------ */
    status = HAL_FLASH_Program(&hflash_dev, TEST_DFLASH_INFO, 512U, program_data);
    Check("programming the D-Flash information region is refused",
          (status == HAL_ERROR) ? 1U : 0U);
    Check("the refused request records the address error",
          ((HAL_FLASH_GetError(&hflash_dev) & HAL_FLASH_ERROR_ADDRESS) != 0U) ? 1U : 0U);

    /* ---- G. a request that crosses a 512 byte row boundary ---------------- */
    erase.TypeErase = FLASH_TYPEERASE_SECTORS;
    erase.Address   = TEST_SECTOR;
    erase.Length    = PFLASH_SECTOR_SIZE;
    addr_error      = 0xFFFFFFFFU;
    status = HAL_FLASH_Erase(&hflash_dev, &erase, &addr_error);
    Check("the test sector is erased before the row split", (status == HAL_OK) ? 1U : 0U);

    status = HAL_FLASH_Program(&hflash_dev, TEST_ROW_SPLIT_ADDR, 512U, program_data);
    Check("a request that crosses a row boundary returns HAL_OK",
          (status == HAL_OK) ? 1U : 0U);

    for (i = 0U; i < TEST_PATTERN_WORDS; i++)
    {
        read_data[i] = 0U;
    }
    status = HAL_FLASH_Read(&hflash_dev, TEST_ROW_SPLIT_ADDR, 512U, read_data);
    Check("the split request is read back unchanged", (status == HAL_OK) ? 1U : 0U);
    Check("the split content matches the source pattern",
          BufferEquals(read_data, program_data, TEST_PATTERN_WORDS));

    status = HAL_FLASH_Read(&hflash_dev, TEST_SECTOR, 8U, read_data);
    Check("the 8 bytes before the start address are untouched",
          BufferIsErased(read_data, 2U));

    /* ---- H. shared helpers and write protection polarity ------------------ */
    Check("FLASH_LockHandle acquires the bare metal lock",
          (FLASH_LockHandle(&hflash_dev, HAL_MAX_DELAY) == HAL_OK) ? 1U : 0U);
    Check("a second acquisition reports HAL_BUSY",
          (FLASH_LockHandle(&hflash_dev, HAL_MAX_DELAY) == HAL_BUSY) ? 1U : 0U);
    FLASH_UnlockHandle(&hflash_dev);
    Check("FLASH_UnlockHandle releases the lock",
          (FLASH_LockHandle(&hflash_dev, HAL_MAX_DELAY) == HAL_OK) ? 1U : 0U);
    FLASH_UnlockHandle(&hflash_dev);

    status = HAL_FLASH_SetPFlashWriteProtection(&hflash_dev, FLASH_WP_AREA1);
    Check("setting a P-Flash area protection returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("the protected area reads back as protected (bit = 0)",
          (HAL_FLASH_GetPFlashWriteProtStatus(&hflash_dev, FLASH_WP_AREA1) ==
           FLASH_FLAG_RESET) ? 1U : 0U);
    status = HAL_FLASH_ResetPFlashWriteProtection(&hflash_dev, FLASH_WP_AREA1);
    Check("removing the P-Flash protection returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("the unprotected area reads back as unprotected (bit = 1)",
          (HAL_FLASH_GetPFlashWriteProtStatus(&hflash_dev, FLASH_WP_AREA1) ==
           FLASH_FLAG_SET) ? 1U : 0U);

    status = HAL_FLASH_SetDFlashWriteProtection(&hflash_dev, FLASH_WP_AREA1);
    Check("setting a D-Flash area protection returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("the protected D-Flash area reads back as protected",
          (HAL_FLASH_GetDFlashWriteProtStatus(&hflash_dev, FLASH_WP_AREA1) ==
           FLASH_FLAG_RESET) ? 1U : 0U);
    status = HAL_FLASH_ResetDFlashWriteProtection(&hflash_dev, FLASH_WP_AREA1);
    Check("removing the D-Flash protection returns HAL_OK", (status == HAL_OK) ? 1U : 0U);

    /* ---- I. exported macros agree with the functions ---------------------- */
    Check("__HAL_FLASH_GET_FLAG agrees with HAL_FLASH_GetFlagStatus",
          (((__HAL_FLASH_GET_FLAG(&hflash_dev, FLASH_FLAG_LOCK) != 0U) ? 1U : 0U) ==
           ((HAL_FLASH_GetFlagStatus(&hflash_dev, FLASH_FLAG_LOCK) == FLASH_FLAG_SET) ? 1U : 0U))
          ? 1U : 0U);

    __HAL_FLASH_ENABLE_IT(&hflash_dev, FLASH_IT_OPEIE);
    Check("__HAL_FLASH_ENABLE_IT sets the interrupt enable bit",
          ((EFLASH->CR & FLASH_IT_OPEIE) != 0U) ? 1U : 0U);
    __HAL_FLASH_DISABLE_IT(&hflash_dev, FLASH_IT_OPEIE);
    Check("__HAL_FLASH_DISABLE_IT clears the interrupt enable bit",
          ((EFLASH->CR & FLASH_IT_OPEIE) == 0U) ? 1U : 0U);

    __HAL_FLASH_CLEAR_FLAG(&hflash_dev, FLASH_CLEAR_FINISH);
    Check("__HAL_FLASH_CLEAR_FLAG clears the completion flag",
          ((EFLASH->SR & FLASH_FLAG_FINISH) == 0U) ? 1U : 0U);

    Check("IS_FLASH_TYPEERASE accepts the three erase types",
          (IS_FLASH_TYPEERASE(FLASH_TYPEERASE_SECTORS) != 0U) &&
          (IS_FLASH_TYPEERASE(FLASH_TYPEERASE_BLOCKS) != 0U) &&
          (IS_FLASH_TYPEERASE(FLASH_TYPEERASE_MASSERASE) != 0U) ? 1U : 0U);
    Check("IS_FLASH_TYPEERASE refuses an unknown value",
          (IS_FLASH_TYPEERASE(0x7FU) == 0U) ? 1U : 0U);
    Check("IS_FLASH_FLAG accepts a documented flag",
          (IS_FLASH_FLAG(FLASH_FLAG_WPERR) != 0U) ? 1U : 0U);
    Check("IS_FLASH_CLEAR accepts a documented clear value",
          (IS_FLASH_CLEAR(FLASH_CLEAR_WPERR) != 0U) ? 1U : 0U);
    Check("IS_FLASH_IT accepts a documented source",
          (IS_FLASH_IT(FLASH_IT_FINIE) != 0U) ? 1U : 0U);
    Check("IS_FLASH_SECFLAG accepts both security flags",
          (IS_FLASH_SECFLAG(FLASH_SECFLAG_KEY) != 0U) &&
          (IS_FLASH_SECFLAG(FLASH_SECFLAG_RP) != 0U) ? 1U : 0U);
    Check("IS_PFLASH_WP_AREAx accepts area 32",
          (IS_PFLASH_WP_AREAx(FLASH_WP_AREA32) != 0U) ? 1U : 0U);
    Check("IS_DFLASH_WP_AREAx accepts area 8",
          (IS_DFLASH_WP_AREAx(FLASH_WP_AREA8) != 0U) ? 1U : 0U);
    Check("IS_FLASH_CLEAR_IT accepts a documented pending value",
          (IS_FLASH_CLEAR_IT(FLASH_CLEAR_IT_ECC2ERR) != 0U) ? 1U : 0U);
    Check("IS_FLASH_CLEAR_IT refuses an unknown value",
          (IS_FLASH_CLEAR_IT(0x7FU) == 0U) ? 1U : 0U);
    Check("IS_FLASH_CMD accepts a documented command",
          (IS_FLASH_CMD(FLASH_Cmd_Program) != 0U) ? 1U : 0U);
    Check("IS_FLASH_CMD refuses an unknown command",
          (IS_FLASH_CMD(0x7FU) == 0U) ? 1U : 0U);
    Check("IS_FLASH_INSTANCE accepts the EFLASH controller",
          (IS_FLASH_INSTANCE(EFLASH) != 0U) ? 1U : 0U);
    Check("IS_FLASH_MEMORY accepts both memory identifiers",
          ((IS_FLASH_MEMORY(FLASH_MEMORY_PFLASH) != 0U) &&
           (IS_FLASH_MEMORY(FLASH_MEMORY_DFLASH) != 0U)) ? 1U : 0U);

    /* The error codes are independent single bits, so they can be combined
     * with a bitwise or without a value being mistaken for another one. */
    Check("the error codes are non overlapping single bits",
          (((HAL_FLASH_ERROR_OPERATION & HAL_FLASH_ERROR_ECC1) == 0U) &&
           ((HAL_FLASH_ERROR_ECC1 & HAL_FLASH_ERROR_ECC2) == 0U) &&
           ((HAL_FLASH_ERROR_ECC2 & HAL_FLASH_ERROR_WRP) == 0U) &&
           ((HAL_FLASH_ERROR_WRP & HAL_FLASH_ERROR_SECKEY) == 0U) &&
           ((HAL_FLASH_ERROR_SECKEY & HAL_FLASH_ERROR_ADDRESS) == 0U) &&
           ((HAL_FLASH_ERROR_ADDRESS & HAL_FLASH_ERROR_PARAM) == 0U) &&
           ((HAL_FLASH_ERROR_PARAM & HAL_FLASH_ERROR_LOCK) == 0U) &&
           (HAL_FLASH_ERROR_LOCK == 0x80U) &&
           (HAL_FLASH_ERROR_NONE == 0U)) ? 1U : 0U);
    Check("the state enumeration keeps the documented values",
          (((uint32)HAL_FLASH_STATE_RESET == 0U) && ((uint32)HAL_FLASH_STATE_READY == 1U) &&
           ((uint32)HAL_FLASH_STATE_BUSY == 2U) && ((uint32)HAL_FLASH_STATE_ERROR == 3U)) ? 1U : 0U);

    status = HAL_FLASH_Lock(&hflash_dev);
    Check("HAL_FLASH_Lock returns HAL_OK", (status == HAL_OK) ? 1U : 0U);

    /* ---- J. null handle protection of every public entry ------------------ */
    Check("Program(NULL) is refused", (HAL_FLASH_Program(NULL_PTR, TEST_SECTOR, 512U, program_data) == HAL_ERROR) ? 1U : 0U);
    Check("Read(NULL) is refused", (HAL_FLASH_Read(NULL_PTR, TEST_SECTOR, 32U, read_data) == HAL_ERROR) ? 1U : 0U);
    Check("Erase(NULL) is refused", (HAL_FLASH_Erase(NULL_PTR, &erase, NULL_PTR) == HAL_ERROR) ? 1U : 0U);
    Check("Unlock(NULL) is refused", (HAL_FLASH_Unlock(NULL_PTR) == HAL_ERROR) ? 1U : 0U);
    Check("Lock(NULL) is refused", (HAL_FLASH_Lock(NULL_PTR) == HAL_ERROR) ? 1U : 0U);
    Check("Init(NULL) is refused", (HAL_FLASH_Init(NULL_PTR) == HAL_ERROR) ? 1U : 0U);
    Check("DeInit(NULL) is refused", (HAL_FLASH_DeInit(NULL_PTR) == HAL_ERROR) ? 1U : 0U);
    Check("SetClockFrequency(NULL) is refused",
          (HAL_FLASH_SetClockFrequency(NULL_PTR, 180U) == HAL_ERROR) ? 1U : 0U);
    Check("EraseWriteProtection(NULL) is refused",
          (HAL_FLASH_EraseWriteProtection(NULL_PTR) == HAL_ERROR) ? 1U : 0U);
    Check("InputSECKEY(NULL) is refused",
          (HAL_FLASH_InputSECKEY(NULL_PTR, 1U, 2U) == HAL_ERROR) ? 1U : 0U);
    Check("SetPFlashWriteProtection(NULL) is refused",
          (HAL_FLASH_SetPFlashWriteProtection(NULL_PTR, FLASH_WP_AREA1) == HAL_ERROR) ? 1U : 0U);
    Check("ResetPFlashWriteProtection(NULL) is refused",
          (HAL_FLASH_ResetPFlashWriteProtection(NULL_PTR, FLASH_WP_AREA1) == HAL_ERROR) ? 1U : 0U);
    Check("SetDFlashWriteProtection(NULL) is refused",
          (HAL_FLASH_SetDFlashWriteProtection(NULL_PTR, FLASH_WP_AREA1) == HAL_ERROR) ? 1U : 0U);
    Check("ResetDFlashWriteProtection(NULL) is refused",
          (HAL_FLASH_ResetDFlashWriteProtection(NULL_PTR, FLASH_WP_AREA1) == HAL_ERROR) ? 1U : 0U);

    Check("GetFlagStatus(NULL) reports RESET",
          (HAL_FLASH_GetFlagStatus(NULL_PTR, FLASH_FLAG_LOCK) == FLASH_FLAG_RESET) ? 1U : 0U);
    Check("GetPFlashWriteProtStatus(NULL) reports RESET",
          (HAL_FLASH_GetPFlashWriteProtStatus(NULL_PTR, FLASH_WP_AREA1) == FLASH_FLAG_RESET) ? 1U : 0U);
    Check("GetDFlashWriteProtStatus(NULL) reports RESET",
          (HAL_FLASH_GetDFlashWriteProtStatus(NULL_PTR, FLASH_WP_AREA1) == FLASH_FLAG_RESET) ? 1U : 0U);
    Check("GetSECFlagStatus(NULL) reports RESET",
          (HAL_FLASH_GetSECFlagStatus(NULL_PTR, FLASH_SECFLAG_RP) == FLASH_FLAG_RESET) ? 1U : 0U);
    Check("GetECCErrorAddress(NULL) reports 0",
          (HAL_FLASH_GetECCErrorAddress(NULL_PTR) == 0U) ? 1U : 0U);
    Check("GetError(NULL) reports no error",
          (HAL_FLASH_GetError(NULL_PTR) == HAL_FLASH_ERROR_NONE) ? 1U : 0U);
    Check("GetState(NULL) reports RESET",
          (HAL_FLASH_GetState(NULL_PTR) == HAL_FLASH_STATE_RESET) ? 1U : 0U);
    HAL_FLASH_ClearFlagStatus(NULL_PTR, FLASH_CLEAR_FINISH);
    HAL_FLASH_ClearITPendingBit(NULL_PTR, FLASH_CLEAR_IT_FINISH);
    HAL_FLASH_ClearECCErrorAddress(NULL_PTR);
    HAL_FLASH_ITConfig(NULL_PTR, FLASH_IT_FINIE, FLASH_IT_DISABLE);
    HAL_FLASH_MspInit(NULL_PTR);
    HAL_FLASH_MspDeInit(NULL_PTR);
    Check("the void entries with a null handle are safe no-ops", 1U);

    Summary();

    for (;;)
    {
        delay_ms(TEST_ROUND_DELAY_MS);
    }
}

/* Private functions -------------------------------------------------------*/

void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

void FillPattern(void)
{
    uint32 i;

    for (i = 0U; i < TEST_PATTERN_WORDS; i++)
    {
        program_data[i] = (0x01020304U + (i * 0x01010101U)) ^ (i << 24);
    }
}

uint32 BufferEquals(const uint32 *a, const uint32 *b, uint32 words)
{
    uint32 i;

    for (i = 0U; i < words; i++)
    {
        if (a[i] != b[i])
        {
            printf("  mismatch at word %u : 0x%08X / 0x%08X\r\n",
               (unsigned)i, (unsigned)a[i], (unsigned)b[i]);
            return 0U;
        }
    }

    return 1U;
}

uint32 BufferIsErased(const uint32 *buf, uint32 words)
{
    uint32 i;

    for (i = 0U; i < words; i++)
    {
        if (buf[i] != 0xFFFFFFFFU)
        {
            printf("  word %u is 0x%08X instead of 0xFFFFFFFF\r\n",
               (unsigned)i, (unsigned)buf[i]);
            return 0U;
        }
    }

    return 1U;
}

/**
 * @brief  Initialize a handle with a complete configuration structure.
 * @param  h: handle to initialize
 * @retval HAL_StatusTypeDef: status of HAL_FLASH_Init()
 */
HAL_StatusTypeDef Flash_InitHandle(HAL_FLASH_HandleTypeDef *h)
{
    h->Instance = EFLASH;
    HAL_FLASH_StructInit(&h->Init);
    h->Init.ClockFreq = (uint32)(SystemCoreClock / 1000000U);

    return HAL_FLASH_Init(h);
}

/**
 * @brief  Configure the system clock tree (PLL 180 MHz, APB 22.5 MHz).
 * @param  None
 * @retval None
 */
void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/* MSP callbacks ------------------------------------------------------------*/

/**
 * @brief  FLASH MSP initialization (overrides the weak default).
 * @note   The override records the call so that the case can prove the
 *         LOCK-06 / MSP-04 contract: the callback runs outside the handle lock
 *         and only on the first initialization. Since the default body is
 *         replaced here, the clock gate and the reset release are applied
 *         explicitly.
 * @param  hflash: FLASH handle (may be null, the call is then a no-op)
 * @retval None
 */
void HAL_FLASH_MspInit(HAL_FLASH_HandleTypeDef *hflash)
{
    if (hflash == NULL_PTR)
    {
        return;
    }

    msp_init_count++;
    msp_state_at_init = (uint32)hflash->State;
    msp_lock_at_init  = (uint32)hflash->Lock;

    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_EFLASH_FORCE_RESET();
    __HAL_SMU_EFLASH_RELEASE_RESET();
}

/**
 * @brief  FLASH MSP de-initialization (overrides the weak default).
 * @note   The clock gate is left open on purpose: the controller must stay
 *         reachable for the read back checks that follow a de-initialization.
 * @param  hflash: FLASH handle (may be null)
 * @retval None
 */
void HAL_FLASH_MspDeInit(HAL_FLASH_HandleTypeDef *hflash)
{
    if (hflash == NULL_PTR)
    {
        return;
    }

    msp_deinit_count++;
}

/*****END OF FILE*****/
