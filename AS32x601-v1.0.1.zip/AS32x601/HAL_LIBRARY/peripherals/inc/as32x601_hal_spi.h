/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_spi.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.6
 * Date:   2026/10/26
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.1     move SPI_ENABLE/DISABLE,
 *                                                       SPI_RESETFIFO_* and
 *                                                       SPI_ITRaw_* to the
 *                                                       exported constants
 *                                                       (public API parameters);
 *                                                       add IS_SPI_GETRAW_IT
 *                                                       validation macro
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.2     align with the source
 *                                                       file V1.2: every public
 *                                                       function guards the
 *                                                       handle against NULL
 *                                                       before any register
 *                                                       access or lock operation
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.3     add the interrupt (_IT)
 *                                                       and DMA (_DMA) transfer
 *                                                       modes, the interrupt
 *                                                       handler and the user
 *                                                       callbacks; add the
 *                                                       hdmatx / hdmarx DMA
 *                                                       handle fields and the
 *                                                       HAL_SPI_ERROR_DMA error
 *                                                       code
 *     ANSILIC APPLICATION GROUP  2026/09/18     1.4     align with the source file V1.4: apply the
 *                                                       resource lock and RTOS
 *                                                       rules - export the
 *                                                       SPI_LockHandle() /
 *                                                       SPI_UnlockHandle() pair
 *                                                       (Timeout parameter and
 *                                                       uncreated-mutex guard,
 *                                                       RTOS-11), lock Init /
 *                                                       DeInit (LOCK-01), call
 *                                                       MspInit on the first
 *                                                       initialization only
 *                                                       (MSP-04), call MspDeInit
 *                                                       after the unlock
 *                                                       (LOCK-06), add the
 *                                                       private
 *                                                       SPI_ITConfigInternal()
 *                                                       and
 *                                                       SPI_GetFlagStatusInternal()
 *                                                       helpers so that the
 *                                                       transfer API and the
 *                                                       interrupt paths no
 *                                                       longer call the public
 *                                                       HAL_SPI_ITConfig() /
 *                                                       HAL_SPI_GetFlagStatus()
 *                                                       (LOCK-04 / LOCK-05), add the
 *                                                       SPI_CheckState() state
 *                                                       gate with the
 *                                                       recoverable ERROR /
 *                                                       TIMEOUT states and the
 *                                                       HAL_SPI_STATE_TIMEOUT
 *                                                       state (ARCH-CONST-09,
 *                                                       STATE-04 / STATE-06),
 *                                                       validate the transfer
 *                                                       parameters before the
 *                                                       lock is taken and report
 *                                                       HAL_SPI_ERROR_INVALID_PARAM,
 *                                                       yield from the blocking
 *                                                       polling loop (RTOS-04 /
 *                                                       RTOS-05), document the
 *                                                       blocking behaviour of
 *                                                       every API (POLL-04),
 *                                                       and drop the unused
 *                                                       HAL_SPI_ERROR_TXE /
 *                                                       HAL_SPI_ERROR_UNKNOWN
 *                                                       codes
 *     ANSILIC APPLICATION GROUP  2026/10/26     1.5     document the single
 *                                                       time budget of a
 *                                                       transfer (lock wait,
 *                                                       every flag wait and the
 *                                                       cleanup of a failed
 *                                                       attempt share the
 *                                                       Timeout of the API),
 *                                                       the frame width masking
 *                                                       of the received data
 *                                                       (including the buffer a
 *                                                       DMA channel filled and
 *                                                       the raw value returned
 *                                                       by HAL_SPI_ReceiveData),
 *                                                       the DMA channel
 *                                                       requirements validated
 *                                                       by the driver before a
 *                                                       DMA transfer starts,
 *                                                       and the cleanup
 *                                                       performed on a failed
 *                                                       transfer
 *     ANSILIC APPLICATION GROUP  2026/10/26     1.6     document that the frame
 *                                                       width is read from the
 *                                                       frame size field of the
 *                                                       SPI mode register (the
 *                                                       handle configuration is
 *                                                       the fallback), and that a
 *                                                       master receive in DMA
 *                                                       mode arms the virtual
 *                                                       transmit stream that
 *                                                       generates the receive
 *                                                       clock
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Serial Peripheral
 *                  Interface (SPI), as a HAL peripheral driver of this
 *                  library:
 *                  - Initialization and de-initialization: HAL_SPI_Init /
 *                    HAL_SPI_DeInit, configuration structure handling;
 *                  - Peripheral control: polling transmit / receive /
 *                    transmit-receive with timeout, state and error
 *                    reporting;
 *                  - Interrupt and DMA transfers: non-blocking transmit /
 *                    receive / transmit-receive (HAL_SPI_xxx_IT / _DMA)
 *                    with the HAL_SPI_IRQHandler() and the user callbacks;
 *                  - Low level register access: enable / disable, FIFO
 *                    reset, slave select, data send / receive, interrupt
 *                    configuration, flag / interrupt status query and
 *                    pending clear.
 *                  The interrupt service routines themselves are provided
 *                  by the user (strong definitions of the weak symbols
 *                  declared in as32x601_hal_plic.h); this module wires the
 *                  SPI interrupt sources to HAL_SPI_IRQHandler().
 *                  Concurrency follows the architecture resource lock rules
 *                  (section 13): every API that changes the handle state is
 *                  serialized through the SPI_LockHandle() /
 *                  SPI_UnlockHandle() pair (bare-metal lock flag, or an RTOS
 *                  mutex with a bounded wait), the SPI_CheckState() gate
 *                  rejects a new transfer while another one is in progress
 *                  and accepts the recoverable ERROR / TIMEOUT states so that
 *                  a failed transfer can be retried without a DeInit / Init
 *                  round trip (STATE-06), the transfer parameters are
 *                  validated before the lock is taken, and the register level
 *                  access helpers stay lock-free so that they remain usable
 *                  from an interrupt service routine (LOCK-04 / RTOS-12).
 * @complexity  Complex
 *              Blocking + IT + DMA modes, state machine, user callbacks.
 */
#ifndef __AS32X601_HAL_SPI_H
#define __AS32X601_HAL_SPI_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "as32x601.h"               /* SPI_TypeDef, SPI register bits         */
#include "as32x601_hal_def.h"       /* HAL_StatusTypeDef, HAL_LockTypeDef     */

/* Exported constants --------------------------------------------------------*/

/**
 * @brief SPI HAL driver module version.
 * @note  0x0100U = V1.0. Bumped only on breaking API changes (architecture
 *        spec COMPAT-13/14/15).
 */
#define __HAL_SPI_MODULE_VERSION  0x0100U

/* The DMA handle is forward declared here: the SPI DMA transfers are driven
 * through a user-provided DMA_HandleTypeDef (see as32x601_hal_dma.h). The
 * full DMA type is not required by this header, so only the forward
 * declaration is provided to avoid a dependency on the DMA module. The
 * struct tag is __DMA_HandleTypeDef to match the definition in
 * as32x601_hal_dma.h. */
typedef struct __DMA_HandleTypeDef DMA_HandleTypeDef;

/* Exported types ------------------------------------------------------------*/

/** @defgroup SPI_Exported_Types SPI Exported Types
  * @{
  */

/**
 * @brief SPI configuration structure definition.
 * @note  The field values directly map to the SPI control registers
 *        (CLKCR clock divider, CR0 mode bit, CFG frame size / Motorola
 *        mode / transmission mode).
 * @note  This structure follows the Version+Size compatibility mechanism
 *        (architecture spec section 22): the user must clear the structure
 *        (__HAL_CLEAR_STRUCT / memset), set the Size and Version metafields
 *        before filling the business fields (see HAL_SPI_StructInit()).
 */
typedef struct
{
    uint32 Size;                    /*!< sizeof(SPI_InitTypeDef), must be set by the user
                                         after clearing the structure           */
    uint32 Version;                 /*!< Structure semantic version: @ref SPI_INIT_VERSION
                                         (SPI_INIT_V1 = 0x0100U)                */
    uint32 SPI_CLKDiv;              /*!< Clock frequency divider: SPI_CLKDivx     */
    uint32 SPI_Mode;                /*!< Master or slave: SPI_Mode_Master/Slave   */
    uint32 SPI_FrameSize;           /*!< Data frame size: SPI_FrameSize_4b..32b.
                                          The transfer functions read the width
                                          back from the frame size field of the
                                          mode register, so a size programmed
                                          directly in the register is honoured */
    uint32 SPI_MotorolaMode;        /*!< Clock polarity/phase: SPI_Motorola_Mode0..3 */
    uint32 SPI_TransMode;           /*!< Transmission mode: SPI_TransNor/BToB     */
    uint32 Reserved[2];             /*!< Reserved for future extension (must be 0) */
} SPI_InitTypeDef;

/**
 * @brief SPI / init structure version macros.
 * @note  SPI_INIT_V1 is the current version. Future versions (e.g. V2 with
 *        new fields) must be appended after the existing fields without
 *        changing the layout (architecture spec section 22.5).
 */
#define SPI_INIT_V1  0x0100U   /*!< SPI Init structure version V1.0 */
#define SPI_INIT_VERSION  SPI_INIT_V1   /*!< Current SPI Init structure version */

/**
 * @brief HAL SPI state structures definition.
 */
typedef enum
{
    HAL_SPI_STATE_RESET      = 0x00U, /*!< Peripheral not initialized            */
    HAL_SPI_STATE_READY      = 0x01U, /*!< Peripheral initialized and ready      */
    HAL_SPI_STATE_BUSY       = 0x02U, /*!< An internal process is ongoing        */
    HAL_SPI_STATE_BUSY_TX    = 0x03U, /*!< Data transmission is ongoing          */
    HAL_SPI_STATE_BUSY_RX    = 0x04U, /*!< Data reception is ongoing             */
    HAL_SPI_STATE_BUSY_TX_RX = 0x05U, /*!< Transmission and reception ongoing    */
    HAL_SPI_STATE_ERROR      = 0x06U, /*!< SPI error state (recoverable)         */
    HAL_SPI_STATE_TIMEOUT    = 0x07U  /*!< A transfer timed out (recoverable)    */
} HAL_SPI_StateTypeDef;

/**
 * @brief SPI handle structure definition.
 * @note  Field order follows the architecture spec HANDLE-02:
 *        Instance -> Init -> Lock -> State -> ErrorCode -> module fields.
 *        The transfer counter fields modified by the ISR / DMA callbacks
 *        are declared as __IO (HANDLE-03).
 */
typedef struct __SPI_HandleTypeDef
{
    SPI_TypeDef               *Instance;      /*!< SPI registers base address      */
    SPI_InitTypeDef           Init;           /*!< SPI communication parameters    */
    HAL_LockTypeDef           Lock;           /*!< Locking object                   */
    __IO HAL_SPI_StateTypeDef State;          /*!< SPI communication state         */
    __IO uint32               ErrorCode;      /*!< SPI error code                   */
    uint8                     *pTxBuffPtr;    /*!< Pointer to SPI Tx buffer        */
    __IO uint32               TxXferSize;     /*!< SPI Tx transfer size (frames)    */
    __IO uint32               TxXferCount;    /*!< SPI Tx transfer counter         */
    uint8                     *pRxBuffPtr;    /*!< Pointer to SPI Rx buffer        */
    __IO uint32               RxXferSize;     /*!< SPI Rx transfer size (frames)    */
    __IO uint32               RxXferCount;    /*!< SPI Rx transfer counter         */
    DMA_HandleTypeDef         *hdmatx;        /*!< SPI Tx DMA handle (optional)      */
    DMA_HandleTypeDef         *hdmarx;        /*!< SPI Rx DMA handle (optional)      */
#if (USE_RTOS == 1)
    HAL_MutexTypeDef          LockMutex;      /*!< RTOS mutex handle (created by the
                                                   user porting layer, e.g. in
                                                   HAL_SPI_MspInit)               */
#endif /* USE_RTOS */
} SPI_HandleTypeDef;

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @defgroup SPI_Exported_Constants SPI Exported Constants
  * @{
  */

/** @defgroup SPI_Error_Code SPI Error Code
  * @{
  */
#define HAL_SPI_ERROR_NONE          ((uint32)0x00000000U)  /*!< No error                        */
#define HAL_SPI_ERROR_RXO           ((uint32)0x00000001U)  /*!< RX buffer overflow error        */
#define HAL_SPI_ERROR_FLAG          ((uint32)0x00000004U)  /*!< Flag wait timeout error         */
#define HAL_SPI_ERROR_DMA           ((uint32)0x00000010U)  /*!< DMA transfer error              */
#define HAL_SPI_ERROR_INVALID_PARAM ((uint32)0x00000020U)  /*!< Invalid parameter (the request
                                                                 was rejected before any register
                                                                 access and without changing the
                                                                 handle state)                     */
/**
  * @}
  */

/** @defgroup SPI_Mode SPI Mode
  * @{
  */
#define SPI_Mode_Slave    ((uint32)0x00000000U)  /*!< SPI slave mode                          */
#define SPI_Mode_Master   ((uint32)0x00000002U)  /*!< SPI master mode (CR0.MSTR bit)          */
/**
  * @}
  */

/** @defgroup SPI_Clock_Divider SPI Clock Divider
  * @{
  */
#define SPI_CLKDiv2       ((uint32)0x00000000U)  /*!< SPI clock frequency division 2          */
#define SPI_CLKDiv4       ((uint32)0x00000001U)  /*!< SPI clock frequency division 4          */
#define SPI_CLKDiv8       ((uint32)0x00000003U)  /*!< SPI clock frequency division 8          */
#define SPI_CLKDiv16      ((uint32)0x00000007U)  /*!< SPI clock frequency division 16         */
#define SPI_CLKDiv32      ((uint32)0x0000000FU)  /*!< SPI clock frequency division 32         */
#define SPI_CLKDiv64      ((uint32)0x0000001FU)  /*!< SPI clock frequency division 64         */
#define SPI_CLKDiv128     ((uint32)0x0000003FU)  /*!< SPI clock frequency division 128        */
#define SPI_CLKDiv256     ((uint32)0x0000007FU)  /*!< SPI clock frequency division 256        */
#define SPI_CLKDiv512     ((uint32)0x000000FFU)  /*!< SPI clock frequency division 512        */
/**
  * @}
  */

/** @defgroup SPI_Frame_Size SPI Frame Size
  * @{
  */
#define SPI_FrameSize_4b  ((uint32)0x00001000U)  /*!< Frame size 4 bit                        */
#define SPI_FrameSize_5b  ((uint32)0x00001400U)  /*!< Frame size 5 bit                        */
#define SPI_FrameSize_6b  ((uint32)0x00001800U)  /*!< Frame size 6 bit                        */
#define SPI_FrameSize_7b  ((uint32)0x00001C00U)  /*!< Frame size 7 bit                        */
#define SPI_FrameSize_8b  ((uint32)0x00002000U)  /*!< Frame size 8 bit                        */
#define SPI_FrameSize_9b  ((uint32)0x00002400U)  /*!< Frame size 9 bit                        */
#define SPI_FrameSize_10b ((uint32)0x00002800U)  /*!< Frame size 10 bit                       */
#define SPI_FrameSize_11b ((uint32)0x00002C00U)  /*!< Frame size 11 bit                       */
#define SPI_FrameSize_12b ((uint32)0x00003000U)  /*!< Frame size 12 bit                       */
#define SPI_FrameSize_13b ((uint32)0x00003400U)  /*!< Frame size 13 bit                       */
#define SPI_FrameSize_14b ((uint32)0x00003800U)  /*!< Frame size 14 bit                       */
#define SPI_FrameSize_15b ((uint32)0x00003C00U)  /*!< Frame size 15 bit                       */
#define SPI_FrameSize_16b ((uint32)0x00004000U)  /*!< Frame size 16 bit                       */
#define SPI_FrameSize_17b ((uint32)0x00004400U)  /*!< Frame size 17 bit                       */
#define SPI_FrameSize_18b ((uint32)0x00004800U)  /*!< Frame size 18 bit                       */
#define SPI_FrameSize_19b ((uint32)0x00004C00U)  /*!< Frame size 19 bit                       */
#define SPI_FrameSize_20b ((uint32)0x00005000U)  /*!< Frame size 20 bit                       */
#define SPI_FrameSize_21b ((uint32)0x00005400U)  /*!< Frame size 21 bit                       */
#define SPI_FrameSize_22b ((uint32)0x00005800U)  /*!< Frame size 22 bit                       */
#define SPI_FrameSize_23b ((uint32)0x00005C00U)  /*!< Frame size 23 bit                       */
#define SPI_FrameSize_24b ((uint32)0x00006000U)  /*!< Frame size 24 bit                       */
#define SPI_FrameSize_25b ((uint32)0x00006400U)  /*!< Frame size 25 bit                       */
#define SPI_FrameSize_26b ((uint32)0x00006800U)  /*!< Frame size 26 bit                       */
#define SPI_FrameSize_27b ((uint32)0x00006C00U)  /*!< Frame size 27 bit                       */
#define SPI_FrameSize_28b ((uint32)0x00007000U)  /*!< Frame size 28 bit                       */
#define SPI_FrameSize_29b ((uint32)0x00007400U)  /*!< Frame size 29 bit                       */
#define SPI_FrameSize_30b ((uint32)0x00007800U)  /*!< Frame size 30 bit                       */
#define SPI_FrameSize_31b ((uint32)0x00007C00U)  /*!< Frame size 31 bit                       */
#define SPI_FrameSize_32b ((uint32)0x00008000U)  /*!< Frame size 32 bit                       */
/**
  * @}
  */

/** @defgroup SPI_Motorola_Mode SPI Motorola Mode
  * @{
  */
#define SPI_Motorola_Mode0 ((uint32)0x00000000U)  /*!< Motorola mode 0 (CPOL=0, CPHA=0)      */
#define SPI_Motorola_Mode1 ((uint32)0x00000004U)  /*!< Motorola mode 1 (CPOL=0, CPHA=1)      */
#define SPI_Motorola_Mode2 ((uint32)0x00000008U)  /*!< Motorola mode 2 (CPOL=1, CPHA=0)      */
#define SPI_Motorola_Mode3 ((uint32)0x0000000CU)  /*!< Motorola mode 3 (CPOL=1, CPHA=1)      */
/**
  * @}
  */

/** @defgroup SPI_Transmission_Mode SPI Transmission Mode
  * @{
  */
#define SPI_TransNor       ((uint32)0x00000000U)  /*!< Normal transmission mode              */
#define SPI_TransBToB      ((uint32)0x00000010U)  /*!< Back-to-back transmission mode        */
/**
  * @}
  */

/** @defgroup SPI_Slave_Selection SPI Slave Selection
  * @{
  */
#define SPI_Slave0         ((uint32)0x00000001U)  /*!< Selection slave 0                     */
#define SPI_Slave1         ((uint32)0x00000002U)  /*!< Selection slave 1                     */
#define SPI_Slave2         ((uint32)0x00000004U)  /*!< Selection slave 2                     */
#define SPI_Slave3         ((uint32)0x00000008U)  /*!< Selection slave 3                     */
/**
  * @}
  */

/** @defgroup SPI_Interrupts_Definition SPI Interrupts Definition
  * @note  Elements value convention: 000000000XXYYYYYb
  *        - YYYYY: interrupt source position in the register (5 bits);
  *        - XX   : interrupt source register (2 bits):
  *                 01: CR0 register, 10: IER register.
  * @{
  */
#define SPI_IT_TD           ((uint32)0x00000023U)  /*!< Tx done interrupt                    */
#define SPI_IT_RXO          ((uint32)0x00000024U)  /*!< RX buffer overflow interrupt         */
#define SPI_IT_TXE          ((uint32)0x00000025U)  /*!< TX buffer empty interrupt            */
#define SPI_IT_NSSV         ((uint32)0x00000045U)  /*!< NSS Voh interrupt                    */
#define SPI_IT_RXNE         ((uint32)0x00000046U)  /*!< RX buffer non-empty interrupt        */
#define SPI_IT_TXNE         ((uint32)0x00000047U)  /*!< TX buffer non-full interrupt         */
/**
  * @}
  */

/** @defgroup SPI_Interrupt_Status SPI Interrupt Status (masked)
  * @{
  */
#define SPI_ITStatus_TD     ((uint32)0x00000001U)  /*!< Tx done interrupt status             */
#define SPI_ITStatus_RXO    ((uint32)0x00000004U)  /*!< RX buffer overflow interrupt status  */
#define SPI_ITStatus_TXE    ((uint32)0x00000008U)  /*!< TX buffer empty interrupt status     */
#define SPI_ITStatus_NSSV   ((uint32)0x00000020U)  /*!< NSS Voh interrupt status             */
#define SPI_ITStatus_RXNE   ((uint32)0x00000040U)  /*!< RX buffer non-empty interrupt status */
#define SPI_ITStatus_TXNF   ((uint32)0x00000080U)  /*!< TX buffer non-full interrupt status  */
/**
  * @}
  */

/** @defgroup SPI_Interrupt_Clear SPI Interrupt Clear
  * @{
  */
#define SPI_CLEAR_TD        ((uint32)0x00000001U)  /*!< Tx done clear interrupt status       */
#define SPI_CLEAR_RXO       ((uint32)0x00000004U)  /*!< RX buffer overflow clear status      */
#define SPI_CLEAR_TXE       ((uint32)0x00000008U)  /*!< TX buffer empty clear status         */
#define SPI_CLEAR_NSSV      ((uint32)0x00000020U)  /*!< NSS Voh clear status                 */
#define SPI_CLEAR_RXNE      ((uint32)0x00000040U)  /*!< RX buffer non-empty clear status     */
#define SPI_CLEAR_TXNF      ((uint32)0x00000080U)  /*!< TX buffer non-full clear status      */
/**
  * @}
  */

/** @defgroup SPI_Flags SPI Status Flags
  * @{
  */
#define SPI_Flag_NFRX       ((uint32)0x00000001U)  /*!< NSS effective, first received frame   */
#define SPI_Flag_DONE       ((uint32)0x00000002U)  /*!< No TX/RX request                      */
#define SPI_Flag_RXE        ((uint32)0x00000004U)  /*!< RX buffer is empty                    */
#define SPI_Flag_TXF        ((uint32)0x00000008U)  /*!< TX buffer is full                     */
#define SPI_Flag_RXO        ((uint32)0x00000010U)  /*!< RX buffer overflow                    */
#define SPI_Flag_TXE        ((uint32)0x00000020U)  /*!< TX buffer is empty                    */
#define SPI_Flag_NSSS       ((uint32)0x00000040U)  /*!< State of slave select                 */
#define SPI_Flag_BUSS       ((uint32)0x00000080U)  /*!< SPI is still transmitting data        */
/**
  * @}
  */

/** @defgroup SPI_Enable_Value SPI Enable Value
  * @{
  */
#define SPI_ENABLE     1U           /*!< Enable the SPI peripheral / function    */
#define SPI_DISABLE    0U           /*!< Disable the SPI peripheral / function   */
/**
  * @}
  */

/** @defgroup SPI_FIFO_Reset SPI FIFO Reset
  * @{
  */
#define SPI_RESETFIFO_RX       ((uint32)0x00000001U)  /*!< Reset the receive FIFO       */
#define SPI_RESETFIFO_TX       ((uint32)0x00000002U)  /*!< Reset the transmit FIFO      */
#define SPI_RESETFIFO_TXANDRX  ((uint32)0x00000003U)  /*!< Reset both FIFOs             */
/**
  * @}
  */

/** @defgroup SPI_IT_Raw_Status SPI Interrupt Raw Status
  * @{
  */
#define SPI_ITRaw_TD           ((uint32)0x00000001U)  /*!< Tx done raw status            */
#define SPI_ITRaw_RXO          ((uint32)0x00000004U)  /*!< RX overflow raw status        */
#define SPI_ITRaw_TXE          ((uint32)0x00000008U)  /*!< TX empty raw status           */
#define SPI_ITRaw_NSSV         ((uint32)0x00000020U)  /*!< NSS Voh raw status            */
#define SPI_ITRaw_RXNE         ((uint32)0x00000040U)  /*!< RX non-empty raw status       */
#define SPI_ITRaw_TXNF         ((uint32)0x00000080U)  /*!< TX non-full raw status        */
/**
  * @}
  */

/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/

/** @addtogroup SPI_Exported_Functions
  * @{
  */

/** @addtogroup SPI_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Fills each SPI_InitStruct member with its default value. (NON-BLOCKING)
 * @param  SPI_InitStruct: pointer to a SPI_InitTypeDef structure which will
 *         be initialized (divider = 2, master mode, 8-bit frame,
 *         Motorola mode 0, normal transmission).
 * @retval None
 */
void HAL_SPI_StructInit(SPI_InitTypeDef *SPI_InitStruct);

/**
 * @brief  Initializes the SPI according to the specified parameters in the
 *         SPI_InitStruct of the handle. (NON-BLOCKING)
 * @note   The SPI clock gating and the pin multiplexing must be configured
 *         by the user in HAL_SPI_MspInit() (the SPI clock is enabled through
 *         the SMU bus clock configuration). HAL_SPI_MspInit() runs only on
 *         the first initialization (while the handle state is
 *         HAL_SPI_STATE_RESET) and is called before the handle lock is taken,
 *         so the callback may use other HAL APIs (MSP-04 / LOCK-06).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure that contains
 *         the configuration information for the specified SPI module.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_SPI_Init(SPI_HandleTypeDef *hspi);

/**
 * @brief  De-initializes the SPI peripheral. (NON-BLOCKING)
 * @note   HAL_SPI_MspDeInit() is called after the handle lock has been
 *         released, so the callback may use other HAL APIs (LOCK-06).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_SPI_DeInit(SPI_HandleTypeDef *hspi);

/**
 * @brief  Initializes the SPI MSP. Weak empty function; the user implements
 *         the low level hardware initialization (SPI clock enable through
 *         the SMU bus clock configuration, GPIO pin configuration).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval None
 */
void HAL_SPI_MspInit(SPI_HandleTypeDef *hspi);

/**
 * @brief  De-initializes the SPI MSP. Weak empty function; the user
 *         implements the low level hardware de-initialization.
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval None
 */
void HAL_SPI_MspDeInit(SPI_HandleTypeDef *hspi);

/**
  * @}
  */

/** @addtogroup SPI_Exported_Functions_Group2 IO operation functions
  * @brief    Polling mode IO operations
  * @{
  */

/**
 * @brief  Transmits an amount of data in blocking mode. (BLOCKING)
 * @note   In master mode the received data is read and discarded to keep
 *         the SPI clock running (full duplex).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  pData: pointer to the data buffer to transmit.
 * @param  Size: number of frames to transmit.
 * @param  Timeout: budget of the whole transfer in ms, covering the lock wait,
 *         every flag wait and the cleanup of a failed attempt
 *         (HAL_MAX_DELAY for infinite).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_SPI_Transmit(SPI_HandleTypeDef *hspi, uint8 *pData, uint32 Size,
                                   uint32 Timeout);

/**
 * @brief  Receives an amount of data in blocking mode. (BLOCKING)
 * @note   In master mode dummy frames are transmitted to generate the SPI
 *         clock.
 * @note   Every received frame is masked to the frame width of the mode
 *         register before it is stored, so the unused upper bits of a frame
 *         narrower than its storage width are always zero in the caller buffer.
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  pData: pointer to the data buffer to store the received data.
 * @param  Size: number of frames to receive.
 * @param  Timeout: budget of the whole transfer in ms, covering the lock wait,
 *         every flag wait and the cleanup of a failed attempt
 *         (HAL_MAX_DELAY for infinite).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 * @note   A transfer that fails is stopped and cleaned up before its state is
 *         published: the interrupt sources are blocked, the shifter is waited
 *         for within the remaining budget, both FIFOs are reset and the
 *         pending events are cleared, so a retry never reads stale frames.
 */
HAL_StatusTypeDef HAL_SPI_Receive(SPI_HandleTypeDef *hspi, uint8 *pData, uint32 Size,
                                  uint32 Timeout);

/**
 * @brief  Transmits and receives an amount of data in blocking mode. (BLOCKING)
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  pTxData: pointer to the data buffer to transmit.
 * @param  pRxData: pointer to the data buffer to store the received data.
 * @param  Size: number of frames to transmit and receive.
 * @param  Timeout: budget of the whole transfer in ms, covering the lock wait,
 *         every flag wait and the cleanup of a failed attempt
 *         (HAL_MAX_DELAY for infinite).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_SPI_TransmitReceive(SPI_HandleTypeDef *hspi, uint8 *pTxData,
                                          uint8 *pRxData, uint32 Size,

                                          uint32 Timeout);

/**
  * @}
  */

/** @addtogroup SPI_Exported_Functions_Group2_IT IO operation functions in interrupt mode
  * @brief    Interrupt mode IO operations
  * @{
  */

/**
 * @brief  Transmits an amount of data in non-blocking mode with Interrupt. (NON-BLOCKING / IT)
 * @note   The SPI Tx buffer empty interrupt is used to feed the transmit
 *         frame by frame; the transfer completion is reported by the
 *         HAL_SPI_TxCpltCallback().
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  pData: pointer to the data buffer to transmit.
 * @param  Size: number of frames to transmit.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_SPI_Transmit_IT(SPI_HandleTypeDef *hspi, uint8 *pData, uint32 Size);

/**
 * @brief  Receives an amount of data in non-blocking mode with Interrupt. (NON-BLOCKING / IT)
 * @note   In master mode the receive is driven by a full-duplex
 *         transmit/receive flow (dummy frames generate the SPI clock); the
 *         transfer completion is reported by the HAL_SPI_RxCpltCallback().
 * @note   Every received frame is masked to the frame width of the mode
 *         register before it is stored, so the unused upper bits of a frame
 *         narrower than its storage width are always zero in the caller buffer.
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  pData: pointer to the data buffer to store the received data.
 * @param  Size: number of frames to receive.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_SPI_Receive_IT(SPI_HandleTypeDef *hspi, uint8 *pData, uint32 Size);

/**
 * @brief  Transmits and receives an amount of data in non-blocking mode
 *         with Interrupt. (NON-BLOCKING / IT)
 * @note   The transfer completion is reported by the HAL_SPI_TxRxCpltCallback().
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  pTxData: pointer to the data buffer to transmit.
 * @param  pRxData: pointer to the data buffer to store the received data.
 * @param  Size: number of frames to transmit and receive.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_SPI_TransmitReceive_IT(SPI_HandleTypeDef *hspi, uint8 *pTxData,
                                             uint8 *pRxData,

                                             uint32 Size);

/**
  * @}
  */

/** @addtogroup SPI_Exported_Functions_Group2_DMA IO operation functions in DMA mode
  * @brief    DMA mode IO operations
  * @{
  */

/**
 * @brief  Transmits an amount of data in non-blocking mode with DMA. (NON-BLOCKING / DMA)
 * @note   The transfer completion is reported by the HAL_SPI_TxCpltCallback().
 *         The DMA channel referenced by hspi->hdmatx must be initialized
 *         (HAL_DMA_Init) and mapped to the SPI peripheral interface
 *         (HAL_DMAEx_ConfigPeriphIF) before this function is called.
 * @note   The channel is validated against the frame width of the mode register
 *         before the transfer starts: DMA_DIR must be DMA_MEMORY_TO_PERIPH,
 *         DMA_PeripheralInc must be disabled, DMA_MemoryInc enabled, DMA_M2M
 *         disabled, and both DMA_PeripheralDataSize and DMA_MemoryDataSize must
 *         equal the frame storage width (byte / half-word / word for a 1 / 2 /
 *         4 byte frame). A channel that does not match is rejected with
 *         HAL_ERROR and HAL_SPI_ERROR_INVALID_PARAM.
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  pData: pointer to the data buffer to transmit.
 * @param  Size: number of frames to transmit.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_SPI_Transmit_DMA(SPI_HandleTypeDef *hspi, uint8 *pData, uint32 Size);

/**
 * @brief  Receives an amount of data in non-blocking mode with DMA. (NON-BLOCKING / DMA)
 * @note   In master mode the receive is driven by a full-duplex
 *         transmit/receive flow (dummy frames generate the SPI clock); the
 *         transfer completion is reported by the HAL_SPI_RxCpltCallback().
 *         The DMA channel referenced by hspi->hdmarx must be initialized
 *         (HAL_DMA_Init) and mapped to the SPI peripheral interface
 *         (HAL_DMAEx_ConfigPeriphIF) before this function is called.
 * @note   The channel is validated against the frame width of the mode register
 *         before the transfer starts: DMA_DIR must be DMA_PERIPH_TO_MEMORY,
 *         DMA_PeripheralInc must be disabled, DMA_MemoryInc enabled, DMA_M2M
 *         disabled, and both DMA_PeripheralDataSize and DMA_MemoryDataSize must
 *         equal the frame storage width. Every received frame is masked to that
 *         width before the completion callback runs.
 * @note   In master mode the receive clock is provided by the frames the
 *         interface transmits, so the driver arms the virtual transmit stream:
 *         the transmission interrupt of the instance (TXE / TX FIFO not full)
 *         then writes one dummy frame per received frame. The SPI interrupt of
 *         the instance must therefore be enabled in the interrupt controller
 *         (the same requirement as the receive overflow interrupt this function
 *         already relies on), and the source is disarmed automatically when the
 *         transfer completes, fails or is aborted. A slave is clocked by the
 *         external master and needs no virtual stream.
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  pData: pointer to the data buffer to store the received data.
 * @param  Size: number of frames to receive.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_SPI_Receive_DMA(SPI_HandleTypeDef *hspi, uint8 *pData, uint32 Size);

/**
 * @brief  Transmits and receives an amount of data in non-blocking mode
 *         with DMA. (NON-BLOCKING / DMA)
 * @note   The transfer completion is reported by the HAL_SPI_TxRxCpltCallback().
 *         Both DMA channels referenced by hspi->hdmatx and hspi->hdmarx
 *         must be initialized and mapped to the SPI peripheral interface, and
 *         both are validated against the configured frame width (see
 *         HAL_SPI_Transmit_DMA / HAL_SPI_Receive_DMA). Every received frame is
 *         masked to its width before the completion callback runs.
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  pTxData: pointer to the data buffer to transmit.
 * @param  pRxData: pointer to the data buffer to store the received data.
 * @param  Size: number of frames to transmit and receive.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_SPI_TransmitReceive_DMA(SPI_HandleTypeDef *hspi, uint8 *pTxData,
                                              uint8 *pRxData,

                                              uint32 Size);

/**
  * @}
  */

/** @addtogroup SPI_Exported_Functions_Group3 Peripheral Control functions
  * @{
  */

/**
 * @brief  Return the SPI handle state. (NON-BLOCKING)
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval HAL_SPI_StateTypeDef: the current handle state.
 */
HAL_SPI_StateTypeDef HAL_SPI_GetState(SPI_HandleTypeDef *hspi);

/**
 * @brief  Return the SPI error code. (NON-BLOCKING)
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval uint32: the SPI error code (HAL_SPI_ERROR_xxx).
 */
uint32 HAL_SPI_GetError(SPI_HandleTypeDef *hspi);

/**
  * @}
  */

/** @addtogroup SPI_Exported_Functions_Group3_Peripheral_Control_Callbacks IRQ handler and callbacks
  * @{
  */

/**
 * @brief  Handle the SPI interrupt request.
 * @note   Called by the user SPI0..SPI5 IRQ handlers (see as32x601_plic.h);
 *         the SPI error and transfer-complete flags are serviced there and
 *         the corresponding user callbacks are invoked.
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval None
 */
void HAL_SPI_IRQHandler(SPI_HandleTypeDef *hspi);

/**
 * @brief  Tx Half Transfer completed callback (WEAK).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval None
 */
void HAL_SPI_TxHalfCpltCallback(SPI_HandleTypeDef *hspi);

/**
 * @brief  Tx Transfer completed callback (WEAK).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval None
 */
void HAL_SPI_TxCpltCallback(SPI_HandleTypeDef *hspi);

/**
 * @brief  Rx Half Transfer completed callback (WEAK).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval None
 */
void HAL_SPI_RxHalfCpltCallback(SPI_HandleTypeDef *hspi);

/**
 * @brief  Rx Transfer completed callback (WEAK).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval None
 */
void HAL_SPI_RxCpltCallback(SPI_HandleTypeDef *hspi);

/**
 * @brief  Tx/Rx Transfer completed callback (WEAK).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval None
 */
void HAL_SPI_TxRxCpltCallback(SPI_HandleTypeDef *hspi);

/**
 * @brief  SPI error callback (WEAK).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval None
 */
void HAL_SPI_ErrorCallback(SPI_HandleTypeDef *hspi);

/**
  * @}
  */

/** @addtogroup SPI_Exported_Functions_Group4 Low level register functions
  * @{
  */

/**
 * @brief  Enables or disables the specified SPI peripheral. (NON-BLOCKING)
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  NewState: SPI_ENABLE or SPI_DISABLE.
 * @retval None
 */
void HAL_SPI_Cmd(SPI_HandleTypeDef *hspi, uint32 NewState);

/**
 * @brief  Resets the specified SPI FIFO (receive / transmit / both). (NON-BLOCKING)
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  SPI_FIFOType: SPI_RESETFIFO_RX / SPI_RESETFIFO_TX /
 *         SPI_RESETFIFO_TXANDRX.
 * @retval None
 */
void HAL_SPI_ResetFIFO(SPI_HandleTypeDef *hspi, uint32 SPI_FIFOType);

/**
 * @brief  Sets or resets the specified SPI slave selection. (NON-BLOCKING)
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  Slavex: SPI_Slave0 / SPI_Slave1 / SPI_Slave2 / SPI_Slave3.
 * @param  NewState: 1 = select, 0 = deselect.
 * @retval None
 */
void HAL_SPI_NSSConfig(SPI_HandleTypeDef *hspi, uint32 Slavex, uint32 NewState);

/**
 * @brief  Transmits a single data frame through the SPI peripheral. (NON-BLOCKING)
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  Data: the data frame to transmit (right-aligned in the register).
 * @retval None
 */
void HAL_SPI_SendData(SPI_HandleTypeDef *hspi, uint32 Data);

/**
 * @brief  Transmits the last data frame of a transfer. (NON-BLOCKING)
 * @note   The last frame is written to the end-of-send data register.
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  DataLast: the last data frame to transmit.
 * @retval None
 */
void HAL_SPI_SendDataLast(SPI_HandleTypeDef *hspi, uint32 DataLast);

/**
 * @brief  Returns the most recent received data frame by the SPI peripheral. (NON-BLOCKING)
 * @note   The returned value is the raw register content: it is NOT masked to
 *         SPI_FrameSize. Use the transfer APIs to obtain frames masked to
 *         their configured width.
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval uint32: the received data frame.
 */
uint32 HAL_SPI_ReceiveData(SPI_HandleTypeDef *hspi);

/**
 * @brief  Enables or disables the specified SPI interrupt source. (NON-BLOCKING)
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  SPI_IT: the interrupt source to enable/disable (SPI_IT_xxx).
 * @param  NewState: 1 = enable, 0 = disable.
 * @retval None
 */
void HAL_SPI_ITConfig(SPI_HandleTypeDef *hspi, uint32 SPI_IT, uint32 NewState);

/**
 * @brief  Checks whether the specified SPI interrupt status (masked) is set. (NON-BLOCKING)
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  SPI_ITSTA: the interrupt status to check (SPI_ITStatus_xxx).
 * @retval 1 if the status is set, 0 otherwise.
 */
uint32 HAL_SPI_GetITStatus(SPI_HandleTypeDef *hspi, uint32 SPI_ITSTA);

/**
 * @brief  Checks whether the specified SPI interrupt raw status is set. (NON-BLOCKING)
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  SPI_ITRaw: the interrupt raw status to check (SPI_ITRaw_xxx).
 * @retval 1 if the raw status is set, 0 otherwise.
 */
uint32 HAL_SPI_GetITRawStatus(SPI_HandleTypeDef *hspi, uint32 SPI_ITRaw);

/**
 * @brief  Checks whether the specified SPI status flag is set. (NON-BLOCKING)
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  SPI_FLAG: the flag to check (SPI_Flag_xxx).
 * @retval 1 if the flag is set, 0 otherwise.
 */
uint32 HAL_SPI_GetFlagStatus(SPI_HandleTypeDef *hspi, uint32 SPI_FLAG);

/**
 * @brief  Clears the specified SPI interrupt pending bit. (NON-BLOCKING)
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  SPI_ITSTA: the interrupt pending bit to clear (SPI_CLEAR_xxx).
 * @retval None
 */
void HAL_SPI_ClearITPendingBit(SPI_HandleTypeDef *hspi, uint32 SPI_ITSTA);

/**
  * @}
  */

/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/

/** @defgroup SPI_Private_Macros SPI Private Macros
  * @{
  */

/**
 * @brief  Check that the SPI peripheral instance is one of SPI0..SPI5.
 */
#define IS_SPI_ALL_PERIPH(PERIPH) (((PERIPH) == SPI0) || \
                                   ((PERIPH) == SPI1) || \
                                   ((PERIPH) == SPI2) || \
                                   ((PERIPH) == SPI3) || \
                                   ((PERIPH) == SPI4) || \
                                   ((PERIPH) == SPI5))

/**
 * @brief  Check that the SPI mode is master or slave.
 */
#define IS_SPI_MODE(MODE) (((MODE) == SPI_Mode_Master) || ((MODE) == SPI_Mode_Slave))

/**
 * @brief  Check that the SPI clock divider is a valid value.
 */
#define IS_SPI_CLKDIV(CLKDIV) (((CLKDIV) == SPI_CLKDiv2)   || ((CLKDIV) == SPI_CLKDiv4)   || \
                               ((CLKDIV) == SPI_CLKDiv8)   || ((CLKDIV) == SPI_CLKDiv16)  || \
                               ((CLKDIV) == SPI_CLKDiv32)  || ((CLKDIV) == SPI_CLKDiv64)  || \
                               ((CLKDIV) == SPI_CLKDiv128) || ((CLKDIV) == SPI_CLKDiv256) || \
                               ((CLKDIV) == SPI_CLKDiv512))

/**
 * @brief  Check that the SPI frame size is a valid value.
 */
#define IS_SPI_FRAMESIZE(FRAMESIZE) (((FRAMESIZE) == SPI_FrameSize_4b)  || ((FRAMESIZE) == SPI_FrameSize_5b)  || \
                                     ((FRAMESIZE) == SPI_FrameSize_6b)  || ((FRAMESIZE) == SPI_FrameSize_7b)  || \
                                     ((FRAMESIZE) == SPI_FrameSize_8b)  || ((FRAMESIZE) == SPI_FrameSize_9b)  || \
                                     ((FRAMESIZE) == SPI_FrameSize_10b) || ((FRAMESIZE) == SPI_FrameSize_11b) || \
                                     ((FRAMESIZE) == SPI_FrameSize_12b) || ((FRAMESIZE) == SPI_FrameSize_13b) || \
                                     ((FRAMESIZE) == SPI_FrameSize_14b) || ((FRAMESIZE) == SPI_FrameSize_15b) || \
                                     ((FRAMESIZE) == SPI_FrameSize_16b) || ((FRAMESIZE) == SPI_FrameSize_17b) || \
                                     ((FRAMESIZE) == SPI_FrameSize_18b) || ((FRAMESIZE) == SPI_FrameSize_19b) || \
                                     ((FRAMESIZE) == SPI_FrameSize_20b) || ((FRAMESIZE) == SPI_FrameSize_21b) || \
                                     ((FRAMESIZE) == SPI_FrameSize_22b) || ((FRAMESIZE) == SPI_FrameSize_23b) || \
                                     ((FRAMESIZE) == SPI_FrameSize_24b) || ((FRAMESIZE) == SPI_FrameSize_25b) || \
                                     ((FRAMESIZE) == SPI_FrameSize_26b) || ((FRAMESIZE) == SPI_FrameSize_27b) || \
                                     ((FRAMESIZE) == SPI_FrameSize_28b) || ((FRAMESIZE) == SPI_FrameSize_29b) || \
                                     ((FRAMESIZE) == SPI_FrameSize_30b) || ((FRAMESIZE) == SPI_FrameSize_31b) || \
                                     ((FRAMESIZE) == SPI_FrameSize_32b))

/**
 * @brief  Check that the SPI Motorola mode is a valid value.
 */
#define IS_SPI_MOTOROLAMODE(MOTOROLAMODE) (((MOTOROLAMODE) == SPI_Motorola_Mode0) || \
                                           ((MOTOROLAMODE) == SPI_Motorola_Mode1) || \
                                           ((MOTOROLAMODE) == SPI_Motorola_Mode2) || \
                                           ((MOTOROLAMODE) == SPI_Motorola_Mode3))

/**
 * @brief  Check that the SPI transmission mode is a valid value.
 */
#define IS_SPI_TRANSMODE(TRANSMODE) (((TRANSMODE) == SPI_TransNor) || ((TRANSMODE) == SPI_TransBToB))

/**
 * @brief  Check that the SPI slave selection is a valid value.
 */
#define IS_SPI_SLAVESEL(SLAVESEL) (((SLAVESEL) == SPI_Slave0) || ((SLAVESEL) == SPI_Slave1) || \
                                   ((SLAVESEL) == SPI_Slave2) || ((SLAVESEL) == SPI_Slave3))

/**
 * @brief  Check that the SPI reset FIFO type is a valid value.
 */
#define IS_SPI_RESETFIFO(RESETFIFO) (((RESETFIFO) == SPI_RESETFIFO_RX) || \
                                     ((RESETFIFO) == SPI_RESETFIFO_TX) || \
                                     ((RESETFIFO) == SPI_RESETFIFO_TXANDRX))

/**
 * @brief  Check that the SPI interrupt source is a valid value.
 */
#define IS_SPI_CONFIG_IT(IT) (((IT) == SPI_IT_TD)   || ((IT) == SPI_IT_RXO)  || \
                              ((IT) == SPI_IT_TXE)  || ((IT) == SPI_IT_NSSV) || \
                              ((IT) == SPI_IT_RXNE) || ((IT) == SPI_IT_TXNE))

/**
 * @brief  Check that the SPI interrupt status is a valid value.
 */
#define IS_SPI_GETSTA_IT(ITSTA) (((ITSTA) == SPI_ITStatus_TD)   || ((ITSTA) == SPI_ITStatus_RXO)  || \
                                 ((ITSTA) == SPI_ITStatus_TXE)  || ((ITSTA) == SPI_ITStatus_NSSV) || \
                                 ((ITSTA) == SPI_ITStatus_RXNE) || ((ITSTA) == SPI_ITStatus_TXNF))

/**
 * @brief  Check that the SPI interrupt clear value is a valid value.
 */
#define IS_SPI_CLEAR_IT(IT) (((IT) == SPI_CLEAR_TD)   || ((IT) == SPI_CLEAR_RXO)  || \
                             ((IT) == SPI_CLEAR_TXE)  || ((IT) == SPI_CLEAR_NSSV) || \
                             ((IT) == SPI_CLEAR_RXNE) || ((IT) == SPI_CLEAR_TXNF))

/**
 * @brief  Check that the SPI status flag is a valid value.
 */
#define IS_SPI_FLAG(FLAG) (((FLAG) == SPI_Flag_NFRX) || ((FLAG) == SPI_Flag_DONE) || \
                           ((FLAG) == SPI_Flag_RXE)  || ((FLAG) == SPI_Flag_TXF)  || \
                           ((FLAG) == SPI_Flag_RXO)  || ((FLAG) == SPI_Flag_TXE)  || \
                           ((FLAG) == SPI_Flag_NSSS) || ((FLAG) == SPI_Flag_BUSS))

/**
 * @brief  Check that the SPI interrupt raw status is a valid value.
 */
#define IS_SPI_GETRAW_IT(ITRAW) (((ITRAW) == SPI_ITRaw_TD)   || ((ITRAW) == SPI_ITRaw_RXO)  || \
                                 ((ITRAW) == SPI_ITRaw_TXE)  || ((ITRAW) == SPI_ITRaw_NSSV) || \
                                 ((ITRAW) == SPI_ITRaw_RXNE) || ((ITRAW) == SPI_ITRaw_TXNF))

/**
  * @}
  */

/* Shared internal functions --------------------------------------------------*/

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_SPI_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the acquisition is bounded by the Timeout parameter (RTOS
 *         ticks, which with the usual 1 ms tick is the same quantity as the
 *         millisecond Timeout of the public API); HAL_MAX_DELAY waits forever.
 *         A mutex that was never created is reported as HAL_ERROR instead of
 *         being passed to the porting layer as a NULL handle.
 * @note   Called by the public API only; the interrupt paths (HAL_SPI_IRQHandler
 *         and the internal transfer services) must never take the lock
 *         (LOCK-04 / RTOS-12).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS, wait expired) /
 *         HAL_ERROR (RTOS, mutex not created) / HAL_BUSY (bare metal, the
 *         handle is already locked).
 */
HAL_StatusTypeDef SPI_LockHandle(SPI_HandleTypeDef *hspi, uint32 Timeout);

/**
 * @brief  Unlock the handle.
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval None
 */
void SPI_UnlockHandle(SPI_HandleTypeDef *hspi);

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_SPI_H */

/*****END OF FILE*****/
