/**
 * @file    USART_IT_DRV_018.c
 * @brief   HAL USART integration test case 018 (synchronous slave transmit (CPOL 0, CPHA 0)).
 *
 * HAL library port of the original AS32x601 standard-library test case
 * USART_IT_DRV_018.c, which drives USART7. Only HAL library APIs are
 * used; the register read backs are there to document what was programmed.
 *
 * Tested functionality:
 *   HAL_USART_DeInit()
 *   HAL_USART_StructInit()
 *   HAL_USART_Init()
 *   HAL_USART_EnableFIFO()
 *   HAL_USART_GetState()
 *   HAL_USART_GetError()
 *   HAL_USART_EnableSlaveMode()
 *   HAL_USART_ClockStructInit()
 *   HAL_USART_ConfigClock()
 *   HAL_USART_Transmit_IT()
 *   HAL_USART_TxDataFlush()
 *
 * Test procedure:
 *   1. map and configure the pins of the device under test (CK is an input here);
 *   2. program the frame parameters and initialize the USART;
 *   3. enable the receive FIFO mode, then the SPI slave mode, then the synchronous clock (the slave mode entry clears CLKEN);
 *   4. queue 8 bytes into the transmit FIFO with the interrupt driven entry point and check that the whole frame is staged;
 *   5. keep a frame armed and re-queue it as soon as the external master has clocked the previous one out; the FIFO flush is checked once, on a completed frame.
 *
 * Expected behaviour:
 *   - CR2.SLVEN is set by HAL_USART_EnableSlaveMode() and CR2.CLKEN by HAL_USART_ConfigClock();
 *   - the 8 bytes are queued into the transmit FIFO (TXFE clears) while no external clock is present;
 *   - with an SPI master connected the frame is clocked out, the transmit complete callback fires and the next frame is queued;
 *   - flushing an empty transmit FIFO returns HAL_OK;
 *   - every check prints [PASS] and "summary : failures = 0".
 *
 * Note:
 *   - Frame parameters: baud rate 281250, word length USART_WORDLENGTH_8B, stop bits USART_STOPBITS_1, parity USART_PARITY_NONE, hardware flow control USART_HWCONTROL_RTS, CPOL USART_POLARITY_LOW, CPHA USART_PHASE_1EDGE, LBCL USART_LASTBIT_ENABLE.
 *   - LBCL is set in synchronous mode as the original test case and the test
 *     specification require; in slave mode the clock itself comes from the master.
 *   - NSS (PC4) is mapped as an input driven by the external SPI master and
 *     RTS/DE (PC5) as an output, as in the original test case.
 *   - In the slave mode the clock comes from the external master, so a frame that
 *     is not clocked never completes. The frame is therefore kept queued in the
 *     transmit FIFO and queued again as soon as it has been clocked out: the
 *     slave has to be ready before the first clock edge of the master.
 *     HAL_USART_TxDataFlush() empties the FIFO but not the byte that is already
 *     in the shift register, and that byte can only leave with a master clock -
 *     a pre-fill followed by a flush therefore leaves one byte behind and shifts
 *     every later frame by one word (measured on the board: the master read
 *     0x11 0x11 0x22 ... 0x77). The original test case keeps re-filling the FIFO
 *     in its main loop for the same reason.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
/* Console: USART0 on GPIOD pin 8 (TX) / pin 9 (RX), 115200 8N1 */
#define TEST_BAUDRATE                   (115200U)

/* Device under test: the pins are the ones the original test case uses */
#define TEST_USART                      USART7
#define TEST_USART_IRQn                 USART7_IRQn
#define TEST_USART_IRQ_HANDLER          USART7_IRQ_Handler
#define TEST_TX_PORT                    GPIOA
#define TEST_TX_PIN                     GPIO_PIN_6
#define TEST_TX_SOURCE                  GPIO_PinSource6
#define TEST_TX_AF                      GPIO_AF_USART7
#define TEST_RX_PORT                    GPIOA
#define TEST_RX_PIN                     GPIO_PIN_7
#define TEST_RX_SOURCE                  GPIO_PinSource7
#define TEST_RX_AF                      GPIO_AF_USART7
#define TEST_CK_PORT                    GPIOB
#define TEST_CK_PIN                     GPIO_PIN_0
#define TEST_CK_SOURCE                  GPIO_PinSource0
#define TEST_CK_AF                      GPIO_AF_USART7
#define TEST_NSS_PORT                   GPIOC
#define TEST_NSS_PIN                    GPIO_PIN_4
#define TEST_NSS_SOURCE                 GPIO_PinSource4
#define TEST_NSS_AF                     GPIO_AF_USART7
#define TEST_RTS_PORT                   GPIOC
#define TEST_RTS_PIN                    GPIO_PIN_5
#define TEST_RTS_SOURCE                 GPIO_PinSource5
#define TEST_RTS_AF                     GPIO_AF_USART7

/* Frame parameters of this case */
#define TEST_BAUD_RATE                  (281250U)
#define TEST_WORD_LENGTH                USART_WORDLENGTH_8B
#define TEST_STOP_BITS                  USART_STOPBITS_1
#define TEST_PARITY                     USART_PARITY_NONE
#define TEST_MODE                       (USART_MODE_TX_RX)
#define TEST_OVERSAMPLING               USART_OVERSAMPLING_16
#define TEST_FLOW_CONTROL               USART_HWCONTROL_RTS
#define TEST_CLK_POLARITY               USART_POLARITY_LOW
#define TEST_CLK_PHASE                  USART_PHASE_1EDGE
#define TEST_CLK_LASTBIT                USART_LASTBIT_ENABLE
#define TEST_SYNC_MODE                  (1U)
#define TEST_SLAVE_MODE                 (1U)

/* Frame geometry, pacing and timeouts */
#define TX_FRAME_SIZE                   (8U)
#define RX_BURST_SIZE                   (64U)
#define TX_FRAME_PERIOD_MS              (500U)
#define TRANSFER_TIMEOUT_MS             (2000U)
#define WAIT_SPINS                      (20000000U)
#define RX_WAIT_MS                      (1000U)

/* Private variables --------------------------------------------------------*/
static USART_HandleTypeDef husart_dev;          /*!< device under test       */
static HAL_SMU_HandleTypeDef hsmu_clk;          /*!< SMU handle (clock tree) */
static const uint8 tx_data[TX_FRAME_SIZE] = {0x11U, 0x22U, 0x33U, 0x44U,
                                              0x55U, 0x66U, 0x77U, 0x88U};

static volatile uint32 check_failures = 0U;     /*!< failed check counter    */
static volatile uint32 tx_done = 0U;        /*!< transfer finished flag  */
static volatile uint32 tx_cplt_count = 0U;   /*!< TxCplt callback counter */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void USART_GPIO_Init(void);
static void Check(const char *name, uint32 condition);
static void Summary(void);
static uint32 Queue_Frame(uint32 frame);
static void USART_PLIC_Init(void);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    USART_InitTypeDef usart_init;
    uint32 expected_brr;
    uint32 frame;
    uint32 spins;
    uint32 armed;
    uint32 flush_checked;
    USART_ClockInitTypeDef clock_init;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock tree */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART (USART0 on GPIOD pin 8 / pin 9) */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== USART_IT_DRV_018 : synchronous slave transmit (CPOL 0, CPHA 0) ===\r\n");

    /* Step 1: map and configure the pins of the device under test */
    USART_GPIO_Init();

    /* Step 2: program the frame parameters and initialize the USART */
    (void)HAL_USART_DeInit(&husart_dev);

    HAL_USART_StructInit(&usart_init);
    usart_init.BaudRate            = TEST_BAUD_RATE;
    usart_init.WordLength          = TEST_WORD_LENGTH;
    usart_init.StopBits            = TEST_STOP_BITS;
    usart_init.Parity              = TEST_PARITY;
    usart_init.Mode                = TEST_MODE;
    usart_init.OverSampling        = TEST_OVERSAMPLING;
    usart_init.HardwareFlowControl = TEST_FLOW_CONTROL;
    usart_init.CLKPolarity         = TEST_CLK_POLARITY;
    usart_init.CLKPhase            = TEST_CLK_PHASE;
    usart_init.CLKLastBit          = TEST_CLK_LASTBIT;

    husart_dev.Instance = TEST_USART;
    husart_dev.Init     = usart_init;

    Check("HAL_USART_Init", (uint32)((HAL_USART_Init(&husart_dev) == HAL_OK) ? 1U : 0U));
    Check("state after init is READY",
          (uint32)((HAL_USART_GetState(&husart_dev) == HAL_USART_STATE_READY) ? 1U : 0U));
    Check("error code after init is NONE",
          (uint32)((HAL_USART_GetError(&husart_dev) == HAL_USART_ERROR_NONE) ? 1U : 0U));

    /* Cross check the baud rate divider: the driver computes the divider as
     * BRR = bus clock / baud rate. USART0..USART3 are clocked by APBBus0 and
     * USART4..USART7 by APBBus1. */
    expected_brr = HAL_SMU_GetPCLK1Freq() / TEST_BAUD_RATE;

    printf("bus clock       : %u Hz\r\n", PRINT_U32(HAL_SMU_GetPCLK1Freq()));
    printf("divider         : BRR = %u (expected %u) %s\r\n",
           PRINT_U32((uint32)TEST_USART->BRR), PRINT_U32(expected_brr),
           (((uint32)TEST_USART->BRR == expected_brr) ? "[PASS]" : "[FAIL]"));
    if ((uint32)TEST_USART->BRR != expected_brr)
    {
        check_failures++;
    }

    /* Step 3: enable the FIFO mode, as the original test case does */
    Check("HAL_USART_EnableFIFO",
          (uint32)((HAL_USART_EnableFIFO(&husart_dev) == HAL_OK) ? 1U : 0U));

    /* Interrupt routing of this case */
    USART_PLIC_Init();

    /* Synchronous slave mode: the slave mode entry clears CLKEN, so the clock
     * is programmed afterwards (see the main loop documentation). */
    Check("HAL_USART_EnableSlaveMode",
          (uint32)((HAL_USART_EnableSlaveMode(&husart_dev) == HAL_OK) ? 1U : 0U));

    HAL_USART_ClockStructInit(&clock_init);
    clock_init.Clock   = USART_CLOCK_ENABLE;
    clock_init.CPOL    = TEST_CLK_POLARITY;
    clock_init.CPHA    = TEST_CLK_PHASE;
    clock_init.LastBit = TEST_CLK_LASTBIT;
    Check("HAL_USART_ConfigClock",
          (uint32)((HAL_USART_ConfigClock(&husart_dev, &clock_init) == HAL_OK) ? 1U : 0U));
    /* Step 4: enter the synchronous slave mode and program the clock. The
     * order matters: HAL_USART_EnableSlaveMode() clears CLKEN (the slave mode
     * entry keeps LINEN and CLKEN cleared), so the clock has to be programmed
     * after it - exactly the order the original test case uses. */
    Check("HAL_USART_EnableSlaveMode",
          (uint32)((HAL_USART_EnableSlaveMode(&husart_dev) == HAL_OK) ? 1U : 0U));
    Check("CR2.SLVEN set by the slave mode entry",
          (uint32)(((TEST_USART->CR2 & (uint32)USART_CR2_SLVEN) != 0U) ? 1U : 0U));

    HAL_USART_ClockStructInit(&clock_init);
    clock_init.Clock   = USART_CLOCK_ENABLE;
    clock_init.CPOL    = TEST_CLK_POLARITY;
    clock_init.CPHA    = TEST_CLK_PHASE;
    clock_init.LastBit = TEST_CLK_LASTBIT;
    Check("HAL_USART_ConfigClock",
          (uint32)((HAL_USART_ConfigClock(&husart_dev, &clock_init) == HAL_OK) ? 1U : 0U));
    Check("CR2.CLKEN + CPOL + CPHA + LBCL programmed",
          (uint32)(((TEST_USART->CR2 & (uint32)(USART_CR2_CLKEN | USART_CR2_CPOL | USART_CR2_CPHA | USART_CR2_LBCL)) ==
                    (uint32)(TEST_CLK_POLARITY | TEST_CLK_PHASE | TEST_CLK_LASTBIT | USART_CLOCK_ENABLE)) ? 1U : 0U));

    /* Step 5: keep a frame armed in the transmit FIFO. The slave has no clock
     * of its own: the external SPI master clocks the frame out and the transmit
     * complete callback makes the driver ready, so the next frame is queued
     * right away.
     *
     * The frame must stay queued between two master reads, and a flush must not
     * happen on a loaded FIFO: HAL_USART_TxDataFlush() empties the FIFO but not
     * the byte that is already in the shift register, and that byte can only
     * leave with a master clock. A pre-fill followed by a flush therefore leaves
     * one byte behind and shifts every later frame by one word (measured on the
     * board: the master read 0x11 0x11 0x22 ... 0x77). The flush is checked
     * once, on a completed frame, where the FIFO and the shift register are both
     * empty. The original test case keeps re-filling the FIFO in its main loop
     * for the same reason. */
    frame         = 0U;
    armed         = 0U;
    flush_checked = 0U;
    while (1)
    {
        if (armed == 0U)
        {
            frame++;
            armed = Queue_Frame(frame);
        }

        /* Pacing delay: the frame is staged above, so the master finds a whole
         * frame at any time during the delay. A delay with an empty FIFO would
         * let it read idle data. */
        delay_ms(TX_FRAME_PERIOD_MS);

        spins = 0U;
        while ((tx_done == 0U) && (spins < (WAIT_SPINS / 20U)))
        {
            spins++;
        }

        printf("frame %u : spins = %u, TxCplt = %u, ISR = 0x%08X\r\n",
               PRINT_U32(frame), PRINT_U32(spins), PRINT_U32(tx_cplt_count),
               PRINT_U32((uint32)TEST_USART->ISR));

        if (tx_done != 0U)
        {
            /* The master clocked the whole frame out: the transmit FIFO and the
             * shift register are empty, so the flush can be verified here
             * without leaving a byte behind */
            if (flush_checked == 0U)
            {
                Check("HAL_USART_TxDataFlush",
                      (uint32)((HAL_USART_TxDataFlush(&husart_dev) == HAL_OK) ? 1U : 0U));
                flush_checked = 1U;
            }

            /* The driver is back to READY: the next frame is queued at the top
             * of the loop, a few cycles from here */
            armed = 0U;
        }
        else
        {
            /* No master clock yet: the frame stays queued and the slave is
             * ready for the first clock edge at any time */
        }

        Summary();
    }
}

/**
 * @brief  Report the result of one check.
 * @param  name: short description of the check.
 * @param  condition: 0 = FAIL, non zero = PASS.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("%-44s : [PASS]\r\n", name);
    }
    else
    {
        check_failures++;
        printf("%-44s : [FAIL]\r\n", name);
    }
}

/**
 * @brief  Print the accumulated failure counter.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("summary : failures = %u\r\n", PRINT_U32(check_failures));
}
/**
 * @brief  Configure the PLIC source(s) of this case.
 * @param  None
 * @retval None
 */
static void USART_PLIC_Init(void)
{
    PLIC_InitTypeDef plic;

    __HAL_SMU_PLIC_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&plic);
    plic.Size               = sizeof(plic);
    plic.Version            = PLIC_INIT_VERSION;
    plic.PLIC_IRQPriority   = 1U;
    plic.PLIC_IRQChannelCmd = ENABLE;

    plic.PLIC_IRQChannel    = TEST_USART_IRQn;
    HAL_PLIC_Init(&plic);

}

/**
 * @brief  Map and configure the pins of the device under test.
 * @note   The ports are the ones the original test case uses. GPIOH lives in
 *         the always on domain, so the library provides no clock gate for it.
 * @param  None
 * @retval None
 */
static void USART_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    /* Port clock gates used by this case */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    /* GPIOH (when used) lives in the always on domain: no clock gate */

    /* TX pin: alternate function push pull */
    HAL_GPIO_PinAFConfig(TEST_TX_PORT, TEST_TX_SOURCE, TEST_TX_AF);
    __HAL_CLEAR_STRUCT(&GPIO_InitStruct);
    GPIO_InitStruct.Size         = sizeof(GPIO_InitStruct);
    GPIO_InitStruct.Version      = GPIO_INIT_VERSION;
    GPIO_InitStruct.Pin          = TEST_TX_PIN;
    GPIO_InitStruct.Mode         = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull         = GPIO_NOPULL;
    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;
    GPIO_InitStruct.Alternate    = TEST_TX_AF;
    HAL_GPIO_Init(TEST_TX_PORT, &GPIO_InitStruct);

    /* RX pin: alternate function input (floating) */
    HAL_GPIO_PinAFConfig(TEST_RX_PORT, TEST_RX_SOURCE, TEST_RX_AF);
    GPIO_InitStruct.Pin       = TEST_RX_PIN;
    GPIO_InitStruct.Mode      = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull      = GPIO_NOPULL;
    GPIO_InitStruct.Alternate = TEST_RX_AF;
    HAL_GPIO_Init(TEST_RX_PORT, &GPIO_InitStruct);
    /* CK input: the external master drives the serial clock */
    HAL_GPIO_PinAFConfig(TEST_CK_PORT, TEST_CK_SOURCE, TEST_CK_AF);
    GPIO_InitStruct.Pin       = TEST_CK_PIN;
    GPIO_InitStruct.Mode      = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull      = GPIO_NOPULL;
    GPIO_InitStruct.Alternate = TEST_CK_AF;
    HAL_GPIO_Init(TEST_CK_PORT, &GPIO_InitStruct);
    /* NSS input: the external master drives the slave select */
    HAL_GPIO_PinAFConfig(TEST_NSS_PORT, TEST_NSS_SOURCE, TEST_NSS_AF);
    GPIO_InitStruct.Pin       = TEST_NSS_PIN;
    GPIO_InitStruct.Mode      = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull      = GPIO_NOPULL;
    GPIO_InitStruct.Alternate = TEST_NSS_AF;
    HAL_GPIO_Init(TEST_NSS_PORT, &GPIO_InitStruct);

    /* RTS / DE output of the hardware flow control */
    HAL_GPIO_PinAFConfig(TEST_RTS_PORT, TEST_RTS_SOURCE, TEST_RTS_AF);
    GPIO_InitStruct.Pin       = TEST_RTS_PIN;
    GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull      = GPIO_NOPULL;
    GPIO_InitStruct.Alternate = TEST_RTS_AF;
    HAL_GPIO_Init(TEST_RTS_PORT, &GPIO_InitStruct);
}
/**
 * @brief  USART interrupt handler (weak symbol of the trap entry).
 * @param  None
 * @retval None
 */
void TEST_USART_IRQ_HANDLER(void)
{
    HAL_USART_IRQHandler(&husart_dev);
}
/**
 * @brief  The transmit complete callback of the device under test.
 * @note   In the synchronous slave mode this callback runs only when an
 *         external SPI master clocks the frame out; the queued state of the
 *         transmit FIFO is checked directly in the main loop.
 * @param  husart: USART handle.
 * @retval None
 */
void HAL_USART_TxCpltCallback(USART_HandleTypeDef *husart)
{
    if (husart == &husart_dev)
    {
        tx_cplt_count++;
        tx_done = 1U;
    }
}

/**
 * @brief  Queue the test frame into the transmit FIFO with the interrupt driven
 *         entry point and report whether the whole frame was handed over.
 * @note   The FIFO state is sampled right after the call: the external master
 *         may clock the frame out at any time, so only the state at this instant
 *         tells whether the whole frame was staged (TXFE = TXFIFO empty, cleared
 *         while data are queued; TxXferCount counts the units still to push).
 * @param  frame: number of the frame, for the console report.
 * @retval 1 when the whole frame was queued, 0 otherwise.
 */
static uint32 Queue_Frame(uint32 frame)
{
    HAL_StatusTypeDef status;
    uint32 staged;

    tx_done       = 0U;
    tx_cplt_count = 0U;

    status = HAL_USART_Transmit_IT(&husart_dev, (uint8 *)tx_data, TX_FRAME_SIZE);

    if (status != HAL_OK)
    {
        check_failures++;
        printf("frame %u : HAL_USART_Transmit_IT = %u [FAIL]\r\n",
               PRINT_U32(frame), PRINT_U32((uint32)status));
        return 0U;
    }

    staged = (uint32)((((TEST_USART->ISR & (uint32)USART_FLAG_TXFE) == 0U) &&
                       (husart_dev.TxXferCount == 0U)) ? 1U : 0U);
    Check("8 bytes queued into the transmit FIFO (TXFE cleared)", staged);

    return staged;
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the CLINT / CMU / MPU integration tests: PLL
 *         VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2, CANX2 by 8.
 *         With this tree the APB bus clock is 22.5 MHz, which is the reference
 *         the baud rate divider check of every case is computed from.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef    SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the same set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_USART7_CLK_ENABLE();
    __HAL_SMU_USART7_FORCE_RESET();
    __HAL_SMU_USART7_RELEASE_RESET();

    /* Clock gate and reset pulse of the USART under test */
    /* Initialize the PMU before the voltage scaling calls: the LDO API is
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Clock tree order: this is the order the chip requires (and the one the
       reference test case uses):
         1. write the bus dividers while the system clock is still the power on
            source (FIRC), so that the new divider values are already in place
            when the faster clock arrives. Writing them after the switch leaves
            the buses at their reset dividers for a moment at the new core
            clock, which the core does not survive at 180 MHz.
         2. configure the PLL and switch the system clock to it. This call also
            programs the flash controller clock before the switch and update
            SystemCoreClock afterwards. */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
