/**
 * @file    TIM_IT_DRV_036.c
 * @brief   whole API self test (defaults, state machine, control functions and run time validation)
 *
 * HAL library port of the original AS32x601 standard-library test case
 * (no original case).c, which drives TIM0 / TIM3. Only HAL library APIs are used; the register
 * read backs document what was programmed.
 *
 * Tested functionality:
 *   HAL_TIM_Base_StructInit() / HAL_TIM_OC_StructInit() / HAL_TIM_IC_StructInit()
 *   HAL_TIM_TC_StructInit family (OnePulse / Encoder / ClockConfig / ClearInput / Slave / Master / BreakDeadTime)
 *   HAL_TIM_Base_Init() / HAL_TIM_Base_DeInit() / HAL_TIM_Base_GetState() / HAL_TIM_GetError()
 *   HAL_TIM_OC_Init() / HAL_TIM_PWM_Init() / HAL_TIM_IC_Init() / HAL_TIM_OnePulse_Init() / HAL_TIM_Encoder_Init()
 *   HAL_TIM_SetPrescaler() / HAL_TIM_SetAutoreload() / HAL_TIM_GetPrescaler() / HAL_TIM_GetCounter()
 *   HAL_TIM_SetCompare() / HAL_TIM_ReadCapturedValue()
 *   HAL_TIM_ConfigOCrefClear() / HAL_TIM_ConfigTI1Input()
 *   HAL_TIM_MasterConfigSynchronization() / HAL_TIM_GenerateEvent()
 *   HAL_TIM_ConfigBreakDeadTime() / HAL_TIM_CtrlPWMOutputs()
 *
 * Test procedure:
 *   check the default values written by the ten structure helpers;
 *   run the initialization / de-initialization state machine of the base unit and of the OC / PWM / IC / one pulse / encoder units;
 *   exercise the run time accessors (prescaler, autoreload, compare, captured value);
 *   exercise the control functions (OCREF clear, TI1 XOR, master TRGO, event generation);
 *   verify that the run time validation rejects the illegal configurations without touching the registers.
 *
 * Expected behaviour:
 *   every helper fills the documented defaults (the base helper also writes Size / Version);
 *   init leaves READY, deinit leaves RESET, and the error code stays NONE on the valid paths;
 *   the accessors read back the programmed values;
 *   the control functions return HAL_OK and set the expected register fields;
 *   the rejected configurations return HAL_ERROR with the invalid parameter error code and do not change the state;
 *   every check prints [PASS] and "summary : failures = 0".
 *
 * Note:
 *   This case extends the ported test cases with the interfaces that the original cases of this module do not reach; it runs entirely on registers, so it needs no external stimulus.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
/* Console: USART0 on GPIOD pin 8 (TX) / pin 9 (RX), 115200 8N1 */
#define TEST_BAUDRATE                   (115200U)


#define TEST_ARR                        (1000U - 1U)
#define TEST_PSC                        (9U - 1U)


/* Private variables -------------------------------------------------------*/
static HAL_TIM_HandleTypeDef htim_dev;          /*!< timer under test        */
static HAL_SMU_HandleTypeDef hsmu_clk;          /*!< SMU handle (clock tree) */
static volatile uint32 check_failures = 0U;     /*!< failed check counter    */



/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure the time base of the timer under test.
 * @note   The helper keeps the Size / Version meta fields through
 *         HAL_TIM_Base_StructInit(), which the initialization interface
 *         validates at run time.
 * @param  instance: TIM0..TIM7
 * @param  arr: auto reload value
 * @param  psc: prescaler value
 * @param  rcr: repetition counter (advanced timers only)
 * @param  ckd: clock division
 * @param  countermode: counting mode
 * @retval HAL status of HAL_TIM_Base_Init()
 */
static HAL_StatusTypeDef TimeBase_Config(TIM_TypeDef *instance, uint32 arr, uint32 psc,
                                         uint32 rcr, uint32 ckd, uint32 countermode)
{
    TIM_Base_InitTypeDef base_init;

    __HAL_CLEAR_STRUCT(&htim_dev);
    htim_dev.Instance = instance;

    HAL_TIM_Base_StructInit(&base_init);
    base_init.CounterMode       = countermode;
    base_init.ClockDivision     = ckd;
    base_init.Period            = arr;
    base_init.Prescaler         = psc;
    base_init.RepetitionCounter = rcr;
    htim_dev.Init               = base_init;

    return HAL_TIM_Base_Init(&htim_dev);
}

/**
 * @brief  Enable the clock of a timer instance and release its reset.
 * @note   The default MSP callbacks of this module are empty, so the suite
 *         performs the gate and reset handling itself; every MSP callback is
 *         routed to this helper.
 * @param  instance: TIM0..TIM7
 * @retval None
 */
static void Tim_ClockEnable(TIM_TypeDef *instance)
{
    if (instance == TIM0)
    {
        __HAL_SMU_HTIM0_CLK_ENABLE();
        __HAL_SMU_HTIM0_FORCE_RESET();
        __HAL_SMU_HTIM0_RELEASE_RESET();
    }
    else if (instance == TIM1)
    {
        __HAL_SMU_HTIM1_CLK_ENABLE();
        __HAL_SMU_HTIM1_FORCE_RESET();
        __HAL_SMU_HTIM1_RELEASE_RESET();
    }
    else if (instance == TIM2)
    {
        __HAL_SMU_HTIM2_CLK_ENABLE();
        __HAL_SMU_HTIM2_FORCE_RESET();
        __HAL_SMU_HTIM2_RELEASE_RESET();
    }
    else if (instance == TIM3)
    {
        __HAL_SMU_TIM3_CLK_ENABLE();
        __HAL_SMU_TIM3_FORCE_RESET();
        __HAL_SMU_TIM3_RELEASE_RESET();
    }
    else if (instance == TIM4)
    {
        __HAL_SMU_TIM4_CLK_ENABLE();
        __HAL_SMU_TIM4_FORCE_RESET();
        __HAL_SMU_TIM4_RELEASE_RESET();
    }
    else if (instance == TIM5)
    {
        __HAL_SMU_HTIM5_CLK_ENABLE();
        __HAL_SMU_HTIM5_FORCE_RESET();
        __HAL_SMU_HTIM5_RELEASE_RESET();
    }
    else if (instance == TIM6)
    {
        __HAL_SMU_TIM6_CLK_ENABLE();
        __HAL_SMU_TIM6_FORCE_RESET();
        __HAL_SMU_TIM6_RELEASE_RESET();
    }
    else
    {
        __HAL_SMU_TIM7_CLK_ENABLE();
        __HAL_SMU_TIM7_FORCE_RESET();
        __HAL_SMU_TIM7_RELEASE_RESET();
    }
}

/* MSP callbacks: the timer clock and reset of the instance under test */
void HAL_TIM_Base_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_OC_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_PWM_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_IC_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_OnePulse_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_Encoder_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the CLINT / CMU / MPU / USART integration tests:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2, CANX2 by
 *         8 -> core 180 MHz, AXILite4 Bus 1 and Bus 2 = 45 MHz (TIM0, TIM1),
 *         APBBus0 and APBBus1 = 22.5 MHz (TIM2 / TIM3 / TIM4 and TIM5 / TIM6 /
 *         TIM7 - TIM2 and TIM5 are advanced timers on the APB).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef    SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks used by this suite (GPIOH lives in the always on
       domain and has no gate macro) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Clock tree order: write the dividers while the system clock is still
       FIRC, then configure the PLL and switch to it (that call programs the
       flash controller clock before the switch and updates SystemCoreClock
       afterwards). */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    TIM_Base_InitTypeDef base_init;
    TIM_OC_InitTypeDef oc_init;
    TIM_IC_InitTypeDef ic_init;
    TIM_OnePulse_InitTypeDef op_init;
    TIM_Encoder_InitTypeDef enc_init;
    TIM_ClockConfigTypeDef clock_init;
    TIM_ClearInputConfigTypeDef clear_init;
    TIM_SlaveConfigTypeDef slave_init;
    TIM_MasterConfigTypeDef master_init;
    uint32                  cr2_before;
    TIM_BreakDeadTimeConfigTypeDef bdtr_init;
    HAL_TIM_HandleTypeDef htim_gen;
    uint32 idx;

    HAL_Init();
    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== TIM_IT_DRV_036 : whole API self test ===\r\n");

    /* ---- Group 1: the structure helpers and their defaults ---- */
    __HAL_CLEAR_STRUCT(&base_init);
    HAL_TIM_Base_StructInit(&base_init);
    Check("Base_StructInit() writes Size", (base_init.Size == sizeof(TIM_Base_InitTypeDef)));
    Check("Base_StructInit() writes Version", (base_init.Version == TIM_INIT_VERSION));
    Check("Base_StructInit() counter mode = UP", (base_init.CounterMode == TIM_COUNTERMODE_UP));
    Check("Base_StructInit() clock division = DIV1", (base_init.ClockDivision == TIM_CKD_DIV1));
    Check("Base_StructInit() reserved words are zero",
          ((base_init.Reserved[0] == 0U) && (base_init.Reserved[1] == 0U)));

    __HAL_CLEAR_STRUCT(&oc_init);
    HAL_TIM_OC_StructInit(&oc_init);
    Check("OC_StructInit() mode = TIMING", (oc_init.OCMode == TIM_OCMODE_TIMING));
    Check("OC_StructInit() polarity = HIGH", (oc_init.OCPolarity == TIM_OCPOLARITY_HIGH));
    Check("OC_StructInit() preload = DISABLE", (oc_init.OCPreload == TIM_OCPRECONFIG_DISABLE));

    __HAL_CLEAR_STRUCT(&ic_init);
    HAL_TIM_IC_StructInit(&ic_init);
    Check("IC_StructInit() polarity = RISING", (ic_init.ICPolarity == TIM_ICPOLARITY_RISING));
    Check("IC_StructInit() selection = DIRECT", (ic_init.ICSelection == TIM_ICSEL_DIRECTTI));
    Check("IC_StructInit() prescaler = DIV1", (ic_init.ICPrescaler == TIM_ICPSC_DIV1));

    __HAL_CLEAR_STRUCT(&op_init);
    HAL_TIM_OnePulse_StructInit(&op_init);
    __HAL_CLEAR_STRUCT(&enc_init);
    HAL_TIM_Encoder_StructInit(&enc_init);
    __HAL_CLEAR_STRUCT(&clock_init);
    HAL_TIM_ClockConfig_StructInit(&clock_init);
    __HAL_CLEAR_STRUCT(&clear_init);
    HAL_TIM_ClearInputConfig_StructInit(&clear_init);
    __HAL_CLEAR_STRUCT(&slave_init);
    HAL_TIM_SlaveConfig_StructInit(&slave_init);
    __HAL_CLEAR_STRUCT(&master_init);
    HAL_TIM_MasterConfig_StructInit(&master_init);
    __HAL_CLEAR_STRUCT(&bdtr_init);
    HAL_TIM_BreakDeadTimeConfig_StructInit(&bdtr_init);
    Check("the six remaining helpers run with a cleared structure", 1U);
    Check("ClockConfig_StructInit() source = INTERNAL",
          (clock_init.ClockSource == TIM_CLOCKSOURCE_INTERNAL));
    Check("ClearInput_StructInit() state = DISABLE",
          (clear_init.ClearInputState == TIM_CLEARINPUT_DISABLE));
    Check("SlaveConfig_StructInit() slave mode = DISABLE",
          (slave_init.SlaveMode == TIM_SLAVEMODE_DISABLE));
    Check("MasterConfig_StructInit() TRGO = RESET",
          (master_init.MasterOutputTrigger == TIM_TRGO_RESET));
    Check("MasterConfig_StructInit() TRGO2 = RESET",
          (master_init.MasterOutputTrigger2 == TIM_TRGO2_RESET));
    Check("IS_TIM_TRGO2_SOURCE() accepts the update event",
          (IS_TIM_TRGO2_SOURCE(TIM_TRGO2_UPDATE) != 0U));
    Check("IS_TIM_TRGO2_SOURCE() rejects a value outside the field",
          (IS_TIM_TRGO2_SOURCE(0x00000020U) == 0U));
    Check("BreakDeadTime_StructInit() dead time = 0", (bdtr_init.DeadTime == 0U));

    /* ---- Group 2: the base state machine ---- */
    Check("Base_Init() returns HAL_OK",
          (TimeBase_Config(TIM0, TEST_ARR, TEST_PSC, 0U, TIM_CKD_DIV1, TIM_COUNTERMODE_UP) == HAL_OK));
    Check("state after init is READY", (HAL_TIM_Base_GetState(&htim_dev) == HAL_TIM_STATE_READY));
    Check("error after init is NONE", (HAL_TIM_GetError(&htim_dev) == HAL_TIM_ERROR_NONE));

    Check("Base_DeInit() returns HAL_OK", (HAL_TIM_Base_DeInit(&htim_dev) == HAL_OK));
    Check("state after deinit is RESET", (HAL_TIM_Base_GetState(&htim_dev) == HAL_TIM_STATE_RESET));
    Check("counter is stopped after deinit", ((TIM0->CR1 & TIM_CR1_CEN) == 0U));
    Check("no interrupt request after deinit", (TIM0->DIER == 0U));
    Check("no channel output after deinit", (TIM0->CCER == 0U));

    /* ---- Group 3: the OC / PWM / IC / one pulse / encoder units ---- */
    Check("Base_Init() again returns HAL_OK",
          (TimeBase_Config(TIM0, TEST_ARR, TEST_PSC, 0U, TIM_CKD_DIV1, TIM_COUNTERMODE_UP) == HAL_OK));

    Check("OC_Init() returns HAL_OK", (HAL_TIM_OC_Init(&htim_dev) == HAL_OK));
    Check("OC state is READY", (HAL_TIM_OC_GetState(&htim_dev) == HAL_TIM_STATE_READY));
    Check("PWM_Init() returns HAL_OK", (HAL_TIM_PWM_Init(&htim_dev) == HAL_OK));
    Check("PWM state is READY", (HAL_TIM_PWM_GetState(&htim_dev) == HAL_TIM_STATE_READY));
    Check("IC_Init() returns HAL_OK", (HAL_TIM_IC_Init(&htim_dev) == HAL_OK));
    Check("IC state is READY", (HAL_TIM_IC_GetState(&htim_dev) == HAL_TIM_STATE_READY));
    Check("OnePulse_Init() returns HAL_OK", (HAL_TIM_OnePulse_Init(&htim_dev, TIM_OPMODE_REPETITIVE) == HAL_OK));
    Check("OnePulse state is READY", (HAL_TIM_OnePulse_GetState(&htim_dev) == HAL_TIM_STATE_READY));
    Check("Encoder_Init() returns HAL_OK", (HAL_TIM_Encoder_Init(&htim_dev, &enc_init) == HAL_OK));
    Check("Encoder state is READY", (HAL_TIM_Encoder_GetState(&htim_dev) == HAL_TIM_STATE_READY));

    Check("OC_DeInit() returns HAL_OK", (HAL_TIM_OC_DeInit(&htim_dev) == HAL_OK));
    Check("PWM_DeInit() returns HAL_OK", (HAL_TIM_PWM_DeInit(&htim_dev) == HAL_OK));
    Check("IC_DeInit() returns HAL_OK", (HAL_TIM_IC_DeInit(&htim_dev) == HAL_OK));
    Check("OnePulse_DeInit() returns HAL_OK", (HAL_TIM_OnePulse_DeInit(&htim_dev) == HAL_OK));
    Check("Encoder_DeInit() returns HAL_OK", (HAL_TIM_Encoder_DeInit(&htim_dev) == HAL_OK));

    /* ---- Group 4: the run time accessors ---- */
    Check("Base_Init() for the accessor group returns HAL_OK",
          (TimeBase_Config(TIM0, TEST_ARR, TEST_PSC, 0U, TIM_CKD_DIV1, TIM_COUNTERMODE_UP) == HAL_OK));
    HAL_TIM_SetPrescaler(&htim_dev, 99U);
    Check("SetPrescaler() reaches PSC", (TIM0->PSC == 99U));
    Check("GetPrescaler() reads back", (HAL_TIM_GetPrescaler(&htim_dev) == 99U));
    HAL_TIM_SetAutoreload(&htim_dev, 1234U);
    Check("SetAutoreload() reaches ARR", (TIM0->ARR == 1234U));
    HAL_TIM_SetCompare(&htim_dev, 567U, TIM_CHANNEL_5);
    Check("SetCompare(CH5) reaches CCR5", (TIM0->CCR5 == 567U));
    TIM0->CCR6 = 0x0ABU;
    Check("ReadCapturedValue(CH6) reads CCR6",
          (HAL_TIM_ReadCapturedValue(&htim_dev, TIM_CHANNEL_6) == 0x0ABU));
    Check("GetCounter() reads CNT", (HAL_TIM_GetCounter(&htim_dev) == TIM0->CNT));

    /* ---- Group 5: the control functions ---- */
    __HAL_CLEAR_STRUCT(&clear_init);
    HAL_TIM_ClearInputConfig_StructInit(&clear_init);
    clear_init.ClearInputState      = TIM_CLEARINPUT_ENABLE;
    clear_init.ClearInputSource     = TIM_CLEARINPUTSOURCE_ETR;
    clear_init.ClearInputPolarity   = TIM_CLEARINPUTPOLARITY_NONINVERTED;
    clear_init.ClearInputPrescaler  = TIM_CLEARINPUTPRESCALER_DIV1;
    clear_init.ClearInputFilter     = 0U;
    Check("ConfigOCrefClear(CH1) returns HAL_OK",
          (HAL_TIM_ConfigOCrefClear(&htim_dev, &clear_init, TIM_CHANNEL_1) == HAL_OK));
    Check("CCMR1.OC1CE is set", ((TIM0->CCMR1 & TIM_CCMR1_OC1CE) != 0U));

    Check("ConfigTI1Input(XOR) returns HAL_OK", (HAL_TIM_ConfigTI1Input(&htim_dev, 1U) == HAL_OK));
    Check("CR2.TI1S is set", ((TIM0->CR2 & TIM_CR2_TI1S) != 0U));
    Check("ConfigTI1Input(direct) returns HAL_OK", (HAL_TIM_ConfigTI1Input(&htim_dev, 0U) == HAL_OK));
    Check("CR2.TI1S is cleared", ((TIM0->CR2 & TIM_CR2_TI1S) == 0U));

    __HAL_CLEAR_STRUCT(&master_init);
    HAL_TIM_MasterConfig_StructInit(&master_init);
    master_init.MasterOutputTrigger  = TIM_TRGO_UPDATE;
    master_init.MasterSlaveMode      = TIM_MASTERSLAVEMODE_DISABLE;
    master_init.MasterOutputTrigger2 = TIM_TRGO2_OC2REF;
    Check("MasterConfigSynchronization() returns HAL_OK",
          (HAL_TIM_MasterConfigSynchronization(&htim_dev, &master_init) == HAL_OK));
    Check("CR2.MMS = 010 (update)", ((TIM0->CR2 & TIM_CR2_MMS) == TIM_TRGO_UPDATE));
    Check("CR2.MMS2 = 1000 (TRGO2 = OC2REF)",
          ((TIM0->CR2 & TIM_CR2_MMS2) == TIM_TRGO2_OC2REF));

    /* the second master output can also be written on its own; MMS and the
     * other CR2 bits must survive that */
    Check("SetMasterOutputTrigger2(OC3REF) returns HAL_OK",
          (HAL_TIM_SetMasterOutputTrigger2(&htim_dev, TIM_TRGO2_OC3REF) == HAL_OK));
    Check("CR2.MMS2 = 0110 (TRGO2 = OC3REF)",
          ((TIM0->CR2 & TIM_CR2_MMS2) == TIM_TRGO2_OC3REF));
    Check("CR2.MMS is preserved by SetMasterOutputTrigger2",
          ((TIM0->CR2 & TIM_CR2_MMS) == TIM_TRGO_UPDATE));
    Check("SetMasterOutputTrigger2(RESET) returns HAL_OK",
          (HAL_TIM_SetMasterOutputTrigger2(&htim_dev, TIM_TRGO2_RESET) == HAL_OK));
    Check("CR2.MMS2 is zero after the neutral value",
          ((TIM0->CR2 & TIM_CR2_MMS2) == 0U));
    Check("an out-of-field source is refused by SetMasterOutputTrigger2",
          (HAL_TIM_SetMasterOutputTrigger2(&htim_dev, 0x00000020U) == HAL_ERROR));
    Check("the refused source reports INVALID_PARAM",
          ((HAL_TIM_GetError(&htim_dev) & HAL_TIM_ERROR_INVALID_PARAM) != 0U));
    Check("CR2.MMS2 is untouched by the refused source",
          ((TIM0->CR2 & TIM_CR2_MMS2) == 0U));

    Check("GenerateEvent(UPDATE) returns HAL_OK",
          (HAL_TIM_GenerateEvent(&htim_dev, TIM_EVENTSOURCE_UPDATE) == HAL_OK));
    Check("DIER.UIE was not set by the event", ((TIM0->DIER & TIM_IT_UPDATE) == 0U));
    Check("GenerateEvent(CC1) returns HAL_OK",
          (HAL_TIM_GenerateEvent(&htim_dev, TIM_EVENTSOURCE_CC1) == HAL_OK));

    /* ---- Group 6: the run time validation ---- */
    /* meta fields */
    base_init.Size = 0U;
    htim_dev.Init = base_init;
    Check("Base_Init() rejects a wrong Size", (HAL_TIM_Base_Init(&htim_dev) == HAL_ERROR));
    Check("error code is INVALID_PARAM",
          ((HAL_TIM_GetError(&htim_dev) & HAL_TIM_ERROR_INVALID_PARAM) != 0U));

    __HAL_CLEAR_STRUCT(&base_init);
    HAL_TIM_Base_StructInit(&base_init);
    base_init.CounterMode = 0x7FU;
    htim_dev.Init = base_init;
    Check("Base_Init() rejects an illegal counter mode", (HAL_TIM_Base_Init(&htim_dev) == HAL_ERROR));

    /* channel 5 does not exist on a general purpose timer */
    __HAL_CLEAR_STRUCT(&htim_gen);
    htim_gen.Instance = TIM3;
    __HAL_CLEAR_STRUCT(&base_init);
    HAL_TIM_Base_StructInit(&base_init);
    base_init.Period = 1000U;
    base_init.Prescaler = 9U;
    htim_gen.Init = base_init;
    Check("TIM3 Base_Init() returns HAL_OK", (HAL_TIM_Base_Init(&htim_gen) == HAL_OK));
    __HAL_CLEAR_STRUCT(&oc_init);
    HAL_TIM_OC_StructInit(&oc_init);
    oc_init.OCMode = TIM_OCMODE_PWM1;
    Check("TIM3 PWM_ConfigChannel(CH5) is refused",
          (HAL_TIM_PWM_ConfigChannel(&htim_gen, &oc_init, TIM_CHANNEL_5) == HAL_ERROR));
    Check("TIM3 error code is INVALID_PARAM",
          ((HAL_TIM_GetError(&htim_gen) & HAL_TIM_ERROR_INVALID_PARAM) != 0U));
    Check("TIM3 PWM_ConfigChannel(CH4) is accepted",
          (HAL_TIM_PWM_ConfigChannel(&htim_gen, &oc_init, TIM_CHANNEL_4) == HAL_OK));

    /* TRGO2 (CR2.MMS2) does not exist on a general purpose timer: a real
     * source must be refused before the lock, the neutral value is accepted */
    cr2_before = TIM3->CR2;
    Check("TIM3 SetMasterOutputTrigger2(update) is refused",
          (HAL_TIM_SetMasterOutputTrigger2(&htim_gen, TIM_TRGO2_UPDATE) == HAL_ERROR));
    Check("TIM3 refused TRGO2 reports INVALID_PARAM",
          ((HAL_TIM_GetError(&htim_gen) & HAL_TIM_ERROR_INVALID_PARAM) != 0U));
    Check("TIM3 CR2 is not modified by the refused TRGO2",
          (TIM3->CR2 == cr2_before));
    Check("TIM3 accepts the neutral TRGO2 value",
          (HAL_TIM_SetMasterOutputTrigger2(&htim_gen, TIM_TRGO2_RESET) == HAL_OK));
    __HAL_CLEAR_STRUCT(&master_init);
    HAL_TIM_MasterConfig_StructInit(&master_init);
    master_init.MasterOutputTrigger  = TIM_TRGO_UPDATE;
    master_init.MasterSlaveMode      = TIM_MASTERSLAVEMODE_DISABLE;
    master_init.MasterOutputTrigger2 = TIM_TRGO2_UPDATE;
    Check("TIM3 MasterConfigSynchronization with a real TRGO2 is refused",
          (HAL_TIM_MasterConfigSynchronization(&htim_gen, &master_init) == HAL_ERROR));
    Check("TIM3 CR2 is unchanged after the refused master configuration",
          (TIM3->CR2 == cr2_before));
    master_init.MasterOutputTrigger2 = TIM_TRGO2_RESET;
    Check("TIM3 MasterConfigSynchronization with the neutral TRGO2 is accepted",
          (HAL_TIM_MasterConfigSynchronization(&htim_gen, &master_init) == HAL_OK));
    Check("TIM3 CR2.MMS = 010 (update)", ((TIM3->CR2 & TIM_CR2_MMS) == TIM_TRGO_UPDATE));
    Check("TIM3 CR2.MMS2 stays zero", ((TIM3->CR2 & TIM_CR2_MMS2) == 0U));

    /* a handle that was never initialized is rejected by the state gate */
    __HAL_CLEAR_STRUCT(&htim_gen);
    htim_gen.Instance = TIM3;
    Check("a RESET handle is rejected by Base_Start", (HAL_TIM_Base_Start(&htim_gen) == HAL_ERROR));
    Check("a RESET handle is rejected by SetCompare",
          ((HAL_TIM_SetPrescaler(&htim_gen, 1U), HAL_TIM_GetError(&htim_gen) == HAL_TIM_ERROR_NONE)));

    /* NULL handle protection */
    Check("NULL handle is rejected by Base_Init", (HAL_TIM_Base_Init(NULL_PTR) == HAL_ERROR));
    Check("NULL handle returns RESET state", (HAL_TIM_Base_GetState(NULL_PTR) == HAL_TIM_STATE_RESET));
    Check("NULL handle returns no error", (HAL_TIM_GetError(NULL_PTR) == HAL_TIM_ERROR_NONE));

    /* ---- Group 7: the break / dead time unit on the advanced timer ---- */
    Check("Base_Init() for the break group returns HAL_OK",
          (TimeBase_Config(TIM0, TEST_ARR, 99U, 0U, TIM_CKD_DIV1, TIM_COUNTERMODE_UP) == HAL_OK));
    __HAL_CLEAR_STRUCT(&bdtr_init);
    HAL_TIM_BreakDeadTimeConfig_StructInit(&bdtr_init);
    bdtr_init.OffStateRunMode  = TIM_OSSR_ENABLE;
    bdtr_init.OffStateIDLEMode = TIM_OSSI_ENABLE;
    bdtr_init.DeadTime         = 0x20U;
    bdtr_init.BreakState       = TIM_BREAK_DISABLE;
    bdtr_init.BreakPolarity    = TIM_BREAKPOLARITY_HIGH;
    bdtr_init.BreakFilter      = 0U;
    bdtr_init.AutomaticOutput  = TIM_AUTOMATICOUTPUT_ENABLE;
    Check("ConfigBreakDeadTime() returns HAL_OK",
          (HAL_TIM_ConfigBreakDeadTime(&htim_dev, &bdtr_init) == HAL_OK));
    Check("BDTR.DTG holds 0x20", ((TIM0->BDTR & TIM_BDTR_DTG) == 0x20U));
    HAL_TIM_CtrlPWMOutputs(&htim_dev, TIM_ENABLE);
    Check("CtrlPWMOutputs(ENABLE) sets MOE", ((TIM0->BDTR & TIM_BDTR_MOE) != 0U));
    HAL_TIM_CtrlPWMOutputs(&htim_dev, TIM_DISABLE);
    Check("CtrlPWMOutputs(DISABLE) clears MOE", ((TIM0->BDTR & TIM_BDTR_MOE) == 0U));

    for (idx = 0U; idx < 3U; idx++)
    {
        delay_ms(10U);
    }

    Summary();

    for (;;)
    {
    }
}
