/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_dac.c
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.4
 * Date:   2026/11/05
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/19     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.1     add the module guard (HAL_DAC_MODULE_ENABLED) around the whole implementation
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.2     put the as32x601_hal.h include first (module switch from the conf) before the module headers
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.3     apply the resource lock / RTOS rules:
 *                                                       run the MSP callbacks outside the
 *                                                       locked region, add the shared lock
 *                                                       helper with a Timeout and a
 *                                                       NULL-mutex guard, protect the
 *                                                       initialization, de-initialization,
 *                                                       start / stop and data interfaces
 *                                                       with it (the de-initialization no
 *                                                       longer releases a lock it never
 *                                                       acquired), add the busy / reset
 *                                                       state gate and the run-time
 *                                                       parameter validation
 *     ANSILIC APPLICATION GROUP  2026/11/05     1.4     complete the run-time parameter
 *                                                       validation: check the DAC enable
 *                                                       field of the initialization and
 *                                                       the comparator enable field of the
 *                                                       comparator configuration, so that
 *                                                       an out of range enable value is
 *                                                       rejected with the invalid parameter
 *                                                       error code (and cannot corrupt the
 *                                                       MD / EN bits of DAC_CTRL) in a build
 *                                                       with the assertions disabled
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Digital to Analog
 *                  Converter (DAC) peripheral:
 *                  - Initialization and de-initialization functions
 *                    (HAL_DAC_Init / HAL_DAC_DeInit + weak MSP hooks);
 *                  - IO operation functions (HAL_DAC_Start / HAL_DAC_Stop /
 *                    HAL_DAC_GetValue);
 *                  - Peripheral Control functions (HAL_DAC_SetValue);
 *                  - Peripheral State and Errors functions (HAL_DAC_GetState /
 *                    HAL_DAC_GetError).
 *                  The chip-specific extended features (on-chip comparator and
 *                  DAC reset control) are provided by this driver.
 *                  HAL_DAC_MspInit() must be overridden by the user to enable
 *                  the DAC peripheral clock and release its bus reset through
 *                  the SMU HAL macros, e.g. for DAC0:
 *                    __HAL_SMU_DAC0_CLK_ENABLE();
 *                    __HAL_SMU_DAC0_RELEASE_RESET();
 *                  (DAC0 clock gate is in SMU->ALB1CFGR, DAC1 clock gate is
 *                  in SMU->ALB2CFGR).
 */
#include "as32x601_hal.h"           /* module switch from as32x601_hal_conf.h */
#include "as32x601_hal_dac.h"       /* DAC HAL API and register macros         */

/* The HAL_DAC_MODULE_ENABLED switch is provided by the user configuration
 * file (as32x601_hal_conf.h, included above through as32x601_hal.h): the
 * whole implementation is compiled only while the module is enabled. */
#ifdef HAL_DAC_MODULE_ENABLED

/* Private functions prototypes ---------------------------------------------*/
/* DAC_HandleIsValid, DAC_CheckState, DAC_LockHandle and DAC_UnlockHandle are
   shared by every entry point: they are declared in the header shared
   internal functions section. */

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Check whether the DAC handle and its instance are valid.
 * @param  hdac: pointer to a DAC_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
uint32 DAC_HandleIsValid(DAC_HandleTypeDef *hdac)
{
    if (hdac == NULL_PTR)
    {
        return 0U;
    }

    if (IS_DAC_ALL_INSTANCE(hdac->Instance) == 0U)
    {
        return 0U;
    }

    return 1U;
}

/**
 * @brief  Check whether the handle accepts a new operation.
 * @note   Architecture constraint ARCH-CONST-09: a handle that is busy (an
 *         operation is ongoing in another context) rejects any other operation
 *         with HAL_BUSY, and a handle that is not initialized (RESET) requires
 *         HAL_DAC_Init() first and is rejected with HAL_ERROR. The remaining
 *         states (READY, and the recoverable TIMEOUT / ERROR) accept the call
 *         directly, so that no DeInit / Init round trip is required.
 * @param  hdac: pointer to a DAC_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK (accepted) / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef DAC_CheckState(DAC_HandleTypeDef *hdac)
{
    if (hdac->State == HAL_DAC_STATE_BUSY)
    {
        return HAL_BUSY;
    }

    if (hdac->State == HAL_DAC_STATE_RESET)
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_DAC_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; when the mutex is not acquired before the
 *         Timeout expires, HAL_TIMEOUT is returned. The value is passed to
 *         HAL_MutexAcquire() as is (RTOS ticks; with the usual 1 ms tick it is
 *         the same quantity as the millisecond Timeout of the public API, and
 *         HAL_MAX_DELAY means an infinite wait).
 * @param  hdac: pointer to a DAC_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef DAC_LockHandle(DAC_HandleTypeDef *hdac, uint32 Timeout)
{
#if (USE_RTOS == 1)
    if (hdac->LockMutex == NULL_PTR)
    {
        /* The porting layer did not create the mutex (e.g. HAL_DAC_MspInit()
         * was not overridden): report it instead of calling the RTOS with a
         * NULL handle */
        return HAL_ERROR;
    }

    return HAL_MutexAcquire(hdac->LockMutex, Timeout);
#else
    /* Prevent unused argument compilation warning: the bare-metal lock flag
     * either succeeds immediately or reports HAL_BUSY, it never waits */
    UNUSED(Timeout);

    if (hdac->Lock == HAL_LOCKED)
    {
        return HAL_BUSY;
    }

    hdac->Lock = HAL_LOCKED;

    return HAL_OK;
#endif /* USE_RTOS */
}

/**
 * @brief  Unlock the handle.
 * @param  hdac: pointer to a DAC_HandleTypeDef structure.
 * @retval None
 */
void DAC_UnlockHandle(DAC_HandleTypeDef *hdac)
{
#if (USE_RTOS == 1)
    (void)HAL_MutexRelease(hdac->LockMutex);
#else
    hdac->Lock = HAL_UNLOCKED;
#endif /* USE_RTOS */
}

/* Exported functions ---------------------------------------------------------*/

/** @defgroup DAC_Exported_Functions DAC Exported Functions
  * @{
  */

/** @defgroup DAC_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Initialize the DAC_InitTypeDef structure with default values. (NON-BLOCKING)
 * @note   Sets the Size / Version compatibility metafields and fills the
 *         configuration fields with the DAC default values.
 * @param  DAC_InitStruct: pointer to a DAC_InitTypeDef structure.
 * @retval None
 */
void HAL_DAC_StructInit(DAC_InitTypeDef *DAC_InitStruct)
{
    /* Check the parameter */
    if (DAC_InitStruct == NULL_PTR)
    {
        return;
    }

    /* Compatibility metafields */
    DAC_InitStruct->Size              = sizeof(DAC_InitTypeDef);
    DAC_InitStruct->Version           = DAC_INIT_VERSION;

    /* Default configuration */
    DAC_InitStruct->DAC_Enable        = DISABLE;
    DAC_InitStruct->DAC_Mode          = DAC_OUTPUTBUFFER_ENABLE;
    DAC_InitStruct->DAC_VrefMode      = DAC_VREF_MD_VREFP;
    DAC_InitStruct->DAC_ClockDivider  = 1U;
    DAC_InitStruct->Reserved[0]       = 0U;
    DAC_InitStruct->Reserved[1]       = 0U;
}

/**
 * @brief  Initialize the DAC peripheral according to the specified parameters
 *         in the hdac->Init structure (output mode, reference voltage, clock
 *         divider, enable state) and initialize the low level hardware.
 * @note   The DAC_ClockDivider field is limited to 0x01 - 0xFF: a 0 value is
 *         interpreted as 1 so that the DAC conversion clock is never stopped.
 *         The RESETN bit is not touched here (released by HAL_DAC_MspInit()).
 * @note   The parameters and the configuration structure metafields (Size /
 *         Version) are validated at run time: an invalid configuration is
 *         rejected with HAL_ERROR and HAL_DAC_ERROR_INVALID_PARAM without
 *         taking the lock and without changing the handle state.
 * @note   LOCK-06: the low level initialization (HAL_DAC_MspInit()) runs
 *         before the handle is locked, so that an override which calls other
 *         HAL APIs (e.g. HAL_GPIO_Init()) cannot deadlock.
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
 *         configuration information for the specified DAC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (NULL pointer, invalid instance or invalid
 *         configuration)
 */
HAL_StatusTypeDef HAL_DAC_Init(DAC_HandleTypeDef *hdac)
{
    /* Check the DAC peripheral handle and instance */
    if (DAC_HandleIsValid(hdac) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_DAC_EN(hdac->Init.DAC_Enable));
    assert_param(IS_DAC_OUTPUT_BUFFER_STATE(hdac->Init.DAC_Mode));
    assert_param(IS_DAC_VREF_MD(hdac->Init.DAC_VrefMode));
    assert_param(IS_DAC_CLK_DIV(hdac->Init.DAC_ClockDivider));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. A DAC_ClockDivider of 0 is
     * accepted here, it is normalized to 1 below. */
    if ((hdac->Init.Size != sizeof(DAC_InitTypeDef)) ||
        (hdac->Init.Version != DAC_INIT_VERSION) ||
        (IS_DAC_EN(hdac->Init.DAC_Enable) == 0U) ||
        (IS_DAC_OUTPUT_BUFFER_STATE(hdac->Init.DAC_Mode) == 0U) ||
        (IS_DAC_VREF_MD(hdac->Init.DAC_VrefMode) == 0U) ||
        (IS_DAC_CLK_DIV(hdac->Init.DAC_ClockDivider) == 0U))
    {
        hdac->ErrorCode |= HAL_DAC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Allocate the lock resource before the first use, so that a handle that
     * was never initialized cannot report HAL_BUSY from a stale Lock field */
    if (hdac->State == HAL_DAC_STATE_RESET)
    {
        hdac->Lock = HAL_UNLOCKED;

        /* Init the low level hardware (peripheral clock / reset release).
         * LOCK-06: the MSP callback runs before the handle is locked */
        HAL_DAC_MspInit(hdac);
    }

    /* Process locked */
    if (DAC_LockHandle(hdac, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Initialize the DAC state */
    hdac->State = HAL_DAC_STATE_BUSY;

    /* Set DAC error code to none */
    hdac->ErrorCode = HAL_DAC_ERROR_NONE;

    /* A divide ratio of 0 would stop the DAC conversion clock: default to 1 */
    if (hdac->Init.DAC_ClockDivider == 0U)
    {
        hdac->Init.DAC_ClockDivider = 1U;
    }

    /* Set DAC clock divide ratio (DAC_CLK_DIV register) */
    MODIFY_REG(hdac->Instance->CLK_DIV, DAC_CLK_DIV_NU,
               ((uint32)hdac->Init.DAC_ClockDivider) << DAC_CLK_DIV_NU_Pos);

    /* Set DAC output mode (DAC_CTRL.MD bit) */
    MODIFY_REG(hdac->Instance->CTRL, DAC_CTRL_MD,
               ((uint32)hdac->Init.DAC_Mode) << DAC_CTRL_MD_Pos);

    /* Set DAC reference voltage mode (DAC_CTRL.VREF_MD bit) */
    MODIFY_REG(hdac->Instance->CTRL, DAC_CTRL_VREF_MD,
               ((uint32)hdac->Init.DAC_VrefMode) << DAC_CTRL_VREF_MD_Pos);

    /* Enable or disable the DAC (DAC_CTRL.EN bit) */
    MODIFY_REG(hdac->Instance->CTRL, DAC_CTRL_EN,
               ((uint32)hdac->Init.DAC_Enable) << DAC_CTRL_EN_Pos);

    /* Initialize the DAC state */
    hdac->State = HAL_DAC_STATE_READY;

    /* Release Lock */
    DAC_UnlockHandle(hdac);

    /* Return function status */
    return HAL_OK;
}

/**
 * @brief  De-initialize the DAC peripheral registers to their default reset
 *         values.
 * @note   The DAC_CTRL.RESETN bit is kept unchanged (the reset state is
 *         handled by HAL_DAC_MspDeInit() through the SMU bus reset). The
 *         comparator registers are cleared as well, matching the register
 *         state left by a peripheral reset.
 * @note   The call is accepted from any handle state, so that a failed
 *         initialization can always be undone; the handle goes back to the
 *         RESET state so that a following HAL_DAC_Init() re-runs
 *         HAL_DAC_MspInit().
 * @note   LOCK-06: the low level de-initialization (HAL_DAC_MspDeInit()) runs
 *         after the unlock, so that an override which calls other HAL APIs
 *         (e.g. HAL_GPIO_DeInit()) cannot deadlock.
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
 *         configuration information for the specified DAC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (NULL pointer or invalid instance)
 */
HAL_StatusTypeDef HAL_DAC_DeInit(DAC_HandleTypeDef *hdac)
{
    /* Check the DAC peripheral handle and instance */
    if (DAC_HandleIsValid(hdac) == 0U)
    {
        return HAL_ERROR;
    }

    /* Process locked. ARCH-CONST-09: the de-initialization is callable from
     * any handle state, so that a failed initialization can always be undone */
    if (DAC_LockHandle(hdac, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Change DAC state */
    hdac->State = HAL_DAC_STATE_BUSY;

    /* Disable the DAC and restore the control register default values.
     * The DAC_CTRL.RESETN bit is kept unchanged: the reset state is handled
     * by HAL_DAC_MspDeInit() through the SMU bus reset macros. */
    CLEAR_BIT(hdac->Instance->CTRL, (DAC_CTRL_EN | DAC_CTRL_MD | DAC_CTRL_VREF_MD));
    WRITE_REG(hdac->Instance->CLK_DIV, 0x00U);
    WRITE_REG(hdac->Instance->CMP_CTRL, 0x00U);

    /* Set DAC error code to none */
    hdac->ErrorCode = HAL_DAC_ERROR_NONE;

    /* Change DAC state */
    hdac->State = HAL_DAC_STATE_RESET;

    /* Release Lock */
    DAC_UnlockHandle(hdac);

    /* LOCK-06 / ARCH-CONST-04: the low level de-initialization runs OUTSIDE
     * the locked region, as the architecture specification requires for the
     * MSP callbacks ("MspDeInit is called after the unlock") */
    HAL_DAC_MspDeInit(hdac);

    /* Return function status */
    return HAL_OK;
}

/**
 * @brief  Initialize the DAC MSP (peripheral clock enable, reset release).
 * @note   This function should not be modified: when the MSP initialization
 *         is needed, HAL_DAC_MspInit() should be implemented in the user file
 *         (e.g. call __HAL_SMU_DAC0_CLK_ENABLE() / __HAL_SMU_DAC0_RELEASE_RESET()
 *         for DAC0, or the DAC1 counterparts for DAC1).
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
 *         configuration information for the specified DAC.
 * @retval None
 */
__weak void HAL_DAC_MspInit(DAC_HandleTypeDef *hdac)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(hdac);

    /* NOTE : This function should not be modified, when the callback is needed,
              the HAL_DAC_MspInit could be implemented in the user file
    */
}

/**
 * @brief  De-initialize the DAC MSP (peripheral clock disable, reset assert).
 * @note   This function should not be modified: when the MSP de-initialization
 *         is needed, HAL_DAC_MspDeInit() should be implemented in the user file
 *         (e.g. call __HAL_SMU_DAC0_FORCE_RESET() / __HAL_SMU_DAC0_CLK_DISABLE()
 *         for DAC0, or the DAC1 counterparts for DAC1).
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
 *         configuration information for the specified DAC.
 * @retval None
 */
__weak void HAL_DAC_MspDeInit(DAC_HandleTypeDef *hdac)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(hdac);

    /* NOTE : This function should not be modified, when the callback is needed,
              the HAL_DAC_MspDeInit could be implemented in the user file
    */
}

/**
  * @}
  */

/** @defgroup DAC_Exported_Functions_Group2 IO operation functions
  * @{
  */

/**
 * @brief  Enable the DAC (starts the conversion of the 8-bit data written to
 *         the DAC_DOUT register).
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_DAC_Init() is required first).
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
 *         configuration information for the specified DAC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance or the handle is not initialized)
 */
HAL_StatusTypeDef HAL_DAC_Start(DAC_HandleTypeDef *hdac)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the DAC peripheral handle and instance */
    if (DAC_HandleIsValid(hdac) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_DAC_Init() is
     * required first) */
    status = DAC_CheckState(hdac);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (DAC_LockHandle(hdac, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Change DAC state */
    hdac->State = HAL_DAC_STATE_BUSY;

    /* Enable the DAC */
    __HAL_DAC_ENABLE(hdac);

    /* Change DAC state */
    hdac->State = HAL_DAC_STATE_READY;

    /* Release Lock */
    DAC_UnlockHandle(hdac);

    /* Return function status */
    return HAL_OK;
}

/**
 * @brief  Disable the DAC (stops the conversion).
 * @note   The call is accepted from any initialized handle state, so that a
 *         running conversion can always be stopped.
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
 *         configuration information for the specified DAC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance or the handle is not initialized)
 */
HAL_StatusTypeDef HAL_DAC_Stop(DAC_HandleTypeDef *hdac)
{
    /* Check the DAC peripheral handle and instance */
    if (DAC_HandleIsValid(hdac) == 0U)
    {
        return HAL_ERROR;
    }

    if (hdac->State == HAL_DAC_STATE_RESET)
    {
        return HAL_ERROR;
    }

    /* Process locked */
    if (DAC_LockHandle(hdac, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Change DAC state */
    hdac->State = HAL_DAC_STATE_BUSY;

    /* Disable the DAC */
    __HAL_DAC_DISABLE(hdac);

    /* Change DAC state */
    hdac->State = HAL_DAC_STATE_READY;

    /* Release Lock */
    DAC_UnlockHandle(hdac);

    /* Return function status */
    return HAL_OK;
}

/**
 * @brief  Return the last data value written to the DAC data register. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context.
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
 *         configuration information for the specified DAC.
 * @retval uint32: the DAC data register value (8-bit), 0 when the handle or
 *         the instance is invalid.
 */
uint32 HAL_DAC_GetValue(DAC_HandleTypeDef *hdac)
{
    /* Check the DAC peripheral handle and instance */
    if (DAC_HandleIsValid(hdac) == 0U)
    {
        return 0U;
    }

    /* Return the DAC data register value */
    return (uint32)READ_REG(hdac->Instance->DOUT);
}

/**
  * @}
  */

/** @defgroup DAC_Exported_Functions_Group3 Peripheral Control functions
  * @{
  */

/**
 * @brief  Set the 8-bit data holding register value of the DAC.
 * @note   The Data parameter is limited to 0x00 - 0xFF (8-bit DAC). The
 *         runtime validation below covers the case of a build with the
 *         assertions disabled.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_DAC_Init() is required first).
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
 *         configuration information for the specified DAC.
 * @param  Data: 8-bit data to be loaded in the DAC data register (0x00 to 0xFF).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid data or the handle is not initialized)
 */
HAL_StatusTypeDef HAL_DAC_SetValue(DAC_HandleTypeDef *hdac, uint32 Data)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the DAC peripheral handle and instance */
    if (DAC_HandleIsValid(hdac) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_DAC_DATA(Data));

    /* Runtime parameter validation */
    if (IS_DAC_DATA(Data) == 0U)
    {
        hdac->ErrorCode |= HAL_DAC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_DAC_Init() is
     * required first) */
    status = DAC_CheckState(hdac);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (DAC_LockHandle(hdac, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Set the selected DAC channel data holding register */
    WRITE_REG(hdac->Instance->DOUT, (uint8)Data);

    /* Release Lock */
    DAC_UnlockHandle(hdac);

    /* Return function status */
    return HAL_OK;
}

/**
  * @}
  */

/** @defgroup DAC_Exported_Functions_Group4 Peripheral State and Errors functions
  * @{
  */

/**
 * @brief  Return the DAC state. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context.
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
 *         configuration information for the specified DAC.
 * @retval HAL_DAC_StateTypeDef: HAL_DAC_STATE_xxx (HAL_DAC_STATE_RESET for an
 *         invalid handle or instance).
 */
HAL_DAC_StateTypeDef HAL_DAC_GetState(DAC_HandleTypeDef *hdac)
{
    /* Check the DAC peripheral handle and instance */
    if (DAC_HandleIsValid(hdac) == 0U)
    {
        return HAL_DAC_STATE_RESET;
    }

    return hdac->State;
}

/**
 * @brief  Return the DAC error code. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context.
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
 *         configuration information for the specified DAC.
 * @retval uint32: DAC error code (HAL_DAC_ERROR_NONE / HAL_DAC_ERROR_INVALID_PARAM),
 *         0 for an invalid handle or instance.
 */
uint32 HAL_DAC_GetError(DAC_HandleTypeDef *hdac)
{
    /* Check the DAC peripheral handle and instance */
    if (DAC_HandleIsValid(hdac) == 0U)
    {
        return 0U;
    }

    return hdac->ErrorCode;
}

/**
  * @}
  */

/**
  * @}
  */

/* Exported functions ---------------------------------------------------------*/

/** @defgroup DAC_Exported_Functions DAC Exported Functions
  * @{
  */

/** @defgroup DAC_Exported_Functions_Group1 Extended features functions
  * @{
  */

/**
 * @brief  Assert or release the DAC reset (DAC_CTRL.RESETN bit).
 * @note   NewState = 1 releases the reset (DAC running), NewState = 0 asserts
 *         the reset (DAC held in reset). The NewState parameter is validated
 *         at run time as well, so that an out of range value cannot be applied
 *         in a build with the assertions disabled.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_DAC_Init() is required first).
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
 *         configuration information for the specified DAC.
 * @param  NewState: 1 = release the DAC reset, 0 = assert the DAC reset.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_DAC_ResetCmd(DAC_HandleTypeDef *hdac, uint32 NewState)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the DAC peripheral handle and instance */
    if (DAC_HandleIsValid(hdac) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_DAC_NEWSTATE(NewState));

    /* Runtime parameter validation */
    if (IS_DAC_NEWSTATE(NewState) == 0U)
    {
        hdac->ErrorCode |= HAL_DAC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_DAC_Init() is
     * required first) */
    status = DAC_CheckState(hdac);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (DAC_LockHandle(hdac, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    if (NewState != 0U)
    {
        /* Release the DAC reset: the DAC is running */
        __HAL_DAC_RESET_RELEASE(hdac);
    }
    else
    {
        /* Assert the DAC reset: the DAC is held in reset */
        __HAL_DAC_RESET_ASSERT(hdac);
    }

    /* Release Lock */
    DAC_UnlockHandle(hdac);

    /* Return function status */
    return HAL_OK;
}

/**
 * @brief  Initialize the DAC comparator configuration structure with default
 *         values.
 * @param  pCMPConf: pointer to a DAC_CMPConfTypeDef structure that will be
 *         filled with the default configuration (disable, mode DACO,
 *         hysteresis 0 mV).
 * @retval None
 */
void HAL_DAC_CMPStructInit(DAC_CMPConfTypeDef *pCMPConf)
{
    /* Reset comparator configuration structure parameters values */
    /* Check the pCMPConf handle allocation */
    if (pCMPConf == NULL_PTR)
    {
        return;
    }
    pCMPConf->CMP_Enable     = DAC_CMP_DISABLE;
    pCMPConf->CMP_Mode       = DAC_CMP_MD_DACO;
    pCMPConf->CMP_Hysteresis = DAC_CMP_HYS_0;
}

/**
 * @brief  Configure the DAC comparator according to the specified parameters
 *         in the pCMPConf structure (enable, mode, hysteresis).
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_DAC_Init() is required first).
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
 *         configuration information for the specified DAC.
 * @param  pCMPConf: pointer to a DAC_CMPConfTypeDef structure that contains
 *         the configuration information for the comparator.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_DAC_ConfigComparator(DAC_HandleTypeDef *hdac, DAC_CMPConfTypeDef *pCMPConf)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the DAC peripheral handle, the instance and the configuration pointer */
    if ((DAC_HandleIsValid(hdac) == 0U) || (pCMPConf == NULL_PTR))
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_DAC_CMP_EN(pCMPConf->CMP_Enable));
    assert_param(IS_DAC_CMP_MD(pCMPConf->CMP_Mode));
    assert_param(IS_DAC_CMP_HYS(pCMPConf->CMP_Hysteresis));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((IS_DAC_CMP_EN(pCMPConf->CMP_Enable) == 0U) ||
        (IS_DAC_CMP_MD(pCMPConf->CMP_Mode) == 0U) ||
        (IS_DAC_CMP_HYS(pCMPConf->CMP_Hysteresis) == 0U))
    {
        hdac->ErrorCode |= HAL_DAC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_DAC_Init() is
     * required first) */
    status = DAC_CheckState(hdac);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (DAC_LockHandle(hdac, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Change DAC state */
    hdac->State = HAL_DAC_STATE_BUSY;

    /* Set DAC comparator enable (DAC_CMP_CTRL.EN bit) */
    MODIFY_REG(hdac->Instance->CMP_CTRL, DAC_CMP_CTRL_EN,
               ((uint32)pCMPConf->CMP_Enable) << DAC_CMP_CTRL_EN_Pos);

    /* Set DAC comparator mode (DAC_CMP_CTRL.MD bit) */
    MODIFY_REG(hdac->Instance->CMP_CTRL, DAC_CMP_CTRL_MD,
               ((uint32)pCMPConf->CMP_Mode) << DAC_CMP_CTRL_MD_Pos);

    /* Set DAC comparator hysteresis (DAC_CMP_CTRL.HYS field) */
    MODIFY_REG(hdac->Instance->CMP_CTRL, DAC_CMP_CTRL_HYS,
               ((uint32)pCMPConf->CMP_Hysteresis) << DAC_CMP_CTRL_HYS_Pos);

    /* Change DAC state */
    hdac->State = HAL_DAC_STATE_READY;

    /* Release Lock */
    DAC_UnlockHandle(hdac);

    /* Return function status */
    return HAL_OK;
}

/**
 * @brief  Enable or disable the DAC comparator (DAC_CMP_CTRL.EN bit).
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_DAC_Init() is required first).
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
 *         configuration information for the specified DAC.
 * @param  NewState: 1 = enable the comparator, 0 = disable the comparator.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_DAC_ComparatorCmd(DAC_HandleTypeDef *hdac, uint32 NewState)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the DAC peripheral handle and instance */
    if (DAC_HandleIsValid(hdac) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_DAC_NEWSTATE(NewState));

    /* Runtime parameter validation */
    if (IS_DAC_NEWSTATE(NewState) == 0U)
    {
        hdac->ErrorCode |= HAL_DAC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_DAC_Init() is
     * required first) */
    status = DAC_CheckState(hdac);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (DAC_LockHandle(hdac, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    if (NewState != 0U)
    {
        /* Enable the selected DAC comparator */
        SET_BIT(hdac->Instance->CMP_CTRL, DAC_CMP_CTRL_EN);
    }
    else
    {
        /* Disable the selected DAC comparator */
        CLEAR_BIT(hdac->Instance->CMP_CTRL, DAC_CMP_CTRL_EN);
    }

    /* Release Lock */
    DAC_UnlockHandle(hdac);

    /* Return function status */
    return HAL_OK;
}

/**
 * @brief  Return the DAC comparator result value (DAC_CMP_CTRL.CMPO bit). (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context.
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
 *         configuration information for the specified DAC.
 * @retval uint32: 1 if the comparator output is high, 0 otherwise (also 0 for
 *         an invalid handle or instance).
 */
uint32 HAL_DAC_GetComparatorResult(DAC_HandleTypeDef *hdac)
{
    /* Check the DAC peripheral handle and instance */
    if (DAC_HandleIsValid(hdac) == 0U)
    {
        return 0U;
    }

    /* Get and return the DAC comparator result value */
    return (uint32)READ_BIT(hdac->Instance->CMP_CTRL, DAC_CMP_CTRL_CMPO) >> DAC_CMP_CTRL_CMPO_Pos;
}

/**
  * @}
  */

/**
  * @}
  */

#endif /* HAL_DAC_MODULE_ENABLED */

/*****END OF FILE*****/

