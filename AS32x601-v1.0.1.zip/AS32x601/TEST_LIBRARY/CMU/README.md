# CMU 应用与测试参考

供 skill 按需求检索 AS32x601 HAL CMU 示例。关键词：时钟监测、FIRC、PLLQ、PLLR、SIRC、窗口、上下阈值、FHH、FLL、LOSSCLK、MSP、句柄锁。共有 15 个独立用例。

HAL 依据：[头文件](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_cmu.h)、[实现](../../HAL_LIBRARY/peripherals/src/as32x601_hal_cmu.c)。按所选案例核对当前驱动，不以接口索引代替实现依据。


## 实例与相关资源

本模块不单独列出外部通信引脚组。按实际功能核对实例、时钟、中断、内存或数据通路；关联 GPIO、定时器或其他外设时，再读取对应分支的引脚资料。具体资源与案例配置见下文。

## 生成前需确认的参数

已有工程、板级资料或用户已明确的值直接复用。仅对影响本次实现的缺失选择使用参数卡询问并等待答复；案例配置不能代替实际接线或应用参数。

| 参数 | 需要核对或确认的内容 |
|---|---|
| 监测对象 | 实际时钟源、参考时钟和监测通道 |
| 阈值与响应 | 允许频率范围、超时、异常中断及恢复策略 |

## 按需求选择

| 用户需求 / 检索关键词 | 推荐用例 | 选择条件 / 需要补充的逻辑 |
|---|---|---|
| FIRC 正常范围监测 | [001](CMU_IT_DRV_001.c) | 预期 FHH/FLL=0/0，按实际时钟和窗口计算阈值 |
| FIRC 上阈值触发 | [002](CMU_IT_DRV_002.c) | 预期 1/0，通过阈值配置制造条件 |
| FIRC 下阈值触发 | [003](CMU_IT_DRV_003.c) | 预期 0/1，通过阈值配置制造条件 |
| PLLQ 正常范围监测 | [004](CMU_IT_DRV_004.c) | 预期 0/0，先准备被监测时钟 |
| PLLQ 上阈值触发 | [005](CMU_IT_DRV_005.c) | 预期 1/0，按实际窗口重算阈值 |
| PLLQ 下阈值触发 | [006](CMU_IT_DRV_006.c) | 预期 0/1，按实际窗口重算阈值 |
| PLLR 正常范围监测 | [007](CMU_IT_DRV_007.c) | 预期 0/0，核对 PLLR 频率 |
| PLLR 上阈值触发 | [008](CMU_IT_DRV_008.c) | 预期 1/0，按实际窗口重算阈值 |
| PLLR 下阈值触发 | [009](CMU_IT_DRV_009.c) | 预期 0/1，按实际窗口重算阈值 |
| SIRC 正常范围监测 | [010](CMU_IT_DRV_010.c) | 预期 0/0，源码实例为 CMU_OSC |
| SIRC 上阈值触发 | [011](CMU_IT_DRV_011.c) | 预期 1/0，源码实例为 CMU_OSC |
| SIRC 下阈值触发 | [012](CMU_IT_DRV_012.c) | 预期 0/1，源码实例为 CMU_OSC |
| 默认配置、初始化反初始化、状态与错误、监测模式 | [013](CMU_IT_DRV_013.c) | 包括非法参数与空句柄路径 |
| MSP 生命周期、句柄锁、BUSY、模块版本 | [014](CMU_IT_DRV_014.c) | 综合接口检查，非越界检测最小模板 |
| 模式遍历、状态标志、寄存器宏、参数边界 | [015](CMU_IT_DRV_015.c) | 查询标志不等于实际制造全部故障 |
| 时钟故障中断、自动切换备用时钟、系统恢复 | 无直接完整模板 | 轮询阈值示例不能直接代表自动恢复方案 |

## 案例实际配置

数值摘录自源码宏，表示配置和预期，不代表本次实测。

| 用例 | 实例 | 窗口 | 上阈值 | 下阈值 | FHH / FLL |
|---|---|---|---|---|---|
| [001](CMU_IT_DRV_001.c) | (CMU_FIRC) | (20000U) | (19200U) | (12800U) | (0U) / (0U) |
| [002](CMU_IT_DRV_002.c) | (CMU_FIRC) | (20000U) | (13000U) | (12800U) | (1U) / (0U) |
| [003](CMU_IT_DRV_003.c) | (CMU_FIRC) | (20000U) | (19200U) | (19000U) | (0U) / (1U) |
| [004](CMU_IT_DRV_004.c) | (CMU_PLLQ) | (20000U) | (216000U) | (144000U) | (0U) / (0U) |
| [005](CMU_IT_DRV_005.c) | (CMU_PLLQ) | (20000U) | (150000U) | (144000U) | (1U) / (0U) |
| [006](CMU_IT_DRV_006.c) | (CMU_PLLQ) | (20000U) | (216000U) | (210000U) | (0U) / (1U) |
| [007](CMU_IT_DRV_007.c) | (CMU_PLLR) | (20000U) | (54000U) | (36000U) | (0U) / (0U) |
| [008](CMU_IT_DRV_008.c) | (CMU_PLLR) | (20000U) | (37500U) | (36000U) | (1U) / (0U) |
| [009](CMU_IT_DRV_009.c) | (CMU_PLLR) | (20000U) | (216000U) | (210000U) | (0U) / (1U) |
| [010](CMU_IT_DRV_010.c) | (CMU_OSC) | (37U) | (24000U) | (16000U) | (0U) / (0U) |
| [011](CMU_IT_DRV_011.c) | (CMU_OSC) | (37U) | (17000U) | (16000U) | (1U) / (0U) |
| [012](CMU_IT_DRV_012.c) | (CMU_OSC) | (37U) | (24000U) | (23000U) | (0U) / (1U) |

## 实现要点与案例配置

流程：准备时钟源 → 初始化 CMU → 配置计数窗口和上下阈值 → 启动 → 等待稳定 → 轮询并清除标志。保留源码 MSP 中所需门控和复位操作。

001～012 通过阈值配置验证状态，不是实际破坏振荡器。阈值是计数配置，不能直接当作 Hz；迁移时按实际时钟树与窗口重新计算。010～012 源码标题称 SIRC，宏实例为 `CMU_OSC`，需要核对芯片及驱动定义。

核对配置回读、FHH/FLL、清除动作和日志失败计数，不能仅看初始化成功。015 对 WORK、CHCDONE、LOSSCLK 等标志的读取不等于已注入并验证全部实际故障。013～015 是扩展接口用例，最小监测优先参考 001～012。

当前驱动的 `HAL_CMU_Cmd(CMU_ENABLE)` 优先恢复句柄中记录的非零监测模式；没有记录非零模式时才使用 MODE 字段全置位的兼容值。`HAL_CMU_SetMode()` 同时更新记录的模式。不要将旧注释中“使能总是写全 1”泛化为当前接口行为；显式选模式后再启停时，应核对模式保持结果。

## 验证方法与适用边界

每个源码有独立 `main()`。选定后读取完整时钟准备、初始化、MSP 和轮询逻辑，按实际应用修改配置及测试逻辑。

本次为源码静态整理，未重新编译或上板；源码已有测试记录与本次验证状态分别判断。

## 按接口与辅助宏检索

来自去除注释后的源码调用或定义，包含 HAL 接口、锁助手、寄存器及参数校验宏。MSP、IRQ、回调可能是定义或转发入口，应结合完整源码阅读；出现不代表所有分支均已覆盖。

| 接口 / 宏 | 参考用例 |
|---|---|
| `CMU_LockHandle` | [014](CMU_IT_DRV_014.c) |
| `CMU_UnlockHandle` | [014](CMU_IT_DRV_014.c) |
| `HAL_CMU_ClearFlag` | [001](CMU_IT_DRV_001.c)、[002](CMU_IT_DRV_002.c)、[003](CMU_IT_DRV_003.c)、[004](CMU_IT_DRV_004.c)、[005](CMU_IT_DRV_005.c)、[006](CMU_IT_DRV_006.c)、[007](CMU_IT_DRV_007.c)、[008](CMU_IT_DRV_008.c)、[009](CMU_IT_DRV_009.c)、[010](CMU_IT_DRV_010.c)、[011](CMU_IT_DRV_011.c)、[012](CMU_IT_DRV_012.c)、[013](CMU_IT_DRV_013.c)、[015](CMU_IT_DRV_015.c) |
| `HAL_CMU_Cmd` | [001](CMU_IT_DRV_001.c)、[002](CMU_IT_DRV_002.c)、[003](CMU_IT_DRV_003.c)、[004](CMU_IT_DRV_004.c)、[005](CMU_IT_DRV_005.c)、[006](CMU_IT_DRV_006.c)、[007](CMU_IT_DRV_007.c)、[008](CMU_IT_DRV_008.c)、[009](CMU_IT_DRV_009.c)、[010](CMU_IT_DRV_010.c)、[011](CMU_IT_DRV_011.c)、[012](CMU_IT_DRV_012.c)、[013](CMU_IT_DRV_013.c)、[014](CMU_IT_DRV_014.c) |
| `HAL_CMU_DeInit` | [013](CMU_IT_DRV_013.c)、[014](CMU_IT_DRV_014.c) |
| `HAL_CMU_GetError` | [001](CMU_IT_DRV_001.c)、[002](CMU_IT_DRV_002.c)、[003](CMU_IT_DRV_003.c)、[004](CMU_IT_DRV_004.c)、[005](CMU_IT_DRV_005.c)、[006](CMU_IT_DRV_006.c)、[007](CMU_IT_DRV_007.c)、[008](CMU_IT_DRV_008.c)、[009](CMU_IT_DRV_009.c)、[010](CMU_IT_DRV_010.c)、[011](CMU_IT_DRV_011.c)、[012](CMU_IT_DRV_012.c)、[013](CMU_IT_DRV_013.c)、[015](CMU_IT_DRV_015.c) |
| `HAL_CMU_GetFlagStatus` | [001](CMU_IT_DRV_001.c)、[002](CMU_IT_DRV_002.c)、[003](CMU_IT_DRV_003.c)、[004](CMU_IT_DRV_004.c)、[005](CMU_IT_DRV_005.c)、[006](CMU_IT_DRV_006.c)、[007](CMU_IT_DRV_007.c)、[008](CMU_IT_DRV_008.c)、[009](CMU_IT_DRV_009.c)、[010](CMU_IT_DRV_010.c)、[011](CMU_IT_DRV_011.c)、[012](CMU_IT_DRV_012.c)、[013](CMU_IT_DRV_013.c)、[015](CMU_IT_DRV_015.c) |
| `HAL_CMU_GetState` | [001](CMU_IT_DRV_001.c)、[002](CMU_IT_DRV_002.c)、[003](CMU_IT_DRV_003.c)、[004](CMU_IT_DRV_004.c)、[005](CMU_IT_DRV_005.c)、[006](CMU_IT_DRV_006.c)、[007](CMU_IT_DRV_007.c)、[008](CMU_IT_DRV_008.c)、[009](CMU_IT_DRV_009.c)、[010](CMU_IT_DRV_010.c)、[011](CMU_IT_DRV_011.c)、[012](CMU_IT_DRV_012.c)、[013](CMU_IT_DRV_013.c)、[014](CMU_IT_DRV_014.c)、[015](CMU_IT_DRV_015.c) |
| `HAL_CMU_Init` | [001](CMU_IT_DRV_001.c)、[002](CMU_IT_DRV_002.c)、[003](CMU_IT_DRV_003.c)、[004](CMU_IT_DRV_004.c)、[005](CMU_IT_DRV_005.c)、[006](CMU_IT_DRV_006.c)、[007](CMU_IT_DRV_007.c)、[008](CMU_IT_DRV_008.c)、[009](CMU_IT_DRV_009.c)、[010](CMU_IT_DRV_010.c)、[011](CMU_IT_DRV_011.c)、[012](CMU_IT_DRV_012.c)、[013](CMU_IT_DRV_013.c)、[014](CMU_IT_DRV_014.c)、[015](CMU_IT_DRV_015.c) |
| `HAL_CMU_MspDeInit` | [014](CMU_IT_DRV_014.c) |
| `HAL_CMU_MspInit` | [001](CMU_IT_DRV_001.c)、[002](CMU_IT_DRV_002.c)、[003](CMU_IT_DRV_003.c)、[004](CMU_IT_DRV_004.c)、[005](CMU_IT_DRV_005.c)、[006](CMU_IT_DRV_006.c)、[007](CMU_IT_DRV_007.c)、[008](CMU_IT_DRV_008.c)、[009](CMU_IT_DRV_009.c)、[010](CMU_IT_DRV_010.c)、[011](CMU_IT_DRV_011.c)、[012](CMU_IT_DRV_012.c)、[013](CMU_IT_DRV_013.c)、[014](CMU_IT_DRV_014.c)、[015](CMU_IT_DRV_015.c) |
| `HAL_CMU_SetMode` | [013](CMU_IT_DRV_013.c)、[014](CMU_IT_DRV_014.c)、[015](CMU_IT_DRV_015.c) |
| `HAL_CMU_SetReferenceThreshold` | [001](CMU_IT_DRV_001.c)、[002](CMU_IT_DRV_002.c)、[003](CMU_IT_DRV_003.c)、[004](CMU_IT_DRV_004.c)、[005](CMU_IT_DRV_005.c)、[006](CMU_IT_DRV_006.c)、[007](CMU_IT_DRV_007.c)、[008](CMU_IT_DRV_008.c)、[009](CMU_IT_DRV_009.c)、[010](CMU_IT_DRV_010.c)、[011](CMU_IT_DRV_011.c)、[012](CMU_IT_DRV_012.c)、[013](CMU_IT_DRV_013.c)、[015](CMU_IT_DRV_015.c) |
| `HAL_CMU_SetWindowLength` | [001](CMU_IT_DRV_001.c)、[002](CMU_IT_DRV_002.c)、[003](CMU_IT_DRV_003.c)、[004](CMU_IT_DRV_004.c)、[005](CMU_IT_DRV_005.c)、[006](CMU_IT_DRV_006.c)、[007](CMU_IT_DRV_007.c)、[008](CMU_IT_DRV_008.c)、[009](CMU_IT_DRV_009.c)、[010](CMU_IT_DRV_010.c)、[011](CMU_IT_DRV_011.c)、[012](CMU_IT_DRV_012.c)、[013](CMU_IT_DRV_013.c)、[015](CMU_IT_DRV_015.c) |
| `HAL_CMU_StructInit` | [001](CMU_IT_DRV_001.c)、[002](CMU_IT_DRV_002.c)、[003](CMU_IT_DRV_003.c)、[004](CMU_IT_DRV_004.c)、[005](CMU_IT_DRV_005.c)、[006](CMU_IT_DRV_006.c)、[007](CMU_IT_DRV_007.c)、[008](CMU_IT_DRV_008.c)、[009](CMU_IT_DRV_009.c)、[010](CMU_IT_DRV_010.c)、[011](CMU_IT_DRV_011.c)、[012](CMU_IT_DRV_012.c)、[013](CMU_IT_DRV_013.c)、[014](CMU_IT_DRV_014.c)、[015](CMU_IT_DRV_015.c) |
| `IS_CMU_ALL_INSTANCE` | [015](CMU_IT_DRV_015.c) |
| `IS_CMU_CLEAR` | [015](CMU_IT_DRV_015.c) |
| `IS_CMU_ENABLE_STATE` | [015](CMU_IT_DRV_015.c) |
| `IS_CMU_FLAG` | [015](CMU_IT_DRV_015.c) |
| `IS_CMU_MODE` | [015](CMU_IT_DRV_015.c) |
| `IS_CMU_THRESHOLD` | [015](CMU_IT_DRV_015.c) |
| `IS_CMU_WINDOW_LENGTH` | [015](CMU_IT_DRV_015.c) |
| `__HAL_CMU_CLEAR_FLAG` | [015](CMU_IT_DRV_015.c) |
| `__HAL_CMU_DISABLE` | [015](CMU_IT_DRV_015.c) |
| `__HAL_CMU_ENABLE` | [015](CMU_IT_DRV_015.c) |
| `__HAL_CMU_GET_FLAG` | [015](CMU_IT_DRV_015.c) |
| `__HAL_CMU_RESET_HANDLE_STATE` | [014](CMU_IT_DRV_014.c) |

