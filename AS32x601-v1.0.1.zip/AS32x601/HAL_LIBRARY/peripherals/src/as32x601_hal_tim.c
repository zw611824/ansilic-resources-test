/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_tim.c
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.9
 * Date:             2026/11/05
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.1     add the DMA mode of the
 *                                                       output compare and PWM
 *                                                       interfaces
 *                                                       (HAL_TIM_OC_Start_DMA /
 *                                                       HAL_TIM_OC_Stop_DMA /
 *                                                       HAL_TIM_PWM_Start_DMA /
 *                                                       HAL_TIM_PWM_Stop_DMA):
 *                                                       the DMA burst (DCR.DBA /
 *                                                       DBL) targets the channel
 *                                                       CCR register through
 *                                                       DMAR, the capture/compare
 *                                                       DMA request (DIER.*DE) is
 *                                                       enabled and the transfer
 *                                                       is started with
 *                                                       HAL_DMA_Start_IT(); the
 *                                                       DMA modes are compiled
 *                                                       only while the DMA module
 *                                                       is enabled
 *     ANSILIC APPLICATION GROUP  2026/09/21     1.2     align the resource lock and the RTOS support with the
 *                                                       architecture specification (section 13 LOCK-01..06 and
 *                                                       section 21 RTOS-04/11): the MSP callbacks run outside
 *                                                       the locked region (LOCK-06) and the MSP init runs only
 *                                                       on the first initialization (MSP-04), the handle lock
 *                                                       takes a Timeout and guards a NULL mutex (RTOS-11),
 *                                                       every lock failure return is documented as a path
 *                                                       where the lock is not held (LOCK-02), a state gate
 *                                                       rejects the calls made on a non initialized handle
 *                                                       (ARCH-CONST-09) while BUSY stays accepted because it
 *                                                       means that the counter is running, the handle and the
 *                                                       instance are checked through one shared helper, the
 *                                                       configuration structure is validated at run time in
 *                                                       the six initialization functions, and the header now
 *                                                       carries the API documentation and the blocking marker
 *                                                       of every prototype
 *     ANSILIC APPLICATION GROUP  2026/10/26     1.3     capture/compare register bit encoding and the de-initialization of the
 *                                                       instance: the update, trigger, break and capture/compare interrupt, flag
 *                                                       and event source constants now match the high half layout of DIER / SR /
 *                                                       EGR, HAL_TIM_IRQHandler serves channels 1..6 of the advanced timers through
 *                                                       one loop and resets the callback channel to TIM_CHANNEL_NONE, the six
 *                                                       de-initialization functions stop the counter and silence every source the
 *                                                       module can have enabled, the six initialization functions refuse a handle
 *                                                       whose counter is running, HAL_TIM_OC_ConfigChannel programs the OCPreload
 *                                                       field, HAL_TIM_ConfigClockSource and HAL_TIM_SlaveConfigSynchronization
 *                                                       refuse the unavailable ITR2 / ITR3 triggers, the break filter is written to
 *                                                       BDTR.BKF, the encoder prescaler no longer double shifts the ICPSC value,
 *                                                       the bare-metal lock uses an interrupt critical section and the ten
 *                                                       configuration structure default helpers are implemented
 *     ANSILIC APPLICATION GROUP  2026/11/05     1.9     expose the capture/compare DMA source selection (CR2.CCDS) as
 *                                                       HAL_TIM_SelectCCDMA(): on this device the capture/compare DMA request
 *                                                       of a channel only reaches the DMA controller while the bit is set, so
 *                                                       a transfer started with HAL_TIM_OC_Start_DMA() or
 *                                                       HAL_TIM_PWM_Start_DMA() stays idle on an otherwise correct
 *                                                       configuration (the timer sets DIER.*DE and SR.CCxIF as usual but no
 *                                                       request is issued). The driver does not set the bit on its own, so a
 *                                                       request driven by the update event keeps working; the new interface
 *                                                       takes the handle and the selection, validates the selection at run
 *                                                       time, applies the state gate and serializes the register access
 *                                                       through the handle lock, and the documentation of the two DMA start
 *                                                       functions names the bit as a prerequisite
 *     ANSILIC APPLICATION GROUP  2026/11/04     1.8     program the output idle state of every channel correctly: CR2 carries one
 *                                                       OISx and one OISxN bit per channel with a two bit stepping (OIS1 = bit8 ...
 *                                                       OIS6N = bit19), but TIM_OC2 / OC3 / OC4_SetConfig() masked the value without
 *                                                       shifting it, so the mask cancelled it and the bit was never set, and channels
 *                                                       4, 5 and 6 never wrote the complementary idle bit at all; with BDTR.OSSR (or
 *                                                       OSSI) set those bits define the level the pin takes while the main output is
 *                                                       disabled, so the twelve outputs settled in a mixture of levels instead of all
 *                                                       following OCIdleState / OCNIdleState
 *     ANSILIC APPLICATION GROUP  2026/11/04     1.7     clear the main output unconditionally when it is disabled: the
 *                                                       HAL_TIM_CtrlPWMOutputs() DISABLE path used the conditional macro, which only
 *                                                       clears BDTR.MOE while every CCxE / CCxNE bit of CCER is already cleared, so
 *                                                       the call did nothing at all while the channel outputs were enabled and the
 *                                                       main output could not be switched off; the new
 *                                                        __HAL_TIM_MOE_DISABLE_UNCONDITIONALLY() macro (same name and semantics as
 *                                                       the reference timer API) is used there instead, while the Stop functions keep
 *                                                       the conditional variant because they clear their own channel first
 *     ANSILIC APPLICATION GROUP  2026/11/04     1.6     accept the complementary outputs of channels 4, 5 and 6: the device drives
 *                                                       CC4NE / CC5NE / CC6NE (CCER bits 14, 18 and 22) and routes them to PC4,
 *                                                       PC5 and PB0 in the HTIM0 M1 option (PD12, PD13 and PD14 in M2), so
 *                                                       IS_TIM_COMPLEMENTARY_CHANNELS() now accepts TIM_CHANNEL_1..6 on the
 *                                                       advanced timers and the eight complementary start / stop functions (OCN
 *                                                       and PWMN, polling and interrupt modes) cover the six channels;
 *                                                       TIM_OC4 / OC5 / OC6_SetConfig() now also program the complementary enable
 *                                                       and polarity bits of their channel, which they previously left untouched;
 *                                                       before this version a call with channel 4, 5 or 6 was refused with
 *                                                       HAL_ERROR before any register was written, which left those complementary
 *                                                       outputs permanently disabled
 *     ANSILIC APPLICATION GROUP  2026/11/02     1.5     expose the second master output trigger (TRGO2,
 *                                                       CR2.MMS2) of the advanced timers: the master
 *                                                       configuration structure gains the
 *                                                       MasterOutputTrigger2 field (appended, so the
 *                                                       two existing fields keep their offsets), the
 *                                                       sixteen TIM_TRGO2_xxx sources and the
 *                                                       IS_TIM_TRGO2_SOURCE() validation macro are
 *                                                       added, HAL_TIM_MasterConfigSynchronization()
 *                                                       now programs CR2.MMS and CR2.MMS2 in one locked
 *                                                       access (a real TRGO2 source on a general purpose
 *                                                       timer is refused with
 *                                                       HAL_TIM_ERROR_INVALID_PARAM without touching the
 *                                                       register) and the new
 *                                                       HAL_TIM_SetMasterOutputTrigger2() changes TRGO2
 *                                                       alone; HAL_TIM_MasterConfig_StructInit() fills
 *                                                       the neutral TIM_TRGO2_RESET
 *     ANSILIC APPLICATION GROUP  2026/10/27     1.4     extend the capture/compare channel support of the advanced timers to
 *                                                       channels 5 and 6 and add the four bit output compare modes: the channel
 *                                                       configuration functions dispatch to the new CCMR3 based helpers
 *                                                       (TIM_OC5/OC6_SetConfig and TIM_TI5/TI6_SetConfig), the interrupt start
 *                                                       and stop functions enable / disable CC5IE and CC6IE, the captured value
 *                                                       read back covers CCR5 and CCR6, the preload and fast mode bits of the
 *                                                       two extra channels are written in CCMR3, the preload selection helper
 *                                                       of the output compare configuration reaches CCMR3 and a channel 5/6
 *                                                       request on a general purpose instance is rejected with the invalid
 *                                                       parameter error code instead of silently reconfiguring channel 4
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the timer (TIM) of the
 *                  AS32x601:
 *                  - Time base, output compare, PWM, input capture, one
 *                    pulse and encoder initialization / de-initialization;
 *                  - Start / stop operations (polling, interrupt and DMA
 *                    modes);
 *                  - Channel configuration (OC / PWM / IC / one pulse);
 *                  - Interrupt service routine dispatch;
 *                  - State and error reporting.
 *
 *                  This driver provides the
 *                  complementary output / PWM and the break / dead-time
 *                  features of the advanced timers.
 */
#include "as32x601_hal.h"          /* HAL_GetTick() / HAL_MAX_DELAY            */
#include "as32x601_hal_tim.h"      /* TIM HAL API and register macros          */

/* The DMA transfer functions are compiled only while the DMA module is
 * enabled: the DMA_HandleTypeDef type and the HAL_DMA_* API are provided by
 * as32x601_hal_dma.h. When the DMA module is disabled the _Start_DMA /
 * _Stop_DMA functions return HAL_ERROR at runtime. */
#ifdef HAL_DMA_MODULE_ENABLED
#include "as32x601_hal_dma.h"      /* DMA_HandleTypeDef, HAL_DMA_* APIs        */
#endif

/* The HAL_TIM_MODULE_ENABLED switch is provided by the user configuration
 * file (as32x601_hal_conf.h, included above through as32x601_hal.h): the
 * whole implementation is compiled only while the module is enabled. */
#ifdef HAL_TIM_MODULE_ENABLED

/* Private define ------------------------------------------------------------*/

/* Prescaler / auto-reload register width of the general timers (16 bits) */
#define TIM_GEN_REG_MASK            ((uint32)0x0000FFFFU)

/* Private function prototypes -----------------------------------------------*/
static void TIM_Base_SetConfig(HAL_TIM_HandleTypeDef *htim);
static void TIM_OC1_SetConfig(HAL_TIM_HandleTypeDef *htim, TIM_OC_InitTypeDef *sConfig);
static void TIM_OC2_SetConfig(HAL_TIM_HandleTypeDef *htim, TIM_OC_InitTypeDef *sConfig);
static void TIM_OC3_SetConfig(HAL_TIM_HandleTypeDef *htim, TIM_OC_InitTypeDef *sConfig);
static void TIM_OC4_SetConfig(HAL_TIM_HandleTypeDef *htim, TIM_OC_InitTypeDef *sConfig);
static void TIM_OC5_SetConfig(HAL_TIM_HandleTypeDef *htim, TIM_OC_InitTypeDef *sConfig);
static void TIM_OC6_SetConfig(HAL_TIM_HandleTypeDef *htim, TIM_OC_InitTypeDef *sConfig);
static void TIM_TI1_SetConfig(HAL_TIM_HandleTypeDef *htim, uint32 ICPolarity, uint32 ICSelection, uint32 ICFilter);
static void TIM_TI2_SetConfig(HAL_TIM_HandleTypeDef *htim, uint32 ICPolarity, uint32 ICSelection, uint32 ICFilter);
static void TIM_TI3_SetConfig(HAL_TIM_HandleTypeDef *htim, uint32 ICPolarity, uint32 ICSelection, uint32 ICFilter);
static void TIM_TI4_SetConfig(HAL_TIM_HandleTypeDef *htim, uint32 ICPolarity, uint32 ICSelection, uint32 ICFilter);
static void TIM_TI5_SetConfig(HAL_TIM_HandleTypeDef *htim, uint32 ICPolarity, uint32 ICSelection, uint32 ICFilter);
static void TIM_TI6_SetConfig(HAL_TIM_HandleTypeDef *htim, uint32 ICPolarity, uint32 ICSelection, uint32 ICFilter);
static uint32 TIM_CCxSelection(HAL_TIM_HandleTypeDef *htim, uint32 Index);
static void TIM_StopInstance(HAL_TIM_HandleTypeDef *htim);
static void TIM_CCxChannelCmd(HAL_TIM_HandleTypeDef *htim, uint32 Channel, uint32 ChannelState);
#ifdef HAL_DMA_MODULE_ENABLED
static uint32 TIM_DMA_GetDMABase(uint32 Channel);
static uint32 TIM_DMA_GetDMARequest(uint32 Channel);
static uint32 TIM_DMA_GetDMAIndex(uint32 Channel);
static void TIM_DMAOC_DelayPulseCplt(DMA_HandleTypeDef *hdma);
static void TIM_DMAPWM_PulseFinishedCplt(DMA_HandleTypeDef *hdma);
static void TIM_DMAErrorCplt(DMA_HandleTypeDef *hdma);
#endif

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Check whether the TIM handle and its instance are valid.
 * @note   Every public entry point of the module performs its handle check
 *         through it, so the NULL pointer and the instance validity are
 *         verified in one place.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
uint32 TIM_HandleIsValid(HAL_TIM_HandleTypeDef *htim)
{
    if (htim == NULL_PTR)
    {
        return 0U;
    }

    if (IS_TIM_ALL_INSTANCE(htim->Instance) == 0U)
    {
        return 0U;
    }

    return 1U;
}

/**
 * @brief  Check whether the handle has been initialized, so that a register
 *         accessing operation may run.
 * @note   ARCH-CONST-09: a handle that is not initialized (RESET) requires one
 *         of the initialization functions first and is rejected with
 *         HAL_ERROR.
 * @note   The BUSY state is accepted on purpose. In this module BUSY means that
 *         the counter is running (the Start functions leave it set) and not
 *         that an operation is ongoing, so the Stop, the compare update and the
 *         configuration calls have to stay usable while the timer runs. The
 *         transient BUSY windows of the initialization and the
 *         de-initialization are protected by the handle lock. The TIMEOUT and
 *         ERROR states are recoverable and accepted as well.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK (accepted) / HAL_ERROR (not initialized).
 */
HAL_StatusTypeDef TIM_CheckInitState(HAL_TIM_HandleTypeDef *htim)
{
    if (htim->State == HAL_TIM_STATE_RESET)
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_TIM_Base_MspInit()). The bare-metal branch uses the Lock flag.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY
 */
HAL_StatusTypeDef TIM_LockHandle(HAL_TIM_HandleTypeDef *htim, uint32 Timeout)
{
#if (USE_RTOS == 1)
    if (htim->LockMutex == NULL_PTR)
    {
        /* The porting layer did not create the mutex: report it instead of
         * calling the RTOS with a NULL handle */
        return HAL_ERROR;
    }

    return HAL_MutexAcquire(htim->LockMutex, Timeout);
#else
    uint32 state = 0U;

    /* Prevent unused argument compilation warning: the bare-metal lock flag
     * either succeeds immediately or reports HAL_BUSY, it never waits */
    UNUSED(Timeout);

    /* The test and the set of the lock flag form a single critical section:
     * with the interrupts left enabled another context could observe the
     * handle unlocked between the test and the assignment and enter the same
     * register sequence (architecture rule LOCK-01). */
    state = __disable_irq_and_save();
    if (htim->Lock == HAL_LOCKED)
    {
        __restore_irq(state);
        return HAL_BUSY;
    }
    htim->Lock = HAL_LOCKED;
    __restore_irq(state);
    return HAL_OK;
#endif /* USE_RTOS */
}

/**
 * @brief  Unlock the handle.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @retval None
 */
void TIM_UnlockHandle(HAL_TIM_HandleTypeDef *htim)
{
#if (USE_RTOS == 1)
    (void)HAL_MutexRelease(htim->LockMutex);
#else
    uint32 state = __disable_irq_and_save();

    htim->Lock = HAL_UNLOCKED;
    __restore_irq(state);
#endif /* USE_RTOS */
}

/**
 * @brief  Configures the time base unit (counter mode, clock division,
 *         prescaler, auto-reload, repetition counter).
 * @note   The writing order follows the HAL sequence: CR1, then ARR,
 *         then PSC, then RCR (advanced), terminated by an update event
 *         (EGR.UG) that reloads the prescaler immediately.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @retval None
 */
static void TIM_Base_SetConfig(HAL_TIM_HandleTypeDef *htim)
{
    uint32 reg = 0U;

    /* Select the counter mode and the clock division in CR1 */
    reg = htim->Instance->CR1;
    reg &= ~(uint32)(TIM_CR1_CMS | TIM_CR1_DIR | TIM_CR1_CKD);
    reg |= (uint32)(htim->Init.CounterMode | htim->Init.ClockDivision);
    htim->Instance->CR1 = reg;

    /* Set the auto-reload value (16-bit on the general timers) */
    if (IS_TIM_GEN_INSTANCE(htim->Instance))
    {
        htim->Instance->ARR = (uint32)(htim->Init.Period & TIM_GEN_REG_MASK);
    }
    else
    {
        htim->Instance->ARR = htim->Init.Period;
    }

    /* Set the prescaler value (16-bit on the general timers) */
    if (IS_TIM_GEN_INSTANCE(htim->Instance))
    {
        htim->Instance->PSC = (uint32)(htim->Init.Prescaler & TIM_GEN_REG_MASK);
    }
    else
    {
        htim->Instance->PSC = htim->Init.Prescaler;
    }

    /* Set the repetition counter (advanced timers only) */
    if (IS_TIM_ADV_INSTANCE(htim->Instance))
    {
        htim->Instance->RCR = htim->Init.RepetitionCounter;
    }

    /* Generate an update event to reload the prescaler immediately */
    htim->Instance->EGR = TIM_EGR_UG;
}

/**
 * @brief  Configure the capture/compare channel 1 in output compare mode.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  sConfig: pointer to the TIM_OC_InitTypeDef structure.
 * @retval None
 */
static void TIM_OC1_SetConfig(HAL_TIM_HandleTypeDef *htim, TIM_OC_InitTypeDef *sConfig)
{
    uint32 ccmr = 0U;
    uint32 ccer = 0U;
    uint32 cr2 = 0U;

    /* Disable the channel 1 output */
    htim->Instance->CCER &= ~(uint32)TIM_CCER_CC1E;

    ccmr = htim->Instance->CCMR1;
    ccer = htim->Instance->CCER;
    cr2 = htim->Instance->CR2;

    /* Output compare 1 mode */
    ccmr &= ~((uint32)TIM_CCMR1_OC1M | TIM_CCMR1_CC1S);
    ccmr |= sConfig->OCMode;

    /* Output 1 polarity */
    ccer &= ~(uint32)TIM_CCER_CC1P;
    ccer |= (sConfig->OCPolarity & (uint32)TIM_CCER_CC1P);

    /* Complementary output: only on the advanced timers */
    if (IS_TIM_ADV_INSTANCE(htim->Instance))
    {
        ccer &= ~(uint32)(TIM_CCER_CC1NE | TIM_CCER_CC1NP);
        ccer |= (sConfig->OCNPolarity & (uint32)TIM_CCER_CC1NP);

        /* Output idle state (CR2 OIS1 / OIS1N) */
        cr2 &= ~(uint32)(TIM_CR2_OIS1 | TIM_CR2_OIS1N);
        cr2 |= (sConfig->OCIdleState & (uint32)TIM_CR2_OIS1);
        cr2 |= (sConfig->OCNIdleState & (uint32)TIM_CR2_OIS1N);
    }

    /* Write back: CR2, CCMR1, CCR1 and finally CCER (the output is
       enabled separately with HAL_TIM_OC_Start) */
    htim->Instance->CR2 = cr2;
    htim->Instance->CCMR1 = ccmr;
    htim->Instance->CCR1 = sConfig->Pulse;
    htim->Instance->CCER = ccer;
}

/**
 * @brief  Configure the capture/compare channel 2 in output compare mode.
 */
static void TIM_OC2_SetConfig(HAL_TIM_HandleTypeDef *htim, TIM_OC_InitTypeDef *sConfig)
{
    uint32 ccmr = 0U;
    uint32 ccer = 0U;
    uint32 cr2 = 0U;

    htim->Instance->CCER &= ~(uint32)TIM_CCER_CC2E;

    ccmr = htim->Instance->CCMR1;
    ccer = htim->Instance->CCER;
    cr2 = htim->Instance->CR2;

    /* Output compare 2 mode (field shifted by 8 bits) */
    ccmr &= ~((uint32)TIM_CCMR1_OC2M | TIM_CCMR1_CC2S);
    ccmr |= (sConfig->OCMode << 8U);

    ccer &= ~(uint32)TIM_CCER_CC2P;
    ccer |= ((sConfig->OCPolarity << 4U) & (uint32)TIM_CCER_CC2P);

    if (IS_TIM_ADV_INSTANCE(htim->Instance))
    {
        ccer &= ~(uint32)(TIM_CCER_CC2NE | TIM_CCER_CC2NP);
        ccer |= ((sConfig->OCNPolarity << 4U) & (uint32)TIM_CCER_CC2NP);

        cr2 &= ~(uint32)(TIM_CR2_OIS2 | TIM_CR2_OIS2N);
        cr2 |= ((sConfig->OCIdleState << 2U) & (uint32)TIM_CR2_OIS2);
        cr2 |= ((sConfig->OCNIdleState << 2U) & (uint32)TIM_CR2_OIS2N);
    }

    htim->Instance->CR2 = cr2;
    htim->Instance->CCMR1 = ccmr;
    htim->Instance->CCR2 = sConfig->Pulse;
    htim->Instance->CCER = ccer;
}

/**
 * @brief  Configure the capture/compare channel 3 in output compare mode.
 */
static void TIM_OC3_SetConfig(HAL_TIM_HandleTypeDef *htim, TIM_OC_InitTypeDef *sConfig)
{
    uint32 ccmr = 0U;
    uint32 ccer = 0U;
    uint32 cr2 = 0U;

    htim->Instance->CCER &= ~(uint32)TIM_CCER_CC3E;

    ccmr = htim->Instance->CCMR2;
    ccer = htim->Instance->CCER;
    cr2 = htim->Instance->CR2;

    ccmr &= ~((uint32)TIM_CCMR2_OC3M | TIM_CCMR2_CC3S);
    ccmr |= sConfig->OCMode;

    ccer &= ~(uint32)TIM_CCER_CC3P;
    ccer |= ((sConfig->OCPolarity << 8U) & (uint32)TIM_CCER_CC3P);

    if (IS_TIM_ADV_INSTANCE(htim->Instance))
    {
        ccer &= ~(uint32)(TIM_CCER_CC3NE | TIM_CCER_CC3NP);
        ccer |= ((sConfig->OCNPolarity << 8U) & (uint32)TIM_CCER_CC3NP);

        cr2 &= ~(uint32)(TIM_CR2_OIS3 | TIM_CR2_OIS3N);
        cr2 |= ((sConfig->OCIdleState << 4U) & (uint32)TIM_CR2_OIS3);
        cr2 |= ((sConfig->OCNIdleState << 4U) & (uint32)TIM_CR2_OIS3N);
    }

    htim->Instance->CR2 = cr2;
    htim->Instance->CCMR2 = ccmr;
    htim->Instance->CCR3 = sConfig->Pulse;
    htim->Instance->CCER = ccer;
}

/**
 * @brief  Configure the capture/compare channel 4 in output compare mode.
 */
static void TIM_OC4_SetConfig(HAL_TIM_HandleTypeDef *htim, TIM_OC_InitTypeDef *sConfig)
{
    uint32 ccmr = 0U;
    uint32 ccer = 0U;
    uint32 cr2 = 0U;

    htim->Instance->CCER &= ~(uint32)TIM_CCER_CC4E;

    ccmr = htim->Instance->CCMR2;
    ccer = htim->Instance->CCER;
    cr2 = htim->Instance->CR2;

    ccmr &= ~((uint32)TIM_CCMR2_OC4M | TIM_CCMR2_CC4S);
    ccmr |= (sConfig->OCMode << 8U);

    ccer &= ~(uint32)TIM_CCER_CC4P;
    ccer |= ((sConfig->OCPolarity << 12U) & (uint32)TIM_CCER_CC4P);

    if (IS_TIM_ADV_INSTANCE(htim->Instance))
    {
        cr2 &= ~(uint32)(TIM_CR2_OIS4 | TIM_CR2_OIS4N);
        cr2 |= ((sConfig->OCIdleState << 6U) & (uint32)TIM_CR2_OIS4);
        cr2 |= ((sConfig->OCNIdleState << 6U) & (uint32)TIM_CR2_OIS4N);

        /* Complementary output 4: the enable bit is cleared here and set
           again by the complementary start functions; the polarity follows
           the same 4 bit channel stepping as the other channels */
        ccer &= ~(uint32)(TIM_CCER_CC4NE | TIM_CCER_CC4NP);
        ccer |= ((sConfig->OCNPolarity << 12U) & (uint32)TIM_CCER_CC4NP);
    }

    htim->Instance->CR2 = cr2;
    htim->Instance->CCMR2 = ccmr;
    htim->Instance->CCR4 = sConfig->Pulse;
    htim->Instance->CCER = ccer;
}
/**
 * @brief  Configure the capture/compare channel 5 in output compare mode.
 * @note   Channels 5 and 6 only exist on the advanced timers; their control
 *         bits live in CCMR3, whose low half carries channel 5 and whose high
 *         half carries channel 6 (same 8 bit layout as CCMR1/CCMR2).
 */
static void TIM_OC5_SetConfig(HAL_TIM_HandleTypeDef *htim, TIM_OC_InitTypeDef *sConfig)
{
    uint32 ccmr = 0U;
    uint32 ccer = 0U;
    uint32 cr2 = 0U;

    htim->Instance->CCER &= ~(uint32)TIM_CCER_CC5E;

    ccmr = htim->Instance->CCMR3;
    ccer = htim->Instance->CCER;
    cr2 = htim->Instance->CR2;

    /* Output compare 5 mode and channel direction */
    ccmr &= ~((uint32)TIM_CCMR3_OC5M | TIM_CCMR3_CC5S);
    ccmr |= sConfig->OCMode;

    /* Output 5 polarity (CCER.CC5P is 16 bits above CC1P) */
    ccer &= ~(uint32)TIM_CCER_CC5P;
    ccer |= ((sConfig->OCPolarity << 16U) & (uint32)TIM_CCER_CC5P);

    /* Output idle state (CR2.OIS5 / OIS5N are 8 bits above OIS1 / OIS1N) */
    cr2 &= ~(uint32)(TIM_CR2_OIS5 | TIM_CR2_OIS5N);
    cr2 |= ((sConfig->OCIdleState << 8U) & (uint32)TIM_CR2_OIS5);
    cr2 |= ((sConfig->OCNIdleState << 8U) & (uint32)TIM_CR2_OIS5N);


    /* Complementary output 5 (same 4 bit stepping as the other channels) */
    ccer &= ~(uint32)(TIM_CCER_CC5NE | TIM_CCER_CC5NP);
    ccer |= ((sConfig->OCNPolarity << 16U) & (uint32)TIM_CCER_CC5NP);
    htim->Instance->CR2 = cr2;
    htim->Instance->CCMR3 = ccmr;
    htim->Instance->CCR5 = sConfig->Pulse;
    htim->Instance->CCER = ccer;
}

/**
 * @brief  Configure the capture/compare channel 6 in output compare mode.
 */
static void TIM_OC6_SetConfig(HAL_TIM_HandleTypeDef *htim, TIM_OC_InitTypeDef *sConfig)
{
    uint32 ccmr = 0U;
    uint32 ccer = 0U;
    uint32 cr2 = 0U;

    htim->Instance->CCER &= ~(uint32)TIM_CCER_CC6E;

    ccmr = htim->Instance->CCMR3;
    ccer = htim->Instance->CCER;
    cr2 = htim->Instance->CR2;

    /* Output compare 6 mode and channel direction (high half of CCMR3) */
    ccmr &= ~((uint32)TIM_CCMR3_OC6M | TIM_CCMR3_CC6S);
    ccmr |= (sConfig->OCMode << 8U);

    ccer &= ~(uint32)TIM_CCER_CC6P;
    ccer |= ((sConfig->OCPolarity << 20U) & (uint32)TIM_CCER_CC6P);

    cr2 &= ~(uint32)(TIM_CR2_OIS6 | TIM_CR2_OIS6N);
    cr2 |= ((sConfig->OCIdleState << 10U) & (uint32)TIM_CR2_OIS6);
    cr2 |= ((sConfig->OCNIdleState << 10U) & (uint32)TIM_CR2_OIS6N);


    /* Complementary output 6 (same 4 bit stepping as the other channels) */
    ccer &= ~(uint32)(TIM_CCER_CC6NE | TIM_CCER_CC6NP);
    ccer |= ((sConfig->OCNPolarity << 20U) & (uint32)TIM_CCER_CC6NP);
    htim->Instance->CR2 = cr2;
    htim->Instance->CCMR3 = ccmr;
    htim->Instance->CCR6 = sConfig->Pulse;
    htim->Instance->CCER = ccer;
}


/**
 * @brief  Configure the input capture channel 1.
 */
static void TIM_TI1_SetConfig(HAL_TIM_HandleTypeDef *htim, uint32 ICPolarity, uint32 ICSelection, uint32 ICFilter)
{
    uint32 ccmr = 0U;
    uint32 ccer = 0U;

    /* Disable the channel 1 capture */
    htim->Instance->CCER &= ~(uint32)TIM_CCER_CC1E;

    ccmr = htim->Instance->CCMR1;
    ccer = htim->Instance->CCER;

    /* Input 1 capture selection and filter */
    ccmr &= ~((uint32)TIM_CCMR1_CC1S | TIM_CCMR1_IC1F);
    ccmr |= (uint32)(ICSelection | (ICFilter << 4U));

    /* Input 1 polarity, keep the channel disabled */
    ccer &= ~(uint32)(TIM_CCER_CC1P | TIM_CCER_CC1NP);
    ccer |= (ICPolarity & (uint32)(TIM_CCER_CC1P | TIM_CCER_CC1NP));

    htim->Instance->CCMR1 = ccmr;
    htim->Instance->CCER = ccer;
}

/**
 * @brief  Configure the input capture channel 2.
 */
static void TIM_TI2_SetConfig(HAL_TIM_HandleTypeDef *htim, uint32 ICPolarity, uint32 ICSelection, uint32 ICFilter)
{
    uint32 ccmr = 0U;
    uint32 ccer = 0U;

    htim->Instance->CCER &= ~(uint32)TIM_CCER_CC2E;

    ccmr = htim->Instance->CCMR1;
    ccer = htim->Instance->CCER;

    ccmr &= ~((uint32)TIM_CCMR1_CC2S | TIM_CCMR1_IC2F);
    ccmr |= (uint32)((ICSelection << 8U) | (ICFilter << 12U));

    ccer &= ~(uint32)(TIM_CCER_CC2P | TIM_CCER_CC2NP);
    ccer |= ((ICPolarity << 4U) & (uint32)(TIM_CCER_CC2P | TIM_CCER_CC2NP));

    htim->Instance->CCMR1 = ccmr;
    htim->Instance->CCER = ccer;
}

/**
 * @brief  Configure the input capture channel 3.
 */
static void TIM_TI3_SetConfig(HAL_TIM_HandleTypeDef *htim, uint32 ICPolarity, uint32 ICSelection, uint32 ICFilter)
{
    uint32 ccmr = 0U;
    uint32 ccer = 0U;

    htim->Instance->CCER &= ~(uint32)TIM_CCER_CC3E;

    ccmr = htim->Instance->CCMR2;
    ccer = htim->Instance->CCER;

    ccmr &= ~((uint32)TIM_CCMR2_CC3S | TIM_CCMR2_IC3F);
    ccmr |= (uint32)(ICSelection | (ICFilter << 4U));

    ccer &= ~(uint32)(TIM_CCER_CC3P | TIM_CCER_CC3NP);
    ccer |= ((ICPolarity << 8U) & (uint32)(TIM_CCER_CC3P | TIM_CCER_CC3NP));

    htim->Instance->CCMR2 = ccmr;
    htim->Instance->CCER = ccer;
}

/**
 * @brief  Configure the input capture channel 4.
 */
static void TIM_TI4_SetConfig(HAL_TIM_HandleTypeDef *htim, uint32 ICPolarity, uint32 ICSelection, uint32 ICFilter)
{
    uint32 ccmr = 0U;
    uint32 ccer = 0U;

    htim->Instance->CCER &= ~(uint32)TIM_CCER_CC4E;

    ccmr = htim->Instance->CCMR2;
    ccer = htim->Instance->CCER;

    ccmr &= ~((uint32)TIM_CCMR2_CC4S | TIM_CCMR2_IC4F);
    ccmr |= (uint32)((ICSelection << 8U) | (ICFilter << 12U));

    ccer &= ~(uint32)(TIM_CCER_CC4P | TIM_CCER_CC4NP);
    ccer |= ((ICPolarity << 12U) & (uint32)(TIM_CCER_CC4P | TIM_CCER_CC4NP));

    htim->Instance->CCMR2 = ccmr;
    htim->Instance->CCER = ccer;
}
/**
 * @brief  Configure the input capture channel 5.
 * @note   The input selection and filter of channels 5 and 6 live in CCMR3
 *         (CC5S/IC5F in the low half, CC6S/IC6F in the high half), which
 *         matches the CC1S/IC1F and CC2S/IC2F layout of CCMR1.
 */
static void TIM_TI5_SetConfig(HAL_TIM_HandleTypeDef *htim, uint32 ICPolarity, uint32 ICSelection, uint32 ICFilter)
{
    uint32 ccmr = 0U;
    uint32 ccer = 0U;

    htim->Instance->CCER &= ~(uint32)TIM_CCER_CC5E;

    ccmr = htim->Instance->CCMR3;
    ccer = htim->Instance->CCER;

    ccmr &= ~((uint32)TIM_CCMR3_CC5S | TIM_CCMR3_IC5F);
    ccmr |= (uint32)(ICSelection | (ICFilter << 4U));

    ccer &= ~(uint32)TIM_CCER_CC5P;
    ccer |= ((ICPolarity << 16U) & (uint32)TIM_CCER_CC5P);

    htim->Instance->CCMR3 = ccmr;
    htim->Instance->CCER = ccer;
}

/**
 * @brief  Configure the input capture channel 6.
 */
static void TIM_TI6_SetConfig(HAL_TIM_HandleTypeDef *htim, uint32 ICPolarity, uint32 ICSelection, uint32 ICFilter)
{
    uint32 ccmr = 0U;
    uint32 ccer = 0U;

    htim->Instance->CCER &= ~(uint32)TIM_CCER_CC6E;

    ccmr = htim->Instance->CCMR3;
    ccer = htim->Instance->CCER;

    ccmr &= ~((uint32)TIM_CCMR3_CC6S | TIM_CCMR3_IC6F);
    ccmr |= (uint32)((ICSelection << 8U) | (ICFilter << 12U));

    ccer &= ~(uint32)TIM_CCER_CC6P;
    ccer |= ((ICPolarity << 20U) & (uint32)TIM_CCER_CC6P);

    htim->Instance->CCMR3 = ccmr;
    htim->Instance->CCER = ccer;
}


/** @brief  Read the CCxS selection of a channel from the CCMRx register.
  * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
  * @param  Index: 0..5 for channel 1..6.
  * @retval the CCxS field value (0 when the channel is an output).
  */
static uint32 TIM_CCxSelection(HAL_TIM_HandleTypeDef *htim, uint32 Index)
{
    uint32 ccmr = 0U;

    if (Index < 2U)
    {
        ccmr = htim->Instance->CCMR1;
    }
    else if (Index < 4U)
    {
        ccmr = htim->Instance->CCMR2;
    }
    else
    {
        ccmr = htim->Instance->CCMR3;   /* advanced instances only */
    }

    /* The low channel of a register uses bits 1:0, the high one bits 9:8 */
    if ((Index & 0x1U) != 0U)
    {
        ccmr >>= 8U;
    }

    return ccmr & 0x3U;
}

/**
 * @brief  Enables or disables a capture/compare channel output.
 * @note   The CCxE bit position is derived from the channel value by the
 *         4-bit stepping of the CCER register (CH1:bit0, CH2:bit4, CH3:bit8,
 *         CH4:bit12, CH5:bit16, CH6:bit20), so the same expression serves
 *         the four general purpose channels and the two extra channels of
 *         the advanced timers.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  Channel: the channel (TIM_CHANNEL_1..6).
 * @param  ChannelState: TIM_CCx_ENABLE or TIM_CCx_DISABLE.
 * @retval None
 */
static void TIM_CCxChannelCmd(HAL_TIM_HandleTypeDef *htim, uint32 Channel, uint32 ChannelState)
{
    uint32 tmp = (uint32)TIM_CCER_CC1E << Channel;

    /* Reset the CCxE bit */
    htim->Instance->CCER &= ~tmp;

    /* Set or reset the CCxE bit */
    htim->Instance->CCER |= (uint32)(ChannelState << Channel);
}

/** @brief  Stop the counter and silence every source this module can have
  *         enabled (update / trigger / break / capture-compare interrupts, the
  *         channel outputs and the capture-compare DMA requests). The
  *         configuration registers keep their values, so a DeInit followed by
  *         an Init only needs the structures the caller wants to change.
  * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
  * @retval None
  */
static void TIM_StopInstance(HAL_TIM_HandleTypeDef *htim)
{
    htim->Instance->CR1 &= ~(uint32)TIM_CR1_CEN;   /* stop counting            */
    htim->Instance->DIER = 0U;                     /* no interrupt request     */
    htim->Instance->CCER = 0U;                     /* no channel output        */
    htim->Instance->SR = 0U;                       /* drop the pending flags   */

    if (IS_TIM_ADV_INSTANCE(htim->Instance))
    {
        htim->Instance->BDTR = 0U;                 /* main output and break off */
    }
}

/* Exported functions ---------------------------------------------------------*/

/** @addtogroup TIM_Exported_Functions_Group1 Time Base functions
  * @{
  */

/**
 * @brief  Initializes the TIM time base unit. (NON-BLOCKING)
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_Base_Init(HAL_TIM_HandleTypeDef *htim)
{
    /* Check the TIM peripheral handle */
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_TIM_ALL_INSTANCE(htim->Instance));
    assert_param(IS_TIM_COUNTER_MODE(htim->Init.CounterMode));
    assert_param(IS_TIM_CKD_DIV(htim->Init.ClockDivision));
    if (IS_TIM_GEN_INSTANCE(htim->Instance))
    {
        assert_param(htim->Init.Prescaler <= 0xFFFFU);
        assert_param(htim->Init.Period <= 0xFFFFU);
    }

    /* Run time validation of the configuration structure, so that the checks
     * stay effective in a build with the assertions disabled. The metafields
     * (Size / Version, architecture spec section 22) and the reserved words are
     * validated as well, and on the general purpose timers the prescaler and the
     * period are checked against the 16 bit register width. A rejected call
     * neither takes the lock nor changes the handle state nor touches a
     * register. */
    if ((htim->Init.Size != sizeof(TIM_Base_InitTypeDef)) ||
        (htim->Init.Version != TIM_INIT_VERSION) ||
        (IS_TIM_COUNTER_MODE(htim->Init.CounterMode) == 0U) ||
        (IS_TIM_CKD_DIV(htim->Init.ClockDivision) == 0U) ||
        ((IS_TIM_GEN_INSTANCE(htim->Instance) != 0U) && (htim->Init.Prescaler > 0xFFFFU)) ||
        ((IS_TIM_GEN_INSTANCE(htim->Instance) != 0U) && (htim->Init.Period > 0xFFFFU)) ||
        (htim->Init.Reserved[0] != 0U) ||
        (htim->Init.Reserved[1] != 0U))
    {
        htim->ErrorCode |= HAL_TIM_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* A timer that is counting keeps the BUSY state set: the Start functions
     * leave it set and only the Stop functions clear it, so the state is a
     * reliable "the counter is running" indicator in this module. Rewriting
     * the time base of a running timer would change the prescaler and the
     * auto-reload value in the middle of a period, so the call is refused
     * instead. A refused call takes no lock, changes no state and touches no
     * register. */
    if (htim->State == HAL_TIM_STATE_BUSY)
    {
        return HAL_BUSY;
    }

    /* Allocate the lock resource and initialize the low level hardware before
     * the first use (architecture rules MSP-04 and LOCK-06): the MSP callback
     * runs before the handle is locked, so an override may create the RTOS
     * mutex that TIM_LockHandle() needs and call other HAL APIs, and it runs
     * only while the handle is in the reset state, so a repeated
     * initialization does not initialize the hardware twice */
    if (htim->State == HAL_TIM_STATE_RESET)
    {
        htim->Lock = HAL_UNLOCKED;

        HAL_TIM_Base_MspInit(htim);
    }

    /* Process locked */
    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Set the TIM time base configuration */
    htim->State = HAL_TIM_STATE_BUSY;
    TIM_Base_SetConfig(htim);

    /* Clear the error code and set the ready state */
    htim->ErrorCode = HAL_TIM_ERROR_NONE;
    htim->State = HAL_TIM_STATE_READY;

    /* Release Lock */
    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  De-initializes the TIM base unit. (NON-BLOCKING)
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_Base_DeInit(HAL_TIM_HandleTypeDef *htim)
{
    /* Check the TIM handle allocation */
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    /* Process locked */
    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    htim->State = HAL_TIM_STATE_BUSY;

    /* Disable the TIM counter */
    TIM_StopInstance(htim);

    /* Set the TIM error code to none and reset the state */
    htim->ErrorCode = HAL_TIM_ERROR_NONE;
    htim->State = HAL_TIM_STATE_RESET;

    /* Release Lock */
    TIM_UnlockHandle(htim);

    /* LOCK-06 / ARCH-CONST-04: the low level de-initialization runs OUTSIDE
     * the locked region, as the architecture specification requires for the
     * MSP callbacks ("MspDeInit is called after the unlock"). An override may
     * call other HAL APIs, which is only allowed while the handle lock is not
     * held. */
    HAL_TIM_Base_MspDeInit(htim);

    return HAL_OK;
}

/**
 * @brief  Fills the time base configuration structure with the reset defaults.
 */
void HAL_TIM_Base_StructInit(TIM_Base_InitTypeDef *InitStruct)
{
    if (InitStruct == NULL_PTR)
    {
        return;
    }

    InitStruct->Size = (uint32)sizeof(TIM_Base_InitTypeDef);
    InitStruct->Version = TIM_INIT_VERSION;
    InitStruct->Prescaler = 0U;
    InitStruct->CounterMode = TIM_COUNTERMODE_UP;
    InitStruct->Period = 0U;
    InitStruct->ClockDivision = TIM_CKD_DIV1;
    InitStruct->RepetitionCounter = 0U;
    InitStruct->Reserved[0] = 0U;
    InitStruct->Reserved[1] = 0U;
}

/**
 * @brief  Fills the output compare configuration structure with the reset
 *         defaults.
 */
void HAL_TIM_OC_StructInit(TIM_OC_InitTypeDef *InitStruct)
{
    if (InitStruct == NULL_PTR)
    {
        return;
    }

    InitStruct->OCMode = TIM_OCMODE_TIMING;
    InitStruct->Pulse = 0U;
    InitStruct->OCPolarity = TIM_OCPOLARITY_HIGH;
    InitStruct->OCNPolarity = TIM_OCNPOLARITY_HIGH;
    InitStruct->OCFastMode = TIM_OCFAST_DISABLE;
    InitStruct->OCPreload = TIM_OCPRECONFIG_DISABLE;
    InitStruct->OCIdleState = TIM_OCIDLESTATE_RESET;
    InitStruct->OCNIdleState = TIM_OCNIDLESTATE_RESET;
}

/**
 * @brief  Fills the input capture configuration structure with the reset
 *         defaults.
 */
void HAL_TIM_IC_StructInit(TIM_IC_InitTypeDef *InitStruct)
{
    if (InitStruct == NULL_PTR)
    {
        return;
    }

    InitStruct->ICPolarity = TIM_ICPOLARITY_RISING;
    InitStruct->ICSelection = TIM_ICSEL_DIRECTTI;
    InitStruct->ICPrescaler = TIM_ICPSC_DIV1;
    InitStruct->ICFilter = 0U;
}

/**
 * @brief  Fills the one pulse configuration structure with the reset defaults.
 */
void HAL_TIM_OnePulse_StructInit(TIM_OnePulse_InitTypeDef *InitStruct)
{
    if (InitStruct == NULL_PTR)
    {
        return;
    }

    InitStruct->OCMode = TIM_OCMODE_TIMING;
    InitStruct->Pulse = 0U;
    InitStruct->OCPolarity = TIM_OCPOLARITY_HIGH;
    InitStruct->OCNPolarity = TIM_OCNPOLARITY_HIGH;
    InitStruct->OCIdleState = TIM_OCIDLESTATE_RESET;
    InitStruct->OCNIdleState = TIM_OCNIDLESTATE_RESET;
    InitStruct->ICPolarity = TIM_ICPOLARITY_RISING;
    InitStruct->ICSelection = TIM_ICSEL_DIRECTTI;
    InitStruct->ICFilter = 0U;
}

/**
 * @brief  Fills the encoder configuration structure with the reset defaults.
 */
void HAL_TIM_Encoder_StructInit(TIM_Encoder_InitTypeDef *InitStruct)
{
    if (InitStruct == NULL_PTR)
    {
        return;
    }

    InitStruct->EncoderMode = TIM_ENCODERMODE_TI1;
    InitStruct->IC1Polarity = TIM_ICPOLARITY_RISING;
    InitStruct->IC1Selection = TIM_ICSEL_DIRECTTI;
    InitStruct->IC1Prescaler = TIM_ICPSC_DIV1;
    InitStruct->IC1Filter = 0U;
    InitStruct->IC2Polarity = TIM_ICPOLARITY_RISING;
    InitStruct->IC2Selection = TIM_ICSEL_DIRECTTI;
    InitStruct->IC2Prescaler = TIM_ICPSC_DIV1;
    InitStruct->IC2Filter = 0U;
}

/**
 * @brief  Fills the clock source configuration structure with the reset
 *         defaults.
 * @note   The default internal clock is always accepted; the caller only has
 *         to change the structure when an external clock is used.
 */
void HAL_TIM_ClockConfig_StructInit(TIM_ClockConfigTypeDef *InitStruct)
{
    if (InitStruct == NULL_PTR)
    {
        return;
    }

    InitStruct->ClockSource = TIM_CLOCKSOURCE_INTERNAL;
    InitStruct->ClockPolarity = TIM_ETRPOLARITY_NONINVERTED;
    InitStruct->ClockPrescaler = TIM_CLOCKPRESCALER_DIV1;
    InitStruct->ClockFilter = 0U;
}

/**
 * @brief  Fills the OCREF clear input configuration structure with the reset
 *         defaults.
 */
void HAL_TIM_ClearInputConfig_StructInit(TIM_ClearInputConfigTypeDef *InitStruct)
{
    if (InitStruct == NULL_PTR)
    {
        return;
    }

    InitStruct->ClearInputState = TIM_CLEARINPUT_DISABLE;
    InitStruct->ClearInputSource = TIM_CLEARINPUTSOURCE_ETR;
    InitStruct->ClearInputPolarity = TIM_CLEARINPUTPOLARITY_NONINVERTED;
    InitStruct->ClearInputPrescaler = TIM_CLEARINPUTPRESCALER_DIV1;
    InitStruct->ClearInputFilter = 0U;
}

/**
 * @brief  Fills the slave mode configuration structure with the reset defaults.
 * @note   The default trigger selection is ITR0; ITR2 and ITR3 are refused by
 *         HAL_TIM_SlaveConfigSynchronization on this device.
 */
void HAL_TIM_SlaveConfig_StructInit(TIM_SlaveConfigTypeDef *InitStruct)
{
    if (InitStruct == NULL_PTR)
    {
        return;
    }

    InitStruct->SlaveMode = TIM_SLAVEMODE_DISABLE;
    InitStruct->InputTrigger = TIM_TS_ITR0;
    InitStruct->TriggerPolarity = TIM_TRIGGERPOLARITY_NONINVERTED;
    InitStruct->TriggerPrescaler = TIM_CLOCKPRESCALER_DIV1;
    InitStruct->TriggerFilter = 0U;
}

/**
 * @brief  Fills the master mode configuration structure with the reset
 *         defaults.
 * @note   The master/slave mode field has no effect on this device (SMCR has
 *         no MSM bit), so only the neutral value is written.
 * @note   The second master output keeps its neutral TIM_TRGO2_RESET, which is
 *         also the only value accepted on the general purpose timers (they have
 *         no CR2.MMS2 field).
 */
void HAL_TIM_MasterConfig_StructInit(TIM_MasterConfigTypeDef *InitStruct)
{
    if (InitStruct == NULL_PTR)
    {
        return;
    }

    InitStruct->MasterOutputTrigger = TIM_TRGO_RESET;
    InitStruct->MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
    InitStruct->MasterOutputTrigger2 = TIM_TRGO2_RESET;
}

/**
 * @brief  Fills the break and dead-time configuration structure with the reset
 *         defaults.
 * @note   The lock level keeps the neutral value: BDTR has no LOCK field on
 *         this device.
 */
void HAL_TIM_BreakDeadTimeConfig_StructInit(TIM_BreakDeadTimeConfigTypeDef *InitStruct)
{
    if (InitStruct == NULL_PTR)
    {
        return;
    }

    InitStruct->OffStateRunMode = TIM_OSSR_DISABLE;
    InitStruct->OffStateIDLEMode = TIM_OSSI_DISABLE;
    InitStruct->LockLevel = TIM_LOCKLEVEL_OFF;
    InitStruct->DeadTime = 0U;
    InitStruct->BreakState = TIM_BREAK_DISABLE;
    InitStruct->BreakPolarity = TIM_BREAKPOLARITY_LOW;
    InitStruct->BreakFilter = 0U;
    InitStruct->AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
}

/**
 * @brief  Initializes the TIM base MSP. Weak empty function.
 */
__weak void HAL_TIM_Base_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    UNUSED(htim);
}

/**
 * @brief  De-initializes the TIM base MSP. Weak empty function.
 */
__weak void HAL_TIM_Base_MspDeInit(HAL_TIM_HandleTypeDef *htim)
{
    UNUSED(htim);
}

/**
 * @brief  Starts the TIM base generation in polling mode. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_Base_Start(HAL_TIM_HandleTypeDef *htim)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Enable the TIM counter */
    __HAL_TIM_ENABLE(htim);

    htim->State = HAL_TIM_STATE_BUSY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Stops the TIM base generation in polling mode. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_Base_Stop(HAL_TIM_HandleTypeDef *htim)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Disable the TIM counter */
    __HAL_TIM_DISABLE(htim);

    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Starts the TIM base generation in interrupt mode. (NON-BLOCKING / IT)
 */
HAL_StatusTypeDef HAL_TIM_Base_Start_IT(HAL_TIM_HandleTypeDef *htim)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the update flag and enable the update interrupt */
    __HAL_TIM_CLEAR_IT(htim, TIM_IT_UPDATE);
    __HAL_TIM_ENABLE_IT(htim, TIM_IT_UPDATE);

    /* Enable the TIM counter */
    __HAL_TIM_ENABLE(htim);

    htim->State = HAL_TIM_STATE_BUSY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Stops the TIM base generation in interrupt mode. (NON-BLOCKING / IT)
 */
HAL_StatusTypeDef HAL_TIM_Base_Stop_IT(HAL_TIM_HandleTypeDef *htim)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Disable the update interrupt */
    __HAL_TIM_DISABLE_IT(htim, TIM_IT_UPDATE);

    /* Disable the TIM counter */
    __HAL_TIM_DISABLE(htim);

    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
  * @}
  */

/** @addtogroup TIM_Exported_Functions_Group2 Output Compare functions
  * @{
  */

/**
 * @brief  Initializes the TIM output compare unit. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_OC_Init(HAL_TIM_HandleTypeDef *htim)
{
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_ALL_INSTANCE(htim->Instance));
    assert_param(IS_TIM_COUNTER_MODE(htim->Init.CounterMode));
    assert_param(IS_TIM_CKD_DIV(htim->Init.ClockDivision));

    /* Run time validation of the configuration structure, so that the checks
     * stay effective in a build with the assertions disabled. The metafields
     * (Size / Version, architecture spec section 22) and the reserved words are
     * validated as well, and on the general purpose timers the prescaler and the
     * period are checked against the 16 bit register width. A rejected call
     * neither takes the lock nor changes the handle state nor touches a
     * register. */
    if ((htim->Init.Size != sizeof(TIM_Base_InitTypeDef)) ||
        (htim->Init.Version != TIM_INIT_VERSION) ||
        (IS_TIM_COUNTER_MODE(htim->Init.CounterMode) == 0U) ||
        (IS_TIM_CKD_DIV(htim->Init.ClockDivision) == 0U) ||
        ((IS_TIM_GEN_INSTANCE(htim->Instance) != 0U) && (htim->Init.Prescaler > 0xFFFFU)) ||
        ((IS_TIM_GEN_INSTANCE(htim->Instance) != 0U) && (htim->Init.Period > 0xFFFFU)) ||
        (htim->Init.Reserved[0] != 0U) ||
        (htim->Init.Reserved[1] != 0U))
    {
        htim->ErrorCode |= HAL_TIM_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* A timer that is counting keeps the BUSY state set: the Start functions
     * leave it set and only the Stop functions clear it, so the state is a
     * reliable "the counter is running" indicator in this module. Rewriting
     * the time base of a running timer would change the prescaler and the
     * auto-reload value in the middle of a period, so the call is refused
     * instead. A refused call takes no lock, changes no state and touches no
     * register. */
    if (htim->State == HAL_TIM_STATE_BUSY)
    {
        return HAL_BUSY;
    }

    /* Allocate the lock resource and initialize the low level hardware before
     * the first use (architecture rules MSP-04 and LOCK-06): the MSP callback
     * runs before the handle is locked, so an override may create the RTOS
     * mutex that TIM_LockHandle() needs and call other HAL APIs, and it runs
     * only while the handle is in the reset state, so a repeated
     * initialization does not initialize the hardware twice */
    if (htim->State == HAL_TIM_STATE_RESET)
    {
        htim->Lock = HAL_UNLOCKED;

        HAL_TIM_OC_MspInit(htim);
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    htim->State = HAL_TIM_STATE_BUSY;
    TIM_Base_SetConfig(htim);
    htim->ErrorCode = HAL_TIM_ERROR_NONE;
    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  De-initializes the TIM output compare unit. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_OC_DeInit(HAL_TIM_HandleTypeDef *htim)
{
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    htim->State = HAL_TIM_STATE_BUSY;
    TIM_StopInstance(htim);
    htim->ErrorCode = HAL_TIM_ERROR_NONE;
    htim->State = HAL_TIM_STATE_RESET;

    TIM_UnlockHandle(htim);

    /* LOCK-06 / ARCH-CONST-04: the low level de-initialization runs OUTSIDE
     * the locked region, as the architecture specification requires for the
     * MSP callbacks ("MspDeInit is called after the unlock"). An override may
     * call other HAL APIs, which is only allowed while the handle lock is not
     * held. */
    HAL_TIM_OC_MspDeInit(htim);

    return HAL_OK;
}

/**
 * @brief  Initializes the TIM OC MSP. Weak empty function.
 */
__weak void HAL_TIM_OC_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    UNUSED(htim);
}

/**
 * @brief  De-initializes the TIM OC MSP. Weak empty function.
 */
__weak void HAL_TIM_OC_MspDeInit(HAL_TIM_HandleTypeDef *htim)
{
    UNUSED(htim);
}

/**
 * @brief  Starts the PWM signal generation on the given channel. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_OC_Start(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_CHANNEL(Channel));

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Enable the output compare channel */
    TIM_CCxChannelCmd(htim, Channel, TIM_CCx_ENABLE);

    if (IS_TIM_ADV_INSTANCE(htim->Instance))
    {
        /* Enable the main outputs */
        __HAL_TIM_MOE_ENABLE(htim);
    }

    /* Enable the TIM counter */
    __HAL_TIM_ENABLE(htim);

    htim->State = HAL_TIM_STATE_BUSY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Stops the output compare signal generation. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_OC_Stop(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_CHANNEL(Channel));

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Disable the output compare channel */
    TIM_CCxChannelCmd(htim, Channel, TIM_CCx_DISABLE);

    if (IS_TIM_ADV_INSTANCE(htim->Instance))
    {
        __HAL_TIM_MOE_DISABLE(htim);
    }

    __HAL_TIM_DISABLE(htim);

    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Starts the output compare signal generation in interrupt mode. (NON-BLOCKING / IT)
 */
HAL_StatusTypeDef HAL_TIM_OC_Start_IT(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_CHANNEL(Channel));

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    switch (Channel)
    {
        case TIM_CHANNEL_1:
            __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC1);
            break;
        case TIM_CHANNEL_2:
            __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC2);
            break;
        case TIM_CHANNEL_3:
            __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC3);
            break;
        case TIM_CHANNEL_5:
            __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC5);
            break;
        case TIM_CHANNEL_6:
            __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC6);
            break;
        default:
            __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC4);
            break;
    }

    TIM_CCxChannelCmd(htim, Channel, TIM_CCx_ENABLE);

    if (IS_TIM_ADV_INSTANCE(htim->Instance))
    {
        __HAL_TIM_MOE_ENABLE(htim);
    }

    __HAL_TIM_ENABLE(htim);

    htim->State = HAL_TIM_STATE_BUSY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Stops the output compare signal generation in interrupt mode. (NON-BLOCKING / IT)
 */
HAL_StatusTypeDef HAL_TIM_OC_Stop_IT(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_CHANNEL(Channel));

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    switch (Channel)
    {
        case TIM_CHANNEL_1:
            __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC1);
            break;
        case TIM_CHANNEL_2:
            __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC2);
            break;
        case TIM_CHANNEL_3:
            __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC3);
            break;
        case TIM_CHANNEL_5:
            __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC5);
            break;
        case TIM_CHANNEL_6:
            __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC6);
            break;
        default:
            __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC4);
            break;
    }

    TIM_CCxChannelCmd(htim, Channel, TIM_CCx_DISABLE);

    if (IS_TIM_ADV_INSTANCE(htim->Instance))
    {
        __HAL_TIM_MOE_DISABLE(htim);
    }

    __HAL_TIM_DISABLE(htim);

    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

#ifdef HAL_DMA_MODULE_ENABLED

/**
 * @brief  Starts the output compare signal generation with DMA. (NON-BLOCKING / DMA)
 * @note   The DMA channel referenced by
 * @note   CR2.CCDS must be set (HAL_TIM_SelectCCDMA(htim, TIM_ENABLE))
 *         before the transfer is started: without it the channel event
 *         never reaches the DMA channel on this device (the timer sets
 *         DIER.*DE and SR.CCxIF as usual, but no request is issued).
 *         htim->hdma[TIM_DMA_ID_CCx] must previously be initialized
 *         (HAL_DMA_Init) with the DMA_MEMORY_TO_PERIPH direction and mapped
 *         to the timer peripheral interface (HAL_DMA_ConfigPeriphIF), and
 *         the channel data width must match the single-word DMAR burst. The
 *         completion is reported by HAL_TIM_OC_DelayElapsedCallback().
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  Channel: the output compare channel (TIM_CHANNEL_1..6).
 * @param  pData: pointer to the buffer that holds the compare values.
 * @param  Length: number of compare values to transfer.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_OC_Start_DMA(HAL_TIM_HandleTypeDef *htim, uint32 Channel, uint32 *pData, uint16 Length)
{
    HAL_StatusTypeDef status = HAL_OK;

    DMA_HandleTypeDef *hdma;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_CHANNEL(Channel));

    /* This DMA start additionally requires the ready state, so that a second
     * DMA start on a running timer is refused */
    if (htim->State != HAL_TIM_STATE_READY)
    {
        return HAL_BUSY;
    }

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    if ((pData == NULL_PTR) || (Length == 0U))
    {
        htim->ErrorCode |= HAL_TIM_ERROR_INVALID_PARAM;
        htim->State = HAL_TIM_STATE_READY;
        TIM_UnlockHandle(htim);
        return HAL_ERROR;
    }

    hdma = htim->hdma[TIM_DMA_GetDMAIndex(Channel)];
    if (hdma == NULL_PTR)
    {
        TIM_UnlockHandle(htim);
        return HAL_ERROR;
    }

    /* Enable the capture/compare DMA request (DIER.*DE) */
    __HAL_TIM_ENABLE_DMA(htim, TIM_DMA_GetDMARequest(Channel));

    /* Set the DMA burst base address to the channel CCR register and use a
     * single transfer burst (one compare value per capture/compare event) */
    __HAL_TIM_SET_DMABURSTBASE(htim, TIM_DMA_GetDMABase(Channel));
    __HAL_TIM_SET_DMABURSTLENGTH(htim, TIM_DMABurstLength_1Transfer);

    /* Enable the channel output and the main output of an advanced timer */
    TIM_CCxChannelCmd(htim, Channel, TIM_CCx_ENABLE);
    if (IS_TIM_ADV_INSTANCE(htim->Instance))
    {
        __HAL_TIM_MOE_ENABLE(htim);
    }

    /* Enable the TIM counter */
    __HAL_TIM_ENABLE(htim);

    /* Configure and start the DMA transfer (memory -> DMAR) */
    hdma->Parent = (void *)htim;
    HAL_DMA_RegisterCallback(hdma, HAL_DMA_XFER_CPLT_CB_ID, TIM_DMAOC_DelayPulseCplt);
    HAL_DMA_RegisterCallback(hdma, HAL_DMA_XFER_ERROR_CB_ID, TIM_DMAErrorCplt);

    if (HAL_DMA_Start_IT(hdma, (uint32)pData, (uint32)&htim->Instance->DMAR, Length) != HAL_OK)
    {
        __HAL_TIM_DISABLE_DMA(htim, TIM_DMA_GetDMARequest(Channel));
        htim->ErrorCode |= HAL_TIM_ERROR_TRANSFER;
        htim->State = HAL_TIM_STATE_READY;
        TIM_UnlockHandle(htim);
        return HAL_ERROR;
    }

    htim->State = HAL_TIM_STATE_BUSY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Stops the output compare signal generation with DMA. (NON-BLOCKING / DMA)
 * @note   The DMA channel is aborted and the
 *         capture/compare DMA request is disabled.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  Channel: the output compare channel (TIM_CHANNEL_1..6).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_OC_Stop_DMA(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    DMA_HandleTypeDef *hdma;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_CHANNEL(Channel));

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    hdma = htim->hdma[TIM_DMA_GetDMAIndex(Channel)];
    if (hdma != NULL_PTR)
    {
        (void)HAL_DMA_Abort(hdma);
    }

    /* Disable the capture/compare DMA request and the channel output */
    __HAL_TIM_DISABLE_DMA(htim, TIM_DMA_GetDMARequest(Channel));
    TIM_CCxChannelCmd(htim, Channel, TIM_CCx_DISABLE);

    if (IS_TIM_ADV_INSTANCE(htim->Instance))
    {
        __HAL_TIM_MOE_DISABLE(htim);
    }

    __HAL_TIM_DISABLE(htim);

    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

#else /* HAL_DMA_MODULE_ENABLED */

/**
 * @brief  Starts the output compare signal generation with DMA. (NON-BLOCKING / DMA)
 * @note   Not supported: the DMA module is disabled in the configuration.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  Channel: the output compare channel (TIM_CHANNEL_1..6).
 * @param  pData: pointer to the buffer that holds the compare values.
 * @param  Length: number of compare values to transfer.
 * @retval HAL_StatusTypeDef: HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_OC_Start_DMA(HAL_TIM_HandleTypeDef *htim, uint32 Channel, uint32 *pData, uint16 Length)
{
    /* Check the htim handle allocation */
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }
    UNUSED(htim);
    UNUSED(Channel);
    UNUSED(pData);
    UNUSED(Length);
    return HAL_ERROR;
}

/**
 * @brief  Stops the output compare signal generation with DMA. (NON-BLOCKING / DMA)
 * @note   Not supported: the DMA module is disabled in the configuration.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  Channel: the output compare channel (TIM_CHANNEL_1..6).
 * @retval HAL_StatusTypeDef: HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_OC_Stop_DMA(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    /* Check the htim handle allocation */
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }
    UNUSED(htim);
    UNUSED(Channel);
    return HAL_ERROR;
}

#endif /* HAL_DMA_MODULE_ENABLED */

/**
  * @}
  */

/** @addtogroup TIM_Exported_Functions_Group3 PWM functions
  * @{
  */

/**
 * @brief  Initializes the TIM PWM unit. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_PWM_Init(HAL_TIM_HandleTypeDef *htim)
{
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_ALL_INSTANCE(htim->Instance));
    assert_param(IS_TIM_COUNTER_MODE(htim->Init.CounterMode));
    assert_param(IS_TIM_CKD_DIV(htim->Init.ClockDivision));

    /* Run time validation of the configuration structure, so that the checks
     * stay effective in a build with the assertions disabled. The metafields
     * (Size / Version, architecture spec section 22) and the reserved words are
     * validated as well, and on the general purpose timers the prescaler and the
     * period are checked against the 16 bit register width. A rejected call
     * neither takes the lock nor changes the handle state nor touches a
     * register. */
    if ((htim->Init.Size != sizeof(TIM_Base_InitTypeDef)) ||
        (htim->Init.Version != TIM_INIT_VERSION) ||
        (IS_TIM_COUNTER_MODE(htim->Init.CounterMode) == 0U) ||
        (IS_TIM_CKD_DIV(htim->Init.ClockDivision) == 0U) ||
        ((IS_TIM_GEN_INSTANCE(htim->Instance) != 0U) && (htim->Init.Prescaler > 0xFFFFU)) ||
        ((IS_TIM_GEN_INSTANCE(htim->Instance) != 0U) && (htim->Init.Period > 0xFFFFU)) ||
        (htim->Init.Reserved[0] != 0U) ||
        (htim->Init.Reserved[1] != 0U))
    {
        htim->ErrorCode |= HAL_TIM_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* A timer that is counting keeps the BUSY state set: the Start functions
     * leave it set and only the Stop functions clear it, so the state is a
     * reliable "the counter is running" indicator in this module. Rewriting
     * the time base of a running timer would change the prescaler and the
     * auto-reload value in the middle of a period, so the call is refused
     * instead. A refused call takes no lock, changes no state and touches no
     * register. */
    if (htim->State == HAL_TIM_STATE_BUSY)
    {
        return HAL_BUSY;
    }

    /* Allocate the lock resource and initialize the low level hardware before
     * the first use (architecture rules MSP-04 and LOCK-06): the MSP callback
     * runs before the handle is locked, so an override may create the RTOS
     * mutex that TIM_LockHandle() needs and call other HAL APIs, and it runs
     * only while the handle is in the reset state, so a repeated
     * initialization does not initialize the hardware twice */
    if (htim->State == HAL_TIM_STATE_RESET)
    {
        htim->Lock = HAL_UNLOCKED;

        HAL_TIM_PWM_MspInit(htim);
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    htim->State = HAL_TIM_STATE_BUSY;
    TIM_Base_SetConfig(htim);
    htim->ErrorCode = HAL_TIM_ERROR_NONE;
    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  De-initializes the TIM PWM unit. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_PWM_DeInit(HAL_TIM_HandleTypeDef *htim)
{
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    htim->State = HAL_TIM_STATE_BUSY;
    TIM_StopInstance(htim);
    htim->ErrorCode = HAL_TIM_ERROR_NONE;
    htim->State = HAL_TIM_STATE_RESET;

    TIM_UnlockHandle(htim);

    /* LOCK-06 / ARCH-CONST-04: the low level de-initialization runs OUTSIDE
     * the locked region, as the architecture specification requires for the
     * MSP callbacks ("MspDeInit is called after the unlock"). An override may
     * call other HAL APIs, which is only allowed while the handle lock is not
     * held. */
    HAL_TIM_PWM_MspDeInit(htim);

    return HAL_OK;
}

/**
 * @brief  Initializes the TIM PWM MSP. Weak empty function.
 */
__weak void HAL_TIM_PWM_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    UNUSED(htim);
}

/**
 * @brief  De-initializes the TIM PWM MSP. Weak empty function.
 */
__weak void HAL_TIM_PWM_MspDeInit(HAL_TIM_HandleTypeDef *htim)
{
    UNUSED(htim);
}

/**
 * @brief  Starts the PWM signal generation on the given channel. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_PWM_Start(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_CHANNEL(Channel));

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    TIM_CCxChannelCmd(htim, Channel, TIM_CCx_ENABLE);

    if (IS_TIM_ADV_INSTANCE(htim->Instance))
    {
        __HAL_TIM_MOE_ENABLE(htim);
    }

    __HAL_TIM_ENABLE(htim);

    htim->State = HAL_TIM_STATE_BUSY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Stops the PWM signal generation on the given channel. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_PWM_Stop(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_CHANNEL(Channel));

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    TIM_CCxChannelCmd(htim, Channel, TIM_CCx_DISABLE);

    if (IS_TIM_ADV_INSTANCE(htim->Instance))
    {
        __HAL_TIM_MOE_DISABLE(htim);
    }

    __HAL_TIM_DISABLE(htim);

    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Starts the PWM signal generation in interrupt mode. (NON-BLOCKING / IT)
 */
HAL_StatusTypeDef HAL_TIM_PWM_Start_IT(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_CHANNEL(Channel));

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    switch (Channel)
    {
        case TIM_CHANNEL_1:
            __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC1);
            break;
        case TIM_CHANNEL_2:
            __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC2);
            break;
        case TIM_CHANNEL_3:
            __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC3);
            break;
        case TIM_CHANNEL_5:
            __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC5);
            break;
        case TIM_CHANNEL_6:
            __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC6);
            break;
        default:
            __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC4);
            break;
    }

    TIM_CCxChannelCmd(htim, Channel, TIM_CCx_ENABLE);

    if (IS_TIM_ADV_INSTANCE(htim->Instance))
    {
        __HAL_TIM_MOE_ENABLE(htim);
    }

    __HAL_TIM_ENABLE(htim);

    htim->State = HAL_TIM_STATE_BUSY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Stops the PWM signal generation in interrupt mode. (NON-BLOCKING / IT)
 */
HAL_StatusTypeDef HAL_TIM_PWM_Stop_IT(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_CHANNEL(Channel));

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    switch (Channel)
    {
        case TIM_CHANNEL_1:
            __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC1);
            break;
        case TIM_CHANNEL_2:
            __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC2);
            break;
        case TIM_CHANNEL_3:
            __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC3);
            break;
        case TIM_CHANNEL_5:
            __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC5);
            break;
        case TIM_CHANNEL_6:
            __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC6);
            break;
        default:
            __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC4);
            break;
    }

    TIM_CCxChannelCmd(htim, Channel, TIM_CCx_DISABLE);

    if (IS_TIM_ADV_INSTANCE(htim->Instance))
    {
        __HAL_TIM_MOE_DISABLE(htim);
    }

    __HAL_TIM_DISABLE(htim);

    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

#ifdef HAL_DMA_MODULE_ENABLED

/**
 * @brief  Starts the PWM signal generation with DMA. (NON-BLOCKING / DMA)
 * @note   The DMA channel referenced by
 * @note   CR2.CCDS must be set (HAL_TIM_SelectCCDMA(htim, TIM_ENABLE))
 *         before the transfer is started: without it the channel event
 *         never reaches the DMA channel on this device (the timer sets
 *         DIER.*DE and SR.CCxIF as usual, but no request is issued).
 *         htim->hdma[TIM_DMA_ID_CCx] must previously be initialized
 *         (HAL_DMA_Init) with the DMA_MEMORY_TO_PERIPH direction and mapped
 *         to the timer peripheral interface (HAL_DMA_ConfigPeriphIF), and
 *         the channel data width must match the single-word DMAR burst. The
 *         completion is reported by HAL_TIM_PWM_PulseFinishedCallback().
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  Channel: the PWM channel (TIM_CHANNEL_1..6).
 * @param  pData: pointer to the buffer that holds the duty cycle values.
 * @param  Length: number of duty cycle values to transfer.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_PWM_Start_DMA(HAL_TIM_HandleTypeDef *htim, uint32 Channel, uint32 *pData, uint16 Length)
{
    HAL_StatusTypeDef status = HAL_OK;

    DMA_HandleTypeDef *hdma;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_CHANNEL(Channel));

    /* This DMA start additionally requires the ready state, so that a second
     * DMA start on a running timer is refused */
    if (htim->State != HAL_TIM_STATE_READY)
    {
        return HAL_BUSY;
    }

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    if ((pData == NULL_PTR) || (Length == 0U))
    {
        htim->ErrorCode |= HAL_TIM_ERROR_INVALID_PARAM;
        htim->State = HAL_TIM_STATE_READY;
        TIM_UnlockHandle(htim);
        return HAL_ERROR;
    }

    hdma = htim->hdma[TIM_DMA_GetDMAIndex(Channel)];
    if (hdma == NULL_PTR)
    {
        TIM_UnlockHandle(htim);
        return HAL_ERROR;
    }

    /* Enable the capture/compare DMA request (DIER.*DE) */
    __HAL_TIM_ENABLE_DMA(htim, TIM_DMA_GetDMARequest(Channel));

    /* Set the DMA burst base address to the channel CCR register and use a
     * single transfer burst (one duty cycle value per capture/compare event) */
    __HAL_TIM_SET_DMABURSTBASE(htim, TIM_DMA_GetDMABase(Channel));
    __HAL_TIM_SET_DMABURSTLENGTH(htim, TIM_DMABurstLength_1Transfer);

    /* Enable the channel output and the main output of an advanced timer */
    TIM_CCxChannelCmd(htim, Channel, TIM_CCx_ENABLE);
    if (IS_TIM_ADV_INSTANCE(htim->Instance))
    {
        __HAL_TIM_MOE_ENABLE(htim);
    }

    /* Enable the TIM counter */
    __HAL_TIM_ENABLE(htim);

    /* Configure and start the DMA transfer (memory -> DMAR) */
    hdma->Parent = (void *)htim;
    HAL_DMA_RegisterCallback(hdma, HAL_DMA_XFER_CPLT_CB_ID, TIM_DMAPWM_PulseFinishedCplt);
    HAL_DMA_RegisterCallback(hdma, HAL_DMA_XFER_ERROR_CB_ID, TIM_DMAErrorCplt);

    if (HAL_DMA_Start_IT(hdma, (uint32)pData, (uint32)&htim->Instance->DMAR, Length) != HAL_OK)
    {
        __HAL_TIM_DISABLE_DMA(htim, TIM_DMA_GetDMARequest(Channel));
        htim->ErrorCode |= HAL_TIM_ERROR_TRANSFER;
        htim->State = HAL_TIM_STATE_READY;
        TIM_UnlockHandle(htim);
        return HAL_ERROR;
    }

    htim->State = HAL_TIM_STATE_BUSY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Stops the PWM signal generation with DMA. (NON-BLOCKING / DMA)
 * @note   The DMA channel is aborted and the
 *         capture/compare DMA request is disabled.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  Channel: the PWM channel (TIM_CHANNEL_1..6).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_PWM_Stop_DMA(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    DMA_HandleTypeDef *hdma;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_CHANNEL(Channel));

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    hdma = htim->hdma[TIM_DMA_GetDMAIndex(Channel)];
    if (hdma != NULL_PTR)
    {
        (void)HAL_DMA_Abort(hdma);
    }

    /* Disable the capture/compare DMA request and the channel output */
    __HAL_TIM_DISABLE_DMA(htim, TIM_DMA_GetDMARequest(Channel));
    TIM_CCxChannelCmd(htim, Channel, TIM_CCx_DISABLE);

    if (IS_TIM_ADV_INSTANCE(htim->Instance))
    {
        __HAL_TIM_MOE_DISABLE(htim);
    }

    __HAL_TIM_DISABLE(htim);

    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

#else /* HAL_DMA_MODULE_ENABLED */

/**
 * @brief  Starts the PWM signal generation with DMA. (NON-BLOCKING / DMA)
 * @note   Not supported: the DMA module is disabled in the configuration.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  Channel: the PWM channel (TIM_CHANNEL_1..6).
 * @param  pData: pointer to the buffer that holds the duty cycle values.
 * @param  Length: number of duty cycle values to transfer.
 * @retval HAL_StatusTypeDef: HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_PWM_Start_DMA(HAL_TIM_HandleTypeDef *htim, uint32 Channel, uint32 *pData, uint16 Length)
{
    /* Check the htim handle allocation */
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }
    UNUSED(htim);
    UNUSED(Channel);
    UNUSED(pData);
    UNUSED(Length);
    return HAL_ERROR;
}

/**
 * @brief  Stops the PWM signal generation with DMA. (NON-BLOCKING / DMA)
 * @note   Not supported: the DMA module is disabled in the configuration.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  Channel: the PWM channel (TIM_CHANNEL_1..6).
 * @retval HAL_StatusTypeDef: HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_PWM_Stop_DMA(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    /* Check the htim handle allocation */
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }
    UNUSED(htim);
    UNUSED(Channel);
    return HAL_ERROR;
}

#endif /* HAL_DMA_MODULE_ENABLED */

/**
  * @}
  */

/** @addtogroup TIM_Exported_Functions_Group4 Input Capture functions
  * @{
  */

/**
 * @brief  Initializes the TIM input capture unit. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_IC_Init(HAL_TIM_HandleTypeDef *htim)
{
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_ALL_INSTANCE(htim->Instance));
    assert_param(IS_TIM_COUNTER_MODE(htim->Init.CounterMode));
    assert_param(IS_TIM_CKD_DIV(htim->Init.ClockDivision));

    /* Run time validation of the configuration structure, so that the checks
     * stay effective in a build with the assertions disabled. The metafields
     * (Size / Version, architecture spec section 22) and the reserved words are
     * validated as well, and on the general purpose timers the prescaler and the
     * period are checked against the 16 bit register width. A rejected call
     * neither takes the lock nor changes the handle state nor touches a
     * register. */
    if ((htim->Init.Size != sizeof(TIM_Base_InitTypeDef)) ||
        (htim->Init.Version != TIM_INIT_VERSION) ||
        (IS_TIM_COUNTER_MODE(htim->Init.CounterMode) == 0U) ||
        (IS_TIM_CKD_DIV(htim->Init.ClockDivision) == 0U) ||
        ((IS_TIM_GEN_INSTANCE(htim->Instance) != 0U) && (htim->Init.Prescaler > 0xFFFFU)) ||
        ((IS_TIM_GEN_INSTANCE(htim->Instance) != 0U) && (htim->Init.Period > 0xFFFFU)) ||
        (htim->Init.Reserved[0] != 0U) ||
        (htim->Init.Reserved[1] != 0U))
    {
        htim->ErrorCode |= HAL_TIM_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* A timer that is counting keeps the BUSY state set: the Start functions
     * leave it set and only the Stop functions clear it, so the state is a
     * reliable "the counter is running" indicator in this module. Rewriting
     * the time base of a running timer would change the prescaler and the
     * auto-reload value in the middle of a period, so the call is refused
     * instead. A refused call takes no lock, changes no state and touches no
     * register. */
    if (htim->State == HAL_TIM_STATE_BUSY)
    {
        return HAL_BUSY;
    }

    /* Allocate the lock resource and initialize the low level hardware before
     * the first use (architecture rules MSP-04 and LOCK-06): the MSP callback
     * runs before the handle is locked, so an override may create the RTOS
     * mutex that TIM_LockHandle() needs and call other HAL APIs, and it runs
     * only while the handle is in the reset state, so a repeated
     * initialization does not initialize the hardware twice */
    if (htim->State == HAL_TIM_STATE_RESET)
    {
        htim->Lock = HAL_UNLOCKED;

        HAL_TIM_IC_MspInit(htim);
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    htim->State = HAL_TIM_STATE_BUSY;
    TIM_Base_SetConfig(htim);
    htim->ErrorCode = HAL_TIM_ERROR_NONE;
    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  De-initializes the TIM input capture unit. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_IC_DeInit(HAL_TIM_HandleTypeDef *htim)
{
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    htim->State = HAL_TIM_STATE_BUSY;
    TIM_StopInstance(htim);
    htim->ErrorCode = HAL_TIM_ERROR_NONE;
    htim->State = HAL_TIM_STATE_RESET;

    TIM_UnlockHandle(htim);

    /* LOCK-06 / ARCH-CONST-04: the low level de-initialization runs OUTSIDE
     * the locked region, as the architecture specification requires for the
     * MSP callbacks ("MspDeInit is called after the unlock"). An override may
     * call other HAL APIs, which is only allowed while the handle lock is not
     * held. */
    HAL_TIM_IC_MspDeInit(htim);

    return HAL_OK;
}

/**
 * @brief  Initializes the TIM IC MSP. Weak empty function.
 */
__weak void HAL_TIM_IC_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    UNUSED(htim);
}

/**
 * @brief  De-initializes the TIM IC MSP. Weak empty function.
 */
__weak void HAL_TIM_IC_MspDeInit(HAL_TIM_HandleTypeDef *htim)
{
    UNUSED(htim);
}

/**
 * @brief  Starts the input capture measurement. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_IC_Start(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_CHANNEL(Channel));

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Enable the capture channel */
    TIM_CCxChannelCmd(htim, Channel, TIM_CCx_ENABLE);

    __HAL_TIM_ENABLE(htim);

    htim->State = HAL_TIM_STATE_BUSY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Stops the input capture measurement. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_IC_Stop(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_CHANNEL(Channel));

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    TIM_CCxChannelCmd(htim, Channel, TIM_CCx_DISABLE);

    __HAL_TIM_DISABLE(htim);

    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Starts the input capture measurement in interrupt mode. (NON-BLOCKING / IT)
 */
HAL_StatusTypeDef HAL_TIM_IC_Start_IT(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_CHANNEL(Channel));

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    switch (Channel)
    {
        case TIM_CHANNEL_1:
            __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC1);
            break;
        case TIM_CHANNEL_2:
            __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC2);
            break;
        case TIM_CHANNEL_3:
            __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC3);
            break;
        case TIM_CHANNEL_5:
            __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC5);
            break;
        case TIM_CHANNEL_6:
            __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC6);
            break;
        default:
            __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC4);
            break;
    }

    TIM_CCxChannelCmd(htim, Channel, TIM_CCx_ENABLE);

    __HAL_TIM_ENABLE(htim);

    htim->State = HAL_TIM_STATE_BUSY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Stops the input capture measurement in interrupt mode. (NON-BLOCKING / IT)
 */
HAL_StatusTypeDef HAL_TIM_IC_Stop_IT(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_CHANNEL(Channel));

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    switch (Channel)
    {
        case TIM_CHANNEL_1:
            __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC1);
            break;
        case TIM_CHANNEL_2:
            __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC2);
            break;
        case TIM_CHANNEL_3:
            __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC3);
            break;
        case TIM_CHANNEL_5:
            __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC5);
            break;
        case TIM_CHANNEL_6:
            __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC6);
            break;
        default:
            __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC4);
            break;
    }

    TIM_CCxChannelCmd(htim, Channel, TIM_CCx_DISABLE);

    __HAL_TIM_DISABLE(htim);

    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
  * @}
  */

/** @addtogroup TIM_Exported_Functions_Group5 One Pulse functions
  * @{
  */

/**
 * @brief  Initializes the TIM one pulse mode. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_OnePulse_Init(HAL_TIM_HandleTypeDef *htim, uint32 OnePulseMode)
{
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_ALL_INSTANCE(htim->Instance));
    assert_param(IS_TIM_COUNTER_MODE(htim->Init.CounterMode));
    assert_param(IS_TIM_CKD_DIV(htim->Init.ClockDivision));
    assert_param(IS_TIM_OPM_MODE(OnePulseMode));

    /* Run time validation of the configuration structure, so that the checks
     * stay effective in a build with the assertions disabled. The metafields
     * (Size / Version, architecture spec section 22) and the reserved words are
     * validated as well, and on the general purpose timers the prescaler and the
     * period are checked against the 16 bit register width. A rejected call
     * neither takes the lock nor changes the handle state nor touches a
     * register. */
    if ((htim->Init.Size != sizeof(TIM_Base_InitTypeDef)) ||
        (htim->Init.Version != TIM_INIT_VERSION) ||
        (IS_TIM_COUNTER_MODE(htim->Init.CounterMode) == 0U) ||
        (IS_TIM_CKD_DIV(htim->Init.ClockDivision) == 0U) ||
        ((IS_TIM_GEN_INSTANCE(htim->Instance) != 0U) && (htim->Init.Prescaler > 0xFFFFU)) ||
        ((IS_TIM_GEN_INSTANCE(htim->Instance) != 0U) && (htim->Init.Period > 0xFFFFU)) ||
        (htim->Init.Reserved[0] != 0U) ||
        (htim->Init.Reserved[1] != 0U))
    {
        htim->ErrorCode |= HAL_TIM_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* A timer that is counting keeps the BUSY state set: the Start functions
     * leave it set and only the Stop functions clear it, so the state is a
     * reliable "the counter is running" indicator in this module. Rewriting
     * the time base of a running timer would change the prescaler and the
     * auto-reload value in the middle of a period, so the call is refused
     * instead. A refused call takes no lock, changes no state and touches no
     * register. */
    if (htim->State == HAL_TIM_STATE_BUSY)
    {
        return HAL_BUSY;
    }

    /* Allocate the lock resource and initialize the low level hardware before
     * the first use (architecture rules MSP-04 and LOCK-06): the MSP callback
     * runs before the handle is locked, so an override may create the RTOS
     * mutex that TIM_LockHandle() needs and call other HAL APIs, and it runs
     * only while the handle is in the reset state, so a repeated
     * initialization does not initialize the hardware twice */
    if (htim->State == HAL_TIM_STATE_RESET)
    {
        htim->Lock = HAL_UNLOCKED;

        HAL_TIM_OnePulse_MspInit(htim);
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    htim->State = HAL_TIM_STATE_BUSY;

    /* Configure the time base */
    TIM_Base_SetConfig(htim);

    /* Configure the one pulse mode in CR1 */
    htim->Instance->CR1 &= ~((uint32)TIM_CR1_OPM);
    htim->Instance->CR1 |= OnePulseMode;

    htim->ErrorCode = HAL_TIM_ERROR_NONE;
    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  De-initializes the TIM one pulse mode. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_OnePulse_DeInit(HAL_TIM_HandleTypeDef *htim)
{
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    htim->State = HAL_TIM_STATE_BUSY;
    TIM_StopInstance(htim);
    htim->ErrorCode = HAL_TIM_ERROR_NONE;
    htim->State = HAL_TIM_STATE_RESET;

    TIM_UnlockHandle(htim);

    /* LOCK-06 / ARCH-CONST-04: the low level de-initialization runs OUTSIDE
     * the locked region, as the architecture specification requires for the
     * MSP callbacks ("MspDeInit is called after the unlock"). An override may
     * call other HAL APIs, which is only allowed while the handle lock is not
     * held. */
    HAL_TIM_OnePulse_MspDeInit(htim);

    return HAL_OK;
}

/**
 * @brief  Initializes the TIM one pulse MSP. Weak empty function.
 */
__weak void HAL_TIM_OnePulse_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    UNUSED(htim);
}

/**
 * @brief  De-initializes the TIM one pulse MSP. Weak empty function.
 */
__weak void HAL_TIM_OnePulse_MspDeInit(HAL_TIM_HandleTypeDef *htim)
{
    UNUSED(htim);
}

/**
 * @brief  Starts the one pulse generation. (NON-BLOCKING)
 * @note   The output channel and its input counterpart are both enabled.
 */
HAL_StatusTypeDef HAL_TIM_OnePulse_Start(HAL_TIM_HandleTypeDef *htim, uint32 OutputChannel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_CHANNEL(OutputChannel));

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Enable the capture compare channels 1 and 2 of the pair */
    TIM_CCxChannelCmd(htim, OutputChannel, TIM_CCx_ENABLE);
    if (OutputChannel == TIM_CHANNEL_1)
    {
        TIM_CCxChannelCmd(htim, TIM_CHANNEL_2, TIM_CCx_ENABLE);
    }
    else
    {
        TIM_CCxChannelCmd(htim, TIM_CHANNEL_1, TIM_CCx_ENABLE);
    }

    if (IS_TIM_ADV_INSTANCE(htim->Instance))
    {
        __HAL_TIM_MOE_ENABLE(htim);
    }

    __HAL_TIM_ENABLE(htim);

    htim->State = HAL_TIM_STATE_BUSY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Stops the one pulse generation. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_OnePulse_Stop(HAL_TIM_HandleTypeDef *htim, uint32 OutputChannel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_CHANNEL(OutputChannel));

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    TIM_CCxChannelCmd(htim, OutputChannel, TIM_CCx_DISABLE);
    if (OutputChannel == TIM_CHANNEL_1)
    {
        TIM_CCxChannelCmd(htim, TIM_CHANNEL_2, TIM_CCx_DISABLE);
    }
    else
    {
        TIM_CCxChannelCmd(htim, TIM_CHANNEL_1, TIM_CCx_DISABLE);
    }

    if (IS_TIM_ADV_INSTANCE(htim->Instance))
    {
        __HAL_TIM_MOE_DISABLE(htim);
    }

    __HAL_TIM_DISABLE(htim);

    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Starts the one pulse generation in interrupt mode. (NON-BLOCKING / IT)
 */
HAL_StatusTypeDef HAL_TIM_OnePulse_Start_IT(HAL_TIM_HandleTypeDef *htim, uint32 OutputChannel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_CHANNEL(OutputChannel));

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Enable the capture compare interrupts of the pair */
    __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC1);
    __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC2);

    TIM_CCxChannelCmd(htim, OutputChannel, TIM_CCx_ENABLE);
    if (OutputChannel == TIM_CHANNEL_1)
    {
        TIM_CCxChannelCmd(htim, TIM_CHANNEL_2, TIM_CCx_ENABLE);
    }
    else
    {
        TIM_CCxChannelCmd(htim, TIM_CHANNEL_1, TIM_CCx_ENABLE);
    }

    if (IS_TIM_ADV_INSTANCE(htim->Instance))
    {
        __HAL_TIM_MOE_ENABLE(htim);
    }

    __HAL_TIM_ENABLE(htim);

    htim->State = HAL_TIM_STATE_BUSY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Stops the one pulse generation in interrupt mode. (NON-BLOCKING / IT)
 */
HAL_StatusTypeDef HAL_TIM_OnePulse_Stop_IT(HAL_TIM_HandleTypeDef *htim, uint32 OutputChannel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_CHANNEL(OutputChannel));

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC1);
    __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC2);

    TIM_CCxChannelCmd(htim, OutputChannel, TIM_CCx_DISABLE);
    if (OutputChannel == TIM_CHANNEL_1)
    {
        TIM_CCxChannelCmd(htim, TIM_CHANNEL_2, TIM_CCx_DISABLE);
    }
    else
    {
        TIM_CCxChannelCmd(htim, TIM_CHANNEL_1, TIM_CCx_DISABLE);
    }

    if (IS_TIM_ADV_INSTANCE(htim->Instance))
    {
        __HAL_TIM_MOE_DISABLE(htim);
    }

    __HAL_TIM_DISABLE(htim);

    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
  * @}
  */

/** @addtogroup TIM_Exported_Functions_Group6 Encoder functions
  * @{
  */

/**
 * @brief  Initializes the TIM encoder interface. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_Encoder_Init(HAL_TIM_HandleTypeDef *htim, TIM_Encoder_InitTypeDef *sConfig)
{
    uint32 ccmr = 0U;
    uint32 ccer = 0U;
    uint32 smcr = 0U;

    if ((TIM_HandleIsValid(htim) == 0U) || (sConfig == NULL_PTR))
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_ALL_INSTANCE(htim->Instance));
    assert_param(IS_TIM_COUNTER_MODE(htim->Init.CounterMode));
    assert_param(IS_TIM_CKD_DIV(htim->Init.ClockDivision));
    assert_param(IS_TIM_ENCODER_MODE(sConfig->EncoderMode));
    assert_param(IS_TIM_IC_POLARITY(sConfig->IC1Polarity));
    assert_param(IS_TIM_IC_POLARITY(sConfig->IC2Polarity));
    assert_param(IS_TIM_IC_FILTER(sConfig->IC1Filter));
    assert_param(IS_TIM_IC_FILTER(sConfig->IC2Filter));

    /* Run time validation of the configuration structure, so that the checks
     * stay effective in a build with the assertions disabled. The metafields
     * (Size / Version, architecture spec section 22) and the reserved words are
     * validated as well, and on the general purpose timers the prescaler and the
     * period are checked against the 16 bit register width. A rejected call
     * neither takes the lock nor changes the handle state nor touches a
     * register. */
    if ((htim->Init.Size != sizeof(TIM_Base_InitTypeDef)) ||
        (htim->Init.Version != TIM_INIT_VERSION) ||
        (IS_TIM_COUNTER_MODE(htim->Init.CounterMode) == 0U) ||
        (IS_TIM_CKD_DIV(htim->Init.ClockDivision) == 0U) ||
        ((IS_TIM_GEN_INSTANCE(htim->Instance) != 0U) && (htim->Init.Prescaler > 0xFFFFU)) ||
        ((IS_TIM_GEN_INSTANCE(htim->Instance) != 0U) && (htim->Init.Period > 0xFFFFU)) ||
        (htim->Init.Reserved[0] != 0U) ||
        (htim->Init.Reserved[1] != 0U))
    {
        htim->ErrorCode |= HAL_TIM_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* A timer that is counting keeps the BUSY state set: the Start functions
     * leave it set and only the Stop functions clear it, so the state is a
     * reliable "the counter is running" indicator in this module. Rewriting
     * the time base of a running timer would change the prescaler and the
     * auto-reload value in the middle of a period, so the call is refused
     * instead. A refused call takes no lock, changes no state and touches no
     * register. */
    if (htim->State == HAL_TIM_STATE_BUSY)
    {
        return HAL_BUSY;
    }

    /* Allocate the lock resource and initialize the low level hardware before
     * the first use (architecture rules MSP-04 and LOCK-06): the MSP callback
     * runs before the handle is locked, so an override may create the RTOS
     * mutex that TIM_LockHandle() needs and call other HAL APIs, and it runs
     * only while the handle is in the reset state, so a repeated
     * initialization does not initialize the hardware twice */
    if (htim->State == HAL_TIM_STATE_RESET)
    {
        htim->Lock = HAL_UNLOCKED;

        HAL_TIM_Encoder_MspInit(htim);
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    htim->State = HAL_TIM_STATE_BUSY;

    /* Reset the slave mode controller, then configure the time base */
    htim->Instance->SMCR &= ~(uint32)(TIM_SMCR_SMS);
    TIM_Base_SetConfig(htim);

    /* Configure the encoder mode and the IC1 / IC2 inputs */
    smcr = htim->Instance->SMCR;
    smcr &= ~(uint32)(TIM_SMCR_SMS);
    smcr |= sConfig->EncoderMode;
    htim->Instance->SMCR = smcr;

    ccmr = htim->Instance->CCMR1;
    ccmr &= ~(uint32)(TIM_CCMR1_CC1S | TIM_CCMR1_IC1F | TIM_CCMR1_IC1PSC);
    /* TIM_ICPSC_xxx already carry the ICxPSC field position (bits 3:2 for the
     * low channel of the register), so channel 1 needs no shift. */
    ccmr |= (uint32)(sConfig->IC1Selection | (sConfig->IC1Filter << 4U) | (sConfig->IC1Prescaler));
    ccmr &= ~(uint32)(TIM_CCMR1_CC2S | TIM_CCMR1_IC2F | TIM_CCMR1_IC2PSC);
    /* The high channel of the register moves the ICxPSC field by 8 bits
     * (bits 3:2 -> bits 11:10), so the same rule as HAL_TIM_IC_ConfigChannel
     * applies. */
    ccmr |= (uint32)((sConfig->IC2Selection << 8U) | (sConfig->IC2Filter << 12U) | (sConfig->IC2Prescaler << 8U));
    htim->Instance->CCMR1 = ccmr;

    ccer = htim->Instance->CCER;
    ccer &= ~(uint32)(TIM_CCER_CC1P | TIM_CCER_CC1NP | TIM_CCER_CC2P | TIM_CCER_CC2NP);
    ccer |= (uint32)((sConfig->IC1Polarity) | ((sConfig->IC2Polarity) << 4U));
    htim->Instance->CCER = ccer;

    htim->ErrorCode = HAL_TIM_ERROR_NONE;
    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  De-initializes the TIM encoder interface. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_Encoder_DeInit(HAL_TIM_HandleTypeDef *htim)
{
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    htim->State = HAL_TIM_STATE_BUSY;
    TIM_StopInstance(htim);
    htim->ErrorCode = HAL_TIM_ERROR_NONE;
    htim->State = HAL_TIM_STATE_RESET;

    TIM_UnlockHandle(htim);

    /* LOCK-06 / ARCH-CONST-04: the low level de-initialization runs OUTSIDE
     * the locked region, as the architecture specification requires for the
     * MSP callbacks ("MspDeInit is called after the unlock"). An override may
     * call other HAL APIs, which is only allowed while the handle lock is not
     * held. */
    HAL_TIM_Encoder_MspDeInit(htim);

    return HAL_OK;
}

/**
 * @brief  Initializes the TIM encoder MSP. Weak empty function.
 */
__weak void HAL_TIM_Encoder_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    UNUSED(htim);
}

/**
 * @brief  De-initializes the TIM encoder MSP. Weak empty function.
 */
__weak void HAL_TIM_Encoder_MspDeInit(HAL_TIM_HandleTypeDef *htim)
{
    UNUSED(htim);
}

/**
 * @brief  Starts the encoder interface. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_Encoder_Start(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    if (Channel != TIM_CHANNEL_ALL)
    {
        TIM_CCxChannelCmd(htim, Channel, TIM_CCx_ENABLE);
    }
    else
    {
        TIM_CCxChannelCmd(htim, TIM_CHANNEL_1, TIM_CCx_ENABLE);
        TIM_CCxChannelCmd(htim, TIM_CHANNEL_2, TIM_CCx_ENABLE);
    }

    __HAL_TIM_ENABLE(htim);

    htim->State = HAL_TIM_STATE_BUSY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Stops the encoder interface. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_Encoder_Stop(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    if (Channel != TIM_CHANNEL_ALL)
    {
        TIM_CCxChannelCmd(htim, Channel, TIM_CCx_DISABLE);
    }
    else
    {
        TIM_CCxChannelCmd(htim, TIM_CHANNEL_1, TIM_CCx_DISABLE);
        TIM_CCxChannelCmd(htim, TIM_CHANNEL_2, TIM_CCx_DISABLE);
    }

    __HAL_TIM_DISABLE(htim);

    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Starts the encoder interface in interrupt mode. (NON-BLOCKING / IT)
 */
HAL_StatusTypeDef HAL_TIM_Encoder_Start_IT(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    if (Channel != TIM_CHANNEL_ALL)
    {
        __HAL_TIM_ENABLE_IT(htim, (Channel == TIM_CHANNEL_1) ? TIM_IT_CC1 : TIM_IT_CC2);
        TIM_CCxChannelCmd(htim, Channel, TIM_CCx_ENABLE);
    }
    else
    {
        __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC1);
        __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC2);
        TIM_CCxChannelCmd(htim, TIM_CHANNEL_1, TIM_CCx_ENABLE);
        TIM_CCxChannelCmd(htim, TIM_CHANNEL_2, TIM_CCx_ENABLE);
    }

    __HAL_TIM_ENABLE(htim);

    htim->State = HAL_TIM_STATE_BUSY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Stops the encoder interface in interrupt mode. (NON-BLOCKING / IT)
 */
HAL_StatusTypeDef HAL_TIM_Encoder_Stop_IT(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    if (Channel != TIM_CHANNEL_ALL)
    {
        __HAL_TIM_DISABLE_IT(htim, (Channel == TIM_CHANNEL_1) ? TIM_IT_CC1 : TIM_IT_CC2);
        TIM_CCxChannelCmd(htim, Channel, TIM_CCx_DISABLE);
    }
    else
    {
        __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC1);
        __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC2);
        TIM_CCxChannelCmd(htim, TIM_CHANNEL_1, TIM_CCx_DISABLE);
        TIM_CCxChannelCmd(htim, TIM_CHANNEL_2, TIM_CCx_DISABLE);
    }

    __HAL_TIM_DISABLE(htim);

    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
  * @}
  */

/** @addtogroup TIM_Exported_Functions_Group7 IRQ Handler
  * @{
  */

/**
 * @brief  Handle the TIM interrupts (update, CC1..CC4, trigger, break).
 * @note   The CCx handler checks the CCMR CCxS field to dispatch between
 *         the input capture and the output compare callbacks.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @retval None
 */
void HAL_TIM_IRQHandler(HAL_TIM_HandleTypeDef *htim)
{
    uint32 idx;
    uint32 channel;
    uint32 bit;

    /* Check the TIM handle allocation */
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return;
    }

    /* Update interrupt */
    if (__HAL_TIM_GET_FLAG(htim, TIM_FLAG_UPDATE) != 0U)
    {
        if (__HAL_TIM_GET_IT_SOURCE(htim, TIM_IT_UPDATE) != 0U)
        {
            __HAL_TIM_CLEAR_IT(htim, TIM_IT_UPDATE);
            htim->Channel = TIM_CHANNEL_NONE;   /* no single channel owner */
            HAL_TIM_PeriodElapsedCallback(htim);
        }
    }

    /* Trigger interrupt */
    if (__HAL_TIM_GET_FLAG(htim, TIM_FLAG_TRIGGER) != 0U)
    {
        if (__HAL_TIM_GET_IT_SOURCE(htim, TIM_IT_TRIGGER) != 0U)
        {
            __HAL_TIM_CLEAR_IT(htim, TIM_IT_TRIGGER);
            htim->Channel = TIM_CHANNEL_NONE;
            HAL_TIM_TriggerCallback(htim);
        }
    }

    /* Capture/compare interrupts. The flag and the interrupt enable of a
     * channel share the same bit index inside the high half of SR and DIER
     * (CC1..CC6 = bits 16..21), so a single loop over the six channel
     * selectors serves the general purpose timers (channels 1..4) and the
     * advanced timers (channels 1..6) with the same code. */
    for (idx = 0U; idx < 6U; idx++)
    {
        channel = (uint32)TIM_CHANNEL_1 + (idx * 4U);
        if (IS_TIM_CHANNELS(htim->Instance, channel) == 0U)
        {
            continue;
        }

        bit = (uint32)TIM_IT_CC1 << idx;   /* CCxIF and CCxIE share bit 16+idx */

        if ((__HAL_TIM_GET_FLAG(htim, bit) != 0U) &&
            (__HAL_TIM_GET_IT_SOURCE(htim, bit) != 0U))
        {
            uint32 input_mode;

            htim->Channel = channel;
            __HAL_TIM_CLEAR_IT(htim, bit);

            /* The capture/compare selection of the channel decides whether the
             * event came from the input stage or from the output stage */
            input_mode = TIM_CCxSelection(htim, idx);

            if (input_mode != 0U)
            {
                HAL_TIM_IC_CaptureCallback(htim);
            }
            else
            {
                HAL_TIM_OC_DelayElapsedCallback(htim);
                HAL_TIM_PWM_PulseFinishedCallback(htim);
            }

            htim->Channel = TIM_CHANNEL_NONE;
        }
    }

    /* Break interrupt (advanced timers only) */
    if (IS_TIM_ADV_INSTANCE(htim->Instance))
    {
        if (__HAL_TIM_GET_FLAG(htim, TIM_FLAG_BREAK) != 0U)
        {
            if (__HAL_TIM_GET_IT_SOURCE(htim, TIM_IT_BREAK) != 0U)
            {
                __HAL_TIM_CLEAR_IT(htim, TIM_IT_BREAK);
                htim->Channel = TIM_CHANNEL_NONE;
                HAL_TIM_BreakCallback(htim);
            }
        }
    }
}

/**
  * @}
  */

/** @addtogroup TIM_Exported_Functions_Group8 Peripheral Control functions
  * @{
  */

/**
 * @brief  Configures the OC channel in output compare mode. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_OC_ConfigChannel(HAL_TIM_HandleTypeDef *htim, TIM_OC_InitTypeDef *sConfig, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if ((TIM_HandleIsValid(htim) == 0U) || (sConfig == NULL_PTR))
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_CHANNELS(htim->Instance, Channel));

    /* Channels 5 and 6 only exist on the advanced timers. Reject them on the
     * general purpose instances instead of silently reconfiguring channel 4
     * (the dispatch below keeps channel 4 as the fall through case). */
    if (IS_TIM_CHANNELS(htim->Instance, Channel) == 0U)
    {
        htim->ErrorCode |= HAL_TIM_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    assert_param(IS_TIM_OC_MODE(sConfig->OCMode));
    assert_param(IS_TIM_OC_POLARITY(sConfig->OCPolarity));
    assert_param(IS_TIM_OCPRELOAD_STATE(sConfig->OCPreload));

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    htim->State = HAL_TIM_STATE_BUSY;

    switch (Channel)
    {
        case TIM_CHANNEL_1:
            TIM_OC1_SetConfig(htim, sConfig);
            break;
        case TIM_CHANNEL_2:
            TIM_OC2_SetConfig(htim, sConfig);
            break;
        case TIM_CHANNEL_3:
            TIM_OC3_SetConfig(htim, sConfig);
            break;
        case TIM_CHANNEL_5:
            TIM_OC5_SetConfig(htim, sConfig);
            break;
        case TIM_CHANNEL_6:
            TIM_OC6_SetConfig(htim, sConfig);
            break;
        default:
            TIM_OC4_SetConfig(htim, sConfig);
            break;
    }

    /* Apply the preload selection to the configured channel. The CCMR
     * registers carry two channels each, with the OCxPE bit at bit3 for the
     * low channel and at bit11 for the high one, so the bit is derived from
     * the channel selector instead of being written per channel above. */
    {
        volatile uint32 *pccmr = (volatile uint32 *)NULL_PTR;
        uint32 pe_bit = 0U;

        if ((Channel == TIM_CHANNEL_1) || (Channel == TIM_CHANNEL_2))
        {
            pccmr = &htim->Instance->CCMR1;
        }
        else if ((Channel == TIM_CHANNEL_3) || (Channel == TIM_CHANNEL_4))
        {
            pccmr = &htim->Instance->CCMR2;
        }
        else
        {
            pccmr = &htim->Instance->CCMR3;   /* channels 5 and 6 */
        }

        if ((Channel == TIM_CHANNEL_1) || (Channel == TIM_CHANNEL_3) ||
            (Channel == TIM_CHANNEL_5))
        {
            pe_bit = (uint32)TIM_CCMR1_OC1PE;   /* bit3 of the register  */
        }
        else
        {
            pe_bit = (uint32)TIM_CCMR1_OC2PE;   /* bit11 of the register */
        }

        if (sConfig->OCPreload == TIM_OCPRECONFIG_ENABLE)
        {
            *pccmr |= pe_bit;
        }
        else
        {
            *pccmr &= ~pe_bit;
        }
    }

    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Configures the OC channel in PWM mode. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_PWM_ConfigChannel(HAL_TIM_HandleTypeDef *htim, TIM_OC_InitTypeDef *sConfig, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if ((TIM_HandleIsValid(htim) == 0U) || (sConfig == NULL_PTR))
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_CHANNELS(htim->Instance, Channel));

    /* Channels 5 and 6 only exist on the advanced timers. Reject them on the
     * general purpose instances instead of silently reconfiguring channel 4
     * (the dispatch below keeps channel 4 as the fall through case). */
    if (IS_TIM_CHANNELS(htim->Instance, Channel) == 0U)
    {
        htim->ErrorCode |= HAL_TIM_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    assert_param(IS_TIM_PWM_MODE(sConfig->OCMode));
    assert_param(IS_TIM_OC_POLARITY(sConfig->OCPolarity));
    assert_param(IS_TIM_OCFAST(sConfig->OCFastMode));

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    htim->State = HAL_TIM_STATE_BUSY;

    switch (Channel)
    {
        case TIM_CHANNEL_1:
            TIM_OC1_SetConfig(htim, sConfig);
            /* Enable the OC1 preload and set / clear the OC1 fast mode */
            htim->Instance->CCMR1 |= TIM_CCMR1_OC1PE;
            if (sConfig->OCFastMode != TIM_OCFAST_DISABLE)
            {
                htim->Instance->CCMR1 |= TIM_CCMR1_OC1FE;
            }
            else
            {
                htim->Instance->CCMR1 &= ~((uint32)TIM_CCMR1_OC1FE);
            }
            break;
        case TIM_CHANNEL_2:
            TIM_OC2_SetConfig(htim, sConfig);
            htim->Instance->CCMR1 |= TIM_CCMR1_OC2PE;
            if (sConfig->OCFastMode != TIM_OCFAST_DISABLE)
            {
                htim->Instance->CCMR1 |= TIM_CCMR1_OC2FE;
            }
            else
            {
                htim->Instance->CCMR1 &= ~((uint32)TIM_CCMR1_OC2FE);
            }
            break;
        case TIM_CHANNEL_3:
            TIM_OC3_SetConfig(htim, sConfig);
            htim->Instance->CCMR2 |= TIM_CCMR2_OC3PE;
            if (sConfig->OCFastMode != TIM_OCFAST_DISABLE)
            {
                htim->Instance->CCMR2 |= TIM_CCMR2_OC3FE;
            }
            else
            {
                htim->Instance->CCMR2 &= ~((uint32)TIM_CCMR2_OC3FE);
            }
            break;
        case TIM_CHANNEL_5:
            TIM_OC5_SetConfig(htim, sConfig);
            htim->Instance->CCMR3 |= TIM_CCMR3_OC5PE;
            if (sConfig->OCFastMode != TIM_OCFAST_DISABLE)
            {
                htim->Instance->CCMR3 |= TIM_CCMR3_OC5FE;
            }
            else
            {
                htim->Instance->CCMR3 &= ~((uint32)TIM_CCMR3_OC5FE);
            }
            break;
        case TIM_CHANNEL_6:
            TIM_OC6_SetConfig(htim, sConfig);
            htim->Instance->CCMR3 |= TIM_CCMR3_OC6PE;
            if (sConfig->OCFastMode != TIM_OCFAST_DISABLE)
            {
                htim->Instance->CCMR3 |= TIM_CCMR3_OC6FE;
            }
            else
            {
                htim->Instance->CCMR3 &= ~((uint32)TIM_CCMR3_OC6FE);
            }
            break;
        default:
            TIM_OC4_SetConfig(htim, sConfig);
            htim->Instance->CCMR2 |= TIM_CCMR2_OC4PE;
            if (sConfig->OCFastMode != TIM_OCFAST_DISABLE)
            {
                htim->Instance->CCMR2 |= TIM_CCMR2_OC4FE;
            }
            else
            {
                htim->Instance->CCMR2 &= ~((uint32)TIM_CCMR2_OC4FE);
            }
            break;
    }

    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Configures the IC channel. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_IC_ConfigChannel(HAL_TIM_HandleTypeDef *htim, TIM_IC_InitTypeDef *sConfig, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if ((TIM_HandleIsValid(htim) == 0U) || (sConfig == NULL_PTR))
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_CHANNELS(htim->Instance, Channel));

    /* Channels 5 and 6 only exist on the advanced timers. Reject them on the
     * general purpose instances instead of silently reconfiguring channel 4
     * (the dispatch below keeps channel 4 as the fall through case). */
    if (IS_TIM_CHANNELS(htim->Instance, Channel) == 0U)
    {
        htim->ErrorCode |= HAL_TIM_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    assert_param(IS_TIM_IC_POLARITY(sConfig->ICPolarity));
    assert_param(IS_TIM_IC_SELECTION(sConfig->ICSelection));
    assert_param(IS_TIM_IC_PRESCALER(sConfig->ICPrescaler));
    assert_param(IS_TIM_IC_FILTER(sConfig->ICFilter));

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    htim->State = HAL_TIM_STATE_BUSY;

    /* Configure the input stage (selection, filter, polarity) */
    switch (Channel)
    {
        case TIM_CHANNEL_1:
            TIM_TI1_SetConfig(htim, sConfig->ICPolarity, sConfig->ICSelection, sConfig->ICFilter);
            /* Set the IC1 prescaler */
            htim->Instance->CCMR1 &= ~(uint32)TIM_CCMR1_IC1PSC;
            htim->Instance->CCMR1 |= (uint32)((sConfig->ICPrescaler) & TIM_CCMR1_IC1PSC);
            break;
        case TIM_CHANNEL_2:
            TIM_TI2_SetConfig(htim, sConfig->ICPolarity, sConfig->ICSelection, sConfig->ICFilter);
            htim->Instance->CCMR1 &= ~(uint32)TIM_CCMR1_IC2PSC;
            htim->Instance->CCMR1 |= (uint32)((sConfig->ICPrescaler << 8U) & TIM_CCMR1_IC2PSC);
            break;
        case TIM_CHANNEL_3:
            TIM_TI3_SetConfig(htim, sConfig->ICPolarity, sConfig->ICSelection, sConfig->ICFilter);
            htim->Instance->CCMR2 &= ~(uint32)TIM_CCMR2_IC3PSC;
            htim->Instance->CCMR2 |= (uint32)((sConfig->ICPrescaler) & TIM_CCMR2_IC3PSC);
            break;
        case TIM_CHANNEL_5:
            TIM_TI5_SetConfig(htim, sConfig->ICPolarity, sConfig->ICSelection, sConfig->ICFilter);
            htim->Instance->CCMR3 &= ~(uint32)TIM_CCMR3_IC5PSC;
            htim->Instance->CCMR3 |= (uint32)((sConfig->ICPrescaler) & TIM_CCMR3_IC5PSC);
            break;
        case TIM_CHANNEL_6:
            TIM_TI6_SetConfig(htim, sConfig->ICPolarity, sConfig->ICSelection, sConfig->ICFilter);
            htim->Instance->CCMR3 &= ~(uint32)TIM_CCMR3_IC6PSC;
            htim->Instance->CCMR3 |= (uint32)((sConfig->ICPrescaler << 8U) & TIM_CCMR3_IC6PSC);
            break;
        default:
            TIM_TI4_SetConfig(htim, sConfig->ICPolarity, sConfig->ICSelection, sConfig->ICFilter);
            htim->Instance->CCMR2 &= ~(uint32)TIM_CCMR2_IC4PSC;
            htim->Instance->CCMR2 |= (uint32)((sConfig->ICPrescaler << 8U) & TIM_CCMR2_IC4PSC);
            break;
    }

    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Configures the one pulse channel. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_OnePulse_ConfigChannel(HAL_TIM_HandleTypeDef *htim,
                                                 TIM_OnePulse_InitTypeDef *sConfig,
                                                 uint32 OutputChannel, uint32 InputChannel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if ((TIM_HandleIsValid(htim) == 0U) || (sConfig == NULL_PTR))
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_CHANNEL(OutputChannel));
    assert_param((InputChannel == TIM_CHANNEL_1) || (InputChannel == TIM_CHANNEL_2));

    /* Configure the output compare channel of the pair */
    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    htim->State = HAL_TIM_STATE_BUSY;

    /* Output channel: OC mode with the given pulse and polarities */
    {
        TIM_OC_InitTypeDef occonfig;

        occonfig.OCMode = sConfig->OCMode;
        occonfig.Pulse = sConfig->Pulse;
        occonfig.OCPolarity = sConfig->OCPolarity;
        occonfig.OCNPolarity = sConfig->OCNPolarity;
        occonfig.OCFastMode = 0U;
        /* The one pulse interface does not expose the preload: the compare
         * value is written once per pulse, so the preload selection of the
         * channel is left untouched by this path. */
        occonfig.OCPreload = TIM_OCPRECONFIG_DISABLE;
        occonfig.OCIdleState = sConfig->OCIdleState;
        occonfig.OCNIdleState = sConfig->OCNIdleState;

        if (OutputChannel == TIM_CHANNEL_1)
        {
            TIM_OC1_SetConfig(htim, &occonfig);
        }
        else
        {
            TIM_OC2_SetConfig(htim, &occonfig);
        }
    }

    /* Input channel: capture configuration (selection, polarity, filter) */
    if (InputChannel == TIM_CHANNEL_1)
    {
        TIM_TI1_SetConfig(htim, sConfig->ICPolarity, sConfig->ICSelection, sConfig->ICFilter);
    }
    else
    {
        TIM_TI2_SetConfig(htim, sConfig->ICPolarity, sConfig->ICSelection, sConfig->ICFilter);
    }

    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Configures the TI1 input (TI1S bit of CR2). (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_ConfigTI1Input(HAL_TIM_HandleTypeDef *htim, uint32 TI1_Selection)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    if (TI1_Selection != 0U)
    {
        /* Enable the XOR combination of the three inputs */
        htim->Instance->CR2 |= TIM_CR2_TI1S;
    }
    else
    {
        htim->Instance->CR2 &= ~((uint32)TIM_CR2_TI1S);
    }

    TIM_UnlockHandle(htim);

    return HAL_OK;
}


/**
 * @brief  Selects the capture/compare DMA source (CCDS bit of CR2).
 *         (NON-BLOCKING)
 * @note   On this device the capture/compare DMA request of a channel only
 *         reaches the DMA controller while CR2.CCDS is set: with the bit
 *         cleared the DIER.*DE enable and the channel event are both
 *         visible in the timer, but no request is issued and the DMA channel
 *         stays idle (measured on silicon: TIER running, DIER.CC1DE = 1,
 *         SR.CC1IF = 1, DMA channel enabled, transfer counter untouched).
 *         The bit is therefore the last step the application has to do
 *         before it starts a transfer with HAL_TIM_OC_Start_DMA() or
 *         HAL_TIM_PWM_Start_DMA(); the driver does not set it on its own,
 *         so that a timer whose DMA request must follow the update event
 *         (CR2.CCDS cleared, DIER.UDE used) keeps working unchanged.
 * @note   Same contract as the other control functions: handle and instance
 *         checked, state selected at run time, state gate applied (RESET
 *         refused, BUSY accepted because it only means that the counter is
 *         running) and the register access serialized by the handle lock.
 *         Only CR2.CCDS is modified, so every other CR2 bit (MMS, MMS2,
 *         TI1S, the channel output idle states, ...) is preserved.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  NewState: TIM_ENABLE (capture/compare event is the DMA source) or
 *         TIM_DISABLE (the bit is cleared again).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_SelectCCDMA(HAL_TIM_HandleTypeDef *htim, uint32 NewState)
{
    HAL_StatusTypeDef status = HAL_OK;

    uint32 cr2 = 0U;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_ENABLE_STATE(NewState));

    /* Run time validation of the selection, effective with the assertions
     * disabled as well (ARCH-CONST-10 / ERR-03). A rejected call touches no
     * register and leaves the handle state unchanged. */
    if (IS_TIM_ENABLE_STATE(NewState) == 0U)
    {
        htim->ErrorCode |= HAL_TIM_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    htim->ErrorCode = HAL_TIM_ERROR_NONE;

    cr2 = htim->Instance->CR2;
    if (NewState != TIM_DISABLE)
    {
        cr2 |= (uint32)TIM_CR2_CCDS;
    }
    else
    {
        cr2 &= ~((uint32)TIM_CR2_CCDS);
    }
    htim->Instance->CR2 = cr2;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}
/**
 * @brief  Configures the clock source of the timer (SMCR clock selection). (NON-BLOCKING)
 * @note   The internal / ITRx / TIx / TI1ED clock sources select the slave
 *         mode controller (SMS) and the trigger (TS) field; the external
 *         trigger modes additionally configure the ETR input stage
 *         (ETF / ETPS / ETP / ECE).
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  sClockConfig: pointer to the TIM_ClockConfigTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_ConfigClockSource(HAL_TIM_HandleTypeDef *htim, TIM_ClockConfigTypeDef *sClockConfig)
{
    HAL_StatusTypeDef status = HAL_OK;

    uint32 smcr = 0U;
    uint32 tmpcr = 0U;

    if ((TIM_HandleIsValid(htim) == 0U) || (sClockConfig == NULL_PTR))
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_CLOCK_SOURCE(sClockConfig->ClockSource));
    assert_param(IS_TIM_ETR_POLARITY(sClockConfig->ClockPolarity));
    assert_param(IS_TIM_CLOCK_PRESCALER(sClockConfig->ClockPrescaler));
    assert_param(sClockConfig->ClockFilter <= 0xFU);

    /* This device does not route the ITR2 and ITR3 internal triggers to the
     * timers, so a selection that would program an unused trigger source is
     * refused instead of being accepted and silently ignored by the hardware.
     * A refused call takes no lock and touches no register. */
    if ((sClockConfig->ClockSource == TIM_CLOCKSOURCE_ITR2) ||
        (sClockConfig->ClockSource == TIM_CLOCKSOURCE_ITR3))
    {
        htim->ErrorCode |= HAL_TIM_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    htim->State = HAL_TIM_STATE_BUSY;

    smcr = htim->Instance->SMCR;

    if (sClockConfig->ClockSource == TIM_CLOCKSOURCE_INTERNAL)
    {
        /* Internal clock: disable the external clock mode 1 and the
           slave mode controller (free-running counting) */
        htim->Instance->SMCR = 0U;
    }
    else if ((sClockConfig->ClockSource == TIM_CLOCKSOURCE_ETRMODE2) ||
             (sClockConfig->ClockSource == TIM_CLOCKSOURCE_ETRMODE1))
    {
        /* Configure the ETR input stage (ETPS / ETF / ETP) and enable the
           external clock mode according to the selected source */
        tmpcr = smcr;
        tmpcr &= ~(uint32)(TIM_SMCR_ETPS | TIM_SMCR_ETF | TIM_SMCR_ETP | TIM_SMCR_ECE | TIM_SMCR_SMS);

        if (sClockConfig->ClockSource == TIM_CLOCKSOURCE_ETRMODE1)
        {
            /* ETR clock mode 1: ETR is the slave mode clock (SMS=External1)
               and the trigger (TS=ETRF) */
            tmpcr |= (uint32)((sClockConfig->ClockPrescaler) |
                              (sClockConfig->ClockFilter << 8U) |
                              (sClockConfig->ClockPolarity) |
                              TIM_SLAVEMODE_EXTERNAL1 |
                              TIM_TS_ETRF);
        }
        else
        {
            /* ETR clock mode 2: ETR is the external clock with ECE */
            tmpcr |= (uint32)((sClockConfig->ClockPrescaler) |
                              (sClockConfig->ClockFilter << 8U) |
                              (sClockConfig->ClockPolarity) |
                              TIM_SMCR_ECE_Msk);
        }
        htim->Instance->SMCR = tmpcr;
    }
    else
    {
        /* ITRx / TI1 / TI2 / TI1ED: select the trigger and use the external
           clock mode 1 (slave mode External1) */
        tmpcr = smcr;
        tmpcr &= ~(uint32)(TIM_SMCR_TS | TIM_SMCR_SMS);
        tmpcr |= (uint32)(sClockConfig->ClockSource | TIM_SLAVEMODE_EXTERNAL1);
        htim->Instance->SMCR = tmpcr;
    }

    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Configures the OCREF clear input of an output channel. (NON-BLOCKING)
 * @note   The selected clear source is directly programmed into the channel
 *         OCxCE bit of the CCMR register (no OCCS source selection bit is
 *         available on this device).
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  sClearInputConfig: pointer to the TIM_ClearInputConfigTypeDef
 *         structure.
 * @param  Channel: the output channel (TIM_CHANNEL_1..4).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_ConfigOCrefClear(HAL_TIM_HandleTypeDef *htim, TIM_ClearInputConfigTypeDef *sClearInputConfig,
                                           uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    uint32 ce_bit = 0U;
    volatile uint32 *pCCMR = (volatile uint32 *)NULL_PTR;

    if ((TIM_HandleIsValid(htim) == 0U) || (sClearInputConfig == NULL_PTR))
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_CHANNEL(Channel));
    assert_param(IS_TIM_CLEARINPUT_STATE(sClearInputConfig->ClearInputState));
    assert_param(IS_TIM_CLEARINPUT_POLARITY(sClearInputConfig->ClearInputPolarity));
    if (sClearInputConfig->ClearInputState == TIM_CLEARINPUT_ENABLE)
    {
        assert_param(IS_TIM_CLEARINPUT_PRESCALER(sClearInputConfig->ClearInputPrescaler));
    }

    /* Only the ETR clear source is supported on this device */
    if (sClearInputConfig->ClearInputSource != TIM_CLEARINPUTSOURCE_ETR)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    htim->State = HAL_TIM_STATE_BUSY;

    /* Select the channel OCxCE bit of the CCMR register */
    if (Channel == TIM_CHANNEL_1)
    {
        pCCMR = &htim->Instance->CCMR1;
        ce_bit = TIM_CCMR1_OC1CE;
    }
    else if (Channel == TIM_CHANNEL_2)
    {
        pCCMR = &htim->Instance->CCMR1;
        ce_bit = TIM_CCMR1_OC2CE;
    }
    else if (Channel == TIM_CHANNEL_3)
    {
        pCCMR = &htim->Instance->CCMR2;
        ce_bit = TIM_CCMR2_OC3CE;
    }
    else
    {
        pCCMR = &htim->Instance->CCMR2;
        ce_bit = TIM_CCMR2_OC4CE;
    }

    if (sClearInputConfig->ClearInputState == TIM_CLEARINPUT_ENABLE)
    {
        /* Enable the OCREF clear */
        *pCCMR |= ce_bit;

        /* Configure the ETR input stage (prescaler, filter, polarity) */
        htim->Instance->SMCR &= ~(uint32)(TIM_SMCR_ETPS | TIM_SMCR_ETF | TIM_SMCR_ETP);
        htim->Instance->SMCR |= (uint32)((sClearInputConfig->ClearInputPrescaler) |
                                         (sClearInputConfig->ClearInputFilter << 8U) |
                                         (sClearInputConfig->ClearInputPolarity));
    }
    else
    {
        /* Disable the OCREF clear */
        *pCCMR &= ~((uint32)ce_bit);
    }

    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Configures the slave mode synchronization. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_SlaveConfigSynchronization(HAL_TIM_HandleTypeDef *htim, TIM_SlaveConfigTypeDef *sSlaveConfig)
{
    HAL_StatusTypeDef status = HAL_OK;

    uint32 smcr = 0U;

    if ((TIM_HandleIsValid(htim) == 0U) || (sSlaveConfig == NULL_PTR))
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_SLAVE_MODE(sSlaveConfig->SlaveMode));
    assert_param(IS_TIM_TRIGGER_SELECTION(sSlaveConfig->InputTrigger));

    /* This device does not route the ITR2 and ITR3 internal triggers to the
     * timers: the trigger selection is refused instead of being accepted and
     * silently ignored by the hardware. A refused call takes no lock and
     * touches no register. */
    if ((sSlaveConfig->InputTrigger == TIM_TS_ITR2) ||
        (sSlaveConfig->InputTrigger == TIM_TS_ITR3))
    {
        htim->ErrorCode |= HAL_TIM_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    smcr = htim->Instance->SMCR;
    smcr &= ~(uint32)(TIM_SMCR_TS | TIM_SMCR_SMS);
    smcr |= (uint32)(sSlaveConfig->InputTrigger | sSlaveConfig->SlaveMode);
    htim->Instance->SMCR = smcr;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Generates the selected events by software. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_GenerateEvent(HAL_TIM_HandleTypeDef *htim, uint32 EventSource)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_EVENT_SOURCE(EventSource));

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    htim->Instance->EGR = EventSource;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Returns the captured value of a channel. (NON-BLOCKING)
 */
uint32 HAL_TIM_ReadCapturedValue(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    uint32 capturedvalue = 0U;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return 0U;
    }

    assert_param(IS_TIM_CHANNEL(Channel));

    switch (Channel)
    {
        case TIM_CHANNEL_1:
            capturedvalue = htim->Instance->CCR1;
            break;
        case TIM_CHANNEL_2:
            capturedvalue = htim->Instance->CCR2;
            break;
        case TIM_CHANNEL_3:
            capturedvalue = htim->Instance->CCR3;
            break;
        case TIM_CHANNEL_4:
            capturedvalue = htim->Instance->CCR4;
            break;
        case TIM_CHANNEL_5:
            capturedvalue = htim->Instance->CCR5;
            break;
        case TIM_CHANNEL_6:
            capturedvalue = htim->Instance->CCR6;
            break;
        default:
            capturedvalue = 0U;
            break;
    }

    return capturedvalue;
}

/**
 * @brief  Sets the compare value of a channel. (NON-BLOCKING)
 */
void HAL_TIM_SetCompare(HAL_TIM_HandleTypeDef *htim, uint32 Compare, uint32 Channel)
{
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return;
    }

    assert_param(IS_TIM_CHANNEL(Channel));

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    if (TIM_CheckInitState(htim) != HAL_OK)
    {
        return;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    __HAL_TIM_SET_COMPARE(htim, Channel, Compare);

    TIM_UnlockHandle(htim);
}

/**
 * @brief  Sets the auto-reload value and updates the handle period. (NON-BLOCKING)
 */
void HAL_TIM_SetAutoreload(HAL_TIM_HandleTypeDef *htim, uint32 Autoreload)
{
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return;
    }

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    if (TIM_CheckInitState(htim) != HAL_OK)
    {
        return;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    __HAL_TIM_SET_AUTORELOAD(htim, Autoreload);

    TIM_UnlockHandle(htim);
}

/**
 * @brief  Sets the prescaler value. (NON-BLOCKING)
 */
void HAL_TIM_SetPrescaler(HAL_TIM_HandleTypeDef *htim, uint32 Prescaler)
{
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return;
    }

    if (IS_TIM_GEN_INSTANCE(htim->Instance))
    {
        assert_param(Prescaler <= 0xFFFFU);
    }

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    if (TIM_CheckInitState(htim) != HAL_OK)
    {
        return;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    if (IS_TIM_GEN_INSTANCE(htim->Instance))
    {
        htim->Instance->PSC = (uint32)(Prescaler & TIM_GEN_REG_MASK);
    }
    else
    {
        htim->Instance->PSC = Prescaler;
    }

    TIM_UnlockHandle(htim);
}

/**
 * @brief  Returns the current counter value. (NON-BLOCKING)
 */
uint32 HAL_TIM_GetCounter(HAL_TIM_HandleTypeDef *htim)
{
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return 0U;
    }

    return htim->Instance->CNT;
}

/**
 * @brief  Returns the current prescaler value. (NON-BLOCKING)
 */
uint32 HAL_TIM_GetPrescaler(HAL_TIM_HandleTypeDef *htim)
{
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return 0U;
    }

    return htim->Instance->PSC;
}

/**
  * @}
  */

/** @addtogroup TIM_Exported_Functions_Group9 Callbacks (weak)
  * @{
  */

/**
 * @brief  Period elapsed callback (weak empty function).
 */
__weak void HAL_TIM_PeriodElapsedCallback(HAL_TIM_HandleTypeDef *htim)
{
    UNUSED(htim);
}

/**
 * @brief  Output compare delay elapsed callback (weak empty function).
 */
__weak void HAL_TIM_OC_DelayElapsedCallback(HAL_TIM_HandleTypeDef *htim)
{
    UNUSED(htim);
}

/**
 * @brief  Input capture callback (weak empty function).
 */
__weak void HAL_TIM_IC_CaptureCallback(HAL_TIM_HandleTypeDef *htim)
{
    UNUSED(htim);
}

/**
 * @brief  PWM pulse finished callback (weak empty function).
 */
__weak void HAL_TIM_PWM_PulseFinishedCallback(HAL_TIM_HandleTypeDef *htim)
{
    UNUSED(htim);
}

/**
 * @brief  Trigger callback (weak empty function).
 */
__weak void HAL_TIM_TriggerCallback(HAL_TIM_HandleTypeDef *htim)
{
    UNUSED(htim);
}

/**
 * @brief  Error callback (weak empty function).
 */
__weak void HAL_TIM_ErrorCallback(HAL_TIM_HandleTypeDef *htim)
{
    UNUSED(htim);
}

/**
  * @}
  */

/** @addtogroup TIM_Exported_Functions_Group10 State functions
  * @{
  */

/**
 * @brief  Returns the TIM base handle state. (NON-BLOCKING)
 */
HAL_TIM_StateTypeDef HAL_TIM_Base_GetState(HAL_TIM_HandleTypeDef *htim)
{
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_TIM_STATE_RESET;
    }

    return htim->State;
}

/**
 * @brief  Returns the TIM OC handle state. (NON-BLOCKING)
 */
HAL_TIM_StateTypeDef HAL_TIM_OC_GetState(HAL_TIM_HandleTypeDef *htim)
{
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_TIM_STATE_RESET;
    }

    return htim->State;
}

/**
 * @brief  Returns the TIM PWM handle state. (NON-BLOCKING)
 */
HAL_TIM_StateTypeDef HAL_TIM_PWM_GetState(HAL_TIM_HandleTypeDef *htim)
{
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_TIM_STATE_RESET;
    }

    return htim->State;
}

/**
 * @brief  Returns the TIM IC handle state. (NON-BLOCKING)
 */
HAL_TIM_StateTypeDef HAL_TIM_IC_GetState(HAL_TIM_HandleTypeDef *htim)
{
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_TIM_STATE_RESET;
    }

    return htim->State;
}

/**
 * @brief  Returns the TIM OnePulse handle state. (NON-BLOCKING)
 */
HAL_TIM_StateTypeDef HAL_TIM_OnePulse_GetState(HAL_TIM_HandleTypeDef *htim)
{
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_TIM_STATE_RESET;
    }

    return htim->State;
}

/**
 * @brief  Returns the TIM Encoder handle state. (NON-BLOCKING)
 */
HAL_TIM_StateTypeDef HAL_TIM_Encoder_GetState(HAL_TIM_HandleTypeDef *htim)
{
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_TIM_STATE_RESET;
    }

    return htim->State;
}

/**
 * @brief  Returns the TIM error code. (NON-BLOCKING)
 */
uint32 HAL_TIM_GetError(HAL_TIM_HandleTypeDef *htim)
{
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_TIM_ERROR_NONE;
    }

    return htim->ErrorCode;
}

/**
  * @}
  */

/**
  * @}
  */

#ifdef HAL_DMA_MODULE_ENABLED

/**
 * @brief  Return the DMA handle table index of a capture/compare channel.
 * @param  Channel: TIM_CHANNEL_1..TIM_CHANNEL_6.
 * @retval The TIM_DMA_ID_CCx index of the channel.
 */
static uint32 TIM_DMA_GetDMAIndex(uint32 Channel)
{
    switch (Channel)
    {
        case TIM_CHANNEL_1:  return TIM_DMA_ID_CC1;
        case TIM_CHANNEL_2:  return TIM_DMA_ID_CC2;
        case TIM_CHANNEL_3:  return TIM_DMA_ID_CC3;
        case TIM_CHANNEL_4:  return TIM_DMA_ID_CC4;
        case TIM_CHANNEL_5:  return TIM_DMA_ID_CC5;
        default:             return TIM_DMA_ID_CC6;
    }
}

/**
 * @brief  Return the DMA burst base address (DCR.DBA) of a CC channel.
 * @param  Channel: TIM_CHANNEL_1..TIM_CHANNEL_6.
 * @retval The TIM_DMABase_CCRx value of the channel.
 */
static uint32 TIM_DMA_GetDMABase(uint32 Channel)
{
    switch (Channel)
    {
        case TIM_CHANNEL_1:  return TIM_DMABase_CCR1;
        case TIM_CHANNEL_2:  return TIM_DMABase_CCR2;
        case TIM_CHANNEL_3:  return TIM_DMABase_CCR3;
        case TIM_CHANNEL_4:  return TIM_DMABase_CCR4;
        case TIM_CHANNEL_5:  return TIM_DMABase_CCR5;
        default:             return TIM_DMABase_CCR6;
    }
}

/**
 * @brief  Return the DMA request source (DIER.*DE) of a CC channel.
 * @param  Channel: TIM_CHANNEL_1..TIM_CHANNEL_6.
 * @retval The TIM_DMA_CCx request value of the channel.
 */
static uint32 TIM_DMA_GetDMARequest(uint32 Channel)
{
    switch (Channel)
    {
        case TIM_CHANNEL_1:  return TIM_DMA_CC1;
        case TIM_CHANNEL_2:  return TIM_DMA_CC2;
        case TIM_CHANNEL_3:  return TIM_DMA_CC3;
        case TIM_CHANNEL_4:  return TIM_DMA_CC4;
        case TIM_CHANNEL_5:  return TIM_DMA_CC5;
        default:             return TIM_DMA_CC6;
    }
}

/**
 * @brief  DMA output compare process complete callback.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure.
 * @retval None
 */
static void TIM_DMAOC_DelayPulseCplt(DMA_HandleTypeDef *hdma)
{
    HAL_TIM_HandleTypeDef *htim = (HAL_TIM_HandleTypeDef *)hdma->Parent;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return;
    }

    htim->State = HAL_TIM_STATE_READY;
    HAL_TIM_OC_DelayElapsedCallback(htim);
}

/**
 * @brief  DMA PWM pulse finished process complete callback.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure.
 * @retval None
 */
static void TIM_DMAPWM_PulseFinishedCplt(DMA_HandleTypeDef *hdma)
{
    HAL_TIM_HandleTypeDef *htim = (HAL_TIM_HandleTypeDef *)hdma->Parent;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return;
    }

    htim->State = HAL_TIM_STATE_READY;
    HAL_TIM_PWM_PulseFinishedCallback(htim);
}

/**
 * @brief  DMA transfer error callback.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure.
 * @retval None
 */
static void TIM_DMAErrorCplt(DMA_HandleTypeDef *hdma)
{
    HAL_TIM_HandleTypeDef *htim = (HAL_TIM_HandleTypeDef *)hdma->Parent;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return;
    }

    htim->ErrorCode |= HAL_TIM_ERROR_TRANSFER;
    htim->State = HAL_TIM_STATE_READY;
    HAL_TIM_ErrorCallback(htim);
}

#endif /* HAL_DMA_MODULE_ENABLED */

/* Private function prototypes -----------------------------------------------*/
static void TIM_CCxNChannelCmd(HAL_TIM_HandleTypeDef *htim, uint32 Channel, uint32 ChannelNState);

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Enables or disables a complementary capture/compare channel output.
 * @note   The CCxNE bit position is derived from the channel value by the
 *         4-bit stepping of the CCER register (CC1NE:bit2, CC2NE:bit6,
 *         CC3NE:bit10, CC4NE:bit14, CC5NE:bit18, CC6NE:bit22).
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  Channel: the channel (TIM_CHANNEL_1..6).
 * @param  ChannelNState: TIM_CCxN_ENABLE or TIM_CCxN_DISABLE.
 * @retval None
 */
static void TIM_CCxNChannelCmd(HAL_TIM_HandleTypeDef *htim, uint32 Channel, uint32 ChannelNState)
{
    uint32 tmp = (uint32)TIM_CCER_CC1NE << Channel;

    /* Reset the CCxNE bit */
    htim->Instance->CCER &= ~tmp;

    /* Set or reset the CCxNE bit */
    htim->Instance->CCER |= (uint32)(ChannelNState << Channel);
}

/* Exported functions ---------------------------------------------------------*/

/** @addtogroup TIM_Exported_Functions_Group12 Complementary Output Compare / PWM functions
  * @{
  */

/**
 * @brief  Starts the complementary output compare signal generation. (NON-BLOCKING)
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  Channel: the complementary output channel (TIM_CHANNEL_1..6).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_OCN_Start(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_COMPLEMENTARY_CHANNELS(htim->Instance, Channel));
    if (IS_TIM_COMPLEMENTARY_CHANNELS(htim->Instance, Channel) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Enable the complementary output channel */
    TIM_CCxNChannelCmd(htim, Channel, TIM_CCxN_ENABLE);

    /* Enable the main outputs */
    __HAL_TIM_MOE_ENABLE(htim);

    /* Enable the TIM counter */
    __HAL_TIM_ENABLE(htim);

    htim->State = HAL_TIM_STATE_BUSY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Stops the complementary output compare signal generation. (NON-BLOCKING)
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  Channel: the complementary output channel (TIM_CHANNEL_1..6).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_OCN_Stop(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_COMPLEMENTARY_CHANNELS(htim->Instance, Channel));
    if (IS_TIM_COMPLEMENTARY_CHANNELS(htim->Instance, Channel) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    TIM_CCxNChannelCmd(htim, Channel, TIM_CCxN_DISABLE);

    __HAL_TIM_MOE_DISABLE(htim);

    __HAL_TIM_DISABLE(htim);

    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Starts the complementary output compare signal generation in (NON-BLOCKING / IT)
 *         interrupt mode.
 */
HAL_StatusTypeDef HAL_TIM_OCN_Start_IT(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_COMPLEMENTARY_CHANNELS(htim->Instance, Channel));
    if (IS_TIM_COMPLEMENTARY_CHANNELS(htim->Instance, Channel) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    switch (Channel)
    {
        case TIM_CHANNEL_1:
            __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC1);
            break;
        case TIM_CHANNEL_2:
            __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC2);
            break;
        default:
            __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC3);
            break;
    }

    /* Enable the break interrupt (advanced timers) */
    __HAL_TIM_ENABLE_IT(htim, TIM_IT_BREAK);

    TIM_CCxNChannelCmd(htim, Channel, TIM_CCxN_ENABLE);

    __HAL_TIM_MOE_ENABLE(htim);

    __HAL_TIM_ENABLE(htim);

    htim->State = HAL_TIM_STATE_BUSY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Stops the complementary output compare signal generation in (NON-BLOCKING / IT)
 *         interrupt mode.
 */
HAL_StatusTypeDef HAL_TIM_OCN_Stop_IT(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_COMPLEMENTARY_CHANNELS(htim->Instance, Channel));
    if (IS_TIM_COMPLEMENTARY_CHANNELS(htim->Instance, Channel) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    switch (Channel)
    {
        case TIM_CHANNEL_1:
            __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC1);
            break;
        case TIM_CHANNEL_2:
            __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC2);
            break;
        default:
            __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC3);
            break;
    }

    /* Disable the break interrupt when no complementary channel remains */
    if ((htim->Instance->CCER & (TIM_CCER_CC1NE | TIM_CCER_CC2NE | TIM_CCER_CC3NE)) == 0U)
    {
        __HAL_TIM_DISABLE_IT(htim, TIM_IT_BREAK);
    }

    TIM_CCxNChannelCmd(htim, Channel, TIM_CCxN_DISABLE);

    __HAL_TIM_MOE_DISABLE(htim);

    __HAL_TIM_DISABLE(htim);

    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Starts the complementary PWM signal generation. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_PWMN_Start(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_COMPLEMENTARY_CHANNELS(htim->Instance, Channel));
    if (IS_TIM_COMPLEMENTARY_CHANNELS(htim->Instance, Channel) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    TIM_CCxNChannelCmd(htim, Channel, TIM_CCxN_ENABLE);

    __HAL_TIM_MOE_ENABLE(htim);

    __HAL_TIM_ENABLE(htim);

    htim->State = HAL_TIM_STATE_BUSY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Stops the complementary PWM signal generation. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_PWMN_Stop(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_COMPLEMENTARY_CHANNELS(htim->Instance, Channel));
    if (IS_TIM_COMPLEMENTARY_CHANNELS(htim->Instance, Channel) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    TIM_CCxNChannelCmd(htim, Channel, TIM_CCxN_DISABLE);

    __HAL_TIM_MOE_DISABLE(htim);

    __HAL_TIM_DISABLE(htim);

    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Starts the complementary PWM signal generation in interrupt mode. (NON-BLOCKING / IT)
 */
HAL_StatusTypeDef HAL_TIM_PWMN_Start_IT(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_COMPLEMENTARY_CHANNELS(htim->Instance, Channel));
    if (IS_TIM_COMPLEMENTARY_CHANNELS(htim->Instance, Channel) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    switch (Channel)
    {
        case TIM_CHANNEL_1:
            __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC1);
            break;
        case TIM_CHANNEL_2:
            __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC2);
            break;
        default:
            __HAL_TIM_ENABLE_IT(htim, TIM_IT_CC3);
            break;
    }

    __HAL_TIM_ENABLE_IT(htim, TIM_IT_BREAK);

    TIM_CCxNChannelCmd(htim, Channel, TIM_CCxN_ENABLE);

    __HAL_TIM_MOE_ENABLE(htim);

    __HAL_TIM_ENABLE(htim);

    htim->State = HAL_TIM_STATE_BUSY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Stops the complementary PWM signal generation in interrupt mode. (NON-BLOCKING / IT)
 */
HAL_StatusTypeDef HAL_TIM_PWMN_Stop_IT(HAL_TIM_HandleTypeDef *htim, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_COMPLEMENTARY_CHANNELS(htim->Instance, Channel));
    if (IS_TIM_COMPLEMENTARY_CHANNELS(htim->Instance, Channel) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    switch (Channel)
    {
        case TIM_CHANNEL_1:
            __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC1);
            break;
        case TIM_CHANNEL_2:
            __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC2);
            break;
        default:
            __HAL_TIM_DISABLE_IT(htim, TIM_IT_CC3);
            break;
    }

    if ((htim->Instance->CCER & (TIM_CCER_CC1NE | TIM_CCER_CC2NE | TIM_CCER_CC3NE)) == 0U)
    {
        __HAL_TIM_DISABLE_IT(htim, TIM_IT_BREAK);
    }

    TIM_CCxNChannelCmd(htim, Channel, TIM_CCxN_DISABLE);

    __HAL_TIM_MOE_DISABLE(htim);

    __HAL_TIM_DISABLE(htim);

    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
  * @}
  */

/** @addtogroup TIM_Exported_Functions_Group13 Extended Control functions
  * @{
  */

/**
 * @brief  Configures the break and dead-time features of the advanced timer. (NON-BLOCKING)
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  sBreakDeadTimeConfig: pointer to the
 *         TIM_BreakDeadTimeConfigTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_ConfigBreakDeadTime(HAL_TIM_HandleTypeDef *htim,
                                                TIM_BreakDeadTimeConfigTypeDef *sBreakDeadTimeConfig)
{
    HAL_StatusTypeDef status = HAL_OK;

    uint32 tmpbdtr = 0U;

    if ((TIM_HandleIsValid(htim) == 0U) || (sBreakDeadTimeConfig == NULL_PTR))
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_ADV_INSTANCE(htim->Instance));
    assert_param(IS_TIM_OSSSR_STATE(sBreakDeadTimeConfig->OffStateRunMode));
    assert_param(IS_TIM_OSSSI_STATE(sBreakDeadTimeConfig->OffStateIDLEMode));
    assert_param(IS_TIM_LOCK_LEVEL(sBreakDeadTimeConfig->LockLevel));
    assert_param(IS_TIM_DEADTIME(sBreakDeadTimeConfig->DeadTime));
    assert_param(IS_TIM_BREAK_STATE(sBreakDeadTimeConfig->BreakState));
    assert_param(IS_TIM_BREAK_POLARITY(sBreakDeadTimeConfig->BreakPolarity));
    assert_param(IS_TIM_BREAK_FILTER(sBreakDeadTimeConfig->BreakFilter));
    assert_param(IS_TIM_AUTOMATIC_OUTPUT_STATE(sBreakDeadTimeConfig->AutomaticOutput));

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    htim->State = HAL_TIM_STATE_BUSY;

    /* Set the lock level, dead-time, off-state, break and automatic output
       fields of the BDTR register (the MOE bit is cleared by this write) */
    tmpbdtr = (uint32)((sBreakDeadTimeConfig->DeadTime) |
                       (sBreakDeadTimeConfig->LockLevel) |
                       (sBreakDeadTimeConfig->OffStateIDLEMode) |
                       (sBreakDeadTimeConfig->OffStateRunMode) |
                       (sBreakDeadTimeConfig->BreakState) |
                       (sBreakDeadTimeConfig->BreakPolarity) |
                       ((sBreakDeadTimeConfig->BreakFilter) << TIM_BREAK_FILTER_Pos) |
                       (sBreakDeadTimeConfig->AutomaticOutput));

    htim->Instance->BDTR = tmpbdtr;

    htim->State = HAL_TIM_STATE_READY;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Configures the master output triggers (TRGO and TRGO2) of the timer.
 *         (NON-BLOCKING)
 * @note   CR2.MMS receives MasterOutputTrigger (any instance) and CR2.MMS2
 *         receives MasterOutputTrigger2 (advanced timers only); both fields are
 *         programmed in the same locked read modify write access. The
 *         master-slave mode field (MSM) is not present on this device: the
 *         MasterSlaveMode field of the configuration structure is therefore
 *         ignored.
 * @note   A real TRGO2 source on a general purpose timer (TIM3 / TIM4 / TIM6 /
 *         TIM7, which have no CR2.MMS2 field) is refused with HAL_ERROR and
 *         HAL_TIM_ERROR_INVALID_PARAM before the lock is taken, so no register
 *         is written; TIM_TRGO2_RESET is accepted on every instance because it
 *         is the neutral value written by HAL_TIM_MasterConfig_StructInit().
 */
HAL_StatusTypeDef HAL_TIM_MasterConfigSynchronization(HAL_TIM_HandleTypeDef *htim,
                                                        TIM_MasterConfigTypeDef *sMasterConfig)
{
    HAL_StatusTypeDef status = HAL_OK;

    uint32 cr2 = 0U;

    if ((TIM_HandleIsValid(htim) == 0U) || (sMasterConfig == NULL_PTR))
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_TRGO_SOURCE(sMasterConfig->MasterOutputTrigger));
    assert_param(IS_TIM_TRGO2_SOURCE(sMasterConfig->MasterOutputTrigger2));

    /* Run time validation of the second master output: it only exists on the
     * advanced timers, so a real source on a general purpose timer is refused
     * before the lock and before any register access (ARCH-CONST-10 / ERR-03). */
    if ((sMasterConfig->MasterOutputTrigger2 != TIM_TRGO2_RESET) &&
        (IS_TIM_ADV_INSTANCE(htim->Instance) == 0U))
    {
        htim->ErrorCode |= HAL_TIM_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    cr2 = htim->Instance->CR2;

    /* Configure the TRGO output (CR2.MMS), keep the other CR2 bits */
    cr2 &= ~(uint32)TIM_CR2_MMS;
    cr2 |= sMasterConfig->MasterOutputTrigger;

    /* Configure the second master output (CR2.MMS2) on the advanced timers;
     * the field does not exist on a general purpose timer, where only the
     * neutral TIM_TRGO2_RESET reached this point (see the validation above) */
    if (IS_TIM_ADV_INSTANCE(htim->Instance) != 0U)
    {
        cr2 &= ~(uint32)TIM_CR2_MMS2;
        cr2 |= sMasterConfig->MasterOutputTrigger2;
    }

    htim->Instance->CR2 = cr2;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Sets the second master output trigger (TRGO2, CR2.MMS2) alone.
 *         (NON-BLOCKING)
 * @note   Same contract as HAL_TIM_MasterConfigSynchronization(): handle and
 *         instance checked, source validated at run time, state gate applied
 *         (RESET refused, BUSY accepted) and the register access serialized by
 *         the handle lock. Only CR2.MMS2 is modified, so the TRGO selection
 *         (CR2.MMS) and every other CR2 bit are preserved.
 * @note   TRGO2 only exists on the advanced timers (TIM0 / TIM1 / TIM2 / TIM5):
 *         a real source on a general purpose timer is refused with HAL_ERROR
 *         and HAL_TIM_ERROR_INVALID_PARAM before the lock, without touching the
 *         register; TIM_TRGO2_RESET is accepted everywhere (neutral value).
 */
HAL_StatusTypeDef HAL_TIM_SetMasterOutputTrigger2(HAL_TIM_HandleTypeDef *htim,
                                                  uint32 MasterOutputTrigger2)
{
    HAL_StatusTypeDef status = HAL_OK;

    uint32 cr2 = 0U;

    if (TIM_HandleIsValid(htim) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_TIM_TRGO2_SOURCE(MasterOutputTrigger2));

    /* Run time validation: the source must be one of the sixteen encodings and
     * a real source needs an advanced instance (ARCH-CONST-10 / ERR-03) */
    if ((IS_TIM_TRGO2_SOURCE(MasterOutputTrigger2) == 0U) ||
        ((MasterOutputTrigger2 != TIM_TRGO2_RESET) &&
         (IS_TIM_ADV_INSTANCE(htim->Instance) == 0U)))
    {
        htim->ErrorCode |= HAL_TIM_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: the handle must have been initialized; BUSY is accepted
     * because it only means that the counter is running */
    status = TIM_CheckInitState(htim);
    if (status != HAL_OK)
    {
        return status;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    htim->ErrorCode = HAL_TIM_ERROR_NONE;

    cr2 = htim->Instance->CR2;
    cr2 &= ~(uint32)TIM_CR2_MMS2;
    cr2 |= MasterOutputTrigger2;
    htim->Instance->CR2 = cr2;

    TIM_UnlockHandle(htim);

    return HAL_OK;
}

/**
 * @brief  Enables or disables the main outputs (MOE bit). (NON-BLOCKING)
 */
void HAL_TIM_CtrlPWMOutputs(HAL_TIM_HandleTypeDef *htim, uint32 NewState)
{
    if (TIM_HandleIsValid(htim) == 0U)
    {
        return;
    }

    assert_param(IS_TIM_ADV_INSTANCE(htim->Instance));

    /* ARCH-CONST-09: reject the call when the handle has not been initialized
     * (one of the initialization functions is required first). The BUSY state
     * is accepted on purpose: in this module it means that the counter is
     * running (the Start functions leave it set) and not that an operation is
     * ongoing, so Stop / SetCompare / configuration calls stay usable while
     * the timer runs. */
    if (TIM_CheckInitState(htim) != HAL_OK)
    {
        return;
    }

    if (TIM_LockHandle(htim, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    if (NewState != TIM_DISABLE)
    {
        __HAL_TIM_MOE_ENABLE(htim);
    }
    else
    {
        /* Unconditional: the main outputs must stop even while the
           channel outputs are still enabled (emergency stop) */
        __HAL_TIM_MOE_DISABLE_UNCONDITIONALLY(htim);
    }

    TIM_UnlockHandle(htim);
}

/**
  * @}
  */

/** @addtogroup TIM_Exported_Functions_Group14 Extended Callbacks (weak)
  * @{
  */

/**
 * @brief  Break interrupt callback (weak empty function).
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_TIM_BreakCallback(HAL_TIM_HandleTypeDef *htim)
{
    UNUSED(htim);
}

/**
  * @}
  */

/**
  * @}
  */

#endif /* HAL_TIM_MODULE_ENABLED */

/*****END OF FILE*****/