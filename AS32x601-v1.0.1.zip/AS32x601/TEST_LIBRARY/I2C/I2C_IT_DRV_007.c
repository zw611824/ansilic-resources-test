/**
 * @file    I2C_IT_DRV_007.c
 * @brief   HAL I2C integration test case 007 (read-write sequence at 100 kHz).
 *
 * One-to-one HAL library port of the original AS32x601 standard-library test
 * case I2C_IT_DRV_007.c. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_I2C_StructInit() / HAL_I2C_Init()      (I2C1 as a master)
 *   HAL_I2C_ITStructInit() / HAL_I2C_ITInit()  (TXEN and RXEN sources)
 *   HAL_PLIC_Init()                            (I2C1_IRQn)
 *   HAL_I2C_Cmd()                              (disable / enable between the
 *                                               two phases)
 *   HAL_I2C_GenerateStart / Send7bitAddress / StartClear / AcknowledgeConfig /
 *   SendData / ReceiveData / GenerateStop / CheckStatus / ClearITPendingBit
 *   HAL_I2C_GetState() / HAL_I2C_GetError()
 *
 * Test procedure:
 *   1. Apply the standard clock tree (PLL 180 MHz) and initialize the console;
 *   2. Configure I2C1 as a master at 100K, route I2C1_IRQn through the
 *      PLIC and enable both the transmit and the receive interrupt source;
 *   3. Phase 1: start a read from slave address 0x55 and print the 64 bytes the
 *      handler stores;
 *   4. Phase 2: disable and re-enable the controller with HAL_I2C_Cmd() (the
 *      original test case cleared and set the enable bit directly), then start
 *      a write of the 64 bytes 0x00..0x3F;
 *   5. Report both phases and the register read back.
 *
 * Expected behaviour:
 *   - phase 1 prints "I2C Master Read Success!" and the 64 received bytes
 *     (16 per line); phase 2 prints "I2C Master Write Success!" and
 *     "Sent 64 bytes: 0x00-0x3F";
 *   - with no slave at 0x55 both phases report a failure instead of hanging
 *     (the handler releases the bus on a not-acknowledge);
 *   - the console prints "=== Read-Write Sequence Test Complete ===" and the
 *     last line reads "summary : failures = N".
 *
 * Notes (deliberate adaptations of this port):
 *   - the bus sequence is driven from the application with the interrupt safe
 *     low level group of the driver (HAL_I2C_GenerateStart / GenerateStop /
 *     StartClear / Send7bitAddress / AcknowledgeConfig / SendData /
 *     ReceiveData / GetFlagStatus / CheckStatus), exactly as the original test
 *     case used its I2C_xxx primitives; those functions take no lock and have
 *     no state gate, so they are callable from the interrupt handler
 *     (ARCH-CONST-19 / LOCK-04);
 *   - the handler of this port also answers an address / data not-acknowledge
 *     by releasing the bus and raising the error flag, so a missing peer
 *     terminates the case instead of starving the interrupt;
 *   - the divider values are recomputed for this library's clock tree:
 *     I2C clock = PCLK / 8 / DIV, 2.8125 MHz / 28 = 100.4 kHz.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Budget of one blocking transfer */
#define TEST_TIMEOUT_MS             (1000U)

/* Standard clock tree (the same tree the other HAL integration suites use) */
#define STD_PLL_DIV_R               (0x04U)
#define STD_PLL_DIV_Q               (0x01U)
#define STD_PLL_DIV_N               (0x14U)
#define STD_PLL_DIV_F               (0xB4U)
#define STD_AXI4BUS3_DIV            SMU_AXI4BUS3CLK_DIV2
#define STD_APBBUS0_DIV             SMU_APBBUS0CLK_DIV2
#define STD_APBBUS1_DIV             SMU_APBBUS1CLK_DIV2
#define STD_CANX2_DIV               SMU_CANX2CLK_DIV8

/* ---------------------- parameters of this test case --------------------- */
#define TEST_I2C                    I2C1
#define TEST_SCL_PORT               GPIOF
#define TEST_SCL_PIN                GPIO_PIN_15
#define TEST_SCL_SOURCE             GPIO_PinSource15
#define TEST_SDA_PORT               GPIOF
#define TEST_SDA_PIN                GPIO_PIN_13
#define TEST_SDA_SOURCE             GPIO_PinSource13
#define TEST_AF                     GPIO_AF_IIC1

/* Own slave address and peer (slave) address of the original test case */
#define TEST_OWN_ADDRESS            (0x5AU)
#define TEST_PEER_ADDRESS           (0x55U)

/* Transfer size of the original test case */
#define TEST_SIZE                   (64U)

/* Divider values for a 22.5 MHz APB clock: I2C clock = APB / 8 = 2.8125 MHz,
 * DIV 28 -> 100.4 kHz, DIV 7 -> 401.8 kHz */
#define TEST_DIV_100K               (0x1CU)
#define TEST_DIV_400K               (0x07U)
#define TEST_DIV_H                  (0x00U)

/* Number of rate rounds */
#define TEST_ROUNDS                 (2U)


/* Budget of the blocking phases of the case (PLIC setup, clock tree) */
#define TEST_TIMEOUT_MS             (1000U)

/* Bounded waits inside the interrupt handler: the bus stages must complete
 * within this many polling rounds, otherwise the case reports an error */
#define TEST_ISR_SPINS              (100000U)

/* Rounds the main loop spins while the interrupt handler completes the
 * transfer (about 1 s at 180 MHz for 64 bytes at 100 kHz) */
#define TEST_WAIT_SPINS             (200000000U)
/* Private variables -------------------------------------------------------*/
static I2C_HandleTypeDef hi2c_dev;          /*!< I2C handle                   */
static HAL_PMU_HandleTypeDef hpmu_dev;      /*!< PMU handle (LDO scaler)      */
static uint8  I2C_BufferTx[TEST_SIZE];      /*!< transmit buffer              */
static uint8  I2C_BufferRx[TEST_SIZE];      /*!< receive buffer               */
static uint32 g_failures;                   /*!< collected failures           */



static volatile uint32 g_dir;               /*!< I2C_READ / I2C_WRITE         */
static volatile uint32 g_index;             /*!< byte index of the transfer   */
static volatile uint32 g_done;              /*!< transfer completed           */
static volatile uint32 g_error;             /*!< transfer failed              */
/* Private function prototypes ---------------------------------------------*/
static void   SystemClock_Init(void);
static void   I2C_Config(uint32 Divider);
static void   Buffer_Init(void);
static uint32 Chk(const char *name, uint32 expect, uint32 actual);
static void   Info(const char *name, uint32 value);

static void   Print_RxBuffer(void);
static void   Interrupt_Config(void);
static void   I2C_MasterStart(uint8 DevAddress, uint32 Direction);
/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    uint32 spins;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);

    printf("\r\n=== I2C_IT_DRV_007: read-write sequence at 100 kHz ===\r\n");

    Buffer_Init();

    /* Configure the peripheral and both interrupt sources of the sequence */
    I2C_Config(TEST_DIV_100K);
    Interrupt_Config();
    printf("I2C1 configured at 100K (divider: 0x%02X)\r\n", PRINT_U32(TEST_DIV_100K));

    /* ---------------- Phase 1: master read ---------------- */
    printf("\r\n=== Phase 1: I2C Master Read Test ===\r\n");
    printf("Starting I2C Master Read from slave address 0x55 with interrupt enabled...\r\n");

    g_index = 0U;
    g_done  = 0U;
    g_error = 0U;
    I2C_MasterStart(TEST_PEER_ADDRESS, I2C_READ);

    spins = 0U;
    while ((g_done == 0U) && (spins < TEST_WAIT_SPINS))
    {
        spins++;
    }

    if ((g_done != 0U) && (g_error == 0U))
    {
        printf("I2C Master Read Success!\r\n");
        printf("Received Data:\r\n");
        Print_RxBuffer();
    }
    else
    {
        printf("I2C Master Read Failed! (done=%u, error=%u)\r\n",
               PRINT_U32(g_done), PRINT_U32(g_error));
    }

    /* ---------------- Phase 2: master write ---------------- */
    /* The original test case disables and re-enables the controller between the
     * two phases; HAL_I2C_Cmd() does exactly that */
    printf("\r\n=== Phase 2: I2C Master Write Test ===\r\n");

    g_failures += Chk("HAL_I2C_Cmd(DISABLE) returns HAL_OK",
                      (uint32)HAL_OK, (uint32)HAL_I2C_Cmd(&hi2c_dev, DISABLE));
    g_failures += Chk("HAL_I2C_Cmd(ENABLE) returns HAL_OK",
                      (uint32)HAL_OK, (uint32)HAL_I2C_Cmd(&hi2c_dev, ENABLE));
    g_failures += Chk("controller enabled again", 1U,
                      (uint32)((TEST_I2C->CTLR & I2C_CTRL_EN) ? 1U : 0U));

    printf("Starting I2C Master Write to slave address 0x55 with interrupt enabled...\r\n");

    g_index = 0U;
    g_done  = 0U;
    g_error = 0U;
    I2C_MasterStart(TEST_PEER_ADDRESS, I2C_WRITE);

    spins = 0U;
    while ((g_done == 0U) && (spins < TEST_WAIT_SPINS))
    {
        spins++;
    }

    if ((g_done != 0U) && (g_error == 0U))
    {
        printf("I2C Master Write Success!\r\n");
        printf("Sent 64 bytes: 0x00-0x3F\r\n");
    }
    else
    {
        printf("I2C Master Write Failed! (done=%u, error=%u)\r\n",
               PRINT_U32(g_done), PRINT_U32(g_error));
    }

    printf("\r\n=== Read-Write Sequence Test Complete ===\r\n");

    /* Configuration read back */
    g_failures += Chk("DIV_L holds the selected divider", (uint32)TEST_DIV_100K,
                      (uint32)TEST_I2C->DIV_L);
    g_failures += Chk("handle state is READY", (uint32)HAL_I2C_STATE_READY,
                      (uint32)HAL_I2C_GetState(&hi2c_dev));
    g_failures += Chk("both interrupt sources enabled",
                      (uint32)((I2C_IRQC_TXEN | I2C_IRQC_RXNEN) >> 0),
                      (uint32)(TEST_I2C->IRQC & (I2C_IRQC_TXEN | I2C_IRQC_RXNEN)));
    Info("error code =", HAL_I2C_GetError(&hi2c_dev));

    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(g_failures));

    while (1)
    {
    }
}

/**
 * @brief  Initialize the clock tree, the SMU / PMU handles and the bus gates.
 * @note   Dividers first (the system clock is still the FIRC), then
 *         HAL_SMU_OscConfig(), which programs the flash controller clock,
 *         switches the system clock and performs the flash clock update.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    osc;
    SMU_ClockInitTypeDef  clk;
    HAL_SMU_HandleTypeDef hsmu;
    SMU_ClocksTypeDef     clocks;

    /* Bus clock gates used by this case */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();

    /* PMU: the LDO APIs are gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu_dev);
    hpmu_dev.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu_dev);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu_dev, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu_dev, PMU_VO12_1V34);

    /* SMU handle */
    __HAL_CLEAR_STRUCT(&hsmu);
    hsmu.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu);

    /* Bus dividers of the standard tree */
    __HAL_CLEAR_STRUCT(&clk);
    clk.Size           = sizeof(clk);
    clk.Version        = SMU_CLOCK_INIT_VERSION;
    clk.AXI4Bus3CLKDiv = STD_AXI4BUS3_DIV;
    clk.APBBus0CLKDiv  = STD_APBBUS0_DIV;
    clk.APBBus1CLKDiv  = STD_APBBUS1_DIV;
    clk.CANX2CLKDiv    = STD_CANX2_DIV;
    (void)HAL_SMU_ClockConfig(&hsmu, &clk);

    /* PLL from the OSC, then switch the system clock to it */
    __HAL_CLEAR_STRUCT(&osc);
    osc.Size                 = sizeof(osc);
    osc.Version              = SMU_OSC_INIT_VERSION;
    osc.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    osc.FIRCState            = SMU_FIRC_ON;
    osc.FIRCCalibrationValue = 0x00U;
    osc.PLL.Size             = sizeof(osc.PLL);
    osc.PLL.Version          = SMU_PLL_INIT_VERSION;
    osc.PLL.PLLState         = SMU_PLL_ON;
    osc.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    osc.PLL.PLLDivR          = STD_PLL_DIV_R;
    osc.PLL.PLLDivQ          = STD_PLL_DIV_Q;
    osc.PLL.PLLDivN          = STD_PLL_DIV_N;
    osc.PLL.PLLDivF          = STD_PLL_DIV_F;
    osc.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;
    (void)HAL_SMU_OscConfig(&hsmu, &osc, SMU_TIMEOUT_DEFAULT);

    (void)HAL_SMU_GetClocksFreq(&clocks);
}

/**
 * @brief  Low level initialization of the I2C peripheral (weak override).
 * @note   The driver calls this from HAL_I2C_Init() before the first register
 *         access and only while the handle is in the RESET state (MSP-04 /
 *         LOCK-06), so the clock gate and the pin multiplexing are in place in
 *         time.  Every round de-initializes the handle first, which is what
 *         makes the callback run again for the second rate.
 * @param  hi2c: I2C handle.
 * @retval None
 */
void HAL_I2C_MspInit(I2C_HandleTypeDef *hi2c)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    if (hi2c->Instance != TEST_I2C)
    {
        return;
    }

    /* Peripheral clock gate and a reset pulse */
    __HAL_SMU_IIC1_CLK_ENABLE();
    __HAL_SMU_IIC1_FORCE_RESET();
    __HAL_SMU_IIC1_RELEASE_RESET();

    /* GPIO port clock of the two pins */
    __HAL_SMU_GPIOF_CLK_ENABLE();

    /* Alternate function mapping */
    HAL_GPIO_PinAFConfig(TEST_SCL_PORT, TEST_SCL_SOURCE, TEST_AF);
    HAL_GPIO_PinAFConfig(TEST_SDA_PORT, TEST_SDA_SOURCE, TEST_AF);

    /* SCL and SDA: alternate function, open drain (pulled up on the bus) */
    __HAL_CLEAR_STRUCT(&GPIO_InitStruct);
    GPIO_InitStruct.Size         = sizeof(GPIO_InitStruct);
    GPIO_InitStruct.Version      = GPIO_INIT_VERSION;
    GPIO_InitStruct.Pin          = TEST_SCL_PIN;
    GPIO_InitStruct.Mode         = GPIO_MODE_AF_OD;
    GPIO_InitStruct.Pull         = GPIO_PULLUP;
    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;
    GPIO_InitStruct.Alternate    = TEST_AF;
    HAL_GPIO_Init(TEST_SCL_PORT, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = TEST_SDA_PIN;
    HAL_GPIO_Init(TEST_SDA_PORT, &GPIO_InitStruct);
}

/**
 * @brief  Low level de-initialization of the I2C peripheral (weak override).
 * @param  hi2c: I2C handle.
 * @retval None
 */
void HAL_I2C_MspDeInit(I2C_HandleTypeDef *hi2c)
{
    if (hi2c->Instance != TEST_I2C)
    {
        return;
    }

    __HAL_SMU_IIC1_CLK_DISABLE();
}

/**
 * @brief  Initialize the I2C peripheral with the selected divider.
 * @param  Divider: value written to the low divider register.
 * @retval None
 */
static void I2C_Config(uint32 Divider)
{
    I2C_InitTypeDef I2C_InitStruct;

    __HAL_CLEAR_STRUCT(&I2C_InitStruct);
    I2C_InitStruct.Size             = sizeof(I2C_InitStruct);
    I2C_InitStruct.Version          = I2C_INIT_VERSION;
    I2C_InitStruct.I2C_ClockScale   = I2C_CLOCKSCALE_PCLK_8;
    I2C_InitStruct.I2C_ICLKDIVL     = (uint8)Divider;
    I2C_InitStruct.I2C_ICLKDIVH     = (uint8)TEST_DIV_H;
    I2C_InitStruct.I2C_EN           = I2C_ENABLE;
    I2C_InitStruct.I2C_SlaveAddress = TEST_OWN_ADDRESS;
    I2C_InitStruct.I2C_Ack          = I2C_ACK;

    hi2c_dev.Instance = TEST_I2C;
    hi2c_dev.Init     = I2C_InitStruct;
    (void)HAL_I2C_Init(&hi2c_dev);
}

/**
 * @brief  Fill the transmit buffer with 0x00..0x3F.
 * @param  None
 * @retval None
 */
static void Buffer_Init(void)
{
    uint16 index;

    for (index = 0U; index < TEST_SIZE; index++)
    {
        I2C_BufferTx[index] = (uint8)index;
    }
}

/**
 * @brief  Print the receive buffer, 16 bytes per line.
 * @param  None
 * @retval None
 */
static void Print_RxBuffer(void)
{
    uint16 index;

    for (index = 0U; index < TEST_SIZE; index++)
    {
        printf("0x%02X ", PRINT_U32(I2C_BufferRx[index]));

        if (((index + 1U) % 16U) == 0U)
        {
            printf("\r\n");
        }
    }
    printf("\r\n");
}

/**
 * @brief  Route the I2C interrupt and enable the interrupt source of the case.
 * @param  None
 * @retval None
 */
static void Interrupt_Config(void)
{
    PLIC_InitTypeDef plic;
    I2C_IRQTypeDef  irq;

    /* PLIC: enable the I2C interrupt line */
    __HAL_CLEAR_STRUCT(&plic);
    plic.Size               = sizeof(plic);
    plic.Version            = PLIC_INIT_VERSION;
    plic.PLIC_IRQChannel    = I2C1_IRQn;
    plic.PLIC_IRQPriority   = 1U;
    plic.PLIC_IRQChannelCmd = ENABLE;
    (void)HAL_PLIC_Init(&plic);

    /* Peripheral interrupt source */
    HAL_I2C_ITStructInit(&irq);
    irq.ERRN = I2C_DISABLE;
    irq.SIEN = I2C_DISABLE;
    irq.TXEN = I2C_ENABLE;
    irq.RXEN = I2C_ENABLE;
    (void)HAL_I2C_ITInit(&hi2c_dev, &irq);
}

/**
 * @brief  Start a master transfer: bus release, START, address, direction.
 * @note   Application level sequence built from the interrupt safe low level
 *         APIs of the driver.
 * @param  DevAddress: 7-bit slave address.
 * @param  Direction: I2C_READ or I2C_WRITE.
 * @retval None
 */
static void I2C_MasterStart(uint8 DevAddress, uint32 Direction)
{
    uint32 spins = 0U;

    g_dir = Direction;

    /* Wait for a released bus, aborting a stuck one */
    while (HAL_I2C_CheckStatus(&hi2c_dev, I2C_STATE_BUS_IDLE) == 0U)
    {
        HAL_I2C_StartClear(&hi2c_dev);
        HAL_I2C_GenerateStop(&hi2c_dev);
        HAL_I2C_ClearITPendingBit(&hi2c_dev);

        if (++spins > TEST_ISR_SPINS)
        {
            g_error = 1U;
            g_done  = 1U;
            return;
        }
    }

    /* START and address */
    HAL_I2C_GenerateStart(&hi2c_dev);

    spins = 0U;
    while (HAL_I2C_CheckStatus(&hi2c_dev, I2C_STATE_MASTER_START_READY) == 0U)
    {
        if (++spins > TEST_ISR_SPINS)
        {
            g_error = 1U;
            g_done  = 1U;
            return;
        }
    }

    HAL_I2C_Send7bitAddress(&hi2c_dev, DevAddress, Direction);
    HAL_I2C_StartClear(&hi2c_dev);
    HAL_I2C_ClearITPendingBit(&hi2c_dev);

    if (Direction == I2C_READ)
    {
        spins = 0U;
        while (HAL_I2C_CheckStatus(&hi2c_dev, I2C_STATE_MSEND_RADDR_ACK) == 0U)
        {
            if (++spins > TEST_ISR_SPINS)
            {
                g_error = 1U;
                g_done  = 1U;
                return;
            }
        }

        HAL_I2C_AcknowledgeConfig(&hi2c_dev, I2C_ACK);
        HAL_I2C_ClearITPendingBit(&hi2c_dev);
    }
}

/**
 * @brief  I2C1 interrupt handler (I2C1_IRQ_Handler, weak symbol of the trap entry).
 * @note   Interrupt context: no lock, only the interrupt safe low level APIs.
 * @param  None
 * @retval None
 */
void I2C1_IRQ_Handler(void)
{
    if (g_dir == I2C_WRITE)
    {
        if (HAL_I2C_CheckStatus(&hi2c_dev, I2C_STATE_MSEND_WADDR_ACK) != 0U)
        {
            /* Address accepted: send the first byte */
            HAL_I2C_SendData(&hi2c_dev, I2C_BufferTx[g_index]);
            g_index++;
            HAL_I2C_ClearITPendingBit(&hi2c_dev);
        }
        else if (HAL_I2C_CheckStatus(&hi2c_dev, I2C_STATE_MSEND_DATA_ACK) != 0U)
        {
            if (g_index < TEST_SIZE)
            {
                HAL_I2C_SendData(&hi2c_dev, I2C_BufferTx[g_index]);
                g_index++;
                HAL_I2C_ClearITPendingBit(&hi2c_dev);
            }
            else
            {
                /* Last byte acknowledged: release the bus */
                HAL_I2C_ClearITPendingBit(&hi2c_dev);
                HAL_I2C_GenerateStop(&hi2c_dev);
                g_index = 0U;
                g_done  = 1U;
            }
        }
        else
        {
            /* Address / data not acknowledged, or the arbitration was lost */
            HAL_I2C_GenerateStop(&hi2c_dev);
            HAL_I2C_ClearITPendingBit(&hi2c_dev);
            g_index = 0U;
            g_error = 1U;
            g_done  = 1U;
        }
    }
    else
    {
        uint32 spins = 0U;

        if (HAL_I2C_CheckStatus(&hi2c_dev, I2C_STATE_MREAD_DATA_ACK) != 0U)
        {
            I2C_BufferRx[g_index] = HAL_I2C_ReceiveData(&hi2c_dev);
            g_index++;
        }

        if (g_index == (TEST_SIZE - 1U))
        {
            /* Next byte is the last one: answer with a NACK and stop */
            HAL_I2C_AcknowledgeConfig(&hi2c_dev, I2C_NACK);
            HAL_I2C_ClearITPendingBit(&hi2c_dev);

            while (HAL_I2C_CheckStatus(&hi2c_dev, I2C_STATE_MREAD_DATA_NACK) == 0U)
            {
                if (++spins > TEST_ISR_SPINS)
                {
                    g_error = 1U;
                    g_done  = 1U;
                    return;
                }
            }

            I2C_BufferRx[g_index] = HAL_I2C_ReceiveData(&hi2c_dev);
            g_index++;
            HAL_I2C_GenerateStop(&hi2c_dev);
            HAL_I2C_ClearITPendingBit(&hi2c_dev);
            g_index = 0U;
            g_done  = 1U;
        }
        else if (g_index < TEST_SIZE)
        {
            HAL_I2C_AcknowledgeConfig(&hi2c_dev, I2C_ACK);
            HAL_I2C_ClearITPendingBit(&hi2c_dev);
        }
        else
        {
            HAL_I2C_GenerateStop(&hi2c_dev);
            HAL_I2C_ClearITPendingBit(&hi2c_dev);
            g_index = 0U;
            g_error = 1U;
            g_done  = 1U;
        }
    }
}

/**
 * @brief  Print one check and return the number of failures it contributes.
 * @param  name: check description.
 * @param  expect: expected value.
 * @param  actual: value read back.
 * @retval uint32: 0 when the check passed, 1 otherwise.
 */
static uint32 Chk(const char *name, uint32 expect, uint32 actual)
{
    uint32 fail = 0U;

    if (expect == actual)
    {
        printf("  [PASS] %s : expect %u, read %u\r\n",
               name, PRINT_U32(expect), PRINT_U32(actual));
    }
    else
    {
        printf("  [FAIL] %s : expect %u, read %u\r\n",
               name, PRINT_U32(expect), PRINT_U32(actual));
        fail = 1U;
    }

    return fail;
}

/**
 * @brief  Print a value without judging it.
 * @param  name: label.
 * @param  value: value to print.
 * @retval None
 */
static void Info(const char *name, uint32 value)
{
    printf("  [info] %s %u\r\n", name, PRINT_U32(value));
}

/*****END OF FILE*****/
