/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      core_riscv.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.7
 * Date:   2026/10/08
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/04     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.1     fix MISA_X bit value; drop
 *                                                       HighTec branch; complete
 *                                                       macro sets; double-level
 *                                                       stringization for CSR ops;
 *                                                       add debug CSR symbols
 *     ANSILIC APPLICATION GROUP  2026/09/07     1.2     complete the CSR symbol
 *                                                       set against the RISC-V
 *                                                       privileged ISA v1.12
 *                                                       (2021-12-03): add the
 *                                                       U-mode CSRs, the
 *                                                       supervisor exception /
 *                                                       interrupt delegation,
 *                                                       senvcfgh, the top-level
 *                                                       interrupt CSRs (sstopi /
 *                                                       vsstopi / mtopi / mstopi),
 *                                                       vsenvcfg / vsenvcfgh and
 *                                                       the trigger CSRs
 *                                                       (mcontrol6 / mcontrol /
 *                                                       icount / itrigger /
 *                                                       etrigger / ttextra32 /
 *                                                       ttextra64); fix the
 *                                                       MSTATUS_UBE misplacement
 *                                                       (bit 6 is HPIE in RV32
 *                                                       mstatus); add the
 *                                                       mstatush bit fields, the
 *                                                       full misa letter bits and
 *                                                       the mcause interrupt
 *                                                       exception codes
 *     ANSILIC APPLICATION GROUP  2026/09/07     1.3     complete the CSR key
 *                                                       field definitions: the
 *                                                       missing mcause exception
 *                                                       codes, the SGEI interrupt
 *                                                       code, the mie / mip bit
 *                                                       masks, the satp field
 *                                                       masks (SV32), the pmpcfg
 *                                                       encodings, the menvcfg
 *                                                       bits and the stvec mode
 *                                                       bits; add the SRET / MRET
 *                                                       / FENCE / FENCE_I
 *                                                       instruction primitives
 *     ANSILIC APPLICATION GROUP  2026/09/07     1.4     add the v1.12 state-enable
 *                                                       CSRs (mstateen0..3 /
 *                                                       mstateen0h..3h / hstateen0..3
 *                                                       / hstateen0h..3h /
 *                                                       sstateen0 / sstateen0h /
 *                                                       vsstateen0 / vsstateen0h)
 *                                                       and the counter
 *                                                       configuration CSRs
 *                                                       (mcyclecfg / minstretcfg /
 *                                                       mcyclecfgh /
 *                                                       minstretcfgh); fix the
 *                                                       mcause exception codes
 *                                                       (drop the non-standard
 *                                                       ecall-from-VS code 0x0A,
 *                                                       set the virtual
 *                                                       instruction code to
 *                                                       0x12); add the sstatus /
 *                                                       hstatus / mcountinhibit
 *                                                       bit fields
 *     ANSILIC APPLICATION GROUP  2026/09/07     1.5     add the CLEAR_CACHE()
 *                                                       instruction primitive
 *                                                       (custom R-type encoding
 *                                                       ".insn r 0x0F,5,0,
 *                                                       x0,x0,x0"), used by the
 *                                                       MAC driver for cache
 *                                                       coherence before DMA
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.6     make NULL_PTR usable from C++ as
 *                                                       well: the definition is selected by
 *                                                       language, because a void pointer to
 *                                                       zero does not convert implicitly to a
 *                                                       typed pointer in C++. The value is
 *                                                       unchanged, only the type of the
 *                                                       expression differs
 *     ANSILIC APPLICATION GROUP  2026/10/08     1.7     complete the CSR symbol
 *                                                       directory against the
 *                                                       standard spellings: fix
 *                                                       the out-of-range
 *                                                       CSR_VSSTOPI address
 *                                                       (0x1DB0 -> 0xEB0); add the
 *                                                       PMP entries 16..63 and
 *                                                       PMPCFG 4..15, the *H high
 *                                                       halves, the Smstateen
 *                                                       correct spellings and the
 *                                                       Smrnmi / Smcsrind / AIA /
 *                                                       Smctr / Ssdbltrp symbols,
 *                                                       keeping the previous
 *                                                       spellings as
 *                                                       compatibility aliases; make
 *                                                       the compiler
 *                                                       identification chain
 *                                                       exclusive so IAR no longer
 *                                                       selects the GCC marker;
 *                                                       give the void CSR
 *                                                       operations do-while bodies
 *                                                       and the read-modify-write
 *                                                       ones separate in/out
 *                                                       operands; clear
 *                                                       mstatus.MIE in
 *                                                       __restore_irq() on a zero
 *                                                       saved state; parenthesise
 *                                                       the UNUSED() and
 *                                                       set_32bit_addr() arguments
 * Description:     This file contains the RISC-V core CSR register definitions,
 *                  the compiler abstraction and the platform data type definitions
 *                  for the firmware library.
 */
#ifndef CORE_RISCV_H
#define CORE_RISCV_H

#ifdef __cplusplus
extern "C" {
#endif

/******************************************************************************
 *  COMPILER IDENTIFICATION DEFINITIONS
 *****************************************************************************/
/*
 * @brief  Compiler identification: exactly one marker is emitted for the
 *         recognized compiler.  The tests are exclusive because the IAR
 *         RISC-V compiler also predefines __GNUC__, so independent #ifdef
 *         blocks would define two markers at once and would let the GCC
 *         abstraction set take part in the selection.
 */
#if defined(__ICCRISCV__)
    /**
     * @brief Symbol required to be defined when IAR compiler is used.
     */
    #define _IAR_C_AS32x601_
#elif defined(__ghs__)
    /**
     * @brief Symbol required to be defined when GreenHills compiler is used.
     */
    #define _GREENHILLS_C_AS32x601_
#elif defined(__DCC__)
    /**
     * @brief Symbol required to be defined when Diab compiler is used.
     */
    #define _DIABDATA_C_AS32x601_
#elif defined(__MWERKS__)
    /**
     * @brief Symbol required to be defined when Codewarrior compiler is used.
     */
    #define _CODEWARRIOR_C_AS32x601_
#elif (defined(__GNUC__) && defined(__riscv))
    /**
     * @brief Symbol required to be defined when GCC compiler is used.
     */
    #define _GCC_C_AS32x601_
#endif /* __ICCRISCV__ / __ghs__ / __DCC__ / __MWERKS__ / __GNUC__ */

/******************************************************************************
 *  COMPILER ABSTRACTION DEFINITIONS
 *****************************************************************************/
/*
 * @brief  Stringification helpers (two levels so that macro arguments are
 *         expanded before being stringized).
 *         Used to turn symbolic CSR names (e.g. CSR_MSTATUS -> 0x300) into
 *         numeric strings accepted by the assembler, and to build _Pragma
 *         operands such as "data_alignment=<n>".
 */
#define CORE_RISCV_STR2(x)  #x
#define CORE_RISCV_STR(x)   CORE_RISCV_STR2(x)

/**
 * @brief The compiler abstraction shall provide the NULL_PTR define with a
 *        null pointer constant definition.
 * @note  C spells it as a void pointer to zero. C++ does not convert that
 *        expression to a typed pointer implicitly, so it uses its own null
 *        pointer constant; the value is the same in both languages, only the
 *        type of the expression differs, which keeps the define usable for
 *        pointer initialisation, assignment and comparison from C as well as
 *        from C++.
 */
#ifdef __cplusplus
    #define NULL_PTR 0
#else
    #define NULL_PTR ((void *)0)
#endif /* __cplusplus */

/*
 * @brief  Register IO permission definitions.
 */
#ifdef __cplusplus
#define __I volatile /* Define the read only permission */
#else
#define __I volatile const /* Define the read only permission */
#endif
#define __O  volatile /* Define the write only permission */
#define __IO volatile /* Define read/write permissions */

/*-------------------------------- Green Hills ---------------------------------*/
#ifdef _GREENHILLS_C_AS32x601_
    #define INLINE              __inline
    #define LOCAL_INLINE        static __inline
    #define INTERRUPT_FUNC      __interrupt
    #define ASM_KEYWORD         __asm
    #define ASMV_KEYWORD        __asm volatile
    #define ALIGNED_VARS_START(sec_name, align)
    #define VAR_ALIGN(v, size)  __attribute__((aligned(size))) v;
    #define ALIGNED_VARS_STOP()
    #define PACKED              __packed
#endif /* _GREENHILLS_C_AS32x601_ */

/*------------------------------- Wind River Diab -------------------------------*/
#ifdef _DIABDATA_C_AS32x601_
    #define INLINE              inline __attribute__((always_inline))
    #define LOCAL_INLINE        static inline __attribute__((always_inline))
#ifdef __clang__
    #define INTERRUPT_FUNC      __attribute__((interrupt))
#else
    #define INTERRUPT_FUNC      __interrupt__
#endif /* __clang__ */
    #define ASM_KEYWORD         __asm
    #define ASMV_KEYWORD        __asm volatile
    #define ALIGNED_VARS_START(sec_name, align)
    #define VAR_ALIGN(v, size)  __attribute__((aligned(size))) v;
    #define ALIGNED_VARS_STOP()
    #define PACKED              __attribute__((packed))
#endif /* _DIABDATA_C_AS32x601_ */

/*--------------------------------- CodeWarrior ---------------------------------*/
#ifdef _CODEWARRIOR_C_AS32x601_
    #define INLINE              inline
    #define LOCAL_INLINE        static inline
    #define INTERRUPT_FUNC      __declspec(interrupt nowarn)
    #define ASM_KEYWORD         asm
    #define ASMV_KEYWORD        asm volatile
    #define ALIGNED_VARS_START(sec_name, align)
    #define VAR_ALIGN(v, size)  v __attribute__((aligned(size)));
    #define ALIGNED_VARS_STOP()
    #define PACKED              __packed
#endif /* _CODEWARRIOR_C_AS32x601_ */

/*------------------------------------ GCC --------------------------------------*/
#ifdef _GCC_C_AS32x601_
    #define INLINE              inline __attribute__((always_inline))
    #define LOCAL_INLINE        static inline __attribute__((always_inline))
    #define INTERRUPT_FUNC
    #define ASM_KEYWORD         __asm__
    #define ASMV_KEYWORD        __asm__ volatile
    #define ALIGNED_VARS_START(sec_name, align)
    #define VAR_ALIGN(v, size)  __attribute__((aligned(size))) v;
    #define ALIGNED_VARS_STOP()
    #define PACKED              __attribute__((__packed__))
#endif /* _GCC_C_AS32x601_ */

/*------------------------------------ IAR --------------------------------------*/
#ifdef _IAR_C_AS32x601_
    #define INLINE              inline __attribute__((always_inline))
    #define LOCAL_INLINE        static inline __attribute__((always_inline))
    #define INTERRUPT_FUNC      __interrupt
    #define ASM_KEYWORD         __asm
    #define ASMV_KEYWORD        __asm volatile
    #define ALIGNED_VARS_START(sec_name, align)
    #define VAR_ALIGN(v, size)  _Pragma(CORE_RISCV_STR(data_alignment=size)) \
                                v;
    #define ALIGNED_VARS_STOP()
    #define PACKED              __packed
#endif /* _IAR_C_AS32x601_ */

/******************************************************************************
 *  PLATFORM DATA TYPE DEFINITIONS
 *****************************************************************************/
#define CPU_TYPE_8 8
#define CPU_TYPE_16 16
#define CPU_TYPE_32 32
#define CPU_TYPE_64 64

#define MSB_FIRST 0
#define LSB_FIRST 1

#define HIGH_BYTE_FIRST 0
#define LOW_BYTE_FIRST 1

#define CPU_TYPE (CPU_TYPE_32)
#define CPU_BIT_ORDER (LSB_FIRST)
#define CPU_BYTE_ORDER (LOW_BYTE_FIRST)

#ifndef TRUE
    #define TRUE 1
#endif /* TRUE */

#ifndef FALSE
    #define FALSE 0
#endif /* FALSE */

#if (CPU_TYPE == CPU_TYPE_64)
typedef unsigned char uint8;
typedef uint8 boolean;
typedef unsigned short uint16;
typedef unsigned int uint32;
typedef unsigned long long uint64;
typedef signed char sint8;
typedef signed short sint16;
typedef signed int sint32;
typedef signed long long sint64;
typedef unsigned char uint8_least;
typedef unsigned short uint16_least;
typedef unsigned int uint32_least;
typedef signed char sint8_least;
typedef signed short sint16_least;
typedef signed int sint32_least;
typedef float float32;
typedef double float64;

#elif (CPU_TYPE == CPU_TYPE_32)
typedef unsigned char uint8;
typedef uint8 boolean;
typedef unsigned short uint16;
typedef unsigned long uint32;
typedef unsigned long long uint64;
typedef signed char sint8;
typedef signed short sint16;
typedef signed long sint32;
typedef signed long long sint64;
typedef unsigned char uint8_least;
typedef unsigned short uint16_least;
typedef unsigned long uint32_least;
typedef signed char sint8_least;
typedef signed short sint16_least;
typedef signed long sint32_least;
typedef float float32;
typedef double float64;

#elif (CPU_TYPE == CPU_TYPE_16)
typedef unsigned char uint8;
typedef uint8 boolean;
typedef unsigned short uint16;
typedef unsigned long uint32;
typedef unsigned long long uint64;
typedef signed char sint8;
typedef signed short sint16;
typedef signed long sint32;
typedef signed long long sint64;
typedef unsigned char uint8_least;
typedef unsigned short uint16_least;
typedef unsigned long uint32_least;
typedef signed char sint8_least;
typedef signed short sint16_least;
typedef signed long sint32_least;
typedef float float32;
typedef double float64;

#endif /* (CPU_TYPE == CPU_TYPE_64) */

/******************************************************************************
 *  COMMON UTILITY MACROS
 *****************************************************************************/
/*
 * @brief  Avoid compiler warnings for unused variables/parameters.
 */
#define UNUSED(X) ((void)(X))

/******************************************************************************
 *  REGISTER ACCESS AND BIT OPERATION MACROS
 *****************************************************************************/
/*
 * @defgroup  Read/write Specifies the address and read/write register definition.
 */
#define set_32bit_addr(addr, offset, value) (*(volatile uint32 *)((addr) + (offset)) = (value))
#define get_32bit_addr(addr, offset) (*(volatile uint32 *)((addr) + (offset)))

/*
 * @brief  Generic bit manipulation macros (register size independent).
 */
#define SET_BIT(REG, BIT)                   ((REG) |= (BIT))
#define CLEAR_BIT(REG, BIT)                 ((REG) &= ~(BIT))
#define READ_BIT(REG, BIT)                  ((REG) & (BIT))
#define CLEAR_REG(REG)                      ((REG) = (0x0))
#define WRITE_REG(REG, VAL)                 ((REG) = (VAL))
#define READ_REG(REG)                       ((REG))
#define MODIFY_REG(REG, CLEARMASK, SETMASK) WRITE_REG((REG), (((READ_REG(REG)) & (~(CLEARMASK))) | (SETMASK)))

/******************************************************************************
 *  RISC-V CSR REGISTER ADDRESS DEFINITIONS
 *****************************************************************************/
/* User-Level CSRs */
#define CSR_USTATUS             0x000   /* User status register (reserved for the N extension) */
#define CSR_UIE                 0x004   /* User interrupt-enable register (reserved for N ext.) */
#define CSR_UTVEC               0x005   /* User trap handler base address (reserved for N ext.) */
#define CSR_UTVT                0x007   /* User-level utvt register. */
#define CSR_SSP                 0x011   /* User-level ssp register. */
#define CSR_SEED                0x015   /* User-level seed register. */
#define CSR_JVT                 0x017   /* User-level jvt register. */
#define CSR_USCRATCH            0x040   /* Scratch register for user trap handlers (reserved) */
#define CSR_UEPC                0x041   /* User exception program counter (reserved for N ext.) */
#define CSR_UCAUSE              0x042   /* User trap cause (reserved for N ext.) */
#define CSR_UTVAL               0x043   /* User bad address or instruction (reserved for N ext.) */
#define CSR_UIP                 0x044   /* User interrupt pending (reserved for N ext.) */
#define CSR_UNXTI               0x045   /* User-level unxti register. */
#define CSR_UINTSTATUS          0x046   /* User-level uintstatus register. */
#define CSR_USCRATCHCSW         0x048   /* User-level uscratchcsw register. */
#define CSR_USCRATCHCSWL        0x049   /* User-level uscratchcswl register. */
#define CSR_FFLAGS              0x001   /* Floating-Point Accrued Exceptions */
#define CSR_FRM                 0x002   /* Floating-Point Dynamic Rounding Mode */
#define CSR_FCSR                0x003   /* Floating-Point Control and Status Register */
#define CSR_VSTART              0x008   /* Vector start position */
#define CSR_VXSAT               0x009   /* Vector fixed-point saturate flag */
#define CSR_VXRM                0x00A   /* Vector fixed-point rounding mode */
#define CSR_VCSR                0x00F   /* Vector control and status register */
#define CSR_VL                  0xC20   /* Vector length */
#define CSR_VTYPE               0xC21   /* Vector data type register */
#define CSR_VLENB               0xC22   /* VLEN in bytes */
#define CSR_MTYPE               0xC23   /* User-level mtype register. */
#define CSR_CYCLE               0xC00   /* Cycle counter for RDCYCLE instruction */
#define CSR_TIME                0xC01   /* Timer for RDTIME instruction */
#define CSR_INSTRET             0xC02   /* Instructions-retired counter */
#define CSR_HPMCOUNTER3         0xC03   /* Performance-monitoring counter 3 */
#define CSR_HPMCOUNTER4         0xC04   /* Performance-monitoring counter 4 */
#define CSR_HPMCOUNTER5         0xC05   /* Performance-monitoring counter 5 */
#define CSR_HPMCOUNTER6         0xC06   /* Performance-monitoring counter 6 */
#define CSR_HPMCOUNTER7         0xC07   /* Performance-monitoring counter 7 */
#define CSR_HPMCOUNTER8         0xC08   /* Performance-monitoring counter 8 */
#define CSR_HPMCOUNTER9         0xC09   /* Performance-monitoring counter 9 */
#define CSR_HPMCOUNTER10        0xC0A   /* Performance-monitoring counter 10 */
#define CSR_HPMCOUNTER11        0xC0B   /* Performance-monitoring counter 11 */
#define CSR_HPMCOUNTER12        0xC0C   /* Performance-monitoring counter 12 */
#define CSR_HPMCOUNTER13        0xC0D   /* Performance-monitoring counter 13 */
#define CSR_HPMCOUNTER14        0xC0E   /* Performance-monitoring counter 14 */
#define CSR_HPMCOUNTER15        0xC0F   /* Performance-monitoring counter 15 */
#define CSR_HPMCOUNTER16        0xC10   /* Performance-monitoring counter 16 */
#define CSR_HPMCOUNTER17        0xC11   /* Performance-monitoring counter 17 */
#define CSR_HPMCOUNTER18        0xC12   /* Performance-monitoring counter 18 */
#define CSR_HPMCOUNTER19        0xC13   /* Performance-monitoring counter 19 */
#define CSR_HPMCOUNTER20        0xC14   /* Performance-monitoring counter 20 */
#define CSR_HPMCOUNTER21        0xC15   /* Performance-monitoring counter 21 */
#define CSR_HPMCOUNTER22        0xC16   /* Performance-monitoring counter 22 */
#define CSR_HPMCOUNTER23        0xC17   /* Performance-monitoring counter 23 */
#define CSR_HPMCOUNTER24        0xC18   /* Performance-monitoring counter 24 */
#define CSR_HPMCOUNTER25        0xC19   /* Performance-monitoring counter 25 */
#define CSR_HPMCOUNTER26        0xC1A   /* Performance-monitoring counter 26 */
#define CSR_HPMCOUNTER27        0xC1B   /* Performance-monitoring counter 27 */
#define CSR_HPMCOUNTER28        0xC1C   /* Performance-monitoring counter 28 */
#define CSR_HPMCOUNTER29        0xC1D   /* Performance-monitoring counter 29 */
#define CSR_HPMCOUNTER30        0xC1E   /* Performance-monitoring counter 30 */
#define CSR_HPMCOUNTER31        0xC1F   /* Performance-monitoring counter 31 */
#define CSR_CYCLEH              0xC80   /* Upper 32 bits of cycle, RV32 only */
#define CSR_TIMEH               0xC81   /* Upper 32 bits of time, RV32 only */
#define CSR_INSTRETH            0xC82   /* Upper 32 bits of instret, RV32 only */
#define CSR_HPMCOUNTER3H        0xC83   /* Upper 32 bits of hpmcounter3, RV32 only */
#define CSR_HPMCOUNTER4H        0xC84   /* Upper 32 bits of hpmcounter4, RV32 only */
#define CSR_HPMCOUNTER5H        0xC85   /* Upper 32 bits of hpmcounter5, RV32 only */
#define CSR_HPMCOUNTER6H        0xC86   /* Upper 32 bits of hpmcounter6, RV32 only */
#define CSR_HPMCOUNTER7H        0xC87   /* Upper 32 bits of hpmcounter7, RV32 only */
#define CSR_HPMCOUNTER8H        0xC88   /* Upper 32 bits of hpmcounter8, RV32 only */
#define CSR_HPMCOUNTER9H        0xC89   /* Upper 32 bits of hpmcounter9, RV32 only */
#define CSR_HPMCOUNTER10H       0xC8A   /* Upper 32 bits of hpmcounter10, RV32 only */
#define CSR_HPMCOUNTER11H       0xC8B   /* Upper 32 bits of hpmcounter11, RV32 only */
#define CSR_HPMCOUNTER12H       0xC8C   /* Upper 32 bits of hpmcounter12, RV32 only */
#define CSR_HPMCOUNTER13H       0xC8D   /* Upper 32 bits of hpmcounter13, RV32 only */
#define CSR_HPMCOUNTER14H       0xC8E   /* Upper 32 bits of hpmcounter14, RV32 only */
#define CSR_HPMCOUNTER15H       0xC8F   /* Upper 32 bits of hpmcounter15, RV32 only */
#define CSR_HPMCOUNTER16H       0xC90   /* Upper 32 bits of hpmcounter16, RV32 only */
#define CSR_HPMCOUNTER17H       0xC91   /* Upper 32 bits of hpmcounter17, RV32 only */
#define CSR_HPMCOUNTER18H       0xC92   /* Upper 32 bits of hpmcounter18, RV32 only */
#define CSR_HPMCOUNTER19H       0xC93   /* Upper 32 bits of hpmcounter19, RV32 only */
#define CSR_HPMCOUNTER20H       0xC94   /* Upper 32 bits of hpmcounter20, RV32 only */
#define CSR_HPMCOUNTER21H       0xC95   /* Upper 32 bits of hpmcounter21, RV32 only */
#define CSR_HPMCOUNTER22H       0xC96   /* Upper 32 bits of hpmcounter22, RV32 only */
#define CSR_HPMCOUNTER23H       0xC97   /* Upper 32 bits of hpmcounter23, RV32 only */
#define CSR_HPMCOUNTER24H       0xC98   /* Upper 32 bits of hpmcounter24, RV32 only */
#define CSR_HPMCOUNTER25H       0xC99   /* Upper 32 bits of hpmcounter25, RV32 only */
#define CSR_HPMCOUNTER26H       0xC9A   /* Upper 32 bits of hpmcounter26, RV32 only */
#define CSR_HPMCOUNTER27H       0xC9B   /* Upper 32 bits of hpmcounter27, RV32 only */
#define CSR_HPMCOUNTER28H       0xC9C   /* Upper 32 bits of hpmcounter28, RV32 only */
#define CSR_HPMCOUNTER29H       0xC9D   /* Upper 32 bits of hpmcounter29, RV32 only */
#define CSR_HPMCOUNTER30H       0xC9E   /* Upper 32 bits of hpmcounter30, RV32 only */
#define CSR_HPMCOUNTER31H       0xC9F   /* Upper 32 bits of hpmcounter31, RV32 only */

/* Supervisor-Level CSRs */
#define CSR_SSTATUS             0x100   /* Supervisor status register */
#define CSR_SEDELEG             0x102   /* Supervisor exception delegation register */
#define CSR_SIDELEG             0x103   /* Supervisor interrupt delegation register */
#define CSR_SIE                 0x104   /* Supervisor interrupt-enable register */
#define CSR_STVEC               0x105   /* Supervisor trap handler base address */
#define CSR_SCOUNTEREN          0x106   /* Supervisor counter enable */
#define CSR_STVT                0x107   /* Supervisor-level stvt register. */
#define CSR_SENVCFG             0x10A   /* Supervisor environment configuration register */
#define CSR_SENVCFGH            0x11A   /* Additional supervisor env. conf. register, RV32 only */
#define CSR_SIEH                0x114   /* Supervisor-level sieh register. */
#define CSR_SSTATEEN0           0x10C   /* Supervisor state enable 0 (v1.12, Smstateen) */
#define CSR_SSTATEEN1           0x10D   /* Supervisor-level sstateen1 register. */
#define CSR_SSTATEEN2           0x10E   /* Supervisor-level sstateen2 register. */
#define CSR_SSTATEEN3           0x10F   /* Supervisor-level sstateen3 register. */
#define CSR_SCOUNTINHIBIT       0x120   /* Supervisor-level scountinhibit register. */
#define CSR_SSTATEEN0H          0x11C   /* Upper 32 bits of sstateen0, RV32 only (v1.12) */
#define CSR_SSCRATCH            0x140   /* Scratch register for supervisor trap handlers */
#define CSR_SEPC                0x141   /* Supervisor exception program counter */
#define CSR_SCAUSE              0x142   /* Supervisor trap cause */
#define CSR_STVAL               0x143   /* Supervisor bad address or instruction */
#define CSR_SIP                 0x144   /* Supervisor interrupt pending */
#define CSR_SNXTI               0x145   /* Supervisor-level snxti register. */
#define CSR_SINTSTATUS          0x146   /* Supervisor-level sintstatus register. */
#define CSR_SSCRATCHCSW         0x148   /* Supervisor-level sscratchcsw register. */
#define CSR_SSCRATCHCSWL        0x149   /* Supervisor-level sscratchcswl register. */
#define CSR_STIMECMP            0x14D   /* Supervisor-level stimecmp register. */
#define CSR_SCTRCTL             0x14E   /* Supervisor-level sctrctl register. */
#define CSR_SCTRSTATUS          0x14F   /* Supervisor-level sctrstatus register. */
#define CSR_SISELECT            0x150   /* Supervisor-level siselect register. */
#define CSR_SIREG               0x151   /* Supervisor-level sireg register. */
#define CSR_SIREG2              0x152   /* Supervisor-level sireg2 register. */
#define CSR_SIREG3              0x153   /* Supervisor-level sireg3 register. */
#define CSR_SIPH                0x154   /* Supervisor-level siph register. */
#define CSR_SIREG4              0x155   /* Supervisor-level sireg4 register. */
#define CSR_SIREG5              0x156   /* Supervisor-level sireg5 register. */
#define CSR_SIREG6              0x157   /* Supervisor-level sireg6 register. */
#define CSR_STOPEI              0x15C   /* Supervisor-level stopei register. */
#define CSR_STIMECMPH           0x15D   /* Supervisor-level stimecmph register. */
#define CSR_SCTRDEPTH           0x15F   /* Supervisor-level sctrdepth register. */
#define CSR_SATP                0x180   /* Supervisor address translation and protection */
#define CSR_SRMCFG              0x181   /* Supervisor-level srmcfg register. */
#define CSR_SPMPEN              0x183   /* Supervisor-level spmpen register. */
#define CSR_SPMPENH             0x193   /* Supervisor-level spmpenh register. */
#define CSR_SCONTEXT            0x5A8   /* Supervisor mode trigger context register */
#define CSR_SCOUNTOVF           0xDA0   /* Supervisor counter overflow (v1.12) */
#define CSR_STOPI               0xDB0   /* Supervisor top-level interrupt pending (v1.12) */

/* Hypervisor-Level CSRs */
#define CSR_VSSTATUS            0x200   /* Virtual supervisor status register */
#define CSR_VSENVCFG            0x20A   /* Virtual supervisor environment configuration register */
#define CSR_VSENVCFGH           0x21A   /* Additional VS env. conf. register, RV32 only */
#define CSR_VSIEH               0x214   /* Hypervisor and virtual-supervisor-level vsieh register. */
#define CSR_VSSTATEN0           0x20C   /* Virtual supervisor state enable 0 (v1.12, Smstateen) */
#define CSR_VSSTATEN0H          0x21C   /* Upper 32 bits of vsstateen0, RV32 only (v1.12) */
#define CSR_VSIE                0x204   /* Virtual supervisor interrupt-enable register */
#define CSR_VSTVEC              0x205   /* Virtual supervisor trap handler base address */
#define CSR_VSSCRATCH           0x240   /* Virtual supervisor scratch register */
#define CSR_VSEPC               0x241   /* Virtual supervisor exception program counter */
#define CSR_VSCAUSE             0x242   /* Virtual supervisor trap cause */
#define CSR_VSTVAL              0x243   /* Virtual supervisor bad address or instruction */
#define CSR_VSIP                0x244   /* Virtual supervisor interrupt pending */
#define CSR_VSATP               0x280   /* Virtual supervisor address translation and protection */
#define CSR_VSTIMECMP           0x24D   /* Hypervisor and virtual-supervisor-level vstimecmp register. */
#define CSR_VSCTRCTL            0x24E   /* Hypervisor and virtual-supervisor-level vsctrctl register. */
#define CSR_VSISELECT           0x250   /* Hypervisor and virtual-supervisor-level vsiselect register. */
#define CSR_VSIREG              0x251   /* Hypervisor and virtual-supervisor-level vsireg register. */
#define CSR_VSIREG2             0x252   /* Hypervisor and virtual-supervisor-level vsireg2 register. */
#define CSR_VSIREG3             0x253   /* Hypervisor and virtual-supervisor-level vsireg3 register. */
#define CSR_VSIPH               0x254   /* Hypervisor and virtual-supervisor-level vsiph register. */
#define CSR_VSIREG4             0x255   /* Hypervisor and virtual-supervisor-level vsireg4 register. */
#define CSR_VSIREG5             0x256   /* Hypervisor and virtual-supervisor-level vsireg5 register. */
#define CSR_VSIREG6             0x257   /* Hypervisor and virtual-supervisor-level vsireg6 register. */
#define CSR_VSTOPEI             0x25C   /* Hypervisor and virtual-supervisor-level vstopei register. */
#define CSR_VSTIMECMPH          0x25D   /* Hypervisor and virtual-supervisor-level vstimecmph register. */
#define CSR_VSTOPI              0xEB0   /* Virtual supervisor top-level interrupt pending (v1.12) */
#define CSR_HSTATUS             0x600   /* Hypervisor status register */
#define CSR_HEDELEG             0x602   /* Hypervisor exception delegation register */
#define CSR_HIDELEG             0x603   /* Hypervisor interrupt delegation register */
#define CSR_HIE                 0x604   /* Hypervisor interrupt-enable register */
#define CSR_HCOUNTEREN          0x606   /* Hypervisor counter enable */
#define CSR_HGEIE               0x607   /* Hypervisor guest external interrupt-enable register */
#define CSR_HVIEN               0x608   /* Hypervisor and virtual-supervisor-level hvien register. */
#define CSR_HVICTL              0x609   /* Hypervisor and virtual-supervisor-level hvictl register. */
#define CSR_HENVCFG             0x60A   /* Hypervisor environment configuration register */
#define CSR_HENVCFGH            0x61A   /* Additional hypervisor env. conf. register, RV32 only */
#define CSR_HSTATEEN0           0x60C   /* Hypervisor state enable 0 (v1.12, Smstateen) */
#define CSR_HSTATEEN1           0x60D   /* Hypervisor state enable 1 (v1.12, Smstateen) */
#define CSR_HSTATEEN2           0x60E   /* Hypervisor state enable 2 (v1.12, Smstateen) */
#define CSR_HSTATEEN3           0x60F   /* Hypervisor state enable 3 (v1.12, Smstateen) */
#define CSR_HEDELEGH            0x612   /* Hypervisor and virtual-supervisor-level hedelegh register. */
#define CSR_HIDELEGH            0x613   /* Hypervisor and virtual-supervisor-level hidelegh register. */
#define CSR_HVIENH              0x618   /* Hypervisor and virtual-supervisor-level hvienh register. */
#define CSR_HSTATEEN0H          0x61C   /* Upper 32 bits of hstateen0, RV32 only (v1.12) */
#define CSR_HSTATEEN1H          0x61D   /* Upper 32 bits of hstateen1, RV32 only (v1.12) */
#define CSR_HSTATEEN2H          0x61E   /* Upper 32 bits of hstateen2, RV32 only (v1.12) */
#define CSR_HSTATEEN3H          0x61F   /* Upper 32 bits of hstateen3, RV32 only (v1.12) */
#define CSR_HTIMEDELTA          0x605   /* Delta for VS/VU-mode timer */
#define CSR_HTIMEDELTAH         0x615   /* Upper 32 bits of htimedelta, HSXLEN=32 only */
#define CSR_HTVAL               0x643   /* Hypervisor bad guest physical address */
#define CSR_HIP                 0x644   /* Hypervisor interrupt pending */
#define CSR_HVIP                0x645   /* Hypervisor virtual interrupt pending */
#define CSR_HVIPRIO1            0x646   /* Hypervisor and virtual-supervisor-level hviprio1 register. */
#define CSR_HVIPRIO2            0x647   /* Hypervisor and virtual-supervisor-level hviprio2 register. */
#define CSR_HVIPH               0x655   /* Hypervisor and virtual-supervisor-level hviph register. */
#define CSR_HVIPRIO1H           0x656   /* Hypervisor and virtual-supervisor-level hviprio1h register. */
#define CSR_HVIPRIO2H           0x657   /* Hypervisor and virtual-supervisor-level hviprio2h register. */
#define CSR_HTINST              0x64A   /* Hypervisor trap instruction (transformed) */
#define CSR_HGATP               0x680   /* Hypervisor guest address translation and protection */
#define CSR_HCONTEXT            0x6A8   /* Hypervisor-mode context register */
#define CSR_HGEIP               0xE12   /* Hypervisor guest external interrupt pending */

/* Machine-Level CSRs */
#define CSR_MSTATUS             0x300   /* Machine status register */
#define CSR_MISA                0x301   /* ISA and extensions */
#define CSR_MEDELEG             0x302   /* Machine exception delegation register */
#define CSR_MIDELEG             0x303   /* Machine interrupt delegation register */
#define CSR_MIE                 0x304   /* Machine interrupt-enable register */
#define CSR_MTVEC               0x305   /* Machine trap-handler base address */
#define CSR_MCOUNTEREN          0x306   /* Machine counter enable */
#define CSR_MTVT                0x307   /* Machine-level mtvt register. */
#define CSR_MVIEN               0x308   /* Machine-level mvien register. */
#define CSR_MVIP                0x309   /* Machine-level mvip register. */
#define CSR_MENVCFG             0x30A   /* Machine environment configuration register */
#define CSR_MSTATEEN0           0x30C   /* Machine state enable 0 (v1.12, Smstateen) */
#define CSR_MSTATEEN1           0x30D   /* Machine state enable 1 (v1.12, Smstateen) */
#define CSR_MSTATEEN2           0x30E   /* Machine state enable 2 (v1.12, Smstateen) */
#define CSR_MSTATEEN3           0x30F   /* Machine state enable 3 (v1.12, Smstateen) */
#define CSR_MEDELEGH            0x312   /* Machine-level medelegh register. */
#define CSR_MIDELEGH            0x313   /* Machine-level midelegh register. */
#define CSR_MIEH                0x314   /* Machine-level mieh register. */
#define CSR_MPMPDELEG           0x316   /* Machine-level mpmpdeleg register. */
#define CSR_MVIENH              0x318   /* Machine-level mvienh register. */
#define CSR_MVIPH               0x319   /* Machine-level mviph register. */
#define CSR_MENVCFGH            0x31A   /* Additional machine env. conf. register, RV32 only */
#define CSR_MSTATUSH            0x310   /* Additional machine status register, RV32 only */
#define CSR_MSTATEEN0H          0x31C   /* Upper 32 bits of mstateen0, RV32 only */
#define CSR_MSTATEEN1H          0x31D   /* Upper 32 bits of mstateen1, RV32 only */
#define CSR_MSTATEEN2H          0x31E   /* Upper 32 bits of mstateen2, RV32 only */
#define CSR_MSTATEEN3H          0x31F   /* Upper 32 bits of mstateen3, RV32 only */
#define CSR_MCOUNTINHIBIT       0x320   /* Machine counter-inhibit register */
#define CSR_MCYCLECFG           0x321   /* Machine cycle counter configuration (v1.12) */
#define CSR_MINSTRETCFG         0x322   /* Machine instructions-retired counter configuration (v1.12) */
#define CSR_MHPMEVENT3          0x323   /* Machine performance-monitoring event selector 3 */
#define CSR_MHPMEVENT4          0x324   /* Machine performance-monitoring event selector 4 */
#define CSR_MHPMEVENT5          0x325   /* Machine performance-monitoring event selector 5 */
#define CSR_MHPMEVENT6          0x326   /* Machine performance-monitoring event selector 6 */
#define CSR_MHPMEVENT7          0x327   /* Machine performance-monitoring event selector 7 */
#define CSR_MHPMEVENT8          0x328   /* Machine performance-monitoring event selector 8 */
#define CSR_MHPMEVENT9          0x329   /* Machine performance-monitoring event selector 9 */
#define CSR_MHPMEVENT10         0x32A   /* Machine performance-monitoring event selector 10 */
#define CSR_MHPMEVENT11         0x32B   /* Machine performance-monitoring event selector 11 */
#define CSR_MHPMEVENT12         0x32C   /* Machine performance-monitoring event selector 12 */
#define CSR_MHPMEVENT13         0x32D   /* Machine performance-monitoring event selector 13 */
#define CSR_MHPMEVENT14         0x32E   /* Machine performance-monitoring event selector 14 */
#define CSR_MHPMEVENT15         0x32F   /* Machine performance-monitoring event selector 15 */
#define CSR_MHPMEVENT16         0x330   /* Machine performance-monitoring event selector 16 */
#define CSR_MHPMEVENT17         0x331   /* Machine performance-monitoring event selector 17 */
#define CSR_MHPMEVENT18         0x332   /* Machine performance-monitoring event selector 18 */
#define CSR_MHPMEVENT19         0x333   /* Machine performance-monitoring event selector 19 */
#define CSR_MHPMEVENT20         0x334   /* Machine performance-monitoring event selector 20 */
#define CSR_MHPMEVENT21         0x335   /* Machine performance-monitoring event selector 21 */
#define CSR_MHPMEVENT22         0x336   /* Machine performance-monitoring event selector 22 */
#define CSR_MHPMEVENT23         0x337   /* Machine performance-monitoring event selector 23 */
#define CSR_MHPMEVENT24         0x338   /* Machine performance-monitoring event selector 24 */
#define CSR_MHPMEVENT25         0x339   /* Machine performance-monitoring event selector 25 */
#define CSR_MHPMEVENT26         0x33A   /* Machine performance-monitoring event selector 26 */
#define CSR_MHPMEVENT27         0x33B   /* Machine performance-monitoring event selector 27 */
#define CSR_MHPMEVENT28         0x33C   /* Machine performance-monitoring event selector 28 */
#define CSR_MHPMEVENT29         0x33D   /* Machine performance-monitoring event selector 29 */
#define CSR_MHPMEVENT30         0x33E   /* Machine performance-monitoring event selector 30 */
#define CSR_MHPMEVENT31         0x33F   /* Machine performance-monitoring event selector 31 */
#define CSR_MSCRATCH            0x340   /* Scratch register for machine trap handlers */
#define CSR_MEPC                0x341   /* Machine exception program counter */
#define CSR_MCAUSE              0x342   /* Machine trap cause */
#define CSR_MTVAL               0x343   /* Machine bad address or instruction */
#define CSR_MIP                 0x344   /* Machine interrupt pending */
#define CSR_MNXTI               0x345   /* Machine-level mnxti register. */
#define CSR_MINTSTATUS          0x346   /* Machine-level mintstatus register. */
#define CSR_MSCRATCHCSW         0x348   /* Machine-level mscratchcsw register. */
#define CSR_MSCRATCHCSWL        0x349   /* Machine-level mscratchcswl register. */
#define CSR_MCTRCTL             0x34E   /* Machine-level mctrctl register. */
#define CSR_MISELECT            0x350   /* Machine-level miselect register. */
#define CSR_MIREG               0x351   /* Machine-level mireg register. */
#define CSR_MIREG2              0x352   /* Machine-level mireg2 register. */
#define CSR_MIREG3              0x353   /* Machine-level mireg3 register. */
#define CSR_MIPH                0x354   /* Machine-level miph register. */
#define CSR_MIREG4              0x355   /* Machine-level mireg4 register. */
#define CSR_MIREG5              0x356   /* Machine-level mireg5 register. */
#define CSR_MIREG6              0x357   /* Machine-level mireg6 register. */
#define CSR_MTOPEI              0x35C   /* Machine-level mtopei register. */
#define CSR_MTINST              0x34A   /* Machine trap instruction (transformed), RV32 only */
#define CSR_MTVAL2              0x34B   /* Machine bad guest physical address, RV32 only */
#define CSR_MCYCLECFGH          0x721   /* Upper 32 bits of mcyclecfg, RV32 only (v1.12) */
#define CSR_MINSTRETCFGH        0x722   /* Upper 32 bits of minstretcfg, RV32 only (v1.12) */
#define CSR_MHPMEVENT3H         0x723   /* Machine-level mhpmevent3h register. */
#define CSR_MHPMEVENT4H         0x724   /* Machine-level mhpmevent4h register. */
#define CSR_MHPMEVENT5H         0x725   /* Machine-level mhpmevent5h register. */
#define CSR_MHPMEVENT6H         0x726   /* Machine-level mhpmevent6h register. */
#define CSR_MHPMEVENT7H         0x727   /* Machine-level mhpmevent7h register. */
#define CSR_MHPMEVENT8H         0x728   /* Machine-level mhpmevent8h register. */
#define CSR_MHPMEVENT9H         0x729   /* Machine-level mhpmevent9h register. */
#define CSR_MHPMEVENT10H        0x72A   /* Machine-level mhpmevent10h register. */
#define CSR_MHPMEVENT11H        0x72B   /* Machine-level mhpmevent11h register. */
#define CSR_MHPMEVENT12H        0x72C   /* Machine-level mhpmevent12h register. */
#define CSR_MHPMEVENT13H        0x72D   /* Machine-level mhpmevent13h register. */
#define CSR_MHPMEVENT14H        0x72E   /* Machine-level mhpmevent14h register. */
#define CSR_MHPMEVENT15H        0x72F   /* Machine-level mhpmevent15h register. */
#define CSR_MHPMEVENT16H        0x730   /* Machine-level mhpmevent16h register. */
#define CSR_MHPMEVENT17H        0x731   /* Machine-level mhpmevent17h register. */
#define CSR_MHPMEVENT18H        0x732   /* Machine-level mhpmevent18h register. */
#define CSR_MHPMEVENT19H        0x733   /* Machine-level mhpmevent19h register. */
#define CSR_MHPMEVENT20H        0x734   /* Machine-level mhpmevent20h register. */
#define CSR_MHPMEVENT21H        0x735   /* Machine-level mhpmevent21h register. */
#define CSR_MHPMEVENT22H        0x736   /* Machine-level mhpmevent22h register. */
#define CSR_MHPMEVENT23H        0x737   /* Machine-level mhpmevent23h register. */
#define CSR_MHPMEVENT24H        0x738   /* Machine-level mhpmevent24h register. */
#define CSR_MHPMEVENT25H        0x739   /* Machine-level mhpmevent25h register. */
#define CSR_MHPMEVENT26H        0x73A   /* Machine-level mhpmevent26h register. */
#define CSR_MHPMEVENT27H        0x73B   /* Machine-level mhpmevent27h register. */
#define CSR_MHPMEVENT28H        0x73C   /* Machine-level mhpmevent28h register. */
#define CSR_MHPMEVENT29H        0x73D   /* Machine-level mhpmevent29h register. */
#define CSR_MHPMEVENT30H        0x73E   /* Machine-level mhpmevent30h register. */
#define CSR_MHPMEVENT31H        0x73F   /* Machine-level mhpmevent31h register. */
#define CSR_MNSCRATCH           0x740   /* Machine-level mnscratch register. */
#define CSR_MNEPC               0x741   /* Machine-level mnepc register. */
#define CSR_MNCAUSE             0x742   /* Machine-level mncause register. */
#define CSR_MNSTATUS            0x744   /* Machine-level mnstatus register. */
#define CSR_MSECCFG             0x747   /* Machine security configuration register */
#define CSR_MSECCFGH            0x757   /* Additional machine security conf. register, RV32 only */
#define CSR_PMPCFG0             0x3A0   /* Physical memory protection configuration 0 */
#define CSR_PMPCFG1             0x3A1   /* Physical memory protection configuration 1, RV32 only */
#define CSR_PMPCFG2             0x3A2   /* Physical memory protection configuration 2 */
#define CSR_PMPCFG3             0x3A3   /* Physical memory protection configuration 3, RV64 only */
#define CSR_PMPCFG4             0x3A4   /* Machine-level pmpcfg4 register. */
#define CSR_PMPCFG5             0x3A5   /* Machine-level pmpcfg5 register. */
#define CSR_PMPCFG6             0x3A6   /* Machine-level pmpcfg6 register. */
#define CSR_PMPCFG7             0x3A7   /* Machine-level pmpcfg7 register. */
#define CSR_PMPCFG8             0x3A8   /* Machine-level pmpcfg8 register. */
#define CSR_PMPCFG9             0x3A9   /* Machine-level pmpcfg9 register. */
#define CSR_PMPCFG10            0x3AA   /* Machine-level pmpcfg10 register. */
#define CSR_PMPCFG11            0x3AB   /* Machine-level pmpcfg11 register. */
#define CSR_PMPCFG12            0x3AC   /* Machine-level pmpcfg12 register. */
#define CSR_PMPCFG13            0x3AD   /* Machine-level pmpcfg13 register. */
#define CSR_PMPCFG14            0x3AE   /* Machine-level pmpcfg14 register. */
#define CSR_PMPCFG15            0x3AF   /* Machine-level pmpcfg15 register. */
#define CSR_PMPADDR0            0x3B0   /* Physical memory protection address register 0 */
#define CSR_PMPADDR1            0x3B1   /* Physical memory protection address register 1 */
#define CSR_PMPADDR2            0x3B2   /* Physical memory protection address register 2 */
#define CSR_PMPADDR3            0x3B3   /* Physical memory protection address register 3 */
#define CSR_PMPADDR4            0x3B4   /* Physical memory protection address register 4 */
#define CSR_PMPADDR5            0x3B5   /* Physical memory protection address register 5 */
#define CSR_PMPADDR6            0x3B6   /* Physical memory protection address register 6 */
#define CSR_PMPADDR7            0x3B7   /* Physical memory protection address register 7 */
#define CSR_PMPADDR8            0x3B8   /* Physical memory protection address register 8 */
#define CSR_PMPADDR9            0x3B9   /* Physical memory protection address register 9 */
#define CSR_PMPADDR10           0x3BA   /* Physical memory protection address register 10 */
#define CSR_PMPADDR11           0x3BB   /* Physical memory protection address register 11 */
#define CSR_PMPADDR12           0x3BC   /* Physical memory protection address register 12 */
#define CSR_PMPADDR13           0x3BD   /* Physical memory protection address register 13 */
#define CSR_PMPADDR14           0x3BE   /* Physical memory protection address register 14 */
#define CSR_PMPADDR15           0x3BF   /* Physical memory protection address register 15 */
#define CSR_PMPADDR16           0x3C0   /* Machine-level pmpaddr16 register. */
#define CSR_PMPADDR17           0x3C1   /* Machine-level pmpaddr17 register. */
#define CSR_PMPADDR18           0x3C2   /* Machine-level pmpaddr18 register. */
#define CSR_PMPADDR19           0x3C3   /* Machine-level pmpaddr19 register. */
#define CSR_PMPADDR20           0x3C4   /* Machine-level pmpaddr20 register. */
#define CSR_PMPADDR21           0x3C5   /* Machine-level pmpaddr21 register. */
#define CSR_PMPADDR22           0x3C6   /* Machine-level pmpaddr22 register. */
#define CSR_PMPADDR23           0x3C7   /* Machine-level pmpaddr23 register. */
#define CSR_PMPADDR24           0x3C8   /* Machine-level pmpaddr24 register. */
#define CSR_PMPADDR25           0x3C9   /* Machine-level pmpaddr25 register. */
#define CSR_PMPADDR26           0x3CA   /* Machine-level pmpaddr26 register. */
#define CSR_PMPADDR27           0x3CB   /* Machine-level pmpaddr27 register. */
#define CSR_PMPADDR28           0x3CC   /* Machine-level pmpaddr28 register. */
#define CSR_PMPADDR29           0x3CD   /* Machine-level pmpaddr29 register. */
#define CSR_PMPADDR30           0x3CE   /* Machine-level pmpaddr30 register. */
#define CSR_PMPADDR31           0x3CF   /* Machine-level pmpaddr31 register. */
#define CSR_PMPADDR32           0x3D0   /* Machine-level pmpaddr32 register. */
#define CSR_PMPADDR33           0x3D1   /* Machine-level pmpaddr33 register. */
#define CSR_PMPADDR34           0x3D2   /* Machine-level pmpaddr34 register. */
#define CSR_PMPADDR35           0x3D3   /* Machine-level pmpaddr35 register. */
#define CSR_PMPADDR36           0x3D4   /* Machine-level pmpaddr36 register. */
#define CSR_PMPADDR37           0x3D5   /* Machine-level pmpaddr37 register. */
#define CSR_PMPADDR38           0x3D6   /* Machine-level pmpaddr38 register. */
#define CSR_PMPADDR39           0x3D7   /* Machine-level pmpaddr39 register. */
#define CSR_PMPADDR40           0x3D8   /* Machine-level pmpaddr40 register. */
#define CSR_PMPADDR41           0x3D9   /* Machine-level pmpaddr41 register. */
#define CSR_PMPADDR42           0x3DA   /* Machine-level pmpaddr42 register. */
#define CSR_PMPADDR43           0x3DB   /* Machine-level pmpaddr43 register. */
#define CSR_PMPADDR44           0x3DC   /* Machine-level pmpaddr44 register. */
#define CSR_PMPADDR45           0x3DD   /* Machine-level pmpaddr45 register. */
#define CSR_PMPADDR46           0x3DE   /* Machine-level pmpaddr46 register. */
#define CSR_PMPADDR47           0x3DF   /* Machine-level pmpaddr47 register. */
#define CSR_PMPADDR48           0x3E0   /* Machine-level pmpaddr48 register. */
#define CSR_PMPADDR49           0x3E1   /* Machine-level pmpaddr49 register. */
#define CSR_PMPADDR50           0x3E2   /* Machine-level pmpaddr50 register. */
#define CSR_PMPADDR51           0x3E3   /* Machine-level pmpaddr51 register. */
#define CSR_PMPADDR52           0x3E4   /* Machine-level pmpaddr52 register. */
#define CSR_PMPADDR53           0x3E5   /* Machine-level pmpaddr53 register. */
#define CSR_PMPADDR54           0x3E6   /* Machine-level pmpaddr54 register. */
#define CSR_PMPADDR55           0x3E7   /* Machine-level pmpaddr55 register. */
#define CSR_PMPADDR56           0x3E8   /* Machine-level pmpaddr56 register. */
#define CSR_PMPADDR57           0x3E9   /* Machine-level pmpaddr57 register. */
#define CSR_PMPADDR58           0x3EA   /* Machine-level pmpaddr58 register. */
#define CSR_PMPADDR59           0x3EB   /* Machine-level pmpaddr59 register. */
#define CSR_PMPADDR60           0x3EC   /* Machine-level pmpaddr60 register. */
#define CSR_PMPADDR61           0x3ED   /* Machine-level pmpaddr61 register. */
#define CSR_PMPADDR62           0x3EE   /* Machine-level pmpaddr62 register. */
#define CSR_PMPADDR63           0x3EF   /* Machine-level pmpaddr63 register. */
#define CSR_MCYCLE              0xB00   /* Machine cycle counter */
#define CSR_MINSTRET            0xB02   /* Machine instructions-retired counter */
#define CSR_MHPMCOUNTER3        0xB03   /* Machine performance-monitoring counter 3 */
#define CSR_MHPMCOUNTER4        0xB04   /* Machine performance-monitoring counter 4 */
#define CSR_MHPMCOUNTER5        0xB05   /* Machine performance-monitoring counter 5 */
#define CSR_MHPMCOUNTER6        0xB06   /* Machine performance-monitoring counter 6 */
#define CSR_MHPMCOUNTER7        0xB07   /* Machine performance-monitoring counter 7 */
#define CSR_MHPMCOUNTER8        0xB08   /* Machine performance-monitoring counter 8 */
#define CSR_MHPMCOUNTER9        0xB09   /* Machine performance-monitoring counter 9 */
#define CSR_MHPMCOUNTER10       0xB0A   /* Machine performance-monitoring counter 10 */
#define CSR_MHPMCOUNTER11       0xB0B   /* Machine performance-monitoring counter 11 */
#define CSR_MHPMCOUNTER12       0xB0C   /* Machine performance-monitoring counter 12 */
#define CSR_MHPMCOUNTER13       0xB0D   /* Machine performance-monitoring counter 13 */
#define CSR_MHPMCOUNTER14       0xB0E   /* Machine performance-monitoring counter 14 */
#define CSR_MHPMCOUNTER15       0xB0F   /* Machine performance-monitoring counter 15 */
#define CSR_MHPMCOUNTER16       0xB10   /* Machine performance-monitoring counter 16 */
#define CSR_MHPMCOUNTER17       0xB11   /* Machine performance-monitoring counter 17 */
#define CSR_MHPMCOUNTER18       0xB12   /* Machine performance-monitoring counter 18 */
#define CSR_MHPMCOUNTER19       0xB13   /* Machine performance-monitoring counter 19 */
#define CSR_MHPMCOUNTER20       0xB14   /* Machine performance-monitoring counter 20 */
#define CSR_MHPMCOUNTER21       0xB15   /* Machine performance-monitoring counter 21 */
#define CSR_MHPMCOUNTER22       0xB16   /* Machine performance-monitoring counter 22 */
#define CSR_MHPMCOUNTER23       0xB17   /* Machine performance-monitoring counter 23 */
#define CSR_MHPMCOUNTER24       0xB18   /* Machine performance-monitoring counter 24 */
#define CSR_MHPMCOUNTER25       0xB19   /* Machine performance-monitoring counter 25 */
#define CSR_MHPMCOUNTER26       0xB1A   /* Machine performance-monitoring counter 26 */
#define CSR_MHPMCOUNTER27       0xB1B   /* Machine performance-monitoring counter 27 */
#define CSR_MHPMCOUNTER28       0xB1C   /* Machine performance-monitoring counter 28 */
#define CSR_MHPMCOUNTER29       0xB1D   /* Machine performance-monitoring counter 29 */
#define CSR_MHPMCOUNTER30       0xB1E   /* Machine performance-monitoring counter 30 */
#define CSR_MHPMCOUNTER31       0xB1F   /* Machine performance-monitoring counter 31 */
#define CSR_MCYCLEH             0xB80   /* Upper 32 bits of mcycle, RV32 only */
#define CSR_MINSTRETH           0xB82   /* Upper 32 bits of minstret, RV32 only */
#define CSR_MHPMCOUNTER3H       0xB83   /* Upper 32 bits of mhpmcounter3, RV32 only */
#define CSR_MHPMCOUNTER4H       0xB84   /* Upper 32 bits of mhpmcounter4, RV32 only */
#define CSR_MHPMCOUNTER5H       0xB85   /* Upper 32 bits of mhpmcounter5, RV32 only */
#define CSR_MHPMCOUNTER6H       0xB86   /* Upper 32 bits of mhpmcounter6, RV32 only */
#define CSR_MHPMCOUNTER7H       0xB87   /* Upper 32 bits of mhpmcounter7, RV32 only */
#define CSR_MHPMCOUNTER8H       0xB88   /* Upper 32 bits of mhpmcounter8, RV32 only */
#define CSR_MHPMCOUNTER9H       0xB89   /* Upper 32 bits of mhpmcounter9, RV32 only */
#define CSR_MHPMCOUNTER10H      0xB8A   /* Upper 32 bits of mhpmcounter10, RV32 only */
#define CSR_MHPMCOUNTER11H      0xB8B   /* Upper 32 bits of mhpmcounter11, RV32 only */
#define CSR_MHPMCOUNTER12H      0xB8C   /* Upper 32 bits of mhpmcounter12, RV32 only */
#define CSR_MHPMCOUNTER13H      0xB8D   /* Upper 32 bits of mhpmcounter13, RV32 only */
#define CSR_MHPMCOUNTER14H      0xB8E   /* Upper 32 bits of mhpmcounter14, RV32 only */
#define CSR_MHPMCOUNTER15H      0xB8F   /* Upper 32 bits of mhpmcounter15, RV32 only */
#define CSR_MHPMCOUNTER16H      0xB90   /* Upper 32 bits of mhpmcounter16, RV32 only */
#define CSR_MHPMCOUNTER17H      0xB91   /* Upper 32 bits of mhpmcounter17, RV32 only */
#define CSR_MHPMCOUNTER18H      0xB92   /* Upper 32 bits of mhpmcounter18, RV32 only */
#define CSR_MHPMCOUNTER19H      0xB93   /* Upper 32 bits of mhpmcounter19, RV32 only */
#define CSR_MHPMCOUNTER20H      0xB94   /* Upper 32 bits of mhpmcounter20, RV32 only */
#define CSR_MHPMCOUNTER21H      0xB95   /* Upper 32 bits of mhpmcounter21, RV32 only */
#define CSR_MHPMCOUNTER22H      0xB96   /* Upper 32 bits of mhpmcounter22, RV32 only */
#define CSR_MHPMCOUNTER23H      0xB97   /* Upper 32 bits of mhpmcounter23, RV32 only */
#define CSR_MHPMCOUNTER24H      0xB98   /* Upper 32 bits of mhpmcounter24, RV32 only */
#define CSR_MHPMCOUNTER25H      0xB99   /* Upper 32 bits of mhpmcounter25, RV32 only */
#define CSR_MHPMCOUNTER26H      0xB9A   /* Upper 32 bits of mhpmcounter26, RV32 only */
#define CSR_MHPMCOUNTER27H      0xB9B   /* Upper 32 bits of mhpmcounter27, RV32 only */
#define CSR_MHPMCOUNTER28H      0xB9C   /* Upper 32 bits of mhpmcounter28, RV32 only */
#define CSR_MHPMCOUNTER29H      0xB9D   /* Upper 32 bits of mhpmcounter29, RV32 only */
#define CSR_MHPMCOUNTER30H      0xB9E   /* Upper 32 bits of mhpmcounter30, RV32 only */
#define CSR_MHPMCOUNTER31H      0xB9F   /* Upper 32 bits of mhpmcounter31, RV32 only */
#define CSR_MVENDORID           0xF11   /* Vendor ID */
#define CSR_MARCHID             0xF12   /* Architecture ID */
#define CSR_MIMPID              0xF13   /* Implementation ID */
#define CSR_MHARTID             0xF14   /* Hardware thread ID */
#define CSR_MCONFIGPTR          0xF15   /* Pointer to configuration data structure */
#define CSR_MTOPI               0xFB0   /* Machine top-level interrupt pending (v1.12) */
#define CSR_MSTOPI              0xFB1   /* Machine supervisor top-level interrupt pending (v1.12) */

/* Debug/Trace CSRs */
#define CSR_TSELECT             0x7A0   /* Debug/Trace trigger register select */
#define CSR_TDATA1              0x7A1   /* First Debug/Trace trigger data register */
#define CSR_TDATA2              0x7A2   /* Second Debug/Trace trigger data register */
#define CSR_TDATA3              0x7A3   /* Third Debug/Trace trigger data register */
#define CSR_TINFO               0x7A4   /* Debug/Trace trigger info register */
#define CSR_TCONTROL            0x7A5   /* Debug/Trace trigger control register */
#define CSR_MCONTROL6           0x7A6   /* Machine trigger (mcontrol6) register */
#define CSR_MCONTEXT            0x7A8   /* Machine mode trigger context register */
#define CSR_MSCONTEXT           0x7AA   /* Machine mode trigger context (mscontext) register */
#define CSR_ICOUNT              0x7AB   /* Instruction-count trigger register */
#define CSR_ITRIGGER            0x7AC   /* Instruction trigger register */
#define CSR_ETRIGGER            0x7AD   /* Exception trigger register */
#define CSR_TTEXTRA32           0x7AE   /* Trigger textra register, RV32 only */
#define CSR_TTEXTRA64           0x7AF   /* Trigger textra register, RV64 only */
#define CSR_DCSR                0x7B0   /* Debug control and status register */
#define CSR_DPC                 0x7B1   /* Debug PC */
#define CSR_DSCRATCH0           0x7B2   /* Debug scratch register 0 */
#define CSR_DSCRATCH1           0x7B3   /* Debug scratch register 1 */

/*
 * @brief  Compatibility spellings of the standard CSR names above. They
 *         expand to the same CSR addresses and are kept so that code written
 *         against the previous releases of this header, and the vendor notes
 *         that use the short spellings, keep compiling unchanged.
 */
#define CSR_SSTATEN0            CSR_SSTATEEN0
#define CSR_SSTATEN0H           CSR_SSTATEEN0H
#define CSR_MSTATEN0            CSR_MSTATEEN0
#define CSR_MSTATEN1            CSR_MSTATEEN1
#define CSR_MSTATEN2            CSR_MSTATEEN2
#define CSR_MSTATEN3            CSR_MSTATEEN3
#define CSR_MSTATEN0H           CSR_MSTATEEN0H
#define CSR_MSTATEN1H           CSR_MSTATEEN1H
#define CSR_MSTATEN2H           CSR_MSTATEEN2H
#define CSR_MSTATEN3H           CSR_MSTATEEN3H
#define CSR_HSTATEN0            CSR_HSTATEEN0
#define CSR_HSTATEN1            CSR_HSTATEEN1
#define CSR_HSTATEN2            CSR_HSTATEEN2
#define CSR_HSTATEN3            CSR_HSTATEEN3
#define CSR_HSTATEN0H           CSR_HSTATEEN0H
#define CSR_HSTATEN1H           CSR_HSTATEEN1H
#define CSR_HSTATEN2H           CSR_HSTATEEN2H
#define CSR_HSTATEN3H           CSR_HSTATEEN3H
#define CSR_MCONTROL            CSR_MSCONTEXT
#define CSR_SSTOPI              CSR_STOPI
#define CSR_VSSTOPI             CSR_VSTOPI

/******************************************************************************
 *  RISC-V CSR KEY FIELD DEFINITIONS
 *****************************************************************************/
/* mstatus bits */
#define MSTATUS_UIE             0x00000001UL
#define MSTATUS_SIE             0x00000002UL
#define MSTATUS_HIE             0x00000004UL
#define MSTATUS_MIE             0x00000008UL
#define MSTATUS_UPIE            0x00000010UL
#define MSTATUS_SPIE            0x00000020UL
#define MSTATUS_HPIE            0x00000040UL
#define MSTATUS_MPIE            0x00000080UL
#define MSTATUS_SPP             0x00000100UL
#define MSTATUS_HPP             0x00000600UL /* Hypervisor previous privilege (VS when V ext. enabled) */
#define MSTATUS_VS              0x00000600UL
#define MSTATUS_MPP             0x00001800UL
#define MSTATUS_FS              0x00006000UL
#define MSTATUS_XS              0x00018000UL
#define MSTATUS_MPRV            0x00020000UL
#define MSTATUS_SUM             0x00040000UL
#define MSTATUS_MXR             0x00080000UL
#define MSTATUS_TVM             0x00100000UL
#define MSTATUS_TW              0x00200000UL
#define MSTATUS_TSR             0x00400000UL
#define MSTATUS_SD              0x80000000UL /* (RV32) Summary of dirty bits */

/* mstatush bits (RV32 only, 0x310) */
#define MSTATUSH_SBE            0x00000010UL /* Big-endian memory access in S-mode (mstatush bit 4) */
#define MSTATUSH_UBE            0x00000020UL /* Big-endian memory access in U-mode (mstatush bit 5) */
#define MSTATUSH_MBE            0x00000040UL /* Big-endian memory access in M-mode (mstatush bit 6) */
#define MSTATUSH_GVA            0x00000080UL /* Virtual address of the trap (mstatush bit 7) */
#define MSTATUSH_MPV            0x00000100UL /* Trap occurred in VS mode (mstatush bit 8) */

/* misa bits */
#define MISA_A                  0x00000001UL
#define MISA_B                  0x00000002UL
#define MISA_C                  0x00000004UL
#define MISA_D                  0x00000008UL
#define MISA_E                  0x00000010UL
#define MISA_F                  0x00000020UL
#define MISA_G                  0x00000040UL
#define MISA_H                  0x00000080UL
#define MISA_I                  0x00000100UL
#define MISA_J                  0x00000200UL
#define MISA_K                  0x00000400UL
#define MISA_L                  0x00000800UL
#define MISA_M                  0x00001000UL
#define MISA_N                  0x00002000UL
#define MISA_O                  0x00004000UL
#define MISA_P                  0x00008000UL
#define MISA_Q                  0x00010000UL
#define MISA_R                  0x00020000UL
#define MISA_S                  0x00040000UL
#define MISA_T                  0x00080000UL
#define MISA_U                  0x00100000UL
#define MISA_V                  0x00200000UL
#define MISA_W                  0x00400000UL
#define MISA_X                  0x00800000UL
#define MISA_Y                  0x01000000UL
#define MISA_Z                  0x02000000UL

/* mcause exception codes (interrupt bit cleared) */
#define MCAUSE_INST_ADDR_MISALIGNED     0x00000000UL
#define MCAUSE_INST_ACCESS_FAULT        0x00000001UL
#define MCAUSE_ILLEGAL_INST             0x00000002UL
#define MCAUSE_BREAKPOINT               0x00000003UL
#define MCAUSE_LOAD_ADDR_MISALIGNED     0x00000004UL
#define MCAUSE_LOAD_ACCESS_FAULT        0x00000005UL
#define MCAUSE_STORE_ADDR_MISALIGNED    0x00000006UL
#define MCAUSE_STORE_ACCESS_FAULT       0x00000007UL
#define MCAUSE_ECALL_UMODE              0x00000008UL
#define MCAUSE_ECALL_SMODE              0x00000009UL
#define MCAUSE_ECALL_MMODE              0x0000000BUL
#define MCAUSE_INST_PAGE_FAULT          0x0000000CUL
#define MCAUSE_LOAD_PAGE_FAULT          0x0000000DUL
#define MCAUSE_STORE_PAGE_FAULT         0x0000000FUL
#define MCAUSE_INST_GUEST_PAGE_FAULT    0x00000014UL /* Instruction guest-page fault (v1.12, H ext.) */
#define MCAUSE_LOAD_GUEST_PAGE_FAULT    0x00000015UL /* Load guest-page fault (v1.12, H ext.) */
#define MCAUSE_VIRTUAL_INST             0x00000016UL /* Virtual instruction (v1.12, H ext.) */
#define MCAUSE_STORE_GUEST_PAGE_FAULT   0x00000017UL /* Store/AMO guest-page fault (v1.12, H ext.) */
#define MCAUSE_IRQ_BIT                  0x80000000UL /* Interrupt flag bit */

/* mcause standard interrupt exception codes (interrupt bit set) */
#define MCAUSE_SSI                      0x80000001UL /* Supervisor software interrupt */
#define MCAUSE_MSI                      0x80000003UL /* Machine software interrupt */
#define MCAUSE_STI                      0x80000005UL /* Supervisor timer interrupt */
#define MCAUSE_MTI                      0x80000007UL /* Machine timer interrupt */
#define MCAUSE_SEI                      0x80000009UL /* Supervisor external interrupt */
#define MCAUSE_MEI                      0x8000000BUL /* Machine external interrupt */
#define MCAUSE_SGEI                     0x8000000DUL /* Supervisor guest external interrupt (v1.12, H ext.) */

/* mtvec mode field */
#define MTVEC_MODE_DIRECT               0x00000000UL
#define MTVEC_MODE_VECTORED             0x00000001UL

/* stvec mode field (same encoding as mtvec) */
#define STVEC_MODE_DIRECT               0x00000000UL
#define STVEC_MODE_VECTORED             0x00000001UL

/* mie / mip bits (0x304 / 0x344, also valid for sie/sip 0x104 / 0x144) */
#define MIE_SSIE                       0x00000002UL /* Supervisor software interrupt enable/pending */
#define MIE_MSIE                       0x00000008UL /* Machine software interrupt enable/pending */
#define MIE_STIE                       0x00000020UL /* Supervisor timer interrupt enable/pending */
#define MIE_MTIE                       0x00000080UL /* Machine timer interrupt enable/pending */
#define MIE_SEIE                       0x00000200UL /* Supervisor external interrupt enable/pending */
#define MIE_MEIE                       0x00000800UL /* Machine external interrupt enable/pending */
#define MIE_SGEIE                      0x00002000UL /* Supervisor guest external interrupt enable/pending (v1.12, H ext.) */
/* mip aliases (pending side) */
#define MIP_SSIP                       MIE_SSIE
#define MIP_MSIP                       MIE_MSIE
#define MIP_STIP                       MIE_STIE
#define MIP_MTIP                       MIE_MTIE
#define MIP_SEIP                       MIE_SEIE
#define MIP_MEIP                       MIE_MEIE
#define MIP_SGEIP                      MIE_SGEIE

/* sstatus bits (S-mode view of mstatus, RV32) */
#define SSTATUS_SIE                     0x00000002UL /* Supervisor interrupt enable */
#define SSTATUS_SPIE                    0x00000020UL /* Supervisor previous interrupt enable */
#define SSTATUS_SPP                     0x00000100UL /* Supervisor previous privilege */
#define SSTATUS_FS                      0x00006000UL /* Floating-point status (RV32) */
#define SSTATUS_XS                      0x00018000UL /* Extension status (RV32) */
#define SSTATUS_SUM                     0x00040000UL /* Supervisor user memory access */
#define SSTATUS_MXR                     0x00080000UL /* Make executable readable */
#define SSTATUS_SD                      0x80000000UL /* Summary of dirty bits (RV32) */

/* hstatus bits (0x600, H extension) */
#define HSTATUS_HU                      0x00000002UL /* Hypervisor user mode */
#define HSTATUS_HV                      0x00000008UL /* Hypervisor virtual mode (trap was in VS) */
#define HSTATUS_SPV                     0x00000010UL /* Supervisor previous virtual mode */
#define HSTATUS_SPVP                    0x00000020UL /* Supervisor previous virtual privilege */
#define HSTATUS_GVA                     0x00000040UL /* Guest virtual address of the trap */
#define HSTATUS_VSBE                    0x00000080UL /* Virtual supervisor big-endian */
#define HSTATUS_VTW                     0x10000000UL /* Virtual trap WFI */
#define HSTATUS_VTVM                    0x20000000UL /* Virtual trap virtual memory */
#define HSTATUS_VTSR                    0x40000000UL /* Virtual trap sret */

/* mcountinhibit bits (0x320) */
#define MCOUNTINHIBIT_CY               0x00000001UL /* Inhibit the cycle counter */
#define MCOUNTINHIBIT_IR               0x00000002UL /* Inhibit the instructions-retired counter */

/* satp fields (RV32, 0x180) */
#define SATP_MODE_OFF                  0x00000000UL /* Bare translation mode (MODE=0) */
#define SATP_MODE_SV32                 0x80000000UL /* Page-based 32-bit virtual memory (MODE=1) */
#define SATP_MODE_MASK                 0x80000000UL /* RV32 MODE field mask (bit 31) */
#define SATP_ASID_MASK                 0x7FE00000UL /* RV32 ASID field mask (bits 22-30) */
#define SATP_PPN_MASK                  0x003FFFFFUL /* RV32 PPN field mask (bits 0-21) */

/* pmpcfg field encodings (pmpcfg0..3) */
#define PMP_CFG_R                      0x00000001UL /* Read permission */
#define PMP_CFG_W                      0x00000002UL /* Write permission */
#define PMP_CFG_X                      0x00000004UL /* Execute permission */
#define PMP_CFG_A_OFF                  0x00000000UL /* Address matching: disabled */
#define PMP_CFG_A_TOR                  0x00000008UL /* Address matching: top-of-range */
#define PMP_CFG_A_NA4                  0x00000010UL /* Address matching: naturally aligned 4-byte */
#define PMP_CFG_A_NAPOT                0x00000018UL /* Address matching: naturally aligned power-of-two */
#define PMP_CFG_L                      0x00000080UL /* Lock bit */

/* menvcfg bits (RV32, 0x30A; S-mode view in senvcfg 0x10A) */
#define MENVCFG_FIOM                   0x00000001UL /* Relaxed memory ordering (fence.i implies f.o) */
#define MENVCFG_CBIE                   0x00000006UL /* Cache block invalidate/clean instruction enable */
#define MENVCFG_CBCFE                  0x00000008UL /* Cache block clean/zero instruction enable */
#define MENVCFG_CBZE                   0x00000010UL /* Cache block zero instruction enable */
#define MENVCFG_PBMTE                  0x00000040UL /* Page-based memory types enable */
#define MENVCFG_STCE                   0x00000080UL /* Supervisor timer counter enable */

/******************************************************************************
 *  RISC-V CSR READ/WRITE OPERATIONS (compiler dependent)
 *****************************************************************************/
#if defined(_IAR_C_AS32x601_) || defined(__ICCRISCV__)
    /* IAR RISC-V compiler CSR intrinsic functions (riscv\inc\c\intrinsics.h).
     * IAR exposes the CSR operations as __intrinsic built-ins that take the
     * CSR register number (e.g. CSR_MCYCLE -> 0xB00) and return the PREVIOUS
     * machine-CSR value, matching the semantics of the GCC inline-asm path
     * below (csrr / csrrw / csrrs / csrrc): csr_write/csr_swap are CSRRW,
     * csr_set_bits/csr_read_set are CSRRS, csr_clear_bits/csr_read_clear are
     * CSRRC.  <intrinsics.h> provides the declarations so no "declared
     * implicitly" diagnostic is emitted. */
    #include <intrinsics.h>

    #define csr_read(csr)            __read_csr(csr)
    #define csr_write(csr, val)      __write_csr(csr, (unsigned long)(val))
    #define csr_set_bits(csr, val)   __set_bits_csr(csr, (unsigned long)(val))
    #define csr_clear_bits(csr, val) __clear_bits_csr(csr, (unsigned long)(val))
    #define csr_swap(csr, val)       __write_csr(csr, (unsigned long)(val))
    #define csr_read_set(csr, val)   __set_bits_csr(csr, (unsigned long)(val))
    #define csr_read_clear(csr, val) __clear_bits_csr(csr, (unsigned long)(val))
#else
    /* GCC compatible compilers (GCC / GreenHills / Diab / CodeWarrior)
     * use GNU statement expressions with RISC-V inline assembly.
     */
    #if defined(_DIABDATA_C_AS32x601_)
        #define __RISCV_ASM   __asm
    #elif defined(_CODEWARRIOR_C_AS32x601_)
        #define __RISCV_ASM   asm
    #else
        #define __RISCV_ASM   __asm__
    #endif

    #define csr_read(csr)                                                       \
        ({                                                                      \
            unsigned long __csr_val;                                            \
            __RISCV_ASM volatile("csrr %0, " CORE_RISCV_STR(csr) : "=r"(__csr_val)); \
            __csr_val;                                                          \
        })

    #define csr_write(csr, val)                                                 \
        do {                                                                    \
            unsigned long __csr_val = (unsigned long)(val);                     \
            __RISCV_ASM volatile("csrw " CORE_RISCV_STR(csr) ", %0" :: "r"(__csr_val)); \
        } while (0)

    #define csr_set_bits(csr, val)                                              \
        do {                                                                    \
            unsigned long __csr_val = (unsigned long)(val);                     \
            __RISCV_ASM volatile("csrs " CORE_RISCV_STR(csr) ", %0" :: "r"(__csr_val)); \
        } while (0)

    #define csr_clear_bits(csr, val)                                            \
        do {                                                                    \
            unsigned long __csr_val = (unsigned long)(val);                     \
            __RISCV_ASM volatile("csrc " CORE_RISCV_STR(csr) ", %0" :: "r"(__csr_val)); \
        } while (0)

    #define csr_swap(csr, val)                                                  \
        ({                                                                      \
            unsigned long __csr_old;                                            \
            unsigned long __csr_new = (unsigned long)(val);                     \
            __RISCV_ASM volatile("csrrw %0, " CORE_RISCV_STR(csr) ", %1"        \
                                 : "=r"(__csr_old) : "r"(__csr_new));           \
            __csr_old;                                                          \
        })

    #define csr_read_set(csr, val)                                              \
        ({                                                                      \
            unsigned long __csr_old;                                            \
            unsigned long __csr_new = (unsigned long)(val);                     \
            __RISCV_ASM volatile("csrrs %0, " CORE_RISCV_STR(csr) ", %1"        \
                                 : "=r"(__csr_old) : "r"(__csr_new));           \
            __csr_old;                                                          \
        })

    #define csr_read_clear(csr, val)                                            \
        ({                                                                      \
            unsigned long __csr_old;                                            \
            unsigned long __csr_new = (unsigned long)(val);                     \
            __RISCV_ASM volatile("csrrc %0, " CORE_RISCV_STR(csr) ", %1"        \
                                 : "=r"(__csr_old) : "r"(__csr_new));           \
            __csr_old;                                                          \
        })
#endif /* #if defined(_IAR_C_AS32x601_) || defined(__ICCRISCV__) */

/******************************************************************************
 *  GLOBAL INTERRUPT ENABLE / DISABLE (M-mode)
 *****************************************************************************/
#define __enable_irq()   csr_set_bits(CSR_MSTATUS, MSTATUS_MIE)
#define __disable_irq()  csr_clear_bits(CSR_MSTATUS, MSTATUS_MIE)

/* Save the current global interrupt enable state and disable global interrupts.
 * Returns the interrupt enable state prior to the call (1: enabled, 0: disabled).
 * Used to protect critical sections in nested contexts.
 * Note: implemented via single csrrc instruction (atomic read-clear). */
#define __disable_irq_and_save() \
    ((csr_read_clear(CSR_MSTATUS, MSTATUS_MIE) & MSTATUS_MIE) ? 1u : 0u)

/* Restore the global interrupt enable state to the value saved previously.
 * A non-zero state enables the global interrupt; a zero state clears
 * mstatus.MIE explicitly, so a nested critical section restores either entry
 * condition instead of leaving the interrupt in whatever state it holds.
 * Must be paired with __disable_irq_and_save(). */
#define __restore_irq(__state) \
    do { if ((__state) != 0u) { __enable_irq(); } else { __disable_irq(); } } while(0)

/******************************************************************************
 *  INSTRUCTION PRIMITIVES
 *****************************************************************************/
/*
 * @brief  Wait For Interrupt: enter low-power state until an interrupt is taken.
 * @note   Supported by the core (base privileged instruction).
 */
#define WFI()    ASM_KEYWORD volatile("wfi")

/*
 * @brief  No operation: consume one instruction cycle.
 */
#define NOP()    ASM_KEYWORD volatile("nop")

/*
 * @brief  Software breakpoint: raise a breakpoint exception (debug trap).
 */
#define EBREAK() ASM_KEYWORD volatile("ebreak")

/*
 * @brief  Return from supervisor trap (privileged instruction).
 */
#define SRET()   ASM_KEYWORD volatile("sret")

/*
 * @brief  Return from machine trap (privileged instruction).
 */
#define MRET()   ASM_KEYWORD volatile("mret")

/*
 * @brief  Memory fence (fence): order device and memory accesses.
 */
#define FENCE()  ASM_KEYWORD volatile("fence")

/*
 * @brief  Instruction fence (fence.i): order instruction fetches.
 */
#define FENCE_I() ASM_KEYWORD volatile("fence.i")

/*
 * @brief  Clear cache: execute the chip cache-clearing instruction.
 * @note   This is a custom R-type instruction encoded as
 *         ".insn r 0x0F, 5, 0, x0, x0, x0".  It is used by the MAC driver
 *         after the transmit / receive descriptor write and before the DMA
 *         poll demand, so that the cache is coherent with the DMA reads.
 */
#define CLEAR_CACHE() ASM_KEYWORD volatile(".insn r 0x0F,5,0,x0,x0,x0")

#ifdef __cplusplus
}
#endif

#endif /* CORE_RISCV_H */

/*****END OF FILE*****/
