/**
 * @file    CRC_IT_DRV_004.c
 * @brief   HAL CRC integration test case 004 (reset, independent data register,
 *          result read back).
 *
 * HAL library extension case for the peripheral control group: the reference
 * library exposes CRC_Reset / CRC_SetIDRegister / CRC_GetIDRegister /
 * CRC_GetCRC without any handle, so the HAL equivalents need their own case.
 *
 * Tested functionality:
 *   HAL_CRC_StructInit() / HAL_CRC_Init() / HAL_CRC_DeInit()
 *   HAL_CRC_Reset()
 *   HAL_CRC_SetIDRegister() / HAL_CRC_GetIDRegister()
 *   HAL_CRC_GetCRC()
 *   HAL_CRC_CalcCRC()
 *   HAL_CRC_GetState() / HAL_CRC_GetError()
 *
 * Test procedure:
 *   1. initialize the handle with the CRC-32 configuration and a non-zero
 *      initial value (0x12345678);
 *   2. reset semantics: HAL_CRC_Reset() must restart the calculation from the
 *      configured initial value; the result is not allowed to depend on the
 *      previous accumulator content. On this device the reset pulse does not
 *      preload the data register (CRC_DR keeps the last computed result), so
 *      the restart is checked through the next fed element;
 *   3. result read back: the value returned by HAL_CRC_CalcCRC() must equal the
 *      value read back through HAL_CRC_GetCRC();
 *   4. independent data register: write / read round trip for 0x5A, 0x00 and
 *      0xFF; the register must not be affected by a calculation or by a reset.
 *      A re-initialization runs HAL_CRC_MspInit() again, whose clock helper
 *      pulses the peripheral reset, so the register is back to its reset
 *      value (0x00) after HAL_CRC_Init();
 *   5. state gate: on an uninitialized (de-initialized) handle HAL_CRC_Reset()
 *      and HAL_CRC_SetIDRegister() are silent no-operations, while the read
 *      back services keep working (they take the lock but no state gate);
 *   6. recovery: a legal HAL_CRC_Init() brings the handle back to READY and the
 *      data of the independent data register is still there.
 *
 * Expected behaviour:
 *   every check below passes and the summary prints
 *   "summary : failures = 0".
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
#define TEST_BAUDRATE                  (115200U)   /*!< console baud rate        */
#define TEST_ROUND_DELAY_MS            (2000U)     /*!< delay between two rounds */

#define TEST_CRC_INIT                  (0x12345678U) /*!< configured initial value */
#define TEST_ID_PATTERN                (0x0000005AU) /*!< first ID register value  */
#define TEST_ID_SECOND                 (0x0000003CU) /*!< second ID register value */
#define TEST_ID_THIRD                  (0x00000077U) /*!< third ID register value  */

/* Private variables ---------------------------------------------------------*/
static volatile uint32 check_failures = 0U;   /*!< failed check counter           */
static HAL_SMU_HandleTypeDef hsmu_clk;        /*!< SMU handle (clock tree)        */

/** @brief CRC handle used by this case. */
HAL_CRC_HandleTypeDef hcrc_dev;

/* MSP callback bookkeeping (written by the shared MSP callbacks) */
uint32 Crc_MspInitCount   = 0U;               /*!< HAL_CRC_MspInit() calls        */
uint32 Crc_MspDeInitCount = 0U;               /*!< HAL_CRC_MspDeInit() calls      */
uint32 Crc_MspStateAtInit = 0xFFFFFFFFU;      /*!< handle state seen in the MSP   */
uint32 Crc_MspLockAtInit  = 0xFFFFFFFFU;      /*!< handle lock seen in the MSP    */

/* Shared helpers of this suite (defined at the end of this file) */
void Check(const char *name, uint32 condition);
void Summary(void);
void SystemClock_Init(void);
void Crc_ClockEnable(void);



/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    CRC_InitTypeDef   crc_init;
    HAL_StatusTypeDef status;
    uint32 round = 0U;
    uint32 result;
    uint32 read_back;
    uint32 before_reset;
    uint32 after_reset;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== CRC_IT_DRV_004 : reset, ID register, result read back ===\r\n");

    /* Handle preparation with a recognisable initial value */
    __HAL_CLEAR_STRUCT(&hcrc_dev);
    hcrc_dev.Instance = CRC;
    HAL_CRC_StructInit(&crc_init);
    Check("HAL_CRC_StructInit() fills the Size metafield",
          (crc_init.Size == (uint32)sizeof(CRC_InitTypeDef)) ? 1U : 0U);
    Check("HAL_CRC_StructInit() fills the Version metafield",
          (crc_init.Version == CRC_INIT_VERSION) ? 1U : 0U);
    crc_init.CRC_INIT = TEST_CRC_INIT;
    hcrc_dev.Init = crc_init;
    hcrc_dev.InputDataFormat = HAL_CRC_INPUTDATA_FORMAT_WORDS;

    status = HAL_CRC_Init(&hcrc_dev);
    Check("HAL_CRC_Init() returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("the handle is READY", (HAL_CRC_GetState(&hcrc_dev) == HAL_CRC_STATE_READY) ? 1U : 0U);

    for (;;)
    {
        /* ---------------- reset semantics --------------------------------- */
        /* The reset pulse does not preload the data register on this device
         * (CRC_DR keeps the last computed result), so the restart from
         * CRC_INIT is checked through the first fed element: two identical
         * reset + feed sequences must produce the same value. */
        HAL_CRC_Reset(&hcrc_dev);
        result = HAL_CRC_CalcCRC(&hcrc_dev, 0x11223344U);
        HAL_CRC_Reset(&hcrc_dev);
        read_back = HAL_CRC_GetCRC(&hcrc_dev);
        if (round == 0U)
        {
            Check("Reset() keeps the last result in CRC_DR (no preload)",
                  (read_back == result) ? 1U : 0U);
        }

        /* after a feed the accumulator changes; a reset brings it back */
        (void)HAL_CRC_CalcCRC(&hcrc_dev, 0xA5A5A5A5U);
        before_reset = HAL_CRC_GetCRC(&hcrc_dev);
        HAL_CRC_Reset(&hcrc_dev);
        read_back = HAL_CRC_GetCRC(&hcrc_dev);
        if (round == 0U)
        {
            Check("the accumulator was advanced before the second reset",
                  (before_reset != TEST_CRC_INIT) ? 1U : 0U);
            Check("the second Reset() keeps that advanced result in CRC_DR",
                  (read_back == before_reset) ? 1U : 0U);
            /* the restart really happens on the next fed element */
            after_reset = HAL_CRC_CalcCRC(&hcrc_dev, 0x11223344U);
            Check("a second Reset() restarts the calculation from CRC_INIT",
                  (after_reset == result) ? 1U : 0U);
            Check("the handle is READY after the reset services",
                  (HAL_CRC_GetState(&hcrc_dev) == HAL_CRC_STATE_READY) ? 1U : 0U);
        }

        /* ---------------- result read back -------------------------------- */
        HAL_CRC_Reset(&hcrc_dev);
        result = HAL_CRC_CalcCRC(&hcrc_dev, 0x11223344U);
        read_back = HAL_CRC_GetCRC(&hcrc_dev);
        if (round == 0U)
        {
            Check("CalcCRC() result equals the value read back through GetCRC()",
                  (result == read_back) ? 1U : 0U);
        }

        /* ---------------- independent data register ----------------------- */
        HAL_CRC_SetIDRegister(&hcrc_dev, (uint8)TEST_ID_PATTERN);
        Check("ID register round trip 0x5A",
              (HAL_CRC_GetIDRegister(&hcrc_dev) == (uint8)TEST_ID_PATTERN) ? 1U : 0U);

        HAL_CRC_SetIDRegister(&hcrc_dev, 0x00U);
        Check("ID register round trip 0x00",
              (HAL_CRC_GetIDRegister(&hcrc_dev) == 0x00U) ? 1U : 0U);

        HAL_CRC_SetIDRegister(&hcrc_dev, 0xFFU);
        Check("ID register round trip 0xFF",
              (HAL_CRC_GetIDRegister(&hcrc_dev) == 0xFFU) ? 1U : 0U);

        /* the register is independent data storage: a calculation, a reset and
         * a re-initialization must not change it */
        HAL_CRC_SetIDRegister(&hcrc_dev, (uint8)TEST_ID_SECOND);
        (void)HAL_CRC_CalcCRC(&hcrc_dev, 0xCAFEBABEU);
        if (round == 0U)
        {
            Check("a calculation does not change the ID register",
                  (HAL_CRC_GetIDRegister(&hcrc_dev) == (uint8)TEST_ID_SECOND) ? 1U : 0U);
            Check("the ID register is visible in CRC->IDR (white-box)",
                  (CRC->IDR == (uint8)TEST_ID_SECOND) ? 1U : 0U);
        }

        HAL_CRC_Reset(&hcrc_dev);
        if (round == 0U)
        {
            Check("Reset() does not change the ID register",
                  (HAL_CRC_GetIDRegister(&hcrc_dev) == (uint8)TEST_ID_SECOND) ? 1U : 0U);
        }

        /* ---------------- state gate on an uninitialized handle ----------- */
        HAL_CRC_SetIDRegister(&hcrc_dev, (uint8)TEST_ID_THIRD);
        status = HAL_CRC_DeInit(&hcrc_dev);
        if (round == 0U)
        {
            Check("HAL_CRC_DeInit() returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
            Check("the handle is uninitialized after the de-initialization",
                  (HAL_CRC_GetState(&hcrc_dev) == HAL_CRC_STATE_RESET) ? 1U : 0U);
            Check("DeInit() does not change the ID register",
                  (HAL_CRC_GetIDRegister(&hcrc_dev) == (uint8)TEST_ID_THIRD) ? 1U : 0U);
        }

        /* the write services are gated: silent no-operations while RESET */
        HAL_CRC_SetIDRegister(&hcrc_dev, 0x11U);
        HAL_CRC_Reset(&hcrc_dev);
        if (round == 0U)
        {
            Check("SetIDRegister() is a no-operation on an uninitialized handle",
                  (HAL_CRC_GetIDRegister(&hcrc_dev) == (uint8)TEST_ID_THIRD) ? 1U : 0U);
            Check("the handle state is untouched by the refused services",
                  (HAL_CRC_GetState(&hcrc_dev) == HAL_CRC_STATE_RESET) ? 1U : 0U);
        }

        /* recovery: re-initialization brings the handle back and the ID data
         * survived (DeInit only writes the control register) */
        status = HAL_CRC_Init(&hcrc_dev);
        if (round == 0U)
        {
            Check("a legal Init() recovers the handle", (status == HAL_OK) ? 1U : 0U);
            Check("the handle is READY again",
                  (HAL_CRC_GetState(&hcrc_dev) == HAL_CRC_STATE_READY) ? 1U : 0U);
            /* the de-initialization itself leaves the ID register alone (checked
             * above), but the low level initialization pulses the peripheral
             * reset (SMU FORCE_RESET / RELEASE_RESET in HAL_CRC_MspInit()),
             * which returns the whole unit - the ID register included - to its
             * reset value. */
            Check("the peripheral reset of MspInit cleared the ID register",
                  (HAL_CRC_GetIDRegister(&hcrc_dev) == 0x00U) ? 1U : 0U);
            Check("no error was recorded", (HAL_CRC_GetError(&hcrc_dev) == HAL_CRC_ERROR_NONE) ? 1U : 0U);
            Summary();
        }

        round++;
        delay_ms(TEST_ROUND_DELAY_MS);
    }
}

/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the other integration tests of this library:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2 and
 *         CANX2 by 8, which gives core 180 MHz and APB 22.5 MHz.
 * @param  None
 * @retval None
 */
void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks (console pins of USART0 on GPIOD) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Open the clock gate of the CRC unit and release its reset.
 * @param  None
 * @retval None
 */
void Crc_ClockEnable(void)
{
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_CRC_CLK_ENABLE();
    __HAL_SMU_CRC_FORCE_RESET();
    __HAL_SMU_CRC_RELEASE_RESET();
}

/* MSP callbacks ------------------------------------------------------------*/

/**
 * @brief  Initialize the CRC MSP (clock gate and reset release).
 * @param  hcrc: CRC handle
 * @retval None
 */
void HAL_CRC_MspInit(HAL_CRC_HandleTypeDef *hcrc)
{
    Crc_MspInitCount++;
    Crc_MspStateAtInit = (uint32)hcrc->State;
    Crc_MspLockAtInit  = (uint32)hcrc->Lock;

    Crc_ClockEnable();
}

/**
 * @brief  De-initialize the CRC MSP (the clock gate is left open).
 * @param  hcrc: CRC handle
 * @retval None
 */
void HAL_CRC_MspDeInit(HAL_CRC_HandleTypeDef *hcrc)
{
    Crc_MspDeInitCount++;

    (void)hcrc;
}

/*****END OF FILE*****/
