/**
 * @file    MPU_IT_DRV_001.c
 * @brief   HAL MPU integration test case 001 (I-Port read protection, channel 0).
 *
 * One-to-one HAL library port of the original AS32x601 standard-library test
 * case MPU_IT_DRV_001.c. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_MPU_SetAddressRange()
 *   HAL_MPU_ReadProtectCmd()
 *   HAL_MPU_Cmd()
 *   HAL_MPU_GetReadProtectStatus()
 *   HAL_MPU_ClearStatus()
 *   HAL_MPU_GetIPortBlock()      (I-Port register block of MPU0)
 *
 * Test procedure:
 *   1. Derive the protected range from the address of the protected function
 *      Mpu_ProtectFunc(), which is linked in .text of the P-Flash;
 *   2. Configure the range of MPU0 channel 0 with HAL_MPU_SetAddressRange(),
 *      enable its read protection with HAL_MPU_ReadProtectCmd() and enable the
 *      channel with HAL_MPU_Cmd();
 *   3. Check the whole configuration path from the firmware: register read-back,
 *      HAL_MPU_GetAddressRange() / HAL_MPU_GetChannelConfig() read-back, the
 *      disable / enable round trip of RPTEN and PTEN and the clear-status path
 *      (none of these touches the protected range, so all of them run);
 *   4. Call the protected function.  Its instruction fetch passes through the
 *      MPU0 instruction port, is refused and is recorded in RPTS.  On this
 *      device the refused fetch does not complete and raises no trap: the core
 *      STOPS on it.  The status is therefore confirmed with the debugger
 *      (MPU0 RPTS = 0x00000001) and the board is reset to run the case again.
 *
 *   Two properties the original case took for granted have to be arranged
 *   explicitly here, otherwise the status never gets set:
 *   - the call must really be emitted: Mpu_ProtectFunc() has no side effect
 *     that the compiler has to keep and its result is not used, so a direct
 *     "(void)Mpu_ProtectFunc();" is removed at -Og and the protected range is
 *     never fetched at all.  The test calls it through a volatile function
 *     pointer (pProtectFunc) instead;
 *   - the fetch has to MISS the instruction cache: a fetch that is served from
 *     the cache never reaches the bus, so it is neither refused nor recorded,
 *     and a line left over from a previously flashed image even lets stale
 *     code run.  Measured on the board (case 002, same mechanism): without the
 *     cache flush the configuration reported RPTS = 0; flushing the cache
 *     right before the triggering call (the call the original case makes
 *     there) recorded the violation.  The function is given a section of its
 *     own with 64-byte alignment (so its first line belongs to it alone) and a
 *     body several cache lines long, so one call always crosses lines.
 *
 * Expected behaviour:
 *   - SADDR / EADDR / RPTEN / PTEN of MPU0 channel 0 are programmed as
 *     requested and report back accordingly;
 *   - the status is clear while only the configuration is exercised;
 *   - the call of the protected function is refused and sets RPTS bit 0, so
 *     the read protection state reads 0x0001; the core stops on that fetch
 *     (no trap, no return), which is expected and is what the debugger check
 *     in step 4 confirms.
 * NOTE: A protection violation is reported through the MPU status registers
 *       (and would be forwarded to the FCU by its MPU0 channel).  Measured on
 *       the board a refused instruction fetch does not return and does not
 *       raise a trap, so unlike the original case this port cannot keep running
 *       after the violating call; every check that the firmware can make is
 *       printed before it.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* MPU instance / channel under test */
#define TEST_MPU_INSTANCE           (HAL_MPU_INSTANCE_0_IBUS)
#define TEST_MPU_CHANNEL            (0U)

/* Protected range: derived from the protected function address.
   The window starts on the cache line that holds the first instruction of the
   protected function and is 256 bytes long, so that the entries of the
   protected function (which is placed in a section of its own, see
   Mpu_ProtectFunc()) can only ever be fetched by a call of that function. */
#define TEST_RANGE_LENGTH           (256U)
#define TEST_RANGE_ALIGN            (0x3FU)

/* Private variables ---------------------------------------------------------*/
static HAL_MPU_HandleTypeDef hmpu_dev;        /*!< MPU device handle           */
static uint32          failures = 0U;         /*!< failed checks               */

static HAL_SMU_HandleTypeDef hsmu_clk;   /*!< SMU handle (lock / state / error) */

/* Volatile input / output of the protected function.  They are volatile so
   that the compiler cannot fold the arithmetic chain into a constant and drop
   the body, and they are globals (not locals) so that the function needs no
   stack frame. */
static volatile uint32 protect_seed = 1U;     /*!< input of the arithmetic    */
static volatile uint32 protect_sink = 0U;     /*!< side effect of the chain   */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void Check(const char *name, uint32 condition);
static uint32 Mpu_ProtectFunc(void);
static uint32 Iport_ReadStatus(void);

/* The call goes through a volatile function pointer on purpose: the function
   has no side effect that the compiler has to keep and its return value is not
   used by the test, so a direct "(void)Mpu_ProtectFunc();" is removed entirely
   at -Og and no instruction fetch of the protected range ever happens. */
static uint32 (* volatile pProtectFunc)(void) = Mpu_ProtectFunc;

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    uint32 start;
    uint32 end;
    uint32 rd_start;
    uint32 rd_end;
    MPU_InitTypeDef mpu_readback;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n\r\n ***** MPU Test ***** \r\n");
    printf("case : MPU_IT_DRV_001 (I-Port read protection, channel 0)\r\n");
    delay_ms(500U);

    /* ---- Step 1: protected range -------------------------------- */
    start = ((uint32)(unsigned long)&Mpu_ProtectFunc) & ~TEST_RANGE_ALIGN;
    end   = start + TEST_RANGE_LENGTH;

    printf("\r\n-----------------protected range----------------- \r\n");
    printf("Mpu_ProtectFunc  : 0x%08X\r\n", PRINT_U32((uint32)(unsigned long)&Mpu_ProtectFunc));
    printf("SADDR / EADDR    : 0x%08X / 0x%08X\r\n", PRINT_U32(start), PRINT_U32(end));

    /* ---- Step 2: configure the MPU0 channel ---------------------- */
    __HAL_CLEAR_STRUCT(&hmpu_dev);
    hmpu_dev.Instance = TEST_MPU_INSTANCE;
    /* The channel control functions require an initialized handle: this case
       drives them directly, so the READY state is set up explicitly (no
       channel is programmed by HAL_MPU_Init() here) */
    hmpu_dev.State = HAL_MPU_STATE_READY;

    HAL_MPU_SetAddressRange(&hmpu_dev, TEST_MPU_CHANNEL, start, end);
    Check("SADDR read-back", (MPU0_Channel0->SADDR == start));
    Check("EADDR read-back", (MPU0_Channel0->EADDR == end));
    /* read the same range back through the HAL API (V1.2); the register reads
       above stay as the white-box cross check of the original test case */
    (void)HAL_MPU_GetAddressRange(&hmpu_dev, TEST_MPU_CHANNEL, &rd_start, &rd_end);
    Check("range read back by HAL_MPU_GetAddressRange",
          (((rd_start == start) && (rd_end == end)) ? 1U : 0U));

    HAL_MPU_ReadProtectCmd(&hmpu_dev, TEST_MPU_CHANNEL, MPU_ENABLE);
    Check("RPTEN bit0 set by HAL_MPU_ReadProtectCmd",
          ((HAL_MPU_GetIPortBlock(TEST_MPU_INSTANCE)->RPTEN & 0x0001UL) != 0U));
    (void)HAL_MPU_GetChannelConfig(&hmpu_dev, TEST_MPU_CHANNEL, &mpu_readback);
    Check("RPTEN bit0 read back by HAL_MPU_GetChannelConfig",
          ((mpu_readback.ReadProtectEnable != 0U) ? 1U : 0U));

    HAL_MPU_Cmd(&hmpu_dev, TEST_MPU_CHANNEL, MPU_ENABLE);
    Check("PTEN bit0 set by HAL_MPU_Cmd",
          ((HAL_MPU_GetIPortBlock(TEST_MPU_INSTANCE)->PTEN & 0x0001UL) != 0U));
    (void)HAL_MPU_GetChannelConfig(&hmpu_dev, TEST_MPU_CHANNEL, &mpu_readback);
    Check("PTEN bit0 read back by HAL_MPU_GetChannelConfig",
          ((mpu_readback.ChannelEnable != 0U) ? 1U : 0U));
    Check("MPU0 reports no write protection enable",
          ((mpu_readback.WriteProtectEnable == 0U) ? 1U : 0U));

    delay_ms(100);

    /* ---- Step 3: verification that needs no violating fetch ------ */
    /* Everything below runs with the protection enabled but without touching
       the protected range, so that the whole HAL configuration path of the
       case can be checked on the target. */
    printf("\r\n-----------------configuration------------------------ \r\n");

    HAL_MPU_ClearStatus(&hmpu_dev, TEST_MPU_CHANNEL);
    Check("status clear before the violating fetch",
          ((Iport_ReadStatus() == 0U) ? 1U : 0U));
    Check("HAL_MPU_GetReadProtectStatus = 0 before the violating fetch",
          ((HAL_MPU_GetReadProtectStatus(&hmpu_dev, TEST_MPU_CHANNEL) == 0U) ? 1U : 0U));

    /* disable / enable round trip of both control bits (no fetch involved) */
    HAL_MPU_ReadProtectCmd(&hmpu_dev, TEST_MPU_CHANNEL, MPU_DISABLE);
    Check("RPTEN bit0 cleared by HAL_MPU_ReadProtectCmd",
          ((HAL_MPU_GetIPortBlock(TEST_MPU_INSTANCE)->RPTEN & 0x0001UL) == 0U));
    HAL_MPU_Cmd(&hmpu_dev, TEST_MPU_CHANNEL, MPU_DISABLE);
    Check("PTEN bit0 cleared by HAL_MPU_Cmd",
          ((HAL_MPU_GetIPortBlock(TEST_MPU_INSTANCE)->PTEN & 0x0001UL) == 0U));
    (void)HAL_MPU_GetChannelConfig(&hmpu_dev, TEST_MPU_CHANNEL, &mpu_readback);
    Check("RPTEN / PTEN cleared (read back through the HAL API)",
          (((mpu_readback.ReadProtectEnable == 0U) &&
            (mpu_readback.ChannelEnable == 0U)) ? 1U : 0U));

    HAL_MPU_ReadProtectCmd(&hmpu_dev, TEST_MPU_CHANNEL, MPU_ENABLE);
    HAL_MPU_Cmd(&hmpu_dev, TEST_MPU_CHANNEL, MPU_ENABLE);
    Check("RPTEN bit0 set again",
          ((HAL_MPU_GetIPortBlock(TEST_MPU_INSTANCE)->RPTEN & 0x0001UL) != 0U));
    Check("PTEN bit0 set again",
          ((HAL_MPU_GetIPortBlock(TEST_MPU_INSTANCE)->PTEN & 0x0001UL) != 0U));

    /* A status bit may be recorded while the configuration is exercised: the
       fetch unit prefetches ahead of the program counter, and a prefetched
       address inside the protected range is recorded even when it is not
       architecturally demanded (no trap follows, the core keeps running).
       Requiring the status to be untouched is therefore not a valid check;
       what has to hold is that the status can be cleared and reads 0 right
       before the trigger, which is what the case verifies here. */
    HAL_MPU_ClearStatus(&hmpu_dev, TEST_MPU_CHANNEL);
    Check("status cleared right before the violating fetch",
          ((Iport_ReadStatus() == 0U) ? 1U : 0U));

    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(failures));

    /* ---- Step 4: the violating fetch ---------------------------- */
    /* This is the step the whole case is about.  Measured on the board: the
       refused instruction fetch does NOT complete and does NOT raise a trap;
       the core stops on it (the debugger loses the hart as well), while the
       violation is recorded, so RPTS reads 0x00000001 afterwards.  There is
       therefore no way to continue in the same run: the status cannot be read
       and cleared from the firmware, and the case is written so that every
       check that can be made from the firmware has already been printed above.
       Use the debugger to confirm the recorded violation, then reset the board
       to run the case again. */
    printf("\r\n-----------------violating fetch----------------- \r\n");
    printf("the next instruction fetch enters the protected range of MPU0,\r\n");
    printf("it is refused, and the core stops on it (no trap, no return).\r\n");
    printf("expected on the debugger : MPU0 RPTS = 0x00000001\r\n");
    printf("reset the board to run the case again.\r\n");
    delay_ms(500U);

    /* The cache has to be cleared first: a fetch that is served from the cache
       never reaches the bus, so it is neither refused nor recorded (and a line
       left over from a previous image would let stale code run as well).  This
       is the call the original case uses before its trigger. */
    CLEAR_CACHE();
    (void)pProtectFunc();          /* the core stops on this fetch */

    /* not reached */
    while (1)
    {
    }
}

/**
 * @brief  Read the read-protection status of the MPU0 instruction port.
 * @note   MPU0 uses the I-Port register layout (PTEN / RPTEN / RPTS), which
 *         differs from the D-Port layout of MPU1..MPU4, so the I-Port block is
 *         addressed through HAL_MPU_GetIPortBlock().
 * @param  None
 * @retval RPTS register value.
 */
static uint32 Iport_ReadStatus(void)
{
    return (uint32)HAL_MPU_GetIPortBlock(TEST_MPU_INSTANCE)->RPTS;
}

/**
 * @brief  The protected function.
 * @note   Placement matters: the function lives in a section of its own
 *         (.text.mpu_test, collected by the "*(.text.*)" rule of the linker
 *         script) and is 64-byte aligned, so its first instruction starts on a
 *         cache line boundary and the whole line belongs to this function.
 * @note   Length matters as well: an instruction fetch that is served from the
 *         cache never reaches the bus, and the I-Port read protection only
 *         reports the fetches that do reach it.  A two instruction body would
 *         be covered by the line the surrounding code had already fetched and
 *         no violation would be reported at all - that is exactly what the
 *         first revision of this port did.  The arithmetic chain below keeps
 *         the body several cache lines long.
 * @note   No stack frame: the chain works on registers and global volatile
 *         variables only, so the function body is self contained.
 * @param  None
 * @retval 3 (a + b).  The chain feeds protect_sink and is what makes the
 *         compiler emit the body at all.
 */
static uint32 __attribute__((noinline, section(".text.mpu_test"), aligned(64)))
Mpu_ProtectFunc(void)
{
    uint32 a = 1U;
    uint32 b = 2U;
    uint32 v = protect_seed;

    v = (v * 3U) + 1U;      v = (v >> 1) + 5U;      v = (v * 5U) + 3U;      v = v ^ 0x00A5A5A5U;
    v = (v * 3U) + 1U;      v = (v >> 1) + 5U;      v = (v * 5U) + 3U;      v = v ^ 0x00A5A5A5U;
    v = (v * 3U) + 1U;      v = (v >> 1) + 5U;      v = (v * 5U) + 3U;      v = v ^ 0x00A5A5A5U;
    v = (v * 3U) + 1U;      v = (v >> 1) + 5U;      v = (v * 5U) + 3U;      v = v ^ 0x00A5A5A5U;
    v = (v * 3U) + 1U;      v = (v >> 1) + 5U;      v = (v * 5U) + 3U;      v = v ^ 0x00A5A5A5U;
    v = (v * 3U) + 1U;      v = (v >> 1) + 5U;      v = (v * 5U) + 3U;      v = v ^ 0x00A5A5A5U;
    v = (v * 3U) + 1U;      v = (v >> 1) + 5U;      v = (v * 5U) + 3U;      v = v ^ 0x00A5A5A5U;
    v = (v * 3U) + 1U;      v = (v >> 1) + 5U;      v = (v * 5U) + 3U;      v = v ^ 0x00A5A5A5U;
    v = (v * 3U) + 1U;      v = (v >> 1) + 5U;      v = (v * 5U) + 3U;      v = v ^ 0x00A5A5A5U;
    v = (v * 3U) + 1U;      v = (v >> 1) + 5U;      v = (v * 5U) + 3U;      v = v ^ 0x00A5A5A5U;

    protect_sink = v;

    return (a + b);
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition == 0U)
    {
        failures++;
    }
    printf("%-46s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Configure the system clock tree using the HAL SMU / PMU drivers.
 * @note   Same clock tree as the CLINT / CMU reference suites: OSC 20 MHz as
 *         the PLL source, PLLDivN = 20 / PLLDivF = 180 / PLLDivQ = 1 /
 *         PLLDivR = 4 -> 180 MHz VCO, AXI4Bus3 = /2, APBBus0 = /2,
 *         APBBus1 = /2, CANX2 = /8; the 2.5V LDO is scaled to 2.78 V and the
 *         1.2V LDO to 1.34 V as in the reference suites.
 * @note   Clock tree order (the order the chip requires, and the order the
 *         vendor test case uses): configure the oscillators and the PLL and
 *         switch the system clock to it, then write the bus clock dividers.
 *         HAL_SMU_OscConfig() programs the EFLASH controller clock (CLKFRQ)
 *         before the switch and lets it follow the new system clock afterwards
 *         (EFLASH_CLK_UPDATE), so no explicit HAL_FLASH_SetClockFrequency() is
 *         needed here; it also updates SystemCoreClock together with the HAL
 *         time base.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef  SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef   SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it (CLKFRQ above), so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Set the bus clock dividers (the system clock source is already set by
       HAL_SMU_OscConfig() above) */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/

