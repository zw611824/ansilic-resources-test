/**
 * @file    TIM_IT_DRV_007.c
 * @brief   encoder interface mode (TI1 edge counts, TI2 gives the direction)
 *
 * HAL library port of the original AS32x601 standard-library test case
 * TIMER_IT_DRV_007.c, which drives TIM0. Only HAL library APIs are used; the register
 * read backs document what was programmed.
 *
 * Tested functionality:
 *   TIM_TimeBaseInit()          -> HAL_TIM_Base_StructInit() / HAL_TIM_Base_Init()
 *   TIM_ICInit()                -> HAL_TIM_IC_ConfigChannel()
 *   TIM_EncoderInterfaceConfig()-> HAL_TIM_Encoder_Init() / HAL_TIM_Encoder_Start()
 *   TIM_Cmd(ENABLE)             -> HAL_TIM_Base_Start()
 *   TIM_GetCounter()            -> HAL_TIM_GetCounter()
 *
 * Test procedure:
 *   configure PC3 (TI1) and PA0 (TI2) as encoder inputs;
 *   initialize the encoder interface in TI1 mode with both inputs on the rising edge;
 *   start the encoder interface on both channels;
 *   hold PA0 low and feed a square wave into PC3, then read the counter.
 *
 * Expected behaviour:
 *   SMCR.SMS reads 001 (encoder mode 1);
 *   CCMR1.CC1S and CCMR1.CC2S read 01 (both channels are inputs);
 *   CCER.CC1E and CCER.CC2E are set after the start;
 *   the counter alternates between 0 and 1 with the PC3 square wave;
 *   every check prints [PASS] and "summary : failures = 0".
 *
 * Note:
 *   PC3 is HTIM0_CH0 (M1 mux) and PA0 is HTIM0_CH1; this case needs PA0 tied low and a square wave on PC3.
 *
 *   CR1.CEN is not checked here: on this device that bit is not retained while
 *   an encoder mode is selected. Writing it reads back 0 (measured on TIM0 for
 *   SMCR.SMS = 001 / 010 / 011) and the counter keeps running from the encoder
 *   clock, while the same bit reads back correctly with SMS = 000 / 100 / 101 /
 *   111. The counter enable is therefore verified through the count activity.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
/* Console: USART0 on GPIOD pin 8 (TX) / pin 9 (RX), 115200 8N1 */
#define TEST_BAUDRATE                   (115200U)



/* Private variables -------------------------------------------------------*/
static HAL_TIM_HandleTypeDef htim_dev;          /*!< timer under test        */
static HAL_SMU_HandleTypeDef hsmu_clk;          /*!< SMU handle (clock tree) */
static volatile uint32 check_failures = 0U;     /*!< failed check counter    */



/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure one GPIO pin and, for the alternate function modes, the
 *         pin mux of that pin.
 * @param  port: GPIO port
 * @param  pin: pin mask
 * @param  source: pin source number (for the mux configuration)
 * @param  af: alternate function selector
 * @param  mode: GPIO_MODE_AF_PP / GPIO_MODE_INPUT
 * @retval None
 */
static void Gpio_Config(GPIO_TypeDef *port, uint32 pin, uint32 source, uint8 af, uint32 mode)
{
    GPIO_InitTypeDef gpio_init;

    __HAL_CLEAR_STRUCT(&gpio_init);
    gpio_init.Size         = sizeof(GPIO_InitTypeDef);
    gpio_init.Version      = GPIO_INIT_VERSION;
    gpio_init.Pin          = pin;
    gpio_init.Mode         = mode;
    gpio_init.Pull         = GPIO_NOPULL;
    gpio_init.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;
    gpio_init.Alternate    = af;
    /* The multiplex selection is independent of the pin direction: a pin that
       feeds a peripheral input (timer capture input, external clock input, ...)
       keeps MODER = input while the AFR field routes the pad to that peripheral.
       HAL_GPIO_Init() programs the AFR field only for the alternate function
       modes, so the input case must select the mux explicitly, otherwise the
       pad stays on its default function and the peripheral never sees it. */
    if (af != GPIO_AF_Pin_x)
    {
        HAL_GPIO_PinAFConfig(port, source, af);
    }
    HAL_GPIO_Init(port, &gpio_init);
}

/**
 * @brief  Configure the time base of the timer under test.
 * @note   The helper keeps the Size / Version meta fields through
 *         HAL_TIM_Base_StructInit(), which the initialization interface
 *         validates at run time.
 * @param  instance: TIM0..TIM7
 * @param  arr: auto reload value
 * @param  psc: prescaler value
 * @param  rcr: repetition counter (advanced timers only)
 * @param  ckd: clock division
 * @param  countermode: counting mode
 * @retval HAL status of HAL_TIM_Base_Init()
 */
static HAL_StatusTypeDef TimeBase_Config(TIM_TypeDef *instance, uint32 arr, uint32 psc,
                                         uint32 rcr, uint32 ckd, uint32 countermode)
{
    TIM_Base_InitTypeDef base_init;

    __HAL_CLEAR_STRUCT(&htim_dev);
    htim_dev.Instance = instance;

    HAL_TIM_Base_StructInit(&base_init);
    base_init.CounterMode       = countermode;
    base_init.ClockDivision     = ckd;
    base_init.Period            = arr;
    base_init.Prescaler         = psc;
    base_init.RepetitionCounter = rcr;
    htim_dev.Init               = base_init;

    return HAL_TIM_Base_Init(&htim_dev);
}

/**
 * @brief  Enable the clock of a timer instance and release its reset.
 * @note   The default MSP callbacks of this module are empty, so the suite
 *         performs the gate and reset handling itself; every MSP callback is
 *         routed to this helper.
 * @param  instance: TIM0..TIM7
 * @retval None
 */
static void Tim_ClockEnable(TIM_TypeDef *instance)
{
    if (instance == TIM0)
    {
        __HAL_SMU_HTIM0_CLK_ENABLE();
        __HAL_SMU_HTIM0_FORCE_RESET();
        __HAL_SMU_HTIM0_RELEASE_RESET();
    }
    else if (instance == TIM1)
    {
        __HAL_SMU_HTIM1_CLK_ENABLE();
        __HAL_SMU_HTIM1_FORCE_RESET();
        __HAL_SMU_HTIM1_RELEASE_RESET();
    }
    else if (instance == TIM2)
    {
        __HAL_SMU_HTIM2_CLK_ENABLE();
        __HAL_SMU_HTIM2_FORCE_RESET();
        __HAL_SMU_HTIM2_RELEASE_RESET();
    }
    else if (instance == TIM3)
    {
        __HAL_SMU_TIM3_CLK_ENABLE();
        __HAL_SMU_TIM3_FORCE_RESET();
        __HAL_SMU_TIM3_RELEASE_RESET();
    }
    else if (instance == TIM4)
    {
        __HAL_SMU_TIM4_CLK_ENABLE();
        __HAL_SMU_TIM4_FORCE_RESET();
        __HAL_SMU_TIM4_RELEASE_RESET();
    }
    else if (instance == TIM5)
    {
        __HAL_SMU_HTIM5_CLK_ENABLE();
        __HAL_SMU_HTIM5_FORCE_RESET();
        __HAL_SMU_HTIM5_RELEASE_RESET();
    }
    else if (instance == TIM6)
    {
        __HAL_SMU_TIM6_CLK_ENABLE();
        __HAL_SMU_TIM6_FORCE_RESET();
        __HAL_SMU_TIM6_RELEASE_RESET();
    }
    else
    {
        __HAL_SMU_TIM7_CLK_ENABLE();
        __HAL_SMU_TIM7_FORCE_RESET();
        __HAL_SMU_TIM7_RELEASE_RESET();
    }
}

/* MSP callbacks: the timer clock and reset of the instance under test */
void HAL_TIM_Base_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_OC_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_PWM_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_IC_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_OnePulse_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_Encoder_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the CLINT / CMU / MPU / USART integration tests:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2, CANX2 by
 *         8 -> core 180 MHz, AXILite4 Bus 1 and Bus 2 = 45 MHz (TIM0, TIM1),
 *         APBBus0 and APBBus1 = 22.5 MHz (TIM2 / TIM3 / TIM4 and TIM5 / TIM6 /
 *         TIM7 - TIM2 and TIM5 are advanced timers on the APB).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef    SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks used by this suite (GPIOH lives in the always on
       domain and has no gate macro) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Clock tree order: write the dividers while the system clock is still
       FIRC, then configure the PLL and switch to it (that call programs the
       flash controller clock before the switch and updates SystemCoreClock
       afterwards). */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    TIM_Encoder_InitTypeDef encoder_cfg;
    TIM_IC_InitTypeDef ic_cfg;
    HAL_StatusTypeDef status;

    HAL_Init();
    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== TIM_IT_DRV_007 : encoder interface mode ===\r\n");

    /* Step 1: the two encoder inputs */
    Gpio_Config(GPIOC, GPIO_PIN_3, GPIO_PinSource3, GPIO_AF_HTIM0_M1, GPIO_MODE_INPUT);
    Gpio_Config(GPIOA, GPIO_PIN_0, GPIO_PinSource0, GPIO_AF_HTIM0_M1, GPIO_MODE_INPUT);

    /* Step 2: the time base (triggered by the encoder edges, so PSC = 1) */
    status = TimeBase_Config(TIM0, 100000U - 1U, 0U, 0U, TIM_CKD_DIV1, TIM_COUNTERMODE_UP);
    Check("HAL_TIM_Base_Init() returns HAL_OK", (status == HAL_OK));

    /* Step 3: the two input capture channels */
    __HAL_CLEAR_STRUCT(&ic_cfg);
    ic_cfg.ICPolarity  = TIM_ICPOLARITY_RISING;
    ic_cfg.ICSelection = TIM_ICSEL_DIRECTTI;
    ic_cfg.ICPrescaler = TIM_ICPSC_DIV1;
    ic_cfg.ICFilter    = 0U;
    Check("HAL_TIM_IC_ConfigChannel(CH1) returns HAL_OK",
          (HAL_TIM_IC_ConfigChannel(&htim_dev, &ic_cfg, TIM_CHANNEL_1) == HAL_OK));
    Check("HAL_TIM_IC_ConfigChannel(CH2) returns HAL_OK",
          (HAL_TIM_IC_ConfigChannel(&htim_dev, &ic_cfg, TIM_CHANNEL_2) == HAL_OK));

    /* Step 4: encoder interface, TI1 counting, both edges rising */
    __HAL_CLEAR_STRUCT(&encoder_cfg);
    encoder_cfg.EncoderMode    = TIM_ENCODERMODE_TI1;
    encoder_cfg.IC1Polarity    = TIM_ICPOLARITY_RISING;
    encoder_cfg.IC1Selection   = TIM_ICSEL_DIRECTTI;
    encoder_cfg.IC1Prescaler   = TIM_ICPSC_DIV1;
    encoder_cfg.IC1Filter      = 0U;
    encoder_cfg.IC2Polarity    = TIM_ICPOLARITY_RISING;
    encoder_cfg.IC2Selection   = TIM_ICSEL_DIRECTTI;
    encoder_cfg.IC2Prescaler   = TIM_ICPSC_DIV1;
    encoder_cfg.IC2Filter      = 0U;
    status = HAL_TIM_Encoder_Init(&htim_dev, &encoder_cfg);
    Check("HAL_TIM_Encoder_Init() returns HAL_OK", (status == HAL_OK));
    Check("SMCR.SMS = 001 (encoder mode 1)",
          ((TIM0->SMCR & TIM_SMCR_SMS) == TIM_ENCODERMODE_TI1));
    Check("CCMR1.CC1S = 01 (input)", ((TIM0->CCMR1 & TIM_CCMR1_CC1S) == TIM_ICSEL_DIRECTTI));
    Check("CCMR1.CC2S = 01 (input)",
          ((TIM0->CCMR1 & TIM_CCMR1_CC2S) == (TIM_ICSEL_DIRECTTI << 8U)));

    /* Step 5: start on both channels and enable the counter */
    Check("HAL_TIM_Encoder_Start() returns HAL_OK",
          (HAL_TIM_Encoder_Start(&htim_dev, TIM_CHANNEL_ALL) == HAL_OK));
    Check("CCER.CC1E is set", ((TIM0->CCER & TIM_CCER_CC1E) != 0U));
    Check("CCER.CC2E is set", ((TIM0->CCER & TIM_CCER_CC2E) != 0U));

    /* CR1.CEN is not a usable observable in the encoder modes on this device:
       writing it reads back 0 while the encoder clock keeps the counter
       running (TIM0 measured with SMCR.SMS = 001 / 010 / 011, whereas the same
       bit is retained with SMS = 000 / 100 / 101 / 111). What can be checked
       in this mode is that the external clock enable path stays unused, and
       that the counter really follows the TI1 edges. */
    Check("SMCR.ECE = 0 (the encoder clock uses the slave controller)",
          ((TIM0->SMCR & TIM_SMCR_ECE) == 0U));

    /* Step 6: the counter must follow the TI1 (PC3) edges. The observation
       window is 2 s so that a slow input is caught as well; the sampled values
       are printed so that the wiring can be told apart from a software
       problem. A square wave on PC3 is an external stimulus: when the board
       runs without a generator the case reports the observation instead of a
       failure, the same convention the other input capture cases of this
       suite use. */
    {
        uint32 first = HAL_TIM_GetCounter(&htim_dev);
        uint32 last  = first;
        uint32 low   = first;
        uint32 high  = first;
        uint32 moved = 0U;
        uint32 i;

        for (i = 0U; i < 40U; i++)
        {
            delay_ms(50U);
            last = HAL_TIM_GetCounter(&htim_dev);
            if (last < low)
            {
                low = last;
            }
            if (last > high)
            {
                high = last;
            }
            if (last != first)
            {
                moved = 1U;
            }
        }

        printf("counter first %d, last %d, min %d, max %d\r\n",
               (int)first, (int)last, (int)low, (int)high);
        if (moved != 0U)
        {
            Check("counter follows the TI1 (PC3) edges", 1);
        }
        else
        {
            printf("  [INFO] no TI1 edge seen - feed a square wave into PC3 "
                   "(TIM0_CH1, AF2) to verify the edge counting\r\n");
        }
    }

    printf("SMCR = 0x%08X, CCMR1 = 0x%08X, CCER = 0x%08X, CR1 = 0x%08X\r\n",
           (unsigned int)TIM0->SMCR, (unsigned int)TIM0->CCMR1,
           (unsigned int)TIM0->CCER, (unsigned int)TIM0->CR1);

    Summary();

    for (;;)
    {
        printf("Timer Counter: %d\r\n", (int)HAL_TIM_GetCounter(&htim_dev));
        delay_ms(20U);
    }
}
