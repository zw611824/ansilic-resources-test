/**
 * @file    GPIO_IT_DRV_044.c
 * @brief   HAL GPIO integration test case 044 (extension: structure defaults
 *          and port de-initialization).
 *
 * This case is not part of the vendor plan (which has 43 cases): it is an
 * extension that covers the HAL GPIO interfaces none of the one-to-one ports
 * exercises.
 *
 * Tested functionality:
 *   HAL_GPIO_StructInit()  (default value of every field, NULL argument)
 *   HAL_GPIO_Init()          (a structure prepared by StructInit)
 *   HAL_GPIO_DeInit()        (whole port restore, protected pins, NULL port)
 *
 * Test configuration:
 *   GPIOD pins 0..7 : initialized and de-initialized (the port has no pin
 *                     whose reset default function is multiplexed)
 *   GPIOB pins 0..5 : pin 5 (JTAG RSTN) is protected, pins 0..4 are not
 *   GPIOH pins 0..9 : pins 0 / 1 (BOOT0 / BOOT1) are protected, pins 2..9 are not
 *
 * Test procedure (every check is recorded in the observation masks below):
 *   step 1  the StructInit defaults and the NULL argument            checks 0..7
 *   step 2  HAL_GPIO_Init() with the StructInit prepared structure   checks 8..9
 *   step 3  HAL_GPIO_DeInit() restores the whole GPIOD port          checks 10..11
 *   step 4  the protected pins of GPIOB are left untouched           checks 12..13
 *   step 5  the rule is applied per port (GPIOH, ten channels)       check  14
 *           the BOOT pins keep their input pull-up, pins 2..9 are reset
 *   step 6  HAL_GPIO_DeInit() with a NULL port touches no register   check  15
 *
 * Expected behaviour:
 *   The case prints nothing. Bit n of Passed_Mask is set when check n passed and
 *   bit n of Failed_Mask when it failed, so
 *     Failed_Mask == 0x00000000  and  Passed_Mask == 0x0000FFFF  and
 *     Check_Count == 16
 *   means that every check of this case passed. The registers are read back
 *   through the device header, so the case is self checking.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"

/* Private define -----------------------------------------------------------*/
/* GPIOD pins used by steps 2 and 3: every channel of that port is a plain
   GPIO, so the whole port is expected to be restored */
#define GPIOD_TEST_PIN          (GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | \
                                 GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7)

/* GPIOB pins used by step 4: pins 0..4 are plain GPIO, pin 5 is the JTAG RSTN
   pin, whose reset default function is multiplexed (GPIOB_PIN_DEFAULT_FUNC) */
#define GPIOB_TEST_PIN          (GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | \
                                 GPIO_PIN_4)
#define GPIOB_PROTECTED_PIN     (GPIO_PIN_5)
#define GPIOB_PROTECTED_POS     (5U)

/* GPIOH pins used by step 5: the BOOT pins are protected */
#define GPIOH_TEST_PIN          (GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_5 | \
                                 GPIO_PIN_6 | GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9)
#define GPIOH_BOOT_PIN          (GPIO_PIN_0 | GPIO_PIN_1)

/* Number of checks of this case and the expected observation of the masks */
#define CHECK_ALL               ((uint32)0x0000FFFFU)
#define CHECK_TOTAL             (16U)

/* Private variables ---------------------------------------------------------*/
static HAL_SMU_HandleTypeDef hsmu_clk;    /*!< SMU handle (lock / state / error) */
static volatile uint32 Passed_Mask = 0U;  /*!< bit n set when check n passed      */
static volatile uint32 Failed_Mask = 0U;  /*!< bit n set when check n failed      */
static volatile uint32 Check_Count = 0U;  /*!< number of checks that were run     */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void check(uint32 index, uint32 condition);
static uint32 moder_field(GPIO_TypeDef *GPIOx, uint32 pin);
static uint32 oicr_field(GPIO_TypeDef *GPIOx, uint32 pin);
static uint32 im0cr_field(GPIO_TypeDef *GPIOx, uint32 pin);
static void port_snapshot(GPIO_TypeDef *GPIOx, uint32 *buf);
static uint32 port_snapshot_equal(const uint32 *a, const uint32 *b);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;
    uint32 snapshot_before[7];
    uint32 snapshot_after[7];
    uint32 protected_before;
    uint32 protected_after;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Enable the GPIO clock gates used by this case */
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();

    /* ---- Step 1: the StructInit defaults (checks 0..7) ------------------- */

    /* A NULL pointer is rejected without any memory access */
    HAL_GPIO_StructInit(NULL_PTR);

    __HAL_CLEAR_STRUCT(&GPIO_InitStruct);
    HAL_GPIO_StructInit(&GPIO_InitStruct);

    check(0U,  (GPIO_InitStruct.Size == sizeof(GPIO_InitTypeDef)) ? 1U : 0U);
    check(1U,  (GPIO_InitStruct.Version == GPIO_INIT_VERSION) ? 1U : 0U);
    check(2U,  (GPIO_InitStruct.Pin == (uint32)GPIO_PIN_All) ? 1U : 0U);
    check(3U,  (GPIO_InitStruct.Mode == GPIO_MODE_INPUT) ? 1U : 0U);
    check(4U,  (GPIO_InitStruct.Pull == GPIO_NOPULL) ? 1U : 0U);
    check(5U,  (GPIO_InitStruct.DriveCurrent == GPIO_DRIVE_CURRENT_LOW) ? 1U : 0U);
    check(6U,  (GPIO_InitStruct.Alternate == GPIO_AF_Pin_x) ? 1U : 0U);
    check(7U,  ((GPIO_InitStruct.Reserved[0] == 0U) &&
                (GPIO_InitStruct.Reserved[1] == 0U)) ? 1U : 0U);

    /* ---- Step 2: initialize GPIOD pins 0..7 (checks 8..9) ---------------- */

    GPIO_InitStruct.Pin          = GPIOD_TEST_PIN;
    GPIO_InitStruct.Mode         = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

    check(8U,  ((moder_field(GPIOD, 0U) == GPIO_MODE_VALUE_OUTPUT) &&
                (moder_field(GPIOD, 7U) == GPIO_MODE_VALUE_OUTPUT)) ? 1U : 0U);
    check(9U,  (oicr_field(GPIOD, 0U) == GPIO_DRIVE_CURRENT_MEDIUM) ? 1U : 0U);

    /* ---- Step 3: HAL_GPIO_DeInit() restores the whole port (checks 10..11) */

    HAL_GPIO_DeInit(GPIOD);

    check(10U, ((GPIO_READ_REG(GPIOD, RWM0CR) == 0U) &&
                (GPIO_READ_REG(GPIOD, IM0CR) == 0U) &&
                (GPIO_READ_REG(GPIOD, OMCR) == 0U) &&
                (GPIO_READ_REG(GPIOD, OICR) == 0U) &&
                (GPIO_READ_REG(GPIOD, MI0SR) == 0U) &&
                (GPIO_READ_REG(GPIOD, ITYPE0R) == 0U)) ? 1U : 0U);
    check(11U, (GPIO_READ_REG(GPIOD, IMR) == 0x0000FFFFU) ? 1U : 0U);

    /* ---- Step 4: the protected pins of GPIOB (checks 12..13) ------------- */

    __HAL_CLEAR_STRUCT(&GPIO_InitStruct);
    HAL_GPIO_StructInit(&GPIO_InitStruct);
    GPIO_InitStruct.Pin          = GPIOB_TEST_PIN | GPIOB_PROTECTED_PIN;  /* pins 0..5 */
    GPIO_InitStruct.Mode         = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    protected_before = moder_field(GPIOB, GPIOB_PROTECTED_POS);
    HAL_GPIO_DeInit(GPIOB);
    protected_after  = moder_field(GPIOB, GPIOB_PROTECTED_POS);

    check(12U, ((moder_field(GPIOB, 0U) == 0U) &&
                (moder_field(GPIOB, 4U) == 0U)) ? 1U : 0U);
    check(13U, ((protected_after == protected_before) &&
                (protected_after == GPIO_MODE_VALUE_OUTPUT)) ? 1U : 0U);

    /* ---- Step 5: the rule is applied per port, GPIOH has ten channels ----
       The protected BOOT pins are configured as inputs with a pull-up (the
       pins are not driven), the pins 2..9 as push-pull outputs. After the
       de-initialization the pull-up of the BOOT pins must still be there while
       the configuration of pins 2..9 must be back to its reset value. */

    __HAL_CLEAR_STRUCT(&GPIO_InitStruct);
    HAL_GPIO_StructInit(&GPIO_InitStruct);
    GPIO_InitStruct.Pin  = GPIOH_BOOT_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(GPIOH, &GPIO_InitStruct);

    GPIO_InitStruct.Pin          = GPIOH_TEST_PIN;
    GPIO_InitStruct.Mode         = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull         = GPIO_NOPULL;
    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    HAL_GPIO_Init(GPIOH, &GPIO_InitStruct);

    HAL_GPIO_DeInit(GPIOH);

    check(14U, ((im0cr_field(GPIOH, 0U) == GPIO_PULLUP) &&
                (im0cr_field(GPIOH, 1U) == GPIO_PULLUP) &&
                (moder_field(GPIOH, 2U) == 0U) &&
                (moder_field(GPIOH, 9U) == 0U) &&
                (im0cr_field(GPIOH, 2U) == 0U)) ? 1U : 0U);

    /* ---- Step 6: a NULL port is rejected without any register access ----- */

    port_snapshot(GPIOD, snapshot_before);
    HAL_GPIO_DeInit(NULL_PTR);
    port_snapshot(GPIOD, snapshot_after);

    check(15U, port_snapshot_equal(snapshot_before, snapshot_after));

    /* Every check has been recorded; the loop keeps the observables alive */
    while (1)
    {
        delay_ms(500U);
    }
}

/**
 * @brief  Record the result of one check.
 * @param  index: check number, used as the bit position of the mask.
 * @param  condition: 1 when the check passed, 0 when it failed.
 * @retval None
 */
static void check(uint32 index, uint32 condition)
{
    Check_Count++;

    if (condition != 0U)
    {
        Passed_Mask |= ((uint32)0x01U << index);
    }
    else
    {
        Failed_Mask |= ((uint32)0x01U << index);
    }
}

/**
 * @brief  Read the RWM0CR mode field of one pin (00 input, 01 output, 10 analog,
 *         11 IDDQ).
 * @param  GPIOx: port to read.
 * @param  pin: pin index (0..15).
 * @retval The two bit mode field of that pin.
 */
static uint32 moder_field(GPIO_TypeDef *GPIOx, uint32 pin)
{
    return ((GPIO_READ_REG(GPIOx, RWM0CR) >> (pin * 2U)) & 0x03U);
}

/**
 * @brief  Read the OICR drive current field of one pin.
 * @param  GPIOx: port to read.
 * @param  pin: pin index (0..15).
 * @retval The two bit drive current field of that pin.
 */
static uint32 oicr_field(GPIO_TypeDef *GPIOx, uint32 pin)
{
    return ((GPIO_READ_REG(GPIOx, OICR) >> (pin * 2U)) & 0x03U);
}

/**
 * @brief  Read the IM0CR pull / input type field of one pin (00 floating,
 *         01 pull-up, 10 pull-down, 11 keep).
 * @param  GPIOx: port to read.
 * @param  pin: pin index (0..15).
 * @retval The two bit input type field of that pin.
 */
static uint32 im0cr_field(GPIO_TypeDef *GPIOx, uint32 pin)
{
    return ((GPIO_READ_REG(GPIOx, IM0CR) >> (pin * 2U)) & 0x03U);
}

/**
 * @brief  Snapshot the seven configuration registers of a port.
 * @param  GPIOx: port to read.
 * @param  buf: buffer of seven words, filled in the order
 *         RWM0CR / IM0CR / OMCR / OICR / MI0SR / ITYPE0R / IMR.
 * @retval None
 */
static void port_snapshot(GPIO_TypeDef *GPIOx, uint32 *buf)
{
    buf[0] = GPIO_READ_REG(GPIOx, RWM0CR);
    buf[1] = GPIO_READ_REG(GPIOx, IM0CR);
    buf[2] = GPIO_READ_REG(GPIOx, OMCR);
    buf[3] = GPIO_READ_REG(GPIOx, OICR);
    buf[4] = GPIO_READ_REG(GPIOx, MI0SR);
    buf[5] = GPIO_READ_REG(GPIOx, ITYPE0R);
    buf[6] = GPIO_READ_REG(GPIOx, IMR);
}

/**
 * @brief  Compare two port snapshots.
 * @param  a: first snapshot.
 * @param  b: second snapshot.
 * @retval 1 when the seven registers are bit identical, 0 otherwise.
 */
static uint32 port_snapshot_equal(const uint32 *a, const uint32 *b)
{
    uint32 i;

    for (i = 0U; i < 7U; i++)
    {
        if (a[i] != b[i])
        {
            return 0U;
        }
    }

    return 1U;
}

/**
 * @brief  Configure the system clock tree (PLL 180 MHz, as the original test).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef  SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef   SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    HAL_PMU_LDO2v5VOLSca(&hpmu, 0xf);
    HAL_PMU_LDO1v2VOLSca(&hpmu, 0xf);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it (CLKFRQ above), so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Clock tree order: this is the order the chip requires, and the vendor
       test case uses the same one.
         1. Write the bus clock dividers while the system clock is still the
            power-on source (FIRC), so that the new divider values are already
            in place when the faster clock arrives. Writing them AFTER the
            switch instead leaves the buses at their reset dividers for a
            moment at the new core clock: at 180 MHz that is
            AXI4Bus3 = 90 MHz and APBBus0 = 45 MHz, right at their ratings, and
            the core does not survive it (measured on the board: the core
            trapped before the divider write was reached, so no output was
            produced at all).
         2. Program the EFLASH controller clock: the controller must already
            know the final frequency while the code still runs from the flash.
         3. Then configure the PLL and switch the system clock to it; this call
            also updates SystemCoreClock and re-initializes the HAL time base. */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
