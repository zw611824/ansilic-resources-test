/**
 * @file    CMU_IT_DRV_014.c
 * @brief   HAL CMU integration test case 014 (handle life cycle, MSP callbacks,
 *          lock helper and module version macro).
 *
 * Extension test case of the HAL CMU driver: it exercises the parts of the
 * driver that the ported cases 001..013 do not reach, i.e. the two low level
 * MSP callbacks, the shared lock helper and the module version macro. Only HAL
 * library APIs are used.
 *
 * Tested functionality:
 *   HAL_CMU_MspInit() / HAL_CMU_MspDeInit()
 *   HAL_CMU_Init() / HAL_CMU_DeInit()
 *   HAL_CMU_Cmd()
 *   HAL_CMU_GetState() / HAL_CMU_GetError()
 *   CMU_LockHandle() / CMU_UnlockHandle()   (shared internal functions)
 *   __HAL_CMU_MODULE_VERSION
 *   __HAL_CMU_RESET_HANDLE_STATE
 *
 * Test procedure:
 *   1. Initialize the HAL library and configure the system clock tree with the
 *      HAL SMU / PMU drivers (core clock 180 MHz);
 *   2. Check the module version macro;
 *   3. Exercise the bare-metal lock helper: a free handle is locked, a second
 *      lock request is refused with HAL_BUSY, the release restores the handle;
 *   4. Verify that HAL_CMU_Init() calls HAL_CMU_MspInit() exactly once and that
 *      HAL_CMU_DeInit() calls HAL_CMU_MspDeInit() exactly once (both callbacks
 *      are overridden here and count their invocations), and that a following
 *      HAL_CMU_Init() runs HAL_CMU_MspInit() again;
 *   5. Check __HAL_CMU_RESET_HANDLE_STATE();
 *   6. Check that a non-zero MonitoringMode makes HAL_CMU_Init() enable the
 *      monitoring directly, without a following HAL_CMU_Cmd();
 *   7. Check the state gate: a handle forced to BUSY refuses the control calls
 *      with HAL_BUSY and recovers afterwards.
 *
 * Expected behaviour:
 *   - CMU_LockHandle() returns HAL_OK on a free handle, HAL_BUSY while the
 *     handle is locked, and HAL_OK again after CMU_UnlockHandle();
 *   - HAL_CMU_MspInit() runs on every transition RESET -> READY and
 *     HAL_CMU_MspDeInit() on every transition READY -> RESET;
 *   - HAL_CMU_Init() with a non-zero MonitoringMode programs CR.MODE with it;
 *   - a BUSY handle refuses the control calls with HAL_BUSY.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Configuration used by the checks */
#define TEST_WINDOW_LENGTH          (20000U)
#define TEST_HIGH_THRESHOLD         (19200U)
#define TEST_LOW_THRESHOLD          (12800U)

/* Monitoring mode used by the "Init enables the monitoring" check */
#define TEST_MODE                   (CMU_MODE_2)

/* Expected module version (0x0100 = V1.0) */
#define TEST_MODULE_VERSION         (0x0100U)

/* Status flag polling period (ms) */
#define TEST_POLL_MS                (500U)

/* Private variables ---------------------------------------------------------*/
static HAL_CMU_HandleTypeDef hcmu_dev;      /*!< CMU device handle            */
static CMU_InitTypeDef       cmu_init;      /*!< CMU configuration structure  */
static uint32                failures = 0U; /*!< failed checks                */

static uint32 msp_init_count   = 0U;        /*!< HAL_CMU_MspInit() calls      */
static uint32 msp_deinit_count = 0U;        /*!< HAL_CMU_MspDeInit() calls    */

static HAL_SMU_HandleTypeDef hsmu_clk;   /*!< SMU handle (lock / state / error) */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void Check(const char *name, uint32 condition);
static void LoadDefaultConfig(void);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL, 180 MHz core / PLLQ) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== CMU_IT_DRV_014: life cycle / MSP callbacks / lock ===\r\n");

    while (1)
    {
        /* ---- Module version macro -------------------------------------- */
        printf("\r\n-----------------module version----------------- \r\n");
        Check("__HAL_CMU_MODULE_VERSION = 0x0100",
              (__HAL_CMU_MODULE_VERSION == TEST_MODULE_VERSION));
        printf("module version = 0x%X (expected 0x%X)\r\n",
               PRINT_U32(__HAL_CMU_MODULE_VERSION), PRINT_U32(TEST_MODULE_VERSION));

        /* ---- Lock helper (bare metal: single-core lock flag) ----------- */
        printf("\r\n-----------------lock helper----------------- \r\n");
        __HAL_CLEAR_STRUCT(&hcmu_dev);
        hcmu_dev.Instance = CMU_PLLQ;
        __HAL_CMU_RESET_HANDLE_STATE(&hcmu_dev);

        Check("LockHandle on a free handle = HAL_OK",
              (CMU_LockHandle(&hcmu_dev, HAL_MAX_DELAY) == HAL_OK));
        Check("Lock field = HAL_LOCKED", (hcmu_dev.Lock == HAL_LOCKED));
        Check("second LockHandle = HAL_BUSY",
              (CMU_LockHandle(&hcmu_dev, HAL_MAX_DELAY) == HAL_BUSY));
        CMU_UnlockHandle(&hcmu_dev);
        Check("Unlock sets Lock = HAL_UNLOCKED", (hcmu_dev.Lock == HAL_UNLOCKED));
        Check("LockHandle after the release = HAL_OK",
              (CMU_LockHandle(&hcmu_dev, HAL_MAX_DELAY) == HAL_OK));
        CMU_UnlockHandle(&hcmu_dev);

        /* ---- MSP callbacks and the RESET <-> READY transitions --------- */
        printf("\r\n-----------------MSP callbacks----------------- \r\n");
        msp_init_count   = 0U;
        msp_deinit_count = 0U;

        LoadDefaultConfig();
        Check("Init returns HAL_OK", (HAL_CMU_Init(&hcmu_dev) == HAL_OK));
        Check("MspInit called exactly once", (msp_init_count == 1U));
        Check("state = READY", (HAL_CMU_GetState(&hcmu_dev) == HAL_CMU_STATE_READY));
        Check("MspDeInit not called yet", (msp_deinit_count == 0U));

        Check("DeInit returns HAL_OK", (HAL_CMU_DeInit(&hcmu_dev) == HAL_OK));
        Check("MspDeInit called exactly once", (msp_deinit_count == 1U));
        Check("state = RESET", (HAL_CMU_GetState(&hcmu_dev) == HAL_CMU_STATE_RESET));
        Check("MspInit not called again by DeInit", (msp_init_count == 1U));

        Check("re-Init returns HAL_OK", (HAL_CMU_Init(&hcmu_dev) == HAL_OK));
        Check("MspInit called again on re-Init", (msp_init_count == 2U));
        printf("msp_init_count = %u, msp_deinit_count = %u\r\n",
               PRINT_U32(msp_init_count), PRINT_U32(msp_deinit_count));

        /* ---- __HAL_CMU_RESET_HANDLE_STATE ------------------------------ */
        printf("\r\n-----------------__HAL_CMU_RESET_HANDLE_STATE----------------- \r\n");
        hcmu_dev.State = HAL_CMU_STATE_BUSY;
        __HAL_CMU_RESET_HANDLE_STATE(&hcmu_dev);
        Check("ResetHandleState sets State = RESET",
              (hcmu_dev.State == HAL_CMU_STATE_RESET));
        Check("a RESET handle is refused by Cmd",
              (HAL_CMU_Cmd(&hcmu_dev, CMU_ENABLE) == HAL_ERROR));

        /* ---- a non-zero MonitoringMode enables the monitoring ---------- */
        printf("\r\n-----------------Init with a non-zero mode----------------- \r\n");
        LoadDefaultConfig();
        cmu_init.MonitoringMode = TEST_MODE;
        hcmu_dev.Init = cmu_init;
        Check("Init with a non-zero mode = HAL_OK",
              (HAL_CMU_Init(&hcmu_dev) == HAL_OK));
        Check("CR.MODE = the requested mode",
              ((hcmu_dev.Instance->CR & CMU_CR_MODE_Msk) ==
               (TEST_MODE << CMU_CR_MODE_Pos)));

        /* ---- state gate: BUSY is refused, then the handle recovers ----- */
        printf("\r\n-----------------state gate----------------- \r\n");
        hcmu_dev.State = HAL_CMU_STATE_BUSY;
        Check("Cmd on a BUSY handle = HAL_BUSY",
              (HAL_CMU_Cmd(&hcmu_dev, CMU_ENABLE) == HAL_BUSY));
        Check("SetMode on a BUSY handle = HAL_BUSY",
              (HAL_CMU_SetMode(&hcmu_dev, CMU_MODE_1) == HAL_BUSY));
        hcmu_dev.State = HAL_CMU_STATE_READY;
        Check("Cmd accepted again once READY",
              (HAL_CMU_Cmd(&hcmu_dev, CMU_DISABLE) == HAL_OK));

        /* the instance stays initialized for the next round */
        Check("state = READY at the end of the round",
              (HAL_CMU_GetState(&hcmu_dev) == HAL_CMU_STATE_READY));

        printf("\r\nsummary : failures = %u\r\n", PRINT_U32(failures));
        delay_ms(TEST_POLL_MS);
    }
}

/**
 * @brief  Fill the configuration structure with the values used by the checks.
 * @param  None
 * @retval None
 */
static void LoadDefaultConfig(void)
{
    HAL_CMU_StructInit(&cmu_init);
    cmu_init.MonitoringMode = CMU_MODE_0;
    cmu_init.WindowLength   = TEST_WINDOW_LENGTH;
    cmu_init.HighThreshold  = TEST_HIGH_THRESHOLD;
    cmu_init.LowThreshold   = TEST_LOW_THRESHOLD;
    hcmu_dev.Init = cmu_init;
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition == 0U)
    {
        failures++;
    }
    printf("%-46s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Initialize the CMU MSP: enable the CMU clock gate, release the CMU
 *         reset and count the invocation.
 * @note   Strong override of the weak HAL_CMU_MspInit() of the driver. The
 *         clock gate is enabled and the reset is released (assert then
 *         release), as the driver default does, and the call is counted so
 *         that the life cycle can be checked.
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @retval None
 */
void HAL_CMU_MspInit(HAL_CMU_HandleTypeDef *hcmu)
{
    msp_init_count++;

    if (hcmu->Instance == CMU_FIRC)
    {
        __HAL_SMU_CMU0_CLK_ENABLE();
        __HAL_SMU_CMU0_FORCE_RESET();
        __HAL_SMU_CMU0_RELEASE_RESET();
    }
    else if (hcmu->Instance == CMU_PLLQ)
    {
        __HAL_SMU_CMU1_CLK_ENABLE();
        __HAL_SMU_CMU1_FORCE_RESET();
        __HAL_SMU_CMU1_RELEASE_RESET();
    }
    else if (hcmu->Instance == CMU_PLLR)
    {
        __HAL_SMU_CMU2_CLK_ENABLE();
        __HAL_SMU_CMU2_FORCE_RESET();
        __HAL_SMU_CMU2_RELEASE_RESET();
    }
    else
    {
        __HAL_SMU_CMU3_CLK_ENABLE();
        __HAL_SMU_CMU3_FORCE_RESET();
        __HAL_SMU_CMU3_RELEASE_RESET();
    }
}

/**
 * @brief  De-initialize the CMU MSP and count the invocation.
 * @note   Strong override of the weak HAL_CMU_MspDeInit() of the driver. The
 *         CMU clock gate is deliberately left enabled (the driver default
 *         disables it): the configuration registers have to stay readable so
 *         that this test can check that HAL_CMU_DeInit() cleared them.
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @retval None
 */
void HAL_CMU_MspDeInit(HAL_CMU_HandleTypeDef *hcmu)
{
    (void)hcmu;

    msp_deinit_count++;
}

/**
 * @brief  Configure the system clock tree using the HAL SMU / PMU drivers.
 * @note   Clock tree order (the order the chip requires): the bus clock
 *         dividers are written while the system clock is still the power-on
 *         source (FIRC), then HAL_SMU_OscConfig() programs the EFLASH
 *         controller clock, switches the system clock to the PLL and lets the
 *         flash clock follow. HAL_SMU_OscConfig() performs the EFLASH
 *         synchronization internally (CLKFRQ + EFLASH_CLK_UPDATE), so no
 *         explicit HAL_FLASH_SetClockFrequency() is needed here.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef  SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef   SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it (CLKFRQ above), so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Clock tree order: this is the order the chip requires, and the vendor
       test case uses the same one.
         1. Write the bus clock dividers while the system clock is still the
            power-on source (FIRC), so that the new divider values are already
            in place when the faster clock arrives. Writing them AFTER the
            switch instead leaves the buses at their reset dividers for a
            moment at the new core clock: at 180 MHz that is
            AXI4Bus3 = 90 MHz and APBBus0 = 45 MHz, right at their ratings, and
            the core does not survive it (measured on the board: the core
            trapped before the divider write was reached, so no output was
            produced at all).
         2. Program the EFLASH controller clock: the controller must already
            know the final frequency while the code still runs from the flash.
         3. Then configure the PLL and switch the system clock to it; this call
            also updates SystemCoreClock and re-initializes the HAL time base. */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
