/**
 * @file    RTC_IT_DRV_008.c
 * @brief   HAL RTC integration test case 008: SetAlarm versus SetAlarm_IT, interrupt enable control.
 *
 * HAL_RTC_SetAlarm() reconfigures the match condition without touching the
 * interrupt enable and without consuming the historical alarm flag;
 * HAL_RTC_SetAlarm_IT() additionally enables the interrupt and consumes the flag.
 * The flag is observed directly in CR; the interrupt mode is additionally routed
 * through the PLIC so that the event burst of a match can be observed.
 *
 * Tested functionality:
 *   HAL_RTC_SetAlarm() / HAL_RTC_SetAlarm_IT() / HAL_RTC_GetAlarm()
 *   __HAL_RTC_ENABLE_IT() / __HAL_RTC_DISABLE_IT() / __HAL_RTC_GET_IT_SOURCE()
 *   __HAL_RTC_GET_FLAG() / __HAL_RTC_CLEAR_FLAG()
 *   RTC_IT_ALARM / RTC_FLAG_ALARM
 *   HAL_RTC_GetState() / HAL_RTC_GetError()
 *   HAL_PLIC_Init() (RTC alarm interrupt line)
 *
 * Expected behaviour:
 *   - after a match the hardware sets CR.ALRMT; the polling loop sees it;
 *   - HAL_RTC_SetAlarm() leaves CR.IE unchanged and keeps the historical flag set;
 *   - HAL_RTC_SetAlarm_IT() consumes the historical flag and sets CR.IE;
 *   - the alarm of this device is level type (SRS RTC-REQ-023): while the
 *     comparison set matches, every clear of CR.ALRMT is followed by a new
 *     assertion, so one match makes the callback run many times. The interrupt
 *     step therefore programs a comparison set that matches for one tenth of a
 *     second only (a target a couple of seconds ahead of the calendar), which
 *     bounds the burst; a set that stays true for an hour would keep re-asserting
 *     the flag and starve the main loop;
 *   - __HAL_RTC_GET_IT_SOURCE()/__HAL_RTC_GET_FLAG() follow both bits, and
 *     __HAL_RTC_DISABLE_IT() / __HAL_RTC_CLEAR_FLAG() clear them again.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* RTC divider coefficient. 1785 is the project baseline of the reference test
 * cases of this chip, 1638 is the other value documented by the library SRS;
 * both are legal hardware values (the driver only checks the 27 bit field
 * width). No test below depends on the resulting absolute frequency: the
 * checks are register read-backs or "the counter moved" observations. */
#define TEST_RTC_DIVISION           (1785U)

/* Calendar value used by the cases that need a known starting point */
#define TEST_TIME_HOURS             (15U)
#define TEST_TIME_MINUTES           (48U)
#define TEST_TIME_SECONDS           (0U)
#define TEST_TIME_TOS               (0U)
#define TEST_DATE_CENTURY           (20U)
#define TEST_DATE_YEAR              (25U)
#define TEST_DATE_MONTH             (RTC_Month_July)
#define TEST_DATE_DATE              (21U)
#define TEST_DATE_WEEKDAY           (RTC_Weekday_Monday)

/* Polling slice of the wait loops (ms) */
#define TEST_POLL_MS                (10U)

/* Reporting period of the final idle loop (ms) */
#define TEST_IDLE_MS                (1000U)

/* Timeouts of this case (ms) */
#define TEST_FLAG_TIMEOUT_MS        (3000U)
#define TEST_QUIET_MS               (500U)

/* Distance of the alarm target of the interrupt step, in RTC seconds: the
 * comparison set is programmed that far ahead of the calendar of the moment,
 * so the match window is one tenth of a second long and the burst of the level
 * type alarm is bounded. */
#define TEST_ALARM_AHEAD_S          (2U)

/* Private variables ---------------------------------------------------------*/
static RTC_HandleTypeDef hrtc_dev;          /*!< RTC device handle            */
static RTC_InitTypeDef   rtc_init;          /*!< RTC configuration structure  */
static uint32            failures = 0U;     /*!< failed checks                */

/* Alarm interrupt bookkeeping (filled by the overridden weak callback) */
static volatile uint32   alarm_events = 0U; /*!< callback entries             */
static volatile uint32   alarm_cr_seen = 0U;/*!< CR register at callback time */

/* Bookkeeping of this case */
static uint32          elapsed;
static RTC_AlarmTypeDef alarm;
static uint8           tgt_hours;           /*!< alarm target of step 8       */
static uint8           tgt_minutes;
static uint8           tgt_seconds;

/* Last calendar read back by the report helpers */
static uint8 r_time_hours;
static uint8 r_time_minutes;
static uint8 r_time_seconds;
static uint8 r_time_tos;
static uint8 r_date_century;
static uint8 r_date_year;
static uint8 r_date_month;
static uint8 r_date_date;
static uint8 r_date_weekday;

/* Private function prototypes -----------------------------------------------*/
static void Check(const char *name, uint32 condition);
static void SystemClock_Init(void);
static void Rtc_Handle_Setup(void);
static HAL_StatusTypeDef Rtc_Start(void);
static HAL_StatusTypeDef Rtc_SetCalendar(uint8 hours, uint8 minutes, uint8 seconds, uint8 tos,
                                         uint8 century, uint8 year, uint8 month, uint8 date,
                                         uint8 weekday);
static HAL_StatusTypeDef Rtc_GetCalendar(void);
static uint8 Rtc_MonthToNumber(uint8 month);
static const char *Rtc_WeekdayName(uint8 weekday);
static void Rtc_PrintCalendar(const char *tag);
static void Plc_RouteRtcIrq(void);

/* Exported interrupt entry ------------------------------------------------*/
/**
 * @brief  RTC interrupt entry, called by the shared PLIC dispatch table.
 * @note   Overrides the weak RTC_IRQ_Handler() of the PLIC driver; it hands the
 *         event to the HAL RTC interrupt handler, which clears the alarm flag
 *         and then calls HAL_RTC_AlarmEventCallback().
 */
void RTC_IRQ_Handler(void)
{
    HAL_RTC_AlarmIRQHandler(&hrtc_dev);
}

/**
 * @brief  Alarm event callback (weak function of the HAL RTC driver).
 * @note   Counts the events and snapshots CR so that the cases can observe the
 *         flag state the driver left behind. It must not block and must not
 *         call a locking RTC interface (interrupt context).
 * @param  hrtc pointer to a RTC_HandleTypeDef structure.
 * @retval None
 */
void HAL_RTC_AlarmEventCallback(RTC_HandleTypeDef *hrtc)
{
    UNUSED(hrtc);

    alarm_events++;
    alarm_cr_seen = hrtc_dev.Instance->CR;
}

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock tree */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n\r\n==== RTC_IT_DRV_008: SetAlarm versus SetAlarm_IT, interrupt enable control ====\r\n");
    printf("Data : %s\r\n", __DATE__);
    printf("Time : %s\r\n", __TIME__);

        /* ---- Step 1: initialization, interrupt disabled -------------------- */
        /* The alarm line must be routed through the PLIC (SRS RTC-REQ-014): the
           RTC only drives CR.IE, the shared trap entry dispatches the line to
           RTC_IRQ_Handler() overridden above. Without the route a still true
           comparison set asserts the request but no interrupt is ever delivered. */
        Plc_RouteRtcIrq();
        Check("RTC init", (Rtc_Start() == HAL_OK));
        Check("calendar programmed",
              (Rtc_SetCalendar(TEST_TIME_HOURS, TEST_TIME_MINUTES, TEST_TIME_SECONDS,
                               TEST_TIME_TOS, TEST_DATE_CENTURY, TEST_DATE_YEAR,
                               TEST_DATE_MONTH, TEST_DATE_DATE,
                               TEST_DATE_WEEKDAY) == HAL_OK));

        __HAL_RTC_DISABLE_IT(&hrtc_dev, RTC_IT_ALARM);
        __HAL_RTC_CLEAR_FLAG(&hrtc_dev, RTC_FLAG_ALARM);
        Check("interrupt enable clear at the start", ((RTC->CR & RTC_CR_IE) == 0U));
        Check("alarm flag clear at the start", ((RTC->CR & RTC_CR_ALRMT) == 0U));

        /* ---- Step 2: a match sets the flag (interrupt disabled) ------------ */
        /* A wide comparison set (hours only) keeps the match condition true for a
           whole hour: with the interrupt disabled the flag can be polled without
           any interrupt traffic. */
        __HAL_CLEAR_STRUCT(&alarm);
        HAL_RTC_AlarmStructInit(&alarm);
        alarm.RTC_AlarmTime.RTC_Hours = TEST_TIME_HOURS;
        alarm.RTC_AlarmTimeCompEn = RTC_AlarmTime_Hours;
        alarm.RTC_AlarmDataCompEn = RTC_Alarm_None;
        Check("wide match alarm programmed",
              (HAL_RTC_SetAlarm(&hrtc_dev, &alarm, RTC_FORMAT_BIN) == HAL_OK));
        Check("calendar enabled", (HAL_RTC_Cmd(&hrtc_dev, ENABLE) == HAL_OK));

        elapsed = 0U;
        while (((RTC->CR & RTC_CR_ALRMT) == 0U) && (elapsed < TEST_FLAG_TIMEOUT_MS))
        {
            delay_ms(TEST_POLL_MS);
            elapsed += TEST_POLL_MS;
        }
        printf("alarm flag after %u ms: CR = 0x%X\r\n", PRINT_U32(elapsed),
               PRINT_U32(RTC->CR));
        Check("alarm flag set by the hardware match", ((RTC->CR & RTC_CR_ALRMT) != 0U));
        Check("__HAL_RTC_GET_FLAG reports the flag",
              (__HAL_RTC_GET_FLAG(&hrtc_dev, RTC_FLAG_ALARM) == SET));
        Check("interrupt enable still clear (IT was not enabled by SetAlarm)",
              ((RTC->CR & RTC_CR_IE) == 0U));

        /* ---- Step 3: SetAlarm keeps the flag, does not touch IE ------------ */
        /* The new match condition is not satisfied at the moment it is committed
           (the hour is shifted by one), so nothing re-asserts the flag. */
        __HAL_CLEAR_STRUCT(&alarm);
        HAL_RTC_AlarmStructInit(&alarm);
        alarm.RTC_AlarmTime.RTC_Hours = (uint8)(TEST_TIME_HOURS + 1U);
        alarm.RTC_AlarmTimeCompEn = RTC_AlarmTime_Hours;
        alarm.RTC_AlarmDataCompEn = RTC_Alarm_None;
        Check("non matching alarm accepted by SetAlarm",
              (HAL_RTC_SetAlarm(&hrtc_dev, &alarm, RTC_FORMAT_BIN) == HAL_OK));
        Check("SetAlarm kept the historical flag", ((RTC->CR & RTC_CR_ALRMT) != 0U));
        Check("SetAlarm did not enable the interrupt", ((RTC->CR & RTC_CR_IE) == 0U));

        /* ---- Step 4: SetAlarm_IT consumes the flag and enables the IRQ ----- */
        Check("non matching alarm accepted by SetAlarm_IT",
              (HAL_RTC_SetAlarm_IT(&hrtc_dev, &alarm, RTC_FORMAT_BIN) == HAL_OK));
        Check("SetAlarm_IT consumed the historical flag", ((RTC->CR & RTC_CR_ALRMT) == 0U));
        Check("SetAlarm_IT enabled the interrupt", ((RTC->CR & RTC_CR_IE) != 0U));
        Check("__HAL_RTC_GET_IT_SOURCE reports the enabled interrupt",
              (__HAL_RTC_GET_IT_SOURCE(&hrtc_dev, RTC_IT_ALARM) == SET));
        Check("__HAL_RTC_GET_FLAG reports the cleared flag",
              (__HAL_RTC_GET_FLAG(&hrtc_dev, RTC_FLAG_ALARM) == RESET));

        /* ---- Step 5: the interrupts stay quiet (no match configured) ------- */
        alarm_events = 0U;
        delay_ms(TEST_QUIET_MS);
        Check("no event while the match condition is false", (alarm_events == 0U));

        /* ---- Step 6: the enable bits can be driven from the macros --------- */
        __HAL_RTC_DISABLE_IT(&hrtc_dev, RTC_IT_ALARM);
        Check("__HAL_RTC_DISABLE_IT cleared the interrupt enable",
              ((RTC->CR & RTC_CR_IE) == 0U));
        __HAL_RTC_ENABLE_IT(&hrtc_dev, RTC_IT_ALARM);
        Check("__HAL_RTC_ENABLE_IT set the interrupt enable",
              ((RTC->CR & RTC_CR_IE) != 0U));
        __HAL_RTC_DISABLE_IT(&hrtc_dev, RTC_IT_ALARM);

        /* ---- Step 7: the flag macros follow the register -------------------- */
        __HAL_RTC_CLEAR_FLAG(&hrtc_dev, RTC_FLAG_ALARM);
        Check("flag clear after __HAL_RTC_CLEAR_FLAG with the comparisons off",
              ((RTC->CR & RTC_CR_ALRMT) == 0U));

        /* ---- Step 8: reconfiguring while the IT is enabled ------------------ */
        /* This is the documented prerequisite scenario: the comparison set of
           the moment (hours only) is still true, the set is replaced by a
           condition that does not match yet and the interrupt is left enabled.
           The driver clears the comparison enables before writing CR.ALRMT to
           zero, so the historical flag is consumed although the previous
           condition was still true; the new condition is not satisfied, so the
           flag stays clear.
           The new set compares every time field including the tenth of a
           second, so the match window is one tenth of a second: the event burst
           of the level type alarm is bounded and the firmware keeps running.
           A still true set (hours only) with the interrupt enabled would keep
           re-asserting the flag for a whole hour and starve the main loop. */
        (void)Rtc_GetCalendar();
        tgt_hours   = r_time_hours;
        tgt_minutes = r_time_minutes;
        tgt_seconds = (uint8)(r_time_seconds + TEST_ALARM_AHEAD_S);
        if (tgt_seconds >= 60U)
        {
            tgt_seconds = (uint8)(tgt_seconds - 60U);
            tgt_minutes = (uint8)(tgt_minutes + 1U);
            if (tgt_minutes >= 60U)
            {
                tgt_minutes = 0U;
                tgt_hours = (uint8)((tgt_hours + 1U) % 24U);
            }
        }
        printf("alarm target %02u:%02u:%02u.0\r\n",
               PRINT_U32(tgt_hours), PRINT_U32(tgt_minutes), PRINT_U32(tgt_seconds));
        __HAL_CLEAR_STRUCT(&alarm);
        HAL_RTC_AlarmStructInit(&alarm);
        alarm.RTC_AlarmTime.RTC_Hours         = tgt_hours;
        alarm.RTC_AlarmTime.RTC_Minutes       = tgt_minutes;
        alarm.RTC_AlarmTime.RTC_Seconds       = tgt_seconds;
        alarm.RTC_AlarmTime.RTC_TenthOfSecond = 0U;
        alarm.RTC_AlarmTimeCompEn = RTC_AlarmTime_Hours | RTC_AlarmTime_Minutes |
                                    RTC_AlarmTime_Seconds | RTC_AlarmTime_TenOfSecond;
        alarm.RTC_AlarmDataCompEn = RTC_Alarm_None;
        Check("matching alarm accepted again",
              (HAL_RTC_SetAlarm_IT(&hrtc_dev, &alarm, RTC_FORMAT_BIN) == HAL_OK));
        printf("CR after SetAlarm_IT with the old condition still true = 0x%X\r\n",
               PRINT_U32(RTC->CR));
        Check("SetAlarm_IT consumed the historical flag", ((RTC->CR & RTC_CR_ALRMT) == 0U));
        Check("interrupt enabled again", ((RTC->CR & RTC_CR_IE) != 0U));

        /* Let the match fire: the event counter must grow (the handler clears the
           flag and restores the comparison enables) and the firmware must stay
           responsive, which is only possible when the flag can really be cleared. */
        alarm_events = 0U;
        elapsed = 0U;
        while ((alarm_events == 0U) && (elapsed < TEST_FLAG_TIMEOUT_MS))
        {
            delay_ms(TEST_POLL_MS);
            elapsed += TEST_POLL_MS;
        }
        printf("events after %u ms of waiting: %u\r\n",
               PRINT_U32(elapsed), PRINT_U32(alarm_events));
        Check("matching alarm produced events", (alarm_events > 0U));
        Check("firmware still responsive (no interrupt deadlock)", (1U));

        /* ---- Step 9: closing the alarm ------------------------------------- */
        __HAL_RTC_DISABLE_IT(&hrtc_dev, RTC_IT_ALARM);
        /* CR.ALRMT can only stay cleared while no comparison field matches (the
           flag is level type), so the alarm is parked on a condition that is not
           satisfied before the flag is cleared - a wildcard set
           (RTC_Alarm_None / RTC_Alarm_None) would match continuously. */
        __HAL_CLEAR_STRUCT(&alarm);
        HAL_RTC_AlarmStructInit(&alarm);
        alarm.RTC_AlarmTime.RTC_Hours = (uint8)(TEST_TIME_HOURS + 1U);
        alarm.RTC_AlarmTimeCompEn = RTC_AlarmTime_Hours;
        alarm.RTC_AlarmDataCompEn = RTC_Alarm_None;
        Check("alarm parked on a non matching condition",
              (HAL_RTC_SetAlarm(&hrtc_dev, &alarm, RTC_FORMAT_BIN) == HAL_OK));
        Check("parking the alarm did not re-enable the interrupt", ((RTC->CR & RTC_CR_IE) == 0U));
        __HAL_RTC_CLEAR_FLAG(&hrtc_dev, RTC_FLAG_ALARM);
        alarm_events = 0U;
        delay_ms(TEST_QUIET_MS);
        Check("no event after the interrupt was disabled", (alarm_events == 0U));
        Check("flag clear at the end", ((RTC->CR & RTC_CR_ALRMT) == 0U));
    /* ---- summary ------------------------------------------------------- */
    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(failures));

    /* Idle: keep the calendar observable on the console */
    while (1)
    {
        Rtc_PrintCalendar("idle");
        delay_ms(TEST_IDLE_MS);
    }
}

/* Private functions --------------------------------------------------------*/
/**
 * @brief  Prepare the RTC handle and its configuration structure.
 * @note   The configuration structure metafields (Size / Version / reserved
 *         words) are mandatory: HAL_RTC_Init() validates them at run time and
 *         rejects a structure that does not carry them.
 * @param  None
 * @retval None
 */
static void Rtc_Handle_Setup(void)
{
    __HAL_CLEAR_STRUCT(&hrtc_dev);
    hrtc_dev.Instance = RTC;

    __HAL_CLEAR_STRUCT(&rtc_init);
    rtc_init.Size     = sizeof(RTC_InitTypeDef);
    rtc_init.Version  = RTC_INIT_VERSION;
    rtc_init.Division = TEST_RTC_DIVISION;
    hrtc_dev.Init     = rtc_init;
}

/**
 * @brief  Initialize the RTC and report its state.
 * @param  None
 * @retval HAL status of the initialization.
 */
static HAL_StatusTypeDef Rtc_Start(void)
{
    HAL_StatusTypeDef status;

    Rtc_Handle_Setup();
    status = HAL_RTC_Init(&hrtc_dev);
    printf("RTC state = %u (1 = READY), error = %u\r\n",
           PRINT_U32(HAL_RTC_GetState(&hrtc_dev)),
           PRINT_U32(HAL_RTC_GetError(&hrtc_dev)));

    return status;
}

/**
 * @brief  Write the calendar (time and date) of the RTC.
 * @param  hours / minutes / seconds / tos: time fields.
 * @param  century / year / month / date / weekday: date fields.
 * @retval HAL_OK when both writes succeeded.
 */
static HAL_StatusTypeDef Rtc_SetCalendar(uint8 hours, uint8 minutes, uint8 seconds, uint8 tos,
                                         uint8 century, uint8 year, uint8 month, uint8 date,
                                         uint8 weekday)
{
    RTC_TimeTypeDef time;
    RTC_DateTypeDef dateS;
    HAL_StatusTypeDef status;

    __HAL_CLEAR_STRUCT(&time);
    __HAL_CLEAR_STRUCT(&dateS);
    HAL_RTC_TimeStructInit(&time);
    HAL_RTC_DateStructInit(&dateS);

    time.RTC_Hours         = hours;
    time.RTC_Minutes       = minutes;
    time.RTC_Seconds       = seconds;
    time.RTC_TenthOfSecond = tos;

    dateS.RTC_WeekDay = weekday;
    dateS.RTC_Century = century;
    dateS.RTC_Year    = year;
    dateS.RTC_Month   = month;
    dateS.RTC_Date    = date;

    status = HAL_RTC_SetTime(&hrtc_dev, &time, RTC_FORMAT_BIN);
    if (status == HAL_OK)
    {
        status = HAL_RTC_SetDate(&hrtc_dev, &dateS, RTC_FORMAT_BIN);
    }

    return status;
}

/**
 * @brief  Read the calendar into the report globals.
 * @param  None
 * @retval HAL status of the read (HAL_ERROR when a read was refused).
 */
static HAL_StatusTypeDef Rtc_GetCalendar(void)
{
    RTC_TimeTypeDef time;
    RTC_DateTypeDef dateS;
    HAL_StatusTypeDef status;

    __HAL_CLEAR_STRUCT(&time);
    __HAL_CLEAR_STRUCT(&dateS);

    status = HAL_RTC_GetTime(&hrtc_dev, &time, RTC_FORMAT_BIN);
    if (status == HAL_OK)
    {
        status = HAL_RTC_GetDate(&hrtc_dev, &dateS, RTC_FORMAT_BIN);
    }
    if (status != HAL_OK)
    {
        return status;
    }

    r_time_hours   = time.RTC_Hours;
    r_time_minutes = time.RTC_Minutes;
    r_time_seconds = time.RTC_Seconds;
    r_time_tos     = time.RTC_TenthOfSecond;

    r_date_century = dateS.RTC_Century;
    r_date_year    = dateS.RTC_Year;
    r_date_month   = dateS.RTC_Month;
    r_date_date    = dateS.RTC_Date;
    r_date_weekday = dateS.RTC_WeekDay;

    return HAL_OK;
}

/**
 * @brief  Translate a month constant to its number (1-12).
 * @param  month: month (RTC_Month_xxx).
 * @retval uint8: month number, or 0 when the value is unknown.
 */
static uint8 Rtc_MonthToNumber(uint8 month)
{
    uint8 result;

    switch (month)
    {
        case RTC_Month_January:   result = 1U;  break;
        case RTC_Month_February:  result = 2U;  break;
        case RTC_Month_March:     result = 3U;  break;
        case RTC_Month_April:     result = 4U;  break;
        case RTC_Month_May:       result = 5U;  break;
        case RTC_Month_June:      result = 6U;  break;
        case RTC_Month_July:      result = 7U;  break;
        case RTC_Month_August:    result = 8U;  break;
        case RTC_Month_September: result = 9U;  break;
        case RTC_Month_October:   result = 10U; break;
        case RTC_Month_November:  result = 11U; break;
        case RTC_Month_December:  result = 12U; break;
        default:                  result = 0U;  break;
    }

    return result;
}

/**
 * @brief  Translate a weekday constant to its name.
 * @param  weekday: weekday (RTC_Weekday_xxx).
 * @retval const char*: weekday name, or "?" when the value is unknown.
 */
static const char *Rtc_WeekdayName(uint8 weekday)
{
    switch (weekday)
    {
        case RTC_Weekday_Monday:    return "Monday";
        case RTC_Weekday_Tuesday:   return "Tuesday";
        case RTC_Weekday_Wednesday: return "Wednesday";
        case RTC_Weekday_Thursday:  return "Thursday";
        case RTC_Weekday_Friday:    return "Friday";
        case RTC_Weekday_Saturday:  return "Saturday";
        case RTC_Weekday_Sunday:    return "Sunday";
        default:                    return "?";
    }
}

/**
 * @brief  Read and print the calendar.
 * @param  tag: text printed in front of the value (may be NULL).
 * @retval None
 */
static void Rtc_PrintCalendar(const char *tag)
{
    if (Rtc_GetCalendar() != HAL_OK)
    {
        printf("%s calendar read refused (state = %u)\r\n",
               ((tag != NULL_PTR) ? tag : ""),
               PRINT_U32(HAL_RTC_GetState(&hrtc_dev)));
        return;
    }

    printf("%s %02u-%02u-%02u %02u:%02u:%02u.%u %s\r\n",
           ((tag != NULL_PTR) ? tag : ""),
           PRINT_U32(r_date_century), PRINT_U32(Rtc_MonthToNumber(r_date_month)),
           PRINT_U32(r_date_date), PRINT_U32(r_time_hours), PRINT_U32(r_time_minutes),
           PRINT_U32(r_time_seconds), PRINT_U32(r_time_tos),
           Rtc_WeekdayName(r_date_weekday));
}

/**
 * @brief  Route the RTC alarm interrupt line through the PLIC.
 * @note   The RTC alarm is the only interrupt source of the module; the shared
 *         trap entry dispatches it to RTC_IRQ_Handler() overridden above.
 * @param  None
 * @retval None
 */
static void Plc_RouteRtcIrq(void)
{
    PLIC_InitTypeDef plic_init;

    __HAL_CLEAR_STRUCT(&plic_init);
    plic_init.Size               = sizeof(plic_init);
    plic_init.Version            = PLIC_INIT_VERSION;
    plic_init.PLIC_IRQChannel    = RTC_IRQn;
    plic_init.PLIC_IRQPriority   = 1U;
    plic_init.PLIC_IRQChannelCmd = ENABLE;
    HAL_PLIC_Init(&plic_init);

    Check("RTC interrupt routed in the PLIC",
          (PLIC->AXI_PLIC_PRIORITY[RTC_IRQn - 1U] == 1U));
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition == 0U)
    {
        failures++;
    }
    printf("%-44s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Configure the system clock tree using the HAL SMU driver.
 * @note   Clock tree shared by every integration test suite of this library:
 *         OSC 20 MHz as the PLL source, PLLDivR = 0x04 / PLLDivN = 0x14 /
 *         PLLDivF = 0xB4 / PLLDivQ = 0x01, then AXI4Bus3 = /2, APBBus0 = /2,
 *         APBBus1 = /2 and CANX2 = /8. The bus dividers are written first and
 *         the PLL is switched in afterwards, which is the order the chip
 *         requires (see HAL_SMU_OscConfig()).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;
    HAL_SMU_HandleTypeDef hsmu_clk;

    /* Enable the bus clock gates */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* The RTC lives in the always-on APB-BusS domain: it has no clock gate of
       its own, the module switch of the configuration file is enough. */

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Bus dividers first (the system clock is still the power-on source) */
    __HAL_CLEAR_STRUCT(&SMU_ClockInitStruct);
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;
    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) and switch to it; the
       call also programs the EFLASH controller clock before the switch. */
    __HAL_CLEAR_STRUCT(&SMU_OscInitStruct);
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
