/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):  	Xiamen Guoke Anxin Technology Co., LTD
 * FileName:     	as32x601.ld
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.4
 * Date:			2026/10/08
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/03     1.1     fix .heap/.stack size
 *                                                       symbols: the sections
 *                                                       referenced the never-
 *                                                       defined uppercase
 *                                                       __HEAP_SIZE/__STACK_SIZE;
 *                                                       use the defined
 *                                                       __heap_size/__stack_size
 *                                                       (also the names exposed
 *                                                       for --defsym override).
 *                                                       Fix the region override
 *                                                       comment to list the
 *                                                       actual symbols.
 *     ANSILIC APPLICATION GROUP  2026/09/03     1.2     discard the unwind
 *                                                       tables (.eh_frame and
 *                                                       .eh_frame.*) in
 *                                                       /DISCARD/: sources are
 *                                                       compiled with
 *                                                       -fno-asynchronous-
 *                                                       unwind-tables
 *                                                       -fno-unwind-tables, but
 *                                                       the prebuilt libgcc.a
 *                                                       still ships a 40-byte
 *                                                       .eh_frame pulled in by
 *                                                       -lgcc; the /DISCARD/
 *                                                       entry removes it so no
 *                                                       orphan section lands in
 *                                                       Flash.
 *     ANSILIC APPLICATION GROUP  2026/10/08     1.3     make .noinit a section of
 *                                                       its own, outside the
 *                                                       zero-fill range, so the
 *                                                       startup clear loop no longer
 *                                                       erases it; collect .srodata
 *                                                       with .sdata in RAM so the
 *                                                       small-data classes share the
 *                                                       gp window; define the region,
 *                                                       stack and heap sizes with
 *                                                       PROVIDE so --defsym can
 *                                                       override them; keep
 *                                                       .text.entry and add the
 *                                                       linkonce/COMMON selectors;
 *                                                       publish __ram_end as a plain
 *                                                       symbol; declare RAM as
 *                                                       read/write only; move the
 *                                                       heap alignment out of the
 *                                                       section; add link-time
 *                                                       invariants for the reset
 *                                                       entry, the copied range, the
 *                                                       copy/clear word size, the
 *                                                       stack bounds and the
 *                                                       no-init placement
 *     ANSILIC APPLICATION GROUP  2026/10/08     1.4     collect .RamFunc (RAM-resident code, the
 *                                                       __RAM_FUNC macro) into the Flash-backed .data
 *                                                       block, so the startup copy loop moves it to
 *                                                       RAM together with the initialised data;
 *                                                       without a rule the section stayed in Flash,
 *                                                       i.e. the macro silently did not do what it
 *                                                       says. Also publish etext / __data_load /
 *                                                       __heap_start / __heap_end as plain
 *                                                       assignments so the conventional names always
 *                                                       exist in the symbol table (a PROVIDE alias
 *                                                       disappears when nothing references it), and
 *                                                       restore the Description line of this banner,
 *                                                       which the V1.3 edit had dropped
 * Description:     Linker script for the AS32x601 (RISC-V rv32imafdc, little
 *                  endian) HAL library, GCC/GAS toolchain.
 *                  It complies with AS32_HAL_linker_requirements_specification V3.1 (LINK-REQ-001
 *                  ~ 029).  Memory map (see as32x601_addrmap.h):
 *                    - Flash (AXI_Bus0) @ 0x01000000, P-Flash main region 2 MB
 *                    - SRAM (AXI_Bus1) @ 0x20000000, SRAM0..SRAM3 512 KB total
 *                  Sections organised by "memory region -> section -> symbol":
 *                    - code / constants -> Flash (the .init reset entry and the
 *                      .text.entry trap entry are both kept and placed first)
 *                    - writable + small data -> RAM (LMA/VM separation, the
 *                      startup copies _data_load .. _data_end which covers
 *                      .sdata, .srodata and .data)
 *                    - zero-init (.bss including .sbss/.bss.isr_stack) -> RAM
 *                    - no-init (.noinit) -> RAM but outside the zero-fill range,
 *                      so the startup clear loop never erases it
 *                    - stack / heap -> RAM top
 *                  The script closes with link-time invariants (ASSERT) for the
 *                  reset entry address, the copied range, the stack bounds and the
 *                  no-init placement, so a broken layout fails the link instead of
 *                  producing a silently wrong image.
 *                  Symbols exported for as32x601_startup_gcc.S and
 *                  as32x601_trapentry_gcc.S (LINK-REQ-014 ~ 019):
 *                    _stack_top, _stack_bottom, _data_load, _data_start,
 *                    _data_end, _bss_start, _bss_end, __global_pointer$,
 *                    __ram_end, _isr_stack_top (RTOS mode, .bss.isr_stack).
 */

OUTPUT_ARCH(riscv)
ENTRY(_start)

/*
/*
 * Region sizes can be overridden by a build option via
 *   -Wl,--defsym=__FLASH_ORIGIN=0x01000000 -Wl,--defsym=__FLASH_LENGTH=0x00200000
 *   -Wl,--defsym=__RAM_ORIGIN=0x20000000   -Wl,--defsym=__RAM_LENGTH=0x00080000
 * so the same script serves chips sharing this memory map.  PROVIDE supplies the
 * value below as the default and lets a --defsym definition win; a plain
 * assignment would silently override the option instead.
 */
PROVIDE(__FLASH_ORIGIN = 0x01000000);
PROVIDE(__FLASH_LENGTH = 0x00200000);   /* 2 MB P-Flash main region        */
PROVIDE(__RAM_ORIGIN   = 0x20000000);
PROVIDE(__RAM_LENGTH   = 0x00080000);   /* 512 KB SRAM0..SRAM3             */

/*
/*
 * Stack and heap size (bytes).  The heap, when enabled, grows up from the end
 * of .bss; the stack grows down from the top of RAM.  These must not overlap.
 * Allow the build to override via -Wl,--defsym=__stack_size=xxx /
 * -Wl,--defsym=__heap_size=xxx (kept in lower case to match the toolchain
 * convention and the IDE builder LD_FLAGS of the AS32x601 project).  PROVIDE is
 * used for the same reason as for the region sizes above.
 */
PROVIDE(__stack_size = 0x00004000);     /* 16 KB task stack                */
PROVIDE(__heap_size  = 0x00000000);     /* 0 = heap disabled               */

MEMORY
{
    FLASH (rx)  : ORIGIN = __FLASH_ORIGIN, LENGTH = __FLASH_LENGTH
    RAM   (rw)  : ORIGIN = __RAM_ORIGIN,   LENGTH = __RAM_LENGTH
}

SECTIONS
{
    /* ---- Code (LINK-REQ-004): executable, in Flash ------------------------ */
    /* The .init reset entry is kept at the very start of the region, and the
       .text.entry trap entry is kept as well and placed next to it so it can
       never be removed as unused while the trap vector still points at it. */
    .text :
    {
        . = ALIGN(4);
        KEEP(*(.init))                 /* _start reset entry (startup)       */
        KEEP(*(.init.*))               /* extra startup sub-sections         */
        KEEP(*(.text.entry))           /* TrapEntry (trap vector target)     */
        KEEP(*(.text.entry.*))
        *(.text)                       /* all code                              */
        *(.text.*)                     /* per-section code                      */
        *(.literal)                    /* RISC-V literal pool                  */
        *(.literal.*)
        *(.gnu.linkonce.t*)            /* linkonce code (legacy C++ objects)   */

        . = ALIGN(4);
        /* Plain assignment, not PROVIDE: the conventional name must be present
           in the symbol table even when nothing in the image references it, so
           that a debug script or a linker fragment can rely on it. */
        etext = .;                     /* end of code                           */
    } > FLASH

    /* ---- Read-only constants (LINK-REQ-005): in Flash --------------------- */
    /* Small read-only data (.srodata) is NOT collected here: the toolchain     */
    /* addresses it relative to gp, so it belongs to the small-data window in   */
    /* RAM, see the .data note below.                                          */
    .rodata :
    {
        . = ALIGN(4);
        *(.rodata)
        *(.rodata.*)
        *(.gnu.linkonce.r*)

        . = ALIGN(4);
    } > FLASH

    /* ---- Writable data + small data (LINK-REQ-006/007): LMA/VM ---------- */
    /* .sdata, .srodata and .sbss are the small-data classes the toolchain     */
    /* reaches through gp, so all three live in RAM inside one 4 KB window     */
    /* anchored at __global_pointer$ = .sdata + 2 KB.  .sdata and .srodata     */
    /* open the Flash-backed copy block so the startup loop (which copies      */
    /* _data_load .. _data_end) also copies them to RAM - LINK-REQ-007/009/016.*/
    .data :
    {
        . = ALIGN(4);
        PROVIDE(_data_start = .);           /* RAM runtime start (VMA)        */
        PROVIDE(__global_pointer$ = . + 0x800);   /* gp = .sdata + 2KB        */

        *(.sdata)                            /* small initialized data        */
        *(.sdata.*)
        *(.srodata)                          /* small read-only data          */
        *(.srodata.*)

        . = ALIGN(4);
        *(.data)                             /* general initialized data      */
        *(.data.*)
        *(.gnu.linkonce.d*)

        /* RAM-resident code (__RAM_FUNC in as32x601_hal_def.h).  It is placed
           inside this Flash-backed block on purpose: the startup copy loop
           (_data_load .. _data_end -> _data_start .. _data_end) then copies it
           to RAM together with the initialised data, so a function tagged with
           __RAM_FUNC really executes from RAM without any extra startup code.
           Without this rule the section would become an orphan and silently
           stay in Flash, which is what used to happen (the macro existed but
           the scripts had no rule for it).  The section is empty as long as no
           object uses the macro, so the layout is unchanged for every build
           that does not. */
        . = ALIGN(4);
        *(.RamFunc)
        *(.RamFunc.*)

        . = ALIGN(4);
        PROVIDE(_data_end = .);             /* RAM runtime end (VMA)          */
    } > RAM AT > FLASH
    PROVIDE(_data_load = LOADADDR(.data)); /* Flash load address (LMA)      */
    __data_load = _data_load;              /* plain alias: always in the symbol
                                              table, so it can be used from a
                                              debug script or a linker fragment
                                              (a PROVIDE alias would vanish when
                                              nothing references it) */

    /* ---- Zero-init data (LINK-REQ-008/009): RAM, no Flash mirror -------- */
    /* .sbss is kept inside this single zero-fill block so that the startup  */
    /* loop (which clears _bss_start.._bss_end) also zeros .sbss.  .bss.*    */
    /* (e.g. .bss.isr_stack for RTOS) is gathered here too.                  */
    .bss (NOLOAD) :
    {
        . = ALIGN(4);
        PROVIDE(_bss_start = .);
        *(.sbss)                             /* small zero-init (gp window)    */
        *(.sbss.*)
        *(.gnu.linkonce.sb*)
        *(.bss)
        *(.bss.*)                            /* includes .bss.isr_stack (RTOS) */
        *(.gnu.linkonce.b*)
        *(COMMON)                            /* tentative definitions          */
        . = ALIGN(4);
        PROVIDE(_bss_end = .);
    } > RAM

    /* ---- No-init data (LINK-REQ-008): RAM, no load image, never cleared -- */
    /* A section of its own, placed after the zero-fill block, so a .noinit   */
    /* object is never covered by _bss_start.._bss_end and keeps its value     */
    /* across a reset.  It used to be collected into .bss, which made the      */
    /* startup zero-fill erase it (the invariant at the end of this script     */
    /* now checks the placement).                                             */
    .noinit (NOLOAD) :
    {
        . = ALIGN(4);
        *(.noinit)
        *(.noinit.*)
        . = ALIGN(4);
    } > RAM

    /* ---- Heap (LINK-REQ-011): optional, RAM ------------------------------ */
    /* The base is aligned outside the section so that a disabled heap leaves  */
    /* no phantom section and consumes no byte.                               */
    . = ALIGN(8);
    .heap (NOLOAD) :
    {
        /* Plain (not PROVIDE) so that both names exist in the symbol table for
           a debug script even when the heap is disabled and nothing references
           them; they then simply mark the same address. */
        __heap_start = .;
        . += __heap_size;
        __heap_end = .;
    } > RAM

    /* ---- Stack (LINK-REQ-010): RAM top ------------------------------------ */
    .stack (NOLOAD) :
    {
        . = ALIGN(16);
        PROVIDE(_stack_bottom = .);         /* stack low address (guard)       */
        . += __stack_size;
        . = ALIGN(16);
        PROVIDE(_stack_top = .);            /* stack high address = initial sp */
    } > RAM

    /* ---- End of RAM: plain definition (not PROVIDE) so the name documented  */
    /* in the build guide is always present in the symbol table.             */
    __ram_end = ORIGIN(RAM) + LENGTH(RAM);

    /DISCARD/ :
    {
        *(.comment)
        *(.note)
        *(.riscv.attributes)
        *(.eh_frame)          /* unwind tables: sources built with -fno-*-tables; */
        *(.eh_frame.*)        /* the rest (prebuilt libgcc) is dropped here too    */
    }
}

/* ---------------------------------------------------------------------------
 * Link-time invariants.  Each check below fails the link instead of producing an
 * image whose placement contradicts the memory contract.  They are written after
 * the SECTIONS block because this toolchain accepts ASSERT only at that level.
 * ------------------------------------------------------------------------- */

/* Reset entry: the first fetched instruction is _start at the base of the
   program-storage region (the BOOT pins select P-Flash boot). */
ASSERT(ADDR(.text) == ORIGIN(FLASH), "reset section is not at the start of P-Flash Main");
ASSERT(_start == ORIGIN(FLASH), "reset entry symbol is not at the start of P-Flash Main");

/* Copy contract: the range the startup copies equals the .data output section
   exactly, so every copied byte has a Flash image and nothing unlisted is
   touched; both ends of that image stay inside P-Flash Main. */
ASSERT(_data_end - _data_start == SIZEOF(.data),
       "initialized-data run range does not match the copied section");
ASSERT(_data_load >= ORIGIN(FLASH), "initialized-data load image starts below P-Flash Main");
ASSERT(_data_load + SIZEOF(.data) <= ORIGIN(FLASH) + LENGTH(FLASH),
       "initialized-data load image leaves P-Flash Main");

/* Word-copy contract: the copy and the clear ranges are multiples of the 32-bit
   access width used by the startup loops. */
ASSERT((_data_end - _data_start) % 4 == 0, "initialized-data range is not word sized");
ASSERT((_bss_end - _bss_start) % 4 == 0, "zero-fill range is not word sized");

/* RAM layout: the writable area and the closed heap reservation stay below the
   stack, the stack keeps the configured size with both ends 16-byte aligned
   (RV32 D-extension ABI), and the stack stays inside the RAM region. */
ASSERT(_bss_end <= _stack_bottom, "writable data collides with the task stack");
ASSERT(ADDR(.heap) + SIZEOF(.heap) <= _stack_bottom, "heap reservation collides with the task stack");
ASSERT(_stack_top - _stack_bottom >= __stack_size, "stack is smaller than the configured size");
ASSERT(_stack_bottom % 16 == 0, "stack bottom is not 16-byte aligned");
ASSERT(_stack_top % 16 == 0, "stack top is not 16-byte aligned");
ASSERT(_stack_top <= ORIGIN(RAM) + LENGTH(RAM), "stack leaves the RAM region");

/* No-init placement: whenever the section carries storage it must start at or
   after the end of the zero-fill range, i.e. outside what the startup clear
   loop erases.  The check is skipped while the section is empty. */
ASSERT(SIZEOF(.noinit) == 0 || ADDR(.noinit) >= _bss_end,
       "no-init storage overlaps the zero-filled range");
