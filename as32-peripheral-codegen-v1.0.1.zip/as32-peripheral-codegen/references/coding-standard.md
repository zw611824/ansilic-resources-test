# 客户应用工程与 C 代码规范

## 默认完整目录

```text
AS32_Application/
├── Core/
│   └── core_riscv.h
├── System/
│   ├── <device_header>.h
│   ├── Startup.S
│   ├── TrapEntry.S
│   └── <linker_script>.ld
├── Peripherals/
│   ├── Inc/
│   └── Src/
├── Bsp/
│   ├── uart.c / uart.h
│   ├── adc.c / adc.h
│   ├── dma.c / dma.h
│   ├── pmu.c / pmu.h
│   ├── rtc.c / rtc.h
│   ├── spi.c / spi.h
│   ├── clock.c / clock.h
│   └── <function_module>.c / <function_module>.h
├── Utils/
│   ├── <chip>_delay.c / <chip>_delay.h
│   └── <chip>_print.c / <chip>_print.h
├── User/
│   ├── main.c
│   ├── main.h
│   └── as32x601_hal_conf.h
├── docs/
│   ├── project.md
│   └── project.drawio
└── build/
```

文件名均为结构示意，按真实芯片 SDK 和工程模板确定；斜杠并列表示两个文件，不是子目录。新建工程默认准备 Utils 中的 delay 和 printf，其他示例模块按需生成，不机械生成全部示例文件。

`as32x601_hal_conf.h` 是 AS32x601 的工程级 HAL 配置示例，由真实配置模板生成；它不属于业务模块，也不受业务函数前缀规则影响。已有工程保留其原位置和命名，其他芯片依据各自 HAL 确定。

- Core：RISC-V Core 文件，不能放普通应用代码。
- System：设备头、启动、Trap/中断入口、链接与内存布局等芯片基础文件；不放外设初始化。不生成无明确需求的 system_init.c / system_init.h。
- Peripherals：新建工程默认复制匹配 SDK 的完整 HAL 外设驱动头文件和源文件，保持真实 Inc / Src 等组织方式；按实际配置启用和编译，不为应用随意重写底层。准备工程副本不得改动 IDE 内部 SDK；已有工程保留其驱动及客户修改。
- Bsp：外设基础封装按外设名称命名，如 dma.c/.h、pmu.c/.h、rtc.c/.h、uart.c/.h、spi.c/.h、adc.c/.h，负责实例、引脚/AF、时钟门控、参数、IRQ、初始化、启停和数据访问；不把 DMA 基础封装命名为 dma_mem，也不加 bsp_ 前缀。完整生成的功能另按功能命名模块，如 power_cycle.c/.h，负责外设协同、状态控制、循环测试、结果校验和统计，通过外设封装接口操作硬件，不复制配置或重写 HAL。按实际功能边界组织，不为每个步骤拆文件，也不固定生成 power_cycle 或 app_test。HAL 驱动留在 Peripherals。系统时钟树、总线分频、PMU 电压和 Flash 时钟统一归 `SystemClock_Init`；串口只初始化一次，printf 和功能模块调用同一发送接口。
- Utils：新建应用默认创建并准备 delay 和 printf 重定向；仅有 IDE 配置的空工程也视为新建应用。printf 使用已确认的串口实例、引脚、波特率和帧格式；任一项缺失时返回规划确认，不得采用默认值或静默补全；客户指定时按客户要求。客户明确禁用时按其要求处理。ring_buffer、log、crc、timeout、format 按需增加。已有应用优先复用其现有结构和输出实现。print 将输出交给 Bsp 统一发送接口，不重复配置引脚、时钟、USART 句柄或中断。日志与提示文本语言按 references/printf-adaptation.md 决定。
- User：留给用户后续开发。新建应用保留 main.c、main.h 和工程级 HAL 配置；main.c 只保留必要的系统启动、错误处理及 Bsp 功能入口调用，不放生成的轮次状态、测试算法或完整业务流程，不在 User 新建 power_cycle.c/.h 等功能模块。单一外设操作可直接调用其 Bsp 接口，不为保持 main 简短再增加没有实际职责的包装层。
- docs：工程说明为单份 project.md，遵循 references/project-documentation.md；独立应用流程图 project.drawio 遵循 references/project-flowchart.md。二者不登记为编译源码。
- build：仅编译输出，不放源代码。

已有工程先识别、后复用；不重复复制 HAL、不重复生成初始化、IRQ 或全局状态，不为符合此目录大范围重构。

避免仅改名而没有实际职责的包装函数、只在一处使用且无配置意义的别名，以及重复描述代码的长注释；保留必要的硬件配置、错误处理和清晰的对外接口。

串口数据流、printf 共用发送及 SDK 适配限制见 `references/printf-adaptation.md`。源文件、头文件和依赖按实际构建系统登记；新建应用默认使用 `<chip>_print.c/.h`，已有工程可保留其现有 print 文件名，不机械要求改名。

新建工程的 `main.c` 包含 `main.h`。`main.h` 使用唯一的头文件保护宏 `MAIN_H`，只放确需跨文件共享的应用入口声明、宏或类型；没有共享内容时保留文件说明和保护宏即可，不虚构函数、公共变量或空章节。外设接口和业务接口仍放各自模块的头文件。已有工程先复用其结构，未要求时不为补齐 main.h 强制重构或修改无关文件。

## 格式与文件组织

适用于新生成 `.c/.h`；不为排版重写已有 HAL 或系统文件。

- 4 个空格缩进，不使用 Tab；Allman 大括号，条件和循环默认加大括号；一条语句一行。
- 二元及赋值运算符两侧留空格；逗号后留空格；if / for / while 后留空格；函数名与左括号不加空格。一元运算、指针声明遵循 C 语法，不机械插空格。
- 两个函数之间恰好两个空行，空行位于下一函数文档注释之前；函数内部不同逻辑阶段一个空行。
- include 与首个代码区块之间一个空行；局部变量声明后进入主要逻辑可空一行；不插无意义连续空行；末尾一个换行。
- 单行建议约 100 字符以内；长参数合理换行，不为长度把代码切碎。
- `.c` 推荐：File Header → Includes → Private Defines → Private Types → Private Variables → Private Function Prototypes → Public Functions → Private Functions。
- `.h` 推荐：File Header → Header Guard → Includes → Public Defines → Public Types → Public Function Prototypes → Header Guard End。
- 只有有内容时才生成相应章节，不生成空章节横幅。头文件保护宏须在工程内唯一，如 UART_H；结尾 `#endif /* UART_H */`。

## 注释和命名

- 默认英文注释；公开函数使用简洁 Doxygen，说明真实行为。带参数写有意义的 @param，带返回值说明 @return 的实际语义。
- 无参数/无返回值不强制 @param None / @retval None；不逐行重复显然代码，不堆模板注释。
- 寄存器特殊操作、中断清除顺序、硬件时序和芯片限制必须注释，附可追溯依据，不编造原因。
- 新应用文件用小写和下划线；SDK 原有 Startup.S、TrapEntry.S 等名称保持不变，目录大小写遵循默认结构。
- Bsp 外设接口以外设名开头，如 dma.c 中的 DMA_Mem_Copy；功能模块接口以功能名为前缀，如 power_cycle.c 中的 PowerCycle_Init / PowerCycle_Process，按实际需要提供，不增加 BSP_、APP_ 或 User_ 等目录层级前缀。文件名用小写和下划线并与模块职责对应；接口后缀可描述操作，不要求与文件名完全相同。
- 私有函数 static；宏全大写加下划线。
- 上述为应用封装风格，不代表 HAL API。检查命名与已有 HAL 符号冲突，必要时采用有意义的实例或功能后缀，不能重命名 HAL。

Init / Process 按实际需要提供，不为凑接口生成空函数。维护已有客户接口时保留原名；如明确要求迁移命名，则同步更新声明、定义及全部调用，不保留失配引用。

## 初始化与中断

main 只 include 实际使用头文件。初始化顺序按当前 HAL 证据安排，不能从 UART → ADC → Timer 的示意顺序推断硬件要求。新建应用至少核对：`HAL_Init()` → `SystemClock_Init()` → 按需 `delay_init(SystemCoreClock / 1000000U)` → 所用外设/端口时钟门控和复位 → 引脚/AF → 外设初始化 → 中断源 PLIC 使能 → 首次接收/启动。`HAL_Init()` 必须先于其他 HAL 调用；每步失败都要可见并停止依赖该步的后续初始化。

需要成功才能继续的初始化和首次启动操作，按真实函数原型检查状态返回值；返回 `void` 的接口不能与 `HAL_OK` 比较或虚构成功返回值，应在调用前核对参数，按需通过实际支持的查询方式检查配置。当前 `HAL_GPIO_Init` 和 `HAL_PLIC_Init` 返回 `void`，`HAL_USART_Init` 返回状态；后续 SDK 以实际声明为准。失败须向调用方传递或执行明确错误处理，不得继续报告启动成功。按实际需求决定是否输出启动提示，默认不加入无关演示文本，保留可用的 `printf` 功能；纯回显或协议数据流不得夹带未经要求的提示信息。

初始化结构体时先查当前 HAL 的初始化函数是否覆盖全部必要字段，再决定是否需要清零；不得假设初始化函数会填充整个结构体。对 `USART_InitTypeDef`、`GPIO_InitTypeDef`、`PLIC_InitTypeDef` 等带 `Size/Version` 的结构体，先清零，设置 `Size = sizeof(...)`、`Version = *_INIT_VERSION`，再填业务字段；优先使用对应的 `HAL_*_StructInit`。保留字按当前 HAL 要求置零。与 HAL 默认值相同但属于客户需求的关键参数可以显式设置以便阅读，其他无意义的重复赋值按实际情况精简，不以简化为由遗漏必需配置。检查 `HAL_*_Init`、`HAL_*_DeInit` 和发送/接收启动的返回值；不照抄 SDK 参考实现中忽略返回值、失败后仍标记 ready 的写法。

新建 AS32x601 应用时，系统时钟初始化函数统一命名 `SystemClock_Init`，默认在 `Bsp/clock.c` 实现、`clock.h` 声明，main 仅调用。它统一负责启动和唤醒恢复所需的时钟树配置，pmu.c 等模块不重复实现该流程。这是应用约定名，不是 HAL 提供的通用函数；函数体必须按当前 HAL 的 SMU/PMU 接口实现。函数返回类型和参数按实际错误处理需要确定，不为了固定名字虚构成功结果。启动时只调用一次；低功耗唤醒确需恢复时由功能模块按真实恢复条件调用，不与启动流程重复执行。`HAL_Init()` 先调用；使用 `HAL_SMU_OscConfig` 等会刷新 `SystemCoreClock` 和 HAL 时基的路径时按当前 HAL 文档核对 `HAL_InitTick`/`HAL_GetTick` 行为；若自行改频，必须更新 `SystemCoreClock` 并重新初始化时基。

AS32x601 时钟树按当前 HAL 和匹配案例核对顺序：先初始化 SMU，按目标频率处理 PMU/LDO 电压；在该芯片要求的顺序下先写总线分频，再配置 PLL 并切换系统时钟；Flash 控制器时钟须在切换前配置。案例中的 180 MHz PLL、PMU 电压和 QSPI/JTAG/BOOT 引脚处理属于案例配置，不能自动成为客户工程默认值，也不得虚构 PLL 参数。

以下名称以当前 SDK 和工具链的实际声明为准，不另造别名：HAL 的 `HAL_Init` 及 `HAL_*` API；复用的 delay 的 `delay_init` / `delay_us` / `delay_ms`（`delay_init` 的参数是 CPU 时钟的 MHz 值，通常写 `SystemCoreClock / 1000000U`，时钟变化后重新初始化）；标准 C 的 `printf`；硬件 IRQ 入口、HAL 回调及 C 库重定向符号。`User_Print_Init` 是 SDK 参考实现的名字，不强制在共享串口适配中生成或重复初始化。封装接口的后缀与参数按功能和真实能力确定，不要求每个模块都有相同的 API。

已有工程优先沿用原有名称并复用初始化；除非客户明确要求迁移，不因统一命名重命名已存在的 `SystemClock_Config`、`System_Clock_Config` 或 `Clock_Init`。不得重复生成多个系统时钟初始化函数。

ISR 尽量短，只做必要寄存器处理、读取数据、更新状态、清标志和事件通知。清除顺序依真实 HAL/案例，不能统一假定。避免耗时格式化、阻塞打印、动态内存分配。复用当前 IRQ 分发，不重复定义 Trap/IRQ，不随意改 TrapEntry.S，不假定 STM32 Callback 存在。

新建应用为固定外设实例生成中断入口时，直接写当前 SDK 分发表实际要求的函数名，便于阅读和检索；不要仅为改名生成 `#define UART_IRQ_HANDLER USART0_IRQ_Handler` 之类的别名。比如当前 AS32x601 的 USART0 入口是 `USART0_IRQ_Handler`。不同芯片及实例须先查真实分发表，不得硬套该名称。

仅定义 IRQ 入口或调用 `HAL_USART_IRQHandler` 不等于中断源已使能。新建应用在启动前必须查当前 PLIC API，用 `HAL_PLIC_Init` 配置 `PLIC_IRQChannel`、优先级大于 0、`PLIC_IRQChannelCmd` 设为当前 HAL 的使能枚举（如 `ENABLE`/`PLIC_ENABLE`），并按结构体规则设置 `Size/Version`；`HAL_PLIC_Init` 保证 PLIC 时钟，但仍需确认 `HAL_PLIC_MODULE_ENABLED`。已有工程有统一 PLIC 初始化时复用，不重复定义；使能后确认首次接收/启动已成功，失败不得报告中断已工作。

新建应用的串口中断入口和需要实现的 HAL 收发、错误回调放在 `Bsp/uart.c`，例如定义 `USART0_IRQ_Handler` 并调用 `HAL_USART_IRQHandler`；功能模块通过必要的事件或数据接口接入，不在 main 中生成业务回调，也不预先生成无用途的回调。句柄默认在 uart.c 内 static，多实例时区分回调来源；每个 HAL 回调只保留一个强定义，不跨文件访问私有句柄。回调通常运行在中断上下文，应简短，耗时处理由主循环调用 Bsp 功能入口完成。先核实当前 HAL 的回调签名、状态和重挂接收条件，避免破坏共享串口状态。

接收缓冲区满、重挂失败及发送超时时须有明确策略：按需求选择错误上报、计数或恢复，不静默宣称全部数据成功处理；首次接收启动失败也须纳入处理。ISR 和主循环之间的重试状态须避免竞态，超时依赖的时基在调用上下文内必须能够运行。仅凭回调内重挂不能保证连续接收不丢字节，注释和交付说明不得作未经验证的保证。

若工程已有统一中断文件或入口，则在原入口中接入 HAL 并复用现有回调，不新增重复强定义。只有多个外设、中断组织或工程约定确实需要时才使用统一 IRQ 文件，须通过合理接口传递上下文，不为跨文件调用随意公开可变全局句柄。测试库为了复用多个实例而使用的宏可以作为配置线索，不必照搬到固定实例的客户应用。

推荐 Timer Trigger → ADC Conversion → ADC IRQ 保存数据/Ready Flag → 主循环调用 Bsp 功能入口完成格式化及 UART 发送。异步发送须明确缓冲区有效期；共享状态按实际访问宽度和并发机制保护。

## 交付完整性

头文件保护宏在工程内唯一；公开原型与定义一致，无参数写 `void`，文档中的参数、返回值与真实接口对应。不交付残留占位符、TODO 实现、空函数或无内容的声明区块；按前述格式与职责规范组织真实代码，保留已有工程结构和已确认的初始化顺序。
