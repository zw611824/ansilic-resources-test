/**
 * @file    SMU_IT_DRV_014.c
 * @brief   HAL SMU integration test case 014 (bus clock dividers).
 *
 * One-to-one HAL library port of the original AS32x601 standard-library test
 * case SMU_IT_DRV_014.c. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_SMU_Init()
 *   HAL_SMU_ClockConfig()      (bus clock dividers)
 *   HAL_SMU_GetClockConfig()   (read back of the dividers)
 *   HAL_SMU_OscConfig()        (system clock source)
 *
 * Test procedure:
 *   1. The standard clock tree (PLL 180 MHz) is applied and reported;
 *   2. The system clock is moved to the FIRC (16 MHz) before the divider
 *      sweep, and the dividers are then programmed in four groups:
 *        group 1: AXI4Bus3 /1, APBBus0 /1, APBBus1 /1, CANCLKx2 /1
 *        group 2: AXI4Bus3 /2, APBBus0 /2, APBBus1 /2, CANCLKx2 /2
 *        group 3: AXI4Bus3 /2 (kept), APBBus0 /4, APBBus1 /4, CANCLKx2 /4
 *        group 4: AXI4Bus3 /2 (kept), APBBus0 /8, APBBus1 /8, CANCLKx2 /8
 *      each group is read back twice: through HAL_SMU_GetClockConfig() and
 *      through the BUSCFGR register bits;
 *   3. The standard clock tree is restored and the collected results are
 *      printed.
 *
 * Expected behaviour:
 *   - every group reads back the dividers that were programmed;
 *   - error_cnt = 0 and "summary : failures = 0".
 *
 * Note (deliberate deviation from the original test case): the vendor case
 * runs the sweep with the PLL (180 MHz) as the system clock, where group 1
 * would put APBBus0 at 90 MHz, i.e. twice the 45 MHz the chip allows for
 * that bus.  This port performs the sweep with the FIRC (16 MHz) as the
 * system clock instead: the divider behaviour is independent of the system
 * clock, and the highest APB frequency of the sweep becomes 8 MHz.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
#define TEST_BAUDRATE               (115200U)

/* Standard clock tree (the same tree the other HAL integration suites use) */
#define STD_PLL_DIV_R               (0x04U)
#define STD_PLL_DIV_Q               (0x01U)
#define STD_PLL_DIV_N               (0x14U)
#define STD_PLL_DIV_F               (0xB4U)
#define STD_AXI4BUS3_DIV            SMU_AXI4BUS3CLK_DIV2
#define STD_APBBUS0_DIV             SMU_APBBUS0CLK_DIV2
#define STD_APBBUS1_DIV             SMU_APBBUS1CLK_DIV2
#define STD_CANX2_DIV               SMU_CANX2CLK_DIV8

/* Number of divider groups of the sweep */
#define DIV_GROUPS                  (4U)

/* Private typedef ---------------------------------------------------------*/
/**
 * @brief Read back result of one divider group.
 */
typedef struct
{
    uint32 axi4bus3;    /*!< AXI4Bus3 divider read back by the driver   */
    uint32 apbbus0;     /*!< APBBus0 divider read back by the driver    */
    uint32 apbbus1;     /*!< APBBus1 divider read back by the driver    */
    uint32 canx2;       /*!< CANCLKx2 divider read back by the driver   */
    uint32 reg_ok;      /*!< 1 when the BUSCFGR bits describe the same   */
} Div_GroupTypeDef;

/* Private variables -------------------------------------------------------*/
static HAL_SMU_HandleTypeDef hsmu_dev;      /*!< SMU handle                   */
static HAL_PMU_HandleTypeDef hpmu_dev;      /*!< PMU handle (LDO scaler)      */
static Div_GroupTypeDef      g_div[DIV_GROUPS];
static uint32                g_error_cnt;   /*!< mismatches (vendor counter)  */
static uint32                g_error_flag;  /*!< 1 when error_cnt != 0        */

/* Private function prototypes ---------------------------------------------*/
static void   Periph_Init(void);
static void   SystemClock_Standard(void);
static void   SystemClock_Firc(void);
static void   Div_Group(uint32 idx, uint32 axi3, uint32 apb0, uint32 apb1, uint32 can2);
static uint32 Chk(const char *name, uint32 expect, uint32 actual);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    uint32 failures = 0U;
    uint32 i;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* SMU and PMU handles */
    Periph_Init();

    /* Standard clock tree first: the console needs a known baud rate */
    SystemClock_Standard();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);

    printf("\r\n=== SMU_IT_DRV_014: bus clock dividers ===\r\n");
    printf("standard tree: SYSCLK = %u Hz, PCLK0 = %u Hz\r\n",
           PRINT_U32(HAL_SMU_GetSysClockFreq()), PRINT_U32(HAL_SMU_GetPCLK0Freq()));
    printf("divider sweep is done with the FIRC as the system clock\r\n");
    printf("(16 MHz core: the highest APB frequency of the sweep is 8 MHz)\r\n");

    /* ---------- move to a low, safe system clock for the sweep ---------- */
    SystemClock_Firc();
    delay_init(SystemCoreClock / 1000000U);

    /* ---------- the four divider groups, nothing printed here ---------- */
    Div_Group(0U, SMU_AXI4BUS3CLK_DIV1, SMU_APBBUS0CLK_DIV1, SMU_APBBUS1CLK_DIV1, SMU_CANX2CLK_DIV1);
    Div_Group(1U, SMU_AXI4BUS3CLK_DIV2, SMU_APBBUS0CLK_DIV2, SMU_APBBUS1CLK_DIV2, SMU_CANX2CLK_DIV2);
    Div_Group(2U, SMU_AXI4BUS3CLK_DIV2, SMU_APBBUS0CLK_DIV4, SMU_APBBUS1CLK_DIV4, SMU_CANX2CLK_DIV4);
    Div_Group(3U, SMU_AXI4BUS3CLK_DIV2, SMU_APBBUS0CLK_DIV8, SMU_APBBUS1CLK_DIV8, SMU_CANX2CLK_DIV8);

    /* The vendor test case derives the error flag from the error counter */
    g_error_flag = (g_error_cnt != 0U) ? 1U : 0U;

    /* ---------- back to the standard tree, then report ---------------- */
    SystemClock_Standard();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);

    printf("\r\n--- divider groups (1 = /1, 2 = /2, 4 = /4, 8 = /8) ---\r\n");
    for (i = 0U; i < DIV_GROUPS; i++)
    {
        printf("group %u: AXI4Bus3=%u APBBus0=%u APBBus1=%u CANCLKx2=%u register=%s\r\n",
               PRINT_U32(i + 1U),
               PRINT_U32(g_div[i].axi4bus3), PRINT_U32(g_div[i].apbbus0),
               PRINT_U32(g_div[i].apbbus1), PRINT_U32(g_div[i].canx2),
               ((g_div[i].reg_ok != 0U) ? "OK" : "MISMATCH"));
    }

    /* Per group pass/fail, so that a single wrong divider is visible */
    failures += Chk("group 1 AXI4Bus3 read back", (uint32)SMU_AXI4BUS3CLK_DIV1, g_div[0].axi4bus3);
    failures += Chk("group 1 APBBus0 read back", (uint32)SMU_APBBUS0CLK_DIV1, g_div[0].apbbus0);
    failures += Chk("group 1 APBBus1 read back", (uint32)SMU_APBBUS1CLK_DIV1, g_div[0].apbbus1);
    failures += Chk("group 1 CANCLKx2 read back", (uint32)SMU_CANX2CLK_DIV1, g_div[0].canx2);
    failures += Chk("group 2 AXI4Bus3 read back", (uint32)SMU_AXI4BUS3CLK_DIV2, g_div[1].axi4bus3);
    failures += Chk("group 2 APBBus0 read back", (uint32)SMU_APBBUS0CLK_DIV2, g_div[1].apbbus0);
    failures += Chk("group 2 APBBus1 read back", (uint32)SMU_APBBUS1CLK_DIV2, g_div[1].apbbus1);
    failures += Chk("group 2 CANCLKx2 read back", (uint32)SMU_CANX2CLK_DIV2, g_div[1].canx2);
    failures += Chk("group 3 AXI4Bus3 read back", (uint32)SMU_AXI4BUS3CLK_DIV2, g_div[2].axi4bus3);
    failures += Chk("group 3 APBBus0 read back", (uint32)SMU_APBBUS0CLK_DIV4, g_div[2].apbbus0);
    failures += Chk("group 3 APBBus1 read back", (uint32)SMU_APBBUS1CLK_DIV4, g_div[2].apbbus1);
    failures += Chk("group 3 CANCLKx2 read back", (uint32)SMU_CANX2CLK_DIV4, g_div[2].canx2);
    failures += Chk("group 4 AXI4Bus3 read back", (uint32)SMU_AXI4BUS3CLK_DIV2, g_div[3].axi4bus3);
    failures += Chk("group 4 APBBus0 read back", (uint32)SMU_APBBUS0CLK_DIV8, g_div[3].apbbus0);
    failures += Chk("group 4 APBBus1 read back", (uint32)SMU_APBBUS1CLK_DIV8, g_div[3].apbbus1);
    failures += Chk("group 4 CANCLKx2 read back", (uint32)SMU_CANX2CLK_DIV8, g_div[3].canx2);

    /* Register level cross check of every group */
    for (i = 0U; i < DIV_GROUPS; i++)
    {
        failures += Chk("BUSCFGR bits match the group", 1U, g_div[i].reg_ok);
    }

    printf("\r\nerror_cnt  = %u\r\nerror_flag = %u\r\n",
           PRINT_U32(g_error_cnt), PRINT_U32(g_error_flag));

    /* The vendor test case states the expected result as error_cnt = 0 */
    failures += Chk("error_cnt is zero", 0U, g_error_cnt);
    failures += Chk("error_flag is zero", 0U, g_error_flag);

    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(failures));

    while (1)
    {
    }
}

/**
 * @brief  Initialize the SMU and PMU handles.
 * @param  None
 * @retval None
 */
static void Periph_Init(void)
{
    __HAL_CLEAR_STRUCT(&hsmu_dev);
    hsmu_dev.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_dev);

    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&hpmu_dev);
    hpmu_dev.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu_dev);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu_dev, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu_dev, PMU_VO12_1V34);
}

/**
 * @brief  Apply the standard clock tree (PLL 180 MHz from the OSC).
 * @note   Dividers first (while the system clock is still the FIRC), then
 *         HAL_SMU_OscConfig(), which programs the flash controller clock,
 *         switches the system clock and performs the flash clock update.
 * @param  None
 * @retval None
 */
static void SystemClock_Standard(void)
{
    SMU_OscInitTypeDef   osc;
    SMU_ClockInitTypeDef clk;

    __HAL_CLEAR_STRUCT(&clk);
    clk.Size           = sizeof(clk);
    clk.Version        = SMU_CLOCK_INIT_VERSION;
    clk.AXI4Bus3CLKDiv = STD_AXI4BUS3_DIV;
    clk.APBBus0CLKDiv  = STD_APBBUS0_DIV;
    clk.APBBus1CLKDiv  = STD_APBBUS1_DIV;
    clk.CANX2CLKDiv    = STD_CANX2_DIV;
    (void)HAL_SMU_ClockConfig(&hsmu_dev, &clk);

    __HAL_CLEAR_STRUCT(&osc);
    osc.Size                 = sizeof(osc);
    osc.Version              = SMU_OSC_INIT_VERSION;
    osc.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    osc.FIRCState            = SMU_FIRC_ON;
    osc.FIRCCalibrationValue = 0x00U;
    osc.PLL.Size             = sizeof(osc.PLL);
    osc.PLL.Version          = SMU_PLL_INIT_VERSION;
    osc.PLL.PLLState         = SMU_PLL_ON;
    osc.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    osc.PLL.PLLDivR          = STD_PLL_DIV_R;
    osc.PLL.PLLDivQ          = STD_PLL_DIV_Q;
    osc.PLL.PLLDivN          = STD_PLL_DIV_N;
    osc.PLL.PLLDivF          = STD_PLL_DIV_F;
    osc.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;
    (void)HAL_SMU_OscConfig(&hsmu_dev, &osc, SMU_TIMEOUT_DEFAULT);
}

/**
 * @brief  Move the system clock to the FIRC (16 MHz) for the divider sweep.
 * @note   HAL_SMU_OscConfig() then programs the flash controller clock from
 *         the nominal FIRC_VALUE, which matches the FIRC the device runs on
 *         (its calibration is not touched here).
 * @param  None
 * @retval None
 */
static void SystemClock_Firc(void)
{
    SMU_OscInitTypeDef osc;

    __HAL_CLEAR_STRUCT(&osc);
    osc.Size           = sizeof(osc);
    osc.Version        = SMU_OSC_INIT_VERSION;
    osc.OscillatorType = SMU_OSCILLATORTYPE_OSC;
    osc.FIRCState      = SMU_FIRC_ON;
    osc.SYSCLKSelect   = SMU_SYSCLKSOURCE_FIRC;
    osc.PLL.Size       = sizeof(osc.PLL);
    osc.PLL.Version    = SMU_PLL_INIT_VERSION;
    osc.PLL.PLLState   = SMU_PLL_NONE;
    osc.PLL.PLLSource  = SMU_PLLSOURCE_OSC;
    osc.PLL.PLLDivR    = STD_PLL_DIV_R;
    osc.PLL.PLLDivQ    = STD_PLL_DIV_Q;
    osc.PLL.PLLDivN    = STD_PLL_DIV_N;
    osc.PLL.PLLDivF    = STD_PLL_DIV_F;
    (void)HAL_SMU_OscConfig(&hsmu_dev, &osc, SMU_TIMEOUT_DEFAULT);
}

/**
 * @brief  Program one divider group and read it back twice.
 * @param  idx: group index (0..DIV_GROUPS-1).
 * @param  axi3: AXI4Bus3 divider (SMU_AXI4BUS3CLK_DIVx).
 * @param  apb0: APBBus0 divider (SMU_APBBUS0CLK_DIVx).
 * @param  apb1: APBBus1 divider (SMU_APBBUS1CLK_DIVx).
 * @param  can2: CANCLKx2 divider (SMU_CANX2CLK_DIVx).
 * @retval None
 */
static void Div_Group(uint32 idx, uint32 axi3, uint32 apb0, uint32 apb1, uint32 can2)
{
    SMU_ClockInitTypeDef cfg;
    SMU_ClockInitTypeDef rb;
    uint32 buscfgr;

    __HAL_CLEAR_STRUCT(&cfg);
    cfg.Size           = sizeof(cfg);
    cfg.Version        = SMU_CLOCK_INIT_VERSION;
    cfg.AXI4Bus3CLKDiv = axi3;
    cfg.APBBus0CLKDiv  = apb0;
    cfg.APBBus1CLKDiv  = apb1;
    cfg.CANX2CLKDiv    = can2;
    (void)HAL_SMU_ClockConfig(&hsmu_dev, &cfg);

    /* Read back through the driver */
    __HAL_CLEAR_STRUCT(&rb);
    (void)HAL_SMU_GetClockConfig(&rb);

    g_div[idx].axi4bus3 = rb.AXI4Bus3CLKDiv;
    g_div[idx].apbbus0  = rb.APBBus0CLKDiv;
    g_div[idx].apbbus1  = rb.APBBus1CLKDiv;
    g_div[idx].canx2    = rb.CANX2CLKDiv;

    /* White box cross check: the register bits describe the same dividers */
    buscfgr = SMU->BUSCFGR;
    if ((((buscfgr & SMU_BUSCFGR_AXI4BUS3DIV) >> SMU_BUSCFGR_AXI4BUS3DIV_Pos) == axi3) &&
        (((buscfgr & SMU_BUSCFGR_APBBUS0DIV) >> SMU_BUSCFGR_APBBUS0DIV_Pos) == apb0) &&
        (((buscfgr & SMU_BUSCFGR_APBBUS1DIV) >> SMU_BUSCFGR_APBBUS1DIV_Pos) == apb1) &&
        (((buscfgr & SMU_BUSCFGR_CANX2DIV) >> SMU_BUSCFGR_CANX2DIV_Pos) == can2))
    {
        g_div[idx].reg_ok = 1U;
    }
    else
    {
        g_div[idx].reg_ok = 0U;
    }

    /* The vendor test case counts every mismatch into error_cnt */
    if ((g_div[idx].axi4bus3 != axi3) || (g_div[idx].apbbus0 != apb0) ||
        (g_div[idx].apbbus1 != apb1) || (g_div[idx].canx2 != can2) ||
        (g_div[idx].reg_ok == 0U))
    {
        g_error_cnt++;
    }
}

/**
 * @brief  Print one check and return the number of failures it contributes.
 * @param  name: check description.
 * @param  expect: expected value.
 * @param  actual: value read back.
 * @retval uint32: 0 when the check passed, 1 otherwise.
 */
static uint32 Chk(const char *name, uint32 expect, uint32 actual)
{
    uint32 fail = 0U;

    if (expect == actual)
    {
        printf("  [PASS] %s : expect %u, read %u\r\n",
               name, PRINT_U32(expect), PRINT_U32(actual));
    }
    else
    {
        printf("  [FAIL] %s : expect %u, read %u\r\n",
               name, PRINT_U32(expect), PRINT_U32(actual));
        fail = 1U;
    }

    return fail;
}

/*****END OF FILE*****/
