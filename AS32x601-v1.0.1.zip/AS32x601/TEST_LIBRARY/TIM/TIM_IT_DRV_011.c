/**
 * @file    TIM_IT_DRV_011.c
 * @brief   PWM mode 1 and PWM mode 2 on channels 1..6
 *
 * HAL library port of the original AS32x601 standard-library test case
 * TIMER_IT_DRV_011.c, which drives TIM0. Only HAL library APIs are used; the register
 * read backs document what was programmed.
 *
 * Tested functionality:
 *   TIM_OCStructInit()      -> HAL_TIM_OC_StructInit()
 *   TIM_OC1Init()..TIM_OC6Init() -> HAL_TIM_PWM_ConfigChannel()
 *   TIM_Cmd(ENABLE)         -> HAL_TIM_PWM_Start() / HAL_TIM_PWMN_Start()
 *   TIM_CtrlPWMOutputs()    -> HAL_TIM_CtrlPWMOutputs()
 *   TIM_BDTRStructInit()/TIM_BDTRConfig() -> HAL_TIM_ConfigBreakDeadTime()
 *
 * Test procedure:
 *   map and configure the output pins (and the complementary pins) of TIM0;
 *   configure every channel with its PWM mode, pulse value and complementary output;
 *   program the break / dead-time register;
 *   start the channels and the main output, then observe the waveforms.
 *
 * Expected behaviour:
 *   every interface returns HAL_OK and the OCxM field reads the programmed mode;
 *   the pulse values are found in the CCR registers;
 *   CCER reads the enable bits (main and complementary) of the configured channels;
 *   BDTR reads the programmed dead time, off-state and automatic output settings;
 *   every channel drives a 50 Hz square wave with a 50 percent duty cycle on its pin;
 *   every check prints [PASS] and "summary : failures = 0".
 *
 * Note:
 *   Channels 1..3 run in PWM mode 1 and channels 4..6 in PWM mode 2, all with a 50 percent pulse on
 *   the HTIM0 clock (AXILite4 Bus 1 = 45 MHz) divided by 9, so the counter runs at 5 MHz and every
 *   channel drives a 50 Hz square wave.
 *
 *   Channel to pin mapping of the HTIM0 M1 multiplex option (the device IO manual lists the
 *   channels from 0, the HAL counts from 1, so "HTIM0_CH2" of the manual is channel 3 here):
 *     channel 1 -> PC3, channel 2 -> PA0, channel 3 -> PA1,
 *     channel 4 -> PA2, channel 5 -> PA3, channel 6 -> PA4.
 *   The optional complementary outputs of the same option are PA7 (channel 3N) and PC5
 *   (channel 5N); they are not enabled by this case.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
/* Console: USART0 on GPIOD pin 8 (TX) / pin 9 (RX), 115200 8N1 */
#define TEST_BAUDRATE                   (115200U)

#define TEST_ARR                        (100000U - 1U)
#define TEST_PSC                        (9U - 1U)


/* Private variables -------------------------------------------------------*/
static HAL_TIM_HandleTypeDef htim_dev;          /*!< timer under test        */
static HAL_SMU_HandleTypeDef hsmu_clk;          /*!< SMU handle (clock tree) */
static volatile uint32 check_failures = 0U;     /*!< failed check counter    */



/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure one GPIO pin and, for the alternate function modes, the
 *         pin mux of that pin.
 * @param  port: GPIO port
 * @param  pin: pin mask
 * @param  source: pin source number (for the mux configuration)
 * @param  af: alternate function selector
 * @param  mode: GPIO_MODE_AF_PP / GPIO_MODE_INPUT
 * @retval None
 */
static void Gpio_Config(GPIO_TypeDef *port, uint32 pin, uint32 source, uint8 af, uint32 mode)
{
    GPIO_InitTypeDef gpio_init;

    __HAL_CLEAR_STRUCT(&gpio_init);
    gpio_init.Size         = sizeof(GPIO_InitTypeDef);
    gpio_init.Version      = GPIO_INIT_VERSION;
    gpio_init.Pin          = pin;
    gpio_init.Mode         = mode;
    gpio_init.Pull         = GPIO_NOPULL;
    gpio_init.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;
    gpio_init.Alternate    = af;
    if (mode == GPIO_MODE_AF_PP)
    {
        HAL_GPIO_PinAFConfig(port, source, af);
    }
    HAL_GPIO_Init(port, &gpio_init);
}

/**
 * @brief  Configure the time base of the timer under test.
 * @note   The helper keeps the Size / Version meta fields through
 *         HAL_TIM_Base_StructInit(), which the initialization interface
 *         validates at run time.
 * @param  instance: TIM0..TIM7
 * @param  arr: auto reload value
 * @param  psc: prescaler value
 * @param  rcr: repetition counter (advanced timers only)
 * @param  ckd: clock division
 * @param  countermode: counting mode
 * @retval HAL status of HAL_TIM_Base_Init()
 */
static HAL_StatusTypeDef TimeBase_Config(TIM_TypeDef *instance, uint32 arr, uint32 psc,
                                         uint32 rcr, uint32 ckd, uint32 countermode)
{
    TIM_Base_InitTypeDef base_init;

    __HAL_CLEAR_STRUCT(&htim_dev);
    htim_dev.Instance = instance;

    HAL_TIM_Base_StructInit(&base_init);
    base_init.CounterMode       = countermode;
    base_init.ClockDivision     = ckd;
    base_init.Period            = arr;
    base_init.Prescaler         = psc;
    base_init.RepetitionCounter = rcr;
    htim_dev.Init               = base_init;

    return HAL_TIM_Base_Init(&htim_dev);
}

/**
 * @brief  Enable the clock of a timer instance and release its reset.
 * @note   The default MSP callbacks of this module are empty, so the suite
 *         performs the gate and reset handling itself; every MSP callback is
 *         routed to this helper.
 * @param  instance: TIM0..TIM7
 * @retval None
 */
static void Tim_ClockEnable(TIM_TypeDef *instance)
{
    if (instance == TIM0)
    {
        __HAL_SMU_HTIM0_CLK_ENABLE();
        __HAL_SMU_HTIM0_FORCE_RESET();
        __HAL_SMU_HTIM0_RELEASE_RESET();
    }
    else if (instance == TIM1)
    {
        __HAL_SMU_HTIM1_CLK_ENABLE();
        __HAL_SMU_HTIM1_FORCE_RESET();
        __HAL_SMU_HTIM1_RELEASE_RESET();
    }
    else if (instance == TIM2)
    {
        __HAL_SMU_HTIM2_CLK_ENABLE();
        __HAL_SMU_HTIM2_FORCE_RESET();
        __HAL_SMU_HTIM2_RELEASE_RESET();
    }
    else if (instance == TIM3)
    {
        __HAL_SMU_TIM3_CLK_ENABLE();
        __HAL_SMU_TIM3_FORCE_RESET();
        __HAL_SMU_TIM3_RELEASE_RESET();
    }
    else if (instance == TIM4)
    {
        __HAL_SMU_TIM4_CLK_ENABLE();
        __HAL_SMU_TIM4_FORCE_RESET();
        __HAL_SMU_TIM4_RELEASE_RESET();
    }
    else if (instance == TIM5)
    {
        __HAL_SMU_HTIM5_CLK_ENABLE();
        __HAL_SMU_HTIM5_FORCE_RESET();
        __HAL_SMU_HTIM5_RELEASE_RESET();
    }
    else if (instance == TIM6)
    {
        __HAL_SMU_TIM6_CLK_ENABLE();
        __HAL_SMU_TIM6_FORCE_RESET();
        __HAL_SMU_TIM6_RELEASE_RESET();
    }
    else
    {
        __HAL_SMU_TIM7_CLK_ENABLE();
        __HAL_SMU_TIM7_FORCE_RESET();
        __HAL_SMU_TIM7_RELEASE_RESET();
    }
}

/* MSP callbacks: the timer clock and reset of the instance under test */
void HAL_TIM_Base_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_OC_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_PWM_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_IC_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_OnePulse_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_Encoder_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the CLINT / CMU / MPU / USART integration tests:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2, CANX2 by
 *         8 -> core 180 MHz, AXILite4 Bus 1 and Bus 2 = 45 MHz (TIM0, TIM1),
 *         APBBus0 and APBBus1 = 22.5 MHz (TIM2 / TIM3 / TIM4 and TIM5 / TIM6 /
 *         TIM7 - TIM2 and TIM5 are advanced timers on the APB).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef    SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks used by this suite (GPIOH lives in the always on
       domain and has no gate macro) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Clock tree order: write the dividers while the system clock is still
       FIRC, then configure the PLL and switch to it (that call programs the
       flash controller clock before the switch and updates SystemCoreClock
       afterwards). */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}
/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    TIM_OC_InitTypeDef oc_cfg;

    HAL_Init();
    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== TIM_IT_DRV_011 : PWM mode 1 and PWM mode 2 on channels 1..6 ===\r\n");

    /* Step 1: the output pins */
    Gpio_Config(GPIOC, GPIO_PIN_3, GPIO_PinSource3, GPIO_AF_HTIM0_M1, GPIO_MODE_AF_PP);
    Gpio_Config(GPIOA, GPIO_PIN_0, GPIO_PinSource0, GPIO_AF_HTIM0_M1, GPIO_MODE_AF_PP);
    Gpio_Config(GPIOA, GPIO_PIN_1, GPIO_PinSource1, GPIO_AF_HTIM0_M1, GPIO_MODE_AF_PP);
    Gpio_Config(GPIOA, GPIO_PIN_2, GPIO_PinSource2, GPIO_AF_HTIM0_M1, GPIO_MODE_AF_PP);
    Gpio_Config(GPIOA, GPIO_PIN_3, GPIO_PinSource3, GPIO_AF_HTIM0_M1, GPIO_MODE_AF_PP);
    Gpio_Config(GPIOA, GPIO_PIN_4, GPIO_PinSource4, GPIO_AF_HTIM0_M1, GPIO_MODE_AF_PP);

    /* Step 2: the time base */
    Check("HAL_TIM_Base_Init() returns HAL_OK",
          (TimeBase_Config(TIM0, TEST_ARR, TEST_PSC, 0U, TIM_CKD_DIV1, TIM_COUNTERMODE_UP) == HAL_OK));

    /* Step 3: the mode and pulse of every channel */
    __HAL_CLEAR_STRUCT(&oc_cfg);
    HAL_TIM_OC_StructInit(&oc_cfg);
    oc_cfg.OCPolarity   = TIM_OCPOLARITY_HIGH;
    oc_cfg.OCNPolarity  = TIM_OCNPOLARITY_HIGH;
    oc_cfg.OCFastMode   = TIM_OCFAST_DISABLE;
    oc_cfg.OCPreload    = TIM_OCPRECONFIG_ENABLE;
    oc_cfg.OCIdleState  = TIM_OCIDLESTATE_SET;
    oc_cfg.OCNIdleState = TIM_OCNIDLESTATE_SET;
    oc_cfg.Pulse = (100000U / 2U);
    oc_cfg.OCMode = TIM_OCMODE_PWM1;
    (void)HAL_TIM_PWM_ConfigChannel(&htim_dev, &oc_cfg, TIM_CHANNEL_1);
    oc_cfg.Pulse = (100000U / 2U);
    oc_cfg.OCMode = TIM_OCMODE_PWM1;
    (void)HAL_TIM_PWM_ConfigChannel(&htim_dev, &oc_cfg, TIM_CHANNEL_2);
    oc_cfg.Pulse = (100000U / 2U);
    oc_cfg.OCMode = TIM_OCMODE_PWM1;
    (void)HAL_TIM_PWM_ConfigChannel(&htim_dev, &oc_cfg, TIM_CHANNEL_3);
    oc_cfg.Pulse = (100000U / 2U);
    oc_cfg.OCMode = TIM_OCMODE_PWM2;
    (void)HAL_TIM_PWM_ConfigChannel(&htim_dev, &oc_cfg, TIM_CHANNEL_4);
    oc_cfg.Pulse = (100000U / 2U);
    oc_cfg.OCMode = TIM_OCMODE_PWM2;
    (void)HAL_TIM_PWM_ConfigChannel(&htim_dev, &oc_cfg, TIM_CHANNEL_5);
    oc_cfg.Pulse = (100000U / 2U);
    oc_cfg.OCMode = TIM_OCMODE_PWM2;
    (void)HAL_TIM_PWM_ConfigChannel(&htim_dev, &oc_cfg, TIM_CHANNEL_6);

    /* Step 4: the programmed modes and pulses */
    Check("OC1 mode = PWM1", ((TIM0->CCMR1 & TIM_CCMR1_OC1M) == TIM_OCMODE_PWM1));
    Check("OC2 mode = PWM1", ((TIM0->CCMR1 & TIM_CCMR1_OC2M) == (TIM_OCMODE_PWM1 << 8U)));
    Check("OC3 mode = PWM1", ((TIM0->CCMR2 & TIM_CCMR2_OC3M) == TIM_OCMODE_PWM1));
    Check("OC4 mode = PWM2", ((TIM0->CCMR2 & TIM_CCMR2_OC4M) == (TIM_OCMODE_PWM2 << 8U)));
    Check("OC5 mode = PWM2", ((TIM0->CCMR3 & TIM_CCMR3_OC5M) == TIM_OCMODE_PWM2));
    Check("OC6 mode = PWM2", ((TIM0->CCMR3 & TIM_CCMR3_OC6M) == (TIM_OCMODE_PWM2 << 8U)));
    Check("CCR1 holds the pulse", (TIM0->CCR1 == (100000U / 2U)));
    Check("CCR2 holds the pulse", (TIM0->CCR2 == (100000U / 2U)));
    Check("CCR3 holds the pulse", (TIM0->CCR3 == (100000U / 2U)));
    Check("CCR4 holds the pulse", (TIM0->CCR4 == (100000U / 2U)));
    Check("CCR5 holds the pulse", (TIM0->CCR5 == (100000U / 2U)));
    Check("CCR6 holds the pulse", (TIM0->CCR6 == (100000U / 2U)));

    /* Step 5: start the channels */
    Check("HAL_TIM_PWM_Start(CH1) returns HAL_OK", (HAL_TIM_PWM_Start(&htim_dev, TIM_CHANNEL_1) == HAL_OK));
    Check("HAL_TIM_PWM_Start(CH2) returns HAL_OK", (HAL_TIM_PWM_Start(&htim_dev, TIM_CHANNEL_2) == HAL_OK));
    Check("HAL_TIM_PWM_Start(CH3) returns HAL_OK", (HAL_TIM_PWM_Start(&htim_dev, TIM_CHANNEL_3) == HAL_OK));
    Check("HAL_TIM_PWM_Start(CH4) returns HAL_OK", (HAL_TIM_PWM_Start(&htim_dev, TIM_CHANNEL_4) == HAL_OK));
    Check("HAL_TIM_PWM_Start(CH5) returns HAL_OK", (HAL_TIM_PWM_Start(&htim_dev, TIM_CHANNEL_5) == HAL_OK));
    Check("HAL_TIM_PWM_Start(CH6) returns HAL_OK", (HAL_TIM_PWM_Start(&htim_dev, TIM_CHANNEL_6) == HAL_OK));
    HAL_TIM_CtrlPWMOutputs(&htim_dev, TIM_ENABLE);
    Check("BDTR.MOE is set", ((TIM0->BDTR & TIM_BDTR_MOE) != 0U));
    Check("CCER reads CC1E set", ((TIM0->CCER & TIM_CCER_CC1E) != 0U));
    Check("CCER reads CC2E set", ((TIM0->CCER & TIM_CCER_CC2E) != 0U));
    Check("CCER reads CC3E set", ((TIM0->CCER & TIM_CCER_CC3E) != 0U));
    Check("CCER reads CC4E set", ((TIM0->CCER & TIM_CCER_CC4E) != 0U));
    Check("CCER reads CC5E set", ((TIM0->CCER & TIM_CCER_CC5E) != 0U));
    Check("CCER reads CC6E set", ((TIM0->CCER & TIM_CCER_CC6E) != 0U));
    Check("CR1.CEN is set", ((TIM0->CR1 & TIM_CR1_CEN) != 0U));

    /* Register evidence for the bench. The counter runs at 45 MHz / 9 = 5 MHz
       and the auto reload value is 100000, so every channel produces a 50 Hz
       square wave with a 50 percent duty cycle on its pin. Channels 1..3 use
       PWM mode 1 (low at the start of the period, high after the compare) and
       channels 4..6 use PWM mode 2 (the opposite phase). */
    printf("PSC=%d ARR=%d CCR1..6=%d/%d/%d/%d/%d/%d\r\n",
           (int)TIM0->PSC, (int)TIM0->ARR,
           (int)TIM0->CCR1, (int)TIM0->CCR2, (int)TIM0->CCR3,
           (int)TIM0->CCR4, (int)TIM0->CCR5, (int)TIM0->CCR6);
    printf("CCMR1=0x%08X CCMR2=0x%08X CCMR3=0x%08X\r\n",
           (unsigned int)TIM0->CCMR1, (unsigned int)TIM0->CCMR2, (unsigned int)TIM0->CCMR3);
    printf("CCER=0x%08X BDTR=0x%08X CR1=0x%08X CNT=%d\r\n",
           (unsigned int)TIM0->CCER, (unsigned int)TIM0->BDTR, (unsigned int)TIM0->CR1,
           (int)TIM0->CNT);
    printf("GPIOA RWM0CR=0x%08X MI0SR=0x%08X OMCR=0x%08X\r\n",
           (unsigned int)GPIOA->RWM0CR, (unsigned int)GPIOA->MI0SR, (unsigned int)GPIOA->OMCR);
    printf("GPIOC RWM0CR=0x%08X MI0SR=0x%08X OMCR=0x%08X\r\n",
           (unsigned int)GPIOC->RWM0CR, (unsigned int)GPIOC->MI0SR, (unsigned int)GPIOC->OMCR);
    printf("analyser 50 Hz / 50%% : CH1=PC3, CH2=PA0, CH3=PA1 (PWM1, high after the compare)\r\n");
    printf("                       CH4=PA2, CH5=PA3, CH6=PA4 (PWM2, low after the compare)\r\n");

    Summary();

    for (;;)
    {

    }
}
