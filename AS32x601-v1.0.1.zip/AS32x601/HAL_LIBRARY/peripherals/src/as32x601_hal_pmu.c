/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_pmu.c
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.3
 * Date:   2026/10/09
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.1     apply the resource lock / RTOS rules:
 *                                                       run the MSP callbacks outside the
 *                                                       locked region, add a Timeout and a
 *                                                       NULL-mutex guard to the lock helper,
 *                                                       add the busy / reset state gate and
 *                                                       the busy intermediate state, return
 *                                                       HAL_StatusTypeDef from the twenty
 *                                                       configuration interfaces with
 *                                                       run-time parameter validation
 *     ANSILIC APPLICATION GROUP  2026/10/08     1.2     merge the capabilities of the System Management
 *                                                       release of 2026/09/29 (header V1.2):
 *                                                       - HAL_PMU_WakeUpSourceCmd() and
 *                                                       HAL_PMU_ClearFlag() accept any
 *                                                       combination of the available channels
 *                                                       (IS_PMU_WKSOURCE_MASK /
 *                                                       IS_PMU_CLEAR_MASK), because the register
 *                                                       accesses (WKEN |= / &= ~, WKFR write) and
 *                                                       the documentation already described a
 *                                                       combination while the former checks only
 *                                                       accepted one single value;
 *                                                       - HAL_PMU_PowerModeConfig() writes only the
 *                                                       POWMC field of PMCR and
 *                                                       HAL_PMU_GetPowerModeStatus() decodes only
 *                                                       that field, instead of writing / reading
 *                                                       the whole register (a reserved bit can no
 *                                                       longer reach the enumeration)
 *     ANSILIC APPLICATION GROUP  2026/10/09     1.3     add HAL_PMU_GetWakeUpFlag(), the mask based
 *                                                       wake-up status query: it accepts the same
 *                                                       mask family HAL_PMU_ClearFlag() writes, so
 *                                                       several wake-up sources can be tested in
 *                                                       one call and the tested mask can be
 *                                                       cleared with the same value
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Power Management Unit
 *                  (PMU) of the AS32x601:
 *                  - Initialization and de-initialization;
 *                  - Power mode control: sleep / deep sleep mode selection
 *                    and current mode read-back;
 *                  - Wake-up source management;
 *                  - LDO control: 3.3V / 2.5V / 1.2V / 1.2V-backup / 1.2V
 *                    reference LDO enable and voltage scaling;
 *                  - Voltage detection: low voltage reset, high / low
 *                    voltage detect enable and threshold scaling;
 *                  - Oscillator control: internal RC 16 MHz enable, RC
 *                    32 kHz frequency scaling;
 *                  - Flag management: LDO ready / wake-up flags query and
 *                    clear;
 *                  - State and error reporting.
 *
 *                  Typical usage of the PMU:
 *                  (#) Call HAL_PMU_Init() with the handle (every
 *                      configuration interface requires the handle to be
 *                      READY);
 *                  (#) Configure the LDOs with HAL_PMU_LDO3v3Cmd() /
 *                      HAL_PMU_LDO3v3VOLSca() and the other LDO functions;
 *                  (#) Optionally enable the voltage detectors and the
 *                      RC oscillators;
 *                  (#) Enter sleep / deep sleep with
 *                      HAL_PMU_PowerModeConfig() and wake up with the
 *                      configured sources.
 *
 *                  All the configuration interfaces take the handle lock and
 *                  reject a call when the handle is busy (an operation is
 *                  ongoing in another context) or not initialized; the
 *                  read-only interfaces are lock-free.
 */
#include "as32x601_hal.h"              /* HAL_StatusTypeDef / HAL_MAX_DELAY / UNUSED */
#include "as32x601_hal_pmu.h"           /* PMU HAL API and register macros            */

/* The HAL_PMU_MODULE_ENABLED switch is provided by the user configuration
 * file (as32x601_hal_conf.h, included above through as32x601_hal.h): the
 * whole implementation is compiled only while the module is enabled. */
#ifdef HAL_PMU_MODULE_ENABLED

/* Private define ------------------------------------------------------------*/

/* Flag encoding: bits[6:5] select the status register (01 = LDOSR,
    10 = WKFR), bits[4:0] give the bit position */
#define PMU_SR_MASK                 ((uint32)0x00000060U)  /*!< Status register select bits */
#define PMU_SR_POS                  ((uint32)5U)           /*!< Status register select shift */
#define PMU_FLAG_MASK               ((uint32)0x0000001FU)  /*!< Bit position mask           */

/* Private functions ---------------------------------------------------------*/

/* Private function prototypes -----------------------------------------------*/
static uint32 PMU_HandleIsValid(HAL_PMU_HandleTypeDef *hpmu);
static HAL_StatusTypeDef PMU_CheckState(HAL_PMU_HandleTypeDef *hpmu);

/**
 * @brief  Check whether a PMU handle and its instance are valid.
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
static uint32 PMU_HandleIsValid(HAL_PMU_HandleTypeDef *hpmu)
{
    if (hpmu == NULL_PTR)
    {
        return 0U;
    }

    if (IS_PMU_ALL_INSTANCE(hpmu->Instance) == 0U)
    {
        return 0U;
    }

    return 1U;
}

/**
 * @brief  Check whether the handle accepts a new operation.
 * @note   Architecture constraint ARCH-CONST-09: a handle that is BUSY (an
 *         operation is ongoing in another context) rejects any other operation
 *         with HAL_BUSY, and a handle that is not initialized (RESET) requires
 *         HAL_PMU_Init() first and is rejected with HAL_ERROR. The recoverable
 *         state ERROR accepts a new operation directly (the entry point of the
 *         operation programs the registers again, so that no DeInit / Init
 *         round trip is required).
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK (accepted) / HAL_BUSY / HAL_ERROR.
 */
static HAL_StatusTypeDef PMU_CheckState(HAL_PMU_HandleTypeDef *hpmu)
{
    if (hpmu->State == HAL_PMU_STATE_BUSY)
    {
        return HAL_BUSY;
    }

    if (hpmu->State == HAL_PMU_STATE_RESET)
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_PMU_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; when the mutex is not acquired before the
 *         Timeout expires, HAL_TIMEOUT is returned. The value is passed to
 *         HAL_MutexAcquire() as is (RTOS ticks; with the usual 1 ms tick it is
 *         the same quantity as the millisecond Timeout of the public API, and
 *         HAL_MAX_DELAY means an infinite wait).
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef PMU_LockHandle(HAL_PMU_HandleTypeDef *hpmu, uint32 Timeout)
{
#if (USE_RTOS == 1)
    if (hpmu->LockMutex == NULL_PTR)
    {
        /* The porting layer did not create the mutex (e.g. HAL_PMU_MspInit()
         * was not overridden): report it instead of calling the RTOS with a
         * NULL handle */
        return HAL_ERROR;
    }

    return HAL_MutexAcquire(hpmu->LockMutex, Timeout);
#else
    /* Prevent unused argument compilation warning: the bare-metal lock flag
     * either succeeds immediately or reports HAL_BUSY, it never waits */
    UNUSED(Timeout);

    if (hpmu->Lock == HAL_LOCKED)
    {
        return HAL_BUSY;
    }

    hpmu->Lock = HAL_LOCKED;

    return HAL_OK;
#endif /* USE_RTOS */
}

/**
 * @brief  Unlock the handle.
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @retval None
 */
void PMU_UnlockHandle(HAL_PMU_HandleTypeDef *hpmu)
{
#if (USE_RTOS == 1)
    (void)HAL_MutexRelease(hpmu->LockMutex);
#else
    hpmu->Lock = HAL_UNLOCKED;
#endif /* USE_RTOS */
}

/* Exported functions ---------------------------------------------------------*/

/** @addtogroup PMU_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Initializes the PMU handle. (NON-BLOCKING)
 * @note   The PMU is located on the APB-BusS clock domain and is always
 *         clocked; the default HAL_PMU_MspInit() is empty. The user may
 *         override it to configure additional low-level settings.
 * @note   Every configuration interface requires the handle to be READY, so
 *         HAL_PMU_Init() must be called before the LDO / detector / wake-up
 *         interfaces (a handle straight from __HAL_CLEAR_STRUCT() is in the
 *         RESET state and its calls are rejected with HAL_ERROR).
 * @note   LOCK-06: the low level initialization (HAL_PMU_MspInit()) runs
 *         before the handle is locked, so that an override which calls other
 *         HAL APIs (e.g. HAL_GPIO_Init()) cannot deadlock.
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (NULL pointer or invalid instance)
 */
HAL_StatusTypeDef HAL_PMU_Init(HAL_PMU_HandleTypeDef *hpmu)
{
    /* Check the PMU peripheral handle and instance */
    if (PMU_HandleIsValid(hpmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Allocate the lock resource before the first use, so that a handle that
     * was never initialized cannot report HAL_BUSY from a stale Lock field */
    if (hpmu->State == HAL_PMU_STATE_RESET)
    {
        hpmu->Lock = HAL_UNLOCKED;

        /* Init the low level hardware (empty for the PMU). LOCK-06: the MSP
         * callback runs before the handle is locked */
        HAL_PMU_MspInit(hpmu);
    }

    /* Process locked */
    if (PMU_LockHandle(hpmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hpmu->ErrorCode = HAL_PMU_ERROR_NONE;
    hpmu->State = HAL_PMU_STATE_BUSY;

    hpmu->State = HAL_PMU_STATE_READY;

    /* Release Lock */
    PMU_UnlockHandle(hpmu);

    return HAL_OK;
}

/**
 * @brief  De-initializes the PMU peripheral. (NON-BLOCKING)
 * @note   The call is accepted from any handle state, so that a failed
 *         initialization can always be undone; the handle goes back to the
 *         RESET state so that a following HAL_PMU_Init() re-runs
 *         HAL_PMU_MspInit().
 * @note   LOCK-06: the low level de-initialization (HAL_PMU_MspDeInit()) runs
 *         after the unlock, so that an override which calls other HAL APIs
 *         (e.g. HAL_GPIO_DeInit()) cannot deadlock.
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (NULL pointer or invalid instance)
 */
HAL_StatusTypeDef HAL_PMU_DeInit(HAL_PMU_HandleTypeDef *hpmu)
{
    /* Check the PMU peripheral handle and instance */
    if (PMU_HandleIsValid(hpmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Process locked. ARCH-CONST-09: the de-initialization is callable from
     * any handle state, so that a failed initialization can always be undone */
    if (PMU_LockHandle(hpmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hpmu->ErrorCode = HAL_PMU_ERROR_NONE;
    hpmu->State = HAL_PMU_STATE_BUSY;

    /* Reset the state */
    hpmu->State = HAL_PMU_STATE_RESET;

    /* Release Lock */
    PMU_UnlockHandle(hpmu);

    /* LOCK-06 / ARCH-CONST-04: the low level de-initialization runs OUTSIDE
     * the locked region, as the architecture specification requires for the
     * MSP callbacks ("MspDeInit is called after the unlock") */
    HAL_PMU_MspDeInit(hpmu);

    return HAL_OK;
}

/**
 * @brief  Initializes the PMU MSP. Weak empty function; the PMU is always
 *         clocked on the APB-BusS domain, no clock gating is needed.
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_PMU_MspInit(HAL_PMU_HandleTypeDef *hpmu)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hpmu);
}

/**
 * @brief  De-initializes the PMU MSP. Weak empty function.
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_PMU_MspDeInit(HAL_PMU_HandleTypeDef *hpmu)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hpmu);
}

/**
  * @}
  */

/** @addtogroup PMU_Exported_Functions_Group2 Power Mode functions
  * @{
  */

/**
 * @brief  Selects the power mode to be switched to (sleep or deep sleep). (NON-BLOCKING)
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  PowerMode: HAL_PMU_POWERMODE_SLEEP or HAL_PMU_POWERMODE_DEEPSLEEP.
 * @retval None
 */
HAL_StatusTypeDef HAL_PMU_PowerModeConfig(HAL_PMU_HandleTypeDef *hpmu, HAL_PMU_PowerModeTypeDef PowerMode)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the PMU peripheral handle and instance */
    if (PMU_HandleIsValid(hpmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_PMU_ALL_INSTANCE(hpmu->Instance));
    assert_param(IS_PMU_POWERMODE(PowerMode));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((IS_PMU_POWERMODE(PowerMode) == 0U))
    {
        hpmu->ErrorCode |= HAL_PMU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_PMU_Init() is
     * required first) */
    status = PMU_CheckState(hpmu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (PMU_LockHandle(hpmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Select the power mode. Only the POWMC field is written: the reserved bits
     * of the register are left untouched */
    MODIFY_REG(hpmu->Instance->PMCR, PMU_PMCR_POWMC_Msk, ((uint32)PowerMode << PMU_PMCR_POWMC_Pos));

    /* Release Lock */
    PMU_UnlockHandle(hpmu);

    return HAL_OK;
}

/**
 * @brief  Returns the current working power mode. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context.
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @retval HAL_PMU_PowerModeTypeDef: the current power mode (HAL_PMU_POWERMODE_INIT
 *         when the handle or the instance is invalid).
 */
HAL_PMU_PowerModeTypeDef HAL_PMU_GetPowerModeStatus(HAL_PMU_HandleTypeDef *hpmu)
{
    /* Check the PMU peripheral handle and instance */
    if (PMU_HandleIsValid(hpmu) == 0U)
    {
        return HAL_PMU_POWERMODE_INIT;
    }

    /* Read-only: no lock. Only the POWMC field is decoded, so that a reserved
     * bit of the register cannot produce an out of range enumeration value */
    return (HAL_PMU_PowerModeTypeDef)((hpmu->Instance->PMCR & PMU_PMCR_POWMC_Msk) >> PMU_PMCR_POWMC_Pos);
}

/**
  * @}
  */

/** @addtogroup PMU_Exported_Functions_Group3 Wake-up Source functions
  * @{
  */

/**
 * @brief  Enables or disables the sleep wake-up source channel(s). (NON-BLOCKING)
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  WakeUpSource: HAL_PMU_WKSOURCE_xxx combination (WKEN bit masks); any
 *         combination of the available channels is accepted, for example
 *         PMU_WKSOURCE_ALL to enable every channel at once. The two reserved
 *         register bits are rejected.
 * @param  NewState: PMU_ENABLE or PMU_DISABLE.
 * @retval None
 */
HAL_StatusTypeDef HAL_PMU_WakeUpSourceCmd(HAL_PMU_HandleTypeDef *hpmu, uint32 WakeUpSource, FunctionalState NewState)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the PMU peripheral handle and instance */
    if (PMU_HandleIsValid(hpmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_PMU_ALL_INSTANCE(hpmu->Instance));
    assert_param(IS_PMU_WKSOURCE_MASK(WakeUpSource));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((IS_PMU_WKSOURCE_MASK(WakeUpSource) == 0U) || (IS_FUNCTIONAL_STATE(NewState) == 0U))
    {
        hpmu->ErrorCode |= HAL_PMU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_PMU_Init() is
     * required first) */
    status = PMU_CheckState(hpmu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (PMU_LockHandle(hpmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    if (NewState != PMU_DISABLE)
    {
        /* Enable the selected wake-up source(s) */
        hpmu->Instance->WKEN |= WakeUpSource;
    }
    else
    {
        /* Disable the selected wake-up source(s) */
        hpmu->Instance->WKEN &= ~WakeUpSource;
    }

    /* Release Lock */
    PMU_UnlockHandle(hpmu);

    return HAL_OK;
}

/**
  * @}
  */

/** @addtogroup PMU_Exported_Functions_Group4 LDO Control functions
  * @{
  */

/**
 * @brief  Enables or disables the 3.3V LDO. (NON-BLOCKING)
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  NewState: PMU_ENABLE or PMU_DISABLE.
 * @retval None
 */
HAL_StatusTypeDef HAL_PMU_LDO3v3Cmd(HAL_PMU_HandleTypeDef *hpmu, FunctionalState NewState)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the PMU peripheral handle and instance */
    if (PMU_HandleIsValid(hpmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_PMU_ALL_INSTANCE(hpmu->Instance));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((IS_FUNCTIONAL_STATE(NewState) == 0U))
    {
        hpmu->ErrorCode |= HAL_PMU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_PMU_Init() is
     * required first) */
    status = PMU_CheckState(hpmu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (PMU_LockHandle(hpmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    if (NewState != PMU_DISABLE)
    {
        /* Enable the 3.3V LDO */
        hpmu->Instance->LDOCR |= PMU_LDOCR_3V3LDOEN;
    }
    else
    {
        /* Disable the 3.3V LDO */
        hpmu->Instance->LDOCR &= ~PMU_LDOCR_3V3LDOEN;
    }

    /* Release Lock */
    PMU_UnlockHandle(hpmu);

    return HAL_OK;
}

/**
 * @brief  Enables or disables the 3.3V LDO bypass. (NON-BLOCKING)
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  NewState: PMU_ENABLE or PMU_DISABLE.
 * @retval None
 */
HAL_StatusTypeDef HAL_PMU_LDO3v3BypassCmd(HAL_PMU_HandleTypeDef *hpmu, FunctionalState NewState)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the PMU peripheral handle and instance */
    if (PMU_HandleIsValid(hpmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_PMU_ALL_INSTANCE(hpmu->Instance));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((IS_FUNCTIONAL_STATE(NewState) == 0U))
    {
        hpmu->ErrorCode |= HAL_PMU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_PMU_Init() is
     * required first) */
    status = PMU_CheckState(hpmu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (PMU_LockHandle(hpmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    if (NewState != PMU_DISABLE)
    {
        /* Enable the 3.3V LDO bypass */
        hpmu->Instance->LDOCR |= PMU_LDOCR_3V3LDOBYP;
    }
    else
    {
        /* Disable the 3.3V LDO bypass */
        hpmu->Instance->LDOCR &= ~PMU_LDOCR_3V3LDOBYP;
    }

    /* Release Lock */
    PMU_UnlockHandle(hpmu);

    return HAL_OK;
}

/**
 * @brief  Sets the 3.3V LDO output voltage scaling. (NON-BLOCKING)
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  VoltageValue: PMU_VO33_xxx voltage selection.
 * @retval None
 */
HAL_StatusTypeDef HAL_PMU_LDO3v3VOLSca(HAL_PMU_HandleTypeDef *hpmu, uint32 VoltageValue)
{
    HAL_StatusTypeDef status = HAL_OK;
    uint32 reg = 0U;

    /* Check the PMU peripheral handle and instance */
    if (PMU_HandleIsValid(hpmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_PMU_ALL_INSTANCE(hpmu->Instance));
    assert_param(IS_PMU_VOS3V3(VoltageValue));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((IS_PMU_VOS3V3(VoltageValue) == 0U))
    {
        hpmu->ErrorCode |= HAL_PMU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_PMU_Init() is
     * required first) */
    status = PMU_CheckState(hpmu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (PMU_LockHandle(hpmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Update the 3V3LDOVOS field, keep the other LDOCR bits */
    reg = hpmu->Instance->LDOCR;
    reg &= ~(uint32)(PMU_LDOCR_3V3LDOVOS);
    reg |= (uint32)(VoltageValue << PMU_LDOCR_3V3LDOVOS_Pos);
    hpmu->Instance->LDOCR = reg;

    /* Release Lock */
    PMU_UnlockHandle(hpmu);

    return HAL_OK;
}

/**
 * @brief  Enables or disables the 2.5V LDO. (NON-BLOCKING)
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  NewState: PMU_ENABLE or PMU_DISABLE.
 * @retval None
 */
HAL_StatusTypeDef HAL_PMU_LDO2v5Cmd(HAL_PMU_HandleTypeDef *hpmu, FunctionalState NewState)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the PMU peripheral handle and instance */
    if (PMU_HandleIsValid(hpmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_PMU_ALL_INSTANCE(hpmu->Instance));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((IS_FUNCTIONAL_STATE(NewState) == 0U))
    {
        hpmu->ErrorCode |= HAL_PMU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_PMU_Init() is
     * required first) */
    status = PMU_CheckState(hpmu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (PMU_LockHandle(hpmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    if (NewState != PMU_DISABLE)
    {
        /* Enable the 2.5V LDO */
        hpmu->Instance->LDOCR |= PMU_LDOCR_2V5LDOEN;
    }
    else
    {
        /* Disable the 2.5V LDO */
        hpmu->Instance->LDOCR &= ~PMU_LDOCR_2V5LDOEN;
    }

    /* Release Lock */
    PMU_UnlockHandle(hpmu);

    return HAL_OK;
}

/**
 * @brief  Sets the 2.5V LDO output voltage scaling. (NON-BLOCKING)
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  VoltageValue: PMU_VO25_xxx voltage selection.
 * @retval None
 */
HAL_StatusTypeDef HAL_PMU_LDO2v5VOLSca(HAL_PMU_HandleTypeDef *hpmu, uint32 VoltageValue)
{
    HAL_StatusTypeDef status = HAL_OK;
    uint32 reg = 0U;

    /* Check the PMU peripheral handle and instance */
    if (PMU_HandleIsValid(hpmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_PMU_ALL_INSTANCE(hpmu->Instance));
    assert_param(IS_PMU_VOS2V5(VoltageValue));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((IS_PMU_VOS2V5(VoltageValue) == 0U))
    {
        hpmu->ErrorCode |= HAL_PMU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_PMU_Init() is
     * required first) */
    status = PMU_CheckState(hpmu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (PMU_LockHandle(hpmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Update the 2V5LDOVOS field, keep the other LDOCR bits */
    reg = hpmu->Instance->LDOCR;
    reg &= ~(uint32)(PMU_LDOCR_2V5LDOVOS);
    reg |= (uint32)(VoltageValue << PMU_LDOCR_2V5LDOVOS_Pos);
    hpmu->Instance->LDOCR = reg;

    /* Release Lock */
    PMU_UnlockHandle(hpmu);

    return HAL_OK;
}

/**
 * @brief  Enables or disables the 1.2V LDO. (NON-BLOCKING)
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  NewState: PMU_ENABLE or PMU_DISABLE.
 * @retval None
 */
HAL_StatusTypeDef HAL_PMU_LDO1v2Cmd(HAL_PMU_HandleTypeDef *hpmu, FunctionalState NewState)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the PMU peripheral handle and instance */
    if (PMU_HandleIsValid(hpmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_PMU_ALL_INSTANCE(hpmu->Instance));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((IS_FUNCTIONAL_STATE(NewState) == 0U))
    {
        hpmu->ErrorCode |= HAL_PMU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_PMU_Init() is
     * required first) */
    status = PMU_CheckState(hpmu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (PMU_LockHandle(hpmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    if (NewState != PMU_DISABLE)
    {
        /* Enable the 1.2V LDO */
        hpmu->Instance->LDOCR |= PMU_LDOCR_1V2LDOEN;
    }
    else
    {
        /* Disable the 1.2V LDO */
        hpmu->Instance->LDOCR &= ~PMU_LDOCR_1V2LDOEN;
    }

    /* Release Lock */
    PMU_UnlockHandle(hpmu);

    return HAL_OK;
}

/**
 * @brief  Sets the 1.2V LDO output voltage scaling. (NON-BLOCKING)
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  VoltageValue: PMU_VO12_xxx voltage selection.
 * @retval None
 */
HAL_StatusTypeDef HAL_PMU_LDO1v2VOLSca(HAL_PMU_HandleTypeDef *hpmu, uint32 VoltageValue)
{
    HAL_StatusTypeDef status = HAL_OK;
    uint32 reg = 0U;

    /* Check the PMU peripheral handle and instance */
    if (PMU_HandleIsValid(hpmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_PMU_ALL_INSTANCE(hpmu->Instance));
    assert_param(IS_PMU_VOS1V2(VoltageValue));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((IS_PMU_VOS1V2(VoltageValue) == 0U))
    {
        hpmu->ErrorCode |= HAL_PMU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_PMU_Init() is
     * required first) */
    status = PMU_CheckState(hpmu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (PMU_LockHandle(hpmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Update the 1V2LDOVOS field, keep the other LDOCR bits */
    reg = hpmu->Instance->LDOCR;
    reg &= ~(uint32)(PMU_LDOCR_1V2LDOVOS);
    reg |= (uint32)(VoltageValue << PMU_LDOCR_1V2LDOVOS_Pos);
    hpmu->Instance->LDOCR = reg;

    /* Release Lock */
    PMU_UnlockHandle(hpmu);

    return HAL_OK;
}

/**
 * @brief  Sets the 1.2V backup LDO output voltage scaling. (NON-BLOCKING)
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  VoltageValue: PMU_VO12_xxx voltage selection.
 * @retval None
 */
HAL_StatusTypeDef HAL_PMU_BLDO1v2VOLSca(HAL_PMU_HandleTypeDef *hpmu, uint32 VoltageValue)
{
    HAL_StatusTypeDef status = HAL_OK;
    uint32 reg = 0U;

    /* Check the PMU peripheral handle and instance */
    if (PMU_HandleIsValid(hpmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_PMU_ALL_INSTANCE(hpmu->Instance));
    assert_param(IS_PMU_VOS1V2(VoltageValue));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((IS_PMU_VOS1V2(VoltageValue) == 0U))
    {
        hpmu->ErrorCode |= HAL_PMU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_PMU_Init() is
     * required first) */
    status = PMU_CheckState(hpmu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (PMU_LockHandle(hpmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Update the 1V2BLDOVOS field, keep the other LDOCR bits */
    reg = hpmu->Instance->LDOCR;
    reg &= ~(uint32)(PMU_LDOCR_1V2BLDOVOS);
    reg |= (uint32)(VoltageValue << PMU_LDOCR_1V2BLDOVOS_Pos);
    hpmu->Instance->LDOCR = reg;

    /* Release Lock */
    PMU_UnlockHandle(hpmu);

    return HAL_OK;
}

/**
 * @brief  Enables or disables the 1.2V reference voltage source. (NON-BLOCKING)
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  NewState: PMU_ENABLE or PMU_DISABLE.
 * @retval None
 */
HAL_StatusTypeDef HAL_PMU_Refer1v2Cmd(HAL_PMU_HandleTypeDef *hpmu, FunctionalState NewState)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the PMU peripheral handle and instance */
    if (PMU_HandleIsValid(hpmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_PMU_ALL_INSTANCE(hpmu->Instance));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((IS_FUNCTIONAL_STATE(NewState) == 0U))
    {
        hpmu->ErrorCode |= HAL_PMU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_PMU_Init() is
     * required first) */
    status = PMU_CheckState(hpmu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (PMU_LockHandle(hpmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    if (NewState != PMU_DISABLE)
    {
        /* Enable the 1.2V reference voltage source */
        hpmu->Instance->LDOCR |= PMU_LDOCR_1V2VREFEN;
    }
    else
    {
        /* Disable the 1.2V reference voltage source */
        hpmu->Instance->LDOCR &= ~PMU_LDOCR_1V2VREFEN;
    }

    /* Release Lock */
    PMU_UnlockHandle(hpmu);

    return HAL_OK;
}

/**
 * @brief  Sets the 1.2V reference voltage source scaling. (NON-BLOCKING)
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  VoltageValue: PMU_VREF12_xxx voltage selection.
 * @retval None
 */
HAL_StatusTypeDef HAL_PMU_Refer1v2VOLSca(HAL_PMU_HandleTypeDef *hpmu, uint32 VoltageValue)
{
    HAL_StatusTypeDef status = HAL_OK;
    uint32 reg = 0U;

    /* Check the PMU peripheral handle and instance */
    if (PMU_HandleIsValid(hpmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_PMU_ALL_INSTANCE(hpmu->Instance));
    assert_param(IS_PMU_VREFS1V2(VoltageValue));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((IS_PMU_VREFS1V2(VoltageValue) == 0U))
    {
        hpmu->ErrorCode |= HAL_PMU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_PMU_Init() is
     * required first) */
    status = PMU_CheckState(hpmu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (PMU_LockHandle(hpmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Update the 1V2VREFS field, keep the other LDOCR bits */
    reg = hpmu->Instance->LDOCR;
    reg &= ~(uint32)(PMU_LDOCR_1V2VREFS);
    reg |= (uint32)(VoltageValue << PMU_LDOCR_1V2VREFS_Pos);
    hpmu->Instance->LDOCR = reg;

    /* Release Lock */
    PMU_UnlockHandle(hpmu);

    return HAL_OK;
}

/**
  * @}
  */

/** @addtogroup PMU_Exported_Functions_Group5 Voltage Detection functions
  * @{
  */

/**
 * @brief  Enables or disables the low voltage reset. (NON-BLOCKING)
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  NewState: PMU_ENABLE or PMU_DISABLE.
 * @retval None
 */
HAL_StatusTypeDef HAL_PMU_LowVolResetCmd(HAL_PMU_HandleTypeDef *hpmu, FunctionalState NewState)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the PMU peripheral handle and instance */
    if (PMU_HandleIsValid(hpmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_PMU_ALL_INSTANCE(hpmu->Instance));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((IS_FUNCTIONAL_STATE(NewState) == 0U))
    {
        hpmu->ErrorCode |= HAL_PMU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_PMU_Init() is
     * required first) */
    status = PMU_CheckState(hpmu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (PMU_LockHandle(hpmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    if (NewState != PMU_DISABLE)
    {
        /* Enable the low voltage reset */
        hpmu->Instance->VDCR |= PMU_VDCR_LVREN;
    }
    else
    {
        /* Disable the low voltage reset */
        hpmu->Instance->VDCR &= ~PMU_VDCR_LVREN;
    }

    /* Release Lock */
    PMU_UnlockHandle(hpmu);

    return HAL_OK;
}

/**
 * @brief  Enables or disables the high voltage detect. (NON-BLOCKING)
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  NewState: PMU_ENABLE or PMU_DISABLE.
 * @retval None
 */
HAL_StatusTypeDef HAL_PMU_HighVolDetectCmd(HAL_PMU_HandleTypeDef *hpmu, FunctionalState NewState)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the PMU peripheral handle and instance */
    if (PMU_HandleIsValid(hpmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_PMU_ALL_INSTANCE(hpmu->Instance));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((IS_FUNCTIONAL_STATE(NewState) == 0U))
    {
        hpmu->ErrorCode |= HAL_PMU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_PMU_Init() is
     * required first) */
    status = PMU_CheckState(hpmu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (PMU_LockHandle(hpmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    if (NewState != PMU_DISABLE)
    {
        /* Enable the high voltage detect */
        hpmu->Instance->VDCR |= PMU_VDCR_HVDEN;
    }
    else
    {
        /* Disable the high voltage detect */
        hpmu->Instance->VDCR &= ~PMU_VDCR_HVDEN;
    }

    /* Release Lock */
    PMU_UnlockHandle(hpmu);

    return HAL_OK;
}

/**
 * @brief  Sets the high voltage detect threshold scaling. (NON-BLOCKING)
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  VoltageValue: PMU_HVDTS_xxx threshold selection.
 * @retval None
 */
HAL_StatusTypeDef HAL_PMU_HighVolDetectThresholdSca(HAL_PMU_HandleTypeDef *hpmu, uint32 VoltageValue)
{
    HAL_StatusTypeDef status = HAL_OK;
    uint32 reg = 0U;

    /* Check the PMU peripheral handle and instance */
    if (PMU_HandleIsValid(hpmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_PMU_ALL_INSTANCE(hpmu->Instance));
    assert_param(IS_PMU_HVDTS(VoltageValue));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((IS_PMU_HVDTS(VoltageValue) == 0U))
    {
        hpmu->ErrorCode |= HAL_PMU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_PMU_Init() is
     * required first) */
    status = PMU_CheckState(hpmu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (PMU_LockHandle(hpmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Update the HVDTS field, keep the other VDCR bits */
    reg = hpmu->Instance->VDCR;
    reg &= ~(uint32)(PMU_VDCR_HVDTS);
    reg |= (uint32)(VoltageValue << PMU_VDCR_HVDTS_Pos);
    hpmu->Instance->VDCR = reg;

    /* Release Lock */
    PMU_UnlockHandle(hpmu);

    return HAL_OK;
}

/**
 * @brief  Enables or disables the low voltage detect. (NON-BLOCKING)
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  NewState: PMU_ENABLE or PMU_DISABLE.
 * @retval None
 */
HAL_StatusTypeDef HAL_PMU_LowVolDetectCmd(HAL_PMU_HandleTypeDef *hpmu, FunctionalState NewState)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the PMU peripheral handle and instance */
    if (PMU_HandleIsValid(hpmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_PMU_ALL_INSTANCE(hpmu->Instance));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((IS_FUNCTIONAL_STATE(NewState) == 0U))
    {
        hpmu->ErrorCode |= HAL_PMU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_PMU_Init() is
     * required first) */
    status = PMU_CheckState(hpmu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (PMU_LockHandle(hpmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    if (NewState != PMU_DISABLE)
    {
        /* Enable the low voltage detect */
        hpmu->Instance->VDCR |= PMU_VDCR_LVDEN;
    }
    else
    {
        /* Disable the low voltage detect */
        hpmu->Instance->VDCR &= ~PMU_VDCR_LVDEN;
    }

    /* Release Lock */
    PMU_UnlockHandle(hpmu);

    return HAL_OK;
}

/**
 * @brief  Sets the low voltage detect threshold scaling. (NON-BLOCKING)
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  VoltageValue: PMU_LVDTS_xxx threshold selection.
 * @retval None
 */
HAL_StatusTypeDef HAL_PMU_LowVolDetectThresholdSca(HAL_PMU_HandleTypeDef *hpmu, uint32 VoltageValue)
{
    HAL_StatusTypeDef status = HAL_OK;
    uint32 reg = 0U;

    /* Check the PMU peripheral handle and instance */
    if (PMU_HandleIsValid(hpmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_PMU_ALL_INSTANCE(hpmu->Instance));
    assert_param(IS_PMU_LVDTS(VoltageValue));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((IS_PMU_LVDTS(VoltageValue) == 0U))
    {
        hpmu->ErrorCode |= HAL_PMU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_PMU_Init() is
     * required first) */
    status = PMU_CheckState(hpmu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (PMU_LockHandle(hpmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Update the LVDTS field, keep the other VDCR bits */
    reg = hpmu->Instance->VDCR;
    reg &= ~(uint32)(PMU_VDCR_LVDTS);
    reg |= (uint32)(VoltageValue << PMU_VDCR_LVDTS_Pos);
    hpmu->Instance->VDCR = reg;

    /* Release Lock */
    PMU_UnlockHandle(hpmu);

    return HAL_OK;
}

/**
  * @}
  */

/** @addtogroup PMU_Exported_Functions_Group6 Oscillator Control functions
  * @{
  */

/**
 * @brief  Enables or disables the internal RC 16 MHz oscillator. (NON-BLOCKING)
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  NewState: PMU_ENABLE or PMU_DISABLE.
 * @retval None
 */
HAL_StatusTypeDef HAL_PMU_RC16MCmd(HAL_PMU_HandleTypeDef *hpmu, FunctionalState NewState)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the PMU peripheral handle and instance */
    if (PMU_HandleIsValid(hpmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_PMU_ALL_INSTANCE(hpmu->Instance));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((IS_FUNCTIONAL_STATE(NewState) == 0U))
    {
        hpmu->ErrorCode |= HAL_PMU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_PMU_Init() is
     * required first) */
    status = PMU_CheckState(hpmu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (PMU_LockHandle(hpmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    if (NewState != PMU_DISABLE)
    {
        /* Enable the internal RC 16 MHz oscillator */
        hpmu->Instance->OCR |= PMU_OCR_IRC16MEN;
    }
    else
    {
        /* Disable the internal RC 16 MHz oscillator */
        hpmu->Instance->OCR &= ~PMU_OCR_IRC16MEN;
    }

    /* Release Lock */
    PMU_UnlockHandle(hpmu);

    return HAL_OK;
}

/**
 * @brief  Sets the RC 32 kHz clock frequency scaling. (NON-BLOCKING)
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  ClockFrequency: RC 32 kHz frequency scaling (0..0x3F).
 * @retval None
 */
HAL_StatusTypeDef HAL_PMU_RC32KFrequencySca(HAL_PMU_HandleTypeDef *hpmu, uint32 ClockFrequency)
{
    HAL_StatusTypeDef status = HAL_OK;
    uint32 reg = 0U;

    /* Check the PMU peripheral handle and instance */
    if (PMU_HandleIsValid(hpmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_PMU_ALL_INSTANCE(hpmu->Instance));
    assert_param(IS_PMU_RC32KFS(ClockFrequency));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((IS_PMU_RC32KFS(ClockFrequency) == 0U))
    {
        hpmu->ErrorCode |= HAL_PMU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_PMU_Init() is
     * required first) */
    status = PMU_CheckState(hpmu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (PMU_LockHandle(hpmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Update the RC32KFS field, keep the other OCR bits */
    reg = hpmu->Instance->OCR;
    reg &= ~(uint32)(PMU_OCR_RC32KFS);
    reg |= (uint32)(ClockFrequency << PMU_OCR_RC32KFS_Pos);
    hpmu->Instance->OCR = reg;

    /* Release Lock */
    PMU_UnlockHandle(hpmu);

    return HAL_OK;
}

/**
  * @}
  */

/** @addtogroup PMU_Exported_Functions_Group7 Flag and State functions
  * @{
  */

/**
 * @brief  Checks whether a PMU flag is set. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context.
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  PMU_FLAG: the flag to check (PMU_FLAG_xxx).
 * @retval 1 if the flag is set, 0 otherwise (also when the handle, the instance
 *         or the flag value is invalid).
 */
uint32 HAL_PMU_GetFlagStatus(HAL_PMU_HandleTypeDef *hpmu, uint32 PMU_FLAG)
{
    uint32 status = 0U;

    /* Check the PMU peripheral handle and instance */
    if (PMU_HandleIsValid(hpmu) == 0U)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_PMU_FLAG(PMU_FLAG));

    /* An invalid flag encoding would select an arbitrary register and bit;
     * report no status instead */
    if (IS_PMU_FLAG(PMU_FLAG) == 0U)
    {
        return 0U;
    }

    /* Read-only: no lock */

    /* The flag encoding selects the status register (LDOSR for 01, WKFR
       for 10) and the bit position */
    if (((PMU_FLAG & PMU_SR_MASK) >> PMU_SR_POS) == 1U)
    {
        /* LDO ready status register */
        status = (hpmu->Instance->LDOSR & (1UL << (PMU_FLAG & PMU_FLAG_MASK)));
    }
    else
    {
        /* Wake-up flag register */
        status = (hpmu->Instance->WKFR & (1UL << (PMU_FLAG & PMU_FLAG_MASK)));
    }

    return (status != 0U) ? 1U : 0U;
}

/**
 * @brief  Checks whether one or more PMU wake-up status flags are set. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context.
 * @note   The parameter is the same mask family that HAL_PMU_ClearFlag()
 *         writes, so one observation window can test and clear exactly the
 *         same wake-up sources with the same value.
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  WakeUpFlag: non-zero combination of the wake-up flag masks
 *         (PMU_CLEAR_IWDGWKF / PMU_CLEAR_RTCWKF / PMU_CLEAR_PH0WKF ..
 *         PMU_CLEAR_PH9WKF / PMU_CLEAR_FOCURF, or PMU_CLEAR_ALL).
 * @retval 1 if at least one of the selected flags is set, 0 otherwise (also
 *         when the handle, the instance binding or the mask is invalid).
 */
uint32 HAL_PMU_GetWakeUpFlag(HAL_PMU_HandleTypeDef *hpmu, uint32 WakeUpFlag)
{
    /* Check the PMU peripheral handle and instance */
    if (PMU_HandleIsValid(hpmu) == 0U)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_PMU_CLEAR_MASK(WakeUpFlag));

    /* An invalid mask would test an arbitrary register bit; report no status
     * instead */
    if (IS_PMU_CLEAR_MASK(WakeUpFlag) == 0U)
    {
        return 0U;
    }

    /* Read-only: no lock. The mask selects one or more bits of WKFR, exactly
       as the clear interface writes them */
    return ((hpmu->Instance->WKFR & WakeUpFlag) != 0U) ? 1U : 0U;
}

/**
 * @brief  Clears a PMU wake-up flag. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_PMU_Init() is required first).
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  PMU_FLAG: the flag(s) to clear (PMU_CLEAR_xxx, WKFR write value); any
 *         combination of the clearable flags is accepted, for example
 *         PMU_CLEAR_ALL to clear every wake-up flag in one access. The two
 *         reserved register bits are rejected.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_PMU_ClearFlag(HAL_PMU_HandleTypeDef *hpmu, uint32 PMU_FLAG)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the PMU peripheral handle and instance */
    if (PMU_HandleIsValid(hpmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_PMU_ALL_INSTANCE(hpmu->Instance));
    assert_param(IS_PMU_CLEAR_MASK(PMU_FLAG));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((IS_PMU_CLEAR_MASK(PMU_FLAG) == 0U))
    {
        hpmu->ErrorCode |= HAL_PMU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_PMU_Init() is
     * required first) */
    status = PMU_CheckState(hpmu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (PMU_LockHandle(hpmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Write the clear value to the wake-up flag register (write 1 to clear) */
    hpmu->Instance->WKFR = PMU_FLAG;

    /* Release Lock */
    PMU_UnlockHandle(hpmu);

    return HAL_OK;
}

/**
 * @brief  Returns the PMU handle state. (NON-BLOCKING)
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @retval HAL_PMU_StateTypeDef: the current handle state.
 */
HAL_PMU_StateTypeDef HAL_PMU_GetState(HAL_PMU_HandleTypeDef *hpmu)
{
    /* Check the PMU handle allocation */
    if (hpmu == NULL_PTR)
    {
        return HAL_PMU_STATE_RESET;
    }

    return hpmu->State;
}

/**
 * @brief  Returns the PMU error code. (NON-BLOCKING)
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @retval uint32: the PMU error code (HAL_PMU_ERROR_xxx).
 */
uint32 HAL_PMU_GetError(HAL_PMU_HandleTypeDef *hpmu)
{
    /* Check the PMU handle allocation */
    if (hpmu == NULL_PTR)
    {
        return HAL_PMU_ERROR_NONE;
    }

    return hpmu->ErrorCode;
}

/**
  * @}
  */

/**
  * @}
  */

#endif /* HAL_PMU_MODULE_ENABLED */

/*****END OF FILE*****/
