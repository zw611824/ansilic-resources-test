/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):  	Xiamen Guoke Anxin Technology Co., LTD
 * FileName:     	as32x601_print.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.0
 * Date:			2026/09/10
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/09/10     1.0     print module for the
 *                                                       USART integration test
 * Description:     Print (printf) retarget for the AS32x601 CLINT integration
 *                  test project. This is a HAL-library flavoured port of the
 *                  Bsp/print.c of the AS32x601 USART test project: USART0 is
 *                  configured on GPIOD pin 8 (TX) / pin 9 (RX) through the HAL
 *                  library only (SMU clock gates, GPIO alternate function and
 *                  HAL_USART_Init), and the C library output is routed to the
 *                  USART through putchar() / _write().
 *                  API: User_Print_Init().
 */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __AS32X601_PRINT_H
#define __AS32X601_PRINT_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "as32x601_hal.h"       /* uint32, USART / GPIO / SMU HAL API         */
#include <stdio.h>              /* printf / putchar                           */

/* Exported define -----------------------------------------------------------*/

/**
 * @brief printf argument helper for the HAL uint32 type.
 * @note  On the 32-bit RISC-V build (ILP32) the HAL "uint32" is an
 *        "unsigned long", while the "%u" / "%X" conversion specifiers expect
 *        an "unsigned int". Wrapping the argument keeps the printf calls free
 *        of format warnings whatever the width of "long" is.
 */
#define PRINT_U32(__VALUE__)        ((unsigned int)(__VALUE__))

/**
 * @brief Console USART selection (USART0 on GPIOD pin 8 / pin 9).
 */
#define PRINT_USART                 USART0
#define PRINT_USART_GPIO            GPIOD
#define PRINT_USART_TX_PIN          GPIO_PIN_8
#define PRINT_USART_RX_PIN          GPIO_PIN_9
#define PRINT_USART_TX_SOURCE       GPIO_PinSource8
#define PRINT_USART_RX_SOURCE       GPIO_PinSource9
#define PRINT_USART_AF              GPIO_AF_USART0

/**
 * @brief Default baud rate and per-call transfer timeout (in ms).
 */
#define PRINT_USART_BAUDRATE        (115200U)
#define PRINT_USART_TIMEOUT         (1000U)

/* Exported functions --------------------------------------------------------*/

/**
 * @brief  Initialize the print (console) USART.
 * @note   Enables the GPIOD / USART0 clock gates, configures the TX / RX
 *         alternate function and initializes USART0 through HAL_USART_Init().
 *         Once initialized, printf() output is routed to the console USART.
 * @param  BaudRate: USART communication baud rate, in bit/s.
 * @retval None
 */
void User_Print_Init(uint32 BaudRate);

/**
 * @brief  Send one character to the console USART (C library retarget hook).
 * @param  ch: character to send.
 * @retval The character sent.
 */
int putchar(int ch);

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_PRINT_H */

/*****END OF FILE*****/
