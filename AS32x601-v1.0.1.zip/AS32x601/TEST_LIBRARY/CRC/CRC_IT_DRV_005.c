/**
 * @file    CRC_IT_DRV_005.c
 * @brief   HAL CRC integration test case 005 (configuration admission, state
 *          gate, error reporting, handle protection).
 *
 * HAL library extension case for the defensive layer of the driver:
 *   - the default values of HAL_CRC_StructInit();
 *   - the run-time admission of HAL_CRC_Init(): the Size / Version / Reserved
 *     metadata and every enumerated field are validated even in a build with
 *     the assertions disabled;
 *   - a rejected configuration records HAL_CRC_ERROR_INVALID_PARAM and leaves
 *     the handle state and the control register untouched (CRC-REQ-042);
 *   - the handle / instance protection of every public entry;
 *   - the state gate on an uninitialized handle.
 *
 * Tested functionality:
 *   HAL_CRC_StructInit()
 *   HAL_CRC_Init() / HAL_CRC_DeInit()
 *   HAL_CRC_CalcCRC() / HAL_CRC_CalcWordBlockCRC() / HAL_CRC_CalcHalfBlockCRC()
 *   HAL_CRC_CalcByteBlockCRC() / HAL_CRC_Accumulate() / HAL_CRC_Calculate()
 *   HAL_CRC_Reset() / HAL_CRC_SetIDRegister() / HAL_CRC_GetIDRegister()
 *   HAL_CRC_GetCRC() / HAL_CRC_GetState() / HAL_CRC_GetError()
 *
 * Test procedure:
 *   1. verify the default values filled by HAL_CRC_StructInit();
 *   2. initialize the handle with a legal configuration;
 *   3. mutate one field at a time into an illegal value (metadata and every
 *      enumerated field) and verify for each of them that HAL_CRC_Init()
 *      returns HAL_ERROR, records HAL_CRC_ERROR_INVALID_PARAM, keeps the handle
 *      state and does not write the control register;
 *   4. restore a legal configuration and verify that the very same handle is
 *      accepted again without a manual de-initialization;
 *   5. call every public entry with a NULL handle and with a handle bound to a
 *      foreign instance address, and verify the documented refusal values;
 *   6. de-initialize the handle and verify the state gate of the calculation
 *      and control services, then re-initialize it.
 *
 * Expected behaviour:
 *   every rejection follows the documented contract and the summary prints
 *   "summary : failures = 0".
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
#define TEST_BAUDRATE                  (115200U)   /*!< console baud rate        */
#define TEST_ROUND_DELAY_MS            (2000U)     /*!< delay between two rounds */

/* Private variables ---------------------------------------------------------*/
static volatile uint32 check_failures = 0U;   /*!< failed check counter           */
static HAL_SMU_HandleTypeDef hsmu_clk;        /*!< SMU handle (clock tree)        */

/** @brief CRC handle used by this case. */
HAL_CRC_HandleTypeDef hcrc_dev;

/* MSP callback bookkeeping (written by the shared MSP callbacks) */
uint32 Crc_MspInitCount   = 0U;               /*!< HAL_CRC_MspInit() calls        */
uint32 Crc_MspDeInitCount = 0U;               /*!< HAL_CRC_MspDeInit() calls      */
uint32 Crc_MspStateAtInit = 0xFFFFFFFFU;      /*!< handle state seen in the MSP   */
uint32 Crc_MspLockAtInit  = 0xFFFFFFFFU;      /*!< handle lock seen in the MSP    */

/* Test pattern */
static uint32 test_words[2] = { 0x11223344U, 0x55667788U };
static uint16 test_halfs[2] = { 0x1234U, 0x5678U };
static uint8  test_bytes[2] = { 0x5AU, 0xA5U };

/* Shared helpers of this suite (defined at the end of this file) */
void Check(const char *name, uint32 condition);
void Summary(void);
void SystemClock_Init(void);
void Crc_ClockEnable(void);
void InitRejectionCheck(const char *name);



/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    CRC_InitTypeDef   crc_init;
    HAL_StatusTypeDef status;
    uint32 round = 0U;
    uint32 cr_legal;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== CRC_IT_DRV_005 : admission, state gate, protection ===\r\n");

    /* ---------------- 1. default values ------------------------------- */
    printf("-- HAL_CRC_StructInit() defaults --\r\n");
    __HAL_CLEAR_STRUCT(&crc_init);
    HAL_CRC_StructInit(&crc_init);
    Check("StructInit : Size = sizeof(CRC_InitTypeDef)",
          (crc_init.Size == (uint32)sizeof(CRC_InitTypeDef)) ? 1U : 0U);
    Check("StructInit : Version = CRC_INIT_VERSION",
          (crc_init.Version == CRC_INIT_VERSION) ? 1U : 0U);
    Check("StructInit : CRC_Size = CRC_SIZE_32B", (crc_init.CRC_Size == CRC_SIZE_32B) ? 1U : 0U);
    Check("StructInit : CRC_OXOR = CRC_OXOR_DISABLE",
          (crc_init.CRC_OXOR == CRC_OXOR_DISABLE) ? 1U : 0U);
    Check("StructInit : CRC_OReverse = CRC_OREVERSE_NOT",
          (crc_init.CRC_OReverse == CRC_OREVERSE_NOT) ? 1U : 0U);
    Check("StructInit : CRC_IReverse = CRC_IREVERSE_NONE",
          (crc_init.CRC_IReverse == CRC_IREVERSE_NONE) ? 1U : 0U);
    Check("StructInit : CRC_PolySize = CRC_POLYSIZE_32B",
          (crc_init.CRC_PolySize == CRC_POLYSIZE_32B) ? 1U : 0U);
    Check("StructInit : CRC_INIT = 0", (crc_init.CRC_INIT == 0x00000000U) ? 1U : 0U);
    Check("StructInit : CRC_Poly = CRC-32 (0x04C11DB7)",
          (crc_init.CRC_Poly == CRC_POLY_32) ? 1U : 0U);
    Check("StructInit : CRC_XOR = 0", (crc_init.CRC_XOR == 0x00000000U) ? 1U : 0U);
    Check("StructInit : Reserved[0..1] = 0",
          ((crc_init.Reserved[0] == 0U) && (crc_init.Reserved[1] == 0U)) ? 1U : 0U);

    /* a NULL structure must be a safe no-operation */
    HAL_CRC_StructInit(NULL);
    Check("StructInit(NULL) is a safe no-operation", 1U);

    /* validation macro family sanity (the same symbols the driver uses) */
    Check("IS_CRC_INPUTDATA_FORMAT() accepts the three formats",
          ((IS_CRC_INPUTDATA_FORMAT(HAL_CRC_INPUTDATA_FORMAT_BYTES) != 0U) &&
           (IS_CRC_INPUTDATA_FORMAT(HAL_CRC_INPUTDATA_FORMAT_HALFWORDS) != 0U) &&
           (IS_CRC_INPUTDATA_FORMAT(HAL_CRC_INPUTDATA_FORMAT_WORDS) != 0U)) ? 1U : 0U);
    Check("IS_CRC_INPUTDATA_FORMAT() refuses 0x5A",
          (IS_CRC_INPUTDATA_FORMAT(0x0000005AU) == 0U) ? 1U : 0U);
    Check("IS_CRC_SIZE() refuses the reserved encoding 0x3",
          (IS_CRC_SIZE(3U) == 0U) ? 1U : 0U);
    Check("IS_CRC_INSTANCE(CRC) accepts the instance, IS_CRC_INSTANCE(NULL) refuses it",
          ((IS_CRC_INSTANCE(CRC) != 0U) && (IS_CRC_INSTANCE(NULL) == 0U)) ? 1U : 0U);

    /* ---------------- 2. legal configuration -------------------------- */
    __HAL_CLEAR_STRUCT(&hcrc_dev);
    hcrc_dev.Instance = CRC;
    hcrc_dev.Init = crc_init;
    hcrc_dev.InputDataFormat = HAL_CRC_INPUTDATA_FORMAT_WORDS;

    status = HAL_CRC_Init(&hcrc_dev);
    Check("a legal configuration is accepted", (status == HAL_OK) ? 1U : 0U);
    Check("the handle is READY", (HAL_CRC_GetState(&hcrc_dev) == HAL_CRC_STATE_READY) ? 1U : 0U);

    for (;;)
    {
        /* ---------------- 3. rejected configurations ------------------ */
        printf("-- rejected configurations (metadata) --\r\n");
        cr_legal = CRC->CR;

        crc_init.Size = 0U;
        hcrc_dev.Init = crc_init;
        InitRejectionCheck("Size = 0 is rejected (INVALID_PARAM, state and CR unchanged)");
        crc_init.Size = (uint32)sizeof(CRC_InitTypeDef);

        crc_init.Version = 0x00000200U;
        hcrc_dev.Init = crc_init;
        InitRejectionCheck("Version = V2 is rejected");
        crc_init.Version = CRC_INIT_VERSION;

        crc_init.Reserved[0] = 1U;
        hcrc_dev.Init = crc_init;
        InitRejectionCheck("Reserved[0] != 0 is rejected");
        crc_init.Reserved[0] = 0U;

        crc_init.Reserved[1] = 1U;
        hcrc_dev.Init = crc_init;
        InitRejectionCheck("Reserved[1] != 0 is rejected");
        crc_init.Reserved[1] = 0U;

        printf("-- rejected configurations (enumerated fields) --\r\n");
        crc_init.CRC_Size = (CRC_SizeTypeDef)0x03U;
        hcrc_dev.Init = crc_init;
        InitRejectionCheck("CRC_Size = 0x3 (reserved encoding) is rejected");
        crc_init.CRC_Size = CRC_SIZE_32B;

        crc_init.CRC_PolySize = (CRC_PolySizeTypeDef)0x04U;
        hcrc_dev.Init = crc_init;
        InitRejectionCheck("CRC_PolySize = 0x4 is rejected");
        crc_init.CRC_PolySize = CRC_POLYSIZE_32B;

        crc_init.CRC_IReverse = (CRC_IReverseTypeDef)0x04U;
        hcrc_dev.Init = crc_init;
        InitRejectionCheck("CRC_IReverse = 0x4 is rejected");
        crc_init.CRC_IReverse = CRC_IREVERSE_NONE;

        crc_init.CRC_OXOR = 0x00000002U;
        hcrc_dev.Init = crc_init;
        InitRejectionCheck("CRC_OXOR = 0x2 is rejected");
        crc_init.CRC_OXOR = CRC_OXOR_DISABLE;

        crc_init.CRC_OReverse = 0x00000002U;
        hcrc_dev.Init = crc_init;
        InitRejectionCheck("CRC_OReverse = 0x2 is rejected");
        crc_init.CRC_OReverse = CRC_OREVERSE_NOT;

        hcrc_dev.Init = crc_init;
        hcrc_dev.InputDataFormat = 0x0000005AU;
        InitRejectionCheck("InputDataFormat = 0x5A is rejected");
        hcrc_dev.InputDataFormat = HAL_CRC_INPUTDATA_FORMAT_WORDS;

        if (round == 0U)
        {
            Check("the control register still holds the legal configuration",
                  (CRC->CR == cr_legal) ? 1U : 0U);
        }

        /* ---------------- 4. recovery ---------------------------------- */
        hcrc_dev.ErrorCode = HAL_CRC_ERROR_NONE;
        status = HAL_CRC_Init(&hcrc_dev);
        if (round == 0U)
        {
            Check("the legal configuration is accepted again (no manual DeInit needed)",
                  (status == HAL_OK) ? 1U : 0U);
            Check("the handle state is READY after the recovery",
                  (HAL_CRC_GetState(&hcrc_dev) == HAL_CRC_STATE_READY) ? 1U : 0U);
            Check("the error code was cleared by the accepted initialization",
                  (HAL_CRC_GetError(&hcrc_dev) == HAL_CRC_ERROR_NONE) ? 1U : 0U);
            Check("HAL_CRC_MspInit() ran only once for this handle",
                  (Crc_MspInitCount == 1U) ? 1U : 0U);
        }

        /* ---------------- 5. handle / instance protection -------------- */
        printf("-- NULL handle and foreign instance --\r\n");
        if (round == 0U)
        {
            Check("Init(NULL) returns HAL_ERROR", (HAL_CRC_Init(NULL) == HAL_ERROR) ? 1U : 0U);
            Check("DeInit(NULL) returns HAL_ERROR", (HAL_CRC_DeInit(NULL) == HAL_ERROR) ? 1U : 0U);
            Check("CalcCRC(NULL) returns 0",
                  (HAL_CRC_CalcCRC(NULL, 0x12345678U) == 0U) ? 1U : 0U);
            Check("CalcWordBlockCRC(NULL) returns 0",
                  (HAL_CRC_CalcWordBlockCRC(NULL, test_words, 2U) == 0U) ? 1U : 0U);
            Check("CalcHalfBlockCRC(NULL) returns 0",
                  (HAL_CRC_CalcHalfBlockCRC(NULL, test_halfs, 2U) == 0U) ? 1U : 0U);
            Check("CalcByteBlockCRC(NULL) returns 0",
                  (HAL_CRC_CalcByteBlockCRC(NULL, test_bytes, 2U) == 0U) ? 1U : 0U);
            Check("Accumulate(NULL) returns 0",
                  (HAL_CRC_Accumulate(NULL, test_words, 2U) == 0U) ? 1U : 0U);
            Check("Calculate(NULL) returns 0",
                  (HAL_CRC_Calculate(NULL, test_words, 2U) == 0U) ? 1U : 0U);
            Check("GetIDRegister(NULL) returns 0", (HAL_CRC_GetIDRegister(NULL) == 0U) ? 1U : 0U);
            Check("GetCRC(NULL) returns 0", (HAL_CRC_GetCRC(NULL) == 0U) ? 1U : 0U);
            Check("GetState(NULL) returns RESET",
                  (HAL_CRC_GetState(NULL) == HAL_CRC_STATE_RESET) ? 1U : 0U);
            Check("GetError(NULL) returns NONE", (HAL_CRC_GetError(NULL) == HAL_CRC_ERROR_NONE) ? 1U : 0U);
            HAL_CRC_Reset(NULL);                 /* must not fault */
            HAL_CRC_SetIDRegister(NULL, 0x5AU);  /* must not fault */
            Check("Reset(NULL) and SetIDRegister(NULL) are safe", 1U);
        }

        {
            /* a handle bound to a foreign address must be refused as well */
            HAL_CRC_HandleTypeDef foreign;

            __HAL_CLEAR_STRUCT(&foreign);
            foreign.Instance = (CRC_TypeDef *)0x40000000U;
            foreign.Init = crc_init;
            foreign.InputDataFormat = HAL_CRC_INPUTDATA_FORMAT_WORDS;

            if (round == 0U)
            {
                Check("Init() of a foreign instance returns HAL_ERROR",
                      (HAL_CRC_Init(&foreign) == HAL_ERROR) ? 1U : 0U);
                Check("CalcCRC() of a foreign instance returns 0",
                      (HAL_CRC_CalcCRC(&foreign, 0x12345678U) == 0U) ? 1U : 0U);
                Check("GetState() of a foreign instance returns RESET",
                      (HAL_CRC_GetState(&foreign) == HAL_CRC_STATE_RESET) ? 1U : 0U);
                Check("GetError() of a foreign instance returns NONE",
                      (HAL_CRC_GetError(&foreign) == HAL_CRC_ERROR_NONE) ? 1U : 0U);
            }
        }

        /* ---------------- 6. state gate on a RESET handle --------------- */
        printf("-- state gate on an uninitialized handle --\r\n");
        (void)HAL_CRC_DeInit(&hcrc_dev);
        if (round == 0U)
        {
            Check("the handle is RESET after the de-initialization",
                  (HAL_CRC_GetState(&hcrc_dev) == HAL_CRC_STATE_RESET) ? 1U : 0U);
            Check("CalcCRC() on a RESET handle returns 0",
                  (HAL_CRC_CalcCRC(&hcrc_dev, 0x12345678U) == 0U) ? 1U : 0U);
            Check("Accumulate() on a RESET handle returns 0",
                  (HAL_CRC_Accumulate(&hcrc_dev, test_words, 2U) == 0U) ? 1U : 0U);
            Check("Calculate() on a RESET handle returns 0",
                  (HAL_CRC_Calculate(&hcrc_dev, test_words, 2U) == 0U) ? 1U : 0U);
            Check("the state is untouched by the refused services",
                  (HAL_CRC_GetState(&hcrc_dev) == HAL_CRC_STATE_RESET) ? 1U : 0U);
        }

        status = HAL_CRC_Init(&hcrc_dev);
        if (round == 0U)
        {
            Check("re-initialization after the gate test succeeds", (status == HAL_OK) ? 1U : 0U);
            Summary();
        }

        round++;
        delay_ms(TEST_ROUND_DELAY_MS);
    }
}

/* Private functions -------------------------------------------------------*/

/**
 * @brief  Verify that HAL_CRC_Init() refuses the current configuration.
 * @note   Four conditions are checked at once, because a partial rejection is
 *         as wrong as an accepted one: the call returns HAL_ERROR, the error
 *         code records INVALID_PARAM, the handle state is unchanged and the
 *         control register was not written (CRC-REQ-042).
 * @param  name: description of the check
 * @retval None
 */
void InitRejectionCheck(const char *name)
{
    uint32            state_before = (uint32)hcrc_dev.State;
    uint32            cr_before = CRC->CR;
    HAL_StatusTypeDef status;

    hcrc_dev.ErrorCode = HAL_CRC_ERROR_NONE;
    status = HAL_CRC_Init(&hcrc_dev);

    Check(name,
          ((status == HAL_ERROR) &&
           (hcrc_dev.ErrorCode == HAL_CRC_ERROR_INVALID_PARAM) &&
           ((uint32)hcrc_dev.State == state_before) &&
           (CRC->CR == cr_before)) ? 1U : 0U);
}

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the other integration tests of this library:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2 and
 *         CANX2 by 8, which gives core 180 MHz and APB 22.5 MHz.
 * @param  None
 * @retval None
 */
void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks (console pins of USART0 on GPIOD) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Open the clock gate of the CRC unit and release its reset.
 * @param  None
 * @retval None
 */
void Crc_ClockEnable(void)
{
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_CRC_CLK_ENABLE();
    __HAL_SMU_CRC_FORCE_RESET();
    __HAL_SMU_CRC_RELEASE_RESET();
}

/* MSP callbacks ------------------------------------------------------------*/

/**
 * @brief  Initialize the CRC MSP (clock gate and reset release).
 * @param  hcrc: CRC handle
 * @retval None
 */
void HAL_CRC_MspInit(HAL_CRC_HandleTypeDef *hcrc)
{
    Crc_MspInitCount++;
    Crc_MspStateAtInit = (uint32)hcrc->State;
    Crc_MspLockAtInit  = (uint32)hcrc->Lock;

    Crc_ClockEnable();
}

/**
 * @brief  De-initialize the CRC MSP (the clock gate is left open).
 * @param  hcrc: CRC handle
 * @retval None
 */
void HAL_CRC_MspDeInit(HAL_CRC_HandleTypeDef *hcrc)
{
    Crc_MspDeInitCount++;

    (void)hcrc;
}

/*****END OF FILE*****/
