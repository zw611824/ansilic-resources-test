/**
 * @file    TIM_IT_DRV_031.c
 * @brief   TIM5 input capture on channels 1 and 2 with the capture interrupt
 *
 * HAL library port of the original AS32x601 standard-library test case
 * TIMER_IT_DRV_034.c, which drives TIM5. Only HAL library APIs are used; the register
 * read backs document what was programmed.
 *
 * Tested functionality:
 *   TIM_ICStructInit()      -> HAL_TIM_IC_StructInit()
 *   TIM_ICInit()            -> HAL_TIM_IC_ConfigChannel() (channels 1 and 2)
 *   TIM_ITConfig()          -> HAL_TIM_IC_Start_IT()
 *   TIM_GetITStatus()/TIM_ClearITPendingBit() -> HAL_TIM_IRQHandler()
 *   TIM_GetCapture1()..      -> HAL_TIM_ReadCapturedValue()
 *
 * Test procedure:
 *   map the capture pins of TIM5 as inputs;
 *   configure channels 1 and 2 as direct rising edge capture inputs;
 *   enable the capture interrupt of every channel and the PLIC line;
 *   feed a square wave into the pins and print the measured frequency per channel.
 *
 * Expected behaviour:
 *   every channel returns HAL_OK and CCxS reads 01 (CCMR3 for channels 5/6);
 *   DIER reads the CCxIE bits set after the interrupt based start;
 *   the capture callback runs for the channels that receive edges;
 *   the measured frequency is printed for every channel with input;
 *   every check prints [PASS] and "summary : failures = 0".
 *
 * Note:
 *   An external square wave is required on the pins of the channels under test.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
/* Console: USART0 on GPIOD pin 8 (TX) / pin 9 (RX), 115200 8N1 */
#define TEST_BAUDRATE                   (115200U)

#define TEST_ARR                        (100000U - 1U)
#define TEST_PSC                        (9U - 1U)
#define TEST_CHANNELS                   (2U)


/* Private variables -------------------------------------------------------*/
static HAL_TIM_HandleTypeDef htim_dev;          /*!< timer under test        */
static HAL_SMU_HandleTypeDef hsmu_clk;          /*!< SMU handle (clock tree) */
static SMU_ClocksTypeDef test_clocks;           /*!< clock tree read back in SystemClock_Init() */
static volatile uint32 check_failures = 0U;     /*!< failed check counter    */

/* Channels that the board brings out on this timer; the TIM5 channels 3..6
 * are not routed on the board. */
static const uint32 test_channels[TEST_CHANNELS] = {
    TIM_CHANNEL_1,
    TIM_CHANNEL_2
};

static volatile uint32 capture_count[6];        /*!< captures per channel    */
static volatile uint32 capture_value[6];        /*!< last capture per channel */
static volatile uint32 capture_prev[6];         /*!< previous capture of the channel */
static volatile uint32 capture_period[6];       /*!< last two captures span          */

void TIM5_IRQ_Handler(void);
void HAL_TIM_IC_CaptureCallback(HAL_TIM_HandleTypeDef *htim);


/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure one GPIO pin and, for the alternate function modes, the
 *         pin mux of that pin.
 * @param  port: GPIO port
 * @param  pin: pin mask
 * @param  source: pin source number (for the mux configuration)
 * @param  af: alternate function selector
 * @param  mode: GPIO_MODE_AF_PP / GPIO_MODE_INPUT
 * @retval None
 */
static void Gpio_Config(GPIO_TypeDef *port, uint32 pin, uint32 source, uint8 af, uint32 mode)
{
    GPIO_InitTypeDef gpio_init;

    __HAL_CLEAR_STRUCT(&gpio_init);
    gpio_init.Size         = sizeof(GPIO_InitTypeDef);
    gpio_init.Version      = GPIO_INIT_VERSION;
    gpio_init.Pin          = pin;
    gpio_init.Mode         = mode;
    gpio_init.Pull         = GPIO_NOPULL;
    gpio_init.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;
    gpio_init.Alternate    = af;
    /* The multiplex selection is independent of the pin direction: a pin that
       feeds a peripheral input (timer capture input, external clock input, ...)
       keeps MODER = input while the AFR field routes the pad to that peripheral.
       HAL_GPIO_Init() programs the AFR field only for the alternate function
       modes, so the input case must select the mux explicitly, otherwise the
       pad stays on its default function and the peripheral never sees it. */
    if (af != GPIO_AF_Pin_x)
    {
        HAL_GPIO_PinAFConfig(port, source, af);
    }
    HAL_GPIO_Init(port, &gpio_init);
}

/**
 * @brief  Configure the time base of the timer under test.
 * @note   The helper keeps the Size / Version meta fields through
 *         HAL_TIM_Base_StructInit(), which the initialization interface
 *         validates at run time.
 * @param  instance: TIM0..TIM7
 * @param  arr: auto reload value
 * @param  psc: prescaler value
 * @param  rcr: repetition counter (advanced timers only)
 * @param  ckd: clock division
 * @param  countermode: counting mode
 * @retval HAL status of HAL_TIM_Base_Init()
 */
static HAL_StatusTypeDef TimeBase_Config(TIM_TypeDef *instance, uint32 arr, uint32 psc,
                                         uint32 rcr, uint32 ckd, uint32 countermode)
{
    TIM_Base_InitTypeDef base_init;

    __HAL_CLEAR_STRUCT(&htim_dev);
    htim_dev.Instance = instance;

    HAL_TIM_Base_StructInit(&base_init);
    base_init.CounterMode       = countermode;
    base_init.ClockDivision     = ckd;
    base_init.Period            = arr;
    base_init.Prescaler         = psc;
    base_init.RepetitionCounter = rcr;
    htim_dev.Init               = base_init;

    return HAL_TIM_Base_Init(&htim_dev);
}

/**
 * @brief  Enable the clock of a timer instance and release its reset.
 * @note   The default MSP callbacks of this module are empty, so the suite
 *         performs the gate and reset handling itself; every MSP callback is
 *         routed to this helper.
 * @param  instance: TIM0..TIM7
 * @retval None
 */
static void Tim_ClockEnable(TIM_TypeDef *instance)
{
    if (instance == TIM0)
    {
        __HAL_SMU_HTIM0_CLK_ENABLE();
        __HAL_SMU_HTIM0_FORCE_RESET();
        __HAL_SMU_HTIM0_RELEASE_RESET();
    }
    else if (instance == TIM1)
    {
        __HAL_SMU_HTIM1_CLK_ENABLE();
        __HAL_SMU_HTIM1_FORCE_RESET();
        __HAL_SMU_HTIM1_RELEASE_RESET();
    }
    else if (instance == TIM2)
    {
        __HAL_SMU_HTIM2_CLK_ENABLE();
        __HAL_SMU_HTIM2_FORCE_RESET();
        __HAL_SMU_HTIM2_RELEASE_RESET();
    }
    else if (instance == TIM3)
    {
        __HAL_SMU_TIM3_CLK_ENABLE();
        __HAL_SMU_TIM3_FORCE_RESET();
        __HAL_SMU_TIM3_RELEASE_RESET();
    }
    else if (instance == TIM4)
    {
        __HAL_SMU_TIM4_CLK_ENABLE();
        __HAL_SMU_TIM4_FORCE_RESET();
        __HAL_SMU_TIM4_RELEASE_RESET();
    }
    else if (instance == TIM5)
    {
        __HAL_SMU_HTIM5_CLK_ENABLE();
        __HAL_SMU_HTIM5_FORCE_RESET();
        __HAL_SMU_HTIM5_RELEASE_RESET();
    }
    else if (instance == TIM6)
    {
        __HAL_SMU_TIM6_CLK_ENABLE();
        __HAL_SMU_TIM6_FORCE_RESET();
        __HAL_SMU_TIM6_RELEASE_RESET();
    }
    else
    {
        __HAL_SMU_TIM7_CLK_ENABLE();
        __HAL_SMU_TIM7_FORCE_RESET();
        __HAL_SMU_TIM7_RELEASE_RESET();
    }
}

/**
 * @brief  Read the CCxS (capture input selection) field of one channel.
 * @note   The field lives in CCMR1 for channels 1/2, in CCMR2 for channels 3/4
 *         and in CCMR3 for channels 5/6, at bit 0 or bit 8 of that register.
 * @param  inst: timer instance
 * @param  channel: TIM_CHANNEL_x
 * @retval uint32: the two bit CCxS value
 */
static uint32 CcsOf(TIM_TypeDef *inst, uint32 channel)
{
    uint32 reg;
    uint32 shift;

    switch (channel)
    {
    case TIM_CHANNEL_1:
        reg = inst->CCMR1;
        shift = 0U;
        break;
    case TIM_CHANNEL_2:
        reg = inst->CCMR1;
        shift = 8U;
        break;
    case TIM_CHANNEL_3:
        reg = inst->CCMR2;
        shift = 0U;
        break;
    case TIM_CHANNEL_4:
        reg = inst->CCMR2;
        shift = 8U;
        break;
    case TIM_CHANNEL_5:
        reg = inst->CCMR3;
        shift = 0U;
        break;
    default:
        reg = inst->CCMR3;
        shift = 8U;
        break;
    }

    return (reg >> shift) & 0x3U;
}

/* MSP callbacks: the timer clock and reset of the instance under test */
void HAL_TIM_Base_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_OC_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_PWM_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_IC_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_OnePulse_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_Encoder_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

/**
 * @brief  Frequency of the counter clock of the timer under test.
 * @note   The timer instances are attached to different buses: TIM0 to
 *         AXILite4 Bus1, TIM1 to AXILite4 Bus2, TIM2..TIM4 to APBBus0 and
 *         TIM5..TIM7 to APBBus1. The kernel clock is divided by the prescaler
 *         that the time base programs.
 * @param  instance: TIM0..TIM7
 * @retval uint32: counter clock in Hz (0 when the bus clock is unknown)
 */
static uint32 Timer_CounterClock(TIM_TypeDef *instance)
{
    uint32 bus = 0U;

    if (instance == TIM0)
    {
        bus = test_clocks.AXILite4Bus1_Frequency;
    }
    else if (instance == TIM1)
    {
        bus = test_clocks.AXILite4Bus2_Frequency;
    }
    else if ((instance == TIM2) || (instance == TIM3) || (instance == TIM4))
    {
        bus = test_clocks.APBBus0_Frequency;
    }
    else
    {
        bus = test_clocks.APBBus1_Frequency;
    }

    if (bus == 0U)
    {
        /* Fall back to the clock that feeds the APB bridges */
        bus = test_clocks.AXIBus3_Frequency;
    }

    return bus / (TEST_PSC + 1U);
}


/**
 * @brief  Capture callback of the timer under test.
 */
void HAL_TIM_IC_CaptureCallback(HAL_TIM_HandleTypeDef *htim)
{
    uint32 idx = htim->Channel / 4U;

    if (idx < 6U)
    {
        uint32 current = HAL_TIM_ReadCapturedValue(htim, htim->Channel);

        if (capture_count[idx] != 0U)
        {
            /* Number of counter ticks of one input period. The difference over
               the auto reload boundary stays positive, so the period has to be
               shorter than one auto reload cycle (ARR + 1 ticks, about 40 ms
               with this time base). */
            capture_period[idx] = (current >= capture_prev[idx])
                                  ? (current - capture_prev[idx])
                                  : (((TEST_ARR + 1U) - capture_prev[idx]) + current);
        }

        capture_prev[idx]  = current;
        capture_value[idx] = current;
        capture_count[idx]++;
    }
}

/**
 * @brief  Interrupt handler of the timer line.
 */
void TIM5_IRQ_Handler(void)
{
    HAL_TIM_IRQHandler(&htim_dev);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the CLINT / CMU / MPU / USART integration tests:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2, CANX2 by
 *         8 -> core 180 MHz, AXILite4 Bus 1 and Bus 2 = 45 MHz (TIM0, TIM1),
 *         APBBus0 and APBBus1 = 22.5 MHz (TIM2 / TIM3 / TIM4 and TIM5 / TIM6 /
 *         TIM7 - TIM2 and TIM5 are advanced timers on the APB).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks used by this suite (GPIOH lives in the always on
       domain and has no gate macro) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Clock tree order: write the dividers while the system clock is still
       FIRC, then configure the PLL and switch to it (that call programs the
       flash controller clock before the switch and updates SystemCoreClock
       afterwards). */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&test_clocks);
}

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    TIM_IC_InitTypeDef ic_cfg;
    PLIC_InitTypeDef plic_init;
    uint32 idx;
    uint32 ccs_ok;
    uint32 dier_ok;
    uint32 counter_clk;

    HAL_Init();
    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== TIM_IT_DRV_031 : TIM5 input capture on channels 1 and 2 ===\r\n");

    Gpio_Config(GPIOC, GPIO_PIN_9, GPIO_PinSource9, GPIO_AF_HTIM5, GPIO_MODE_INPUT);
    Gpio_Config(GPIOH, GPIO_PIN_9, GPIO_PinSource9, GPIO_AF_HTIM5, GPIO_MODE_INPUT);

    Check("HAL_TIM_Base_Init() returns HAL_OK",
          (TimeBase_Config(TIM5, TEST_ARR, TEST_PSC, 0U, TIM_CKD_DIV1, TIM_COUNTERMODE_UP) == HAL_OK));

    __HAL_CLEAR_STRUCT(&ic_cfg);
    HAL_TIM_IC_StructInit(&ic_cfg);
    ic_cfg.ICPolarity  = TIM_ICPOLARITY_RISING;
    ic_cfg.ICSelection = TIM_ICSEL_DIRECTTI;
    ic_cfg.ICPrescaler = TIM_ICPSC_DIV1;
    ic_cfg.ICFilter    = 0U;
    for (idx = 0U; idx < TEST_CHANNELS; idx++)
    {
        Check("HAL_TIM_IC_ConfigChannel() returns HAL_OK",
              (HAL_TIM_IC_ConfigChannel(&htim_dev, &ic_cfg, test_channels[idx]) == HAL_OK));
    }
    ccs_ok = 1U;
    for (idx = 0U; idx < TEST_CHANNELS; idx++)
    {
        if (CcsOf(TIM5, test_channels[idx]) != TIM_ICSEL_DIRECTTI)
        {
            ccs_ok = 0U;
        }
    }
    Check("CCxS reads 01 on every channel of this case", ccs_ok);

    HAL_PLIC_StructInit(&plic_init);
    plic_init.PLIC_IRQChannel    = TIM5_IRQn;
    plic_init.PLIC_IRQPriority   = 1U;
    plic_init.PLIC_IRQChannelCmd = PLIC_ENABLE;
    (void)HAL_PLIC_Init(&plic_init);

    for (idx = 0U; idx < TEST_CHANNELS; idx++)
    {
        Check("HAL_TIM_IC_Start_IT() returns HAL_OK",
              (HAL_TIM_IC_Start_IT(&htim_dev, test_channels[idx]) == HAL_OK));
    }
    dier_ok = 1U;
    for (idx = 0U; idx < TEST_CHANNELS; idx++)
    {
        if ((TIM5->DIER & (TIM_IT_CC1 << (test_channels[idx] / 4U))) == 0U)
        {
            dier_ok = 0U;
        }
    }
    Check("DIER reads the CCxIE bit of every channel of this case", dier_ok);

    /* Counter clock of the instance under test, so that the period of the
       input signal can be converted into a frequency. */
    counter_clk = Timer_CounterClock(TIM5);
    printf("counter clock = %d Hz (bus %d Hz / %d); feed a square wave into "
           "the channel pins to read its frequency below\r\n",
           (int)counter_clk, (int)(counter_clk * (TEST_PSC + 1U)),
           (int)(TEST_PSC + 1U));

    Summary();

    for (;;)
    {
        for (idx = 0U; idx < TEST_CHANNELS; idx++)
        {
            /* The callback stores a capture in the slot of the channel number
               (TIM_CHANNEL_x / 4), which is not the index inside the table of
               this case whenever the table does not start at channel 1. */
            uint32 cidx   = test_channels[idx] / 4U;
            uint32 period = capture_period[cidx];
            uint32 freq   = (period != 0U) ? (counter_clk / period) : 0U;

            if (capture_count[cidx] >= 2U)
            {
                printf("Channel %d captures = %d, period = %d ticks, freq = %d Hz, "
                       "last value = %d\r\n",
                       (int)(cidx + 1U), (int)capture_count[cidx],
                       (int)period, (int)freq, (int)capture_value[cidx]);
            }
            else
            {
                printf("Channel %d captures = %d, waiting for two edges, "
                       "last value = %d\r\n",
                       (int)(cidx + 1U), (int)capture_count[cidx],
                       (int)capture_value[cidx]);
            }
        }
        delay_ms(1000U);
    }
    {
        for (idx = 0U; idx < TEST_CHANNELS; idx++)
        {
            printf("Channel %d captures = %d, last value = %d\r\n",
                   (int)((test_channels[idx] / 4U) + 1U), (int)capture_count[idx],
                   (int)capture_value[idx]);
        }
        delay_ms(1000U);
    }
}
