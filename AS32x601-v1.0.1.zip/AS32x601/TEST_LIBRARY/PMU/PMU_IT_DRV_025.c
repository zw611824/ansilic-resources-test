/**
 * @file    PMU_IT_DRV_025.c
 * @brief   HAL PMU integration test case 025 (validation macros, mask mapping,
 *          wake-up table consistency and LDO ready flags).
 *
 * Extension case of the suite: it checks the structural side of the driver,
 * i.e. the validation macros of the module, the consistency of the three tables
 * that describe a wake-up source (the WKEN enable bit, the wake-up flag
 * selector and the flag clear value), the mask combinations the driver accepts
 * since the mask based release, and the LDO ready flags of the status register.
 * A typo in one of those tables compiles without a warning and yields a driver
 * that silently misses a wake-up source, which is why the case checks them
 * field by field instead of only using them.
 *
 * Tested functionality:
 *   IS_PMU_ALL_INSTANCE() / IS_PMU_ENABLE_STATE() / IS_PMU_POWERMODE()
 *   IS_PMU_WKSOURCE() / IS_PMU_WKSOURCE_MASK()
 *   IS_PMU_FLAG() / IS_PMU_CLEAR() / IS_PMU_CLEAR_MASK()
 *   IS_PMU_HVDTS() / IS_PMU_LVDTS()
 *   HAL_PMU_Init() / HAL_PMU_WakeUpSourceCmd() / HAL_PMU_ClearFlag()
 *   HAL_PMU_GetFlagStatus() / HAL_PMU_GetWakeUpFlag()
 *   PMU_WKSOURCE_ALL / PMU_CLEAR_ALL masks
 *   the voltage / threshold constant tables (first, default and last entry)
 *
 * Test procedure:
 *   1. The validation macros are called with accepted and rejected values;
 *   2. For every wake-up source the three table entries are compared with each
 *      other and with the flag encoding (bit position of the clear value);
 *   3. The all-masks are compared with the OR of their table, and clearing
 *      every wake-up flag is verified to leave the ready status register
 *      untouched (the clear family is a WKFR mask, the ready flags live in
 *      LDOSR);
 *   4. Mask combinations that are not the "all" mask are enabled, verified in
 *      WKEN, and disabled again;
 *   5. The wake-up flag queries (single flag and mask) are compared with a
 *      direct read of WKFR, and the flag clear is verified for a single value
 *      and for a combination;
 *   6. The LDO ready flags are compared with a direct read of the ready status
 *      register, and the rails that the running system uses are verified to be
 *      reported as ready;
 *   7. The first, default and last entry of every scaling constant table is
 *      sampled, plus the module version.
 *
 * Expected behaviour:
 *   - every check prints PASS and the summary stays at zero failures;
 *   - the case never enters a power mode, never enables a voltage detector and
 *     leaves every wake-up source and wake-up flag disabled / cleared.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Current (already scaled) rail values: the case only re-writes these */
#define TEST_VO33_SAFE              (PMU_VO33_3V30)
#define TEST_VO12_SAFE              (PMU_VO12_1V34)

/* Settling time granted to a rail after it has been enabled (ms) */
#define TEST_RAIL_SETTLE_MS         (5U)

/* Reporting period of the final loop (ms) */
#define TEST_POLL_MS                (1000U)

/* Private variables ---------------------------------------------------------*/
static HAL_PMU_HandleTypeDef hpmu_dev;      /*!< PMU device handle            */
static uint32                failures = 0U; /*!< failed checks                */
static uint32                checks = 0U;   /*!< executed checks              */

/* Wake-up source table: the WKEN bit, the flag selector and the clear value of
 * every source the PMU can wake the chip up from. The three columns describe
 * the same source, so they are checked against each other. */
static const uint32 wakeup_source[] =
{
    HAL_PMU_WKSOURCE_IWDG, HAL_PMU_WKSOURCE_RTC,
    HAL_PMU_WKSOURCE_PH0,  HAL_PMU_WKSOURCE_PH1, HAL_PMU_WKSOURCE_PH2,
    HAL_PMU_WKSOURCE_PH3,  HAL_PMU_WKSOURCE_PH4, HAL_PMU_WKSOURCE_PH5,
    HAL_PMU_WKSOURCE_PH6,  HAL_PMU_WKSOURCE_PH7, HAL_PMU_WKSOURCE_PH8,
    HAL_PMU_WKSOURCE_PH9
};

static const uint32 wakeup_flag[] =
{
    PMU_FLAG_IWDGWK, PMU_FLAG_RTCWK,
    PMU_FLAG_PH0WK,  PMU_FLAG_PH1WK, PMU_FLAG_PH2WK,
    PMU_FLAG_PH3WK,  PMU_FLAG_PH4WK, PMU_FLAG_PH5WK,
    PMU_FLAG_PH6WK,  PMU_FLAG_PH7WK, PMU_FLAG_PH8WK,
    PMU_FLAG_PH9WK
};

static const uint32 wakeup_clear[] =
{
    PMU_CLEAR_IWDGWKF, PMU_CLEAR_RTCWKF,
    PMU_CLEAR_PH0WKF,  PMU_CLEAR_PH1WKF, PMU_CLEAR_PH2WKF,
    PMU_CLEAR_PH3WKF,  PMU_CLEAR_PH4WKF, PMU_CLEAR_PH5WKF,
    PMU_CLEAR_PH6WKF,  PMU_CLEAR_PH7WKF, PMU_CLEAR_PH8WKF,
    PMU_CLEAR_PH9WKF
};

/* Every flag selector the driver accepts (the four LDO ready flags, the twelve
 * wake-up flags and the FOCU reset flag). */
static const uint32 all_flags[] =
{
    PMU_FLAG_3V3LDORDY, PMU_FLAG_2V5LDORDY, PMU_FLAG_1V2LDORDY, PMU_FLAG_1V2BLDORDY,
    PMU_FLAG_IWDGWK, PMU_FLAG_RTCWK,
    PMU_FLAG_PH0WK,  PMU_FLAG_PH1WK, PMU_FLAG_PH2WK, PMU_FLAG_PH3WK,
    PMU_FLAG_PH4WK,  PMU_FLAG_PH5WK, PMU_FLAG_PH6WK, PMU_FLAG_PH7WK,
    PMU_FLAG_PH8WK,  PMU_FLAG_PH9WK,
    PMU_FLAG_FOCUR
};

/* Every clearable flag value (the twelve wake-up flags and the FOCU reset flag;
 * the ready flags have no clear value, they track the hardware). */
static const uint32 all_clears[] =
{
    PMU_CLEAR_IWDGWKF, PMU_CLEAR_RTCWKF,
    PMU_CLEAR_PH0WKF,  PMU_CLEAR_PH1WKF, PMU_CLEAR_PH2WKF, PMU_CLEAR_PH3WKF,
    PMU_CLEAR_PH4WKF,  PMU_CLEAR_PH5WKF, PMU_CLEAR_PH6WKF, PMU_CLEAR_PH7WKF,
    PMU_CLEAR_PH8WKF,  PMU_CLEAR_PH9WKF,
    PMU_CLEAR_FOCURF
};

static HAL_SMU_HandleTypeDef hsmu_clk;   /*!< SMU handle (lock / state / error) */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void Section(const char *name);
static void Check(const char *name, uint32 condition);
static uint32 BitIndex(uint32 Value);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    uint32 i;
    uint32 count;
    uint32 mask;
    uint32 expected;
    uint32 combination;
    uint32 ldosr;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL, 45 MHz core clock) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n\r\n==== PMU_IT_DRV_025: validation macros, mask mapping, ready flags ====\r\n");
    printf("Data : %s\r\n", __DATE__);
    printf("Time : %s\r\n", __TIME__);

    __HAL_CLEAR_STRUCT(&hpmu_dev);
    hpmu_dev.Instance = PMU;
    Check("PMU init", (HAL_PMU_Init(&hpmu_dev) == HAL_OK));

    /* ==================================================================== *
     *  Group 1: validation macros
     * ==================================================================== */
    Section("Group 1: validation macros");

    Check("IS_PMU_ALL_INSTANCE(PMU) accepted", (IS_PMU_ALL_INSTANCE(PMU) == 1U));
    Check("IS_PMU_ALL_INSTANCE(0) rejected", (IS_PMU_ALL_INSTANCE(0) == 0U));
    Check("IS_PMU_ENABLE_STATE(PMU_ENABLE) accepted",
          (IS_PMU_ENABLE_STATE(PMU_ENABLE) == 1U));
    Check("IS_PMU_ENABLE_STATE(PMU_DISABLE) accepted",
          (IS_PMU_ENABLE_STATE(PMU_DISABLE) == 1U));
    Check("IS_PMU_ENABLE_STATE(2) rejected", (IS_PMU_ENABLE_STATE(2U) == 0U));

    Check("IS_PMU_POWERMODE(SLEEP) accepted",
          (IS_PMU_POWERMODE(HAL_PMU_POWERMODE_SLEEP) == 1U));
    Check("IS_PMU_POWERMODE(DEEPSLEEP) accepted",
          (IS_PMU_POWERMODE(HAL_PMU_POWERMODE_DEEPSLEEP) == 1U));
    Check("IS_PMU_POWERMODE(NORMAL) rejected (read-only status)",
          (IS_PMU_POWERMODE(HAL_PMU_POWERMODE_NORMAL) == 0U));

    /* every wake-up source of the table must be accepted, and the reserved
     * register bit plus the zero value must be rejected */
    count = (uint32)(sizeof(wakeup_source) / sizeof(wakeup_source[0]));
    mask = 0U;
    for (i = 0U; i < count; i++)
    {
        Check("IS_PMU_WKSOURCE(source) accepted",
              (IS_PMU_WKSOURCE(wakeup_source[i]) == 1U));
        mask |= wakeup_source[i];
    }
    Check("IS_PMU_WKSOURCE(0) rejected", (IS_PMU_WKSOURCE(0U) == 0U));
    Check("IS_PMU_WKSOURCE(reserved bit) rejected", (IS_PMU_WKSOURCE(0x8000U) == 0U));
    Check("IS_PMU_WKSOURCE_MASK(one source) accepted",
          (IS_PMU_WKSOURCE_MASK(HAL_PMU_WKSOURCE_RTC) == 1U));
    Check("IS_PMU_WKSOURCE_MASK(PMU_WKSOURCE_ALL) accepted",
          (IS_PMU_WKSOURCE_MASK(PMU_WKSOURCE_ALL) == 1U));
    Check("IS_PMU_WKSOURCE_MASK(0) rejected", (IS_PMU_WKSOURCE_MASK(0U) == 0U));
    Check("IS_PMU_WKSOURCE_MASK(reserved bit) rejected",
          (IS_PMU_WKSOURCE_MASK(0x8000U) == 0U));

    /* every flag selector and every clear value must be accepted */
    count = (uint32)(sizeof(all_flags) / sizeof(all_flags[0]));
    for (i = 0U; i < count; i++)
    {
        Check("IS_PMU_FLAG(flag) accepted", (IS_PMU_FLAG(all_flags[i]) == 1U));
    }
    Check("IS_PMU_FLAG(0xFF) rejected", (IS_PMU_FLAG(0x000000FFU) == 0U));

    count = (uint32)(sizeof(all_clears) / sizeof(all_clears[0]));
    for (i = 0U; i < count; i++)
    {
        Check("IS_PMU_CLEAR(value) accepted", (IS_PMU_CLEAR(all_clears[i]) == 1U));
    }
    Check("IS_PMU_CLEAR(0x8000) rejected", (IS_PMU_CLEAR(0x8000U) == 0U));
    Check("IS_PMU_CLEAR_MASK(one value) accepted",
          (IS_PMU_CLEAR_MASK(PMU_CLEAR_RTCWKF) == 1U));
    Check("IS_PMU_CLEAR_MASK(PMU_CLEAR_ALL) accepted",
          (IS_PMU_CLEAR_MASK(PMU_CLEAR_ALL) == 1U));
    Check("IS_PMU_CLEAR_MASK(0) rejected", (IS_PMU_CLEAR_MASK(0U) == 0U));
    Check("IS_PMU_CLEAR_MASK(reserved bit) rejected",
          (IS_PMU_CLEAR_MASK(0x8000U) == 0U));

    Check("IS_PMU_HVDTS(0) accepted", (IS_PMU_HVDTS(0U) == 1U));
    Check("IS_PMU_HVDTS(0x1F) accepted", (IS_PMU_HVDTS(0x1FU) == 1U));
    Check("IS_PMU_HVDTS(0x20) rejected", (IS_PMU_HVDTS(0x20U) == 0U));
    Check("IS_PMU_LVDTS(0) accepted", (IS_PMU_LVDTS(0U) == 1U));
    Check("IS_PMU_LVDTS(0x1F) accepted", (IS_PMU_LVDTS(0x1FU) == 1U));
    Check("IS_PMU_LVDTS(0x20) rejected", (IS_PMU_LVDTS(0x20U) == 0U));

    /* ==================================================================== *
     *  Group 2: the three tables of a wake-up source describe the same source
     * ==================================================================== */
    Section("Group 2: wake-up source / flag / clear table consistency");

    count = (uint32)(sizeof(wakeup_source) / sizeof(wakeup_source[0]));
    for (i = 0U; i < count; i++)
    {
        /* the WKEN enable bit and the WKFR clear bit are the same register bit
         * (bit 0 = IWDG, bit 3 = RTC, bit 4..13 = PH0..PH9) */
        Check("WKEN bit equals the WKFR clear bit", (wakeup_source[i] == wakeup_clear[i]));

        /* the flag selector carries the register selection (bits 6:5) plus the
         * bit position (bits 4:0), and the position must match the clear value */
        Check("flag selector encodes the clear bit position",
              ((wakeup_flag[i] & 0x1FU) == BitIndex(wakeup_clear[i])));

        /* the sources are listed in increasing bit order */
        if (i > 0U)
        {
            Check("source table is in increasing bit order",
                  (wakeup_clear[i] > wakeup_clear[i - 1U]));
        }
    }

    /* the all-masks are exactly the OR of their table (and the wake-up mask has
     * no bit for the FOCU flag, which is a status flag rather than a source) */
    expected = 0U;
    for (i = 0U; i < count; i++) { expected |= wakeup_source[i]; }
    Check("PMU_WKSOURCE_ALL is the OR of the source table",
          (PMU_WKSOURCE_ALL == expected));

    expected = 0U;
    for (i = 0U; i < (uint32)(sizeof(all_clears) / sizeof(all_clears[0])); i++)
    {
        expected |= all_clears[i];
    }
    Check("PMU_CLEAR_ALL is the OR of the clear table", (PMU_CLEAR_ALL == expected));

    /* PMU_CLEAR_ALL is a WKFR write mask and carries no register selector: the
     * PMU_FLAG_* family encodes the status register in bits[6:5] (01 = LDOSR,
     * 10 = WKFR) while the clear family is a plain bit mask, and
     * HAL_PMU_ClearFlag() writes the WKFR register only. A ready flag of LDOSR
     * can therefore never be reached from a clear value - that is checked on
     * the register after the clear in Group 4 - and no bit above the
     * implemented WKFR bits is used (bit 12 / 13 / 14 are the PH8 / PH9 / FOCU
     * positions) */
    Check("PMU_CLEAR_ALL uses only the implemented WKFR bits",
          ((PMU_CLEAR_ALL & ~0x7FFFU) == 0U));

    /* ==================================================================== *
     *  Group 3: mask combinations
     * ==================================================================== */
    Section("Group 3: mask combinations");

    combination = (HAL_PMU_WKSOURCE_IWDG | HAL_PMU_WKSOURCE_PH2 | HAL_PMU_WKSOURCE_PH9);
    Check("combination of three sources accepted",
          (HAL_PMU_WakeUpSourceCmd(&hpmu_dev, combination, ENABLE) == HAL_OK));
    printf("WKEN = 0x%X (requested 0x%X)\r\n",
           PRINT_U32(hpmu_dev.Instance->WKEN), PRINT_U32(combination));
    Check("WKEN holds exactly the requested combination",
          ((hpmu_dev.Instance->WKEN & PMU_WKSOURCE_ALL) == combination));
    Check("combination disabled again",
          (HAL_PMU_WakeUpSourceCmd(&hpmu_dev, combination, DISABLE) == HAL_OK));
    Check("WKEN cleared after the combination", (hpmu_dev.Instance->WKEN == 0U));

    combination = (HAL_PMU_WKSOURCE_RTC | HAL_PMU_WKSOURCE_PH5);
    Check("second combination accepted",
          (HAL_PMU_WakeUpSourceCmd(&hpmu_dev, combination, ENABLE) == HAL_OK));
    Check("WKEN holds exactly the second combination",
          ((hpmu_dev.Instance->WKEN & PMU_WKSOURCE_ALL) == combination));
    Check("second combination disabled again",
          (HAL_PMU_WakeUpSourceCmd(&hpmu_dev, combination, DISABLE) == HAL_OK));
    Check("WKEN cleared after the second combination",
          (hpmu_dev.Instance->WKEN == 0U));

    /* the two reserved bits are refused even when they come with a valid bit */
    Check("reserved bit refused inside a combination",
          (HAL_PMU_WakeUpSourceCmd(&hpmu_dev,
                                   (HAL_PMU_WKSOURCE_PH2 | 0x8000U), ENABLE) == HAL_ERROR));
    Check("WKEN untouched by the refused combination",
          (hpmu_dev.Instance->WKEN == 0U));

    /* ==================================================================== *
     *  Group 4: flag query and clear with single values and with masks
     * ==================================================================== */
    Section("Group 4: flag query / clear (single value and mask)");

    /* All the wake-up flags are cleared first, so that the queries below are
     * compared against a known register content. Anything the hardware has
     * latched (a wake-up left over by a previous run) is reported as well. */
    printf("WKFR before the queries = 0x%X\r\n", PRINT_U32(hpmu_dev.Instance->WKFR));
    ldosr = hpmu_dev.Instance->LDOSR;
    Check("all wake-up flags cleared", (HAL_PMU_ClearFlag(&hpmu_dev, PMU_CLEAR_ALL) == HAL_OK));
    Check("WKFR is 0 after PMU_CLEAR_ALL", (hpmu_dev.Instance->WKFR == 0U));
    /* the ready flags live in LDOSR and have no clear value: clearing every
     * wake-up flag must leave that register untouched */
    Check("ready flags (LDOSR) untouched by the clear",
          (hpmu_dev.Instance->LDOSR == ldosr));

    count = (uint32)(sizeof(all_clears) / sizeof(all_clears[0]));
    for (i = 0U; i < count; i++)
    {
        /* a single flag query and a single value clear both accept the value */
        Check("single flag query accepted",
              (HAL_PMU_GetWakeUpFlag(&hpmu_dev, all_clears[i]) == 0U));
        Check("single value clear accepted",
              (HAL_PMU_ClearFlag(&hpmu_dev, all_clears[i]) == HAL_OK));
    }
    Check("WKFR still 0 after the single clears", (hpmu_dev.Instance->WKFR == 0U));

    /* the mask query answers whether at least one of the selected flags is set */
    combination = (PMU_CLEAR_RTCWKF | PMU_CLEAR_PH5WKF | PMU_CLEAR_FOCURF);
    Check("mask query on a combination reads 0", (HAL_PMU_GetWakeUpFlag(&hpmu_dev, combination) == 0U));
    Check("mask query on PMU_CLEAR_ALL reads 0",
          (HAL_PMU_GetWakeUpFlag(&hpmu_dev, PMU_CLEAR_ALL) == 0U));
    Check("mask clear of a combination accepted",
          (HAL_PMU_ClearFlag(&hpmu_dev, combination) == HAL_OK));

    /* the four LDO ready flags are status flags of the ready register: they have
     * no clear value, so a clear request that only asks for them must be
     * refused (the reserved bits of WKFR are the only other refused values) */
    Check("clear of a value outside the clearable set refused",
          (HAL_PMU_ClearFlag(&hpmu_dev, 0x8000U) == HAL_ERROR));

    /* ==================================================================== *
     *  Group 5: LDO ready flags against a direct read of the status register
     * ==================================================================== */
    Section("Group 5: LDO ready flags");

    Check("3.3V LDO enabled", (HAL_PMU_LDO3v3Cmd(&hpmu_dev, ENABLE) == HAL_OK));
    Check("core 1.2V rail kept at its current value",
          (HAL_PMU_LDO1v2VOLSca(&hpmu_dev, TEST_VO12_SAFE) == HAL_OK));
    Check("3.3V rail kept at its safe value",
          (HAL_PMU_LDO3v3VOLSca(&hpmu_dev, TEST_VO33_SAFE) == HAL_OK));
    delay_ms(TEST_RAIL_SETTLE_MS);

    ldosr = hpmu_dev.Instance->LDOSR;
    printf("LDOCR = 0x%08X, LDOSR = 0x%08X\r\n",
           PRINT_U32(hpmu_dev.Instance->LDOCR), PRINT_U32(ldosr));
    printf("ready : 3V3 = %u, 2V5 = %u, 1V2 = %u, 1V2B = %u\r\n",
           PRINT_U32(HAL_PMU_GetFlagStatus(&hpmu_dev, PMU_FLAG_3V3LDORDY)),
           PRINT_U32(HAL_PMU_GetFlagStatus(&hpmu_dev, PMU_FLAG_2V5LDORDY)),
           PRINT_U32(HAL_PMU_GetFlagStatus(&hpmu_dev, PMU_FLAG_1V2LDORDY)),
           PRINT_U32(HAL_PMU_GetFlagStatus(&hpmu_dev, PMU_FLAG_1V2BLDORDY)));

    /* the flag query selects the ready register and the bit position: it must
     * agree with the register read, whatever the hardware reports */
    Check("3V3 ready flag matches LDOSR bit 0",
          (HAL_PMU_GetFlagStatus(&hpmu_dev, PMU_FLAG_3V3LDORDY) == ((ldosr & 0x1U) ? 1U : 0U)));
    Check("2V5 ready flag matches LDOSR bit 1",
          (HAL_PMU_GetFlagStatus(&hpmu_dev, PMU_FLAG_2V5LDORDY) == ((ldosr & 0x2U) ? 1U : 0U)));
    Check("1V2 ready flag matches LDOSR bit 2",
          (HAL_PMU_GetFlagStatus(&hpmu_dev, PMU_FLAG_1V2LDORDY) == ((ldosr & 0x4U) ? 1U : 0U)));
    Check("1V2 backup ready flag matches LDOSR bit 3",
          (HAL_PMU_GetFlagStatus(&hpmu_dev, PMU_FLAG_1V2BLDORDY) == ((ldosr & 0x8U) ? 1U : 0U)));

    /* the core rail and the IO rail are used by the running system (the core
     * executes from them and the console is driven by the IO rail), so their
     * ready flags must be set once the rails have settled */
    Check("3.3V rail reports ready",
          (HAL_PMU_GetFlagStatus(&hpmu_dev, PMU_FLAG_3V3LDORDY) == 1U));
    Check("core 1.2V rail reports ready",
          (HAL_PMU_GetFlagStatus(&hpmu_dev, PMU_FLAG_1V2LDORDY) == 1U));

    /* ==================================================================== *
     *  Group 6: constant tables and the module version
     * ==================================================================== */
    Section("Group 6: constant tables / module version");

    Check("VO33 first entry is the lowest voltage", (PMU_VO33_2V90 == 0U));
    Check("VO33 default entry is the 9th step", (PMU_VO33_3V30 == 0x8U));
    Check("VO33 last entry is the 16th step", (PMU_VO33_3V65 == 0xFU));
    Check("VO25 first entry is the lowest voltage", (PMU_VO25_2V18 == 0U));
    Check("VO25 default entry is the 9th step", (PMU_VO25_2V50 == 0x8U));
    Check("VO25 last entry is the 16th step", (PMU_VO25_2V78 == 0xFU));

    Check("VO12 first entry is the lowest voltage", (PMU_VO12_1V04 == 0U));
    Check("VO12 default entry is the 9th step", (PMU_VO12_1V20 == 0x8U));
    Check("VO12 last entry is the 16th step", (PMU_VO12_1V34 == 0xFU));
    Check("VREF12 first entry is the lowest voltage", (PMU_VREF12_1V04 == 0U));
    Check("VREF12 default entry is the 9th step", (PMU_VREF12_1V20 == 0x8U));
    Check("VREF12 last entry is the 16th step", (PMU_VREF12_1V34 == 0xFU));

    Check("HVDTS first entry is the lowest threshold", (PMU_HVDTS_2V4 == 0U));
    Check("HVDTS default entry is the last step", (PMU_HVDTS_5V5 == 0x1FU));
    Check("LVDTS first entry is the lowest threshold", (PMU_LVDTS_2V4 == 0U));
    Check("LVDTS default entry is the 6th step", (PMU_LVDTS_2V9 == 0x5U));
    Check("LVDTS last entry is the 32nd step", (PMU_LVDTS_5V5 == 0x1FU));

    printf("module version = 0x%08X\r\n", PRINT_U32(__HAL_PMU_MODULE_VERSION));
    Check("module version = 0x0100", (__HAL_PMU_MODULE_VERSION == 0x0100U));
    Check("error code NONE = 0", (HAL_PMU_ERROR_NONE == 0U));
    Check("error code INVALID_PARAM = 1", (HAL_PMU_ERROR_INVALID_PARAM == 1U));

    /* ==================================================================== *
     *  Final report
     * ==================================================================== */
    Check("every wake-up source is disabled at the end",
          (hpmu_dev.Instance->WKEN == 0U));
    Check("every wake-up flag is cleared at the end",
          (hpmu_dev.Instance->WKFR == 0U));

    printf("\r\nfinal : checks = %u, failures = %u\r\n",
           PRINT_U32(checks), PRINT_U32(failures));

    while (1)
    {
        printf("WKEN = 0x%X | WKFR = 0x%X | LDOSR = 0x%X | checks = %u | summary : failures = %u\r\n",
               PRINT_U32(hpmu_dev.Instance->WKEN), PRINT_U32(hpmu_dev.Instance->WKFR),
               PRINT_U32(hpmu_dev.Instance->LDOSR),
               PRINT_U32(checks), PRINT_U32(failures));
        delay_ms(TEST_POLL_MS);
    }
}

/**
 * @brief  Position of the single bit set in a one-hot value.
 * @param  Value: one-hot value (a power of two).
 * @retval uint32: bit index (0 based), or 0xFFFFFFFF when the value is not a
 *         power of two.
 */
static uint32 BitIndex(uint32 Value)
{
    uint32 index;

    if ((Value == 0U) || ((Value & (Value - 1U)) != 0U))
    {
        return 0xFFFFFFFFU;
    }

    index = 0U;
    while (Value > 1U)
    {
        Value >>= 1U;
        index++;
    }

    return index;
}

/**
 * @brief  Print the header of a test group.
 * @param  name: group name.
 * @retval None
 */
static void Section(const char *name)
{
    printf("\r\n-- %s --\r\n", name);
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    checks++;

    if (condition == 0U)
    {
        failures++;
    }
    printf("%-52s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Configure the system clock tree using the HAL SMU driver.
 * @note   Clock tree shared by every integration test suite of this library:
 *         OSC 20 MHz as the PLL source, PLLDivR = 0x04 / PLLDivN = 0x14 /
 *         PLLDivF = 0xB4 / PLLDivQ = 0x01 -> 45 MHz core clock, then
 *         AXI4Bus3 = /2, APBBus0 = /2, APBBus1 = /2 and CANX2 = /8.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Bus dividers, then the system clock source is the PLL as requested */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
