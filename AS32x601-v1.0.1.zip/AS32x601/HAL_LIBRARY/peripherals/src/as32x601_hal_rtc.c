/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):    Xiamen Guoke Anxin Technology Co., LTD
 * FileName:         as32x601_hal_rtc.c
 * Author:           ANSILIC APPLICATION GROUP
 * Version:          V1.6
 * Date:             2026/11/04
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/11/04     1.6     clear CR before TR / DR in
 *                                                       HAL_RTC_DeInit(): the device ignores writes
 *                                                       to the time and date registers while the
 *                                                       calendar is enabled, so the six register
 *                                                       reset of the de-initialization only took
 *                                                       effect for CR / ALRMTR / ALRMDR / WUCR
 *     ANSILIC APPLICATION GROUP  2026/11/02     1.5     close the double version comparison findings: make the header
 *                                                       self-contained (as32x601_hal.h), export RTC_HandleIsValid()
 *                                                       next to the other shared internal processes so that every
 *                                                       interface touching a register runs the same handle check,
 *                                                       state gate and lock sequence, add the metafield check of
 *                                                       the configuration structure and run time validation with
 *                                                       HAL_RTC_ERROR_INVALID_PARAM (including the per digit BCD
 *                                                       check), clear the alarm flag only after the comparison
 *                                                       enables have been cleared (device prerequisite) in
 *                                                       HAL_RTC_SetAlarm_IT() and in the interrupt entry, stop the
 *                                                       interrupt entry from writing the task side State, protect
 *                                                       the read interfaces with the same gate and lock, and
 *                                                       assemble the control register instead of a read modify
 *                                                       write so that a flag asserted by the hardware around the
 *                                                       update is kept
 *     ANSILIC APPLICATION GROUP  2026/08/24     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.1     add the module guard (HAL_RTC_MODULE_ENABLED) around the whole implementation
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.2     put the as32x601_hal.h include first (module switch from the conf) before the module headers
 *     ANSILIC APPLICATION GROUP  2026/09/17     1.3     align the resource lock and the RTOS support with the architecture specification (sections 13 and 21):
 *                                                       replace the public lock macro with the shared
 *                                                       helpers RTC_LockHandle (Timeout parameter and
 *                                                       NULL mutex guard, RTOS-11) / RTC_UnlockHandle
 *                                                       and lock every state changing API (init /
 *                                                       de-init / time / date / alarm / alarm IT /
 *                                                       command); gate the register accessing APIs with
 *                                                       RTC_CheckState (ARCH-CONST-09); run the MSP
 *                                                       callbacks outside the locked region (LOCK-06)
 *                                                       with the MSP init on the first initialization
 *                                                       only (MSP-04); factor the alarm register
 *                                                       sequence into the private RTC_SetAlarmConfig so
 *                                                       that HAL_RTC_SetAlarm_IT no longer calls the
 *                                                       public HAL_RTC_SetAlarm while the lock is held
 *                                                       (LOCK-05); clear the error code on every start
 *                                                       operation (ARCH-CONST-10 / ERR-03)
 *     ANSILIC APPLICATION GROUP  2026/09/21     1.4     document the command interface without referring to an external
 *                                                       implementation
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Real Time Clock (RTC)
 *                  peripheral:
 *                  - Initialization and de-initialization functions
 *                    (HAL_RTC_Init / HAL_RTC_DeInit + weak MSP hooks);
 *                  - RTC Time and Date functions (HAL_RTC_SetTime /
 *                    HAL_RTC_GetTime / HAL_RTC_SetDate / HAL_RTC_GetDate +
 *                    *StructInit);
 *                  - RTC Alarm functions (HAL_RTC_SetAlarm /
 *                    HAL_RTC_SetAlarm_IT / HAL_RTC_GetAlarm +
 *                    HAL_RTC_AlarmStructInit, interrupt mode with
 *                    HAL_RTC_AlarmIRQHandler and the weak
 *                    HAL_RTC_AlarmEventCallback callback);
 *                  - Peripheral Control functions (HAL_RTC_Cmd);
 *                  - Peripheral State functions (HAL_RTC_GetState).
 *                  The chip-specific wake-up feature is provided by
 *                  this driver (HAL_RTC_WakeUpCmd).
 *                  The RTC has no SMU clock gate (the clock is always on),
 *                  so HAL_RTC_MspInit() is empty by default: it can be
 *                  overridden by the user to enable the RTC_IRQn PLIC line
 *                  when the alarm interrupt is used.
 */
#include "as32x601_hal.h"           /* module switch from as32x601_hal_conf.h */
#include "as32x601_hal_rtc.h"       /* RTC HAL API and register macros         */

/* The HAL_RTC_MODULE_ENABLED switch is provided by the user configuration
 * file (as32x601_hal_conf.h, included above through as32x601_hal.h): the
 * whole implementation is compiled only while the module is enabled. */
#ifdef HAL_RTC_MODULE_ENABLED

/* Fields of the control register owned by this module. The two bits between DIV
   and IE (bit 27 and bit 28) are reserved: the device layer does not define
   them, they are not part of any documented feature of this module and they must
   keep their reset value, so every control write is masked to these fields. */
#define RTC_CR_OWNED_MASK        ((uint32)(RTC_CR_EN | RTC_CR_ALRMT | RTC_CR_IE | RTC_CR_DIV))

/* Comparison enable bits of the two alarm registers: the fields that decide
   whether an alarm field takes part in the match (a set bit means compared). */
#define RTC_ALARMTIME_COMP_MASK  ((uint32)(RTC_ALRMTR_TOSCE | RTC_ALRMTR_SCE | \
                                           RTC_ALRMTR_MCE | RTC_ALRMTR_HCE |   \
                                           RTC_ALRMTR_WDCE))
#define RTC_ALARMDATE_COMP_MASK  ((uint32)(RTC_ALRMDR_DCE | RTC_ALRMDR_MCE | \
                                           RTC_ALRMDR_YCE | RTC_ALRMDR_CCE))

/* Private functions prototypes ---------------------------------------------*/
static uint8 RTC_ByteToBcd2(uint8 Value);
static uint8 RTC_Bcd2ToByte(uint8 Value);
static uint32 RTC_IsValidBcdByte(uint8 Value);
static uint32 RTC_TimeIsValid(const RTC_TimeTypeDef *sTime, uint32 Format);
static uint32 RTC_DateIsValid(const RTC_DateTypeDef *sDate, uint32 Format);
static uint32 RTC_AlarmIsValid(const RTC_AlarmTypeDef *sAlarm, uint32 Format);
static void RTC_ModifyControl(RTC_HandleTypeDef *hrtc, uint32 clrMask, uint32 setMask);
static void RTC_SetAlarmConfig(RTC_HandleTypeDef *hrtc, const RTC_AlarmTypeDef *sAlarm, uint32 Format,
                              uint32 EnableIt);

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Check the RTC handle and its peripheral instance. (Shared)
 * @note   First check of every interface of this driver (null pointer plus the
 *         model instance set), so the validation strength cannot differ between
 *         interfaces. Not static: declared in the shared internal functions
 *         section of the header, so the application and a test bench reuse the
 *         same check (the same pattern as ADC_HandleIsValid()).
 * @param  hrtc: pointer to a RTC_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
uint32 RTC_HandleIsValid(RTC_HandleTypeDef *hrtc)
{
    return ((hrtc != NULL_PTR) && (IS_RTC_ALL_INSTANCE(hrtc->Instance) != 0U)) ? 1U : 0U;
}

/**
 * @brief  Check the handle state before a register access. (Tier 3)
 * @note   ARCH-CONST-09: a handle that is busy with another operation rejects
 *         the call with HAL_BUSY, and a handle that was never initialized
 *         rejects it with HAL_ERROR (HAL_RTC_Init() is required first). The
 *         timeout / error states are recoverable, a new operation may be
 *         called directly.
 * @note   Not static: declared in the shared internal functions section of
 *         this header, so the application may reuse the same check.
 * @param  hrtc: pointer to a RTC_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef RTC_CheckState(RTC_HandleTypeDef *hrtc)
{
    if (hrtc->State == HAL_RTC_STATE_BUSY)
    {
        return HAL_BUSY;
    }

    if (hrtc->State == HAL_RTC_STATE_RESET)
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag). (Tier 3)
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_RTC_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the acquisition is bounded by the Timeout parameter;
 *         HAL_MAX_DELAY waits forever.
 * @note   Not static: declared in the shared internal functions section of
 *         this header, so the application may reuse the same helper.
 * @param  hrtc: pointer to a RTC_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS, wait expired) /
 *         HAL_ERROR (RTOS, mutex not created) / HAL_BUSY (bare metal, the
 *         handle is already locked).
 */
HAL_StatusTypeDef RTC_LockHandle(RTC_HandleTypeDef *hrtc, uint32 Timeout)
{
#if (USE_RTOS == 1)
    if (hrtc->LockMutex == NULL_PTR)
    {
        /* The porting layer did not create the mutex (e.g. HAL_RTC_MspInit()
         * was not overridden): report it instead of calling the RTOS with a
         * NULL handle */
        return HAL_ERROR;
    }

    return HAL_MutexAcquire(hrtc->LockMutex, Timeout);
#else
    /* Prevent unused argument compilation warning: the bare-metal lock flag
     * either succeeds immediately or reports HAL_BUSY, it never waits */
    UNUSED(Timeout);

    if (hrtc->Lock == HAL_LOCKED)
    {
        return HAL_BUSY;
    }
    hrtc->Lock = HAL_LOCKED;
    return HAL_OK;
#endif /* USE_RTOS */
}

/**
 * @brief  Unlock the handle. (Tier 3)
 * @param  hrtc: pointer to a RTC_HandleTypeDef structure.
 * @retval None
 */
void RTC_UnlockHandle(RTC_HandleTypeDef *hrtc)
{
#if (USE_RTOS == 1)
    (void)HAL_MutexRelease(hrtc->LockMutex);
#else
    hrtc->Lock = HAL_UNLOCKED;
#endif /* USE_RTOS */
}
/**
 * @brief  Report whether a byte is a legal two-digit BCD value (both nibbles in
 *         0..9). (Tier 3)
 * @note   Used by the run time validation so that an illegal BCD digit is
 *         rejected instead of being converted to a different decimal value.
 * @param  Value: candidate BCD byte.
 * @retval uint32: 1 when both nibbles are decimal digits, 0 otherwise.
 */
static uint32 RTC_IsValidBcdByte(uint8 Value)
{
    uint32 low = (uint32)Value & 0x0FU;
    uint32 high = ((uint32)Value >> 4) & 0x0FU;

    return ((low <= 9U) && (high <= 9U)) ? 1U : 0U;
}

/**
 * @brief  Run time validation of a time structure. (Tier 3)
 * @note   The format, the hour / minute / second fields and the tenth of a
 *         second field are checked; in RTC_FORMAT_BCD every decimal digit is
 *         checked to be 0..9 before the value is converted. assert_param()
 *         reports the same conditions in a full assertion build.
 * @param  sTime:  pointer to the candidate time structure (not NULL).
 * @param  Format: RTC_FORMAT_BIN or RTC_FORMAT_BCD.
 * @retval uint32: 1 when the structure is usable, 0 otherwise.
 */
static uint32 RTC_TimeIsValid(const RTC_TimeTypeDef *sTime, uint32 Format)
{
    uint32 hours = (uint32)sTime->RTC_Hours;
    uint32 minutes = (uint32)sTime->RTC_Minutes;
    uint32 seconds = (uint32)sTime->RTC_Seconds;

    if (IS_RTC_FORMAT(Format) == 0U)
    {
        return 0U;
    }

    if (Format == RTC_FORMAT_BCD)
    {
        if ((RTC_IsValidBcdByte(sTime->RTC_Hours) == 0U) ||
            (RTC_IsValidBcdByte(sTime->RTC_Minutes) == 0U) ||
            (RTC_IsValidBcdByte(sTime->RTC_Seconds) == 0U))
        {
            return 0U;
        }
        hours = (uint32)RTC_Bcd2ToByte(sTime->RTC_Hours);
        minutes = (uint32)RTC_Bcd2ToByte(sTime->RTC_Minutes);
        seconds = (uint32)RTC_Bcd2ToByte(sTime->RTC_Seconds);
    }

    if ((hours > 23U) || (minutes > 59U) || (seconds > 59U))
    {
        return 0U;
    }

    /* The tenth of a second field is always binary (never BCD encoded) */
    return (IS_RTC_TENOFSECOND(sTime->RTC_TenthOfSecond) != 0U) ? 1U : 0U;
}

/**
 * @brief  Run time validation of a date structure. (Tier 3)
 * @note   The format, the weekday and the century / year / month / day fields
 *         are checked; in RTC_FORMAT_BCD every decimal digit is checked to be
 *         0..9 before the value is converted. The weekday is an enumerated
 *         value and does not switch with the format. The driver does not check
 *         the month / day combination, leap years or the consistency between
 *         the weekday and the date.
 * @param  sDate:  pointer to the candidate date structure (not NULL).
 * @param  Format: RTC_FORMAT_BIN or RTC_FORMAT_BCD.
 * @retval uint32: 1 when the structure is usable, 0 otherwise.
 */
static uint32 RTC_DateIsValid(const RTC_DateTypeDef *sDate, uint32 Format)
{
    uint32 century = (uint32)sDate->RTC_Century;
    uint32 year = (uint32)sDate->RTC_Year;
    uint32 month = (uint32)sDate->RTC_Month;
    uint32 day = (uint32)sDate->RTC_Date;

    if (IS_RTC_FORMAT(Format) == 0U)
    {
        return 0U;
    }

    if (IS_RTC_WEEKDAY(sDate->RTC_WeekDay) == 0U)
    {
        return 0U;
    }

    if (Format == RTC_FORMAT_BCD)
    {
        if ((RTC_IsValidBcdByte(sDate->RTC_Century) == 0U) ||
            (RTC_IsValidBcdByte(sDate->RTC_Year) == 0U) ||
            (RTC_IsValidBcdByte(sDate->RTC_Month) == 0U) ||
            (RTC_IsValidBcdByte(sDate->RTC_Date) == 0U))
        {
            return 0U;
        }
        century = (uint32)RTC_Bcd2ToByte(sDate->RTC_Century);
        year = (uint32)RTC_Bcd2ToByte(sDate->RTC_Year);
        month = (uint32)RTC_Bcd2ToByte(sDate->RTC_Month);
        day = (uint32)RTC_Bcd2ToByte(sDate->RTC_Date);
    }

    if ((century > 99U) || (year > 99U))
    {
        return 0U;
    }
    if ((IS_RTC_MONTH(month) == 0U) || (IS_RTC_DATE(day) == 0U))
    {
        return 0U;
    }

    return 1U;
}

/**
 * @brief  Run time validation of an alarm structure. (Tier 3)
 * @note   The alarm time and the alarm date are validated with the same
 *         functions as the calendar, and the two comparison enable masks must
 *         hold only their own bits (an all-zero mask is legal: it makes every
 *         field a wildcard, which is a continuous-match configuration).
 * @param  sAlarm: pointer to the candidate alarm structure (not NULL).
 * @param  Format: RTC_FORMAT_BIN or RTC_FORMAT_BCD.
 * @retval uint32: 1 when the structure is usable, 0 otherwise.
 */
static uint32 RTC_AlarmIsValid(const RTC_AlarmTypeDef *sAlarm, uint32 Format)
{
    if ((RTC_TimeIsValid(&sAlarm->RTC_AlarmTime, Format) == 0U) ||
        (RTC_DateIsValid(&sAlarm->RTC_AlarmDate, Format) == 0U))
    {
        return 0U;
    }
    if (IS_RTC_ALARMTIME(sAlarm->RTC_AlarmTimeCompEn) == 0U)
    {
        return 0U;
    }
    if (IS_RTC_ALARMDATE(sAlarm->RTC_AlarmDataCompEn) == 0U)
    {
        return 0U;
    }

    return 1U;
}

/**
 * @brief  Update the fields of the control register owned by this module.
 *         (Tier 3)
 * @note   The register is assembled and written once (no read modify write
 *         cycle through the caller), and the write is masked to the owned
 *         fields so the reserved bits keep their reset value.
 * @note   CR.ALRMT is a plain read/write flag bit of this device: it is set by
 *         the hardware when the configured alarm matches and by software when a
 *         1 is written to it, and it is cleared by writing 0. The bit is
 *         therefore written back with the value that was read, which keeps a
 *         flag already asserted by the hardware and never asserts one.
 * @param  hrtc:    pointer to a RTC_HandleTypeDef structure.
 * @param  clrMask: fields to clear.
 * @param  setMask: fields to set.
 * @retval None
 */
static void RTC_ModifyControl(RTC_HandleTypeDef *hrtc, uint32 clrMask, uint32 setMask)
{
    uint32 state = __disable_irq_and_save();
    uint32 control = hrtc->Instance->CR;

    control &= ~clrMask;
    control |= setMask;
    hrtc->Instance->CR = control & RTC_CR_OWNED_MASK;

    __restore_irq(state);
}

/**
 * @brief  Program the alarm time and date registers. (Tier 3)
 * @note   Shared by HAL_RTC_SetAlarm() and HAL_RTC_SetAlarm_IT(). It performs
 *         the device sequence without taking the handle lock: the caller shall
 *         hold it. The sequence is
 *         1. mask the alarm interrupt (the previous interrupt enable is saved),
 *         2. clear every comparison enable (the device prerequisite for
 *            clearing the alarm flag),
 *         3. write the match fields of both alarm registers,
 *         4. optionally clear the historical alarm flag (only reachable while
 *            the comparison enables are still clear),
 *         5. commit the new comparison enables,
 *         6. restore the previous interrupt enable, or leave it enabled for the
 *            interrupt form.
 *         The whole sequence runs inside one short critical section so that no
 *         alarm event can be observed half configured.
 * @param  hrtc:     pointer to a RTC_HandleTypeDef structure.
 * @param  sAlarm:   pointer to a RTC_AlarmTypeDef structure.
 * @param  Format:   RTC_FORMAT_BIN or RTC_FORMAT_BCD.
 * @param  EnableIt: 0 keeps the previous interrupt enable and the historical
 *                   flag, 1 clears the historical flag and enables the
 *                   interrupt.
 * @retval None
 */
static void RTC_SetAlarmConfig(RTC_HandleTypeDef *hrtc, const RTC_AlarmTypeDef *sAlarm,
                               uint32 Format, uint32 EnableIt)
{
    uint32 tmpreg = 0U;
    uint32 previousInte = 0U;
    uint32 state = 0U;

    state = __disable_irq_and_save();

    /* 1. Mask the alarm interrupt for the whole reconfiguration */
    previousInte = ((hrtc->Instance->CR & RTC_CR_IE) != 0U) ? 1U : 0U;
    CLEAR_BIT(hrtc->Instance->CR, RTC_CR_IE);

    /* 2. Clear every comparison enable: the match condition must be inactive
     *    before the alarm flag may be cleared */
    CLEAR_BIT(hrtc->Instance->ALRMTR, RTC_ALARMTIME_COMP_MASK);
    CLEAR_BIT(hrtc->Instance->ALRMDR, RTC_ALARMDATE_COMP_MASK);

    /* 3a. Time match fields (the comparison enable bits stay clear here) */
    tmpreg = hrtc->Instance->ALRMTR;
    tmpreg &= ~((uint32)(RTC_ALRMTR_TOS | RTC_ALRMTR_SU | RTC_ALRMTR_ST |
                         RTC_ALRMTR_MNU | RTC_ALRMTR_MNT | RTC_ALRMTR_HU |
                         RTC_ALRMTR_HT | RTC_ALRMTR_WDU));
    tmpreg |= ((uint32)(sAlarm->RTC_AlarmDate.RTC_WeekDay) << RTC_ALRMTR_WDU_Pos);

    if (Format == RTC_FORMAT_BIN)
    {
        tmpreg |= ((uint32)RTC_ByteToBcd2(sAlarm->RTC_AlarmTime.RTC_Hours) << RTC_ALRMTR_HU_Pos);
        tmpreg |= ((uint32)RTC_ByteToBcd2(sAlarm->RTC_AlarmTime.RTC_Minutes) << RTC_ALRMTR_MNU_Pos);
        tmpreg |= ((uint32)RTC_ByteToBcd2(sAlarm->RTC_AlarmTime.RTC_Seconds) << RTC_ALRMTR_SU_Pos);
    }
    else
    {
        tmpreg |= ((uint32)(sAlarm->RTC_AlarmTime.RTC_Hours) << RTC_ALRMTR_HU_Pos);
        tmpreg |= ((uint32)(sAlarm->RTC_AlarmTime.RTC_Minutes) << RTC_ALRMTR_MNU_Pos);
        tmpreg |= ((uint32)(sAlarm->RTC_AlarmTime.RTC_Seconds) << RTC_ALRMTR_SU_Pos);
    }

    /* The tenth of a second field is always binary (never BCD encoded) */
    tmpreg |= ((uint32)(sAlarm->RTC_AlarmTime.RTC_TenthOfSecond) << RTC_ALRMTR_TOS_Pos);
    hrtc->Instance->ALRMTR = tmpreg;

    /* 3b. Date match fields */
    tmpreg = hrtc->Instance->ALRMDR;
    tmpreg &= ~((uint32)(RTC_ALRMDR_DU | RTC_ALRMDR_DT | RTC_ALRMDR_MU |
                         RTC_ALRMDR_MT | RTC_ALRMDR_YU | RTC_ALRMDR_YT |
                         RTC_ALRMDR_CU | RTC_ALRMDR_CT));

    if (Format == RTC_FORMAT_BIN)
    {
        tmpreg |= ((uint32)RTC_ByteToBcd2(sAlarm->RTC_AlarmDate.RTC_Century) << RTC_ALRMDR_CU_Pos);
        tmpreg |= ((uint32)RTC_ByteToBcd2(sAlarm->RTC_AlarmDate.RTC_Year) << RTC_ALRMDR_YU_Pos);
        tmpreg |= ((uint32)RTC_ByteToBcd2(sAlarm->RTC_AlarmDate.RTC_Month) << RTC_ALRMDR_MU_Pos);
        tmpreg |= ((uint32)RTC_ByteToBcd2(sAlarm->RTC_AlarmDate.RTC_Date) << RTC_ALRMDR_DU_Pos);
    }
    else
    {
        tmpreg |= ((uint32)(sAlarm->RTC_AlarmDate.RTC_Century) << RTC_ALRMDR_CU_Pos);
        tmpreg |= ((uint32)(sAlarm->RTC_AlarmDate.RTC_Year) << RTC_ALRMDR_YU_Pos);
        tmpreg |= ((uint32)(sAlarm->RTC_AlarmDate.RTC_Month) << RTC_ALRMDR_MU_Pos);
        tmpreg |= ((uint32)(sAlarm->RTC_AlarmDate.RTC_Date) << RTC_ALRMDR_DU_Pos);
    }
    hrtc->Instance->ALRMDR = tmpreg;

    /* 4. Clear the historical alarm flag, still with every comparison disabled */
    if (EnableIt != 0U)
    {
        CLEAR_BIT(hrtc->Instance->CR, RTC_CR_ALRMT);
    }

    /* 5. Commit the new comparison enables */
    SET_BIT(hrtc->Instance->ALRMTR, ((uint32)(sAlarm->RTC_AlarmTimeCompEn)) & RTC_ALARMTIME_COMP_MASK);
    SET_BIT(hrtc->Instance->ALRMDR, ((uint32)(sAlarm->RTC_AlarmDataCompEn)) & RTC_ALARMDATE_COMP_MASK);

    /* 6. Restore the previous interrupt enable, or enable it for the IT form */
    if ((EnableIt != 0U) || (previousInte != 0U))
    {
        SET_BIT(hrtc->Instance->CR, RTC_CR_IE);
    }

    __restore_irq(state);
}

/* Exported functions ---------------------------------------------------------*/

/** @defgroup RTC_Exported_Functions RTC Exported Functions
  * @{
  */

/** @defgroup RTC_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Initialize the RTC peripheral (clock divider coefficient). (NON-BLOCKING)
 * @note   The RTC is not enabled by this function: call HAL_RTC_Cmd() with
 *         ENABLE to start the calendar.
 * @note   Run time validation before the lock, the MSP callback and any register
 *         access: the configuration structure metafields (IS_RTC_INIT_STRUCT_OK)
 *         and the divider width are checked and a rejected structure is reported
 *         with HAL_ERROR and HAL_RTC_ERROR_INVALID_PARAM, leaving the handle and
 *         the peripheral untouched.
 * @note   The low level initialization callback runs only on the first call
 *         (while the handle is in the reset state) and before the handle is
 *         locked (architecture rules MSP-04 and LOCK-06), hence an override
 *         may create an RTOS mutex and call other HAL APIs.
 * @param  hrtc: pointer to a RTC_HandleTypeDef structure that contains
 *         the configuration information for RTC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY.
 */
HAL_StatusTypeDef HAL_RTC_Init(RTC_HandleTypeDef *hrtc)
{
    uint32 tmpreg = 0U;

    /* Check the RTC peripheral handle and instance */
    if (RTC_HandleIsValid(hrtc) == 0U)
    {
        return HAL_ERROR;
    }

    /* Run time validation of the configuration structure (architecture spec
     * section 22): the metafields and the divider width are checked before the
     * lock, the MSP callback and any register access */
    if ((IS_RTC_INIT_STRUCT_OK(&hrtc->Init) == 0U) || (IS_RTC_DIVISION(hrtc->Init.Division) == 0U))
    {
        hrtc->ErrorCode |= HAL_RTC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_RTC_DIVISION(hrtc->Init.Division));

    /* LOCK-06 / MSP-04: allocate the lock resource and run the low level
     * initialization BEFORE the handle is locked, and only on the first call
     * (avoid initializing the hardware twice; in an RTOS build the porting
     * layer may create the mutex in the callback, which is then guaranteed to
     * exist before the lock helper is used for the first time). */
    if (hrtc->State == HAL_RTC_STATE_RESET)
    {
        hrtc->Lock = HAL_UNLOCKED;

        /* Initialize RTC MSP */
        HAL_RTC_MspInit(hrtc);
    }

    /* Process locked */
    if (RTC_LockHandle(hrtc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state while configuring
     * (ARCH-CONST-10 / ERR-03 / STATE-03) */
    hrtc->ErrorCode = HAL_RTC_ERROR_NONE;
    hrtc->State = HAL_RTC_STATE_BUSY;

    /* Set RTC divider coefficient. The control register is assembled and written
     * once, masked to the fields owned by this module: the calendar enable, the
     * interrupt enable and the alarm flag keep their hardware value (the flag is
     * written with its neutral value, so a flag asserted by the hardware around
     * the update is not lost). */
    tmpreg = ((uint32)(hrtc->Init.Division) << RTC_CR_DIV_Pos) & (uint32)RTC_CR_DIV;
    RTC_ModifyControl(hrtc, RTC_CR_DIV, tmpreg);

    hrtc->State = HAL_RTC_STATE_READY;

    /* Release Lock */
    RTC_UnlockHandle(hrtc);

    return HAL_OK;
}

/**
 * @brief  De-initialize the RTC peripheral. (NON-BLOCKING)
 * @note   This function resets all RTC registers (TR / DR / ALRMTR /
 *         ALRMDR / CR / WUCR), including the divider coefficient: the
 *         HAL_RTC_Init() must be called again before reusing the RTC.
 * @note   Device prerequisite: the control register is cleared first, so the
 *         calendar is stopped before the time and date registers are written.
 *         While CR.EN is set the device ignores the writes to TR and DR, so
 *         clearing CR after them would leave the calendar of the previous
 *         session in place.
 * @note   The low level de-initialization callback runs after the handle lock
 *         has been released (LOCK-06), so an override may call other HAL APIs.
 * @param  hrtc: pointer to a RTC_HandleTypeDef structure that contains
 *         the configuration information for RTC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY.
 */
HAL_StatusTypeDef HAL_RTC_DeInit(RTC_HandleTypeDef *hrtc)
{
    /* Check the RTC peripheral handle and instance */
    if (RTC_HandleIsValid(hrtc) == 0U)
    {
        return HAL_ERROR;
    }

    /* Process locked */
    if (RTC_LockHandle(hrtc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state while tearing the handle
     * down (ARCH-CONST-10 / ERR-03 / STATE-03) */
    hrtc->ErrorCode = HAL_RTC_ERROR_NONE;
    hrtc->State = HAL_RTC_STATE_BUSY;

    /* Reset CR, TR, DR, ALRMTR, ALRMDR and WUCR registers. The control register
     * goes first: the calendar must be stopped before the time and date
     * registers are written, otherwise the device ignores those writes. */
    hrtc->Instance->CR = (uint32)0x00000000;
    hrtc->Instance->TR = (uint32)0x00000000;
    hrtc->Instance->DR = (uint32)0x00000000;
    hrtc->Instance->ALRMTR = (uint32)0x00000000;
    hrtc->Instance->ALRMDR = (uint32)0x00000000;
    hrtc->Instance->WUCR = (uint32)0x00000000;

    /* The handle goes back to the reset state so that a following
     * HAL_RTC_Init() runs the low level initialization again */
    hrtc->State = HAL_RTC_STATE_RESET;

    /* Release Lock */
    RTC_UnlockHandle(hrtc);

    /* LOCK-06 / ARCH-CONST-04: the low level de-initialization runs OUTSIDE
     * the locked region, as the architecture specification requires for the
     * MSP callbacks ("MspDeInit is called after the unlock"). The override may
     * call other HAL APIs (e.g. a GPIO / PLIC de-initialization), which is only
     * allowed while the handle lock is not held. */
    HAL_RTC_MspDeInit(hrtc);

    return HAL_OK;
}

/**
 * @brief  Initialize the RTC MSP.
 * @note   This function should not be modified: when the MSP initialization
 *         is needed, HAL_RTC_MspInit() should be implemented in the user file
 *         (e.g. enable the RTC_IRQn PLIC line for interrupt mode). The RTC
 *         has no SMU clock gate, so no clock enable is required.
 * @param  hrtc: pointer to a RTC_HandleTypeDef structure that contains the
 *         configuration information for RTC.
 * @retval None
 */
__weak void HAL_RTC_MspInit(RTC_HandleTypeDef *hrtc)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(hrtc);

    /* NOTE : This function should not be modified, when the callback is needed,
              the HAL_RTC_MspInit could be implemented in the user file
    */
}

/**
 * @brief  De-initialize the RTC MSP.
 * @note   This function should not be modified: when the MSP de-initialization
 *         is needed, HAL_RTC_MspDeInit() should be implemented in the user file
 *         (e.g. disable the RTC_IRQn PLIC line).
 * @param  hrtc: pointer to a RTC_HandleTypeDef structure that contains the
 *         configuration information for RTC.
 * @retval None
 */
__weak void HAL_RTC_MspDeInit(RTC_HandleTypeDef *hrtc)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(hrtc);

    /* NOTE : This function should not be modified, when the callback is needed,
              the HAL_RTC_MspDeInit could be implemented in the user file
    */
}

/**
  * @}
  */

/** @defgroup RTC_Exported_Functions_Group2 RTC Time and Date functions
  * @{
  */

/**
 * @brief  Set the RTC current time. (NON-BLOCKING)
 * @note   The chip RTC is 24-hour only: the RTC_Hours field must stay in the
 *         0-23 range whatever the Format.
 * @note   Run time validation of the format, the fields and every BCD digit
 *         before the lock: a rejected value is reported with HAL_ERROR and
 *         HAL_RTC_ERROR_INVALID_PARAM without touching the register or the
 *         state.
 * @note   Gated by the handle state (ARCH-CONST-09) and serialized by the
 *         handle lock; the error code is cleared on entry.
 * @param  hrtc:   pointer to a RTC_HandleTypeDef structure that contains
 *         the configuration information for RTC.
 * @param  sTime:  pointer to a RTC_TimeTypeDef structure that contains
 *         the time configuration information for the RTC.
 * @param  Format: specifies the format of the entered parameters.
 *         This parameter can be one of the following values:
 *           @arg RTC_FORMAT_BIN: Binary data format
 *           @arg RTC_FORMAT_BCD: BCD data format
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_RTC_SetTime(RTC_HandleTypeDef *hrtc, RTC_TimeTypeDef *sTime, uint32 Format)
{
    HAL_StatusTypeDef status = HAL_OK;
    uint32 tmpreg = 0U;

    if ((RTC_HandleIsValid(hrtc) == 0U) || (sTime == NULL_PTR))
    {
        return HAL_ERROR;
    }

    /* Check the parameters (a full assertion build reports the same conditions) */
    assert_param(IS_RTC_FORMAT(Format));
    assert_param(IS_RTC_TENOFSECOND(sTime->RTC_TenthOfSecond));

    if (Format == RTC_FORMAT_BIN)
    {
        assert_param(IS_RTC_HOURS(sTime->RTC_Hours));
        assert_param(IS_RTC_MINUTES(sTime->RTC_Minutes));
        assert_param(IS_RTC_SECONDS(sTime->RTC_Seconds));
    }
    else
    {
        assert_param(IS_RTC_HOURS(RTC_Bcd2ToByte(sTime->RTC_Hours)));
        assert_param(IS_RTC_MINUTES(RTC_Bcd2ToByte(sTime->RTC_Minutes)));
        assert_param(IS_RTC_SECONDS(RTC_Bcd2ToByte(sTime->RTC_Seconds)));
    }

    /* Run time validation: the format, the fields and every BCD digit. The call
     * is rejected before the lock, so neither the register nor the state change
     * (ARCH-CONST-10 / ERR-03: the error code reports the reason). */
    if (RTC_TimeIsValid(sTime, Format) == 0U)
    {
        hrtc->ErrorCode |= HAL_RTC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY,
     * HAL_BUSY) or when the handle has not been initialized (RESET, HAL_ERROR:
     * HAL_RTC_Init() is required first). The timeout / error states are
     * recoverable and accepted. */
    status = RTC_CheckState(hrtc);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (RTC_LockHandle(hrtc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state (ARCH-CONST-10 / ERR-03) */
    hrtc->ErrorCode = HAL_RTC_ERROR_NONE;
    hrtc->State = HAL_RTC_STATE_BUSY;

    /* Get the RTC_TR register */
    tmpreg = hrtc->Instance->TR;

    if (Format == RTC_FORMAT_BIN)
    {
        /* Set RTC hours */
        tmpreg &= ~((uint32)(RTC_TR_HT | RTC_TR_HU));
        tmpreg |= ((uint32)RTC_ByteToBcd2(sTime->RTC_Hours) << RTC_TR_HU_Pos);

        /* Set RTC minutes */
        tmpreg &= ~((uint32)(RTC_TR_MNT | RTC_TR_MNU));
        tmpreg |= ((uint32)RTC_ByteToBcd2(sTime->RTC_Minutes) << RTC_TR_MNU_Pos);

        /* Set RTC seconds */
        tmpreg &= ~((uint32)(RTC_TR_ST | RTC_TR_SU));
        tmpreg |= ((uint32)RTC_ByteToBcd2(sTime->RTC_Seconds) << RTC_TR_SU_Pos);
    }
    else
    {
        /* Set RTC hours */
        tmpreg &= ~((uint32)(RTC_TR_HT | RTC_TR_HU));
        tmpreg |= ((uint32)(sTime->RTC_Hours) << RTC_TR_HU_Pos);

        /* Set RTC minutes */
        tmpreg &= ~((uint32)(RTC_TR_MNT | RTC_TR_MNU));
        tmpreg |= ((uint32)(sTime->RTC_Minutes) << RTC_TR_MNU_Pos);

        /* Set RTC seconds */
        tmpreg &= ~((uint32)(RTC_TR_ST | RTC_TR_SU));
        tmpreg |= ((uint32)(sTime->RTC_Seconds) << RTC_TR_SU_Pos);
    }

    /* Set RTC tenth of second (not BCD encoded) */
    tmpreg &= ~((uint32)RTC_TR_TOS);
    tmpreg |= ((uint32)(sTime->RTC_TenthOfSecond) << RTC_TR_TOS_Pos);

    /* Write to RTC TR */
    hrtc->Instance->TR = tmpreg;

    hrtc->State = HAL_RTC_STATE_READY;

    /* Release Lock */
    RTC_UnlockHandle(hrtc);

    return HAL_OK;
}

/**
 * @brief  Get the RTC current time. (NON-BLOCKING)
 * @note   Runs the shared handle check, the state gate (ARCH-CONST-09) and the
 *         handle lock, so the read cannot interleave with the read modify write
 *         of HAL_RTC_SetTime() / HAL_RTC_SetDate(); it is therefore NOT
 *         callable from an interrupt service routine (LOCK-04 / RTOS-12).
 * @param  hrtc:   pointer to a RTC_HandleTypeDef structure that contains
 *         the configuration information for RTC.
 * @param  sTime:  pointer to a RTC_TimeTypeDef structure that will contain
 *         the returned current time configuration.
 * @param  Format: specifies the format of the entered parameters.
 *         This parameter can be one of the following values:
 *           @arg RTC_FORMAT_BIN: Binary data format
 *           @arg RTC_FORMAT_BCD: BCD data format
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_RTC_GetTime(RTC_HandleTypeDef *hrtc, RTC_TimeTypeDef *sTime, uint32 Format)
{
    HAL_StatusTypeDef status = HAL_OK;
    uint32 tmpreg = 0U;

    if ((RTC_HandleIsValid(hrtc) == 0U) || (sTime == NULL_PTR))
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_RTC_ALL_INSTANCE(hrtc->Instance));
    assert_param(IS_RTC_FORMAT(Format));

    /* Run time validation of the requested representation */
    if (IS_RTC_FORMAT(Format) == 0U)
    {
        hrtc->ErrorCode |= HAL_RTC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: the read runs the same gate as the write side, so a
     * rejected handle is reported instead of returning meaningless data */
    status = RTC_CheckState(hrtc);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked: the handle lock serializes the read against the read
     * modify write of HAL_RTC_SetTime() / HAL_RTC_SetDate() */
    if (RTC_LockHandle(hrtc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Get the RTC_TR register */
    tmpreg = (uint32)(hrtc->Instance->TR & RTC_TR_RESERVED_MASK);

    /* Fill the structure fields with the read parameters */
    if (Format == RTC_FORMAT_BIN)
    {
        sTime->RTC_Hours = (uint8)RTC_Bcd2ToByte((tmpreg & (RTC_TR_HT | RTC_TR_HU)) >> RTC_TR_HU_Pos);
        sTime->RTC_Minutes = (uint8)RTC_Bcd2ToByte((tmpreg & (RTC_TR_MNT | RTC_TR_MNU)) >> RTC_TR_MNU_Pos);
        sTime->RTC_Seconds = (uint8)RTC_Bcd2ToByte((tmpreg & (RTC_TR_ST | RTC_TR_SU)) >> RTC_TR_SU_Pos);
    }
    else
    {
        sTime->RTC_Hours = (uint8)((tmpreg & (RTC_TR_HT | RTC_TR_HU)) >> RTC_TR_HU_Pos);
        sTime->RTC_Minutes = (uint8)((tmpreg & (RTC_TR_MNT | RTC_TR_MNU)) >> RTC_TR_MNU_Pos);
        sTime->RTC_Seconds = (uint8)((tmpreg & (RTC_TR_ST | RTC_TR_SU)) >> RTC_TR_SU_Pos);
    }
    sTime->RTC_TenthOfSecond = (uint8)((tmpreg & RTC_TR_TOS) >> RTC_TR_TOS_Pos);

    /* Release Lock */
    RTC_UnlockHandle(hrtc);

    return HAL_OK;
}

/**
 * @brief  Fill each RTC_TimeTypeDef member with its default value (NON-BLOCKING)
 *         (Time = 00h:00min:00sec:00ms). (NON-BLOCKING)
 * @param  sTime: pointer to a RTC_TimeTypeDef structure which will be
 *         initialized.
 * @retval None
 */
void HAL_RTC_TimeStructInit(RTC_TimeTypeDef *sTime)
{
    if (sTime == NULL_PTR)
    {
        return;
    }

    /* Time = 00h:00min:00sec:00ms */
    sTime->RTC_Hours = 0;
    sTime->RTC_Minutes = 0;
    sTime->RTC_Seconds = 0;
    sTime->RTC_TenthOfSecond = 0;
}

/**
 * @brief  Set the RTC current date. (NON-BLOCKING)
 * @note   The weekday is written into the RTC_TR.WDU field (not BCD encoded).
 * @note   Run time validation of the format, the weekday, the fields and every
 *         BCD digit before the lock: a rejected value is reported with
 *         HAL_ERROR and HAL_RTC_ERROR_INVALID_PARAM without touching the
 *         register or the state.
 * @note   Gated by the handle state (ARCH-CONST-09) and serialized by the
 *         handle lock; the error code is cleared on entry.
 * @param  hrtc:   pointer to a RTC_HandleTypeDef structure that contains
 *         the configuration information for RTC.
 * @param  sDate:  pointer to a RTC_DateTypeDef structure that contains
 *         the date configuration information for the RTC.
 * @param  Format: specifies the format of the entered parameters.
 *         This parameter can be one of the following values:
 *           @arg RTC_FORMAT_BIN: Binary data format
 *           @arg RTC_FORMAT_BCD: BCD data format
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_RTC_SetDate(RTC_HandleTypeDef *hrtc, RTC_DateTypeDef *sDate, uint32 Format)
{
    HAL_StatusTypeDef status = HAL_OK;
    uint32 tmpreg = 0U;

    if ((RTC_HandleIsValid(hrtc) == 0U) || (sDate == NULL_PTR))
    {
        return HAL_ERROR;
    }

    /* Check the parameters (a full assertion build reports the same conditions) */
    assert_param(IS_RTC_FORMAT(Format));
    assert_param(IS_RTC_WEEKDAY(sDate->RTC_WeekDay));

    if (Format == RTC_FORMAT_BIN)
    {
        assert_param(IS_RTC_CENTURY(sDate->RTC_Century));
        assert_param(IS_RTC_YEAR(sDate->RTC_Year));
        assert_param(IS_RTC_MONTH(sDate->RTC_Month));
        assert_param(IS_RTC_DATE(sDate->RTC_Date));
    }
    else
    {
        assert_param(IS_RTC_CENTURY(RTC_Bcd2ToByte(sDate->RTC_Century)));
        assert_param(IS_RTC_YEAR(RTC_Bcd2ToByte(sDate->RTC_Year)));
        assert_param(IS_RTC_MONTH(RTC_Bcd2ToByte(sDate->RTC_Month)));
        assert_param(IS_RTC_DATE(RTC_Bcd2ToByte(sDate->RTC_Date)));
    }

    /* Run time validation: the format, the weekday, the fields and every BCD
     * digit. The call is rejected before the lock (ARCH-CONST-10 / ERR-03). */
    if (RTC_DateIsValid(sDate, Format) == 0U)
    {
        hrtc->ErrorCode |= HAL_RTC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY,
     * HAL_BUSY) or when the handle has not been initialized (RESET, HAL_ERROR:
     * HAL_RTC_Init() is required first). The timeout / error states are
     * recoverable and accepted. */
    status = RTC_CheckState(hrtc);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (RTC_LockHandle(hrtc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state (ARCH-CONST-10 / ERR-03) */
    hrtc->ErrorCode = HAL_RTC_ERROR_NONE;
    hrtc->State = HAL_RTC_STATE_BUSY;

    /* Set RTC weekday (written in the RTC_TR register) */
    tmpreg = hrtc->Instance->TR;
    tmpreg &= ~((uint32)RTC_TR_WDU);
    tmpreg |= ((uint32)(sDate->RTC_WeekDay) << RTC_TR_WDU_Pos);

    /* Write to RTC TR */
    hrtc->Instance->TR = tmpreg;

    tmpreg = 0U;

    /* Get the RTC_DR register */
    tmpreg = hrtc->Instance->DR;

    if (Format == RTC_FORMAT_BIN)
    {
        /* Set RTC century */
        tmpreg &= ~((uint32)(RTC_DR_CT | RTC_DR_CU));
        tmpreg |= ((uint32)RTC_ByteToBcd2(sDate->RTC_Century) << RTC_DR_CU_Pos);

        /* Set RTC year */
        tmpreg &= ~((uint32)(RTC_DR_YT | RTC_DR_YU));
        tmpreg |= ((uint32)RTC_ByteToBcd2(sDate->RTC_Year) << RTC_DR_YU_Pos);

        /* Set RTC month */
        tmpreg &= ~((uint32)(RTC_DR_MT | RTC_DR_MU));
        tmpreg |= ((uint32)RTC_ByteToBcd2(sDate->RTC_Month) << RTC_DR_MU_Pos);

        /* Set RTC date */
        tmpreg &= ~((uint32)(RTC_DR_DT | RTC_DR_DU));
        tmpreg |= ((uint32)RTC_ByteToBcd2(sDate->RTC_Date) << RTC_DR_DU_Pos);
    }
    else
    {
        /* Set RTC century */
        tmpreg &= ~((uint32)(RTC_DR_CT | RTC_DR_CU));
        tmpreg |= ((uint32)(sDate->RTC_Century) << RTC_DR_CU_Pos);

        /* Set RTC year */
        tmpreg &= ~((uint32)(RTC_DR_YT | RTC_DR_YU));
        tmpreg |= ((uint32)(sDate->RTC_Year) << RTC_DR_YU_Pos);

        /* Set RTC month */
        tmpreg &= ~((uint32)(RTC_DR_MT | RTC_DR_MU));
        tmpreg |= ((uint32)(sDate->RTC_Month) << RTC_DR_MU_Pos);

        /* Set RTC date */
        tmpreg &= ~((uint32)(RTC_DR_DT | RTC_DR_DU));
        tmpreg |= ((uint32)(sDate->RTC_Date) << RTC_DR_DU_Pos);
    }

    /* Write to RTC DR */
    hrtc->Instance->DR = tmpreg;

    hrtc->State = HAL_RTC_STATE_READY;

    /* Release Lock */
    RTC_UnlockHandle(hrtc);

    return HAL_OK;
}

/**
 * @brief  Get the RTC current date. (NON-BLOCKING)
 * @note   Runs the shared handle check, the state gate (ARCH-CONST-09) and the
 *         handle lock (see HAL_RTC_GetTime()), so it is NOT callable from an
 *         interrupt service routine. The weekday and the date live in different
 *         registers, so the two reads are not one atomic snapshot.
 * @param  hrtc:   pointer to a RTC_HandleTypeDef structure that contains
 *         the configuration information for RTC.
 * @param  sDate:  pointer to a RTC_DateTypeDef structure that will contain
 *         the returned current date configuration.
 * @param  Format: specifies the format of the entered parameters.
 *         This parameter can be one of the following values:
 *           @arg RTC_FORMAT_BIN: Binary data format
 *           @arg RTC_FORMAT_BCD: BCD data format
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_RTC_GetDate(RTC_HandleTypeDef *hrtc, RTC_DateTypeDef *sDate, uint32 Format)
{
    HAL_StatusTypeDef status = HAL_OK;
    uint32 tmpreg = 0U;

    if ((RTC_HandleIsValid(hrtc) == 0U) || (sDate == NULL_PTR))
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_RTC_ALL_INSTANCE(hrtc->Instance));
    assert_param(IS_RTC_FORMAT(Format));

    /* Run time validation of the requested representation */
    if (IS_RTC_FORMAT(Format) == 0U)
    {
        hrtc->ErrorCode |= HAL_RTC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09 gate, then the handle lock (see HAL_RTC_GetTime()) */
    status = RTC_CheckState(hrtc);
    if (status != HAL_OK)
    {
        return status;
    }

    if (RTC_LockHandle(hrtc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Get the RTC_TR register (weekday) */
    tmpreg = (uint32)(hrtc->Instance->TR & RTC_TR_WDU);

    /* Fill the structure fields with the read parameters */
    sDate->RTC_WeekDay = (uint8)((tmpreg & RTC_TR_WDU) >> RTC_TR_WDU_Pos);

    /* Get the RTC_DR register */
    tmpreg = (uint32)(hrtc->Instance->DR & RTC_DR_RESERVED_MASK);

    if (Format == RTC_FORMAT_BIN)
    {
        /* Fill the structure fields with the read parameters */
        sDate->RTC_Century = (uint8)RTC_Bcd2ToByte((tmpreg & (RTC_DR_CT | RTC_DR_CU)) >> RTC_DR_CU_Pos);
        sDate->RTC_Year = (uint8)RTC_Bcd2ToByte((tmpreg & (RTC_DR_YT | RTC_DR_YU)) >> RTC_DR_YU_Pos);
        sDate->RTC_Month = (uint8)RTC_Bcd2ToByte((tmpreg & (RTC_DR_MT | RTC_DR_MU)) >> RTC_DR_MU_Pos);
        sDate->RTC_Date = (uint8)RTC_Bcd2ToByte((tmpreg & (RTC_DR_DT | RTC_DR_DU)) >> RTC_DR_DU_Pos);
    }
    else
    {
        /* Fill the structure fields with the read parameters */
        sDate->RTC_Century = (uint8)((tmpreg & (RTC_DR_CT | RTC_DR_CU)) >> RTC_DR_CU_Pos);
        sDate->RTC_Year = (uint8)((tmpreg & (RTC_DR_YT | RTC_DR_YU)) >> RTC_DR_YU_Pos);
        sDate->RTC_Month = (uint8)((tmpreg & (RTC_DR_MT | RTC_DR_MU)) >> RTC_DR_MU_Pos);
        sDate->RTC_Date = (uint8)((tmpreg & (RTC_DR_DT | RTC_DR_DU)) >> RTC_DR_DU_Pos);
    }

    /* Release Lock */
    RTC_UnlockHandle(hrtc);

    return HAL_OK;
}

/**
 * @brief  Fill each RTC_DateTypeDef member with its default value (NON-BLOCKING)
 *         (Monday, January 01 0000). (NON-BLOCKING)
 * @param  sDate: pointer to a RTC_DateTypeDef structure which will be
 *         initialized.
 * @retval None
 */
void HAL_RTC_DateStructInit(RTC_DateTypeDef *sDate)
{
    if (sDate == NULL_PTR)
    {
        return;
    }

    /* Monday, January 01 0000 */
    sDate->RTC_WeekDay = RTC_Weekday_Monday;
    sDate->RTC_Date = 1;
    sDate->RTC_Month = RTC_Month_January;
    sDate->RTC_Year = 0;
    sDate->RTC_Century = 0;
}

/**
  * @}
  */

/** @defgroup RTC_Exported_Functions_Group3 RTC Alarm functions
  * @{
  */

/**
 * @brief  Set the RTC alarm. (NON-BLOCKING)
 * @note   The chip has a single alarm (no Alarm A/B). The comparison enable
 *         fields (RTC_AlarmTimeCompEn / RTC_AlarmDataCompEn) select which time
 *         / date fields are compared (a bit set to 1 means compared); an
 *         all-zero mask makes every field a wildcard.
 * @note   This call configures the match condition without enabling the
 *         interrupt and without consuming the historical alarm flag. The
 *         interrupt is masked for the whole reconfiguration and the comparison
 *         enables are cleared while the match fields are written.
 * @note   Run time validation of the format, both structures and every BCD
 *         digit before the lock: a rejected value is reported with HAL_ERROR
 *         and HAL_RTC_ERROR_INVALID_PARAM.
 * @note   Gated by the handle state (ARCH-CONST-09) and serialized by the
 *         handle lock; the error code is cleared on entry.
 * @param  hrtc:   pointer to a RTC_HandleTypeDef structure that contains
 *         the configuration information for RTC.
 * @param  sAlarm: pointer to a RTC_AlarmTypeDef structure that contains the
 *         alarm configuration parameters.
 * @param  Format: specifies the format of the entered parameters.
 *         This parameter can be one of the following values:
 *           @arg RTC_FORMAT_BIN: Binary data format
 *           @arg RTC_FORMAT_BCD: BCD data format
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_RTC_SetAlarm(RTC_HandleTypeDef *hrtc, RTC_AlarmTypeDef *sAlarm, uint32 Format)
{
    HAL_StatusTypeDef status = HAL_OK;

    if ((RTC_HandleIsValid(hrtc) == 0U) || (sAlarm == NULL_PTR))
    {
        return HAL_ERROR;
    }

    /* Check the parameters (a full assertion build reports the same conditions) */
    assert_param(IS_RTC_FORMAT(Format));
    assert_param(IS_RTC_ALARMTIME(sAlarm->RTC_AlarmTimeCompEn));
    assert_param(IS_RTC_ALARMDATE(sAlarm->RTC_AlarmDataCompEn));
    assert_param(IS_RTC_WEEKDAY(sAlarm->RTC_AlarmDate.RTC_WeekDay));
    assert_param(IS_RTC_TENOFSECOND(sAlarm->RTC_AlarmTime.RTC_TenthOfSecond));

    if (Format == RTC_FORMAT_BIN)
    {
        assert_param(IS_RTC_HOURS(sAlarm->RTC_AlarmTime.RTC_Hours));
        assert_param(IS_RTC_MINUTES(sAlarm->RTC_AlarmTime.RTC_Minutes));
        assert_param(IS_RTC_SECONDS(sAlarm->RTC_AlarmTime.RTC_Seconds));
        assert_param(IS_RTC_CENTURY(sAlarm->RTC_AlarmDate.RTC_Century));
        assert_param(IS_RTC_YEAR(sAlarm->RTC_AlarmDate.RTC_Year));
        assert_param(IS_RTC_MONTH(sAlarm->RTC_AlarmDate.RTC_Month));
        assert_param(IS_RTC_DATE(sAlarm->RTC_AlarmDate.RTC_Date));
    }
    else
    {
        assert_param(IS_RTC_HOURS(RTC_Bcd2ToByte(sAlarm->RTC_AlarmTime.RTC_Hours)));
        assert_param(IS_RTC_MINUTES(RTC_Bcd2ToByte(sAlarm->RTC_AlarmTime.RTC_Minutes)));
        assert_param(IS_RTC_SECONDS(RTC_Bcd2ToByte(sAlarm->RTC_AlarmTime.RTC_Seconds)));
        assert_param(IS_RTC_CENTURY(RTC_Bcd2ToByte(sAlarm->RTC_AlarmDate.RTC_Century)));
        assert_param(IS_RTC_YEAR(RTC_Bcd2ToByte(sAlarm->RTC_AlarmDate.RTC_Year)));
        assert_param(IS_RTC_MONTH(RTC_Bcd2ToByte(sAlarm->RTC_AlarmDate.RTC_Month)));
        assert_param(IS_RTC_DATE(RTC_Bcd2ToByte(sAlarm->RTC_AlarmDate.RTC_Date)));
    }

    /* Run time validation: the format, both alarm structures (including every
     * BCD digit) and the two comparison enable masks. The call is rejected
     * before the lock (ARCH-CONST-10 / ERR-03). */
    if (RTC_AlarmIsValid(sAlarm, Format) == 0U)
    {
        hrtc->ErrorCode |= HAL_RTC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY,
     * HAL_BUSY) or when the handle has not been initialized (RESET, HAL_ERROR:
     * HAL_RTC_Init() is required first). The timeout / error states are
     * recoverable and accepted. */
    status = RTC_CheckState(hrtc);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (RTC_LockHandle(hrtc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state (ARCH-CONST-10 / ERR-03) */
    hrtc->ErrorCode = HAL_RTC_ERROR_NONE;
    hrtc->State = HAL_RTC_STATE_BUSY;

    /* Program the alarm comparison registers through the Tier 3 helper (no
     * public API is called while the lock is held - rule LOCK-05). The
     * interrupt is not enabled and the historical alarm flag is not consumed
     * (EnableIt = 0). */
    RTC_SetAlarmConfig(hrtc, sAlarm, Format, 0U);

    hrtc->State = HAL_RTC_STATE_READY;

    /* Release Lock */
    RTC_UnlockHandle(hrtc);

    return HAL_OK;
}

/**
 * @brief  Set the RTC alarm with interrupt enabled. (NON-BLOCKING / IT)
 * @note   The interrupt must be routed to the CPU through the PLIC (see
 *         HAL_RTC_MspInit()).
 * @note   Clearing order (device prerequisite): CR.ALRMT is set by the hardware
 *         when the enabled comparison fields match and is cleared by software
 *         writing 0. While a comparison enable is still set the still true match
 *         condition re-asserts the flag, so the flag is cleared only after the
 *         comparison enables have been cleared; the interrupt is masked for the
 *         whole reconfiguration and the previous interrupt enable is restored
 *         afterwards. The historical flag is consumed by this call.
 * @note   Run time validation of the format, both structures and every BCD
 *         digit before the lock: a rejected value is reported with HAL_ERROR
 *         and HAL_RTC_ERROR_INVALID_PARAM.
 * @note   Gated by the handle state (ARCH-CONST-09) and serialized by the
 *         handle lock; the error code is cleared on entry.
 * @param  hrtc:   pointer to a RTC_HandleTypeDef structure that contains
 *         the configuration information for RTC.
 * @param  sAlarm: pointer to a RTC_AlarmTypeDef structure that contains the
 *         alarm configuration parameters.
 * @param  Format: specifies the format of the entered parameters.
 *         This parameter can be one of the following values:
 *           @arg RTC_FORMAT_BIN: Binary data format
 *           @arg RTC_FORMAT_BCD: BCD data format
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_RTC_SetAlarm_IT(RTC_HandleTypeDef *hrtc, RTC_AlarmTypeDef *sAlarm, uint32 Format)
{
    HAL_StatusTypeDef status = HAL_OK;

    if ((RTC_HandleIsValid(hrtc) == 0U) || (sAlarm == NULL_PTR))
    {
        return HAL_ERROR;
    }

    /* Check the parameters (a full assertion build reports the same conditions) */
    assert_param(IS_RTC_FORMAT(Format));
    assert_param(IS_RTC_ALARMTIME(sAlarm->RTC_AlarmTimeCompEn));
    assert_param(IS_RTC_ALARMDATE(sAlarm->RTC_AlarmDataCompEn));
    assert_param(IS_RTC_WEEKDAY(sAlarm->RTC_AlarmDate.RTC_WeekDay));
    assert_param(IS_RTC_TENOFSECOND(sAlarm->RTC_AlarmTime.RTC_TenthOfSecond));

    if (Format == RTC_FORMAT_BIN)
    {
        assert_param(IS_RTC_HOURS(sAlarm->RTC_AlarmTime.RTC_Hours));
        assert_param(IS_RTC_MINUTES(sAlarm->RTC_AlarmTime.RTC_Minutes));
        assert_param(IS_RTC_SECONDS(sAlarm->RTC_AlarmTime.RTC_Seconds));
        assert_param(IS_RTC_CENTURY(sAlarm->RTC_AlarmDate.RTC_Century));
        assert_param(IS_RTC_YEAR(sAlarm->RTC_AlarmDate.RTC_Year));
        assert_param(IS_RTC_MONTH(sAlarm->RTC_AlarmDate.RTC_Month));
        assert_param(IS_RTC_DATE(sAlarm->RTC_AlarmDate.RTC_Date));
    }
    else
    {
        assert_param(IS_RTC_HOURS(RTC_Bcd2ToByte(sAlarm->RTC_AlarmTime.RTC_Hours)));
        assert_param(IS_RTC_MINUTES(RTC_Bcd2ToByte(sAlarm->RTC_AlarmTime.RTC_Minutes)));
        assert_param(IS_RTC_SECONDS(RTC_Bcd2ToByte(sAlarm->RTC_AlarmTime.RTC_Seconds)));
        assert_param(IS_RTC_CENTURY(RTC_Bcd2ToByte(sAlarm->RTC_AlarmDate.RTC_Century)));
        assert_param(IS_RTC_YEAR(RTC_Bcd2ToByte(sAlarm->RTC_AlarmDate.RTC_Year)));
        assert_param(IS_RTC_MONTH(RTC_Bcd2ToByte(sAlarm->RTC_AlarmDate.RTC_Month)));
        assert_param(IS_RTC_DATE(RTC_Bcd2ToByte(sAlarm->RTC_AlarmDate.RTC_Date)));
    }

    /* Run time validation: the format, both alarm structures (including every
     * BCD digit) and the two comparison enable masks. The call is rejected
     * before the lock (ARCH-CONST-10 / ERR-03). */
    if (RTC_AlarmIsValid(sAlarm, Format) == 0U)
    {
        hrtc->ErrorCode |= HAL_RTC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY,
     * HAL_BUSY) or when the handle has not been initialized (RESET, HAL_ERROR:
     * HAL_RTC_Init() is required first). The timeout / error states are
     * recoverable and accepted. */
    status = RTC_CheckState(hrtc);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (RTC_LockHandle(hrtc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state (ARCH-CONST-10 / ERR-03) */
    hrtc->ErrorCode = HAL_RTC_ERROR_NONE;
    hrtc->State = HAL_RTC_STATE_BUSY;

    /* Configure the alarm through the Tier 3 helper (no public API is called
     * while the lock is held - rule LOCK-05). The device prerequisite is
     * honoured inside the helper: every comparison enable is cleared before
     * CR.ALRMT is written 0, and only then are the new comparison enables
     * committed and the interrupt enabled (EnableIt = 1). */
    RTC_SetAlarmConfig(hrtc, sAlarm, Format, 1U);

    hrtc->State = HAL_RTC_STATE_READY;

    /* Release Lock */
    RTC_UnlockHandle(hrtc);

    return HAL_OK;
}

/**
 * @brief  Get the RTC alarm value and comparison enables. (NON-BLOCKING)
 * @note   Runs the shared handle check, the state gate (ARCH-CONST-09) and the
 *         handle lock (see HAL_RTC_GetTime()), so it is NOT callable from an
 *         interrupt service routine. Two registers are read, so the result is
 *         not one atomic snapshot of the alarm configuration.
 * @param  hrtc:   pointer to a RTC_HandleTypeDef structure that contains
 *         the configuration information for RTC.
 * @param  sAlarm: pointer to a RTC_AlarmTypeDef structure that will contain
 *         the returned alarm configuration values.
 * @param  Format: specifies the format of the entered parameters.
 *         This parameter can be one of the following values:
 *           @arg RTC_FORMAT_BIN: Binary data format
 *           @arg RTC_FORMAT_BCD: BCD data format
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_RTC_GetAlarm(RTC_HandleTypeDef *hrtc, RTC_AlarmTypeDef *sAlarm, uint32 Format)
{
    HAL_StatusTypeDef status = HAL_OK;
    uint32 tmpreg = 0U;

    if ((RTC_HandleIsValid(hrtc) == 0U) || (sAlarm == NULL_PTR))
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_RTC_ALL_INSTANCE(hrtc->Instance));
    assert_param(IS_RTC_FORMAT(Format));

    /* Run time validation of the requested representation */
    if (IS_RTC_FORMAT(Format) == 0U)
    {
        hrtc->ErrorCode |= HAL_RTC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09 gate, then the handle lock (see HAL_RTC_GetTime()) */
    status = RTC_CheckState(hrtc);
    if (status != HAL_OK)
    {
        return status;
    }

    if (RTC_LockHandle(hrtc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Get the RTC_ALRMTR register */
    tmpreg = (uint32)(hrtc->Instance->ALRMTR);

    /* Fill the structure fields with the read parameters */
    sAlarm->RTC_AlarmTimeCompEn = ((uint32)(tmpreg & RTC_ALARMTIME_COMP_MASK));
    sAlarm->RTC_AlarmDate.RTC_WeekDay = (uint8)((tmpreg & RTC_ALRMTR_WDU) >> RTC_ALRMTR_WDU_Pos);

    if (Format == RTC_FORMAT_BIN)
    {
        sAlarm->RTC_AlarmTime.RTC_Hours =
            (uint8)RTC_Bcd2ToByte((tmpreg & (RTC_ALRMTR_HT | RTC_ALRMTR_HU)) >> RTC_ALRMTR_HU_Pos);
        sAlarm->RTC_AlarmTime.RTC_Minutes =
            (uint8)RTC_Bcd2ToByte((tmpreg & (RTC_ALRMTR_MNT | RTC_ALRMTR_MNU)) >> RTC_ALRMTR_MNU_Pos);
        sAlarm->RTC_AlarmTime.RTC_Seconds =
            (uint8)RTC_Bcd2ToByte((tmpreg & (RTC_ALRMTR_ST | RTC_ALRMTR_SU)) >> RTC_ALRMTR_SU_Pos);
    }
    else
    {
        sAlarm->RTC_AlarmTime.RTC_Hours = (uint8)((tmpreg & (RTC_ALRMTR_HT | RTC_ALRMTR_HU)) >> RTC_ALRMTR_HU_Pos);
        sAlarm->RTC_AlarmTime.RTC_Minutes = (uint8)((tmpreg & (RTC_ALRMTR_MNT | RTC_ALRMTR_MNU)) >> RTC_ALRMTR_MNU_Pos);
        sAlarm->RTC_AlarmTime.RTC_Seconds = (uint8)((tmpreg & (RTC_ALRMTR_ST | RTC_ALRMTR_SU)) >> RTC_ALRMTR_SU_Pos);
    }
    sAlarm->RTC_AlarmTime.RTC_TenthOfSecond = (uint8)((tmpreg & RTC_ALRMTR_TOS) >> RTC_ALRMTR_TOS_Pos);

    tmpreg = 0U;

    /* Get the RTC_ALRMDR register */
    tmpreg = (uint32)(hrtc->Instance->ALRMDR);

    /* Fill the structure fields with the read parameters */
    sAlarm->RTC_AlarmDataCompEn = ((uint32)(tmpreg & RTC_ALARMDATE_COMP_MASK));

    if (Format == RTC_FORMAT_BIN)
    {
        sAlarm->RTC_AlarmDate.RTC_Century =
            (uint8)RTC_Bcd2ToByte((tmpreg & (RTC_ALRMDR_CT | RTC_ALRMDR_CU)) >> RTC_ALRMDR_CU_Pos);
        sAlarm->RTC_AlarmDate.RTC_Year =
            (uint8)RTC_Bcd2ToByte((tmpreg & (RTC_ALRMDR_YT | RTC_ALRMDR_YU)) >> RTC_ALRMDR_YU_Pos);
        sAlarm->RTC_AlarmDate.RTC_Month =
            (uint8)RTC_Bcd2ToByte((tmpreg & (RTC_ALRMDR_MT | RTC_ALRMDR_MU)) >> RTC_ALRMDR_MU_Pos);
        sAlarm->RTC_AlarmDate.RTC_Date =
            (uint8)RTC_Bcd2ToByte((tmpreg & (RTC_ALRMDR_DT | RTC_ALRMDR_DU)) >> RTC_ALRMDR_DU_Pos);
    }
    else
    {
        sAlarm->RTC_AlarmDate.RTC_Century = (uint8)((tmpreg & (RTC_ALRMDR_CT | RTC_ALRMDR_CU)) >> RTC_ALRMDR_CU_Pos);
        sAlarm->RTC_AlarmDate.RTC_Year = (uint8)((tmpreg & (RTC_ALRMDR_YT | RTC_ALRMDR_YU)) >> RTC_ALRMDR_YU_Pos);
        sAlarm->RTC_AlarmDate.RTC_Month = (uint8)((tmpreg & (RTC_ALRMDR_MT | RTC_ALRMDR_MU)) >> RTC_ALRMDR_MU_Pos);
        sAlarm->RTC_AlarmDate.RTC_Date = (uint8)((tmpreg & (RTC_ALRMDR_DT | RTC_ALRMDR_DU)) >> RTC_ALRMDR_DU_Pos);
    }

    /* Release Lock */
    RTC_UnlockHandle(hrtc);

    return HAL_OK;
}

/**
 * @brief  Fill each RTC_AlarmTypeDef member with its default value (NON-BLOCKING)
 *         (Time = 00h:00mn:00sec:00ms / Date = Monday, January 01 0000 /
 *         Comparison = all fields are not compared). (NON-BLOCKING)
 * @param  sAlarm: pointer to a RTC_AlarmTypeDef structure which will be
 *         initialized.
 * @retval None
 */
void HAL_RTC_AlarmStructInit(RTC_AlarmTypeDef *sAlarm)
{
    if (sAlarm == NULL_PTR)
    {
        return;
    }

    /* Alarm Time Settings : Time = 00h:00mn:00sec:00ms */
    sAlarm->RTC_AlarmTime.RTC_Hours = 0;
    sAlarm->RTC_AlarmTime.RTC_Minutes = 0;
    sAlarm->RTC_AlarmTime.RTC_Seconds = 0;
    sAlarm->RTC_AlarmTime.RTC_TenthOfSecond = 0;

    /* Alarm Date Settings : Date = Monday, January 01 0000 */
    sAlarm->RTC_AlarmDate.RTC_WeekDay = RTC_Weekday_Monday;
    sAlarm->RTC_AlarmDate.RTC_Century = 0;
    sAlarm->RTC_AlarmDate.RTC_Year = 0;
    sAlarm->RTC_AlarmDate.RTC_Month = RTC_Month_January;
    sAlarm->RTC_AlarmDate.RTC_Date = 1;

    /* Alarm Masks Settings : Comparison = all fields are not compared */
    sAlarm->RTC_AlarmTimeCompEn = RTC_Alarm_None;
    sAlarm->RTC_AlarmDataCompEn = RTC_Alarm_None;
}

/**
 * @brief  Handle the RTC alarm interrupt request.
 * @note   This function must be called from the RTC_IRQ_Handler() PLIC callback
 *         when the alarm interrupt is used.
 * @note   LOCK-FREE and GATE-FREE by design (LOCK-04 / RTOS-12: an interrupt
 *         service routine must not take the task lock). The shared register
 *         sequence runs inside a short critical section that is closed before
 *         the user callback.
 * @note   Clearing order (device prerequisite): the comparison enables are
 *         cleared first, then CR.ALRMT is written 0, then the comparison enables
 *         are restored - otherwise the still true match condition re-asserts the
 *         flag and the interrupt becomes a storm.
 * @note   This function never writes the task side State or ErrorCode: a busy or
 *         uninitialized handle is not turned into READY by an interrupt.
 * @param  hrtc: pointer to a RTC_HandleTypeDef structure that contains
 *         the configuration information for RTC.
 * @retval None
 */
void HAL_RTC_AlarmIRQHandler(RTC_HandleTypeDef *hrtc)
{
    uint32 savedTr = 0U;
    uint32 savedDr = 0U;
    uint32 state = 0U;
    uint32 fire = 0U;

    if (RTC_HandleIsValid(hrtc) == 0U)
    {
        return;
    }

    /* LOCK-04 / RTOS-12: an interrupt service routine must not take the task
     * lock, so the shared register sequence runs inside a short critical
     * section instead. The device prerequisite for clearing the alarm flag is
     * honoured: every comparison enable is cleared first, then CR.ALRMT is
     * written 0, then the comparison enables are restored - otherwise the still
     * true match condition re-asserts the flag and the interrupt becomes a
     * storm. */
    state = __disable_irq_and_save();

    if (((hrtc->Instance->CR & RTC_CR_IE) != 0U) && ((hrtc->Instance->CR & RTC_CR_ALRMT) != 0U))
    {
        savedTr = hrtc->Instance->ALRMTR;
        savedDr = hrtc->Instance->ALRMDR;

        CLEAR_BIT(hrtc->Instance->ALRMTR, RTC_ALARMTIME_COMP_MASK);
        CLEAR_BIT(hrtc->Instance->ALRMDR, RTC_ALARMDATE_COMP_MASK);
        CLEAR_BIT(hrtc->Instance->CR, RTC_CR_ALRMT);
        SET_BIT(hrtc->Instance->ALRMTR, ((uint32)savedTr) & RTC_ALARMTIME_COMP_MASK);
        SET_BIT(hrtc->Instance->ALRMDR, ((uint32)savedDr) & RTC_ALARMDATE_COMP_MASK);
        fire = 1U;
    }

    __restore_irq(state);

    /* The user callback runs outside the critical section. This function never
     * writes the task side State or ErrorCode: a busy or uninitialized handle
     * is not turned into READY by an interrupt. */
    if (fire != 0U)
    {
        HAL_RTC_AlarmEventCallback(hrtc);
    }
}

/**
 * @brief  Alarm event callback.
 * @note   This function should not be modified: when the callback is needed,
 *         the HAL_RTC_AlarmEventCallback could be implemented in the user file.
 * @param  hrtc: pointer to a RTC_HandleTypeDef structure that contains
 *         the configuration information for RTC.
 * @retval None
 */
__weak void HAL_RTC_AlarmEventCallback(RTC_HandleTypeDef *hrtc)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(hrtc);

    /* NOTE : This function should not be modified, when the callback is needed,
              the HAL_RTC_AlarmEventCallback could be implemented in the user file
    */
}

/**
  * @}
  */

/** @defgroup RTC_Exported_Functions_Group4 Peripheral Control functions
  * @{
  */

/**
 * @brief  Enable or disable the RTC peripheral. (NON-BLOCKING)
 * @note   Only the calendar enable bit of the module owned fields is changed.
 *         The control register is assembled and written once, and the alarm flag
 *         is written with its neutral value (writing 1 keeps a flag asserted by
 *         the hardware, writing 0 would clear it), so a flag asserted around the
 *         update cannot be lost.
 * @note   Run time validation of the functional state before the lock; gated by
 *         the handle state (ARCH-CONST-09) and serialized by the handle lock.
 * @param  hrtc: pointer to a RTC_HandleTypeDef structure that contains
 *         the configuration information for RTC.
 * @param  NewState: new state of the RTC peripheral.
 *         This parameter can be: ENABLE or DISABLE.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY.
 */
HAL_StatusTypeDef HAL_RTC_Cmd(RTC_HandleTypeDef *hrtc, FunctionalState NewState)
{
    HAL_StatusTypeDef status = HAL_OK;

    if (RTC_HandleIsValid(hrtc) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    if (IS_FUNCTIONAL_STATE(NewState) == 0U)
    {
        hrtc->ErrorCode |= HAL_RTC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY,
     * HAL_BUSY) or when the handle has not been initialized (RESET, HAL_ERROR:
     * HAL_RTC_Init() is required first). The timeout / error states are
     * recoverable and accepted. */
    status = RTC_CheckState(hrtc);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (RTC_LockHandle(hrtc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Only the calendar enable bit changes. The control register is assembled and
     * written once (masked to the owned fields) with the alarm flag written with
     * its neutral value, so the divider, the interrupt enable and a flag asserted
     * by the hardware are preserved. */
    RTC_ModifyControl(hrtc, RTC_CR_EN, (NewState != DISABLE) ? (uint32)RTC_CR_EN : 0U);

    /* Release Lock */
    RTC_UnlockHandle(hrtc);

    return HAL_OK;
}

/**
  * @}
  */

/** @defgroup RTC_Exported_Functions_Group5 Peripheral State functions
  * @{
  */

/**
 * @brief  Return the RTC state. (NON-BLOCKING)
 * @note   Reads a handle field only (no register access, no lock, no state
 *         gate), so it stays callable from an interrupt service routine. The
 *         shared RTC_HandleIsValid() check is still applied.
 * @param  hrtc: pointer to a RTC_HandleTypeDef structure that contains
 *         the configuration information for RTC.
 * @retval HAL_RTCStateTypeDef: HAL_RTC_STATE_x (RESET for an invalid handle).
 */
HAL_RTCStateTypeDef HAL_RTC_GetState(RTC_HandleTypeDef *hrtc)
{
    if (RTC_HandleIsValid(hrtc) == 0U)
    {
        return HAL_RTC_STATE_RESET;
    }

    return hrtc->State;
}

/**
 * @brief  Returns the RTC error code. (NON-BLOCKING)
 * @note   Reads a handle field only (no register access, no lock, no state
 *         gate), so it stays callable from an interrupt service routine. The
 *         shared RTC_HandleIsValid() check is still applied.
 * @param  hrtc: pointer to a RTC_HandleTypeDef structure.
 * @retval uint32: the RTC error code (HAL_RTC_ERROR_xxx, NONE for an invalid
 *         handle).
 */
uint32 HAL_RTC_GetError(RTC_HandleTypeDef *hrtc)
{
    if (RTC_HandleIsValid(hrtc) == 0U)
    {
        return HAL_RTC_ERROR_NONE;
    }

    return hrtc->ErrorCode;
}

/**
  * @}
  */

/**
  * @}
  */

/* Exported functions ---------------------------------------------------------*/

/** @defgroup RTC_Exported_Functions RTC Exported Functions
  * @{
  */

/** @defgroup RTC_Exported_Functions_Group1 RTC Wake-up timer functions
  * @{
  */

/**
 * @brief  Enable or disable the RTC wake-up timer. (NON-BLOCKING)
 * @note   The chip wake-up timer has no counter register: only the wake-up
 *         enable bit (RTC_WUCR.WUTE) is available. The wake-up period is
 *         defined by the hardware (the RTC divider coefficient), it cannot be
 *         programmed by software.
 * @note   The register access is protected by the handle lock, so that the
 *         read-modify-write of WUCR cannot interleave with another RTC
 *         operation; the wake-up enable is gated by the handle state
 *         (ARCH-CONST-09), so a handle that is busy or that has not been
 *         initialized is left untouched. The interface keeps the void
 *         signature of the library control setters: a rejected call simply
 *         does not touch the peripheral, and the outcome can be checked with
 *         HAL_RTC_GetState() / HAL_RTC_GetError().
 *         It is not an interrupt service routine path: the alarm handler
 *         (HAL_RTC_AlarmIRQHandler) does not touch WUCR.
 * @param  hrtc:     pointer to a RTC_HandleTypeDef structure that contains
 *         the configuration information for RTC.
 * @param  NewState: new state of the RTC wake-up timer.
 *         This parameter can be: ENABLE or DISABLE.
 * @retval None
 */
void HAL_RTC_WakeUpCmd(RTC_HandleTypeDef *hrtc, FunctionalState NewState)
{
    if (RTC_HandleIsValid(hrtc) == 0U)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    if (IS_FUNCTIONAL_STATE(NewState) == 0U)
    {
        hrtc->ErrorCode |= HAL_RTC_ERROR_INVALID_PARAM;
        return;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_RTC_Init() is
     * required first). The timeout / error states are recoverable and
     * accepted. */
    if (RTC_CheckState(hrtc) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (RTC_LockHandle(hrtc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    if (NewState != DISABLE)
    {
        /* Enable the RTC wake-up by setting the WUTE bit in the WUCR register */
        __HAL_RTC_WAKEUPTIMER_ENABLE(hrtc);
    }
    else
    {
        /* Disable the RTC wake-up by clearing the WUTE bit in the WUCR register */
        __HAL_RTC_WAKEUPTIMER_DISABLE(hrtc);
    }

    /* Release Lock */
    RTC_UnlockHandle(hrtc);
}

/**
  * @}
  */

/**
  * @}
  */

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Convert a 2 digit decimal to BCD format.
 * @param  Value: byte to be converted.
 * @retval Converted byte.
 */
static uint8 RTC_ByteToBcd2(uint8 Value)
{
    uint8 bcdhigh = 0;

    while (Value >= 10)
    {
        bcdhigh++;
        Value -= 10;
    }

    return ((uint8)(bcdhigh << 4) | Value);
}

/**
 * @brief  Convert from 2 digit BCD to Binary.
 * @param  Value: BCD value to be converted.
 * @retval Converted word.
 */
static uint8 RTC_Bcd2ToByte(uint8 Value)
{
    uint8 tmp = 0;
    tmp = ((uint8)(Value & (uint8)0xF0) >> (uint8)0x4) * 10;
    return (tmp + (Value & (uint8)0x0F));
}

#endif /* HAL_RTC_MODULE_ENABLED */

/*****END OF FILE*****/

