/**
 * @file    TIM_IT_DRV_034.c
 * @brief   TIM7 PWM mode 1 on channel 3
 *
 * HAL library port of the original AS32x601 standard-library test case
 * TIMER_IT_DRV_037.c, which drives TIM7. Only HAL library APIs are used; the register
 * read backs document what was programmed.
 *
 * Tested functionality:
 *   TIM_OCStructInit()      -> HAL_TIM_OC_StructInit()
 *   TIM_OC3Init() -> HAL_TIM_PWM_ConfigChannel()
 *   TIM_Cmd(ENABLE)         -> HAL_TIM_PWM_Start()
 *
 * Test procedure:
 *   map the output pin of TIM7 (PG8);
 *   configure every channel with PWM mode 1 and a 50 percent pulse;
 *   start every channel and observe the waveform.
 *
 * Expected behaviour:
 *   every channel returns HAL_OK and OC3M reads PWM mode 1;
 *   the pulse value is found in every CCR register;
 *   CCER reads CC1E..CC4E set (the general purpose timers have no main output enable bit);
 *   every check prints [PASS] and "summary : failures = 0".
 *
 * Note:
 *   TIM7 is a general purpose timer: it has four channels and no break / dead-time register, so the main output is not gated.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
/* Console: USART0 on GPIOD pin 8 (TX) / pin 9 (RX), 115200 8N1 */
#define TEST_BAUDRATE                   (115200U)

#define TEST_ARR                        (10000U - 1U)
#define TEST_PSC                        (9U - 1U)
#define TEST_PULSE                      (10000U / 2U)


/* Private variables -------------------------------------------------------*/
/* Channels that the board brings out on this timer; the pins of the
 * remaining channels of the device are not routed on the board. */
static const uint32 test_channels[1] = {
    TIM_CHANNEL_3
};

static HAL_TIM_HandleTypeDef htim_dev;          /*!< timer under test        */
static HAL_SMU_HandleTypeDef hsmu_clk;          /*!< SMU handle (clock tree) */
static volatile uint32 check_failures = 0U;     /*!< failed check counter    */



/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure one GPIO pin and, for the alternate function modes, the
 *         pin mux of that pin.
 * @param  port: GPIO port
 * @param  pin: pin mask
 * @param  source: pin source number (for the mux configuration)
 * @param  af: alternate function selector
 * @param  mode: GPIO_MODE_AF_PP / GPIO_MODE_INPUT
 * @retval None
 */
static void Gpio_Config(GPIO_TypeDef *port, uint32 pin, uint32 source, uint8 af, uint32 mode)
{
    GPIO_InitTypeDef gpio_init;

    __HAL_CLEAR_STRUCT(&gpio_init);
    gpio_init.Size         = sizeof(GPIO_InitTypeDef);
    gpio_init.Version      = GPIO_INIT_VERSION;
    gpio_init.Pin          = pin;
    gpio_init.Mode         = mode;
    gpio_init.Pull         = GPIO_NOPULL;
    gpio_init.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;
    gpio_init.Alternate    = af;
    if (mode == GPIO_MODE_AF_PP)
    {
        HAL_GPIO_PinAFConfig(port, source, af);
    }
    HAL_GPIO_Init(port, &gpio_init);
}

/**
 * @brief  Configure the time base of the timer under test.
 * @note   The helper keeps the Size / Version meta fields through
 *         HAL_TIM_Base_StructInit(), which the initialization interface
 *         validates at run time.
 * @param  instance: TIM0..TIM7
 * @param  arr: auto reload value
 * @param  psc: prescaler value
 * @param  rcr: repetition counter (advanced timers only)
 * @param  ckd: clock division
 * @param  countermode: counting mode
 * @retval HAL status of HAL_TIM_Base_Init()
 */
static HAL_StatusTypeDef TimeBase_Config(TIM_TypeDef *instance, uint32 arr, uint32 psc,
                                         uint32 rcr, uint32 ckd, uint32 countermode)
{
    TIM_Base_InitTypeDef base_init;

    __HAL_CLEAR_STRUCT(&htim_dev);
    htim_dev.Instance = instance;

    HAL_TIM_Base_StructInit(&base_init);
    base_init.CounterMode       = countermode;
    base_init.ClockDivision     = ckd;
    base_init.Period            = arr;
    base_init.Prescaler         = psc;
    base_init.RepetitionCounter = rcr;
    htim_dev.Init               = base_init;

    return HAL_TIM_Base_Init(&htim_dev);
}

/**
 * @brief  Enable the clock of a timer instance and release its reset.
 * @note   The default MSP callbacks of this module are empty, so the suite
 *         performs the gate and reset handling itself; every MSP callback is
 *         routed to this helper.
 * @param  instance: TIM0..TIM7
 * @retval None
 */
static void Tim_ClockEnable(TIM_TypeDef *instance)
{
    if (instance == TIM0)
    {
        __HAL_SMU_HTIM0_CLK_ENABLE();
        __HAL_SMU_HTIM0_FORCE_RESET();
        __HAL_SMU_HTIM0_RELEASE_RESET();
    }
    else if (instance == TIM1)
    {
        __HAL_SMU_HTIM1_CLK_ENABLE();
        __HAL_SMU_HTIM1_FORCE_RESET();
        __HAL_SMU_HTIM1_RELEASE_RESET();
    }
    else if (instance == TIM2)
    {
        __HAL_SMU_HTIM2_CLK_ENABLE();
        __HAL_SMU_HTIM2_FORCE_RESET();
        __HAL_SMU_HTIM2_RELEASE_RESET();
    }
    else if (instance == TIM3)
    {
        __HAL_SMU_TIM3_CLK_ENABLE();
        __HAL_SMU_TIM3_FORCE_RESET();
        __HAL_SMU_TIM3_RELEASE_RESET();
    }
    else if (instance == TIM4)
    {
        __HAL_SMU_TIM4_CLK_ENABLE();
        __HAL_SMU_TIM4_FORCE_RESET();
        __HAL_SMU_TIM4_RELEASE_RESET();
    }
    else if (instance == TIM5)
    {
        __HAL_SMU_HTIM5_CLK_ENABLE();
        __HAL_SMU_HTIM5_FORCE_RESET();
        __HAL_SMU_HTIM5_RELEASE_RESET();
    }
    else if (instance == TIM6)
    {
        __HAL_SMU_TIM6_CLK_ENABLE();
        __HAL_SMU_TIM6_FORCE_RESET();
        __HAL_SMU_TIM6_RELEASE_RESET();
    }
    else
    {
        __HAL_SMU_TIM7_CLK_ENABLE();
        __HAL_SMU_TIM7_FORCE_RESET();
        __HAL_SMU_TIM7_RELEASE_RESET();
    }
}

/**
 * @brief  Read the OCxM (output compare mode) field of one channel.
 * @note   The field lives in CCMR1 for channels 1/2, in CCMR2 for channels 3/4
 *         and in CCMR3 for channels 5/6. Inside one register the low-half
 *         channel has its field at bits 6:4 and the high-half channel at bits
 *         14:12 (the OCxM[3] extension bit sits separately at bit 16 / 24 and
 *         is not read here), so the shift is 4 or 12 - NOT 0 or 8, which are
 *         the CCxS positions.
 * @note   The result is normalised to the bits 6:4 position, so it can be
 *         compared with the TIM_OCMODE_xxx constants whatever channel it was
 *         read from.
 * @param  inst: timer instance
 * @param  channel: TIM_CHANNEL_x
 * @retval uint32: the three bit OCxM value, aligned like OC1M
 */
static uint32 OcmOf(TIM_TypeDef *inst, uint32 channel)
{
    uint32 reg;
    uint32 shift;

    switch (channel)
    {
    case TIM_CHANNEL_1:
        reg = inst->CCMR1;
        shift = 4U;
        break;
    case TIM_CHANNEL_2:
        reg = inst->CCMR1;
        shift = 12U;
        break;
    case TIM_CHANNEL_3:
        reg = inst->CCMR2;
        shift = 4U;
        break;
    case TIM_CHANNEL_4:
        reg = inst->CCMR2;
        shift = 12U;
        break;
    case TIM_CHANNEL_5:
        reg = inst->CCMR3;
        shift = 4U;
        break;
    default:
        reg = inst->CCMR3;
        shift = 12U;
        break;
    }

    return ((reg >> shift) << 4U) & TIM_CCMR1_OC1M;
}

/**
 * @brief  Read the capture/compare register of one channel.
 * @param  inst: timer instance
 * @param  channel: TIM_CHANNEL_x
 * @retval uint32: the CCRx value
 */
static uint32 CcrOf(TIM_TypeDef *inst, uint32 channel)
{
    uint32 value;

    switch (channel)
    {
    case TIM_CHANNEL_1:
        value = inst->CCR1;
        break;
    case TIM_CHANNEL_2:
        value = inst->CCR2;
        break;
    case TIM_CHANNEL_3:
        value = inst->CCR3;
        break;
    default:
        value = inst->CCR4;
        break;
    }

    return value;
}

/* MSP callbacks: the timer clock and reset of the instance under test */
void HAL_TIM_Base_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_OC_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_PWM_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_IC_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_OnePulse_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_Encoder_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the CLINT / CMU / MPU / USART integration tests:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2, CANX2 by
 *         8 -> core 180 MHz, AXILite4 Bus 1 and Bus 2 = 45 MHz (TIM0, TIM1),
 *         APBBus0 and APBBus1 = 22.5 MHz (TIM2 / TIM3 / TIM4 and TIM5 / TIM6 /
 *         TIM7 - TIM2 and TIM5 are advanced timers on the APB).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef    SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks used by this suite (GPIOH lives in the always on
       domain and has no gate macro) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Clock tree order: write the dividers while the system clock is still
       FIRC, then configure the PLL and switch to it (that call programs the
       flash controller clock before the switch and updates SystemCoreClock
       afterwards). */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    TIM_OC_InitTypeDef oc_cfg;
    uint32 idx;
    uint32 ocm_ok;
    uint32 ccr_ok;
    uint32 cce_ok;

    HAL_Init();
    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== TIM_IT_DRV_034 : TIM7 PWM mode 1 on one channel ===\r\n");
    Gpio_Config(GPIOG, GPIO_PIN_8, GPIO_PinSource8, GPIO_AF_TIM7, GPIO_MODE_AF_PP);

    Check("HAL_TIM_Base_Init() returns HAL_OK",
          (TimeBase_Config(TIM7, TEST_ARR, TEST_PSC, 0U, TIM_CKD_DIV4, TIM_COUNTERMODE_UP) == HAL_OK));

    __HAL_CLEAR_STRUCT(&oc_cfg);
    HAL_TIM_OC_StructInit(&oc_cfg);
    oc_cfg.Pulse      = TEST_PULSE;
    oc_cfg.OCMode     = TIM_OCMODE_PWM1;
    oc_cfg.OCPolarity = TIM_OCPOLARITY_HIGH;
    for (idx = 0U; idx < 1U; idx++)
    {
        Check("HAL_TIM_PWM_ConfigChannel() returns HAL_OK",
              (HAL_TIM_PWM_ConfigChannel(&htim_dev, &oc_cfg, test_channels[idx]) == HAL_OK));
        Check("HAL_TIM_PWM_Start() returns HAL_OK",
              (HAL_TIM_PWM_Start(&htim_dev, test_channels[idx]) == HAL_OK));
    }
    ocm_ok = 1U;
    ccr_ok = 1U;
    cce_ok = 1U;
    for (idx = 0U; idx < 1U; idx++)
    {
        if (OcmOf(TIM7, test_channels[idx]) != TIM_OCMODE_PWM1)
        {
            ocm_ok = 0U;
        }
        if (CcrOf(TIM7, test_channels[idx]) != TEST_PULSE)
        {
            ccr_ok = 0U;
        }
        if ((TIM7->CCER &
             (TIM_CCER_CC1E << (4U * (test_channels[idx] / 4U)))) == 0U)
        {
            cce_ok = 0U;
        }
    }
    Check("OCxM reads PWM mode 1 on every channel of this case", ocm_ok);
    Check("CCRx holds the pulse on every channel of this case", ccr_ok);
    Check("CCER reads the CCxE bit of every channel of this case", cce_ok);

    Summary();

    for (;;)
    {
    }
}
