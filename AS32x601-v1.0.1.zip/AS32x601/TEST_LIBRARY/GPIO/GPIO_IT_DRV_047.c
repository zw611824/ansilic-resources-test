/**
 * @file    GPIO_IT_DRV_047.c
 * @brief   HAL GPIO integration test case 047 (extension: interrupt interface
 *          coverage).
 *
 * This case is not part of the vendor plan (which has 43 cases): it is an
 * extension. The one-to-one ports exercise the interrupt path through a
 * software forced request or an external edge; this case checks the interrupt
 * configuration registers, the status helpers and the callback at register
 * level, and then the complete path through the PLIC.
 *
 * Tested functionality:
 *   HAL_GPIO_Init()
 *   HAL_GPIO_ITConfig()          (GPIO_ITType_EDGEUP / EDGEDOWN / EDGE /
 *                                   CLOSE, ENABLE and DISABLE)
 *   HAL_GPIO_ITMaskConfig()      (mask / unmask, IMR)
 *   HAL_GPIO_GetITStatus()
 *   HAL_GPIO_ForceINT()
 *   HAL_GPIO_ClearITPendingBit()
 *   HAL_GPIO_IRQHandler() + HAL_GPIOD_EXTI_Callback()
 *   HAL_PLIC_Init()                (enable the port line)
 *
 * Test configuration:
 *   GPIOD pins 0..3 : interrupt lines of the device under test
 *
 * Test procedure (every check is recorded in the observation masks below):
 *   step 1  the trigger type of every line is programmed (ITYPE0R) and the
 *           line is unmasked / masked accordingly                     checks 0..3
 *   step 2  masking and unmasking through ITMaskConfig                 checks 4..5
 *   step 3  a software forced request is reported by GetITStatus       checks 6..8
 *   step 4  ClearITPendingBit() clears it                              check  9
 *   step 5  a direct call of HAL_GPIO_IRQHandler() clears the pending bits
 *           and reports the fired pins to the callback               checks 10..11
 *   step 6  rejected arguments leave the registers untouched          checks 12..14
 *   step 7  the complete path: the PLIC line is enabled, a forced request
 *           is served by GPIOD_IRQ_Handler()                         checks 15..16
 *
 * Expected behaviour:
 *   The case prints nothing. Bit n of Passed_Mask is set when check n passed and
 *   bit n of Failed_Mask when it failed, so
 *     Failed_Mask == 0x00000000  and  Passed_Mask == 0x0001FFFF  and
 *     Check_Count == 17
 *   means that every check of this case passed. Cpu_Irq_Count counts the
 *   interrupts served by GPIOD_IRQ_Handler() and Callback_Mask accumulates the
 *   pins reported to HAL_GPIOD_EXTI_Callback().
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"

/* Private define -----------------------------------------------------------*/
/* GPIOD interrupt lines used by this case */
#define TEST_IT_PIN_0           (GPIO_PIN_0)
#define TEST_IT_PIN_1           (GPIO_PIN_1)
#define TEST_IT_PIN_2           (GPIO_PIN_2)
#define TEST_IT_PIN_3           (GPIO_PIN_3)
#define TEST_IT_PIN             (GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3)
#define TEST_IT_UNMASKED_PIN    (GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2)

/* Trigger type encodings of the ITYPE0R register */
#define ITYPE0R_DISABLED        (0U)
#define ITYPE0R_RISING          (1U)
#define ITYPE0R_FALLING         (2U)
#define ITYPE0R_BOTH_EDGES      (3U)

/* An unsupported trigger type and an unsupported pin mask */
#define INVALID_IT_TYPE         ((GPIO_ITType_TypeDef)0x05)

/* Number of checks of this case and the expected observation of the masks */
#define CHECK_ALL               ((uint32)0x0001FFFFU)
#define CHECK_TOTAL             (17U)

/* Private variables ---------------------------------------------------------*/
static HAL_SMU_HandleTypeDef hsmu_clk;    /*!< SMU handle (lock / state / error) */
static volatile uint32 Passed_Mask = 0U;  /*!< bit n set when check n passed      */
static volatile uint32 Failed_Mask = 0U;  /*!< bit n set when check n failed      */
static volatile uint32 Check_Count = 0U;  /*!< number of checks that were run     */
static volatile uint32 Callback_Mask = 0U;/*!< pins reported to the callback      */
static volatile uint32 Cpu_Irq_Count = 0U;/*!< interrupts served by the handler   */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void plic_Config(void);
static void check(uint32 index, uint32 condition);
static uint32 itype_field(uint32 pin);
static uint32 imr_bit(uint32 pin);
static uint32 is_masked(uint32 pin);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    uint32 ok;
    uint32 imr_before;
    uint32 status_before;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Enable the GPIOD clock gate and configure the interrupt lines as inputs.
       The PLIC line is enabled at the very end only, so that the checks of the
       steps 1..6 cannot be disturbed by an interrupt. */
    __HAL_SMU_GPIOD_CLK_ENABLE();
    {
        GPIO_InitTypeDef GPIO_InitStruct;

        __HAL_CLEAR_STRUCT(&GPIO_InitStruct);
        HAL_GPIO_StructInit(&GPIO_InitStruct);
        GPIO_InitStruct.Pin          = TEST_IT_PIN;
        GPIO_InitStruct.Mode         = GPIO_MODE_INPUT;
        GPIO_InitStruct.Pull         = GPIO_NOPULL;
        GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
        HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
    }

    /* ---- Step 1: the trigger type of every line (checks 0..3) ------------ */

    HAL_GPIO_ITConfig(GPIOD, TEST_IT_PIN_0, GPIO_ITType_EDGEUP, ENABLE);
    ok = ((itype_field(0U) == ITYPE0R_RISING) && (is_masked(0U) == 0U));
    check(0U, ok);

    HAL_GPIO_ITConfig(GPIOD, TEST_IT_PIN_1, GPIO_ITType_EDGEDOWN, ENABLE);
    ok = ((itype_field(1U) == ITYPE0R_FALLING) && (is_masked(1U) == 0U));
    check(1U, ok);

    HAL_GPIO_ITConfig(GPIOD, TEST_IT_PIN_2, GPIO_ITType_EDGE, ENABLE);
    ok = ((itype_field(2U) == ITYPE0R_BOTH_EDGES) && (is_masked(2U) == 0U));
    check(2U, ok);

    /* A disabled line keeps the trigger cleared and is masked */
    HAL_GPIO_ITConfig(GPIOD, TEST_IT_PIN_3, GPIO_ITType_CLOSE, DISABLE);
    ok = ((itype_field(3U) == ITYPE0R_DISABLED) && (is_masked(3U) != 0U));
    check(3U, ok);

    /* ---- Step 2: mask / unmask (checks 4..5) ----------------------------- */

    HAL_GPIO_ITMaskConfig(GPIOD, TEST_IT_PIN_0, DISABLE);
    ok = (is_masked(0U) != 0U);
    if (HAL_GPIO_GetITStatus(GPIOD, TEST_IT_PIN_0) != RESET)
    {
        ok = 0U;
    }
    check(4U, ok);

    HAL_GPIO_ITMaskConfig(GPIOD, TEST_IT_PIN_0, ENABLE);
    ok = (is_masked(0U) == 0U);
    check(5U, ok);

    /* ---- Step 3: a forced request is reported (checks 6..8) ------------- */

    HAL_GPIO_ForceINT(GPIOD, TEST_IT_PIN);
    ok = ((HAL_GPIO_GetITStatus(GPIOD, TEST_IT_PIN_0) == SET) &&
          (HAL_GPIO_GetITStatus(GPIOD, TEST_IT_PIN_1) == SET));
    check(6U, ok);

    /* The status register reports the request AND NOT the mask, so the masked
       line 3 is not reported while its request is pending */
    ok = (HAL_GPIO_GetITStatus(GPIOD, TEST_IT_PIN_3) == RESET);
    check(7U, ok);

    /* The whole mask form reports the request when at least one line is pending */
    ok = (HAL_GPIO_GetITStatus(GPIOD, TEST_IT_PIN) == SET);
    check(8U, ok);

    /* ---- Step 4: clear the pending bits (check 9) ------------------------ */

    HAL_GPIO_ClearITPendingBit(GPIOD, TEST_IT_PIN_0);
    ok = (HAL_GPIO_GetITStatus(GPIOD, TEST_IT_PIN_0) == RESET);
    check(9U, ok);

    /* ---- Step 5: the port handler and the callback (checks 10..11) ------- */

    HAL_GPIO_ForceINT(GPIOD, TEST_IT_UNMASKED_PIN);
    Callback_Mask = 0U;
    HAL_GPIO_IRQHandler(GPIOD);

    ok = ((HAL_GPIO_GetITStatus(GPIOD, TEST_IT_PIN_0) == RESET) &&
          (HAL_GPIO_GetITStatus(GPIOD, TEST_IT_PIN_1) == RESET) &&
          (HAL_GPIO_GetITStatus(GPIOD, TEST_IT_PIN_2) == RESET));
    check(10U, ok);

    ok = (Callback_Mask == (uint32)TEST_IT_UNMASKED_PIN);
    check(11U, ok);

    /* ---- Step 6: rejected arguments (checks 12..14) ---------------------- */

    /* an unsupported trigger type and an empty pin mask */
    imr_before = GPIO_READ_REG(GPIOD, IMR);
    HAL_GPIO_ITConfig(GPIOD, TEST_IT_PIN_1, INVALID_IT_TYPE, ENABLE);
    HAL_GPIO_ITConfig(GPIOD, 0U, GPIO_ITType_EDGE, ENABLE);
    HAL_GPIO_ITConfig(NULL_PTR, TEST_IT_PIN_1, GPIO_ITType_EDGE, ENABLE);
    ok = ((GPIO_READ_REG(GPIOD, IMR) == imr_before) && (itype_field(1U) == ITYPE0R_FALLING));
    check(12U, ok);

    HAL_GPIO_ITMaskConfig(GPIOD, 0U, DISABLE);
    HAL_GPIO_ITMaskConfig(NULL_PTR, TEST_IT_PIN_1, DISABLE);
    ok = (GPIO_READ_REG(GPIOD, IMR) == imr_before);
    check(13U, ok);

    /* a NULL port, an empty mask and a non existing channel of the GPIOH port
       are refused, and a rejected read returns RESET */
    status_before = (uint32)HAL_GPIO_GetITStatus(GPIOD, TEST_IT_PIN_3);
    HAL_GPIO_ForceINT(NULL_PTR, TEST_IT_PIN);
    HAL_GPIO_ForceINT(GPIOD, 0U);
    HAL_GPIO_ClearITPendingBit(NULL_PTR, TEST_IT_PIN);
    HAL_GPIO_ClearITPendingBit(GPIOD, 0U);
    ok = ((uint32)HAL_GPIO_GetITStatus(GPIOD, TEST_IT_PIN_3) == status_before);
    if (HAL_GPIO_GetITStatus(NULL_PTR, TEST_IT_PIN_0) != RESET)
    {
        ok = 0U;
    }
    if (HAL_GPIO_GetITStatus(GPIOD, 0U) != RESET)
    {
        ok = 0U;
    }
    if (HAL_GPIO_GetITStatus(GPIOH, GPIO_PIN_10) != RESET)
    {
        ok = 0U;
    }
    check(14U, ok);

    /* ---- Step 7: the complete path through the PLIC (checks 15..16) ------ */

    Callback_Mask  = 0U;
    Cpu_Irq_Count  = 0U;
    plic_Config();
    HAL_GPIO_ClearITPendingBit(GPIOD, TEST_IT_PIN);

    HAL_GPIO_ForceINT(GPIOD, TEST_IT_UNMASKED_PIN);

    /* Give the interrupt a moment to be served */
    delay_us(200U);

    ok = ((HAL_GPIO_GetITStatus(GPIOD, TEST_IT_PIN_0) == RESET) &&
          (HAL_GPIO_GetITStatus(GPIOD, TEST_IT_PIN_1) == RESET) &&
          (HAL_GPIO_GetITStatus(GPIOD, TEST_IT_PIN_2) == RESET));
    check(15U, ok);

    ok = ((Cpu_Irq_Count >= 1U) && (Callback_Mask == (uint32)TEST_IT_UNMASKED_PIN));
    check(16U, ok);

    /* Every check has been recorded; the loop keeps the observables alive */
    while (1)
    {
        delay_ms(500U);
    }
}

/**
 * @brief  Record the result of one check.
 * @param  index: check number, used as the bit position of the mask.
 * @param  condition: 1 when the check passed, 0 when it failed.
 * @retval None
 */
static void check(uint32 index, uint32 condition)
{
    Check_Count++;

    if (condition != 0U)
    {
        Passed_Mask |= ((uint32)0x01U << index);
    }
    else
    {
        Failed_Mask |= ((uint32)0x01U << index);
    }
}

/**
 * @brief  Read the ITYPE0R trigger field of one GPIOD pin.
 * @param  pin: pin index (0..3).
 * @retval The two bit trigger field of that pin.
 */
static uint32 itype_field(uint32 pin)
{
    return ((GPIO_READ_REG(GPIOD, ITYPE0R) >> (pin * 2U)) & 0x03U);
}

/**
 * @brief  Read the IMR mask bit of one GPIOD pin.
 * @param  pin: pin index (0..3).
 * @retval The mask bit of that pin.
 */
static uint32 imr_bit(uint32 pin)
{
    return ((GPIO_READ_REG(GPIOD, IMR) >> pin) & 0x01U);
}

/**
 * @brief  Read the IMR mask bit of one GPIOD pin.
 * @param  pin: pin index (0..3).
 * @retval The mask bit of that pin (non zero when the line is masked).
 */
static uint32 is_masked(uint32 pin)
{
    return (imr_bit(pin) != 0U) ? 1U : 0U;
}

/**
 * @brief  Enable the GPIOD interrupt line in the PLIC (priority 1 = enabled).
 * @param  None
 * @retval None
 */
static void plic_Config(void)
{
    PLIC_InitTypeDef plic_init;

    __HAL_CLEAR_STRUCT(&plic_init);
    HAL_PLIC_StructInit(&plic_init);

    plic_init.PLIC_IRQChannel    = GPIOD_IRQn;
    plic_init.PLIC_IRQPriority   = 1U;
    plic_init.PLIC_IRQChannelCmd = PLIC_ENABLE;

    HAL_PLIC_Init(&plic_init);
}

/**
 * @brief  GPIOD port interrupt handler: strong override of the weak handler
 *         provided by the PLIC module.
 * @param  None
 * @retval None
 */
void GPIOD_IRQ_Handler(void)
{
    Cpu_Irq_Count++;
    HAL_GPIO_IRQHandler(GPIOD);
}

/**
 * @brief  GPIO interrupt line callback: accumulate the pins that fired.
 * @param  GPIO_Pin: pin mask of the interrupted port line.
 * @retval None
 */
void HAL_GPIOD_EXTI_Callback(uint16 GPIO_Pin)
{
    Callback_Mask |= (uint32)GPIO_Pin;
}

/**
 * @brief  Configure the system clock tree (PLL 180 MHz, as the original test).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef  SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef   SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    HAL_PMU_LDO2v5VOLSca(&hpmu, 0xf);
    HAL_PMU_LDO1v2VOLSca(&hpmu, 0xf);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it (CLKFRQ above), so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Clock tree order: this is the order the chip requires, and the vendor
       test case uses the same one.
         1. Write the bus clock dividers while the system clock is still the
            power-on source (FIRC), so that the new divider values are already
            in place when the faster clock arrives. Writing them AFTER the
            switch instead leaves the buses at their reset dividers for a
            moment at the new core clock: at 180 MHz that is
            AXI4Bus3 = 90 MHz and APBBus0 = 45 MHz, right at their ratings, and
            the core does not survive it (measured on the board: the core
            trapped before the divider write was reached, so no output was
            produced at all).
         2. Program the EFLASH controller clock: the controller must already
            know the final frequency while the code still runs from the flash.
         3. Then configure the PLL and switch the system clock to it; this call
            also updates SystemCoreClock and re-initializes the HAL time base. */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
