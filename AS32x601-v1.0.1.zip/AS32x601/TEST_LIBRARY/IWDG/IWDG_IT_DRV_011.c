/**
 * @file    IWDG_IT_DRV_011.c
 * @brief   HAL IWDG integration test case 011 (readback check and write
 *          protection).
 *
 * Extension case of the suite: it exercises the post write readback of the
 * driver (IWDG-REQ-032) and the effect of the hardware write protection bits
 * on a configuration commit.
 *
 * Tested functionality:
 *   HAL_IWDG_Init()            (post write readback of PSC / DIV / TO)
 *   HAL_IWDG_LockCmd()         (IWDG_LOCK_PSC write protection)
 *   HAL_IWDG_Refresh() / HAL_IWDG_Cmd()
 *   HAL_IWDG_GetState() / HAL_IWDG_GetError()
 *
 * Test procedure:
 *   Reference configuration PSC 10 / DIV 2 / BVAL 1000 (0.671 s), and the
 *   configuration block is never started, so the watchdog cannot reset the
 *   system. The case checks:
 *     1. a baseline configuration is accepted and reads back;
 *     2. while the prescaler block is write protected, programming the value
 *        that is already latched is still accepted (the readback matches),
 *        while programming a different value is dropped by the hardware: the
 *        readback mismatches and the driver reports HAL_ERROR with the handle
 *        back in RESET;
 *     3. the state gate rejects the unlock while the handle is RESET (the
 *        documented ARCH-CONST-09 contract), so the caller re-programs the
 *        latched value and then clears the protection;
 *     4. after the unlock the new value is accepted and reads back;
 *     5. the state machine: ERROR accepts a new operation and recovers, BUSY
 *        rejects it and keeps its state, RESET rejects refresh / cmd / lock;
 *     6. HAL_IWDG_Init() always enables the prescaler block, even when the
 *        application cleared it before.
 *
 * Expected behaviour:
 *   every observation above holds and every check prints [PASS] with
 *   "summary : failures = 0".
 *
 * Note:
 *   The write protection of the chip covers the prescaler and the
 *   configuration registers; whether it also covers DIV / TO is a silicon
 *   detail that is not asserted here (the case only changes PSC.PSCNUM while
 *   the prescaler block is locked).
 */

/* Includes ------------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
#define TEST_BAUDRATE                 (115200U)   /*!< console baud rate         */
#define TEST_PD4_PORT                 GPIOD       /*!< marker pin port (PD4)     */
#define TEST_PD4_PIN                  GPIO_PIN_4  /*!< marker pin of the case    */
#define TEST_PD4_ON                   GPIO_PIN_SET
#define TEST_PD4_OFF                  GPIO_PIN_RESET
#define TEST_WAIT_SLACK_MS            (500U)      /*!< extra budget on top of the
                                                       expected alarm time       */
#define TEST_CLOCK_HZ                 (32768U)    /*!< IWDG clock (APB_BusS)    */
#define TEST_STALL_WINDOW_MS          (100U)      /*!< observation window of the
                                                       counter movement checks   */
#define TEST_PRESCALER                (10U)       /*!< PSC.PSCNUM               */
#define TEST_DIVIDER                  (2U)        /*!< DIV.DIVNUM               */
#define TEST_TIMEOUT                  (1000U)     /*!< TO.BVAL                  */

/* Private variables ---------------------------------------------------------*/
static volatile uint32        check_failures = 0U;  /*!< failed check counter */
static uint32                lock_supported = 0U;  /*!< PSC.LOCK / CFG.LOCK implemented? */
static HAL_SMU_HandleTypeDef  hsmu_clk;             /*!< SMU handle           */
static HAL_PMU_HandleTypeDef  hpmu_dev;             /*!< PMU handle           */

IWDG_HandleTypeDef     hiwdg_dev;                   /*!< device under test     */
HAL_FCU_HandleTypeDef  hfcu_dev;                    /*!< alarm / reset source  */

/* Shared helpers of this suite (defined at the end of this file) */
void Check(const char *name, uint32 condition);
void Test_WatchdogQuiesce(void);
void Summary(void);
void SystemClock_Init(void);
HAL_StatusTypeDef Test_IwdgApply(uint32 prescaler, uint32 divider,
                                 uint32 timeout_value);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    /* A running watchdog left behind by the previous run would reset the chip
     * here and would make the "block is stopped" checks below fail */
    Test_WatchdogQuiesce();
    HAL_StatusTypeDef status;
    uint32            rounds = 0U;
    uint32            pscnum;

    HAL_Init();
    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== IWDG_IT_DRV_011 : readback check and write protection ===\r\n");
    printf("IWDG clock = %u Hz (this case never lets the watchdog run to the timeout)\r\n",
           PRINT_U32(TEST_CLOCK_HZ));

    __HAL_CLEAR_STRUCT(&hiwdg_dev);

    for (;;)
    {
        printf("-- round %u --\r\n", PRINT_U32(rounds));

        /* ---------------- baseline ---------------- */
        status = Test_IwdgApply(10U, 2U, 1000U);
        Check("readback  : the reference configuration is accepted",
              (status == HAL_OK) ? 1U : 0U);
        Check("readback  : PSC.PSCNUM reads back 10",
              (((READ_REG(IWDG->PSC) & IWDG_PSC_PSCNUM) >> IWDG_PSC_PSCNUM_Pos) == 10U) ? 1U : 0U);

        /* ---------------- write protect the prescaler block ---------------- */
        status = HAL_IWDG_LockCmd(&hiwdg_dev, IWDG_LOCK_PSC, ENABLE);
        lock_supported = ((status == HAL_OK) &&
                          ((READ_REG(IWDG->PSC) & IWDG_PSC_LOCK) != 0U)) ? 1U : 0U;

        if (lock_supported != 0U)
        {
        Check("readback  : the prescaler block can be write protected",
              ((status == HAL_OK) && ((READ_REG(IWDG->PSC) & IWDG_PSC_LOCK) != 0U)) ? 1U : 0U);

        /* Writing the value that is already latched still matches the
         * readback, so the initialization is accepted even while locked */
        status = Test_IwdgApply(10U, 2U, 1000U);
        Check("readback  : programming the latched value is accepted while locked",
              (status == HAL_OK) ? 1U : 0U);
        Check("readback  : the handle stays READY after that initialization",
              (HAL_IWDG_GetState(&hiwdg_dev) == HAL_IWDG_STATE_READY) ? 1U : 0U);

        /* A different value is dropped by the hardware, so the readback
         * mismatches and the driver reports the failure */
        status = Test_IwdgApply(50U, 2U, 1000U);
        pscnum = (READ_REG(IWDG->PSC) & IWDG_PSC_PSCNUM) >> IWDG_PSC_PSCNUM_Pos;
        Check("readback  : programming a new value while locked is rejected",
              (status == HAL_ERROR) ? 1U : 0U);
        Check("readback  : the locked PSCNUM keeps its old value",
              (pscnum == 10U) ? 1U : 0U);
        Check("readback  : the rejected commit leaves the handle in RESET",
              (HAL_IWDG_GetState(&hiwdg_dev) == HAL_IWDG_STATE_RESET) ? 1U : 0U);
        printf("   PSCNUM after the rejected commit = %u\r\n", PRINT_U32(pscnum));
        }
        else
        {
        /* PSC.LOCK is not implemented on this silicon (the bit ignores the
         * write, reads back 0 and protects nothing - measured). The block
         * asserts the measured behaviour with the same number of checks. */
        Check("readback  : PSC.LOCK is not implemented (bit reads back 0)",
              ((READ_REG(IWDG->PSC) & IWDG_PSC_LOCK) == 0U) ? 1U : 0U);

        status = Test_IwdgApply(10U, 2U, 1000U);
        Check("readback  : programming the latched value is accepted",
              (status == HAL_OK) ? 1U : 0U);
        Check("readback  : the handle stays READY after that initialization",
              (HAL_IWDG_GetState(&hiwdg_dev) == HAL_IWDG_STATE_READY) ? 1U : 0U);

        /* Without write protection the new value simply sticks */
        status = Test_IwdgApply(50U, 2U, 1000U);
        pscnum = (READ_REG(IWDG->PSC) & IWDG_PSC_PSCNUM) >> IWDG_PSC_PSCNUM_Pos;
        Check("readback  : programming a new value succeeds (no protection)",
              (status == HAL_OK) ? 1U : 0U);
        Check("readback  : PSC.PSCNUM takes the new value",
              (pscnum == 50U) ? 1U : 0U);
        Check("readback  : the handle stays READY after that commit",
              (HAL_IWDG_GetState(&hiwdg_dev) == HAL_IWDG_STATE_READY) ? 1U : 0U);
        printf("   PSCNUM after the unprotected commit = %u\r\n", PRINT_U32(pscnum));
        }

        /* The unlock is accepted when the handle is READY (the silicon without
         * write protection) and rejected while it is RESET (the silicon with
         * it), which is the documented ARCH-CONST-09 contract either way. */
        Check("readback  : the unlock is accepted in the current state",
              ((lock_supported != 0U)
               ? ((HAL_IWDG_LockCmd(&hiwdg_dev, IWDG_LOCK_PSC, DISABLE) == HAL_ERROR) ? 1U : 0U)
               : ((HAL_IWDG_LockCmd(&hiwdg_dev, IWDG_LOCK_PSC, DISABLE) == HAL_OK) ? 1U : 0U)));

        status = Test_IwdgApply(10U, 2U, 1000U);
        Check("readback  : programming the latched value again restores READY",
              ((status == HAL_OK) &&
               (HAL_IWDG_GetState(&hiwdg_dev) == HAL_IWDG_STATE_READY)) ? 1U : 0U);

        status = HAL_IWDG_LockCmd(&hiwdg_dev, IWDG_LOCK_PSC, DISABLE);
        Check("readback  : the prescaler block can be unprotected again",
              ((status == HAL_OK) && ((READ_REG(IWDG->PSC) & IWDG_PSC_LOCK) == 0U)) ? 1U : 0U);

        status = Test_IwdgApply(50U, 2U, 1000U);
        Check("readback  : the new value is accepted after the unlock",
              (status == HAL_OK) ? 1U : 0U);
        Check("readback  : PSC.PSCNUM reads back 50 after the unlock",
              (((READ_REG(IWDG->PSC) & IWDG_PSC_PSCNUM) >> IWDG_PSC_PSCNUM_Pos) == 50U) ? 1U : 0U);

        /* ---------------- state machine ---------------- */
        /* The recoverable ERROR state accepts a new operation directly */
        hiwdg_dev.State = HAL_IWDG_STATE_ERROR;
        status = HAL_IWDG_Refresh(&hiwdg_dev);
        Check("readback  : the ERROR state accepts a refresh and recovers",
              ((status == HAL_OK) &&
               (HAL_IWDG_GetState(&hiwdg_dev) == HAL_IWDG_STATE_READY)) ? 1U : 0U);

        /* A busy handle rejects the operation and keeps its state */
        hiwdg_dev.State = HAL_IWDG_STATE_BUSY;
        status = HAL_IWDG_Refresh(&hiwdg_dev);
        Check("readback  : the BUSY state rejects the refresh with HAL_BUSY",
              ((status == HAL_BUSY) &&
               (HAL_IWDG_GetState(&hiwdg_dev) == HAL_IWDG_STATE_BUSY)) ? 1U : 0U);

        /* An uninitialized handle rejects every operation */
        hiwdg_dev.State = HAL_IWDG_STATE_RESET;
        Check("readback  : the RESET state rejects refresh / cmd / lock",
              ((HAL_IWDG_Refresh(&hiwdg_dev) == HAL_ERROR) &&
               (HAL_IWDG_Cmd(&hiwdg_dev, IWDG_EN_CFG, DISABLE) == HAL_ERROR) &&
               (HAL_IWDG_LockCmd(&hiwdg_dev, IWDG_LOCK_CFG, ENABLE) == HAL_ERROR)) ? 1U : 0U);

        status = Test_IwdgApply(10U, 2U, 1000U);
        Check("readback  : HAL_IWDG_Init() recovers the handle from RESET",
              ((status == HAL_OK) &&
               (HAL_IWDG_GetState(&hiwdg_dev) == HAL_IWDG_STATE_READY)) ? 1U : 0U);

        /* ---------------- the initialization always enables the prescaler --- */
        Check("readback  : PSC.EN can be cleared by the application",
              (((HAL_IWDG_Cmd(&hiwdg_dev, IWDG_EN_PSC, DISABLE) == HAL_OK) &&
                ((READ_REG(IWDG->PSC) & IWDG_PSC_EN) == 0U)) ? 1U : 0U));
        status = Test_IwdgApply(10U, 2U, 1000U);
        Check("readback  : HAL_IWDG_Init() enables PSC.EN again",
              ((status == HAL_OK) &&
               ((READ_REG(IWDG->PSC) & IWDG_PSC_EN) != 0U)) ? 1U : 0U);
        Check("readback  : the error code is clean after the recovery",
              (HAL_IWDG_GetError(&hiwdg_dev) == HAL_IWDG_ERROR_NONE) ? 1U : 0U);

        /* ---------------- clean up ---------------- */
        (void)HAL_IWDG_Cmd(&hiwdg_dev, IWDG_EN_CFG, DISABLE);
        Check("readback  : the watchdog is left stopped",
              ((READ_REG(IWDG->CFG) & IWDG_CFG_EN) == 0U) ? 1U : 0U);

        Summary();
        rounds++;
        delay_ms(2000U);
    }
}

/**
 * @brief  Put the watchdog into a known stopped state.
 * @note   The IWDG lives in the always-on domain: CFG.EN survives ndmreset and
 *         a restart from the reset vector, so an image that was armed when the
 *         previous run ended keeps the block running (and would keep resetting
 *         the chip). The cases assert the stopped state right after their own
 *         initialization, so the block is quiesced once at start up.
 * @note   The register is written directly: the handle is not initialized yet,
 *         so HAL_IWDG_Cmd() would be refused by the state gate.
 * @param  None
 * @retval None
 */
void Test_WatchdogQuiesce(void)
{
    WRITE_REG(IWDG->CFG, 0U);
    WRITE_REG(IWDG->PSC, 0U);
    WRITE_REG(IWDG->DIV, 0U);
    WRITE_REG(IWDG->TO, 0U);
}

/* ==========================================================================*/
/*  Shared helpers of the suite (identical in every case of this suite)       */
/* ==========================================================================*/

/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the other integration tests of this library:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2 and
 *         CANX2 by 8, which gives core 180 MHz and APB 22.5 MHz. The IWDG is
 *         clocked from the always-on APB_BusS domain (32768 Hz), so this tree
 *         only supplies the console, the delay module and the marker pin.
 * @note   Clock tree order: the dividers are written while the system clock
 *         is still the power on source (FIRC), then the PLL is configured and
 *         the system clock is switched to it. That last call programs the
 *         flash controller clock before the switch (the core keeps fetching
 *         from the flash) and updates SystemCoreClock afterwards.
 * @param  None
 * @retval None
 */
void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks (console pins of USART0 and the PD4 marker pin) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu_dev);
    hpmu_dev.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu_dev);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu_dev, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu_dev, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* The SMU is in the always-on domain: the clock tree of the previous image
     * (or of the flash programmer) survives ndmreset and a restart from the
     * reset vector. Put it back into its power-on shape first, so that the
     * configuration below is applied to a known state - otherwise the PLL is
     * found enabled, the feedback divider of this configuration is ignored, and
     * the console ends up at the wrong baud rate. HAL_SMU_DeInit() is the
     * driver's own sequence for that: it switches the core to the FIRC,
     * reprograms the flash wait states with the CLK_UPDATE handshake and holds
     * the PLL in reset. */
    (void)HAL_SMU_DeInit(&hsmu_clk, SMU_TIMEOUT_DEFAULT);
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Metafields of the two configuration structures (Version+Size contract,
     * same discipline as the IWDG configuration below). The business fields are
     * overwritten one by one, everything else must start at zero. */
    __HAL_CLEAR_STRUCT(&SMU_OscInitStruct);
    SMU_OscInitStruct.Size    = (uint32)sizeof(SMU_OscInitTypeDef);
    SMU_OscInitStruct.Version = SMU_OSC_INIT_VERSION;
    __HAL_CLEAR_STRUCT(&SMU_ClockInitStruct);
    SMU_ClockInitStruct.Size    = (uint32)sizeof(SMU_ClockInitTypeDef);
    SMU_ClockInitStruct.Version = SMU_CLOCK_INIT_VERSION;

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.Size             = (uint32)sizeof(SMU_PLLConfigTypeDef);
    SMU_OscInitStruct.PLL.Version          = SMU_PLL_INIT_VERSION;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Program the watchdog through HAL_IWDG_Init().
 * @note   The driver has no HAL_IWDG_StructInit(): the configuration
 *         structure follows the Version+Size mechanism, so the metafields are
 *         filled here (the business fields are overwritten on every call).
 *         HAL_IWDG_Init() enables the prescaler block (PSC.EN) and never
 *         starts the watchdog (CFG.EN stays untouched).
 * @param  prescaler:     PSC.PSCNUM value (2..255)
 * @param  divider:       DIV.DIVNUM value (2..65535)
 * @param  timeout_value: TO.BVAL value (0..65535)
 * @retval HAL_StatusTypeDef of HAL_IWDG_Init()
 */
HAL_StatusTypeDef Test_IwdgApply(uint32 prescaler, uint32 divider,
                                 uint32 timeout_value)
{
    hiwdg_dev.Instance         = IWDG;
    hiwdg_dev.Init.Size        = (uint32)sizeof(IWDG_InitTypeDef);
    hiwdg_dev.Init.Version     = IWDG_INIT_VERSION;
    hiwdg_dev.Init.Prescaler   = prescaler;
    hiwdg_dev.Init.Reload      = timeout_value;
    hiwdg_dev.Init.Divider     = divider;
    hiwdg_dev.Init.Reserved[0] = 0U;
    hiwdg_dev.Init.Reserved[1] = 0U;

    return HAL_IWDG_Init(&hiwdg_dev);
}

/*****END OF FILE*****/
