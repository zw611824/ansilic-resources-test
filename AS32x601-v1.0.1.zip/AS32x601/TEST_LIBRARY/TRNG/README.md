# TRNG 应用与测试参考

供 skill 按需求检索 AS32x601 HAL 真随机数发生器（TRNG）示例。别名/关键词：TRNG、随机数、DRBG、熵源、ZEROIZE、GEN_NOISE、CREATE_STATE、GEN_RANDOM、RAND0–3、轮询、中断、回调、PLIC。共有 6 个独立用例。

HAL 依据：[头文件](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_trng.h)、[实现](../../HAL_LIBRARY/peripherals/src/as32x601_hal_trng.c)。原测试工程的 4_HAL_LIBRARY 未提供，尚不能确认原始链接版本；文中标出的源码与当前 SDK 差异须先解决再迁移。


## 实例与相关资源

本模块不单独列出外部通信引脚组。按实际功能核对实例、时钟、中断、内存或数据通路；关联 GPIO、定时器或其他外设时，再读取对应分支的引脚资料。具体资源与案例配置见下文。

## 生成前需确认的参数

已有工程、板级资料或用户已明确的值直接复用。仅对影响本次实现的缺失选择使用参数卡询问并等待答复；案例配置不能代替实际接线或应用参数。

| 参数 | 需要核对或确认的内容 |
|---|---|
| 输出要求 | 随机数长度、使用场景及读取方式 |
| 健康检查 | 就绪超时、错误状态与失败处理要求 |

## 按需求选择

| 用户需求 / 检索关键词 | 推荐用例 | 选择条件 / 需要补充的逻辑 |
|---|---|---|
| 最短路径：初始化后取一个随机数 | [003](TRNG_IT_DRV_003.c) | 用 `HAL_TRNG_GenerateRandomNumber()` 自动发 GEN_RANDOM、限时等待并返回；种子仍需先按 001 的命令序列建立 |
| 原始命令序列：零化、噪声、建态、生成 | [001](TRNG_IT_DRV_001.c) | 轮询模板，也是理解 DRBG 状态机的入口。每次上电须 ZEROIZE → GEN_NOISE → CREATE_STATE，之后才能 GEN_RANDOM |
| 中断方式执行完整命令序列 | [002](TRNG_IT_DRV_002.c) | 配 PLIC、`HAL_TRNG_ITConfig(ZEROIZED\|DONE\|GLBL)`，在 `TRNG_IRQ_Handler()` 中转发并确认；适合不想阻塞的初始化流程 |
| 中断方式单次生成 + 就绪回调 | [004](TRNG_IT_DRV_004.c) | `HAL_TRNG_GenerateRandomNumber_IT()` + `HAL_TRNG_ReadyDataCallback()`；BUSY/生命周期断言与 SDK 存在差异，见选用边界 |
| 结构/参数/生命周期/错误码自检 | [005](TRNG_IT_DRV_005.c) | 防御性自检，不是应用模板；可查句柄校验、状态门控、DeInit 行为 |
| 事件位、写 1 清除、结果归属 | [006](TRNG_IT_DRV_006.c) | 需要自己管理多个事件源或确认“中断入口不会误消费他人完成事件”时参考 |
| 熵源健康测试、KAT、重新播种 | 无完整应用模板 | 驱动有 `TRNG_COMMAND_RUN_KAT`、`RENEW_STATE`、`REFRESH_ADDIN` 等命令，但本目录没有针对性的应用流程；需按手册自行组织并验证 |
| 随机性质量认证/统计测试 | 无 | 用例只证明命令完成、数据变化和回调归属，不能证明熵质量；认证需外部统计工具和厂商资料 |

## 实现要点与案例配置

- TRNG 是命令驱动的 DRBG 状态机，没有单独的“使能位”。`HAL_TRNG_Init()` 只把 `CTRL.CMD` 置回 NOP；上电后必须先发 `TRNG_COMMAND_ZEROIZE`（等 ZEROIZED 事件）→ `TRNG_COMMAND_GEN_NOISE`（等 DONE）→ `TRNG_COMMAND_CREATE_STATE`（等 DONE），之后 `TRNG_COMMAND_GEN_RANDOM` 才有有效输出。
- 一次 GEN_RANDOM 产生 128 位，分四个 32 位寄存器：`HAL_TRNG_GetRandomNumber0()` … `GetRandomNumber3()`。轮询 API 返回一个 32 位字，同时缓存最后一块，可用 `HAL_TRNG_ReadLastRandomNumber()` 读取。
- 轮询流程：`HAL_TRNG_SendCommand()` → 轮询 `HAL_TRNG_GetITStatus()` 的 ZEROIZED/DONE → `HAL_TRNG_ClearITPendingBit()`。中断流程：`HAL_TRNG_ITConfig(TRNG_IT_ZEROIZED | TRNG_IT_DONE | TRNG_IT_GLBL, ENABLE)` → PLIC 使能 → `TRNG_IRQ_Handler()` 调 `HAL_TRNG_IRQHandler()`；完成事件由驱动/应用按所有权确认，ISTAT 为写 1 清除。
- 单次 API 的所有权：003 显示轮询等待会临时屏蔽并恢复 `IE.DONE`，并清除遗留的 stale DONE，避免与已打开的中断线抢同一个完成事件；004 的拒绝断言为用例预期，不能代替当前 SDK 的实际生命周期契约。
- 证据边界：事件到达、随机字变化、缓存字与 RAND 寄存器一致，能证明命令链和数据通路工作；不能证明随机性质量、熵源健康或抗预测性。KAT/健康测试在本组用例中未执行。

## 验证方法与适用边界

- 不要跳过 ZEROIZE/GEN_NOISE/CREATE_STATE 直接 GEN_RANDOM；状态机未建立时输出不可用。
- 轮询与中断共用完成位：应用若同时打开中断又用轮询 API，要按 003 的方式接受“轮询临时屏蔽 IE.DONE、返回后恢复”的语义，不要在外层再改 IE。
- SDK DeInit 关闭相关中断、清事件并复位句柄，再调用 MSP；不等于发 ZEROIZE 擦除 DRBG 内部状态或清空 RAND。重新使用需按设备序列建态，零化需求另发命令并确认。
- 004 断言 BUSY 时拒绝 DeInit，但 SDK 允许任意句柄状态尝试清理，锁占用时仍拒绝。生命周期与硬件中止语义需核对实际版本，不能概括为全部拒绝或全部可中止。
- ISTAT 写 1 清除：确认事件时只写自己拥有的位，避免误清其他事件；006 专门验证了这一点。
- 示例会打印生成值；应用若用于密钥等敏感用途，应移除相关日志并按实际需求管理缓冲。
- 中断是电平型链路（TRNG → PLIC），入口必须确认并清除事件，否则会反复进入。
- 高安全场景不要把这些示例当作随机数认证依据；需另行做 KAT、健康测试和熵评估。

## 按接口与辅助宏检索

| 接口 / 宏 | 参考用例 |
|---|---|
| `HAL_TRNG_StructInit` / `HAL_TRNG_Init` / `HAL_TRNG_DeInit` | [001](TRNG_IT_DRV_001.c)、[005](TRNG_IT_DRV_005.c) |
| `HAL_TRNG_SendCommand` | [001](TRNG_IT_DRV_001.c)、[003](TRNG_IT_DRV_003.c) |
| `HAL_TRNG_GenerateRandomNumber` / `HAL_TRNG_ReadLastRandomNumber` | [003](TRNG_IT_DRV_003.c) |
| `HAL_TRNG_GenerateRandomNumber_IT` / `HAL_TRNG_ReadyDataCallback` | [004](TRNG_IT_DRV_004.c) |
| `HAL_TRNG_IRQHandler` | [002](TRNG_IT_DRV_002.c)、[004](TRNG_IT_DRV_004.c) |
| `HAL_TRNG_ITConfig` / `HAL_TRNG_GetITStatus` / `HAL_TRNG_ClearITPendingBit` | [002](TRNG_IT_DRV_002.c)、[006](TRNG_IT_DRV_006.c) |
| `HAL_TRNG_GetRandomNumber0` … `HAL_TRNG_GetRandomNumber3` | [001](TRNG_IT_DRV_001.c)、[002](TRNG_IT_DRV_002.c) |
| `HAL_TRNG_GetState` / `HAL_TRNG_GetError` | [004](TRNG_IT_DRV_004.c)、[005](TRNG_IT_DRV_005.c) |
| `TRNG_COMMAND_ZEROIZE` / `GEN_NOISE` / `CREATE_STATE` / `GEN_RANDOM` | [001](TRNG_IT_DRV_001.c) |


本次为源码静态整理，未重新编译、未上板；源码里的历史测试注释不代表本次验证结果。
