/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_trng.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.4
 * Date:   2026/10/09
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/10/09     1.4     restore the " *" prefix of the history
 *                                                       continuation lines
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.3     align the module with the library
 *                                                       architecture spec (resource lock and
 *                                                       RTOS chapters): give the lock helper
 *                                                       a Timeout parameter and a NULL mutex
 *                                                       guard, add the shared handle validity
 *                                                       and state helpers, run the MSP
 *                                                       callbacks outside the locked region,
 *                                                       validate the configuration metafields
 *                                                       at run time, apply the busy / reset
 *                                                       state gate to the transfer
 *                                                       interfaces, report the guard path of
 *                                                       every locked entry point, yield the
 *                                                       CPU while polling and add the
 *                                                       blocking annotation of every public
 *                                                       prototype (the 1.2 note that they
 *                                                       stay in the source file only was
 *                                                       superseded by the library wide
 *                                                       convention)
 *     ANSILIC APPLICATION GROUP  2026/09/03     1.2     second compliance review:
 *                                                       rename the handle struct
 *                                                       tag to __HAL_TRNG_HandleTypeDef
 *                                                       (library convention, e.g.
 *                                                       SPI/CRC/QSPI); drop the
 *                                                       (BLOCKING) / (NON-BLOCKING)
 *                                                       annotations from the
 *                                                       function declarations in
 *                                                       the header (they stay in
 *                                                       the source file only, as
 *                                                       in every other library
 *                                                       header); switch the
 *                                                       function group comments
 *                                                       to @addtogroup; wrap the
 *                                                       TRNG_IT_xxx / TRNG_FLAG_xxx
 *                                                       aliases with (uint32) casts
 *                                                       (QSPI/CMU alias style);
 *                                                       re-lay out the lines that
 *                                                       exceeded 100 characters
 *     ANSILIC APPLICATION GROUP  2026/09/03     1.1     align with the library
 *                                                       conventions: include the
 *                                                       device layer through
 *                                                       as32x601.h (register
 *                                                       file is the monolithic
 *                                                       device header, no
 *                                                       trng_regs.h dependency);
 *                                                       add the module version
 *                                                       macro; add a minimal
 *                                                       TRNG_InitTypeDef
 *                                                       (Size/Version/Reserved)
 *                                                       and the Init handle
 *                                                       field; add the ErrorCode
 *                                                       field and the
 *                                                       HAL_TRNG_ErrorCode
 *                                                       constants and
 *                                                       HAL_TRNG_GetError();
 *                                                       guard every public
 *                                                       function against a NULL
 *                                                       handle; reorder
 *                                                       GenerateRandomNumber_IT
 *                                                       (enable the DONE
 *                                                       interrupt before
 *                                                       unlocking) and
 *                                                       IRQHandler (clear the
 *                                                       event flag before the
 *                                                       callback and update the
 *                                                       error code); annotate
 *                                                       the blocking behaviour
 *                                                       in the @brief lines
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the True Random Number
 *                  Generator (TRNG) peripheral, as a HAL peripheral driver
 *                  of this library:
 *                  - Initialization / de-initialization: HAL_TRNG_Init /
 *                    HAL_TRNG_DeInit, configuration structure handling;
 *                  - Control functions: HAL_TRNG_SendCommand() sends a
 *                    command (the TRNG operates as a command-driven DRBG
 *                    state machine: ZEROIZE -> GEN_NOISE -> CREATE_STATE
 *                    -> GEN_RANDOM); HAL_TRNG_GenerateRandomNumber()
 *                    sends the GEN_RANDOM command, waits for the DONE
 *                    interrupt status, reads the RAND0 register and
 *                    returns the 32-bit random number; the interrupt
 *                    variant HAL_TRNG_GenerateRandomNumber_IT() plus
 *                    HAL_TRNG_IRQHandler() and the callbacks
 *                    HAL_TRNG_ReadyDataCallback() /
 *                    HAL_TRNG_ErrorCallback();
 *                  - Random number retrieval: HAL_TRNG_GetRandomNumber0()
 *                    .. HAL_TRNG_GetRandomNumber3() read the four RAND0-3
 *                    registers (one DRBG generation outputs 128 bits,
 *                    split into four 32-bit random words);
 *                  - State / error reporting: HAL_TRNG_GetState() /
 *                    HAL_TRNG_GetError();
 *                  - Interrupt / flag management: HAL_TRNG_ITConfig() /
 *                    HAL_TRNG_GetITStatus() /
 *                    HAL_TRNG_ClearITPendingBit().
 *                  This driver depends on as32x601.h (device layer:
 *                  TRNG_TypeDef, register bit definitions) and on
 *                  as32x601_hal_def.h (HAL common types and utilities).
 *                  Note on the peripheral: the chip TRNG is command-driven
 *                  (it has no RNGEN enable bit: the peripheral is "started"
 *                  by issuing a command) and exposes no clock/seed error
 *                  status bits. Instead of a single DR register it provides
 *                  four 32-bit random registers RAND0-3. The interrupt
 *                  status register ISTAT carries five event bits (ZEROIZED
 *                  / KAT_COMPLETE / NOISE_RDY / ALARMED / DONE) and the
 *                  interrupt enable register IE adds a global gate (GLBL).
 *                  The TRNG is clocked by the AXILite4-Bus1 domain without
 *                  any SMU clock gating, but it has a dedicated PLIC
 *                  interrupt line (TRNG_IRQn = 0x0F): HAL_TRNG_MspInit()
 *                  is provided as an empty weak function where the user
 *                  enables the PLIC line and implements
 *                  TRNG_IRQ_Handler() calling HAL_TRNG_IRQHandler().
 * @complexity  Medium
 *              State machine + lock, blocking + interrupt modes.
 */
#ifndef __AS32X601_HAL_TRNG_H
#define __AS32X601_HAL_TRNG_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "as32x601.h"               /* TRNG_TypeDef, TRNG, register bits      */
#include "as32x601_hal_def.h"       /* HAL_StatusTypeDef, HAL_LockTypeDef     */

/* Exported constants --------------------------------------------------------*/

/**
 * @brief TRNG HAL driver module version.
 * @note  0x0100U = V1.0. Bumped only on breaking API changes (architecture
 *        spec COMPAT-13/14/15).
 */
#define __HAL_TRNG_MODULE_VERSION  0x0100U

/* Exported types ------------------------------------------------------------*/

/** @defgroup TRNG_Exported_Types TRNG Exported Types
  * @{
  */

/**
 * @brief TRNG configuration structure definition.
 * @note  The TRNG peripheral is command-driven and exposes no configuration
 *        register: HAL_TRNG_Init() only clears the CTRL.CMD command field
 *        (equivalent to the NOP command) and there is no business field to
 *        configure. The structure is kept for the library-wide Handle layout
 *        (Instance -> Init -> Lock -> State -> ErrorCode) and follows the
 *        Version+Size compatibility mechanism (architecture spec section
 *        22): the user must clear the structure (__HAL_CLEAR_STRUCT /
 *        memset) and set the Size and Version metafields (see
 *        HAL_TRNG_StructInit()).
 */
typedef struct
{
    uint32  Size;                   /*!< sizeof(TRNG_InitTypeDef), must be set by the user
                                         after clearing the structure           */
    uint32  Version;                /*!< Structure semantic version: @ref TRNG_INIT_VERSION
                                         (TRNG_INIT_V1 = 0x0100U)                */
    uint32  Reserved[2];            /*!< Reserved for future extension (must be 0) */
} TRNG_InitTypeDef;

/**
 * @brief TRNG / init structure version macros.
 * @note  TRNG_INIT_V1 is the current version. Future versions (e.g. V2 with
 *        new fields) must be appended after the existing fields without
 *        changing the layout (architecture spec section 22.5).
 */
#define TRNG_INIT_V1  0x0100U   /*!< TRNG Init structure version V1.0 */
#define TRNG_INIT_VERSION  TRNG_INIT_V1   /*!< Current TRNG Init structure version */

/**
 * @brief  TRNG State structure definition
 * @note   The TRNG runs a command-driven DRBG state machine: the state
 *         transitions to BUSY while a random number is being generated and
 *         back to READY on completion (or ERROR / TIMEOUT on failure).
 */
typedef enum
{
    HAL_TRNG_STATE_RESET   = 0x00U,     /*!< TRNG not yet initialized */
    HAL_TRNG_STATE_READY   = 0x01U,     /*!< TRNG initialized and ready */
    HAL_TRNG_STATE_BUSY    = 0x02U,     /*!< TRNG internal process ongoing */
    HAL_TRNG_STATE_TIMEOUT = 0x03U,     /*!< TRNG timeout state */
    HAL_TRNG_STATE_ERROR   = 0x04U      /*!< TRNG error state */
} HAL_TRNG_StateTypeDef;

/**
 * @brief  TRNG Handle Structure definition
 * @note   Field order follows the library handle layout (Instance -> Init ->
 *         Lock -> State -> ErrorCode -> module fields). RandomNumber stores
 *         the last 32-bit random word read from the RAND0 register. The
 *         error code field aggregates the error sources observed during the
 *         current operation (HAL_TRNG_ERROR_xxx, cleared on the next
 *         operation start).
 */
typedef struct __HAL_TRNG_HandleTypeDef
{
    TRNG_TypeDef              *Instance;      /*!< Register base address */
    TRNG_InitTypeDef          Init;           /*!< TRNG configuration parameters */
    HAL_LockTypeDef           Lock;           /*!< TRNG locking object */
    __IO HAL_TRNG_StateTypeDef State;         /*!< TRNG communication state */
    __IO uint32               ErrorCode;      /*!< TRNG error code */
    uint32                    RandomNumber;   /*!< Last generated random number */
#if (USE_RTOS == 1)
    HAL_MutexTypeDef          LockMutex;      /*!< RTOS mutex handle (created by the
                                                   user porting layer, e.g. in
                                                   HAL_TRNG_MspInit)               */
#endif /* USE_RTOS */
} TRNG_HandleTypeDef;
/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @defgroup TRNG_Exported_Constants TRNG Exported Constants
  * @{
  */

/** @defgroup TRNG_Error_Code TRNG Error Code
  * @{
  */
#define HAL_TRNG_ERROR_NONE          ((uint32)0x00000000U)   /*!< No error          */
#define HAL_TRNG_ERROR_TIMEOUT       ((uint32)0x00000001U)   /*!< Flag wait timeout */
#define HAL_TRNG_ERROR_ALARMED       ((uint32)0x00000002U)   /*!< TRNG alarmed      */
#define HAL_TRNG_ERROR_INVALID_PARAM ((uint32)0x00000004U)   /*!< Invalid parameter or rejected operation */
/**
  * @}
  */

/** @defgroup TRNG_Commands TRNG Commands
  * @brief  TRNG command definitions. The TRNG runs as a command-driven
  *         DRBG (Deterministic Random Bit Generator) state machine: the
  *         CTRL.CMD 4-bit field selects the command to execute. The
  *         command values map the CTRL.CMD field (see the TRNG_CTRL_CMD_*
  *         bit definitions in the device layer header).
  * @note   The command is issued with HAL_TRNG_SendCommand(). Several
  *         commands (e.g. ZEROIZE / GEN_NOISE / CREATE_STATE / GEN_RANDOM)
  *         complete by setting the DONE (or ZEROIZED) event bit in the
  *         ISTAT register, which the output-side functions
  *         HAL_TRNG_GenerateRandomNumber() wait for and clear.
  * @{
  */
#define TRNG_COMMAND_NOP            ((uint32)0x00000000U)  /*!< No command */
#define TRNG_COMMAND_GEN_NOISE      ((uint32)0x00000001U)  /*!< Generate full-entropy
                                                                seed from noise */
#define TRNG_COMMAND_GEN_NONCE      ((uint32)0x00000002U)  /*!< Generate seed from a
                                                                host-written nonce */
#define TRNG_COMMAND_CREATE_STATE   ((uint32)0x00000003U)  /*!< Move DRBG to create state */
#define TRNG_COMMAND_RENEW_STATE    ((uint32)0x00000004U)  /*!< Move DRBG to renew state */
#define TRNG_COMMAND_REFRESH_ADDIN  ((uint32)0x00000005U)  /*!< Move DRBG to refresh addin */
#define TRNG_COMMAND_GEN_RANDOM     ((uint32)0x00000006U)  /*!< Generate random numbers */
#define TRNG_COMMAND_ADVANCE_STATE  ((uint32)0x00000007U)  /*!< Advance DRBG state */
#define TRNG_COMMAND_RUN_KAT        ((uint32)0x00000008U)  /*!< Run KAT on DRBG or entropy source */
#define TRNG_COMMAND_ZEROIZE        ((uint32)0x0000000FU)  /*!< Zeroize */
/**
  * @}
  */

/** @defgroup TRNG_IT_Definitions TRNG Interrupt Enable Definitions
  * @brief  TRNG interrupt enable definitions. The values map the TRNG_IE
  *         register bits (one bit per event source plus the global gate).
  *         The interrupt is enabled with HAL_TRNG_ITConfig() or
  *         __HAL_TRNG_ENABLE_IT().
  * @{
  */
#define TRNG_IT_ZEROIZED            ((uint32)TRNG_IE_ZEROIZED)      /*!< Zeroized interrupt
                                                                           enable */
#define TRNG_IT_KAT_COMPLETE        ((uint32)TRNG_IE_KAT_COMPLETED) /*!< KAT complete interrupt
                                                                           enable */
#define TRNG_IT_NOISE_RDY           ((uint32)TRNG_IE_NOISE_RDY)     /*!< Noise ready interrupt
                                                                           enable */
#define TRNG_IT_ALARMED             ((uint32)TRNG_IE_ALARMS)        /*!< Alarmed interrupt enable */
#define TRNG_IT_DONE                ((uint32)TRNG_IE_DONE)          /*!< Done interrupt enable */
#define TRNG_IT_GLBL                ((uint32)TRNG_IE_GLBL)          /*!< Global interrupt enable */
/**
  * @}
  */

/** @defgroup TRNG_Flags_Definitions TRNG Flag Definitions
  * @brief  TRNG flag definitions. The values map the TRNG_ISTAT register
  *         bits. The ISTAT bits are read as status / interrupt source
  *         flags and cleared by writing a 1 (the device layer names them
  *         TRNG_ISTAT_*, kept as the single source for both the IT status
  *         and the flag query APIs).
  * @{
  */
#define TRNG_FLAG_ZEROIZED          ((uint32)TRNG_ISTAT_ZEROIZED)     /*!< Zeroized interrupt
                                                                             status */
#define TRNG_FLAG_KAT_COMPLETE      ((uint32)TRNG_ISTAT_KAT_COMPLETED) /*!< KAT complete interrupt
                                                                               status */
#define TRNG_FLAG_NOISE_RDY         ((uint32)TRNG_ISTAT_NOISE_RDY)    /*!< Noise ready interrupt
                                                                             status */
#define TRNG_FLAG_ALARMED           ((uint32)TRNG_ISTAT_ALARMS)       /*!< Alarmed interrupt
                                                                             status */
#define TRNG_FLAG_DONE              ((uint32)TRNG_ISTAT_DONE)         /*!< Done interrupt status */
/**
  * @}
  */

/**
  * @}
  */

/* Exported macros -----------------------------------------------------------*/

/** @defgroup TRNG_Exported_Macros TRNG Exported Macros
  * @{
  */

/**
 * @brief  Enables the selected TRNG interrupt.
 * @param  __HANDLE__: TRNG Handle
 * @param  __IT__: TRNG interrupt to enable (TRNG_IT_*)
 * @retval None
 */
#define __HAL_TRNG_ENABLE_IT(__HANDLE__, __IT__)    SET_BIT((__HANDLE__)->Instance->IE, (__IT__))

/**
 * @brief  Disables the selected TRNG interrupt.
 * @param  __HANDLE__: TRNG Handle
 * @param  __IT__: TRNG interrupt to disable (TRNG_IT_*)
 * @retval None
 */
#define __HAL_TRNG_DISABLE_IT(__HANDLE__, __IT__)   CLEAR_BIT((__HANDLE__)->Instance->IE, (__IT__))

/**
 * @brief  Checks whether the specified TRNG interrupt status has occurred.
 * @note   The status flags are read from the ISTAT register. The DONE bit
 *         is the completion flag of the issued command.
 * @param  __HANDLE__: TRNG Handle
 * @param  __IT__: TRNG interrupt status to check (TRNG_FLAG_*)
 * @retval The new state of __IT__ (SET or RESET).
 */
#define __HAL_TRNG_GET_IT(__HANDLE__, __IT__)       \
    (READ_BIT((__HANDLE__)->Instance->ISTAT, (__IT__)) != 0U)

/**
 * @brief  Clears the selected TRNG interrupt status flag.
 * @note   The ISTAT bits are cleared by writing a 1.
 * @param  __HANDLE__: TRNG Handle
 * @param  __IT__: TRNG interrupt status to clear (TRNG_FLAG_*)
 * @retval None
 */
#define __HAL_TRNG_CLEAR_IT(__HANDLE__, __IT__)     SET_BIT((__HANDLE__)->Instance->ISTAT, (__IT__))

/**
 * @brief  Checks whether the specified TRNG flag is set.
 * @param  __HANDLE__: TRNG Handle
 * @param  __FLAG__: TRNG flag to check (TRNG_FLAG_*)
 * @retval The new state of __FLAG__ (SET or RESET).
 */
#define __HAL_TRNG_GET_FLAG(__HANDLE__, __FLAG__)   \
    (READ_BIT((__HANDLE__)->Instance->ISTAT, (__FLAG__)) != 0U)

/**
 * @brief  Clears the selected TRNG flag.
 * @note   The ISTAT bits are cleared by writing a 1.
 * @param  __HANDLE__: TRNG Handle
 * @param  __FLAG__: TRNG flag to clear (TRNG_FLAG_*)
 * @retval None
 */
#define __HAL_TRNG_CLEAR_FLAG(__HANDLE__, __FLAG__) \
    SET_BIT((__HANDLE__)->Instance->ISTAT, (__FLAG__))

/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/

/** @addtogroup TRNG_Exported_Functions TRNG Exported Functions
  * @{
  */

/** @addtogroup TRNG_Exported_Functions_Group1 Initialization and de-initialization functions
  *  @brief    Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Fills each TRNG_InitStruct member with its default value. (NON-BLOCKING)
 * @param  TRNG_InitStruct: pointer to a TRNG_InitTypeDef structure which
 *         will be initialized (only the Size / Version metafields and the
 *         reserved fields are set).
 * @retval None
 */
void HAL_TRNG_StructInit(TRNG_InitTypeDef *TRNG_InitStruct);

/**
 * @brief  Initializes the TRNG peripheral. (NON-BLOCKING)
 * @note   The TRNG is command-driven: there is no enable bit. HAL_TRNG_Init()
 *         clears the CTRL.CMD command field (equivalent to issuing the NOP
 *         command) so that the DRBG state machine starts from an idle state.
 *         The DRBG state machine must then be initialized by sending the
 *         ZEROIZE -> GEN_NOISE -> CREATE_STATE command sequence before any
 *         random number can be generated (see HAL_TRNG_SendCommand()).
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure that contains
 *                the configuration information for TRNG.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_TRNG_Init(TRNG_HandleTypeDef *htrng);

/**
 * @brief  De-initializes the TRNG peripheral. (NON-BLOCKING)
 * @note   The TRNG has no clock gating to disable: the de-initialization
 *         clears the interrupt enables and the interrupt status flags.
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure that contains
 *                the configuration information for TRNG.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_TRNG_DeInit(TRNG_HandleTypeDef *htrng);

/**
 * @brief  Initializes the TRNG MSP. Weak empty function; the user (NON-BLOCKING)
 *         implements the low level hardware initialization.
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure that contains
 *                the configuration information for TRNG.
 * @retval None
 */
void HAL_TRNG_MspInit(TRNG_HandleTypeDef *htrng);

/**
 * @brief  De-initializes the TRNG MSP. Weak empty function; the user (NON-BLOCKING)
 *         implements the low level hardware de-initialization.
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure that contains
 *                the configuration information for TRNG.
 * @retval None
 */
void HAL_TRNG_MspDeInit(TRNG_HandleTypeDef *htrng);
/**
  * @}
  */

/** @addtogroup TRNG_Exported_Functions_Group2 Control functions
  *  @brief    Control functions
  * @{
  */

/**
 * @brief  Sends a command to the command-driven DRBG state machine. (NON-BLOCKING)
 * @note   The TRNG runs as a command-driven DRBG: the CTRL.CMD 4-bit field
 *         selects the command. This function writes the command only; the
 *         completion is observed in the ISTAT register (DONE or ZEROIZED
 *         event bit). The DRBG state machine must be initialized with the
 *         ZEROIZE -> GEN_NOISE -> CREATE_STATE sequence before any random
 *         number can be generated.
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @param  Command: TRNG command to send. This parameter can be one of the
 *                  following values:
 *                    @arg TRNG_COMMAND_NOP
 *                    @arg TRNG_COMMAND_GEN_NOISE
 *                    @arg TRNG_COMMAND_GEN_NONCE
 *                    @arg TRNG_COMMAND_CREATE_STATE
 *                    @arg TRNG_COMMAND_RENEW_STATE
 *                    @arg TRNG_COMMAND_REFRESH_ADDIN
 *                    @arg TRNG_COMMAND_GEN_RANDOM
 *                    @arg TRNG_COMMAND_ADVANCE_STATE
 *                    @arg TRNG_COMMAND_RUN_KAT
 *                    @arg TRNG_COMMAND_ZEROIZE
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_TRNG_SendCommand(TRNG_HandleTypeDef *htrng, uint32 Command);

/**
 * @brief  Generates a 32-bit random number in polling mode. (BLOCKING)
 * @note   The DRBG state machine must be initialized first. This function
 *         issues the GEN_RANDOM command, waits for the DONE event flag,
 *         clears it and reads the RAND0 register. Each read of the RAND0
 *         register is not automatically cleared; flag clearing is done
 *         explicitly.
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @param  random32bit: pointer to generated random number variable if
 *                      successful.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_TIMEOUT.
 */
HAL_StatusTypeDef HAL_TRNG_GenerateRandomNumber(TRNG_HandleTypeDef *htrng, uint32 *random32bit);

/**
 * @brief  Generates a 32-bit random number in interrupt mode. (NON-BLOCKING / IT)
 * @note   The DRBG state machine must be initialized first. This function
 *         issues the GEN_RANDOM command and enables the DONE interrupt;
 *         the random number is read in HAL_TRNG_IRQHandler() and returned
 *         through the HAL_TRNG_ReadyDataCallback().
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_TRNG_GenerateRandomNumber_IT(TRNG_HandleTypeDef *htrng);

/**
 * @brief  Reads the RAND0 random number register. (NON-BLOCKING)
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @retval 32-bit random number.
 */
uint32 HAL_TRNG_GetRandomNumber0(TRNG_HandleTypeDef *htrng);

/**
 * @brief  Reads the RAND1 random number register. (NON-BLOCKING)
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @retval 32-bit random number.
 */
uint32 HAL_TRNG_GetRandomNumber1(TRNG_HandleTypeDef *htrng);

/**
 * @brief  Reads the RAND2 random number register. (NON-BLOCKING)
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @retval 32-bit random number.
 */
uint32 HAL_TRNG_GetRandomNumber2(TRNG_HandleTypeDef *htrng);

/**
 * @brief  Reads the RAND3 random number register. (NON-BLOCKING)
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @retval 32-bit random number.
 */
uint32 HAL_TRNG_GetRandomNumber3(TRNG_HandleTypeDef *htrng);

/**
 * @brief  Reads the last generated random number. (NON-BLOCKING)
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @retval random value.
 */
uint32 HAL_TRNG_ReadLastRandomNumber(TRNG_HandleTypeDef *htrng);

/**
 * @brief  Enables or disables the selected TRNG interrupt. (NON-BLOCKING)
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @param  ITType: TRNG interrupt type. This parameter can be one of the
 *                 following values (TRNG_IT_*):
 *                    @arg TRNG_IT_ZEROIZED
 *                    @arg TRNG_IT_KAT_COMPLETE
 *                    @arg TRNG_IT_NOISE_RDY
 *                    @arg TRNG_IT_ALARMED
 *                    @arg TRNG_IT_DONE
 *                    @arg TRNG_IT_GLBL
 * @param  NewState: ENABLE or DISABLE.
 * @retval None
 */
void HAL_TRNG_ITConfig(TRNG_HandleTypeDef *htrng, uint32 ITType, FunctionalState NewState);

/**
 * @brief  Gets the TRNG interrupt status. (NON-BLOCKING)
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @param  IT: TRNG interrupt state. This parameter can be one of the
 *             following values (TRNG_FLAG_*):
 *               @arg TRNG_FLAG_ZEROIZED
 *               @arg TRNG_FLAG_KAT_COMPLETE
 *               @arg TRNG_FLAG_NOISE_RDY
 *               @arg TRNG_FLAG_ALARMED
 *               @arg TRNG_FLAG_DONE
 * @retval FlagStatus: SET or RESET.
 */
FlagStatus HAL_TRNG_GetITStatus(TRNG_HandleTypeDef *htrng, uint32 IT);

/**
 * @brief  Clears the TRNG interrupt pending bit. (NON-BLOCKING)
 * @note   The ISTAT flags are cleared by writing a 1.
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @param  ClearIT: TRNG interrupt pending bit. This parameter can be one
 *                  of the following values (TRNG_FLAG_*):
 *                    @arg TRNG_FLAG_ZEROIZED
 *                    @arg TRNG_FLAG_KAT_COMPLETE
 *                    @arg TRNG_FLAG_NOISE_RDY
 *                    @arg TRNG_FLAG_ALARMED
 *                    @arg TRNG_FLAG_DONE
 * @retval None
 */
void HAL_TRNG_ClearITPendingBit(TRNG_HandleTypeDef *htrng, uint32 ClearIT);

/**
 * @brief  Handles the TRNG interrupt request. (NON-BLOCKING / IT)
 * @note   The TRNG interrupt status register ISTAT carries five event bits.
 *         The DONE bit is the completion flag of the issued command: the
 *         HAL_TRNG_GenerateRandomNumber_IT() flow uses it as "data ready".
 *         The ALARMED bit is reported through HAL_TRNG_ErrorCallback().
 *         The ZEROIZED / KAT_COMPLETE / NOISE_RDY event bits are simply
 *         cleared (they are normally polled in blocking flows). The user
 *         must implement TRNG_IRQ_Handler() to dispatch to this handler.
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @retval None
 */
void HAL_TRNG_IRQHandler(TRNG_HandleTypeDef *htrng);

/**
 * @brief  Data Ready callback in non-blocking mode (WEAK). (NON-BLOCKING)
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @param  random32bit: generated random number.
 * @retval None
 */
void HAL_TRNG_ReadyDataCallback(TRNG_HandleTypeDef *htrng, uint32 random32bit);

/**
 * @brief  TRNG error callback (WEAK). (NON-BLOCKING)
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @retval None
 */
void HAL_TRNG_ErrorCallback(TRNG_HandleTypeDef *htrng);
/**
  * @}
  */

/** @addtogroup TRNG_Exported_Functions_Group3 Peripheral State functions
  *  @brief    Peripheral State functions
  * @{
  */

/**
 * @brief  Returns the TRNG state. (NON-BLOCKING)
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @retval HAL_TRNG_StateTypeDef: TRNG state.
 */
HAL_TRNG_StateTypeDef HAL_TRNG_GetState(TRNG_HandleTypeDef *htrng);

/**
 * @brief  Returns the TRNG error code. (NON-BLOCKING)
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @retval uint32: the TRNG error code (HAL_TRNG_ERROR_xxx).
 */
uint32 HAL_TRNG_GetError(TRNG_HandleTypeDef *htrng);
/**
  * @}
  */

/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/
/** @defgroup TRNG_Private_Macros TRNG Private Macros
  * @{
  */
#define IS_TRNG_ALL_INSTANCE(INSTANCE) (((INSTANCE) == TRNG))
#define IS_TRNG_COMMAND(COMMAND)       (((COMMAND) == TRNG_COMMAND_NOP)       || \
                                        ((COMMAND) == TRNG_COMMAND_GEN_NOISE) || \
                                        ((COMMAND) == TRNG_COMMAND_GEN_NONCE) || \
                                        ((COMMAND) == TRNG_COMMAND_CREATE_STATE) || \
                                        ((COMMAND) == TRNG_COMMAND_RENEW_STATE) || \
                                        ((COMMAND) == TRNG_COMMAND_REFRESH_ADDIN) || \
                                        ((COMMAND) == TRNG_COMMAND_GEN_RANDOM) || \
                                        ((COMMAND) == TRNG_COMMAND_ADVANCE_STATE) || \
                                        ((COMMAND) == TRNG_COMMAND_RUN_KAT) || \
                                        ((COMMAND) == TRNG_COMMAND_ZEROIZE))
#define IS_TRNG_IT(IT)                 (((IT) == TRNG_IT_ZEROIZED)   || \
                                        ((IT) == TRNG_IT_KAT_COMPLETE) || \
                                        ((IT) == TRNG_IT_NOISE_RDY)  || \
                                        ((IT) == TRNG_IT_ALARMED)    || \
                                        ((IT) == TRNG_IT_DONE)       || \
                                        ((IT) == TRNG_IT_GLBL))
#define IS_TRNG_FLAG(FLAG)             (((FLAG) == TRNG_FLAG_ZEROIZED) || \
                                        ((FLAG) == TRNG_FLAG_KAT_COMPLETE) || \
                                        ((FLAG) == TRNG_FLAG_NOISE_RDY) || \
                                        ((FLAG) == TRNG_FLAG_ALARMED)  || \
                                        ((FLAG) == TRNG_FLAG_DONE))
/**
  * @}
  */

/* Shared internal functions --------------------------------------------------*/
/** @defgroup TRNG_Shared_Internal_Functions TRNG Shared Internal Functions
  * @brief    Helpers shared by the TRNG driver and the user callbacks
  *           (Tier 3). They are not part of the public API and shall not be
  *           called by the application.
  * @{
  */
/**
 * @brief  Checks whether the TRNG handle and its instance are valid.
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
uint32 TRNG_HandleIsValid(TRNG_HandleTypeDef *htrng);

/**
 * @brief  Checks whether the handle accepts a new operation (ARCH-CONST-09).
 * @note   A handle that is BUSY (an operation is ongoing in another context)
 *         rejects the call with HAL_BUSY, an uninitialized handle (RESET) with
 *         HAL_ERROR, while the recoverable states (TIMEOUT / ERROR) accept it
 *         directly.
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef TRNG_CheckState(TRNG_HandleTypeDef *htrng);

/**
 * @brief  Lock the handle (RTOS mutex or single core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_TRNG_MspInit()). The bare metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; the value is passed to HAL_MutexAcquire() as
 *         is (RTOS ticks; HAL_MAX_DELAY means an infinite wait).
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef TRNG_LockHandle(TRNG_HandleTypeDef *htrng, uint32 Timeout);

/**
 * @brief  Unlock the handle.
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @retval None
 */
void TRNG_UnlockHandle(TRNG_HandleTypeDef *htrng);
/**
  * @}
  */

/**
  * @}
  */

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_TRNG_H */

/*****END OF FILE*****/
