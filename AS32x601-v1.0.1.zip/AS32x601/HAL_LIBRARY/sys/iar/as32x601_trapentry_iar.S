; /*
;  *   __ _   _ __    ___  (_) | | (_)   ___
;  *  / _` | | '_ \  / __| | | | | | |  / __|
;  * | (_| | | | | | \__ \ | | | | | | | (__
;  *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
;  *
;  * Copyright (C):  	Xiamen Guoke Anxin Technology Co., LTD
;  * FileName:     	as32x601_trapentry_iar.S
;  * Author:          ANSILIC APPLICATION GROUP
;  * Version:         V1.3
;  * Date:			2026/10/08
;  * History:
;  *               <author>           <time>    <version >      <desc>
;  *     ANSILIC APPLICATION GROUP  2026/08/17     1.0     refactor per AS32_HAL_trap_entry_requirements_specification V3.1:
;  *                                                       full ABI context save (GPRs + FP + fcsr),
;  *                                                       mstatus/mepc snapshot, mcause decode,
;  *                                                       PLIC claim/complete handshake, weak dispatch,
;  *                                                       stack-underflow guard -> fatal
;  *     ANSILIC APPLICATION GROUP  2026/08/18     1.1     optional dedicated interrupt stack for RTOS
;  *                                                       (HAL_INTERRUPT_STACK_SIZE>0): mscratch swap
;  *                                                       between task sp and ISR stack top, stack
;  *                                                       guard against _isr_stack_bottom, self-contained
;  *                                                       .bss.isr_stack section
;  *     ANSILIC APPLICATION GROUP  2026/10/08     1.2     fix the dedicated interrupt-stack
;  *                                                       section directive so the RTOS
;  *                                                       configuration assembles: the dotted
;  *                                                       section name is written in the
;  *                                                       assembler's quoted form (backticks)
;  *                                                       and the alignment argument becomes
;  *                                                       NOROOT(4) - 2^4 = 16 byte, the
;  *                                                       alignment sp keeps at the handler
;  *                                                       call point; the previous NOROOT(16)
;  *                                                       asked for 64 KB, and the unquoted
;  *                                                       dotted name was rejected by the
;  *                                                       assembler
;  *     ANSILIC APPLICATION GROUP  2026/10/08     1.3     harden the entry: align the dedicated interrupt-stack
                                                           top to 16 bytes and point both reserved
                                                           dispatch-table slots at 0 so a hit completes the
                                                           claimed source before the hook runs (the table
                                                           comments now state why)
;  * Description:     This file provides the RISC-V trap/interrupt entry functions
;  *                  for the AS32x601 (IAR toolchain).
;  *
;  *                  Pipeline (per AS32_HAL_trap_entry_requirements_specification V3.1):
;  *                    TrapEntry (CB-ENTRY)
;  *                      -> SAVE_CONTEXT (CB-SAVE)
;  *                      -> mcause decode (CB-DECODE)
;  *                      -> interrupt path: MSI/MTI direct dispatch,
;  *                         MEI: PLIC claim -> dispatch table -> complete (CB-DISPATCH),
;  *                         table miss -> pending clear + default hook (CB-DEFAULT)
;  *                      -> exception path: mtval snapshot, exception table dispatch (CB-EXCEPT),
;  *                         unregistered/unknown -> fatal loop (CB-FATAL)
;  *                      -> RESTORE_CONTEXT (CB-RESTORE) -> mret (CB-RETURN)
;  *
;  *                  Nesting policy: NOT nested (interrupts stay disabled during
;  *                  the whole trap processing; matches as32x601_core.h INTNEST=0).
;  *                  Vector mode: direct (startup configures mtvec = TrapEntry).
;  */

#define REGBYTES  4
#define STORE     sw
#define LOAD      lw

; ============================================================================
; RTOS support: dedicated interrupt stack switch
; ----------------------------------------------------------------------------
; HAL_INTERRUPT_STACK_SIZE:
;   0 (default) : no stack switch.  The trap frame is pushed on the task
;                 stack (original behaviour, fine for bare-metal single-task
;                 applications).
;   > 0         : the trap entry switches to a dedicated interrupt stack of
;                 HAL_INTERRUPT_STACK_SIZE bytes (defined below) so that
;                 interrupt handling no longer consumes the task stack
;                 (required for RTOS where task stacks are small and may be
;                 switched by the scheduler).
;
; Configuration source (priority order):
;   1. "as32x601_hal_conf.h" (the user copies as32x601_hal_conf_template.h
;      into the application folder and tunes USE_RTOS there; this file is
;      auto-included through the preprocessor has_include feature when found
;      on the include path and HAL_INTERRUPT_STACK_SIZE is derived from
;      USE_RTOS).
;   2. Build option -DHAL_INTERRUPT_STACK_SIZE=xxx (overrides the file).
;   If neither is present the default 0 applies (bare-metal behaviour).
;
; Mechanism (standard RISC-V mscratch swap):
;   - mscratch holds the interrupt stack TOP in normal (non-trap) context;
;     the startup file initializes it (csrw mscratch, _isr_stack_top) before
;     enabling global interrupts.
;   - On trap entry:  csrrw sp, mscratch, sp
;       -> sp = interrupt stack top, mscratch = task sp (saved for return).
;   - On trap exit:   csrrw sp, mscratch, sp
;       -> sp = task sp, mscratch = interrupt stack top (self-restored).
;   - While a dedicated ISR stack is used, mscratch no longer carries the
;     frame base; handlers that need to rewrite the frame mepc slot (e.g.
;     ECall_Handler) access it through sp directly.
; ============================================================================
#if defined(__has_include)
    #if __has_include("as32x601_hal_conf.h")
        #include "as32x601_hal_conf.h"
    #endif
#endif /* defined(__has_include) */

#ifndef HAL_INTERRUPT_STACK_SIZE
    #define HAL_INTERRUPT_STACK_SIZE 0
#endif /* HAL_INTERRUPT_STACK_SIZE */

; A dedicated interrupt stack is mandatory once a scheduler owns the task
; stacks: without it the trap frame would be built on a task stack that may be
; switched away mid-handler.  A missing configuration header must therefore
; fail here, loudly, instead of silently degrading to the bare-metal layout.
; The same gate is present in both startup files.
#if defined(USE_RTOS) && (USE_RTOS == 1U) && (HAL_INTERRUPT_STACK_SIZE == 0)
    #error "USE_RTOS is enabled but HAL_INTERRUPT_STACK_SIZE is zero; put as32x601_hal_conf.h on the include path"
#endif /* defined(USE_RTOS) && (USE_RTOS == 1U) && (HAL_INTERRUPT_STACK_SIZE == 0) */

; The reserved interrupt-stack range is a multiple of 16 bytes.  The trap
; entry hands _isr_stack_top straight to sp and the psABI requires 16-byte
; alignment at every handler call, so a configured size that is not a
; multiple of 16 is rounded up here (the ALIGN directive is not usable for
; this: it reserves storage instead of padding the position counter).
#define ISR_STACK_BYTES      (((HAL_INTERRUPT_STACK_SIZE) + 15) / 16 * 16)

; PLIC base address (Core-Local Interruptor), see as32x601_addrmap.h:
;   +0x000 AXI_PLIC_ID      read = claim (pending source ID), write = complete
;   +0x004 AXI_PLIC_PRIORITY[64]
;   +0x104 AXI_PLIC_EN[2]
#define PLIC_BASE  0x30020000

; ============================================================================
; FPU adaptive configuration (per RISC-V_FPU context-save adaptation doc)
; Uses the standard __riscv_flen macro to detect FPU mode:
;   64 = D extension (fsd/fld, 8-byte alignment), 32 = F extension (fsw/flw),
;   not defined = no FPU (skip float register save entirely)
; ============================================================================
#if defined(__riscv_flen)
    #if __riscv_flen == 64
        #define FSTORE              fsd
        #define FLOAD               fld
        #define FPREGBYTES          8
    #else
        #define FSTORE              fsw
        #define FLOAD               flw
        #define FPREGBYTES          4
    #endif
    #define HAS_FPU                 1
#else
    #define HAS_FPU                 0
#endif

; Number of registers saved in the context:
;   GPRs: x1 (ra), x4-x31 (tp + caller/callee-saved ABI set), 29 in total;
;         sp (x2) and gp (x3) are NOT saved (unchanged during trap processing).
;   FPRs: f0-f7, f10-f17, f28-f31 (FP caller-saved ABI set), 20 in total.
#define CTX_GENERAL_REGS            29
#define CTX_FP_REGS                 20

; Stack frame layout (save order):
;   [0..115]  GPR area        x1, x4..x31 (29 * 4B)
;   [FP..]    FP area         20 FPRs (aligned to FPREGBYTES, if HAS_FPU)
;   [FCSR]    fcsr snapshot   4B (if HAS_FPU)
;   [MSTATUS] mstatus snapshot (taken before FPU FS enable, if HAS_FPU)
;   [MEPC]    mepc snapshot   mret return target; frame slot so a recoverable
;                             exception handler may rewrite it via mscratch
;   [MTVAL]   mtval snapshot  written by the exception path only (diagnostic)
;   Frame total aligned to 16B so that sp keeps the RISC-V psABI 16-byte
;   alignment at the handler call point (jalr rd, handler) - required for
;   any 64-bit stack data / nested calls inside the handler.
;   Restore order is the exact reverse of the save order.
#if HAS_FPU
    #define OFFSET_FP_START   (((CTX_GENERAL_REGS * REGBYTES) + (FPREGBYTES - 1)) & ~(FPREGBYTES - 1))
    #define OFFSET_FCSR       (OFFSET_FP_START + CTX_FP_REGS * FPREGBYTES)
    #define OFFSET_MSTATUS    (OFFSET_FCSR + 4)
    #define OFFSET_MEPC       (OFFSET_MSTATUS + 4)
    #define OFFSET_MTVAL      (OFFSET_MEPC + 4)
#else
    #define OFFSET_MSTATUS    (CTX_GENERAL_REGS * REGBYTES)
    #define OFFSET_MEPC       (OFFSET_MSTATUS + 4)
    #define OFFSET_MTVAL      (OFFSET_MEPC + 4)
#endif
#define STACK_FRAME_SIZE  (((OFFSET_MTVAL + 4) + 15) & ~15)

    SECTION      `.text.entry`:CODE

    ALIGN       4

    PUBLIC      TrapEntry
    PUBLIC      SetMstatusMie
    PUBLIC      ResetMstatusMie
; Default_Int_Handler and the per-source interrupt / exception handlers are
; provided as weak C stubs (as32x601_hal_plic.c), referenced here
; with EXTERN: the IAR RISC-V assembler has no weak reference directive, so
; the C __weak stubs keep the "user strong handler overrides the default"
; behavior.
    EXTERN      Default_Int_Handler

; Stack-underflow guard symbol: CSTACK block base (low end of the stack),
; generated by the IAR linker from the CSTACK block in the .icf file.
    EXTERN      CSTACK$$Base

; Weak references to per-source interrupt handlers (defined by driver/user,
; else resolved to 0 -> dispatch falls back to Default_Int_Handler).
; Source IDs follow PLICIRQn_TypeDef in as32x601_plic.h.
    EXTERN      EFLASH_IRQ_Handler
    EXTERN      FCU_IRQ_Handler
    EXTERN      DMA0_IRQ_Handler
    EXTERN      DMA1_IRQ_Handler
    EXTERN      TIM0_IRQ_Handler
    EXTERN      CANFD0_IRQ_Handler
    EXTERN      CANFD1_IRQ_Handler
    EXTERN      ADC0_IRQ_Handler
    EXTERN      ADC1_IRQ_Handler
    EXTERN      GPIOA_IRQ_Handler
    EXTERN      GPIOB_IRQ_Handler
    EXTERN      GPIOC_IRQ_Handler
    EXTERN      PKA_IRQ_Handler
    EXTERN      SPACC_IRQ_Handler
    EXTERN      TRNG_IRQ_Handler
    EXTERN      TIM1_IRQ_Handler
    EXTERN      CANFD2_IRQ_Handler
    EXTERN      CANFD3_IRQ_Handler
    EXTERN      GPIOD_IRQ_Handler
    EXTERN      GPIOE_IRQ_Handler
    EXTERN      GPIOF_IRQ_Handler
    EXTERN      GPIOG_IRQ_Handler
    EXTERN      MAC_IRQ_Handler
    EXTERN      SPI0_IRQ_Handler
    EXTERN      SPI1_IRQ_Handler
    EXTERN      SPI2_IRQ_Handler
    EXTERN      I2C0_IRQ_Handler
    EXTERN      I2C1_IRQ_Handler
    EXTERN      USART0_IRQ_Handler
    EXTERN      USART1_IRQ_Handler
    EXTERN      USART2_IRQ_Handler
    EXTERN      USART3_IRQ_Handler
    EXTERN      TIM2_IRQ_Handler
    EXTERN      TIM3_IRQ_Handler
    EXTERN      TIM4_IRQ_Handler
    EXTERN      SPI3_IRQ_Handler
    EXTERN      SPI4_IRQ_Handler
    EXTERN      SPI5_IRQ_Handler
    EXTERN      I2C2_IRQ_Handler
    EXTERN      I2C3_IRQ_Handler
    EXTERN      USART4_IRQ_Handler
    EXTERN      USART5_IRQ_Handler
    EXTERN      USART6_IRQ_Handler
    EXTERN      USART7_IRQ_Handler
    EXTERN      TIM5_IRQ_Handler
    EXTERN      TIM6_IRQ_Handler
    EXTERN      TIM7_IRQ_Handler
    EXTERN      GPIOH_IRQ_Handler
    EXTERN      RTC_IRQ_Handler
; Machine software / timer interrupt handlers
    EXTERN      MSoftWare_IRQ_Handler
    EXTERN      MTimer_IRQ_Handler
; Weak references to exception handlers (mcause exception code based)
    EXTERN      InstAddrMisalign_Handler
    EXTERN      InstAccessFault_Handler
    EXTERN      IllegalInst_Handler
    EXTERN      Breakpoint_Handler
    EXTERN      LoadAddrMisalign_Handler
    EXTERN      LoadAccessFault_Handler
    EXTERN      StoreAMOAddrMisalign_Handler
    EXTERN      StoreAMOAccessFault_Handler
    EXTERN      ECall_Handler
    EXTERN      InstPageFault_Handler
    EXTERN      LoadPageFault_Handler
    EXTERN      StoreAMOPageFault_Handler

; @brief Macro to save context when entering the trap.
; Saves the full ABI integer context, the FP caller-saved context (if FPU
; enabled), the mstatus snapshot and the mepc snapshot to the stack frame.
; Save order: GPRs -> mstatus (pre-FS) -> mepc -> mscratch(frame base, or
;             task sp in RTOS mode) -> FS=Dirty -> FPRs -> fcsr.
;             Internal (CSR) registers are saved only as far as they are
;             used by mret / the FPU state.
SAVE_CONTEXT MACRO

#if (HAL_INTERRUPT_STACK_SIZE > 0)
    ; Switch to the dedicated interrupt stack (RTOS mode).  The swap saves
    ; the task sp into mscratch and puts sp on the ISR stack top.
    csrrw sp, mscratch, sp
#endif

    addi sp, sp, -STACK_FRAME_SIZE

    STORE x1,  0*REGBYTES(sp)
    STORE x4,  1*REGBYTES(sp)
    STORE x5,  2*REGBYTES(sp)
    STORE x6,  3*REGBYTES(sp)
    STORE x7,  4*REGBYTES(sp)
    STORE x8,  5*REGBYTES(sp)
    STORE x9,  6*REGBYTES(sp)
    STORE x10, 7*REGBYTES(sp)
    STORE x11, 8*REGBYTES(sp)
    STORE x12, 9*REGBYTES(sp)
    STORE x13, 10*REGBYTES(sp)
    STORE x14, 11*REGBYTES(sp)
    STORE x15, 12*REGBYTES(sp)
    STORE x16, 13*REGBYTES(sp)
    STORE x17, 14*REGBYTES(sp)
    STORE x18, 15*REGBYTES(sp)
    STORE x19, 16*REGBYTES(sp)
    STORE x20, 17*REGBYTES(sp)
    STORE x21, 18*REGBYTES(sp)
    STORE x22, 19*REGBYTES(sp)
    STORE x23, 20*REGBYTES(sp)
    STORE x24, 21*REGBYTES(sp)
    STORE x25, 22*REGBYTES(sp)
    STORE x26, 23*REGBYTES(sp)
    STORE x27, 24*REGBYTES(sp)
    STORE x28, 25*REGBYTES(sp)
    STORE x29, 26*REGBYTES(sp)
    STORE x30, 27*REGBYTES(sp)
    STORE x31, 28*REGBYTES(sp)

    ; Snapshot mstatus BEFORE enabling FPU, so MPIE/MPP and the original
    ; FS field are faithfully restored (mret depends on MPIE/MPP).
    ; NOTE: on trap entry the hardware cleared MIE, so this snapshot has
    ; MIE=0; restoring it keeps interrupts disabled until mret.
    csrr t0, mstatus
    STORE t0, OFFSET_MSTATUS(sp)

    ; Snapshot mepc (the mret return target).  It is restored right before
    ; mret; a recoverable exception handler that needs to redirect the
    ; return may instead rewrite this frame slot (frame base = sp).
    csrr t0, mepc
    STORE t0, OFFSET_MEPC(sp)

#if (HAL_INTERRUPT_STACK_SIZE > 0)
    ; RTOS mode: mscratch holds the task sp (see the swap above), so it is
    ; not available as a frame-base pointer.  Handlers access the frame
    ; through sp directly (sp is the frame base; it is not modified inside
    ; the trap handler).
#else
    ; Expose the frame base to handlers via mscratch (valid only during
    ; trap processing; unused outside the trap path).
    csrw mscratch, sp
#endif

#if HAS_FPU
    ; Enable FPU (mstatus.FS = 11 Dirty) before float stores; the trap
    ; entry does not depend on the FS value left by the startup
    li t0, 0x00006000
    csrs mstatus, t0

    FSTORE f0,  (OFFSET_FP_START + 0*FPREGBYTES)(sp)
    FSTORE f1,  (OFFSET_FP_START + 1*FPREGBYTES)(sp)
    FSTORE f2,  (OFFSET_FP_START + 2*FPREGBYTES)(sp)
    FSTORE f3,  (OFFSET_FP_START + 3*FPREGBYTES)(sp)
    FSTORE f4,  (OFFSET_FP_START + 4*FPREGBYTES)(sp)
    FSTORE f5,  (OFFSET_FP_START + 5*FPREGBYTES)(sp)
    FSTORE f6,  (OFFSET_FP_START + 6*FPREGBYTES)(sp)
    FSTORE f7,  (OFFSET_FP_START + 7*FPREGBYTES)(sp)
    FSTORE f10, (OFFSET_FP_START + 8*FPREGBYTES)(sp)
    FSTORE f11, (OFFSET_FP_START + 9*FPREGBYTES)(sp)
    FSTORE f12, (OFFSET_FP_START + 10*FPREGBYTES)(sp)
    FSTORE f13, (OFFSET_FP_START + 11*FPREGBYTES)(sp)
    FSTORE f14, (OFFSET_FP_START + 12*FPREGBYTES)(sp)
    FSTORE f15, (OFFSET_FP_START + 13*FPREGBYTES)(sp)
    FSTORE f16, (OFFSET_FP_START + 14*FPREGBYTES)(sp)
    FSTORE f17, (OFFSET_FP_START + 15*FPREGBYTES)(sp)
    FSTORE f28, (OFFSET_FP_START + 16*FPREGBYTES)(sp)
    FSTORE f29, (OFFSET_FP_START + 17*FPREGBYTES)(sp)
    FSTORE f30, (OFFSET_FP_START + 18*FPREGBYTES)(sp)
    FSTORE f31, (OFFSET_FP_START + 19*FPREGBYTES)(sp)

    ; Save FP control/status register (rounding mode + exception flags)
    csrr t0, fcsr
    STORE t0, OFFSET_FCSR(sp)
#endif

    ; Stack-underflow guard (TRAP-REQ-002 abnormal path): the frame base
    ; must stay inside the stack region, otherwise the save has overflowed
    ; the stack and we go fatal (context stays on the stack for diagnosis).
    ; t0/t1 are scratch; their original values are already in the frame.
    ; In RTOS mode the checked region is the dedicated interrupt stack;
    ; in bare-metal mode it is the task stack (CSTACK block).
#if (HAL_INTERRUPT_STACK_SIZE > 0)
    la t0, _isr_stack_bottom
#else
    la t0, CSTACK$$Base
#endif
    bltu sp, t0, Trap_Fatal
    ENDM

; @brief Macro to restore context when exiting the trap.
; Restores fcsr/FPRs (FS still Dirty), restores the mstatus snapshot,
; restores the mepc snapshot, then restores the GPRs in reverse save order,
; deallocates the frame and returns with mret.
;
; The mstatus snapshot was taken right after trap entry, so MIE=0 in it:
; restoring it keeps interrupts disabled for the remainder of the restore
; sequence (no re-enable window before mret - mret itself re-enables MIE
; from MPIE).  mepc is therefore never overwritten between its restore and
; mret, and the frame mepc value is honored exactly.
;
; Recoverable exception handlers (e.g. ECall_Handler) that need to change
; the return address must rewrite the frame mepc slot instead of the
; hardware register:  csrr t0, mscratch ; lw t1, OFFSET_MEPC(t0) ; ...
; (the frame base was stored in mscratch by SAVE_CONTEXT).
RESTORE_CONTEXT MACRO
#if HAS_FPU
    lw t0, OFFSET_FCSR(sp)
    csrw fcsr, t0

    FLOAD f0,  (OFFSET_FP_START + 0*FPREGBYTES)(sp)
    FLOAD f1,  (OFFSET_FP_START + 1*FPREGBYTES)(sp)
    FLOAD f2,  (OFFSET_FP_START + 2*FPREGBYTES)(sp)
    FLOAD f3,  (OFFSET_FP_START + 3*FPREGBYTES)(sp)
    FLOAD f4,  (OFFSET_FP_START + 4*FPREGBYTES)(sp)
    FLOAD f5,  (OFFSET_FP_START + 5*FPREGBYTES)(sp)
    FLOAD f6,  (OFFSET_FP_START + 6*FPREGBYTES)(sp)
    FLOAD f7,  (OFFSET_FP_START + 7*FPREGBYTES)(sp)
    FLOAD f10, (OFFSET_FP_START + 8*FPREGBYTES)(sp)
    FLOAD f11, (OFFSET_FP_START + 9*FPREGBYTES)(sp)
    FLOAD f12, (OFFSET_FP_START + 10*FPREGBYTES)(sp)
    FLOAD f13, (OFFSET_FP_START + 11*FPREGBYTES)(sp)
    FLOAD f14, (OFFSET_FP_START + 12*FPREGBYTES)(sp)
    FLOAD f15, (OFFSET_FP_START + 13*FPREGBYTES)(sp)
    FLOAD f16, (OFFSET_FP_START + 14*FPREGBYTES)(sp)
    FLOAD f17, (OFFSET_FP_START + 15*FPREGBYTES)(sp)
    FLOAD f28, (OFFSET_FP_START + 16*FPREGBYTES)(sp)
    FLOAD f29, (OFFSET_FP_START + 17*FPREGBYTES)(sp)
    FLOAD f30, (OFFSET_FP_START + 18*FPREGBYTES)(sp)
    FLOAD f31, (OFFSET_FP_START + 19*FPREGBYTES)(sp)
#endif

    ; Restore the mstatus snapshot (restores original FS/MPIE/MPP; the
    ; snapshot MIE=0 keeps interrupts disabled until mret)
    lw t0, OFFSET_MSTATUS(sp)
    csrw mstatus, t0

    ; Restore the mepc snapshot (mret return target).  Interrupts are
    ; still disabled here (see above), so no nested trap can overwrite
    ; mepc before mret.
    lw t0, OFFSET_MEPC(sp)
    csrw mepc, t0

    LOAD x31, 28*REGBYTES(sp)
    LOAD x30, 27*REGBYTES(sp)
    LOAD x29, 26*REGBYTES(sp)
    LOAD x28, 25*REGBYTES(sp)
    LOAD x27, 24*REGBYTES(sp)
    LOAD x26, 23*REGBYTES(sp)
    LOAD x25, 22*REGBYTES(sp)
    LOAD x24, 21*REGBYTES(sp)
    LOAD x23, 20*REGBYTES(sp)
    LOAD x22, 19*REGBYTES(sp)
    LOAD x21, 18*REGBYTES(sp)
    LOAD x20, 17*REGBYTES(sp)
    LOAD x19, 16*REGBYTES(sp)
    LOAD x18, 15*REGBYTES(sp)
    LOAD x17, 14*REGBYTES(sp)
    LOAD x16, 13*REGBYTES(sp)
    LOAD x15, 12*REGBYTES(sp)
    LOAD x14, 11*REGBYTES(sp)
    LOAD x13, 10*REGBYTES(sp)
    LOAD x12, 9*REGBYTES(sp)
    LOAD x11, 8*REGBYTES(sp)
    LOAD x10, 7*REGBYTES(sp)
    LOAD x9,  6*REGBYTES(sp)
    LOAD x8,  5*REGBYTES(sp)
    LOAD x7,  4*REGBYTES(sp)
    LOAD x6,  3*REGBYTES(sp)
    LOAD x5,  2*REGBYTES(sp)
    LOAD x4,  1*REGBYTES(sp)
    LOAD x1,  0*REGBYTES(sp)

    addi sp, sp, STACK_FRAME_SIZE
#if (HAL_INTERRUPT_STACK_SIZE > 0)
    ; Switch back to the task stack.  The swap restores sp to the saved
    ; task sp and puts the interrupt stack top back into mscratch for the
    ; next trap.
    csrrw sp, mscratch, sp
#endif
    mret
    ENDM

; @brief Unified trap/interrupt entry (CB-ENTRY / CB-SAVE / CB-DECODE)
; Saves the full context, then decodes mcause:
;   bit31=1 -> interrupt (MSI=3 / MTI=7 / MEI=11, others fatal)
;   bit31=0 -> exception (dispatched via the exception table)
TrapEntry:
    SAVE_CONTEXT

    csrr a0, mcause
    bge  a0, zero, Trap_Exception

    ; ----- interrupt path -----
    li   t0, 0xfff
    and  a1, a0, t0                  ; a1 = interrupt cause code
    li   t0, 3                       ; machine software interrupt
    beq  a1, t0, Trap_MSI
    li   t0, 7                       ; machine timer interrupt
    beq  a1, t0, Trap_MTI
    li   t0, 11                      ; machine external interrupt (PLIC)
    beq  a1, t0, Trap_MEI
    j    Trap_Fatal                  ; reserved/illegal interrupt code

    ; MSI: dispatch to the (weak) software interrupt handler
Trap_MSI:
    la   t2, MSoftWare_IRQ_Handler
    beqz t2, Trap_Fatal
    jalr ra, 0(t2)
    j    Trap_Restore

    ; MTI: dispatch to the (weak) timer interrupt handler
Trap_MTI:
    la   t2, MTimer_IRQ_Handler
    beqz t2, Trap_Fatal
    jalr ra, 0(t2)
    j    Trap_Restore

    ; MEI: PLIC claim -> dispatch table -> complete (CB-DISPATCH)
Trap_MEI:
    li   t0, PLIC_BASE
    lw   a1, 0(t0)                   ; claim: read AXI_PLIC_ID -> source ID
    beqz a1, Trap_Restore            ; spurious (None) -> nothing to complete
    li   t0, 50                      ; highest valid source ID (RTC_IRQn)
    bltu t0, a1, Trap_DefaultIRQ     ; out-of-range source -> default
    mv   s0, a1                      ; keep ID across the handler call
    la   t0, Trap_IRQTable
    slli t1, a1, 2
    add  t0, t0, t1
    lw   t2, 0(t0)                   ; handler address or 0
    beqz t2, Trap_DefaultIRQ         ; table miss -> default
    jalr ra, 0(t2)                      ; call the registered handler
    li   t0, PLIC_BASE
    sw   s0, 0(t0)                   ; complete: write source ID back
    j    Trap_Restore

    ; Unregistered source: clear the pending flag (mandatory, no storm),
    ; then call the weak default hook (default = fatal loop; a user
    ; override may return -> ignore policy). (CB-DEFAULT)
Trap_DefaultIRQ:
    li   t0, PLIC_BASE
    sw   a1, 0(t0)                   ; complete: clear pending
    call Default_Int_Handler
    j    Trap_Restore                ; reached only if hook returns

    ; ----- exception path (CB-EXCEPT) -----
Trap_Exception:
    csrr t0, mtval                   ; retain fault address for diagnostics
    STORE t0, OFFSET_MTVAL(sp)
    li   t0, 0xfff
    and  a1, a0, t0                  ; a1 = exception code
    li   t0, 15
    bltu t0, a1, Trap_Fatal          ; reserved/illegal code -> fatal
    la   t0, Trap_ExcTable
    slli t1, a1, 2
    add  t0, t0, t1
    lw   t2, 0(t0)
    beqz t2, Trap_Fatal              ; unregistered -> fatal
    jalr ra, 0(t2)                      ; recoverable handler (may fix mepc)
    j    Trap_Restore

Trap_Restore:
    RESTORE_CONTEXT

    ; Fatal handling: preserve the context on the stack and spin.
    ; No return instruction is executed (CB-FATAL).
Trap_Fatal:
    j    Trap_Fatal
    ALIGN 4

; @brief Dispatch table for external interrupt sources (ID 0..50).
; Entry 0 (None) is unreachable (spurious claim returns before lookup) and
; entry 19 names the id the controller reserves.  Both hold 0 on purpose: the
; default path completes the claimed source before the hook runs, whereas a hit
; on Default_Int_Handler would call the hook straight away and leave the source
; pending - an interrupt storm as soon as the hook is overridden with a
; returning ignore policy.
; Entries are weak references: unresolved handlers resolve to 0 and the
; dispatch falls back to Trap_DefaultIRQ.
Trap_IRQTable:
    DC32 0                           ;  0 None: unreachable, claim 0 returns early
    DC32 EFLASH_IRQ_Handler          ;  1
    DC32 FCU_IRQ_Handler             ;  2
    DC32 DMA0_IRQ_Handler            ;  3
    DC32 DMA1_IRQ_Handler            ;  4
    DC32 TIM0_IRQ_Handler            ;  5
    DC32 CANFD0_IRQ_Handler          ;  6
    DC32 CANFD1_IRQ_Handler          ;  7
    DC32 ADC0_IRQ_Handler            ;  8
    DC32 ADC1_IRQ_Handler            ;  9
    DC32 GPIOA_IRQ_Handler           ; 10
    DC32 GPIOB_IRQ_Handler           ; 11
    DC32 GPIOC_IRQ_Handler           ; 12
    DC32 PKA_IRQ_Handler             ; 13
    DC32 SPACC_IRQ_Handler           ; 14
    DC32 TRNG_IRQ_Handler            ; 15
    DC32 TIM1_IRQ_Handler            ; 16
    DC32 CANFD2_IRQ_Handler          ; 17
    DC32 CANFD3_IRQ_Handler          ; 18
    DC32 0                           ; 19 reserved: default path completes first
    DC32 GPIOD_IRQ_Handler           ; 20
    DC32 GPIOE_IRQ_Handler           ; 21
    DC32 GPIOF_IRQ_Handler           ; 22
    DC32 GPIOG_IRQ_Handler           ; 23
    DC32 MAC_IRQ_Handler             ; 24
    DC32 SPI0_IRQ_Handler            ; 25
    DC32 SPI1_IRQ_Handler            ; 26
    DC32 SPI2_IRQ_Handler            ; 27
    DC32 I2C0_IRQ_Handler            ; 28
    DC32 I2C1_IRQ_Handler            ; 29
    DC32 USART0_IRQ_Handler          ; 30
    DC32 USART1_IRQ_Handler          ; 31
    DC32 USART2_IRQ_Handler          ; 32
    DC32 USART3_IRQ_Handler          ; 33
    DC32 TIM2_IRQ_Handler            ; 34
    DC32 TIM3_IRQ_Handler            ; 35
    DC32 TIM4_IRQ_Handler            ; 36
    DC32 SPI3_IRQ_Handler            ; 37
    DC32 SPI4_IRQ_Handler            ; 38
    DC32 SPI5_IRQ_Handler            ; 39
    DC32 I2C2_IRQ_Handler            ; 40
    DC32 I2C3_IRQ_Handler            ; 41
    DC32 USART4_IRQ_Handler          ; 42
    DC32 USART5_IRQ_Handler          ; 43
    DC32 USART6_IRQ_Handler          ; 44
    DC32 USART7_IRQ_Handler          ; 45
    DC32 TIM5_IRQ_Handler            ; 46
    DC32 TIM6_IRQ_Handler            ; 47
    DC32 TIM7_IRQ_Handler            ; 48
    DC32 GPIOH_IRQ_Handler           ; 49
    DC32 RTC_IRQ_Handler             ; 50

; @brief Exception dispatch table (mcause exception code 0..15).
; Codes 8/9 are U/S-mode ECALL: AS32x601 runs M-mode only (no U/S mode),
; so they are never generated on this chip and kept as reserved (0 -> fatal).
; Codes 10/14 are architecturally reserved.
    ALIGN 4
Trap_ExcTable:
    DC32 InstAddrMisalign_Handler      ;  0
    DC32 InstAccessFault_Handler       ;  1
    DC32 IllegalInst_Handler           ;  2
    DC32 Breakpoint_Handler            ;  3
    DC32 LoadAddrMisalign_Handler      ;  4
    DC32 LoadAccessFault_Handler       ;  5
    DC32 StoreAMOAddrMisalign_Handler  ;  6
    DC32 StoreAMOAccessFault_Handler   ;  7
    DC32 0                             ;  8 U-mode ECALL (no U/S mode)
    DC32 0                             ;  9 S-mode ECALL (no U/S mode)
    DC32 0                             ; 10 reserved
    DC32 ECall_Handler                 ; 11
    DC32 InstPageFault_Handler         ; 12
    DC32 LoadPageFault_Handler         ; 13
    DC32 0                             ; 14 reserved
    DC32 StoreAMOPageFault_Handler     ; 15

; @brief Global interrupt enable (mstatus.MIE = 1)
SetMstatusMie:
    csrsi mstatus, 0x08
    ret

; @brief Global interrupt disable (mstatus.MIE = 0)
ResetMstatusMie:
    csrci mstatus, 0x08
    ret

; The weak default hook Default_Int_Handler and the per-source interrupt /
; exception handlers are provided as C __weak stubs in
; as32x601_hal_plic.c (the IAR RISC-V assembler has no weak symbol
; support; the C __weak stubs keep the "user strong handler overrides the
; default" design).

#if (HAL_INTERRUPT_STACK_SIZE > 0)
; ============================================================================
; Dedicated interrupt stack (RTOS mode, HAL_INTERRUPT_STACK_SIZE > 0).
; Placed in a NOINIT data section; the IAR linker places it in RAM.
;   _isr_stack_bottom : low address (guard symbol)
;   _isr_stack_top    : high address = initial sp; it is 16-byte aligned for any
;                       configured size because ISR_STACK_BYTES rounds the range
;                       up (the trap entry hands this value to sp before any C
;                       handler runs)
; The section name starts with a dot, so it is written in the assembler's
; quoted form (backticks); an unquoted dotted name is rejected.  NOROOT(n)
; requests 2^n-byte alignment, so the 16-byte alignment sp must keep at the
; handler call point (see STACK_FRAME_SIZE) is NOROOT(4) - not NOROOT(16),
; which would request 64 KB.
; ============================================================================
    SECTION `.bss.isr_stack`:DATA:REORDER:NOROOT(4)
    PUBLIC  _isr_stack_bottom
    PUBLIC  _isr_stack_top
_isr_stack_bottom:
    DS8     ISR_STACK_BYTES
_isr_stack_top:
#endif /* (HAL_INTERRUPT_STACK_SIZE > 0) */

    END
