/**
 * @file    MPU_IT_DRV_004.c
 * @brief   HAL MPU integration test case 004 (D-Port write protection, channels
 *          0..15).
 *
 * One-to-one HAL library port of the original AS32x601 standard-library test
 * case MPU_IT_DRV_004.c. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_MPU_SetAddressRange()
 *   HAL_MPU_WriteProtectCmd()
 *   HAL_MPU_Cmd()
 *   HAL_MPU_GetWriteProtectStatus()
 *   HAL_MPU_ClearStatus()
 *   HAL_MPU_GetChannelConfig()
 *
 * Test procedure:
 *   1. Declare 16 data words, one per channel, 256 bytes apart so that every
 *      channel protects a window that lies in its own 64-byte cache line;
 *   2. Program the range of MPU1 channel 0..15 and enable their write
 *      protection, then enable the channels;
 *   3. Check the whole configuration from the firmware: register read-back,
 *      HAL_MPU_GetChannelConfig() read-back, the disable / enable round trip
 *      and the clear-status path (none of these touches a protected word);
 *   4. Store into the 16 data words and flush the cache, so that the stores
 *      reach the D-Port: every refused store sets the write-protection status
 *      of the matching channel;
 *   5. Check the WPTS register and the per channel status, then clear them;
 *   6. Disable the protection, store a new value and check that the store
 *      reaches the memory and that nothing is recorded.
 *
 * Test configuration (same as the original test case):
 *   MPU1 (D-Bus) channels 0..15, write protection. The original case placed the
 *   16 variables at fixed RAM addresses (0x20007000 .. 0x20007F00 through IAR
 *   #pragma location), that is 256 bytes apart, which needs a dedicated linker
 *   script; the integration test project shares one linker script, so the
 *   variables are declared here and the protected windows are derived from
 *   their addresses.  The 256-byte spacing is kept on purpose, see below.
 *
 *   Two properties of the D-Port have to be arranged explicitly, otherwise the
 *   status never reaches 0xFFFF:
 *   - the windows must sit one per cache line.  Measured on the board: a
 *     D-Port access is compared against the whole 64-byte cache line it
 *     belongs to, so several windows inside one line collapse into a single
 *     reported channel.  With the 16-byte stride of the first revision of this
 *     port (4 windows per line) the status could only ever show one channel
 *     per line; with one window per line it reads 0xFFFF;
 *   - the cache has to be flushed between the stores and the status read
 *     (CLEAR_CACHE()).  A store is taken by the cache first; measured on the
 *     board the write-protection status stays 0 until the dirty line is
 *     written back, and the refused write-back leaves the memory untouched.
 *
 * Expected behaviour:
 *   - SADDR / EADDR of the 16 channels are programmed as requested and
 *     WPTEN / PTEN read back as 0xFFFF;
 *   - before the stores the status is clear;
 *   - the 16 stores set WPTS bit 0..15, so the write-protection state reads
 *     0xFFFF (the value the original test specification expects);
 *   - HAL_MPU_GetWriteProtectStatus() reports 1 for all 16 channels;
 *   - HAL_MPU_ClearStatus() empties the status;
 *   - the protected data keeps the value it had before the refused stores;
 *   - after the protection is disabled a new store reaches the memory and
 *     records nothing.
 * NOTE: A violation is recorded by the MPU (and forwarded to the FCU by its
 *       MPU1 channel); it does not abort the access.  Measured on the board a
 *       refused store is dropped: the memory keeps its previous content.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Report period (ms) */
#define TEST_PERIOD_MS              (1000U)

/* MPU instance under test (MPU1 = D-Bus data port) */
#define TEST_MPU_INSTANCE           (HAL_MPU_INSTANCE_1_DBUS)

/* Number of channels of MPU1 */
#define TEST_CHANNEL_COUNT          (16U)

/* Distance between two protected words in words (64 words = 256 bytes): one
   window per 64-byte cache line, like the 0x20007000 .. 0x20007F00 spacing of
   the original test case */
#define TEST_DATA_STRIDE            (64U)

/* Length of one protected window (bytes) */
#define TEST_WINDOW_LENGTH          (4U)

/* Content of the 16 data words before the protected stores */
#define TEST_DATA_PATTERN           (0x5A5A5A5AU)

/* Value the refused stores try to write */
#define TEST_DATA_BLOCKED           (0xFFFFFFFFU)

/* Value written after the protection is disabled */
#define TEST_DATA_ALLOWED           (0xA5A5A5A5U)

/* Private variables ---------------------------------------------------------*/
static HAL_MPU_HandleTypeDef hmpu_dev;        /*!< MPU device handle           */
static uint32          failures = 0U;         /*!< failed checks               */

/* The 16 protected data words: one word every TEST_DATA_STRIDE words, so that
   every channel protects a window in a cache line of its own.  The buffer is
   4 KB aligned and 4 KB long, i.e. 16 times the 256-byte stride. */
static volatile uint32 d_port_data[TEST_CHANNEL_COUNT * TEST_DATA_STRIDE]
    __attribute__((aligned(4096)));
static volatile uint32 read_sink;             /*!< sink of the reads           */
static MPU_Channel_TypeDef * const mpu1_channel[16] =
{
    MPU1_Channel0, MPU1_Channel1, MPU1_Channel2,  MPU1_Channel3,
    MPU1_Channel4, MPU1_Channel5, MPU1_Channel6,  MPU1_Channel7,
    MPU1_Channel8, MPU1_Channel9, MPU1_Channel10, MPU1_Channel11,
    MPU1_Channel12, MPU1_Channel13, MPU1_Channel14, MPU1_Channel15
};

static HAL_SMU_HandleTypeDef hsmu_clk;   /*!< SMU handle (lock / state / error) */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void Check(const char *name, uint32 condition);
static void Read_EnableMasks(HAL_MPU_HandleTypeDef *hmpu, uint32 count,
                             uint32 *pten, uint32 *rpten, uint32 *wpten);
static uint32 Window_Address(uint32 ch);
static void Write_Pattern(uint32 value);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    uint32 ch;
    uint32 start;
    uint32 state;
    uint32 rd_pten;
    uint32 rd_rpten;
    uint32 rd_wpten;
    uint32 ok;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n\r\n ***** MPU Test ***** \r\n");
    printf("case : MPU_IT_DRV_004 (D-Port write protection, channels 0..15)\r\n");
    delay_ms(500U);

    /* ---- Step 1: data pattern and per channel range -------------- */
    Write_Pattern(TEST_DATA_PATTERN);

    printf("\r\n-----------------protected windows----------------- \r\n");
    __HAL_CLEAR_STRUCT(&hmpu_dev);
    hmpu_dev.Instance = TEST_MPU_INSTANCE;
    /* The channel control functions require an initialized handle: this case
       drives them directly, so the READY state is set up explicitly (no
       channel is programmed by HAL_MPU_Init() here) */
    hmpu_dev.State = HAL_MPU_STATE_READY;

    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        start = Window_Address(ch);
        HAL_MPU_SetAddressRange(&hmpu_dev, ch, start, start + TEST_WINDOW_LENGTH);
        printf("channel %2u : 0x%08X .. 0x%08X\r\n",
               PRINT_U32(ch), PRINT_U32(start), PRINT_U32(start + TEST_WINDOW_LENGTH));
    }

    ok = 1U;
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        start = Window_Address(ch);
        if ((mpu1_channel[ch]->SADDR != start) ||
            (mpu1_channel[ch]->EADDR != (start + TEST_WINDOW_LENGTH)))
        {
            ok = 0U;
        }
    }
    Check("SADDR / EADDR of all 16 channels", ok);

    /* ---- Step 2: write protection and channel enable -------------- */
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        HAL_MPU_WriteProtectCmd(&hmpu_dev, ch, MPU_ENABLE);
    }
    Check("WPTEN = 0xFFFF", (((MPU1_DBUS->WPTEN & 0xFFFFUL) == 0xFFFFUL) ? 1U : 0U));

    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        HAL_MPU_Cmd(&hmpu_dev, ch, MPU_ENABLE);
    }
    Check("PTEN = 0xFFFF", (((MPU1_DBUS->PTEN & 0xFFFFUL) == 0xFFFFUL) ? 1U : 0U));
    /* read the enable masks back through the HAL API (V1.2); the direct
       register reads above stay as the white-box cross check */
    Read_EnableMasks(&hmpu_dev, TEST_CHANNEL_COUNT, &rd_pten, &rd_rpten, &rd_wpten);
    Check("WPTEN read back by HAL_MPU_GetChannelConfig",
          (((rd_wpten & 0xFFFFUL) == 0xFFFFUL) ? 1U : 0U));
    Check("PTEN read back by HAL_MPU_GetChannelConfig",
          (((rd_pten & 0xFFFFUL) == 0xFFFFUL) ? 1U : 0U));
    Check("no read protection enable (write protection case, HAL read-back)",
          ((rd_rpten == 0U) ? 1U : 0U));

    delay_ms(100U);

    /* ---- Step 3: status path before any protected store ----------- */
    printf("\r\n-----------------configuration------------------------ \r\n");

    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        (void)HAL_MPU_ClearStatus(&hmpu_dev, ch);
    }
    Check("WPTS = 0 before the protected stores",
          ((((uint32)MPU1_DBUS->WPTS & 0xFFFFUL) == 0U) ? 1U : 0U));

    ok = 1U;
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        if (HAL_MPU_GetWriteProtectStatus(&hmpu_dev, ch) != 0U)
        {
            ok = 0U;
        }
    }
    Check("HAL_MPU_GetWriteProtectStatus = 0 for all 16 channels", ok);

    /* disable / enable round trip of both control bits (no protected store) */
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        HAL_MPU_WriteProtectCmd(&hmpu_dev, ch, MPU_DISABLE);
        HAL_MPU_Cmd(&hmpu_dev, ch, MPU_DISABLE);
    }
    Check("WPTEN = 0 after the disable",
          (((MPU1_DBUS->WPTEN & 0xFFFFUL) == 0U) ? 1U : 0U));
    Check("PTEN = 0 after the disable",
          (((MPU1_DBUS->PTEN & 0xFFFFUL) == 0U) ? 1U : 0U));

    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        HAL_MPU_WriteProtectCmd(&hmpu_dev, ch, MPU_ENABLE);
        HAL_MPU_Cmd(&hmpu_dev, ch, MPU_ENABLE);
    }
    Check("WPTEN = 0xFFFF after the re-enable",
          (((MPU1_DBUS->WPTEN & 0xFFFFUL) == 0xFFFFUL) ? 1U : 0U));
    Check("PTEN = 0xFFFF after the re-enable",
          (((MPU1_DBUS->PTEN & 0xFFFFUL) == 0xFFFFUL) ? 1U : 0U));

    ok = 1U;
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        start = Window_Address(ch);
        if ((mpu1_channel[ch]->SADDR != start) ||
            (mpu1_channel[ch]->EADDR != (start + TEST_WINDOW_LENGTH)))
        {
            ok = 0U;
        }
    }
    Check("SADDR / EADDR of all 16 channels after the round trip", ok);

    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        (void)HAL_MPU_ClearStatus(&hmpu_dev, ch);
    }
    Check("status cleared right before the protected stores",
          ((((uint32)MPU1_DBUS->WPTS & 0xFFFFUL) == 0U) ? 1U : 0U));

    /* ---- Step 4: the protected stores ---------------------------- */
    printf("\r\n-----------------trigger the protection----------------- \r\n");

    /* The stores are taken by the cache first, so the cache has to be cleaned
       before the D-Port sees them (a store that is still dirty in the cache
       has not reached the bus and cannot be reported) */
    CLEAR_CACHE();
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        d_port_data[ch * TEST_DATA_STRIDE] = TEST_DATA_BLOCKED;
    }
    CLEAR_CACHE();

    state = (uint32)MPU1_DBUS->WPTS;
    printf("MPU1 WPTS : 0x%08X (data after the refused store 0x%08X)\r\n",
           PRINT_U32(state), PRINT_U32(d_port_data[0]));

    Check("write protection state = 0xFFFF", ((state & 0xFFFFUL) == 0xFFFFUL));
    Check("bit 0 (channel 0 window) set", ((state & 0x0001UL) != 0U));
    Check("bit 15 (channel 15 window) set", ((state & 0x8000UL) != 0U));

    ok = 1U;
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        if (HAL_MPU_GetWriteProtectStatus(&hmpu_dev, ch) == 0U)
        {
            ok = 0U;
        }
    }
    Check("HAL_MPU_GetWriteProtectStatus of all 16 channels", ok);

    Check("the refused store did not reach the memory",
          ((d_port_data[0] == TEST_DATA_PATTERN) ? 1U : 0U));

    /* ---- Step 5: clear, then disable ---------------------------- */
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        (void)HAL_MPU_ClearStatus(&hmpu_dev, ch);
    }
    Check("status cleared by HAL_MPU_ClearStatus",
          ((((uint32)MPU1_DBUS->WPTS & 0xFFFFUL) == 0U) ? 1U : 0U));

    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        HAL_MPU_WriteProtectCmd(&hmpu_dev, ch, MPU_DISABLE);
        HAL_MPU_Cmd(&hmpu_dev, ch, MPU_DISABLE);
    }
    Check("WPTEN / PTEN cleared by the disable",
          (((((uint32)MPU1_DBUS->WPTEN & 0xFFFFUL) == 0U) &&
            (((uint32)MPU1_DBUS->PTEN & 0xFFFFUL) == 0U)) ? 1U : 0U));

    /* with the protection off the same store has to reach the memory */
    Write_Pattern(TEST_DATA_ALLOWED);
    CLEAR_CACHE();
    read_sink = d_port_data[0];
    Check("no violation while the protection is disabled",
          ((((uint32)MPU1_DBUS->WPTS & 0xFFFFUL) == 0U) ? 1U : 0U));
    Check("unprotected store reaches the memory",
          ((read_sink == TEST_DATA_ALLOWED) ? 1U : 0U));

    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(failures));

    /* The D-Port only refuses the data: no trap, no exception, so the case can
       keep running and the result can be read again on the next round */
    while (1)
    {
        delay_ms(TEST_PERIOD_MS);
    }
}

/**
 * @brief  Address of the protected word of one channel.
 * @param  ch: channel index (0..15).
 * @retval Address of the 4-byte protected window of that channel.
 */
static uint32 Window_Address(uint32 ch)
{
    return (uint32)(unsigned long)&d_port_data[ch * TEST_DATA_STRIDE];
}

/**
 * @brief  Write a value into the protected word of every channel.
 * @param  value: value to write.
 * @retval None
 */
static void Write_Pattern(uint32 value)
{
    uint32 ch;

    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        d_port_data[ch * TEST_DATA_STRIDE] = value;
    }
}


/**
 * @brief  Rebuild the channel enable / protection enable masks of a MPU
 *         instance by reading the configuration of every channel back through
 *         HAL_MPU_GetChannelConfig().
 * @note   The driver provides the configuration read-back interface from V1.2
 *         on: the masks let the case check the programmed enables through the
 *         HAL API in addition to the direct PTEN / RPTEN / WPTEN reads of the
 *         original test case.
 * @param  hmpu: pointer to the MPU handle.
 * @param  count: number of channels of the instance (16 or 8).
 * @param  pten: receives the channel enable mask.
 * @param  rpten: receives the read protection enable mask.
 * @param  wpten: receives the write protection enable mask.
 * @retval None
 */
static void Read_EnableMasks(HAL_MPU_HandleTypeDef *hmpu, uint32 count,
                             uint32 *pten, uint32 *rpten, uint32 *wpten)
{
    uint32 i;
    MPU_InitTypeDef cfg;

    *pten  = 0U;
    *rpten = 0U;
    *wpten = 0U;

    for (i = 0U; i < count; i++)
    {
        __HAL_CLEAR_STRUCT(&cfg);

        if (HAL_MPU_GetChannelConfig(hmpu, i, &cfg) == HAL_OK)
        {
            *pten  |= ((uint32)cfg.ChannelEnable      << i);
            *rpten |= ((uint32)cfg.ReadProtectEnable  << i);
            *wpten |= ((uint32)cfg.WriteProtectEnable << i);
        }
    }
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition == 0U)
    {
        failures++;
    }
    printf("%-46s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Configure the system clock tree using the HAL SMU / PMU drivers.
 * @note   Same clock tree as the CLINT / CMU reference suites: OSC 20 MHz as
 *         the PLL source, PLLDivN = 20 / PLLDivF = 180 / PLLDivQ = 1 /
 *         PLLDivR = 4 -> 180 MHz VCO, AXI4Bus3 = /2, APBBus0 = /2,
 *         APBBus1 = /2, CANX2 = /8; the 2.5V LDO is scaled to 2.78 V and the
 *         1.2V LDO to 1.34 V as in the reference suites.
 * @note   Clock tree order (the order the chip requires, and the order the
 *         vendor test case uses): configure the oscillators and the PLL and
 *         switch the system clock to it, then write the bus clock dividers.
 *         HAL_SMU_OscConfig() programs the EFLASH controller clock (CLKFRQ)
 *         before the switch and lets it follow the new system clock afterwards
 *         (EFLASH_CLK_UPDATE), so no explicit HAL_FLASH_SetClockFrequency() is
 *         needed here; it also updates SystemCoreClock together with the HAL
 *         time base.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef  SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef   SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it (CLKFRQ above), so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Set the bus clock dividers (the system clock source is already set by
       HAL_SMU_OscConfig() above) */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
