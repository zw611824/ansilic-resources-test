/**
 * @file    MPU_IT_DRV_012.c
 * @brief   HAL MPU integration test case 012 (HAL_MPU_Init semantics: channel
 *          enable handling, run-time validation and instance coverage).
 *
 * Extension test case of the HAL MPU driver: it exercises the behaviour that
 * HAL_MPU_Init() gained with the current driver release and that the other
 * cases do not cover:
 *   - the channel is closed while its address range is programmed, and a zero
 *     channel enable request restores the enable state the channel had before
 *     the call;
 *   - the configuration structure is validated at run time (meta fields,
 *     address order, enable fields, instance and channel bounds), and a
 *     rejected call neither takes the lock nor changes a register;
 *   - the five instances are covered with their own channel counts;
 *   - a write protection request addressing MPU0 is rejected with a dedicated
 *     error code before any register is written.
 *
 * Tested functionality:
 *   HAL_MPU_StructInit() / HAL_MPU_Init() / HAL_MPU_DeInit()
 *   HAL_MPU_Cmd() / HAL_MPU_ResetInstance()
 *   HAL_MPU_GetChannelConfig() / HAL_MPU_GetAddressRange()
 *   HAL_MPU_GetState() / HAL_MPU_GetError()
 *   HAL_MPU_GetRegBlock() / HAL_MPU_GetIPortBlock()
 *   MPU_INIT_VERSION / MPU_INIT_V1
 *   HAL_MPU_ERROR_NONE / HAL_MPU_ERROR_INVALID_PARAM /
 *   HAL_MPU_ERROR_NOT_SUPPORTED / HAL_MPU_ERROR_HARDWARE
 *   IS_MPU_INSTANCE / IS_MPU_CHANNEL / IS_MPU_WP_INSTANCE
 *
 * Test procedure:
 *   1. Initialize MPU1 channel 3 with every protection enabled and check the
 *      register programming, the handle state and the error code;
 *   2. Re-initialize the same channel with ChannelEnable = 0: the channel was
 *      enabled before the call, so it must still be enabled afterwards (the
 *      driver restores the previous enable state);
 *   3. Disable the channel, then re-initialize it with ChannelEnable = 0: a
 *      channel that was disabled must stay disabled;
 *   4. Re-initialize it with ChannelEnable = 1: the channel is enabled again;
 *   5. Repeat the same configuration twice: the second call must leave the
 *      registers and the state unchanged (idempotent);
 *   6. Check the run-time validation: a wrong Size, a wrong Version, an
 *      inverted address range, an enable field above 1, an instance above 4
 *      and a channel above the count of the instance are all rejected with
 *      HAL_ERROR and HAL_MPU_ERROR_INVALID_PARAM, without touching the
 *      registers and while the handle stays READY;
 *   7. Check that a write protection request addressing MPU0 is rejected with
 *      HAL_MPU_ERROR_NOT_SUPPORTED and leaves the I-Port registers untouched;
 *   8. Cover the five instances with their own channel count (16 channels for
 *      MPU0/1/2, 8 channels for MPU3/4): the last channel is accepted, one
 *      past it is rejected;
 *   9. Check that initializing one channel does not disturb its neighbour;
 *  10. Leave every touched instance clean and re-initializable.
 *
 * Expected behaviour:
 *   - HAL_MPU_Init() programs SADDR / EADDR and only the requested protection
 *     and enable bits;
 *   - a zero ChannelEnable request restores the previous enable state of the
 *     channel (keeps an enabled channel enabled, keeps a disabled one
 *     disabled);
 *   - the rejected calls return HAL_ERROR, report
 *     HAL_MPU_ERROR_INVALID_PARAM or HAL_MPU_ERROR_NOT_SUPPORTED, leave the
 *     registers untouched and keep the handle READY;
 *   - the channel counts per instance are enforced (16 / 16 / 16 / 8 / 8).
 * NOTE: HAL_MPU_ERROR_HARDWARE is reported when the read-back verification of
 *       HAL_MPU_Init() fails, i.e. when a register does not hold the value
 *       that was just written. That requires a fault in the peripheral block
 *       (a register that does not retain its content), which cannot be
 *       produced from software on a healthy device, so this case only checks
 *       that the code is defined and distinct from the other error codes. The
 *       healthy read-back path is covered by step 1 and step 5.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Report period (ms) */
#define TEST_PERIOD_MS              (1000U)

/* Instance / channel used by the enable-restore checks (MPU1 has 16 channels) */
#define TEST_INSTANCE               (HAL_MPU_INSTANCE_1_DBUS)
#define TEST_CHANNEL                (3U)

/* Channel used by the "neighbour is not disturbed" check */
#define TEST_NEIGHBOUR              (4U)

/* Protected window: 4 bytes around the protected word */
#define TEST_WINDOW_LENGTH          (4U)

/* Channel count of each instance: MPU0/1/2 have 16, MPU3/4 have 8 */
#define TEST_CHANNELS_16            (16U)
#define TEST_CHANNELS_8             (8U)

/* Out of range values used by the validation checks */
#define TEST_BAD_INSTANCE           (5U)

/* Private variables ---------------------------------------------------------*/
static HAL_MPU_HandleTypeDef hmpu_dev;        /*!< MPU device handle           */
static uint32          failures = 0U;         /*!< failed checks               */

static MPU_InitTypeDef mpu_init;              /*!< MPU configuration structure */

/* The protected word lives in a 64-byte cache line of its own: a D-Port access
   is compared against the whole cache line it belongs to, so a window that
   shared its line with other variables (the failure counter, the C library
   state) would protect them as well while a channel is enabled. */
static volatile uint32 protected_line[16] __attribute__((aligned(64)));

/* The protected word is the first word of that line */
#define protected_word              (protected_line[0])

static HAL_SMU_HandleTypeDef hsmu_clk;   /*!< SMU handle (lock / state / error) */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void Check(const char *name, uint32 condition);
static uint32 ChannelEnableBit(uint32 instance, uint32 channel);
static void LoadConfig(uint32 instance, uint32 channel, uint32 start, uint32 end,
                       uint32 wp, uint32 rp, uint32 ce);
static void InstanceCoverage(uint32 instance, uint32 lastChannel);
static void ResetInstanceSafe(uint32 instance);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    uint32 start;
    uint32 rd_start;
    uint32 rd_end;
    MPU_InitTypeDef rd_cfg;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n\r\n ***** MPU Test ***** \r\n");
    printf("case : MPU_IT_DRV_012 (HAL_MPU_Init semantics)\r\n");
    delay_ms(500U);

    start = (uint32)(unsigned long)&protected_word;

    while (1)
    {
        /* ---- Step 1: full configuration ---------------------------- */
        printf("\r\n-----------------Init: full configuration----------------- \r\n");

        __HAL_CLEAR_STRUCT(&hmpu_dev);
        hmpu_dev.Instance = TEST_INSTANCE;

        LoadConfig(TEST_INSTANCE, TEST_CHANNEL, start, start + TEST_WINDOW_LENGTH,
                   1U, 1U, 1U);

        Check("Init (all protections) = HAL_OK",
              ((HAL_MPU_Init(&hmpu_dev) == HAL_OK) ? 1U : 0U));
        Check("SADDR / EADDR read back",
              (((HAL_MPU_GetAddressRange(&hmpu_dev, TEST_CHANNEL, &rd_start, &rd_end) == HAL_OK) &&
                (rd_start == start) && (rd_end == (start + TEST_WINDOW_LENGTH))) ? 1U : 0U));
        Check("WPTEN / RPTEN / PTEN set",
              (((HAL_MPU_GetChannelConfig(&hmpu_dev, TEST_CHANNEL, &rd_cfg) == HAL_OK) &&
                (rd_cfg.WriteProtectEnable == 1U) &&
                (rd_cfg.ReadProtectEnable == 1U) &&
                (rd_cfg.ChannelEnable == 1U)) ? 1U : 0U));
        Check("state = READY", ((HAL_MPU_GetState(&hmpu_dev) == HAL_MPU_STATE_READY) ? 1U : 0U));
        Check("error = NONE", ((HAL_MPU_GetError(&hmpu_dev) == HAL_MPU_ERROR_NONE) ? 1U : 0U));

        /* ---- Step 2: ChannelEnable = 0 on an ENABLED channel ------- */
        printf("\r\n-----------------Init: ChannelEnable = 0 keeps it enabled-- \r\n");
        Check("channel is enabled before the call",
              ((ChannelEnableBit(TEST_INSTANCE, TEST_CHANNEL) == 1U) ? 1U : 0U));

        LoadConfig(TEST_INSTANCE, TEST_CHANNEL, start, start + TEST_WINDOW_LENGTH,
                   1U, 1U, 0U);
        Check("Init with ChannelEnable = 0 = HAL_OK",
              ((HAL_MPU_Init(&hmpu_dev) == HAL_OK) ? 1U : 0U));
        Check("channel still enabled (previous state restored)",
              ((ChannelEnableBit(TEST_INSTANCE, TEST_CHANNEL) == 1U) ? 1U : 0U));

        /* ---- Step 3: ChannelEnable = 0 on a DISABLED channel ------- */
        printf("\r\n-----------------Init: ChannelEnable = 0 keeps it disabled- \r\n");
        (void)HAL_MPU_Cmd(&hmpu_dev, TEST_CHANNEL, MPU_DISABLE);
        Check("channel disabled before the call",
              ((ChannelEnableBit(TEST_INSTANCE, TEST_CHANNEL) == 0U) ? 1U : 0U));

        LoadConfig(TEST_INSTANCE, TEST_CHANNEL, start, start + TEST_WINDOW_LENGTH,
                   1U, 1U, 0U);
        Check("Init with ChannelEnable = 0 = HAL_OK",
              ((HAL_MPU_Init(&hmpu_dev) == HAL_OK) ? 1U : 0U));
        Check("channel still disabled (previous state restored)",
              ((ChannelEnableBit(TEST_INSTANCE, TEST_CHANNEL) == 0U) ? 1U : 0U));

        /* ---- Step 4: ChannelEnable = 1 on a DISABLED channel ------- */
        printf("\r\n-----------------Init: ChannelEnable = 1 enables---------- \r\n");
        LoadConfig(TEST_INSTANCE, TEST_CHANNEL, start, start + TEST_WINDOW_LENGTH,
                   1U, 1U, 1U);
        Check("Init with ChannelEnable = 1 = HAL_OK",
              ((HAL_MPU_Init(&hmpu_dev) == HAL_OK) ? 1U : 0U));
        Check("channel enabled", ((ChannelEnableBit(TEST_INSTANCE, TEST_CHANNEL) == 1U) ? 1U : 0U));

        /* ---- Step 5: idempotence ---------------------------------- */
        printf("\r\n-----------------Init: repeated call----------------- \r\n");
        Check("second Init with the same configuration = HAL_OK",
              ((HAL_MPU_Init(&hmpu_dev) == HAL_OK) ? 1U : 0U));
        Check("range unchanged",
              (((HAL_MPU_GetAddressRange(&hmpu_dev, TEST_CHANNEL, &rd_start, &rd_end) == HAL_OK) &&
                (rd_start == start) && (rd_end == (start + TEST_WINDOW_LENGTH))) ? 1U : 0U));
        Check("protections unchanged",
              ((ChannelEnableBit(TEST_INSTANCE, TEST_CHANNEL) == 1U) ? 1U : 0U));
        Check("state still READY",
              ((HAL_MPU_GetState(&hmpu_dev) == HAL_MPU_STATE_READY) ? 1U : 0U));

        /* ---- Step 6: run-time validation --------------------------- */
        printf("\r\n-----------------Init: run-time validation----------------- \r\n");

        /* a wrong Size / Version is rejected by the meta field check */
        LoadConfig(TEST_INSTANCE, TEST_CHANNEL, start, start + TEST_WINDOW_LENGTH, 1U, 1U, 1U);
        mpu_init.Size = 1U;
        hmpu_dev.Init = mpu_init;
        Check("Init with a wrong Size = HAL_ERROR",
              ((HAL_MPU_Init(&hmpu_dev) == HAL_ERROR) ? 1U : 0U));
        Check("... reports HAL_MPU_ERROR_INVALID_PARAM",
              (((HAL_MPU_GetError(&hmpu_dev) & HAL_MPU_ERROR_INVALID_PARAM) != 0U) ? 1U : 0U));

        LoadConfig(TEST_INSTANCE, TEST_CHANNEL, start, start + TEST_WINDOW_LENGTH, 1U, 1U, 1U);
        mpu_init.Version = 0U;
        hmpu_dev.Init = mpu_init;
        Check("Init with a wrong Version = HAL_ERROR",
              ((HAL_MPU_Init(&hmpu_dev) == HAL_ERROR) ? 1U : 0U));

        /* an inverted range is rejected */
        LoadConfig(TEST_INSTANCE, TEST_CHANNEL, start + TEST_WINDOW_LENGTH, start, 1U, 1U, 1U);
        Check("Init with StartAddr >= EndAddr = HAL_ERROR",
              ((HAL_MPU_Init(&hmpu_dev) == HAL_ERROR) ? 1U : 0U));

        /* an enable field above 1 is rejected */
        LoadConfig(TEST_INSTANCE, TEST_CHANNEL, start, start + TEST_WINDOW_LENGTH, 2U, 1U, 1U);
        Check("Init with WriteProtectEnable = 2 = HAL_ERROR",
              ((HAL_MPU_Init(&hmpu_dev) == HAL_ERROR) ? 1U : 0U));

        LoadConfig(TEST_INSTANCE, TEST_CHANNEL, start, start + TEST_WINDOW_LENGTH, 1U, 1U, 2U);
        Check("Init with ChannelEnable = 2 = HAL_ERROR",
              ((HAL_MPU_Init(&hmpu_dev) == HAL_ERROR) ? 1U : 0U));

        /* an instance above 4 and a channel above the count are rejected */
        LoadConfig(TEST_BAD_INSTANCE, TEST_CHANNEL, start, start + TEST_WINDOW_LENGTH, 1U, 1U, 1U);
        Check("Init with instance 5 = HAL_ERROR",
              ((HAL_MPU_Init(&hmpu_dev) == HAL_ERROR) ? 1U : 0U));

        LoadConfig(TEST_INSTANCE, TEST_CHANNELS_16, start, start + TEST_WINDOW_LENGTH, 1U, 1U, 1U);
        Check("Init with channel 16 on MPU1 = HAL_ERROR",
              ((HAL_MPU_Init(&hmpu_dev) == HAL_ERROR) ? 1U : 0U));

        LoadConfig(HAL_MPU_INSTANCE_3_DMA0, TEST_CHANNELS_8, start,
                   start + TEST_WINDOW_LENGTH, 1U, 1U, 1U);
        Check("Init with channel 8 on MPU3 = HAL_ERROR",
              ((HAL_MPU_Init(&hmpu_dev) == HAL_ERROR) ? 1U : 0U));

        /* the rejected calls must not have disturbed the handle or the channel */
        hmpu_dev.Instance = TEST_INSTANCE;
        Check("state still READY after the rejected calls",
              ((HAL_MPU_GetState(&hmpu_dev) == HAL_MPU_STATE_READY) ? 1U : 0U));
        Check("channel configuration unchanged after the rejected calls",
              (((HAL_MPU_GetChannelConfig(&hmpu_dev, TEST_CHANNEL, &rd_cfg) == HAL_OK) &&
                (rd_cfg.StartAddr == start) &&
                (rd_cfg.EndAddr == (start + TEST_WINDOW_LENGTH)) &&
                (rd_cfg.WriteProtectEnable == 1U) &&
                (rd_cfg.ReadProtectEnable == 1U) &&
                (rd_cfg.ChannelEnable == 1U)) ? 1U : 0U));

        /* ---- Step 7: write protection on MPU0 ---------------------- */
        printf("\r\n-----------------Init: MPU0 write protection----------------- \r\n");
        __HAL_CLEAR_STRUCT(&hmpu_dev);
        hmpu_dev.Instance = HAL_MPU_INSTANCE_0_IBUS;

        LoadConfig(HAL_MPU_INSTANCE_0_IBUS, 0U, start, start + TEST_WINDOW_LENGTH, 1U, 1U, 1U);
        Check("Init on MPU0 with WriteProtectEnable = 1 = HAL_ERROR",
              ((HAL_MPU_Init(&hmpu_dev) == HAL_ERROR) ? 1U : 0U));
        Check("... reports HAL_MPU_ERROR_NOT_SUPPORTED",
              (((HAL_MPU_GetError(&hmpu_dev) & HAL_MPU_ERROR_NOT_SUPPORTED) != 0U) ? 1U : 0U));
        Check("MPU0 read protection not enabled by the rejected call",
              (((HAL_MPU_GetIPortBlock(HAL_MPU_INSTANCE_0_IBUS)->RPTEN & 0x0001UL) == 0U) ? 1U : 0U));

        LoadConfig(HAL_MPU_INSTANCE_0_IBUS, 0U, start, start + TEST_WINDOW_LENGTH, 0U, 1U, 1U);
        Check("Init on MPU0 with read protection only = HAL_OK",
              ((HAL_MPU_Init(&hmpu_dev) == HAL_OK) ? 1U : 0U));
        Check("MPU0 RPTEN bit 0 set",
              (((HAL_MPU_GetIPortBlock(HAL_MPU_INSTANCE_0_IBUS)->RPTEN & 0x0001UL) != 0U) ? 1U : 0U));
        Check("MPU0 has no write protection bit to set",
              ((HAL_MPU_GetChannelConfig(&hmpu_dev, 0U, &rd_cfg) == HAL_OK) ? 1U : 0U));

        (void)HAL_MPU_DeInit(&hmpu_dev);
        Check("MPU0 DeInit cleared RPTEN",
              (((HAL_MPU_GetIPortBlock(HAL_MPU_INSTANCE_0_IBUS)->RPTEN & 0x0001UL) == 0U) ? 1U : 0U));

        /* ---- Step 8: instance / channel count coverage ------------- */
        printf("\r\n-----------------Init: instance coverage----------------- \r\n");
        /* the helper takes the highest channel INDEX of the instance, i.e. the
           channel count minus one (16 channels -> 15, 8 channels -> 7) */
        InstanceCoverage(HAL_MPU_INSTANCE_0_IBUS,    TEST_CHANNELS_16 - 1U);
        InstanceCoverage(HAL_MPU_INSTANCE_1_DBUS,    TEST_CHANNELS_16 - 1U);
        InstanceCoverage(HAL_MPU_INSTANCE_2_PBUS,    TEST_CHANNELS_16 - 1U);
        InstanceCoverage(HAL_MPU_INSTANCE_3_DMA0,    TEST_CHANNELS_8 - 1U);
        InstanceCoverage(HAL_MPU_INSTANCE_4_DMA1,    TEST_CHANNELS_8 - 1U);

        /* ---- Step 9: the neighbour channel is not disturbed -------- */
        printf("\r\n-----------------Init: neighbour channel----------------- \r\n");
        __HAL_CLEAR_STRUCT(&hmpu_dev);
        hmpu_dev.Instance = TEST_INSTANCE;

        LoadConfig(TEST_INSTANCE, TEST_NEIGHBOUR, start + 0x40U, start + 0x44U, 1U, 0U, 1U);
        Check("neighbour configured",
              ((HAL_MPU_Init(&hmpu_dev) == HAL_OK) ? 1U : 0U));

        LoadConfig(TEST_INSTANCE, TEST_CHANNEL, start, start + TEST_WINDOW_LENGTH, 1U, 1U, 1U);
        Check("target channel configured again",
              ((HAL_MPU_Init(&hmpu_dev) == HAL_OK) ? 1U : 0U));
        Check("neighbour range unchanged",
              (((HAL_MPU_GetAddressRange(&hmpu_dev, TEST_NEIGHBOUR, &rd_start, &rd_end) == HAL_OK) &&
                (rd_start == (start + 0x40U)) && (rd_end == (start + 0x44U))) ? 1U : 0U));
        Check("neighbour still enabled",
              ((ChannelEnableBit(TEST_INSTANCE, TEST_NEIGHBOUR) == 1U) ? 1U : 0U));

        (void)HAL_MPU_Cmd(&hmpu_dev, TEST_NEIGHBOUR, MPU_DISABLE);

        /* ---- Step 10: the error code set --------------------------- */
        printf("\r\n-----------------error codes----------------- \r\n");
        Check("HAL_MPU_ERROR_NONE is zero",
              ((HAL_MPU_ERROR_NONE == 0U) ? 1U : 0U));
        /* The codes are independent bit flags, so two of them can be reported
           together and none of them overlaps another. HAL_MPU_ERROR_HARDWARE
           is the code of the read-back verification of HAL_MPU_Init(); it is
           only produced by a peripheral block that does not retain the value
           it was written, which cannot be produced from software, so this case
           checks the definition only (the healthy read-back path is covered by
           step 1 and step 5). */
        Check("error codes are independent, non overlapping flags",
              (((HAL_MPU_ERROR_INVALID_PARAM != 0U) &&
                (HAL_MPU_ERROR_HARDWARE != 0U) &&
                (HAL_MPU_ERROR_NOT_SUPPORTED != 0U) &&
                ((HAL_MPU_ERROR_INVALID_PARAM & HAL_MPU_ERROR_HARDWARE) == 0U) &&
                ((HAL_MPU_ERROR_INVALID_PARAM & HAL_MPU_ERROR_NOT_SUPPORTED) == 0U) &&
                ((HAL_MPU_ERROR_HARDWARE & HAL_MPU_ERROR_NOT_SUPPORTED) == 0U)) ? 1U : 0U));
        Check("error codes are distinct",
              (((HAL_MPU_ERROR_INVALID_PARAM != HAL_MPU_ERROR_HARDWARE) &&
                (HAL_MPU_ERROR_HARDWARE != HAL_MPU_ERROR_NOT_SUPPORTED) &&
                (HAL_MPU_ERROR_INVALID_PARAM != HAL_MPU_ERROR_NOT_SUPPORTED)) ? 1U : 0U));

        /* ---- Step 11: leave the instance clean --------------------- */
        printf("\r\n-----------------clean up----------------- \r\n");
        ResetInstanceSafe(HAL_MPU_INSTANCE_0_IBUS);
        ResetInstanceSafe(HAL_MPU_INSTANCE_1_DBUS);
        ResetInstanceSafe(HAL_MPU_INSTANCE_2_PBUS);
        ResetInstanceSafe(HAL_MPU_INSTANCE_3_DMA0);
        ResetInstanceSafe(HAL_MPU_INSTANCE_4_DMA1);

        hmpu_dev.Instance = TEST_INSTANCE;
        LoadConfig(TEST_INSTANCE, TEST_CHANNEL, start, start + TEST_WINDOW_LENGTH, 0U, 0U, 0U);
        Check("re-Init after the clean up = HAL_OK",
              ((HAL_MPU_Init(&hmpu_dev) == HAL_OK) ? 1U : 0U));
        (void)HAL_MPU_DeInit(&hmpu_dev);

        printf("\r\nsummary : failures = %u\r\n", PRINT_U32(failures));
        delay_ms(TEST_PERIOD_MS);
    }
}

/**
 * @brief  Read the channel enable bit of one instance.
 * @param  instance: MPU instance.
 * @param  channel: channel index.
 * @retval 1 when the channel is enabled, 0 otherwise.
 */
static uint32 ChannelEnableBit(uint32 instance, uint32 channel)
{
    MPU_InitTypeDef cfg;
    HAL_MPU_HandleTypeDef probe;

    __HAL_CLEAR_STRUCT(&probe);
    probe.Instance = (HAL_MPU_InstanceTypeDef)instance;
    probe.State    = HAL_MPU_STATE_READY;

    if (HAL_MPU_GetChannelConfig(&probe, channel, &cfg) != HAL_OK)
    {
        return 0U;
    }

    return cfg.ChannelEnable;
}

/**
 * @brief  Fill the configuration structure of the handle.
 * @param  instance: MPU instance.
 * @param  channel: channel index.
 * @param  start: first protected address.
 * @param  end: last protected address (exclusive).
 * @param  wp: write protection enable request.
 * @param  rp: read protection enable request.
 * @param  ce: channel enable request.
 * @retval None
 */
static void LoadConfig(uint32 instance, uint32 channel, uint32 start, uint32 end,
                       uint32 wp, uint32 rp, uint32 ce)
{
    HAL_MPU_StructInit(&mpu_init);
    mpu_init.Instance           = (HAL_MPU_InstanceTypeDef)instance;
    mpu_init.Channel            = channel;
    mpu_init.StartAddr          = start;
    mpu_init.EndAddr            = end;
    mpu_init.WriteProtectEnable = wp;
    mpu_init.ReadProtectEnable  = rp;
    mpu_init.ChannelEnable      = ce;
    hmpu_dev.Init = mpu_init;
}

/**
 * @brief  Initialize the last channel of one instance and check that one past
 *         it is rejected, then reset the instance.
 * @note   MPU0 has no write protection, so only the read protection is
 *         requested there.
 * @param  instance: MPU instance.
 * @param  lastChannel: highest channel index of the instance.
 * @retval None
 */
static void InstanceCoverage(uint32 instance, uint32 lastChannel)
{
    HAL_MPU_HandleTypeDef hmpu;
    uint32 start = (uint32)(unsigned long)&protected_word;

    __HAL_CLEAR_STRUCT(&hmpu);
    hmpu.Instance = (HAL_MPU_InstanceTypeDef)instance;

    HAL_MPU_StructInit(&mpu_init);
    mpu_init.Instance    = (HAL_MPU_InstanceTypeDef)instance;
    mpu_init.Channel     = lastChannel;
    mpu_init.StartAddr   = start;
    mpu_init.EndAddr     = start + TEST_WINDOW_LENGTH;
    mpu_init.ChannelEnable = 1U;

    if (instance == HAL_MPU_INSTANCE_0_IBUS)
    {
        mpu_init.WriteProtectEnable = 0U;
        mpu_init.ReadProtectEnable  = 1U;
    }
    else
    {
        mpu_init.WriteProtectEnable = 1U;
        mpu_init.ReadProtectEnable  = 1U;
    }
    hmpu.Init = mpu_init;

    Check("last channel of the instance accepted",
          ((HAL_MPU_Init(&hmpu) == HAL_OK) ? 1U : 0U));

    mpu_init.Channel = lastChannel + 1U;
    hmpu.Init = mpu_init;
    Check("channel past the last one rejected",
          ((HAL_MPU_Init(&hmpu) == HAL_ERROR) ? 1U : 0U));

    /* a successful Init leaves the handle READY, so ResetInstance is accepted */
    Check("ResetInstance of the instance = HAL_OK",
          ((HAL_MPU_ResetInstance(&hmpu) == HAL_OK) ? 1U : 0U));
}

/**
 * @brief  Reset one instance when the handle state allows it.
 * @param  instance: MPU instance.
 * @retval None
 */
static void ResetInstanceSafe(uint32 instance)
{
    HAL_MPU_HandleTypeDef hmpu;

    __HAL_CLEAR_STRUCT(&hmpu);
    hmpu.Instance = (HAL_MPU_InstanceTypeDef)instance;
    hmpu.State    = HAL_MPU_STATE_READY;

    (void)HAL_MPU_ResetInstance(&hmpu);
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition == 0U)
    {
        failures++;
    }
    printf("%-52s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Configure the system clock tree using the HAL SMU / PMU drivers.
 * @note   Same clock tree as the CLINT / CMU reference suites: OSC 20 MHz as
 *         the PLL source, PLLDivN = 20 / PLLDivF = 180 / PLLDivQ = 1 /
 *         PLLDivR = 4 -> 180 MHz VCO, AXI4Bus3 = /2, APBBus0 = /2,
 *         APBBus1 = /2, CANX2 = /8; the 2.5V LDO is scaled to 2.78 V and the
 *         1.2V LDO to 1.34 V as in the reference suites.
 * @note   Clock tree order (the order the chip requires, and the order the
 *         vendor test case uses): configure the oscillators and the PLL and
 *         switch the system clock to it, then write the bus clock dividers.
 *         HAL_SMU_OscConfig() programs the EFLASH controller clock (CLKFRQ)
 *         before the switch and lets it follow the new system clock afterwards
 *         (EFLASH_CLK_UPDATE), so no explicit HAL_FLASH_SetClockFrequency() is
 *         needed here; it also updates SystemCoreClock together with the HAL
 *         time base.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef  SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef   SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it (CLKFRQ above), so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Set the bus clock dividers (the system clock source is already set by
       HAL_SMU_OscConfig() above) */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
