/**
 * @file    PMU_IT_DRV_001.c
 * @brief   HAL PMU integration test case 001 (RC32K clock scaling, minimum, SIRC on CLKOUT).
 *
 * One-to-one HAL library port of the original AS32x601 standard-library
 * test case PMU_IT_DRV_001.c. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_PMU_Init()
 *   HAL_PMU_RC32KFrequencySca()
 *   HAL_SMU_MCOConfig() (SIRC routed to the CLKOUT pad)
 *   HAL_PMU_GetState() / HAL_PMU_GetError()
 *   HAL_GPIO_Init() / HAL_GPIO_PinAFConfig() (CLKOUT pad)
 *   PMU_FLAG_3V3LDORDY / PMU_FLAG_1V2LDORDY (LDO ready flags)
 *
 * Test procedure (same as the original test case):
 *   1. Configure GPIOB pin 4 as the CLKOUT output;
 *   2. Program the RC32K frequency scaling to 0x00U;
 *   3. Route the SIRC clock (the RC32K oscillator) to the CLKOUT pad;
 *   4. Keep the measurement running (the frequency is measured on the pin).
 *
 * Test configuration (same values as the original test case):
 *   RC32KFS = 0x00U, CLKOUT = SIRC.
 *
 * Expected behaviour:
 *   - The OCR.RC32KFS field reads back the programmed value and the
 *     OTHCFGR.CLKOUTMUX field reads back the SIRC selection (a PMU / SMU held
 *     in reset would read back zeros);
 *   - The frequency measured on PB4 is about 22 kHz (observed value of the
 *     original test case; the measurement itself is done externally, so the
 *     case only reports the programmed configuration).
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* RC32K frequency scaling programmed by this case */
#define TEST_RC32K_FS               (0x00U)

/* Frequency expected on the CLKOUT pin (informative, measured externally) */
#define TEST_EXPECTED_KHZ           (22)

/* CLKOUT pad: GPIOB pin 4, alternate function CLKOUT */
#define TEST_CLKOUT_GPIO            GPIOB
#define TEST_CLKOUT_PIN             GPIO_PIN_4
#define TEST_CLKOUT_PIN_SOURCE      GPIO_PinSource4

/* Reporting period of the measurement loop (ms) */
#define TEST_POLL_MS                (1000U)

/* Private variables ---------------------------------------------------------*/
static HAL_PMU_HandleTypeDef hpmu_dev;      /*!< PMU device handle            */
static uint32                failures = 0U; /*!< failed checks                */

static HAL_SMU_HandleTypeDef hsmu_clk;   /*!< SMU handle (lock / state / error) */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void PMU_Init(void);
static void Check(const char *name, uint32 condition);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    GPIO_InitTypeDef gpio_init;
    uint32           rc32kfs;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL, 45 MHz core clock) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n\r\n==== PMU_IT_DRV_001: RC32K clock scaling, minimum, SIRC on CLKOUT ====\r\n");
    printf("Data : %s\r\n", __DATE__);
    printf("Time : %s\r\n", __TIME__);
    printf("RC32K scaling = 0x00 (minimum), SIRC clock on PB4\r\n");

    /* ---- Step 1: PMU initialization ------------------------------------ */
    PMU_Init();

    /* ---- Step 2: CLKOUT pin (GPIOB pin 4, alternate function CLKOUT) --- */
    __HAL_SMU_GPIOB_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&gpio_init);
    HAL_GPIO_StructInit(&gpio_init);
    gpio_init.Pin          = TEST_CLKOUT_PIN;
    gpio_init.Mode         = GPIO_MODE_OUTPUT_PP;
    gpio_init.Pull         = GPIO_NOPULL;
    gpio_init.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;    /* 4.5 mA, as in the original */
    HAL_GPIO_Init(TEST_CLKOUT_GPIO, &gpio_init);
    HAL_GPIO_PinAFConfig(TEST_CLKOUT_GPIO, TEST_CLKOUT_PIN_SOURCE, GPIO_AF_CLKOUT);

    /* the multiplex interface encodes 3 bits per pin (MI0SR for pins 0..9) */
    printf("MI0SR = 0x%X (AF field of PB4 = 0x%X, expected 0x%X)\r\n",
           PRINT_U32(TEST_CLKOUT_GPIO->MI0SR),
           PRINT_U32((TEST_CLKOUT_GPIO->MI0SR >> ((uint32)TEST_CLKOUT_PIN_SOURCE * 3U)) & 0x7U),
           PRINT_U32(GPIO_AF_CLKOUT));
    Check("CLKOUT pin multiplexed",
          (((TEST_CLKOUT_GPIO->MI0SR >> ((uint32)TEST_CLKOUT_PIN_SOURCE * 3U)) & 0x7U) ==
           (uint32)GPIO_AF_CLKOUT));

    /* ---- Step 3: RC32K frequency scaling ------------------------------- */
    Check("RC32K scaling accepted",
          (HAL_PMU_RC32KFrequencySca(&hpmu_dev, TEST_RC32K_FS) == HAL_OK));

    rc32kfs = (hpmu_dev.Instance->OCR & PMU_OCR_RC32KFS) >> PMU_OCR_RC32KFS_Pos;
    printf("OCR = 0x%X (RC32KFS = 0x%X, expected 0x%X)\r\n",
           PRINT_U32(hpmu_dev.Instance->OCR), PRINT_U32(rc32kfs),
           PRINT_U32(TEST_RC32K_FS));
    Check("RC32KFS read-back", (rc32kfs == TEST_RC32K_FS));
    /* ---- Step 3b: LDO ready flags -------------------------------------- *
     * The flag selectors encode the status register in bits 6:5 and the bit
     * position in bits 4:0 (PMU_FLAG_3V3LDORDY = 0x20, PMU_FLAG_1V2LDORDY =
     * 0x22), so this also exercises the flag decoding of the driver. Both
     * rails power the chip: a zero here means the handle or the PMU is held
     * in reset. The 2.5 V rail and the backup 1.2 V rail are only reported,
     * because their enable state depends on the board. */
    printf("LDOSR = 0x%X (3V3 ready = %u, 2V5 ready = %u, 1V2 ready = %u, 1V2 backup ready = %u)\r\n",
           PRINT_U32(hpmu_dev.Instance->LDOSR),
           PRINT_U32(HAL_PMU_GetFlagStatus(&hpmu_dev, PMU_FLAG_3V3LDORDY)),
           PRINT_U32(HAL_PMU_GetFlagStatus(&hpmu_dev, PMU_FLAG_2V5LDORDY)),
           PRINT_U32(HAL_PMU_GetFlagStatus(&hpmu_dev, PMU_FLAG_1V2LDORDY)),
           PRINT_U32(HAL_PMU_GetFlagStatus(&hpmu_dev, PMU_FLAG_1V2BLDORDY)));
    Check("3.3V LDO ready flag set",
          (HAL_PMU_GetFlagStatus(&hpmu_dev, PMU_FLAG_3V3LDORDY) != 0U));
    Check("1.2V LDO ready flag set",
          (HAL_PMU_GetFlagStatus(&hpmu_dev, PMU_FLAG_1V2LDORDY) != 0U));

    /* ---- Step 4: route the SIRC clock to the CLKOUT pad ---------------- */
    HAL_SMU_MCOConfig(&hsmu_clk, SMU_CLKOUTMUX_SIRC);

    printf("OTHCFGR = 0x%X (CLKOUTMUX = 0x%X, expected 0x%X)\r\n",
           PRINT_U32(SMU->OTHCFGR),
           PRINT_U32((SMU->OTHCFGR & SMU_OTHCFGR_CLKOUTMUX) >> SMU_OTHCFGR_CLKOUTMUX_Pos),
           PRINT_U32(SMU_CLKOUTMUX_SIRC));
    Check("CLKOUT mux = SIRC",
          (((SMU->OTHCFGR & SMU_OTHCFGR_CLKOUTMUX) >> SMU_OTHCFGR_CLKOUTMUX_Pos) ==
           SMU_CLKOUTMUX_SIRC));

    printf("measure PB4: expected about %u kHz (RC32KFS = 0x%X)\r\n",
           PRINT_U32(TEST_EXPECTED_KHZ), PRINT_U32(TEST_RC32K_FS));

    /* ---- Step 5: keep the clock output running ------------------------- */
    while (1)
    {
        printf("RC32KFS = 0x%X | CLKOUTMUX = 0x%X | expected PB4 = %u kHz | summary : failures = %u\r\n",
               PRINT_U32((hpmu_dev.Instance->OCR & PMU_OCR_RC32KFS) >> PMU_OCR_RC32KFS_Pos),
               PRINT_U32((SMU->OTHCFGR & SMU_OTHCFGR_CLKOUTMUX) >> SMU_OTHCFGR_CLKOUTMUX_Pos),
               PRINT_U32(TEST_EXPECTED_KHZ), PRINT_U32(failures));
        delay_ms(TEST_POLL_MS);
    }
}

/**
 * @brief  Configure the system clock tree using the HAL SMU driver.
 * @note   Clock tree shared by every integration test suite of this library:
 *         OSC 20 MHz as the PLL source, PLLDivR = 0x04 / PLLDivN = 0x14 /
 *         PLLDivF = 0xB4 / PLLDivQ = 0x01 -> 45 MHz core clock, then
 *         AXI4Bus3 = /2, APBBus0 = /2, APBBus1 = /2 and CANX2 = /8. The
 *         dividers are programmed while the system clock is still the
 *         power-on source and the PLL is switched in afterwards, which is
 *         the order the chip requires (see HAL_SMU_OscConfig()).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it, so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Clock tree order: the bus dividers are written while the system clock is
       still the power-on source (FIRC), so that the new divider values are
       already in place when the faster clock arrives; the previous call has
       already programmed the EFLASH controller clock and switched the system
       clock. */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition == 0U)
    {
        failures++;
    }
    printf("%-44s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Initialize the PMU handle and report its state.
 * @note   HAL_PMU_Init() must run before any other PMU API of this project:
 *         the configuration APIs are gated on the handle state and refuse to
 *         work on a handle that is still in the RESET state.
 * @param  None
 * @retval None
 */
static void PMU_Init(void)
{
    __HAL_CLEAR_STRUCT(&hpmu_dev);
    hpmu_dev.Instance = PMU;

    Check("PMU init", (HAL_PMU_Init(&hpmu_dev) == HAL_OK));
    printf("PMU state = %u (1 = READY), error = %u\r\n",
           PRINT_U32(HAL_PMU_GetState(&hpmu_dev)),
           PRINT_U32(HAL_PMU_GetError(&hpmu_dev)));
}

/*****END OF FILE*****/
