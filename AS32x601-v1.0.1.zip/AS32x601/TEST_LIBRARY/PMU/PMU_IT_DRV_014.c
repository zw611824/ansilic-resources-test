/**
 * @file    PMU_IT_DRV_014.c
 * @brief   HAL PMU integration test case 014 (deep sleep mode, RTC wake-up (20 s)).
 *
 * One-to-one HAL library port of the original AS32x601 standard-library
 * test case PMU_IT_DRV_014.c. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_PMU_Init()
 *   HAL_PMU_WakeUpSourceCmd()
 *   HAL_PMU_PowerModeConfig() / HAL_PMU_GetPowerModeStatus()
 *   HAL_PMU_GetFlagStatus() / HAL_PMU_GetWakeUpFlag() / HAL_PMU_ClearFlag()
 *   HAL_PMU_GetState() / HAL_PMU_GetError()
 *   HAL_PLIC_Init() (RTC alarm interrupt line)
 *   HAL_RTC_Init() / HAL_RTC_Cmd()
 *   HAL_RTC_SetTime() / HAL_RTC_GetTime()
 *   HAL_RTC_SetDate() / HAL_RTC_GetDate()
 *   HAL_RTC_AlarmStructInit() / HAL_RTC_SetAlarm_IT()
 *   HAL_RTC_WakeUpCmd()
 *   HAL_RTC_AlarmIRQHandler() / HAL_RTC_AlarmEventCallback()
 *   HAL_RTC_GetState() / HAL_RTC_GetError()
 *   RTC control register prerequisite (calendar written while disabled)
 *
 * Test procedure (same as the original test case):
 *   - report (and clear) the wake-up flag left over by a previous run;
 *   1. Configure the RTC and program its alarm 20 s ahead;
 *   2. Enable the RTC wake-up source in the PMU (WKEN);
 *   3. Enter deep sleep mode (PMCR.POWMC);
 *   4. The wake-up resets the system, so the program restarts from the
 *      beginning and reports the wake-up flag at its start.
 *
 * Test configuration (same values as the original test case):
 *   power mode     = deep sleep (HAL_PMU_POWERMODE_DEEPSLEEP)
 *   wake-up source = RTC (HAL_PMU_WKSOURCE_RTC)
 *   RTC            = division 1638, alarm 20 s ahead
 *
 * Expected behaviour:
 *   - The WKEN read-back shows the enabled wake-up source and the PMCR read-back
 *     shows the selected power mode before the mode is entered (a missing WKEN
 *     bit would leave the chip asleep forever);
 *   - The wake-up resets the system: the program restarts, the wake-up flag of
 *     the RTC source is still set and is reported (then cleared) at start-up.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Power mode entered by this case */
#define TEST_POWER_MODE             (HAL_PMU_POWERMODE_DEEPSLEEP)

/* Name of the power mode (for the report) */
#define TEST_POWER_NAME             "deep sleep"

/* Wake-up source enabled by this case */
#define TEST_WAKEUP_SOURCE          (HAL_PMU_WKSOURCE_RTC)

/* Wake-up flag expected after the wake-up */
#define TEST_WAKEUP_FLAG            (PMU_FLAG_RTCWK)

/* Wake-up clear value (WKFR write one to clear) of the expected source */
#define TEST_WAKEUP_CLEAR           (PMU_CLEAR_RTCWKF)

/* Human readable name of the wake-up source (for the report) */
#define TEST_WAKEUP_NAME            "RTC"

/* RTC configuration (same values as the original test case: divider 1638,
 * calendar 2025-07-21 15:48:00, alarm programmed 20 s ahead) */
#define TEST_RTC_DIVISION           (1638U)
#define TEST_TIME_HOURS             (15U)
#define TEST_TIME_MINUTES           (48U)
#define TEST_TIME_SECONDS           (0U)
#define TEST_TIME_TOS               (0U)
#define TEST_DATE_CENTURY           (20U)
#define TEST_DATE_YEAR              (25U)
#define TEST_DATE_MONTH             (RTC_Month_July)
#define TEST_DATE_DATE              (21U)
#define TEST_DATE_WEEKDAY           (RTC_Weekday_Monday)
#define TEST_ALARM_OFFSET_S         (20U)
#define TEST_ALARM_HOURS            (TEST_TIME_HOURS)
#define TEST_ALARM_MINUTES          (TEST_TIME_MINUTES)
#define TEST_ALARM_SECONDS          (TEST_TIME_SECONDS + TEST_ALARM_OFFSET_S)
#define TEST_ALARM_TOS              (TEST_TIME_TOS)
#define TEST_ALARM_CENTURY          (TEST_DATE_CENTURY)
#define TEST_ALARM_YEAR             (TEST_DATE_YEAR)
#define TEST_ALARM_MONTH            (RTC_Month_September)
#define TEST_ALARM_DATE             (TEST_DATE_DATE)
#define TEST_ALARM_WEEKDAY          (RTC_Weekday_Wednesday)

/* Settling time granted to the wake-up path after PMCR is written (ms) */
#define TEST_WAKE_SETTLE_MS         (100U)

/* Reporting period of the final loop (ms) */
#define TEST_POLL_MS                (500U)

/* Private variables ---------------------------------------------------------*/
static HAL_PMU_HandleTypeDef hpmu_dev;      /*!< PMU device handle            */
static uint32                failures = 0U; /*!< failed checks                */
static volatile uint32       source_flag_seen = 0U; /*!< wake-up flag seen     */

static RTC_HandleTypeDef   hrtc_dev;        /*!< RTC device handle            */
static RTC_InitTypeDef     rtc_init;        /*!< RTC configuration structure  */
static PLIC_InitTypeDef    plic_init;       /*!< PLIC configuration structure */
static RTC_AlarmTypeDef    alarm;           /*!< Alarm configuration          */

/* Last calendar read back by the report */
static uint8 r_date_year;
static uint8 r_date_month;
static uint8 r_date_date;
static uint8 r_time_hours;
static uint8 r_time_minutes;
static uint8 r_time_seconds;
static uint8 r_time_tos;

static HAL_SMU_HandleTypeDef hsmu_clk;   /*!< SMU handle (lock / state / error) */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void PMU_Init(void);
static void ReportWakeUpFlags(void);
static void Check(const char *name, uint32 condition);

static void RTC_SetCalendar(uint8 hours, uint8 min, uint8 sec, uint8 tos,
                            uint8 century, uint8 year, uint8 month, uint8 date,
                            uint8 weekday);
static void RTC_GetCalendar(void);
static uint8 RTC_MonthToNumber(uint8 month);

/**
 * @brief PMU wake-up flag table: flag selector, clear value and source name.
 * @note  Every wake-up flag of the PMU is listed, so any unexpected wake-up
 *        source is reported instead of being silently ignored.
 */
typedef struct
{
    uint32      Flag;                       /*!< PMU_FLAG_xxx selector        */
    uint32      Clear;                      /*!< PMU_CLEAR_xxx write value    */
    const char *Name;                       /*!< wake-up source name          */
} WakeUpFlagTypeDef;

static const WakeUpFlagTypeDef wakeup_flags[] =
{
    { PMU_FLAG_IWDGWK, PMU_CLEAR_IWDGWKF, "IWDG" },
    { PMU_FLAG_RTCWK,  PMU_CLEAR_RTCWKF,  "RTC"  },
    { PMU_FLAG_PH0WK,  PMU_CLEAR_PH0WKF,  "PH0"  },
    { PMU_FLAG_PH1WK,  PMU_CLEAR_PH1WKF,  "PH1"  },
    { PMU_FLAG_PH2WK,  PMU_CLEAR_PH2WKF,  "PH2"  },
    { PMU_FLAG_PH3WK,  PMU_CLEAR_PH3WKF,  "PH3"  },
    { PMU_FLAG_PH4WK,  PMU_CLEAR_PH4WKF,  "PH4"  },
    { PMU_FLAG_PH5WK,  PMU_CLEAR_PH5WKF,  "PH5"  },
    { PMU_FLAG_PH6WK,  PMU_CLEAR_PH6WKF,  "PH6"  },
    { PMU_FLAG_PH7WK,  PMU_CLEAR_PH7WKF,  "PH7"  },
    { PMU_FLAG_PH8WK,  PMU_CLEAR_PH8WKF,  "PH8"  },
    { PMU_FLAG_PH9WK,  PMU_CLEAR_PH9WKF,  "PH9"  },
    { PMU_FLAG_FOCUR,  PMU_CLEAR_FOCURF,  "FOCU" },
};

/**
 * @brief  Read every PMU wake-up flag; print and clear the ones that are set.
 * @note   Mirrors the flag polling of the original test case. The flag of the
 *         expected source additionally arms the "expected wake-up source
 *         reported" check, and the clear operation is verified afterwards
 *         (the wake-up flags are cleared by writing one to the WKFR register).
 * @param  None
 * @retval None
 */
static void ReportWakeUpFlags(void)
{
    uint32 i;
    uint32 count;

    count = (uint32)(sizeof(wakeup_flags) / sizeof(wakeup_flags[0]));

    for (i = 0U; i < count; i++)
    {
        if (HAL_PMU_GetFlagStatus(&hpmu_dev, wakeup_flags[i].Flag) != 0U)
        {
            printf("%s wake up!\r\n", wakeup_flags[i].Name);
            HAL_PMU_ClearFlag(&hpmu_dev, wakeup_flags[i].Clear);

            if (wakeup_flags[i].Flag == (uint32)TEST_WAKEUP_FLAG)
            {
                source_flag_seen = 1U;
            }
        }
    }

    /* acknowledge the expected flag as well and verify the clear operation */
    HAL_PMU_ClearFlag(&hpmu_dev, TEST_WAKEUP_CLEAR);
    printf("WKFR = 0x%X after clearing the reported flags\r\n",
           PRINT_U32(hpmu_dev.Instance->WKFR));
    Check("wake-up flag acknowledged (WKFR cleared)",
          (HAL_PMU_GetFlagStatus(&hpmu_dev, TEST_WAKEUP_FLAG) == 0U));
}

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL, 45 MHz core clock) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n\r\n==== PMU_IT_DRV_014: deep sleep mode, RTC wake-up (20 s) ====\r\n");
    printf("Data : %s\r\n", __DATE__);
    printf("Time : %s\r\n", __TIME__);
    printf("RTC wake up deep sleep 20s\r\n");

    /* ---- Step 1a: PMU initialization ----------------------------------- */
    PMU_Init();

    /* ---- Step 1b: report a wake-up left over from the previous run ------ *
     * In deep sleep mode the wake-up resets the system, so this program
     * restarts from the beginning and the wake-up flag raised by the power
     * mode hardware is still set: reporting it here is what makes the
     * deep sleep cases observable on the console (the section after the
     * power mode request below is never reached in that mode). On a cold
     * start no flag is set and nothing is printed. */
    ReportWakeUpFlags();
    if (source_flag_seen != 0U)
    {
        Check("previous wake-up reported (deep sleep restarts the program)",
              source_flag_seen);
        source_flag_seen = 0U;
    }
    printf("WKFR before entering the mode = 0x%X\r\n",
           PRINT_U32(hpmu_dev.Instance->WKFR));

    /* ---- Step 1c: configure the wake-up source -------------------------- */

    /* RTC alarm as the wake-up event: the alarm line is routed through the
     * PLIC, the RTC runs on its own divider and the PMU uses the alarm as a
     * wake-up source (RTC_WakeUpCmd enables the wake-up timer path). */
    __HAL_CLEAR_STRUCT(&plic_init);
    plic_init.Size               = sizeof(plic_init);
    plic_init.Version            = PLIC_INIT_VERSION;
    plic_init.PLIC_IRQChannel    = RTC_IRQn;
    plic_init.PLIC_IRQPriority   = 1U;
    plic_init.PLIC_IRQChannelCmd = ENABLE;
    HAL_PLIC_Init(&plic_init);
    Check("RTC interrupt routed in the PLIC",
          (PLIC->AXI_PLIC_PRIORITY[RTC_IRQn - 1U] == 1U));

    __HAL_CLEAR_STRUCT(&hrtc_dev);
    hrtc_dev.Instance = RTC;
    __HAL_CLEAR_STRUCT(&rtc_init);
    rtc_init.Size     = sizeof(RTC_InitTypeDef);
    rtc_init.Version  = RTC_INIT_VERSION;
    rtc_init.Division = TEST_RTC_DIVISION;
    hrtc_dev.Init     = rtc_init;
    Check("RTC init", (HAL_RTC_Init(&hrtc_dev) == HAL_OK));
    printf("RTC state = %u (1 = READY), error = %u\r\n",
           PRINT_U32(HAL_RTC_GetState(&hrtc_dev)),
           PRINT_U32(HAL_RTC_GetError(&hrtc_dev)));

    RTC_SetCalendar(TEST_TIME_HOURS, TEST_TIME_MINUTES, TEST_TIME_SECONDS,
                    TEST_TIME_TOS, TEST_DATE_CENTURY, TEST_DATE_YEAR,
                    TEST_DATE_MONTH, TEST_DATE_DATE, TEST_DATE_WEEKDAY);
    RTC_GetCalendar();
    Check("calendar read-back", ((r_time_hours == TEST_TIME_HOURS) &&
                                 (r_time_seconds == TEST_TIME_SECONDS) &&
                                 (r_date_date == TEST_DATE_DATE)));
    /* ---- Step 1b: RTC device prerequisite ------------------------------- *
     * The device ignores writes to the time and the date registers while the
     * calendar is enabled, so the calendar above has to be written before
     * HAL_RTC_Cmd(ENABLE): the control register must still report the
     * calendar as disabled at this point. */
    printf("RTC CR = 0x%X (calendar enabled = %u, expected 0 at this point)\r\n",
           PRINT_U32(hrtc_dev.Instance->CR),
           PRINT_U32(((hrtc_dev.Instance->CR & RTC_CR_EN) != 0U) ? 1U : 0U));
    Check("calendar still disabled while it was written",
          ((hrtc_dev.Instance->CR & RTC_CR_EN) == 0U));

    printf("calendar = %02u-%02u-%02u %02u:%02u:%02u.%u\r\n",
           PRINT_U32(r_date_year), PRINT_U32(RTC_MonthToNumber(r_date_month)),
           PRINT_U32(r_date_date), PRINT_U32(r_time_hours),
           PRINT_U32(r_time_minutes), PRINT_U32(r_time_seconds),
           PRINT_U32(r_time_tos));

    __HAL_CLEAR_STRUCT(&alarm);
    HAL_RTC_AlarmStructInit(&alarm);
    alarm.RTC_AlarmTime.RTC_Hours         = TEST_ALARM_HOURS;
    alarm.RTC_AlarmTime.RTC_Minutes       = TEST_ALARM_MINUTES;
    alarm.RTC_AlarmTime.RTC_Seconds       = TEST_ALARM_SECONDS;
    alarm.RTC_AlarmTime.RTC_TenthOfSecond = TEST_ALARM_TOS;
    alarm.RTC_AlarmDate.RTC_WeekDay       = TEST_ALARM_WEEKDAY;
    alarm.RTC_AlarmDate.RTC_Century       = TEST_ALARM_CENTURY;
    alarm.RTC_AlarmDate.RTC_Year          = TEST_ALARM_YEAR;
    alarm.RTC_AlarmDate.RTC_Month         = TEST_ALARM_MONTH;
    alarm.RTC_AlarmDate.RTC_Date          = TEST_ALARM_DATE;
    alarm.RTC_AlarmTimeCompEn = RTC_AlarmTime_Hours | RTC_AlarmTime_Minutes |
                                RTC_AlarmTime_Seconds | RTC_AlarmTime_TenOfSecond;
    alarm.RTC_AlarmDataCompEn = RTC_Alarm_None;
    Check("RTC alarm programmed",
          (HAL_RTC_SetAlarm_IT(&hrtc_dev, &alarm, RTC_FORMAT_BIN) == HAL_OK));
    printf("alarm at %02u:%02u:%02u.%u (+%u s)\r\n",
           PRINT_U32(TEST_ALARM_HOURS), PRINT_U32(TEST_ALARM_MINUTES),
           PRINT_U32(TEST_ALARM_SECONDS), PRINT_U32(TEST_ALARM_TOS),
           PRINT_U32(TEST_ALARM_OFFSET_S));

    /* Enable the RTC wake-up timer (the original RTC_WakeUpCmd(ENABLE)) */
    HAL_RTC_WakeUpCmd(&hrtc_dev, ENABLE);
    Check("RTC wake-up enable set",
          ((hrtc_dev.Instance->WUCR & RTC_WUCR_WUTE) != 0U));

    Check("RTC enabled", (HAL_RTC_Cmd(&hrtc_dev, ENABLE) == HAL_OK));
    Check("calendar enabled in CR after HAL_RTC_Cmd(ENABLE)",
          ((hrtc_dev.Instance->CR & RTC_CR_EN) != 0U));

    /* ---- Step 2: enable the wake-up source ----------------------------- */
    Check("wake-up source enabled",
          (HAL_PMU_WakeUpSourceCmd(&hpmu_dev, TEST_WAKEUP_SOURCE, ENABLE) == HAL_OK));
    printf("WKEN = 0x%X (requested 0x%X)\r\n",
           PRINT_U32(hpmu_dev.Instance->WKEN), PRINT_U32(TEST_WAKEUP_SOURCE));
    Check("wake-up source bit set in WKEN",
          ((hpmu_dev.Instance->WKEN & (uint32)TEST_WAKEUP_SOURCE) != 0U));

    /* ---- Step 3: enter the power mode ---------------------------------- */
    if (TEST_POWER_MODE == HAL_PMU_POWERMODE_DEEPSLEEP)
    {
        printf("entering deep sleep mode, the wake-up resets the system\r\n");
    }
    else
    {
        printf("entering sleep mode, the wake-up resumes the program\r\n");
    }

    Check("power mode requested",
          (HAL_PMU_PowerModeConfig(&hpmu_dev, TEST_POWER_MODE) == HAL_OK));

    /* The chip is awake again from here on: in sleep mode the core resumes
     * with the peripherals still running, in deep sleep mode the system is
     * reset and this program restarts from the beginning. */
    delay_ms(TEST_WAKE_SETTLE_MS);

    /* the console has to be brought back after the wake-up */
    User_Print_Init(TEST_BAUDRATE);
    delay_init(SystemCoreClock / 1000000U);

    /* ---- Step 4: report and clear the wake-up source -------------------- */
    printf("PMCR = 0x%X (power mode status, 3 = normal)\r\n",
           PRINT_U32(HAL_PMU_GetPowerModeStatus(&hpmu_dev)));
    source_flag_seen = 0U;
    ReportWakeUpFlags();
    Check("expected wake-up source reported", source_flag_seen);

    while (1)
    {
        printf("power mode = %u | mode = %s | WKFR = 0x%X | source = %s | expected = %s | summary : failures = %u\r\n",
               PRINT_U32(HAL_PMU_GetPowerModeStatus(&hpmu_dev)),
               TEST_POWER_NAME,
               PRINT_U32(hpmu_dev.Instance->WKFR),
               TEST_WAKEUP_NAME,
               "wake-up + system reset",
               PRINT_U32(failures));
        delay_ms(TEST_POLL_MS);
    }
}

/**
 * @brief  RTC interrupt handler (weak symbol of the trap entry).
 * @note   Delegates to the HAL handler, which clears the alarm flag and calls
 *         the alarm event callback.
 * @param  None
 * @retval None
 */
void RTC_IRQ_Handler(void)
{
    HAL_RTC_AlarmIRQHandler(&hrtc_dev);
}

/**
 * @brief  Alarm event callback (weak function of the HAL RTC driver).
 * @note   Reached through HAL_RTC_AlarmIRQHandler() when the alarm fires; in
 *         sleep mode this happens while the core is asleep, right before the
 *         core resumes with the interrupt return.
 * @param  hrtc: pointer to a RTC_HandleTypeDef structure.
 * @retval None
 */
void HAL_RTC_AlarmEventCallback(RTC_HandleTypeDef *hrtc)
{
    UNUSED(hrtc);

    printf("RTC Alarm Interrupt Occurred!\r\n");
}

/**
 * @brief  Write the calendar (time and date) of the RTC.
 * @param  hours: hours (0-23).
 * @param  min: minutes (0-59).
 * @param  sec: seconds (0-59).
 * @param  tos: tenth of second (0-9).
 * @param  century: century (0-99).
 * @param  year: year (0-99).
 * @param  month: month (RTC_Month_xxx).
 * @param  date: day of month (1-31).
 * @param  weekday: weekday (RTC_Weekday_xxx).
 * @retval None
 */
static void RTC_SetCalendar(uint8 hours, uint8 min, uint8 sec, uint8 tos,
                            uint8 century, uint8 year, uint8 month, uint8 date,
                            uint8 weekday)
{
    RTC_TimeTypeDef time;
    RTC_DateTypeDef dateS;

    __HAL_CLEAR_STRUCT(&time);
    HAL_RTC_TimeStructInit(&time);
    time.RTC_Hours         = hours;
    time.RTC_Minutes       = min;
    time.RTC_Seconds       = sec;
    time.RTC_TenthOfSecond = tos;
    Check("set time", (HAL_RTC_SetTime(&hrtc_dev, &time, RTC_FORMAT_BIN) == HAL_OK));

    __HAL_CLEAR_STRUCT(&dateS);
    HAL_RTC_DateStructInit(&dateS);
    dateS.RTC_WeekDay = weekday;
    dateS.RTC_Date    = date;
    dateS.RTC_Month   = month;
    dateS.RTC_Year    = year;
    dateS.RTC_Century = century;
    Check("set date", (HAL_RTC_SetDate(&hrtc_dev, &dateS, RTC_FORMAT_BIN) == HAL_OK));
}

/**
 * @brief  Read the calendar (time and date) into the module variables.
 * @param  None
 * @retval None
 */
static void RTC_GetCalendar(void)
{
    RTC_TimeTypeDef time;
    RTC_DateTypeDef dateS;

    __HAL_CLEAR_STRUCT(&time);
    __HAL_CLEAR_STRUCT(&dateS);

    (void)HAL_RTC_GetTime(&hrtc_dev, &time, RTC_FORMAT_BIN);
    (void)HAL_RTC_GetDate(&hrtc_dev, &dateS, RTC_FORMAT_BIN);

    r_time_hours   = time.RTC_Hours;
    r_time_minutes = time.RTC_Minutes;
    r_time_seconds = time.RTC_Seconds;
    r_time_tos     = time.RTC_TenthOfSecond;

    r_date_year    = dateS.RTC_Year;
    r_date_month   = dateS.RTC_Month;
    r_date_date    = dateS.RTC_Date;
}

/**
 * @brief  Translate a month constant to its number (1-12).
 * @param  month: month (RTC_Month_xxx).
 * @retval uint8: month number, or 0 when the value is unknown.
 */
static uint8 RTC_MonthToNumber(uint8 month)
{
    uint8 result;

    switch (month)
    {
        case RTC_Month_January:   result = 1U;  break;
        case RTC_Month_February:  result = 2U;  break;
        case RTC_Month_March:     result = 3U;  break;
        case RTC_Month_April:     result = 4U;  break;
        case RTC_Month_May:       result = 5U;  break;
        case RTC_Month_June:      result = 6U;  break;
        case RTC_Month_July:      result = 7U;  break;
        case RTC_Month_August:    result = 8U;  break;
        case RTC_Month_September: result = 9U;  break;
        case RTC_Month_October:   result = 10U; break;
        case RTC_Month_November:  result = 11U; break;
        case RTC_Month_December:  result = 12U; break;
        default:                  result = 0U;  break;
    }

    return result;
}

/**
 * @brief  Configure the system clock tree using the HAL SMU driver.
 * @note   Clock tree shared by every integration test suite of this library:
 *         OSC 20 MHz as the PLL source, PLLDivR = 0x04 / PLLDivN = 0x14 /
 *         PLLDivF = 0xB4 / PLLDivQ = 0x01 -> 45 MHz core clock, then
 *         AXI4Bus3 = /2, APBBus0 = /2, APBBus1 = /2 and CANX2 = /8. The
 *         dividers are programmed while the system clock is still the
 *         power-on source and the PLL is switched in afterwards, which is
 *         the order the chip requires (see HAL_SMU_OscConfig()).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it, so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Clock tree order: the bus dividers are written while the system clock is
       still the power-on source (FIRC), so that the new divider values are
       already in place when the faster clock arrives; the previous call has
       already programmed the EFLASH controller clock and switched the system
       clock. */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition == 0U)
    {
        failures++;
    }
    printf("%-44s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Initialize the PMU handle and report its state.
 * @note   HAL_PMU_Init() must run before any other PMU API of this project:
 *         the configuration APIs are gated on the handle state and refuse to
 *         work on a handle that is still in the RESET state.
 * @param  None
 * @retval None
 */
static void PMU_Init(void)
{
    __HAL_CLEAR_STRUCT(&hpmu_dev);
    hpmu_dev.Instance = PMU;

    Check("PMU init", (HAL_PMU_Init(&hpmu_dev) == HAL_OK));
    printf("PMU state = %u (1 = READY), error = %u\r\n",
           PRINT_U32(HAL_PMU_GetState(&hpmu_dev)),
           PRINT_U32(HAL_PMU_GetError(&hpmu_dev)));
}

/*****END OF FILE*****/
