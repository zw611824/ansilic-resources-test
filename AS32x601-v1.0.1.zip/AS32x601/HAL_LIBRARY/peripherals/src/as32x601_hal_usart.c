/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_usart.c
 * Author:          ANSILIC APPLICATION GROUP
 * Version :        V1.6
 * Date:   2026/10/12
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.1     implement the USART DMA transfer APIs (Transmit/Receive/TransmitReceive_DMA, DMAStop) and the DMA callbacks
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.2     add the module guard (HAL_USART_MODULE_ENABLED) around the whole implementation
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.3     put the as32x601_hal.h include first (module switch from the conf) before the module headers
 *     ANSILIC APPLICATION GROUP  2026/09/14     1.4     use USART_FLAG_TXE (not USART_FLAG_TC) as the handshake before writing each byte in Transmit / TransmitReceive / the Receive synchronous dummy byte (TC is cleared until a frame has been sent)
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.5     align the module with the library architecture spec (resource lock and RTOS chapters): add the shared validity / state / lock helpers, take the lock and clear the error code in every register writing entry point (initialization and de-initialization included), apply the busy state gate, move the blocking timeout bookkeeping (state, timeout error code and unlock) to the caller, run the MSP callbacks outside the locked region, yield the CPU while polling, program the advanced features through the Tier-3 helper (no public API inside a locked region), declare the timeout and invalid parameter error codes and validate the configuration structure at run time
 *                                                       the whole file is kept free of external references
 *     ANSILIC APPLICATION GROUP  2026/10/12     1.6     implement the capabilities declared by the V1.6 header:
 *                                                       (1) the baud rate divider computed by USART_SetConfig() is validated against
 *                                                       the 16 bit domain of the BRR register before it is written, so an out of range
 *                                                       divider is rejected with HAL_USART_ERROR_INVALID_PARAM instead of being silently
 *                                                       truncated by the 16 bit store (the IS_USART_BRR_DIVIDER() check macro is declared
 *                                                       in the header),
 *                                                       (2) a failed Tx start of HAL_USART_TransmitReceive_DMA() rolls the already started
 *                                                       Rx direction back (its request is closed, its channel aborted and its transfer
 *                                                       state reset), so that no armed channel is left behind and the documented retry
 *                                                       really works,
 *                                                       (3) HAL_USART_DeInit() aborts the DMA channels linked to the instance before the
 *                                                       control registers are zeroed, through the new Tier-3 core USART_AbortLinkedDmaChannels()
 *                                                       that HAL_USART_DMAStop() now shares as well
 * Description:     This file provides firmware functions to manage the functionalities of the USART HAL peripheral.
 *                  It is a HAL-style port of the AS32X601 USART peripheral library (as32x601_usart.c/.h),
 *                  providing the initialization, blocking / interrupt / DMA data transfers and
 *                  peripheral state management for the USART peripheral.
 *                  Usage: declare a USART_HandleTypeDef handle, implement HAL_USART_MspInit() (USARTx clock
 *                  enable, GPIO alternate function pins, NVIC/PLIC configuration), fill husart.Init and call
 *                  HAL_USART_Init(), then use the blocking (HAL_USART_Transmit/Receive), interrupt (_IT) or
 *                  DMA (_DMA) APIs.
 *                  Note: the DMA transfer APIs (HAL_USART_Transmit_DMA() ...) are kept as stubs until the
 *                  AS32X601 DMA HAL driver (as32x601_hal_dma.c/.h) is available; the polling and interrupt
 *                  modes are fully functional.
 */

/* Includes ------------------------------------------------------------------*/
#include "as32x601_hal.h"           /* module switch from as32x601_hal_conf.h */
#include "as32x601_hal_usart.h"
/* The extension header is included explicitly: it used to be pulled in by
 * the base header, which formed a circular include (the extension header
 * includes the base header for the handle definition). */
#include "as32x601_hal_smu.h"
#ifdef HAL_DMA_MODULE_ENABLED
#include "as32x601_hal_dma.h"
#endif

/* The HAL_USART_MODULE_ENABLED switch is provided by the user configuration
 * file (as32x601_hal_conf.h, included above through as32x601_hal.h): the
 * whole implementation is compiled only while the module is enabled. */
#ifdef HAL_USART_MODULE_ENABLED

/** @addtogroup AS32X601_HAL_Driver
  * @{
  */

/** @defgroup USART USART
  * @brief HAL USART module driver
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/** @addtogroup USART_Private_Constants
  * @{
  */
#define USART_DUMMY_DATA                  ((uint16)0xFFFFU)  /*!< USART transmitted dummy data */
#define USART_TEACK_REACK_TIMEOUT         ((uint32)1000U)

#define USART_CR1_FIELDS  ((uint32)(USART_CR1_M | USART_CR1_PCE | USART_CR1_PS | \
                                      USART_CR1_TE | USART_CR1_RE | USART_CR1_OVER8))
#define USART_CR2_FIELDS  ((uint32)(USART_CR2_CPHA | USART_CR2_CPOL | \
                                      USART_CR2_CLKEN | USART_CR2_LBCL | USART_CR2_STOP))
#define USART_CR3_FIELDS  ((uint32)(USART_CR3_RTSE | USART_CR3_CTSE))
/**
  * @}
  */

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/** @addtogroup USART_Private_Functions
  * @{
  */
static void USART_EndRxTransfer(USART_HandleTypeDef *husart);
#ifdef HAL_DMA_MODULE_ENABLED
static void USART_EndTxTransfer(USART_HandleTypeDef *husart);
#endif
static HAL_StatusTypeDef USART_WaitOnFlagUntilTimeout(USART_HandleTypeDef *husart,
                                                      uint32 Flag, FlagStatus Status,
                                                      uint32 Tickstart, uint32 Timeout);
static HAL_StatusTypeDef USART_CheckInitState(USART_HandleTypeDef *husart);
static HAL_StatusTypeDef USART_SetConfig(USART_HandleTypeDef *husart);
static HAL_StatusTypeDef USART_Transmit_IT(USART_HandleTypeDef *husart);
static HAL_StatusTypeDef USART_EndTransmit_IT(USART_HandleTypeDef *husart);
static void USART_TxPushPending(USART_HandleTypeDef *husart);
static HAL_StatusTypeDef USART_Receive_IT(USART_HandleTypeDef *husart);
static HAL_StatusTypeDef USART_TransmitReceive_IT(USART_HandleTypeDef *husart);
#ifdef HAL_DMA_MODULE_ENABLED
static void USART_DMATransmitCplt(DMA_HandleTypeDef *hdma);
static void USART_DMATxHalfCplt(DMA_HandleTypeDef *hdma);
static void USART_DMAReceiveCplt(DMA_HandleTypeDef *hdma);
static void USART_DMARxHalfCplt(DMA_HandleTypeDef *hdma);
static void USART_DMATransmitReceiveCplt(DMA_HandleTypeDef *hdma);
static void USART_DMAError(DMA_HandleTypeDef *hdma);
static void USART_DMAAbortOnError(DMA_HandleTypeDef *hdma);
static void USART_AbortLinkedDmaChannels(USART_HandleTypeDef *husart);
#endif

/* Shared internal functions -------------------------------------------------*/
/** @defgroup USART_Shared_Internal_Functions USART Shared Internal Functions
  * @brief    Helpers shared by the core and the extended part of this driver
  *           (Tier 3). They are not part of the public API and shall not be
  *           called by the application.
  * @{
  */

/**
 * @brief  Check whether the USART handle and its instance are valid.
 * @param  husart: pointer to a USART_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
uint32 USART_HandleIsValid(USART_HandleTypeDef *husart)
{
    if (husart == NULL_PTR)
    {
        return 0U;
    }

    if (IS_USART_ALL_PERIPH(husart->Instance) == 0U)
    {
        return 0U;
    }

    return 1U;
}

/**
 * @brief  Check whether the handle accepts a new operation.
 * @note   ARCH-CONST-09: a handle that is busy (an operation is ongoing in
 *         another context) rejects any other operation with HAL_BUSY, an
 *         uninitialized handle (RESET) requires HAL_USART_Init() first and is
 *         rejected with HAL_ERROR, while the recoverable states (TIMEOUT and
 *         ERROR) accept a new operation directly.
 * @param  husart: pointer to a USART_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK (accepted) / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef USART_CheckState(USART_HandleTypeDef *husart)
{
    if ((husart->State == HAL_USART_STATE_BUSY) ||
        (husart->State == HAL_USART_STATE_BUSY_TX) ||
        (husart->State == HAL_USART_STATE_BUSY_RX) ||
        (husart->State == HAL_USART_STATE_BUSY_TX_RX))
    {
        return HAL_BUSY;
    }

    if (husart->State == HAL_USART_STATE_RESET)
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Check whether the handle has been initialized (only RESET is rejected).
 * @note   Tier 3 helper for the interfaces that serve an ongoing transfer (the
 *         DMA pause and resume commands): they must not be rejected by the busy
 *         state gate, only by an uninitialized handle.
 * @param  husart: pointer to a USART_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
static HAL_StatusTypeDef USART_CheckInitState(USART_HandleTypeDef *husart)
{
    if (husart->State == HAL_USART_STATE_RESET)
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Lock the handle (RTOS mutex or single core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_USART_MspInit()). The bare metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; the value is passed to HAL_MutexAcquire() as
 *         is (RTOS ticks; HAL_MAX_DELAY means an infinite wait).
 * @param  husart: pointer to a USART_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef USART_LockHandle(USART_HandleTypeDef *husart, uint32 Timeout)
{
#if (USE_RTOS == 1)
    if (husart->LockMutex == NULL_PTR)
    {
        /* The porting layer did not create the mutex (e.g. HAL_USART_MspInit()
         * was not overridden): report it instead of calling the RTOS with a
         * NULL handle */
        return HAL_ERROR;
    }

    return HAL_MutexAcquire(husart->LockMutex, Timeout);
#else
    /* Prevent unused argument compilation warning: the bare metal lock flag
     * either succeeds immediately or reports HAL_BUSY, it never waits */
    UNUSED(Timeout);

    if (husart->Lock == HAL_LOCKED)
    {
        return HAL_BUSY;
    }

    husart->Lock = HAL_LOCKED;

    return HAL_OK;
#endif /* USE_RTOS */
}

/**
 * @brief  Unlock the handle.
 * @param  husart: pointer to a USART_HandleTypeDef structure.
 * @retval None
 */
void USART_UnlockHandle(USART_HandleTypeDef *husart)
{
#if (USE_RTOS == 1)
    (void)HAL_MutexRelease(husart->LockMutex);
#else
    husart->Lock = HAL_UNLOCKED;
#endif /* USE_RTOS */
}


/* Exported functions --------------------------------------------------------*/

/** @defgroup USART_Exported_Functions USART Exported Functions
  * @{
  */

/** @defgroup USART_Exported_Functions_Group1 USART Initialization and de-initialization functions
  *  @brief    Initialization and Configuration functions
  *
  @verbatim
  ===============================================================================
            ##### Initialization and Configuration functions #####
  ===============================================================================
    [..]
    This subsection provides a set of functions allowing to initialize the USART
    in asynchronous and in synchronous modes.
      (+) For the asynchronous mode only these parameters can be configured:
        (++) Baud Rate
        (++) Word Length
        (++) Stop Bit
        (++) Parity: If the parity is enabled, then the MSB bit of the data
             written in the data register is transmitted but is changed by the
             parity bit.
        (++) USART polarity
        (++) USART phase
        (++) USART LastBit
        (++) Receiver/transmitter modes
        (++) Hardware flow control

    [..]
    The HAL_USART_Init() function follows the USART synchronous configuration
  *         procedure (the configuration sequence is described below).

  @endverbatim
  * @{
  */

/**
  * @brief  Initialize the USART_InitTypeDef structure with default values. (NON-BLOCKING)
  * @note   Sets the Size / Version compatibility metafields and fills the
  *         configuration fields with the USART default values
  *         (115200 baud, 8-bit, 1 stop bit, no parity, TX+RX, no flow
  *         control, 16x oversampling).
  * @param  USART_InitStruct: pointer to a USART_InitTypeDef structure.
  * @retval None
  */
void HAL_USART_StructInit(USART_InitTypeDef *USART_InitStruct)
{
    /* Check the parameter */
    if (USART_InitStruct == NULL_PTR)
    {
        return;
    }

    /* Compatibility metafields */
    USART_InitStruct->Size                = sizeof(USART_InitTypeDef);
    USART_InitStruct->Version             = USART_INIT_VERSION;

    /* Default configuration */
    USART_InitStruct->BaudRate            = 115200U;
    USART_InitStruct->WordLength          = USART_WORDLENGTH_8B;
    USART_InitStruct->StopBits            = USART_STOPBITS_1;
    USART_InitStruct->Parity              = USART_PARITY_NONE;
    USART_InitStruct->Mode                = USART_MODE_TX_RX;
    USART_InitStruct->OverSampling        = USART_OVERSAMPLING_16;
    USART_InitStruct->HardwareFlowControl = USART_HWCONTROL_NONE;
    USART_InitStruct->CLKPolarity         = USART_POLARITY_LOW;
    USART_InitStruct->CLKPhase            = USART_PHASE_1EDGE;
    USART_InitStruct->CLKLastBit          = USART_LASTBIT_DISABLE;
#if defined(USART_ADVFEATURE_NO_INIT)
    USART_InitStruct->AdvancedInit.AdvFeatureInit = USART_ADVFEATURE_NO_INIT;
#endif
    USART_InitStruct->Reserved[0]         = 0U;
    USART_InitStruct->Reserved[1]         = 0U;
}

/**
  * @brief  Initializes the USART mode according to the specified (BLOCKING)
  *         parameters in the USART_InitTypeDef and create the associated handle. (NON-BLOCKING)
  * @param  husart: USART handle
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_Init(USART_HandleTypeDef *husart)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the USART handle and instance */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_USART_ALL_PERIPH(husart->Instance));
    assert_param(IS_USART_BAUDRATE(husart->Init.BaudRate));
    assert_param(IS_USART_WORD_LENGTH(husart->Init.WordLength));
    assert_param(IS_USART_STOPBITS(husart->Init.StopBits));
    assert_param(IS_USART_PARITY(husart->Init.Parity));
    assert_param(IS_USART_MODE(husart->Init.Mode));
    assert_param(IS_USART_OVERSAMPLING(husart->Init.OverSampling));
    assert_param(IS_USART_HARDWARE_FLOW_CONTROL(husart->Init.HardwareFlowControl));
    assert_param(IS_USART_POLARITY(husart->Init.CLKPolarity));
    assert_param(IS_USART_PHASE(husart->Init.CLKPhase));
    assert_param(IS_USART_LASTBIT(husart->Init.CLKLastBit));

    /* Run time parameter validation, so that the checks stay effective in a build
     * with the assertions disabled. The metafields of the configuration structure
     * (Size / Version, architecture spec section 22) and the two reserved words are
     * validated as well. A rejected call neither takes the lock nor changes the
     * handle state nor touches a register. */
    if ((IS_USART_ALL_PERIPH(husart->Instance) == 0U) ||
        (husart->Init.Size != sizeof(USART_InitTypeDef)) ||
        (husart->Init.Version != USART_INIT_VERSION) ||
        (IS_USART_BAUDRATE(husart->Init.BaudRate) == 0U) ||
        (IS_USART_WORD_LENGTH(husart->Init.WordLength) == 0U) ||
        (IS_USART_STOPBITS(husart->Init.StopBits) == 0U) ||
        (IS_USART_PARITY(husart->Init.Parity) == 0U) ||
        (IS_USART_MODE(husart->Init.Mode) == 0U) ||
        (IS_USART_OVERSAMPLING(husart->Init.OverSampling) == 0U) ||
        (IS_USART_HARDWARE_FLOW_CONTROL(husart->Init.HardwareFlowControl) == 0U) ||
        (IS_USART_POLARITY(husart->Init.CLKPolarity) == 0U) ||
        (IS_USART_PHASE(husart->Init.CLKPhase) == 0U) ||
        (IS_USART_LASTBIT(husart->Init.CLKLastBit) == 0U) ||
        (husart->Init.Reserved[0] != 0U) ||
        (husart->Init.Reserved[1] != 0U))
    {
        husart->ErrorCode |= HAL_USART_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Allocate the lock resource before its first use, so that a handle that was
     * never initialized cannot report HAL_BUSY from a stale Lock field.
     * LOCK-06: the low level initialization runs before the handle is locked, so
     * that an override which calls other HAL APIs cannot deadlock. */
    if (husart->State == HAL_USART_STATE_RESET)
    {
        husart->Lock = HAL_UNLOCKED;

        /* Init the low level hardware : GPIO, CLOCK */
        HAL_USART_MspInit(husart);
    }

    /* Process locked */
    if (USART_LockHandle(husart, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    husart->State = HAL_USART_STATE_BUSY;
    husart->ErrorCode = HAL_USART_ERROR_NONE;

    /* Disable the Peripheral */
    __HAL_USART_DISABLE(husart);

    /* Set the USART Communication parameters */
    status = USART_SetConfig(husart);
    if (status != HAL_OK)
    {
        /* Invalid configuration (e.g. an instance outside the two clock domains):
         * report it and leave the handle ready, so that it can be reconfigured */
        husart->ErrorCode |= HAL_USART_ERROR_INVALID_PARAM;
        husart->State = HAL_USART_STATE_READY;
        USART_UnlockHandle(husart);
        return HAL_ERROR;
    }

    /* Configure the USART Advanced Features if requested. LOCK-05: the register
       access sequence is programmed through the Tier-3 helper of the extension
       module, so that no public API is called inside the locked region. */
    if (husart->Init.AdvancedInit.AdvFeatureInit != USART_ADVFEATURE_NO_INIT)
    {
        if (USART_ConfigAdvFeatureInternal(husart, &husart->Init.AdvancedInit) != HAL_OK)
        {
            husart->ErrorCode |= HAL_USART_ERROR_INVALID_PARAM;
            husart->State = HAL_USART_STATE_READY;
            USART_UnlockHandle(husart);
            return HAL_ERROR;
        }
    }

    /* In Synchronous mode, the following bits must be kept cleared:
       - LINEN bit in the USART_CR2 register
       - HDSEL bit in the USART_CR3 register */
    CLEAR_BIT(husart->Instance->CR2, USART_CR2_LINEN);
    CLEAR_BIT(husart->Instance->CR3, USART_CR3_HDSEL);

    /* Enable the Peripheral */
    __HAL_USART_ENABLE(husart);

    /* Initialize the USART state. The idle state check of
       HAL_USART_CheckIdleState() only clears the error code and sets the ready
       state on this device (no TEACK/REACK acknowledge flags), which is done
       here inside the same locked transaction. */
    husart->State = HAL_USART_STATE_READY;

    /* Process Unlocked */
    USART_UnlockHandle(husart);

    return HAL_OK;
}

/**
  * @brief DeInitializes the USART peripheral (NON-BLOCKING)
  * @param husart: USART handle
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_DeInit(USART_HandleTypeDef *husart)
{
    /* Check the USART handle and instance */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_USART_ALL_PERIPH(husart->Instance));

    /* Process locked. ARCH-CONST-09: the de-initialization is callable from any
     * handle state, so that a failed initialization can always be undone */
    if (USART_LockHandle(husart, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    husart->State = HAL_USART_STATE_BUSY;
    husart->ErrorCode = HAL_USART_ERROR_NONE;

#ifdef HAL_DMA_MODULE_ENABLED
    /* Abort the DMA channels linked to this instance BEFORE the control
       registers are zeroed: a channel that is still armed keeps its DMA
       request active even after the CR3 request bits are cleared, so a later
       initialization would start on a channel that is still running. The call
       goes to the Tier-3 core shared with HAL_USART_DMAStop(), so no public
       API is invoked inside the locked region (LOCK-05). */
    USART_AbortLinkedDmaChannels(husart);
#endif

    husart->Instance->CR1 = 0x0U;
    husart->Instance->CR2 = 0x0U;
    husart->Instance->CR3 = 0x0U;

    husart->State = HAL_USART_STATE_RESET;

    /* Release Lock */
    USART_UnlockHandle(husart);

    /* LOCK-06 / ARCH-CONST-04: the low level de-initialization runs OUTSIDE the
     * locked region, as the architecture specification requires for the MSP
     * callbacks ("MspDeInit is called after the unlock") */
    HAL_USART_MspDeInit(husart);

    return HAL_OK;
}

/**
  * @brief USART MSP Init (NON-BLOCKING)
  * @param husart: USART handle
  * @retval None
  */
__weak void HAL_USART_MspInit(USART_HandleTypeDef *husart)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(husart);

    /* NOTE: This function should not be modified, when the callback is needed,
             the HAL_USART_MspInit can be implemented in the user file
     */
}

/**
  * @brief USART MSP DeInit (NON-BLOCKING)
  * @param husart: USART handle
  * @retval None
  */
__weak void HAL_USART_MspDeInit(USART_HandleTypeDef *husart)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(husart);

    /* NOTE: This function should not be modified, when the callback is needed,
             the HAL_USART_MspDeInit can be implemented in the user file
     */
}

/**
  * @brief Check the USART Idle State (NON-BLOCKING)
  * @param husart: USART handle
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_CheckIdleState(USART_HandleTypeDef *husart)
{
    /* Check the USART handle and instance */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_USART_ALL_PERIPH(husart->Instance));

    /* ARCH-CONST-09: the check moves the handle to the ready state, so a busy
     * handle (an ongoing transfer) must be rejected */
    if (USART_CheckState(husart) != HAL_OK)
    {
        return USART_CheckState(husart);
    }

    /* Process locked */
    if (USART_LockHandle(husart, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Initialize the USART ErrorCode */
    husart->ErrorCode = HAL_USART_ERROR_NONE;

    /* The AS32X601 USART ISR does not provide TEACK/REACK acknowledge flags,
       so no wait loop is required here */

    /* Initialize the USART state */
    husart->State = HAL_USART_STATE_READY;

    /* Release Lock */
    USART_UnlockHandle(husart);

    return HAL_OK;
}

/**
  * @}
  */

/** @defgroup USART_Exported_Functions_Group2 IO operation functions
  *  @brief   USART Transmit and Receive functions
  *
  @verbatim
  ===============================================================================
                      ##### IO operation functions #####
  ===============================================================================
    This subsection provides a set of functions allowing to manage the USART
    synchronous data transfers.

    (#) There are two mode of transfer:
       (++) Blocking mode: The communication is performed in polling mode.
            The HAL status of all data processing is returned by the same
            function after finishing transfer.
       (++) No-Blocking mode: The communication is performed using Interrupts
            or DMA. These API's return the HAL status.
            The end of the data processing will be indicated through the
            dedicated USART IRQ when using Interrupt mode or the DMA IRQ when
            using DMA mode.
            The HAL_USART_TxCpltCallback(), HAL_USART_RxCpltCallback() and
            HAL_USART_TxRxCpltCallback() user callbacks will be executed
            respectively at the end of the transmit or receive process.
            The HAL_USART_ErrorCallback() user callback will be executed when
            a communication error is detected.

    (#) Blocking mode API's are :
        (++) HAL_USART_Transmit() in simplex mode
        (++) HAL_USART_Receive() in full duplex receive only
        (++) HAL_USART_TransmitReceive() in full duplex mode

    (#) Non-Blocking mode API's with Interrupt are :
        (++) HAL_USART_Transmit_IT() in simplex mode
        (++) HAL_USART_Receive_IT() in full duplex receive only
        (++) HAL_USART_TransmitReceive_IT() in full duplex mode
        (++) HAL_USART_IRQHandler()

    (#) No-Blocking mode functions with DMA are :
        (++) HAL_USART_Transmit_DMA() in simplex mode
        (++) HAL_USART_Receive_DMA() in full duplex receive only
        (++) HAL_USART_TransmitReceive_DMA() in full duplex mode
        (++) HAL_USART_DMAPause()
        (++) HAL_USART_DMAResume()
        (++) HAL_USART_DMAStop()

    (#) A set of Transfer Complete Callbacks are provided in No_Blocking mode:
        (++) HAL_USART_TxCpltCallback()
        (++) HAL_USART_RxCpltCallback()
        (++) HAL_USART_TxHalfCpltCallback()
        (++) HAL_USART_RxHalfCpltCallback()
        (++) HAL_USART_ErrorCallback()
        (++) HAL_USART_TxRxCpltCallback()

  @endverbatim
  * @{
  */

/**
  * @brief  Simplex Send an amount of data in blocking mode (BLOCKING)
  * @param  husart: USART handle
  * @param  pTxData: pointer to data buffer
  * @param  Size: amount of data to be sent
  * @param  Timeout: Timeout duration
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_Transmit(USART_HandleTypeDef *husart, uint8 *pTxData, uint16 Size, uint32 Timeout)
{
    uint16 *tmp;
    uint32 tickstart = 0U;

    /* Check the USART handle and instance */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_USART_ALL_PERIPH(husart->Instance));

    /* Run time parameter validation, so that the checks stay effective in a
     * build with the assertions disabled. A rejected call neither takes the
     * lock nor changes the handle state. */
    if ((pTxData == NULL_PTR) || (Size == 0U))
    {
        husart->ErrorCode |= HAL_USART_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: state gate */
    if (USART_CheckState(husart) != HAL_OK)
    {
        return USART_CheckState(husart);
    }

    /* Process Locked */
    if (USART_LockHandle(husart, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    husart->ErrorCode = HAL_USART_ERROR_NONE;
    husart->State = HAL_USART_STATE_BUSY_TX;

    /* Init tickstart for timeout management */
    tickstart = HAL_GetTick();

    husart->TxXferSize = Size;
    husart->TxXferCount = Size;

    /* Check the remaining data to be sent */
    while (husart->TxXferCount > 0U)
    {
        husart->TxXferCount--;

        /* Wait until the transmit data register is empty before writing the
         * next byte (USART_FLAG_TXE). The transmission complete flag
         * (USART_FLAG_TC) is only checked once, after the last byte, below:
         * on this device TC is cleared while the transmitter has never sent
         * a frame, so waiting for it before the first write would time out
         * and no data would ever be transmitted. */
        if (USART_WaitOnFlagUntilTimeout(husart, USART_FLAG_TXE, RESET, tickstart, Timeout) != HAL_OK)
        {
            /* Timeout: report it through the handle state and the error code.
               The transfer is aborted; the timeout state is recoverable, the
               next operation clears the error code and returns to ready. */
            husart->State = HAL_USART_STATE_TIMEOUT;
            husart->ErrorCode |= HAL_USART_ERROR_TIMEOUT;

            /* Process Unlocked */
            USART_UnlockHandle(husart);

            return HAL_TIMEOUT;
        }

        if ((husart->Init.WordLength == USART_WORDLENGTH_9B) && (husart->Init.Parity == USART_PARITY_NONE))
        {
            tmp = (uint16 *)pTxData;
            husart->Instance->TDR = (*tmp & (uint16)0x01FFU);
            pTxData += 2U;
        }
        else
        {
            husart->Instance->TDR = (*pTxData++ & (uint8)0xFFU);
        }
    }

    if (USART_WaitOnFlagUntilTimeout(husart, USART_FLAG_TC, RESET, tickstart, Timeout) != HAL_OK)
    {
        husart->State = HAL_USART_STATE_TIMEOUT;
        husart->ErrorCode |= HAL_USART_ERROR_TIMEOUT;

        /* Process Unlocked */
        USART_UnlockHandle(husart);

        return HAL_TIMEOUT;
    }

    husart->State = HAL_USART_STATE_READY;

    /* Process Unlocked */
    USART_UnlockHandle(husart);

    return HAL_OK;
}

/**
  * @brief  Receive an amount of data in blocking mode (BLOCKING)
  * @note   In synchronous mode (CLKEN = 1), dummy data are simultaneously
  *         transmitted to generate the clock for the slave.
  * @param  husart: USART handle
  * @param  pRxData: pointer to data buffer
  * @param  Size: amount of data to be received
  * @param  Timeout: Timeout duration
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_Receive(USART_HandleTypeDef *husart, uint8 *pRxData, uint16 Size, uint32 Timeout)
{
    uint16 *tmp;
    uint16 uhMask;
    uint32 tickstart = 0U;

    /* Check the USART handle and instance */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_USART_ALL_PERIPH(husart->Instance));

    /* Run time parameter validation, so that the checks stay effective in a
     * build with the assertions disabled. A rejected call neither takes the
     * lock nor changes the handle state. */
    if ((pRxData == NULL_PTR) || (Size == 0U))
    {
        husart->ErrorCode |= HAL_USART_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: state gate */
    if (USART_CheckState(husart) != HAL_OK)
    {
        return USART_CheckState(husart);
    }

    /* Process Locked */
    if (USART_LockHandle(husart, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    husart->ErrorCode = HAL_USART_ERROR_NONE;
    husart->State = HAL_USART_STATE_BUSY_RX;

    /* Init tickstart for timeout management */
    tickstart = HAL_GetTick();

    husart->RxXferSize = Size;
    husart->RxXferCount = Size;

    /* Computation of USART mask to apply to RDR register */
    __HAL_USART_MASK_COMPUTATION(husart);
    uhMask = husart->Mask;

    /* As long as data have to be received */
    while (husart->RxXferCount > 0U)
    {
        husart->RxXferCount--;

        if (READ_BIT(husart->Instance->CR2, USART_CR2_CLKEN) != RESET)
        {
            /* Synchronous mode: send a dummy byte in order to generate the
               clock for the slave to send data. The handshake is the
               transmit data register empty flag (USART_FLAG_TXE), not the
               transmission complete flag: on this device TC is cleared while
               the transmitter has never sent a frame, so waiting for it
               before the first dummy byte would time out. */
            if (USART_WaitOnFlagUntilTimeout(husart, USART_FLAG_TXE, RESET, tickstart, Timeout) != HAL_OK)
            {
                husart->State = HAL_USART_STATE_TIMEOUT;
                husart->ErrorCode |= HAL_USART_ERROR_TIMEOUT;

                /* Process Unlocked */
                USART_UnlockHandle(husart);

                return HAL_TIMEOUT;
            }
            husart->Instance->TDR = (USART_DUMMY_DATA & (uint16)0x00FFU);
        }

        /* Wait for RXNE Flag */
        if (USART_WaitOnFlagUntilTimeout(husart, USART_FLAG_RXNE, RESET, tickstart, Timeout) != HAL_OK)
        {
            husart->State = HAL_USART_STATE_TIMEOUT;
            husart->ErrorCode |= HAL_USART_ERROR_TIMEOUT;

            /* Process Unlocked */
            USART_UnlockHandle(husart);

            return HAL_TIMEOUT;
        }

        if ((husart->Init.WordLength == USART_WORDLENGTH_9B) && (husart->Init.Parity == USART_PARITY_NONE))
        {
            tmp = (uint16 *)pRxData;
            *tmp = (uint16)(husart->Instance->RDR & uhMask);
            pRxData += 2U;
        }
        else
        {
            *pRxData++ = (uint8)(husart->Instance->RDR & (uint8)uhMask);
        }
    }

    husart->State = HAL_USART_STATE_READY;

    /* Process Unlocked */
    USART_UnlockHandle(husart);

    return HAL_OK;
}

/**
  * @brief  Full-Duplex Send and Receive an amount of data in blocking mode (BLOCKING)
  * @param  husart: USART handle
  * @param  pTxData: pointer to TX data buffer
  * @param  pRxData: pointer to RX data buffer
  * @param  Size: amount of data to be sent (same amount to be received)
  * @param  Timeout: Timeout duration
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_TransmitReceive(USART_HandleTypeDef *husart, uint8 *pTxData, uint8 *pRxData, uint16 Size,
                                            uint32 Timeout)
{
    uint16 *tmp;
    uint16 uhMask;
    uint32 tickstart = 0U;

    /* Check the USART handle and instance */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_USART_ALL_PERIPH(husart->Instance));

    /* Run time parameter validation, so that the checks stay effective in a
     * build with the assertions disabled. A rejected call neither takes the
     * lock nor changes the handle state. */
    if ((pTxData == NULL_PTR) || (pRxData == NULL_PTR) || (Size == 0U))
    {
        husart->ErrorCode |= HAL_USART_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: state gate */
    if (USART_CheckState(husart) != HAL_OK)
    {
        return USART_CheckState(husart);
    }

    /* Process Locked */
    if (USART_LockHandle(husart, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    husart->ErrorCode = HAL_USART_ERROR_NONE;
    husart->State = HAL_USART_STATE_BUSY_RX;

    /* Init tickstart for timeout management */
    tickstart = HAL_GetTick();

    husart->RxXferSize = Size;
    husart->TxXferSize = Size;
    husart->TxXferCount = Size;
    husart->RxXferCount = Size;

    /* Computation of USART mask to apply to RDR register */
    __HAL_USART_MASK_COMPUTATION(husart);
    uhMask = husart->Mask;

    /* Check the remaining data to be sent */
    while (husart->TxXferCount > 0U)
    {
        husart->TxXferCount--;
        husart->RxXferCount--;

        /* Wait until the transmit data register is empty before writing the
         * next byte (USART_FLAG_TXE), see HAL_USART_Transmit() above: the
         * transmission complete flag (USART_FLAG_TC) is only set once a
         * frame has been sent on this device, so it cannot be used as the
         * handshake before the very first write. */
        if (USART_WaitOnFlagUntilTimeout(husart, USART_FLAG_TXE, RESET, tickstart, Timeout) != HAL_OK)
        {
            husart->State = HAL_USART_STATE_TIMEOUT;
            husart->ErrorCode |= HAL_USART_ERROR_TIMEOUT;

            /* Process Unlocked */
            USART_UnlockHandle(husart);

            return HAL_TIMEOUT;
        }

        if ((husart->Init.WordLength == USART_WORDLENGTH_9B) && (husart->Init.Parity == USART_PARITY_NONE))
        {
            tmp = (uint16 *)pTxData;
            husart->Instance->TDR = (*tmp & uhMask);
            pTxData += 2U;
        }
        else
        {
            husart->Instance->TDR = (*pTxData++ & (uint8)uhMask);
        }

        /* Wait for RXNE Flag */
        if (USART_WaitOnFlagUntilTimeout(husart, USART_FLAG_RXNE, RESET, tickstart, Timeout) != HAL_OK)
        {
            husart->State = HAL_USART_STATE_TIMEOUT;
            husart->ErrorCode |= HAL_USART_ERROR_TIMEOUT;

            /* Process Unlocked */
            USART_UnlockHandle(husart);

            return HAL_TIMEOUT;
        }

        if ((husart->Init.WordLength == USART_WORDLENGTH_9B) && (husart->Init.Parity == USART_PARITY_NONE))
        {
            tmp = (uint16 *)pRxData;
            *tmp = (uint16)(husart->Instance->RDR & uhMask);
            pRxData += 2U;
        }
        else
        {
            *pRxData++ = (uint8)(husart->Instance->RDR & (uint8)uhMask);
        }
    }

    husart->State = HAL_USART_STATE_READY;

    /* Process Unlocked */
    USART_UnlockHandle(husart);

    return HAL_OK;
}

/**
  * @brief  Send an amount of data in interrupt mode (NON-BLOCKING / IT)
  * @param  husart: USART handle
  * @param  pTxData: pointer to data buffer
  * @param  Size: amount of data to be sent
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_Transmit_IT(USART_HandleTypeDef *husart, uint8 *pTxData, uint16 Size)
{
    /* Check the USART handle allocation before any access (MISRA-MEM-04) */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: state gate. A busy handle (an ongoing transfer) is
       rejected with HAL_BUSY, an uninitialized handle with HAL_ERROR, while
       the recoverable states (timeout / error) accept the new operation. */
    if (USART_CheckState(husart) == HAL_OK)



    {
        if ((pTxData == NULL_PTR) || (Size == 0U))
        {
            husart->ErrorCode |= HAL_USART_ERROR_INVALID_PARAM;
            return HAL_ERROR;
        }

        /* Process Locked */
        if (USART_LockHandle(husart, HAL_MAX_DELAY) != HAL_OK)
        {
            /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
            return HAL_BUSY;
        }

        husart->pTxBuffPtr = pTxData;
        husart->TxXferSize = Size;
        husart->TxXferCount = Size;

        husart->ErrorCode = HAL_USART_ERROR_NONE;
        husart->State = HAL_USART_STATE_BUSY_TX;

        /* The USART Error Interrupts (frame error, noise error, overrun error)
           are not managed by the USART Transmit Process to avoid the overrun
           interrupt when the USART mode is configured for transmit and receive
           (USART_MODE_TX_RX). To benefit from the frame error and noise
           interrupts, the USART mode should be configured only for transmit
           (USART_MODE_TX). */

        /* Prime the transfer: push the pending data units now (in FIFO mode the
           whole frame fits into the TXFIFO), the transmit complete interrupt
           carries what is left over (see the note on the interrupt source
           below). */
        USART_TxPushPending(husart);

        /* Enable the USART Transmit Complete Interrupt.
           NOTE: the transmit data register empty (TXE / TXFNF) interrupt of this
           device does not generate an interrupt request. Measured on silicon:
           with TXE = 1 and TXEIE = 1 nothing is requested, and even a real TXE
           transition produced after TXEIE was set does not reach the interrupt
           controller, while the transmit complete (TC) event does. A transfer
           driven by TXEIE therefore never starts - nothing would ever write the
           first data unit - and the frame chain is driven by the transmit
           complete event instead, which is the event the reference test case
           uses as well. */
        __HAL_USART_ENABLE_IT(husart, USART_IT_TC);

        /* Process Unlocked */
        USART_UnlockHandle(husart);

        return HAL_OK;
    }
    else
    {
        /* ARCH-CONST-09: only a busy or uninitialized handle reaches this
           branch, so the gate verdict is reported as is */
           return USART_CheckState(husart);
    }
}

/**
  * @brief  Receive an amount of data in interrupt mode (NON-BLOCKING / IT)
  * @note   In synchronous mode (CLKEN = 1), dummy data are simultaneously
  *         transmitted to generate the clock for the slave.
  * @param  husart: USART handle
  * @param  pRxData: pointer to data buffer
  * @param  Size: amount of data to be received
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_Receive_IT(USART_HandleTypeDef *husart, uint8 *pRxData, uint16 Size)
{
    /* Check the USART handle allocation before any access (MISRA-MEM-04) */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: state gate. A busy handle (an ongoing transfer) is
       rejected with HAL_BUSY, an uninitialized handle with HAL_ERROR, while
       the recoverable states (timeout / error) accept the new operation. */
    if (USART_CheckState(husart) == HAL_OK)



    {
        if ((pRxData == NULL_PTR) || (Size == 0U))
        {
            husart->ErrorCode |= HAL_USART_ERROR_INVALID_PARAM;
            return HAL_ERROR;
        }

        /* Process Locked */
        if (USART_LockHandle(husart, HAL_MAX_DELAY) != HAL_OK)
        {
            /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
            return HAL_BUSY;
        }

        husart->pRxBuffPtr = pRxData;
        husart->RxXferSize = Size;
        husart->RxXferCount = Size;

        __HAL_USART_MASK_COMPUTATION(husart);

        husart->ErrorCode = HAL_USART_ERROR_NONE;
        husart->State = HAL_USART_STATE_BUSY_RX;

        /* Enable the USART Parity Error Interrupt */
        SET_BIT(husart->Instance->CR1, USART_CR1_PEIE);

        /* Enable the USART Error Interrupt: (frame error, noise error, overrun error) */
        SET_BIT(husart->Instance->CR3, USART_CR3_EIE);

        /* Enable the USART Data Register not empty Interrupt */
        SET_BIT(husart->Instance->CR1, USART_CR1_RXNEIE);

        /* Process Unlocked */
        USART_UnlockHandle(husart);

        /* Send dummy byte in order to generate the clock for the slave to send
           the next data (synchronous mode only) */
        if (READ_BIT(husart->Instance->CR2, USART_CR2_CLKEN) != RESET)
        {
            if (husart->Init.WordLength == USART_WORDLENGTH_9B)
            {
                husart->Instance->TDR = (USART_DUMMY_DATA & (uint16)0x01FFU);
            }
            else
            {
                husart->Instance->TDR = (USART_DUMMY_DATA & (uint16)0x00FFU);
            }
        }

        return HAL_OK;
    }
    else
    {
        /* ARCH-CONST-09: only a busy or uninitialized handle reaches this
           branch, so the gate verdict is reported as is */
           return USART_CheckState(husart);
    }
}

/**
  * @brief  Full-Duplex Send and Receive an amount of data in interrupt mode (NON-BLOCKING / IT)
  * @param  husart: USART handle
  * @param  pTxData: pointer to TX data buffer
  * @param  pRxData: pointer to RX data buffer
  * @param  Size: amount of data to be sent/received
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_TransmitReceive_IT(USART_HandleTypeDef *husart, uint8 *pTxData, uint8 *pRxData, uint16 Size)
{
    /* Check the USART handle allocation before any access (MISRA-MEM-04) */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: state gate. A busy handle (an ongoing transfer) is
       rejected with HAL_BUSY, an uninitialized handle with HAL_ERROR, while
       the recoverable states (timeout / error) accept the new operation. */
    if (USART_CheckState(husart) == HAL_OK)



    {
        if ((pTxData == NULL_PTR) || (pRxData == NULL_PTR) || (Size == 0U))
        {
            husart->ErrorCode |= HAL_USART_ERROR_INVALID_PARAM;
            return HAL_ERROR;
        }

        /* Process Locked */
        if (USART_LockHandle(husart, HAL_MAX_DELAY) != HAL_OK)
        {
            /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
            return HAL_BUSY;
        }

        husart->pRxBuffPtr = pRxData;
        husart->RxXferSize = Size;
        husart->RxXferCount = Size;
        husart->pTxBuffPtr = pTxData;
        husart->TxXferSize = Size;
        husart->TxXferCount = Size;

        /* Computation of USART mask to apply to RDR register */
        __HAL_USART_MASK_COMPUTATION(husart);

        husart->ErrorCode = HAL_USART_ERROR_NONE;
        husart->State = HAL_USART_STATE_BUSY_TX_RX;

        /* Prime the transmit side: push the pending data units now (in FIFO mode
           the whole frame fits into the TXFIFO - see the note on the interrupt
           source in HAL_USART_Transmit_IT). */
        USART_TxPushPending(husart);

        /* Enable the USART Data Register not empty Interrupt */
        SET_BIT(husart->Instance->CR1, USART_CR1_RXNEIE);

        /* Enable the USART Parity Error Interrupt */
        SET_BIT(husart->Instance->CR1, USART_CR1_PEIE);

        /* Enable the USART Error Interrupt: (frame error, noise error, overrun error) */
        SET_BIT(husart->Instance->CR3, USART_CR3_EIE);

        /* Process Unlocked */
        USART_UnlockHandle(husart);

        /* Enable the USART Transmit Complete Interrupt.
           NOTE: the transmit data register empty (TXE / TXFNF) interrupt of this
           device does not generate an interrupt request (see the note in
           HAL_USART_Transmit_IT), so the transmit side of the full duplex
           transfer is completed by the transmit complete event as well. */
        __HAL_USART_ENABLE_IT(husart, USART_IT_TC);

        return HAL_OK;
    }
    else
    {
        /* ARCH-CONST-09: only a busy or uninitialized handle reaches this
           branch, so the gate verdict is reported as is */
           return USART_CheckState(husart);
    }
}

/**
  * @brief  Send an amount of data in DMA mode. (NON-BLOCKING / DMA)
  * @note   The DMA channel referenced by husart->hdmatx must be initialized
  *         (HAL_DMA_Init) and mapped to the USART peripheral interface
  *         (HAL_DMA_ConfigPeriphIF). The channel data width must match the
  *         USART data width. The transfer completion is reported by
  *         HAL_USART_TxCpltCallback().
  * @param  husart: USART handle
  * @param  pTxData: pointer to data buffer
  * @param  Size: amount of data to be sent
  * @retval HAL status
  */
#ifdef HAL_DMA_MODULE_ENABLED
HAL_StatusTypeDef HAL_USART_Transmit_DMA(USART_HandleTypeDef *husart, uint8 *pTxData, uint16 Size)
{
    /* Check the USART handle allocation before any access (MISRA-MEM-04) */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    /* ARCH-CONST-09: state gate. A busy handle (an ongoing transfer) is
       rejected with HAL_BUSY, an uninitialized handle with HAL_ERROR, while
       the recoverable states (timeout / error) accept the new operation. */
    if (USART_CheckState(husart) == HAL_OK)



    {
        if ((pTxData == NULL_PTR) || (Size == 0U))
        {
            husart->ErrorCode |= HAL_USART_ERROR_INVALID_PARAM;
            return HAL_ERROR;
        }
        if (husart->hdmatx == NULL_PTR)
        {
            husart->ErrorCode |= HAL_USART_ERROR_INVALID_PARAM;
            return HAL_ERROR;
        }

        /* Process Locked */
        if (USART_LockHandle(husart, HAL_MAX_DELAY) != HAL_OK)
        {
            /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
            return HAL_BUSY;
        }

        husart->pTxBuffPtr = pTxData;
        husart->TxXferSize = Size;
        husart->TxXferCount = Size;
        husart->ErrorCode = HAL_USART_ERROR_NONE;
        husart->State = HAL_USART_STATE_BUSY_TX;

        /* Set the DMA channel parent and register the callbacks */
        husart->hdmatx->Parent  = (void *)husart;
        HAL_DMA_RegisterCallback(husart->hdmatx, HAL_DMA_XFER_CPLT_CB_ID, USART_DMATransmitCplt);
        HAL_DMA_RegisterCallback(husart->hdmatx, HAL_DMA_XFER_HALFCPLT_CB_ID, USART_DMATxHalfCplt);
        HAL_DMA_RegisterCallback(husart->hdmatx, HAL_DMA_XFER_ERROR_CB_ID, USART_DMAError);
        HAL_DMA_RegisterCallback(husart->hdmatx, HAL_DMA_XFER_ABORT_CB_ID, USART_DMAAbortOnError);

        /* Enable the USART Error Interrupt: (frame error, noise error, overrun error) */
        SET_BIT(husart->Instance->CR3, USART_CR3_EIE);

        /* Clear the USART parity error, frame error, noise error and overrun error flags */
        __HAL_USART_CLEAR_IT(husart, (USART_CLEAR_PEF | USART_CLEAR_FEF | USART_CLEAR_NEF | USART_CLEAR_OREF));

        /* Start the DMA transfer */
        if (HAL_DMA_Start_IT(husart->hdmatx, (uint32)pTxData,
                             (uint32)&husart->Instance->TDR, Size) != HAL_OK)
        {
            /* The DMA engine refused the transfer: report it through the error
               code and leave the handle ready, the call can be retried */
            husart->ErrorCode |= HAL_USART_ERROR_DMA;
            husart->State = HAL_USART_STATE_READY;
            USART_UnlockHandle(husart);
            return HAL_ERROR;
        }

        /* Enable the USART DMA Tx request */
        SET_BIT(husart->Instance->CR3, USART_CR3_DMAT);

        /* Process Unlocked */
        USART_UnlockHandle(husart);

        return HAL_OK;
    }
    else
    {
        /* ARCH-CONST-09: only a busy or uninitialized handle reaches this
           branch, so the gate verdict is reported as is */
           return USART_CheckState(husart);
    }
}
#else
HAL_StatusTypeDef HAL_USART_Transmit_DMA(USART_HandleTypeDef *husart, uint8 *pTxData, uint16 Size)
{
    /* Prevent unused argument(s) compilation warning */
    /* Check the husart handle allocation */
    if (husart == NULL_PTR)
    {
        return HAL_ERROR;
    }
    UNUSED(husart);
    UNUSED(pTxData);
    UNUSED(Size);

    return HAL_ERROR;
}
#endif

/**
  * @brief  Receive an amount of data in DMA mode (NON-BLOCKING / DMA)
  * @note   When the USART parity is enabled (PCE = 1), the received data contain
  *         the parity bit (MSB position)
  * @param  husart: USART handle
  * @param  pRxData: pointer to data buffer
  * @param  Size: amount of data to be received
  * @retval HAL status
  */
#ifdef HAL_DMA_MODULE_ENABLED
HAL_StatusTypeDef HAL_USART_Receive_DMA(USART_HandleTypeDef *husart, uint8 *pRxData, uint16 Size)
{
    /* Check the USART handle allocation before any access (MISRA-MEM-04) */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    /* ARCH-CONST-09: state gate. A busy handle (an ongoing transfer) is
       rejected with HAL_BUSY, an uninitialized handle with HAL_ERROR, while
       the recoverable states (timeout / error) accept the new operation. */
    if (USART_CheckState(husart) == HAL_OK)



    {
        if ((pRxData == NULL_PTR) || (Size == 0U))
        {
            husart->ErrorCode |= HAL_USART_ERROR_INVALID_PARAM;
            return HAL_ERROR;
        }
        if (husart->hdmarx == NULL_PTR)
        {
            husart->ErrorCode |= HAL_USART_ERROR_INVALID_PARAM;
            return HAL_ERROR;
        }

        /* Process Locked */
        if (USART_LockHandle(husart, HAL_MAX_DELAY) != HAL_OK)
        {
            /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
            return HAL_BUSY;
        }

        husart->pRxBuffPtr = pRxData;
        husart->RxXferSize = Size;
        husart->RxXferCount = Size;
        husart->ErrorCode = HAL_USART_ERROR_NONE;
        husart->State = HAL_USART_STATE_BUSY_RX;

        /* Set the DMA channel parent and register the callbacks */
        husart->hdmarx->Parent  = (void *)husart;
        HAL_DMA_RegisterCallback(husart->hdmarx, HAL_DMA_XFER_CPLT_CB_ID, USART_DMAReceiveCplt);
        HAL_DMA_RegisterCallback(husart->hdmarx, HAL_DMA_XFER_HALFCPLT_CB_ID, USART_DMARxHalfCplt);
        HAL_DMA_RegisterCallback(husart->hdmarx, HAL_DMA_XFER_ERROR_CB_ID, USART_DMAError);
        HAL_DMA_RegisterCallback(husart->hdmarx, HAL_DMA_XFER_ABORT_CB_ID, USART_DMAAbortOnError);

        /* Enable the USART Parity Error Interrupt */
        SET_BIT(husart->Instance->CR1, USART_CR1_PEIE);

        /* Enable the USART Error Interrupt: (frame error, noise error, overrun error) */
        SET_BIT(husart->Instance->CR3, USART_CR3_EIE);

        /* Clear the USART parity error, frame error, noise error and overrun error flags */
        __HAL_USART_CLEAR_IT(husart, (USART_CLEAR_PEF | USART_CLEAR_FEF | USART_CLEAR_NEF | USART_CLEAR_OREF));

        /* Start the DMA transfer */
        if (HAL_DMA_Start_IT(husart->hdmarx, (uint32)&husart->Instance->RDR,
                             (uint32)pRxData, Size) != HAL_OK)
        {
            /* The DMA engine refused the transfer: report it through the error
               code and leave the handle ready, the call can be retried */
            husart->ErrorCode |= HAL_USART_ERROR_DMA;
            husart->State = HAL_USART_STATE_READY;
            USART_UnlockHandle(husart);
            return HAL_ERROR;
        }

        /* Enable the USART DMA Rx request */
        SET_BIT(husart->Instance->CR3, USART_CR3_DMAR);

        /* Process Unlocked */
        USART_UnlockHandle(husart);

        return HAL_OK;
    }
    else
    {
        /* ARCH-CONST-09: only a busy or uninitialized handle reaches this
           branch, so the gate verdict is reported as is */
           return USART_CheckState(husart);
    }
}
#else
HAL_StatusTypeDef HAL_USART_Receive_DMA(USART_HandleTypeDef *husart, uint8 *pRxData, uint16 Size)
{
    /* Prevent unused argument(s) compilation warning */
    /* Check the husart handle allocation */
    if (husart == NULL_PTR)
    {
        return HAL_ERROR;
    }
    UNUSED(husart);
    UNUSED(pRxData);
    UNUSED(Size);

    return HAL_ERROR;
}
#endif

/**
  * @brief  Full-Duplex Transmit Receive an amount of data in non blocking mode (NON-BLOCKING / DMA)
  * @note   When the USART parity is enabled (PCE = 1), the data received contain
  *         the parity bit.
  * @param  husart: USART handle
  * @param  pTxData: pointer to TX data buffer
  * @param  pRxData: pointer to RX data buffer
  * @param  Size: amount of data to be received/sent
  * @retval HAL status
  */
#ifdef HAL_DMA_MODULE_ENABLED
HAL_StatusTypeDef HAL_USART_TransmitReceive_DMA(USART_HandleTypeDef *husart, uint8 *pTxData, uint8 *pRxData,
                                                uint16 Size)
{
    /* Check the USART handle allocation before any access (MISRA-MEM-04) */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    /* ARCH-CONST-09: state gate. A busy handle (an ongoing transfer) is
       rejected with HAL_BUSY, an uninitialized handle with HAL_ERROR, while
       the recoverable states (timeout / error) accept the new operation. */
    if (USART_CheckState(husart) == HAL_OK)



    {
        if ((pTxData == NULL_PTR) || (pRxData == NULL_PTR) || (Size == 0U))
        {
            husart->ErrorCode |= HAL_USART_ERROR_INVALID_PARAM;
            return HAL_ERROR;
        }
        if ((husart->hdmatx == NULL_PTR) || (husart->hdmarx == NULL_PTR))
        {
            return HAL_ERROR;
        }

        /* Process Locked */
        if (USART_LockHandle(husart, HAL_MAX_DELAY) != HAL_OK)
        {
            /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
            return HAL_BUSY;
        }

        husart->pTxBuffPtr = pTxData;
        husart->TxXferSize = Size;
        husart->TxXferCount = Size;
        husart->pRxBuffPtr = pRxData;
        husart->RxXferSize = Size;
        husart->RxXferCount = Size;
        husart->ErrorCode = HAL_USART_ERROR_NONE;
        husart->State = HAL_USART_STATE_BUSY_TX_RX;

        /* Set the DMA channel parents and register the callbacks.
         * The full-duplex transfer is driven by the Rx DMA channel completion;
         * the Tx DMA channel callback is left empty. */
        husart->hdmatx->Parent  = (void *)husart;
        husart->hdmarx->Parent  = (void *)husart;
        HAL_DMA_RegisterCallback(husart->hdmarx, HAL_DMA_XFER_CPLT_CB_ID, USART_DMATransmitReceiveCplt);
        HAL_DMA_RegisterCallback(husart->hdmarx, HAL_DMA_XFER_HALFCPLT_CB_ID, USART_DMARxHalfCplt);
        HAL_DMA_RegisterCallback(husart->hdmarx, HAL_DMA_XFER_ERROR_CB_ID, USART_DMAError);
        HAL_DMA_RegisterCallback(husart->hdmarx, HAL_DMA_XFER_ABORT_CB_ID, USART_DMAAbortOnError);
        HAL_DMA_RegisterCallback(husart->hdmatx, HAL_DMA_XFER_CPLT_CB_ID, NULL_PTR);
        HAL_DMA_RegisterCallback(husart->hdmatx, HAL_DMA_XFER_HALFCPLT_CB_ID, USART_DMATxHalfCplt);
        HAL_DMA_RegisterCallback(husart->hdmatx, HAL_DMA_XFER_ERROR_CB_ID, USART_DMAError);
        HAL_DMA_RegisterCallback(husart->hdmatx, HAL_DMA_XFER_ABORT_CB_ID, USART_DMAAbortOnError);

        /* Enable the USART Parity Error Interrupt */
        SET_BIT(husart->Instance->CR1, USART_CR1_PEIE);

        /* Enable the USART Error Interrupt: (frame error, noise error, overrun error) */
        SET_BIT(husart->Instance->CR3, USART_CR3_EIE);

        /* Clear the USART parity error, frame error, noise error and overrun error flags */
        __HAL_USART_CLEAR_IT(husart, (USART_CLEAR_PEF | USART_CLEAR_FEF | USART_CLEAR_NEF | USART_CLEAR_OREF));

        /* Start the Rx DMA transfer */
        if (HAL_DMA_Start_IT(husart->hdmarx, (uint32)&husart->Instance->RDR,
                             (uint32)pRxData, Size) != HAL_OK)
        {
            /* The DMA engine refused the transfer: report it through the error
               code and leave the handle ready, the call can be retried */
            husart->ErrorCode |= HAL_USART_ERROR_DMA;
            husart->State = HAL_USART_STATE_READY;
            USART_UnlockHandle(husart);
            return HAL_ERROR;
        }

        /* Start the Tx DMA transfer */
        if (HAL_DMA_Start_IT(husart->hdmatx, (uint32)pTxData,
                             (uint32)&husart->Instance->TDR, Size) != HAL_OK)
        {
            /* The Tx direction could not be started while the Rx direction is
               already armed: roll the Rx direction back (close its request,
               abort its channel and reset the transfer state), so that no
               armed channel is left behind and the documented retry really
               works. The Rx request bit is cleared defensively, it is only
               set after both channels have started. */
            CLEAR_BIT(husart->Instance->CR3, USART_CR3_DMAR);
            (void)HAL_DMA_Abort(husart->hdmarx);
            USART_EndRxTransfer(husart);

            /* The DMA engine refused the transfer: report it through the error
               code and leave the handle ready, the call can be retried */
            husart->ErrorCode |= HAL_USART_ERROR_DMA;
            USART_UnlockHandle(husart);
            return HAL_ERROR;
        }

        /* Enable the USART DMA Rx request before the DMA Tx request */
        SET_BIT(husart->Instance->CR3, USART_CR3_DMAR);
        SET_BIT(husart->Instance->CR3, USART_CR3_DMAT);

        /* Process Unlocked */
        USART_UnlockHandle(husart);

        return HAL_OK;
    }
    else
    {
        /* ARCH-CONST-09: only a busy or uninitialized handle reaches this
           branch, so the gate verdict is reported as is */
           return USART_CheckState(husart);
    }
}
#else
HAL_StatusTypeDef HAL_USART_TransmitReceive_DMA(USART_HandleTypeDef *husart, uint8 *pTxData, uint8 *pRxData,
                                                uint16 Size)
{
    /* Prevent unused argument(s) compilation warning */
    /* Check the husart handle allocation */
    if (husart == NULL_PTR)
    {
        return HAL_ERROR;
    }
    UNUSED(husart);
    UNUSED(pTxData);
    UNUSED(pRxData);
    UNUSED(Size);

    return HAL_ERROR;
}
#endif

/**
  * @brief  Pauses the DMA Transfer. (NON-BLOCKING)
  * @param  husart: USART handle
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_DMAPause(USART_HandleTypeDef *husart)
{
    /* Check the USART handle and instance */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: this command serves an ongoing transfer, so only an
       uninitialized handle is rejected (the busy states are accepted) */
    if (USART_CheckInitState(husart) != HAL_OK)
    {
        return HAL_ERROR;
    }

    /* Process Locked */
    if (USART_LockHandle(husart, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    if (husart->State == HAL_USART_STATE_BUSY_TX)
    {
        /* Disable the USART DMA Tx request */
        CLEAR_BIT(husart->Instance->CR3, USART_CR3_DMAT);
    }
    else if (husart->State == HAL_USART_STATE_BUSY_RX)
    {
        /* Disable RXNE, PE and ERR (frame error, noise error, overrun error) interrupts */
        CLEAR_BIT(husart->Instance->CR1, (USART_CR1_RXNEIE | USART_CR1_PEIE));
        CLEAR_BIT(husart->Instance->CR3, USART_CR3_EIE);

        /* Disable the USART DMA Rx request */
        CLEAR_BIT(husart->Instance->CR3, USART_CR3_DMAR);
    }
    else if (husart->State == HAL_USART_STATE_BUSY_TX_RX)
    {
        /* Disable the USART DMA Rx request */
        CLEAR_BIT(husart->Instance->CR3, USART_CR3_DMAR);

        /* Disable the USART DMA Tx request */
        CLEAR_BIT(husart->Instance->CR3, USART_CR3_DMAT);
    }

    /* Process Unlocked */
    USART_UnlockHandle(husart);

    return HAL_OK;
}

/**
  * @brief  Resumes the DMA Transfer. (NON-BLOCKING)
  * @param  husart: USART handle
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_DMAResume(USART_HandleTypeDef *husart)
{
    /* Check the USART handle and instance */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: this command serves an ongoing transfer, so only an
       uninitialized handle is rejected (the busy states are accepted) */
    if (USART_CheckInitState(husart) != HAL_OK)
    {
        return HAL_ERROR;
    }

    /* Process Locked */
    if (USART_LockHandle(husart, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    if (husart->State == HAL_USART_STATE_BUSY_TX)
    {
        /* Enable the USART DMA Tx request */
        SET_BIT(husart->Instance->CR3, USART_CR3_DMAT);
    }
    else if (husart->State == HAL_USART_STATE_BUSY_RX)
    {
        /* Clear the Overrun flag before resuming the Rx transfer */
        __HAL_USART_CLEAR_IT(husart, USART_CLEAR_OREF);

        /* Reenable RXNE, PE and ERR (frame error, noise error, overrun error) interrupts */
        SET_BIT(husart->Instance->CR1, (USART_CR1_RXNEIE | USART_CR1_PEIE));
        SET_BIT(husart->Instance->CR3, USART_CR3_EIE);

        /* Enable the USART DMA Rx request */
        SET_BIT(husart->Instance->CR3, USART_CR3_DMAR);
    }
    else if (husart->State == HAL_USART_STATE_BUSY_TX_RX)
    {
        /* Clear the Overrun flag before resuming the Rx transfer */
        __HAL_USART_CLEAR_IT(husart, USART_CLEAR_OREF);

        /* Enable the USART DMA Rx request before the DMA Tx request */
        SET_BIT(husart->Instance->CR3, USART_CR3_DMAR);

        /* Enable the USART DMA Tx request */
        SET_BIT(husart->Instance->CR3, USART_CR3_DMAT);
    }

    /* Process Unlocked */
    USART_UnlockHandle(husart);

    return HAL_OK;
}

/**
  * @brief  Stops the DMA Transfer. (NON-BLOCKING)
  * @param  husart: USART handle
  * @retval HAL status
  */
#ifdef HAL_DMA_MODULE_ENABLED
HAL_StatusTypeDef HAL_USART_DMAStop(USART_HandleTypeDef *husart)
{
    /* Check the USART handle allocation before any access (MISRA-MEM-04) */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* The Lock is not implemented on this API to allow the transfers to be
       aborted from the callbacks (HAL_USART_ErrorCallback, ...). */

    /* Close the DMA requests and abort the channels (Tier-3 core shared with
       HAL_USART_DeInit()) */
    USART_AbortLinkedDmaChannels(husart);

    /* Reset the USART transfer state */
    USART_EndTxTransfer(husart);
    USART_EndRxTransfer(husart);

    return HAL_OK;
}
#else
HAL_StatusTypeDef HAL_USART_DMAStop(USART_HandleTypeDef *husart)
{
    /* Prevent unused argument(s) compilation warning */
    /* Check the husart handle allocation */
    if (husart == NULL_PTR)
    {
        return HAL_ERROR;
    }
    UNUSED(husart);

    return HAL_ERROR;
}
#endif

/**
  * @brief  This function handles USART interrupt request. (NON-BLOCKING)
  * @param  husart: USART handle
  * @retval None
  */
void HAL_USART_IRQHandler(USART_HandleTypeDef *husart)
{
    uint32 isrflags;
    uint32 cr1its;
    uint32 cr3its;
    uint32 errorflags;

    /* Check the husart handle allocation before any register access
     * (MISRA-MEM-04) */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return;
    }

    isrflags = READ_REG(husart->Instance->ISR);
    cr1its   = READ_REG(husart->Instance->CR1);
    cr3its   = READ_REG(husart->Instance->CR3);

    /* If no error occurs */
    errorflags = (isrflags & (uint32)(USART_ISR_PE | USART_ISR_FE | USART_ISR_ORE | USART_ISR_NE));
    if (errorflags == RESET)
    {
        /* USART in mode Receiver --------------------------------------------------*/
        if (((isrflags & USART_ISR_RXNE_RXFNE) != RESET) && ((cr1its & USART_CR1_RXNEIE) != RESET))
        {
            if (husart->State == HAL_USART_STATE_BUSY_RX)
            {
                USART_Receive_IT(husart);
            }
            else
            {
                USART_TransmitReceive_IT(husart);
            }
        }
    }

    /* If some errors occur */
    if ((errorflags != RESET) &&
        (((cr1its & USART_CR1_PEIE) != RESET) ||
         ((cr3its & USART_CR3_EIE) != RESET)))
    {
        /* USART parity error interrupt occurred ------------------------------------*/
        if (((isrflags & USART_ISR_PE) != RESET) && ((cr1its & USART_CR1_PEIE) != RESET))
        {
            __HAL_USART_CLEAR_IT(husart, USART_CLEAR_PEF);
            husart->ErrorCode |= HAL_USART_ERROR_PE;
        }

        /* USART frame error interrupt occurred -------------------------------------*/
        if (((isrflags & USART_ISR_FE) != RESET) && ((cr3its & USART_CR3_EIE) != RESET))
        {
            __HAL_USART_CLEAR_IT(husart, USART_CLEAR_FEF);
            husart->ErrorCode |= HAL_USART_ERROR_FE;
        }

        /* USART noise error interrupt occurred -------------------------------------*/
        if (((isrflags & USART_ISR_NE) != RESET) && ((cr3its & USART_CR3_EIE) != RESET))
        {
            __HAL_USART_CLEAR_IT(husart, USART_CLEAR_NEF);
            husart->ErrorCode |= HAL_USART_ERROR_NE;
        }

        /* USART Over-Run interrupt occurred ----------------------------------------*/
        if (((isrflags & USART_ISR_ORE) != RESET) && ((cr3its & USART_CR3_EIE) != RESET))
        {
            __HAL_USART_CLEAR_IT(husart, USART_CLEAR_OREF);
            husart->ErrorCode |= HAL_USART_ERROR_ORE;
        }

        /* Call USART Error Call back function if need be --------------------------*/
        if (husart->ErrorCode != HAL_USART_ERROR_NONE)
        {
            /* USART in mode Receiver ---------------------------------------------------*/
            if (((isrflags & USART_ISR_RXNE_RXFNE) != RESET) && ((cr1its & USART_CR1_RXNEIE) != RESET))
            {
                USART_Receive_IT(husart);
            }

            /* If Overrun error occurs, consider error as blocking */
            if ((husart->ErrorCode & HAL_USART_ERROR_ORE) != RESET)
            {
                /* Blocking error: transfer is aborted.
                   Set the USART state ready to be able to start again the process,
                   disable Rx interrupts */
                USART_EndRxTransfer(husart);

                /* Call user error callback */
                HAL_USART_ErrorCallback(husart);
            }
            else
            {
                /* Non Blocking error: transfer could go on.
                   Error is notified to user through user error callback */
                HAL_USART_ErrorCallback(husart);
                husart->ErrorCode = HAL_USART_ERROR_NONE;
            }
        }
        return;
    } /* End if some error occurs */

    /* USART in mode Transmitter -----------------------------------------------*/
    if (((isrflags & USART_ISR_TXE_TXFNF) != RESET) && ((cr1its & USART_CR1_TXEIE) != RESET))
    {
        if (husart->State == HAL_USART_STATE_BUSY_TX)
        {
            USART_Transmit_IT(husart);
        }
        else
        {
            USART_TransmitReceive_IT(husart);
        }
        return;
    }

    /* USART in mode Transmitter (transmission end) -----------------------------*/
    if (((isrflags & USART_ISR_TC) != RESET) && ((cr1its & USART_CR1_TCIE) != RESET))
    {
        USART_EndTransmit_IT(husart);
        return;
    }
}

/**
  * @brief  Tx Transfer completed callbacks (NON-BLOCKING)
  * @param  husart: USART handle
  * @retval None
  */
__weak void HAL_USART_TxCpltCallback(USART_HandleTypeDef *husart)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(husart);

    /* NOTE: This function should not be modified, when the callback is needed,
             the HAL_USART_TxCpltCallback can be implemented in the user file
     */
}

/**
  * @brief  Tx Half Transfer completed callbacks (NON-BLOCKING)
  * @param  husart: USART handle
  * @retval None
  */
__weak void HAL_USART_TxHalfCpltCallback(USART_HandleTypeDef *husart)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(husart);

    /* NOTE: This function should not be modified, when the callback is needed,
             the HAL_USART_TxHalfCpltCallback can be implemented in the user file
     */
}

/**
  * @brief  Rx Transfer completed callbacks (NON-BLOCKING)
  * @param  husart: USART handle
  * @retval None
  */
__weak void HAL_USART_RxCpltCallback(USART_HandleTypeDef *husart)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(husart);

    /* NOTE: This function should not be modified, when the callback is needed,
             the HAL_USART_RxCpltCallback can be implemented in the user file
     */
}

/**
  * @brief  Rx Half Transfer completed callbacks (NON-BLOCKING)
  * @param  husart: USART handle
  * @retval None
  */
__weak void HAL_USART_RxHalfCpltCallback(USART_HandleTypeDef *husart)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(husart);

    /* NOTE: This function should not be modified, when the callback is needed,
             the HAL_USART_RxHalfCpltCallback can be implemented in the user file
     */
}

/**
  * @brief  Tx/Rx Transfers completed callback for the non-blocking process (NON-BLOCKING)
  * @param  husart: USART handle
  * @retval None
  */
__weak void HAL_USART_TxRxCpltCallback(USART_HandleTypeDef *husart)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(husart);

    /* NOTE: This function should not be modified, when the callback is needed,
             the HAL_USART_TxRxCpltCallback can be implemented in the user file
     */
}

/**
  * @brief  USART error callbacks (NON-BLOCKING)
  * @param  husart: USART handle
  * @retval None
  */
__weak void HAL_USART_ErrorCallback(USART_HandleTypeDef *husart)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(husart);

    /* NOTE: This function should not be modified, when the callback is needed,
             the HAL_USART_ErrorCallback can be implemented in the user file
     */
}

/**
  * @}
  */

/** @defgroup USART_Exported_Functions_Group3 Peripheral State and Errors functions
  *  @brief   USART State and Errors functions
  *
  @verbatim
  ==============================================================================
                  ##### Peripheral State and Errors functions #####
  ==============================================================================
    [..]
    This subsection provides a set of functions allowing to return the State of
    USART communication process, return Peripheral Errors occurred during
    communication process
     (+) HAL_USART_GetState() API can be helpful to check in run-time the state
         of the USART peripheral.
     (+) HAL_USART_GetError() checks in run-time errors that could be occurred
         during communication.
  @endverbatim
  * @{
  */

/**
  * @brief  Return the USART state (NON-BLOCKING)
  * @param  husart: USART handle
  * @retval HAL state
  */
HAL_USART_StateTypeDef HAL_USART_GetState(USART_HandleTypeDef *husart)
{
    /* Check the husart handle allocation */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_USART_STATE_RESET;
    }
    return husart->State;
}

/**
  * @brief  Return the USART error code (NON-BLOCKING)
  * @param  husart: pointer to a USART_HandleTypeDef structure that contains
  *                 the configuration information for the specified USART.
  * @retval USART Error Code
  */
uint32 HAL_USART_GetError(USART_HandleTypeDef *husart)
{
    /* Check the husart handle allocation */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return 0U;
    }
    return husart->ErrorCode;
}

/**
  * @}
  */

/**
  * @}
  */

/* Private function prototypes -----------------------------------------------*/
static uint32 USART_DisableInstanceForUpdate(USART_HandleTypeDef *husart);
static void USART_RestoreInstanceState(USART_HandleTypeDef *husart, uint32 ue_state);

/** @addtogroup AS32X601_HAL_Driver
  * @{
  */

/** @defgroup USART USART
  * @brief HAL USART Extension module driver
  * @{
  */

/** @defgroup USART_Exported_Functions USART Exported Functions
  * @{
  */

/**
  * @brief  Initializes the USARTx peripheral clock according to the specified (NON-BLOCKING)
  *         parameters in the USART_ClockInitTypeDef. (NON-BLOCKING)
  * @param  husart: USART handle
  * @param  pClockInit: pointer to a USART_ClockInitTypeDef structure that
  *                     contains the configuration information for the specified
  *                     USART peripheral.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_ConfigClock(USART_HandleTypeDef *husart, USART_ClockInitTypeDef *pClockInit)
{
    uint32 tmpreg = 0x00U;
    uint32 ue_state = 0U;

    /* Check the USART handle allocation */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_USART_ALL_PERIPH(husart->Instance));
    assert_param(IS_USART_CLOCK(pClockInit->Clock));
    assert_param(IS_USART_POLARITY(pClockInit->CPOL));
    assert_param(IS_USART_PHASE(pClockInit->CPHA));
    assert_param(IS_USART_LASTBIT(pClockInit->LastBit));

    /* Run time parameter validation, so that the checks stay effective in a
     * build with the assertions disabled. A rejected call neither takes the
     * lock nor touches a register. */
    if (pClockInit == NULL_PTR)
    {
        husart->ErrorCode |= HAL_USART_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    tmpreg = husart->Instance->CR2;

    /* Save the CR1 UE bit, disable the instance for the update and restore the
       saved state afterwards: an instance the user had enabled stays enabled,
       one that was disabled is never enabled by this interface. The CLKEN and
       LBCL bits are only writable while the instance is disabled, hence the
       order below. */
    ue_state = USART_DisableInstanceForUpdate(husart);

    /* Clear CLKEN, CPOL, CPHA and LBCL bits */
    tmpreg &= ~((uint32)(USART_CR2_CLKEN | USART_CR2_CPOL | USART_CR2_CPHA | USART_CR2_LBCL));

    /* Configure the USART Clock, CPOL, CPHA and LastBit */
    tmpreg |= (uint32)(pClockInit->Clock | pClockInit->CPOL | pClockInit->CPHA | pClockInit->LastBit);

    /* Write to USART CR2 */
    husart->Instance->CR2 = tmpreg;

    /* Restore the instance state saved above */
    USART_RestoreInstanceState(husart, ue_state);

    return HAL_OK;
}

/**
  * @brief  Configure the USART peripheral advanced features. (NON-BLOCKING)
  * @param  husart: USART handle
  * @param  pAdvFeatureInit: pointer to a USART_AdvFeatureInitTypeDef structure
  *                          that contains the configuration information for the
  *                          specified USART peripheral.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_ConfigAdvFeature(USART_HandleTypeDef *husart,
                                               USART_AdvFeatureInitTypeDef *pAdvFeatureInit)
{
    uint32 ue_state = 0U;
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the USART handle and instance */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* Run time parameter validation, so that the checks stay effective in a
     * build with the assertions disabled */
    if (pAdvFeatureInit == NULL_PTR)
    {
        husart->ErrorCode |= HAL_USART_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_USART_ALL_PERIPH(husart->Instance));
    assert_param(IS_USART_ADVFEATURE_INIT(pAdvFeatureInit->AdvFeatureInit));

    /* Save the CR1 UE bit, disable the instance for the update and restore the
       saved state afterwards: an instance the user had enabled stays enabled,
       one that was disabled is never enabled by this interface. The MSBFIRST
       bit is only writable while the instance is disabled, hence the order
       below. */
    ue_state = USART_DisableInstanceForUpdate(husart);

    /* LOCK-05: the register access sequence lives in a Tier-3 helper, so that
       HAL_USART_Init() can program the advanced features inside its locked
       region without calling a public API. The helper must keep running with
       the instance disabled: restoring the state here, in the public API, is
       what keeps it out of the critical region of HAL_USART_Init(). */
    status = USART_ConfigAdvFeatureInternal(husart, pAdvFeatureInit);

    /* Restore the instance state saved above */
    USART_RestoreInstanceState(husart, ue_state);

    return status;
}


/**
  * @brief  Fills each USART_ClockInitStruct member with its default value. (NON-BLOCKING)
  * @param  pClockInit: pointer to a USART_ClockInitTypeDef structure that will
  *                     be initialized
  * @retval None
  */
void HAL_USART_ClockStructInit(USART_ClockInitTypeDef *pClockInit)
{
    /* USART_ClockInitStruct members default value */
    /* Check the pClockInit handle allocation */
    if (pClockInit == NULL_PTR)
    {
        return;
    }
    pClockInit->Clock = USART_CLOCK_DISABLE;
    pClockInit->CPOL = USART_POLARITY_LOW;
    pClockInit->CPHA = USART_PHASE_1EDGE;
    pClockInit->LastBit = USART_LASTBIT_DISABLE;
}

/**
  * @brief  Enable the FIFO mode. (NON-BLOCKING)
  * @param  husart: USART handle
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_EnableFIFO(USART_HandleTypeDef *husart)
{
    uint32 ue_state = 0U;

    /* Check the USART handle allocation */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_USART_ALL_PERIPH(husart->Instance));

    /* Save the CR1 UE bit, disable the instance for the update and restore the
       saved state afterwards: an instance the user had enabled stays enabled,
       one that was disabled is never enabled by this interface */
    ue_state = USART_DisableInstanceForUpdate(husart);

    /* Enable FIFO mode */
    SET_BIT(husart->Instance->CR1, USART_CR1_FIFOEN);

    /* Restore the instance state saved above */
    USART_RestoreInstanceState(husart, ue_state);

    return HAL_OK;
}

/**
  * @brief  Disable the FIFO mode. (NON-BLOCKING)
  * @param  husart: USART handle
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_DisableFIFO(USART_HandleTypeDef *husart)
{
    uint32 ue_state = 0U;

    /* Check the USART handle allocation */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_USART_ALL_PERIPH(husart->Instance));

    /* Save the CR1 UE bit, disable the instance for the update and restore the
       saved state afterwards: an instance the user had enabled stays enabled,
       one that was disabled is never enabled by this interface */
    ue_state = USART_DisableInstanceForUpdate(husart);

    /* Disable FIFO mode */
    CLEAR_BIT(husart->Instance->CR1, USART_CR1_FIFOEN);

    /* Restore the instance state saved above */
    USART_RestoreInstanceState(husart, ue_state);

    return HAL_OK;
}

/**
  * @brief  Set the TXFIFO threshold. (NON-BLOCKING)
  * @param  husart: USART handle
  * @param  Threshold: TX FIFO threshold value.
  *         This parameter can be one of the following values:
  *           @arg USART_TXFIFO_THRESHOLD_1_8: TXFIFO reaches 1/8 of its depth
  *           @arg USART_TXFIFO_THRESHOLD_1_4: TXFIFO reaches 1/4 of its depth
  *           @arg USART_TXFIFO_THRESHOLD_1_2: TXFIFO reaches 1/2 of its depth
  *           @arg USART_TXFIFO_THRESHOLD_3_4: TXFIFO reaches 3/4 of its depth
  *           @arg USART_TXFIFO_THRESHOLD_7_8: TXFIFO reaches 7/8 of its depth
  *           @arg USART_TXFIFO_THRESHOLD_8_8: TXFIFO becomes empty
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_SetTxFIFOThreshold(USART_HandleTypeDef *husart, uint32 Threshold)
{
    uint32 ue_state = 0U;

    /* Check the USART handle allocation */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_USART_ALL_PERIPH(husart->Instance));
    assert_param(IS_USART_TXFIFO_THRESHOLD(Threshold));

    /* Save the CR1 UE bit, disable the instance for the update and restore the
       saved state afterwards: an instance the user had enabled stays enabled,
       one that was disabled is never enabled by this interface */
    ue_state = USART_DisableInstanceForUpdate(husart);

    /* Update TX threshold configuration */
    CLEAR_BIT(husart->Instance->CR3, USART_CR3_TXFTCFG);
    SET_BIT(husart->Instance->CR3, Threshold);

    /* Restore the instance state saved above */
    USART_RestoreInstanceState(husart, ue_state);

    return HAL_OK;
}

/**
  * @brief  Set the RXFIFO threshold. (NON-BLOCKING)
  * @param  husart: USART handle
  * @param  Threshold: RX FIFO threshold value.
  *         This parameter can be one of the following values:
  *           @arg USART_RXFIFO_THRESHOLD_1_8: RXFIFO reaches 1/8 of its depth
  *           @arg USART_RXFIFO_THRESHOLD_1_4: RXFIFO reaches 1/4 of its depth
  *           @arg USART_RXFIFO_THRESHOLD_1_2: RXFIFO reaches 1/2 of its depth
  *           @arg USART_RXFIFO_THRESHOLD_3_4: RXFIFO reaches 3/4 of its depth
  *           @arg USART_RXFIFO_THRESHOLD_7_8: RXFIFO reaches 7/8 of its depth
  *           @arg USART_RXFIFO_THRESHOLD_8_8: RXFIFO becomes full
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_SetRxFIFOThreshold(USART_HandleTypeDef *husart, uint32 Threshold)
{
    uint32 ue_state = 0U;

    /* Check the USART handle allocation */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_USART_ALL_PERIPH(husart->Instance));
    assert_param(IS_USART_RXFIFO_THRESHOLD(Threshold));

    /* Save the CR1 UE bit, disable the instance for the update and restore the
       saved state afterwards: an instance the user had enabled stays enabled,
       one that was disabled is never enabled by this interface */
    ue_state = USART_DisableInstanceForUpdate(husart);

    /* Update RX threshold configuration */
    CLEAR_BIT(husart->Instance->CR3, USART_CR3_RXFTCFG);
    SET_BIT(husart->Instance->CR3, Threshold);

    /* Restore the instance state saved above */
    USART_RestoreInstanceState(husart, ue_state);

    return HAL_OK;
}

/**
  * @brief  Enable the SPI slave mode. (NON-BLOCKING)
  * @note   When the USART operates in SPI slave mode, it handles data flow using
  *         the serial interface clock derived from the external SCLK signal
  *         provided by the external master SPI device.
  *         In SPI slave mode, the USART must be enabled before starting the
  *         master communications (or between frames while the clock is stable).
  *         Otherwise, if the USART slave is enabled while the master is in the
  *         middle of a frame, it will become desynchronized with the master.
  *         The data register of the slave needs to be ready before the first
  *         edge of the communication clock or before the end of the ongoing
  *         communication, otherwise the SPI slave will transmit zeros.
  * @param  husart: USART handle
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_EnableSlaveMode(USART_HandleTypeDef *husart)
{
    uint32 ue_state = 0U;

    /* Check the USART handle allocation */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_USART_ALL_PERIPH(husart->Instance));

    /* Save the CR1 UE bit, disable the instance for the update and restore the
       saved state afterwards: an instance the user had enabled stays enabled,
       one that was disabled is never enabled by this interface. The data
       length bit and the slave mode bits are only writable while the instance
       is disabled, hence the order below. */
    ue_state = USART_DisableInstanceForUpdate(husart);

    /* Synchronous slave mode limited to 8-bit data length */
    CLEAR_BIT(husart->Instance->CR1, USART_CR1_M);

    /* In half-duplex mode, the following bits must be kept cleared:
       - LINEN and CLKEN bits in the USART_CR2 register */
    CLEAR_BIT(husart->Instance->CR2, (USART_CR2_LINEN | USART_CR2_CLKEN));

    /* Enable the Synchronous slave mode by setting the SLVEN bit in the CR2 register */
    SET_BIT(husart->Instance->CR2, USART_CR2_SLVEN);

    /* Restore the instance state saved above */
    USART_RestoreInstanceState(husart, ue_state);

    return HAL_OK;
}

/**
  * @brief  Disable the SPI slave mode. (NON-BLOCKING)
  * @param  husart: USART handle
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_DisableSlaveMode(USART_HandleTypeDef *husart)
{
    uint32 ue_state = 0U;

    /* Check the USART handle allocation */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_USART_ALL_PERIPH(husart->Instance));

    /* Save the CR1 UE bit, disable the instance for the update and restore the
       saved state afterwards: an instance the user had enabled stays enabled,
       one that was disabled is never enabled by this interface */
    ue_state = USART_DisableInstanceForUpdate(husart);

    /* Disable SPI slave mode */
    CLEAR_BIT(husart->Instance->CR2, USART_CR2_SLVEN);

    /* Restore the instance state saved above */
    USART_RestoreInstanceState(husart, ue_state);

    return HAL_OK;
}

/**
  * @brief  Configure the Slave Select input pin (NSS) (NON-BLOCKING)
  * @note   Software NSS management: SPI slave will always be selected and NSS
  *         input pin will be ignored.
  *         Hardware NSS management: the SPI slave selection depends on NSS
  *         input pin. The slave is selected when NSS is low and deselected
  *         when NSS is high.
  * @param  husart: USART handle
  * @param  NSSConfig: NSS configuration.
  *         This parameter can be one of the following values:
  *           @arg USART_NSS_HARDWARE
  *           @arg USART_NSS_SOFTWARE
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_ConfigNSS(USART_HandleTypeDef *husart, uint32 NSSConfig)
{
    uint32 ue_state = 0U;

    /* Check the USART handle allocation */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_USART_ALL_PERIPH(husart->Instance));
    assert_param(IS_USART_NSS(NSSConfig));

    /* Save the CR1 UE bit, disable the instance for the update and restore the
       saved state afterwards: an instance the user had enabled stays enabled,
       one that was disabled is never enabled by this interface */
    ue_state = USART_DisableInstanceForUpdate(husart);

    /* Program DIS_NSS bit in the USART_CR2 register */
    CLEAR_BIT(husart->Instance->CR2, USART_CR2_DIS_NSS);
    SET_BIT(husart->Instance->CR2, NSSConfig);

    /* Restore the instance state saved above */
    USART_RestoreInstanceState(husart, ue_state);

    return HAL_OK;
}

/**
  * @brief  Enables or disables the USART's LIN mode. (NON-BLOCKING)
  * @param  husart: USART handle
  * @param  NewState: new state of the USART LIN mode.
  *         This parameter can be: ENABLE or DISABLE.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_LINCmd(USART_HandleTypeDef *husart, FunctionalState NewState)
{
    uint32 ue_state = 0U;

    /* Check the USART handle allocation */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_USART_ALL_PERIPH(husart->Instance));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Save the CR1 UE bit, disable the instance for the update and restore the
       saved state afterwards: an instance the user had enabled stays enabled,
       one that was disabled is never enabled by this interface. The LINEN bit
       is only writable while the instance is disabled, hence the order
       below. */
    ue_state = USART_DisableInstanceForUpdate(husart);

    if (NewState != DISABLE)
    {
        /* Enable the LIN mode by setting the LINEN bit in the CR2 register */
        SET_BIT(husart->Instance->CR2, USART_CR2_LINEN);
    }
    else
    {
        /* Disable the LIN mode by clearing the LINEN bit in the CR2 register */
        CLEAR_BIT(husart->Instance->CR2, USART_CR2_LINEN);
    }

    /* Restore the instance state saved above */
    USART_RestoreInstanceState(husart, ue_state);

    return HAL_OK;
}

/**
  * @brief  Sets the USART LIN Break detection length. (NON-BLOCKING)
  * @param  husart: USART handle
  * @param  LINBreakDetectLength: specifies the LIN break detection length.
  *         This parameter can be one of the following values:
  *           @arg USART_LINBREAKDETECTLENGTH_11B: 11-bit break detection
  *           @arg USART_LINBREAKDETECTLENGTH_12B: 12-bit break detection
  *           @arg USART_LINBREAKDETECTLENGTH_13B: 13-bit break detection
  *           @arg USART_LINBREAKDETECTLENGTH_14B: 14-bit break detection
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_LINBreakDetectLengthConfig(USART_HandleTypeDef *husart, uint32 LINBreakDetectLength)
{
    /* Check the USART handle allocation */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_USART_ALL_PERIPH(husart->Instance));
    assert_param(IS_USART_LIN_BREAK_DETECT_LENGTH(LINBreakDetectLength));

    CLEAR_BIT(husart->Instance->CR2, USART_CR2_BKNUM);
    SET_BIT(husart->Instance->CR2, LINBreakDetectLength);

    return HAL_OK;
}

/**
  * @brief  Enables or disables the USART's Half Duplex communication. (NON-BLOCKING)
  * @param  husart: USART handle
  * @param  NewState: new state of the USART Communication.
  *         This parameter can be: ENABLE or DISABLE.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_HalfDuplexCmd(USART_HandleTypeDef *husart, FunctionalState NewState)
{
    /* Check the USART handle allocation */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_USART_ALL_PERIPH(husart->Instance));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    if (NewState != DISABLE)
    {
        /* Enable the Half-Duplex mode by setting the HDSEL bit in the CR3 register */
        SET_BIT(husart->Instance->CR3, USART_CR3_HDSEL);
    }
    else
    {
        /* Disable the Half-Duplex mode by clearing the HDSEL bit in the CR3 register */
        CLEAR_BIT(husart->Instance->CR3, USART_CR3_HDSEL);
    }

    return HAL_OK;
}

/**
  * @brief  Enables or disables the USART's one bit sampling method. (NON-BLOCKING)
  * @param  husart: USART handle
  * @param  NewState: new state of the USART one bit sampling method.
  *         This parameter can be: ENABLE or DISABLE.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_OneBitMethodCmd(USART_HandleTypeDef *husart, FunctionalState NewState)
{
    uint32 ue_state = 0U;

    /* Check the USART handle allocation */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_USART_ALL_PERIPH(husart->Instance));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Save the CR1 UE bit, disable the instance for the update and restore the
       saved state afterwards: an instance the user had enabled stays enabled,
       one that was disabled is never enabled by this interface. The ONEBIT bit
       is only writable while the instance is disabled, hence the order
       below. */
    ue_state = USART_DisableInstanceForUpdate(husart);

    if (NewState != DISABLE)
    {
        /* Enable the one bit method by setting the ONEBIT bit in the CR3 register */
        SET_BIT(husart->Instance->CR3, USART_CR3_ONEBIT);
    }
    else
    {
        /* Disable the one bit method by clearing the ONEBIT bit in the CR3 register */
        CLEAR_BIT(husart->Instance->CR3, USART_CR3_ONEBIT);
    }

    /* Restore the instance state saved above */
    USART_RestoreInstanceState(husart, ue_state);

    return HAL_OK;
}

/**
  * @brief  Transmit break characters. (NON-BLOCKING)
  * @param  husart: USART handle
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_SendBreak(USART_HandleTypeDef *husart)
{
    /* Check the USART handle allocation */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_USART_ALL_PERIPH(husart->Instance));

    /* Send break characters */
    SET_BIT(husart->Instance->RQR, USART_RQR_SBKRQ);

    return HAL_OK;
}

/**
  * @brief  Auto Baud rate request. (NON-BLOCKING)
  * @param  husart: USART handle
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_AutoBaudRateRequest(USART_HandleTypeDef *husart)
{
    /* Check the USART handle allocation */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_USART_ALL_PERIPH(husart->Instance));

    /* Auto Baud rate request */
    SET_BIT(husart->Instance->RQR, USART_RQR_ABRRQ);

    return HAL_OK;
}

/**
  * @brief  Receive data flush request. (NON-BLOCKING)
  * @param  husart: USART handle
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_RxDataFlush(USART_HandleTypeDef *husart)
{
    /* Check the USART handle allocation */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_USART_ALL_PERIPH(husart->Instance));

    /* Receive data flush request */
    SET_BIT(husart->Instance->RQR, USART_RQR_RXFRQ);

    return HAL_OK;
}

/**
  * @brief  Transmit data flush request. (NON-BLOCKING)
  * @param  husart: USART handle
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_TxDataFlush(USART_HandleTypeDef *husart)
{
    /* Check the USART handle allocation */
    if (USART_HandleIsValid(husart) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_USART_ALL_PERIPH(husart->Instance));

    /* Transmit data flush request */
    SET_BIT(husart->Instance->RQR, USART_RQR_TXFRQ);

    return HAL_OK;
}

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/* Private functions ---------------------------------------------------------*/
/** @addtogroup USART_Private_Functions
  * @{
  */

/**
  * @brief  Disable the USART instance for a configuration update.
  * @note   Several extension interfaces program bits that the peripheral only
  *         accepts while the instance is disabled (FIFO mode, FIFO thresholds,
  *         slave mode, NSS management, LIN mode, the clock bits, the MSB first
  *         bit and the one bit sampling method). This helper saves the CR1 UE
  *         bit and clears it, so that the caller can update the registers and
  *         then restore the saved state with USART_RestoreInstanceState().
  * @param  husart: USART handle
  * @retval uint32: 1 when the instance was enabled (its state must be restored
  *         afterwards), 0 when it was already disabled (it must stay disabled)
  */
static uint32 USART_DisableInstanceForUpdate(USART_HandleTypeDef *husart)
{
    uint32 ue_state = 0U;

    if ((husart->Instance->CR1 & USART_CR1_UE) != 0U)
    {
        ue_state = 1U;
        CLEAR_BIT(husart->Instance->CR1, USART_CR1_UE);
    }

    return ue_state;
}

/**
  * @brief  Restore the USART instance state saved before a configuration update.
  * @note   Companion of USART_DisableInstanceForUpdate(): an instance that
  *         was enabled by the user is enabled again, while an instance that was
  *         disabled is never enabled by the extension interfaces.
  * @param  husart: USART handle
  * @param  ue_state: value returned by the matching
  *         USART_DisableInstanceForUpdate() call
  * @retval None
  */
static void USART_RestoreInstanceState(USART_HandleTypeDef *husart, uint32 ue_state)
{
    if (ue_state != 0U)
    {
        SET_BIT(husart->Instance->CR1, USART_CR1_UE);
    }
}

/**
  * @brief  Programs the USART peripheral advanced features (register access only).
  * @note   Tier 3 helper shared with as32x601_hal_usart.c: it performs no
  *         validation, takes no lock and applies no state gate, the caller owns
  *         the handle check and the lock.
  * @param  husart: USART handle
  * @param  pAdvFeatureInit: pointer to a USART_AdvFeatureInitTypeDef structure
  *                          that contains the configuration information for the
  *                          specified USART peripheral.
  * @retval HAL status
  */
HAL_StatusTypeDef USART_ConfigAdvFeatureInternal(USART_HandleTypeDef *husart,
                                                   USART_AdvFeatureInitTypeDef *pAdvFeatureInit)
{
    /* If required, configure TX pin active level inversion */
    if ((pAdvFeatureInit->AdvFeatureInit & USART_ADVFEATURE_TXINVERT_INIT) != RESET)
    {
        assert_param(IS_USART_ADVFEATURE_TXINV(pAdvFeatureInit->TxPinLevelInvert));

        CLEAR_BIT(husart->Instance->CR2, USART_CR2_TXINV);
        SET_BIT(husart->Instance->CR2, pAdvFeatureInit->TxPinLevelInvert);
    }

    /* If required, configure RX pin active level inversion */
    if ((pAdvFeatureInit->AdvFeatureInit & USART_ADVFEATURE_RXINVERT_INIT) != RESET)
    {
        assert_param(IS_USART_ADVFEATURE_RXINV(pAdvFeatureInit->RxPinLevelInvert));

        CLEAR_BIT(husart->Instance->CR2, USART_CR2_RXINV);
        SET_BIT(husart->Instance->CR2, pAdvFeatureInit->RxPinLevelInvert);
    }

    /* If required, configure data inversion */
    if ((pAdvFeatureInit->AdvFeatureInit & USART_ADVFEATURE_DATAINVERT_INIT) != RESET)
    {
        assert_param(IS_USART_ADVFEATURE_DATAINV(pAdvFeatureInit->DataInvert));

        CLEAR_BIT(husart->Instance->CR2, USART_CR2_DATAINV);
        SET_BIT(husart->Instance->CR2, pAdvFeatureInit->DataInvert);
    }

    /* If required, configure RX overrun detection disabling */
    if ((pAdvFeatureInit->AdvFeatureInit & USART_ADVFEATURE_RXOVERRUNDISABLE_INIT) != RESET)
    {
        assert_param(IS_USART_OVERRUN(pAdvFeatureInit->OverrunDisable));

        CLEAR_BIT(husart->Instance->CR3, USART_CR3_OVRDIS);
        SET_BIT(husart->Instance->CR3, pAdvFeatureInit->OverrunDisable);
    }

    /* If required, configure auto Baud rate detection scheme */
    if ((pAdvFeatureInit->AdvFeatureInit & USART_ADVFEATURE_AUTOBAUDRATE_INIT) != RESET)
    {
        assert_param(IS_USART_ADVFEATURE_AUTOBAUDRATE(pAdvFeatureInit->AutoBaudRateEnable));

        CLEAR_BIT(husart->Instance->CR2, USART_CR2_ABREN);
        SET_BIT(husart->Instance->CR2, pAdvFeatureInit->AutoBaudRateEnable);

        /* Set auto Baud rate detection parameters if detection is enabled */
        if (pAdvFeatureInit->AutoBaudRateEnable == USART_ADVFEATURE_AUTOBAUDRATE_ENABLE)
        {
            assert_param(IS_USART_ADVFEATURE_AUTOBAUDRATEMODE(pAdvFeatureInit->AutoBaudRateMode));

            CLEAR_BIT(husart->Instance->CR2, USART_CR2_ABRMODE);
            SET_BIT(husart->Instance->CR2, pAdvFeatureInit->AutoBaudRateMode);
        }
    }

    /* If required, configure MSB first on communication line */
    if ((pAdvFeatureInit->AdvFeatureInit & USART_ADVFEATURE_MSBFIRST_INIT) != RESET)
    {
        assert_param(IS_USART_ADVFEATURE_MSBFIRST(pAdvFeatureInit->MSBFirst));

        CLEAR_BIT(husart->Instance->CR2, USART_CR2_MSBFIRST);
        SET_BIT(husart->Instance->CR2, pAdvFeatureInit->MSBFirst);
    }

    return HAL_OK;
}

/**
  * @}
  */

/* Private functions ---------------------------------------------------------*/
/** @addtogroup USART_Private_Functions
  * @{
  */

/**
  * @brief  Push the pending data units into the transmit path.
  * @note   In FIFO mode the whole frame is staged in the TXFIFO (as many units
  *         as the FIFO takes while it reports room), in single data register
  *         mode exactly one unit is pushed so that an interrupt driven transfer
  *         stays non-blocking: TXE is a level there, so a fill loop would turn
  *         the call into a blocking transmission.
  * @note   Staging the whole frame is required in the synchronous slave mode:
  *         the external master clocks the frame out on its own and the TXE
  *         interrupt cannot refill the FIFO in between (see the note in
  *         HAL_USART_Transmit_IT), so a frame that is not queued completely
  *         before the master starts clocking it is sent partially.
  * @param  husart: USART handle
  * @retval None
  */
static void USART_TxPushPending(USART_HandleTypeDef *husart)
{
    uint32 fifo_mode = ((READ_REG(husart->Instance->CR1) & (uint32)USART_FIFOMODE_ENABLE) != 0U) ? 1U : 0U;

    if (husart->TxXferCount == 0U)
    {
        return;
    }

    do
    {
        if ((husart->Init.WordLength == USART_WORDLENGTH_9B) && (husart->Init.Parity == USART_PARITY_NONE))
        {
            uint16 *ptx = (uint16 *)husart->pTxBuffPtr;
            husart->Instance->TDR = (uint16)(*ptx & (uint16)0x01FFU);
            husart->pTxBuffPtr += 2U;
        }
        else
        {
            husart->Instance->TDR = (uint8)(*husart->pTxBuffPtr++ & (uint8)0xFFU);
        }

        husart->TxXferCount--;
    } while ((fifo_mode != 0U) && (husart->TxXferCount > 0U) &&
             (__HAL_USART_GET_FLAG(husart, USART_FLAG_TXE) != RESET));
}

/**
  * @brief  Simplex Send an amount of data in non-blocking mode.
  * @note   Function called under interruption only, once interruptions have
  *         been enabled by HAL_USART_Transmit_IT().
  * @param  husart: USART handle
  * @retval HAL status
  * @note   The USART errors are not managed to avoid the overrun error.
  */
static HAL_StatusTypeDef USART_Transmit_IT(USART_HandleTypeDef *husart)
{
    uint16 *tmp;

    if (husart->State == HAL_USART_STATE_BUSY_TX)
    {
        if (husart->TxXferCount == 0U)
        {
            /* Disable the USART Transmit data register empty interrupt */
            __HAL_USART_DISABLE_IT(husart, USART_IT_TXE);

            /* Enable the USART Transmit Complete Interrupt */
            __HAL_USART_ENABLE_IT(husart, USART_IT_TC);

            return HAL_OK;
        }
        else
        {
            if ((husart->Init.WordLength == USART_WORDLENGTH_9B) && (husart->Init.Parity == USART_PARITY_NONE))
            {
                tmp = (uint16 *)husart->pTxBuffPtr;
                husart->Instance->TDR = (*tmp & (uint16)0x01FFU);
                husart->pTxBuffPtr += 2U;
            }
            else
            {
                husart->Instance->TDR = (uint8)(*husart->pTxBuffPtr++ & (uint8)0xFFU);
            }

            husart->TxXferCount--;

            return HAL_OK;
        }
    }
    else
    {
        /* ARCH-CONST-09: only a busy or uninitialized handle reaches this
           branch, so the gate verdict is reported as is */
           return USART_CheckState(husart);
    }
}

/**
  * @brief  Wraps up transmission in non-blocking mode.
  * @param  husart: pointer to a USART_HandleTypeDef structure that contains
  *                 the configuration information for the specified USART module.
  * @retval HAL status
  */
static HAL_StatusTypeDef USART_EndTransmit_IT(USART_HandleTypeDef *husart)
{
    /* Chain the transfer: while data remain, push the next unit and let the
       next transmit complete event follow. (The TXE / TXFNF interrupt of this
       device does not generate an interrupt request - see the note in
       HAL_USART_Transmit_IT - so the frame chain runs on the transmit complete
       event.) */
    if (husart->TxXferCount > 0U)
    {
        /* Clear the complete flag, so that the next completion is a fresh
           event for the controller */
        __HAL_USART_CLEAR_IT(husart, USART_CLEAR_TCF);

        /* Refill the transmit path (in FIFO mode the whole remaining frame is
           pushed again), then let the next transmit complete event follow */
        USART_TxPushPending(husart);

        return HAL_OK;
    }

    /* Disable the USART Transmit Complete Interrupt */
    CLEAR_BIT(husart->Instance->CR1, USART_CR1_TCIE);

    /* Full duplex transfer with the receive side still running: the transmit
       side is done, the receive side keeps its own bookkeeping (interrupts and
       state) and reports the end of the frame through the TxRxCplt callback.
       Only the transmit complete interrupt is turned off here. */
    if ((husart->State == HAL_USART_STATE_BUSY_TX_RX) && (husart->RxXferCount > 0U))
    {
        return HAL_OK;
    }

    /* Disable the USART Error Interrupt: (frame error, noise error, overrun error) */
    CLEAR_BIT(husart->Instance->CR3, USART_CR3_EIE);

    husart->State = HAL_USART_STATE_READY;

    HAL_USART_TxCpltCallback(husart);

    return HAL_OK;
}

/**
  * @brief  Simplex Receive an amount of data in non-blocking mode.
  *         Function called under interruption only, once interruptions have
  *         been enabled by HAL_USART_Receive_IT().
  * @param  husart: USART handle
  * @retval HAL status
  */
static HAL_StatusTypeDef USART_Receive_IT(USART_HandleTypeDef *husart)
{
    uint16 *tmp;
    uint16 uhMask = husart->Mask;

    if (husart->State == HAL_USART_STATE_BUSY_RX)
    {
        if ((husart->Init.WordLength == USART_WORDLENGTH_9B) && (husart->Init.Parity == USART_PARITY_NONE))
        {
            tmp = (uint16 *)husart->pRxBuffPtr;
            *tmp = (uint16)(husart->Instance->RDR & uhMask);
            husart->pRxBuffPtr += 2U;
        }
        else
        {
            *husart->pRxBuffPtr++ = (uint8)(husart->Instance->RDR & (uint8)uhMask);
        }

        /* Send dummy byte in order to generate the clock for the slave to send
           the next data (synchronous mode only) */
        if (READ_BIT(husart->Instance->CR2, USART_CR2_CLKEN) != RESET)
        {
            husart->Instance->TDR = (USART_DUMMY_DATA & (uint16)0x00FFU);
        }

        if (--husart->RxXferCount == 0U)
        {
            CLEAR_BIT(husart->Instance->CR1, USART_CR1_RXNEIE);

            /* Disable the USART Parity Error Interrupt */
            CLEAR_BIT(husart->Instance->CR1, USART_CR1_PEIE);

            /* Disable the USART Error Interrupt: (frame error, noise error, overrun error) */
            CLEAR_BIT(husart->Instance->CR3, USART_CR3_EIE);

            husart->State = HAL_USART_STATE_READY;

            HAL_USART_RxCpltCallback(husart);

            return HAL_OK;
        }

        return HAL_OK;
    }
    else
    {
        /* ARCH-CONST-09: only a busy or uninitialized handle reaches this
           branch, so the gate verdict is reported as is */
           return USART_CheckState(husart);
    }
}

/**
  * @brief  Full-Duplex Send receive an amount of data in full-duplex mode (non-blocking).
  *         Function called under interruption only, once interruptions have
  *         been enabled by HAL_USART_TransmitReceive_IT().
  * @param  husart: USART handle
  * @retval HAL status
  */
static HAL_StatusTypeDef USART_TransmitReceive_IT(USART_HandleTypeDef *husart)
{
    uint16 *tmp;
    uint16 uhMask = husart->Mask;

    if (husart->State == HAL_USART_STATE_BUSY_TX_RX)
    {
        if (husart->TxXferCount != 0x00U)
        {
            if (__HAL_USART_GET_FLAG(husart, USART_FLAG_TXE) != RESET)
            {
                if ((husart->Init.WordLength == USART_WORDLENGTH_9B) && (husart->Init.Parity == USART_PARITY_NONE))
                {
                    tmp = (uint16 *)husart->pTxBuffPtr;
                    husart->Instance->TDR = (uint16)(*tmp & uhMask);
                    husart->pTxBuffPtr += 2U;
                }
                else
                {
                    husart->Instance->TDR = (uint8)(*husart->pTxBuffPtr++ & (uint8)uhMask);
                }
                husart->TxXferCount--;

                /* Check the latest data transmitted */
                if (husart->TxXferCount == 0U)
                {
                    CLEAR_BIT(husart->Instance->CR1, USART_CR1_TXEIE);
                }
            }
        }

        if (husart->RxXferCount != 0x00U)
        {
            if (__HAL_USART_GET_FLAG(husart, USART_FLAG_RXNE) != RESET)
            {
                if ((husart->Init.WordLength == USART_WORDLENGTH_9B) && (husart->Init.Parity == USART_PARITY_NONE))
                {
                    tmp = (uint16 *)husart->pRxBuffPtr;
                    *tmp = (uint16)(husart->Instance->RDR & uhMask);
                    husart->pRxBuffPtr += 2U;
                }
                else
                {
                    *husart->pRxBuffPtr++ = (uint8)(husart->Instance->RDR & (uint8)uhMask);
                }
                husart->RxXferCount--;
            }
        }

        /* Check the latest data received */
        if (husart->RxXferCount == 0U)
        {
            CLEAR_BIT(husart->Instance->CR1, USART_CR1_RXNEIE);

            /* Disable the USART Parity Error Interrupt */
            CLEAR_BIT(husart->Instance->CR1, USART_CR1_PEIE);

            /* Disable the USART Error Interrupt: (frame error, noise error, overrun error) */
            CLEAR_BIT(husart->Instance->CR3, USART_CR3_EIE);

            if (husart->TxXferCount != 0U)
            {
                /* The receive side is done but the transmit side is not yet finished:
                 * continue in TX-only mode so that no data is silently truncated. */
                husart->State = HAL_USART_STATE_BUSY_TX;
            }
            else
            {
                /* Both directions are done: disable the transmit interrupts (the
                 * TXE one as well as the transmit complete one this device is
                 * driven with) and complete. */
                CLEAR_BIT(husart->Instance->CR1, (USART_CR1_TXEIE | USART_CR1_TCIE));
                husart->State = HAL_USART_STATE_READY;

                HAL_USART_TxRxCpltCallback(husart);
            }

            return HAL_OK;
        }

        return HAL_OK;
    }
    else
    {
        /* ARCH-CONST-09: only a busy or uninitialized handle reaches this
           branch, so the gate verdict is reported as is */
           return USART_CheckState(husart);
    }
}

/**
  * @brief  This function handles USART Communication Timeout.
  * @param  husart: USART handle
  * @param  Flag: specifies the USART flag to check.
  * @param  Status: the new Flag status (SET or RESET).
  * @param  Tickstart: tick start value
  * @param  Timeout: timeout duration
  * @retval HAL status
  */
static HAL_StatusTypeDef USART_WaitOnFlagUntilTimeout(USART_HandleTypeDef *husart,
                                                      uint32 Flag, FlagStatus Status,
                                                      uint32 Tickstart, uint32 Timeout)
{
    /* Wait until flag is set */
    while ((__HAL_USART_GET_FLAG(husart, Flag) ? SET : RESET) == Status)
    {
        /* RTOS-04/05: yield the CPU so that a task polling the peripheral does
           not starve the other tasks (empty macro in a bare-metal build) */
        HAL_RTOS_Yield();

        /* Check for the Timeout */
        if (Timeout != HAL_MAX_DELAY)
        {
            if ((Timeout == 0U) || ((HAL_GetTick() - Tickstart) >= Timeout))
            {
                /* Disable the USART Transmit Complete Interrupt */
                CLEAR_BIT(husart->Instance->CR1, USART_CR1_TXEIE);

                /* Disable the USART RXNE Interrupt */
                CLEAR_BIT(husart->Instance->CR1, USART_CR1_RXNEIE);

                /* Disable the USART Parity Error Interrupt */
                CLEAR_BIT(husart->Instance->CR1, USART_CR1_PEIE);

                /* Disable the USART Error Interrupt: (frame error, noise error, overrun error) */
                CLEAR_BIT(husart->Instance->CR3, USART_CR3_EIE);

                /* NOTE: this helper performs the register access only. The handle
                 * state, the error code and the release of the lock are owned by
                 * the caller, so that the timeout bookkeeping stays in one place. */

                return HAL_TIMEOUT;
            }
        }
    }
    return HAL_OK;
}

#ifdef HAL_DMA_MODULE_ENABLED
/**
  * @brief  End ongoing Tx transfer on USART peripheral (following error
  *         detection or Transmit completion).
  * @param  husart: USART handle
  * @retval None
  */
static void USART_EndTxTransfer(USART_HandleTypeDef *husart)
{
    /* At end of Tx process, restore husart->State to Ready */
    husart->State = HAL_USART_STATE_READY;

    /* Disable TXEIE and TCIE interrupts */
    CLEAR_BIT(husart->Instance->CR1, (USART_CR1_TXEIE | USART_CR1_TCIE));
}
#endif /* HAL_DMA_MODULE_ENABLED */

/**
  * @brief  End ongoing Rx transfer on USART peripheral (following error
  *         detection or Reception completion).
  * @param  husart: USART handle
  * @retval None
  */
static void USART_EndRxTransfer(USART_HandleTypeDef *husart)
{
    /* At end of Rx process, restore husart->State to Ready */
    husart->State = HAL_USART_STATE_READY;

    /* Disable RXNE, PE and ERR interrupts */
    CLEAR_BIT(husart->Instance->CR1, (USART_CR1_RXNEIE | USART_CR1_PEIE));
    CLEAR_BIT(husart->Instance->CR3, USART_CR3_EIE);
}

#ifdef HAL_DMA_MODULE_ENABLED
/**
  * @brief  DMA Tx complete callback.
  * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains
  *         the configuration information for the specified DMA channel.
  * @retval None
  */
static void USART_DMATransmitCplt(DMA_HandleTypeDef *hdma)
{
    USART_HandleTypeDef *husart = (USART_HandleTypeDef *)(hdma->Parent);

    husart->TxXferCount = 0U;
    USART_EndTxTransfer(husart);
    HAL_USART_TxCpltCallback(husart);
}

/**
  * @brief  DMA Tx half complete callback.
  * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains
  *         the configuration information for the specified DMA channel.
  * @retval None
  */
static void USART_DMATxHalfCplt(DMA_HandleTypeDef *hdma)
{
    USART_HandleTypeDef *husart = (USART_HandleTypeDef *)(hdma->Parent);

    HAL_USART_TxHalfCpltCallback(husart);
}

/**
  * @brief  DMA Rx complete callback.
  * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains
  *         the configuration information for the specified DMA channel.
  * @retval None
  */
static void USART_DMAReceiveCplt(DMA_HandleTypeDef *hdma)
{
    USART_HandleTypeDef *husart = (USART_HandleTypeDef *)(hdma->Parent);

    husart->RxXferCount = 0U;
    USART_EndRxTransfer(husart);
    HAL_USART_RxCpltCallback(husart);
}

/**
  * @brief  DMA Rx half complete callback.
  * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains
  *         the configuration information for the specified DMA channel.
  * @retval None
  */
static void USART_DMARxHalfCplt(DMA_HandleTypeDef *hdma)
{
    USART_HandleTypeDef *husart = (USART_HandleTypeDef *)(hdma->Parent);

    HAL_USART_RxHalfCpltCallback(husart);
}

/**
  * @brief  DMA Tx and Rx full-duplex complete callback.
  * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains
  *         the configuration information for the specified DMA channel.
  * @retval None
  */
static void USART_DMATransmitReceiveCplt(DMA_HandleTypeDef *hdma)
{
    USART_HandleTypeDef *husart = (USART_HandleTypeDef *)(hdma->Parent);

    husart->RxXferCount = 0U;
    husart->TxXferCount = 0U;
    USART_EndRxTransfer(husart);
    USART_EndTxTransfer(husart);
    HAL_USART_TxRxCpltCallback(husart);
}

/**
  * @brief  DMA error callback.
  * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains
  *         the configuration information for the specified DMA channel.
  * @retval None
  */
static void USART_DMAError(DMA_HandleTypeDef *hdma)
{
    USART_HandleTypeDef *husart = (USART_HandleTypeDef *)(hdma->Parent);

    husart->RxXferCount = 0U;
    husart->TxXferCount = 0U;
    husart->State = HAL_USART_STATE_READY;
    husart->ErrorCode |= HAL_USART_ERROR_DMA;
    HAL_USART_ErrorCallback(husart);
}

/**
  * @brief  DMA abort on error callback.
  * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains
  *         the configuration information for the specified DMA channel.
  * @retval None
  */
static void USART_DMAAbortOnError(DMA_HandleTypeDef *hdma)
{
    USART_HandleTypeDef *husart = (USART_HandleTypeDef *)(hdma->Parent);

    husart->RxXferCount = 0U;
    husart->TxXferCount = 0U;
    husart->State = HAL_USART_STATE_READY;
}

/**
  * @brief  Close the DMA requests of the instance and abort its channels.
  * @note   Tier 3 helper shared by HAL_USART_DeInit() and HAL_USART_DMAStop():
  *         it performs no validation, takes no lock and applies no state gate,
  *         the caller owns the handle check and the lock. The request of a
  *         channel is closed before the channel is aborted, so that the
  *         peripheral cannot re-arm a channel that is being stopped.
  * @param  husart: USART handle
  * @retval None
  */
static void USART_AbortLinkedDmaChannels(USART_HandleTypeDef *husart)
{
    if (husart->hdmatx != NULL_PTR)
    {
        CLEAR_BIT(husart->Instance->CR3, USART_CR3_DMAT);
        (void)HAL_DMA_Abort(husart->hdmatx);
    }

    if (husart->hdmarx != NULL_PTR)
    {
        CLEAR_BIT(husart->Instance->CR3, USART_CR3_DMAR);
        (void)HAL_DMA_Abort(husart->hdmarx);
    }
}
#endif /* HAL_DMA_MODULE_ENABLED */

/**
  * @brief  Configure the USART peripheral
  * @param  husart: USART handle
  * @retval HAL status
  */
static HAL_StatusTypeDef USART_SetConfig(USART_HandleTypeDef *husart)
{
    uint32 tmpreg = 0x0U;
    USART_ClockSourceTypeDef clocksource = USART_CLOCKSOURCE_UNDEFINED;
    uint32 apbclock = 0U;
    uint32 divider = 0U;

    /* Check the parameters */
    assert_param(IS_USART_POLARITY(husart->Init.CLKPolarity));
    assert_param(IS_USART_PHASE(husart->Init.CLKPhase));
    assert_param(IS_USART_LASTBIT(husart->Init.CLKLastBit));
    assert_param(IS_USART_BAUDRATE(husart->Init.BaudRate));
    assert_param(IS_USART_WORD_LENGTH(husart->Init.WordLength));
    assert_param(IS_USART_STOPBITS(husart->Init.StopBits));
    assert_param(IS_USART_PARITY(husart->Init.Parity));
    assert_param(IS_USART_MODE(husart->Init.Mode));
    assert_param(IS_USART_OVERSAMPLING(husart->Init.OverSampling));
    assert_param(IS_USART_HARDWARE_FLOW_CONTROL(husart->Init.HardwareFlowControl));

    /*-------------------------- USART CR1 Configuration -----------------------*/
    /* Clear M, PCE, PS, TE, RE and OVER8 bits and configure the USART Word
       Length, Parity, Mode and OverSampling:
       - set the M bits according to husart->Init.WordLength value
       - set PCE and PS bits according to husart->Init.Parity value
       - set TE and RE bits according to husart->Init.Mode value
       - set OVER8 bit according to husart->Init.OverSampling value */
    tmpreg = (uint32)husart->Init.WordLength | husart->Init.Parity | husart->Init.Mode | husart->Init.OverSampling;
    MODIFY_REG(husart->Instance->CR1, USART_CR1_FIELDS, tmpreg);

    /*---------------------------- USART CR2 Configuration ---------------------*/
    /* Clear and configure the USART Clock, CPOL, CPHA, LBCL and STOP bits:
       - set CPOL bit according to husart->Init.CLKPolarity value
       - set CPHA bit according to husart->Init.CLKPhase value
       - set LBCL bit according to husart->Init.CLKLastBit value
       - set STOP[13:12] bits according to husart->Init.StopBits value */
    tmpreg = (uint32)husart->Init.CLKPolarity | husart->Init.CLKPhase | husart->Init.CLKLastBit | husart->Init.StopBits;
    MODIFY_REG(husart->Instance->CR2, USART_CR2_FIELDS, tmpreg);

    /*-------------------------- USART CR3 Configuration -----------------------*/
    /* Clear and configure the USART Hardware Flow Control:
       - set RTSE and CTSE bits according to husart->Init.HardwareFlowControl value */
    tmpreg = (uint32)husart->Init.HardwareFlowControl;
    MODIFY_REG(husart->Instance->CR3, USART_CR3_FIELDS, tmpreg);

    /*-------------------------- USART BRR Configuration -----------------------*/
    /* Get the USART Bus Clock: USART0..USART3 are on APBBus0,
       USART4..USART7 are on APBBus1 */
    if ((husart->Instance == USART0) || (husart->Instance == USART1) ||
        (husart->Instance == USART2) || (husart->Instance == USART3))
    {
        clocksource = USART_CLOCKSOURCE_APB0;
    }
    else if ((husart->Instance == USART4) || (husart->Instance == USART5) ||
             (husart->Instance == USART6) || (husart->Instance == USART7))
    {
        clocksource = USART_CLOCKSOURCE_APB1;
    }
    else
    {
        clocksource = USART_CLOCKSOURCE_UNDEFINED;
    }

    switch (clocksource)
    {
        case USART_CLOCKSOURCE_APB0:
        apbclock = HAL_SMU_GetPCLK0Freq();
        break;
        case USART_CLOCKSOURCE_APB1:
        apbclock = HAL_SMU_GetPCLK1Freq();
        break;
        case USART_CLOCKSOURCE_UNDEFINED:
        default:
        return HAL_ERROR;
    }

    /* Compute the Baud Rate divider. The BRR register holds a 16 bit divider,
       so the computed value is validated against that domain at run time
       (independently of the assertions): an out of range divider is reported
       with HAL_USART_ERROR_INVALID_PARAM instead of being silently truncated
       by the 16 bit store, which would silently program a wrong baud rate. */
    divider = apbclock / husart->Init.BaudRate;

    if (IS_USART_BRR_DIVIDER(divider) == 0U)
    {
        husart->ErrorCode |= HAL_USART_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Fill the USART BRR register with the computed value */
    husart->Instance->BRR = (uint16)divider;

    return HAL_OK;
}

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

#endif /* HAL_USART_MODULE_ENABLED */

/************************ (C) COPYRIGHT ANSILIC *****END OF FILE****/

