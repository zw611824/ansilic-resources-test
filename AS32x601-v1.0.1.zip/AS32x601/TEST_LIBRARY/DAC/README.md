# DAC 应用与测试参考

供 skill 按用户需求定位 AS32x601 HAL DAC 示例，共 15 个独立用例。

HAL 依据：[头文件](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_dac.h)、[实现](../../HAL_LIBRARY/peripherals/src/as32x601_hal_dac.c)。按所选案例核对当前驱动，不以接口索引代替实现依据。


## 实例与可选引脚

本目录同时包含 DAC 与比较器案例。下表列出 AS32x601 LQFP144 的模拟引脚和比较器复用信号。DAC 输出路径需结合模拟模块配置和板级电路核对，不能把比较器输入当成 DAC 输出。

| 信号 | 引脚 | LQFP144 脚号 | 功能 | HAL 配置 |
| --- | --- | --- | --- | --- |
| CMP0_N | PE3 | 124 | 模拟功能 | 模拟功能无需配置数字 AF |
| CMP0_P | PE2 | 123 | 模拟功能 | 模拟功能无需配置数字 AF |
| CMP1_N | PE6 | 128 | 模拟功能 | 模拟功能无需配置数字 AF |
| CMP1_P | PE5 | 127 | 模拟功能 | 模拟功能无需配置数字 AF |
| DAC0_OUT | PE4 | 120 | 模拟功能 | 模拟功能无需配置数字 AF |
| DAC1_OUT | PC13 | 125 | 模拟功能 | 模拟功能无需配置数字 AF |
| CMP0_O | PF11 | 104 | 功能1 | GPIO_AF_CMP0_M1（0x02） |
| CMP0_O | PG10 | 18 | 功能3 | GPIO_AF_CMP0_M3（0x04） |
| CMP1_O | PF12 | 102 | 功能1 | GPIO_AF_CMP1_M1（0x02） |
| CMP1_O | PG11 | 17 | 功能3 | GPIO_AF_CMP1_M3（0x04） |

## 生成前需确认的参数

已有工程、板级资料或用户已明确的值直接复用。仅对影响本次实现的缺失选择使用参数卡询问并等待答复；案例配置不能代替实际接线或应用参数。

| 参数 | 需要核对或确认的内容 |
|---|---|
| 输出配置 | DAC 实例、通道、模拟输出引脚与参考电压 |
| 输出要求 | 电压范围、负载、波形与更新速率 |
| 触发与数据 | 软件/定时触发、DMA 或轮询，按需确认缓冲与启动电平 |

## 按需求选择

按目标行为选择，再核对完整源码；组合需求可阅读多个用例，不直接合并多个 main。

| 用户需求 / 检索关键词 | 推荐用例 | 选择条件 / 需要补充的逻辑 |
|---|---|---|
| DAC 配置结构默认值 | [001](DAC_IT_DRV_001.c) | 配置起点；实际输出还需要初始化、复位释放与启动 |
| DAC 初始化；参考源、输出模式、分频 | [002](DAC_IT_DRV_002.c) | HAL_DAC_Init 不负责释放 RESETN |
| 启用和关闭 DAC 数据通路 | [003](DAC_IT_DRV_003.c) | Start 成功不代表模拟输出已脱离复位 |
| 设置模拟输出码；扫值；读回数据 | [004](DAC_IT_DRV_004.c) | 8 位码 0x00～0xFF；电压需外部仪表测量 |
| 比较器配置结构默认值 | [005](DAC_IT_DRV_005.c) | 比较器启用和输入配置参考 006 / 007 |
| 比较器配置；输入选择与迟滞 | [006](DAC_IT_DRV_006.c) | 覆盖 EN、MD、HYS，实际输入电压另行提供 |
| 比较器启用和关闭 | [007](DAC_IT_DRV_007.c) | 与 DAC 数据通路启停分开核对 |
| 读取比较器输出；模拟输入比较 | [008](DAC_IT_DRV_008.c) | CMP0_P=PE2、CMP0_N=PE3；悬空输入不能断言比较值 |
| DAC 反初始化 | [009](DAC_IT_DRV_009.c) | 生命周期及寄存器结果检查 |
| 模块复位；RESETN 释放；完整启动顺序 | [010](DAC_IT_DRV_010.c) | 模拟输出必须显式释放复位 |
| MSP 生命周期和调用次数 | [011](DAC_IT_DRV_011.c) | 保留所需时钟与模拟引脚配置 |
| 非法参数、实例与空指针保护 | [012](DAC_IT_DRV_012.c) | 综合边界测试，不把非法配置用于应用 |
| 状态门控；BUSY、ERROR、TIMEOUT | [013](DAC_IT_DRV_013.c) | Stop 有特殊停止语义，不能泛化所有接口拒绝 BUSY |
| DAC0 / DAC1 独立性与时钟门控 | [014](DAC_IT_DRV_014.c) | DAC0=PE4、DAC1=PC13；核对每个实例 MSP |
| 校验宏、导出宏与常量 | [015](DAC_IT_DRV_015.c) | 接口结构自检，不代表模拟精度测试 |

## 实现要点与案例配置

基础输出可组合参考 002（初始化）、010（复位顺序）、003（启动）、004（写码）。HAL_DAC_Init 不释放 CTRL.RESETN，HAL_DAC_Start / SetValue 在复位保持时仍可能成功写寄存器；必须按 010 的顺序显式释放复位，再用输出脚实测判断。

DAC0 输出 PE4、DAC1 输出 PC13；DAC0 比较器输入 CMP0_P=PE2 / CMP0_N=PE3。保留 MSP 的实例时钟与模拟引脚设置。004 扫描 8 位码 0x00～0xFF，源码使用 VOUT=code/256*VREF 作为理论预期；参考电压取实际板卡和选择，不能仅凭日志保证电压、满量程或精度。

006 配置比较器输入、迟滞与使能，007 启停比较器，008 检查结果与 CMPO 位一致并观察模拟输入变化。未接外部源时读数不确定；寄存器一致不代表模拟比较阈值已验证。013 对状态接口有特例，例如 Stop 的行为不能泛化为所有 BUSY 操作都被拒绝。

验证返回值、寄存器及失败计数，并用万用表/示波器核对模拟电压或波形；比较器需施加已知电压。DMA 波形播放、定时器触发、任意频率信号和校准精度没有独立完整应用模板。

`HAL_DAC_ResetCmd(hdac, 0U)` 保持复位，`HAL_DAC_ResetCmd(hdac, 1U)` 释放复位，参数含义跟随 RESETN 位。结合 010 及所选用例的 MSP 核对复位顺序和稳定等待。

013 中 `HAL_DAC_Stop()` 允许已初始化的 BUSY 等状态请求停止，但锁已占用时仍可能返回 HAL_BUSY；允许 BUSY 状态停止不等于绕过资源锁，应检查返回值。

## 验证方法与适用边界

每个用例是独立测试程序。选定后核对实例、引脚或地址、时钟、配置、主循环、中断与回调，按目标板调整测试初值、日志和故障制造逻辑。综合接口自检只提供对应行为参考，不代表完整产品需求已覆盖。

本次为源码静态整理，未重新编译或上板；源码已有记录、预期结果与本次验证状态分别判断。

## 按接口与辅助宏检索

索引来自去除注释和字符串后的源码调用或定义，包含本模块 HAL、锁助手、寄存器及参数校验宏。MSP、IRQ、回调可能是定义或转发入口，需结合完整实现阅读；出现不代表所有分支都已验证。

| 接口 / 宏 | 参考用例 |
|---|---|
| `HAL_DAC_CMPStructInit` | [001](DAC_IT_DRV_001.c)、[002](DAC_IT_DRV_002.c)、[003](DAC_IT_DRV_003.c)、[004](DAC_IT_DRV_004.c)、[005](DAC_IT_DRV_005.c)、[006](DAC_IT_DRV_006.c)、[007](DAC_IT_DRV_007.c)、[008](DAC_IT_DRV_008.c)、[009](DAC_IT_DRV_009.c)、[010](DAC_IT_DRV_010.c)、[011](DAC_IT_DRV_011.c)、[012](DAC_IT_DRV_012.c)、[013](DAC_IT_DRV_013.c)、[014](DAC_IT_DRV_014.c)、[015](DAC_IT_DRV_015.c) |
| `HAL_DAC_ComparatorCmd` | [006](DAC_IT_DRV_006.c)、[007](DAC_IT_DRV_007.c)、[012](DAC_IT_DRV_012.c)、[013](DAC_IT_DRV_013.c) |
| `HAL_DAC_ConfigComparator` | [001](DAC_IT_DRV_001.c)、[002](DAC_IT_DRV_002.c)、[003](DAC_IT_DRV_003.c)、[004](DAC_IT_DRV_004.c)、[005](DAC_IT_DRV_005.c)、[006](DAC_IT_DRV_006.c)、[007](DAC_IT_DRV_007.c)、[008](DAC_IT_DRV_008.c)、[009](DAC_IT_DRV_009.c)、[010](DAC_IT_DRV_010.c)、[011](DAC_IT_DRV_011.c)、[012](DAC_IT_DRV_012.c)、[013](DAC_IT_DRV_013.c)、[014](DAC_IT_DRV_014.c)、[015](DAC_IT_DRV_015.c) |
| `HAL_DAC_DeInit` | [003](DAC_IT_DRV_003.c)、[009](DAC_IT_DRV_009.c)、[011](DAC_IT_DRV_011.c)、[012](DAC_IT_DRV_012.c)、[013](DAC_IT_DRV_013.c)、[014](DAC_IT_DRV_014.c) |
| `HAL_DAC_GetComparatorResult` | [005](DAC_IT_DRV_005.c)、[006](DAC_IT_DRV_006.c)、[008](DAC_IT_DRV_008.c)、[012](DAC_IT_DRV_012.c) |
| `HAL_DAC_GetError` | [001](DAC_IT_DRV_001.c)、[002](DAC_IT_DRV_002.c)、[003](DAC_IT_DRV_003.c)、[004](DAC_IT_DRV_004.c)、[005](DAC_IT_DRV_005.c)、[006](DAC_IT_DRV_006.c)、[007](DAC_IT_DRV_007.c)、[009](DAC_IT_DRV_009.c)、[010](DAC_IT_DRV_010.c)、[011](DAC_IT_DRV_011.c)、[012](DAC_IT_DRV_012.c)、[013](DAC_IT_DRV_013.c)、[015](DAC_IT_DRV_015.c) |
| `HAL_DAC_GetState` | [001](DAC_IT_DRV_001.c)、[002](DAC_IT_DRV_002.c)、[003](DAC_IT_DRV_003.c)、[004](DAC_IT_DRV_004.c)、[005](DAC_IT_DRV_005.c)、[006](DAC_IT_DRV_006.c)、[007](DAC_IT_DRV_007.c)、[009](DAC_IT_DRV_009.c)、[010](DAC_IT_DRV_010.c)、[011](DAC_IT_DRV_011.c)、[012](DAC_IT_DRV_012.c)、[013](DAC_IT_DRV_013.c)、[014](DAC_IT_DRV_014.c)、[015](DAC_IT_DRV_015.c) |
| `HAL_DAC_GetValue` | [004](DAC_IT_DRV_004.c)、[012](DAC_IT_DRV_012.c)、[014](DAC_IT_DRV_014.c) |
| `HAL_DAC_Init` | [001](DAC_IT_DRV_001.c)、[002](DAC_IT_DRV_002.c)、[003](DAC_IT_DRV_003.c)、[004](DAC_IT_DRV_004.c)、[005](DAC_IT_DRV_005.c)、[006](DAC_IT_DRV_006.c)、[007](DAC_IT_DRV_007.c)、[008](DAC_IT_DRV_008.c)、[009](DAC_IT_DRV_009.c)、[010](DAC_IT_DRV_010.c)、[011](DAC_IT_DRV_011.c)、[012](DAC_IT_DRV_012.c)、[013](DAC_IT_DRV_013.c)、[014](DAC_IT_DRV_014.c)、[015](DAC_IT_DRV_015.c) |
| `HAL_DAC_MspDeInit` | [001](DAC_IT_DRV_001.c)、[002](DAC_IT_DRV_002.c)、[003](DAC_IT_DRV_003.c)、[004](DAC_IT_DRV_004.c)、[005](DAC_IT_DRV_005.c)、[006](DAC_IT_DRV_006.c)、[007](DAC_IT_DRV_007.c)、[008](DAC_IT_DRV_008.c)、[009](DAC_IT_DRV_009.c)、[010](DAC_IT_DRV_010.c)、[011](DAC_IT_DRV_011.c)、[012](DAC_IT_DRV_012.c)、[013](DAC_IT_DRV_013.c)、[014](DAC_IT_DRV_014.c)、[015](DAC_IT_DRV_015.c) |
| `HAL_DAC_MspInit` | [001](DAC_IT_DRV_001.c)、[002](DAC_IT_DRV_002.c)、[003](DAC_IT_DRV_003.c)、[004](DAC_IT_DRV_004.c)、[005](DAC_IT_DRV_005.c)、[006](DAC_IT_DRV_006.c)、[007](DAC_IT_DRV_007.c)、[008](DAC_IT_DRV_008.c)、[009](DAC_IT_DRV_009.c)、[010](DAC_IT_DRV_010.c)、[011](DAC_IT_DRV_011.c)、[012](DAC_IT_DRV_012.c)、[013](DAC_IT_DRV_013.c)、[014](DAC_IT_DRV_014.c)、[015](DAC_IT_DRV_015.c) |
| `HAL_DAC_ResetCmd` | [001](DAC_IT_DRV_001.c)、[002](DAC_IT_DRV_002.c)、[003](DAC_IT_DRV_003.c)、[004](DAC_IT_DRV_004.c)、[005](DAC_IT_DRV_005.c)、[006](DAC_IT_DRV_006.c)、[007](DAC_IT_DRV_007.c)、[008](DAC_IT_DRV_008.c)、[009](DAC_IT_DRV_009.c)、[010](DAC_IT_DRV_010.c)、[011](DAC_IT_DRV_011.c)、[012](DAC_IT_DRV_012.c)、[013](DAC_IT_DRV_013.c)、[014](DAC_IT_DRV_014.c)、[015](DAC_IT_DRV_015.c) |
| `HAL_DAC_SetValue` | [004](DAC_IT_DRV_004.c)、[008](DAC_IT_DRV_008.c)、[009](DAC_IT_DRV_009.c)、[010](DAC_IT_DRV_010.c)、[012](DAC_IT_DRV_012.c)、[013](DAC_IT_DRV_013.c)、[014](DAC_IT_DRV_014.c)、[015](DAC_IT_DRV_015.c) |
| `HAL_DAC_Start` | [003](DAC_IT_DRV_003.c)、[004](DAC_IT_DRV_004.c)、[008](DAC_IT_DRV_008.c)、[009](DAC_IT_DRV_009.c)、[010](DAC_IT_DRV_010.c)、[012](DAC_IT_DRV_012.c)、[013](DAC_IT_DRV_013.c) |
| `HAL_DAC_Stop` | [003](DAC_IT_DRV_003.c)、[012](DAC_IT_DRV_012.c)、[013](DAC_IT_DRV_013.c) |
| `HAL_DAC_StructInit` | [001](DAC_IT_DRV_001.c)、[002](DAC_IT_DRV_002.c)、[003](DAC_IT_DRV_003.c)、[004](DAC_IT_DRV_004.c)、[005](DAC_IT_DRV_005.c)、[006](DAC_IT_DRV_006.c)、[007](DAC_IT_DRV_007.c)、[008](DAC_IT_DRV_008.c)、[009](DAC_IT_DRV_009.c)、[010](DAC_IT_DRV_010.c)、[011](DAC_IT_DRV_011.c)、[012](DAC_IT_DRV_012.c)、[013](DAC_IT_DRV_013.c)、[014](DAC_IT_DRV_014.c)、[015](DAC_IT_DRV_015.c) |
| `IS_DAC_ALL_INSTANCE` | [015](DAC_IT_DRV_015.c) |
| `IS_DAC_CLK_DIV` | [015](DAC_IT_DRV_015.c) |
| `IS_DAC_CMP_EN` | [015](DAC_IT_DRV_015.c) |
| `IS_DAC_CMP_HYS` | [015](DAC_IT_DRV_015.c) |
| `IS_DAC_CMP_MD` | [015](DAC_IT_DRV_015.c) |
| `IS_DAC_DATA` | [015](DAC_IT_DRV_015.c) |
| `IS_DAC_EN` | [015](DAC_IT_DRV_015.c) |
| `IS_DAC_NEWSTATE` | [015](DAC_IT_DRV_015.c) |
| `IS_DAC_OUTPUT_BUFFER_STATE` | [015](DAC_IT_DRV_015.c) |
| `IS_DAC_VREF_MD` | [015](DAC_IT_DRV_015.c) |
| `__HAL_DAC_DISABLE` | [015](DAC_IT_DRV_015.c) |
| `__HAL_DAC_ENABLE` | [015](DAC_IT_DRV_015.c) |
| `__HAL_DAC_RESET_ASSERT` | [015](DAC_IT_DRV_015.c) |
| `__HAL_DAC_RESET_HANDLE_STATE` | [011](DAC_IT_DRV_011.c)、[015](DAC_IT_DRV_015.c) |
| `__HAL_DAC_RESET_RELEASE` | [015](DAC_IT_DRV_015.c) |

