# AS32x601 调试参考

## 芯片与工程参数

- 仅支持 AS32x601 的 EIDE `RISCV_GCC` 工程。
- Flash：基址 `0x01000000`，大小 `0x200000`（2 MiB）。
- RAM：基址 `0x20000000`，大小 `0x80000`（512 KiB）。
- OpenOCD 目标配置：`target/as32x601_eflash.cfg`。
- `$PROJ` 表示当前 EIDE 工程根目录；`$ANSILIC` 表示 Ansilic Studio 的安装资源根目录。二者均为语义变量，不代表个人绝对路径。

## GPIOG LED 示例（板级配置）

- GPIOG 基址：`0x42006000`；OCR 偏移：`0x24`；GPIOG OCR 地址：`0x42006024`。
- 示例板 LED1：PG15，低电平点亮，掩码 `0x8000`；接线和极性须按实际板卡核实，不能当作芯片通用配置。
- 修改 LED 前先读取 OCR，以读-改-写方式保留无关位；例如旧值 `0x0000c400` 时，LED1 点亮后的新值为 `0x00004400`。

## 常见错误与诊断

| 现象 | 含义 | 诊断步骤 |
| --- | --- | --- |
| OpenOCD 无法启动或找不到配置 | OpenOCD 路径、`target/as32x601_eflash.cfg` 或其搜索目录不正确。 | 检查 EIDE 工程上下文、OpenOCD 输出和目标配置。 |
| OpenOCD 连接超时或目标未识别 | 探针、供电、JTAG 连线或目标配置有问题。 | 检查开发板供电、探针连接和 OpenOCD 输出中的首个错误。 |
| GDB server 立即退出或端口被占用 | 已有调试服务器/会话占用端口，或服务器未能连接目标。 | 检查当前 Cortex-Debug 会话和 gdb-server 输出；不要启动第二个 GDB。 |
| GDB 无法连接或会话未就绪 | Cortex-Debug 会话尚未建立，或 GDB 与服务器的端口不匹配。 | 检查当前会话状态、Debug Console 和 gdb-server 输出。 |

正常操作只使用受控 AS32 工具；不得提供任意 shell、GDB 命令或可执行文件调用入口。这些信息仅用于解释诊断结果。
