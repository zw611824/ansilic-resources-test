/**
 * @file    SPI_IT_DRV_017.c
 * @brief   HAL SPI integration test case 017 (transport layer coverage).
 *
 * Extension case of this suite: it exercises every data transport entry point
 * of the HAL SPI driver on one instance, which the ported reference cases do
 * not do (they cover the register level interface and one mode each). Only HAL
 * library APIs are used.
 *
 * Tested functionality:
 *   HAL_SPI_StructInit() / HAL_SPI_Init() / HAL_SPI_ResetFIFO()
 *   HAL_SPI_NSSConfig()            (asserts SPI_Slave0 around the transfers)
 *   HAL_SPI_Transmit()             (blocking)
 *   HAL_SPI_Receive()              (blocking, master dummy frames)
 *   HAL_SPI_TransmitReceive()      (blocking, full duplex)
 *   HAL_SPI_Transmit_IT()          + HAL_SPI_TxCpltCallback()
 *   HAL_SPI_Receive_IT()           + HAL_SPI_RxCpltCallback()
 *   HAL_SPI_TransmitReceive_IT()   + HAL_SPI_TxRxCpltCallback()
 *   HAL_SPI_Transmit_DMA()         + HAL_SPI_TxCpltCallback()
 *   HAL_SPI_Receive_DMA()          + HAL_SPI_RxCpltCallback()
 *   HAL_SPI_TransmitReceive_DMA()  + HAL_SPI_TxRxCpltCallback()
 *   HAL_SPI_TxHalfCpltCallback() / HAL_SPI_RxHalfCpltCallback()
 *   HAL_DMA_StructInit() / HAL_DMA_Init() / HAL_DMA_ConfigPeriphIF()
 *   HAL_SPI_IRQHandler() / HAL_DMA_IRQHandler()
 *   HAL_PLIC_Init()                (SPI3 and DMA1 interrupt lines)
 *   HAL_SPI_GetState() / HAL_SPI_GetError() / HAL_DMA_GetState()
 *
 * Test procedure:
 *   Nine phases are run one after the other on SPI3 (master, 8 bit, Motorola
 *   mode 0, divider /512):
 *     1 .. 3   the three blocking transports;
 *     4 .. 6   the same three transports in interrupt mode;
 *     7 .. 9   the same three transports in DMA mode.
 *   Every phase checks the returned status, the handle state, the error code,
 *   the callback counters and - where the peer allows it - the received data.
 *
 * Expected behaviour:
 *   - every transport entry point returns HAL_OK and leaves the SPI handle in
 *     READY with the error code NONE;
 *   - the DMA channels return to READY after every DMA phase;
 *   - the completion callbacks fire exactly once per phase;
 *   - every check prints [PASS] and "summary : failures = 0" when the required
 *     peer is present.
 *
 * Note:
 *   - External stimulus is required for the data comparison of the receive and
 *     full duplex phases: an SPI slave (or a MOSI to MISO loop) must return the
 *     frames. The blocking transmit phase and the state / status checks of
 *     every phase run without a peer, because a master generates the clock
 *     itself (the receive phases transmit dummy frames to do so).
 *   - The DMA channel widths are fixed by the driver: the peripheral side of
 *     every channel moves one 32 bit FIFO word, the memory side moves one
 *     frame (byte for an 8 bit frame). Any other combination is rejected with
 *     HAL_SPI_ERROR_INVALID_PARAM.
 *   - A master transmit always receives the frames it clocks out, so the
 *     transmit-only DMA phase has to keep the receive FIFO empty by itself
 *     until the bus goes idle; otherwise the unread frames overflow the
 *     32 entry receive FIFO and the phase ends in an RXO error.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console: USART0 on GPIOD pin 8 (TX) / pin 9 (RX), 115200 8N1 */
#define TEST_BAUDRATE                   (115200U)

/* Device under test: SPI3
 *   CS0  = PC10   SCK  = PD3   MOSI = PD1   MISO = PD2
 */
#define TEST_SPI                        SPI3
#define TEST_SPI_IRQn                   SPI3_IRQn
#define TEST_DMA                        DMA1
#define TEST_DMA_IRQn                   DMA1_IRQn
#define TEST_DMA_RX_INSTANCE            DMA1_Channel12
#define TEST_DMA_TX_INSTANCE            DMA1_Channel13
#define TEST_CS_PORT                    GPIOC
#define TEST_CS_PIN                     GPIO_PIN_10
#define TEST_CS_SOURCE                  GPIO_PinSource10
#define TEST_SCK_PORT                   GPIOD
#define TEST_SCK_PIN                    GPIO_PIN_3
#define TEST_SCK_SOURCE                 GPIO_PinSource3
#define TEST_MOSI_PORT                  GPIOD
#define TEST_MOSI_PIN                   GPIO_PIN_1
#define TEST_MOSI_SOURCE                GPIO_PinSource1
#define TEST_MISO_PORT                  GPIOD
#define TEST_MISO_PIN                   GPIO_PIN_2
#define TEST_MISO_SOURCE                GPIO_PinSource2
#define TEST_PIN_AF                     GPIO_AF_SPI3

/* Frame geometry, timeouts and the poll bound of the wait loops */
#define FRAME_COUNT                     (64U)
#define TRANSFER_TIMEOUT_MS             (2000U)
#define WAIT_POLLS                      (20000000U)
#define PHASE_GAP_MS                    (500U)

/* Private variables ---------------------------------------------------------*/
static SPI_HandleTypeDef hspi_dev;              /*!< device under test      */
static HAL_SMU_HandleTypeDef hsmu_clk;          /*!< SMU handle (clock tree) */
static DMA_HandleTypeDef hdma_rx;               /*!< receive channel        */
static DMA_HandleTypeDef hdma_tx;               /*!< transmit channel       */
static uint8 tx_data[FRAME_COUNT];              /*!< transmit pattern        */
static uint8 rx_data[FRAME_COUNT];              /*!< received frames         */
static volatile uint32 check_failures = 0U;     /*!< failed check counter    */
static volatile uint32 tx_cplt = 0U;            /*!< transmit completions    */
static volatile uint32 rx_cplt = 0U;            /*!< receive completions     */
static volatile uint32 txrx_cplt = 0U;          /*!< full duplex completions */
static volatile uint32 tx_half = 0U;            /*!< transmit half complete  */
static volatile uint32 rx_half = 0U;            /*!< receive half complete   */
static volatile uint32 error_events = 0U;       /*!< error callbacks         */
static volatile uint32 phase_done = 0U;         /*!< phase completion flag   */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void DMA_Config(void);
static void SPI_PLIC_Init(void);
static void BufferInit(void);
static void ClearCounters(void);
static void WaitPhase(uint32 drain_rx);
static void Check(const char *name, uint32 condition);
static void CheckData(const char *name);
static void Summary(void);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    SPI_InitTypeDef spi_init;
    HAL_StatusTypeDef status;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock tree */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART (USART0 on GPIOD pin 8 / pin 9) */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== SPI_IT_DRV_017 : transport layer coverage (SPI3) ===\r\n");

    BufferInit();

    /* Initialize the device under test */
    __HAL_CLEAR_STRUCT(&hspi_dev);
    HAL_SPI_StructInit(&spi_init);
    spi_init.SPI_CLKDiv       = SPI_CLKDiv512;
    spi_init.SPI_Mode         = SPI_Mode_Master;
    spi_init.SPI_FrameSize    = SPI_FrameSize_8b;
    spi_init.SPI_MotorolaMode = SPI_Motorola_Mode0;
    spi_init.SPI_TransMode    = SPI_TransNor;

    hspi_dev.Instance = TEST_SPI;
    hspi_dev.Init     = spi_init;

    status = HAL_SPI_Init(&hspi_dev);
    /* The slave select is not part of the initialization: SSR
     * resets to 0 (no slave selected) and HAL_SPI_Init() does not
     * touch it, so the selection has to be programmed here. */
    HAL_SPI_ResetFIFO(&hspi_dev, SPI_RESETFIFO_TXANDRX);
    HAL_SPI_NSSConfig(&hspi_dev, SPI_Slave0, SPI_ENABLE);
    Check("HAL_SPI_Init returns HAL_OK", (uint32)((status == HAL_OK) ? 1U : 0U));

    /* DMA channels and interrupt routing */
    DMA_Config();
    SPI_PLIC_Init();
    hspi_dev.hdmatx = &hdma_tx;
    hspi_dev.hdmarx = &hdma_rx;

    printf("APBBus1 clock : %u Hz, SPI clock /512 = %u Hz\r\n",
           PRINT_U32(HAL_SMU_GetPCLK1Freq()),
           PRINT_U32(HAL_SMU_GetPCLK1Freq() / 512U));

    /* ---------------- phase 1 : blocking transmit ---------------- */
    printf("\r\n-- phase 1 : HAL_SPI_Transmit (blocking) --\r\n");
    ClearCounters();
    status = HAL_SPI_Transmit(&hspi_dev, tx_data, FRAME_COUNT,
                              TRANSFER_TIMEOUT_MS);
    Check("HAL_SPI_Transmit returns HAL_OK", (uint32)((status == HAL_OK) ? 1U : 0U));
    Check("state after the transfer is READY",
          (uint32)((HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_READY) ? 1U : 0U));
    Check("error code after the transfer is NONE",
          (uint32)((HAL_SPI_GetError(&hspi_dev) == HAL_SPI_ERROR_NONE) ? 1U : 0U));
    delay_ms(PHASE_GAP_MS);

    /* ---------------- phase 2 : blocking receive ----------------- */
    printf("\r\n-- phase 2 : HAL_SPI_Receive (blocking, dummy frames) --\r\n");
    ClearCounters();
    status = HAL_SPI_Receive(&hspi_dev, rx_data, FRAME_COUNT,
                             TRANSFER_TIMEOUT_MS);
    Check("HAL_SPI_Receive returns HAL_OK", (uint32)((status == HAL_OK) ? 1U : 0U));
    Check("state after the reception is READY",
          (uint32)((HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_READY) ? 1U : 0U));
    Check("error code after the reception is NONE",
          (uint32)((HAL_SPI_GetError(&hspi_dev) == HAL_SPI_ERROR_NONE) ? 1U : 0U));
    CheckData("phase 2 received pattern");
    delay_ms(PHASE_GAP_MS);

    /* ---------------- phase 3 : blocking full duplex -------------- */
    printf("\r\n-- phase 3 : HAL_SPI_TransmitReceive (blocking) --\r\n");
    ClearCounters();
    BufferInit();
    status = HAL_SPI_TransmitReceive(&hspi_dev, tx_data, rx_data, FRAME_COUNT,
                                     TRANSFER_TIMEOUT_MS);
    Check("HAL_SPI_TransmitReceive returns HAL_OK",
          (uint32)((status == HAL_OK) ? 1U : 0U));
    Check("state after the exchange is READY",
          (uint32)((HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_READY) ? 1U : 0U));
    Check("error code after the exchange is NONE",
          (uint32)((HAL_SPI_GetError(&hspi_dev) == HAL_SPI_ERROR_NONE) ? 1U : 0U));
    CheckData("phase 3 received pattern");
    delay_ms(PHASE_GAP_MS);

    /* ---------------- phase 4 : interrupt transmit ---------------- */
    printf("\r\n-- phase 4 : HAL_SPI_Transmit_IT --\r\n");
    ClearCounters();
    status = HAL_SPI_Transmit_IT(&hspi_dev, tx_data, FRAME_COUNT);
    Check("HAL_SPI_Transmit_IT returns HAL_OK", (uint32)((status == HAL_OK) ? 1U : 0U));
    Check("state is BUSY_TX while the transfer runs",
          (uint32)((HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_BUSY_TX) ? 1U : 0U));
    WaitPhase(0U);
    Check("transmit completion callback fired once",
          (uint32)((tx_cplt == 1U) ? 1U : 0U));
    Check("state is READY after the interrupt transfer",
          (uint32)((HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_READY) ? 1U : 0U));
    Check("no error after the interrupt transfer",
          (uint32)((HAL_SPI_GetError(&hspi_dev) == HAL_SPI_ERROR_NONE) ? 1U : 0U));
    delay_ms(PHASE_GAP_MS);

    /* ---------------- phase 5 : interrupt receive ----------------- */
    printf("\r\n-- phase 5 : HAL_SPI_Receive_IT --\r\n");
    ClearCounters();
    BufferInit();
    status = HAL_SPI_Receive_IT(&hspi_dev, rx_data, FRAME_COUNT);
    Check("HAL_SPI_Receive_IT returns HAL_OK", (uint32)((status == HAL_OK) ? 1U : 0U));
    WaitPhase(0U);
    Check("receive completion callback fired once",
          (uint32)((rx_cplt == 1U) ? 1U : 0U));
    Check("state is READY after the interrupt reception",
          (uint32)((HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_READY) ? 1U : 0U));
    Check("no error after the interrupt reception",
          (uint32)((HAL_SPI_GetError(&hspi_dev) == HAL_SPI_ERROR_NONE) ? 1U : 0U));
    CheckData("phase 5 received pattern");
    delay_ms(PHASE_GAP_MS);

    /* ---------------- phase 6 : interrupt full duplex -------------- */
    printf("\r\n-- phase 6 : HAL_SPI_TransmitReceive_IT --\r\n");
    ClearCounters();
    BufferInit();
    status = HAL_SPI_TransmitReceive_IT(&hspi_dev, tx_data, rx_data, FRAME_COUNT);
    Check("HAL_SPI_TransmitReceive_IT returns HAL_OK",
          (uint32)((status == HAL_OK) ? 1U : 0U));
    Check("state is BUSY_TX_RX while the exchange runs",
          (uint32)((HAL_SPI_GetState(&hspi_dev) ==
                    HAL_SPI_STATE_BUSY_TX_RX) ? 1U : 0U));
    WaitPhase(0U);
    Check("full duplex callback fired once", (uint32)((txrx_cplt == 1U) ? 1U : 0U));
    Check("state is READY after the interrupt exchange",
          (uint32)((HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_READY) ? 1U : 0U));
    Check("no error after the interrupt exchange",
          (uint32)((HAL_SPI_GetError(&hspi_dev) == HAL_SPI_ERROR_NONE) ? 1U : 0U));
    CheckData("phase 6 received pattern");
    delay_ms(PHASE_GAP_MS);

    /* ---------------- phase 7 : DMA transmit ---------------------- */
    printf("\r\n-- phase 7 : HAL_SPI_Transmit_DMA --\r\n");
    ClearCounters();
    status = HAL_SPI_Transmit_DMA(&hspi_dev, tx_data, FRAME_COUNT);
    Check("HAL_SPI_Transmit_DMA returns HAL_OK", (uint32)((status == HAL_OK) ? 1U : 0U));
    if (status != HAL_OK)
    {
        printf("error code : 0x%08X\r\n", PRINT_U32(HAL_SPI_GetError(&hspi_dev)));
    }
    WaitPhase(1U);
    Check("transmit completion callback fired once", (uint32)((tx_cplt == 1U) ? 1U : 0U));
    Check("state is READY after the DMA transfer",
          (uint32)((HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_READY) ? 1U : 0U));
    Check("DMA transmit channel is READY again",
          (uint32)((HAL_DMA_GetState(&hdma_tx) == HAL_DMA_STATE_READY) ? 1U : 0U));
    Check("no error after the DMA transfer",
          (uint32)((HAL_SPI_GetError(&hspi_dev) == HAL_SPI_ERROR_NONE) ? 1U : 0U));
    delay_ms(PHASE_GAP_MS);

    /* ---------------- phase 8 : DMA receive ----------------------- */
    printf("\r\n-- phase 8 : HAL_SPI_Receive_DMA --\r\n");
    ClearCounters();
    BufferInit();
    status = HAL_SPI_Receive_DMA(&hspi_dev, rx_data, FRAME_COUNT);
    Check("HAL_SPI_Receive_DMA returns HAL_OK", (uint32)((status == HAL_OK) ? 1U : 0U));
    if (status != HAL_OK)
    {
        printf("error code : 0x%08X\r\n", PRINT_U32(HAL_SPI_GetError(&hspi_dev)));
    }
    WaitPhase(0U);
    Check("receive completion callback fired once", (uint32)((rx_cplt == 1U) ? 1U : 0U));
    Check("state is READY after the DMA reception",
          (uint32)((HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_READY) ? 1U : 0U));
    Check("DMA receive channel is READY again",
          (uint32)((HAL_DMA_GetState(&hdma_rx) == HAL_DMA_STATE_READY) ? 1U : 0U));
    Check("no error after the DMA reception",
          (uint32)((HAL_SPI_GetError(&hspi_dev) == HAL_SPI_ERROR_NONE) ? 1U : 0U));
    CheckData("phase 8 received pattern");
    delay_ms(PHASE_GAP_MS);

    /* ---------------- phase 9 : DMA full duplex ------------------- */
    printf("\r\n-- phase 9 : HAL_SPI_TransmitReceive_DMA --\r\n");
    ClearCounters();
    BufferInit();
    status = HAL_SPI_TransmitReceive_DMA(&hspi_dev, tx_data, rx_data,
                                         FRAME_COUNT);
    Check("HAL_SPI_TransmitReceive_DMA returns HAL_OK",
          (uint32)((status == HAL_OK) ? 1U : 0U));
    if (status != HAL_OK)
    {
        printf("error code : 0x%08X\r\n", PRINT_U32(HAL_SPI_GetError(&hspi_dev)));
    }
    WaitPhase(0U);
    Check("full duplex callback fired once", (uint32)((txrx_cplt == 1U) ? 1U : 0U));
    Check("state is READY after the DMA exchange",
          (uint32)((HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_READY) ? 1U : 0U));
    Check("DMA receive channel is READY again",
          (uint32)((HAL_DMA_GetState(&hdma_rx) == HAL_DMA_STATE_READY) ? 1U : 0U));
    Check("DMA transmit channel is READY again",
          (uint32)((HAL_DMA_GetState(&hdma_tx) == HAL_DMA_STATE_READY) ? 1U : 0U));
    Check("no error after the DMA exchange",
          (uint32)((HAL_SPI_GetError(&hspi_dev) == HAL_SPI_ERROR_NONE) ? 1U : 0U));
    CheckData("phase 9 received pattern");

    printf("\r\ncallbacks : tx %u, rx %u, txrx %u, half tx %u, half rx %u, errors %u\r\n",
           PRINT_U32(tx_cplt), PRINT_U32(rx_cplt), PRINT_U32(txrx_cplt),
           PRINT_U32(tx_half), PRINT_U32(rx_half), PRINT_U32(error_events));

    /* Release the slave select, so the lines are not left asserted */
    HAL_SPI_NSSConfig(&hspi_dev, SPI_Slave0, SPI_DISABLE);

    Summary();

    while (1)
    {
        delay_ms(1000U);
    }
}

/**
 * @brief  Fill the transmit buffer and clear the receive buffer.
 * @param  None
 * @retval None
 */
static void BufferInit(void)
{
    uint32 index;

    for (index = 0U; index < FRAME_COUNT; index++)
    {
        tx_data[index] = (uint8)index;
        rx_data[index] = 0x00U;
    }
}

/**
 * @brief  Clear the callback counters and the phase completion flag.
 * @param  None
 * @retval None
 */
static void ClearCounters(void)
{
    tx_cplt     = 0U;
    rx_cplt     = 0U;
    txrx_cplt   = 0U;
    tx_half     = 0U;
    rx_half     = 0U;
    error_events = 0U;
    phase_done  = 0U;
}

/**
 * @brief  Wait for the phase completion flag (bounded).
 * @param  drain_rx: 1 = keep the receive FIFO empty while waiting (a master
 *         transmit always receives the frames it clocks out; the transmit-only
 *         DMA phase has no other consumer for them).
 * @retval None
 */
static void WaitPhase(uint32 drain_rx)
{
    uint32 polls = 0U;

    /* When the receive side has no consumer of its own (the transmit-only DMA
     * phase), the frames the master clocks out have to be taken out of the
     * receive FIFO until the bus really goes idle: the DMA channel completes
     * as soon as the last frame is queued in the transmit FIFO, which is up to
     * 32 frames before the last bit leaves the shifter. Stopping the drain at
     * the completion callback lets the remaining frames overflow the 32 entry
     * receive FIFO and turns the phase into an RXO error. */
    while ((polls < WAIT_POLLS) &&
           ((phase_done == 0U) ||
            ((drain_rx != 0U) && ((TEST_SPI->SR & SPI_Flag_BUSS) != 0U))))
    {
        if ((drain_rx != 0U) && ((TEST_SPI->SR & SPI_Flag_RXE) == 0U))
        {
            (void)TEST_SPI->RXDR;
        }
        polls++;
    }

    if (phase_done == 0U)
    {
        printf("            (no completion - a peer is required)\r\n");
        Check("phase completed", 0U);
    }
    else
    {
        Check("phase completed", 1U);
    }
}

/**
 * @brief  Compare the receive buffer with the expected pattern.
 * @param  name: short description of the comparison.
 * @retval None
 */
static void CheckData(const char *name)
{
    uint32 index;
    uint32 mismatches = 0U;

    for (index = 0U; index < FRAME_COUNT; index++)
    {
        if (rx_data[index] != tx_data[index])
        {
            mismatches++;
        }
    }

    printf("%-46s : rx[0..3] = 0x%02X 0x%02X 0x%02X 0x%02X, mismatches %u\r\n",
           name, PRINT_U32(rx_data[0]), PRINT_U32(rx_data[1]),
           PRINT_U32(rx_data[2]), PRINT_U32(rx_data[3]), PRINT_U32(mismatches));
}

/**
 * @brief  Report the result of one check.
 * @param  name: short description of the check.
 * @param  condition: 0 = FAIL, non zero = PASS.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("%-46s : [PASS]\r\n", name);
    }
    else
    {
        check_failures++;
        printf("%-46s : [FAIL]\r\n", name);
    }
}

/**
 * @brief  Print the accumulated failure counter.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(check_failures));
}

/**
 * @brief  Initialize the two DMA channels that carry the SPI3 request.
 * @param  None
 * @retval None
 */
static void DMA_Config(void)
{
    DMA_InitTypeDef dma_init;

    /* DMA controller clock gate and reset pulse */
    __HAL_SMU_DMA1_CLK_ENABLE();
    __HAL_SMU_DMA1_FORCE_RESET();
    __HAL_SMU_DMA1_RELEASE_RESET();

    /* Receive channel: peripheral (RXDR) to memory */
    __HAL_CLEAR_STRUCT(&hdma_rx);
    hdma_rx.Instance = TEST_DMA_RX_INSTANCE;

    HAL_DMA_StructInit(&dma_init);
    dma_init.DMA_PeripheralBaseAddr = (uint32)&TEST_SPI->RXDR;
    dma_init.DMA_MemoryBaseAddr     = (uint32)rx_data;
    dma_init.DMA_DIR                = DMA_PERIPH_TO_MEMORY;
    dma_init.DMA_BufferSize         = FRAME_COUNT;
    dma_init.DMA_PeripheralInc      = DMA_PINC_DISABLE;
    dma_init.DMA_MemoryInc          = DMA_MINC_ENABLE;
    dma_init.DMA_PeripheralDataSize = DMA_PDATAALIGN_WORD;
    dma_init.DMA_MemoryDataSize     = DMA_MDATAALIGN_BYTE;
    dma_init.DMA_Priority           = DMA_PRIORITY_HIGH;
    dma_init.DMA_M2M                = DMA_M2M_Disable;
    dma_init.DMA_Mode               = DMA_NORMAL;
    hdma_rx.Init = dma_init;

    Check("HAL_DMA_Init (receive channel)",
          (uint32)((HAL_DMA_Init(&hdma_rx) == HAL_OK) ? 1U : 0U));
    HAL_DMA_ConfigPeriphIF(&hdma_rx, SPI3_IF);

    /* Transmit channel: memory to peripheral */
    __HAL_CLEAR_STRUCT(&hdma_tx);
    hdma_tx.Instance = TEST_DMA_TX_INSTANCE;

    HAL_DMA_StructInit(&dma_init);
    dma_init.DMA_PeripheralBaseAddr = (uint32)&TEST_SPI->TXEDR;
    dma_init.DMA_MemoryBaseAddr     = (uint32)tx_data;
    dma_init.DMA_DIR                = DMA_MEMORY_TO_PERIPH;
    dma_init.DMA_BufferSize         = FRAME_COUNT;
    dma_init.DMA_PeripheralInc      = DMA_PINC_DISABLE;
    dma_init.DMA_MemoryInc          = DMA_MINC_ENABLE;
    dma_init.DMA_PeripheralDataSize = DMA_PDATAALIGN_WORD;
    dma_init.DMA_MemoryDataSize     = DMA_MDATAALIGN_BYTE;
    dma_init.DMA_Priority           = DMA_PRIORITY_HIGH;
    dma_init.DMA_M2M                = DMA_M2M_Disable;
    dma_init.DMA_Mode               = DMA_NORMAL;
    hdma_tx.Init = dma_init;

    Check("HAL_DMA_Init (transmit channel)",
          (uint32)((HAL_DMA_Init(&hdma_tx) == HAL_OK) ? 1U : 0U));
    HAL_DMA_ConfigPeriphIF(&hdma_tx, SPI3_IF);
}

/**
 * @brief  Route the SPI3 and DMA1 interrupt lines through the PLIC.
 * @param  None
 * @retval None
 */
static void SPI_PLIC_Init(void)
{
    PLIC_InitTypeDef plic;

    __HAL_SMU_PLIC_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&plic);
    plic.Size               = sizeof(plic);
    plic.Version            = PLIC_INIT_VERSION;
    plic.PLIC_IRQPriority   = 1U;
    plic.PLIC_IRQChannelCmd = ENABLE;

    plic.PLIC_IRQChannel    = TEST_SPI_IRQn;
    HAL_PLIC_Init(&plic);

    plic.PLIC_IRQChannel    = TEST_DMA_IRQn;
    HAL_PLIC_Init(&plic);
}

/**
 * @brief  SPI3 interrupt handler (weak symbol of the trap entry).
 * @param  None
 * @retval None
 */
void SPI3_IRQ_Handler(void)
{
    HAL_SPI_IRQHandler(&hspi_dev);
}

/**
 * @brief  DMA1 interrupt handler (weak symbol of the trap entry).
 * @note   One line is shared by the 16 channels of the controller.
 * @param  None
 * @retval None
 */
void DMA1_IRQ_Handler(void)
{
    HAL_DMA_IRQHandler(&hdma_rx);
    HAL_DMA_IRQHandler(&hdma_tx);
}

/**
 * @brief  Transmit complete callback of the device under test.
 * @param  hspi: SPI handle.
 * @retval None
 */
void HAL_SPI_TxCpltCallback(SPI_HandleTypeDef *hspi)
{
    if (hspi == &hspi_dev)
    {
        tx_cplt++;
        phase_done = 1U;
    }
}

/**
 * @brief  Receive complete callback of the device under test.
 * @param  hspi: SPI handle.
 * @retval None
 */
void HAL_SPI_RxCpltCallback(SPI_HandleTypeDef *hspi)
{
    if (hspi == &hspi_dev)
    {
        rx_cplt++;
        phase_done = 1U;
    }
}

/**
 * @brief  Full duplex complete callback of the device under test.
 * @param  hspi: SPI handle.
 * @retval None
 */
void HAL_SPI_TxRxCpltCallback(SPI_HandleTypeDef *hspi)
{
    if (hspi == &hspi_dev)
    {
        txrx_cplt++;
        phase_done = 1U;
    }
}

/**
 * @brief  Transmit half complete callback of the device under test.
 * @param  hspi: SPI handle.
 * @retval None
 */
void HAL_SPI_TxHalfCpltCallback(SPI_HandleTypeDef *hspi)
{
    if (hspi == &hspi_dev)
    {
        tx_half++;
    }
}

/**
 * @brief  Receive half complete callback of the device under test.
 * @param  hspi: SPI handle.
 * @retval None
 */
void HAL_SPI_RxHalfCpltCallback(SPI_HandleTypeDef *hspi)
{
    if (hspi == &hspi_dev)
    {
        rx_half++;
    }
}

/**
 * @brief  Error callback of the device under test.
 * @param  hspi: SPI handle.
 * @retval None
 */
void HAL_SPI_ErrorCallback(SPI_HandleTypeDef *hspi)
{
    if (hspi == &hspi_dev)
    {
        error_events++;
        printf("[irq] SPI error, error code 0x%08X\r\n",
               PRINT_U32(HAL_SPI_GetError(&hspi_dev)));
    }
}

/**
 * @brief  MSP initialization of the device under test.
 * @note   Strong override of the weak driver callback.
 * @param  hspi: SPI handle of the device under test.
 * @retval None
 */
void HAL_SPI_MspInit(SPI_HandleTypeDef *hspi)
{
    GPIO_InitTypeDef gpio;

    if (hspi->Instance != TEST_SPI)
    {
        return;
    }

    /* Peripheral clock gate and reset pulse */
    __HAL_SMU_SPI3_CLK_ENABLE();
    __HAL_SMU_SPI3_FORCE_RESET();
    __HAL_SMU_SPI3_RELEASE_RESET();

    /* Port clock gates used by this case */
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&gpio);
    gpio.Size         = sizeof(gpio);
    gpio.Version      = GPIO_INIT_VERSION;
    gpio.Pull         = GPIO_NOPULL;
    gpio.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    gpio.Alternate    = TEST_PIN_AF;

    /* CS0 (driven by the SSR register) */
    HAL_GPIO_PinAFConfig(TEST_CS_PORT, TEST_CS_SOURCE, TEST_PIN_AF);
    gpio.Pin  = TEST_CS_PIN;
    gpio.Mode = GPIO_MODE_AF_PP;
    HAL_GPIO_Init(TEST_CS_PORT, &gpio);

    /* SCK */
    HAL_GPIO_PinAFConfig(TEST_SCK_PORT, TEST_SCK_SOURCE, TEST_PIN_AF);
    gpio.Pin = TEST_SCK_PIN;
    HAL_GPIO_Init(TEST_SCK_PORT, &gpio);

    /* MOSI */
    HAL_GPIO_PinAFConfig(TEST_MOSI_PORT, TEST_MOSI_SOURCE, TEST_PIN_AF);
    gpio.Pin = TEST_MOSI_PIN;
    HAL_GPIO_Init(TEST_MOSI_PORT, &gpio);

    /* MISO: alternate function input, floating */
    HAL_GPIO_PinAFConfig(TEST_MISO_PORT, TEST_MISO_SOURCE, TEST_PIN_AF);
    gpio.Pin  = TEST_MISO_PIN;
    gpio.Mode = GPIO_MODE_INPUT;
    HAL_GPIO_Init(TEST_MISO_PORT, &gpio);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the CLINT / CMU / MPU / USART integration tests.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef    SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the same set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls (PMU_CheckState) */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
