/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_usart.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version :        V1.7
 * Date:   2026/10/19
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.1     add the DMA handle forward declaration matching the DMA HAL driver
 *     ANSILIC APPLICATION GROUP  2026/09/14     1.2     document that the blocking transmit APIs handshake on USART_FLAG_TXE
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.5     add the shared validity / state / lock helpers, apply the runtime parameter validation and the busy state gate, move the blocking timeout bookkeeping (state + timeout error code + unlock) to the caller, run the MSP callbacks outside the locked region, yield the CPU while polling, declare the timeout and invalid parameter error codes, document every public prototype (blocking behaviour included) and drop the circular include with the extension header
 *     ANSILIC APPLICATION GROUP  2026/10/10     1.6     merge the capabilities of the USART release of 2026/10/10
 *                                                       into this driver: (1) the baud rate divider computed by
 *                                                       USART_SetConfig() is validated against the 16 bit domain
 *                                                       of the BRR register before it is written (an out of range
 *                                                       divider is rejected with HAL_USART_ERROR_INVALID_PARAM
 *                                                       instead of being truncated by the 16 bit store), (2) a
 *                                                       failed Tx start of HAL_USART_TransmitReceive_DMA() rolls
 *                                                       the already started Rx direction back (its request is
 *                                                       closed and its channel aborted), so that no armed channel
 *                                                       is left behind and the documented retry actually works,
 *                                                       (3) HAL_USART_DeInit() aborts the DMA channels linked to
 *                                                       the instance before the control registers are zeroed
 *     ANSILIC APPLICATION GROUP  2026/10/19     1.7     fix IS_USART_BAUDRATE(): the parameter is
 *                                                       the bit rate, not a register field, so it is no longer
 *                                                       limited to the 16 bit domain of BRR (that domain
 *                                                       constrains the computed divider, which is validated
 *                                                       separately).  The previous bound rejected every rate
 *                                                       above 65535 bit/s (115200, 921600, ...), so the run
 *                                                       time validation of HAL_USART_Init() returned
 *                                                       HAL_ERROR before any register was touched and the
 *                                                       peripheral stayed unprogrammed: CR1 and BRR kept their
 *                                                       reset values and no character was ever transmitted
 * Description:     This file contains all the functions prototypes for the USART HAL firmware library.
 *                  It is a HAL-style port of the AS32X601 USART peripheral library (as32x601_usart.c/.h),
 *                  providing the initialization, blocking / interrupt / DMA data transfers and
 *                  peripheral state management for the USART peripheral.
 *                  Prerequisite: the file "as32x601_hal_def.h" shall be provided by the user (HAL common
 *                  definitions: HAL_StatusTypeDef, HAL_LockTypeDef, HAL_MAX_DELAY, __HAL_LOCK/__HAL_UNLOCK,
 *                  HAL_GetTick(), ...).
 * @complexity  Complex
 *              Blocking + IT + DMA modes, state machine, user callbacks.
 */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __AS32X601_HAL_USART_H
#define __AS32X601_HAL_USART_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include <stddef.h>
#include "as32x601_hal_def.h"
#include "as32x601.h"

/* Exported constants --------------------------------------------------------*/

/**
 * @brief USART HAL driver module version.
 * @note  0x0100U = V1.0. Bumped only on breaking API changes (architecture
 *        spec COMPAT-13/14/15).
 */
#define __HAL_USART_MODULE_VERSION  0x0100U

/** @addtogroup AS32X601_HAL_Driver
  * @{
  */

/** @addtogroup USART
  * @{
  */

/* Exported types ------------------------------------------------------------*/
/** @defgroup USART_Exported_Types USART Exported Types
  * @{
  */

/**
  * @brief USART Advanced Features initialization structure definition
  */
typedef struct
{
    uint32 AdvFeatureInit;      /*!< Advanced feature init selector: @ref USART_ADVFEATURE_NO_INIT,
                                     or a combination of the *_INIT flags (TX/RX/data invert,
                                     overrun disable, auto baud rate, MSB first)             */
    uint32 TxPinLevelInvert;    /*!< TX pin level inversion enable: USART_ADVFEATURE_TXINVERT_ENABLE /
                                     USART_ADVFEATURE_TXINVERT_DISABLE                        */
    uint32 RxPinLevelInvert;    /*!< RX pin level inversion enable: USART_ADVFEATURE_RXINVERT_ENABLE /
                                     USART_ADVFEATURE_RXINVERT_DISABLE                        */
    uint32 DataInvert;          /*!< Data inversion enable: USART_ADVFEATURE_DATAINVERT_ENABLE /
                                     USART_ADVFEATURE_DATAINVERT_DISABLE                      */
    uint32 OverrunDisable;      /*!< Overrun disable: USART_ADVFEATURE_OVERRUN_ENABLE /
                                     USART_ADVFEATURE_OVERRUN_DISABLE                        */
    uint32 AutoBaudRateEnable;  /*!< Auto baud rate enable: USART_ADVFEATURE_AUTOBAUDRATE_ENABLE /
                                     USART_ADVFEATURE_AUTOBAUDRATE_DISABLE                    */
    uint32 AutoBaudRateMode;    /*!< Auto baud rate mode (fully / measured by a field) */
    uint32 MSBFirst;            /*!< MSB first transmission enable: USART_ADVFEATURE_MSBFIRST_ENABLE /
                                     USART_ADVFEATURE_MSBFIRST_DISABLE                        */
} USART_AdvFeatureInitTypeDef;

/**
  * @brief USART Init Structure definition
  * @note  This structure follows the Version+Size compatibility mechanism
  *        (architecture spec section 22): the user must clear the structure,
  *        set the Size and Version metafields before filling the business
  *        fields (see HAL_USART_StructInit()).
  */
typedef struct
{
    uint32 Size;                      /*!< sizeof(USART_InitTypeDef), must be set by the user
                                             after clearing the structure           */
    uint32 Version;                   /*!< Structure semantic version: @ref USART_INIT_VERSION
                                             (USART_INIT_V1 = 0x0100U)              */

    uint32 BaudRate;                  /*!< This member configures the USART communication baud rate.
                                             The baud rate is computed using the following formula:
                                                Baud Rate Register = ((PCLKx) / (BaudRate))
                                             where PCLKx is the APBBus0/APBBus1 clock frequency
                                             (SMU_ClocksStruct.APBBus0_Frequency / APBBus1_Frequency). */

    uint32 WordLength;   /*!< Specifies the number of data bits transmitted or received in a frame.
                         This parameter can be a value of @ref USART_Word_Length */

    uint32 StopBits;                  /*!< Specifies the number of stop bits transmitted.
                                             This parameter can be a value of @ref USART_Stop_Bits */

    uint32 Parity;                    /*!< Specifies the parity mode.
                                             This parameter can be a value of @ref USART_Parity
                                             @note When parity is enabled, the computed parity is inserted
                                                   at the MSB position of the transmitted data (9th bit when
                                                   the word length is set to 9 data bits; 8th bit when the
                                                   word length is set to 8 data bits). */

    uint32 Mode;   /*!< Specifies whether the Receive or Transmit mode is enabled or disabled. This
                   parameter can be a value of @ref USART_Mode */

    uint32 OverSampling;   /*!< Specifies whether the Over sampling 8 is enabled or disabled. This
                           parameter can be a value of @ref USART_Over_Sampling */

    uint32 HardwareFlowControl;   /*!< Specifies whether the hardware flow control mode is enabled or
                                  disabled. This parameter can be a value of @ref USART_Hardware_Flow_Control */

    uint32 CLKPolarity;               /*!< Specifies the steady state of the serial clock.
                                             This parameter can be a value of @ref USART_Clock_Polarity */

    uint32 CLKPhase;   /*!< Specifies the clock transition on which the bit capture is made. This
                       parameter can be a value of @ref USART_Clock_Phase */

    uint32 CLKLastBit;   /*!< Specifies whether the clock pulse corresponding to the
                                      last transmitted data bit (MSB) has to be output on the SCLK pin in synchronous mode. This parameter can be a value of @ref USART_Last_Bit */

    USART_AdvFeatureInitTypeDef AdvancedInit; /*!< USART Advanced Features initialization parameters
                                                   (TX/RX pin level inversion, data inversion, overrun disable,
                                                   auto baud rate, MSB first). Only evaluated when
                                                   AdvancedInit.AdvFeatureInit is not USART_ADVFEATURE_NO_INIT. */
    uint32 Reserved[2];               /*!< Reserved for future extension (must be 0) */
} USART_InitTypeDef;

/**
  * @brief USART init structure version macros.
  * @note  USART_INIT_V1 is the current version. Future versions must be
  *        appended after the existing fields (architecture spec section 22.5).
  */
#define USART_INIT_V1  0x0100U   /*!< USART Init structure version V1.0 */
#define USART_INIT_VERSION  USART_INIT_V1   /*!< Current USART Init structure version */

/**
  * @brief USART Clock Init Structure definition
  */
typedef struct
{
    uint32 Clock;                     /*!< Specifies whether the USART clock is enabled or disabled.
                                             This parameter can be a value of @ref USART_Clock */
    uint32 CPOL;                      /*!< Specifies the steady state of the serial clock.
                                             This parameter can be a value of @ref USART_Clock_Polarity */
    uint32 CPHA;   /*!< Specifies the clock transition on which the bit capture is made. This
                   parameter can be a value of @ref USART_Clock_Phase */
    uint32 LastBit;   /*!< Specifies whether the clock pulse corresponding to the
                                      last transmitted data bit (MSB) has to be output on the SCLK pin in synchronous mode. This parameter can be a value of @ref USART_Last_Bit */
} USART_ClockInitTypeDef;

/**
  * @brief HAL USART State structures definition
  */
typedef enum
{
    HAL_USART_STATE_RESET             = 0x00U,    /*!< Peripheral is not initialized   */
    HAL_USART_STATE_READY             = 0x01U,    /*!< Peripheral Initialized and ready for use */
    HAL_USART_STATE_BUSY              = 0x02U,    /*!< an internal process is ongoing */
    HAL_USART_STATE_BUSY_TX           = 0x12U,    /*!< Data Transmission process is ongoing */
    HAL_USART_STATE_BUSY_RX           = 0x22U,    /*!< Data Reception process is ongoing */
    HAL_USART_STATE_BUSY_TX_RX        = 0x32U,   /*!< Data Transmission Reception process is
                                                  ongoing */
    HAL_USART_STATE_TIMEOUT           = 0x03U,    /*!< Timeout state */
    HAL_USART_STATE_ERROR             = 0x04U     /*!< Error */
} HAL_USART_StateTypeDef;

/**
  * @brief USART clock sources definitions
  */
typedef enum
{
    USART_CLOCKSOURCE_APB0     = 0x00U,   /*!< APBBus0 clock source (USART0..USART3) */
    USART_CLOCKSOURCE_APB1     = 0x01U,   /*!< APBBus1 clock source (USART4..USART7) */
    USART_CLOCKSOURCE_UNDEFINED = 0x10U   /*!< Undefined clock source */
} USART_ClockSourceTypeDef;

/* Forward declaration of the DMA handle (AS32X601 DMA HAL driver).
 * The struct tag is __DMA_HandleTypeDef to match the definition in
 * as32x601_hal_dma.h. */
typedef struct __DMA_HandleTypeDef DMA_HandleTypeDef;

/**
  * @brief USART handle Structure definition
  * @note  Field order follows the architecture spec HANDLE-02:
  *        Instance -> Init -> Lock -> State -> ErrorCode -> module fields.
  *        The transfer counter fields modified by the ISR / DMA callbacks
  *        are declared as __IO (HANDLE-03).
  */
typedef struct __USART_HandleTypeDef
{
    USART_TypeDef                 *Instance;        /*!< USART registers base address        */

    USART_InitTypeDef             Init;             /*!< USART communication parameters      */

    HAL_LockTypeDef               Lock;             /*!< Locking object                       */
#if (USE_RTOS == 1)
    HAL_MutexTypeDef              LockMutex;        /*!< RTOS mutex handle                  */
#endif

    __IO HAL_USART_StateTypeDef   State;            /*!< USART communication state           */

    __IO uint32                   ErrorCode;        /*!< USART Error code                    */

    uint8                       *pTxBuffPtr;      /*!< Pointer to USART Tx transfer Buffer */

    __IO uint16                  TxXferSize;       /*!< USART Tx Transfer size              */

    __IO uint16                  TxXferCount;      /*!< USART Tx Transfer Counter           */

    uint8                       *pRxBuffPtr;      /*!< Pointer to USART Rx transfer Buffer */

    __IO uint16                  RxXferSize;       /*!< USART Rx Transfer size              */

    __IO uint16                  RxXferCount;      /*!< USART Rx Transfer Counter           */

    uint16                      Mask;             /*!< USART Rx RDR register mask          */

    DMA_HandleTypeDef             *hdmatx;          /*!< USART Tx DMA Handle parameters      */

    DMA_HandleTypeDef             *hdmarx;          /*!< USART Rx DMA Handle parameters      */

} USART_HandleTypeDef;

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/
/** @defgroup USART_Exported_Constants USART Exported Constants
  * @{
  */

/** @defgroup USART_Error_Code USART Error Code
  * @brief    USART Error Code
  * @{
  */
#define HAL_USART_ERROR_NONE         ((uint32)0x00000000U)   /*!< No error            */
#define HAL_USART_ERROR_PE           ((uint32)0x00000001U)   /*!< Parity error        */
#define HAL_USART_ERROR_NE           ((uint32)0x00000002U)   /*!< Noise error         */
#define HAL_USART_ERROR_FE           ((uint32)0x00000004U)   /*!< Frame error         */
#define HAL_USART_ERROR_ORE          ((uint32)0x00000008U)   /*!< Overrun error       */
#define HAL_USART_ERROR_DMA          ((uint32)0x00000010U)   /*!< DMA transfer error  */
#define HAL_USART_ERROR_TIMEOUT      ((uint32)0x00000020U)   /*!< Timeout error       */
#define HAL_USART_ERROR_INVALID_PARAM ((uint32)0x00000040U)  /*!< Invalid parameter or rejected operation */
/**
  * @}
  */

/** @defgroup USART_Stop_Bits  USART Number of Stop Bits
  * @{
  */
#define USART_STOPBITS_1                     ((uint32)0x0000U)
#define USART_STOPBITS_2                     ((uint32)USART_CR2_STOP_1)
/**
  * @}
  */

/** @defgroup USART_Parity    USART Parity
  * @{
  */
#define USART_PARITY_NONE                   ((uint32)0x0000U)
#define USART_PARITY_EVEN                   ((uint32)USART_CR1_PCE)
#define USART_PARITY_ODD                    ((uint32)(USART_CR1_PCE | USART_CR1_PS))
/**
  * @}
  */

/** @defgroup USART_Mode   USART Mode
  * @{
  */
#define USART_MODE_RX                       ((uint32)USART_CR1_RE)
#define USART_MODE_TX                       ((uint32)USART_CR1_TE)
#define USART_MODE_TX_RX                    ((uint32)(USART_CR1_TE | USART_CR1_RE))
/**
  * @}
  */

/** @defgroup USART_Over_Sampling USART Over Sampling
  * @{
  */
#define USART_OVERSAMPLING_16               ((uint32)0x0000U)
#define USART_OVERSAMPLING_8                ((uint32)USART_CR1_OVER8)
/**
  * @}
  */

/** @defgroup USART_Hardware_Flow_Control USART Hardware Flow Control
  * @{
  */
#define USART_HWCONTROL_NONE                ((uint32)0x00000000U)
#define USART_HWCONTROL_RTS                 ((uint32)USART_CR3_RTSE)
#define USART_HWCONTROL_CTS                 ((uint32)USART_CR3_CTSE)
#define USART_HWCONTROL_RTS_CTS             ((uint32)(USART_CR3_RTSE | USART_CR3_CTSE))
/**
  * @}
  */

/** @defgroup USART_Clock  USART Clock
  * @{
  */
#define USART_CLOCK_DISABLE                 ((uint32)0x0000U)
#define USART_CLOCK_ENABLE                  ((uint32)USART_CR2_CLKEN)
/**
  * @}
  */

/** @defgroup USART_Clock_Polarity  USART Clock Polarity
  * @{
  */
#define USART_POLARITY_LOW                  ((uint32)0x0000U)
#define USART_POLARITY_HIGH                 ((uint32)USART_CR2_CPOL)
/**
  * @}
  */

/** @defgroup USART_Clock_Phase   USART Clock Phase
  * @{
  */
#define USART_PHASE_1EDGE                   ((uint32)0x0000U)
#define USART_PHASE_2EDGE                   ((uint32)USART_CR2_CPHA)
/**
  * @}
  */

/** @defgroup USART_Last_Bit  USART Last Bit
  * @{
  */
#define USART_LASTBIT_DISABLE               ((uint32)0x0000U)
#define USART_LASTBIT_ENABLE                ((uint32)USART_CR2_LBCL)
/**
  * @}
  */

/** @defgroup USART_Request_Parameters  USART Request Parameters
  * @{
  */
#define USART_AUTOBAUD_REQUEST              ((uint32)USART_RQR_ABRRQ)        /*!< Auto-Baud Rate Request */
#define USART_SENDBREAK_REQUEST             ((uint32)USART_RQR_SBKRQ)        /*!< Send Break Request */
#define USART_RXDATA_FLUSH_REQUEST          ((uint32)USART_RQR_RXFRQ)        /*!< Receive Data flush Request */
#define USART_TXDATA_FLUSH_REQUEST          ((uint32)USART_RQR_TXFRQ)        /*!< Transmit data flush Request */
#define IS_USART_REQUEST_PARAMETER(__PARAM__) (((__PARAM__) == USART_AUTOBAUD_REQUEST)  || \
                                               ((__PARAM__) == USART_SENDBREAK_REQUEST) || \
                                               ((__PARAM__) == USART_RXDATA_FLUSH_REQUEST) || \
                                               ((__PARAM__) == USART_TXDATA_FLUSH_REQUEST))
/**
  * @}
  */

/** @defgroup USART_Flags      USART Flags
  *        Elements values convention: 0xXXXX
  *           - 0xXXXX  : Flag mask in the ISR register
  * @{
  */
#define USART_FLAG_TXFT                     ((uint32)0x08000000U)            /*!< USART TXFIFO threshold flag */
#define USART_FLAG_RXFT                     ((uint32)0x04000000U)            /*!< USART RXFIFO threshold flag */
#define USART_FLAG_RXFF                     ((uint32)0x01000000U)            /*!< USART RXFIFO Full flag */
#define USART_FLAG_TXFE                     ((uint32)0x00800000U)            /*!< USART TXFIFO Empty flag */
#define USART_FLAG_SBKF                     ((uint32)0x00040000U)            /*!< USART send break flag */
#define USART_FLAG_BUSY                     ((uint32)0x00010000U)            /*!< USART busy flag */
#define USART_FLAG_ABRF                     ((uint32)0x00008000U)            /*!< USART auto Baud rate flag */
#define USART_FLAG_ABRE                     ((uint32)0x00004000U)            /*!< USART auto Baud rate error */
#define USART_FLAG_CTS                      ((uint32)0x00000400U)            /*!< USART CTS flag */
#define USART_FLAG_CTSIF                    ((uint32)0x00000200U)            /*!< USART CTS interrupt flag */
#define USART_FLAG_LBDF                     ((uint32)0x00000100U)            /*!< USART LIN break detection flag */
#define USART_FLAG_TXE                      ((uint32)0x00000080U)            /*!< USART transmit data register empty */
#define USART_FLAG_TXFNF                    ((uint32)0x00000080U)            /*!< USART TXFIFO not full */
#define USART_FLAG_TC                       ((uint32)0x00000040U)            /*!< USART transmission complete */
#define USART_FLAG_RXNE                     ((uint32)0x00000020U)            /*!< USART read data register not empty */
#define USART_FLAG_RXFNE                    ((uint32)0x00000020U)            /*!< USART RXFIFO not empty */
#define USART_FLAG_IDLE                     ((uint32)0x00000010U)            /*!< USART idle flag */
#define USART_FLAG_ORE                      ((uint32)0x00000008U)            /*!< USART overrun error */
#define USART_FLAG_NE                       ((uint32)0x00000004U)            /*!< USART noise error */
#define USART_FLAG_FE                       ((uint32)0x00000002U)            /*!< USART frame error */
#define USART_FLAG_PE                       ((uint32)0x00000001U)            /*!< USART parity error */
/**
  * @}
  */

/** @defgroup USART_Interrupt_definition USART Interrupts Definition
  *        Each interrupt source is encoded in a single 16-bit value
  *        (elements values convention: 0000ZZZZ0XXYYYYYb):
  *           - YYYYY  : Interrupt source (enable bit) position in the XX register (5bits)
  *           - XX     : Interrupt source register (2bits)
  *                 - 01: CR1 register
  *                 - 10: CR2 register
  *                 - 11: CR3 register
  *           - ZZZZ   : Flag position in the ISR register (extracted by >>8)
  *        The USART_IT_MAKE() helper builds the value from a readable
  *        (register, enable-bit position, flag position) triplet.
  * @{
  */
#define USART_IT_MAKE(__REG__, __BIT__, __FLAG__) ((uint16)((((__REG__) & 0x3U) << 5U) | (((__FLAG__) & 0x1FU) << 8U) | ((__BIT__) & 0x1FU)))

#define USART_IT_PE      USART_IT_MAKE(1U, 8U, 0U)     /*!< CR1.PEIE (bit8),   ISR.PE (bit0)      Parity Error interrupt */
#define USART_IT_TXE     USART_IT_MAKE(1U, 7U, 7U)     /*!< CR1.TXEIE (bit7),  ISR.TXE (bit7)     Transmit Data Register empty interrupt */
#define USART_IT_TC      USART_IT_MAKE(1U, 6U, 6U)     /*!< CR1.TCIE (bit6),   ISR.TC (bit6)      Transmission complete interrupt */
#define USART_IT_RXNE    USART_IT_MAKE(1U, 5U, 5U)     /*!< CR1.RXNEIE (bit5), ISR.RXNE (bit5)    Receive Data register not empty interrupt */
#define USART_IT_IDLE    USART_IT_MAKE(1U, 4U, 4U)     /*!< CR1.IDLEIE (bit4), ISR.IDLE (bit4)    Idle line detection interrupt */
#define USART_IT_LBD     USART_IT_MAKE(2U, 6U, 8U)     /*!< CR2.LBDIE (bit6),  ISR.LBDF (bit8)    LIN break detection interrupt */
#define USART_IT_CTS     USART_IT_MAKE(3U, 8U, 9U)     /*!< CR3.CTSIE (bit8),  ISR.CTSIF (bit9)   CTS interrupt */
#define USART_IT_ERR     USART_IT_MAKE(3U, 0U, 0U)     /*!< CR3.EIE (bit0),    ISR.PE (bit0)      Error interrupt (frame/noise/overrun) */
#define USART_IT_ORE     USART_IT_MAKE(3U, 0U, 3U)     /*!< CR3.EIE (bit0),    ISR.ORE (bit3)     OverRun Error interrupt */
#define USART_IT_NE      USART_IT_MAKE(3U, 0U, 2U)     /*!< CR3.EIE (bit0),    ISR.NE (bit2)      Noise Error interrupt */
#define USART_IT_FE      USART_IT_MAKE(3U, 0U, 1U)     /*!< CR3.EIE (bit0),    ISR.FE (bit1)      Framing Error interrupt */
#define USART_IT_TXFE    USART_IT_MAKE(1U, 30U, 23U)   /*!< CR1.TXIEF (bit30), ISR.TXFE (bit23)   TXFIFO empty interrupt */
#define USART_IT_RXFF    USART_IT_MAKE(1U, 31U, 24U)   /*!< CR1.RXFIEF (bit31),ISR.RXFF (bit24)   RXFIFO full interrupt */
#define USART_IT_TXFT    USART_IT_MAKE(3U, 20U, 27U)   /*!< CR3.TXFTIE (bit20),ISR.TXFT (bit27)   TXFIFO threshold interrupt */
#define USART_IT_RXFT    USART_IT_MAKE(3U, 25U, 26U)   /*!< CR3.RXFTIE (bit25),ISR.RXFT (bit26)   RXFIFO threshold interrupt */
/**
  * @}
  */

/** @defgroup USART_IT_CLEAR_Flags    USART Interruption Clear Flags
  * @{
  */
#define USART_CLEAR_PEF                       USART_ICR_PECF            /*!< Parity Error Clear Flag */
#define USART_CLEAR_FEF                       USART_ICR_FECF            /*!< Framing Error Clear Flag */
#define USART_CLEAR_NEF                       USART_ICR_NECF            /*!< Noise detected Clear Flag */
#define USART_CLEAR_OREF                      USART_ICR_ORECF           /*!< OverRun Error Clear Flag */
#define USART_CLEAR_IDLEF                     USART_ICR_IDLECF          /*!< IDLE line detected Clear Flag */
#define USART_CLEAR_TXFEF                     USART_ICR_TXFECF          /*!< TXFIFO empty Clear Flag */
#define USART_CLEAR_TCF                       USART_ICR_TCCF            /*!< Transmission Complete Clear Flag */
#define USART_CLEAR_LBDF                      USART_ICR_LBDCF           /*!< LIN Break Detection Clear Flag */
#define USART_CLEAR_CTSF                      USART_ICR_CTSCF           /*!< CTS Interrupt Clear Flag */
#define USART_CLEAR_RXFTF                     USART_ICR_RXFTCF          /*!< RXFIFO threshold Clear Flag */
#define USART_CLEAR_TXFTF                     USART_ICR_TXFTCF          /*!< TXFIFO threshold Clear Flag */
/**
  * @}
  */

/** @defgroup USART_Interruption_Masks USART Interrupts definition masks
  * @{
  */
#define USART_IT_MASK                         ((uint32)0x0000001FU)    /*!< USART interruptions flags mask */
/**
  * @}
  */

/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/
/** @defgroup USART_Private_Macros USART Private Macros
  * @{
  */

/** @brief  Check the USART peripheral instance.
  * @param  __INSTANCE__: specifies the USART peripheral instance.
  * @retval None
  */
#define IS_USART_ALL_PERIPH(__INSTANCE__) (((__INSTANCE__) == USART0) || ((__INSTANCE__) == USART1) || \
                                           ((__INSTANCE__) == USART2) || ((__INSTANCE__) == USART3) || \
                                           ((__INSTANCE__) == USART4) || ((__INSTANCE__) == USART5) || \
                                           ((__INSTANCE__) == USART6) || ((__INSTANCE__) == USART7))

/** @brief  Check the USART baud rate value.
  * @param  __BAUDRATE__: specifies the USART baud rate, in bit/s.
  * @retval None
  * @note   The parameter is a BIT RATE, not a register field, so it is not
  *         limited to the 16 bit domain of the BRR register: that domain
  *         constrains the DIVIDER computed from the bus clock, and it is
  *         validated separately by IS_USART_BRR_DIVIDER() before the value is
  *         programmed.  Applying the 16 bit bound to the bit rate itself
  *         rejected every usable rate above 65535 bit/s (115200, 921600, ...),
  *         which made the run time validation of HAL_USART_Init() fail and left
  *         the peripheral unprogrammed.  Zero is still rejected here because
  *         USART_SetConfig() divides the bus clock by this value; an
  *         unachievable (too high) rate is reported by the divider check.
  */
#define IS_USART_BAUDRATE(__BAUDRATE__) (((__BAUDRATE__) > 0U) && ((__BAUDRATE__) <= 10000000U))

/** @brief  Check the USART baud rate divider computed by USART_SetConfig().
  * @note   The BRR register holds a 16 bit divider, so the quotient of the bus
  *         clock and the requested baud rate is validated against that domain
  *         before it is programmed: a divider of zero (baud rate higher than
  *         the bus clock) or a value that does not fit in 16 bits is rejected
  *         with HAL_USART_ERROR_INVALID_PARAM instead of being truncated by
  *         the 16 bit store.
  * @param  __DIVIDER__: specifies the computed baud rate divider.
  * @retval None
  */
#define IS_USART_BRR_DIVIDER(__DIVIDER__) (((__DIVIDER__) > 0U) && ((__DIVIDER__) <= 0xFFFFU))

/** @brief  Check the USART data value.
  * @param  __DATA__: specifies the USART data.
  * @retval None
  */
#define IS_USART_DATA(__DATA__) ((__DATA__) <= 0x1FFU)

/** @brief  Check the USART mode.
  * @param  __MODE__: specifies the USART mode.
  * @retval None
  */
#define IS_USART_MODE(__MODE__) ((((__MODE__) & (uint32)0xFFFFFFF3U) == 0x00U) && ((__MODE__) != (uint32)0x00U))

/** @brief  Check the USART parity.
  * @param  __PARITY__: specifies the USART parity.
  * @retval None
  */
#define IS_USART_PARITY(__PARITY__) (((__PARITY__) == USART_PARITY_NONE) || \
                                     ((__PARITY__) == USART_PARITY_EVEN) || \
                                     ((__PARITY__) == USART_PARITY_ODD))

/** @brief  Check the USART stop bits.
  * @param  __STOPBITS__: specifies the USART stop bits.
  * @retval None
  */
#define IS_USART_STOPBITS(__STOPBITS__) (((__STOPBITS__) == USART_STOPBITS_1) || \
                                         ((__STOPBITS__) == USART_STOPBITS_2))

/** @brief  Check the USART over sampling.
  * @param  __SAMPLING__: specifies the USART over sampling.
  * @retval None
  */
#define IS_USART_OVERSAMPLING(__SAMPLING__) (((__SAMPLING__) == USART_OVERSAMPLING_16) || \
                                             ((__SAMPLING__) == USART_OVERSAMPLING_8))

/** @brief  Check the USART hardware flow control.
  * @param  __CONTROL__: specifies the USART hardware flow control.
  * @retval None
  */
#define IS_USART_HARDWARE_FLOW_CONTROL(__CONTROL__) (((__CONTROL__) == USART_HWCONTROL_NONE) || \
                                                     ((__CONTROL__) == USART_HWCONTROL_RTS) || \
                                                     ((__CONTROL__) == USART_HWCONTROL_CTS) || \
                                                     ((__CONTROL__) == USART_HWCONTROL_RTS_CTS))

/** @brief  Check the USART clock.
  * @param  __CLOCK__: specifies the USART clock.
  * @retval None
  */
#define IS_USART_CLOCK(__CLOCK__) (((__CLOCK__) == USART_CLOCK_DISABLE) || \
                                   ((__CLOCK__) == USART_CLOCK_ENABLE))

/** @brief  Check the USART clock polarity.
  * @param  __CPOL__: specifies the USART clock polarity.
  * @retval None
  */
#define IS_USART_POLARITY(__CPOL__) (((__CPOL__) == USART_POLARITY_LOW) || \
                                     ((__CPOL__) == USART_POLARITY_HIGH))

/** @brief  Check the USART clock phase.
  * @param  __CPHA__: specifies the USART clock phase.
  * @retval None
  */
#define IS_USART_PHASE(__CPHA__) (((__CPHA__) == USART_PHASE_1EDGE) || \
                                  ((__CPHA__) == USART_PHASE_2EDGE))

/** @brief  Check the USART last bit.
  * @param  __LASTBIT__: specifies the USART last bit.
  * @retval None
  */
#define IS_USART_LASTBIT(__LASTBIT__) (((__LASTBIT__) == USART_LASTBIT_DISABLE) || \
                                       ((__LASTBIT__) == USART_LASTBIT_ENABLE))

/** @brief  Check the USART interrupt.
  * @param  __IT__: specifies the USART interrupt.
  * @retval None
  */
#define IS_USART_IT(__IT__) (((__IT__) == USART_IT_PE)   || ((__IT__) == USART_IT_TXE)   || \
                             ((__IT__) == USART_IT_TC)   || ((__IT__) == USART_IT_RXNE) || \
                             ((__IT__) == USART_IT_IDLE) || ((__IT__) == USART_IT_LBD)  || \
                             ((__IT__) == USART_IT_CTS)  || ((__IT__) == USART_IT_ERR)  || \
                             ((__IT__) == USART_IT_ORE)  || ((__IT__) == USART_IT_NE)   || \
                             ((__IT__) == USART_IT_FE)   || ((__IT__) == USART_IT_TXFE) || \
                             ((__IT__) == USART_IT_RXFF) || ((__IT__) == USART_IT_TXFT) || \
                             ((__IT__) == USART_IT_RXFT))

/** @brief  Check the USART flag.
  * @param  __FLAG__: specifies the USART flag.
  * @retval None
  */
#define IS_USART_FLAG(__FLAG__) (((__FLAG__) == USART_FLAG_TXFT)  || ((__FLAG__) == USART_FLAG_RXFT)  || \
                                 ((__FLAG__) == USART_FLAG_RXFF)  || ((__FLAG__) == USART_FLAG_TXFE)  || \
                                 ((__FLAG__) == USART_FLAG_SBKF)  || ((__FLAG__) == USART_FLAG_BUSY)  || \
                                 ((__FLAG__) == USART_FLAG_ABRF)  || ((__FLAG__) == USART_FLAG_ABRE)  || \
                                 ((__FLAG__) == USART_FLAG_CTS)   || ((__FLAG__) == USART_FLAG_CTSIF) || \
                                 ((__FLAG__) == USART_FLAG_LBDF)  || ((__FLAG__) == USART_FLAG_TXE)   || \
                                 ((__FLAG__) == USART_FLAG_TXFNF) || ((__FLAG__) == USART_FLAG_TC)    || \
                                 ((__FLAG__) == USART_FLAG_RXNE)  || ((__FLAG__) == USART_FLAG_RXFNE) || \
                                 ((__FLAG__) == USART_FLAG_IDLE)  || ((__FLAG__) == USART_FLAG_ORE)   || \
                                 ((__FLAG__) == USART_FLAG_NE)    || ((__FLAG__) == USART_FLAG_FE)    || \
                                 ((__FLAG__) == USART_FLAG_PE))

/** @brief  Check the USART interrupt clear flag.
  * @param  __CLEAR__: specifies the USART interrupt clear flag.
  * @retval None
  */
#define IS_USART_CLEAR(__CLEAR__) (((__CLEAR__) == USART_CLEAR_PEF)  || ((__CLEAR__) == USART_CLEAR_FEF)   || \
                                   ((__CLEAR__) == USART_CLEAR_NEF)  || ((__CLEAR__) == USART_CLEAR_OREF) || \
                                   ((__CLEAR__) == USART_CLEAR_IDLEF) || ((__CLEAR__) == USART_CLEAR_TXFEF) || \
                                   ((__CLEAR__) == USART_CLEAR_TCF)  || ((__CLEAR__) == USART_CLEAR_LBDF) || \
                                   ((__CLEAR__) == USART_CLEAR_CTSF) || ((__CLEAR__) == USART_CLEAR_RXFTF) || \
                                   ((__CLEAR__) == USART_CLEAR_TXFTF))
/**
  * @}
  */

/* Exported macros -----------------------------------------------------------*/
/** @defgroup USART_Exported_Macros USART Exported Macros
  * @{
  */

/** @brief Reset USART handle state
  * @param  __HANDLE__: USART handle.
  * @retval None
  */
#define __HAL_USART_RESET_HANDLE_STATE(__HANDLE__)  ((__HANDLE__)->State = HAL_USART_STATE_RESET)

/** @brief  Checks whether the specified USART flag is set or not.
  * @param  __HANDLE__: specifies the USART Handle
  * @param  __FLAG__: specifies the flag to check.
  *        This parameter can be one of the following values:
  *            @arg USART_FLAG_TXFT: TXFIFO threshold flag
  *            @arg USART_FLAG_RXFT: RXFIFO threshold flag
  *            @arg USART_FLAG_RXFF: RXFIFO Full flag
  *            @arg USART_FLAG_TXFE: TXFIFO Empty flag
  *            @arg USART_FLAG_SBKF: Send break flag
  *            @arg USART_FLAG_BUSY: Busy flag
  *            @arg USART_FLAG_ABRF: Auto Baud rate flag
  *            @arg USART_FLAG_ABRE: Auto Baud rate error
  *            @arg USART_FLAG_CTS:  CTS flag
  *            @arg USART_FLAG_CTSIF: CTS interrupt flag
  *            @arg USART_FLAG_LBDF: LIN break detection flag
  *            @arg USART_FLAG_TXE:  Transmit data register empty flag
  *            @arg USART_FLAG_TC:   Transmission Complete flag
  *            @arg USART_FLAG_RXNE: Receive data register not empty flag
  *            @arg USART_FLAG_IDLE: Idle Line detection flag
  *            @arg USART_FLAG_ORE:  OverRun Error flag
  *            @arg USART_FLAG_NE:   Noise Error flag
  *            @arg USART_FLAG_FE:   Framing Error flag
  *            @arg USART_FLAG_PE:   Parity Error flag
  * @retval The new state of __FLAG__ (TRUE or FALSE).
  */
#define __HAL_USART_GET_FLAG(__HANDLE__, __FLAG__) (((__HANDLE__)->Instance->ISR & (__FLAG__)) == (__FLAG__))

/** @brief  Enables the specified USART interrupt.
  * @param  __HANDLE__: specifies the USART Handle
  * @param  __INTERRUPT__: specifies the USART interrupt source to enable.
  *          This parameter can be one of the following values:
  *            @arg USART_IT_TXE:  Transmit Data Register empty interrupt
  *            @arg USART_IT_TC:   Transmission complete interrupt
  *            @arg USART_IT_RXNE: Receive Data register not empty interrupt
  *            @arg USART_IT_IDLE: Idle line detection interrupt
  *            @arg USART_IT_PE:   Parity Error interrupt
  *            @arg USART_IT_LBD:  LIN break detection interrupt
  *            @arg USART_IT_CTS:  CTS interrupt
  *            @arg USART_IT_TXFT: TXFIFO threshold interrupt
  *            @arg USART_IT_RXFT: RXFIFO threshold interrupt
  *            @arg USART_IT_TXFE: TXFIFO empty interrupt
  *            @arg USART_IT_RXFF: RXFIFO full interrupt
  *            @arg USART_IT_ERR:  Error interrupt (frame error, noise error, overrun error)
  * @retval None
  */
#define __HAL_USART_ENABLE_IT(__HANDLE__, __INTERRUPT__)   (((((uint8)(__INTERRUPT__)) >> 5U) == 1U)? ((__HANDLE__)->Instance->CR1 |= (1U << ((__INTERRUPT__) & USART_IT_MASK))): \
                                                            ((((uint8)(__INTERRUPT__)) >> 5U) == 2U)? ((__HANDLE__)->Instance->CR2 |= (1U << ((__INTERRUPT__) & USART_IT_MASK))): \
                                                            ((__HANDLE__)->Instance->CR3 |= (1U << ((__INTERRUPT__) & USART_IT_MASK))))

/** @brief  Disables the specified USART interrupt.
  * @param  __HANDLE__: specifies the USART Handle.
  * @param  __INTERRUPT__: specifies the USART interrupt source to disable.
  *          This parameter can be one of the following values:
  *            @arg USART_IT_TXE:  Transmit Data Register empty interrupt
  *            @arg USART_IT_TC:   Transmission complete interrupt
  *            @arg USART_IT_RXNE: Receive Data register not empty interrupt
  *            @arg USART_IT_IDLE: Idle line detection interrupt
  *            @arg USART_IT_PE:   Parity Error interrupt
  *            @arg USART_IT_LBD:  LIN break detection interrupt
  *            @arg USART_IT_CTS:  CTS interrupt
  *            @arg USART_IT_TXFT: TXFIFO threshold interrupt
  *            @arg USART_IT_RXFT: RXFIFO threshold interrupt
  *            @arg USART_IT_TXFE: TXFIFO empty interrupt
  *            @arg USART_IT_RXFF: RXFIFO full interrupt
  *            @arg USART_IT_ERR:  Error interrupt (frame error, noise error, overrun error)
  * @retval None
  */
#define __HAL_USART_DISABLE_IT(__HANDLE__, __INTERRUPT__)  (((((uint8)(__INTERRUPT__)) >> 5U) == 1U)? ((__HANDLE__)->Instance->CR1 &= ~(1U << ((__INTERRUPT__) & USART_IT_MASK))): \
                                                            ((((uint8)(__INTERRUPT__)) >> 5U) == 2U)? ((__HANDLE__)->Instance->CR2 &= ~(1U << ((__INTERRUPT__) & USART_IT_MASK))): \
                                                            ((__HANDLE__)->Instance->CR3 &= ~(1U << ((__INTERRUPT__) & USART_IT_MASK))))

/** @brief  Checks whether the specified USART interrupt has occurred or not.
  * @param  __HANDLE__: specifies the USART Handle
  * @param  __IT__: specifies the USART interrupt source to check.
  *          This parameter can be one of the following values:
  *            @arg USART_IT_TXE: Transmit Data Register empty interrupt
  *            @arg USART_IT_TC:  Transmission complete interrupt
  *            @arg USART_IT_RXNE: Receive Data register not empty interrupt
  *            @arg USART_IT_IDLE: Idle line detection interrupt
  *            @arg USART_IT_ORE: OverRun Error interrupt
  *            @arg USART_IT_NE:  Noise Error interrupt
  *            @arg USART_IT_FE:  Framing Error interrupt
  *            @arg USART_IT_PE:  Parity Error interrupt
  *            @arg USART_IT_LBD: LIN break detection interrupt
  *            @arg USART_IT_CTS: CTS interrupt
  *            @arg USART_IT_TXFT: TXFIFO threshold interrupt
  *            @arg USART_IT_RXFT: RXFIFO threshold interrupt
  *            @arg USART_IT_TXFE: TXFIFO empty interrupt
  *            @arg USART_IT_RXFF: RXFIFO full interrupt
  * @retval The new state of __IT__ (TRUE or FALSE).
  */
#define __HAL_USART_GET_IT(__HANDLE__, __IT__) ((__HANDLE__)->Instance->ISR & ((uint32)1U << ((__IT__) >> 0x08U)))

/** @brief  Checks whether the specified USART interrupt source is enabled.
  * @param  __HANDLE__: specifies the USART Handle.
  * @param  __IT__: specifies the USART interrupt source to check.
  *          This parameter can be one of the following values:
  *            @arg USART_IT_TXE: Transmit Data Register empty interrupt
  *            @arg USART_IT_TC:  Transmission complete interrupt
  *            @arg USART_IT_RXNE: Receive Data register not empty interrupt
  *            @arg USART_IT_IDLE: Idle line detection interrupt
  *            @arg USART_IT_ORE: OverRun Error interrupt
  *            @arg USART_IT_NE:  Noise Error interrupt
  *            @arg USART_IT_FE:  Framing Error interrupt
  *            @arg USART_IT_PE:  Parity Error interrupt
  *            @arg USART_IT_LBD: LIN break detection interrupt
  *            @arg USART_IT_CTS: CTS interrupt
  *            @arg USART_IT_TXFT: TXFIFO threshold interrupt
  *            @arg USART_IT_RXFT: RXFIFO threshold interrupt
  *            @arg USART_IT_TXFE: TXFIFO empty interrupt
  *            @arg USART_IT_RXFF: RXFIFO full interrupt
  * @retval The new state of __IT__ (TRUE or FALSE).
  */
#define __HAL_USART_GET_IT_SOURCE(__HANDLE__, __IT__) ((((((uint8)(__IT__)) >> 5U) == 1U)? (__HANDLE__)->Instance->CR1:(((((uint8)(__IT__)) >> 5U) == 2U)? \
                                                        (__HANDLE__)->Instance->CR2 : (__HANDLE__)->Instance->CR3)) & ((uint32)1U << \
                                                        (((uint16)(__IT__)) & USART_IT_MASK)))

/** @brief  Clears the specified USART ISR flag, in setting the proper ICR register flag.
  * @param  __HANDLE__: specifies the USART Handle.
  * @param  __IT_CLEAR__: specifies the interrupt clear register flag that needs to be set
  *                       to clear the corresponding interrupt
  *          This parameter can be one of the following values:
  *            @arg USART_CLEAR_PEF: Parity Error Clear Flag
  *            @arg USART_CLEAR_FEF: Framing Error Clear Flag
  *            @arg USART_CLEAR_NEF: Noise detected Clear Flag
  *            @arg USART_CLEAR_OREF: OverRun Error Clear Flag
  *            @arg USART_CLEAR_IDLEF: IDLE line detected Clear Flag
  *            @arg USART_CLEAR_TXFEF: TXFIFO empty Clear Flag
  *            @arg USART_CLEAR_TCF: Transmission Complete Clear Flag
  *            @arg USART_CLEAR_LBDF: LIN Break Detection Clear Flag
  *            @arg USART_CLEAR_CTSF: CTS Interrupt Clear Flag
  *            @arg USART_CLEAR_RXFTF: RXFIFO threshold Clear Flag
  *            @arg USART_CLEAR_TXFTF: TXFIFO threshold Clear Flag
  * @retval None
  */
#define __HAL_USART_CLEAR_IT(__HANDLE__, __IT_CLEAR__) ((__HANDLE__)->Instance->ICR = (uint32)(__IT_CLEAR__))

/** @brief  Set a specific USART request flag.
  * @param  __HANDLE__: specifies the USART Handle.
  * @param  __REQ__: specifies the request flag to set
  *          This parameter can be one of the following values:
  *            @arg USART_RXDATA_FLUSH_REQUEST: Receive Data flush Request
  *            @arg USART_TXDATA_FLUSH_REQUEST: Transmit data flush Request
  * @retval None
  */
#define __HAL_USART_SEND_REQ(__HANDLE__, __REQ__) ((__HANDLE__)->Instance->RQR |= (uint16)(__REQ__))

/** @brief  Enable USART
  * @param  __HANDLE__: specifies the USART Handle.
  * @retval None
  */
#define __HAL_USART_ENABLE(__HANDLE__)                 ((__HANDLE__)->Instance->CR1 |= USART_CR1_UE)

/** @brief  Disable USART
  * @param  __HANDLE__: specifies the USART Handle.
  * @retval None
  */
#define __HAL_USART_DISABLE(__HANDLE__)                ((__HANDLE__)->Instance->CR1 &= ~USART_CR1_UE)

/**
  * @}
  */

/* NOTE: this header is self contained: it defines USART_HandleTypeDef and
 * declares both the core and the chip-specific extended prototypes, so no
 * additional include is required by the application. */

/* Exported functions --------------------------------------------------------*/
/** @addtogroup USART_Exported_Functions
  * @{
  */

/** @addtogroup USART_Exported_Functions_Group1
  * @{
  */
/* Initialization/de-initialization functions **********************************/
/**
  * @brief  Fills each USART_InitStruct member with its default value. (NON-BLOCKING)
  * @note   Sets the Size / Version compatibility metafields and the USART default
  *         communication parameters.
  * @param  USART_InitStruct: pointer to a USART_InitTypeDef structure.
  * @retval None
  */
void HAL_USART_StructInit(USART_InitTypeDef *USART_InitStruct);

/**
  * @brief  Initializes the USART mode according to the specified parameters in the (BLOCKING)
  *         USART_InitTypeDef and creates the associated handle.
  * @note   The configuration is validated at run time (Size / Version metafields and
  *         every configuration field) before the lock is taken: a rejected call returns
  *         HAL_ERROR with HAL_USART_ERROR_INVALID_PARAM and leaves the handle unchanged.
  *         ARCH-CONST-09: a handle that is BUSY is rejected with HAL_BUSY.
  * @param  husart: USART handle.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_Init(USART_HandleTypeDef *husart);

/**
  * @brief  DeInitializes the USART peripheral. (NON-BLOCKING)
  * @note   The low level de-initialization (MspDeInit) runs outside the locked region.
  * @param  husart: USART handle.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_DeInit(USART_HandleTypeDef *husart);

/**
  * @brief  Initializes the USART MSP (clock, GPIO alternate function, interrupt line). (NON-BLOCKING)
  * @param  husart: USART handle.
  * @retval None
  */
void HAL_USART_MspInit(USART_HandleTypeDef *husart);

/**
  * @brief  DeInitializes the USART MSP. (NON-BLOCKING)
  * @param  husart: USART handle.
  * @retval None
  */
void HAL_USART_MspDeInit(USART_HandleTypeDef *husart);

/**
  * @brief  Checks the USART idle state and moves the handle to the ready state. (NON-BLOCKING)
  * @note   ARCH-CONST-09: this is a modification entry point, so it takes the handle
  *         lock and rejects an uninitialized handle with HAL_ERROR.
  * @param  husart: USART handle.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_CheckIdleState(USART_HandleTypeDef *husart);
/**
  * @}
  */

/** @addtogroup USART_Exported_Functions_Group2
  * @{
  */
/* IO operation functions *******************************************************/
/**
  * @brief  Sends an amount of data in blocking mode. (BLOCKING)
  * @note   The handshake before each byte is the transmit data register empty
  *         flag (USART_FLAG_TXE); USART_FLAG_TC is only checked once, after the
  *         last byte, because on this device TC stays cleared until a frame has
  *         been transmitted. On timeout the handle is moved to the timeout state,
  *         HAL_USART_ERROR_TIMEOUT is reported and the transfer is aborted.
  * @param  husart: USART handle.
  * @param  pTxData: pointer to data buffer.
  * @param  Size: amount of data to be sent.
  * @param  Timeout: timeout duration in ms (HAL_MAX_DELAY = no timeout).
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_Transmit(USART_HandleTypeDef *husart, uint8 *pTxData, uint16 Size,
                                     uint32 Timeout);

/**
  * @brief  Receives an amount of data in blocking mode. (BLOCKING)
  * @note   In synchronous mode (CLKEN = 1) dummy data are transmitted to generate
  *         the clock for the slave, using the same TXE handshake as HAL_USART_Transmit().
  * @param  husart: USART handle.
  * @param  pRxData: pointer to data buffer.
  * @param  Size: amount of data to be received.
  * @param  Timeout: timeout duration in ms (HAL_MAX_DELAY = no timeout).
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_Receive(USART_HandleTypeDef *husart, uint8 *pRxData, uint16 Size,
                                    uint32 Timeout);

/**
  * @brief  Sends and receives an amount of data in blocking mode. (BLOCKING)
  * @param  husart: USART handle.
  * @param  pTxData: pointer to TX data buffer.
  * @param  pRxData: pointer to RX data buffer.
  * @param  Size: amount of data to be sent (same amount is received).
  * @param  Timeout: timeout duration in ms (HAL_MAX_DELAY = no timeout).
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_TransmitReceive(USART_HandleTypeDef *husart, uint8 *pTxData,
                                            uint8 *pRxData, uint16 Size,
                                            uint32 Timeout);

/**
  * @brief  Sends an amount of data in interrupt mode. (NON-BLOCKING / IT)
  * @param  husart: USART handle.
  * @param  pTxData: pointer to data buffer.
  * @param  Size: amount of data to be sent.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_Transmit_IT(USART_HandleTypeDef *husart, uint8 *pTxData, uint16 Size);

/**
  * @brief  Receives an amount of data in interrupt mode. (NON-BLOCKING / IT)
  * @param  husart: USART handle.
  * @param  pRxData: pointer to data buffer.
  * @param  Size: amount of data to be received.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_Receive_IT(USART_HandleTypeDef *husart, uint8 *pRxData, uint16 Size);

/**
  * @brief  Sends and receives an amount of data in interrupt mode. (NON-BLOCKING / IT)
  * @param  husart: USART handle.
  * @param  pTxData: pointer to TX data buffer.
  * @param  pRxData: pointer to RX data buffer.
  * @param  Size: amount of data to be sent/received.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_TransmitReceive_IT(USART_HandleTypeDef *husart, uint8 *pTxData,
                                               uint8 *pRxData,
                                               uint16 Size);

/**
  * @brief  Sends an amount of data in DMA mode. (NON-BLOCKING / DMA)
  * @param  husart: USART handle.
  * @param  pTxData: pointer to data buffer.
  * @param  Size: amount of data to be sent.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_Transmit_DMA(USART_HandleTypeDef *husart, uint8 *pTxData, uint16 Size);

/**
  * @brief  Receives an amount of data in DMA mode. (NON-BLOCKING / DMA)
  * @param  husart: USART handle.
  * @param  pRxData: pointer to data buffer.
  * @param  Size: amount of data to be received.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_Receive_DMA(USART_HandleTypeDef *husart, uint8 *pRxData, uint16 Size);

/**
  * @brief  Sends and receives an amount of data in DMA mode. (NON-BLOCKING / DMA)
  * @param  husart: USART handle.
  * @param  pTxData: pointer to TX data buffer.
  * @param  pRxData: pointer to RX data buffer.
  * @param  Size: amount of data to be sent/received.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_TransmitReceive_DMA(USART_HandleTypeDef *husart, uint8 *pTxData,
                                                uint8 *pRxData,
                                                uint16 Size);

/**
  * @brief  Pauses the DMA transfer. (NON-BLOCKING)
  * @note   It serves an ongoing transfer, so only an uninitialized handle is
  *         rejected (the busy states are accepted).
  * @param  husart: USART handle.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_DMAPause(USART_HandleTypeDef *husart);

/**
  * @brief  Resumes the DMA transfer. (NON-BLOCKING)
  * @note   It serves an ongoing transfer, so only an uninitialized handle is
  *         rejected (the busy states are accepted).
  * @param  husart: USART handle.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_DMAResume(USART_HandleTypeDef *husart);

/**
  * @brief  Stops the DMA transfer. (NON-BLOCKING)
  * @note   Interrupt safe by design: it takes no handle lock and applies no state
  *         gate, so that an ongoing transfer can be aborted from the error callback
  *         (which runs in the interrupt context).
  * @param  husart: USART handle.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_DMAStop(USART_HandleTypeDef *husart);

/**
  * @brief  Handles the USART interrupt request. (NON-BLOCKING)
  * @note   Interrupt context: it takes no lock and waits for nothing.
  * @param  husart: USART handle.
  * @retval None
  */
void HAL_USART_IRQHandler(USART_HandleTypeDef *husart);

/**
  * @brief  Tx transfer half completed callback. (NON-BLOCKING)
  * @param  husart: USART handle.
  * @retval None
  */
void HAL_USART_TxHalfCpltCallback(USART_HandleTypeDef *husart);

/**
  * @brief  Tx transfer completed callback. (NON-BLOCKING)
  * @param  husart: USART handle.
  * @retval None
  */
void HAL_USART_TxCpltCallback(USART_HandleTypeDef *husart);

/**
  * @brief  Rx transfer completed callback. (NON-BLOCKING)
  * @param  husart: USART handle.
  * @retval None
  */
void HAL_USART_RxCpltCallback(USART_HandleTypeDef *husart);

/**
  * @brief  Rx transfer half completed callback. (NON-BLOCKING)
  * @param  husart: USART handle.
  * @retval None
  */
void HAL_USART_RxHalfCpltCallback(USART_HandleTypeDef *husart);

/**
  * @brief  Tx and Rx transfer completed callback. (NON-BLOCKING)
  * @param  husart: USART handle.
  * @retval None
  */
void HAL_USART_TxRxCpltCallback(USART_HandleTypeDef *husart);

/**
  * @brief  USART error callback. (NON-BLOCKING)
  * @param  husart: USART handle.
  * @retval None
  */
void HAL_USART_ErrorCallback(USART_HandleTypeDef *husart);
/**
  * @}
  */

/** @addtogroup USART_Exported_Functions_Group3
  * @{
  */
/* Peripheral State functions ************************************************/
/**
  * @brief  Returns the USART state. (NON-BLOCKING)
  * @param  husart: USART handle.
  * @retval HAL_USART_StateTypeDef: the USART state.
  */
HAL_USART_StateTypeDef HAL_USART_GetState(USART_HandleTypeDef *husart);

/**
  * @brief  Returns the USART error code. (NON-BLOCKING)
  * @param  husart: USART handle.
  * @retval uint32: the USART error code (HAL_USART_ERROR_xxx).
  */
uint32 HAL_USART_GetError(USART_HandleTypeDef *husart);
/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */


/* Shared internal functions --------------------------------------------------*/
/** @defgroup USART_Shared_Internal_Functions USART Shared Internal Functions
  * @brief    Helpers shared by the core and the extended part of this driver
  *           (Tier 3). They are not part of the public API and shall not be
  *           called by the application.
  * @{
  */
/**
  * @brief  Checks whether the USART handle and its instance are valid.
  * @param  husart: USART handle.
  * @retval uint32: 1 when valid, 0 otherwise.
  */
uint32 USART_HandleIsValid(USART_HandleTypeDef *husart);

/**
  * @brief  Checks whether the handle accepts a new operation (ARCH-CONST-09).
  * @note   The busy states (BUSY / BUSY_TX / BUSY_RX / BUSY_TX_RX) reject the call
  *         with HAL_BUSY, an uninitialized handle (RESET) with HAL_ERROR, while the
  *         recoverable states (TIMEOUT / ERROR) accept it.
  * @param  husart: USART handle.
  * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
  */
HAL_StatusTypeDef USART_CheckState(USART_HandleTypeDef *husart);

/**
  * @brief  Locks the handle (RTOS mutex or single core lock flag).
  * @param  husart: USART handle.
  * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
  * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (no mutex created).
  */
HAL_StatusTypeDef USART_LockHandle(USART_HandleTypeDef *husart, uint32 Timeout);

/**
  * @brief  Unlocks the handle.
  * @param  husart: USART handle.
  * @retval None
  */
void USART_UnlockHandle(USART_HandleTypeDef *husart);
/**
  * @}
  */
/**
  * @}
  */

/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/** @addtogroup USART_Exported_Constants USART Exported Constants
  * @{
  */

/** @defgroup USART_Word_Length USART Word Length
  * @{
  */
#define USART_WORDLENGTH_6B                  ((uint32)(USART_CR1_M1 | USART_CR1_M0))  /*!< 6-bit long USART frame */
#define USART_WORDLENGTH_7B                  ((uint32)USART_CR1_M1)                  /*!< 7-bit long USART frame */
#define USART_WORDLENGTH_8B                  ((uint32)0x00000000U)                   /*!< 8-bit long USART frame */
#define USART_WORDLENGTH_9B                  ((uint32)USART_CR1_M0)                  /*!< 9-bit long USART frame */
/**
  * @}
  */

/** @defgroup USART_FIFO_Mode USART FIFO Mode
  * @{
  */
#define USART_FIFOMODE_DISABLE               ((uint32)0x00000000U)                   /*!< FIFO mode disable */
#define USART_FIFOMODE_ENABLE                ((uint32)USART_CR1_FIFOEN)              /*!< FIFO mode enable */
/**
  * @}
  */

/** @defgroup USART_TXFIFO_Threshold USART TXFIFO Threshold
  * @{
  */
#define USART_TXFIFO_THRESHOLD_1_8           ((uint32)0x00000000U)                   /*!< TXFIFO reaches 1/8 of its depth */
#define USART_TXFIFO_THRESHOLD_1_4           ((uint32)0x04000000U)                   /*!< TXFIFO reaches 1/4 of its depth */
#define USART_TXFIFO_THRESHOLD_1_2           ((uint32)0x08000000U)                   /*!< TXFIFO reaches 1/2 of its depth */
#define USART_TXFIFO_THRESHOLD_3_4           ((uint32)0x0C000000U)                   /*!< TXFIFO reaches 3/4 of its depth */
#define USART_TXFIFO_THRESHOLD_7_8           ((uint32)0x10000000U)                   /*!< TXFIFO reaches 7/8 of its depth */
#define USART_TXFIFO_THRESHOLD_8_8           ((uint32)0x14000000U)                   /*!< TXFIFO becomes empty */
/**
  * @}
  */

/** @defgroup USART_RXFIFO_Threshold USART RXFIFO Threshold
  * @{
  */
#define USART_RXFIFO_THRESHOLD_1_8           ((uint32)0x00000000U)                   /*!< RXFIFO reaches 1/8 of its depth */
#define USART_RXFIFO_THRESHOLD_1_4           ((uint32)0x00400000U)                   /*!< RXFIFO reaches 1/4 of its depth */
#define USART_RXFIFO_THRESHOLD_1_2           ((uint32)0x00800000U)                   /*!< RXFIFO reaches 1/2 of its depth */
#define USART_RXFIFO_THRESHOLD_3_4           ((uint32)0x00C00000U)                   /*!< RXFIFO reaches 3/4 of its depth */
#define USART_RXFIFO_THRESHOLD_7_8           ((uint32)0x01000000U)                   /*!< RXFIFO reaches 7/8 of its depth */
#define USART_RXFIFO_THRESHOLD_8_8           ((uint32)0x01400000U)                   /*!< RXFIFO becomes full */
/**
  * @}
  */

/** @defgroup USART_Slave_Mode USART SPI Slave Mode
  * @{
  */
#define USART_SLAVEMODE_DISABLE              ((uint32)0x00000000U)                   /*!< USART SPI Slave Mode Disable */
#define USART_SLAVEMODE_ENABLE               ((uint32)0x00000001U)                   /*!< USART SPI Slave Mode Enable */
#define IS_USART_SLAVEMODE_STATE(__STATE__) (((__STATE__) == USART_SLAVEMODE_DISABLE) || \
                                             ((__STATE__) == USART_SLAVEMODE_ENABLE))
/**
  * @}
  */

/** @defgroup USART_LIN_Mode USART LIN Mode
  * @{
  */
#define USART_LIN_DISABLE                    ((uint32)0x00000000U)                   /*!< Local Interconnect Network disable */
#define USART_LIN_ENABLE                     ((uint32)USART_CR2_LINEN)               /*!< Local Interconnect Network enable */
#define IS_USART_LIN(__LIN__) (((__LIN__) == USART_LIN_DISABLE) || \
                               ((__LIN__) == USART_LIN_ENABLE))
/**
  * @}
  */

/** @defgroup USART_DMA_Request USART DMA Requests
  * @note  These requests are managed internally by the DMA transfer APIs
  *        (HAL_USART_Transmit_DMA(), HAL_USART_Receive_DMA(), ...) once the
  *        AS32X601 DMA HAL driver is available. They are exported to keep
  *        backward compatibility with existing code.
  * @{
  */
#define USART_DMAReq_TX                      ((uint32)0x00000020U)                   /*!< USART DMA TX enabled */
#define USART_DMAReq_RX                      ((uint32)0x00000010U)                   /*!< USART DMA RX enabled */
#define IS_USART_DMAREQ(__DMAREQ__) ((((__DMAREQ__) & (uint32)0xFFFFFFCFU) == 0x00U) && ((__DMAREQ__) != (uint32)0x00U))
/**
  * @}
  */

/** @defgroup USART_NSS USART Slave Select Management
  * @{
  */
#define USART_NSS_HARDWARE                   ((uint32)0x00000000U)                   /*!< USART Hardware NSS management */
#define USART_NSS_SOFTWARE                   ((uint32)USART_CR2_DIS_NSS)             /*!< USART Software NSS management */
/**
  * @}
  */

/** @defgroup USART_LIN_Break_Detection_Length USART LIN Break Detection Length
  * @{
  */
#define USART_LINBREAKDETECTLENGTH_11B       ((uint32)0x00000006U)                   /*!< LIN 11-bit break detection length */
#define USART_LINBREAKDETECTLENGTH_12B       ((uint32)0x00000004U)                   /*!< LIN 12-bit break detection length */
#define USART_LINBREAKDETECTLENGTH_13B       ((uint32)0x00000000U)                   /*!< LIN 13-bit break detection length */
#define USART_LINBREAKDETECTLENGTH_14B       ((uint32)0x00000002U)                   /*!< LIN 14-bit break detection length */
/**
  * @}
  */

/** @defgroup USART_Half_Duplex USART Half Duplex Selection
  * @{
  */
#define USART_HALF_DUPLEX_DISABLE            ((uint32)0x00000000U)                   /*!< USART half-duplex disabled */
#define USART_HALF_DUPLEX_ENABLE             ((uint32)USART_CR3_HDSEL)               /*!< USART half-duplex enabled */
/**
  * @}
  */

/** @defgroup USART_One_Bit_Sampling USART One Bit Sampling Method
  * @{
  */
#define USART_ONE_BIT_SAMPLE_ENABLE          ((uint32)USART_CR3_ONEBIT)              /*!< One-bit sampling enable */
#define USART_THREE_BIT_SAMPLE_ENABLE        ((uint32)0x00000000U)                   /*!< Three-bit sampling enable */
/**
  * @}
  */

/** @defgroup USART_Overrun_Detection USART Overrun Detection
  * @{
  */
#define USART_ADVFEATURE_OVERRUN_ENABLE      ((uint32)0x00000000U)                   /*!< RX overrun enable */
#define USART_ADVFEATURE_OVERRUN_DISABLE     ((uint32)USART_CR3_OVRDIS)              /*!< RX overrun disable */
/**
  * @}
  */

/** @defgroup USART_Advanced_Features_Initialization_Type USART Advanced Features Initialization Type
  * @{
  */
#define USART_ADVFEATURE_NO_INIT             ((uint32)0x00000000U)                   /*!< No advanced feature initialization */
#define USART_ADVFEATURE_TXINVERT_INIT       ((uint32)0x00000001U)                   /*!< TX pin active level inversion */
#define USART_ADVFEATURE_RXINVERT_INIT       ((uint32)0x00000002U)                   /*!< RX pin active level inversion */
#define USART_ADVFEATURE_DATAINVERT_INIT     ((uint32)0x00000004U)                   /*!< Binary data inversion */
#define USART_ADVFEATURE_RXOVERRUNDISABLE_INIT ((uint32)0x00000008U)                 /*!< RX overrun disable */
#define USART_ADVFEATURE_AUTOBAUDRATE_INIT   ((uint32)0x00000010U)                   /*!< Auto Baud rate detection initialization */
#define USART_ADVFEATURE_MSBFIRST_INIT       ((uint32)0x00000020U)                   /*!< Most significant bit sent/received first */
/**
  * @}
  */

/** @defgroup USART_TX_Pin_Level_Inversion USART TX Pin Active Level Inversion
  * @{
  */
#define USART_ADVFEATURE_TXINVERT_DISABLE    ((uint32)0x00000000U)                   /*!< TX pin active level inversion disable */
#define USART_ADVFEATURE_TXINVERT_ENABLE     ((uint32)USART_CR2_TXINV)               /*!< TX pin active level inversion enable */
/**
  * @}
  */

/** @defgroup USART_RX_Pin_Level_Inversion USART RX Pin Active Level Inversion
  * @{
  */
#define USART_ADVFEATURE_RXINVERT_DISABLE    ((uint32)0x00000000U)                   /*!< RX pin active level inversion disable */
#define USART_ADVFEATURE_RXINVERT_ENABLE     ((uint32)USART_CR2_RXINV)               /*!< RX pin active level inversion enable */
/**
  * @}
  */

/** @defgroup USART_Binary_Data_Inversion USART Binary Data Inversion
  * @{
  */
#define USART_ADVFEATURE_DATAINVERT_DISABLE  ((uint32)0x00000000U)                   /*!< Binary data inversion disable */
#define USART_ADVFEATURE_DATAINVERT_ENABLE   ((uint32)USART_CR2_DATAINV)             /*!< Binary data inversion enable */
/**
  * @}
  */

/** @defgroup USART_MSB_First USART MSB First
  * @{
  */
#define USART_ADVFEATURE_MSBFIRST_DISABLE    ((uint32)0x00000000U)                   /*!< Most significant bit sent/received first disable */
#define USART_ADVFEATURE_MSBFIRST_ENABLE     ((uint32)USART_CR2_MSBFIRST)            /*!< Most significant bit sent/received first enable */
/**
  * @}
  */

/** @defgroup USART_Auto_Baud_Rate USART Auto Baud Rate Enable
  * @{
  */
#define USART_ADVFEATURE_AUTOBAUDRATE_DISABLE ((uint32)0x00000000U)                  /*!< RX Auto Baud rate detection disable */
#define USART_ADVFEATURE_AUTOBAUDRATE_ENABLE  ((uint32)USART_CR2_ABREN)              /*!< RX Auto Baud rate detection enable */
/**
  * @}
  */

/** @defgroup USART_Auto_Baud_Rate_Mode USART Auto Baud Rate Mode
  * @{
  */
#define USART_ADVFEATURE_AUTOBAUDRATE_ON0X55FRAME ((uint32)USART_CR2_ABRMODE)        /*!< Auto Baud rate detection on 0x55 frame detection */
/**
  * @}
  */

/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/
/** @addtogroup USART_Private_Macros USART Private Macros
  * @{
  */

/** @brief  Check the USART word length.
  * @param  __LENGTH__: specifies the USART word length.
  * @retval None
  */
#define IS_USART_WORD_LENGTH(__LENGTH__) (((__LENGTH__) == USART_WORDLENGTH_6B) || \
                                          ((__LENGTH__) == USART_WORDLENGTH_7B) || \
                                          ((__LENGTH__) == USART_WORDLENGTH_8B) || \
                                          ((__LENGTH__) == USART_WORDLENGTH_9B))

/** @brief  Check the USART FIFO mode state.
  * @param  __STATE__: specifies the USART FIFO mode state.
  * @retval None
  */
#define IS_USART_FIFOMODE_STATE(__STATE__) (((__STATE__) == USART_FIFOMODE_DISABLE) || \
                                            ((__STATE__) == USART_FIFOMODE_ENABLE))

/** @brief  Check the USART TXFIFO threshold.
  * @param  __THRESHOLD__: specifies the USART TXFIFO threshold.
  * @retval None
  */
#define IS_USART_TXFIFO_THRESHOLD(__THRESHOLD__) (((__THRESHOLD__) == USART_TXFIFO_THRESHOLD_1_8) || \
                                                  ((__THRESHOLD__) == USART_TXFIFO_THRESHOLD_1_4) || \
                                                  ((__THRESHOLD__) == USART_TXFIFO_THRESHOLD_1_2) || \
                                                  ((__THRESHOLD__) == USART_TXFIFO_THRESHOLD_3_4) || \
                                                  ((__THRESHOLD__) == USART_TXFIFO_THRESHOLD_7_8) || \
                                                  ((__THRESHOLD__) == USART_TXFIFO_THRESHOLD_8_8))

/** @brief  Check the USART RXFIFO threshold.
  * @param  __THRESHOLD__: specifies the USART RXFIFO threshold.
  * @retval None
  */
#define IS_USART_RXFIFO_THRESHOLD(__THRESHOLD__) (((__THRESHOLD__) == USART_RXFIFO_THRESHOLD_1_8) || \
                                                  ((__THRESHOLD__) == USART_RXFIFO_THRESHOLD_1_4) || \
                                                  ((__THRESHOLD__) == USART_RXFIFO_THRESHOLD_1_2) || \
                                                  ((__THRESHOLD__) == USART_RXFIFO_THRESHOLD_3_4) || \
                                                  ((__THRESHOLD__) == USART_RXFIFO_THRESHOLD_7_8) || \
                                                  ((__THRESHOLD__) == USART_RXFIFO_THRESHOLD_8_8))

/** @brief  Check the USART NSS configuration.
  * @param  __NSS__: specifies the USART NSS configuration.
  * @retval None
  */
#define IS_USART_NSS(__NSS__) (((__NSS__) == USART_NSS_HARDWARE) || \
                               ((__NSS__) == USART_NSS_SOFTWARE))

/** @brief  Check the USART LIN break detection length.
  * @param  __LENGTH__: specifies the USART LIN break detection length.
  * @retval None
  */
#define IS_USART_LIN_BREAK_DETECT_LENGTH(__LENGTH__) (((__LENGTH__) == USART_LINBREAKDETECTLENGTH_11B) || \
                                                      ((__LENGTH__) == USART_LINBREAKDETECTLENGTH_12B) || \
                                                      ((__LENGTH__) == USART_LINBREAKDETECTLENGTH_13B) || \
                                                      ((__LENGTH__) == USART_LINBREAKDETECTLENGTH_14B))

/** @brief  Check the USART half duplex state.
  * @param  __HDSEL__: specifies the USART half duplex state.
  * @retval None
  */
#define IS_USART_HALF_DUPLEX(__HDSEL__) (((__HDSEL__) == USART_HALF_DUPLEX_DISABLE) || \
                                         ((__HDSEL__) == USART_HALF_DUPLEX_ENABLE))

/** @brief  Check the USART one bit sampling state.
  * @param  __ONEBIT__: specifies the USART one bit sampling state.
  * @retval None
  */
#define IS_USART_ONE_BIT_SAMPLE(__ONEBIT__) (((__ONEBIT__) == USART_ONE_BIT_SAMPLE_ENABLE) || \
                                             ((__ONEBIT__) == USART_THREE_BIT_SAMPLE_ENABLE))

/** @brief  Check the USART overrun state.
  * @param  __OVERRUN__: specifies the USART overrun state.
  * @retval None
  */
#define IS_USART_OVERRUN(__OVERRUN__) (((__OVERRUN__) == USART_ADVFEATURE_OVERRUN_ENABLE) || \
                                       ((__OVERRUN__) == USART_ADVFEATURE_OVERRUN_DISABLE))

/** @brief  Check the USART advanced features initialization.
  * @param  __INIT__: specifies the USART advanced features initialization.
  * @retval None
  */
#define IS_USART_ADVFEATURE_INIT(__INIT__) ((__INIT__) <= (USART_ADVFEATURE_NO_INIT | \
                                                           USART_ADVFEATURE_TXINVERT_INIT | \
                                                           USART_ADVFEATURE_RXINVERT_INIT | \
                                                           USART_ADVFEATURE_DATAINVERT_INIT | \
                                                           USART_ADVFEATURE_RXOVERRUNDISABLE_INIT | \
                                                           USART_ADVFEATURE_AUTOBAUDRATE_INIT | \
                                                           USART_ADVFEATURE_MSBFIRST_INIT))

/** @brief  Check the USART TX pin level inversion.
  * @param  __TXINV__: specifies the USART TX pin level inversion.
  * @retval None
  */
#define IS_USART_ADVFEATURE_TXINV(__TXINV__) (((__TXINV__) == USART_ADVFEATURE_TXINVERT_DISABLE) || \
                                              ((__TXINV__) == USART_ADVFEATURE_TXINVERT_ENABLE))

/** @brief  Check the USART RX pin level inversion.
  * @param  __RXINV__: specifies the USART RX pin level inversion.
  * @retval None
  */
#define IS_USART_ADVFEATURE_RXINV(__RXINV__) (((__RXINV__) == USART_ADVFEATURE_RXINVERT_DISABLE) || \
                                              ((__RXINV__) == USART_ADVFEATURE_RXINVERT_ENABLE))

/** @brief  Check the USART binary data inversion.
  * @param  __DATAINV__: specifies the USART binary data inversion.
  * @retval None
  */
#define IS_USART_ADVFEATURE_DATAINV(__DATAINV__) (((__DATAINV__) == USART_ADVFEATURE_DATAINVERT_DISABLE) || \
                                                  ((__DATAINV__) == USART_ADVFEATURE_DATAINVERT_ENABLE))

/** @brief  Check the USART MSB first state.
  * @param  __MSBFIRST__: specifies the USART MSB first state.
  * @retval None
  */
#define IS_USART_ADVFEATURE_MSBFIRST(__MSBFIRST__) (((__MSBFIRST__) == USART_ADVFEATURE_MSBFIRST_DISABLE) || \
                                                    ((__MSBFIRST__) == USART_ADVFEATURE_MSBFIRST_ENABLE))

/** @brief  Check the USART auto Baud rate state.
  * @param  __AUTOBAUDRATE__: specifies the USART auto Baud rate state.
  * @retval None
  */
#define IS_USART_ADVFEATURE_AUTOBAUDRATE(__AUTOBAUDRATE__) (((__AUTOBAUDRATE__) == USART_ADVFEATURE_AUTOBAUDRATE_DISABLE) || \
                                                            ((__AUTOBAUDRATE__) == USART_ADVFEATURE_AUTOBAUDRATE_ENABLE))

/** @brief  Check the USART auto Baud rate mode.
  * @param  __MODE__: specifies the USART auto Baud rate mode.
  * @retval None
  */
#define IS_USART_ADVFEATURE_AUTOBAUDRATEMODE(__MODE__) ((__MODE__) == USART_ADVFEATURE_AUTOBAUDRATE_ON0X55FRAME)

/** @brief  Computes the USART mask to apply to retrieve the received data
  *         according to the word length and to the parity bits activation.
  *         If PCE = 1, the parity bit is not included in the data extracted
  *         by the reception API().
  *         This masking operation is not carried out in the case of
  *         DMA transfers.
  * @param  __HANDLE__: specifies the USART Handle
  * @retval none
  */
#define __HAL_USART_MASK_COMPUTATION(__HANDLE__)                      \
  do {                                                                \
  if ((__HANDLE__)->Init.WordLength == USART_WORDLENGTH_9B)           \
  {                                                                   \
     if ((__HANDLE__)->Init.Parity == USART_PARITY_NONE)              \
     {                                                                \
        (__HANDLE__)->Mask = 0x01FFU;                                 \
     }                                                                \
     else                                                             \
     {                                                                \
        (__HANDLE__)->Mask = 0x00FFU;                                 \
     }                                                                \
  }                                                                   \
  else if ((__HANDLE__)->Init.WordLength == USART_WORDLENGTH_8B)      \
  {                                                                   \
     if ((__HANDLE__)->Init.Parity == USART_PARITY_NONE)              \
     {                                                                \
        (__HANDLE__)->Mask = 0x00FFU;                                 \
     }                                                                \
     else                                                             \
     {                                                                \
        (__HANDLE__)->Mask = 0x007FU;                                 \
     }                                                                \
  }                                                                   \
  else if ((__HANDLE__)->Init.WordLength == USART_WORDLENGTH_7B)      \
  {                                                                   \
     if ((__HANDLE__)->Init.Parity == USART_PARITY_NONE)              \
     {                                                                \
        (__HANDLE__)->Mask = 0x007FU;                                 \
     }                                                                \
     else                                                             \
     {                                                                \
        (__HANDLE__)->Mask = 0x003FU;                                 \
     }                                                                \
  }                                                                   \
  else if ((__HANDLE__)->Init.WordLength == USART_WORDLENGTH_6B)      \
  {                                                                   \
     if ((__HANDLE__)->Init.Parity == USART_PARITY_NONE)              \
     {                                                                \
        (__HANDLE__)->Mask = 0x003FU;                                 \
     }                                                                \
     else                                                             \
     {                                                                \
        (__HANDLE__)->Mask = 0x001FU;                                 \
     }                                                                \
  }                                                                   \
} while(0)

/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/
/** @addtogroup USART_Exported_Functions
  * @{
  */

/** @addtogroup USART_Exported_Functions_Group1
  * @{
  */
/* Configuration functions ****************************************************/
/**
  * @brief  Initializes the USART peripheral clock according to the specified (NON-BLOCKING)
  *         parameters in the USART_ClockInitTypeDef.
  * @param  husart: USART handle.
  * @param  pClockInit: pointer to a USART_ClockInitTypeDef structure.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_ConfigClock(USART_HandleTypeDef *husart,
                                          USART_ClockInitTypeDef *pClockInit);
/**
  * @brief  Configures the USART peripheral advanced features. (NON-BLOCKING)
  * @note   The register access sequence is shared with the base driver through
  *         USART_ConfigAdvFeatureInternal() (Tier 3), so that HAL_USART_Init()
  *         can program the advanced features inside its locked region without
  *         calling a public API.
  * @param  husart: USART handle.
  * @param  pAdvFeatureInit: pointer to a USART_AdvFeatureInitTypeDef structure.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_ConfigAdvFeature(USART_HandleTypeDef *husart,
                                               USART_AdvFeatureInitTypeDef *pAdvFeatureInit);

/* Default value helpers (backward compatibility) ****************************/

/* HAL_USART_StructInit() used to be duplicated here as a
   backward compatible helper; it is identical to the core
   HAL_USART_StructInit() (only the default baud rate differed,
   9600 vs 115200), so the merge keeps the core function. */
/**
  * @brief  Fills the USART_ClockInitTypeDef structure with the default values. (NON-BLOCKING)
  * @param  pClockInit: pointer to a USART_ClockInitTypeDef structure.
  * @retval None
  */
void HAL_USART_ClockStructInit(USART_ClockInitTypeDef *pClockInit);
/**
  * @}
  */

/** @addtogroup USART_Exported_Functions_Group2
  * @note   The interfaces of this group that program bits which are only
  *         writable while the instance is disabled (the FIFO mode, the FIFO
  *         thresholds, the slave mode and the NSS management) save the CR1 UE
  *         bit, disable the instance for the update and restore the saved
  *         state afterwards, so an instance that the user had enabled stays
  *         enabled and one that was disabled is never enabled by them. The
  *         LIN mode and the sampling method interfaces do not need the
  *         instance to be disabled.
  * @{
  */
/* FIFO mode functions ********************************************************/
/**
  * @brief  Enables the USART FIFO mode. (NON-BLOCKING)
  * @param  husart: USART handle.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_EnableFIFO(USART_HandleTypeDef *husart);
/**
  * @brief  Disables the USART FIFO mode. (NON-BLOCKING)
  * @param  husart: USART handle.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_DisableFIFO(USART_HandleTypeDef *husart);
/**
  * @brief  Sets the USART TX FIFO threshold. (NON-BLOCKING)
  * @param  husart: USART handle.
  * @param  Threshold: TX FIFO threshold value.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_SetTxFIFOThreshold(USART_HandleTypeDef *husart, uint32 Threshold);
/**
  * @brief  Sets the USART RX FIFO threshold. (NON-BLOCKING)
  * @param  husart: USART handle.
  * @param  Threshold: RX FIFO threshold value.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_SetRxFIFOThreshold(USART_HandleTypeDef *husart, uint32 Threshold);

/* SPI slave mode functions ***************************************************/
/**
  * @brief  Enables the SPI slave mode. (NON-BLOCKING)
  * @param  husart: USART handle.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_EnableSlaveMode(USART_HandleTypeDef *husart);
/**
  * @brief  Disables the SPI slave mode. (NON-BLOCKING)
  * @param  husart: USART handle.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_DisableSlaveMode(USART_HandleTypeDef *husart);
/**
  * @brief  Configures the NSS pin in SPI slave mode. (NON-BLOCKING)
  * @param  husart: USART handle.
  * @param  NSSConfig: specifies the NSS configuration (USART_NSS_*).
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_ConfigNSS(USART_HandleTypeDef *husart, uint32 NSSConfig);

/* LIN mode functions *********************************************************/
/**
  * @brief  Enables or disables the LIN mode. (NON-BLOCKING)
  * @param  husart: USART handle.
  * @param  NewState: ENABLE or DISABLE.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_LINCmd(USART_HandleTypeDef *husart, FunctionalState NewState);
/**
  * @brief  Sets the LIN break detection length. (NON-BLOCKING)
  * @param  husart: USART handle.
  * @param  LINBreakDetectLength: USART_LINBREAK_* value.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_LINBreakDetectLengthConfig(USART_HandleTypeDef *husart,
                                                         uint32 LINBreakDetectLength);

/* Other extended functions ***************************************************/
/**
  * @brief  Enables or disables the half-duplex mode. (NON-BLOCKING)
  * @param  husart: USART handle.
  * @param  NewState: ENABLE or DISABLE.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_HalfDuplexCmd(USART_HandleTypeDef *husart, FunctionalState NewState);
/**
  * @brief  Enables or disables the one bit sampling method. (NON-BLOCKING)
  * @param  husart: USART handle.
  * @param  NewState: ENABLE or DISABLE.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_OneBitMethodCmd(USART_HandleTypeDef *husart,
                                              FunctionalState NewState);
/**
  * @brief  Transmits a break frame. (NON-BLOCKING)
  * @param  husart: USART handle.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_SendBreak(USART_HandleTypeDef *husart);
/**
  * @brief  Requests the auto baud rate detection. (NON-BLOCKING)
  * @param  husart: USART handle.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_AutoBaudRateRequest(USART_HandleTypeDef *husart);
/**
  * @brief  Flushes the USART RX data. (NON-BLOCKING)
  * @param  husart: USART handle.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_RxDataFlush(USART_HandleTypeDef *husart);
/**
  * @brief  Flushes the USART TX data. (NON-BLOCKING)
  * @param  husart: USART handle.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_USART_TxDataFlush(USART_HandleTypeDef *husart);
/**
  * @}
  */

/**
  * @}
  */

/**
  */


/* Shared internal functions --------------------------------------------------*/
/** @addtogroup USART_Shared_Internal_Functions USART Shared Internal Functions
  * @brief    Helpers shared by the extended and the core part of this driver
  *           (Tier 3). They are not part of the public API and shall not be
  *           called by the application.
  * @{
  */
/**
  * @brief  Programs the USART advanced features (register access only).
  * @note   It performs no validation, takes no lock and applies no state gate:
  *         the caller (the public wrapper or HAL_USART_Init()) owns the handle
  *         check and the lock.
  * @param  husart: USART handle.
  * @param  pAdvFeatureInit: pointer to a USART_AdvFeatureInitTypeDef structure.
  * @retval HAL status
  */
HAL_StatusTypeDef USART_ConfigAdvFeatureInternal(USART_HandleTypeDef *husart,
                                                   USART_AdvFeatureInitTypeDef *pAdvFeatureInit);
/**
  * @}
  */
/**
  */

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_USART_H */

/************************ (C) COPYRIGHT ANSILIC *****END OF FILE****/