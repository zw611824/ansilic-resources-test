/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_mpu.c
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.3
 * Date:   2026/10/12
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.1     apply the resource lock / RTOS rules:
 *                                                       run the MSP callbacks outside the
 *                                                       locked region, add a Timeout and a
 *                                                       NULL-mutex guard to the lock helper,
 *                                                       add the busy / reset state gate,
 *                                                       return HAL_StatusTypeDef from the
 *                                                       channel control setters with
 *                                                       run-time parameter validation, and
 *                                                       keep the write protection off the
 *                                                       I-Port register block of MPU0
 *     ANSILIC APPLICATION GROUP  2026/09/21     1.2     add the configuration read-back
 *                                                       interfaces (GetAddressRange /
 *                                                       GetChannelConfig) and the whole
 *                                                       instance reset (ResetInstance),
 *                                                       verify the programmed registers in
 *                                                       Init (HAL_MPU_ERROR_HARDWARE), type
 *                                                       the instance fields as
 *                                                       HAL_MPU_InstanceTypeDef and document
 *                                                       which I-Port registers the D-Port
 *                                                       type would reach on MPU0
 *     ANSILIC APPLICATION GROUP  2026/10/12     1.3     implement the capabilities declared by the V1.3 header: add the not-supported
 *                                                       error code HAL_MPU_ERROR_NOT_SUPPORTED and reject a write protection request
 *                                                       addressing MPU0 in HAL_MPU_WriteProtectCmd() and HAL_MPU_Init() instead of dropping
 *                                                       it silently, close the addressed channel before a new address range is programmed
 *                                                       (a zero channel enable request restores the enable state the channel had before it
 *                                                       was closed), clear the violation status of a single channel (HAL_MPU_ClearStatus())
 *                                                       and of the whole instance (HAL_MPU_ResetInstance()) with the write-one-to-clear
 *                                                       channel mask instead of a read-modify-write, and check the instance binding of the
 *                                                       read-only state and error reporting interfaces
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Memory Protection Unit
 *                  (MPU) of the AS32x601:
 *                  - Initialization and de-initialization;
 *                  - Channel management: address range setting, channel
 *                    enable / disable, write / read protection enable,
 *                    whole instance reset;
 *                  - Configuration read-back: address range and channel
 *                    configuration query;
 *                  - Status management: write / read protection status
 *                    query and clear;
 *                  - State and error reporting.
 *
 *                  Typical usage of the MPU:
 *                  (#) Fill the MPU_InitTypeDef with HAL_MPU_StructInit(),
 *                      set the Instance, Channel, the address range and the
 *                      protection / enable flags, then call HAL_MPU_Init()
 *                      with the handle;
 *                  (#) Optionally re-configure at runtime with
 *                      HAL_MPU_SetAddressRange() / HAL_MPU_Cmd() /
 *                      HAL_MPU_WriteProtectCmd() /
 *                      HAL_MPU_ReadProtectCmd();
 *                  (#) Query the protection status with
 *                      HAL_MPU_GetWriteProtectStatus() /
 *                      HAL_MPU_GetReadProtectStatus() and clear it with
 *                      HAL_MPU_ClearStatus(); the same interfaces report the
 *                      violation status (WPTS / RPTS), while the enable bits
 *                      are read back with HAL_MPU_GetChannelConfig();
 *                  (#) Verify the programmed configuration with
 *                      HAL_MPU_GetAddressRange() / HAL_MPU_GetChannelConfig()
 *                      and clear all the channels of the instance with
 *                      HAL_MPU_ResetInstance().
 *
 *                  All the register writing interfaces take the handle lock
 *                  and reject a call when the handle is busy (an operation is
 *                  ongoing in another context) or not initialized. The single
 *                  bit status queries are lock-free, so they are callable from
 *                  an interrupt context, while the configuration read-back
 *                  interfaces take the lock so that the multi register
 *                  snapshot they return is consistent.
 */
#include "as32x601_hal.h"          /* HAL_StatusTypeDef / HAL_MAX_DELAY / UNUSED */
#include "as32x601_hal_mpu.h"      /* MPU HAL API and register macros          */

/* The HAL_MPU_MODULE_ENABLED switch is provided by the user configuration
 * file (as32x601_hal_conf.h, included above through as32x601_hal.h): the
 * whole implementation is compiled only while the module is enabled. */
#ifdef HAL_MPU_MODULE_ENABLED

/* Private function prototypes -----------------------------------------------*/
static uint32 MPU_HandleIsValid(HAL_MPU_HandleTypeDef *hmpu);
static HAL_StatusTypeDef MPU_CheckState(HAL_MPU_HandleTypeDef *hmpu);
static uint32 MPU_GetChannelBase(HAL_MPU_InstanceTypeDef Instance);
static uint32 MPU_GetChannelCount(HAL_MPU_InstanceTypeDef Instance);
static uint32 MPU_GetChannelEnableBit(HAL_MPU_InstanceTypeDef Instance, uint32 Channel);
static uint32 MPU_GetReadProtectionEnableBit(HAL_MPU_InstanceTypeDef Instance, uint32 Channel);
static uint32 MPU_GetWriteProtectionEnableBit(HAL_MPU_InstanceTypeDef Instance, uint32 Channel);
static void MPU_SetChannelEnableBit(HAL_MPU_InstanceTypeDef Instance, uint32 Channel, uint32 NewState);

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Check whether a MPU handle and its instance are valid.
 * @note   The instance of the handle is validated as well: an out of range
 *         instance would be mapped onto the MPU0 register block by
 *         HAL_MPU_GetRegBlock() and, through the D-Port type, would address
 *         the wrong registers of the I-Port layout (the WPTEN member of the
 *         D-Port type is at the offset of the I-Port RPTEN register).
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
static uint32 MPU_HandleIsValid(HAL_MPU_HandleTypeDef *hmpu)
{
    if (hmpu == NULL_PTR)
    {
        return 0U;
    }

    if (IS_MPU_INSTANCE(hmpu->Instance) == 0U)
    {
        return 0U;
    }

    return 1U;
}

/**
 * @brief  Check whether the handle accepts a new operation.
 * @note   Architecture constraint ARCH-CONST-09: a handle that is BUSY (an
 *         operation is ongoing in another context) rejects any other operation
 *         with HAL_BUSY, and a handle that is not initialized (RESET) requires
 *         HAL_MPU_Init() first and is rejected with HAL_ERROR. The recoverable
 *         state ERROR accepts a new operation directly (the entry point of the
 *         operation programs the registers again, so that no DeInit / Init
 *         round trip is required).
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK (accepted) / HAL_BUSY / HAL_ERROR.
 */
static HAL_StatusTypeDef MPU_CheckState(HAL_MPU_HandleTypeDef *hmpu)
{
    if (hmpu->State == HAL_MPU_STATE_BUSY)
    {
        return HAL_BUSY;
    }

    if (hmpu->State == HAL_MPU_STATE_RESET)
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Returns the base address of the channel register array of a MPU
 *         instance.
 * @note   The channel array starts right after the port status registers:
 *         at offset 0x0C for the I-Port (MPU0, 3 control/status registers)
 *         and at offset 0x14 for the D-Port (MPU1..MPU4, 5 control/status
 *         registers). Each channel occupies 8 bytes (SADDR / EADDR).
 * @param  Instance: MPU instance (HAL_MPU_INSTANCE_0..4).
 * @retval uint32: base address of the channel register array.
 */
static uint32 MPU_GetChannelBase(HAL_MPU_InstanceTypeDef Instance)
{
    uint32 base = (uint32)HAL_MPU_GetRegBlock(Instance);

    if (Instance == HAL_MPU_INSTANCE_0_IBUS)
    {
        base += 0x0CU;
    }
    else
    {
        base += 0x14U;
    }

    return base;
}

/**
 * @brief  Returns the number of channels of a MPU instance.
 * @note   MPU0/1/2 expose 16 channels, MPU3 (DMA0) and MPU4 (DMA1) 8 channels,
 *         the same mapping the IS_MPU_CHANNEL() macro validates.
 * @param  Instance: MPU instance (HAL_MPU_INSTANCE_0..4).
 * @retval uint32: number of channels of the instance.
 */
static uint32 MPU_GetChannelCount(HAL_MPU_InstanceTypeDef Instance)
{
    if ((Instance == HAL_MPU_INSTANCE_3_DMA0) || (Instance == HAL_MPU_INSTANCE_4_DMA1))
    {
        return 8U;
    }

    return 16U;
}

/**
 * @brief  Program the write protection bit of a channel.
 * @note   The write protection only exists on the D-Port instances
 *         (MPU1..MPU4). MPU0 (I-Port) has no write protection register: on
 *         MPU0 the request is ignored, because the WPTEN member of the D-Port
 *         type resolves to the offset 0x04, which is the RPTEN register of the
 *         I-Port layout - programming it would corrupt the read protection of
 *         MPU0.
 * @param  Instance: MPU instance (HAL_MPU_INSTANCE_0..4).
 * @param  Channel: channel index (0..15, MPU3/4: 0..7).
 * @param  NewState: MPU_ENABLE or MPU_DISABLE.
 * @retval None
 */
static void MPU_SetWriteProtectionBit(HAL_MPU_InstanceTypeDef Instance, uint32 Channel, uint32 NewState)
{
    if (IS_MPU_WP_INSTANCE(Instance) == 0U)
    {
        /* MPU0 has no write protection hardware */
        return;
    }

    if (NewState != MPU_DISABLE)
    {
        /* Enable the write protection */
        HAL_MPU_GetRegBlock(Instance)->WPTEN |= (1UL << Channel);
    }
    else
    {
        /* Disable the write protection */
        HAL_MPU_GetRegBlock(Instance)->WPTEN &= ~(1UL << Channel);
    }
}

/**
 * @brief  Program the read protection bit of a channel.
 * @note   MPU0 uses the I-Port layout, MPU1..MPU4 the D-Port layout.
 * @param  Instance: MPU instance (HAL_MPU_INSTANCE_0..4).
 * @param  Channel: channel index (0..15, MPU3/4: 0..7).
 * @param  NewState: MPU_ENABLE or MPU_DISABLE.
 * @retval None
 */
static void MPU_SetReadProtectionBit(HAL_MPU_InstanceTypeDef Instance, uint32 Channel, uint32 NewState)
{
    if (Instance == HAL_MPU_INSTANCE_0_IBUS)
    {
        if (NewState != MPU_DISABLE)
        {
            HAL_MPU_GetIPortBlock(Instance)->RPTEN |= (1UL << Channel);
        }
        else
        {
            HAL_MPU_GetIPortBlock(Instance)->RPTEN &= ~(1UL << Channel);
        }
    }
    else
    {
        if (NewState != MPU_DISABLE)
        {
            HAL_MPU_GetRegBlock(Instance)->RPTEN |= (1UL << Channel);
        }
        else
        {
            HAL_MPU_GetRegBlock(Instance)->RPTEN &= ~(1UL << Channel);
        }
    }
}

/**
 * @brief  Read the read protection status bit of a channel.
 * @param  Instance: MPU instance (HAL_MPU_INSTANCE_0..4).
 * @param  Channel: channel index (0..15, MPU3/4: 0..7).
 * @retval uint32: 1 if the status bit is set, 0 otherwise.
 */
static uint32 MPU_GetReadProtectionStatusBit(HAL_MPU_InstanceTypeDef Instance, uint32 Channel)
{
    uint32 status;

    if (Instance == HAL_MPU_INSTANCE_0_IBUS)
    {
        status = (uint32)HAL_MPU_GetIPortBlock(Instance)->RPTS;
    }
    else
    {
        status = (uint32)HAL_MPU_GetRegBlock(Instance)->RPTS;
    }

    return ((status & (1UL << Channel)) != 0U) ? 1U : 0U;
}

/**
 * @brief  Read the write protection violation status bit of a channel.
 * @note   MPU0 has no write protection hardware, so the request is ignored and
 *         0 is returned. Reading the WPTS member of the D-Port type through
 *         HAL_MPU_GetRegBlock(MPU0) would be wrong for the same reason: the
 *         I-Port block holds three control/status registers where the D-Port
 *         block holds five, so that member (offset 0x0C) resolves to the SADDR
 *         register of MPU0 channel 0, and the RPTS member (offset 0x10) to the
 *         EADDR register of the same channel.
 * @param  Instance: MPU instance (HAL_MPU_INSTANCE_0..4).
 * @param  Channel: channel index (0..15, MPU3/4: 0..7).
 * @retval uint32: 1 if the status bit is set, 0 otherwise.
 */
static uint32 MPU_GetWriteProtectionStatusBit(HAL_MPU_InstanceTypeDef Instance, uint32 Channel)
{
    if (IS_MPU_WP_INSTANCE(Instance) == 0U)
    {
        /* MPU0 has no write protection hardware */
        return 0U;
    }

    return ((HAL_MPU_GetRegBlock(Instance)->WPTS & (1UL << Channel)) != 0U) ? 1U : 0U;
}

/**
 * @brief  Read the channel enable bit of a channel.
 * @note   The PTEN register is the only register whose offset is identical in
 *         the two layouts, so it can be reached through the D-Port type for
 *         every instance.
 * @param  Instance: MPU instance (HAL_MPU_INSTANCE_0..4).
 * @param  Channel: channel index (0..15, MPU3/4: 0..7).
 * @retval uint32: 1 if the channel is enabled, 0 otherwise.
 */
static uint32 MPU_GetChannelEnableBit(HAL_MPU_InstanceTypeDef Instance, uint32 Channel)
{
    return ((HAL_MPU_GetRegBlock(Instance)->PTEN & (1UL << Channel)) != 0U) ? 1U : 0U;
}

/**
 * @brief  Read the read protection enable bit of a channel.
 * @note   MPU0 uses the I-Port layout, MPU1..MPU4 the D-Port layout, so the
 *         RPTEN register is reached through the matching register block.
 * @param  Instance: MPU instance (HAL_MPU_INSTANCE_0..4).
 * @param  Channel: channel index (0..15, MPU3/4: 0..7).
 * @retval uint32: 1 if the enable bit is set, 0 otherwise.
 */
static uint32 MPU_GetReadProtectionEnableBit(HAL_MPU_InstanceTypeDef Instance, uint32 Channel)
{
    uint32 enable;

    if (Instance == HAL_MPU_INSTANCE_0_IBUS)
    {
        enable = (uint32)HAL_MPU_GetIPortBlock(Instance)->RPTEN;
    }
    else
    {
        enable = (uint32)HAL_MPU_GetRegBlock(Instance)->RPTEN;
    }

    return ((enable & (1UL << Channel)) != 0U) ? 1U : 0U;
}

/**
 * @brief  Read the write protection enable bit of a channel.
 * @note   MPU0 has no write protection enable register: the request is
 *         ignored and 0 is returned (the WPTEN member of the D-Port type
 *         resolves to the I-Port RPTEN register, so it must not be used for
 *         MPU0).
 * @param  Instance: MPU instance (HAL_MPU_INSTANCE_0..4).
 * @param  Channel: channel index (0..15, MPU3/4: 0..7).
 * @retval uint32: 1 if the enable bit is set, 0 otherwise.
 */
static uint32 MPU_GetWriteProtectionEnableBit(HAL_MPU_InstanceTypeDef Instance, uint32 Channel)
{
    if (IS_MPU_WP_INSTANCE(Instance) == 0U)
    {
        /* MPU0 has no write protection hardware */
        return 0U;
    }

    return ((HAL_MPU_GetRegBlock(Instance)->WPTEN & (1UL << Channel)) != 0U) ? 1U : 0U;
}

/**
 * @brief  Program the channel enable bit of a channel.
 * @note   The PTEN register has the same offset on both layouts (I-Port and
 *         D-Port), so the D-Port register block can be used for every
 *         instance here.
 * @param  Instance: MPU instance (HAL_MPU_INSTANCE_0..4).
 * @param  Channel: channel index (0..15, MPU3/4: 0..7).
 * @param  NewState: non-zero to enable the channel, 0 to close it.
 * @retval None
 */
static void MPU_SetChannelEnableBit(HAL_MPU_InstanceTypeDef Instance, uint32 Channel, uint32 NewState)
{
    if (NewState != 0U)
    {
        HAL_MPU_GetRegBlock(Instance)->PTEN |= (1UL << Channel);
    }
    else
    {
        HAL_MPU_GetRegBlock(Instance)->PTEN &= ~(1UL << Channel);
    }
}

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_MPU_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; when the mutex is not acquired before the
 *         Timeout expires, HAL_TIMEOUT is returned. The value is passed to
 *         HAL_MutexAcquire() as is (RTOS ticks; with the usual 1 ms tick it is
 *         the same quantity as the millisecond Timeout of the public API, and
 *         HAL_MAX_DELAY means an infinite wait).
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef MPU_LockHandle(HAL_MPU_HandleTypeDef *hmpu, uint32 Timeout)
{
#if (USE_RTOS == 1)
    if (hmpu->LockMutex == NULL_PTR)
    {
        /* The porting layer did not create the mutex (e.g. HAL_MPU_MspInit()
         * was not overridden): report it instead of calling the RTOS with a
         * NULL handle */
        return HAL_ERROR;
    }

    return HAL_MutexAcquire(hmpu->LockMutex, Timeout);
#else
    /* Prevent unused argument compilation warning: the bare-metal lock flag
     * either succeeds immediately or reports HAL_BUSY, it never waits */
    UNUSED(Timeout);

    if (hmpu->Lock == HAL_LOCKED)
    {
        return HAL_BUSY;
    }

    hmpu->Lock = HAL_LOCKED;

    return HAL_OK;
#endif /* USE_RTOS */
}

/**
 * @brief  Returns the D-Port register block of the given MPU instance.
 * @note   Meant for MPU1..MPU4, which use the D-Port layout. For MPU0 the
 *         pointer is the I-Port block address cast to the D-Port type, and
 *         only the PTEN member is valid through it, as the two layouts share
 *         that single offset (0x00). The remaining members resolve to
 *         different registers of the I-Port block (WPTEN -> RPTEN, RPTEN ->
 *         RPTS) or into its channel array (WPTS -> the SADDR of MPU0 channel 0,
 *         RPTS -> the EADDR of the same channel). Use HAL_MPU_GetIPortBlock()
 *         to reach the I-Port registers of MPU0.
 * @param  Instance: MPU instance (HAL_MPU_INSTANCE_0..4).
 * @retval MPU_DPort_TypeDef: pointer to the register block.
 */
MPU_DPort_TypeDef *HAL_MPU_GetRegBlock(HAL_MPU_InstanceTypeDef Instance)
{
    MPU_DPort_TypeDef *regblock = (MPU_DPort_TypeDef *)MPU0_IBUS_BASE;

    if (Instance == HAL_MPU_INSTANCE_1_DBUS)
    {
        regblock = MPU1_DBUS;
    }
    else if (Instance == HAL_MPU_INSTANCE_2_PBUS)
    {
        regblock = MPU2_PBUS;
    }
    else if (Instance == HAL_MPU_INSTANCE_3_DMA0)
    {
        regblock = MPU3_DMA0;
    }
    else if (Instance == HAL_MPU_INSTANCE_4_DMA1)
    {
        regblock = MPU4_DMA1;
    }
    else
    {
        /* MPU0_IBUS: keep the default */
    }

    return regblock;
}

/**
 * @brief  Returns the I-Port register block (MPU0 only).
 * @note   The only accessor that reaches the PTEN / RPTEN / RPTS registers of
 *         MPU0 at their real offsets.
 * @param  Instance: MPU instance (HAL_MPU_INSTANCE_0_IBUS; the I-Port layout
 *         exists on MPU0 only).
 * @retval MPU_IPort_TypeDef: pointer to the register block.
 */
MPU_IPort_TypeDef *HAL_MPU_GetIPortBlock(HAL_MPU_InstanceTypeDef Instance)
{
    /* Only instance 0 (I-Bus) has the I-Port layout; this function is
       called exclusively with instance 0 by the driver */
    (void)Instance;

    return MPU0_IBUS;
}

/**
 * @brief  Unlock the handle.
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @retval None
 */
void MPU_UnlockHandle(HAL_MPU_HandleTypeDef *hmpu)
{
#if (USE_RTOS == 1)
    (void)HAL_MutexRelease(hmpu->LockMutex);
#else
    hmpu->Lock = HAL_UNLOCKED;
#endif /* USE_RTOS */
}

/* Exported functions ---------------------------------------------------------*/

/** @addtogroup MPU_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Fills each MPU_InitStruct member with its default value
 *         (instance 0, channel 0, address range 0, protections and channel
 *         disabled). (NON-BLOCKING)
 * @param  MPU_InitStruct: pointer to a MPU_InitTypeDef structure which
 *         will be initialized.
 * @retval None
 */
void HAL_MPU_StructInit(MPU_InitTypeDef *MPU_InitStruct)
{
    if (MPU_InitStruct == NULL_PTR)
    {
        return;
    }

    MPU_InitStruct->Size               = (uint32)sizeof(MPU_InitTypeDef);   /*!< Data structure
                                                                           size */
    MPU_InitStruct->Version            = MPU_INIT_VERSION;   /*!< Data structure
                                                                           version */
    MPU_InitStruct->Instance           = HAL_MPU_INSTANCE_0_IBUS; /*!< Default instance       */
    MPU_InitStruct->Channel            = 0U;          /*!< Default channel         */
    MPU_InitStruct->StartAddr          = 0U;          /*!< Start address           */
    MPU_InitStruct->EndAddr            = 0U;          /*!< End address             */
    MPU_InitStruct->WriteProtectEnable = 0U;          /*!< Write protection off    */
    MPU_InitStruct->ReadProtectEnable  = 0U;          /*!< Read protection off     */
    MPU_InitStruct->ChannelEnable      = 0U;          /*!< Channel disabled        */
    MPU_InitStruct->Reserved[0]        = 0U;          /*!< Reserved for future extension */
    MPU_InitStruct->Reserved[1]        = 0U;          /*!< Reserved for future extension */
}

/**
 * @brief  Initializes a MPU channel according to the specified parameters
 *         in the MPU_InitStruct of the handle. (NON-BLOCKING)
 * @note   The address range is programmed first, then the write / read
 *         protection and finally the channel enable (per the enable bits).
 * @note   The write protection only exists on MPU1..MPU4: a write protection
 *         requested for MPU0 (I-Port) is ignored, MPU0 has no such register.
 * @note   The parameters and the configuration structure metafields (Size /
 *         Version) are validated at run time: an invalid configuration is
 *         rejected with HAL_ERROR and HAL_MPU_ERROR_INVALID_PARAM without
 *         taking the lock and without changing the handle state.
 * @note   The programmed registers are read back before the call returns: a
 *         channel register that does not hold the requested value (the address
 *         range or a requested enable bit) rejects the call with HAL_ERROR,
 *         sets HAL_MPU_ERROR_HARDWARE and leaves the handle in the ERROR state.
 * @note   LOCK-06: the low level initialization (HAL_MPU_MspInit()) runs
 *         before the handle is locked.
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (NULL pointer, invalid configuration or failed
 *         read-back verification)
 */
HAL_StatusTypeDef HAL_MPU_Init(HAL_MPU_HandleTypeDef *hmpu)
{
    HAL_MPU_InstanceTypeDef instance = HAL_MPU_INSTANCE_0_IBUS;
    uint32 channel = 0U;
    uint32 channelenabled = 0U;
    MPU_Channel_TypeDef *pchannel = NULL_PTR;

    /* Check the MPU peripheral handle */
    if (hmpu == NULL_PTR)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_MPU_INSTANCE(hmpu->Init.Instance));
    assert_param(IS_MPU_CHANNEL(hmpu->Init.Instance, hmpu->Init.Channel));
    assert_param((hmpu->Init.WriteProtectEnable == 0U) || (hmpu->Init.WriteProtectEnable == 1U));
    assert_param((hmpu->Init.ReadProtectEnable == 0U) || (hmpu->Init.ReadProtectEnable == 1U));
    assert_param((hmpu->Init.ChannelEnable == 0U) || (hmpu->Init.ChannelEnable == 1U));
    assert_param(hmpu->Init.StartAddr < hmpu->Init.EndAddr);

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((hmpu->Init.Size != sizeof(MPU_InitTypeDef)) ||
        (hmpu->Init.Version != MPU_INIT_VERSION) ||
        (IS_MPU_INSTANCE(hmpu->Init.Instance) == 0U) ||
        (IS_MPU_CHANNEL(hmpu->Init.Instance, hmpu->Init.Channel) == 0U) ||
        (hmpu->Init.WriteProtectEnable > 1U) ||
        (hmpu->Init.ReadProtectEnable > 1U) ||
        (hmpu->Init.ChannelEnable > 1U) ||
        (hmpu->Init.StartAddr >= hmpu->Init.EndAddr))
    {
        hmpu->ErrorCode |= HAL_MPU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* The write protection does not exist on MPU0 (the I-Port layout has no
     * write protection register), so a request addressing it can never be
     * honoured: it is rejected with a dedicated error code before any register
     * is written, instead of being dropped silently. */
    if ((hmpu->Init.Instance == HAL_MPU_INSTANCE_0_IBUS) &&
        (hmpu->Init.WriteProtectEnable != 0U))
    {
        hmpu->ErrorCode |= HAL_MPU_ERROR_NOT_SUPPORTED;
        return HAL_ERROR;
    }

    /* Allocate the lock resource before the first use, so that a handle that
     * was never initialized cannot report HAL_BUSY from a stale Lock field */
    if (hmpu->State == HAL_MPU_STATE_RESET)
    {
        hmpu->Lock = HAL_UNLOCKED;

        /* Init the low level hardware (empty for the MPU). LOCK-06: the MSP
         * callback runs before the handle is locked */
        HAL_MPU_MspInit(hmpu);
    }

    /* Process locked */
    if (MPU_LockHandle(hmpu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hmpu->ErrorCode = HAL_MPU_ERROR_NONE;
    hmpu->State = HAL_MPU_STATE_BUSY;

    /* Synchronize the handle instance with the configured instance */
    instance = hmpu->Init.Instance;
    channel = hmpu->Init.Channel;
    hmpu->Instance = instance;

    /* Close the channel before the address range is programmed: an enabled
     * channel must never hold the new start address together with the previous
     * end address, because that transient range could latch a spurious
     * violation while it is being re-configured. The enable state is read
     * first, so that a zero channel enable request can restore it below. */
    channelenabled = MPU_GetChannelEnableBit(instance, channel);
    MPU_SetChannelEnableBit(instance, channel, 0U);

    /* Program the address range */
    pchannel = (MPU_Channel_TypeDef *)(MPU_GetChannelBase(instance) + (channel * 0x08U));
    pchannel->SADDR = hmpu->Init.StartAddr;
    pchannel->EADDR = hmpu->Init.EndAddr;

    /* Program the write protection (MPU0 was rejected above, it has none) */
    if (hmpu->Init.WriteProtectEnable != 0U)
    {
        MPU_SetWriteProtectionBit(instance, channel, MPU_ENABLE);
    }

    /* Program the read protection */
    if (hmpu->Init.ReadProtectEnable != 0U)
    {
        MPU_SetReadProtectionBit(instance, channel, MPU_ENABLE);
    }

    /* Enable the channel. A zero channel enable request restores the enable
     * state the channel had before it was closed, so the end state of the
     * earlier release is preserved. */
    if ((hmpu->Init.ChannelEnable != 0U) || (channelenabled != 0U))
    {
        MPU_SetChannelEnableBit(instance, channel, MPU_ENABLE);
    }

    /* Read-back verification: a register that does not hold the requested
     * value means that the programming did not take effect (for example
     * because the peripheral block is not ready). Only the values that were
     * requested are checked, as a zero request leaves the previous content of
     * the register untouched, and the write protection is not checked on MPU0,
     * which has no such register. */
    if ((pchannel->SADDR != hmpu->Init.StartAddr) ||
        (pchannel->EADDR != hmpu->Init.EndAddr) ||
        ((hmpu->Init.WriteProtectEnable != 0U) && (IS_MPU_WP_INSTANCE(instance) != 0U) &&
         (MPU_GetWriteProtectionEnableBit(instance, channel) == 0U)) ||
        ((hmpu->Init.ReadProtectEnable != 0U) &&
         (MPU_GetReadProtectionEnableBit(instance, channel) == 0U)) ||
        ((hmpu->Init.ChannelEnable != 0U) &&
         (MPU_GetChannelEnableBit(instance, channel) == 0U)))
    {
        hmpu->ErrorCode |= HAL_MPU_ERROR_HARDWARE;
        hmpu->State = HAL_MPU_STATE_ERROR;

        /* Release Lock */
        MPU_UnlockHandle(hmpu);

        return HAL_ERROR;
    }

    hmpu->State = HAL_MPU_STATE_READY;

    /* Release Lock */
    MPU_UnlockHandle(hmpu);

    return HAL_OK;
}

/**
 * @brief  De-initializes a MPU channel. (NON-BLOCKING)
 * @note   The channel is disabled and its address range and protection bits
 *         are cleared. The handle goes back to the RESET state so that a
 *         following HAL_MPU_Init() re-runs HAL_MPU_MspInit().
 * @note   The state transition is READY -> BUSY -> RESET, so that a concurrent
 *         caller sees the handle as busy while the registers are cleared.
 * @note   The call is accepted from any handle state, so that a failed
 *         initialization can always be undone.
 * @note   LOCK-06: the low level de-initialization (HAL_MPU_MspDeInit()) runs
 *         after the unlock.
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (NULL pointer or invalid instance)
 */
HAL_StatusTypeDef HAL_MPU_DeInit(HAL_MPU_HandleTypeDef *hmpu)
{
    HAL_MPU_InstanceTypeDef instance = HAL_MPU_INSTANCE_0_IBUS;
    uint32 channel = 0U;

    /* Check the MPU peripheral handle and instance */
    if (MPU_HandleIsValid(hmpu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Process locked. ARCH-CONST-09: the de-initialization is callable from
     * any handle state, so that a failed initialization can always be undone */
    if (MPU_LockHandle(hmpu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hmpu->ErrorCode = HAL_MPU_ERROR_NONE;
    hmpu->State = HAL_MPU_STATE_BUSY;

    instance = hmpu->Instance;
    channel = hmpu->Init.Channel;

    /* The channel index of the configuration may have been left invalid (for
     * example by a handle that was never initialized): the protection bits and
     * the address range are then skipped, as shifting by an out of range
     * channel index is not meaningful */
    if (IS_MPU_CHANNEL(instance, channel) == 0U)
    {
        hmpu->ErrorCode |= HAL_MPU_ERROR_INVALID_PARAM;
    }
    else
    {
        /* Disable the channel and clear its protection bits */
        MPU_SetWriteProtectionBit(instance, channel, MPU_DISABLE);
        MPU_SetReadProtectionBit(instance, channel, MPU_DISABLE);
        HAL_MPU_GetRegBlock(instance)->PTEN &= ~(1UL << channel);

        /* Clear the address range */
        ((MPU_Channel_TypeDef *)(MPU_GetChannelBase(instance) + (channel * 0x08U)))->SADDR = 0U;
        ((MPU_Channel_TypeDef *)(MPU_GetChannelBase(instance) + (channel * 0x08U)))->EADDR = 0U;
    }

    /* Reset the state */
    hmpu->State = HAL_MPU_STATE_RESET;

    /* Release Lock */
    MPU_UnlockHandle(hmpu);

    /* LOCK-06 / ARCH-CONST-04: the low level de-initialization runs OUTSIDE
     * the locked region, as the architecture specification requires for the
     * MSP callbacks ("MspDeInit is called after the unlock") */
    HAL_MPU_MspDeInit(hmpu);

    return HAL_OK;
}

/**
 * @brief  Resets the whole MPU instance: every channel of the instance is
 *         disabled and its address range, protection enables and protection
 *         status are cleared. (NON-BLOCKING)
 * @note   Unlike HAL_MPU_DeInit(), which clears the single channel named by
 *         the handle configuration, this interface clears all the channels of
 *         the instance in one call: use it to recover the instance after
 *         several channels have been configured, or to leave it in a known
 *         state. The handle stays initialized (the state returns to READY), so
 *         no HAL_MPU_Init() is required afterwards.
 * @note   The channel count comes from the instance (MPU0/1/2: 16 channels,
 *         MPU3/4: 8 channels).
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_MPU_Init() is required first).
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken or another operation is ongoing) / HAL_ERROR (NULL pointer,
 *         invalid instance or the handle is not initialized)
 */
HAL_StatusTypeDef HAL_MPU_ResetInstance(HAL_MPU_HandleTypeDef *hmpu)
{
    HAL_StatusTypeDef status = HAL_OK;
    HAL_MPU_InstanceTypeDef instance = HAL_MPU_INSTANCE_0_IBUS;
    uint32 channel = 0U;
    uint32 channelcount = 0U;
    uint32 channelmask = 0U;

    /* Check the MPU peripheral handle and instance */
    if (MPU_HandleIsValid(hmpu) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_MPU_Init() is
     * required first) */
    status = MPU_CheckState(hmpu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (MPU_LockHandle(hmpu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hmpu->ErrorCode = HAL_MPU_ERROR_NONE;
    hmpu->State = HAL_MPU_STATE_BUSY;

    instance = hmpu->Instance;
    channelcount = MPU_GetChannelCount(instance);

    /* The violation status registers are cleared by writing one, so the mask
     * covering every channel of this instance is what has to be written to
     * them (MPU0..2 have 16 channels, MPU3/4 only 8) */
    channelmask = ((channelcount >= 16U) ? 0x0000FFFFU : 0x000000FFU);

    /* Clear the address range of every channel of the instance */
    for (channel = 0U; channel < channelcount; channel++)
    {
        ((MPU_Channel_TypeDef *)(MPU_GetChannelBase(instance) + (channel * 0x08U)))->SADDR = 0U;
        ((MPU_Channel_TypeDef *)(MPU_GetChannelBase(instance) + (channel * 0x08U)))->EADDR = 0U;
    }

    /* Disable every channel and clear the protection enables together with the
     * violation status. The write protection registers are skipped on MPU0,
     * which has no such hardware: the WPTEN / WPTS members of the D-Port type
     * would resolve to the I-Port RPTEN / RPTS registers and, for WPTS, to the
     * SADDR register of channel 0. The violation status registers are cleared
     * by writing one, so the mask of every channel of the instance is written
     * to them: writing zero would leave the latched violations untouched. */
    if (instance == HAL_MPU_INSTANCE_0_IBUS)
    {
        HAL_MPU_GetIPortBlock(instance)->PTEN = 0U;
        HAL_MPU_GetIPortBlock(instance)->RPTEN = 0U;
        HAL_MPU_GetIPortBlock(instance)->RPTS = channelmask;
    }
    else
    {
        HAL_MPU_GetRegBlock(instance)->PTEN = 0U;
        HAL_MPU_GetRegBlock(instance)->WPTEN = 0U;
        HAL_MPU_GetRegBlock(instance)->RPTEN = 0U;
        HAL_MPU_GetRegBlock(instance)->WPTS = channelmask;
        HAL_MPU_GetRegBlock(instance)->RPTS = channelmask;
    }

    hmpu->State = HAL_MPU_STATE_READY;

    /* Release Lock */
    MPU_UnlockHandle(hmpu);

    return HAL_OK;
}

/**
 * @brief  Initializes the MPU MSP. Weak empty function; the MPU is directly
 *         clocked by the AXILite bus clock, no clock gating is needed.
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_MPU_MspInit(HAL_MPU_HandleTypeDef *hmpu)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hmpu);
}

/**
 * @brief  De-initializes the MPU MSP. Weak empty function.
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_MPU_MspDeInit(HAL_MPU_HandleTypeDef *hmpu)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hmpu);
}

/**
  * @}
  */

/** @addtogroup MPU_Exported_Functions_Group2 Peripheral Control functions
  * @{
  */

/**
 * @brief  Sets the address range of a MPU channel. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_MPU_Init() is required first).
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @param  Channel: channel index (0..15, MPU3/4: 0..7).
 * @param  StartAddr: start address of the protected range.
 * @param  EndAddr: end address of the protected range (must be greater
 *         than StartAddr).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_MPU_SetAddressRange(HAL_MPU_HandleTypeDef *hmpu, uint32 Channel, uint32 StartAddr,
                                          uint32 EndAddr)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the MPU peripheral handle and instance */
    if (MPU_HandleIsValid(hmpu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_MPU_CHANNEL(hmpu->Instance, Channel));
    assert_param(StartAddr < EndAddr);

    /* Runtime parameter validation (see HAL_MPU_Init()) */
    if ((IS_MPU_CHANNEL(hmpu->Instance, Channel) == 0U) || (StartAddr >= EndAddr))
    {
        hmpu->ErrorCode |= HAL_MPU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_MPU_Init() is
     * required first) */
    status = MPU_CheckState(hmpu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (MPU_LockHandle(hmpu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    ((MPU_Channel_TypeDef *)(MPU_GetChannelBase(hmpu->Instance) + (Channel * 0x08U)))->SADDR = StartAddr;
    ((MPU_Channel_TypeDef *)(MPU_GetChannelBase(hmpu->Instance) + (Channel * 0x08U)))->EADDR = EndAddr;

    /* Release Lock */
    MPU_UnlockHandle(hmpu);

    return HAL_OK;
}

/**
 * @brief  Enables or disables a MPU channel. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_MPU_Init() is required first).
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @param  Channel: channel index (0..15, MPU3/4: 0..7).
 * @param  NewState: ENABLE or DISABLE (MPU_ENABLE / MPU_DISABLE).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_MPU_Cmd(HAL_MPU_HandleTypeDef *hmpu, uint32 Channel, FunctionalState NewState)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the MPU peripheral handle and instance */
    if (MPU_HandleIsValid(hmpu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_MPU_CHANNEL(hmpu->Instance, Channel));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Runtime parameter validation (see HAL_MPU_Init()) */
    if ((IS_MPU_CHANNEL(hmpu->Instance, Channel) == 0U) ||
        (IS_FUNCTIONAL_STATE(NewState) == 0U))
    {
        hmpu->ErrorCode |= HAL_MPU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_MPU_Init() is
     * required first) */
    status = MPU_CheckState(hmpu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (MPU_LockHandle(hmpu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    if (NewState != DISABLE)
    {
        /* Enable the channel */
        HAL_MPU_GetRegBlock(hmpu->Instance)->PTEN |= (1UL << Channel);
    }
    else
    {
        /* Disable the channel */
        HAL_MPU_GetRegBlock(hmpu->Instance)->PTEN &= ~(1UL << Channel);
    }

    /* Release Lock */
    MPU_UnlockHandle(hmpu);

    return HAL_OK;
}

/**
 * @brief  Enables or disables the write protection of a MPU channel. (NON-BLOCKING)
 * @note   Only supported by MPU1..MPU4 (D-Bus / P-Bus / DMA ports); MPU0
 *         (I-Bus) has no write-protection hardware and the request is
 *         ignored (no register is touched).
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_MPU_Init() is required first).
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @param  Channel: channel index (0..15, MPU3/4: 0..7).
 * @param  NewState: ENABLE or DISABLE (MPU_ENABLE / MPU_DISABLE).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_MPU_WriteProtectCmd(HAL_MPU_HandleTypeDef *hmpu, uint32 Channel,
                                          FunctionalState NewState)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the MPU peripheral handle and instance */
    if (MPU_HandleIsValid(hmpu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_MPU_CHANNEL(hmpu->Instance, Channel));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Runtime parameter validation (see HAL_MPU_Init()) */
    if ((IS_MPU_CHANNEL(hmpu->Instance, Channel) == 0U) ||
        (IS_FUNCTIONAL_STATE(NewState) == 0U))
    {
        hmpu->ErrorCode |= HAL_MPU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* The write protection only exists on MPU1..MPU4: MPU0 (I-Port) has no
     * such register, so the request can never be honoured and is rejected with
     * a dedicated error code without touching any register, instead of being
     * dropped silently */
    if (IS_MPU_WP_INSTANCE(hmpu->Instance) == 0U)
    {
        hmpu->ErrorCode |= HAL_MPU_ERROR_NOT_SUPPORTED;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_MPU_Init() is
     * required first) */
    status = MPU_CheckState(hmpu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (MPU_LockHandle(hmpu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Program the write protection bit */
    MPU_SetWriteProtectionBit(hmpu->Instance, Channel,
                              ((NewState != DISABLE) ? MPU_ENABLE : MPU_DISABLE));

    /* Release Lock */
    MPU_UnlockHandle(hmpu);

    return HAL_OK;
}

/**
 * @brief  Enables or disables the read protection of a MPU channel. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_MPU_Init() is required first).
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @param  Channel: channel index (0..15, MPU3/4: 0..7).
 * @param  NewState: ENABLE or DISABLE (MPU_ENABLE / MPU_DISABLE).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_MPU_ReadProtectCmd(HAL_MPU_HandleTypeDef *hmpu, uint32 Channel,
                                         FunctionalState NewState)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the MPU peripheral handle and instance */
    if (MPU_HandleIsValid(hmpu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_MPU_CHANNEL(hmpu->Instance, Channel));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Runtime parameter validation (see HAL_MPU_Init()) */
    if ((IS_MPU_CHANNEL(hmpu->Instance, Channel) == 0U) ||
        (IS_FUNCTIONAL_STATE(NewState) == 0U))
    {
        hmpu->ErrorCode |= HAL_MPU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_MPU_Init() is
     * required first) */
    status = MPU_CheckState(hmpu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (MPU_LockHandle(hmpu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Program the read protection bit (I-Port for MPU0, D-Port otherwise) */
    MPU_SetReadProtectionBit(hmpu->Instance, Channel,
                             ((NewState != DISABLE) ? MPU_ENABLE : MPU_DISABLE));

    /* Release Lock */
    MPU_UnlockHandle(hmpu);

    return HAL_OK;
}

/**
  * @}
  */

/** @addtogroup MPU_Exported_Functions_Group3 Status and configuration functions
  * @{
  */

/**
 * @brief  Returns the write-protection violation status of a MPU channel.
 *         (NON-BLOCKING)
 * @note   This is the violation status (the WPTS register): the bit is set
 *         once a write access has hit the protected range, and it is cleared
 *         by HAL_MPU_ClearStatus(). The write protection enable itself (the
 *         WPTEN register) is read back by HAL_MPU_GetChannelConfig().
 * @note   Only valid for MPU1..MPU4; MPU0 has no write protection hardware
 *         and 0 is returned.
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context.
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @param  Channel: channel index (0..15, MPU3/4: 0..7).
 * @retval 1 if the write-protection violation status is set, 0 otherwise (also
 *         when the handle, the instance or the channel is invalid).
 */
uint32 HAL_MPU_GetWriteProtectStatus(HAL_MPU_HandleTypeDef *hmpu, uint32 Channel)
{
    /* Check the MPU peripheral handle and instance */
    if (MPU_HandleIsValid(hmpu) == 0U)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_MPU_CHANNEL(hmpu->Instance, Channel));

    /* An out of range channel index would make the shift undefined; report no
     * status instead */
    if (IS_MPU_CHANNEL(hmpu->Instance, Channel) == 0U)
    {
        return 0U;
    }

    /* Read-only: no lock */
    return MPU_GetWriteProtectionStatusBit(hmpu->Instance, Channel);
}

/**
 * @brief  Returns the read-protection violation status of a MPU channel.
 *         (NON-BLOCKING)
 * @note   This is the violation status (the RPTS register): the bit is set
 *         once a read access has hit the protected range, and it is cleared by
 *         HAL_MPU_ClearStatus(). The read protection enable itself (the RPTEN
 *         register) is read back by HAL_MPU_GetChannelConfig().
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context.
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @param  Channel: channel index (0..15, MPU3/4: 0..7).
 * @retval 1 if the read-protection violation status is set, 0 otherwise (also
 *         when the handle, the instance or the channel is invalid).
 */
uint32 HAL_MPU_GetReadProtectStatus(HAL_MPU_HandleTypeDef *hmpu, uint32 Channel)
{
    /* Check the MPU peripheral handle and instance */
    if (MPU_HandleIsValid(hmpu) == 0U)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_MPU_CHANNEL(hmpu->Instance, Channel));

    /* An out of range channel index would make the shift undefined; report no
     * status instead */
    if (IS_MPU_CHANNEL(hmpu->Instance, Channel) == 0U)
    {
        return 0U;
    }

    /* Read-only: no lock */
    return MPU_GetReadProtectionStatusBit(hmpu->Instance, Channel);
}

/**
 * @brief  Clears the write / read protection status of a MPU channel. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_MPU_Init() is required first).
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @param  Channel: channel index (0..15, MPU3/4: 0..7).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_MPU_ClearStatus(HAL_MPU_HandleTypeDef *hmpu, uint32 Channel)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the MPU peripheral handle and instance */
    if (MPU_HandleIsValid(hmpu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_MPU_CHANNEL(hmpu->Instance, Channel));

    /* Runtime parameter validation (see HAL_MPU_Init()) */
    if (IS_MPU_CHANNEL(hmpu->Instance, Channel) == 0U)
    {
        hmpu->ErrorCode |= HAL_MPU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_MPU_Init() is
     * required first) */
    status = MPU_CheckState(hmpu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (MPU_LockHandle(hmpu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    if (hmpu->Instance == HAL_MPU_INSTANCE_0_IBUS)
    {
        HAL_MPU_GetIPortBlock(hmpu->Instance)->RPTS = (1UL << Channel);
    }
    else
    {
        HAL_MPU_GetRegBlock(hmpu->Instance)->WPTS = (1UL << Channel);
        HAL_MPU_GetRegBlock(hmpu->Instance)->RPTS = (1UL << Channel);
    }

    /* Release Lock */
    MPU_UnlockHandle(hmpu);

    return HAL_OK;
}

/**
 * @brief  Reads back the address range of a MPU channel. (NON-BLOCKING)
 * @note   The SADDR / EADDR registers are readable, so the range that is
 *         really programmed can be verified: the driver writes them from
 *         HAL_MPU_Init() and HAL_MPU_SetAddressRange() only, there is no
 *         other path to them.
 * @note   The lock is taken so that the two register reads form a consistent
 *         snapshot; the single bit queries of this group are lock-free
 *         instead and remain callable from an interrupt context.
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @param  Channel: channel index (0..15, MPU3/4: 0..7).
 * @param  StartAddr: pointer to the variable receiving the start address.
 * @param  EndAddr: pointer to the variable receiving the end address.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (NULL pointer, invalid instance or invalid
 *         channel)
 */
HAL_StatusTypeDef HAL_MPU_GetAddressRange(HAL_MPU_HandleTypeDef *hmpu, uint32 Channel,
                                          uint32 *StartAddr, uint32 *EndAddr)
{
    /* Check the MPU peripheral handle, the instance and the output pointers */
    if ((MPU_HandleIsValid(hmpu) == 0U) || (StartAddr == NULL_PTR) || (EndAddr == NULL_PTR))
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_MPU_CHANNEL(hmpu->Instance, Channel));

    /* An out of range channel index would address a register outside the
     * channel array of the instance: no read is performed then */
    if (IS_MPU_CHANNEL(hmpu->Instance, Channel) == 0U)
    {
        return HAL_ERROR;
    }

    /* Process locked: the two reads form a single snapshot */
    if (MPU_LockHandle(hmpu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    *StartAddr = ((MPU_Channel_TypeDef *)(MPU_GetChannelBase(hmpu->Instance) +
                                          (Channel * 0x08U)))->SADDR;
    *EndAddr = ((MPU_Channel_TypeDef *)(MPU_GetChannelBase(hmpu->Instance) +
                                        (Channel * 0x08U)))->EADDR;

    /* Release Lock */
    MPU_UnlockHandle(hmpu);

    return HAL_OK;
}

/**
 * @brief  Reads back the configuration of a MPU channel. (NON-BLOCKING)
 * @note   The whole configuration is returned in a MPU_InitTypeDef structure:
 *         the instance, the channel, the address range and the protection /
 *         channel enable bits as they are programmed in the registers, so
 *         that a configuration can be verified or carried over to another
 *         channel. The size / version metafields are filled in and the
 *         reserved words are cleared.
 * @note   The enable bits come from the PTEN / WPTEN / RPTEN registers, that
 *         is from the configuration. They are NOT the violation status
 *         reported by HAL_MPU_GetWriteProtectStatus() and
 *         HAL_MPU_GetReadProtectStatus(), which read the WPTS / RPTS
 *         registers. WriteProtectEnable always reads back as 0 on MPU0, which
 *         has no write protection hardware.
 * @note   The lock is taken so that the register reads form a consistent
 *         snapshot; the single bit queries of this group are lock-free
 *         instead and remain callable from an interrupt context.
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @param  Channel: channel index (0..15, MPU3/4: 0..7).
 * @param  pConfig: pointer to the MPU_InitTypeDef structure that receives the
 *         configuration (its size / version metafields are filled in).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (NULL pointer, invalid instance or invalid
 *         channel)
 */
HAL_StatusTypeDef HAL_MPU_GetChannelConfig(HAL_MPU_HandleTypeDef *hmpu, uint32 Channel,
                                           MPU_InitTypeDef *pConfig)
{
    /* Check the MPU peripheral handle, the instance and the output structure */
    if ((MPU_HandleIsValid(hmpu) == 0U) || (pConfig == NULL_PTR))
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_MPU_CHANNEL(hmpu->Instance, Channel));

    /* An out of range channel index would address a register outside the
     * channel array of the instance: no read is performed then */
    if (IS_MPU_CHANNEL(hmpu->Instance, Channel) == 0U)
    {
        return HAL_ERROR;
    }

    /* Process locked: the register reads form a single snapshot */
    if (MPU_LockHandle(hmpu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    pConfig->Size = (uint32)sizeof(MPU_InitTypeDef);
    pConfig->Version = MPU_INIT_VERSION;
    pConfig->Instance = hmpu->Instance;
    pConfig->Channel = Channel;
    pConfig->StartAddr = ((MPU_Channel_TypeDef *)(MPU_GetChannelBase(hmpu->Instance) +
                                                  (Channel * 0x08U)))->SADDR;
    pConfig->EndAddr = ((MPU_Channel_TypeDef *)(MPU_GetChannelBase(hmpu->Instance) +
                                                (Channel * 0x08U)))->EADDR;
    pConfig->WriteProtectEnable = MPU_GetWriteProtectionEnableBit(hmpu->Instance, Channel);
    pConfig->ReadProtectEnable = MPU_GetReadProtectionEnableBit(hmpu->Instance, Channel);
    pConfig->ChannelEnable = MPU_GetChannelEnableBit(hmpu->Instance, Channel);
    pConfig->Reserved[0] = 0U;
    pConfig->Reserved[1] = 0U;

    /* Release Lock */
    MPU_UnlockHandle(hmpu);

    return HAL_OK;
}

/**
  * @}
  */

/** @addtogroup MPU_Exported_Functions_Group4 State functions
  * @{
  */

/**
 * @brief  Returns the MPU handle state. (NON-BLOCKING)
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @retval HAL_MPU_StateTypeDef: the current handle state.
 */
HAL_MPU_StateTypeDef HAL_MPU_GetState(HAL_MPU_HandleTypeDef *hmpu)
{
    /* Check the MPU handle allocation */
    if (hmpu == NULL_PTR)
    {
        return HAL_MPU_STATE_RESET;
    }

    /* Instance binding: a handle that is not bound to one of the approved
       instances has no state to report (the same answer as an uninitialized
       handle). A NULL handle keeps the documented "uninitialized" answer. */
    if (IS_MPU_INSTANCE(hmpu->Instance) == 0U)
    {
        return HAL_MPU_STATE_RESET;
    }

    return hmpu->State;
}

/**
 * @brief  Returns the MPU error code. (NON-BLOCKING)
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @retval uint32: the MPU error code (HAL_MPU_ERROR_xxx).
 */
uint32 HAL_MPU_GetError(HAL_MPU_HandleTypeDef *hmpu)
{
    /* Check the MPU handle allocation */
    if (hmpu == NULL_PTR)
    {
        return HAL_MPU_ERROR_NONE;
    }

    /* Instance binding: a handle that is not bound to one of the approved
       instances reports the invalid parameter error code, because the value
       it carries cannot be attributed to a peripheral. A NULL handle keeps
       the documented "no error" answer. */
    if (IS_MPU_INSTANCE(hmpu->Instance) == 0U)
    {
        return HAL_MPU_ERROR_INVALID_PARAM;
    }

    return hmpu->ErrorCode;
}

/**
  * @}
  */

/**
  * @}
  */

#endif /* HAL_MPU_MODULE_ENABLED */

/*****END OF FILE*****/
