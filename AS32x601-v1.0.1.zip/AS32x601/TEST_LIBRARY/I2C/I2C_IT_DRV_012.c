/**
 * @file    I2C_IT_DRV_012.c
 * @brief   HAL I2C integration test case 012 (full API coverage).
 *
 * Extension case (no one-to-one vendor counterpart): it exercises the whole
 * HAL I2C API surface on I2C1 with only HAL library calls.
 *
 * Tested functionality:
 *   Group 1   HAL_I2C_StructInit()             (default values)
 *   Group 2   HAL_I2C_Init() + GetState() / GetError(), MspInit() counting
 *   Group 3   HAL_I2C_Init() invalid parameter rejection
 *   Group 4   HAL_I2C_Cmd()                    (enable / disable read back)
 *   Group 5   HAL_I2C_ITStructInit()           (all sources disabled)
 *   Group 6   HAL_I2C_ITInit()                 (each source, register read back)
 *   Group 7   HAL_I2C_ITInit() invalid parameter rejection
 *   Group 8   HAL_I2C_GetITStatus() / HAL_I2C_ClearITPendingBit()
 *   Group 9   low level group: HAL_I2C_GenerateStart / GenerateStop /
 *             StartClear / Send7bitAddress / AcknowledgeConfig / SendData /
 *             ReceiveData / GetFlagStatus / CheckStatus
 *   Group 10  transfer API invalid parameter rejection (NULL buffer, zero size,
 *             out of range address)
 *   Group 11  HAL_I2C_DeInit() + MspDeInit() counting, register residue after
 *             DeInit (enabled bit cleared, configuration kept)
 *   Group 12  re-initialization after the de-initialization
 *
 * Test procedure:
 *   The case runs without a peer on the bus: the register level checks are made
 *   with the controller disabled, so nothing is driven on to the bus.  The only
 *   calls that would touch the bus are the transfer APIs, and those are called
 *   with invalid parameters on purpose (they must be rejected before the bus is
 *   used) or are not called at all.
 *
 * Expected behaviour:
 *   "summary : failures = 0".  The lines marked "info" are recorded but not
 *   judged (they describe the default values and the rejected-call side
 *   effects).
 *
 * Note: the low level group takes no lock and has no state gate by design
 * (ARCH-CONST-19 / LOCK-04): it is meant for an interrupt driven transfer, so
 * it stays callable while the handle is busy.  This case therefore checks that
 * those calls work on a handle that is deliberately left de-initialized, which
 * is the harshest condition.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
#define TEST_BAUDRATE               (115200U)

/* Standard clock tree (the same tree the other HAL integration suites use) */
#define STD_PLL_DIV_R               (0x04U)
#define STD_PLL_DIV_Q               (0x01U)
#define STD_PLL_DIV_N               (0x14U)
#define STD_PLL_DIV_F               (0xB4U)
#define STD_AXI4BUS3_DIV            SMU_AXI4BUS3CLK_DIV2
#define STD_APBBUS0_DIV             SMU_APBBUS0CLK_DIV2
#define STD_APBBUS1_DIV             SMU_APBBUS1CLK_DIV2
#define STD_CANX2_DIV               SMU_CANX2CLK_DIV8

/* Instance under test and its pins (I2C1 on GPIOF, alternate function IIC1) */
#define TEST_I2C                    I2C1
#define TEST_SCL_PORT               GPIOF
#define TEST_SCL_PIN                GPIO_PIN_15
#define TEST_SCL_SOURCE             GPIO_PinSource15
#define TEST_SDA_PORT               GPIOF
#define TEST_SDA_PIN                GPIO_PIN_13
#define TEST_SDA_SOURCE             GPIO_PinSource13
#define TEST_AF                     GPIO_AF_IIC1

/* Own slave address and a divider value (100 kHz at a 22.5 MHz APB clock) */
#define TEST_OWN_ADDRESS            (0x5AU)
#define TEST_DIV                    (0x1CU)

/* Private variables -------------------------------------------------------*/
static I2C_HandleTypeDef  hi2c_dev;         /*!< I2C handle                   */
static HAL_PMU_HandleTypeDef hpmu_dev;      /*!< PMU handle (LDO scaler)      */
static uint32 g_failures;                   /*!< collected failures           */

/* MSP callback instrumentation (the weak symbols are overridden below) */
static uint32 g_msp_init_cnt;
static uint32 g_msp_deinit_cnt;
static uint32 g_msp_init_state;
static uint32 g_msp_init_lock;
static uint32 g_msp_deinit_state;

/* Register snapshot taken by MspDeInit() while the peripheral clock is still
 * running (reading a clock gated module is not a valid observation) */
static uint32 g_deinit_ctlr;
static uint32 g_deinit_addr;
static uint32 g_deinit_div_l;
static uint32 g_deinit_div_h;
static uint32 g_deinit_irqc;

/* Private function prototypes ---------------------------------------------*/
static void   SystemClock_Init(void);
static void   I2C_ApplyInit(uint32 Divider, uint32 Enable);
static uint32 Chk(const char *name, uint32 expect, uint32 actual);
static void   Info(const char *name, uint32 value);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    I2C_InitTypeDef  init;
    I2C_IRQTypeDef   irq;
    uint8            data;
    uint32           saved;
    uint32           saved_ctlr;
    uint32           saved_addr;
    uint32           saved_div_l;
    uint32           saved_div_h;
    uint32           saved_irqc;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);

    printf("\r\n=== I2C_IT_DRV_012: full API coverage ===\r\n");

    /* ---------------- Group 1: StructInit defaults ---------------- */
    printf("--- group 1: HAL_I2C_StructInit ---\r\n");
    __HAL_CLEAR_STRUCT(&init);
    HAL_I2C_StructInit(&init);
    g_failures += Chk("Size is filled", (uint32)sizeof(I2C_InitTypeDef), init.Size);
    g_failures += Chk("Version is filled", (uint32)I2C_INIT_VERSION, init.Version);
    g_failures += Chk("ClockScale default", (uint32)I2C_CLOCKSCALE_PCLK_256,
                      init.I2C_ClockScale);
    g_failures += Chk("EN default is disabled", (uint32)I2C_DISABLE, init.I2C_EN);
    g_failures += Chk("Ack default is NACK", (uint32)I2C_NACK, init.I2C_Ack);
    g_failures += Chk("slave address default is 0", 0U,
                      (uint32)init.I2C_SlaveAddress);
    Info("ICLKDIVL default =", (uint32)init.I2C_ICLKDIVL);
    Info("ICLKDIVH default =", (uint32)init.I2C_ICLKDIVH);
    g_failures += Chk("Reserved[0] is zero", 0U, init.Reserved[0]);
    g_failures += Chk("Reserved[1] is zero", 0U, init.Reserved[1]);

    /* ---------------- Group 2: Init + state ---------------- */
    printf("--- group 2: HAL_I2C_Init / GetState / GetError ---\r\n");
    __HAL_CLEAR_STRUCT(&hi2c_dev);
    hi2c_dev.Instance = TEST_I2C;
    g_failures += Chk("state before Init is RESET", (uint32)HAL_I2C_STATE_RESET,
                      (uint32)HAL_I2C_GetState(&hi2c_dev));
    I2C_ApplyInit(TEST_DIV, I2C_ENABLE);
    g_failures += Chk("state after Init is READY", (uint32)HAL_I2C_STATE_READY,
                      (uint32)HAL_I2C_GetState(&hi2c_dev));
    g_failures += Chk("error code is NONE after Init", (uint32)HAL_I2C_ERROR_NONE,
                      HAL_I2C_GetError(&hi2c_dev));
    g_failures += Chk("MspInit was called once", 1U, g_msp_init_cnt);
    g_failures += Chk("MspInit saw the RESET state", (uint32)HAL_I2C_STATE_RESET,
                      g_msp_init_state);
    g_failures += Chk("MspInit saw an unlocked handle", (uint32)HAL_UNLOCKED,
                      g_msp_init_lock);

    /* ---------------- Group 3: Init invalid parameters ---------------- */
    printf("--- group 3: HAL_I2C_Init invalid parameters ---\r\n");
    g_failures += Chk("Init(NULL) returns HAL_ERROR", (uint32)HAL_ERROR,
                      (uint32)HAL_I2C_Init(NULL_PTR));

    __HAL_CLEAR_STRUCT(&init);
    init.Size             = sizeof(I2C_InitTypeDef);
    init.Version          = I2C_INIT_VERSION;
    init.I2C_ClockScale   = 0x7FU;              /* not a valid scale */
    init.I2C_EN           = I2C_ENABLE;
    init.I2C_SlaveAddress = TEST_OWN_ADDRESS;
    init.I2C_Ack          = I2C_ACK;
    hi2c_dev.Init = init;
    g_failures += Chk("invalid ClockScale is rejected", (uint32)HAL_ERROR,
                      (uint32)HAL_I2C_Init(&hi2c_dev));
    g_failures += Chk("rejection reports INVALID_PARAM",
                      (uint32)HAL_I2C_ERROR_INVALID_PARAM, HAL_I2C_GetError(&hi2c_dev));
    g_failures += Chk("rejection keeps the handle READY",
                      (uint32)HAL_I2C_STATE_READY, (uint32)HAL_I2C_GetState(&hi2c_dev));

    I2C_ApplyInit(TEST_DIV, I2C_ENABLE);
    hi2c_dev.Init.I2C_EN = 0x5AU;               /* neither ENABLE nor DISABLE */
    g_failures += Chk("invalid I2C_EN is rejected", (uint32)HAL_ERROR,
                      (uint32)HAL_I2C_Init(&hi2c_dev));

    I2C_ApplyInit(TEST_DIV, I2C_ENABLE);
    hi2c_dev.Init.I2C_Ack = 0x5AU;              /* neither ACK nor NACK */
    g_failures += Chk("invalid I2C_Ack is rejected", (uint32)HAL_ERROR,
                      (uint32)HAL_I2C_Init(&hi2c_dev));

    I2C_ApplyInit(TEST_DIV, I2C_ENABLE);
    hi2c_dev.Init.I2C_SlaveAddress = 0x80U;     /* 7 bits only */
    g_failures += Chk("out of range slave address is rejected", (uint32)HAL_ERROR,
                      (uint32)HAL_I2C_Init(&hi2c_dev));

    /* Restore a valid configuration */
    I2C_ApplyInit(TEST_DIV, I2C_ENABLE);
    g_failures += Chk("valid configuration is accepted again",
                      (uint32)HAL_I2C_STATE_READY, (uint32)HAL_I2C_GetState(&hi2c_dev));

    /* ---------------- Group 4: Cmd ---------------- */
    printf("--- group 4: HAL_I2C_Cmd ---\r\n");
    g_failures += Chk("Cmd(DISABLE) returns HAL_OK", (uint32)HAL_OK,
                      (uint32)HAL_I2C_Cmd(&hi2c_dev, DISABLE));
    g_failures += Chk("controller disabled in CTLR", 0U,
                      (uint32)((TEST_I2C->CTLR & I2C_CTRL_EN) ? 1U : 0U));
    g_failures += Chk("Cmd(ENABLE) returns HAL_OK", (uint32)HAL_OK,
                      (uint32)HAL_I2C_Cmd(&hi2c_dev, ENABLE));
    g_failures += Chk("controller enabled in CTLR", 1U,
                      (uint32)((TEST_I2C->CTLR & I2C_CTRL_EN) ? 1U : 0U));
    g_failures += Chk("Cmd(NULL) returns HAL_ERROR", (uint32)HAL_ERROR,
                      (uint32)HAL_I2C_Cmd(NULL_PTR, ENABLE));

    /* ---------------- Group 5: ITStructInit ---------------- */
    printf("--- group 5: HAL_I2C_ITStructInit ---\r\n");
    irq.ERRN = I2C_ENABLE;
    irq.SIEN = I2C_ENABLE;
    irq.TXEN = I2C_ENABLE;
    irq.RXEN = I2C_ENABLE;
    HAL_I2C_ITStructInit(&irq);
    g_failures += Chk("ERRN disabled by default", (uint32)I2C_DISABLE, irq.ERRN);
    g_failures += Chk("SIEN disabled by default", (uint32)I2C_DISABLE, irq.SIEN);
    g_failures += Chk("TXEN disabled by default", (uint32)I2C_DISABLE, irq.TXEN);
    g_failures += Chk("RXEN disabled by default", (uint32)I2C_DISABLE, irq.RXEN);
    HAL_I2C_ITStructInit(NULL_PTR);             /* must not fault */

    /* ---------------- Group 6: ITInit per source ---------------- */
    printf("--- group 6: HAL_I2C_ITInit ---\r\n");
    HAL_I2C_ITStructInit(&irq);
    irq.ERRN = I2C_ENABLE;
    g_failures += Chk("ITInit(ERRN) returns HAL_OK", (uint32)HAL_OK,
                      (uint32)HAL_I2C_ITInit(&hi2c_dev, &irq));
    g_failures += Chk("ERRN set in IRQC", (uint32)I2C_IRQC_ERRN,
                      (uint32)(TEST_I2C->IRQC & I2C_IRQC_ERRN));

    HAL_I2C_ITStructInit(&irq);
    irq.TXEN = I2C_ENABLE;
    g_failures += Chk("ITInit(TXEN) returns HAL_OK", (uint32)HAL_OK,
                      (uint32)HAL_I2C_ITInit(&hi2c_dev, &irq));
    g_failures += Chk("TXEN set in IRQC", (uint32)I2C_IRQC_TXEN,
                      (uint32)(TEST_I2C->IRQC & I2C_IRQC_TXEN));

    HAL_I2C_ITStructInit(&irq);
    irq.RXEN = I2C_ENABLE;
    g_failures += Chk("ITInit(RXEN) returns HAL_OK", (uint32)HAL_OK,
                      (uint32)HAL_I2C_ITInit(&hi2c_dev, &irq));
    g_failures += Chk("RXEN set in IRQC", (uint32)I2C_IRQC_RXNEN,
                      (uint32)(TEST_I2C->IRQC & I2C_IRQC_RXNEN));

    HAL_I2C_ITStructInit(&irq);
    irq.SIEN = I2C_ENABLE;
    g_failures += Chk("ITInit(SIEN) returns HAL_OK", (uint32)HAL_OK,
                      (uint32)HAL_I2C_ITInit(&hi2c_dev, &irq));
    g_failures += Chk("SIEN set in IRQC", (uint32)I2C_IRQC_SIEN,
                      (uint32)(TEST_I2C->IRQC & I2C_IRQC_SIEN));

    /* All sources disabled again */
    HAL_I2C_ITStructInit(&irq);
    g_failures += Chk("ITInit(all disabled) returns HAL_OK", (uint32)HAL_OK,
                      (uint32)HAL_I2C_ITInit(&hi2c_dev, &irq));
    g_failures += Chk("IRQC cleared", 0U, (uint32)TEST_I2C->IRQC);
    /* ---------------- Group 7: ITInit invalid parameters ---------------- */
    printf("--- group 7: HAL_I2C_ITInit invalid parameters ---\r\n");
    g_failures += Chk("ITInit(NULL handle) returns HAL_ERROR", (uint32)HAL_ERROR,
                      (uint32)HAL_I2C_ITInit(NULL_PTR, &irq));
    g_failures += Chk("ITInit(NULL config) returns HAL_ERROR", (uint32)HAL_ERROR,
                      (uint32)HAL_I2C_ITInit(&hi2c_dev, NULL_PTR));

    HAL_I2C_ITStructInit(&irq);
    irq.TXEN = 0x5AU;                           /* neither ENABLE nor DISABLE */
    saved = (uint32)TEST_I2C->IRQC;
    g_failures += Chk("invalid TXEN is rejected", (uint32)HAL_ERROR,
                      (uint32)HAL_I2C_ITInit(&hi2c_dev, &irq));
    g_failures += Chk("rejected ITInit leaves IRQC unchanged", saved,
                      (uint32)TEST_I2C->IRQC);
    g_failures += Chk("rejection reports INVALID_PARAM",
                      (uint32)HAL_I2C_ERROR_INVALID_PARAM, HAL_I2C_GetError(&hi2c_dev));

    /* ---------------- Group 8: GetITStatus / ClearITPendingBit ------- */
    printf("--- group 8: HAL_I2C_GetITStatus / ClearITPendingBit ---\r\n");
    Info("GetITStatus (interrupt flag) =", HAL_I2C_GetITStatus(&hi2c_dev));
    HAL_I2C_ClearITPendingBit(&hi2c_dev);
    g_failures += Chk("ClearITPendingBit clears CTLR.INT", 0U,
                      (uint32)((TEST_I2C->CTLR & I2C_CTRL_INT) ? 1U : 0U));
    g_failures += Chk("GetITStatus is 0 after the clear", 0U,
                      HAL_I2C_GetITStatus(&hi2c_dev));
    HAL_I2C_ClearITPendingBit(NULL_PTR);        /* must not fault */

    /* ---------------- Group 8b: shared internal helpers ------------- */
    printf("--- group 8b: shared internal helpers ---\r\n");
    g_failures += Chk("I2C_CheckState on a READY handle returns HAL_OK",
                      (uint32)HAL_OK, (uint32)I2C_CheckState(&hi2c_dev));
    g_failures += Chk("I2C_LockHandle takes a free lock", (uint32)HAL_OK,
                      (uint32)I2C_LockHandle(&hi2c_dev, 0U));
    g_failures += Chk("I2C_LockHandle on a locked handle returns HAL_BUSY",
                      (uint32)HAL_BUSY, (uint32)I2C_LockHandle(&hi2c_dev, 0U));
    I2C_UnlockHandle(&hi2c_dev);
    g_failures += Chk("I2C_LockHandle after the unlock succeeds", (uint32)HAL_OK,
                      (uint32)I2C_LockHandle(&hi2c_dev, 0U));
    I2C_UnlockHandle(&hi2c_dev);

    /* ---------------- Group 9: low level register group ------------- */
    printf("--- group 9: low level register group ---\r\n");
    /* The controller is disabled so that nothing is driven on to the bus; the
     * low level group is register access only. */
    (void)HAL_I2C_Cmd(&hi2c_dev, DISABLE);

    saved = (uint32)TEST_I2C->CTLR;
    HAL_I2C_GenerateStart(&hi2c_dev);
    g_failures += Chk("GenerateStart sets CTLR.IICSTA", 1U,
                      (uint32)((TEST_I2C->CTLR & I2C_CTRL_IICSTA) ? 1U : 0U));
    HAL_I2C_StartClear(&hi2c_dev);
    g_failures += Chk("StartClear clears CTLR.IICSTA", 0U,
                      (uint32)((TEST_I2C->CTLR & I2C_CTRL_IICSTA) ? 1U : 0U));
    TEST_I2C->CTLR = (uint8)saved;

    HAL_I2C_AcknowledgeConfig(&hi2c_dev, I2C_ACK);
    g_failures += Chk("AcknowledgeConfig(ACK) sets CTLR.AA", 1U,
                      (uint32)((TEST_I2C->CTLR & I2C_CTRL_AA) ? 1U : 0U));
    HAL_I2C_AcknowledgeConfig(&hi2c_dev, I2C_NACK);
    g_failures += Chk("AcknowledgeConfig(NACK) clears CTLR.AA", 0U,
                      (uint32)((TEST_I2C->CTLR & I2C_CTRL_AA) ? 1U : 0U));

    HAL_I2C_SendData(&hi2c_dev, 0xA5U);
    data = HAL_I2C_ReceiveData(&hi2c_dev);
    Info("data register read back after a write =", (uint32)data);

    /* The running state of an idle controller is reported as BUS_IDLE */
    Info("running state (STAT.STATE) =", (uint32)HAL_I2C_GetFlagStatus(&hi2c_dev));
    g_failures += Chk("CheckStatus(BUS_IDLE) on an idle controller", 1U,
                      HAL_I2C_CheckStatus(&hi2c_dev, I2C_STATE_BUS_IDLE));
    g_failures += Chk("CheckStatus(unsupported state) is 0", 0U,
                      HAL_I2C_CheckStatus(&hi2c_dev, I2C_STATE_MASTER_START_REPEAT));

    /* The low level group must tolerate a NULL handle */
    HAL_I2C_GenerateStart(NULL_PTR);
    HAL_I2C_GenerateStop(NULL_PTR);
    HAL_I2C_StartClear(NULL_PTR);
    HAL_I2C_Send7bitAddress(NULL_PTR, TEST_OWN_ADDRESS, I2C_WRITE);
    HAL_I2C_AcknowledgeConfig(NULL_PTR, I2C_ACK);
    HAL_I2C_SendData(NULL_PTR, 0x00U);
    g_failures += Chk("ReceiveData(NULL) returns 0", 0U,
                      (uint32)HAL_I2C_ReceiveData(NULL_PTR));
    g_failures += Chk("GetFlagStatus(NULL) returns 0", 0U,
                      (uint32)HAL_I2C_GetFlagStatus(NULL_PTR));
    g_failures += Chk("CheckStatus(NULL) returns 0", 0U,
                      HAL_I2C_CheckStatus(NULL_PTR, I2C_STATE_BUS_IDLE));

    /* ---------------- Group 10: transfer API parameter guard -------- */
    printf("--- group 10: transfer API parameter guard ---\r\n");
    (void)HAL_I2C_Cmd(&hi2c_dev, ENABLE);

    g_failures += Chk("Master_Transmit(NULL data) is rejected", (uint32)HAL_ERROR,
                      (uint32)HAL_I2C_Master_Transmit(&hi2c_dev, 0x55U, NULL_PTR,
                                                      16U, 100U));
    g_failures += Chk("Master_Transmit(zero size) is rejected", (uint32)HAL_ERROR,
                      (uint32)HAL_I2C_Master_Transmit(&hi2c_dev, 0x55U, &data,
                                                      0U, 100U));
    g_failures += Chk("Master_Transmit(bad address) is rejected", (uint32)HAL_ERROR,
                      (uint32)HAL_I2C_Master_Transmit(&hi2c_dev, 0x80U, &data,
                                                      1U, 100U));
    g_failures += Chk("Master_Receive(NULL data) is rejected", (uint32)HAL_ERROR,
                      (uint32)HAL_I2C_Master_Receive(&hi2c_dev, 0x55U, NULL_PTR,
                                                     16U, 100U));
    g_failures += Chk("Master_Receive(bad address) is rejected", (uint32)HAL_ERROR,
                      (uint32)HAL_I2C_Master_Receive(&hi2c_dev, 0x80U, &data,
                                                     1U, 100U));
    g_failures += Chk("Slave_Transmit(NULL data) is rejected", (uint32)HAL_ERROR,
                      (uint32)HAL_I2C_Slave_Transmit(&hi2c_dev, NULL_PTR, 16U, 100U));
    g_failures += Chk("Slave_Receive(zero size) is rejected", (uint32)HAL_ERROR,
                      (uint32)HAL_I2C_Slave_Receive(&hi2c_dev, &data, 0U, 100U));
    g_failures += Chk("rejections report INVALID_PARAM",
                      (uint32)HAL_I2C_ERROR_INVALID_PARAM, HAL_I2C_GetError(&hi2c_dev));
    g_failures += Chk("handle stays READY after the rejections",
                      (uint32)HAL_I2C_STATE_READY, (uint32)HAL_I2C_GetState(&hi2c_dev));

    /* ---------------- Group 11: DeInit ---------------- */
    printf("--- group 11: HAL_I2C_DeInit ---\r\n");

    /* I2C-REQ-013 defines the de-initialization as "acquire the lock, disable
     * the peripheral, return to the RESET state, release the lock, then run
     * MspDeInit outside the lock": the only register it touches is the enable
     * bit. The rest of the register file keeps whatever the last
     * HAL_I2C_Init() programmed, which is harmless because the next
     * initialization rewrites every configured field. The snapshot below is
     * taken before the call and compared against the snapshot MspDeInit()
     * takes while the clock gate is still open. */
    saved_ctlr = (uint32)TEST_I2C->CTLR;
    saved_addr = (uint32)TEST_I2C->ADDR;
    saved_div_l = (uint32)TEST_I2C->DIV_L;
    saved_div_h = (uint32)TEST_I2C->DIV_H;
    saved_irqc = (uint32)TEST_I2C->IRQC;

    g_failures += Chk("DeInit returns HAL_OK", (uint32)HAL_OK,
                      (uint32)HAL_I2C_DeInit(&hi2c_dev));
    g_failures += Chk("state after DeInit is RESET", (uint32)HAL_I2C_STATE_RESET,
                      (uint32)HAL_I2C_GetState(&hi2c_dev));
    g_failures += Chk("MspDeInit was called once", 1U, g_msp_deinit_cnt);
    g_failures += Chk("MspDeInit saw the RESET state", (uint32)HAL_I2C_STATE_RESET,
                      g_msp_deinit_state);
    g_failures += Chk("DeInit clears CTLR.EN", 0U,
                      g_deinit_ctlr & (uint32)I2C_CTRL_EN);
    g_failures += Chk("CTLR.EN was set before DeInit", (uint32)I2C_CTRL_EN,
                      saved_ctlr & (uint32)I2C_CTRL_EN);
    g_failures += Chk("rest of CTLR untouched by DeInit",
                      saved_ctlr & ~(uint32)I2C_CTRL_EN,
                      g_deinit_ctlr & ~(uint32)I2C_CTRL_EN);
    g_failures += Chk("CTLR keeps the configured clock scale",
                      (uint32)I2C_CLOCKSCALE_PCLK_8,
                      g_deinit_ctlr & (uint32)I2C_CTRL_CLK);
    g_failures += Chk("ADDR keeps the programmed own address", saved_addr,
                      g_deinit_addr);
    g_failures += Chk("ADDR holds the shifted own address",
                      (uint32)(TEST_OWN_ADDRESS << 1U), g_deinit_addr);
    g_failures += Chk("DIV_L keeps the programmed divider", saved_div_l,
                      g_deinit_div_l);
    g_failures += Chk("DIV_H unchanged by DeInit", saved_div_h, g_deinit_div_h);
    g_failures += Chk("IRQC unchanged by DeInit", saved_irqc, g_deinit_irqc);
    Info("CTLR after DeInit =", g_deinit_ctlr);
    Info("DIV_L after DeInit =", g_deinit_div_l);
    g_failures += Chk("DeInit(NULL) returns HAL_ERROR", (uint32)HAL_ERROR,
                      (uint32)HAL_I2C_DeInit(NULL_PTR));
    (void)HAL_I2C_DeInit(&hi2c_dev);            /* repeated DeInit must not fault */

    /* ---------------- Group 12: re-initialization ---------------- */
    printf("--- group 12: re-initialization after DeInit ---\r\n");
    I2C_ApplyInit(TEST_DIV, I2C_ENABLE);
    g_failures += Chk("state is READY again", (uint32)HAL_I2C_STATE_READY,
                      (uint32)HAL_I2C_GetState(&hi2c_dev));
    g_failures += Chk("MspInit ran again", 2U, g_msp_init_cnt);
    g_failures += Chk("DIV_L holds the new divider", (uint32)TEST_DIV,
                      (uint32)TEST_I2C->DIV_L);
    g_failures += Chk("controller enabled again", 1U,
                      (uint32)((TEST_I2C->CTLR & I2C_CTRL_EN) ? 1U : 0U));
    g_failures += Chk("error code is NONE after the restart",
                      (uint32)HAL_I2C_ERROR_NONE, HAL_I2C_GetError(&hi2c_dev));
    Info("SCL estimate (Hz) =", HAL_SMU_GetPCLK0Freq() / 8U / TEST_DIV);

    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(g_failures));

    while (1)
    {
    }
}

/**
 * @brief  Apply a configuration to the handle and initialize the peripheral.
 * @param  Divider: low divider register value.
 * @param  Enable: I2C_ENABLE or I2C_DISABLE.
 * @retval None
 */
static void I2C_ApplyInit(uint32 Divider, uint32 Enable)
{
    I2C_InitTypeDef init;

    __HAL_CLEAR_STRUCT(&init);
    init.Size             = sizeof(I2C_InitTypeDef);
    init.Version          = I2C_INIT_VERSION;
    init.I2C_ClockScale   = I2C_CLOCKSCALE_PCLK_8;
    init.I2C_ICLKDIVL     = (uint8)Divider;
    init.I2C_ICLKDIVH     = 0x00U;
    init.I2C_EN           = Enable;
    init.I2C_SlaveAddress = TEST_OWN_ADDRESS;
    init.I2C_Ack          = I2C_ACK;

    hi2c_dev.Instance = TEST_I2C;
    hi2c_dev.Init     = init;
    (void)HAL_I2C_Init(&hi2c_dev);
}

/**
 * @brief  Low level initialization of the I2C peripheral (weak override).
 * @note   Called by HAL_I2C_Init() before the first register access and only
 *         while the handle is in the RESET state (MSP-04 / LOCK-06).  The
 *         callback records the invocation so that the case can check it.
 * @param  hi2c: I2C handle.
 * @retval None
 */
void HAL_I2C_MspInit(I2C_HandleTypeDef *hi2c)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    if (hi2c->Instance != TEST_I2C)
    {
        return;
    }

    g_msp_init_cnt++;
    g_msp_init_state = (uint32)hi2c->State;
    g_msp_init_lock  = (uint32)hi2c->Lock;

    /* Peripheral clock gate and a reset pulse */
    __HAL_SMU_IIC1_CLK_ENABLE();
    __HAL_SMU_IIC1_FORCE_RESET();
    __HAL_SMU_IIC1_RELEASE_RESET();

    /* GPIO port clock of the two pins */
    __HAL_SMU_GPIOF_CLK_ENABLE();

    /* Alternate function mapping */
    HAL_GPIO_PinAFConfig(TEST_SCL_PORT, TEST_SCL_SOURCE, TEST_AF);
    HAL_GPIO_PinAFConfig(TEST_SDA_PORT, TEST_SDA_SOURCE, TEST_AF);

    __HAL_CLEAR_STRUCT(&GPIO_InitStruct);
    GPIO_InitStruct.Size         = sizeof(GPIO_InitStruct);
    GPIO_InitStruct.Version      = GPIO_INIT_VERSION;
    GPIO_InitStruct.Pin          = TEST_SCL_PIN;
    GPIO_InitStruct.Mode         = GPIO_MODE_AF_OD;
    GPIO_InitStruct.Pull         = GPIO_PULLUP;
    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;
    GPIO_InitStruct.Alternate    = TEST_AF;
    HAL_GPIO_Init(TEST_SCL_PORT, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = TEST_SDA_PIN;
    HAL_GPIO_Init(TEST_SDA_PORT, &GPIO_InitStruct);
}

/**
 * @brief  Low level de-initialization of the I2C peripheral (weak override).
 * @note   Called by HAL_I2C_DeInit() after the handle lock has been released
 *         (LOCK-06).  The callback records the invocation, the state it saw and
 *         the register content left behind by the HAL, all while the peripheral
 *         clock is still enabled (a clock gated read is not observable).
 * @param  hi2c: I2C handle.
 * @retval None
 */
void HAL_I2C_MspDeInit(I2C_HandleTypeDef *hi2c)
{
    if (hi2c->Instance != TEST_I2C)
    {
        return;
    }

    g_msp_deinit_cnt++;
    g_msp_deinit_state = (uint32)hi2c->State;

    g_deinit_ctlr  = (uint32)TEST_I2C->CTLR;
    g_deinit_addr  = (uint32)TEST_I2C->ADDR;
    g_deinit_div_l = (uint32)TEST_I2C->DIV_L;
    g_deinit_div_h = (uint32)TEST_I2C->DIV_H;
    g_deinit_irqc  = (uint32)TEST_I2C->IRQC;

    __HAL_SMU_IIC1_CLK_DISABLE();
}

/**
 * @brief  Initialize the clock tree, the SMU / PMU handles and the bus gates.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    osc;
    SMU_ClockInitTypeDef  clk;
    HAL_SMU_HandleTypeDef hsmu;

    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&hpmu_dev);
    hpmu_dev.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu_dev);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu_dev, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu_dev, PMU_VO12_1V34);

    __HAL_CLEAR_STRUCT(&hsmu);
    hsmu.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu);

    __HAL_CLEAR_STRUCT(&clk);
    clk.Size           = sizeof(clk);
    clk.Version        = SMU_CLOCK_INIT_VERSION;
    clk.AXI4Bus3CLKDiv = STD_AXI4BUS3_DIV;
    clk.APBBus0CLKDiv  = STD_APBBUS0_DIV;
    clk.APBBus1CLKDiv  = STD_APBBUS1_DIV;
    clk.CANX2CLKDiv    = STD_CANX2_DIV;
    (void)HAL_SMU_ClockConfig(&hsmu, &clk);

    __HAL_CLEAR_STRUCT(&osc);
    osc.Size                 = sizeof(osc);
    osc.Version              = SMU_OSC_INIT_VERSION;
    osc.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    osc.FIRCState            = SMU_FIRC_ON;
    osc.FIRCCalibrationValue = 0x00U;
    osc.PLL.Size             = sizeof(osc.PLL);
    osc.PLL.Version          = SMU_PLL_INIT_VERSION;
    osc.PLL.PLLState         = SMU_PLL_ON;
    osc.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    osc.PLL.PLLDivR          = STD_PLL_DIV_R;
    osc.PLL.PLLDivQ          = STD_PLL_DIV_Q;
    osc.PLL.PLLDivN          = STD_PLL_DIV_N;
    osc.PLL.PLLDivF          = STD_PLL_DIV_F;
    osc.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;
    (void)HAL_SMU_OscConfig(&hsmu, &osc, SMU_TIMEOUT_DEFAULT);
}

/**
 * @brief  Print one check and return the number of failures it contributes.
 * @param  name: check description.
 * @param  expect: expected value.
 * @param  actual: value read back.
 * @retval uint32: 0 when the check passed, 1 otherwise.
 */
static uint32 Chk(const char *name, uint32 expect, uint32 actual)
{
    uint32 fail = 0U;

    if (expect == actual)
    {
        printf("  [PASS] %s : expect %u, read %u\r\n",
               name, PRINT_U32(expect), PRINT_U32(actual));
    }
    else
    {
        printf("  [FAIL] %s : expect %u, read %u\r\n",
               name, PRINT_U32(expect), PRINT_U32(actual));
        fail = 1U;
    }

    return fail;
}

/**
 * @brief  Print a value without judging it.
 * @param  name: label.
 * @param  value: value to print.
 * @retval None
 */
static void Info(const char *name, uint32 value)
{
    printf("  [info] %s %u\r\n", name, PRINT_U32(value));
}

/*****END OF FILE*****/
