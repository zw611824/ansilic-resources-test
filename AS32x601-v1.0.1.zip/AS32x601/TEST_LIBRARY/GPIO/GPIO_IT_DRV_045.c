/**
 * @file    GPIO_IT_DRV_045.c
 * @brief   HAL GPIO integration test case 045 (extension: run time parameter
 *          validation and pin availability).
 *
 * This case is not part of the vendor plan (which has 43 cases): it is an
 * extension. It proves that every rejected call of HAL_GPIO_Init() leaves the
 * port registers untouched, so that the validation of the driver stays
 * effective in a build with the assertions disabled.
 *
 * Tested functionality:
 *   HAL_GPIO_Init()   (run time validation: Size / Version metafields,
 *                      reserved words, pin mask and pin availability, mode,
 *                      input type, drive current, alternate function, NULL
 *                      instance and NULL structure)
 *   HAL_GPIO_StructInit()  (through the prepared structure)
 *
 * Test configuration:
 *   GPIOD pins 0..3 : device under test of the validation checks (the port has
 *                     no pin whose reset default function is multiplexed)
 *   GPIOH pins 2..9 : pin availability checks (that port has ten channels, its
 *                     Pin10..Pin15 do not exist)
 *
 * Test procedure (every check is recorded in the observation masks below):
 *   step 1  baseline: an accepted configuration changes the registers      check  0
 *   step 2  rejected metadata: Size + 1, Size - 1, wrong Version,
 *           Reserved[0] != 0, Reserved[1] != 0                            checks 1..5
 *   step 3  rejected pin masks: Pin = 0, Pin = 0x00010000                 checks 6..7
 *   step 4  rejected business fields: unsupported mode, unsupported input
 *           type, unsupported drive current, unsupported alternate function
 *           in an alternate function mode                                   checks 8..11
 *   step 5  an accepted alternate function configuration                  check  12
 *   step 6  NULL instance and NULL structure                              checks 13..14
 *   step 7  GPIOH availability: Pin = GPIO_PIN_All refused, Pin = Pin10
 *           refused, Pin = 0 refused, Pin2..Pin9 accepted                checks 15..18
 *   step 8  the chip specific IDDQ mode and KEEP input type are accepted   checks 19..20
 *
 * Expected behaviour:
 *   The case prints nothing. Bit n of Passed_Mask is set when check n passed and
 *   bit n of Failed_Mask when it failed, so
 *     Failed_Mask == 0x00000000  and  Passed_Mask == 0x001FFFFF  and
 *     Check_Count == 21
 *   means that every check of this case passed (a rejected call is accepted by
 *   the check when the seven configuration registers of the port are bit
 *   identical before and after the call).
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"

/* Private define -----------------------------------------------------------*/
/* GPIOD pins used as the device under test of the validation checks */
#define GPIOD_TEST_PIN          (GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3)
#define GPIOD_AF_TEST_PIN       (GPIO_PIN_4)

/* GPIOH pins used by the pin availability checks */
#define GPIOH_AVAILABLE_PIN     (GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_5 | \
                                 GPIO_PIN_6 | GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9)

/* Unsupported values, none of them is part of the accepted sets of the driver */
#define INVALID_MODE            ((uint32)0x000000FFU)
#define INVALID_PULL            ((uint32)0x00000005U)
#define INVALID_DRIVE_CURRENT   ((uint32)0x00000004U)
#define INVALID_AF              ((uint8)0xFFU)
#define INVALID_VERSION         ((uint32)0x00000200U)
#define OUT_OF_RANGE_PIN        ((uint32)0x00010000U)

/* Number of checks of this case and the expected observation of the masks */
#define CHECK_ALL               ((uint32)0x001FFFFFU)
#define CHECK_TOTAL             (21U)

/* Private variables ---------------------------------------------------------*/
static HAL_SMU_HandleTypeDef hsmu_clk;    /*!< SMU handle (lock / state / error) */
static volatile uint32 Passed_Mask = 0U;  /*!< bit n set when check n passed      */
static volatile uint32 Failed_Mask = 0U;  /*!< bit n set when check n failed      */
static volatile uint32 Check_Count = 0U;  /*!< number of checks that were run     */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void check(uint32 index, uint32 condition);
static uint32 moder_field(GPIO_TypeDef *GPIOx, uint32 pin);
static uint32 im0cr_field(GPIO_TypeDef *GPIOx, uint32 pin);
static uint32 mi0sr_field(GPIO_TypeDef *GPIOx, uint32 pin);
static void port_snapshot(GPIO_TypeDef *GPIOx, uint32 *buf);
static uint32 port_snapshot_equal(const uint32 *a, const uint32 *b);

/**
 * @brief  Call HAL_GPIO_Init() with the structure prepared by the caller and
 *         record whether the configuration registers of the port were left
 *         untouched (which is what a rejected call shall do).
 * @note   It uses the snapshot_before / snapshot_after buffers of main().
 */
#define CHECK_REJECTED(idx)                                                   \
    do {                                                                      \
        port_snapshot(GPIOD, snapshot_before);                                \
        HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);                               \
        port_snapshot(GPIOD, snapshot_after);                                 \
        check((idx), port_snapshot_equal(snapshot_before, snapshot_after));   \
    } while (0)

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;
    uint32 snapshot_before[7];
    uint32 snapshot_after[7];

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Enable the clock gates used by this case (GPIOH has no clock gate) */
    __HAL_SMU_GPIOD_CLK_ENABLE();

    /* The structure every check starts from */
    __HAL_CLEAR_STRUCT(&GPIO_InitStruct);
    HAL_GPIO_StructInit(&GPIO_InitStruct);

    /* ---- Step 1: baseline, an accepted configuration (check 0) ----------- */

    GPIO_InitStruct.Pin          = GPIOD_TEST_PIN;
    GPIO_InitStruct.Mode         = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull         = GPIO_NOPULL;
    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

    check(0U, ((moder_field(GPIOD, 0U) == GPIO_MODE_VALUE_OUTPUT) &&
               (moder_field(GPIOD, 3U) == GPIO_MODE_VALUE_OUTPUT)) ? 1U : 0U);

    /* ---- Step 2: rejected Size / Version / reserved words (checks 1..5) -- */

    GPIO_InitStruct.Size = sizeof(GPIO_InitTypeDef) + 1U;
    CHECK_REJECTED(1U);
    GPIO_InitStruct.Size = sizeof(GPIO_InitTypeDef) - 1U;
    CHECK_REJECTED(2U);
    GPIO_InitStruct.Size = sizeof(GPIO_InitTypeDef);

    GPIO_InitStruct.Version = INVALID_VERSION;
    CHECK_REJECTED(3U);
    GPIO_InitStruct.Version = GPIO_INIT_VERSION;

    GPIO_InitStruct.Reserved[0] = 1U;
    CHECK_REJECTED(4U);
    GPIO_InitStruct.Reserved[0] = 0U;

    GPIO_InitStruct.Reserved[1] = 1U;
    CHECK_REJECTED(5U);
    GPIO_InitStruct.Reserved[1] = 0U;

    /* ---- Step 3: rejected pin masks (checks 6..7) ------------------------ */

    GPIO_InitStruct.Pin = 0U;
    CHECK_REJECTED(6U);

    GPIO_InitStruct.Pin = OUT_OF_RANGE_PIN;
    CHECK_REJECTED(7U);

    /* ---- Step 4: rejected business fields (checks 8..11) ----------------- */

    GPIO_InitStruct.Pin  = GPIOD_TEST_PIN;
    GPIO_InitStruct.Mode = INVALID_MODE;
    CHECK_REJECTED(8U);

    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = INVALID_PULL;
    CHECK_REJECTED(9U);
    GPIO_InitStruct.Pull = GPIO_NOPULL;

    GPIO_InitStruct.DriveCurrent = INVALID_DRIVE_CURRENT;
    CHECK_REJECTED(10U);
    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;

    /* In an alternate function mode the alternate function itself is part of
       the contract, so an unsupported value is refused as well */
    GPIO_InitStruct.Pin       = GPIOD_AF_TEST_PIN;
    GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Alternate = INVALID_AF;
    CHECK_REJECTED(11U);

    /* ---- Step 5: an accepted alternate function (check 12) --------------- */

    GPIO_InitStruct.Alternate = GPIO_AF_USART0;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
    check(12U, (mi0sr_field(GPIOD, 4U) == (uint32)GPIO_AF_USART0) ? 1U : 0U);

    /* ---- Step 6: NULL arguments (checks 13..14) -------------------------- */

    GPIO_InitStruct.Pin       = GPIOD_TEST_PIN;
    GPIO_InitStruct.Mode      = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Alternate = GPIO_AF_Pin_x;

    port_snapshot(GPIOD, snapshot_before);
    HAL_GPIO_Init(NULL_PTR, &GPIO_InitStruct);
    port_snapshot(GPIOD, snapshot_after);
    check(13U, port_snapshot_equal(snapshot_before, snapshot_after));

    port_snapshot(GPIOD, snapshot_before);
    HAL_GPIO_Init(GPIOD, NULL_PTR);
    port_snapshot(GPIOD, snapshot_after);
    check(14U, port_snapshot_equal(snapshot_before, snapshot_after));

    /* ---- Step 7: GPIOH pin availability (checks 15..18) ------------------ */

    /* GPIO_PIN_All names the channels 10..15, which that port does not have */
    __HAL_CLEAR_STRUCT(&GPIO_InitStruct);
    GPIO_InitStruct.Size         = sizeof(GPIO_InitTypeDef);
    GPIO_InitStruct.Version      = GPIO_INIT_VERSION;
    GPIO_InitStruct.Pin          = GPIO_PIN_All;
    GPIO_InitStruct.Mode         = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull         = GPIO_NOPULL;
    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;

    port_snapshot(GPIOH, snapshot_before);
    HAL_GPIO_Init(GPIOH, &GPIO_InitStruct);
    port_snapshot(GPIOH, snapshot_after);
    check(15U, port_snapshot_equal(snapshot_before, snapshot_after));

    GPIO_InitStruct.Pin = GPIO_PIN_10;
    port_snapshot(GPIOH, snapshot_before);
    HAL_GPIO_Init(GPIOH, &GPIO_InitStruct);
    port_snapshot(GPIOH, snapshot_after);
    check(16U, port_snapshot_equal(snapshot_before, snapshot_after));

    GPIO_InitStruct.Pin = 0U;
    port_snapshot(GPIOH, snapshot_before);
    HAL_GPIO_Init(GPIOH, &GPIO_InitStruct);
    port_snapshot(GPIOH, snapshot_after);
    check(17U, port_snapshot_equal(snapshot_before, snapshot_after));

    GPIO_InitStruct.Pin = GPIOH_AVAILABLE_PIN;
    HAL_GPIO_Init(GPIOH, &GPIO_InitStruct);
    check(18U, ((moder_field(GPIOH, 2U) == GPIO_MODE_VALUE_OUTPUT) &&
                (moder_field(GPIOH, 9U) == GPIO_MODE_VALUE_OUTPUT)) ? 1U : 0U);

    /* ---- Step 8: the chip specific values of the extension (checks 19..20) */

    GPIO_InitStruct.Pin  = GPIOD_TEST_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_IDDQ;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
    check(19U, (moder_field(GPIOD, 0U) == GPIO_MODE_VALUE_IDDQ) ? 1U : 0U);

    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLKEEP;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
    check(20U, (im0cr_field(GPIOD, 0U) == GPIO_PULLKEEP) ? 1U : 0U);

    /* Every check has been recorded; the loop keeps the observables alive */
    while (1)
    {
        delay_ms(500U);
    }
}

/**
 * @brief  Record the result of one check.
 * @param  index: check number, used as the bit position of the mask.
 * @param  condition: 1 when the check passed, 0 when it failed.
 * @retval None
 */
static void check(uint32 index, uint32 condition)
{
    Check_Count++;

    if (condition != 0U)
    {
        Passed_Mask |= ((uint32)0x01U << index);
    }
    else
    {
        Failed_Mask |= ((uint32)0x01U << index);
    }
}

/**
 * @brief  Read the RWM0CR mode field of one pin (00 input, 01 output, 10 analog,
 *         11 IDDQ).
 * @param  GPIOx: port to read.
 * @param  pin: pin index (0..15).
 * @retval The two bit mode field of that pin.
 */
static uint32 moder_field(GPIO_TypeDef *GPIOx, uint32 pin)
{
    return ((GPIO_READ_REG(GPIOx, RWM0CR) >> (pin * 2U)) & 0x03U);
}

/**
 * @brief  Read the IM0CR pull / input type field of one pin.
 * @param  GPIOx: port to read.
 * @param  pin: pin index (0..15).
 * @retval The two bit input type field of that pin.
 */
static uint32 im0cr_field(GPIO_TypeDef *GPIOx, uint32 pin)
{
    return ((GPIO_READ_REG(GPIOx, IM0CR) >> (pin * 2U)) & 0x03U);
}

/**
 * @brief  Read the MI0SR alternate function field of one pin (channels 0..9).
 * @param  GPIOx: port to read.
 * @param  pin: pin index (0..9).
 * @retval The three bit alternate function field of that pin.
 */
static uint32 mi0sr_field(GPIO_TypeDef *GPIOx, uint32 pin)
{
    return ((GPIO_READ_REG(GPIOx, MI0SR) >> (pin * 3U)) & 0x07U);
}

/**
 * @brief  Snapshot the seven configuration registers of a port.
 * @param  GPIOx: port to read.
 * @param  buf: buffer of seven words, filled in the order
 *         RWM0CR / IM0CR / OMCR / OICR / MI0SR / ITYPE0R / IMR.
 * @retval None
 */
static void port_snapshot(GPIO_TypeDef *GPIOx, uint32 *buf)
{
    buf[0] = GPIO_READ_REG(GPIOx, RWM0CR);
    buf[1] = GPIO_READ_REG(GPIOx, IM0CR);
    buf[2] = GPIO_READ_REG(GPIOx, OMCR);
    buf[3] = GPIO_READ_REG(GPIOx, OICR);
    buf[4] = GPIO_READ_REG(GPIOx, MI0SR);
    buf[5] = GPIO_READ_REG(GPIOx, ITYPE0R);
    buf[6] = GPIO_READ_REG(GPIOx, IMR);
}

/**
 * @brief  Compare two port snapshots.
 * @param  a: first snapshot.
 * @param  b: second snapshot.
 * @retval 1 when the seven registers are bit identical, 0 otherwise.
 */
static uint32 port_snapshot_equal(const uint32 *a, const uint32 *b)
{
    uint32 i;

    for (i = 0U; i < 7U; i++)
    {
        if (a[i] != b[i])
        {
            return 0U;
        }
    }

    return 1U;
}

/**
 * @brief  Configure the system clock tree (PLL 180 MHz, as the original test).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef  SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef   SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    HAL_PMU_LDO2v5VOLSca(&hpmu, 0xf);
    HAL_PMU_LDO1v2VOLSca(&hpmu, 0xf);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it (CLKFRQ above), so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Clock tree order: this is the order the chip requires, and the vendor
       test case uses the same one.
         1. Write the bus clock dividers while the system clock is still the
            power-on source (FIRC), so that the new divider values are already
            in place when the faster clock arrives. Writing them AFTER the
            switch instead leaves the buses at their reset dividers for a
            moment at the new core clock: at 180 MHz that is
            AXI4Bus3 = 90 MHz and APBBus0 = 45 MHz, right at their ratings, and
            the core does not survive it (measured on the board: the core
            trapped before the divider write was reached, so no output was
            produced at all).
         2. Program the EFLASH controller clock: the controller must already
            know the final frequency while the code still runs from the flash.
         3. Then configure the PLL and switch the system clock to it; this call
            also updates SystemCoreClock and re-initializes the HAL time base. */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
