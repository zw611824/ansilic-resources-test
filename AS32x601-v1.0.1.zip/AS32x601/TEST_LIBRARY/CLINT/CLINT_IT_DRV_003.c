/**
 * @file    CLINT_IT_DRV_003.c
 * @brief   HAL CLINT integration test case 003 (machine software interrupt).
 *
 * One-to-one HAL library port of the original AS32x601 standard-library
 * test case CLINT_IT_DRV_003.c. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_CLINT_Init()
 *   HAL_CLINT_SoftIntCmd()
 *   HAL_CLINT_ClearSoftInt() (interrupt safe clear used by the MSI handler)
 *   HAL_CLINT_GetState()
 *   HAL_CLINT_GetError()
 *
 * Test procedure:
 *   1. Initialize the CLINT and enable the machine software interrupt (MSI)
 *      in the mie CSR;
 *   2. Raise the software interrupt pending bit with
 *      HAL_CLINT_SoftIntCmd(&hclint, 1U);
 *   3. Wait for the interrupt: MSoftWare_IRQ_Handler() clears the pending bit
 *      and masks the source, and increments the interrupt counter;
 *   4. Clear the pending bit with HAL_CLINT_SoftIntCmd(&hclint, 0U) and verify
 *      that no further interrupt is generated while the source is enabled;
 *   5. Repeat steps 2..4.
 *
 * Expected behaviour:
 *   - Every HAL_CLINT_SoftIntCmd(&hclint, 1U) raises exactly one software
 *     interrupt (the counter increases by one);
 *   - After HAL_CLINT_SoftIntCmd(&hclint, 0U) the counter does not change
 *     during the observation window.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"
#include "core_riscv.h"          /* csr_set_bits / csr_clear_bits / CSR_MIE   */

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Observation window after each software interrupt operation */
#define TEST_WINDOW_MS              (300U)

/* Private variables ---------------------------------------------------------*/
static HAL_CLINT_HandleTypeDef hclint;      /*!< CLINT handle                 */
static volatile uint32 softint_count = 0U;  /*!< software interrupt counter   */

static HAL_SMU_HandleTypeDef hsmu_clk;   /*!< SMU handle (lock / state / error) */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    uint32 count_before;
    uint32 round = 0U;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== CLINT_IT_DRV_003: machine software interrupt ===\r\n");

    /* Initialize the CLINT peripheral */
    hclint.Instance = CLINT;
    if (HAL_CLINT_Init(&hclint) != HAL_OK)
    {
        printf("HAL_CLINT_Init failed\r\n");
        while (1)
        {
        }
    }

    printf("CLINT state = %u (1 = READY), error = %u\r\n",
           PRINT_U32(HAL_CLINT_GetState(&hclint)),
           PRINT_U32(HAL_CLINT_GetError(&hclint)));

    while (1)
    {
        round++;
        printf("\r\n--- round %u ---\r\n", PRINT_U32(round));

        /* Step 2: enable MSI and raise the pending bit */
        count_before = softint_count;
        csr_set_bits(CSR_MIE, MIE_MSIE);
        HAL_CLINT_SoftIntCmd(&hclint, 1U);
        delay_ms(TEST_WINDOW_MS);

        printf("trigger : count %u -> %u (expected +1)  [%s]\r\n",
               PRINT_U32(count_before), PRINT_U32(softint_count),
               ((softint_count == (count_before + 1U)) ? "PASS" : "FAIL"));

        /* Step 4: clear the pending bit, keep MSI enabled, expect no trigger */
        count_before = softint_count;
        csr_clear_bits(CSR_MIE, MIE_MSIE);
        HAL_CLINT_SoftIntCmd(&hclint, 0U);
        HAL_CLINT_SoftIntCmd(&hclint, 0U);
        csr_set_bits(CSR_MIE, MIE_MSIE);
        delay_ms(TEST_WINDOW_MS);

        printf("clear   : count %u -> %u (expected +0)  [%s]\r\n",
               PRINT_U32(count_before), PRINT_U32(softint_count),
               ((softint_count == count_before) ? "PASS" : "FAIL"));

        csr_clear_bits(CSR_MIE, MIE_MSIE);
        delay_ms(TEST_WINDOW_MS);
    }
}

/**
 * @brief  Machine software interrupt handler (weak symbol of the trap entry).
 * @param  None
 * @retval None
 */
void MSoftWare_IRQ_Handler(void)
{
    /* Clear the software interrupt pending bit and mask the source, so that
     * the handler is executed exactly once per HAL_CLINT_SoftIntCmd(x, 1U). */
    /* Interrupt safe clear: takes no handle lock (LOCK-04 / RTOS-12) */
    HAL_CLINT_ClearSoftInt(&hclint);
    csr_clear_bits(CSR_MIE, MIE_MSIE);

    softint_count++;
}

/**
 * @brief  Configure the system clock tree using the HAL SMU driver.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef  SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef   SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it (CLKFRQ above), so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Clock tree order: this is the order the chip requires, and the vendor
       test case uses the same one.
         1. Write the bus clock dividers while the system clock is still the
            power-on source (FIRC), so that the new divider values are already
            in place when the faster clock arrives. Writing them AFTER the
            switch instead leaves the buses at their reset dividers for a
            moment at the new core clock: at 180 MHz that is
            AXI4Bus3 = 90 MHz and APBBus0 = 45 MHz, right at their ratings, and
            the core does not survive it (measured on the board: the core
            trapped before the divider write was reached, so no output was
            produced at all).
         2. Program the EFLASH controller clock: the controller must already
            know the final frequency while the code still runs from the flash.
         3. Then configure the PLL and switch the system clock to it; this call
            also updates SystemCoreClock and re-initializes the HAL time base. */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
