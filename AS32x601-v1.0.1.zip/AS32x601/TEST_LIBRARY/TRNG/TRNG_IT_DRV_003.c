/**
 * @file    TRNG_IT_DRV_003.c
 * @brief   HAL TRNG integration test case 003 (polling generation API (ownership, stale completion, masked source)).
 *
 * HAL library extension case (no reference standard-library counterpart).
 * Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_TRNG_GenerateRandomNumber()   (bounded polling generation)
 *   HAL_TRNG_ReadLastRandomNumber() / HAL_TRNG_GetRandomNumber0()
 *   HAL_TRNG_ITConfig()               (completion source mask / restore)
 *   HAL_TRNG_SendCommand() / HAL_TRNG_GetITStatus() / ClearITPendingBit()
 *   HAL_PLIC_Init()                   (armed interrupt line)
 *   TRNG_POLLING_BUDGET_MS            (public polling budget)
 *
 * Test procedure:
 *   Seed the DRBG, enable the completion source and arm the interrupt
 *   line, then:
 *     A. generate one word with HAL_TRNG_GenerateRandomNumber(); the wait
 *        masks IE.DONE and must restore it on the way out, so the armed
 *        interrupt line cannot consume the polling completion;
 *     B. leave a raw GEN_RANDOM completion pending (a stale DONE), then run
 *        the polling API 8 times and compare the results with the stale
 *        word read before the loop;
 *     C. verify that a disabled IE.DONE stays disabled after a poll;
 *     D. verify that consecutive polls return different words.
 *
 * Expected behaviour:
 *   the polling call returns HAL_OK well inside TRNG_POLLING_BUDGET_MS,
 *   the output equals the cached word, DONE is cleared, IE.DONE is
 *   restored to the application setting, the data callback never runs
 *   during a poll, the stale completion is never reported, and
 *   "summary : failures = 0" is printed.
 *
 * Note:
 *   HAL extension case. It covers the three behaviours the driver was
 *   given after the dual version comparison: the polling wait owns the
 *   completion it observes (stale DONE cleared, IE.DONE masked and
 *   restored) and the wait is bounded by a budget converted with
 *   HAL_GetTickFreq().
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
#define TEST_BAUDRATE                  (115200U)   /*!< console baud rate     */
#define TEST_STEP_TIMEOUT_MS           (1000U)     /*!< per step wait budget  */
#define TEST_ROUND_DELAY_MS            (2000U)     /*!< delay between rounds  */

/* Private variables ---------------------------------------------------------*/
static volatile uint32 check_failures = 0U;   /*!< failed check counter        */
static HAL_SMU_HandleTypeDef hsmu_clk;        /*!< SMU handle (clock tree)     */

/**
 * @brief  TRNG handle used by every case of this suite.
 * @note   The peripheral is a single instance, so one handle is enough; the
 *         lifecycle case uses additional local handles for the refusal paths.
 */
TRNG_HandleTypeDef htrng_dev;

/* MSP callback bookkeeping (written by the shared MSP callbacks) */
uint32 Trng_MspInitCount   = 0U;              /*!< HAL_TRNG_MspInit() calls    */
uint32 Trng_MspDeInitCount = 0U;              /*!< HAL_TRNG_MspDeInit() calls  */
uint32 Trng_MspStateAtInit = 0xFFFFFFFFU;     /*!< handle state seen in the MSP */
uint32 Trng_MspLockAtInit  = 0xFFFFFFFFU;     /*!< handle lock seen in the MSP  */

/* Shared helpers of this suite (defined at the end of this file) */
void Check(const char *name, uint32 condition);
void Summary(void);
void SystemClock_Init(void);
void Trng_ClockEnable(void);
void Trng_PlicEnable(uint8 priority);
HAL_StatusTypeDef Trng_WaitFlag(uint32 flag, uint32 timeout_ms);
HAL_StatusTypeDef Trng_Seed(uint32 timeout_ms);



/* Private define ------------------------------------------------------------*/
#define TEST_STALE_ROUNDS             (8U)     /*!< stale completion probes    */

/* Private variables ---------------------------------------------------------*/
static volatile uint32 ready_callbacks = 0U;   /*!< data ready callbacks       */
static volatile uint32 done_events     = 0U;   /*!< DONE events served         */

/* Private function prototypes -----------------------------------------------*/
static void Trng_AckApplicationEvents(void);
static HAL_StatusTypeDef Trng_RawCommandAndWait(uint32 command, uint32 flag);

/**
 * @brief  TRNG interrupt entry (overrides the weak PLIC dispatch entry).
 * @note   The driver owns an interrupt generation (it publishes BUSY and enables
 *         the completion source), so the completion is consumed by
 *         HAL_TRNG_IRQHandler() and delivered through the ready callback. The
 *         application only acknowledges an event that the driver left pending,
 *         so that a level triggered source can never re-enter this handler.
 * @param  None
 * @retval None
 */
void TRNG_IRQ_Handler(void)
{
    HAL_TRNG_IRQHandler(&htrng_dev);

    Trng_AckApplicationEvents();
}

/**
 * @brief  Weak data ready callback of the driver (overridden for the check).
 * @param  htrng: TRNG handle
 * @param  random32bit: generated random number
 * @retval None
 */
void HAL_TRNG_ReadyDataCallback(TRNG_HandleTypeDef *htrng, uint32 random32bit)
{
    (void)htrng;
    (void)random32bit;

    ready_callbacks++;
}

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    TRNG_InitTypeDef  trng_init;
    HAL_StatusTypeDef status;
    uint32 round = 0U;
    uint32 value = 0U;
    uint32 stale = 0U;
    uint32 differ = 0U;
    uint32 tickstart;
    uint32 elapsed;
    uint32 i;
    uint32 previous = 0U;
    uint32 changes = 0U;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== TRNG_IT_DRV_003 : polling generation API ===\r\n");

    /* Handle preparation */
    __HAL_CLEAR_STRUCT(&htrng_dev);
    htrng_dev.Instance = TRNG;
    HAL_TRNG_StructInit(&trng_init);
    htrng_dev.Init = trng_init;

    status = HAL_TRNG_Init(&htrng_dev);
    Check("HAL_TRNG_Init() returns HAL_OK", (status == HAL_OK) ? 1U : 0U);

    /* The DRBG must be seeded before the generation interfaces are usable */
    status = Trng_Seed(TEST_STEP_TIMEOUT_MS);
    Check("the DRBG startup sequence completes", (status == HAL_OK) ? 1U : 0U);

    /* ---- A. the polling generation API, with the completion source armed -- */
    HAL_TRNG_ITConfig(&htrng_dev, (uint32)(TRNG_IT_DONE | TRNG_IT_GLBL), ENABLE);
    Check("IE.DONE and IE.GLBL are enabled before the polling call",
          ((TRNG->IE & (TRNG_IT_DONE | TRNG_IT_GLBL)) == (TRNG_IT_DONE | TRNG_IT_GLBL)) ? 1U : 0U);

    /* Arm the interrupt line as well: if the polling wait did not mask the
     * completion source, the interrupt handler would steal the completion */
    Trng_PlicEnable(1U);
    ready_callbacks = 0U;

    tickstart = HAL_GetTick();
    status    = HAL_TRNG_GenerateRandomNumber(&htrng_dev, &value);
    elapsed   = HAL_GetTick() - tickstart;

    Check("HAL_TRNG_GenerateRandomNumber() returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("the output equals the cached random word",
          (value == HAL_TRNG_ReadLastRandomNumber(&htrng_dev)) ? 1U : 0U);
    Check("the handle is READY again after the call",
          (HAL_TRNG_GetState(&htrng_dev) == HAL_TRNG_STATE_READY) ? 1U : 0U);
    Check("ISTAT.DONE is cleared by the polling call",
          (HAL_TRNG_GetITStatus(&htrng_dev, TRNG_FLAG_DONE) == RESET) ? 1U : 0U);
    Check("IE.DONE is restored after the polling wait",
          ((TRNG->IE & TRNG_IT_DONE) != 0U) ? 1U : 0U);
    Check("the armed interrupt entry did not consume the polling completion",
          (ready_callbacks == 0U) ? 1U : 0U);
    Check("the call returns well inside the polling budget",
          (elapsed < TRNG_POLLING_BUDGET_MS) ? 1U : 0U);
    Check("TRNG_POLLING_BUDGET_MS is the documented 1000 ms",
          (TRNG_POLLING_BUDGET_MS == 1000U) ? 1U : 0U);
    printf("polling call : %u ms, value = 0x%08X\r\n", PRINT_U32(elapsed), PRINT_U32(value));

    /* ---- B. a stale completion must never be reported as a new one -------- */
    /* Disarm the completion source first: the raw command below is owned by the
     * application, and a level triggered line left asserted by an unowned event
     * would re-enter the handler forever */
    HAL_TRNG_ITConfig(&htrng_dev, TRNG_IT_DONE, DISABLE);
    Check("IE.DONE is disabled before the stale completion test",
          ((TRNG->IE & TRNG_IT_DONE) == 0U) ? 1U : 0U);

    status = Trng_RawCommandAndWait(TRNG_COMMAND_GEN_RANDOM, TRNG_FLAG_DONE);
    Check("a raw GEN_RANDOM command completes", (status == HAL_OK) ? 1U : 0U);
    stale = HAL_TRNG_GetRandomNumber0(&htrng_dev);
    Check("the raw completion is left pending for the stale test",
          (HAL_TRNG_GetITStatus(&htrng_dev, TRNG_FLAG_DONE) == SET) ? 1U : 0U);

    for (i = 0U; i < TEST_STALE_ROUNDS; i++)
    {
        status = HAL_TRNG_GenerateRandomNumber(&htrng_dev, &value);
        if (status != HAL_OK)
        {
            break;
        }
        if (value != stale)
        {
            differ++;
        }
    }
    Check("every polling call after a stale completion returns HAL_OK",
          (status == HAL_OK) ? 1U : 0U);
    Check("the polling API never reports the stale completion as its result",
          (differ >= (TEST_STALE_ROUNDS - 1U)) ? 1U : 0U);
    printf("stale test   : %u of %u results differ from the stale word 0x%08X\r\n",
           PRINT_U32(differ), PRINT_U32(TEST_STALE_ROUNDS), PRINT_U32(stale));

    /* ---- C. the polling wait restores the application setting ------------- */
    Check("a disabled IE.DONE stays disabled after the polling wait",
          ((TRNG->IE & TRNG_IT_DONE) == 0U) ? 1U : 0U);

    /* ---- D. consecutive generations keep changing ------------------------- */
    previous = value;
    changes  = 0U;
    for (i = 0U; i < TEST_STALE_ROUNDS; i++)
    {
        if (HAL_TRNG_GenerateRandomNumber(&htrng_dev, &value) != HAL_OK)
        {
            break;
        }
        if (value != previous)
        {
            changes++;
        }
        previous = value;
    }
    Check("consecutive polling calls return different words",
          (changes >= (TEST_STALE_ROUNDS - 1U)) ? 1U : 0U);

    Summary();

    for (;;)
    {
        if (HAL_TRNG_GenerateRandomNumber(&htrng_dev, &value) == HAL_OK)
        {
            printf("poll %u : 0x%08X\r\n", PRINT_U32(round), PRINT_U32(value));
        }
        else
        {
            printf("poll %u : generation failed\r\n", PRINT_U32(round));
        }
        round++;
        delay_ms(TEST_ROUND_DELAY_MS);
    }
}

/**
 * @brief  Send one raw command and wait for its completion event.
 * @param  command: TRNG_COMMAND_x
 * @param  flag: event that signals the completion (TRNG_FLAG_DONE / ZEROIZED)
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_TIMEOUT
 */
static HAL_StatusTypeDef Trng_RawCommandAndWait(uint32 command, uint32 flag)
{
    if (HAL_TRNG_SendCommand(&htrng_dev, command) != HAL_OK)
    {
        return HAL_ERROR;
    }

    return Trng_WaitFlag(flag, TEST_STEP_TIMEOUT_MS);
}

/**
 * @brief  Acknowledge the events the application enabled itself.
 * @note   Only called from the interrupt handler; the driver-owned completion
 *         is already consumed by HAL_TRNG_IRQHandler() at that point.
 * @param  None
 * @retval None
 */
static void Trng_AckApplicationEvents(void)
{
    if (HAL_TRNG_GetITStatus(&htrng_dev, TRNG_FLAG_DONE) != RESET)
    {
        HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_DONE);
        done_events++;
    }

    if (HAL_TRNG_GetITStatus(&htrng_dev, TRNG_FLAG_ZEROIZED) != RESET)
    {
        HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_ZEROIZED);
    }
}

/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the other integration tests of this library:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2 and
 *         CANX2 by 8, which gives core 180 MHz and APB 22.5 MHz (the console
 *         USART is clocked from APBBus0). The TRNG sits on the AXILite4-Bus1
 *         bus, which is not divided by this tree.
 * @note   Clock tree order: the dividers are written while the system clock
 *         is still the power on source (FIRC), then the PLL is configured and
 *         the system clock is switched to it. That last call programs the
 *         flash controller clock before the switch (the core keeps fetching
 *         from the flash) and updates SystemCoreClock afterwards.
 * @param  None
 * @retval None
 */
void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks (console pins of USART0 on GPIOD) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Open the clock gate of the security domain and release its reset.
 * @note   The TRNG has no dedicated SMU gate: it is clocked and reset through
 *         the DSE (security engine) domain bits of SMU->ALB1CFGR, exactly like
 *         the reference test case does with its DSE_CLK_ENABLE / DSE_RESET /
 *         DSE_SET sequence. The HAL TRNG driver has no default MSP body, so
 *         this helper is what HAL_TRNG_MspInit() / the cases call.
 * @note   The gate is never closed again (not even by HAL_TRNG_MspDeInit):
 *         the DSE domain is shared with the other security peripherals, and a
 *         closed gate makes any later register access stall the bus.
 * @param  None
 * @retval None
 */
void Trng_ClockEnable(void)
{
    __HAL_SMU_DSE_CLK_ENABLE();
    __HAL_SMU_DSE_FORCE_RESET();
    __HAL_SMU_DSE_RELEASE_RESET();
}

/**
 * @brief  Enable the TRNG interrupt source in the PLIC.
 * @param  priority: source priority (1..63, larger = higher priority)
 * @retval None
 */
void Trng_PlicEnable(uint8 priority)
{
    PLIC_InitTypeDef plic_init;

    __HAL_CLEAR_STRUCT(&plic_init);
    plic_init.Size               = sizeof(plic_init);
    plic_init.Version            = PLIC_INIT_VERSION;
    plic_init.PLIC_IRQChannel    = TRNG_IRQn;
    plic_init.PLIC_IRQPriority   = priority;
    plic_init.PLIC_IRQChannelCmd = PLIC_ENABLE;
    (void)HAL_PLIC_Init(&plic_init);
}

/**
 * @brief  Wait (bounded) until one ISTAT event flag of the handle is set.
 * @note   The flag is not cleared here: the caller decides who acknowledges it
 *         (the driver for the completions it owns, the application for the
 *         events it enabled itself).
 * @param  flag: event mask (TRNG_FLAG_x or a combination)
 * @param  timeout_ms: timeout in milliseconds
 * @retval HAL_StatusTypeDef: HAL_OK when the flag was observed / HAL_TIMEOUT
 */
HAL_StatusTypeDef Trng_WaitFlag(uint32 flag, uint32 timeout_ms)
{
    uint32 tickstart = HAL_GetTick();

    while (HAL_TRNG_GetITStatus(&htrng_dev, flag) == RESET)
    {
        if ((HAL_GetTick() - tickstart) > timeout_ms)
        {
            return HAL_TIMEOUT;
        }
    }

    return HAL_OK;
}

/**
 * @brief  Run the DRBG startup sequence: ZEROIZE -> GEN_NOISE -> CREATE_STATE.
 * @note   This is the sequence the reference test case runs at the beginning of
 *         every round; it is factored out here because the cases that use the
 *         HAL generation interfaces only need the DRBG to be seeded once.
 * @param  timeout_ms: per step timeout in milliseconds
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (command refused) / HAL_TIMEOUT
 */
HAL_StatusTypeDef Trng_Seed(uint32 timeout_ms)
{
    if (HAL_TRNG_SendCommand(&htrng_dev, TRNG_COMMAND_ZEROIZE) != HAL_OK)
    {
        return HAL_ERROR;
    }
    if (Trng_WaitFlag(TRNG_FLAG_ZEROIZED, timeout_ms) != HAL_OK)
    {
        return HAL_TIMEOUT;
    }
    HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_ZEROIZED);
    HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_DONE);

    if (HAL_TRNG_SendCommand(&htrng_dev, TRNG_COMMAND_GEN_NOISE) != HAL_OK)
    {
        return HAL_ERROR;
    }
    if (Trng_WaitFlag(TRNG_FLAG_DONE, timeout_ms) != HAL_OK)
    {
        return HAL_TIMEOUT;
    }
    HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_DONE);

    if (HAL_TRNG_SendCommand(&htrng_dev, TRNG_COMMAND_CREATE_STATE) != HAL_OK)
    {
        return HAL_ERROR;
    }
    if (Trng_WaitFlag(TRNG_FLAG_DONE, timeout_ms) != HAL_OK)
    {
        return HAL_TIMEOUT;
    }
    HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_DONE);

    return HAL_OK;
}

/* MSP callbacks ------------------------------------------------------------*/

/**
 * @brief  Initialize the TRNG MSP (security domain clock gate and reset).
 * @note   The default implementation of the driver is empty, so the DSE domain
 *         is opened here (the TRNG has no gate of its own).
 * @note   The call is recorded so that the lifecycle case can verify the
 *         LOCK-06 / MSP-04 contract: the callback must run outside the handle
 *         lock and only on the first initialization (state RESET).
 * @param  htrng: TRNG handle
 * @retval None
 */
void HAL_TRNG_MspInit(TRNG_HandleTypeDef *htrng)
{
    Trng_MspInitCount++;
    Trng_MspStateAtInit = (uint32)htrng->State;
    Trng_MspLockAtInit  = (uint32)htrng->Lock;

    Trng_ClockEnable();
}

/**
 * @brief  De-initialize the TRNG MSP.
 * @note   The DSE clock gate is shared with the other security peripherals and
 *         is left open on purpose, so that a case may read the TRNG registers
 *         after a de-initialization without stalling the bus.
 * @param  htrng: TRNG handle
 * @retval None
 */
void HAL_TRNG_MspDeInit(TRNG_HandleTypeDef *htrng)
{
    Trng_MspDeInitCount++;

    (void)htrng;
}

/*****END OF FILE*****/
