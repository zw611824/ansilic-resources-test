/**
 * @file    EFLASH_IT_DRV_006.c
 * @brief   HAL EFLASH integration test case 006 (flags, interrupts and error reporting).
 *
 * HAL library extension case (no reference standard-library counterpart).
 * Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_FLASH_ITConfig() / HAL_FLASH_ClearITPendingBit()
 *   HAL_FLASH_GetFlagStatus() / HAL_FLASH_ClearFlagStatus()
 *   HAL_FLASH_GetError() / HAL_FLASH_GetState()
 *   the exported flag / interrupt macros
 *   the completion interrupt path through the PLIC
 *
 * Test procedure:
 *   A. initialize the driver, unlock the controller and raise the EFLASH
 *      completion source in the PLIC;
 *   B. enable the three interrupt sources and read them back from CR, then
 *      disable them and read them back again;
 *   C. arm the completion source and trigger a real command: the interrupt
 *      must be serviced, and the handler must release the line (clear the
 *      pending bit) and disable the source;
 *   D. clear every documented clear value twice: the flag must stay clear
 *      (the write-one-to-clear register is not a read-modify-write) and no
 *      other flag may be disturbed;
 *   E. query every documented flag and prove that a clear command does not
 *      set an unrelated flag;
 *   F. check that the exported macros agree with the functions;
 *      (CLKSWRDY is a transient status bit - it is raised while the
 *      controller completes a clock preparation and is low again once
 *      the new frequency is in use - so it is compared against the
 *      raw status register instead of being required to read set)
 *   G. lock / unlock and confirm the LOCK flag polarity, then tear down.
 *
 * Expected behaviour:
 *   the interrupt is delivered once per armed command, the flag clearing
 *   commands are idempotent and affect only the selected bit, the error code
 *   is clean after successful operations and "summary : failures = 0" is
 *   printed.
 *
 * Note:
 *   SECKEYERR is a reset-only latch (the module has no clear value for it),
 *   so this case never provokes a security key error: a latched SECKEYERR
 *   would make every following command report an error.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define -----------------------------------------------------------*/
#define TEST_BAUDRATE                  (115200U)      /*!< console baud rate   */
#define TEST_SECTOR                    (0x01100000U)  /*!< P-Flash test sector */
#define TEST_PATTERN_WORDS             (128U)         /*!< 512 bytes           */
#define TEST_ROUND_DELAY_MS            (2000U)        /*!< delay between runs  */
#define TEST_ISR_TIMEOUT_MS            (1000U)        /*!< interrupt wait      */

/* Private variables ---------------------------------------------------------*/
static volatile uint32 check_failures = 0U;   /*!< failed check counter        */
static volatile uint32 irq_count      = 0U;   /*!< completion ISR entries      */
static volatile uint32 irq_finish_seen = 0U;  /*!< FINISH latched inside the ISR */
static HAL_SMU_HandleTypeDef hsmu_clk;        /*!< SMU handle (clock tree)     */
static HAL_FLASH_HandleTypeDef hflash_dev;    /*!< FLASH handle of this case   */

static uint32 program_data[TEST_PATTERN_WORDS];

/* Shared helpers of this suite (defined at the end of this file) */
void Check(const char *name, uint32 condition);
void Summary(void);
void SystemClock_Init(void);
void Flash_InitDevice(void);
void FillPattern(void);
void Flash_PlicEnable(void);
void Flash_WaitIrq(uint32 timeout_ms);

/**
 * @brief  EFLASH interrupt handler.
 * @note   The HAL FLASH driver is polling only; the application owns this
 *         entry. It overrides the weak EFLASH_IRQ_Handler() of the PLIC module.
 * @param  None
 * @retval None
 */
void EFLASH_IRQ_Handler(void)
{
    irq_count++;

    if (HAL_FLASH_GetFlagStatus(&hflash_dev, FLASH_FLAG_FINISH) == FLASH_FLAG_SET)
    {
        irq_finish_seen++;
        HAL_FLASH_ClearITPendingBit(&hflash_dev, FLASH_CLEAR_IT_FINISH);
    }

    /* The error sources are level driven: an OPERR / ECC2 event that is not
     * acknowledged keeps the interrupt line asserted and the core would never
     * leave this handler. Drop whatever the controller reports. */
    HAL_FLASH_ClearITPendingBit(&hflash_dev, FLASH_CLEAR_IT_OPERR);
    HAL_FLASH_ClearITPendingBit(&hflash_dev, FLASH_CLEAR_IT_ECC2ERR);

    /* Disable the source unconditionally so that a level triggered line can
     * never trap the core in the handler. */
    HAL_FLASH_ITConfig(&hflash_dev, FLASH_IT_FINIE, FLASH_IT_DISABLE);
}

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    FLASH_EraseInitTypeDef erase;
    HAL_StatusTypeDef      status;
    uint32                 addr_error;
    uint32                 i;

    HAL_Init();
    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== EFLASH_IT_DRV_006 : flags, interrupts and error reporting ===\r\n");

    /* ---- A. initialization and interrupt routing -------------------------- */
    Flash_InitDevice();
    Check("HAL_FLASH_Init publishes the READY state",
          (HAL_FLASH_GetState(&hflash_dev) == HAL_FLASH_STATE_READY) ? 1U : 0U);
    Flash_PlicEnable();

    status = HAL_FLASH_Unlock(&hflash_dev);
    Check("HAL_FLASH_Unlock returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("the LOCK flag is cleared while the registers are unlocked",
          (HAL_FLASH_GetFlagStatus(&hflash_dev, FLASH_FLAG_LOCK) == FLASH_FLAG_RESET) ? 1U : 0U);

    /* ---- B. interrupt source configuration -------------------------------- */
    /* Enabling an error source whose flag is already latched (a read raises an
     * ECC flag without any command being issued) would make the line assert
     * immediately, so the flags are dropped before the sources are armed. */
    HAL_FLASH_ClearFlagStatus(&hflash_dev, FLASH_CLEAR_OPERR);
    HAL_FLASH_ClearFlagStatus(&hflash_dev, FLASH_CLEAR_ECC1ERR);
    HAL_FLASH_ClearFlagStatus(&hflash_dev, FLASH_CLEAR_ECC2ERR);
    HAL_FLASH_ClearFlagStatus(&hflash_dev, FLASH_CLEAR_WPERR);

    HAL_FLASH_ITConfig(&hflash_dev, FLASH_IT_FINIE, FLASH_IT_ENABLE);
    Check("the completion source is enabled in CR",
          ((EFLASH->CR & FLASH_IT_FINIE) != 0U) ? 1U : 0U);
    HAL_FLASH_ITConfig(&hflash_dev, FLASH_IT_OPEIE, FLASH_IT_ENABLE);
    Check("the operation error source is enabled in CR",
          ((EFLASH->CR & FLASH_IT_OPEIE) != 0U) ? 1U : 0U);
    HAL_FLASH_ITConfig(&hflash_dev, FLASH_IT_ECC2EIE, FLASH_IT_ENABLE);
    Check("the ECC double bit source is enabled in CR",
          ((EFLASH->CR & FLASH_IT_ECC2EIE) != 0U) ? 1U : 0U);

    HAL_FLASH_ITConfig(&hflash_dev, FLASH_IT_OPEIE, FLASH_IT_DISABLE);
    HAL_FLASH_ITConfig(&hflash_dev, FLASH_IT_ECC2EIE, FLASH_IT_DISABLE);
    Check("the two auxiliary sources are disabled again",
          ((EFLASH->CR & (FLASH_IT_OPEIE | FLASH_IT_ECC2EIE)) == 0U) ? 1U : 0U);

    /* ---- C. one real command with the completion source armed ------------- */
    FillPattern();
    irq_count       = 0U;
    irq_finish_seen = 0U;
    HAL_FLASH_ClearFlagStatus(&hflash_dev, FLASH_CLEAR_FINISH);

    erase.TypeErase = FLASH_TYPEERASE_SECTORS;
    erase.Address   = TEST_SECTOR;
    erase.Length    = PFLASH_SECTOR_SIZE;
    addr_error      = 0xFFFFFFFFU;
    status = HAL_FLASH_Erase(&hflash_dev, &erase, &addr_error);
    Check("the sector erase returns HAL_OK", (status == HAL_OK) ? 1U : 0U);

    Flash_WaitIrq(TEST_ISR_TIMEOUT_MS);
    Check("the completion interrupt was serviced", (irq_count > 0U) ? 1U : 0U);
    Check("the handler disabled the completion source",
          ((EFLASH->CR & FLASH_IT_FINIE) == 0U) ? 1U : 0U);
    Check("the completion flag is clear after the handler ran",
          (HAL_FLASH_GetFlagStatus(&hflash_dev, FLASH_FLAG_FINISH) == FLASH_FLAG_RESET) ? 1U : 0U);

    /* ---- D. write-one-to-clear semantics --------------------------------- */
    HAL_FLASH_ClearFlagStatus(&hflash_dev, FLASH_CLEAR_OPERR);
    Check("clearing OPERR leaves the completion flag alone",
          (HAL_FLASH_GetFlagStatus(&hflash_dev, FLASH_FLAG_FINISH) == FLASH_FLAG_RESET) ? 1U : 0U);
    HAL_FLASH_ClearFlagStatus(&hflash_dev, FLASH_CLEAR_ECC1ERR);
    Check("clearing ECC1ERR works", (HAL_FLASH_GetFlagStatus(&hflash_dev, FLASH_FLAG_ECC1ERR) ==
                                     FLASH_FLAG_RESET) ? 1U : 0U);
    HAL_FLASH_ClearFlagStatus(&hflash_dev, FLASH_CLEAR_ECC2ERR);
    Check("clearing ECC2ERR works", (HAL_FLASH_GetFlagStatus(&hflash_dev, FLASH_FLAG_ECC2ERR) ==
                                     FLASH_FLAG_RESET) ? 1U : 0U);
    HAL_FLASH_ClearFlagStatus(&hflash_dev, FLASH_CLEAR_WPERR);
    Check("clearing WPERR works", (HAL_FLASH_GetFlagStatus(&hflash_dev, FLASH_FLAG_WPERR) ==
                                   FLASH_FLAG_RESET) ? 1U : 0U);
    HAL_FLASH_ClearFlagStatus(&hflash_dev, FLASH_CLEAR_FINISH);
    Check("clearing the completion flag twice is harmless",
          (HAL_FLASH_GetFlagStatus(&hflash_dev, FLASH_FLAG_FINISH) == FLASH_FLAG_RESET) ? 1U : 0U);

    HAL_FLASH_ClearITPendingBit(&hflash_dev, FLASH_CLEAR_IT_FINISH);
    HAL_FLASH_ClearITPendingBit(&hflash_dev, FLASH_CLEAR_IT_OPERR);
    HAL_FLASH_ClearITPendingBit(&hflash_dev, FLASH_CLEAR_IT_ECC2ERR);
    Check("the pending clear entries leave every reported flag clear",
          ((HAL_FLASH_GetFlagStatus(&hflash_dev, FLASH_FLAG_FINISH) == FLASH_FLAG_RESET) &&
           (HAL_FLASH_GetFlagStatus(&hflash_dev, FLASH_FLAG_OPERR) == FLASH_FLAG_RESET) &&
           (HAL_FLASH_GetFlagStatus(&hflash_dev, FLASH_FLAG_ECC2ERR) == FLASH_FLAG_RESET)) ? 1U : 0U);

    /* ---- E. every documented flag is queryable ---------------------------- */
    Check("FLASH_FLAG_LOCK is readable",
          (HAL_FLASH_GetFlagStatus(&hflash_dev, FLASH_FLAG_LOCK) != 0xFFU) ? 1U : 0U);
    Check("FLASH_FLAG_BUSY reports idle",
          (HAL_FLASH_GetFlagStatus(&hflash_dev, FLASH_FLAG_BUSY) == FLASH_FLAG_RESET) ? 1U : 0U);
    Check("FLASH_FLAG_SECKEYERR is clear",
          (HAL_FLASH_GetFlagStatus(&hflash_dev, FLASH_FLAG_SECKEYERR) == FLASH_FLAG_RESET) ? 1U : 0U);
    /* CLKSWRDY is a transient status: the controller raises it while it
     * completes an internal clock preparation and it is low again once the
     * new frequency is in use, so a "flag is set" assertion only holds at
     * that very moment. What can be asserted at any time is that the API
     * and the raw status register agree. */
    Check("FLASH_FLAG_CLKSWRDY agrees with the raw status register",
          ((((EFLASH->SR & FLASH_FLAG_CLKSWRDY) != 0U) ? 1U : 0U) ==
           ((HAL_FLASH_GetFlagStatus(&hflash_dev, FLASH_FLAG_CLKSWRDY) == FLASH_FLAG_SET)
            ? 1U : 0U)) ? 1U : 0U);

    /* ---- F. the exported macros agree with the functions ------------------ */
    Check("__HAL_FLASH_GET_FLAG agrees with HAL_FLASH_GetFlagStatus",
          (((__HAL_FLASH_GET_FLAG(&hflash_dev, FLASH_FLAG_LOCK) != 0U) ? 1U : 0U) ==
           ((HAL_FLASH_GetFlagStatus(&hflash_dev, FLASH_FLAG_LOCK) == FLASH_FLAG_SET) ? 1U : 0U))
          ? 1U : 0U);

    __HAL_FLASH_ENABLE_IT(&hflash_dev, FLASH_IT_FINIE);
    Check("__HAL_FLASH_ENABLE_IT sets FINIE",
          ((EFLASH->CR & FLASH_IT_FINIE) != 0U) ? 1U : 0U);
    __HAL_FLASH_DISABLE_IT(&hflash_dev, FLASH_IT_FINIE);
    Check("__HAL_FLASH_DISABLE_IT clears FINIE",
          ((EFLASH->CR & FLASH_IT_FINIE) == 0U) ? 1U : 0U);

    __HAL_FLASH_CLEAR_FLAG(&hflash_dev, FLASH_CLEAR_OPERR);
    Check("__HAL_FLASH_CLEAR_FLAG leaves OPERR clear",
          ((EFLASH->SR & FLASH_FLAG_OPERR) == 0U) ? 1U : 0U);

    /* ---- G. error reporting and lock polarity ---------------------------- */
    status = HAL_FLASH_Program(&hflash_dev, TEST_SECTOR, 512U, program_data);
    Check("a successful programming returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("a successful programming leaves no error code",
          (HAL_FLASH_GetError(&hflash_dev) == HAL_FLASH_ERROR_NONE) ? 1U : 0U);

    status = HAL_FLASH_Lock(&hflash_dev);
    Check("HAL_FLASH_Lock returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("the LOCK flag is set while the registers are locked",
          (HAL_FLASH_GetFlagStatus(&hflash_dev, FLASH_FLAG_LOCK) == FLASH_FLAG_SET) ? 1U : 0U);

    status = HAL_FLASH_DeInit(&hflash_dev);
    Check("HAL_FLASH_DeInit returns HAL_OK", (status == HAL_OK) ? 1U : 0U);

    for (i = 0U; i < 1U; i++)
    {
        /* keep the compiler from folding the pattern helper away */
        program_data[i] = program_data[i];
    }

    Summary();

    for (;;)
    {
        delay_ms(TEST_ROUND_DELAY_MS);
    }
}

/* Private functions -------------------------------------------------------*/

void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

void FillPattern(void)
{
    uint32 i;

    for (i = 0U; i < TEST_PATTERN_WORDS; i++)
    {
        program_data[i] = (0x01020304U + (i * 0x01010101U)) ^ (i << 24);
    }
}

/**
 * @brief  Wait (bounded) until the completion handler has been entered.
 * @param  timeout_ms: timeout in milliseconds
 * @retval None
 */
void Flash_WaitIrq(uint32 timeout_ms)
{
    uint32 tickstart = HAL_GetTick();

    while ((irq_count == 0U) && ((HAL_GetTick() - tickstart) < timeout_ms))
    {
    }
}

/**
 * @brief  Route the EFLASH completion interrupt through the PLIC.
 * @param  None
 * @retval None
 */
void Flash_PlicEnable(void)
{
    PLIC_InitTypeDef plic_init;

    __HAL_CLEAR_STRUCT(&plic_init);
    plic_init.Size               = sizeof(plic_init);
    plic_init.Version            = PLIC_INIT_VERSION;
    plic_init.PLIC_IRQChannel    = EFLASH_IRQn;
    plic_init.PLIC_IRQPriority   = 1U;
    plic_init.PLIC_IRQChannelCmd = PLIC_ENABLE;
    HAL_PLIC_Init(&plic_init);
}

/**
 * @brief  Configure the system clock tree (PLL 180 MHz, APB 22.5 MHz).
 * @param  None
 * @retval None
 */
void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Initialize the FLASH driver handle of this suite.
 * @param  None
 * @retval None
 */
void Flash_InitDevice(void)
{
    __HAL_CLEAR_STRUCT(&hflash_dev);
    hflash_dev.Instance = EFLASH;
    HAL_FLASH_StructInit(&hflash_dev.Init);
    hflash_dev.Init.ClockFreq = (uint32)(SystemCoreClock / 1000000U);
    (void)HAL_FLASH_Init(&hflash_dev);
}

/*****END OF FILE*****/
