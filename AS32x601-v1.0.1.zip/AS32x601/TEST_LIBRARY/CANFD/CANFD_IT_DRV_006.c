/**
 * @file    CANFD_IT_DRV_006.c
 * @brief   HAL CANFD integration test case 006 (snoop (listen only) mode).
 *
 * One-to-one HAL port of the AS32x601 standard-library test case
 * CANFD_IT_DRV_006.c.  Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_CANFD_StructInit() / HAL_CANFD_Init() / HAL_CANFD_DeInit()
 *   HAL_CANFD_FilterInit()
 *   HAL_CANFD_MspInit() (driver hook, overridden by the case)
 *   HAL_CANFD_GetState() / HAL_CANFD_GetError()
 *   HAL_CANFD_SetSnoop() / HAL_CANFD_CloseSnoop()
 *   HAL_CANFD_FrameStructInit() / HAL_CANFD_FrameInit()
 *   HAL_CANFD_GetReceiveBytes() / HAL_CANFD_GetReceiveData()
 *   HAL_CANFD_GetRxFillLevel() / HAL_CANFD_Transmit()
 *   HAL_CANFD_GetStatus()
 *   direct read of the RX message buffer registers (CANFDx->RxMessage[])
 *
 * Test procedure:
 *   1. initialize the controller;
 *   2. request snoop mode and verify MSR.SNOOP / SR.SNOOP;
 *   3. wait (bounded) for a frame of the partner and check the payload;
 *   4. wait for a second frame to prove that the receive path keeps working
 *      while the controller never acknowledges anything;
 *   5. check that a transmit request is refused in snoop mode and that the
 *      handle stays in a usable state;
 *   6. leave snoop mode and verify that the normal bus path is restored.
 *
 * Expected behaviour:
 *   - snoop mode is entered (SR.SNOOP set);
 *   - the frames of the partner are captured, their payload matches;
 *   - HAL_CANFD_Transmit() is refused while the controller does not drive the
 *     bus, without corrupting the handle state;
 *   - HAL_CANFD_CloseSnoop() restores the normal mode.
 *
 * PARTNER: the external node sends the frames and must report that they were
 * not acknowledged (the board listens only).
 *
 * @note SNOOP receive path (important): while the controller listens only it
 *       still stores every accepted frame into the RX message buffer
 *       (CANFDx->RxMessage[]), but it does NOT update RFSR.FL (the fill
 *       level).  HAL_CANFD_GetRxFillLevel(), HAL_CANFD_GetReceiveBytes() and
 *       HAL_CANFD_GetReceiveData() are all driven by that fill level, so in
 *       snoop mode they keep reporting "no message" even though the payload
 *       is already in the buffer.  This case therefore waits for a bounded
 *       time and then reads the message buffer registers directly.  The fill
 *       level is still printed (as a probe) to document the difference.
 *
 * @note Clock tree: the CAN FD controller is clocked by
 *       CANCLK = PLLR / CANX2DIV / 2 (SMU formula).  This suite keeps the
 *       vendor configuration of the CAN FD reference cases: VCO 160 MHz,
 *       PLLR = 1 -> CANCLK = 80 MHz, so the bit timing of the reference cases
 *       (10 tq prescaler, 16 tq per arbitration bit = 500 kbit/s and 2 tq
 *       prescaler, 8 tq per data bit = 5 Mbit/s) is reproduced unchanged.
 *       The core therefore runs at 160 MHz in this suite (AXI4Bus3 80 MHz,
 *       APBBus0/APBBus1 40 MHz); the other HAL suites use 180 MHz and cannot
 *       reach a CANCLK inside the 8..80 MHz window with a 500 kbit/s timing.
 *
 * @note Only HAL library APIs are used.  The one exception is the source of
 *       case 011, whose whole purpose is to reproduce the reference scenario
 *       "configure the GPIO first, then enable the peripheral clock".
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* CAN FD instance under test */
#define TEST_CANFD                  CANFD3
#define TEST_CANFD_IRQn             CANFD3_IRQn
#define TEST_CANFD_CLK_ENABLE()     __HAL_SMU_CANFD3_CLK_ENABLE()
#define TEST_CANFD_FORCE_RESET()    __HAL_SMU_CANFD3_FORCE_RESET()
#define TEST_CANFD_RELEASE_RESET()  __HAL_SMU_CANFD3_RELEASE_RESET()

/* Port / pins of the instance (from the chip IO map) */
#define TEST_CAN_TX_GPIO            GPIOC
#define TEST_CAN_TX_PIN             GPIO_PIN_7
#define TEST_CAN_TX_SOURCE          GPIO_PinSource7
#define TEST_CAN_RX_PIN             GPIO_PIN_8
#define TEST_CAN_RX_SOURCE          GPIO_PinSource8
#define TEST_CAN_AF                 GPIO_AF_CAN3
#define TEST_CAN_GPIO_CLK_ENABLE()  __HAL_SMU_GPIOC_CLK_ENABLE()

/* Bit timing of the reference cases: 500 kbit/s arbitration,
 * 5 Mbit/s data phase, CANCLK = 80 MHz */
#define TEST_APBRPR_VALUE           (10U)   /* 80 MHz / 10 = 8 MHz tq clock     */
#define TEST_APTS1_VALUE            (11U)   /* + 1 sync = 16 tq -> 500 kbit/s   */
#define TEST_APTS2_VALUE            (4U)
#define TEST_APSJW_VALUE            (2U)
#define TEST_DPBRPR_VALUE           (2U)    /* 80 MHz / 2 = 40 MHz tq clock     */
#define TEST_DPTS1_VALUE            (5U)    /* + 1 sync = 8 tq -> 5 Mbit/s      */
#define TEST_DPTS2_VALUE            (2U)
#define TEST_DPSJW_VALUE            (2U)

/* Number of bytes used to exercise the discrete CAN FD length set */
#define TEST_DATA_BYTES_CLASSIC     (8U)
#define TEST_DATA_BYTES_FD          (64U)

/* Frame identifiers used by the reference cases (the acceptance filters
 * accept 0x147 standard, 0x147 extended and 0x258 / 0x269) */
#define TEST_STD_ID                 (0x147U)
#define TEST_EXT_ID                 (0x147U)
#define TEST_FILTER_ID_1            (0x28E00000U)   /* standard 0x147 */
#define TEST_FILTER_ID_2            (0x4B000000U)   /* standard 0x258 */
#define TEST_FILTER_ID_3            (0x6D200000U)   /* standard 0x269 */
#define TEST_FILTER_ID_4            (0x0008028EU)   /* extended 0x0000147 */
#define TEST_FILTER_MASK_STD        (0xFFE00000U)
#define TEST_FILTER_MASK_EXT        (0xFFEFFFFEU)

/* Bounded waits: the cases must never hang when the external CAN partner is
 * absent, they report the timeout instead */
#define TEST_WAIT_FRAME_MS          (2000U)   /* one frame on the bus         */
#define TEST_WAIT_BUSOFF_MS         (5000U)   /* bus-off recovery             */
#define TEST_WAIT_WAKEUP_MS         (10000U)  /* wait for the partner frame   */
#define TEST_TX_TIMEOUT_MS          (100U)    /* wait for normal mode         */

/* Snoop mode: RFSR.FL is not updated, so the RX message buffer is polled
 * directly.  The poll period only controls how often the buffer is read; the
 * overall wait stays TEST_WAIT_WAKEUP_MS. */
#define TEST_SNOOP_POLL_MS          (50U)
#define TEST_RX_SLOT_COUNT          (64U)     /* CANFDx->RxMessage[0..63]      */

/* Physical identifiers the acceptance filters of this case accept; a frame
 * with any of them is treated as "captured" */
#define TEST_STD_ID_ALT_1           (0x258U)
#define TEST_STD_ID_ALT_2           (0x269U)

/* Number of bytes per DLC code (CAN FD: 0..8, 12, 16, 20, 24, 32, 48, 64) */
#define TEST_DLC_MAX_CODE           (15U)
#define TEST_DLC_MAX_BYTES          (64U)

/* Private variables ---------------------------------------------------------*/
static CANFD_HandleTypeDef hcanfd_dev;      /*!< CAN FD handle                */
static HAL_SMU_HandleTypeDef   hsmu_clk;    /*!< SMU handle (lock / state)    */
static SMU_ClocksTypeDef       g_clocks;    /*!< clock tree snapshot          */

static uint32 failures = 0U;                /*!< failed check counter         */

static volatile uint32 tx_ok_count   = 0U;  /*!< TXOK interrupt counter       */
static volatile uint32 rx_ok_count   = 0U;  /*!< RXOK interrupt counter       */
static volatile uint32 busoff_count  = 0U;  /*!< BSOFF interrupt counter      */
static volatile uint32 wakeup_count  = 0U;  /*!< WKUP  interrupt counter      */
static volatile uint32 error_count   = 0U;  /*!< EERROR interrupt counter     */

static uint8 tx_data[TEST_DATA_BYTES_FD];   /*!< transmit payload             */
static uint8 rx_data[TEST_DATA_BYTES_FD];   /*!< receive payload              */

static volatile uint32 rx_len = 0U;         /*!< length of the last rx frame  */

/* Payload pattern of the reference cases */
static const uint8 test_pattern[TEST_DATA_BYTES_FD] =
{
    0x11U, 0x12U, 0x13U, 0x14U, 0x15U, 0x16U, 0x17U, 0x18U,
    0x21U, 0x22U, 0x23U, 0x24U, 0x25U, 0x26U, 0x27U, 0x28U,
    0x31U, 0x32U, 0x33U, 0x34U, 0x35U, 0x36U, 0x37U, 0x38U,
    0x41U, 0x42U, 0x43U, 0x44U, 0x45U, 0x46U, 0x47U, 0x48U,
    0x51U, 0x52U, 0x53U, 0x54U, 0x55U, 0x56U, 0x57U, 0x58U,
    0x61U, 0x62U, 0x63U, 0x64U, 0x65U, 0x66U, 0x67U, 0x68U,
    0x71U, 0x72U, 0x73U, 0x74U, 0x75U, 0x76U, 0x77U, 0x78U,
    0x81U, 0x82U, 0x83U, 0x84U, 0x85U, 0x86U, 0x87U, 0x88U
};

/* Number of data bytes per DLC code (CAN FD: 0..8, 12, 16, 20, 24, 32, 48, 64).
 * The HAL keeps its own private copy for the fill-level based read path; the
 * direct buffer read of this case needs the same table, so it is repeated
 * here as a private constant of the case. */
static const uint8 test_dlc_to_bytes[TEST_DLC_MAX_CODE + 1U] =
{
    0U, 1U, 2U, 3U, 4U, 5U, 6U, 7U,
    8U, 12U, 16U, 20U, 24U, 32U, 48U, 64U
};

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void Can_ClockEnable(void);
static void Can_GpioInit(void);
static void Can_InitStruct_Default(CANFD_InitTypeDef *init);
static void Can_SetAcceptanceFilters(void);
static HAL_StatusTypeDef Can_Setup(void);
static void Can_CheckPayload(const char *what, uint32 Length);
static void Check(const char *name, int ok);
static void Summary(void);
static void Print_ErrorCounters(void);
static uint32 Can_DlcToBytes(uint32 Dlc);
static uint32 Can_SlotIsCapturedFrame(uint32 Slot, uint32 *pId, uint32 *pIsExt,
                                      uint32 *pDlc, uint32 *pTs);
static uint32 Can_ReadRxBufferDirect(uint8 *pData, uint32 *pId, uint32 *pIsExt,
                                     uint32 *pSlot, uint32 *pTs, uint32 *pDlc);
static uint32 Can_WaitSnoopFrame(uint8 *pData, uint32 TimeoutMs, uint32 *pId,
                                 uint32 *pIsExt, uint32 *pSlot, uint32 *pTs,
                                 uint32 *pDlc);

/**
 * @brief  Accumulate one check result.
 * @param  name: name of the checked item.
 * @param  ok:   non zero when the check passed.
 * @retval None
 */
static void Check(const char *name, int ok)
{
    printf("  %-52s [%s]\r\n", name, (ok != 0) ? "PASS" : "FAIL");

    if (ok == 0)
    {
        failures++;
    }
}

/**
 * @brief  Print the summary line of the case.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("summary : failures = %u\r\n", PRINT_U32(failures));
}

/**
 * @brief  Print the CAN FD error counters.
 * @param  None
 * @retval None
 */
static void Print_ErrorCounters(void)
{
    printf("RXErrorCount: 0x%X\r\n", PRINT_U32(HAL_CANFD_GetRXErrorCount(&hcanfd_dev)));
    printf("TXErrorCount: 0x%X\r\n", PRINT_U32(HAL_CANFD_GetTXErrorCount(&hcanfd_dev)));
}


/**
 * @brief  Compare the received payload with the reference pattern.
 * @param  what:   text printed in front of the check name.
 * @param  Length: number of bytes that must match.
 * @retval None
 */
static void Can_CheckPayload(const char *what, uint32 Length)
{
    uint32 i;
    int equal = 1;
    char name[96];

    for (i = 0U; i < Length; i++)
    {
        if (rx_data[i] != test_pattern[i])
        {
            equal = 0;
            break;
        }
    }

    (void)snprintf(name, sizeof(name), "%s : payload matches the reference", what);
    Check(name, equal);

    printf("  %s : received", what);
    for (i = 0U; i < Length; i++)
    {
        printf(" %x", (unsigned int)rx_data[i]);
    }
    printf("\r\n");
}

/**
 * @brief  Convert a CAN FD DLC code into a number of data bytes.
 * @param  Dlc: DLC code (0..15).
 * @retval uint32: number of data bytes (0..64), 0 for an invalid code.
 */
static uint32 Can_DlcToBytes(uint32 Dlc)
{
    if (Dlc > TEST_DLC_MAX_CODE)
    {
        return 0U;
    }

    return ((uint32)test_dlc_to_bytes[Dlc]);
}

/**
 * @brief  Check whether one RX message buffer slot carries a frame with an
 *         identifier accepted by this case, and decode its header fields.
 * @note   The message buffer is only read, it is never written: in snoop mode
 *         it is the only place where the captured frame can be observed.
 * @param  Slot:    message buffer index (0..63).
 * @param  pId:     physical identifier (11 bit standard or 29 bit extended).
 * @param  pIsExt:  1 for an extended identifier, 0 for a standard one.
 * @param  pDlc:    DLC code of the frame.
 * @param  pTs:     capture timestamp of the frame.
 * @retval uint32: 1 when the slot holds an accepted frame, 0 otherwise.
 */
static uint32 Can_SlotIsCapturedFrame(uint32 Slot, uint32 *pId, uint32 *pIsExt,
                                      uint32 *pDlc, uint32 *pTs)
{
    uint32 rbId;
    uint32 rbDlc;
    uint32 dlcCode;
    uint32 isExt;
    uint32 idField;

    rbId    = TEST_CANFD->RxMessage[Slot].RB_ID;
    rbDlc   = TEST_CANFD->RxMessage[Slot].RB_DLC;
    dlcCode = ((rbDlc & CANFD_RB_DLC_DLC) >> CANFD_RB_DLC_DLC_Pos);
    isExt   = ((rbId & CANFD_RB_ID_IDE) != 0U) ? 1U : 0U;

    if (dlcCode > TEST_DLC_MAX_CODE)
    {
        return 0U;
    }

    if (isExt != 0U)
    {
        /* Extended identifier: ID[28:18] followed by ID[17:0] */
        idField = (((rbId & CANFD_RB_ID_ID) >> CANFD_RB_ID_ID_Pos) << 18U) +
                  ((rbId & CANFD_RB_ID_EM_ID) >> CANFD_RB_ID_EM_ID_Pos);

        if (idField != TEST_EXT_ID)
        {
            return 0U;
        }
    }
    else
    {
        idField = ((rbId & CANFD_RB_ID_ID) >> CANFD_RB_ID_ID_Pos);

        if ((idField != TEST_STD_ID) && (idField != TEST_STD_ID_ALT_1) &&
            (idField != TEST_STD_ID_ALT_2))
        {
            return 0U;
        }
    }

    if (pId != NULL)
    {
        *pId = idField;
    }
    if (pIsExt != NULL)
    {
        *pIsExt = isExt;
    }
    if (pDlc != NULL)
    {
        *pDlc = dlcCode;
    }
    if (pTs != NULL)
    {
        *pTs = ((rbDlc & CANFD_RB_DLC_TS) >> CANFD_RB_DLC_TS_Pos);
    }

    return 1U;
}

/**
 * @brief  Read the captured frame directly out of the RX message buffer.
 * @note   This is the snoop-mode read path: RFSR.FL is not updated while the
 *         controller listens only, so HAL_CANFD_GetRxFillLevel() and the
 *         interfaces built on it report an empty FIFO.  All 64 message buffer
 *         slots are inspected; a standard identifier wins over an extended
 *         one (the partner of this case sends 0x147 as a standard frame).
 *         The reset content of the buffer is not one of the accepted
 *         identifiers, so a stale slot cannot be mistaken for a frame.
 * @param  pData:  buffer that receives the payload (at least 64 bytes).
 * @param  pId:    physical identifier of the captured frame.
 * @param  pIsExt: 1 for an extended identifier.
 * @param  pSlot:  message buffer index the frame was found in.
 * @param  pTs:    capture timestamp of the frame.
 * @param  pDlc:   DLC code of the frame.
 * @retval uint32: payload length in bytes, 0 when no frame was captured.
 */
static uint32 Can_ReadRxBufferDirect(uint8 *pData, uint32 *pId, uint32 *pIsExt,
                                     uint32 *pSlot, uint32 *pTs, uint32 *pDlc)
{
    uint32 slot;
    uint32 found = 0xFFFFFFFFU;
    uint32 idField = 0U;
    uint32 isExt = 0U;
    uint32 dlcCode = 0U;
    uint32 ts = 0U;
    uint32 len;
    uint32 i;

    for (slot = 0U; slot < TEST_RX_SLOT_COUNT; slot++)
    {
        if (Can_SlotIsCapturedFrame(slot, &idField, &isExt, &dlcCode, &ts) == 0U)
        {
            continue;
        }

        if (isExt == 0U)
        {
            found = slot;
            break;
        }

        /* Keep the first extended match as a fallback and keep looking for a
         * standard one */
        if (found == 0xFFFFFFFFU)
        {
            found = slot;
        }
    }

    if (found == 0xFFFFFFFFU)
    {
        return 0U;
    }

    (void)Can_SlotIsCapturedFrame(found, &idField, &isExt, &dlcCode, &ts);

    len = Can_DlcToBytes(dlcCode);
    if (len > TEST_DLC_MAX_BYTES)
    {
        len = TEST_DLC_MAX_BYTES;
    }

    /* The data words are stored most significant byte first, four bytes per
     * RB_DWn register */
    for (i = 0U; i < len; i++)
    {
        uint32 wordIndex = i / 4U;
        uint32 byteIndex = i % 4U;
        uint32 word =
            *((const volatile uint32 *)(&TEST_CANFD->RxMessage[found].RB_DW0) + wordIndex);

        pData[i] = (uint8)(word >> (24U - (byteIndex * 8U)));
    }

    if (pId != NULL)
    {
        *pId = idField;
    }
    if (pIsExt != NULL)
    {
        *pIsExt = isExt;
    }
    if (pSlot != NULL)
    {
        *pSlot = found;
    }
    if (pTs != NULL)
    {
        *pTs = ts;
    }
    if (pDlc != NULL)
    {
        *pDlc = dlcCode;
    }

    return len;
}

/**
 * @brief  Bounded wait for a frame captured in snoop mode.
 * @note   The wait is time based because the fill level of RFSR cannot be used
 *         as a "message pending" indication in snoop mode; the message buffer
 *         is polled every TEST_SNOOP_POLL_MS instead.
 * @param  pData:     buffer that receives the payload (at least 64 bytes).
 * @param  TimeoutMs: overall wait in milliseconds.
 * @param  pId:       physical identifier of the captured frame.
 * @param  pIsExt:    1 for an extended identifier.
 * @param  pSlot:     message buffer index the frame was found in.
 * @param  pTs:       capture timestamp of the frame.
 * @param  pDlc:      DLC code of the frame.
 * @retval uint32: payload length in bytes, 0 on timeout.
 */
static uint32 Can_WaitSnoopFrame(uint8 *pData, uint32 TimeoutMs, uint32 *pId,
                                 uint32 *pIsExt, uint32 *pSlot, uint32 *pTs,
                                 uint32 *pDlc)
{
    uint32 tickstart = HAL_GetTick();
    uint32 len;

    for (;;)
    {
        len = Can_ReadRxBufferDirect(pData, pId, pIsExt, pSlot, pTs, pDlc);
        if (len != 0U)
        {
            return len;
        }

        if ((HAL_GetTick() - tickstart) >= TimeoutMs)
        {
            return 0U;
        }

        delay_ms(TEST_SNOOP_POLL_MS);
    }
}




/**
 * @brief  Enable the clock gate of the CAN FD instance under test and release
 *         its reset.
 * @note   HAL_CANFD_MspInit() is a weak empty function in the driver, so the
 *         low level bring-up (clock gate, reset, pin multiplexing) is done by
 *         the test case.  The reset bit is SET = released / CLEAR = reset
 *         asserted, as for every other instance of the SMU block.
 * @param  None
 * @retval None
 */
static void Can_ClockEnable(void)
{
    TEST_CAN_GPIO_CLK_ENABLE();
    TEST_CANFD_CLK_ENABLE();

    TEST_CANFD_FORCE_RESET();
    TEST_CANFD_RELEASE_RESET();
    TEST_CAN_GPIO_CLK_ENABLE();
}

/**
 * @brief  Configure the CAN TX / RX pins.
 * @note   Both pins are configured as alternate function push-pull: the
 *         transmit pin is driven by the controller and the receive pin is an
 *         input of the controller, and the direction is selected by the
 *         peripheral, not by the GPIO mode.  The receive pin keeps an internal
 *         pull-up so that a floating bus does not produce a permanent dominant
 *         level.
 * @param  None
 * @retval None
 */
static void Can_GpioInit(void)
{
    GPIO_InitTypeDef gpio;

    __HAL_CLEAR_STRUCT(&gpio);
    gpio.Size         = sizeof(gpio);
    gpio.Version      = GPIO_INIT_VERSION;
    gpio.Mode         = GPIO_MODE_AF_PP;
    gpio.Pull         = GPIO_NOPULL;
    gpio.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    gpio.Alternate    = TEST_CAN_AF;

    gpio.Pin = TEST_CAN_TX_PIN;
    HAL_GPIO_Init(TEST_CAN_TX_GPIO, &gpio);

    /* The transceiver drives RXD, so the RX pin must stay an input with a
     * pull-up; only the AF number selects the CAN function
     * (a push-pull output here would fight the transceiver and the
     * controller would never see a frame). */
    gpio.Mode = GPIO_MODE_INPUT;
    gpio.Pull = GPIO_PULLUP;
    gpio.Pin  = TEST_CAN_RX_PIN;
    HAL_GPIO_Init(TEST_CAN_TX_GPIO, &gpio);

    HAL_GPIO_PinAFConfig(TEST_CAN_TX_GPIO, TEST_CAN_TX_SOURCE, TEST_CAN_AF);
    HAL_GPIO_PinAFConfig(TEST_CAN_TX_GPIO, TEST_CAN_RX_SOURCE, TEST_CAN_AF);
}

/**
 * @brief  Fill the CAN FD init structure with the bit timing of the reference
 *         cases (500 kbit/s arbitration, 5 Mbit/s data phase).
 * @note   The driver takes register encodings, and the encoding of every
 *         prescaler / time segment is "value - 1"; the CANFD_xxx_VALUE()
 *         helpers apply that rule, so the numbers below are the physical
 *         time quantum counts of the reference cases.
 * @param  init: pointer to the structure to fill.
 * @retval None
 */
static void Can_InitStruct_Default(CANFD_InitTypeDef *init)
{
    HAL_CANFD_StructInit(init);

    init->CANFD_SRR         = CANFD_SRR_ENABLE;
    init->CANFD_APBRPR      = CANFD_APBRPR_PRESCALER(TEST_APBRPR_VALUE);
    init->CANFD_APBTR_APTS1 = CANFD_APBTR_TS1_VALUE(TEST_APTS1_VALUE);
    init->CANFD_APBTR_APTS2 = CANFD_APBTR_TS2_VALUE(TEST_APTS2_VALUE);
    init->CANFD_APBTR_APSJW = CANFD_APBTR_SJW_VALUE(TEST_APSJW_VALUE);
    init->CANFD_DPBRPR      = CANFD_DPBRPR_PRESCALER(TEST_DPBRPR_VALUE);
    init->CANFD_DPBTR_DPTS1 = CANFD_DPBTR_TS1_VALUE(TEST_DPTS1_VALUE);
    init->CANFD_DPBTR_DPTS2 = CANFD_DPBTR_TS2_VALUE(TEST_DPTS2_VALUE);
    init->CANFD_DPBTR_DPSJW = CANFD_DPBTR_SJW_VALUE(TEST_DPSJW_VALUE);
}

/**
 * @brief  Install the four acceptance filters of the reference cases.
 * @param  None
 * @retval None
 */
static void Can_SetAcceptanceFilters(void)
{
    CANFD_FilterConfigTypeDef filter;

    __HAL_CLEAR_STRUCT(&filter);
    filter.CANFD_FilterCmd = CANFD_ENABLE;

    filter.CANFD_FilterNumber = 0U;
    filter.CANFD_FilterMask   = TEST_FILTER_MASK_STD;
    filter.CANFD_FilterID     = TEST_FILTER_ID_1;
    (void)HAL_CANFD_FilterInit(&hcanfd_dev, &filter);

    filter.CANFD_FilterNumber = 1U;
    filter.CANFD_FilterMask   = TEST_FILTER_MASK_STD;
    filter.CANFD_FilterID     = TEST_FILTER_ID_2;
    (void)HAL_CANFD_FilterInit(&hcanfd_dev, &filter);

    filter.CANFD_FilterNumber = 2U;
    filter.CANFD_FilterMask   = TEST_FILTER_MASK_STD;
    filter.CANFD_FilterID     = TEST_FILTER_ID_3;
    (void)HAL_CANFD_FilterInit(&hcanfd_dev, &filter);

    filter.CANFD_FilterNumber = 3U;
    filter.CANFD_FilterMask   = TEST_FILTER_MASK_EXT;
    filter.CANFD_FilterID     = TEST_FILTER_ID_4;
    (void)HAL_CANFD_FilterInit(&hcanfd_dev, &filter);
}

/**
 * @brief  Initialize the CAN FD instance with the reference bit timing and
 *         install the acceptance filters.
 * @param  None
 * @retval HAL_OK on success, the driver status otherwise.
 */
static HAL_StatusTypeDef Can_Setup(void)
{
    CANFD_InitTypeDef init;
    HAL_StatusTypeDef status;

    __HAL_CLEAR_STRUCT(&hcanfd_dev);
    hcanfd_dev.Instance = TEST_CANFD;

    Can_InitStruct_Default(&init);
    hcanfd_dev.Init = init;

    status = HAL_CANFD_Init(&hcanfd_dev);
    if (status == HAL_OK)
    {
        Can_SetAcceptanceFilters();
    }

    return status;
}


/**
 * @brief  Override of the weak driver hook: bring the CAN FD instance up
 *         (clock gate, reset, pin multiplexing) once the configuration is
 *         known.
 * @note   LOCK-06: the driver calls this hook BEFORE it takes the handle lock,
 *         so calling HAL_GPIO_Init() from here is safe.
 * @param  hcanfd: CAN FD handle.
 * @retval None
 */
void HAL_CANFD_MspInit(CANFD_HandleTypeDef *hcanfd)
{
    if (hcanfd != &hcanfd_dev)
    {
        return;
    }

    Can_ClockEnable();
    Can_GpioInit();
}

/**
 * @brief  Configure the system clock tree using the HAL SMU driver.
 * @note   The CAN FD bit timing needs a CANCLK inside 8..80 MHz; with the
 *         vendor PLLR = 1 and CANX2DIV = 1 the controller runs at 80 MHz,
 *         which is exactly the frequency of the CAN FD reference cases.
 *         The core therefore runs at 160 MHz (VCO 160 MHz).
 * @note   Order: the bus dividers are written while the system clock is still
 *         the power-on source (FIRC), then the flash controller is programmed
 *         and the clock is switched by HAL_SMU_OscConfig().  Writing the
 *         dividers after the switch would leave the buses at their reset
 *         dividers for a moment at the new core clock.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   osc;
    SMU_ClockInitTypeDef clk;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the console USART needs AXI4Bus3 / APBBus0) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* 1.2 V / 2.5 V LDO trimming (the PMU API is gated on the handle state,
     * so the handle must be initialized first) */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Bus dividers first: the system clock is still FIRC here */
    clk.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV1;   /* 80 MHz */
    clk.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;    /* 40 MHz */
    clk.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;    /* 40 MHz */
    clk.CANX2CLKDiv    = SMU_CANX2CLK_DIV1;      /* CANCLK = PLLR / 2 = 80 MHz */
    (void)HAL_SMU_ClockConfig(&hsmu_clk, &clk);

    /* PLL: VCO 160 MHz, PLLR = 1 -> CANCLKx2 source 160 MHz */
    osc.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    osc.FIRCState            = SMU_FIRC_ON;
    osc.FIRCCalibrationValue = 0x00U;
    osc.PLL.PLLState         = SMU_PLL_ON;
    osc.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    osc.PLL.PLLDivR          = 0x01U;
    osc.PLL.PLLDivQ          = 0x01U;
    osc.PLL.PLLDivN          = 0x14U;
    osc.PLL.PLLDivF          = 0xA0U;
    osc.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    (void)HAL_SMU_OscConfig(&hsmu_clk, &osc, SMU_TIMEOUT_DEFAULT);
    (void)HAL_SMU_GetClocksFreq(&g_clocks);
}

/**
 * @brief  CAN FD interrupt handler of the instance under test.
 * @note   The driver has no interrupt dispatcher and no callbacks, so the
 *         application owns the interrupt service routine: it reads the pending
 *         sources, services them and clears them through the interrupt safe
 *         HAL_CANFD_ClearITPendingBit() (that interface takes no handle lock
 *         and applies no state gate, so it is usable from the ISR even while a
 *         task owns the handle).
 * @note   The receive FIFO is drained here, which is the intended use of the
 *         lock free read path HAL_CANFD_GetReceiveData().
 * @param  None
 * @retval None
 */
void CANFD3_IRQ_Handler(void)
{
    if (HAL_CANFD_GetITStatus(&hcanfd_dev, CANFD_IT_ERXOK) != 0U)
    {
        rx_ok_count++;
        rx_len = HAL_CANFD_GetReceiveData(&hcanfd_dev, rx_data);
        HAL_CANFD_ClearITPendingBit(&hcanfd_dev, CANFD_IT_ERXOK);
    }

    if (HAL_CANFD_GetITStatus(&hcanfd_dev, CANFD_IT_ETXOK) != 0U)
    {
        tx_ok_count++;
        HAL_CANFD_ClearITPendingBit(&hcanfd_dev, CANFD_IT_ETXOK);
    }

    if (HAL_CANFD_GetITStatus(&hcanfd_dev, CANFD_IT_EBSOFF) != 0U)
    {
        busoff_count++;
        HAL_CANFD_ClearITPendingBit(&hcanfd_dev, CANFD_IT_EBSOFF);
    }

    if (HAL_CANFD_GetITStatus(&hcanfd_dev, CANFD_IT_EWKUP) != 0U)
    {
        wakeup_count++;
        HAL_CANFD_ClearITPendingBit(&hcanfd_dev, CANFD_IT_EWKUP);
    }

    if (HAL_CANFD_GetITStatus(&hcanfd_dev, CANFD_IT_EERROR) != 0U)
    {
        error_count++;
        HAL_CANFD_ClearITPendingBit(&hcanfd_dev, CANFD_IT_EERROR);
    }

    /* An event that is not serviced above would keep the line asserted: clear
     * every remaining source of the enable register as a safety net */
    HAL_CANFD_ClearITPendingBit(&hcanfd_dev, CANFD_IT_ALL);
}

/*****END OF FILE*****/

int main(void)
{
    uint32 len;
    uint32 len2;
    uint32 slot;
    uint32 id;
    uint32 isExt;
    uint32 ts;
    uint32 dlc;
    uint32 fill_probe;
    uint32 first_slot = 0xFFFFFFFFU;
    uint32 first_ts = 0U;
    uint32 print_slot = 0xFFFFFFFFU;
    uint32 print_ts = 0xFFFFFFFFU;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (VCO 160 MHz, CANCLK 80 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);

    printf("\r\n=== CANFD_IT_DRV_006 : snoop (listen only) mode ===\r\n");
    printf("clock    : core %u Hz, CANCLK %u Hz\r\n",
           PRINT_U32(SystemCoreClock), PRINT_U32(g_clocks.CANCLKx2_Frequency));
    printf("PARTNER  : the external node sends the frames; the board must NOT\r\n");
    printf("           acknowledge them (listen only)\r\n");

    /* Step 1: initialize the controller */
    if (Can_Setup() != HAL_OK)
    {
        printf("HAL_CANFD_Init failed, error = 0x%08X\r\n",
               PRINT_U32(HAL_CANFD_GetError(&hcanfd_dev)));
        Summary();
        while (1)
        {
        }
    }

    Check("HAL_CANFD_Init : state = READY",
          (HAL_CANFD_GetState(&hcanfd_dev) == HAL_CANFD_STATE_READY));

    /* Step 2: request snoop (listen only) mode: the controller receives the
     * bus traffic without driving the bus, so the partner reports that its
     * frame was not acknowledged while the board still captures it */
    HAL_CANFD_SetSnoop(&hcanfd_dev);
    delay_ms(10U);

    Check("snoop requested (MSR.SNOOP set)",
          ((TEST_CANFD->MSR & CANFD_MSR_SNOOP) != 0U));
    Check("HAL_CANFD_GetStatus : snoop mode",
          (HAL_CANFD_GetStatus(&hcanfd_dev, CANFD_STATUS_SNOOP) != 0U));
    printf("listening, waiting for a partner frame ...\r\n");

    /* Step 3: wait for the first frame of the partner.
     * In snoop mode the controller stores the frame in the RX message buffer
     * but does not update RFSR.FL, so the buffer is polled directly; the fill
     * level is printed as a probe to document that it stays 0. */
    printf("snoop probe: RFSR = 0x%08X (RI = %u, FL = %u)\r\n",
           PRINT_U32((uint32)TEST_CANFD->RFSR),
           PRINT_U32(HAL_CANFD_GetRxReadIndex(&hcanfd_dev)),
           PRINT_U32(HAL_CANFD_GetRxFillLevel(&hcanfd_dev)));

    len = Can_WaitSnoopFrame(rx_data, TEST_WAIT_WAKEUP_MS, &id, &isExt, &slot,
                             &ts, &dlc);

    fill_probe = HAL_CANFD_GetRxFillLevel(&hcanfd_dev);
    printf("snoop probe: FL = %u after the wait (not updated in snoop mode)\r\n",
           PRINT_U32(fill_probe));

    if (len != 0U)
    {
        first_slot = slot;
        first_ts = ts;

        printf("rx frame   : %u bytes, id = 0x%X (%s), dlc = %u, slot = %u, ts = %u\r\n",
               PRINT_U32(len), PRINT_U32(id),
               (isExt != 0U) ? "extended" : "standard",
               PRINT_U32(dlc), PRINT_U32(slot), PRINT_U32(ts));

        Check("receive : a partner frame was captured in snoop mode", 1);

        if ((isExt == 0U) && (id == TEST_STD_ID))
        {
            Can_CheckPayload("snoop frame",
                             (len <= TEST_DATA_BYTES_FD) ? len : TEST_DATA_BYTES_FD);
        }
        else
        {
            /* The reference payload of this case belongs to the standard 0x147
             * frame; any other accepted identifier is reported without a
             * payload comparison */
            printf("  payload check skipped: a standard 0x147 frame was expected\r\n");
        }
    }
    else
    {
        Check("receive : a partner frame was captured in snoop mode", 0);
        printf("  no frame: let the partner send a frame on the bus\r\n");
    }

    /* Step 4: a second frame proves the receive path keeps working while the
     * controller never acknowledges anything */
    len2 = Can_WaitSnoopFrame(rx_data, TEST_WAIT_WAKEUP_MS, &id, &isExt, &slot,
                              &ts, &dlc);

    if (len2 != 0U)
    {
        printf("rx frame   : %u bytes, id = 0x%X (%s), slot = %u, ts = %u (second)\r\n",
               PRINT_U32(len2), PRINT_U32(id),
               (isExt != 0U) ? "extended" : "standard",
               PRINT_U32(slot), PRINT_U32(ts));

        Check("snoop : a second frame was captured", 1);

        if ((slot == first_slot) && (ts == first_ts))
        {
            printf("  note: same slot and timestamp as the first frame, the\r\n");
            printf("        partner may have sent only one frame\r\n");
        }
    }
    else
    {
        Check("snoop : a second frame was captured", 0);
    }

    /* Step 5: the transmit path is unusable in snoop mode (the controller does
     * not drive the bus), so a transmit request must not corrupt the state */
    Check("transmit is refused in snoop mode",
          (HAL_CANFD_Transmit(&hcanfd_dev, 0U, tx_data, CANFD_BYTES_8,
                              TEST_TX_TIMEOUT_MS) != HAL_OK));
    Check("HAL_CANFD_GetState : still a valid state after the refusal",
          ((HAL_CANFD_GetState(&hcanfd_dev) == HAL_CANFD_STATE_READY) ||
           (HAL_CANFD_GetState(&hcanfd_dev) == HAL_CANFD_STATE_LISTEN) ||
           (HAL_CANFD_GetState(&hcanfd_dev) == HAL_CANFD_STATE_TIMEOUT) ||
           (HAL_CANFD_GetState(&hcanfd_dev) == HAL_CANFD_STATE_ERROR)));

    /* Step 6: leaving snoop mode restores the normal bus path */
    HAL_CANFD_CloseSnoop(&hcanfd_dev);
    delay_ms(10U);
    Check("HAL_CANFD_CloseSnoop : snoop cleared",
          (HAL_CANFD_GetStatus(&hcanfd_dev, CANFD_STATUS_SNOOP) == 0U));
    Check("HAL_CANFD_GetStatus : normal mode restored",
          (HAL_CANFD_GetStatus(&hcanfd_dev, CANFD_STATUS_NORMAL) != 0U));

    Print_ErrorCounters();
    Summary();

    printf("-- continuous receive from the snoop message buffer\r\n");
    printf("   (reset the board to run the checks again)\r\n");
    while (1)
    {
        len = Can_ReadRxBufferDirect(rx_data, &id, &isExt, &slot, &ts, &dlc);

        if (len != 0U)
        {
            /* Only report a change: the buffer keeps the last captured frame,
             * so a new printout is produced when another frame was stored */
            if ((slot != print_slot) || (ts != print_ts))
            {
                print_slot = slot;
                print_ts = ts;

                printf("rx: %u bytes, id = 0x%X (%s), slot = %u, ts = %u\r\n",
                       PRINT_U32(len), PRINT_U32(id),
                       (isExt != 0U) ? "extended" : "standard",
                       PRINT_U32(slot), PRINT_U32(ts));
            }
        }

        delay_ms(TEST_SNOOP_POLL_MS);
    }
}

