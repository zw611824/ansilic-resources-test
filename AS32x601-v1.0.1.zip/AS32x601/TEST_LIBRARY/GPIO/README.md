# GPIO 应用与测试参考

用于按需求检索 AS32x601 HAL GPIO 示例。关键词：GPIO、输入、输出、置位、清零、翻转、回读、EXTI、软件中断、外部中断、引脚复用、上下拉、驱动电流。


## 实例与可选引脚

GPIO 按实际端口、引脚和封装选择，可配置范围见 [GPIO 头文件](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_gpio.h)。外设复用查相应外设 README，案例接线不能推广为板级默认值。

### LQFP144 脚号与默认功能

<details>
<summary>展开封装脚号与默认功能</summary>

| 脚号 | 引脚 | 类型 | 默认模式 | 默认功能或用途 |
| --- | --- | --- | --- | --- |
| 1 | PE10 | GPIO | IF | GPIO |
| 2 | PF13 | GPIO | IF | GPIO |
| 3 | OSCIN | IO | — | OSC 输入 |
| 4 | OSCOUT | IO | — | OSC 输出 |
| 5 | PB9 | GPIO | IF | JTAG_TMS |
| 6 | PB8 | GPIO | IF | JTAG_TDI |
| 7 | PB7 | GPIO | IF | JTAG_TCK |
| 8 | PB6 | GPIO | OPP | JTAG_TDO |
| 9 | VDD_IO_OFF | POWER | — | power IO，提供off区域GPIO电源 |
| 10 | PB5 | GPIO | IF | JTAG_RSTN |
| 11 | PB4 | GPIO | IF | GPIO |
| 12 | PB3 | GPIO | IF | GPIO |
| 13 | PG15 | GPIO | IF | GPIO |
| 14 | PG14 | GPIO | IF | GPIO |
| 15 | PG13 | GPIO | IF | GPIO |
| 16 | PG12 | GPIO | IF | GPIO |
| 17 | PG11 | GPIO | IF | GPIO |
| 18 | PG10 | GPIO | IF | GPIO |
| 19 | PG9 | GPIO | IF | GPIO |
| 20 | PD7 | GPIO | IF | GPIO |
| 21 | PD6 | GPIO | IF | GPIO |
| 22 | PD5 | GPIO | IF | GPIO |
| 23 | PD4 | GPIO | IF | GPIO |
| 24 | VDD_IO_OFF | POWER | — | power IO，提供off区域GPIO电源 |
| 25 | VSS_IO_OFF | GROUND | — | ground IO，提供off区域GPIO地 |
| 26 | PD3 | GPIO | IF | GPIO |
| 27 | PD2 | GPIO | IF | GPIO |
| 28 | PD1 | GPIO | IF | GPIO |
| 29 | PD0 | GPIO | IF | GPIO |
| 30 | PC12 | GPIO | IF | GPIO |
| 31 | PC11 | GPIO | IF | GPIO |
| 32 | PC10 | GPIO | IF | GPIO |
| 33 | PA15 | GPIO | IF | GPIO |
| 34 | PA14 | GPIO | IF | GPIO |
| 35 | PA13 | GPIO | OOD | QSPI_DIO3 |
| 36 | PA12 | GPIO | OOD | QSPI_DIO2 |
| 37 | PA11 | GPIO | OOD | QSPI_DIO1 |
| 38 | PA10 | GPIO | OOD | QSPI_DIO0 |
| 39 | PA9 | GPIO | OPP | QSPI_SCK |
| 40 | PA8 | GPIO | OPP | QSPI_CSN |
| 41 | PC9 | GPIO | IF | GPIO |
| 42 | PC8 | GPIO | IF | GPIO |
| 43 | PC7 | GPIO | IF | GPIO |
| 44 | PC6 | GPIO | IF | GPIO |
| 45 | PG8 | GPIO | IF | GPIO |
| 46 | PG7 | GPIO | IF | GPIO |
| 47 | VDD_IO_OFF | POWER | — | power IO，提供off区域GPIO电源 |
| 48 | VSS_IO_OFF | GROUND | — | ground IO，提供off区域GPIO地 |
| 49 | PG6 | GPIO | IF | GPIO |
| 50 | PG5 | GPIO | IF | GPIO |
| 51 | PG4 | GPIO | IF | GPIO |
| 52 | PG3 | GPIO | IF | GPIO |
| 53 | PG2 | GPIO | IF | GPIO |
| 54 | PD15 | GPIO | IF | GPIO |
| 55 | PD14 | GPIO | IF | GPIO |
| 56 | PD13 | GPIO | IF | GPIO |
| 57 | PD12 | GPIO | IF | GPIO |
| 58 | PD11 | GPIO | IF | GPIO |
| 59 | PD10 | GPIO | IF | GPIO |
| 60 | PD9 | GPIO | IF | GPIO |
| 61 | PD8 | GPIO | IF | GPIO |
| 62 | PB15 | GPIO | IF | GPIO |
| 63 | PE0 | GPIO | IF | GPIO |
| 64 | PE1 | GPIO | IF | GPIO |
| 65 | RESET_N | RST | — | 热复位 |
| 66 | DFT_EN | IO | — | DFT测试复位 |
| 67 | PH9 | GPIO | IF | GPIO |
| 68 | PH8 | GPIO | IF | GPIO |
| 69 | PH7 | GPIO | IF | GPIO |
| 70 | PH6 | GPIO | IF | GPIO |
| 71 | PH5 | GPIO | IF | GPIO |
| 72 | PH4 | GPIO | IF | GPIO |
| 73 | VDD_IO_AON | POWER | — | power IO，提供aon区域GPIO电源 |
| 74 | VSS_IO_AON | GROUND | — | ground IO，提供aon区域GPIO地 |
| 75 | PH3 | GPIO | IF | GPIO |
| 76 | PH2 | GPIO | IF | GPIO |
| 77 | PH1 | GPIO | IF | BOOT1 |
| 78 | PH0 | GPIO | IF | BOOT0 |
| 79 | VDD25 | REFN | — | 电源控制模块 2.5V输出 |
| 80 | VDD33 | REFP | — | 电源控制模块 3.3V输出 |
| 81 | VDD | POWER | — | 功能描述:power IO，提供PMB/RTC电源（详见芯片设计手册4.3.2电源结构图） |
| 82 | VDD | POWER | — | 功能描述:power IO，提供PMB/RTC电源（详见芯片设计手册4.3.2电源结构图） |
| 83 | VSS | GROUND | — | 功能描述:ground IO，提供PMB/RTC地 |
| 84 | PF6 | GPIO | OPP | FB_FR1 |
| 85 | PC14 | GPIO | IF | FB_RST |
| 86 | PC15 | GPIO | OOD | FB_TMSC0 |
| 87 | PF7 | GPIO | OPP | FB_FR2 |
| 88 | PF0 | GPIO | OOD | FB_TMSC1 |
| 89 | PF8 | GPIO | OPP | FB_FR3 |
| 90 | PF1 | GPIO | OOD | FB_TMSC2 |
| 91 | PF9 | GPIO | OPP | FB_FR4 |
| 92 | PF2 | GPIO | OOD | FB_TMSC3 |
| 93 | PF10 | GPIO | IF | GPIO |
| 94 | PF3 | GPIO | OOD | FB_TMSC4 |
| 95 | PC0 | GPIO | IF | GPIO |
| 96 | PF4 | GPIO | OPP | FB_MS |
| 97 | PC1 | GPIO | IF | GPIO |
| 98 | VDD_IO_OFF | POWER | — | power IO，提供off区域GPIO电源 |
| 99 | PF5 | GPIO | OPP | FB_FR0 |
| 100 | PC2 | GPIO | IF | GPIO |
| 101 | PB12 | GPIO | IF | GPIO |
| 102 | PF12 | GPIO | IF | GPIO |
| 103 | PA6 | GPIO | IF | GPIO |
| 104 | PF11 | GPIO | IF | GPIO |
| 105 | PA5 | GPIO | IF | GPIO |
| 106 | VREFP | POWER | — | 模拟 IP 的正参考电压 |
| 107 | VREFN | POWER | — | 模拟 IP 的负参考电压 |
| 108 | PB2 | GPIO | IF | GPIO |
| 109 | PA4 | GPIO | IF | GPIO |
| 110 | PB13 | GPIO | IF | GPIO |
| 111 | PB1 | GPIO | IF | GPIO |
| 112 | PA3 | GPIO | IF | GPIO |
| 113 | VDD_IO_OFF | POWER | — | power IO，提供off区域GPIO电源(模拟信号IO电源) |
| 114 | PB0 | GPIO | IF | GPIO |
| 115 | PA2 | GPIO | IF | GPIO |
| 116 | PC5 | GPIO | IF | GPIO |
| 117 | PA1 | GPIO | IF | GPIO |
| 118 | PC4 | GPIO | IF | GPIO |
| 119 | PA0 | GPIO | IF | GPIO |
| 120 | PE4 | GPIO | IF | GPIO |
| 121 | PA7 | VREFN | POWER | 模拟 IP 的负参考电压 |
| 122 | PC3 | VREFP | POWER | 模拟 IP 的正参考电压 |
| 123 | PE2 | GPIO | IF | GPIO |
| 124 | PE3 | GPIO | IF | GPIO |
| 125 | PC13 | GPIO | IF | FB_TCK |
| 126 | PB14 | GPIO | IF | GPIO |
| 127 | PE5 | GPIO | IF | GPIO |
| 128 | PE6 | GPIO | IF | GPIO |
| 129 | PB11 | GPIO | IF | GPIO |
| 130 | PE9 | GPIO | IF | GPIO |
| 131 | PB10 | GPIO | IF | GPIO |
| 132 | VDD_IO_OFF | POWER | — | power IO，提供off区域GPIO电源(模拟信号IO电源) |
| 133 | VSS_IO_OFF | GROUND | — | ground IO，提供off区域GPIO地 (模拟信号IO地) |
| 134 | PE8 | GPIO | IF | GPIO |
| 135 | PE15 | GPIO | IF | GPIO |
| 136 | PE7 | GPIO | IF | GPIO |
| 137 | PE14 | GPIO | IF | GPIO |
| 138 | PG1 | GPIO | IF | GPIO |
| 139 | PE13 | GPIO | IF | GPIO |
| 140 | PG0 | GPIO | IF | GPIO |
| 141 | PE12 | GPIO | IF | GPIO |
| 142 | PF15 | GPIO | IF | GPIO |
| 143 | PE11 | GPIO | IF | GPIO |
| 144 | PF14 | GPIO | IF | GPIO |

</details>

默认模式 IF 为输入浮空，OOD 为漏极开路输出，表中 OPP 表示推挽输出。芯片内部不区分数字地与模拟地。调试、启动或外部总线已占用的引脚，按 GPIO 头文件的默认功能说明核对后再复用。专用复用信号 FAULT_IN0 在 PB3（脚 12），FAULT_IN1 在 PB4（脚 11），均为功能0，HAL AF 为 GPIO_AF_FAULT（0x01）。

## 生成前需确认的参数

已有工程、板级资料或用户已明确的值直接复用。仅对影响本次实现的缺失选择使用参数卡询问并等待答复；案例配置不能代替实际接线或应用参数。

| 参数 | 需要核对或确认的内容 |
|---|---|
| 端口与引脚 | 实际信号引脚、封装引出及已有复用冲突 |
| 电气与逻辑 | 输入/输出、上拉/下拉、开漏/推挽、有效电平和外接电路 |
| 中断需求 | 需要时确认触发边沿、消抖和响应方式 |

## 用于应用生成的入口

本文件负责需求路由与案例使用边界，不是独立应用工程或硬件验证报告。建议按“按需求选择 → 选中源码 → 对应 HAL 定义 → 应用迁移”阅读；只有需要查特定函数时再读接口索引，不必一次加载全部案例。

- HAL 依据：[GPIO 头文件](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_gpio.h)、[GPIO 实现](../../HAL_LIBRARY/peripherals/src/as32x601_hal_gpio.c)。引脚、复用和 IRQ 同时核对当前设备头及目标板。
- 辅助依赖：抽查的 008 等案例引用 `as32x601_delay.h`；对应源码已从 HAL 参考工程复制到 [HAL_LIBRARY/utils](../../HAL_LIBRARY/utils/README.md)。需要延时时先确认时钟、计数器及工程依赖，已有工程优先复用现有实现。
- 案例中的 PLL 180 MHz、PMU 电压、QSPI/JTAG/BOOT 引脚处理属于案例配置，不能自动成为客户工程默认值。代码与历史注释不一致时，核对当前 HAL 和芯片资料后再决定，不凭注释直接修改时钟或电压。

### 从案例迁移为应用

1. 确认端口/引脚、方向、有效电平、上下拉、负载及与其他外设的占用关系；只配置业务需要的引脚，不整组复制测试掩码。
2. 将必要时钟、PinMux、GPIO 与 IRQ 配置放入 `Bsp/gpio.c / gpio.h` 或已有板级模块，保留客户工程现有系统初始化。
3. 业务行为按功能放入 User，如 `button_input.c / button_input.h` 对应 `Button_Input_Process()`；简单应用可留在 main。消抖、长短按、事件队列等不是输入读数或边沿中断本身提供的功能。
4. 中断入口、端口回调在工程中各保留一份；共享端口按引脚分发到业务处理。回调只记录必要状态/事件，主循环处理业务，不在 ISR 中延时消抖。
5. `Interrupt_State` 的累计位图只表示哪些引脚曾触发，不能证明每个引脚“恰好一次”，也不能保留事件次数和顺序。需要计数或连续事件时另行设计并发与溢出处理。

去除测试循环、检查计数和调试观察逻辑；实际错误处理、共享状态保护及外部信号验证不能省略。应用文件组织与命名遵循 `as32-peripheral-codegen` Skill。

## 按需求选择

按“用户想实现的行为 → 推荐源码 → 适用条件”选择。同一需求涉及多个功能时组合阅读相关用例，不直接拼接多个 `main()`。

| 用户需求 / 检索关键词 | 推荐用例 | 选择条件 / 需要补充的逻辑 |
|---|---|---|
| 配置 GPIO 推挽输出；拉高、拉低；控制 LED / 使能脚 | [001](GPIO_IT_DRV_001.c) | 示例使用 GPIOA；按目标板修改引脚和有效电平，外部负载驱动能力另行核对 |
| 翻转引脚；LED 闪烁；Toggle | [002](GPIO_IT_DRV_002.c) | 示例使用延时循环，不提供任务调度 |
| 一次写入一组 GPIO 输出值；端口输出寄存器写入 | [003](GPIO_IT_DRV_003.c) | 整组写入前核对其他引脚是否需要保留 |
| 按位写输出；比较输出写入接口 | [004](GPIO_IT_DRV_004.c) | 核对所用 API 的引脚掩码与写入语义 |
| 读取输出锁存值；验证写入后的寄存器状态 | [005](GPIO_IT_DRV_005.c) | 输出回读不等于实际引脚电平测量 |
| 读取引脚电平；轮询按键；数字输入 | [006](GPIO_IT_DRV_006.c) | 只提供输入读取参考；按键消抖、上下拉及有效电平按应用补充 |
| 软件触发 GPIO 中断；验证中断入口和回调 | [007](GPIO_IT_DRV_007.c) | 验证软件请求路径，不能代替外部边沿输入验证 |
| 外部信号触发中断；按键中断；边沿检测 | [008](GPIO_IT_DRV_008.c) | 按源码核对触发边沿；按应用补充消抖和事件处理 |
| GPIOB：输出波形、置位清零、翻转和输出 API | [009](GPIO_IT_DRV_009.c) | 按源码确认测试掩码和实际波形 |
| GPIOB：输出寄存器回读 | [010](GPIO_IT_DRV_010.c) | 不能替代引脚实测 |
| GPIOB：输入电平读取 | [011](GPIO_IT_DRV_011.c) | 需要外部施加电平，核对上下拉 |
| GPIOB：软件触发中断 | [012](GPIO_IT_DRV_012.c) | 需要端口中断与 PLIC 配置 |
| GPIOB：外部边沿中断 | [013](GPIO_IT_DRV_013.c) | 需要外部边沿信号，核对触发配置 |
| GPIOC：输出波形、置位清零、翻转和输出 API | [014](GPIO_IT_DRV_014.c) | 按源码确认测试掩码和实际波形 |
| GPIOC：输出寄存器回读 | [015](GPIO_IT_DRV_015.c) | 不能替代引脚实测 |
| GPIOC：输入电平读取 | [016](GPIO_IT_DRV_016.c) | 需要外部施加电平，核对上下拉 |
| GPIOC：软件触发中断 | [017](GPIO_IT_DRV_017.c) | 需要端口中断与 PLIC 配置 |
| GPIOC：外部边沿中断 | [018](GPIO_IT_DRV_018.c) | 需要外部边沿信号，核对触发配置 |
| GPIOD：输出波形、置位清零、翻转和输出 API | [019](GPIO_IT_DRV_019.c) | 按源码确认测试掩码和实际波形 |
| GPIOD：输出寄存器回读 | [020](GPIO_IT_DRV_020.c) | 不能替代引脚实测 |
| GPIOD：输入电平读取 | [021](GPIO_IT_DRV_021.c) | 需要外部施加电平，核对上下拉 |
| GPIOD：软件触发中断 | [022](GPIO_IT_DRV_022.c) | 需要端口中断与 PLIC 配置 |
| GPIOD：外部边沿中断 | [023](GPIO_IT_DRV_023.c) | 需要外部边沿信号，核对触发配置 |
| GPIOE：输出波形、置位清零、翻转和输出 API | [024](GPIO_IT_DRV_024.c) | 按源码确认测试掩码和实际波形 |
| GPIOE：输出寄存器回读 | [025](GPIO_IT_DRV_025.c) | 不能替代引脚实测 |
| GPIOE：输入电平读取 | [026](GPIO_IT_DRV_026.c) | 需要外部施加电平，核对上下拉 |
| GPIOE：软件触发中断 | [027](GPIO_IT_DRV_027.c) | 需要端口中断与 PLIC 配置 |
| GPIOE：外部边沿中断 | [028](GPIO_IT_DRV_028.c) | 需要外部边沿信号，核对触发配置 |
| GPIOF：输出波形、置位清零、翻转和输出 API | [029](GPIO_IT_DRV_029.c) | 按源码确认测试掩码和实际波形 |
| GPIOF：输出寄存器回读 | [030](GPIO_IT_DRV_030.c) | 不能替代引脚实测 |
| GPIOF：输入电平读取 | [031](GPIO_IT_DRV_031.c) | 需要外部施加电平，核对上下拉 |
| GPIOF：软件触发中断 | [032](GPIO_IT_DRV_032.c) | 需要端口中断与 PLIC 配置 |
| GPIOF：外部边沿中断 | [033](GPIO_IT_DRV_033.c) | 需要外部边沿信号，核对触发配置 |
| GPIOG：输出波形、置位清零、翻转和输出 API | [034](GPIO_IT_DRV_034.c) | 按源码确认测试掩码和实际波形 |
| GPIOG：输出寄存器回读 | [035](GPIO_IT_DRV_035.c) | 不能替代引脚实测 |
| GPIOG：输入电平读取 | [036](GPIO_IT_DRV_036.c) | 需要外部施加电平，核对上下拉 |
| GPIOG：软件触发中断 | [037](GPIO_IT_DRV_037.c) | 需要端口中断与 PLIC 配置 |
| GPIOG：外部边沿中断 | [038](GPIO_IT_DRV_038.c) | 需要外部边沿信号，核对触发配置 |
| GPIOH：输出波形、置位清零、翻转和输出 API | [039](GPIO_IT_DRV_039.c) | 按源码确认测试掩码和实际波形；GPIOH 仅 10 个通道 |
| GPIOH：输出寄存器回读 | [040](GPIO_IT_DRV_040.c) | 不能替代引脚实测；GPIOH 仅 10 个通道 |
| GPIOH：输入电平读取 | [041](GPIO_IT_DRV_041.c) | 需要外部施加电平，核对上下拉；GPIOH 仅 10 个通道 |
| GPIOH：软件触发中断 | [042](GPIO_IT_DRV_042.c) | 需要端口中断与 PLIC 配置；GPIOH 仅 10 个通道 |
| GPIOH：外部边沿中断 | [043](GPIO_IT_DRV_043.c) | 需要外部边沿信号，核对触发配置；GPIOH 仅 10 个通道 |
| 初始化结构默认值；端口反初始化；特殊引脚保护 | [044](GPIO_IT_DRV_044.c) | 接口和寄存器检查，非最小 GPIO 应用模板 |
| 非法参数；Size / Version；引脚有效性 | [045](GPIO_IT_DRV_045.c) | 参考错误路径与参数校验，不照搬非法配置到应用 |
| GPIO 读写 API 行为；IO 访问参数保护 | [046](GPIO_IT_DRV_046.c) | 偏接口覆盖；基础输出优先 001～004 |
| 中断配置、屏蔽、状态和回调接口 | [047](GPIO_IT_DRV_047.c) | 综合中断接口检查；最小中断参考 007 / 008 |
| 复用 AF；输入类型；上下拉；驱动电流；模式编码 | [048](GPIO_IT_DRV_048.c) | 寄存器编码覆盖；实际外设复用同时参考相应外设用例 |
| 按键消抖；低功耗唤醒；RTOS GPIO 事件 | 无直接对应用例 | 可参考输入或中断用例，但这些应用功能没有独立完整模板 |

001～043 对应原测试计划的移植用例，044～048 是扩展接口测试。

048 在 PD0 写入 `GPIO_AF_USART0` 后检查寄存器编码，属于 GPIO 配置字段测试。引脚表中 PD0 的功能1是 `SPI3_CS3`，该测试不能作为 PD0 支持 USART0 的接线依据；外设信号必须按对应引脚映射选择。

## 实现要点与案例配置

基本流程：HAL 初始化 → 系统时钟 → 延时 → GPIO 时钟和引脚配置 → 测试循环。源码通常配置 PLL 180 MHz，复用时核对目标板条件。

001 测试 PA0～PA7、PA14～PA15，掩码 `0xC0FF`，高低各 500 ms，预期约 1 Hz、50% 占空比。PA8～PA13 因上电 QSPI 功能排除。其他端口的可用与保护引脚须分别查阅源码。

- 输出测试：示波器或逻辑分析仪观察引脚波形。
- 输出回读：检查输出寄存器和观察变量，不能代替引脚实测。
- 输入测试：外部施加电平，核对读取结果。
- 软件中断：软件产生请求，检查中断记录变量。
- 外部中断：外部信号源提供边沿，按源码核对触发模式与中断记录。
- 扩展测试：核对源码中的检查计数、观察变量和配置寄存器；047 还检查 PLIC 中断链路。

007 中断链路：`GPIOA_IRQ_Handler()` → `HAL_GPIO_IRQHandler(GPIOA)` → `HAL_GPIOA_EXTI_Callback()` → 更新 `Interrupt_State`。其他端口使用对应入口与回调。001 不打印日志，其他用例以源码为准。

## 验证方法与适用边界

先根据上方需求表选择用例，再核对完整源码中的引脚、时钟、参数、主循环、中断和回调。推荐表示可参考的实现，不表示已经满足完整产品需求；无直接对应项时，说明需要新增的逻辑。

本索引基于源码静态整理，未重新编译或上板；预期结果与实际验证状态分别判断。

当前记录：已抽查代表性源码及 GPIO HAL 实现；未逐条复核全部用例，未执行编译或上板验证。依赖缺口为本次目录检查结果，补齐后应更新本文，不能长期沿用“缺失”结论。维护格式见 [案例库说明](../README.md#新增外设-readme-的统一写法)。

采用案例前至少确认：设备头、HAL 配置头、GPIO/SMU/PLIC 等实际依赖驱动及项目登记完整；需要 delay 时有匹配实现；IRQ 名称与现有启动/Trap 分发匹配。缺少这些资料时只报告待补齐项，不把源码引用关系视为工程已经可链接。

## 按接口与辅助宏检索

下表按 API 名称提供检索入口，每项最多列出四个参考用例，不是完整调用清单或覆盖率证明。先从需求表选例，再读完整源码及当前 HAL；通用时钟、GPIO 和 DMA 依赖也须一并核对。

| 接口 | 参考用例 |
|---|---|
| `HAL_GPIO_ClearITPendingBit` | [047](GPIO_IT_DRV_047.c) |
| `HAL_GPIO_DeInit` | [044](GPIO_IT_DRV_044.c) |
| `HAL_GPIO_ForceINT` | [007](GPIO_IT_DRV_007.c), [012](GPIO_IT_DRV_012.c), [017](GPIO_IT_DRV_017.c), [022](GPIO_IT_DRV_022.c) |
| `HAL_GPIO_GetITStatus` | [047](GPIO_IT_DRV_047.c) |
| `HAL_GPIO_ITConfig` | [007](GPIO_IT_DRV_007.c), [008](GPIO_IT_DRV_008.c), [012](GPIO_IT_DRV_012.c), [013](GPIO_IT_DRV_013.c) |
| `HAL_GPIO_ITMaskConfig` | [047](GPIO_IT_DRV_047.c) |
| `HAL_GPIO_Init` | [001](GPIO_IT_DRV_001.c), [002](GPIO_IT_DRV_002.c), [003](GPIO_IT_DRV_003.c), [004](GPIO_IT_DRV_004.c) |
| `HAL_GPIO_PinAFConfig` | [014](GPIO_IT_DRV_014.c), [015](GPIO_IT_DRV_015.c), [016](GPIO_IT_DRV_016.c), [017](GPIO_IT_DRV_017.c) |
| `HAL_GPIO_ReadInputPort` | [006](GPIO_IT_DRV_006.c), [011](GPIO_IT_DRV_011.c), [016](GPIO_IT_DRV_016.c), [021](GPIO_IT_DRV_021.c) |
| `HAL_GPIO_ReadOutputPin` | [005](GPIO_IT_DRV_005.c), [010](GPIO_IT_DRV_010.c), [015](GPIO_IT_DRV_015.c), [020](GPIO_IT_DRV_020.c) |
| `HAL_GPIO_ReadOutputPort` | [003](GPIO_IT_DRV_003.c), [005](GPIO_IT_DRV_005.c), [010](GPIO_IT_DRV_010.c), [015](GPIO_IT_DRV_015.c) |
| `HAL_GPIO_ReadPin` | [006](GPIO_IT_DRV_006.c), [011](GPIO_IT_DRV_011.c), [016](GPIO_IT_DRV_016.c), [021](GPIO_IT_DRV_021.c) |
| `HAL_GPIO_StructInit` | [044](GPIO_IT_DRV_044.c), [045](GPIO_IT_DRV_045.c), [047](GPIO_IT_DRV_047.c), [048](GPIO_IT_DRV_048.c) |
| `HAL_GPIO_TogglePin` | [002](GPIO_IT_DRV_002.c), [009](GPIO_IT_DRV_009.c), [014](GPIO_IT_DRV_014.c), [019](GPIO_IT_DRV_019.c) |
| `HAL_GPIO_WritePin` | [001](GPIO_IT_DRV_001.c), [004](GPIO_IT_DRV_004.c), [005](GPIO_IT_DRV_005.c), [009](GPIO_IT_DRV_009.c) |
| `HAL_GPIO_WritePort` | [003](GPIO_IT_DRV_003.c), [004](GPIO_IT_DRV_004.c), [005](GPIO_IT_DRV_005.c), [009](GPIO_IT_DRV_009.c) |

## 观察变量与保护条件

044～048 的扩展测试使用 `Passed_Mask`、`Failed_Mask`、`Check_Count` 等调试观察变量，具体名称及预期值应查看各用例。以 044 为例，预期 `Check_Count == CHECK_TOTAL`、`Passed_Mask == CHECK_ALL`、`Failed_Mask == 0`，不能只看程序进入死循环。

GPIOH 只有 10 个通道，不能套用其他端口的 16 位引脚掩码。044 还检查 GPIOB 的 PB5（JTAG RSTN）及 GPIOH 的 PH0/PH1（BOOT）保护行为。外部边沿中断与软件触发中断须分别验证，软件请求通过不等于外部输入路径通过。

