/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_mpu.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.3
 * Date:   2026/10/10
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.1     apply the resource lock / RTOS rules:
 *                                                       run the MSP callbacks outside the
 *                                                       locked region, add a Timeout and a
 *                                                       NULL-mutex guard to the lock helper,
 *                                                       add the busy / reset state gate,
 *                                                       return HAL_StatusTypeDef from the
 *                                                       channel control setters with
 *                                                       run-time parameter validation, and
 *                                                       keep the write protection off the
 *                                                       I-Port register block of MPU0
 *     ANSILIC APPLICATION GROUP  2026/09/21     1.2     add the configuration read-back
 *                                                       interfaces (GetAddressRange /
 *                                                       GetChannelConfig) and the whole
 *                                                       instance reset (ResetInstance),
 *                                                       verify the programmed registers in
 *                                                       Init (HAL_MPU_ERROR_HARDWARE), type
 *                                                       the instance fields as
 *                                                       HAL_MPU_InstanceTypeDef and document
 *                                                       which I-Port registers the D-Port
 *                                                       type would reach on MPU0
 *     ANSILIC APPLICATION GROUP  2026/10/10     1.3     merge the capabilities of the MPU
 *                                                       release of 2026/09/29 into this
 *                                                       driver: add the not-supported error
 *                                                       code HAL_MPU_ERROR_NOT_SUPPORTED and
 *                                                       reject a write protection request
 *                                                       addressing MPU0 in
 *                                                       HAL_MPU_WriteProtectCmd() and
 *                                                       HAL_MPU_Init() instead of dropping it
 *                                                       silently, close the addressed channel
 *                                                       before a new address range is
 *                                                       programmed, clear the violation status
 *                                                       of a single channel
 *                                                       (HAL_MPU_ClearStatus()) and of the
 *                                                       whole instance
 *                                                       (HAL_MPU_ResetInstance()) with the
 *                                                       write-one-to-clear channel mask, and
 *                                                       check the instance binding of the
 *                                                       read-only state and error reporting
 *                                                       interfaces
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Memory Protection Unit
 *                  (MPU) of the AS32x601:
 *                  - Initialization and de-initialization: HAL_MPU_Init /
 *                    HAL_MPU_DeInit, configuration structure handling;
 *                  - Channel management: address range setting, channel
 *                    enable / disable, write / read protection enable,
 *                    whole instance reset (HAL_MPU_ResetInstance);
 *                  - Configuration read-back: address range and channel
 *                    configuration query (HAL_MPU_GetAddressRange /
 *                    HAL_MPU_GetChannelConfig);
 *                  - Status management: write / read protection status
 *                    query and clear;
 *                  - State and error reporting.
 *
 *                  The AS32x601 embeds five MPU instances, one per bus
 *                  master port:
 *                  - MPU0 (I-Bus): instruction port, 16 channels, no write
 *                    protection register (I-Port layout: PTEN/RPTEN/RPTS);
 *                  - MPU1 (D-Bus): data port, 16 channels;
 *                  - MPU2 (P-Bus): peripheral port, 16 channels;
 *                  - MPU3 (DMA0) / MPU4 (DMA1): DMA ports, 8 channels each;
 *                  the latter four use the D-Port layout
 *                  (PTEN/WPTEN/RPTEN/WPTS/RPTS).
 *                  Each channel defines an address range [StartAddr,
 *                  EndAddr] and an optional read / write protection.
 *
 * @note            All the register writing interfaces (Init / DeInit /
 *                  ResetInstance / SetAddressRange / Cmd / WriteProtectCmd /
 *                  ReadProtectCmd / ClearStatus) take the handle lock and
 *                  reject a call when the handle is busy or not initialized.
 * @note            The single bit status queries (GetWriteProtectStatus /
 *                  GetReadProtectStatus / GetState / GetError) are lock-free,
 *                  so they are callable from an interrupt context; the
 *                  configuration read-back interfaces (GetAddressRange /
 *                  GetChannelConfig) take the lock instead, so that the multi
 *                  register snapshot they return is consistent.
 * @note            The write protection only exists on MPU1..MPU4: a request
 *                  addressing MPU0 is rejected with HAL_ERROR and
 *                  HAL_MPU_ERROR_NOT_SUPPORTED (MPU0 has no such register, so
 *                  the request can never be honoured and is not dropped
 *                  silently).
 * @complexity  Medium
 *              State machine (State/ErrorCode) and blocking lock operations.
 */
#ifndef __AS32X601_HAL_MPU_H
#define __AS32X601_HAL_MPU_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "as32x601.h"               /* MPU register types and channel macros   */
#include "as32x601_hal_def.h"       /* HAL_StatusTypeDef, HAL_LockTypeDef      */

/* Exported constants --------------------------------------------------------*/

/**
 * @brief  MPU HAL driver module version.
 * @note   0x0100U = V1.0. Bumped only on breaking API changes (architecture
 *         spec COMPAT-13/14/15).
 */
#define __HAL_MPU_MODULE_VERSION  0x0100U

/* Exported types ------------------------------------------------------------*/

/** @defgroup MPU_Exported_Types MPU Exported Types
  * @{
  */

/**
 * @brief MPU instance identifiers.
 * @note  The values select the bus master port whose MPU is addressed:
 *        MPU0 = I-Bus, MPU1 = D-Bus, MPU2 = P-Bus, MPU3 = DMA0, MPU4 = DMA1.
 */
typedef enum
{
    HAL_MPU_INSTANCE_0_IBUS = 0x00U, /*!< MPU0: instruction bus port   */
    HAL_MPU_INSTANCE_1_DBUS = 0x01U, /*!< MPU1: data bus port          */
    HAL_MPU_INSTANCE_2_PBUS = 0x02U, /*!< MPU2: peripheral bus port    */
    HAL_MPU_INSTANCE_3_DMA0 = 0x03U, /*!< MPU3: DMA0 port              */
    HAL_MPU_INSTANCE_4_DMA1 = 0x04U  /*!< MPU4: DMA1 port              */
} HAL_MPU_InstanceTypeDef;

/**
 * @brief HAL MPU state structures definition.
 */
typedef enum
{
    HAL_MPU_STATE_RESET      = 0x00U, /*!< Peripheral not initialized          */
    HAL_MPU_STATE_READY      = 0x01U, /*!< Peripheral initialized and ready    */
    HAL_MPU_STATE_BUSY       = 0x02U, /*!< An internal process is ongoing      */
    HAL_MPU_STATE_ERROR      = 0x03U  /*!< MPU error state                     */
} HAL_MPU_StateTypeDef;

/**
 * @brief MPU configuration structure definition.
 * @note  The write protection is only available on the D-Bus / P-Bus / DMA
 *        ports (MPU1..MPU4); a write protection request on MPU0 is rejected
 *        by HAL_MPU_Init() with HAL_ERROR and HAL_MPU_ERROR_NOT_SUPPORTED,
 *        because MPU0 has no write protection register.
 * @note  Unlike the other drivers of the library, whose handles carry a
 *        register block pointer, the MPU identifies its instance with an
 *        index of the HAL_MPU_InstanceTypeDef enumeration: the five MPU
 *        instances use two different register layouts (MPU0 = I-Port,
 *        MPU1..MPU4 = D-Port), so no single pointer type can address them
 *        all. The layout is resolved from the index by the driver.
 */
typedef struct
{
    uint32 Size;   /*!< sizeof(MPU_InitTypeDef), set by the user after clearing the
                                structure */
    uint32 Version;   /*!< Structure semantic version: @ref MPU_INIT_VERSION
                                (MPU_INIT_V1 = 0x0100U) */
    HAL_MPU_InstanceTypeDef Instance;   /*!< MPU instance: HAL_MPU_INSTANCE_0..4  */
    uint32 Channel;             /*!< Channel index: 0..15 (MPU3/4: 0..7)  */
    uint32 StartAddr;           /*!< Start address of the protected range  */
    uint32 EndAddr;             /*!< End address of the protected range    */
    uint32 WriteProtectEnable;  /*!< Write protection enable (0/1, MPU1..4) */
    uint32 ReadProtectEnable;   /*!< Read protection enable (0/1)          */
    uint32 ChannelEnable;       /*!< Channel enable (0/1)                  */
    uint32 Reserved[2];         /*!< Reserved for future extension (must be 0) */
} MPU_InitTypeDef;

#define MPU_INIT_V1      0x0100U                        /*!< Init structure version 1 */
#define MPU_INIT_VERSION MPU_INIT_V1                    /*!< Init structure semantic version */

/**
 * @brief MPU handle structure definition.
 */
typedef struct __HAL_MPU_HandleTypeDef
{
    HAL_MPU_InstanceTypeDef   Instance;      /*!< MPU instance id (0..4)      */
    MPU_InitTypeDef           Init;          /*!< MPU configuration parameters */
    HAL_LockTypeDef           Lock;          /*!< Locking object              */
    __IO HAL_MPU_StateTypeDef State;         /*!< MPU communication state     */
    __IO uint32               ErrorCode;     /*!< MPU error code              */
#if (USE_RTOS == 1)
    HAL_MutexTypeDef          LockMutex;     /*!< RTOS mutex handle (created by the
                                                  user porting layer, e.g. in
                                                  HAL_MPU_MspInit)            */
#endif /* USE_RTOS */
} HAL_MPU_HandleTypeDef;

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @defgroup MPU_Exported_Constants MPU Exported Constants
  * @{
  */

/** @defgroup MPU_Error_Code MPU Error Code
  * @note  The codes are independent bit flags so that a combination can be
  *        reported with the bitwise OR operator.
  * @{
  */
#define HAL_MPU_ERROR_NONE           ((uint32)0x00000000U) /*!< No error                             */
#define HAL_MPU_ERROR_INVALID_PARAM  ((uint32)0x00000001U) /*!< Invalid parameter, invalid
                                                                configuration structure or a
                                                                rejected operation              */
#define HAL_MPU_ERROR_HARDWARE       ((uint32)0x00000002U) /*!< Configuration read-back
                                                                verification failed: the
                                                                programmed channel register does
                                                                not hold the requested value    */
#define HAL_MPU_ERROR_NOT_SUPPORTED  ((uint32)0x00000004U) /*!< The addressed instance does not
                                                                implement the requested
                                                                capability: a write protection
                                                                request addressing MPU0, whose
                                                                layout has no write protection
                                                                register                         */
/**
  * @}
  */

/** @defgroup MPU_Enable_Value MPU Enable Value
  * @{
  */
#define MPU_ENABLE                    1U       /*!< Enable the MPU function     */
#define MPU_DISABLE                   0U       /*!< Disable the MPU function    */
/**
  * @}
  */

/**
  * @}
  */

/* Exported macros ------------------------------------------------------------*/

/** @defgroup MPU_Exported_Macros MPU Exported Macros
  * @{
  */

/**
 * @brief  Reset the handle State field.
 * @note   Must be used before passing a local handle to HAL_MPU_Init() the
 *         first time, so that the low level initialization (MspInit) is
 *         always executed.
 */
#define __HAL_MPU_RESET_HANDLE_STATE(__HANDLE__) ((__HANDLE__)->State = 0U)

/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/

/** @addtogroup MPU_Exported_Functions
  * @{
  */

/** @addtogroup MPU_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Fills each MPU_InitStruct member with its default value
 *         (instance 0, channel 0, address range 0, protections and channel
 *         disabled). (NON-BLOCKING)
 * @param  MPU_InitStruct: pointer to a MPU_InitTypeDef structure which
 *         will be initialized.
 * @retval None
 */
void HAL_MPU_StructInit(MPU_InitTypeDef *MPU_InitStruct);

/**
 * @brief  Initializes a MPU channel according to the specified parameters
 *         in the MPU_InitStruct of the handle. (NON-BLOCKING)
 * @note   The channel is closed first, then the address range is programmed,
 *         then the write / read protection and finally the channel enable
 *         (per the enable bits): a channel that was already enabled never
 *         holds the new start address together with the previous end address,
 *         so re-configuring it cannot expose a transient range and latch a
 *         spurious violation. A zero channel enable request restores the
 *         enable state the channel had before it was closed, so the end state
 *         of the earlier release is preserved.
 * @note   The write protection only exists on MPU1..MPU4: a write protection
 *         requested for MPU0 (I-Port) is rejected with HAL_ERROR and
 *         HAL_MPU_ERROR_NOT_SUPPORTED before any register is written, because
 *         MPU0 has no such register and the request can never be honoured.
 * @note   The parameters and the configuration structure metafields (Size /
 *         Version) are validated at run time: an invalid configuration is
 *         rejected with HAL_ERROR and HAL_MPU_ERROR_INVALID_PARAM without
 *         changing the handle state.
 * @note   The programmed registers are read back before the call returns: a
 *         channel register that does not hold the requested value (the address
 *         range or a requested enable bit) rejects the call with HAL_ERROR,
 *         sets HAL_MPU_ERROR_HARDWARE and leaves the handle in the ERROR state.
 * @note   LOCK-06: the low level initialization (HAL_MPU_MspInit()) runs
 *         before the handle is locked.
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (NULL pointer, invalid configuration, write
 *         protection request on MPU0 or failed read-back verification)
 */
HAL_StatusTypeDef HAL_MPU_Init(HAL_MPU_HandleTypeDef *hmpu);

/**
 * @brief  De-initializes a MPU channel. (NON-BLOCKING)
 * @note   The channel is disabled and its address range and protection bits
 *         are cleared; the handle goes back to the RESET state so that a
 *         following HAL_MPU_Init() re-runs HAL_MPU_MspInit().
 * @note   The call is accepted from any handle state, so that a failed
 *         initialization can always be undone.
 * @note   LOCK-06: the low level de-initialization (HAL_MPU_MspDeInit()) runs
 *         after the unlock.
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (NULL pointer or invalid instance)
 */
HAL_StatusTypeDef HAL_MPU_DeInit(HAL_MPU_HandleTypeDef *hmpu);

/**
 * @brief  Resets the whole MPU instance: every channel of the instance is
 *         disabled and its address range, protection enables and protection
 *         status are cleared. (NON-BLOCKING)
 * @note   Unlike HAL_MPU_DeInit(), which clears the single channel named by
 *         the handle configuration, this interface clears all the channels of
 *         the instance in one call: use it to recover the instance after
 *         several channels have been configured, or to leave it in a known
 *         state. The handle stays initialized (the state returns to READY), so
 *         no HAL_MPU_Init() is required afterwards.
 * @note   The channel count comes from the instance (MPU0/1/2: 16 channels,
 *         MPU3/4: 8 channels). The write protection registers are skipped on
 *         MPU0, which has no such hardware.
 * @note   The violation status registers are cleared by writing one, so the
 *         mask of every channel of the instance is written to them: writing
 *         zero would leave the latched violations untouched.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_MPU_Init() is required first).
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken or another operation is ongoing) / HAL_ERROR (NULL pointer,
 *         invalid instance or the handle is not initialized)
 */
HAL_StatusTypeDef HAL_MPU_ResetInstance(HAL_MPU_HandleTypeDef *hmpu);

/**
 * @brief  Initializes the MPU MSP. Weak empty function; the MPU is directly
 *         clocked by the AXILite bus clock, no clock gating is needed.
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @retval None
 */
void HAL_MPU_MspInit(HAL_MPU_HandleTypeDef *hmpu);

/**
 * @brief  De-initializes the MPU MSP. Weak empty function.
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @retval None
 */
void HAL_MPU_MspDeInit(HAL_MPU_HandleTypeDef *hmpu);

/**
  * @}
  */

/** @addtogroup MPU_Exported_Functions_Group2 Peripheral Control functions
  * @{
  */

/**
 * @brief  Sets the address range of a MPU channel. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_MPU_Init() is required first).
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @param  Channel: channel index (0..15, MPU3/4: 0..7).
 * @param  StartAddr: start address of the protected range.
 * @param  EndAddr: end address of the protected range (must be greater
 *         than StartAddr).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_MPU_SetAddressRange(HAL_MPU_HandleTypeDef *hmpu, uint32 Channel, uint32 StartAddr,
                                          uint32 EndAddr);

/**
 * @brief  Enables or disables a MPU channel. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_MPU_Init() is required first).
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @param  Channel: channel index (0..15, MPU3/4: 0..7).
 * @param  NewState: ENABLE or DISABLE (MPU_ENABLE / MPU_DISABLE).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_MPU_Cmd(HAL_MPU_HandleTypeDef *hmpu, uint32 Channel, FunctionalState NewState);

/**
 * @brief  Enables or disables the write protection of a MPU channel. (NON-BLOCKING)
 * @note   Only supported by MPU1..MPU4 (D-Bus / P-Bus / DMA ports); MPU0
 *         (I-Bus) has no write-protection hardware: a request addressing MPU0
 *         is rejected with HAL_ERROR and HAL_MPU_ERROR_NOT_SUPPORTED without
 *         touching any register, because the capability does not exist and the
 *         request can never be honoured.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_MPU_Init() is required first).
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @param  Channel: channel index (0..15, MPU3/4: 0..7).
 * @param  NewState: ENABLE or DISABLE (MPU_ENABLE / MPU_DISABLE).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter, write protection request on
 *         MPU0 or the handle is not initialized)
 */
HAL_StatusTypeDef HAL_MPU_WriteProtectCmd(HAL_MPU_HandleTypeDef *hmpu, uint32 Channel,
                                          FunctionalState NewState);

/**
 * @brief  Enables or disables the read protection of a MPU channel. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_MPU_Init() is required first).
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @param  Channel: channel index (0..15, MPU3/4: 0..7).
 * @param  NewState: ENABLE or DISABLE (MPU_ENABLE / MPU_DISABLE).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_MPU_ReadProtectCmd(HAL_MPU_HandleTypeDef *hmpu, uint32 Channel,
                                         FunctionalState NewState);

/**
  * @}
  */

/** @addtogroup MPU_Exported_Functions_Group3 Status and configuration functions
  * @{
  */

/**
 * @brief  Returns the write-protection violation status of a MPU channel.
 *         (NON-BLOCKING)
 * @note   This is the violation status (the WPTS register): the bit is set
 *         once a write access has hit the protected range, and it is cleared
 *         by HAL_MPU_ClearStatus(). The write protection enable itself (the
 *         WPTEN register) is read back by HAL_MPU_GetChannelConfig().
 * @note   Only valid for MPU1..MPU4; MPU0 has no write protection hardware
 *         and 0 is returned.
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context.
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @param  Channel: channel index (0..15, MPU3/4: 0..7).
 * @retval 1 if the write-protection violation status is set, 0 otherwise (also
 *         when the handle, the instance or the channel is invalid).
 */
uint32 HAL_MPU_GetWriteProtectStatus(HAL_MPU_HandleTypeDef *hmpu, uint32 Channel);

/**
 * @brief  Returns the read-protection violation status of a MPU channel.
 *         (NON-BLOCKING)
 * @note   This is the violation status (the RPTS register): the bit is set
 *         once a read access has hit the protected range, and it is cleared by
 *         HAL_MPU_ClearStatus(). The read protection enable itself (the RPTEN
 *         register) is read back by HAL_MPU_GetChannelConfig().
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context.
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @param  Channel: channel index (0..15, MPU3/4: 0..7).
 * @retval 1 if the read-protection violation status is set, 0 otherwise (also
 *         when the handle, the instance or the channel is invalid).
 */
uint32 HAL_MPU_GetReadProtectStatus(HAL_MPU_HandleTypeDef *hmpu, uint32 Channel);

/**
 * @brief  Clears the write / read protection status of a MPU channel. (NON-BLOCKING)
 * @note   The status registers are cleared by writing one, so only the bit of
 *         the addressed channel is written: a read-modify-write would read the
 *         latched status back and write the other channel bits as one, which
 *         would clear the pending violations of every channel of the instance.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_MPU_Init() is required first).
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @param  Channel: channel index (0..15, MPU3/4: 0..7).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_MPU_ClearStatus(HAL_MPU_HandleTypeDef *hmpu, uint32 Channel);

/**
 * @brief  Reads back the address range of a MPU channel. (NON-BLOCKING)
 * @note   The SADDR / EADDR registers are readable, so the range that is
 *         really programmed can be verified: the driver writes them from
 *         HAL_MPU_Init() and HAL_MPU_SetAddressRange() only, there is no
 *         other path to them.
 * @note   The lock is taken so that the two register reads form a consistent
 *         snapshot; the single bit queries of this group are lock-free
 *         instead and remain callable from an interrupt context.
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @param  Channel: channel index (0..15, MPU3/4: 0..7).
 * @param  StartAddr: pointer to the variable receiving the start address.
 * @param  EndAddr: pointer to the variable receiving the end address.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (NULL pointer, invalid instance or invalid
 *         channel)
 */
HAL_StatusTypeDef HAL_MPU_GetAddressRange(HAL_MPU_HandleTypeDef *hmpu, uint32 Channel,
                                          uint32 *StartAddr, uint32 *EndAddr);

/**
 * @brief  Reads back the configuration of a MPU channel. (NON-BLOCKING)
 * @note   The whole configuration is returned in a MPU_InitTypeDef structure:
 *         the instance, the channel, the address range and the protection /
 *         channel enable bits as they are programmed in the registers, so
 *         that a configuration can be verified or carried over to another
 *         channel. The size / version metafields are filled in and the
 *         reserved words are cleared.
 * @note   The enable bits come from the PTEN / WPTEN / RPTEN registers, that
 *         is from the configuration. They are NOT the violation status
 *         reported by HAL_MPU_GetWriteProtectStatus() and
 *         HAL_MPU_GetReadProtectStatus(), which read the WPTS / RPTS
 *         registers. WriteProtectEnable always reads back as 0 on MPU0, which
 *         has no write protection hardware.
 * @note   The lock is taken so that the register reads form a consistent
 *         snapshot; the single bit queries of this group are lock-free
 *         instead and remain callable from an interrupt context.
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @param  Channel: channel index (0..15, MPU3/4: 0..7).
 * @param  pConfig: pointer to the MPU_InitTypeDef structure that receives the
 *         configuration (its size / version metafields are filled in).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (NULL pointer, invalid instance or invalid
 *         channel)
 */
HAL_StatusTypeDef HAL_MPU_GetChannelConfig(HAL_MPU_HandleTypeDef *hmpu, uint32 Channel,
                                           MPU_InitTypeDef *pConfig);

/**
  * @}
  */

/** @addtogroup MPU_Exported_Functions_Group4 State functions
  * @{
  */

/**
 * @brief  Returns the MPU handle state. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context.
 * @note   The instance binding is checked as well: a handle whose instance is
 *         not one of the approved instances reports HAL_MPU_STATE_RESET.
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @retval HAL_MPU_StateTypeDef: the current handle state.
 */
HAL_MPU_StateTypeDef HAL_MPU_GetState(HAL_MPU_HandleTypeDef *hmpu);

/**
 * @brief  Returns the MPU error code. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context.
 * @note   The instance binding is checked as well: a handle whose instance is
 *         not one of the approved instances reports
 *         HAL_MPU_ERROR_INVALID_PARAM.
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @retval uint32: the MPU error code (HAL_MPU_ERROR_xxx).
 */
uint32 HAL_MPU_GetError(HAL_MPU_HandleTypeDef *hmpu);

/**
  * @}
  */

/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/

/** @defgroup MPU_Private_Macros MPU Private Macros
  * @{
  */

/**
 * @brief  Check that the MPU instance is a valid value (0..4).
 */
#define IS_MPU_INSTANCE(INSTANCE) ((INSTANCE) <= 4U)

/**
 * @brief  Check that the MPU channel index is valid for the instance.
 * @note   MPU0/1/2 expose 16 channels, MPU3/4 expose 8 channels.
 */
#define IS_MPU_CHANNEL(INSTANCE, CHANNEL) (((INSTANCE) <= 2U) ? ((CHANNEL) <= 15U) : ((CHANNEL) <= 7U))

/**
 * @brief  Check that the write protection instance is valid (MPU1..MPU4).
 */
#define IS_MPU_WP_INSTANCE(INSTANCE) (((INSTANCE) >= 1U) && ((INSTANCE) <= 4U))

/**
 * @brief  Check that the enable value is valid.
 * @note   The driver validates the parameter of the enable / disable
 *         interfaces with the library wide IS_FUNCTIONAL_STATE() macro; the
 *         MPU_ENABLE / MPU_DISABLE constants stay in use by the callers.
 */
#define IS_MPU_ENABLE_STATE(NEWSTATE) (((NEWSTATE) == MPU_ENABLE) || ((NEWSTATE) == MPU_DISABLE))

/**
  * @}
  */

/* Shared internal functions --------------------------------------------------*/

/**
 * @brief  Returns the D-Port register block of the given MPU instance.
 * @note   This interface is meant for MPU1..MPU4, which use the D-Port layout.
 *         For MPU0 it returns the I-Port block address cast to the D-Port
 *         type, and only the PTEN member is valid through it, because the two
 *         layouts share that single offset (0x00). The I-Port block holds
 *         three control/status registers where the D-Port block holds five, so
 *         the remaining members resolve to different registers:
 *         - WPTEN (0x04) lands on the I-Port RPTEN register,
 *         - RPTEN (0x08) lands on the I-Port RPTS register,
 *         - WPTS (0x0C) lands on the SADDR register of MPU0 channel 0,
 *         - RPTS (0x10) lands on the EADDR register of MPU0 channel 0.
 *         Programming them through this pointer would silently corrupt the
 *         read protection or the protected range of MPU0: use
 *         HAL_MPU_GetIPortBlock() for the registers of MPU0.
 * @param  Instance: MPU instance (HAL_MPU_INSTANCE_0..4).
 * @retval MPU_DPort_TypeDef: pointer to the register block.
 */
MPU_DPort_TypeDef *HAL_MPU_GetRegBlock(HAL_MPU_InstanceTypeDef Instance);

/**
 * @brief  Returns the I-Port register block (MPU0 only).
 * @note   The only accessor that reaches the PTEN / RPTEN / RPTS registers of
 *         MPU0 at their real offsets.
 * @param  Instance: MPU instance (HAL_MPU_INSTANCE_0_IBUS; the I-Port layout
 *         exists on MPU0 only).
 * @retval MPU_IPort_TypeDef: pointer to the register block.
 */
MPU_IPort_TypeDef *HAL_MPU_GetIPortBlock(HAL_MPU_InstanceTypeDef Instance);

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_MPU_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; when the mutex is not acquired before the
 *         Timeout expires, HAL_TIMEOUT is returned. The value is passed to
 *         HAL_MutexAcquire() as is (RTOS ticks; with the usual 1 ms tick it is
 *         the same quantity as the millisecond Timeout of the public API, and
 *         HAL_MAX_DELAY means an infinite wait).
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef MPU_LockHandle(HAL_MPU_HandleTypeDef *hmpu, uint32 Timeout);

/**
 * @brief  Unlock the handle.
 * @param  hmpu: pointer to a HAL_MPU_HandleTypeDef structure.
 * @retval None
 */
void MPU_UnlockHandle(HAL_MPU_HandleTypeDef *hmpu);

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_MPU_H */

/*****END OF FILE*****/
