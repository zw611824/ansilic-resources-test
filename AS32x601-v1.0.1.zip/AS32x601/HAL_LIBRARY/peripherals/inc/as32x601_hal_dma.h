/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_dma.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.5
 * Date:   2026/10/10
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/21     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/21     1.4     align the resource lock and the RTOS support with the
 *                                                       architecture specification (section 13 LOCK-01..06 and
 *                                                       section 21 RTOS-04/11): the public lock macros are
 *                                                       replaced by the shared lock helpers with a Timeout
 *                                                       parameter and a NULL mutex guard (RTOS-11), the
 *                                                       de-initialization no longer releases a lock it never
 *                                                       acquired, the MSP callbacks run outside the locked
 *                                                       region (LOCK-06) with the MSP init on the first
 *                                                       initialization only (MSP-04), every lock failure return
 *                                                       is documented as a path where the lock is not held
 *                                                       (LOCK-02), a state gate is applied to the start and the
 *                                                       callback interfaces while the abort and the polling
 *                                                       interfaces use a gate that accepts the busy state, the
 *                                                       handle and the instance are checked through one shared
 *                                                       helper, the polling loop yields the CPU (RTOS-04), the
 *                                                       configuration structure is validated at run time, the
 *                                                       handle keeps the RTOS mutex at the end of the structure
 *                                                       and the external implementation references are dropped
 *     ANSILIC APPLICATION GROUP  2026/10/10     1.5     merge the capabilities of the DMA release of 2026/10/10
 *                                                       into this driver: guard the read-modify-write of the
 *                                                       controller registers shared by the 16 channels (the CHEN
 *                                                       enable bits and the ERR/HTF/FTF interrupt mask bits, plus
 *                                                       the PTCH request mapping and the CCR watchdog field in the
 *                                                       extension file) with a short interrupt masked critical
 *                                                       section, publish and clear the callback pointers in the
 *                                                       same critical section (they are read by the ISR without
 *                                                       the handle lock), enforce the documented 1..0xFFFF buffer
 *                                                       domain of the transfer length at run time on the start and
 *                                                       the counter interfaces, confirm that the channel has
 *                                                       stopped before HAL_DMA_Abort() reports success, accept a
 *                                                       recoverable state only once the channel is inactive, bind
 *                                                       the state, error and counter queries to a valid instance,
 *                                                       release the handle lock while polling (architecture rule
 *                                                       section 12), finalize the data cache on the error, abort
 *                                                       and half transfer paths, and restore the parameter
 *                                                       assertions of the abort, polling, interrupt and callback
 *                                                       interfaces
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Direct Memory Access
 *                  (DMA) peripheral:
 *                  - Initialization and de-initialization (HAL_DMA_Init /
 *                    HAL_DMA_DeInit + weak MSP hooks);
 *                  - IO operation (HAL_DMA_Start / HAL_DMA_Start_IT /
 *                    HAL_DMA_Abort / HAL_DMA_Abort_IT /
 *                    HAL_DMA_PollForTransfer / HAL_DMA_IRQHandler);
 *                  - Peripheral control and flag management (HAL_DMA_ITConfig /
 *                    HAL_DMA_StructInit / HAL_DMA_SetCurrDataCounter /
 *                    HAL_DMA_GetCurrDataCounter / HAL_DMA_GetFlagStatus /
 *                    HAL_DMA_ClearFlag / HAL_DMA_GetITStatus /
 *                    HAL_DMA_ClearITPendingBit);
 *                  - Callback registration (HAL_DMA_RegisterCallback /
 *                    HAL_DMA_UnRegisterCallback / HAL_DMA_CleanCallbacks);
 *                  - Peripheral state and errors (HAL_DMA_GetState /
 *                    HAL_DMA_GetError).
 *                  The chip-specific extended features (watchdog, dual-core
 *                  lock step, peripheral interface mapping) are provided by
 *                  this driver.
 *                  This driver depends on as32x601_hal_def.h (HAL common
 *                  types and utilities) and on the SMU HAL module for the
 *                  peripheral clock enable / reset release in HAL_DMA_MspInit
 *                  (see the weak implementations in as32x601_hal_dma.c).
 * @complexity  Complex
 *              Blocking + Interrupt modes, state machine, user callbacks.
 */
#ifndef __AS32X601_HAL_DMA_H
#define __AS32X601_HAL_DMA_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "as32x601_hal_def.h"       /* HAL common types and utilities          */
#include "as32x601.h"               /* DMA_TypeDef, DMA0/DMA1, register bits   */

/* Exported constants --------------------------------------------------------*/

/**
 * @brief DMA HAL driver module version.
 * @note  0x0100U = V1.0. Bumped only on breaking API changes (architecture
 *        spec COMPAT-13/14/15).
 */
#define __HAL_DMA_MODULE_VERSION  0x0100U

/* Exported types ------------------------------------------------------------*/

/** @defgroup DMA_Exported_Types DMA Exported Types
  * @{
  */

/**
 * @brief  HAL DMA State structures definition
 * @note   The state is a mutually exclusive value (unlike the ADC states
 *         which are bitfields): the handle State field and the
 *         HAL_DMA_GetState() return value are typed HAL_DMA_StateTypeDef.
 * @{
 */
#define HAL_DMA_STATE_RESET             0x00000000U  /*!< DMA not yet initialized or disabled */
#define HAL_DMA_STATE_READY             0x00000001U  /*!< DMA initialized and ready for use   */
#define HAL_DMA_STATE_BUSY              0x00000002U  /*!< DMA process is ongoing              */
#define HAL_DMA_STATE_TIMEOUT           0x00000003U  /*!< DMA timeout state                   */
#define HAL_DMA_STATE_ERROR             0x00000004U  /*!< DMA error state                     */
#define HAL_DMA_STATE_ABORT             0x00000005U  /*!< DMA Abort state                     */
typedef uint32 HAL_DMA_StateTypeDef;
/**
  * @}
  */

/**
 * @brief  HAL DMA Level Complete structures definition
 * @{
 */
#define HAL_DMA_FULL_TRANSFER           0x00000000U  /*!< Full transfer */
#define HAL_DMA_HALF_TRANSFER           0x00000001U  /*!< Half Transfer */
typedef uint32 HAL_DMA_LevelCompleteTypeDef;
/**
  * @}
  */

/**
 * @brief  HAL DMA Callback ID structures definition
 * @note   The values keep the conventional numeric encodings (M1 related
 *         IDs, not supported by this chip, are removed).
 * @{
 */
#define HAL_DMA_XFER_CPLT_CB_ID         0x00000000U  /*!< Full transfer */
#define HAL_DMA_XFER_HALFCPLT_CB_ID     0x00000001U  /*!< Half Transfer */
#define HAL_DMA_XFER_ERROR_CB_ID        0x00000004U  /*!< Error         */
#define HAL_DMA_XFER_ABORT_CB_ID        0x00000005U  /*!< Abort         */
#define HAL_DMA_XFER_ALL_CB_ID          0x00000006U  /*!< All           */
typedef uint32 HAL_DMA_CallbackIDTypeDef;
/**
  * @}
  */

/**
 * @brief DMA Init Structure definition
 * @note  The fields keep the conventional field names so that existing code
 *         keeps compiling. All the configuration values are the CHCTL register
 *         bit values (DIR/PINC/MINC/PSIZE/MSIZE/PRIO/M2M fields) and are
 *         OR-ed together, exactly like the channel initialization.
 *         The DMA_Mode field extends the configuration structure to expose
 *         the circular mode bit (CIRC, CHCTL bit 2).
 *
 */
typedef struct
{
    uint32 Size;                                  /*!< sizeof(DMA_InitTypeDef), set by the user
                                                       after clearing the structure */
    uint32 Version;   /*!< Structure semantic version: @ref
                                                  DMA_INIT_VERSION (DMA_INIT_V1 = 0x0100U) */
    uint32 DMA_PeripheralBaseAddr;   /*!< Peripheral base address for the DMA
                                                  channel.   */
    uint32 DMA_MemoryBaseAddr;   /*!< Memory base address for the DMA channel.
                                                      */
    uint32 DMA_DIR;   /*!< Data transfer direction:
                                                  DMA_PERIPH_TO_MEMORY / DMA_MEMORY_TO_PERIPH */
    uint32 DMA_BufferSize;   /*!< Buffer size in data units (1..0xFFFF).
                                                      */
    uint32 DMA_PeripheralInc;   /*!< Peripheral address increment:
                                                  DMA_PINC_ENABLE / DMA_PINC_DISABLE */
    uint32 DMA_MemoryInc;   /*!< Memory address increment: DMA_MINC_ENABLE
                                                  / DMA_MINC_DISABLE */
    uint32 DMA_PeripheralDataSize;   /*!< Peripheral data width: DMA_PDATAALIGN_BYTE
                                                  / _HALFWORD / _WORD */
    uint32 DMA_MemoryDataSize;   /*!< Memory data width: DMA_MDATAALIGN_BYTE /
                                                  _HALFWORD / _WORD */
    uint32 DMA_Priority;   /*!< Channel priority: DMA_PRIORITY_LOW /
                                                  _MEDIUM / _HIGH / _VERY_HIGH */
    uint32 DMA_M2M;   /*!< Memory-to-memory mode: DMA_M2M_Enable /
                                                  DMA_M2M_Disable */
    uint32 DMA_Mode;   /*!< Channel mode: DMA_NORMAL / DMA_CIRCULAR
                                                      */
    uint32 Reserved[2];                           /*!< Reserved for future extension (must be 0) */
} DMA_InitTypeDef;

/**
 * @brief DMA init structure version macros.
 * @note  DMA_INIT_V1 is the current version. Future versions must be
 *        appended after the existing fields (architecture spec section 22.5).
 */
#define DMA_INIT_V1  0x0100U   /*!< DMA Init structure version V1.0 */
#define DMA_INIT_VERSION  DMA_INIT_V1   /*!< Current DMA Init structure version */

/**
 * @brief  DMA handle Structure definition
 * @note   One handle is created per channel (DMAx_Channel0..15). The
 *         ChannelIndex field (0..15) is computed by HAL_DMA_Init() and used
 *         by the IRQ handler and the flag macros to select the channel bit
 *         inside the shared 16-bit interrupt registers. The owning
 *         controller (DMA0/DMA1) is derived from the Instance address.
 */
typedef struct __DMA_HandleTypeDef
{
    DMA_Channel_TypeDef              *Instance;   /*!< Register base address                  */
    DMA_InitTypeDef                  Init;        /*!< DMA communication parameters           */
    HAL_LockTypeDef                  Lock;        /*!< DMA locking object                      */
    __IO HAL_DMA_StateTypeDef        State;       /*!< DMA transfer state                      */
    __IO uint32                      ErrorCode;   /*!< DMA Error code                           */
    void                             *Parent;     /*!< Parent object state                     */
    void (* XferCpltCallback)(struct __DMA_HandleTypeDef *hdma);   /*!< DMA transfer complete
                                                                     callback  */
    void (* XferHalfCpltCallback)(struct __DMA_HandleTypeDef *hdma);   /*!< DMA half transfer
                                                                     complete callback */
    void (* XferErrorCallback)(struct __DMA_HandleTypeDef *hdma);   /*!< DMA transfer error
                                                                     callback     */
    void (* XferAbortCallback)(struct __DMA_HandleTypeDef *hdma);   /*!< DMA transfer Abort
                                                                     callback     */
    uint32                           ChannelIndex; /*!< DMA channel index (0..15)                */
#if (USE_RTOS == 1)
    HAL_MutexTypeDef                 LockMutex;   /*!< RTOS mutex handle                       */
#endif
} DMA_HandleTypeDef;

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @defgroup DMA_Exported_Constants DMA Exported Constants
  * @{
  */

/** @defgroup DMA_Error_Code DMA Error Code
  * @note  The values use the conventional numeric encodings.
  * @{
  */
#define HAL_DMA_ERROR_NONE              0x00000000U  /*!< No error                            */
#define HAL_DMA_ERROR_TE                0x00000001U  /*!< Transfer error                      */
#define HAL_DMA_ERROR_TIMEOUT           0x00000020U  /*!< Timeout error                       */
#define HAL_DMA_ERROR_PARAM             0x00000040U  /*!< Parameter error                     */
#define HAL_DMA_ERROR_NO_XFER           0x00000080U  /*!< Abort requested with no Xfer ongoing */
#define HAL_DMA_ERROR_NOT_SUPPORTED     0x00000100U  /*!< Not supported mode                  */
/**
  * @}
  */

/** @defgroup DMA_Data_transfer_direction DMA Data transfer direction
  * @note  Values are the CHCTL.DIR bit values. The memory-to-memory transfer
  *        is not a direction on this chip: it is enabled with the DMA_M2M
  *        field (CHCTL.M2M bit).
  * @{
  */
#define DMA_PERIPH_TO_MEMORY            0x00000000U  /*!< Peripheral to memory direction */
#define DMA_MEMORY_TO_PERIPH            0x00000002U  /*!< Memory to peripheral direction */

/* Legacy aliases kept for source compatibility */
#define DMA_DIR_PeripheralSRC           DMA_PERIPH_TO_MEMORY      /*!< legacy alias */
#define DMA_DIR_PeripheralDST           DMA_MEMORY_TO_PERIPH      /*!< legacy alias */
/**
  * @}
  */

/** @defgroup DMA_Peripheral_incremented_mode DMA Peripheral incremented mode
  * @{
  */
#define DMA_PINC_ENABLE                 0x00000008U  /*!< Peripheral increment mode enable  */
#define DMA_PINC_DISABLE                0x00000000U  /*!< Peripheral increment mode disable */

/* Legacy aliases kept for source compatibility */
#define DMA_PeripheralInc_Enable        DMA_PINC_ENABLE           /*!< legacy alias */
#define DMA_PeripheralInc_Disable       DMA_PINC_DISABLE          /*!< legacy alias */
/**
  * @}
  */

/** @defgroup DMA_Memory_incremented_mode DMA Memory incremented mode
  * @{
  */
#define DMA_MINC_ENABLE                 0x00000010U  /*!< Memory increment mode enable  */
#define DMA_MINC_DISABLE                0x00000000U  /*!< Memory increment mode disable */

/* Legacy aliases kept for source compatibility */
#define DMA_MemoryInc_Enable            DMA_MINC_ENABLE           /*!< legacy alias */
#define DMA_MemoryInc_Disable           DMA_MINC_DISABLE          /*!< legacy alias */
/**
  * @}
  */

/** @defgroup DMA_Peripheral_data_size DMA Peripheral data size
  * @{
  */
#define DMA_PDATAALIGN_BYTE             0x00000000U  /*!< Peripheral data alignment: Byte     */
#define DMA_PDATAALIGN_HALFWORD         0x00000020U  /*!< Peripheral data alignment: HalfWord */
#define DMA_PDATAALIGN_WORD             0x00000040U  /*!< Peripheral data alignment: Word     */

/* Legacy aliases kept for source compatibility */
#define DMA_PeripheralDataSize_Byte     DMA_PDATAALIGN_BYTE       /*!< legacy alias */
#define DMA_PeripheralDataSize_HalfWord DMA_PDATAALIGN_HALFWORD   /*!< legacy alias */
#define DMA_PeripheralDataSize_Word     DMA_PDATAALIGN_WORD       /*!< legacy alias */
/**
  * @}
  */

/** @defgroup DMA_Memory_data_size DMA Memory data size
  * @{
  */
#define DMA_MDATAALIGN_BYTE             0x00000000U  /*!< Memory data alignment: Byte     */
#define DMA_MDATAALIGN_HALFWORD         0x00000080U  /*!< Memory data alignment: HalfWord */
#define DMA_MDATAALIGN_WORD             0x00000100U  /*!< Memory data alignment: Word     */

/* Legacy aliases kept for source compatibility */
#define DMA_MemoryDataSize_Byte         DMA_MDATAALIGN_BYTE       /*!< legacy alias */
#define DMA_MemoryDataSize_HalfWord     DMA_MDATAALIGN_HALFWORD   /*!< legacy alias */
#define DMA_MemoryDataSize_Word         DMA_MDATAALIGN_WORD       /*!< legacy alias */
/**
  * @}
  */

/** @defgroup DMA_mode DMA mode
  * @{
  */
#define DMA_NORMAL                      0x00000000U  /*!< Normal mode                  */
#define DMA_CIRCULAR                    0x00000004U  /*!< Circular mode (CHCTL.CIRC)   */
/**
  * @}
  */

/** @defgroup DMA_Priority_level DMA Priority level
  * @{
  */
#define DMA_PRIORITY_LOW                0x00000000U  /*!< Priority level: Low       */
#define DMA_PRIORITY_MEDIUM             0x00000200U  /*!< Priority level: Medium    */
#define DMA_PRIORITY_HIGH               0x00000400U  /*!< Priority level: High      */
#define DMA_PRIORITY_VERY_HIGH          0x00000600U  /*!< Priority level: Very High */

/* Legacy aliases kept for source compatibility */
#define DMA_Priority_Low                DMA_PRIORITY_LOW          /*!< legacy alias */
#define DMA_Priority_Medium             DMA_PRIORITY_MEDIUM       /*!< legacy alias */
#define DMA_Priority_High               DMA_PRIORITY_HIGH         /*!< legacy alias */
#define DMA_Priority_VeryHigh           DMA_PRIORITY_VERY_HIGH    /*!< legacy alias */
/**
  * @}
  */

/** @defgroup DMA_Memory_to_memory DMA Memory to memory mode
  * @note  These names are device specific: the M2M mode is a
  *        dedicated CHCTL.M2M bit on this chip).
  * @{
  */
#define DMA_M2M_Enable                  0x00000001U  /*!< Memory-to-memory transfer enabled  */
#define DMA_M2M_Disable                 0x00000000U  /*!< Memory-to-memory transfer disabled */
/**
  * @}
  */

/** @defgroup DMA_interrupt_type_definitions DMA interrupt type definitions
  * @note  Values select the interrupt type of a controller (used together
  *        with HAL_DMA_ITConfig() / __HAL_DMA_ENABLE_IT()).
  * @{
  */
#define DMA_ERR_IT                      0x10000000U  /*!< Transfer error interrupt mask   */
#define DMA_FTF_IT                      0x20000000U  /*!< Full transfer interrupt mask    */
#define DMA_HTF_IT                      0x40000000U  /*!< Half transfer interrupt mask    */
#define DMA_WDG_IT                      0x80000000U  /*!< Watchdog interrupt mask         */
/**
  * @}
  */

/** @defgroup DMA_flag_definitions DMA flag definitions
  * @note  The encoding is fixed by the device: bits 31..28 select the flag
  *        type (ERR/FTF/HTF/WDG), bits 15..0 hold the channel bit. The WDG
  *        flag is a global (controller level) flag.
  * @{
  */
#define DMA_FLAG_ERR0                   0x10000001U
#define DMA_FLAG_ERR1                   0x10000002U
#define DMA_FLAG_ERR2                   0x10000004U
#define DMA_FLAG_ERR3                   0x10000008U
#define DMA_FLAG_ERR4                   0x10000010U
#define DMA_FLAG_ERR5                   0x10000020U
#define DMA_FLAG_ERR6                   0x10000040U
#define DMA_FLAG_ERR7                   0x10000080U
#define DMA_FLAG_ERR8                   0x10000100U
#define DMA_FLAG_ERR9                   0x10000200U
#define DMA_FLAG_ERR10                  0x10000400U
#define DMA_FLAG_ERR11                  0x10000800U
#define DMA_FLAG_ERR12                  0x10001000U
#define DMA_FLAG_ERR13                  0x10002000U
#define DMA_FLAG_ERR14                  0x10004000U
#define DMA_FLAG_ERR15                  0x10008000U

#define DMA_FLAG_FTF0                   0x20000001U
#define DMA_FLAG_FTF1                   0x20000002U
#define DMA_FLAG_FTF2                   0x20000004U
#define DMA_FLAG_FTF3                   0x20000008U
#define DMA_FLAG_FTF4                   0x20000010U
#define DMA_FLAG_FTF5                   0x20000020U
#define DMA_FLAG_FTF6                   0x20000040U
#define DMA_FLAG_FTF7                   0x20000080U
#define DMA_FLAG_FTF8                   0x20000100U
#define DMA_FLAG_FTF9                   0x20000200U
#define DMA_FLAG_FTF10                  0x20000400U
#define DMA_FLAG_FTF11                  0x20000800U
#define DMA_FLAG_FTF12                  0x20001000U
#define DMA_FLAG_FTF13                  0x20002000U
#define DMA_FLAG_FTF14                  0x20004000U
#define DMA_FLAG_FTF15                  0x20008000U

#define DMA_FLAG_HTF0                   0x40000001U
#define DMA_FLAG_HTF1                   0x40000002U
#define DMA_FLAG_HTF2                   0x40000004U
#define DMA_FLAG_HTF3                   0x40000008U
#define DMA_FLAG_HTF4                   0x40000010U
#define DMA_FLAG_HTF5                   0x40000020U
#define DMA_FLAG_HTF6                   0x40000040U
#define DMA_FLAG_HTF7                   0x40000080U
#define DMA_FLAG_HTF8                   0x40000100U
#define DMA_FLAG_HTF9                   0x40000200U
#define DMA_FLAG_HTF10                  0x40000400U
#define DMA_FLAG_HTF11                  0x40000800U
#define DMA_FLAG_HTF12                  0x40001000U
#define DMA_FLAG_HTF13                  0x40002000U
#define DMA_FLAG_HTF14                  0x40004000U
#define DMA_FLAG_HTF15                  0x40008000U

#define DMA_FLAG_WDG                    0x80000001U  /*!< Watchdog flag (global) */
/**
  * @}
  */

/** @defgroup DMA_interrupt_definitions DMA interrupt definitions
  * @note  Same encoding as the flags; used by HAL_DMA_GetITStatus() /
  *        HAL_DMA_ClearITPendingBit().
  * @{
  */
#define DMA_IT_ERR0                     0x10000001U
#define DMA_IT_ERR1                     0x10000002U
#define DMA_IT_ERR2                     0x10000004U
#define DMA_IT_ERR3                     0x10000008U
#define DMA_IT_ERR4                     0x10000010U
#define DMA_IT_ERR5                     0x10000020U
#define DMA_IT_ERR6                     0x10000040U
#define DMA_IT_ERR7                     0x10000080U
#define DMA_IT_ERR8                     0x10000100U
#define DMA_IT_ERR9                     0x10000200U
#define DMA_IT_ERR10                    0x10000400U
#define DMA_IT_ERR11                    0x10000800U
#define DMA_IT_ERR12                    0x10001000U
#define DMA_IT_ERR13                    0x10002000U
#define DMA_IT_ERR14                    0x10004000U
#define DMA_IT_ERR15                    0x10008000U

#define DMA_IT_FTF0                     0x20000001U
#define DMA_IT_FTF1                     0x20000002U
#define DMA_IT_FTF2                     0x20000004U
#define DMA_IT_FTF3                     0x20000008U
#define DMA_IT_FTF4                     0x20000010U
#define DMA_IT_FTF5                     0x20000020U
#define DMA_IT_FTF6                     0x20000040U
#define DMA_IT_FTF7                     0x20000080U
#define DMA_IT_FTF8                     0x20000100U
#define DMA_IT_FTF9                     0x20000200U
#define DMA_IT_FTF10                    0x20000400U
#define DMA_IT_FTF11                    0x20000800U
#define DMA_IT_FTF12                    0x20001000U
#define DMA_IT_FTF13                    0x20002000U
#define DMA_IT_FTF14                    0x20004000U
#define DMA_IT_FTF15                    0x20008000U

#define DMA_IT_HTF0                     0x40000001U
#define DMA_IT_HTF1                     0x40000002U
#define DMA_IT_HTF2                     0x40000004U
#define DMA_IT_HTF3                     0x40000008U
#define DMA_IT_HTF4                     0x40000010U
#define DMA_IT_HTF5                     0x40000020U
#define DMA_IT_HTF6                     0x40000040U
#define DMA_IT_HTF7                     0x40000080U
#define DMA_IT_HTF8                     0x40000100U
#define DMA_IT_HTF9                     0x40000200U
#define DMA_IT_HTF10                    0x40000400U
#define DMA_IT_HTF11                    0x40000800U
#define DMA_IT_HTF12                    0x40001000U
#define DMA_IT_HTF13                    0x40002000U
#define DMA_IT_HTF14                    0x40004000U
#define DMA_IT_HTF15                    0x40008000U

#define DMA_IT_WDG                      0x80000001U  /*!< Watchdog interrupt (global) */
/**
  * @}
  */

/**
  * @}
  */

/* Exported macro ------------------------------------------------------------*/

/** @defgroup DMA_Exported_Macros DMA Exported Macros
  * @{
  */

/**
 * @brief  Return the DMA controller (DMA0/DMA1) owning the given handle.
 * @note   Internal helper used by the exported macros below.
 * @param  __HANDLE__: DMA handle
 * @retval DMA0 or DMA1
 */
#define DMA_GET_DMAy(__HANDLE__) \
    (((uint32)((__HANDLE__)->Instance) < (uint32)DMA1_Channel0) ? DMA0 : DMA1)

/**
 * @brief  Enable the specified DMA channel.
 * @param  __HANDLE__: DMA handle
 * @retval None
 */
#define __HAL_DMA_ENABLE(__HANDLE__) \
    (DMA_GET_DMAy(__HANDLE__)->CHEN |= (uint32)(1UL << (__HANDLE__)->ChannelIndex))

/**
 * @brief  Disable the specified DMA channel.
 * @param  __HANDLE__: DMA handle
 * @retval None
 */
#define __HAL_DMA_DISABLE(__HANDLE__) \
    (DMA_GET_DMAy(__HANDLE__)->CHEN &= (uint32)(~(1UL << (__HANDLE__)->ChannelIndex)))

/**
 * @brief  Get the DMA channel pending flags (raw status).
 * @param  __HANDLE__: DMA handle
 * @param  __FLAG__: DMA_FLAG_ERRx / DMA_FLAG_FTFx / DMA_FLAG_HTFx / DMA_FLAG_WDG
 * @retval The state of FLAG (SET or RESET).
 */
#define __HAL_DMA_GET_FLAG(__HANDLE__, __FLAG__) \
    ((((__FLAG__) & DMA_MASK_ERR) == DMA_MASK_ERR) ? (DMA_GET_DMAy(__HANDLE__)->ERR_INT_RAW & (__FLAG__)) : \
     (((__FLAG__) & DMA_MASK_FTF) == DMA_MASK_FTF) ? (DMA_GET_DMAy(__HANDLE__)->FTF_INT_RAW & (__FLAG__)) : \
     (((__FLAG__) & DMA_MASK_HTF) == DMA_MASK_HTF) ? (DMA_GET_DMAy(__HANDLE__)->HTF_INT_RAW & (__FLAG__)) : \
     (DMA_GET_DMAy(__HANDLE__)->WDG_INT_RAW & (__FLAG__)))

/**
 * @brief  Clear the DMA channel pending flags (write 1 to the raw register).
 * @param  __HANDLE__: DMA handle
 * @param  __FLAG__: DMA_FLAG_ERRx / DMA_FLAG_FTFx / DMA_FLAG_HTFx / DMA_FLAG_WDG
 * @retval None
 */
#define __HAL_DMA_CLEAR_FLAG(__HANDLE__, __FLAG__) \
    ((((__FLAG__) & DMA_MASK_ERR) == DMA_MASK_ERR) ? (DMA_GET_DMAy(__HANDLE__)->ERR_INT_RAW = (__FLAG__)) : \
     (((__FLAG__) & DMA_MASK_FTF) == DMA_MASK_FTF) ? (DMA_GET_DMAy(__HANDLE__)->FTF_INT_RAW = (__FLAG__)) : \
     (((__FLAG__) & DMA_MASK_HTF) == DMA_MASK_HTF) ? (DMA_GET_DMAy(__HANDLE__)->HTF_INT_RAW = (__FLAG__)) : \
     (DMA_GET_DMAy(__HANDLE__)->WDG_INT_RAW = (__FLAG__)))

/**
 * @brief  Get the DMA channel interrupt status (masked status).
 * @param  __HANDLE__: DMA handle
 * @param  __IT__: DMA_IT_ERRx / DMA_IT_FTFx / DMA_IT_HTFx / DMA_IT_WDG
 * @retval The state of IT (SET or RESET).
 */
#define __HAL_DMA_GET_IT(__HANDLE__, __IT__) \
    ((((__IT__) & DMA_MASK_ERR) == DMA_MASK_ERR) ? (DMA_GET_DMAy(__HANDLE__)->ERR_INT_STATUS & (__IT__)) : \
     (((__IT__) & DMA_MASK_FTF) == DMA_MASK_FTF) ? (DMA_GET_DMAy(__HANDLE__)->FTF_INT_STATUS & (__IT__)) : \
     (((__IT__) & DMA_MASK_HTF) == DMA_MASK_HTF) ? (DMA_GET_DMAy(__HANDLE__)->HTF_INT_STATUS & (__IT__)) : \
     (DMA_GET_DMAy(__HANDLE__)->WDG_INT_STATUS & (__IT__)))

/**
 * @brief  Clear the DMA channel interrupt pending bit (write 1 to the raw
 *         register; the masked status register is read-only).
 * @param  __HANDLE__: DMA handle
 * @param  __IT__: DMA_IT_ERRx / DMA_IT_FTFx / DMA_IT_HTFx / DMA_IT_WDG
 * @retval None
 */
#define __HAL_DMA_CLEAR_IT(__HANDLE__, __IT__) \
    ((((__IT__) & DMA_MASK_ERR) == DMA_MASK_ERR) ? (DMA_GET_DMAy(__HANDLE__)->ERR_INT_RAW = (__IT__)) : \
     (((__IT__) & DMA_MASK_FTF) == DMA_MASK_FTF) ? (DMA_GET_DMAy(__HANDLE__)->FTF_INT_RAW = (__IT__)) : \
     (((__IT__) & DMA_MASK_HTF) == DMA_MASK_HTF) ? (DMA_GET_DMAy(__HANDLE__)->HTF_INT_RAW = (__IT__)) : \
     (DMA_GET_DMAy(__HANDLE__)->WDG_INT_RAW = (__IT__)))

/**
 * @brief  Get the full transfer flag of the handle channel.
 * @param  __HANDLE__: DMA handle
 * @retval The state of the full transfer flag (SET or RESET).
 */
#define __HAL_DMA_GET_TC_FLAG(__HANDLE__) \
    (DMA_GET_DMAy(__HANDLE__)->FTF_INT_RAW & (uint32)(1UL << (__HANDLE__)->ChannelIndex))

/**
 * @brief  Get the half transfer flag of the handle channel.
 * @param  __HANDLE__: DMA handle
 * @retval The state of the half transfer flag (SET or RESET).
 */
#define __HAL_DMA_GET_HT_FLAG(__HANDLE__) \
    (DMA_GET_DMAy(__HANDLE__)->HTF_INT_RAW & (uint32)(1UL << (__HANDLE__)->ChannelIndex))

/**
 * @brief  Get the transfer error flag of the handle channel.
 * @param  __HANDLE__: DMA handle
 * @retval The state of the transfer error flag (SET or RESET).
 */
#define __HAL_DMA_GET_TE_FLAG(__HANDLE__) \
    (DMA_GET_DMAy(__HANDLE__)->ERR_INT_RAW & (uint32)(1UL << (__HANDLE__)->ChannelIndex))

/**
 * @brief  Clear the full transfer flag of the handle channel.
 * @param  __HANDLE__: DMA handle
 * @retval None
 */
#define __HAL_DMA_CLEAR_TC_FLAG(__HANDLE__) \
    (DMA_GET_DMAy(__HANDLE__)->FTF_INT_RAW = (uint32)(1UL << (__HANDLE__)->ChannelIndex))

/**
 * @brief  Clear the half transfer flag of the handle channel.
 * @param  __HANDLE__: DMA handle
 * @retval None
 */
#define __HAL_DMA_CLEAR_HT_FLAG(__HANDLE__) \
    (DMA_GET_DMAy(__HANDLE__)->HTF_INT_RAW = (uint32)(1UL << (__HANDLE__)->ChannelIndex))

/**
 * @brief  Clear the transfer error flag of the handle channel.
 * @param  __HANDLE__: DMA handle
 * @retval None
 */
#define __HAL_DMA_CLEAR_TE_FLAG(__HANDLE__) \
    (DMA_GET_DMAy(__HANDLE__)->ERR_INT_RAW = (uint32)(1UL << (__HANDLE__)->ChannelIndex))

/**
 * @brief  Enable the specified DMA channel interrupts (clear the mask bit;
 *         a mask bit set to 1 disables the interrupt on this chip).
 * @param  __HANDLE__: DMA handle
 * @param  __INTERRUPT__: DMA_ERR_IT / DMA_FTF_IT / DMA_HTF_IT / DMA_WDG_IT
 * @retval None
 */
#define __HAL_DMA_ENABLE_IT(__HANDLE__, __INTERRUPT__) \
    (((__INTERRUPT__) == DMA_ERR_IT) ? (DMA_GET_DMAy(__HANDLE__)->ERR_INT_MASK &= (uint32)(~(1UL << (__HANDLE__)->ChannelIndex))) : \
     ((__INTERRUPT__) == DMA_HTF_IT) ? (DMA_GET_DMAy(__HANDLE__)->HTF_INT_MASK &= (uint32)(~(1UL << (__HANDLE__)->ChannelIndex))) : \
     ((__INTERRUPT__) == DMA_FTF_IT) ? (DMA_GET_DMAy(__HANDLE__)->FTF_INT_MASK &= (uint32)(~(1UL << (__HANDLE__)->ChannelIndex))) : \
     (DMA_GET_DMAy(__HANDLE__)->WDG_INT_MASK &= (uint32)(~DMA_WDG_INT_MASK_MASK)))

/**
 * @brief  Disable the specified DMA channel interrupts (set the mask bit).
 * @param  __HANDLE__: DMA handle
 * @param  __INTERRUPT__: DMA_ERR_IT / DMA_FTF_IT / DMA_HTF_IT / DMA_WDG_IT
 * @retval None
 */
#define __HAL_DMA_DISABLE_IT(__HANDLE__, __INTERRUPT__) \
    (((__INTERRUPT__) == DMA_ERR_IT) ? (DMA_GET_DMAy(__HANDLE__)->ERR_INT_MASK |= (uint32)(1UL << (__HANDLE__)->ChannelIndex)) : \
     ((__INTERRUPT__) == DMA_HTF_IT) ? (DMA_GET_DMAy(__HANDLE__)->HTF_INT_MASK |= (uint32)(1UL << (__HANDLE__)->ChannelIndex)) : \
     ((__INTERRUPT__) == DMA_FTF_IT) ? (DMA_GET_DMAy(__HANDLE__)->FTF_INT_MASK |= (uint32)(1UL << (__HANDLE__)->ChannelIndex)) : \
     (DMA_GET_DMAy(__HANDLE__)->WDG_INT_MASK |= DMA_WDG_INT_MASK_MASK))

/**
 * @brief  Check whether the specified DMA channel interrupt source is enabled.
 * @note   The mask registers are inverted on this chip: a mask bit set to 1
 *         disables the interrupt, so the enabled state is read as the
 *         complement of the mask bit.
 * @param  __HANDLE__: DMA handle
 * @param  __INTERRUPT__: DMA_ERR_IT / DMA_FTF_IT / DMA_HTF_IT / DMA_WDG_IT
 * @retval The state of the interrupt source (1 = enabled, 0 = masked).
 */
#define __HAL_DMA_GET_IT_SOURCE(__HANDLE__, __INTERRUPT__) \
    (((__INTERRUPT__) == DMA_ERR_IT) ? (((DMA_GET_DMAy(__HANDLE__)->ERR_INT_MASK & (uint32)(1UL << (__HANDLE__)->ChannelIndex)) == 0U) ? 1U : 0U) : \
     ((__INTERRUPT__) == DMA_HTF_IT) ? (((DMA_GET_DMAy(__HANDLE__)->HTF_INT_MASK & (uint32)(1UL << (__HANDLE__)->ChannelIndex)) == 0U) ? 1U : 0U) : \
     ((__INTERRUPT__) == DMA_FTF_IT) ? (((DMA_GET_DMAy(__HANDLE__)->FTF_INT_MASK & (uint32)(1UL << (__HANDLE__)->ChannelIndex)) == 0U) ? 1U : 0U) : \
     (((DMA_GET_DMAy(__HANDLE__)->WDG_INT_MASK & DMA_WDG_INT_MASK_MASK) == 0U) ? 1U : 0U))

/**
 * @brief  Writes the number of data units to be transferred on the DMA channel.
 * @param  __HANDLE__: DMA handle
 * @param  __COUNTER__: number of data units to be transferred (from 0 to 65535)
 * @retval None
 */
#define __HAL_DMA_SET_COUNTER(__HANDLE__, __COUNTER__) \
    ((__HANDLE__)->Instance->CHCNT = (uint16)(__COUNTER__))

/**
 * @brief  Returns the number of remaining data units in the current transfer.
 * @param  __HANDLE__: DMA handle
 * @retval The number of remaining data units.
 */
#define __HAL_DMA_GET_COUNTER(__HANDLE__) ((__HANDLE__)->Instance->CHCNT)

/**
 * @brief  Reset the DMA handle state.
 * @param  __HANDLE__: DMA handle
 * @retval None
 */
#define __HAL_DMA_RESET_HANDLE_STATE(__HANDLE__) ((__HANDLE__)->State = HAL_DMA_STATE_RESET)

/**
  * @}
  */

/* Include DMA HAL Extension module */

/* Exported functions --------------------------------------------------------*/

/** @defgroup DMA_Exported_Functions DMA Exported Functions
  * @{
  */

/** @defgroup DMA_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Initialize the DMA channel according to the specified parameters in (NON-BLOCKING)
 *         the hdma->Init structure (direction, increment, data sizes,
 *         priority, M2M, mode, addresses and buffer size) and initialize the
 *         low level hardware.
 * @note   Programs the channel with the conventional register write sequence. The
 *         channel index is computed and stored in the handle, the pending
 *         interrupt raw flags of the channel are cleared and the channel is
 *         left disabled: it is enabled by HAL_DMA_Start() / HAL_DMA_Start_IT().
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_DMA_Init(DMA_HandleTypeDef *hdma);

/**
 * @brief  De-initialize the DMA channel registers to their default reset (NON-BLOCKING)
 *         values and de-initialize the low level hardware.
 * @note   The channel is disabled, its interrupts
 *         are masked, the pending raw flags are cleared and the four channel
 *         registers (CHCTL/CHCNT/CHPADDR/CHMADDR) are reset to zero. The WDG
 *         interrupt of the controller is masked and cleared as well.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY.
 */
HAL_StatusTypeDef HAL_DMA_DeInit(DMA_HandleTypeDef *hdma);

/**
 * @brief  Initialize the DMA MSP (peripheral clock enable, reset release).
 * @note   This function should not be modified: when the MSP initialization
 *         is needed, HAL_DMA_MspInit() should be implemented in the user file
 *         (e.g. call __HAL_SMU_DMA0_CLK_ENABLE() / __HAL_SMU_DMA0_RELEASE_RESET()
 *         for DMA0, or the DMA1 counterparts for DMA1).
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @retval None
 */
void HAL_DMA_MspInit(DMA_HandleTypeDef *hdma);

/**
 * @brief  De-initialize the DMA MSP (peripheral clock disable, reset assert).
 * @note   This function should not be modified: when the MSP de-initialization
 *         is needed, HAL_DMA_MspDeInit() should be implemented in the user file
 *         (e.g. call __HAL_SMU_DMA0_FORCE_RESET() / __HAL_SMU_DMA0_CLK_DISABLE()
 *         for DMA0, or the DMA1 counterparts for DMA1).
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @retval None
 */
void HAL_DMA_MspDeInit(DMA_HandleTypeDef *hdma);
/**
  * @}
  */

/** @defgroup DMA_Exported_Functions_Group2 IO operation functions
  * @{
  */

/**
 * @brief  Start the DMA transfer. (NON-BLOCKING)
 * @param  hdma:       pointer to a DMA_HandleTypeDef structure that contains
 *         the configuration information for the specified DMA channel.
 * @param  SrcAddress: the source memory buffer address.
 * @param  DstAddress: the destination memory buffer address.
 * @param  DataLength: the length of data to be transferred from source to
 *         destination.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY.
 */
HAL_StatusTypeDef HAL_DMA_Start(DMA_HandleTypeDef *hdma, uint32 SrcAddress, uint32 DstAddress,
                                uint32 DataLength);

/**
 * @brief  Start the DMA transfer with interrupt enabled. (NON-BLOCKING / IT)
 * @note   The full transfer (FTF) and the transfer error (ERR) interrupts are
 *         always unmasked; the half transfer (HTF) interrupt is unmasked only
 *         when the XferHalfCpltCallback is registered. The WDG interrupt is
 *         not touched (it is a global interrupt configured with
 *         HAL_DMA_ConfigWatchDog()).
 * @note   The transfer length is validated at run time against the counter
 *         domain of the interface constants (1..0xFFFF units), so a build with
 *         the assertions disabled rejects an unusable length instead of
 *         programming a truncated one.
 * @param  hdma:       pointer to a DMA_HandleTypeDef structure that contains
 *         the configuration information for the specified DMA channel.
 * @param  SrcAddress: the source memory buffer address.
 * @param  DstAddress: the destination memory buffer address.
 * @param  DataLength: the length of data to be transferred from source to
 *         destination.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (handle, instance or length
 *         invalid) / HAL_BUSY.
 */
HAL_StatusTypeDef HAL_DMA_Start_IT(DMA_HandleTypeDef *hdma, uint32 SrcAddress, uint32 DstAddress,
                                   uint32 DataLength);

/**
 * @brief  Abort the DMA transfer. (NON-BLOCKING)
 * @note   The channel is disabled immediately (no wait loop: the channel
 *         enable bit stops the transfer right away on this chip), all the
 *         channel interrupts are masked and the pending raw flags are cleared.
 * @note   The stop is confirmed by reading the enable bit back: a channel that
 *         is still active keeps its state and reports HAL_ERROR, so the caller
 *         is never told to reuse a buffer the hardware is still writing.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (handle or instance invalid,
 *         no transfer ongoing, or the stop could not be confirmed) / HAL_BUSY
 *         (the handle lock is held by another context).
 */
HAL_StatusTypeDef HAL_DMA_Abort(DMA_HandleTypeDef *hdma);

/**
 * @brief  Abort the DMA transfer in interrupt mode. (NON-BLOCKING / IT)
 * @note   The channel is disabled and the abort completion is reported by the
 *         XferAbortCallback, invoked from HAL_DMA_IRQHandler() when the full
 *         transfer interrupt of the disabled channel is serviced. If the
 *         channel stops without any pending full transfer flag, the user
 *         should call HAL_DMA_Abort() instead (blocking completion).
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (handle or instance invalid or
 *         no transfer ongoing) / HAL_BUSY (the handle lock is held by another
 *         context).
 */
HAL_StatusTypeDef HAL_DMA_Abort_IT(DMA_HandleTypeDef *hdma);

/**
 * @brief  Poll for transfer complete. (BLOCKING)
 * @note   The polling mode is not supported in circular mode.
 * @note   The wait does not hold the handle lock (architecture rule section
 *         12): the lock is taken for a short verification of this transfer at
 *         each iteration and released before the yield hook, so another user
 *         of this channel and a task of the same priority can run while the
 *         transfer completes. A context that finalizes the transfer during the
 *         wait ends this poll with its final state.
 * @param  hdma:          pointer to a DMA_HandleTypeDef structure that contains
 *         the configuration information for the specified DMA channel.
 * @param  CompleteLevel: specifies the DMA level complete (HAL_DMA_FULL_TRANSFER /
 *         HAL_DMA_HALF_TRANSFER).
 * @param  Timeout:       timeout duration.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (handle, instance or level
 *         invalid, no transfer ongoing, transfer error, or circular mode) /
 *         HAL_TIMEOUT (the wait expired, the transfer itself is not stopped) /
 *         HAL_BUSY (the handle lock could not be acquired).
 */
HAL_StatusTypeDef HAL_DMA_PollForTransfer(DMA_HandleTypeDef *hdma,
                                          HAL_DMA_LevelCompleteTypeDef CompleteLevel,
                                          uint32 Timeout);

/**
 * @brief  Handle the DMA interrupt request of one channel.
 * @note   One IRQ line is shared by the 16 channels of a controller: the user
 *         DMA0_IRQ_Handler() / DMA1_IRQ_Handler() (PLIC entries, see
 *         as32x601_plic.h) must call HAL_DMA_IRQHandler() for every active
 *         channel handle of the controller. The masked status registers are
 *         polled, so only the unmasked (enabled) interrupts are serviced.
 *         The WDG interrupt is global and not channel related: it must be
 *         polled by the user with HAL_DMA_GetITStatus(DMAy, DMA_IT_WDG) and
 *         cleared with HAL_DMA_ClearITPendingBit(DMAy, DMA_IT_WDG).
 * @note   Before an error, abort or half transfer callback is invoked, the
 *         data cache of a peripheral-to-memory transfer is finalized (flush
 *         and invalidate), so that the callback reads the buffer the hardware
 *         has just written and the full transfer path does the same.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @retval None
 */
void HAL_DMA_IRQHandler(DMA_HandleTypeDef *hdma);
/**
  * @}
  */

/** @defgroup DMA_Exported_Functions_Group3 Peripheral Control and Flag functions
  * @{
  */

/**
 * @brief  Enable or disable the specified DMA channel interrupt sources. (NON-BLOCKING)
 * @note   The interrupt mask registers are
 *         inverted on this chip: a mask bit set to 1 disables the interrupt.
 * @param  hdma:     pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @param  DMA_IT:   specifies the DMA interrupt source to be enabled or
 *         disabled (DMA_ERR_IT / DMA_FTF_IT / DMA_HTF_IT / DMA_WDG_IT).
 * @param  NewState: new state of the DMA interrupt (ENABLE or DISABLE).
 * @retval None
 */
void HAL_DMA_ITConfig(DMA_HandleTypeDef *hdma, uint32 DMA_IT, FunctionalState NewState);

/**
 * @brief  Fill each DMA_InitStruct member with its default value. (NON-BLOCKING)
 * @param  DMA_InitStruct: pointer to a DMA_InitTypeDef structure which will
 *         be initialized.
 * @retval None
 */
void HAL_DMA_StructInit(DMA_InitTypeDef *DMA_InitStruct);

/**
 * @brief  Set the number of data units in the current DMA channel transfer. (NON-BLOCKING)
 * @note   The call is silently refused (the interface returns void, so the
 *         refusal is not observable by the caller) when the handle or its
 *         instance is not valid. The counter domain needs no check: the
 *         parameter type already bounds it to 0..0xFFFF data units. A zero
 *         value is accepted: it is the empty transfer. The counter may be
 *         updated while a transfer is ongoing, so no state gate is applied.
 * @param  hdma:       pointer to a DMA_HandleTypeDef structure that contains
 *         the configuration information for the specified DMA channel.
 * @param  DataNumber: the number of data units in the current DMA channel
 *         transfer.
 * @retval None
 */
void HAL_DMA_SetCurrDataCounter(DMA_HandleTypeDef *hdma, uint16 DataNumber);

/**
 * @brief  Return the number of remaining data units in the current DMA channel (NON-BLOCKING)
 *         transfer.
 * @note   The query is bound to a valid instance: a handle that is not bound
 *         to an approved channel reports zero.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @retval The number of remaining data units in the current transfer.
 */
uint16 HAL_DMA_GetCurrDataCounter(DMA_HandleTypeDef *hdma);

/**
 * @brief  Checks whether the specified DMA flag is set or not (raw status). (NON-BLOCKING)
 * @param  DMAy:     where y can be 0 or 1 to select the DMA controller.
 * @param  DMA_FLAG: specifies the flag to check (DMA_FLAG_ERRx / DMA_FLAG_FTFx /
 *         DMA_FLAG_HTFx / DMA_FLAG_WDG).
 * @retval FlagStatus: SET or RESET.
 */
FlagStatus HAL_DMA_GetFlagStatus(DMA_TypeDef *DMAy, uint32 DMA_FLAG);

/**
 * @brief  Clear the specified DMA flag (write 1 to the raw register). (NON-BLOCKING)
 * @param  DMAy:     where y can be 0 or 1 to select the DMA controller.
 * @param  DMA_FLAG: specifies the flag to clear (DMA_FLAG_ERRx / DMA_FLAG_FTFx /
 *         DMA_FLAG_HTFx / DMA_FLAG_WDG).
 * @retval None
 */
void HAL_DMA_ClearFlag(DMA_TypeDef *DMAy, uint32 DMA_FLAG);

/**
 * @brief  Checks whether the specified DMA interrupt is set or not (masked (NON-BLOCKING)
 *         status).
 * @param  DMAy:    where y can be 0 or 1 to select the DMA controller.
 * @param  DMAy_IT: specifies the interrupt to check (DMA_IT_ERRx / DMA_IT_FTFx /
 *         DMA_IT_HTFx / DMA_IT_WDG).
 * @retval ITStatus: SET or RESET.
 */
ITStatus HAL_DMA_GetITStatus(DMA_TypeDef *DMAy, uint32 DMAy_IT);

/**
 * @brief  Clear the specified DMA interrupt pending bit (write 1 to the raw (NON-BLOCKING)
 *         register; the masked status register is read-only).
 * @param  DMAy:    where y can be 0 or 1 to select the DMA controller.
 * @param  DMAy_IT: specifies the interrupt to clear (DMA_IT_ERRx / DMA_IT_FTFx /
 *         DMA_IT_HTFx / DMA_IT_WDG).
 * @retval None
 */
void HAL_DMA_ClearITPendingBit(DMA_TypeDef *DMAy, uint32 DMAy_IT);
/**
  * @}
  */

/** @defgroup DMA_Exported_Functions_Group4 Callback registration functions
  * @{
  */

/**
 * @brief  Clean all the callbacks of the DMA handle. (NON-BLOCKING)
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @retval HAL_StatusTypeDef: HAL_OK.
 */
HAL_StatusTypeDef HAL_DMA_CleanCallbacks(DMA_HandleTypeDef *hdma);

/**
 * @brief  Register the callbacks of the DMA handle. (NON-BLOCKING)
 * @param  hdma:       pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @param  CallbackID: user callback identifier (HAL_DMA_XFER_CPLT_CB_ID /
 *         HAL_DMA_XFER_HALFCPLT_CB_ID / HAL_DMA_XFER_ERROR_CB_ID /
 *         HAL_DMA_XFER_ABORT_CB_ID / HAL_DMA_XFER_ALL_CB_ID).
 * @param  pCallback:  pointer to the private callback function which takes a
 *         DMA_HandleTypeDef structure as parameter.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_DMA_RegisterCallback(DMA_HandleTypeDef *hdma,
                                           HAL_DMA_CallbackIDTypeDef CallbackID,

                                           void (*pCallback)(DMA_HandleTypeDef *_hdma));

/**
 * @brief  Un-register the callbacks of the DMA handle. (NON-BLOCKING)
 * @param  hdma:       pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @param  CallbackID: user callback identifier (HAL_DMA_XFER_CPLT_CB_ID /
 *         HAL_DMA_XFER_HALFCPLT_CB_ID / HAL_DMA_XFER_ERROR_CB_ID /
 *         HAL_DMA_XFER_ABORT_CB_ID / HAL_DMA_XFER_ALL_CB_ID).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_DMA_UnRegisterCallback(DMA_HandleTypeDef *hdma,
                                             HAL_DMA_CallbackIDTypeDef CallbackID);
/**
  * @}
  */

/** @defgroup DMA_Exported_Functions_Group5 Peripheral State and Errors functions
  * @{
  */

/**
 * @brief  Return the DMA handle state. (NON-BLOCKING)
 * @note   The query is bound to a valid instance: a handle that is not bound
 *         to an approved channel reports HAL_DMA_STATE_RESET, the same answer
 *         as an uninitialized handle.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @retval HAL_DMA_StateTypeDef: HAL_DMA_STATE_RESET / READY / BUSY / TIMEOUT
 *         / ERROR / ABORT.
 */
HAL_DMA_StateTypeDef HAL_DMA_GetState(DMA_HandleTypeDef *hdma);

/**
 * @brief  Return the DMA error code. (NON-BLOCKING)
 * @note   The query is bound to a valid instance: a handle that is not bound
 *         to an approved channel reports no error, the same answer as an
 *         uninitialized handle.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @retval DMA Error Code: HAL_DMA_ERROR_NONE / TE / TIMEOUT / PARAM / NO_XFER
 *         / NOT_SUPPORTED.
 */
uint32 HAL_DMA_GetError(DMA_HandleTypeDef *hdma);
/**
  * @}
  */
/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @addtogroup DMA_Exported_Constants DMA Exported Constants
  * @{
  */

/** @defgroup DMA_Peripheral_Interface_Number DMA Peripheral Interface numbers
  * @note  Interface numbers are controller dependent: the first group
  *        (TIM0/ADC0/ADC1/SPI0..2/USART0..3/TIM2..4) is wired to DMA0, the
  *        second group (TIM1/SPI3..5/USART4..7/TIM5..7) is wired to DMA1.
  *        The names and the values are fixed by the device interface map.
  * @{
  */
/* DMA0 peripheral interfaces */
#define TIM0_IF                             0x00000000U
#define ADC0_IF                             0x00000001U
#define ADC1_IF                             0x00000002U
#define SPI0_IF                             0x00000003U
#define SPI1_IF                             0x00000004U
#define SPI2_IF                             0x00000005U
#define USART0_IF                           0x00000008U
#define USART1_IF                           0x00000009U
#define USART2_IF                           0x0000000AU
#define USART3_IF                           0x0000000BU
#define TIM2_IF                             0x0000000CU
#define TIM3_IF                             0x0000000DU
#define TIM4_IF                             0x0000000EU

/* DMA1 peripheral interfaces */
#define TIM1_IF                             0x00000000U
#define SPI3_IF                             0x00000002U
#define SPI4_IF                             0x00000003U
#define SPI5_IF                             0x00000004U
#define USART4_IF                           0x00000007U
#define USART5_IF                           0x00000008U
#define USART6_IF                           0x00000009U
#define USART7_IF                           0x0000000AU
#define TIM5_IF                             0x0000000BU
#define TIM6_IF                             0x0000000CU
#define TIM7_IF                             0x0000000DU
/**
  * @}
  */

/** @defgroup DMA_Watchdog_Counter DMA watchdog counter
  * @note  The watchdog counter parameter check is prefixed with IS_DMA_ so
  *        that it does not collide with the Window Watchdog (WWDG) module
  *        macro of the same name (IS_WWDG_COUNTER in as32x601_hal_wwdg.h).
  * @{
  */
#define IS_DMA_WDG_COUNTER(COUNTER)            (((COUNTER) >= 0x0000U) && ((COUNTER) <= 0xFFFFU))
/**
  * @}
  */

/** @defgroup DMA_Request_Mapping DMA request mapping register layout
  * @note  The PTCH0 / PTCH1 request mapping registers hold one four bit field
  *        per channel: channels 0..7 are mapped in PTCH0, channels 8..15 in
  *        PTCH1.
  * @{
  */
#define DMA_PTCH_CHANNELS                     8U
#define DMA_PTCH_FIELD_SHIFT                  4U
#define DMA_PTCH_FIELD_MASK                   0x0FU
/**
  * @}
  */

/** @defgroup DMA_Request_Table DMA request table of each controller
  * @note  The interface numbers of the two controllers overlap (0x00 names
  *        TIM0 on DMA0 and TIM1 on DMA1, 0x03 names SPI0 on DMA0 and SPI4 on
  *        DMA1, ...), so a request number is only meaningful together with the
  *        controller that owns the channel. These macros check a number
  *        against the connection table of one controller; the numbering
  *        without a controller is covered by IS_PeriphInterface_Number().
  * @{
  */
#define IS_DMA0_PERIPH_IF(IF_Number)  (((IF_Number) == TIM0_IF)   || \
                                       ((IF_Number) == ADC0_IF)   || \
                                       ((IF_Number) == ADC1_IF)   || \
                                       ((IF_Number) == SPI0_IF)   || \
                                       ((IF_Number) == SPI1_IF)   || \
                                       ((IF_Number) == SPI2_IF)   || \
                                       ((IF_Number) == USART0_IF) || \
                                       ((IF_Number) == USART1_IF) || \
                                       ((IF_Number) == USART2_IF) || \
                                       ((IF_Number) == USART3_IF) || \
                                       ((IF_Number) == TIM2_IF)   || \
                                       ((IF_Number) == TIM3_IF)   || \
                                       ((IF_Number) == TIM4_IF))

#define IS_DMA1_PERIPH_IF(IF_Number)  (((IF_Number) == TIM1_IF)   || \
                                       ((IF_Number) == SPI3_IF)   || \
                                       ((IF_Number) == SPI4_IF)   || \
                                       ((IF_Number) == SPI5_IF)   || \
                                       ((IF_Number) == USART4_IF) || \
                                       ((IF_Number) == USART5_IF) || \
                                       ((IF_Number) == USART6_IF) || \
                                       ((IF_Number) == USART7_IF) || \
                                       ((IF_Number) == TIM5_IF)   || \
                                       ((IF_Number) == TIM6_IF)   || \
                                       ((IF_Number) == TIM7_IF))
/**
  * @}
  */

/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/

/** @addtogroup DMA_Exported_Functions DMA Exported Functions
  * @{
  */

/** @addtogroup DMA_Exported_Functions_Group1 Extended features functions
  * @{
  */

/**
 * @brief  Configure the DMA watchdog of a controller. (NON-BLOCKING)
 * @note   The watchdog is a controller level
 *         feature: it generates the global WDG interrupt (DMA_IT_WDG) when
 *         the configured counter elapses without any transfer progress. The
 *         WDG interrupt enable is handled separately by HAL_DMA_ITConfig()
 *         or __HAL_DMA_ENABLE_IT() with DMA_WDG_IT, and the WDG flag is
 *         polled with HAL_DMA_GetITStatus(DMAy, DMA_IT_WDG).
 * @note   The threshold is taken over only while the watchdog is disabled
 *         (the implementation clears WDEN, writes WDCNT and restores WDEN), so
 *         that a threshold update cannot produce a spurious global timeout.
 *         The call is silently refused (the interface returns void, so the
 *         refusal is not observable by the caller) when the controller is
 *         invalid or the state is invalid; the counter needs no check, its
 *         parameter type already bounds it to the 0..0xFFFF counter domain.
 * @param  DMAy:     where y can be 0 or 1 to select the DMA controller.
 * @param  Counter:  specifies the watchdog counter value (0x0000..0xFFFF).
 * @param  NewState: new state of the DMA watchdog (ENABLE or DISABLE).
 * @retval None
 */
void HAL_DMA_ConfigWatchDog(DMA_TypeDef *DMAy, uint16 Counter, FunctionalState NewState);

/**
 * @brief  Enable or disable the dual-core lock step of a controller. (NON-BLOCKING)
 * @note   The dual-core lock step duplicates
 *         the DMA controller (DEN bit of the CCR register); the ready and
 *         error statuses are reported by the DRDY and DERR bits.
 * @param  DMAy:     where y can be 0 or 1 to select the DMA controller.
 * @param  NewState: new state of the dual-core lock step (ENABLE or DISABLE).
 * @retval None
 */
void HAL_DMA_DualCoreCmd(DMA_TypeDef *DMAy, FunctionalState NewState);

/**
 * @brief  Configure the peripheral interface number of a DMA channel. (NON-BLOCKING)
 * @note   Channels 0..7 are mapped in the PTCH0
 *         register (4 bits per channel), channels 8..15 in the PTCH1
 *         register. The interface numbers are controller dependent: the
 *         first group is wired to DMA0, the second group to DMA1.
 * @note   The call is silently refused (the interface returns void, so the
 *         refusal is not observable by the caller) when the handle or its
 *         instance is invalid, when the channel is busy or not initialized,
 *         when the request number is not one of the interface constants, or
 *         when the number names a peripheral of the other controller: the
 *         request numbers of DMA0 and DMA1 overlap, so the value is checked
 *         against the connection table of the controller that owns the
 *         channel.
 * @param  hdma:      pointer to a DMA_HandleTypeDef structure that contains
 *         the configuration information for the specified DMA channel.
 * @param  IF_Number: DMA channel peripheral interface number (TIM0_IF /
 *         ADC0_IF / ... / TIM7_IF, see the DMA interface groups).
 * @retval None
 */
void HAL_DMA_ConfigPeriphIF(DMA_HandleTypeDef *hdma, uint32 IF_Number);
/**
  * @}
  */

/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/

/** @addtogroup DMA_Private_Macros DMA Private Macros
  * @{
  */
#define IS_PeriphInterface_Number(IF_Number)  (((IF_Number) == ADC0_IF) || \
                                               ((IF_Number) == ADC1_IF) || \
                                               ((IF_Number) == SPI0_IF) || \
                                               ((IF_Number) == SPI1_IF) || \
                                               ((IF_Number) == SPI2_IF) || \
                                               ((IF_Number) == USART0_IF) || \
                                               ((IF_Number) == USART1_IF) || \
                                               ((IF_Number) == USART2_IF) || \
                                               ((IF_Number) == USART3_IF) || \
                                               ((IF_Number) == TIM2_IF) || \
                                               ((IF_Number) == TIM3_IF) || \
                                               ((IF_Number) == TIM4_IF) || \
                                               ((IF_Number) == TIM1_IF) || \
                                               ((IF_Number) == SPI3_IF) || \
                                               ((IF_Number) == SPI4_IF) || \
                                               ((IF_Number) == SPI5_IF) || \
                                               ((IF_Number) == USART4_IF) || \
                                               ((IF_Number) == USART5_IF) || \
                                               ((IF_Number) == USART6_IF) || \
                                               ((IF_Number) == USART7_IF) || \
                                               ((IF_Number) == TIM5_IF) || \
                                               ((IF_Number) == TIM6_IF) || \
                                               ((IF_Number) == TIM7_IF))
/**
  * @}
  */

/* Private functions ---------------------------------------------------------*/

/** @addtogroup DMA_Private_Functions DMA Private Functions
  * @{
  */
/**
  * @}
  */

/* Private constants ---------------------------------------------------------*/

/** @defgroup DMA_Private_Constants DMA Private Constants
  * @{
  */
/* Register helper masks of this device, defined here because the device level
    header carries the bit fields only. */
#define DMA_CHCTL_CLEAR_Mask            0xFFFFF800U  /*!< Clears M2M/DIR/CIRC/PINC/MINC/PSIZE/MSIZE/PRIO bits */
#define DMA_CHCTL_CIRC                  DMA_CH0CTL_CIRC           /*!< Circular bit (same position on every channel) */
#define DMA_FLAG_CHANNEL_MASK           0x0000FFFFU  /*!< Channel bit field of a flag / interrupt encoding */
#define DMA_MASK_ERR                    0x10000000U  /*!< Error flag type mask     */
#define DMA_MASK_FTF                    0x20000000U  /*!< Full transfer type mask  */
#define DMA_MASK_HTF                    0x40000000U  /*!< Half transfer type mask  */
#define DMA_MASK_WDG                    0x80000000U  /*!< Watchdog type mask       */
/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/

/** @defgroup DMA_Private_Macros DMA Private Macros
  * @{
  */

#define IS_DMA_ALL_INSTANCE(INSTANCE)     (((INSTANCE) == DMA0_Channel0)  || \
                                           ((INSTANCE) == DMA0_Channel1)  || \
                                           ((INSTANCE) == DMA0_Channel2)  || \
                                           ((INSTANCE) == DMA0_Channel3)  || \
                                           ((INSTANCE) == DMA0_Channel4)  || \
                                           ((INSTANCE) == DMA0_Channel5)  || \
                                           ((INSTANCE) == DMA0_Channel6)  || \
                                           ((INSTANCE) == DMA0_Channel7)  || \
                                           ((INSTANCE) == DMA0_Channel8)  || \
                                           ((INSTANCE) == DMA0_Channel9)  || \
                                           ((INSTANCE) == DMA0_Channel10) || \
                                           ((INSTANCE) == DMA0_Channel11) || \
                                           ((INSTANCE) == DMA0_Channel12) || \
                                           ((INSTANCE) == DMA0_Channel13) || \
                                           ((INSTANCE) == DMA0_Channel14) || \
                                           ((INSTANCE) == DMA0_Channel15) || \
                                           ((INSTANCE) == DMA1_Channel0)  || \
                                           ((INSTANCE) == DMA1_Channel1)  || \
                                           ((INSTANCE) == DMA1_Channel2)  || \
                                           ((INSTANCE) == DMA1_Channel3)  || \
                                           ((INSTANCE) == DMA1_Channel4)  || \
                                           ((INSTANCE) == DMA1_Channel5)  || \
                                           ((INSTANCE) == DMA1_Channel6)  || \
                                           ((INSTANCE) == DMA1_Channel7)  || \
                                           ((INSTANCE) == DMA1_Channel8)  || \
                                           ((INSTANCE) == DMA1_Channel9)  || \
                                           ((INSTANCE) == DMA1_Channel10) || \
                                           ((INSTANCE) == DMA1_Channel11) || \
                                           ((INSTANCE) == DMA1_Channel12) || \
                                           ((INSTANCE) == DMA1_Channel13) || \
                                           ((INSTANCE) == DMA1_Channel14) || \
                                           ((INSTANCE) == DMA1_Channel15))

/* Legacy alias kept for source compatibility */
#define IS_DMA_ALL_PERIPH                IS_DMA_ALL_INSTANCE

#define IS_DMA_TypeDef(DMA)               (((DMA) == DMA0) || ((DMA) == DMA1))

#define IS_DMA_DIRECTION(DIRECTION)       (((DIRECTION) == DMA_PERIPH_TO_MEMORY) || \
                                           ((DIRECTION) == DMA_MEMORY_TO_PERIPH))
/* Legacy alias kept for source compatibility */
#define IS_DMA_DIR                        IS_DMA_DIRECTION

#define IS_DMA_BUFFER_SIZE(SIZE)          (((SIZE) >= 0x00000001U) && ((SIZE) < 0x00010000U))

#define IS_DMA_PERIPHERAL_INC_STATE(STATE) (((STATE) == DMA_PINC_ENABLE) || \
                                            ((STATE) == DMA_PINC_DISABLE))

#define IS_DMA_MEMORY_INC_STATE(STATE)    (((STATE) == DMA_MINC_ENABLE) || \
                                           ((STATE) == DMA_MINC_DISABLE))

#define IS_DMA_PERIPHERAL_DATA_SIZE(SIZE) (((SIZE) == DMA_PDATAALIGN_BYTE)     || \
                                           ((SIZE) == DMA_PDATAALIGN_HALFWORD) || \
                                           ((SIZE) == DMA_PDATAALIGN_WORD))

#define IS_DMA_MEMORY_DATA_SIZE(SIZE)     (((SIZE) == DMA_MDATAALIGN_BYTE)     || \
                                           ((SIZE) == DMA_MDATAALIGN_HALFWORD) || \
                                           ((SIZE) == DMA_MDATAALIGN_WORD))

#define IS_DMA_MODE(MODE)                 (((MODE) == DMA_NORMAL) || \
                                           ((MODE) == DMA_CIRCULAR))

#define IS_DMA_PRIORITY(PRIORITY)         (((PRIORITY) == DMA_PRIORITY_LOW)     || \
                                           ((PRIORITY) == DMA_PRIORITY_MEDIUM)  || \
                                           ((PRIORITY) == DMA_PRIORITY_HIGH)    || \
                                           ((PRIORITY) == DMA_PRIORITY_VERY_HIGH))

/* Device specific name (no generic counterpart) */
#define IS_DMA_M2M_STATE(STATE)           (((STATE) == DMA_M2M_Enable) || \
                                           ((STATE) == DMA_M2M_Disable))

#define IS_DMA_CONFIG_IT(IT)              (((IT) == DMA_ERR_IT) || ((IT) == DMA_FTF_IT) || \
                                           ((IT) == DMA_HTF_IT) || ((IT) == DMA_WDG_IT))

#define IS_DMA_CLEAR_FLAG(FLAG)           (((((FLAG) & 0xEFFF0000U) == 0x00000000U) || \
                                            (((FLAG) & 0xDFFF0000U) == 0x00000000U) || \
                                            (((FLAG) & 0xBFFF0000U) == 0x00000000U) || \
                                            (((FLAG) & 0x7FFF0000U) == 0x00000000U)) && \
                                           ((FLAG) != 0x00000000U))

#define IS_DMA_FLAG(FLAG)                 (((FLAG) == DMA_FLAG_ERR0)  || ((FLAG) == DMA_FLAG_ERR1)  || \
                                           ((FLAG) == DMA_FLAG_ERR2)  || ((FLAG) == DMA_FLAG_ERR3)  || \
                                           ((FLAG) == DMA_FLAG_ERR4)  || ((FLAG) == DMA_FLAG_ERR5)  || \
                                           ((FLAG) == DMA_FLAG_ERR6)  || ((FLAG) == DMA_FLAG_ERR7)  || \
                                           ((FLAG) == DMA_FLAG_ERR8)  || ((FLAG) == DMA_FLAG_ERR9)  || \
                                           ((FLAG) == DMA_FLAG_ERR10) || ((FLAG) == DMA_FLAG_ERR11) || \
                                           ((FLAG) == DMA_FLAG_ERR12) || ((FLAG) == DMA_FLAG_ERR13) || \
                                           ((FLAG) == DMA_FLAG_ERR14) || ((FLAG) == DMA_FLAG_ERR15) || \
                                           ((FLAG) == DMA_FLAG_FTF0)  || ((FLAG) == DMA_FLAG_FTF1)  || \
                                           ((FLAG) == DMA_FLAG_FTF2)  || ((FLAG) == DMA_FLAG_FTF3)  || \
                                           ((FLAG) == DMA_FLAG_FTF4)  || ((FLAG) == DMA_FLAG_FTF5)  || \
                                           ((FLAG) == DMA_FLAG_FTF6)  || ((FLAG) == DMA_FLAG_FTF7)  || \
                                           ((FLAG) == DMA_FLAG_FTF8)  || ((FLAG) == DMA_FLAG_FTF9)  || \
                                           ((FLAG) == DMA_FLAG_FTF10) || ((FLAG) == DMA_FLAG_FTF11) || \
                                           ((FLAG) == DMA_FLAG_FTF12) || ((FLAG) == DMA_FLAG_FTF13) || \
                                           ((FLAG) == DMA_FLAG_FTF14) || ((FLAG) == DMA_FLAG_FTF15) || \
                                           ((FLAG) == DMA_FLAG_HTF0)  || ((FLAG) == DMA_FLAG_HTF1)  || \
                                           ((FLAG) == DMA_FLAG_HTF2)  || ((FLAG) == DMA_FLAG_HTF3)  || \
                                           ((FLAG) == DMA_FLAG_HTF4)  || ((FLAG) == DMA_FLAG_HTF5)  || \
                                           ((FLAG) == DMA_FLAG_HTF6)  || ((FLAG) == DMA_FLAG_HTF7)  || \
                                           ((FLAG) == DMA_FLAG_HTF8)  || ((FLAG) == DMA_FLAG_HTF9)  || \
                                           ((FLAG) == DMA_FLAG_HTF10) || ((FLAG) == DMA_FLAG_HTF11) || \
                                           ((FLAG) == DMA_FLAG_HTF12) || ((FLAG) == DMA_FLAG_HTF13) || \
                                           ((FLAG) == DMA_FLAG_HTF14) || ((FLAG) == DMA_FLAG_HTF15) || \
                                           ((FLAG) == DMA_FLAG_WDG))

#define IS_DMA_CLEAR_IT(IT)               (((((IT) & 0xEFFF0000U) == 0x00000000U) || \
                                            (((IT) & 0xDFFF0000U) == 0x00000000U) || \
                                            (((IT) & 0xBFFF0000U) == 0x00000000U) || \
                                            (((IT) & 0x7FFF0000U) == 0x00000000U)) && \
                                           ((IT) != 0x00000000U))

#define IS_DMA_IT(IT)                     (((IT) == DMA_IT_ERR0)  || ((IT) == DMA_IT_ERR1)  || \
                                           ((IT) == DMA_IT_ERR2)  || ((IT) == DMA_IT_ERR3)  || \
                                           ((IT) == DMA_IT_ERR4)  || ((IT) == DMA_IT_ERR5)  || \
                                           ((IT) == DMA_IT_ERR6)  || ((IT) == DMA_IT_ERR7)  || \
                                           ((IT) == DMA_IT_ERR8)  || ((IT) == DMA_IT_ERR9)  || \
                                           ((IT) == DMA_IT_ERR10) || ((IT) == DMA_IT_ERR11) || \
                                           ((IT) == DMA_IT_ERR12) || ((IT) == DMA_IT_ERR13) || \
                                           ((IT) == DMA_IT_ERR14) || ((IT) == DMA_IT_ERR15) || \
                                           ((IT) == DMA_IT_FTF0)  || ((IT) == DMA_IT_FTF1)  || \
                                           ((IT) == DMA_IT_FTF2)  || ((IT) == DMA_IT_FTF3)  || \
                                           ((IT) == DMA_IT_FTF4)  || ((IT) == DMA_IT_FTF5)  || \
                                           ((IT) == DMA_IT_FTF6)  || ((IT) == DMA_IT_FTF7)  || \
                                           ((IT) == DMA_IT_FTF8)  || ((IT) == DMA_IT_FTF9)  || \
                                           ((IT) == DMA_IT_FTF10) || ((IT) == DMA_IT_FTF11) || \
                                           ((IT) == DMA_IT_FTF12) || ((IT) == DMA_IT_FTF13) || \
                                           ((IT) == DMA_IT_FTF14) || ((IT) == DMA_IT_FTF15) || \
                                           ((IT) == DMA_IT_HTF0)  || ((IT) == DMA_IT_HTF1)  || \
                                           ((IT) == DMA_IT_HTF2)  || ((IT) == DMA_IT_HTF3)  || \
                                           ((IT) == DMA_IT_HTF4)  || ((IT) == DMA_IT_HTF5)  || \
                                           ((IT) == DMA_IT_HTF6)  || ((IT) == DMA_IT_HTF7)  || \
                                           ((IT) == DMA_IT_HTF8)  || ((IT) == DMA_IT_HTF9)  || \
                                           ((IT) == DMA_IT_HTF10) || ((IT) == DMA_IT_HTF11) || \
                                           ((IT) == DMA_IT_HTF12) || ((IT) == DMA_IT_HTF13) || \
                                           ((IT) == DMA_IT_HTF14) || ((IT) == DMA_IT_HTF15) || \
                                           ((IT) == DMA_IT_WDG))
/**
  * @}
  */

/* Private functions ---------------------------------------------------------*/

/** @defgroup DMA_Private_Functions DMA Private Functions
  * @brief  DMA private functions are declared in as32x601_hal_dma.c
  * @{
  */
/**
  * @}
  */

/* Shared internal functions --------------------------------------------------*/

/**
 * @brief  Check whether the DMA handle and its channel instance are valid.
 * @note   Shared with the extension implementation file: every public entry
 *         point of both files performs its handle check through it, so the
 *         NULL pointer and the instance validity are verified in one place.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
uint32 DMA_HandleIsValid(DMA_HandleTypeDef *hdma);

/**
 * @brief  Check whether the handle accepts a new operation.
 * @note   ARCH-CONST-09: a handle that is BUSY (a transfer is ongoing) rejects
 *         a new operation with HAL_BUSY, and a handle that is not initialized
 *         (RESET) requires HAL_DMA_Init() first and is rejected with
 *         HAL_ERROR. The recoverable states TIMEOUT, ERROR and ABORT accept a
 *         new operation directly, so a failed transfer can be restarted
 *         without a re-initialization.
 * @note   A recoverable state is accepted only once the channel has really
 *         stopped (its CHEN enable bit is clear): a start that re-programmed
 *         the counters and the addresses of a still active channel would make
 *         the ongoing transfer undefined. The channel activity is therefore
 *         part of this gate, which reports HAL_BUSY while it lasts.
 * @note   This gate is applied to the start and the callback registration
 *         interfaces. The abort and the polling interfaces deliberately do NOT
 *         use it: they operate on a BUSY channel by definition, so they apply
 *         their own busy check (HAL_DMA_CheckInitState).
 * @param  hdma: pointer to a DMA_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK (accepted) / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef DMA_CheckState(DMA_HandleTypeDef *hdma);

/**
 * @brief  Check whether the handle has been initialized (no busy check).
 * @note   Variant of DMA_CheckState() used by the abort and the polling
 *         interfaces, which are meant to run while a transfer is ongoing and
 *         therefore accept the busy state; only a handle that was never
 *         initialized (RESET) is rejected with HAL_ERROR.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK (accepted) / HAL_ERROR (not initialized).
 */
HAL_StatusTypeDef DMA_CheckInitState(DMA_HandleTypeDef *hdma);

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_DMA_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared channel; the value is passed to HAL_MutexAcquire() as is
 *         (RTOS ticks; HAL_MAX_DELAY means an infinite wait).
 * @param  hdma: pointer to a DMA_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS, wait expired) /
 *         HAL_ERROR (RTOS, mutex not created) / HAL_BUSY (bare metal, the
 *         handle is already locked).
 */
HAL_StatusTypeDef DMA_LockHandle(DMA_HandleTypeDef *hdma, uint32 Timeout);

/**
 * @brief  Unlock the handle.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure.
 * @retval None
 */
void DMA_UnlockHandle(DMA_HandleTypeDef *hdma);

/**
 * @brief  Enter a short critical section that protects a controller register
 *         shared by the 16 channels of that controller.
 * @note   The CHEN enable bits, the ERR/HTF/FTF interrupt mask bits, the PTCH
 *         request mapping registers and the CCR watchdog field are shared by
 *         the channels of one controller, so a read-modify-write of one
 *         channel may lose the update of an interrupt handler servicing
 *         another channel of the same controller (or of a task running on the
 *         other core). The mask/disable style critical section keeps the
 *         update atomic without holding the handle lock, which the ISR must
 *         not take (the handle lock cannot be used from an interrupt context).
 * @note   Shared with the extension implementation file. The returned state
 *         must be passed to DMA_ExitCritical() unchanged; the pair nests.
 * @retval uint32: the interrupt mask state to restore.
 */
uint32 DMA_EnterCritical(void);

/**
 * @brief  Leave the critical section entered by DMA_EnterCritical().
 * @param  state: the value returned by the matching DMA_EnterCritical().
 * @retval None
 */
void DMA_ExitCritical(uint32 state);

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_DMA_H */

/*****END OF FILE*****/
