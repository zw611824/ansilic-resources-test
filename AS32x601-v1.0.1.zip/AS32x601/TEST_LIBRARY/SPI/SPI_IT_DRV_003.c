/**
 * @file    SPI_IT_DRV_003.c
 * @brief   HAL SPI integration test case 003 (Motorola mode sweep).
 *
 * HAL library port of the original AS32x601 standard-library test case
 * SPI_IT_DRV_003.c, which drives SPI3 in master mode and lets the operator
 * choose the Motorola mode (CPOL / CPHA combination) on the console. The port
 * sweeps all four modes in one run. Only HAL library APIs are used; the
 * register read backs are there to document what was programmed.
 *
 * Tested functionality:
 *   HAL_SPI_StructInit()
 *   HAL_SPI_Init()
 *   HAL_SPI_ResetFIFO()
 *   HAL_SPI_NSSConfig()         (asserts SPI_Slave0 around every transfer)
 *   HAL_SPI_Transmit()          (blocking, 64 frames of 8 bit)
 *   HAL_SPI_GetState() / HAL_SPI_GetError()
 *   HAL_SPI_MspInit()           (overridden: clock gate, reset pulse, pins)
 *
 * Test procedure:
 *   For every Motorola mode of the table (Mode0 .. Mode3):
 *     1. program the mode and initialize SPI3 in master mode with the divider
 *        of the reference case (/512);
 *     2. read the mode field back from the CFG register;
 *     3. transmit 64 frames and check the status / state / error code.
 *
 * Expected behaviour:
 *   - CFG carries exactly the requested CPOL / CPHA combination:
 *       Mode0 (CPOL=0, CPHA=0) -> 0x00
 *       Mode1 (CPOL=0, CPHA=1) -> 0x04
 *       Mode2 (CPOL=1, CPHA=0) -> 0x08
 *       Mode3 (CPOL=1, CPHA=1) -> 0x0C
 *   - every transmission completes with HAL_OK and the handle returns to
 *     READY with the error code NONE;
 *   - every check prints [PASS] and "summary : failures = 0";
 *   - an oscilloscope on PD3 (SCK) and PD1 (MOSI) shows the clock polarity and
 *     the sampling edge of the selected mode; a peer configured with the same
 *     mode receives the 64 bytes 0x00 .. 0x3F.
 *
 * Note:
 *   - The SPI clock is APBBus1 / 512, i.e. a slow clock that is easy to
 *     capture on an oscilloscope.
 *   - The received frames are discarded by HAL_SPI_Transmit() in master mode,
 *     so no peer is required for the register and status checks; the data
 *     comparison is the business of the peer.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console: USART0 on GPIOD pin 8 (TX) / pin 9 (RX), 115200 8N1 */
#define TEST_BAUDRATE                   (115200U)

/* Device under test: SPI3 (as in the reference test case)
 *   CS0  = PC10   SCK  = PD3   MOSI = PD1   MISO = PD2
 */
#define TEST_SPI                        SPI3
#define TEST_CS_PORT                    GPIOC
#define TEST_CS_PIN                     GPIO_PIN_10
#define TEST_CS_SOURCE                  GPIO_PinSource10
#define TEST_SCK_PORT                   GPIOD
#define TEST_SCK_PIN                    GPIO_PIN_3
#define TEST_SCK_SOURCE                 GPIO_PinSource3
#define TEST_MOSI_PORT                  GPIOD
#define TEST_MOSI_PIN                   GPIO_PIN_1
#define TEST_MOSI_SOURCE                GPIO_PinSource1
#define TEST_MISO_PORT                  GPIOD
#define TEST_MISO_PIN                   GPIO_PIN_2
#define TEST_MISO_SOURCE                GPIO_PinSource2
#define TEST_PIN_AF                     GPIO_AF_SPI3

/* Frame geometry, timeouts and the mode table */
#define TX_FRAME_COUNT                  (64U)
#define TRANSFER_TIMEOUT_MS             (1000U)
#define MODE_COUNT                      (4U)

/* Private variables ---------------------------------------------------------*/
static SPI_HandleTypeDef hspi_dev;              /*!< device under test      */
static HAL_SMU_HandleTypeDef hsmu_clk;          /*!< SMU handle (clock tree) */
static uint8 tx_data[TX_FRAME_COUNT];           /*!< transmit pattern        */
static volatile uint32 check_failures = 0U;     /*!< failed check counter    */

/* Motorola mode register value and its CPOL / CPHA description */
static const uint32 mode_reg[MODE_COUNT] = {
    SPI_Motorola_Mode0, SPI_Motorola_Mode1, SPI_Motorola_Mode2,
    SPI_Motorola_Mode3
};
static const char * const mode_name[MODE_COUNT] = {
    "Mode0 (CPOL=0, CPHA=0)", "Mode1 (CPOL=0, CPHA=1)",
    "Mode2 (CPOL=1, CPHA=0)", "Mode3 (CPOL=1, CPHA=1)"
};

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void Check(const char *name, uint32 condition);
static void Summary(void);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    SPI_InitTypeDef spi_init;
    HAL_StatusTypeDef status;
    uint32 index;
    uint32 mode_index;
    uint32 cfg_mode;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock tree */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART (USART0 on GPIOD pin 8 / pin 9) */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== SPI_IT_DRV_003 : Motorola mode sweep (SPI3) ===\r\n");

    /* Transmit pattern: 0, 1, 2 .. 63 (as in the reference test case) */
    for (index = 0U; index < TX_FRAME_COUNT; index++)
    {
        tx_data[index] = (uint8)index;
    }

    __HAL_CLEAR_STRUCT(&hspi_dev);

    for (mode_index = 0U; mode_index < MODE_COUNT; mode_index++)
    {
        printf("\r\n-- %s --\r\n", mode_name[mode_index]);

        /* Step 1: program the Motorola mode of this iteration */
        HAL_SPI_StructInit(&spi_init);
        spi_init.SPI_CLKDiv       = SPI_CLKDiv512;
        spi_init.SPI_Mode         = SPI_Mode_Master;
        spi_init.SPI_FrameSize    = SPI_FrameSize_8b;
        spi_init.SPI_MotorolaMode = mode_reg[mode_index];
        spi_init.SPI_TransMode    = SPI_TransNor;

        hspi_dev.Instance = TEST_SPI;
        hspi_dev.Init     = spi_init;

        status = HAL_SPI_Init(&hspi_dev);
        /* The slave select is not part of the initialization: SSR
         * resets to 0 (no slave selected) and HAL_SPI_Init() does not
         * touch it, so the selection has to be programmed here. */
        HAL_SPI_ResetFIFO(&hspi_dev, SPI_RESETFIFO_TXANDRX);
        HAL_SPI_NSSConfig(&hspi_dev, SPI_Slave0, SPI_ENABLE);
        Check("HAL_SPI_Init returns HAL_OK", (uint32)((status == HAL_OK) ? 1U : 0U));
        Check("state after init is READY",
              (uint32)((HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_READY) ? 1U : 0U));
        Check("error code after init is NONE",
              (uint32)((HAL_SPI_GetError(&hspi_dev) == HAL_SPI_ERROR_NONE) ? 1U : 0U));

        /* Step 2: the mode field of CFG must carry the requested value */
        cfg_mode = (uint32)TEST_SPI->CFG & SPI_CFG_MOTMODESEL_Msk;
        printf("CFG          : 0x%08X (mode field 0x%02X, requested 0x%02X) %s\r\n",
               PRINT_U32((uint32)TEST_SPI->CFG),
               PRINT_U32(cfg_mode),
               PRINT_U32(mode_reg[mode_index] & SPI_CFG_MOTMODESEL_Msk),
               ((cfg_mode == (mode_reg[mode_index] & SPI_CFG_MOTMODESEL_Msk)) ?
                "[PASS]" : "[FAIL]"));
        if (cfg_mode != (mode_reg[mode_index] & SPI_CFG_MOTMODESEL_Msk))
        {
            check_failures++;
        }

        /* The frame size and the transfer mode must be untouched */
        Check("frame size field is still 8 bit",
              (uint32)((((uint32)TEST_SPI->CFG & SPI_CFG_FS_Msk) ==
                        (SPI_FrameSize_8b & SPI_CFG_FS_Msk)) ? 1U : 0U));
        Check("transfer mode field is still normal",
              (uint32)((((uint32)TEST_SPI->CFG & SPI_CFG_TRANSMODE_Msk) == 0U) ? 1U : 0U));

        /* Step 3: transmit the pattern with this clock polarity / phase */
        status = HAL_SPI_Transmit(&hspi_dev, tx_data, TX_FRAME_COUNT,
                                  TRANSFER_TIMEOUT_MS);
        Check("HAL_SPI_Transmit returns HAL_OK", (uint32)((status == HAL_OK) ? 1U : 0U));
        Check("state after the transfer is READY",
              (uint32)((HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_READY) ? 1U : 0U));
        Check("error code after the transfer is NONE",
              (uint32)((HAL_SPI_GetError(&hspi_dev) == HAL_SPI_ERROR_NONE) ? 1U : 0U));
    }

    /* Release the slave select, so the lines are not left asserted */
    HAL_SPI_NSSConfig(&hspi_dev, SPI_Slave0, SPI_DISABLE);

    Summary();

    while (1)
    {
        delay_ms(1000U);
    }
}

/**
 * @brief  Report the result of one check.
 * @param  name: short description of the check.
 * @param  condition: 0 = FAIL, non zero = PASS.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("%-46s : [PASS]\r\n", name);
    }
    else
    {
        check_failures++;
        printf("%-46s : [FAIL]\r\n", name);
    }
}

/**
 * @brief  Print the accumulated failure counter.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(check_failures));
}

/**
 * @brief  MSP initialization of the device under test.
 * @note   Strong override of the weak driver callback.
 * @param  hspi: SPI handle of the device under test.
 * @retval None
 */
void HAL_SPI_MspInit(SPI_HandleTypeDef *hspi)
{
    GPIO_InitTypeDef gpio;

    if (hspi->Instance != TEST_SPI)
    {
        return;
    }

    /* Peripheral clock gate and reset pulse */
    __HAL_SMU_SPI3_CLK_ENABLE();
    __HAL_SMU_SPI3_FORCE_RESET();
    __HAL_SMU_SPI3_RELEASE_RESET();

    /* Port clock gates used by this case */
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&gpio);
    gpio.Size         = sizeof(gpio);
    gpio.Version      = GPIO_INIT_VERSION;
    gpio.Pull         = GPIO_NOPULL;
    gpio.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    gpio.Alternate    = TEST_PIN_AF;
    gpio.Mode         = GPIO_MODE_AF_PP;

    /* CS0 (driven by the SSR register) */
    HAL_GPIO_PinAFConfig(TEST_CS_PORT, TEST_CS_SOURCE, TEST_PIN_AF);
    gpio.Pin = TEST_CS_PIN;
    HAL_GPIO_Init(TEST_CS_PORT, &gpio);

    /* SCK */
    HAL_GPIO_PinAFConfig(TEST_SCK_PORT, TEST_SCK_SOURCE, TEST_PIN_AF);
    gpio.Pin = TEST_SCK_PIN;
    HAL_GPIO_Init(TEST_SCK_PORT, &gpio);

    /* MOSI */
    HAL_GPIO_PinAFConfig(TEST_MOSI_PORT, TEST_MOSI_SOURCE, TEST_PIN_AF);
    gpio.Pin = TEST_MOSI_PIN;
    HAL_GPIO_Init(TEST_MOSI_PORT, &gpio);

    /* MISO: alternate function input, floating */
    HAL_GPIO_PinAFConfig(TEST_MISO_PORT, TEST_MISO_SOURCE, TEST_PIN_AF);
    gpio.Pin  = TEST_MISO_PIN;
    gpio.Mode = GPIO_MODE_INPUT;
    HAL_GPIO_Init(TEST_MISO_PORT, &gpio);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the CLINT / CMU / MPU / USART integration tests.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef    SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the same set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls (PMU_CheckState) */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
