/**
 * @file    DAC_IT_DRV_015.c
 * @brief   HAL DAC integration test case 015 (check macros, exported macros and constants).
 *
 * Extension case of the DAC integration test suite: it exercises the
 * validation macros, the exported macros and the constant encodings of the
 * module header, which the functional cases only use implicitly. A wrong
 * encoding or a validation macro with an open range would not produce a
 * compiler warning, it would silently accept (or reject) the wrong values.
 * Only HAL library APIs are used.
 *
 * Tested functionality:
 *   IS_DAC_ALL_INSTANCE / IS_DAC_ALL_PERIPH / IS_DAC_EN /
 *   IS_DAC_OUTPUT_BUFFER_STATE / IS_DAC_MD / IS_DAC_VREF_MD /
 *   IS_DAC_CLK_DIV / IS_DAC_DATA / IS_DAC_NEWSTATE /
 *   IS_DAC_CMP_EN / IS_DAC_CMP_MD / IS_DAC_CMP_HYS
 *   __HAL_DAC_ENABLE / __HAL_DAC_DISABLE / __HAL_DAC_RESET_RELEASE /
 *   __HAL_DAC_RESET_ASSERT / __HAL_DAC_RESET_HANDLE_STATE
 *   the constant encodings (output buffer, reference, comparator modes, the
 *   eight hysteresis steps and their device layer aliases)
 *   __HAL_DAC_MODULE_VERSION
 *
 * Test procedure:
 *   1. Check every validation macro with accepted and rejected values;
 *   2. Check the encodings of the output buffer, reference voltage and
 *      comparator constants, including the eight hysteresis steps and the
 *      device layer aliases;
 *   3. Check the exported macros on a real instance (enable / disable, reset
 *      release / assert, handle state reset);
 *   4. Check the module version macro.
 *
 * Expected behaviour:
 *   - every validation macro accepts exactly the documented values;
 *   - the aliases keep their value (especially DAC_CMP_HYS_330 = 7, the alias
 *     of the eight step table);
 *   - the exported macros act on the CTRL register and on the handle state;
 *   - every check prints [PASS] and "summary : failures = 0".
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define -----------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* DAC output pins and comparator input pins of this suite, taken from the
 * device IO map (ioDoc): DAC0_OUT = PE4, DAC1_OUT = PC13,
 * CMP0_P = PE2, CMP0_N = PE3. */
#define TEST_DAC0_PORT              GPIOE
#define TEST_DAC0_PIN               GPIO_PIN_4
#define TEST_DAC0_SOURCE            GPIO_PinSource4
#define TEST_DAC1_PORT              GPIOC
#define TEST_DAC1_PIN               GPIO_PIN_13
#define TEST_DAC1_SOURCE            GPIO_PinSource13
#define TEST_CMP_PORT               GPIOE
#define TEST_CMP_P_PIN              GPIO_PIN_2
#define TEST_CMP_N_PIN              GPIO_PIN_3
#define TEST_CMP_P_SOURCE           GPIO_PinSource2
#define TEST_CMP_N_SOURCE           GPIO_PinSource3

/* Private variables ---------------------------------------------------------*/
static volatile uint32 check_failures = 0U;  /*!< failed check counter        */
static HAL_SMU_HandleTypeDef hsmu_clk;       /*!< SMU handle (clock tree)     */
static DAC_HandleTypeDef hadac_dev;          /*!< DAC under test              */

/* MSP callback bookkeeping (defined with the callbacks at the end of the file) */
extern uint32 Dac_MspInitCount;
extern uint32 Dac_MspDeInitCount;
extern uint32 Dac_MspStateAtInit;
extern uint32 Dac_MspLockAtInit;
extern uint32 Dac_MspStateAtDeInit;

/* Private function prototypes -----------------------------------------------*/
/* Shared helpers of this suite (defined at the end of this file) */
void Check(const char *name, uint32 condition);
void Summary(void);
void SystemClock_Init(void);
void Dac_PeriphClockEnable(DAC_TypeDef *instance);
void Dac_PinConfig(DAC_TypeDef *instance);
void Dac_InitStruct_Default(DAC_InitTypeDef *p_init);
HAL_StatusTypeDef Dac_Config(DAC_TypeDef *instance, FunctionalState enable, uint32 divider);
HAL_StatusTypeDef Dac_ConfigComparator(DAC_HandleTypeDef *hdac, uint32 cmp_enable, uint32 cmp_mode, uint32 cmp_hys);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    uint32 ok;
    uint32 step;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== DAC_IT_DRV_015 : check macros, exported macros and constants ===\r\n");

    /* ---- Step 1: the validation macros ------------------------------- */
    ok = 1U;
    ok &= (IS_DAC_ALL_INSTANCE(DAC0) != 0U) ? 1U : 0U;
    ok &= (IS_DAC_ALL_INSTANCE(DAC1) != 0U) ? 1U : 0U;
    ok &= (IS_DAC_ALL_INSTANCE((DAC_TypeDef *)0x40000000UL) == 0U) ? 1U : 0U;
    ok &= (IS_DAC_ALL_PERIPH(DAC0) != 0U) ? 1U : 0U;
    Check("IS_DAC_ALL_INSTANCE / IS_DAC_ALL_PERIPH accept DAC0 and DAC1 only", ok);

    ok = 1U;
    ok &= (IS_DAC_EN(DAC_ENABLE) != 0U) ? 1U : 0U;
    ok &= (IS_DAC_EN(DAC_DISABLE) != 0U) ? 1U : 0U;
    ok &= (IS_DAC_EN(2U) == 0U) ? 1U : 0U;
    Check("IS_DAC_EN accepts 0 and 1 and rejects 2", ok);

    ok = 1U;
    ok &= (IS_DAC_OUTPUT_BUFFER_STATE(DAC_OUTPUTBUFFER_ENABLE) != 0U) ? 1U : 0U;
    ok &= (IS_DAC_OUTPUT_BUFFER_STATE(DAC_OUTPUTBUFFER_DISABLE) != 0U) ? 1U : 0U;
    ok &= (IS_DAC_OUTPUT_BUFFER_STATE(DAC_MD_BUFFER_OUT) != 0U) ? 1U : 0U;
    ok &= (IS_DAC_OUTPUT_BUFFER_STATE(DAC_MD_BYPASS_OUT) != 0U) ? 1U : 0U;
    ok &= (IS_DAC_OUTPUT_BUFFER_STATE(2U) == 0U) ? 1U : 0U;
    ok &= (IS_DAC_MD(2U) == 0U) ? 1U : 0U;
    Check("IS_DAC_OUTPUT_BUFFER_STATE (and its IS_DAC_MD alias) accepts the two modes", ok);

    ok = 1U;
    ok &= (IS_DAC_VREF_MD(DAC_VREF_MD_VREFP) != 0U) ? 1U : 0U;
    ok &= (IS_DAC_VREF_MD(DAC_VREF_MD_AVD) != 0U) ? 1U : 0U;
    ok &= (IS_DAC_VREF_MD(2U) == 0U) ? 1U : 0U;
    Check("IS_DAC_VREF_MD accepts the two references and rejects 2", ok);

    ok = 1U;
    ok &= (IS_DAC_CLK_DIV(0x00U) != 0U) ? 1U : 0U;
    ok &= (IS_DAC_CLK_DIV(0xFFU) != 0U) ? 1U : 0U;
    ok &= (IS_DAC_CLK_DIV(0x100U) == 0U) ? 1U : 0U;
    Check("IS_DAC_CLK_DIV covers 0x00 - 0xFF (8-bit field)", ok);

    ok = 1U;
    ok &= (IS_DAC_DATA(0x00U) != 0U) ? 1U : 0U;
    ok &= (IS_DAC_DATA(0xFFU) != 0U) ? 1U : 0U;
    ok &= (IS_DAC_DATA(0x100U) == 0U) ? 1U : 0U;
    Check("IS_DAC_DATA covers 0x00 - 0xFF (8-bit DAC)", ok);

    ok = 1U;
    ok &= (IS_DAC_NEWSTATE(0U) != 0U) ? 1U : 0U;
    ok &= (IS_DAC_NEWSTATE(1U) != 0U) ? 1U : 0U;
    ok &= (IS_DAC_NEWSTATE(2U) == 0U) ? 1U : 0U;
    Check("IS_DAC_NEWSTATE accepts 0 and 1 only", ok);

    ok = 1U;
    ok &= (IS_DAC_CMP_EN(DAC_CMP_ENABLE) != 0U) ? 1U : 0U;
    ok &= (IS_DAC_CMP_EN(DAC_CMP_DISABLE) != 0U) ? 1U : 0U;
    ok &= (IS_DAC_CMP_EN(2U) == 0U) ? 1U : 0U;
    ok &= (IS_DAC_CMP_MD(DAC_CMP_MD_DACO) != 0U) ? 1U : 0U;
    ok &= (IS_DAC_CMP_MD(DAC_CMP_MD_CMP_P) != 0U) ? 1U : 0U;
    ok &= (IS_DAC_CMP_MD(2U) == 0U) ? 1U : 0U;
    Check("IS_DAC_CMP_EN / IS_DAC_CMP_MD accept their two values", ok);

    ok = 1U;
    for (step = 0U; step <= 7U; step++)
    {
        ok &= (IS_DAC_CMP_HYS(step) != 0U) ? 1U : 0U;
    }
    ok &= (IS_DAC_CMP_HYS(8U) == 0U) ? 1U : 0U;
    Check("IS_DAC_CMP_HYS covers the eight steps 0..7 and rejects 8", ok);

    /* ---- Step 2: the constant encodings ------------------------------ */
    ok = 1U;
    ok &= (DAC_OUTPUTBUFFER_ENABLE == 0U) ? 1U : 0U;
    ok &= (DAC_OUTPUTBUFFER_DISABLE == 1U) ? 1U : 0U;
    ok &= (DAC_MD_BUFFER_OUT == DAC_OUTPUTBUFFER_ENABLE) ? 1U : 0U;
    ok &= (DAC_MD_BYPASS_OUT == DAC_OUTPUTBUFFER_DISABLE) ? 1U : 0U;
    ok &= (DAC_VREF_MD_VREFP == 0U) ? 1U : 0U;
    ok &= (DAC_VREF_MD_AVD == 1U) ? 1U : 0U;
    ok &= (DAC_ENABLE == 1U) ? 1U : 0U;
    ok &= (DAC_DISABLE == 0U) ? 1U : 0U;
    Check("the output buffer / reference / enable encodings match the CTRL register", ok);

    ok = 1U;
    ok &= (DAC_CMP_ENABLE == 1U) ? 1U : 0U;
    ok &= (DAC_CMP_DISABLE == 0U) ? 1U : 0U;
    ok &= (DAC_CMP_MD_DACO == 0U) ? 1U : 0U;
    ok &= (DAC_CMP_MD_CMP_P == 1U) ? 1U : 0U;
    Check("the comparator enable / mode encodings match the CMP_CTRL register", ok);

    ok = 1U;
    ok &= (DAC_CMP_HYS_0MV == 0U) ? 1U : 0U;
    ok &= (DAC_CMP_HYS_3P30MV == 1U) ? 1U : 0U;
    ok &= (DAC_CMP_HYS_16P50MV == 2U) ? 1U : 0U;
    ok &= (DAC_CMP_HYS_33MV == 3U) ? 1U : 0U;
    ok &= (DAC_CMP_HYS_66MV == 4U) ? 1U : 0U;
    ok &= (DAC_CMP_HYS_165MV == 5U) ? 1U : 0U;
    ok &= (DAC_CMP_HYS_264MV == 6U) ? 1U : 0U;
    ok &= (DAC_CMP_HYS_330MV == 7U) ? 1U : 0U;
    Check("the eight hysteresis steps are coded 0..7", ok);

    ok = 1U;
    ok &= (DAC_CMP_HYS_0 == DAC_CMP_HYS_0MV) ? 1U : 0U;
    ok &= (DAC_CMP_HYS_3MV3 == DAC_CMP_HYS_3P30MV) ? 1U : 0U;
    ok &= (DAC_CMP_HYS_16MV5 == DAC_CMP_HYS_16P50MV) ? 1U : 0U;
    ok &= (DAC_CMP_HYS_33 == DAC_CMP_HYS_33MV) ? 1U : 0U;
    ok &= (DAC_CMP_HYS_66 == DAC_CMP_HYS_66MV) ? 1U : 0U;
    ok &= (DAC_CMP_HYS_165 == DAC_CMP_HYS_165MV) ? 1U : 0U;
    ok &= (DAC_CMP_HYS_330 == DAC_CMP_HYS_330MV) ? 1U : 0U;
    ok &= (DAC_CMP_HYS_330 == 7U) ? 1U : 0U;
    Check("the device layer hysteresis aliases keep the eight step encoding", ok);

    Check("the module version is 0x0100 (V1.0)",
          (__HAL_DAC_MODULE_VERSION == 0x0100U) ? 1U : 0U);

    /* ---- Step 3: the exported macros --------------------------------- */
    Check("HAL_DAC_Init() returns HAL_OK", (Dac_Config(DAC0, DISABLE, 0x1EU) == HAL_OK));

    __HAL_DAC_ENABLE(&hadac_dev);
    Check("__HAL_DAC_ENABLE() sets CTRL.EN",
          ((DAC0->CTRL & DAC_CTRL_EN) != 0U) ? 1U : 0U);
    __HAL_DAC_DISABLE(&hadac_dev);
    Check("__HAL_DAC_DISABLE() clears CTRL.EN",
          ((DAC0->CTRL & DAC_CTRL_EN) == 0U) ? 1U : 0U);

    __HAL_DAC_RESET_ASSERT(&hadac_dev);
    Check("__HAL_DAC_RESET_ASSERT() clears CTRL.RESETN",
          ((DAC0->CTRL & DAC_CTRL_RESETN) == 0U) ? 1U : 0U);
    __HAL_DAC_RESET_RELEASE(&hadac_dev);
    Check("__HAL_DAC_RESET_RELEASE() sets CTRL.RESETN",
          ((DAC0->CTRL & DAC_CTRL_RESETN) != 0U) ? 1U : 0U);

    __HAL_DAC_RESET_HANDLE_STATE(&hadac_dev);
    Check("__HAL_DAC_RESET_HANDLE_STATE() puts the handle back to RESET",
          (HAL_DAC_GetState(&hadac_dev) == HAL_DAC_STATE_RESET) ? 1U : 0U);

    /* ---- Step 4: the module still works ------------------------------ */
    hadac_dev.Instance = DAC0;
    hadac_dev.Init.Size    = sizeof(DAC_InitTypeDef);
    hadac_dev.Init.Version = DAC_INIT_VERSION;
    hadac_dev.Init.DAC_Enable       = ENABLE;
    hadac_dev.Init.DAC_Mode         = DAC_OUTPUTBUFFER_ENABLE;
    hadac_dev.Init.DAC_VrefMode     = DAC_VREF_MD_VREFP;
    hadac_dev.Init.DAC_ClockDivider = 0x1EU;
    Check("the module can be initialized after the macro checks",
          (HAL_DAC_Init(&hadac_dev) == HAL_OK));
    Check("the data path works after the macro checks",
          ((HAL_DAC_SetValue(&hadac_dev, 0x7EU) == HAL_OK) &&
           ((uint32)DAC0->DOUT == 0x7EU)) ? 1U : 0U);

    Summary();

    for (;;)
    {
        /* Keep the console alive for the observation */
        printf("state = %u, error = 0x%08X, CTRL = 0x%02X, DOUT = %u\r\n",
               PRINT_U32(HAL_DAC_GetState(&hadac_dev)),
               PRINT_U32(HAL_DAC_GetError(&hadac_dev)),
               PRINT_U32(DAC0->CTRL),
               PRINT_U32(DAC0->DOUT));
        delay_ms(2000U);
    }
}
/*****END OF FILE*****/

/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the other integration tests of this library:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2 and
 *         CANX2 by 8, which gives core 180 MHz, AXILiteBus1 (the DAC0 clock)
 *         and AXILiteBus2 (the DAC1 clock) 45 MHz and APB 22.5 MHz.
 * @note   Clock tree order: the dividers are written while the system clock
 *         is still the power on source (FIRC), then the PLL is configured and
 *         the system clock is switched to it. That last call programs the
 *         flash controller clock before the switch (the core keeps fetching
 *         from the flash) and updates SystemCoreClock afterwards.
 * @param  None
 * @retval None
 */
void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef    SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks of this suite (the DAC / comparator pins) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Enable the clock gate of a DAC instance and release its bus reset.
 * @note   The default MSP callbacks of the DAC driver are empty by design (the
 *         clock gate belongs to the application), therefore this suite performs
 *         the gate and bus reset handling itself. The macros drive
 *         SMU->ALB1CFGR (DAC0) / SMU->ALB2CFGR (DAC1), which is a different
 *         reset domain than the module reset bit DAC_CTRL.RESETN handled by
 *         HAL_DAC_ResetCmd().
 * @param  instance: DAC0 or DAC1
 * @retval None
 */
void Dac_PeriphClockEnable(DAC_TypeDef *instance)
{
    if (instance == DAC0)
    {
        __HAL_SMU_DAC0_CLK_ENABLE();
        __HAL_SMU_DAC0_FORCE_RESET();
        __HAL_SMU_DAC0_RELEASE_RESET();
    }
    else
    {
        __HAL_SMU_DAC1_CLK_ENABLE();
        __HAL_SMU_DAC1_FORCE_RESET();
        __HAL_SMU_DAC1_RELEASE_RESET();
    }
}

/**
 * @brief  Configure a group of pins as analog pins.
 * @note   Every pin of the mask is configured on its own, so that the
 *         multiplexer register of each pin is programmed with the "plain pin"
 *         alternate function before the pin is switched to the analog mode.
 * @param  port: GPIO port the pins belong to
 * @param  pins: pin mask (GPIO_PIN_x or a combination)
 * @retval None
 */
static void Gpio_AnalogConfig(GPIO_TypeDef *port, uint32 pins)
{
    GPIO_InitTypeDef gpio_init;
    uint32 i;
    uint32 pin;

    __HAL_CLEAR_STRUCT(&gpio_init);
    gpio_init.Size         = sizeof(gpio_init);
    gpio_init.Version      = GPIO_INIT_VERSION;
    gpio_init.Pull         = GPIO_NOPULL;
    gpio_init.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;
    gpio_init.Mode         = GPIO_MODE_ANALOG;
    gpio_init.Alternate    = GPIO_AF_Pin_x;

    for (i = 0U; i < 16U; i++)
    {
        pin = (uint32)(1UL << i);
        if ((pins & pin) != 0U)
        {
            HAL_GPIO_PinAFConfig(port, i, GPIO_AF_Pin_x);
            gpio_init.Pin = pin;
            (void)HAL_GPIO_Init(port, &gpio_init);
        }
    }
}

/**
 * @brief  Configure the analog pins of one DAC instance.
 * @note   DAC0 drives PE4 and uses the comparator inputs CMP0_P (PE2) and
 *         CMP0_N (PE3); DAC1 drives PC13. The pin map comes from the device IO
 *         map (ioDoc.xlsx, column "analog function").
 * @param  instance: DAC0 or DAC1
 * @retval None
 */
void Dac_PinConfig(DAC_TypeDef *instance)
{
    if (instance == DAC0)
    {
        Gpio_AnalogConfig(TEST_DAC0_PORT, TEST_DAC0_PIN);
        Gpio_AnalogConfig(TEST_CMP_PORT, TEST_CMP_P_PIN | TEST_CMP_N_PIN);
    }
    else
    {
        Gpio_AnalogConfig(TEST_DAC1_PORT, TEST_DAC1_PIN);
    }
}

/**
 * @brief  Fill a DAC init structure with the configuration of the reference
 *         test project (the baseline every case starts from).
 * @note   The structure meta fields (Size / Version) are filled by
 *         HAL_DAC_StructInit(), and the initialization interface validates
 *         them at run time, so this helper is the only place where the
 *         baseline is built.
 * @param  p_init: pointer to the init structure to fill
 * @retval None
 */
void Dac_InitStruct_Default(DAC_InitTypeDef *p_init)
{
    HAL_DAC_StructInit(p_init);

    p_init->DAC_Enable       = DISABLE;
    p_init->DAC_Mode         = DAC_OUTPUTBUFFER_ENABLE;
    p_init->DAC_VrefMode     = DAC_VREF_MD_VREFP;
    p_init->DAC_ClockDivider = 0x1EU;      /* the divider of the reference case */
}

/**
 * @brief  Configure and initialize one DAC instance.
 * @note   HAL_DAC_Init() does not release the module reset (DAC_CTRL.RESETN
 *         resets to 0), so HAL_DAC_ResetCmd() is called afterwards to release
 *         it: without that call HAL_DAC_Start() / HAL_DAC_SetValue() report
 *         HAL_ERROR. The clear+settle delay follows the sequence documented by
 *         the driver (release the reset, wait for the data path to settle).
 * @param  instance: DAC0 or DAC1
 * @param  enable: initial value of the DAC enable field (ENABLE / DISABLE)
 * @param  divider: clock divide ratio (1 to 0xFF)
 * @retval HAL status of HAL_DAC_Init()
 */
HAL_StatusTypeDef Dac_Config(DAC_TypeDef *instance, FunctionalState enable, uint32 divider)
{
    DAC_InitTypeDef dac_init;
    HAL_StatusTypeDef status;

    Dac_PinConfig(instance);

    __HAL_CLEAR_STRUCT(&hadac_dev);
    hadac_dev.Instance = instance;

    Dac_InitStruct_Default(&dac_init);
    dac_init.DAC_Enable       = enable;
    dac_init.DAC_ClockDivider = divider;
    hadac_dev.Init = dac_init;

    status = HAL_DAC_Init(&hadac_dev);
    if (status == HAL_OK)
    {
        (void)HAL_DAC_ResetCmd(&hadac_dev, 1U);
        delay_ms(20U);
    }

    return status;
}

/**
 * @brief  Configure the comparator of one DAC instance.
 * @param  hdac: DAC handle
 * @param  cmp_enable: DAC_CMP_ENABLE / DAC_CMP_DISABLE
 * @param  cmp_mode: DAC_CMP_MD_DACO / DAC_CMP_MD_CMP_P
 * @param  cmp_hys: DAC_CMP_HYS_xMV (0 to 7)
 * @retval HAL status of HAL_DAC_ConfigComparator()
 */
HAL_StatusTypeDef Dac_ConfigComparator(DAC_HandleTypeDef *hdac, uint32 cmp_enable,
                                       uint32 cmp_mode, uint32 cmp_hys)
{
    DAC_CMPConfTypeDef cmp_conf;

    HAL_DAC_CMPStructInit(&cmp_conf);
    cmp_conf.CMP_Enable     = cmp_enable;
    cmp_conf.CMP_Mode       = cmp_mode;
    cmp_conf.CMP_Hysteresis = cmp_hys;

    return HAL_DAC_ConfigComparator(hdac, &cmp_conf);
}

/* MSP callback bookkeeping -------------------------------------------------*/

uint32 Dac_MspInitCount    = 0U;   /*!< HAL_DAC_MspInit() call counter        */
uint32 Dac_MspDeInitCount  = 0U;   /*!< HAL_DAC_MspDeInit() call counter      */
uint32 Dac_MspStateAtInit  = 0xFFU;/*!< handle state observed in MspInit      */
uint32 Dac_MspLockAtInit   = 0xFFU;/*!< handle lock observed in MspInit       */
uint32 Dac_MspStateAtDeInit= 0xFFU;/*!< handle state observed in MspDeInit    */

/**
 * @brief  Initialize the low level hardware of the DAC (strong override of the
 *         weak callback of the driver).
 * @note   Records the call and the handle fields it observes, so that the
 *         cases can assert the MSP contract: the callback runs once per
 *         initialization, before the handle is locked (LOCK-06) and while the
 *         handle is still in the RESET state (MSP-04).
 * @param  hdac: DAC handle
 * @retval None
 */
void HAL_DAC_MspInit(DAC_HandleTypeDef *hdac)
{
    if (hdac == NULL_PTR)
    {
        return;
    }

    Dac_MspInitCount++;
    Dac_MspStateAtInit = (uint32)hdac->State;
    Dac_MspLockAtInit  = (uint32)hdac->Lock;

    Dac_PeriphClockEnable(hdac->Instance);
}

/**
 * @brief  De-initialize the low level hardware of the DAC (strong override of
 *         the weak callback of the driver).
 * @note   The callback runs after the handle has been unlocked (LOCK-06) and
 *         after the state has been set back to RESET.
 * @param  hdac: DAC handle
 * @retval None
 */
void HAL_DAC_MspDeInit(DAC_HandleTypeDef *hdac)
{
    if (hdac == NULL_PTR)
    {
        return;
    }

    Dac_MspDeInitCount++;
    Dac_MspStateAtDeInit = (uint32)hdac->State;

    if (hdac->Instance == DAC0)
    {
        __HAL_SMU_DAC0_FORCE_RESET();
        __HAL_SMU_DAC0_CLK_DISABLE();
    }
    else
    {
        __HAL_SMU_DAC1_FORCE_RESET();
        __HAL_SMU_DAC1_CLK_DISABLE();
    }
}
