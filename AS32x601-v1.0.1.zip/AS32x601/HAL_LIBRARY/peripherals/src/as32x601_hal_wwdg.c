/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):    Xiamen Guoke Anxin Technology Co., LTD
 * FileName:         as32x601_hal_wwdg.c
 * Author:           ANSILIC APPLICATION GROUP
 * Version:          V1.3
 * Date:             2026/09/21
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.1     add the module guard (HAL_WWDG_MODULE_ENABLED) around the whole implementation
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.2     put the as32x601_hal.h include first (module switch from the conf) before the module headers
 *     ANSILIC APPLICATION GROUP  2026/09/21     1.3     bring the module up to the Medium level
 *                                                       of the architecture specification: add the
 *                                                       shared lock / state helpers, take the lock
 *                                                       and clear the error code in the operation
 *                                                       entry points, apply the busy / reset state
 *                                                       gate, validate the configuration at run
 *                                                       time in front of the first register access,
 *                                                       add the state and error reporting
 *                                                       interfaces, let the default MspInit enable
 *                                                       the instance clock and release its reset,
 *                                                       add the blocking marker of every interface,
 *                                                       align the version of the four module files
 *                                                       and describe the module without referring to
 *                                                       an external implementation
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Window Watchdog
 *                  (WWDG) peripheral:
 *                  - Initialization (HAL_WWDG_Init): prescaler number
 *                    (PSC.PSCNUM), divider number (DIV.DIVNUM), timeout
 *                    value (TO.BVAL) and window counter (WD.WDCNT)
 *                    configuration;
 *                  - IO operation functions (HAL_WWDG_Refresh /
 *                    HAL_WWDG_GetCounter / HAL_WWDG_GetBKStatus);
 *                  - State and error reporting (HAL_WWDG_GetState /
 *                    HAL_WWDG_GetError).
 *                  The chip-specific enable / lock control is provided by
 *                  this driver (HAL_WWDG_Cmd / HAL_WWDG_LockCmd).
 *                  The WWDG0 peripheral is clocked by the APBBus0 domain
 *                  and the WWDG1 peripheral by the APBBus1 domain, both
 *                  gated by the SMU: the default HAL_WWDG_MspInit()
 *                  implementation enables the clock of the selected
 *                  instance and releases its reset.
 *                  The watchdog is started by setting the configuration
 *                  enable bit (CFG.EN) through HAL_WWDG_Cmd() with
 *                  WWDG_EN_CFG / ENABLE or through the __HAL_WWDG_START()
 *                  macro, and is stopped again by disabling the three
 *                  blocks, so the module deliberately provides no
 *                  de-initialization interface and no MSP de-initialization
 *                  callback.
 */
#include "as32x601_hal.h"           /* module switch from as32x601_hal_conf.h */
#include "as32x601_hal_wwdg.h"      /* WWDG HAL API and register macros         */

/* The HAL_WWDG_MODULE_ENABLED switch is provided by the user configuration
 * file (as32x601_hal_conf.h, included above through as32x601_hal.h): the
 * whole implementation is compiled only while the module is enabled. */
#ifdef HAL_WWDG_MODULE_ENABLED

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Check whether the WWDG handle and its instance are valid.
 * @param  hwwdg: pointer to a WWDG_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
uint32 WWDG_HandleIsValid(WWDG_HandleTypeDef *hwwdg)
{
    if (hwwdg == NULL_PTR)
    {
        return 0U;
    }

    if (IS_WWDG_ALL_INSTANCE(hwwdg->Instance) == 0U)
    {
        return 0U;
    }

    return 1U;
}

/**
 * @brief  Check whether the handle accepts a new operation.
 * @note   ARCH-CONST-09: a handle that is BUSY (an operation is ongoing in
 *         another context) rejects any other operation with HAL_BUSY, and a
 *         handle that is not initialized (RESET) requires HAL_WWDG_Init()
 *         first and is rejected with HAL_ERROR. The recoverable state ERROR
 *         accepts a new operation directly.
 * @param  hwwdg: pointer to a WWDG_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK (accepted) / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef WWDG_CheckState(WWDG_HandleTypeDef *hwwdg)
{
    if (hwwdg->State == HAL_WWDG_STATE_BUSY)
    {
        return HAL_BUSY;
    }

    if (hwwdg->State == HAL_WWDG_STATE_RESET)
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer. The
 *         bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; the value is passed to HAL_MutexAcquire() as
 *         is (RTOS ticks; HAL_MAX_DELAY means an infinite wait).
 * @param  hwwdg: pointer to a WWDG_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef WWDG_LockHandle(WWDG_HandleTypeDef *hwwdg, uint32 Timeout)
{
#if (USE_RTOS == 1)
    if (hwwdg->LockMutex == NULL_PTR)
    {
        /* The porting layer did not create the mutex: report it instead of
         * calling the RTOS with a NULL handle */
        return HAL_ERROR;
    }

    return HAL_MutexAcquire(hwwdg->LockMutex, Timeout);
#else
    /* Prevent unused argument compilation warning: the bare-metal lock flag
     * either succeeds immediately or reports HAL_BUSY, it never waits */
    UNUSED(Timeout);

    if (hwwdg->Lock == HAL_LOCKED)
    {
        return HAL_BUSY;
    }

    hwwdg->Lock = HAL_LOCKED;

    return HAL_OK;
#endif /* USE_RTOS */
}

/**
 * @brief  Unlock the handle.
 * @param  hwwdg: pointer to a WWDG_HandleTypeDef structure.
 * @retval None
 */
void WWDG_UnlockHandle(WWDG_HandleTypeDef *hwwdg)
{
#if (USE_RTOS == 1)
    (void)HAL_MutexRelease(hwwdg->LockMutex);
#else
    hwwdg->Lock = HAL_UNLOCKED;
#endif /* USE_RTOS */
}

/* Exported functions ---------------------------------------------------------*/

/** @defgroup WWDG_Exported_Functions WWDG Exported Functions
  * @{
  */

/** @defgroup WWDG_Exported_Functions_Group1 Initialization functions
  * @{
  */

/**
 * @brief  Initialize the WWDG: write the prescaler number, the divider, the
 *         timeout value and the window counter. (NON-BLOCKING)
 * @note   This function does not start the watchdog: the configuration
 *         enable bit (CFG.EN) is set afterwards by HAL_WWDG_Cmd() with
 *         WWDG_EN_CFG / ENABLE (or by the __HAL_WWDG_START() macro), so the
 *         sequence is: configure the four values, then start the watchdog.
 * @note   The configuration structure metafields (Size / Version), the
 *         reserved words and the four values are validated at run time: an
 *         invalid configuration is rejected with HAL_ERROR and
 *         HAL_WWDG_ERROR_INVALID_PARAM without taking the lock and without
 *         changing the handle state or touching a register.
 * @note   The low level initialization callback runs only while the handle is
 *         in the reset state (MSP-04) and before the handle is locked
 *         (LOCK-06), so that an override may create an RTOS mutex and call
 *         other HAL APIs.
 * @param  hwwdg: pointer to a WWDG_HandleTypeDef structure that contains
 *         the configuration information for WWDG.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_WWDG_Init(WWDG_HandleTypeDef *hwwdg)
{
    WWDG_TypeDef *periph;

    /* Check the WWDG handle and instance */
    if (WWDG_HandleIsValid(hwwdg) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_WWDG_ALL_INSTANCE(hwwdg->Instance));
    assert_param(IS_WWDG_PRESCALER(hwwdg->Init.Prescaler));
    assert_param(IS_WWDG_DIVIDER(hwwdg->Init.Divider));
    assert_param(IS_WWDG_COUNTER(hwwdg->Init.Counter));
    assert_param(IS_WWDG_WINDOW(hwwdg->Init.Window));

    /* Run time parameter validation, so that the checks stay effective in a
     * build with the assertions disabled. The metafields of the
     * configuration structure (Size / Version, architecture spec section 22)
     * and the reserved words are validated as well. The prescaler is checked
     * against the register field width (see IS_WWDG_PRESCALER_RANGE()), while
     * the divider, the timeout and the window keep the ranges of the
     * validation macros. A rejected call neither takes the lock nor changes
     * the handle state nor touches a register. */
    if ((hwwdg->Init.Size != sizeof(WWDG_InitTypeDef)) ||
        (hwwdg->Init.Version != WWDG_INIT_VERSION) ||
        (IS_WWDG_PRESCALER_RANGE(hwwdg->Init.Prescaler) == 0U) ||
        (IS_WWDG_DIVIDER(hwwdg->Init.Divider) == 0U) ||
        (IS_WWDG_COUNTER(hwwdg->Init.Counter) == 0U) ||
        (IS_WWDG_WINDOW(hwwdg->Init.Window) == 0U) ||
        (hwwdg->Init.Reserved[0] != 0U) ||
        (hwwdg->Init.Reserved[1] != 0U))
    {
        hwwdg->ErrorCode |= HAL_WWDG_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Allocate the lock resource and initialize the low level hardware before
     * the first use, so that a handle that was never initialized cannot report
     * HAL_BUSY from a stale Lock field. LOCK-06: the MSP callback runs before
     * the handle is locked. MSP-04: it runs while the handle is in the reset
     * state only, so a repeated HAL_WWDG_Init() does not initialize the
     * hardware twice. */
    if (hwwdg->State == HAL_WWDG_STATE_RESET)
    {
        hwwdg->Lock = HAL_UNLOCKED;

        HAL_WWDG_MspInit(hwwdg);
    }

    /* Process locked */
    if (WWDG_LockHandle(hwwdg, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hwwdg->ErrorCode = HAL_WWDG_ERROR_NONE;
    hwwdg->State = HAL_WWDG_STATE_BUSY;

    /* Get the instance-level register base (WWDG0 or WWDG1) */
    periph = WWDG_GET_PERIPH(hwwdg->Instance);

    /* Disable the prescaler (PSC.EN cleared), update the prescaler number
       and re-enable the prescaler: the field can only be changed while the
       block is disabled */
    CLEAR_BIT(periph->PSC, WWDG_PSC_EN);
    CLEAR_BIT(periph->PSC, WWDG_PSC_PSCNUM);
    SET_BIT(periph->PSC, ((uint32)(hwwdg->Init.Prescaler) << WWDG_PSC_PSCNUM_Pos));
    SET_BIT(periph->PSC, WWDG_PSC_EN);

    /* Write the divider value */
    WRITE_REG(hwwdg->Instance->DIV, (uint32)(hwwdg->Init.Divider));

    /* Write the timeout value */
    WRITE_REG(hwwdg->Instance->TO, (uint32)(hwwdg->Init.Counter));

    /* Disable the window counter (WD.WDEN cleared), update the window
       counter value and re-enable the window counter: the field can only be
       changed while the block is disabled */
    CLEAR_BIT(hwwdg->Instance->WD, WWDG_WD_WDEN);
    CLEAR_BIT(hwwdg->Instance->WD, WWDG_WD_WDCNT);
    SET_BIT(hwwdg->Instance->WD, ((uint32)(hwwdg->Init.Window) << WWDG_WD_WDCNT_Pos));
    SET_BIT(hwwdg->Instance->WD, WWDG_WD_WDEN);

    hwwdg->State = HAL_WWDG_STATE_READY;

    /* Release Lock */
    WWDG_UnlockHandle(hwwdg);

    return HAL_OK;
}

/**
 * @brief  Initialize the WWDG MSP. Weak function; the default implementation
 *         enables the clock of the selected watchdog instance and releases its
 *         reset through the SMU.
 * @note   The WWDG0 clock is gated by the SMU APB0CFGR register (WWDG0EN) and
 *         the WWDG1 clock by the APB1CFGR register (WWDG1EN); the reset bit is
 *         released by SETTING it (SET = released, CLEAR = reset asserted),
 *         which is what the register reset value (every RST bit set) and the
 *         __HAL_SMU_WWDGx_RELEASE_RESET() macros assume. The device level
 *         register and bit names are used so that the module keeps depending
 *         on the device header only.
 * @param  hwwdg: pointer to a WWDG_HandleTypeDef structure that contains
 *         the configuration information for WWDG.
 * @retval None
 */
__weak void HAL_WWDG_MspInit(WWDG_HandleTypeDef *hwwdg)
{
    /* A NULL handle selects no instance: leave the clock gating to the caller
     * (the public entry points never call this hook with a NULL handle) */
    if (hwwdg == NULL_PTR)
    {
        return;
    }

    if (WWDG_GET_PERIPH(hwwdg->Instance) == WWDG0)
    {
        SMU->APB0CFGR |= SMU_APB0CFGR_WWDG0EN;
        SMU->APB0CFGR |= SMU_APB0CFGR_WWDG0RST;
    }
    else
    {
        SMU->APB1CFGR |= SMU_APB1CFGR_WWDG1EN;
        SMU->APB1CFGR |= SMU_APB1CFGR_WWDG1RST;
    }
}

/**
  * @}
  */

/** @defgroup WWDG_Exported_Functions_Group2 IO operation functions
  * @{
  */

/**
 * @brief  Refresh the WWDG (reload the watchdog counter). (NON-BLOCKING)
 * @note   The chip WWDG counter is refreshed by writing the key value
 *         0x2F3E5D8A into the WWDG_CLR register.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_WWDG_Init() is required first).
 * @param  hwwdg: pointer to a WWDG_HandleTypeDef structure that contains
 *         the configuration information for WWDG.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_WWDG_Refresh(WWDG_HandleTypeDef *hwwdg)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the WWDG handle and instance */
    if (WWDG_HandleIsValid(hwwdg) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_WWDG_ALL_INSTANCE(hwwdg->Instance));

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_WWDG_Init() is
     * required first) */
    status = WWDG_CheckState(hwwdg);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (WWDG_LockHandle(hwwdg, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hwwdg->ErrorCode = HAL_WWDG_ERROR_NONE;
    hwwdg->State = HAL_WWDG_STATE_BUSY;

    /* Reload the WWDG counter with the refresh key value */
    __HAL_WWDG_RELOAD_COUNTER(hwwdg);

    hwwdg->State = HAL_WWDG_STATE_READY;

    /* Release Lock */
    WWDG_UnlockHandle(hwwdg);

    return HAL_OK;
}

/**
 * @brief  Get the WWDG counter value. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock and applies no state gate, so
 *         it is callable from an interrupt context.
 * @param  hwwdg: pointer to a WWDG_HandleTypeDef structure that contains
 *         the configuration information for WWDG.
 * @retval The WWDG counter value (16-bit); 0 for an invalid handle or
 *         instance.
 */
uint16 HAL_WWDG_GetCounter(WWDG_HandleTypeDef *hwwdg)
{
    /* Check the WWDG handle and instance */
    if (WWDG_HandleIsValid(hwwdg) == 0U)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_WWDG_ALL_INSTANCE(hwwdg->Instance));

    /* Return the WWDG counter value */
    return (uint16)(READ_REG(hwwdg->Instance->CNT) & WWDG_CNT_CNTNUM);
}

/**
 * @brief  Check whether the specified WWDG channel bark flag is set or
 *         not. (NON-BLOCKING)
 * @note   The bark flags are read-only (WWDG_DSTA is a status register): they
 *         are cleared by the hardware or through the FCU, not by software.
 * @note   Read-only interface: it takes no lock and applies no state gate, so
 *         it is callable from an interrupt context.
 * @param  hwwdg:   pointer to a WWDG_HandleTypeDef structure that contains
 *         the configuration information for WWDG.
 * @param  BK_Flag: specifies the bark flag to check.
 *         This parameter can be one of the following values:
 *            @arg WWDG_FLAG_BK0
 *            @arg WWDG_FLAG_BK1
 *            @arg WWDG_FLAG_BK2
 *            @arg WWDG_FLAG_BK3
 * @retval The new state of WWDG bark flag (SET or RESET); RESET for an
 *         invalid handle, instance or flag.
 */
FlagStatus HAL_WWDG_GetBKStatus(WWDG_HandleTypeDef *hwwdg, uint32 BK_Flag)
{
    WWDG_TypeDef *periph;

    /* Check the WWDG handle and instance */
    if (WWDG_HandleIsValid(hwwdg) == 0U)
    {
        return RESET;
    }

    /* Check the parameters */
    assert_param(IS_WWDG_ALL_INSTANCE(hwwdg->Instance));
    assert_param(IS_WWDG_BARK_FLAG(BK_Flag));

    /* Run time flag validation, so that the check stays effective in a build
     * with the assertions disabled: an unknown flag reads RESET */
    if (IS_WWDG_BARK_FLAG(BK_Flag) == 0U)
    {
        return RESET;
    }

    /* Get the instance-level register base (WWDG0 or WWDG1) */
    periph = WWDG_GET_PERIPH(hwwdg->Instance);

    /* Check whether the specified bark flag is set */
    if ((READ_REG(periph->DSTA) & BK_Flag) != (uint32)RESET)
    {
        /* The specified WWDG channel bark flag is set */
        return SET;
    }
    else
    {
        /* The specified WWDG channel bark flag is reset */
        return RESET;
    }
}

/**
  * @}
  */

/** @defgroup WWDG_Exported_Functions_Group3 State and error functions
  * @{
  */

/**
 * @brief  Return the WWDG handle state. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock and applies no state gate, so
 *         it is callable from an interrupt context.
 * @param  hwwdg: pointer to a WWDG_HandleTypeDef structure.
 * @retval HAL_WWDG_StateTypeDef: the current handle state
 *         (HAL_WWDG_STATE_RESET for an invalid handle or instance).
 */
HAL_WWDG_StateTypeDef HAL_WWDG_GetState(WWDG_HandleTypeDef *hwwdg)
{
    /* Check the WWDG handle and instance */
    if (WWDG_HandleIsValid(hwwdg) == 0U)
    {
        return HAL_WWDG_STATE_RESET;
    }

    return hwwdg->State;
}

/**
 * @brief  Return the WWDG error code. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock and applies no state gate, so
 *         it is callable from an interrupt context.
 * @param  hwwdg: pointer to a WWDG_HandleTypeDef structure.
 * @retval uint32: the WWDG error code (HAL_WWDG_ERROR_xxx), 0 for an invalid
 *         handle or instance.
 */
uint32 HAL_WWDG_GetError(WWDG_HandleTypeDef *hwwdg)
{
    /* Check the WWDG handle and instance */
    if (WWDG_HandleIsValid(hwwdg) == 0U)
    {
        return HAL_WWDG_ERROR_NONE;
    }

    return hwwdg->ErrorCode;
}

/**
  * @}
  */

/**
  * @}
  */

/* Exported functions ---------------------------------------------------------*/

/** @defgroup WWDG_Exported_Functions WWDG Exported Functions
  * @{
  */

/** @defgroup WWDG_Exported_Functions_Group1 Enable and lock functions
  * @{
  */

/**
 * @brief  Enable or disable the WWDG prescaler, configuration or window
 *         counter block. (NON-BLOCKING)
 * @note   The watchdog is effectively started when the prescaler enable
 *         (PSC.EN, set by HAL_WWDG_Init), the window counter enable
 *         (WD.WDEN, set by HAL_WWDG_Init) and the configuration enable
 *         (CFG.EN) are all set.
 * @note   The selector and the functional state are validated at run time in
 *         front of the first register access, so an invalid selector is
 *         rejected with HAL_ERROR and no register is written (the lock is not
 *         taken either). ARCH-CONST-09: the call is rejected with HAL_BUSY
 *         while another operation is ongoing and with HAL_ERROR when the
 *         handle has not been initialized (HAL_WWDG_Init() is required first).
 * @param  hwwdg:    pointer to a WWDG_HandleTypeDef structure that
 *         contains the configuration information for WWDG.
 * @param  Enable:   specifies the WWDG block to enable / disable.
 *         This parameter can be:
 *            @arg WWDG_EN_PSC
 *            @arg WWDG_EN_CFG
 *            @arg WWDG_EN_WD
 * @param  NewState: new state of the selected WWDG block (ENABLE or
 *         DISABLE).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_WWDG_Cmd(WWDG_HandleTypeDef *hwwdg, uint32 Enable, FunctionalState NewState)
{
    __IO uint32 *enreg_address;
    WWDG_TypeDef *periph;
    uint32 tmreg = 0;
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the WWDG handle and instance */
    if (WWDG_HandleIsValid(hwwdg) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_WWDG_ALL_INSTANCE(hwwdg->Instance));
    assert_param(IS_WWDG_EN(Enable));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Run time parameter validation, so that the checks stay effective in a
     * build with the assertions disabled: an invalid selector or functional
     * state is rejected before the lock is taken and before any register is
     * accessed (the register pointer stays uninitialized otherwise) */
    if ((IS_WWDG_EN(Enable) == 0U) || (IS_FUNCTIONAL_STATE(NewState) == 0U))
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_WWDG_Init() is
     * required first) */
    status = WWDG_CheckState(hwwdg);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (WWDG_LockHandle(hwwdg, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hwwdg->ErrorCode = HAL_WWDG_ERROR_NONE;
    hwwdg->State = HAL_WWDG_STATE_BUSY;

    /* Get the instance-level register base (WWDG0 or WWDG1) */
    periph = WWDG_GET_PERIPH(hwwdg->Instance);

    /* Check if Enable is WWDG_EN_PSC, WWDG_EN_CFG or WWDG_EN_WD */
    if (Enable == WWDG_EN_PSC)
    {
        /* Get the value of the prescaler register and its enable bit */
        enreg_address = &(periph->PSC);
        tmreg = WWDG_PSC_EN;
    }
    else if (Enable == WWDG_EN_CFG)
    {
        /* Get the value of the configuration register and its enable bit */
        enreg_address = &(hwwdg->Instance->CFG);
        tmreg = WWDG_CFG_EN;
    }
    else
    {
        /* Get the value of the window counter register and its enable bit */
        enreg_address = &(hwwdg->Instance->WD);
        tmreg = WWDG_WD_WDEN;
    }

    if (NewState != DISABLE)
    {
        /* Enable the selected WWDG block */
        SET_BIT(*enreg_address, tmreg);
    }
    else
    {
        /* Disable the selected WWDG block */
        CLEAR_BIT(*enreg_address, tmreg);
    }

    hwwdg->State = HAL_WWDG_STATE_READY;

    /* Release Lock */
    WWDG_UnlockHandle(hwwdg);

    return HAL_OK;
}

/**
 * @brief  Lock or unlock the WWDG prescaler or configuration block.
 *         (NON-BLOCKING)
 * @note   A locked block rejects further writes of its registers.
 * @note   The selector and the functional state are validated at run time in
 *         front of the first register access, so an invalid selector is
 *         rejected with HAL_ERROR and no register is written (the lock is not
 *         taken either). ARCH-CONST-09: the call is rejected with HAL_BUSY
 *         while another operation is ongoing and with HAL_ERROR when the
 *         handle has not been initialized (HAL_WWDG_Init() is required first).
 * @param  hwwdg:    pointer to a WWDG_HandleTypeDef structure that
 *         contains the configuration information for WWDG.
 * @param  Lock:     specifies the WWDG block to lock / unlock.
 *         This parameter can be:
 *            @arg WWDG_LOCK_PSC
 *            @arg WWDG_LOCK_CFG
 * @param  NewState: new state of the selected WWDG lock (ENABLE or
 *         DISABLE).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_WWDG_LockCmd(WWDG_HandleTypeDef *hwwdg, uint32 Lock, FunctionalState NewState)
{
    __IO uint32 *enreg_address;
    WWDG_TypeDef *periph;
    uint32 tmreg = 0;
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the WWDG handle and instance */
    if (WWDG_HandleIsValid(hwwdg) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_WWDG_ALL_INSTANCE(hwwdg->Instance));
    assert_param(IS_WWDG_LOCK(Lock));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Run time parameter validation, so that the checks stay effective in a
     * build with the assertions disabled: an invalid selector or functional
     * state is rejected before the lock is taken and before any register is
     * accessed (the register pointer stays uninitialized otherwise) */
    if ((IS_WWDG_LOCK(Lock) == 0U) || (IS_FUNCTIONAL_STATE(NewState) == 0U))
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_WWDG_Init() is
     * required first) */
    status = WWDG_CheckState(hwwdg);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (WWDG_LockHandle(hwwdg, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hwwdg->ErrorCode = HAL_WWDG_ERROR_NONE;
    hwwdg->State = HAL_WWDG_STATE_BUSY;

    /* Get the instance-level register base (WWDG0 or WWDG1) */
    periph = WWDG_GET_PERIPH(hwwdg->Instance);

    /* Check if Lock is WWDG_LOCK_PSC or WWDG_LOCK_CFG */
    if (Lock == WWDG_LOCK_PSC)
    {
        /* Get the value of the prescaler register and its lock bit */
        enreg_address = &(periph->PSC);
        tmreg = WWDG_PSC_LOCK;
    }
    else
    {
        /* Get the value of the configuration register and its lock bit */
        enreg_address = &(hwwdg->Instance->CFG);
        tmreg = WWDG_CFG_LOCK;
    }

    if (NewState != DISABLE)
    {
        /* Lock the selected WWDG block */
        SET_BIT(*enreg_address, tmreg);
    }
    else
    {
        /* Unlock the selected WWDG block */
        CLEAR_BIT(*enreg_address, tmreg);
    }

    hwwdg->State = HAL_WWDG_STATE_READY;

    /* Release Lock */
    WWDG_UnlockHandle(hwwdg);

    return HAL_OK;
}

/**
  * @}
  */

/**
  * @}
  */

#endif /* HAL_WWDG_MODULE_ENABLED */

/*****END OF FILE*****/
