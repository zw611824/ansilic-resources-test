/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):    Xiamen Guoke Anxin Technology Co., LTD
 * FileName:         as32x601_hal_wwdg.h
 * Author:           ANSILIC APPLICATION GROUP
 * Version:          V1.4
 * Date:             2026/10/08
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.1     add the module guard (HAL_WWDG_MODULE_ENABLED) around the whole implementation
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.2     put the as32x601_hal.h include first (module switch from the conf) before the module headers
 *     ANSILIC APPLICATION GROUP  2026/09/21     1.3     bring the module up to the Medium level
 *                                                       of the architecture specification: add the
 *                                                       lock / state / error handle fields, the
 *                                                       shared lock and state helpers, the state
 *                                                       and error reporting interfaces, the busy /
 *                                                       reset state gate, the run time parameter
 *                                                       validation in front of the first register
 *                                                       access, the msp de-initialization note, the
 *                                                       blocking marker of every public prototype,
 *                                                       align the version of the four module files
 *                                                       and describe the module without referring to
 *                                                       an external implementation
 *     ANSILIC APPLICATION GROUP  2026/10/08     1.4     restate the bark flag note: the values stay hard-coded
 *                                                       and now match the corrected device level
 *                                                       WWDG_DSTA_BK0..3 masks (as32x601.h V1.6)
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Window Watchdog
 *                  (WWDG) peripheral:
 *                  - Initialization (HAL_WWDG_Init): prescaler number
 *                    (PSC.PSCNUM), divider number (DIV.DIVNUM), timeout
 *                    value (TO.BVAL) and window counter (WD.WDCNT)
 *                    configuration;
 *                  - IO operation functions (HAL_WWDG_Refresh /
 *                    HAL_WWDG_GetCounter / HAL_WWDG_GetBKStatus);
 *                  - State and error reporting (HAL_WWDG_GetState /
 *                    HAL_WWDG_GetError).
 *                  The chip-specific enable / lock control is provided by
 *                  this driver (HAL_WWDG_Cmd / HAL_WWDG_LockCmd).
 *                  This driver depends on as32x601_hal_def.h (HAL common
 *                  types and utilities). The WWDG0 peripheral is clocked
 *                  by the APBBus0 domain and the WWDG1 peripheral by the
 *                  APBBus1 domain, both gated by the SMU (see the
 *                  WWDG0_CLK_ENABLE() / WWDG1_CLK_ENABLE() macros of
 *                  as32x601_smu.h): the default HAL_WWDG_MspInit()
 *                  implementation enables the clock of the selected
 *                  instance and releases its reset, and an override may
 *                  replace it.
 *                  The chip WWDG has no Early Wakeup Interrupt (EWI): the
 *                  bark flags (DSTA.BK0..3) are read-only status bits and
 *                  the interrupt is routed through the FCU (fault control
 *                  unit) instead of a dedicated WWDG PLIC line, so no
 *                  HAL_WWDG_IRQHandler() / HAL_WWDG_EarlyWakeupCallback()
 *                  is provided. The counter value is read through the
 *                  read-only CNT register and the watchdog is refreshed by
 *                  writing the key value into the WWDG_CLR register.
 *                  The module takes the Medium level of the architecture
 *                  specification: the handle carries the resource lock,
 *                  the state and the error code, the register writing
 *                  interfaces (HAL_WWDG_Init / HAL_WWDG_Refresh and the
 *                  extended HAL_WWDG_Cmd / HAL_WWDG_LockCmd) are
 *                  serialized by the handle lock and gated by the handle
 *                  state, while the read-only interfaces (the counter and
 *                  bark queries, the state and error reporting) take no
 *                  lock and no state gate, so they stay callable from an
 *                  interrupt context. No operation of this module waits on
 *                  the hardware, so the timeout state and the timeout error
 *                  code are not produced and are not defined.
 * @complexity  Medium
 *              State machine + lock, register primitives only (no blocking
 *              operation, no interrupt mode of its own).
 */
#ifndef __AS32X601_HAL_WWDG_H
#define __AS32X601_HAL_WWDG_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "as32x601_hal_def.h"       /* HAL common types and utilities          */
#include "as32x601.h"               /* WWDG_TypeDef, WWDG_Channel_TypeDef,     */
                                    /* WWDG0/WWDG1, WWDGx_Channely, reg bits   */

/**
 * @brief WWDG HAL driver module version.
 * @note  0x0100U = V1.0. Bumped only on breaking API changes (architecture
 *        spec COMPAT-13/14/15).
 */
#define __HAL_WWDG_MODULE_VERSION  0x0100U

/* Exported types ------------------------------------------------------------*/

/** @defgroup WWDG_Exported_Types WWDG Exported Types
  * @{
  */

/**
 * @brief WWDG Init Structure definition
 * @note  The Prescaler field maps the WWDG_PSC.PSCNUM prescaler number (a
 *        plain value in the PSCNUM register field range, no discrete
 *        prescaler enum). The Counter field maps the WWDG_TO.BVAL timeout
 *        value (0-65535, 16-bit wide). The Window field maps the
 *        WWDG_WD.WDCNT window counter value (0-65535, 16-bit wide). The
 *        Divider field is a chip-specific extension that maps the
 *        WWDG_DIV.DIVNUM divider (2-65535).
 * @note  This structure follows the Version+Size compatibility mechanism
 *        (architecture spec section 22): the user must clear the structure
 *        (__HAL_CLEAR_STRUCT / memset), set the Size and Version metafields
 *        before filling the business fields.
 */
typedef struct
{
    uint32 Size;   /*!< sizeof(WWDG_InitTypeDef), must be set by
                                                  the user after clearing the structure */
    uint32 Version;   /*!< Structure semantic version: @ref
                                                  WWDG_INIT_VERSION (WWDG_INIT_V1 = 0x0100U) */
    uint32 Prescaler;   /*!< WWDG prescaler number (PSC.PSCNUM, 2-255)
                                                      */
    uint32 Divider;   /*!< WWDG divider number (DIV.DIVNUM, 2-65535)
                                                      */
    uint32 Counter;   /*!< WWDG timeout value (TO.BVAL, 0-65535)
                                                       */
    uint32 Window;   /*!< WWDG window counter value (WD.WDCNT,
                                                  0-65535)  */
    uint32 Reserved[2];   /*!< Reserved for future extension (must be 0)
                                                     */
} WWDG_InitTypeDef;

/**
 * @brief WWDG / init structure version macros.
 * @note  WWDG_INIT_V1 is the current version. Future versions (e.g. V2 with
 *        new fields) must be appended after the existing fields without
 *        changing the layout (architecture spec section 22.5).
 */
#define WWDG_INIT_V1  0x0100U   /*!< WWDG Init structure version V1.0 */
#define WWDG_INIT_VERSION  WWDG_INIT_V1   /*!< Current WWDG Init structure version */

/**
 * @brief HAL WWDG state structures definition.
 * @note  The timeout recovery state of the specification is not produced by
 *        this module: no operation of the WWDG waits on the hardware, so a
 *        timeout state and a timeout error code are not defined.
 */
typedef enum
{
    HAL_WWDG_STATE_RESET      = 0x00U, /*!< Peripheral not initialized           */
    HAL_WWDG_STATE_READY      = 0x01U, /*!< Peripheral initialized and ready     */
    HAL_WWDG_STATE_BUSY       = 0x02U, /*!< An internal process is ongoing       */
    HAL_WWDG_STATE_ERROR      = 0x03U  /*!< WWDG error state                     */
} HAL_WWDG_StateTypeDef;

/**
 * @brief WWDG Handle Structure definition
 * @note  The handle carries the configuration, the resource lock, the state
 *        and the error code of the module (architecture spec section 4.1,
 *        Medium level). The Lock field is allocated by HAL_WWDG_Init() and
 *        the state starts in RESET, so the handle shall be cleared
 *        (__HAL_CLEAR_STRUCT / memset) before its first use.
 * @note  The Instance field points to the WWDG channel registers
 *        (WWDG0_Channel0..WWDG1_Channel3): the instance-level registers
 *        (PSC / DSTA) are addressed through the WWDG_GET_PERIPH() private
 *        macro.
 */
typedef struct __WWDG_HandleTypeDef
{
    WWDG_Channel_TypeDef       *Instance;   /*!< Channel register base address
                                                     */
    WWDG_InitTypeDef           Init;   /*!< WWDG required parameters
                                                      */
    HAL_LockTypeDef            Lock;   /*!< Locking object                         */
    __IO HAL_WWDG_StateTypeDef State;  /*!< WWDG state                             */
    __IO uint32                ErrorCode;   /*!< WWDG error code                    */
#if (USE_RTOS == 1)
    HAL_MutexTypeDef           LockMutex;   /*!< RTOS mutex handle (created by the
                                                 user porting layer)             */
#endif /* USE_RTOS */
} WWDG_HandleTypeDef;
/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @defgroup WWDG_Exported_Constants WWDG Exported Constants
  * @{
  */

/** @defgroup WWDG_Error_Code WWDG Error Code
  * @{
  */
#define HAL_WWDG_ERROR_NONE           ((uint32)0x00000000U) /*!< No error                     */
#define HAL_WWDG_ERROR_INVALID_PARAM  ((uint32)0x00000001U) /*!< Invalid parameter or rejected
                                                                 operation                      */
/**
  * @}
  */

/** @defgroup WWDG_Flags_Definitions WWDG Flags Definitions
  * @brief  WWDG bark flag definition. The flags map the read-only
  *         WWDG_DSTA register bits: channel 0..3 bark status.
  * @note   The values are hard-coded so that the flags stay self contained,
  *         and they match the device level WWDG_DSTA_BK0..3 masks, whose bit
  *         positions were corrected in as32x601.h V1.6 (the BK1..BK3 _DPos
  *         fields had been copied from BK0 before that).
  * @{
  */
#define WWDG_FLAG_BK0                       ((uint32)0x00000001)  /*!< WWDG channel 0 bark flag */
#define WWDG_FLAG_BK1                       ((uint32)0x00000002)  /*!< WWDG channel 1 bark flag */
#define WWDG_FLAG_BK2                       ((uint32)0x00000004)  /*!< WWDG channel 2 bark flag */
#define WWDG_FLAG_BK3                       ((uint32)0x00000008)  /*!< WWDG channel 3 bark flag */
/**
  * @}
  */

/**
  * @}
  */

/* Exported macro ------------------------------------------------------------*/
/** @defgroup WWDG_Exported_Macros WWDG Exported Macros
  * @{
  */

/**
 * @brief  Reset the handle State field.
 * @note   Must be used before passing a local handle to HAL_WWDG_Init() the
 *         first time, so that the lock resource is allocated and the low
 *         level initialization callback is reached again.
 */
#define __HAL_WWDG_RESET_HANDLE_STATE(__HANDLE__) ((__HANDLE__)->State = 0U)

/**
 * @brief  Start the WWDG peripheral.
 * @note   This macro sets the WWDG_CFG.CFG_EN bit. The prescaler enable
 *         (PSC.EN) and the window counter enable (WD.WDEN) are set by
 *         HAL_WWDG_Init() before it returns, so starting the watchdog after
 *         an initialization enables all three blocks.
 * @param  __HANDLE__: specifies the WWDG handle.
 * @retval None
 */
#define __HAL_WWDG_START(__HANDLE__)            SET_BIT((__HANDLE__)->Instance->CFG, WWDG_CFG_EN)

/**
 * @brief  Reload WWDG counter with the refresh key value.
 * @note   The chip WWDG counter is refreshed by writing the key value
 *         0x2F3E5D8A into the WWDG_CLR register (there is no key register).
 * @param  __HANDLE__: specifies the WWDG handle.
 * @retval None
 */
#define __HAL_WWDG_RELOAD_COUNTER(__HANDLE__)   WRITE_REG((__HANDLE__)->Instance->CLR, WWDG_CLR_KEY_RESET)

/**
 * @brief  Get the WWDG counter value.
 * @param  __HANDLE__: specifies the WWDG handle.
 * @retval The WWDG counter value (16-bit).
 */
#define __HAL_WWDG_GET_COUNTER(__HANDLE__)      ((uint16)(READ_REG((__HANDLE__)->Instance->CNT) & WWDG_CNT_CNTNUM))

/**
 * @brief  Check whether the specified WWDG bark flag is set or not.
 * @note   The bark flags are read-only (WWDG_DSTA is a status register):
 *         they are cleared by hardware or through the FCU, not by
 *         software.
 * @param  __HANDLE__: specifies the WWDG handle.
 * @param  __FLAG__: specifies the flag to check.
 *         This parameter can be one of the following values:
 *            @arg WWDG_FLAG_BK0
 *            @arg WWDG_FLAG_BK1
 *            @arg WWDG_FLAG_BK2
 *            @arg WWDG_FLAG_BK3
 * @retval The new state of WWDG flag (SET or RESET).
 */
#define __HAL_WWDG_GET_FLAG(__HANDLE__, __FLAG__) (((READ_REG(WWDG_GET_PERIPH((__HANDLE__)->Instance)->DSTA) & (__FLAG__)) == (__FLAG__)))
/**
  * @}
  */

/* Include WWDG HAL Extension module */

/* Exported functions --------------------------------------------------------*/
/** @addtogroup WWDG_Exported_Functions
  * @{
  */

/** @addtogroup WWDG_Exported_Functions_Group1 Initialization functions
  * @{
  */

/**
 * @brief  Initialize the WWDG: write the prescaler number, the divider,
 *         the timeout value and the window counter. (NON-BLOCKING)
 * @note   This function does not start the watchdog: the configuration
 *         enable bit (CFG.EN) is set afterwards by HAL_WWDG_Cmd() with
 *         WWDG_EN_CFG / ENABLE (or by the __HAL_WWDG_START() macro), so the
 *         sequence is: configure the four values, then start the watchdog.
 * @note   The low level initialization callback (HAL_WWDG_MspInit) runs
 *         before the handle is locked and only while the handle is in the
 *         reset state (architecture rules MSP-04 and LOCK-06), so an
 *         override may create an RTOS mutex and call other HAL APIs.
 * @note   The configuration structure metafields (Size / Version), the
 *         reserved words and the four values are validated at run time: an
 *         invalid configuration is rejected with HAL_ERROR and
 *         HAL_WWDG_ERROR_INVALID_PARAM without taking the lock and without
 *         changing the handle state or touching a register.
 * @param  hwwdg: pointer to a WWDG_HandleTypeDef structure that contains
 *         the configuration information for WWDG.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (NULL pointer, invalid instance, invalid
 *         configuration).
 */
HAL_StatusTypeDef HAL_WWDG_Init(WWDG_HandleTypeDef *hwwdg);

/**
 * @brief  Initialize the WWDG MSP. Weak function; the default
 *         implementation enables the clock of the selected watchdog instance
 *         and releases its reset through the SMU.
 * @note   The WWDG0 clock is gated by the SMU APB0CFGR register
 *         (WWDG0_CLK_ENABLE()) and the WWDG1 clock by the APB1CFGR register
 *         (WWDG1_CLK_ENABLE()); the reset bit is released by SETTING it
 *         (SET = released, CLEAR = reset asserted).
 * @param  hwwdg: pointer to a WWDG_HandleTypeDef structure that contains
 *         the configuration information for WWDG.
 * @retval None
 */
void HAL_WWDG_MspInit(WWDG_HandleTypeDef *hwwdg);
/**
  * @}
  */

/** @addtogroup WWDG_Exported_Functions_Group2 IO operation functions
  * @{
  */

/**
 * @brief  Refresh the WWDG (reload the watchdog counter). (NON-BLOCKING)
 * @note   The chip WWDG counter is refreshed by writing the key value
 *         0x2F3E5D8A into the WWDG_CLR register.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_WWDG_Init() is required first). The register
 *         access is serialized by the handle lock.
 * @param  hwwdg: pointer to a WWDG_HandleTypeDef structure that contains
 *         the configuration information for WWDG.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_WWDG_Refresh(WWDG_HandleTypeDef *hwwdg);

/**
 * @brief  Get the WWDG counter value. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock and applies no state gate, so
 *         it is callable from an interrupt context.
 * @param  hwwdg: pointer to a WWDG_HandleTypeDef structure that contains
 *         the configuration information for WWDG.
 * @retval The WWDG counter value (16-bit); 0 for an invalid handle or
 *         instance.
 */
uint16 HAL_WWDG_GetCounter(WWDG_HandleTypeDef *hwwdg);

/**
 * @brief  Check whether the specified WWDG channel bark flag is set or
 *         not. (NON-BLOCKING)
 * @note   The bark flags are read-only (WWDG_DSTA is a status register).
 * @note   Read-only interface: it takes no lock and applies no state gate, so
 *         it is callable from an interrupt context.
 * @param  hwwdg:   pointer to a WWDG_HandleTypeDef structure that contains
 *         the configuration information for WWDG.
 * @param  BK_Flag: specifies the bark flag to check.
 *         This parameter can be one of the following values:
 *            @arg WWDG_FLAG_BK0
 *            @arg WWDG_FLAG_BK1
 *            @arg WWDG_FLAG_BK2
 *            @arg WWDG_FLAG_BK3
 * @retval The new state of WWDG bark flag (SET or RESET); RESET for an
 *         invalid handle, instance or flag.
 */
FlagStatus HAL_WWDG_GetBKStatus(WWDG_HandleTypeDef *hwwdg, uint32 BK_Flag);
/**
  * @}
  */

/** @addtogroup WWDG_Exported_Functions_Group3 State and error functions
  * @{
  */

/**
 * @brief  Return the WWDG handle state. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock and applies no state gate, so
 *         it is callable from an interrupt context.
 * @param  hwwdg: pointer to a WWDG_HandleTypeDef structure.
 * @retval HAL_WWDG_StateTypeDef: the current handle state
 *         (HAL_WWDG_STATE_RESET for an invalid handle or instance).
 */
HAL_WWDG_StateTypeDef HAL_WWDG_GetState(WWDG_HandleTypeDef *hwwdg);

/**
 * @brief  Return the WWDG error code. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock and applies no state gate, so
 *         it is callable from an interrupt context.
 * @param  hwwdg: pointer to a WWDG_HandleTypeDef structure.
 * @retval uint32: the WWDG error code (HAL_WWDG_ERROR_xxx), 0 for an invalid
 *         handle or instance.
 */
uint32 HAL_WWDG_GetError(WWDG_HandleTypeDef *hwwdg);
/**
  * @}
  */

/**
  * @}
  */

/* Exported types ------------------------------------------------------------*/

/* Exported constants --------------------------------------------------------*/

/** @addtogroup WWDG_Exported_Constants WWDG Exported Constants
  * @{
  */

/** @defgroup WWDG_Enable_Definitions WWDG Enable Definitions
  * @note  The values are selector codes (they are not register bit values):
  *        they select which block (prescaler / configuration / window
  *        counter) is enabled or disabled by HAL_WWDG_Cmd().
  * @{
  */
#define WWDG_EN_PSC                     ((uint32)0x10000000)  /*!< Enable / disable the WWDG prescaler (PSC.EN) */
#define WWDG_EN_CFG                     ((uint32)0x20000000)  /*!< Enable / disable the WWDG configuration (CFG.EN) */
#define WWDG_EN_WD                      ((uint32)0x40000000)  /*!< Enable / disable the WWDG window counter (WD.WDEN) */

/* Legacy selector aliases of the same values */
#define W_PSC_EN                        WWDG_EN_PSC
#define W_CFG_EN                        WWDG_EN_CFG
#define W_WD_EN                         WWDG_EN_WD
/**
  * @}
  */

/** @defgroup WWDG_Lock_Definitions WWDG Lock Definitions
  * @note  The values are selector codes: they select which block (prescaler
  *        / configuration) is locked or unlocked by HAL_WWDG_LockCmd().
  * @{
  */
#define WWDG_LOCK_PSC                   ((uint32)0x80000000)  /*!< Lock / unlock the WWDG prescaler (PSC.LOCK) */
#define WWDG_LOCK_CFG                   ((uint32)0xA0000000)  /*!< Lock / unlock the WWDG configuration (CFG.LOCK) */

/* Legacy selector aliases of the same values */
#define W_PSC_LOCK                      WWDG_LOCK_PSC
#define W_CFG_LOCK                      WWDG_LOCK_CFG
/**
  * @}
  */

/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/
/** @addtogroup WWDG_Exported_Functions
  * @{
  */

/** @addtogroup WWDG_Exported_Functions_Group1 Enable and lock functions
  * @{
  */

/**
 * @brief  Enable or disable the WWDG prescaler, configuration or window
 *         counter block. (NON-BLOCKING)
 * @note   The watchdog is effectively started when the prescaler enable
 *         (PSC.EN, set by HAL_WWDG_Init), the window counter enable
 *         (WD.WDEN, set by HAL_WWDG_Init) and the configuration enable
 *         (CFG.EN) are all set.
 * @note   The selector and the functional state are validated at run time in
 *         front of the first register access, so an invalid selector is
 *         rejected with HAL_ERROR and no register is written (the lock is not
 *         taken either). ARCH-CONST-09: the call is rejected with HAL_BUSY
 *         while another operation is ongoing and with HAL_ERROR when the
 *         handle has not been initialized (HAL_WWDG_Init() is required
 *         first).
 * @param  hwwdg:    pointer to a WWDG_HandleTypeDef structure that
 *         contains the configuration information for WWDG.
 * @param  Enable:   specifies the WWDG block to enable / disable.
 *         This parameter can be:
 *            @arg WWDG_EN_PSC
 *            @arg WWDG_EN_CFG
 *            @arg WWDG_EN_WD
 * @param  NewState: new state of the selected WWDG block (ENABLE or
 *         DISABLE).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid selector, not initialized).
 */
HAL_StatusTypeDef HAL_WWDG_Cmd(WWDG_HandleTypeDef *hwwdg, uint32 Enable,
                                 FunctionalState NewState);

/**
 * @brief  Lock or unlock the WWDG prescaler or configuration block.
 *         (NON-BLOCKING)
 * @note   A locked block rejects further writes of its registers.
 * @note   The selector and the functional state are validated at run time in
 *         front of the first register access, so an invalid selector is
 *         rejected with HAL_ERROR and no register is written (the lock is not
 *         taken either). ARCH-CONST-09: the call is rejected with HAL_BUSY
 *         while another operation is ongoing and with HAL_ERROR when the
 *         handle has not been initialized (HAL_WWDG_Init() is required
 *         first).
 * @param  hwwdg:    pointer to a WWDG_HandleTypeDef structure that
 *         contains the configuration information for WWDG.
 * @param  Lock:     specifies the WWDG block to lock / unlock.
 *         This parameter can be:
 *            @arg WWDG_LOCK_PSC
 *            @arg WWDG_LOCK_CFG
 * @param  NewState: new state of the selected WWDG lock (ENABLE or
 *         DISABLE).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid selector, not initialized).
 */
HAL_StatusTypeDef HAL_WWDG_LockCmd(WWDG_HandleTypeDef *hwwdg, uint32 Lock,
                                     FunctionalState NewState);
/**
  * @}
  */

/**
  * @}
  */

/* Private types -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private constants ---------------------------------------------------------*/
/* Private macros ------------------------------------------------------------*/
/** @addtogroup WWDG_Private_Macros WWDG Private Macros
  * @{
  */

/** @addtogroup WWDG_IS_WWDG_Definitions WWDG Private macros to check input parameters
  * @{
  */
#define IS_WWDG_EN(EN)                    (((EN) == WWDG_EN_PSC) || \
                                           ((EN) == WWDG_EN_CFG) || \
                                           ((EN) == WWDG_EN_WD))

#define IS_WWDG_LOCK(LOCK)                (((LOCK) == WWDG_LOCK_PSC) || ((LOCK) == WWDG_LOCK_CFG))

/* Legacy selector name kept as an alias of the current name */
#define IS_WWDG_CONFIG_EN                 IS_WWDG_EN
#define IS_WWDG_CONFIG_LOCK               IS_WWDG_LOCK
/**
  * @}
  */

/**
  * @}
  */

/* Private types -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private constants ---------------------------------------------------------*/
/** @defgroup WWDG_Private_Constants WWDG Private Constants
  * @{
  */
/* WWDG_CLR register refresh key value (hardware defined). */
#define WWDG_CLR_KEY_RESET              ((uint32)0x2F3E5D8A)
/**
  * @}
  */

/** @defgroup WWDG_Private_Macros WWDG Private Macros
  * @{
  */

/**
 * @brief  Get the WWDG instance-level register base from a channel
 *         register base address.
 * @param  CHANNEL: the WWDG channel register base address
 *         (WWDG0_Channel0..WWDG1_Channel3).
 * @retval The WWDG instance register base (WWDG0 or WWDG1).
 */
#define WWDG_GET_PERIPH(CHANNEL)                (((uint32)(CHANNEL) < (uint32)WWDG1_Channel0) ? WWDG0 : WWDG1)
/**
  * @}
  */

/** @defgroup WWDG_IS_WWDG_Definitions WWDG Private macros to check input parameters
  * @{
  */
#define IS_WWDG_ALL_INSTANCE(INSTANCE)    (((INSTANCE) == WWDG0_Channel0) || \
                                           ((INSTANCE) == WWDG0_Channel1) || \
                                           ((INSTANCE) == WWDG0_Channel2) || \
                                           ((INSTANCE) == WWDG0_Channel3) || \
                                           ((INSTANCE) == WWDG1_Channel0) || \
                                           ((INSTANCE) == WWDG1_Channel1) || \
                                           ((INSTANCE) == WWDG1_Channel2) || \
                                           ((INSTANCE) == WWDG1_Channel3))

#define IS_WWDG_TypeDef(INSTANCE)         (((INSTANCE) == WWDG0) || ((INSTANCE) == WWDG1))

#define IS_WWDG_PRESCALER(PRESCALER)      (((PRESCALER) >= 0x02) && ((PRESCALER) <= 0xFF))

/**
 * @brief  Check the prescaler number against the register field width.
 * @note   The PSC.PSCNUM field is 8 bits wide and the device accepts 0
 *         (which means "divide by 1", as the timeout is computed from
 *         (PSCNUM + 1)); the reference fence / watchdog alarm test cases of
 *         this device program it. The legacy IS_WWDG_PRESCALER() macro keeps
 *         the stricter range (2-255) and is kept for the assertions and for
 *         the applications that use it, while the run time validation of
 *         HAL_WWDG_Init() uses this macro so that a configuration the device
 *         accepts is not rejected in a build with the assertions disabled.
 */
#define IS_WWDG_PRESCALER_RANGE(PRESCALER) ((PRESCALER) <= 0xFFU)

#define IS_WWDG_DIVIDER(DIVIDER)          (((DIVIDER) >= 0x02) && ((DIVIDER) <= 0xFFFF))

#define IS_WWDG_COUNTER(COUNTER)          ((COUNTER) <= WWDG_TO_BVAL)

#define IS_WWDG_WINDOW(WINDOW)            ((WINDOW) <= 0xFFFFU)

#define IS_WWDG_BARK_FLAG(FLAG)           (((FLAG) == WWDG_FLAG_BK0) || \
                                           ((FLAG) == WWDG_FLAG_BK1) || \
                                           ((FLAG) == WWDG_FLAG_BK2) || \
                                           ((FLAG) == WWDG_FLAG_BK3))

/* Legacy selector name kept as an alias of the current name */
#define IS_WWDG_ALL_PERIPH                 IS_WWDG_ALL_INSTANCE
#define IS_WWDG_TOValue                   IS_WWDG_COUNTER
#define IS_WWDG_WDCNTValue                IS_WWDG_WINDOW
#define IS_WWDG_BRAK_FLAG                  IS_WWDG_BARK_FLAG
/**
  * @}
  */

/* Shared internal functions --------------------------------------------------*/

/**
 * @brief  Check whether the WWDG handle and its instance are valid.
 * @note   Shared with the extension implementation file.
 * @param  hwwdg: pointer to a WWDG_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
uint32 WWDG_HandleIsValid(WWDG_HandleTypeDef *hwwdg);

/**
 * @brief  Check whether the handle accepts a new operation.
 * @note   ARCH-CONST-09: a handle that is BUSY (an operation is ongoing in
 *         another context) rejects any other operation with HAL_BUSY, and a
 *         handle that is not initialized (RESET) requires HAL_WWDG_Init()
 *         first and is rejected with HAL_ERROR. The recoverable state ERROR
 *         accepts a new operation directly.
 * @param  hwwdg: pointer to a WWDG_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK (accepted) / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef WWDG_CheckState(WWDG_HandleTypeDef *hwwdg);

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle, which shall have been
 *         created by the user porting layer (e.g. in HAL_WWDG_MspInit()).
 *         RTOS-11: the Timeout parameter prevents a task from blocking
 *         forever; HAL_MAX_DELAY means an infinite wait.
 * @param  hwwdg: pointer to a WWDG_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef WWDG_LockHandle(WWDG_HandleTypeDef *hwwdg, uint32 Timeout);

/**
 * @brief  Unlock the handle.
 * @param  hwwdg: pointer to a WWDG_HandleTypeDef structure.
 * @retval None
 */
void WWDG_UnlockHandle(WWDG_HandleTypeDef *hwwdg);

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_WWDG_H */

/*****END OF FILE*****/
