/**
 * @file    CRC_IT_DRV_006.c
 * @brief   HAL CRC integration test case 006 (lifecycle, MSP contract, lock
 *          helpers, data size matrix).
 *
 * HAL library extension case that covers the parts of the driver the reference
 * library does not have: the handle lifecycle with its low level callbacks, the
 * exported lock helpers, the module version macro and the three data sizes.
 *
 * Tested functionality:
 *   HAL_CRC_StructInit() / HAL_CRC_Init() / HAL_CRC_DeInit()
 *   HAL_CRC_MspInit() / HAL_CRC_MspDeInit()      (contract, not the body)
 *   CRC_LockHandle() / CRC_UnlockHandle()        (shared internal helpers)
 *   HAL_CRC_Reset() / HAL_CRC_CalcCRC()
 *   HAL_CRC_GetCRC() / HAL_CRC_GetState() / HAL_CRC_GetError()
 *   __HAL_CRC_MODULE_VERSION / CRC_INIT_V1 / CRC_INIT_VERSION
 *
 * Test procedure:
 *   1. lifecycle: the first HAL_CRC_Init() runs HAL_CRC_MspInit() exactly once,
 *      while the handle is still in the RESET state and still unlocked
 *      (LOCK-06 / MSP-04); a repeated initialization on a READY handle does not
 *      run it again;
 *   2. de-initialization: HAL_CRC_DeInit() runs HAL_CRC_MspDeInit() after the
 *      unlock, writes the model reset command to the control register and
 *      brings the handle back to RESET; a following initialization runs the low
 *      level preparation again;
 *   3. lock helpers: the bare-metal handle lock is a single flag, so a second
 *      acquisition without a release reports HAL_BUSY and the release makes the
 *      handle usable again;
 *   4. version macros: the module version and the structure version are the
 *      documented values;
 *   5. data size matrix: the three data sizes are configured, the result is
 *      reproducible and the sizes really change the result.
 *
 * Expected behaviour:
 *   every check passes and the summary prints "summary : failures = 0".
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
#define TEST_BAUDRATE                  (115200U)   /*!< console baud rate        */
#define TEST_ROUND_DELAY_MS            (2000U)     /*!< delay between two rounds */

#define TEST_MODULE_VERSION            (0x0100U)   /*!< documented driver version */
#define TEST_INIT_VERSION              (0x0100U)   /*!< documented structure version */

/* Private variables ---------------------------------------------------------*/
static volatile uint32 check_failures = 0U;   /*!< failed check counter           */
static HAL_SMU_HandleTypeDef hsmu_clk;        /*!< SMU handle (clock tree)        */

/** @brief CRC handle used by this case. */
HAL_CRC_HandleTypeDef hcrc_dev;

/* MSP callback bookkeeping (written by the shared MSP callbacks) */
uint32 Crc_MspInitCount   = 0U;               /*!< HAL_CRC_MspInit() calls        */
uint32 Crc_MspDeInitCount = 0U;               /*!< HAL_CRC_MspDeInit() calls      */
uint32 Crc_MspStateAtInit = 0xFFFFFFFFU;      /*!< handle state seen in the MSP   */
uint32 Crc_MspLockAtInit  = 0xFFFFFFFFU;      /*!< handle lock seen in the MSP    */
uint32 Crc_MspStateAtDeInit = 0xFFFFFFFFU;    /*!< handle state seen in the MSP   */

/* Shared helpers of this suite (defined at the end of this file) */
void Check(const char *name, uint32 condition);
void Summary(void);
void SystemClock_Init(void);
void Crc_ClockEnable(void);



/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    CRC_InitTypeDef   crc_init;
    HAL_StatusTypeDef status;
    uint32 round = 0U;
    uint32 value_8b;
    uint32 value_16b;
    uint32 value_32b;
    uint32 value_again;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== CRC_IT_DRV_006 : lifecycle, MSP, locks, data sizes ===\r\n");

    /* ---------------- 4. version macros -------------------------------- */
    printf("-- version and structure markers --\r\n");
    Check("__HAL_CRC_MODULE_VERSION is 0x0100",
          (__HAL_CRC_MODULE_VERSION == TEST_MODULE_VERSION) ? 1U : 0U);
    Check("CRC_INIT_V1 is 0x0100", (CRC_INIT_V1 == TEST_INIT_VERSION) ? 1U : 0U);
    Check("CRC_INIT_VERSION equals CRC_INIT_V1",
          (CRC_INIT_VERSION == CRC_INIT_V1) ? 1U : 0U);

    /* ---------------- 1. lifecycle ------------------------------------- */
    printf("-- lifecycle and MSP contract --\r\n");
    __HAL_CLEAR_STRUCT(&hcrc_dev);
    hcrc_dev.Instance = CRC;
    HAL_CRC_StructInit(&crc_init);
    Check("HAL_CRC_StructInit() fills the Size metafield",
          (crc_init.Size == (uint32)sizeof(CRC_InitTypeDef)) ? 1U : 0U);
    Check("HAL_CRC_StructInit() fills the Version metafield",
          (crc_init.Version == CRC_INIT_VERSION) ? 1U : 0U);
    hcrc_dev.Init = crc_init;
    hcrc_dev.InputDataFormat = HAL_CRC_INPUTDATA_FORMAT_WORDS;

    Check("HAL_CRC_MspInit() has not run before the first initialization",
          (Crc_MspInitCount == 0U) ? 1U : 0U);
    Check("the cleared handle is in the RESET state",
          (HAL_CRC_GetState(&hcrc_dev) == HAL_CRC_STATE_RESET) ? 1U : 0U);

    status = HAL_CRC_Init(&hcrc_dev);
    Check("the first HAL_CRC_Init() returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("HAL_CRC_MspInit() ran exactly once", (Crc_MspInitCount == 1U) ? 1U : 0U);
    Check("the MSP callback observed the RESET state (MSP-04)",
          (Crc_MspStateAtInit == (uint32)HAL_CRC_STATE_RESET) ? 1U : 0U);
    Check("the MSP callback observed an unlocked handle (LOCK-06)",
          (Crc_MspLockAtInit == (uint32)HAL_UNLOCKED) ? 1U : 0U);
    Check("the handle is READY after the initialization",
          (HAL_CRC_GetState(&hcrc_dev) == HAL_CRC_STATE_READY) ? 1U : 0U);

    status = HAL_CRC_Init(&hcrc_dev);
    Check("a repeated initialization returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("a repeated initialization does not run the MSP callback again (MSP-04)",
          (Crc_MspInitCount == 1U) ? 1U : 0U);

    /* ---------------- 2. de-initialization ----------------------------- */
    status = HAL_CRC_DeInit(&hcrc_dev);
    Check("HAL_CRC_DeInit() returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("HAL_CRC_MspDeInit() ran exactly once", (Crc_MspDeInitCount == 1U) ? 1U : 0U);
    Check("the MSP de-initialization callback saw the RESET state",
          (Crc_MspStateAtDeInit == (uint32)HAL_CRC_STATE_RESET) ? 1U : 0U);
    Check("the handle is RESET after the de-initialization",
          (HAL_CRC_GetState(&hcrc_dev) == HAL_CRC_STATE_RESET) ? 1U : 0U);
    Check("the de-initialization cleared the configuration fields of the control register",
          ((CRC->CR & (CRC_CR_SIZE | CRC_CR_POLYSIZE | CRC_CR_REVIN |
                       CRC_CR_REVOUT | CRC_CR_XOROUT)) == 0U) ? 1U : 0U);
    {
        uint32 read_once = HAL_CRC_GetCRC(&hcrc_dev);
        uint32 read_twice = HAL_CRC_GetCRC(&hcrc_dev);
        Check("the read back service is still callable after the de-initialization",
              ((read_once == read_twice) && (read_once == CRC->DR)) ? 1U : 0U);
    }

    status = HAL_CRC_Init(&hcrc_dev);
    Check("a following initialization returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("the low level preparation ran again (second call)",
          (Crc_MspInitCount == 2U) ? 1U : 0U);
    Check("the handle is READY again",
          (HAL_CRC_GetState(&hcrc_dev) == HAL_CRC_STATE_READY) ? 1U : 0U);

    /* ---------------- 3. lock helpers ---------------------------------- */
    printf("-- shared lock helpers --\r\n");
    status = CRC_LockHandle(&hcrc_dev, 0U);
    Check("CRC_LockHandle() acquires a free handle", (status == HAL_OK) ? 1U : 0U);
    status = CRC_LockHandle(&hcrc_dev, 0U);
    Check("a second CRC_LockHandle() without release reports HAL_BUSY",
          (status == HAL_BUSY) ? 1U : 0U);
    CRC_UnlockHandle(&hcrc_dev);
    Check("CRC_UnlockHandle() releases the flag",
          (hcrc_dev.Lock == HAL_UNLOCKED) ? 1U : 0U);
    status = CRC_LockHandle(&hcrc_dev, 0U);
    Check("the lock can be acquired again after the release", (status == HAL_OK) ? 1U : 0U);
    CRC_UnlockHandle(&hcrc_dev);
    Check("a calculation is possible after the unlock",
          (HAL_CRC_GetState(&hcrc_dev) == HAL_CRC_STATE_READY) ? 1U : 0U);

    /* ---------------- 5. data size matrix ------------------------------ */
    printf("-- data size matrix (8 / 16 / 32-bit) --\r\n");
    for (;;)
    {
        /* 8-bit data size with the 8-bit polynomial */
        crc_init.CRC_Size     = CRC_SIZE_8B;
        crc_init.CRC_PolySize = CRC_POLYSIZE_8B;
        crc_init.CRC_Poly     = CRC_POLY_8;
        crc_init.CRC_INIT     = 0x00000000U;
        crc_init.CRC_XOR      = 0x00000000U;
        hcrc_dev.Init = crc_init;
        status = HAL_CRC_Init(&hcrc_dev);
        if (round == 0U)
        {
            Check("the 8-bit configuration is accepted", (status == HAL_OK) ? 1U : 0U);
            Check("the control register holds the 8-bit data size",
                  ((CRC->CR & CRC_CR_SIZE) == ((uint32)CRC_SIZE_8B << CRC_CR_SIZE_Pos)) ? 1U : 0U);
        }
        HAL_CRC_Reset(&hcrc_dev);
        value_8b = HAL_CRC_CalcCRC(&hcrc_dev, 0x12U);

        /* 16-bit data size with the 16-bit polynomial */
        crc_init.CRC_Size     = CRC_SIZE_16B;
        crc_init.CRC_PolySize = CRC_POLYSIZE_16B;
        crc_init.CRC_Poly     = CRC_POLY_16XMODEM;
        hcrc_dev.Init = crc_init;
        status = HAL_CRC_Init(&hcrc_dev);
        if (round == 0U)
        {
            Check("the 16-bit configuration is accepted", (status == HAL_OK) ? 1U : 0U);
            Check("the control register holds the 16-bit data size",
                  ((CRC->CR & CRC_CR_SIZE) == ((uint32)CRC_SIZE_16B << CRC_CR_SIZE_Pos)) ? 1U : 0U);
        }
        HAL_CRC_Reset(&hcrc_dev);
        value_16b = HAL_CRC_CalcCRC(&hcrc_dev, 0x1234U);

        /* 32-bit data size with the 32-bit polynomial */
        crc_init.CRC_Size     = CRC_SIZE_32B;
        crc_init.CRC_PolySize = CRC_POLYSIZE_32B;
        crc_init.CRC_Poly     = CRC_POLY_32;
        hcrc_dev.Init = crc_init;
        status = HAL_CRC_Init(&hcrc_dev);
        if (round == 0U)
        {
            Check("the 32-bit configuration is accepted", (status == HAL_OK) ? 1U : 0U);
            Check("the control register holds the 32-bit data size",
                  ((CRC->CR & CRC_CR_SIZE) == ((uint32)CRC_SIZE_32B << CRC_CR_SIZE_Pos)) ? 1U : 0U);
        }
        HAL_CRC_Reset(&hcrc_dev);
        value_32b = HAL_CRC_CalcCRC(&hcrc_dev, 0x12345678U);

        /* reproducibility of the last configuration */
        HAL_CRC_Reset(&hcrc_dev);
        value_again = HAL_CRC_CalcCRC(&hcrc_dev, 0x12345678U);

        printf("8-bit : 0x%08X  16-bit : 0x%08X  32-bit : 0x%08X\r\n",
               (unsigned int)value_8b, (unsigned int)value_16b, (unsigned int)value_32b);

        if (round == 0U)
        {
            Check("the 32-bit result is reproducible after a reset",
                  (value_again == value_32b) ? 1U : 0U);
            Check("the three data sizes give three different results",
                  ((value_8b != value_16b) && (value_16b != value_32b) &&
                   (value_8b != value_32b)) ? 1U : 0U);
            Check("the handle is still READY", (HAL_CRC_GetState(&hcrc_dev) == HAL_CRC_STATE_READY) ? 1U : 0U);
            Check("no error was recorded", (HAL_CRC_GetError(&hcrc_dev) == HAL_CRC_ERROR_NONE) ? 1U : 0U);
            Summary();
        }

        round++;
        delay_ms(TEST_ROUND_DELAY_MS);
    }
}

/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the other integration tests of this library:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2 and
 *         CANX2 by 8, which gives core 180 MHz and APB 22.5 MHz.
 * @param  None
 * @retval None
 */
void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks (console pins of USART0 on GPIOD) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Open the clock gate of the CRC unit and release its reset.
 * @param  None
 * @retval None
 */
void Crc_ClockEnable(void)
{
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_CRC_CLK_ENABLE();
    __HAL_SMU_CRC_FORCE_RESET();
    __HAL_SMU_CRC_RELEASE_RESET();
}

/* MSP callbacks ------------------------------------------------------------*/

/**
 * @brief  Initialize the CRC MSP (clock gate and reset release).
 * @note   The state and the lock flag observed here are recorded, because the
 *         lifecycle case verifies the LOCK-06 / MSP-04 contract with them: the
 *         callback runs while the handle is still RESET and not locked, i.e.
 *         before the driver takes the handle lock and before the first register
 *         write.
 * @param  hcrc: CRC handle
 * @retval None
 */
void HAL_CRC_MspInit(HAL_CRC_HandleTypeDef *hcrc)
{
    Crc_MspInitCount++;
    Crc_MspStateAtInit = (uint32)hcrc->State;
    Crc_MspLockAtInit  = (uint32)hcrc->Lock;

    Crc_ClockEnable();
}

/**
 * @brief  De-initialize the CRC MSP.
 * @note   The clock gate is left open so that the read back services keep
 *         working after a de-initialization; the state observed here proves
 *         that the callback runs after the handle went back to RESET, i.e.
 *         after the unlock.
 * @param  hcrc: CRC handle
 * @retval None
 */
void HAL_CRC_MspDeInit(HAL_CRC_HandleTypeDef *hcrc)
{
    Crc_MspDeInitCount++;
    Crc_MspStateAtDeInit = (uint32)hcrc->State;

    (void)hcrc;
}

/*****END OF FILE*****/
