/**
 * @file    CLINT_IT_DRV_004.c
 * @brief   HAL CLINT integration test case 004 (timer comparator, periodic MTI).
 *
 * One-to-one HAL library port of the original AS32x601 standard-library
 * test case CLINT_IT_DRV_004.c. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_CLINT_Init()
 *   HAL_CLINT_ReadTimerValue()
 *   HAL_CLINT_SetTickPeriod()
 *   HAL_CLINT_TimerIntCmd()
 *   HAL_CLINT_IRQHandler() + HAL_CLINT_TickCallback()
 *   HAL_CLINT_GetTimerComparator() (mirror of the planned instant: it advances
 *   by exactly one period per tick and never drifts)
 *
 * Test procedure:
 *   1. Initialize the CLINT and program the system time base period (1 s);
 *   2. Check that the machine timer interrupt is masked while a tick period is
 *      being enabled and disabled again (no tick is counted while masked);
 *   3. Enable the machine timer interrupt through the driver and leave it
 *      running: the interrupt entry reloads the comparator one period ahead,
 *      so the interrupt is generated periodically.  The mask window is a test
 *      item of its own, therefore the periodic-phase counters are reset here
 *      (and the first report is aligned between two ticks) so that the elapsed
 *      mask window is not carried into the period, mirror and drift checks;
 *   4. The main loop prints the accumulated interrupt count every 2 s.
 *
 * Expected behaviour:
 *   - No interrupt is counted while the machine timer interrupt is masked;
 *   - The machine timer interrupt is generated every second
 *     (2 interrupts per printed line);
 *   - Every counter value printed by the callback is larger than the previous
 *     one, and the difference between two consecutive values equals
 *     SystemCoreClock (180 000 000 counter ticks = 1 s) within the jitter of
 *     the interrupt entry;
 *   - The comparator mirror advances by exactly one period per tick
 *     (mirror_ok grows and mirror_bad stays 0);
 *   - The accumulated drift printed by the main loop stays inside the bound,
 *     i.e. the period error does not grow with the number of ticks (drift
 *     limit = SystemCoreClock / 1000, one millisecond of counter ticks);
 *   - The comparator is reloaded by the driver from the instant planned last
 *     plus one period (the counter read inside the handler is the base of the
 *     very first arming only), so the effective period equals the programmed
 *     period and the interrupt latency does not accumulate from tick to tick;
 *   - The comparator mirror therefore advances by exactly one period per
 *     tick, and the elapsed time measured over the whole run stays within a
 *     fixed bound of "ticks x period" however many ticks have been served.
 *
 * Note: the original test case computed and wrote every comparator value by
 * hand from MTimer_IRQ_Handler() and enabled the interrupt with a raw CSR
 * access; the driver owns both now (see CLINT-REQ-025/026/027).
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* System time base period: 1 s of CLINT real-time counter ticks */
#define TIMER_STEP_SECONDS          (1U)

/* Period of the main loop report */
#define REPORT_PERIOD_MS            (2000U)

/* Bound of the accumulated tick error, in counter ticks: SystemCoreClock/1000
 * is one millisecond of counting, i.e. the elapsed time of N ticks may differ
 * from N x period by at most that much, whatever N is.  A reload taken from the
 * counter read inside the handler would instead accumulate one interrupt
 * latency per tick and leave this bound quickly. */
#define DRIFT_LIMIT_TICKS           (SystemCoreClock / 1000U)

/* Accepted relative jitter of a single period measurement (percent) */
#define PERIOD_TOLERANCE_PERCENT    (1U)

/* Private variables ---------------------------------------------------------*/
static HAL_CLINT_HandleTypeDef hclint_dev; /*!< CLINT handle                 */
static volatile uint32 timerint_count = 0U; /*!< timer interrupt counter      */
static volatile uint64 last_mtime = 0U;     /*!< previous counter value       */
static volatile uint64 last_delta = 0U;     /*!< previous counter difference  */
static volatile uint32 masked_count = 0U;   /*!< ticks when MTI was disabled  */
static volatile uint64 first_mtime = 0U;    /*!< counter at the first tick    */
static volatile uint64 last_mirror = 0U;    /*!< mirror at the previous tick  */
static volatile uint32 mirror_ok  = 0U;     /*!< ticks with a one period mirror step */
static volatile uint32 mirror_bad = 0U;     /*!< ticks with an unexpected mirror step */
static volatile uint32 period_ok  = 0U;     /*!< ticks inside the period jitter band */
static volatile uint32 period_bad = 0U;     /*!< ticks outside the period jitter band */
static volatile sint64 drift_ticks = 0;     /*!< measured elapsed - ticks x period */

static HAL_SMU_HandleTypeDef hsmu_clk;   /*!< SMU handle (lock / state / error) */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    uint64 mtime;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== CLINT_IT_DRV_004: system time base (1 s period) ===\r\n");

    /* Initialize the CLINT peripheral */
    hclint_dev.Instance = CLINT;
    if (HAL_CLINT_Init(&hclint_dev) != HAL_OK)
    {
        printf("HAL_CLINT_Init failed\r\n");
        while (1)
        {
        }
    }

    /* Step 1: program the system time base period (1 s) through the driver,
     * which also arms the first tick one period ahead of the counter */
    if (HAL_CLINT_SetTickPeriod(&hclint_dev,
                                TIMER_STEP_SECONDS * SystemCoreClock) != HAL_OK)
    {
        printf("HAL_CLINT_SetTickPeriod failed\r\n");
        while (1)
        {
        }
    }

    mtime = HAL_CLINT_ReadTimerValue(&hclint_dev);
    printf("SystemCoreClock = %u Hz (1 s = %u ticks)\r\n",
           PRINT_U32(SystemCoreClock), PRINT_U32(SystemCoreClock));
    printf("initial mtime   = 0x%08X%08X\r\n",
           PRINT_U32(mtime >> 32U), PRINT_U32(mtime));
    printf("tick period     = %u counter ticks, error = 0x%08X\r\n",
           PRINT_U32(TIMER_STEP_SECONDS * SystemCoreClock),
           PRINT_U32(HAL_CLINT_GetError(&hclint_dev)));

    /* Baseline of the mirror drift check: the instant that the driver planned
     * for the first tick.  Every later tick must advance it by one period. */
    last_mirror = HAL_CLINT_GetTimerComparator(&hclint_dev);
    printf("planned instant : 0x%08X%08X (mirror, first tick)\r\n",
           PRINT_U32(last_mirror >> 32U), PRINT_U32(last_mirror));

    /* Step 2: exercise the enable / disable pair of the time base. While the
     * machine timer interrupt is masked no tick may be counted, even though
     * the period is programmed and the counter keeps running. */
    HAL_CLINT_TimerIntCmd(&hclint_dev, ENABLE);
    delay_ms(REPORT_PERIOD_MS);
    HAL_CLINT_TimerIntCmd(&hclint_dev, DISABLE);
    masked_count = timerint_count;
    delay_ms(REPORT_PERIOD_MS);
    printf("masked window : %u ticks before, %u after [%s]\r\n",
           PRINT_U32(masked_count), PRINT_U32(timerint_count),
           ((timerint_count == masked_count) ? "PASS" : "FAIL"));

    /* Step 3: re-enable the machine timer interrupt and leave it running: the
     * interrupt entry reloads the comparator on every tick */
    HAL_CLINT_TimerIntCmd(&hclint_dev, ENABLE);

    /* The periodic-phase metrics start from a clean baseline here.  The mask
     * window above is a test item of its own: two whole periods elapsed while
     * the interrupt was masked, and the re-arm performed by
     * HAL_CLINT_TimerIntCmd(ENABLE) moves the planned instant ahead, so
     * carrying Step 2 into these counters would report a constant two period
     * offset in the drift and a re-arm step in the mirror - neither of them is
     * a period error.  Resetting them keeps every check below measuring the
     * steady periodic behaviour only. */
    timerint_count = 0U;
    period_ok      = 0U;
    period_bad     = 0U;
    mirror_ok      = 0U;
    mirror_bad     = 0U;
    drift_ticks    = 0;
    first_mtime    = 0U;
    last_mtime     = 0U;
    last_delta     = 0U;
    last_mirror    = 0U;

    /* Wait half a period before the first report so that the reporting window
     * begins between two ticks: a window that starts exactly on a tick
     * boundary could end just short of the next tick and count one interrupt
     * less than expected. */
    delay_ms((TIMER_STEP_SECONDS * 1000U) / 2U);

    printf("MTI enabled, waiting for periodic interrupts...\r\n");

    while (1)
    {
        delay_ms(REPORT_PERIOD_MS);

        /* One second per period, so a report window of REPORT_PERIOD_MS holds
         * exactly REPORT_PERIOD_MS / 1000 interrupts (2 for a 2 s window) */
        printf("interrupts = %u, last mtime = 0x%08X%08X, last delta = %u ticks [%s]\r\n",
               PRINT_U32(timerint_count),
               PRINT_U32(last_mtime >> 32U), PRINT_U32(last_mtime),
               PRINT_U32(last_delta),
               ((timerint_count >= (REPORT_PERIOD_MS / (TIMER_STEP_SECONDS * 1000U)))
                    ? "PASS" : "FAIL"));

        printf("period in band  : ok = %u, out = %u [%s]\r\n",
               PRINT_U32(period_ok), PRINT_U32(period_bad),
               ((period_bad == 0U) ? "PASS" : "FAIL"));

        printf("mirror step     : ok = %u, bad = %u [%s]\r\n",
               PRINT_U32(mirror_ok), PRINT_U32(mirror_bad),
               ((mirror_bad == 0U) ? "PASS" : "FAIL"));

        printf("accumulated drift = %d ticks, limit = +-%u [%s]\r\n",
               (int)drift_ticks, PRINT_U32(DRIFT_LIMIT_TICKS),
               (((drift_ticks <= (sint64)DRIFT_LIMIT_TICKS) &&
                 (drift_ticks >= -(sint64)DRIFT_LIMIT_TICKS)) ? "PASS" : "FAIL"));
    }
}

/**
 * @brief  Machine timer interrupt handler (weak symbol of the trap entry).
 * @note   Trampoline of the system time base: the driver entry answers the
 *         interrupt by reloading the comparator and then runs the tick
 *         callback.  No lock is taken here (LOCK-04 / RTOS-12).
 * @param  None
 * @retval None
 */
void MTimer_IRQ_Handler(void)
{
    HAL_CLINT_IRQHandler(&hclint_dev);
}

/**
 * @brief  System time base tick callback (weak symbol of the CLINT driver).
 * @note   Runs in interrupt context once per period, after the next tick has
 *         been armed by HAL_CLINT_IRQHandler(); the printed mtime difference
 *         between two consecutive calls must be one period.
 * @param  hclint: CLINT handle.
 * @retval None
 */
void HAL_CLINT_TickCallback(HAL_CLINT_HandleTypeDef *hclint)
{
    uint64 now = HAL_CLINT_ReadTimerValue(hclint);
    uint64 mirror = HAL_CLINT_GetTimerComparator(hclint);
    uint64 period = (uint64)(TIMER_STEP_SECONDS * SystemCoreClock);
    uint32 next_count;

    if (timerint_count == 0U)
    {
        /* First tick: the elapsed time is measured from here on */
        first_mtime = now;
    }
    else
    {
        /* Counter difference with respect to the previous tick, checked
         * against the programmed period within the entry jitter */
        uint32 band = (uint32)(period / 100U) * PERIOD_TOLERANCE_PERCENT;

        last_delta = now - last_mtime;
        if ((last_delta >= (period - band)) && (last_delta <= (period + band)))
        {
            period_ok++;
        }
        else
        {
            period_bad++;
        }

        /* Accumulated error: with the reload taken from the planned instant it
         * stays bounded, with a reload taken from the counter read here it
         * would grow by one interrupt latency per tick */
        drift_ticks = (sint64)(now - first_mtime) -
                      (sint64)((uint64)timerint_count * period);
    }

    /* The driver reloads before this callback runs, so the mirror has already
     * been advanced: the step must be exactly one period (V1.6 semantics) */
    if (last_mirror != 0U)
    {
        if ((mirror - last_mirror) == period)
        {
            mirror_ok++;
        }
        else
        {
            mirror_bad++;
        }
    }
    last_mirror = mirror;

    last_mtime = now;

    timerint_count++;
    next_count = timerint_count;

    printf("[MTI] #%u mtime = 0x%08X%08X delta = %u ticks\r\n",
           PRINT_U32(next_count), PRINT_U32(now >> 32U), PRINT_U32(now),
           PRINT_U32(last_delta));
}

/**
 * @brief  Configure the system clock tree using the HAL SMU driver.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef  SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef   SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it (CLKFRQ above), so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Clock tree order: this is the order the chip requires, and the vendor
       test case uses the same one.
         1. Write the bus clock dividers while the system clock is still the
            power-on source (FIRC), so that the new divider values are already
            in place when the faster clock arrives. Writing them AFTER the
            switch instead leaves the buses at their reset dividers for a
            moment at the new core clock: at 180 MHz that is
            AXI4Bus3 = 90 MHz and APBBus0 = 45 MHz, right at their ratings, and
            the core does not survive it (measured on the board: the core
            trapped before the divider write was reached, so no output was
            produced at all).
         2. Program the EFLASH controller clock: the controller must already
            know the final frequency while the code still runs from the flash.
         3. Then configure the PLL and switch the system clock to it; this call
            also updates SystemCoreClock and re-initializes the HAL time base. */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
