# CANFD 应用与测试参考

供 skill 按需求检索 AS32x601 HAL CAN FD 示例。别名/关键词：CANFD、CAN-FD、CAN 总线、经典 CAN、FD 帧、BRS、内部回环、验收过滤器、位时序、采样点、总线关闭、时间戳。共收录 13 个独立用例。

来源：D 盘原始 CANFD 测试工程的 001～013 main.c，按用例编号原样收录为 CANFD_IT_DRV_001.c～013.c。案例存在不代表已经完成当前 SDK 的编译及板级验证。

HAL 依据：[头文件](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_canfd.h)、[实现](../../HAL_LIBRARY/peripherals/src/as32x601_hal_canfd.c)。原测试工程的 4_HAL_LIBRARY 未提供，尚不能确认原始链接版本；文中标出的源码与当前 SDK 差异须先解决再迁移。


## 实例与可选引脚

下表列出 AS32x601 LQFP144 封装的本外设信号。每根信号单独选择引脚，并核对 [GPIO AF 定义](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_gpio.h)；文档功能编号不能直接当作 HAL 编码传入。其他封装需另查引出情况。

| 信号 | 可选引脚 | 封装脚号 | 文档功能 | HAL AF |
|---|---|---|---|---|
| `CAN0_RX` | PD0 | 29 | 功能3 | `GPIO_AF_CAN0_M3`（0x04） |
| `CAN0_RX` | PB2 | 108 | 功能1 | `GPIO_AF_CAN0_M1`（0x02） |
| `CAN0_TX` | PC12 | 30 | 功能3 | `GPIO_AF_CAN0_M3`（0x04） |
| `CAN0_TX` | PB1 | 111 | 功能1 | `GPIO_AF_CAN0_M1`（0x02） |
| `CAN1_RX` | PD14 | 55 | 功能1 | `GPIO_AF_CAN1`（0x02） |
| `CAN1_TX` | PD13 | 56 | 功能1 | `GPIO_AF_CAN1`（0x02） |
| `CAN2_RX` | PH6 | 70 | 功能1 | `GPIO_AF_CAN2`（0x02） |
| `CAN2_TX` | PH7 | 69 | 功能1 | `GPIO_AF_CAN2`（0x02） |
| `CAN3_RX` | PC8 | 42 | 功能1 | `GPIO_AF_CAN3`（0x02） |
| `CAN3_TX` | PC7 | 43 | 功能1 | `GPIO_AF_CAN3`（0x02） |

候选引脚不代表已验证的接线组合。实例、通道与路由约束按当前驱动和手册核对；同一引脚的其他功能须检查资源冲突。案例配置见下文。

## 生成前需确认的参数

已有工程、板级资料或用户已明确的值直接复用。仅对影响本次实现的缺失选择使用参数卡询问并等待答复；案例配置不能代替实际接线或应用参数。

| 参数 | 需要核对或确认的内容 |
|---|---|
| 实例与接线 | 控制器、TX/RX、外部收发器、电平、EN/STB 与终端电阻 |
| 通信参数 | 对端仲裁速率、数据速率、BRS、采样点和帧格式 |
| 过滤与模式 | 接收 ID、过滤条件、正常通信或内部回环 |

## 按需求选择

按目标行为选取案例，再核对完整源码和当前 HAL。

| 用户需求 / 检索关键词 | 推荐用例 | 使用条件 / 补充逻辑 |
|---|---|---|
| 经典 CAN / CANFD、标准 / 扩展 ID | [001](CANFD_IT_DRV_001.c) | 协议与 ID 格式矩阵；按实际对端选择组合 |
| 轮询发送与接收 | [002](CANFD_IT_DRV_002.c) | 需要实际收发条件，核对发送完成、接收数据与超时 |
| Bus-off 恢复与自动重传 | [003](CANFD_IT_DRV_003.c) | 核对故障制造、总线条件及恢复状态；仅模式回读不能证明恢复成功 |
| 休眠与唤醒中断 | [004](CANFD_IT_DRV_004.c) | 核对实际唤醒事件、PLIC 配置和清标志 |
| 内部回环收发 | [005](CANFD_IT_DRV_005.c) | 无对端数据通路检查；不能代替外部总线验证 |
| 只听 / Snoop 模式 | [006](CANFD_IT_DRV_006.c) | 需要外部总线流量，核对监听及不主动发送的行为 |
| 错误计数与自动重传 | [007](CANFD_IT_DRV_007.c) | 按源码准备故障和对端条件，观察错误计数变化 |
| 逐字段校验接收信息 | [008](CANFD_IT_DRV_008.c) | 核对 ID、帧格式、长度和数据等字段 |
| 多缓冲并发发送 | [009](CANFD_IT_DRV_009.c) | 按缓冲状态和发送完成条件管理多个请求 |
| DLC 长度编码扫描 | [010](CANFD_IT_DRV_010.c) | 区分 DLC 编码、实际字节长度和缓冲容量 |
| GPIO 先于控制器时钟配置 | [011](CANFD_IT_DRV_011.c) | 初始化顺序回归参考，迁移时保留实际时钟/复位依赖 |
| 无对端 API 契约自检 | [012](CANFD_IT_DRV_012.c) | 参数、状态及接口行为检查；不证明外部通信 |
| 模式、状态机、长度扫描与过滤等综合检查 | [013](CANFD_IT_DRV_013.c) | 原有综合案例；具体边界见下文 |

## 案例实际配置

以下从各文件 TEST 宏提取，配置只代表测试接线。位时序、收发器、对端与错误处理需阅读对应源码。

| 用例 | 实例 | TX | RX | HAL AF |
|---|---|---|---|---|
| [001](CANFD_IT_DRV_001.c) | CANFD3 | PC7 | PC8 | `GPIO_AF_CAN3` |
| [002](CANFD_IT_DRV_002.c) | CANFD3 | PC7 | PC8 | `GPIO_AF_CAN3` |
| [003](CANFD_IT_DRV_003.c) | CANFD3 | PC7 | PC8 | `GPIO_AF_CAN3` |
| [004](CANFD_IT_DRV_004.c) | CANFD3 | PC7 | PC8 | `GPIO_AF_CAN3` |
| [005](CANFD_IT_DRV_005.c) | CANFD3 | PC7 | PC8 | `GPIO_AF_CAN3` |
| [006](CANFD_IT_DRV_006.c) | CANFD3 | PC7 | PC8 | `GPIO_AF_CAN3` |
| [007](CANFD_IT_DRV_007.c) | CANFD3 | PC7 | PC8 | `GPIO_AF_CAN3` |
| [008](CANFD_IT_DRV_008.c) | CANFD2 | PH7 | PH6 | `GPIO_AF_CAN2` |
| [009](CANFD_IT_DRV_009.c) | CANFD2 | PH7 | PH6 | `GPIO_AF_CAN2` |
| [010](CANFD_IT_DRV_010.c) | CANFD3 | PC7 | PC8 | `GPIO_AF_CAN3` |
| [011](CANFD_IT_DRV_011.c) | CANFD2 | PH7 | PH6 | `GPIO_AF_CAN2` |
| [012](CANFD_IT_DRV_012.c) | CANFD3 | PC7 | PC8 | `GPIO_AF_CAN3` |
| [013](CANFD_IT_DRV_013.c) | CANFD3 | PC7 | PC8 | `GPIO_AF_CAN3` |

## 实现要点

以下详细说明以 013 为例；其他案例按上表和各自源码核对。

- 实例与引脚：013 使用 `CANFD3`，TX = `GPIOC` pin 7、RX = `GPIOC` pin 8，AF = `GPIO_AF_CAN3`。RX 配为输入上拉（收发器驱动 RXD），TX 配为复用推挽；不接收发器时只能做内部回环。
- 时钟：示例核心 160 MHz，CANCLK=80 MHz。仲裁段预分频 10、每位 16 tq，得到 80 MHz/10/16=500 kbit/s；数据段预分频 2、每位 8 tq，得到 80 MHz/2/8=5 Mbit/s。按实际 CANCLK 重算，预分频值不是每位 tq 数。
- 初始化顺序：`HAL_Init()` → `SystemClock_Init()` → `delay_init()` / 串口 → GPIO 时钟与 CANFD 时钟/复位（在覆写的 `HAL_CANFD_MspInit()` 中做，驱动在取句柄锁之前调用该钩子）→ `HAL_CANFD_StructInit()` 后填 `CANFD_InitTypeDef` → `HAL_CANFD_Init()` → `HAL_CANFD_FilterInit()` 逐个装过滤器 → 需要时 `HAL_CANFD_SetLoopback()` / `SetSnoop()` / `Sleep()` / `WakeUp()`。
- 收发流程：内部回环下 `HAL_CANFD_FrameInit()` 配置发送缓冲 → `HAL_CANFD_LoopbackTransmit()` → 轮询 `HAL_CANFD_GetRxFillLevel()` → `HAL_CANFD_GetReceiveData()`。CAN FD 的离散长度不是由 API 参数直接决定：示例直接修改 `TxMessage[n].TB_DLC` 的 `DLC` 位域，再以字节长度调用发送。接收信息用 `HAL_CANFD_GetReceiveInfo()`，读索引由读取路径推进，也可调用 `HAL_CANFD_SetRxIncReadIndex()`。
- 中断链：驱动没有中断分发器，也没有发送/接收回调；`CANFD3_IRQ_Handler()` 由应用实现，内部用 `HAL_CANFD_GetITStatus()` 判源、`HAL_CANFD_ClearITPendingBit()` 清挂起（该接口不加锁、不受状态门控，可在 ISR 中调用）。示例末尾用 `CANFD_IT_ALL` 兜底清挂起。
- 证据边界：013 的 PASS 来自寄存器回读与内部回环，能证明配置写入、模式/状态机、FIFO 读写路径；不能证明真实总线波形、收发器工作、双节点互操作或 bus-off 恢复。这些需要总线分析仪/示波器和第二节点实测。

## 验证方法与适用边界

- 内部回环 PASS 不能证明外部收发器、对端或真实总线通信；需带收发器的第二节点及总线测量。
- 模式请求受句柄状态门控：`HAL_CANFD_DeInit()` 后 `SetLoopback/SetSnoop/Sleep/SetBusOff` 全部被拒，`MSR` 保持 0；恢复前必须重新初始化。
- 发送缓冲与 DLC 是两处独立配置；应用若只改发送长度参数而不改 `TB_DLC`，FD 帧可能仍按旧长度发出。
- 接收路径会推进 FIFO 读索引；读完一帧后不要再次盲目递增，空 FIFO 虽容忍递增，但会打乱后续读取位置。
- 零长度帧允许 `NULL` 数据指针；非零长度时缓冲区必须覆盖对应字节数。
- `HAL_CANFD_TDCConfig()` 的 TDC/延迟补偿只在配置模式可靠锁存；运行模式下硬件可能忽略，示例因此接受两种结果，应用应在初始化阶段配置。
- 该案例的核心频率是 160 MHz，不能与其他 180 MHz 套件的延时、波特率计算混用。

## 按接口与辅助宏检索

| 接口 / 宏 | 参考用例 |
|---|---|
| `HAL_CANFD_StructInit` / `HAL_CANFD_Init` / `HAL_CANFD_DeInit` | [013](CANFD_IT_DRV_013.c) |
| `HAL_CANFD_FilterInit` | [013](CANFD_IT_DRV_013.c) |
| `HAL_CANFD_FrameInit` / `HAL_CANFD_LoopbackTransmit` | [013](CANFD_IT_DRV_013.c) |
| `HAL_CANFD_GetRxFillLevel` / `HAL_CANFD_GetReceiveData` / `HAL_CANFD_GetReceiveInfo` | [013](CANFD_IT_DRV_013.c) |
| `HAL_CANFD_SetLoopback` / `HAL_CANFD_SetSnoop` / `HAL_CANFD_Sleep` / `HAL_CANFD_WakeUp` | [013](CANFD_IT_DRV_013.c) |
| `HAL_CANFD_ITConfig` / `HAL_CANFD_GetITStatus` / `HAL_CANFD_ClearITPendingBit` | [013](CANFD_IT_DRV_013.c) |
| `HAL_CANFD_BitRateConfig` / `HAL_CANFD_ProtExcConfig` / `HAL_CANFD_TDCConfig` | [013](CANFD_IT_DRV_013.c) |
| `HAL_CANFD_GetTimestampValue` / `HAL_CANFD_ClearTimestamp` | [013](CANFD_IT_DRV_013.c) |

本次为源码静态整理，未重新编译、未上板；源码里的历史测试注释不代表本次验证结果。
