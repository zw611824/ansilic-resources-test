/**
 * @file    CMU_IT_DRV_015.c
 * @brief   HAL CMU integration test case 015 (monitoring modes, status flags,
 *          exported macros and parameter validation macros).
 *
 * Extension test case of the HAL CMU driver: it exercises the remaining
 * constants and macros that the ported cases 001..013 and the life cycle case
 * 014 do not reach, i.e. every CMU_MODE_xxx value, the whole CMU_FLAG_xxx set,
 * the exported register access macros, the run time bounds of the window
 * length and of the thresholds, and the IS_CMU_xxx validation macros. Only HAL
 * library APIs are used.
 *
 * Tested functionality:
 *   HAL_CMU_Init()
 *   HAL_CMU_SetMode() / HAL_CMU_Cmd()
 *   HAL_CMU_SetWindowLength() / HAL_CMU_SetReferenceThreshold()
 *   HAL_CMU_GetFlagStatus() / HAL_CMU_ClearFlag()
 *   HAL_CMU_GetState() / HAL_CMU_GetError()
 *   __HAL_CMU_ENABLE() / __HAL_CMU_DISABLE()
 *   __HAL_CMU_GET_FLAG() / __HAL_CMU_CLEAR_FLAG()
 *   IS_CMU_ALL_INSTANCE() / IS_CMU_MODE() / IS_CMU_WINDOW_LENGTH()
 *   IS_CMU_THRESHOLD() / IS_CMU_FLAG() / IS_CMU_CLEAR() / IS_CMU_ENABLE_STATE()
 *   CMU_MODE_0..CMU_MODE_7 / CMU_FLAG_ALL / CMU_WINLEN_MIN / CMU_WINLEN_MAX
 *
 * Test procedure:
 *   1. Initialize the HAL library and configure the system clock tree with the
 *      HAL SMU / PMU drivers (core clock 180 MHz);
 *   2. Initialize the instance and walk through every monitoring mode
 *      (CMU_MODE_0..CMU_MODE_7), checking the CR.MODE field after each write;
 *   3. Check the run time bounds of the window length and of the two
 *      thresholds (minimum / maximum accepted, just outside the range
 *      refused with HAL_CMU_ERROR_INVALID_PARAM);
 *   4. Read every status flag (CMU_FLAG_WORK, CMU_FLAG_CHCDONE,
 *      CMU_FLAG_LOSSCLK, CMU_FLAG_FHH, CMU_FLAG_FLL) and the CMU_FLAG_ALL
 *      mask, then clear the two latched events;
 *   5. Check the exported register access macros __HAL_CMU_ENABLE(),
 *      __HAL_CMU_DISABLE(), __HAL_CMU_GET_FLAG() and __HAL_CMU_CLEAR_FLAG();
 *   6. Check the IS_CMU_xxx validation macros on accepted and refused values;
 *   7. Check that an instance bound to a foreign address is reported by
 *      HAL_CMU_GetError() / HAL_CMU_GetState().
 *
 * Expected behaviour:
 *   - HAL_CMU_SetMode() programs every accepted CMU_MODE_xxx value and keeps
 *     the other CR bits;
 *   - CMU_WINLEN_MIN..CMU_WINLEN_MAX and 0..0xFFFFFF are accepted, one step
 *     outside is refused;
 *   - every CMU_FLAG_xxx value can be queried; the two latched events can be
 *     cleared one by one and together;
 *   - the exported macros operate on the CMU registers directly;
 *   - the validation macros accept the documented values and refuse the rest.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Configuration used by the checks */
#define TEST_WINDOW_LENGTH          (20000U)
#define TEST_HIGH_THRESHOLD         (19200U)
#define TEST_LOW_THRESHOLD          (12800U)

/* Maximum value of the 24-bit window length / threshold fields */
#define TEST_FIELD_MAX              (0x00FFFFFFU)

/* One step above the 24-bit fields */
#define TEST_FIELD_OVER             (0x01000000U)

/* An address outside the four CMU register blocks */
#define TEST_FOREIGN_ADDRESS        (0x0000F000U)

/* Status flag polling period (ms) */
#define TEST_POLL_MS                (500U)

/* Private variables ---------------------------------------------------------*/
static HAL_CMU_HandleTypeDef hcmu_dev;      /*!< CMU device handle            */
static CMU_InitTypeDef       cmu_init;      /*!< CMU configuration structure  */
static uint32                failures = 0U; /*!< failed checks                */

static HAL_SMU_HandleTypeDef hsmu_clk;   /*!< SMU handle (lock / state / error) */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void Check(const char *name, uint32 condition);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    const uint32 modes[8] =
    {
        CMU_MODE_0, CMU_MODE_1, CMU_MODE_2, CMU_MODE_3,
        CMU_MODE_4, CMU_MODE_5, CMU_MODE_6, CMU_MODE_7
    };
    const uint32 flags[5] =
    {
        CMU_FLAG_WORK, CMU_FLAG_CHCDONE, CMU_FLAG_LOSSCLK,
        CMU_FLAG_FHH,  CMU_FLAG_FLL
    };
    CMU_TypeDef *foreign = (CMU_TypeDef *)TEST_FOREIGN_ADDRESS;
    uint32 index;
    uint32 mode_field;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL, 180 MHz core / PLLQ) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== CMU_IT_DRV_015: modes / flags / macros ===\r\n");

    __HAL_CLEAR_STRUCT(&hcmu_dev);
    hcmu_dev.Instance = CMU_PLLQ;

    while (1)
    {
        /* ---- Step 1: every monitoring mode ----------------------------- */
        printf("\r\n-----------------CMU_MODE_0..7----------------- \r\n");
        HAL_CMU_StructInit(&cmu_init);
        cmu_init.MonitoringMode = CMU_MODE_0;
        cmu_init.WindowLength   = TEST_WINDOW_LENGTH;
        cmu_init.HighThreshold  = TEST_HIGH_THRESHOLD;
        cmu_init.LowThreshold   = TEST_LOW_THRESHOLD;
        hcmu_dev.Init = cmu_init;

        Check("Init returns HAL_OK", (HAL_CMU_Init(&hcmu_dev) == HAL_OK));

        for (index = 0U; index < 8U; index++)
        {
            (void)HAL_CMU_SetMode(&hcmu_dev, modes[index]);
            mode_field = hcmu_dev.Instance->CR & CMU_CR_MODE_Msk;
            Check("SetMode programmed the requested mode",
                  (mode_field == (modes[index] << CMU_CR_MODE_Pos)));
            printf("CMU_MODE_%u -> CR.MODE field = 0x%X\r\n",
                   PRINT_U32(index), PRINT_U32(mode_field));
        }

        /* a mode outside the 3-bit field is refused at run time */
        Check("SetMode(8) refused + INVALID_PARAM",
              ((HAL_CMU_SetMode(&hcmu_dev, 8U) == HAL_ERROR) &&
               ((HAL_CMU_GetError(&hcmu_dev) & HAL_CMU_ERROR_INVALID_PARAM) != 0U)));

        /* ---- Step 2: window length and threshold bounds ---------------- */
        printf("\r\n-----------------window / threshold bounds----------------- \r\n");
        Check("SetWindowLength(CMU_WINLEN_MIN) accepted",
              (HAL_CMU_SetWindowLength(&hcmu_dev, CMU_WINLEN_MIN) == HAL_OK));
        Check("CCR = CMU_WINLEN_MIN", (hcmu_dev.Instance->CCR == CMU_WINLEN_MIN));
        Check("SetWindowLength(CMU_WINLEN_MAX) accepted",
              (HAL_CMU_SetWindowLength(&hcmu_dev, CMU_WINLEN_MAX) == HAL_OK));
        Check("CCR = CMU_WINLEN_MAX", (hcmu_dev.Instance->CCR == CMU_WINLEN_MAX));
        Check("SetWindowLength(CMU_WINLEN_MIN - 1) refused",
              (HAL_CMU_SetWindowLength(&hcmu_dev, (CMU_WINLEN_MIN - 1U)) == HAL_ERROR));
        Check("window refused value not programmed",
              (hcmu_dev.Instance->CCR == CMU_WINLEN_MAX));

        Check("SetReferenceThreshold(0, 0) accepted",
              (HAL_CMU_SetReferenceThreshold(&hcmu_dev, 0U, 0U) == HAL_OK));
        Check("SetReferenceThreshold(max, max) accepted",
              (HAL_CMU_SetReferenceThreshold(&hcmu_dev, TEST_FIELD_MAX,
                                             TEST_FIELD_MAX) == HAL_OK));
        Check("HTCR = the maximum threshold",
              (hcmu_dev.Instance->HTCR == TEST_FIELD_MAX));
        Check("LTCR = the maximum threshold",
              (hcmu_dev.Instance->LTCR == TEST_FIELD_MAX));
        Check("SetReferenceThreshold(over, over) refused",
              (HAL_CMU_SetReferenceThreshold(&hcmu_dev, TEST_FIELD_OVER,
                                             TEST_FIELD_OVER) == HAL_ERROR));

        /* restore the working configuration */
        Check("window restored",
              (HAL_CMU_SetWindowLength(&hcmu_dev, TEST_WINDOW_LENGTH) == HAL_OK));
        Check("thresholds restored",
              (HAL_CMU_SetReferenceThreshold(&hcmu_dev, TEST_HIGH_THRESHOLD,
                                             TEST_LOW_THRESHOLD) == HAL_OK));

        /* ---- Step 3: every status flag --------------------------------- */
        printf("\r\n-----------------status flags----------------- \r\n");
        for (index = 0U; index < 5U; index++)
        {
            uint32 value = HAL_CMU_GetFlagStatus(&hcmu_dev, flags[index]);
            printf("flag mask 0x%X -> %u\r\n", PRINT_U32(flags[index]), PRINT_U32(value));
            Check("a single flag query returns 0 or 1", (value <= 1U));
        }
        Check("CMU_FLAG_ALL query returns 0 or 1",
              (HAL_CMU_GetFlagStatus(&hcmu_dev, CMU_FLAG_ALL) <= 1U));
        printf("SR = 0x%X, CMU_FLAG_ALL = 0x%X\r\n",
               PRINT_U32(hcmu_dev.Instance->SR), PRINT_U32(CMU_FLAG_ALL));

        Check("ClearFlag(CMU_CLEAR_FHH) accepted",
              (HAL_CMU_ClearFlag(&hcmu_dev, CMU_CLEAR_FHH) == HAL_OK));
        Check("ClearFlag(CMU_CLEAR_FLL) accepted",
              (HAL_CMU_ClearFlag(&hcmu_dev, CMU_CLEAR_FLL) == HAL_OK));
        Check("ClearFlag(FLL | FHH) accepted",
              (HAL_CMU_ClearFlag(&hcmu_dev, (CMU_CLEAR_FLL | CMU_CLEAR_FHH)) == HAL_OK));

        /* ---- Step 4: exported register access macros ------------------- */
        printf("\r\n-----------------exported macros----------------- \r\n");
        __HAL_CMU_DISABLE(&hcmu_dev);
        mode_field = hcmu_dev.Instance->CR & CMU_CR_MODE_Msk;
        Check("__HAL_CMU_DISABLE clears CR.MODE", (mode_field == 0U));

        __HAL_CMU_ENABLE(&hcmu_dev);
        mode_field = hcmu_dev.Instance->CR & CMU_CR_MODE_Msk;
        Check("__HAL_CMU_ENABLE sets CR.MODE",
              (mode_field == (CMU_CR_MODE_Msk >> CMU_CR_MODE_Pos)));
        printf("CR after __HAL_CMU_ENABLE = 0x%X\r\n", PRINT_U32(hcmu_dev.Instance->CR));

        __HAL_CMU_CLEAR_FLAG(&hcmu_dev, (CMU_CLEAR_FLL | CMU_CLEAR_FHH));
        Check("__HAL_CMU_CLEAR_FLAG cleared the latched events",
              ((hcmu_dev.Instance->SR & (CMU_CLEAR_FLL | CMU_CLEAR_FHH)) == 0U));
        Check("__HAL_CMU_GET_FLAG reads the SR register",
              (__HAL_CMU_GET_FLAG(&hcmu_dev, CMU_FLAG_ALL) ==
               ((hcmu_dev.Instance->SR & CMU_FLAG_ALL) != 0U)));

        __HAL_CMU_DISABLE(&hcmu_dev);

        /* ---- Step 5: validation macros --------------------------------- */
        printf("\r\n-----------------IS_CMU_xxx macros----------------- \r\n");
        Check("IS_CMU_ALL_INSTANCE(CMU_FIRC) = 1", (IS_CMU_ALL_INSTANCE(CMU_FIRC) != 0U));
        Check("IS_CMU_ALL_INSTANCE(CMU_PLLQ) = 1", (IS_CMU_ALL_INSTANCE(CMU_PLLQ) != 0U));
        Check("IS_CMU_ALL_INSTANCE(CMU_PLLR) = 1", (IS_CMU_ALL_INSTANCE(CMU_PLLR) != 0U));
        Check("IS_CMU_ALL_INSTANCE(CMU_OSC) = 1", (IS_CMU_ALL_INSTANCE(CMU_OSC) != 0U));
        Check("IS_CMU_ALL_INSTANCE(foreign) = 0", (IS_CMU_ALL_INSTANCE(foreign) == 0U));

        Check("IS_CMU_MODE(CMU_MODE_0) = 1", (IS_CMU_MODE(CMU_MODE_0) != 0U));
        Check("IS_CMU_MODE(CMU_MODE_7) = 1", (IS_CMU_MODE(CMU_MODE_7) != 0U));
        Check("IS_CMU_MODE(8) = 0", (IS_CMU_MODE(8U) == 0U));

        Check("IS_CMU_WINDOW_LENGTH(MIN) = 1",
              (IS_CMU_WINDOW_LENGTH(CMU_WINLEN_MIN) != 0U));
        Check("IS_CMU_WINDOW_LENGTH(MAX) = 1",
              (IS_CMU_WINDOW_LENGTH(CMU_WINLEN_MAX) != 0U));
        Check("IS_CMU_WINDOW_LENGTH(MIN - 1) = 0",
              (IS_CMU_WINDOW_LENGTH((CMU_WINLEN_MIN - 1U)) == 0U));

        Check("IS_CMU_THRESHOLD(0) = 1", (IS_CMU_THRESHOLD(0U) != 0U));
        Check("IS_CMU_THRESHOLD(0xFFFFFF) = 1", (IS_CMU_THRESHOLD(TEST_FIELD_MAX) != 0U));
        Check("IS_CMU_THRESHOLD(0x1000000) = 0", (IS_CMU_THRESHOLD(TEST_FIELD_OVER) == 0U));

        Check("IS_CMU_FLAG(CMU_FLAG_FHH) = 1", (IS_CMU_FLAG(CMU_FLAG_FHH) != 0U));
        Check("IS_CMU_FLAG(CMU_FLAG_ALL) = 1", (IS_CMU_FLAG(CMU_FLAG_ALL) != 0U));
        Check("IS_CMU_FLAG(0) = 0", (IS_CMU_FLAG(0U) == 0U));
        Check("IS_CMU_FLAG(out of range) = 0",
              (IS_CMU_FLAG((CMU_FLAG_ALL + 1U)) == 0U));

        Check("IS_CMU_CLEAR(CMU_CLEAR_FLL) = 1", (IS_CMU_CLEAR(CMU_CLEAR_FLL) != 0U));
        Check("IS_CMU_CLEAR(FLL | FHH) = 1",
              (IS_CMU_CLEAR((CMU_CLEAR_FLL | CMU_CLEAR_FHH)) != 0U));
        Check("IS_CMU_CLEAR(0) = 0", (IS_CMU_CLEAR(0U) == 0U));

        Check("IS_CMU_ENABLE_STATE(CMU_ENABLE) = 1",
              (IS_CMU_ENABLE_STATE(CMU_ENABLE) != 0U));
        Check("IS_CMU_ENABLE_STATE(CMU_DISABLE) = 1",
              (IS_CMU_ENABLE_STATE(CMU_DISABLE) != 0U));
        Check("IS_CMU_ENABLE_STATE(2) = 0", (IS_CMU_ENABLE_STATE(2U) == 0U));

        /* ---- Step 6: an instance bound to a foreign address ------------ */
        printf("\r\n-----------------foreign instance----------------- \r\n");
        hcmu_dev.Instance = foreign;
        Check("GetState(foreign) = RESET",
              (HAL_CMU_GetState(&hcmu_dev) == HAL_CMU_STATE_RESET));
        Check("GetError(foreign) = INVALID_PARAM",
              ((HAL_CMU_GetError(&hcmu_dev) & HAL_CMU_ERROR_INVALID_PARAM) != 0U));
        hcmu_dev.Instance = CMU_PLLQ;
        Check("GetState(CMU_PLLQ) = READY again",
              (HAL_CMU_GetState(&hcmu_dev) == HAL_CMU_STATE_READY));

        printf("\r\nsummary : failures = %u\r\n", PRINT_U32(failures));
        delay_ms(TEST_POLL_MS);
    }
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition == 0U)
    {
        failures++;
    }
    printf("%-46s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Initialize the CMU MSP: enable the CMU clock gate and release the
 *         CMU reset.
 * @note   Strong override of the weak HAL_CMU_MspInit() of the driver: it
 *         reproduces the sequence of the original test case
 *         (CMUx_CLK_ENABLE(); CMUx_RESET(); CMUx_SET();), i.e. it enables the
 *         clock, asserts the reset and releases it again, so that the
 *         monitoring registers start from a known state.
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @retval None
 */
void HAL_CMU_MspInit(HAL_CMU_HandleTypeDef *hcmu)
{
    if (hcmu->Instance == CMU_FIRC)
    {
        __HAL_SMU_CMU0_CLK_ENABLE();
        __HAL_SMU_CMU0_FORCE_RESET();
        __HAL_SMU_CMU0_RELEASE_RESET();
    }
    else if (hcmu->Instance == CMU_PLLQ)
    {
        __HAL_SMU_CMU1_CLK_ENABLE();
        __HAL_SMU_CMU1_FORCE_RESET();
        __HAL_SMU_CMU1_RELEASE_RESET();
    }
    else if (hcmu->Instance == CMU_PLLR)
    {
        __HAL_SMU_CMU2_CLK_ENABLE();
        __HAL_SMU_CMU2_FORCE_RESET();
        __HAL_SMU_CMU2_RELEASE_RESET();
    }
    else
    {
        __HAL_SMU_CMU3_CLK_ENABLE();
        __HAL_SMU_CMU3_FORCE_RESET();
        __HAL_SMU_CMU3_RELEASE_RESET();
    }
}

/**
 * @brief  Configure the system clock tree using the HAL SMU / PMU drivers.
 * @note   Clock tree order (the order the chip requires): the bus clock
 *         dividers are written while the system clock is still the power-on
 *         source (FIRC), then HAL_SMU_OscConfig() programs the EFLASH
 *         controller clock, switches the system clock to the PLL and lets the
 *         flash clock follow. HAL_SMU_OscConfig() performs the EFLASH
 *         synchronization internally (CLKFRQ + EFLASH_CLK_UPDATE), so no
 *         explicit HAL_FLASH_SetClockFrequency() is needed here.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef  SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef   SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it (CLKFRQ above), so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Clock tree order: this is the order the chip requires, and the vendor
       test case uses the same one.
         1. Write the bus clock dividers while the system clock is still the
            power-on source (FIRC), so that the new divider values are already
            in place when the faster clock arrives. Writing them AFTER the
            switch instead leaves the buses at their reset dividers for a
            moment at the new core clock: at 180 MHz that is
            AXI4Bus3 = 90 MHz and APBBus0 = 45 MHz, right at their ratings, and
            the core does not survive it (measured on the board: the core
            trapped before the divider write was reached, so no output was
            produced at all).
         2. Program the EFLASH controller clock: the controller must already
            know the final frequency while the code still runs from the flash.
         3. Then configure the PLL and switch the system clock to it; this call
            also updates SystemCoreClock and re-initializes the HAL time base. */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
