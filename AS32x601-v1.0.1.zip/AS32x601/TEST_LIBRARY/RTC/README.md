# RTC 应用与测试参考

供 skill 按用户需求定位 AS32x601 HAL RTC 示例，共 14 个独立用例。

HAL 依据：[头文件](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_rtc.h)、[实现](../../HAL_LIBRARY/peripherals/src/as32x601_hal_rtc.c)。按所选案例核对当前驱动，不以接口索引代替实现依据。


## 实例与可选引脚

外部信号需按工作模式核对 RTC HAL 与板级电路。当前资料未给出完整的 RTC 专用引脚映射。系统外部振荡器的引脚可查 [SMU README](../SMU/README.md#实例与可选引脚)。

## 生成前需确认的参数

已有工程、板级资料或用户已明确的值直接复用。仅对影响本次实现的缺失选择使用参数卡询问并等待答复；案例配置不能代替实际接线或应用参数。

| 参数 | 需要核对或确认的内容 |
|---|---|
| 时钟与周期 | RTC 时钟来源、实际频率、日期时间及唤醒/闹钟周期 |
| 保持与唤醒 | 低功耗模式、时间保持需求及实际唤醒来源 |
| 外部信号 | 仅使用外部时钟或输出时确认相应引脚和电路 |

## 按需求选择

按目标行为选择，再核对完整源码；组合需求可阅读多个用例，不直接合并多个 main。

| 用户需求 / 检索关键词 | 推荐用例 | 选择条件 / 需要补充的逻辑 |
|---|---|---|
| 日历运行；跨年；时间日期设置及闹钟 | [001](RTC_IT_DRV_001.c) | 从 2024-12-31 23:59:50 开始；属于测试初值，不是当前日期 |
| RTC 闹钟唤醒 Sleep 睡眠 | [002](RTC_IT_DRV_002.c) | 同时配置 RTC 唤醒门和 PMU 唤醒源；不能强制要求回调执行 |
| 二进制时间日期读写；边界值 | [003](RTC_IT_DRV_003.c) | 使用 BIN 格式，按结构字段范围配置 |
| BCD 时间日期读写；非法 BCD 数字 | [004](RTC_IT_DRV_004.c) | BCD 与 BIN 不能混用 |
| 初始化 Size / Version 与分频校验 | [005](RTC_IT_DRV_005.c) | 接口边界测试，合法分频不等于走时精确 |
| 时间日期字段、格式、空指针参数校验 | [006](RTC_IT_DRV_006.c) | 非法参数用于测试，不照搬到应用 |
| 闹钟匹配字段；比较使能位 | [007](RTC_IT_DRV_007.c) | 按需选择参与比较的时间日期字段 |
| 普通闹钟与中断闹钟；SetAlarm / SetAlarm_IT | [008](RTC_IT_DRV_008.c) | 配置比较和使能中断是不同动作 |
| 一次性闹钟中断；关闭与重新装载 | [009](RTC_IT_DRV_009.c) | 保留中断处理和 re-arm 逻辑，不能假定自动周期运行 |
| 匹配仍成立时清除闹钟标志；重配置 | [010](RTC_IT_DRV_010.c) | 先移除比较使能，再清标志和提交新配置 |
| 句柄生命周期；日历启停；唤醒门控 | [011](RTC_IT_DRV_011.c) | 检查控制及状态，不代表实际睡眠唤醒 |
| MSP 回调顺序；重复初始化 | [012](RTC_IT_DRV_012.c) | 生命周期与回调调用次数测试 |
| 句柄合法性、状态检查与锁助手 | [013](RTC_IT_DRV_013.c) | 内部流程测试，不替代 RTOS 并发验证 |
| 公共 API、宏和常量自检 | [014](RTC_IT_DRV_014.c) | 综合接口覆盖，按具体接口读取测试段 |

## 实现要点与案例配置

基础日历参考 001 / 003，BIN 与 BCD 分别参考 003 / 004。源码测试日历是固定初值；初始化分频的合法性不等于 RTC 走时精度。示例常用分频 1785，具体按所选源码与实际时钟核对，不把测试分频当作所有板卡的 1 s 保证。

中断配置及普通闹钟差异参考 008，一次性触发和重新装载参考 009。读取 IRQ 转发与 HAL_RTC_AlarmIRQHandler / HAL_RTC_AlarmEventCallback 的完整链路。010 检查匹配条件仍成立时的清旗前提：移除比较使能后清标志，再提交新配置，避免仍然匹配导致标志重置。

002 同时使用 RTC 唤醒门、PMU RTC 唤醒源和 Sleep。源码说明睡眠入口会消耗该设备的闹钟配置，醒后 ALRMTR / ALRMDR 为零，本次唤醒不期待闹钟回调执行；应检查唤醒日历和 PMU 来源及清除结果，不能要求回调计数增加。实际睡眠唤醒与只切换 wake-up 门控（011）分别验证。

检查 HAL 返回值、配置回读、日历变化、中断/重装及失败计数；静态字段往返正确不证明跨月闰年和长期精度全部通过。自动校时、掉电保持、完整时区和网络对时没有独立应用模板。

009 的“一次性”指包含日期的匹配时刻不重复，不是回调恰好执行一次。源码允许约十分之一秒匹配窗口内出现回调突发，验证突发停止、关闭后无事件及重装后有新事件。若应用要求每个闹钟只处理一次，应另行设计事件与关闭/重装策略。中断链路为 PLIC → `RTC_IRQ_Handler()` → `HAL_RTC_AlarmIRQHandler()` → `HAL_RTC_AlarmEventCallback()`。

BCD 模式中十分之一秒始终是二进制，星期始终是枚举。当前驱动校验字段范围和 BCD 数字，但不检查月份与日期组合、闰年、星期与日期一致性；应用需要时应补充日历合法性校验，不能将 006 当作完整日历校验模板。

设置日历参考 003：先 HAL_RTC_Cmd(DISABLE) 并确认计数停止，再 SetTime / SetDate、GetTime / GetDate 回读，最后 ENABLE 恢复。当前 SetTime / SetDate 实现不替调用者自动停日历；HAL_OK 不能单独证明运行中的日历已按期望改写。连续读取跨日边界时，应用还应保证时间与日期属于同一日历快照，不能把独立调用自然视为原子读取。

## 验证方法与适用边界

每个用例是独立测试程序。选定后核对实例、引脚或地址、时钟、配置、主循环、中断与回调，按目标板调整测试初值、日志和故障制造逻辑。综合接口自检只提供对应行为参考，不代表完整产品需求已覆盖。

本次为源码静态整理，未重新编译或上板；源码已有记录、预期结果与本次验证状态分别判断。

## 按接口与辅助宏检索

索引来自去除注释和字符串后的源码调用或定义，包含本模块 HAL、锁助手、寄存器及参数校验宏。MSP、IRQ、回调可能是定义或转发入口，需结合完整实现阅读；出现不代表所有分支都已验证。

| 接口 / 宏 | 参考用例 |
|---|---|
| `HAL_RTC_AlarmEventCallback` | [001](RTC_IT_DRV_001.c)、[002](RTC_IT_DRV_002.c)、[003](RTC_IT_DRV_003.c)、[004](RTC_IT_DRV_004.c)、[005](RTC_IT_DRV_005.c)、[006](RTC_IT_DRV_006.c)、[007](RTC_IT_DRV_007.c)、[008](RTC_IT_DRV_008.c)、[009](RTC_IT_DRV_009.c)、[010](RTC_IT_DRV_010.c)、[011](RTC_IT_DRV_011.c)、[012](RTC_IT_DRV_012.c)、[013](RTC_IT_DRV_013.c)、[014](RTC_IT_DRV_014.c) |
| `HAL_RTC_AlarmIRQHandler` | [001](RTC_IT_DRV_001.c)、[002](RTC_IT_DRV_002.c)、[003](RTC_IT_DRV_003.c)、[004](RTC_IT_DRV_004.c)、[005](RTC_IT_DRV_005.c)、[006](RTC_IT_DRV_006.c)、[007](RTC_IT_DRV_007.c)、[008](RTC_IT_DRV_008.c)、[009](RTC_IT_DRV_009.c)、[010](RTC_IT_DRV_010.c)、[011](RTC_IT_DRV_011.c)、[012](RTC_IT_DRV_012.c)、[013](RTC_IT_DRV_013.c)、[014](RTC_IT_DRV_014.c) |
| `HAL_RTC_AlarmStructInit` | [001](RTC_IT_DRV_001.c)、[002](RTC_IT_DRV_002.c)、[006](RTC_IT_DRV_006.c)、[007](RTC_IT_DRV_007.c)、[008](RTC_IT_DRV_008.c)、[009](RTC_IT_DRV_009.c)、[010](RTC_IT_DRV_010.c)、[013](RTC_IT_DRV_013.c)、[014](RTC_IT_DRV_014.c) |
| `HAL_RTC_Cmd` | [001](RTC_IT_DRV_001.c)、[002](RTC_IT_DRV_002.c)、[003](RTC_IT_DRV_003.c)、[004](RTC_IT_DRV_004.c)、[006](RTC_IT_DRV_006.c)、[008](RTC_IT_DRV_008.c)、[009](RTC_IT_DRV_009.c)、[010](RTC_IT_DRV_010.c)、[011](RTC_IT_DRV_011.c)、[013](RTC_IT_DRV_013.c)、[014](RTC_IT_DRV_014.c) |
| `HAL_RTC_DateStructInit` | [001](RTC_IT_DRV_001.c)、[002](RTC_IT_DRV_002.c)、[003](RTC_IT_DRV_003.c)、[004](RTC_IT_DRV_004.c)、[006](RTC_IT_DRV_006.c)、[008](RTC_IT_DRV_008.c)、[009](RTC_IT_DRV_009.c)、[010](RTC_IT_DRV_010.c)、[011](RTC_IT_DRV_011.c)、[012](RTC_IT_DRV_012.c)、[013](RTC_IT_DRV_013.c)、[014](RTC_IT_DRV_014.c) |
| `HAL_RTC_DeInit` | [011](RTC_IT_DRV_011.c)、[012](RTC_IT_DRV_012.c)、[013](RTC_IT_DRV_013.c)、[014](RTC_IT_DRV_014.c) |
| `HAL_RTC_GetAlarm` | [001](RTC_IT_DRV_001.c)、[006](RTC_IT_DRV_006.c)、[007](RTC_IT_DRV_007.c)、[010](RTC_IT_DRV_010.c)、[013](RTC_IT_DRV_013.c)、[014](RTC_IT_DRV_014.c) |
| `HAL_RTC_GetDate` | [001](RTC_IT_DRV_001.c)、[002](RTC_IT_DRV_002.c)、[003](RTC_IT_DRV_003.c)、[004](RTC_IT_DRV_004.c)、[005](RTC_IT_DRV_005.c)、[006](RTC_IT_DRV_006.c)、[007](RTC_IT_DRV_007.c)、[008](RTC_IT_DRV_008.c)、[009](RTC_IT_DRV_009.c)、[010](RTC_IT_DRV_010.c)、[011](RTC_IT_DRV_011.c)、[012](RTC_IT_DRV_012.c)、[013](RTC_IT_DRV_013.c)、[014](RTC_IT_DRV_014.c) |
| `HAL_RTC_GetError` | [001](RTC_IT_DRV_001.c)、[002](RTC_IT_DRV_002.c)、[003](RTC_IT_DRV_003.c)、[004](RTC_IT_DRV_004.c)、[005](RTC_IT_DRV_005.c)、[006](RTC_IT_DRV_006.c)、[007](RTC_IT_DRV_007.c)、[008](RTC_IT_DRV_008.c)、[009](RTC_IT_DRV_009.c)、[010](RTC_IT_DRV_010.c)、[011](RTC_IT_DRV_011.c)、[012](RTC_IT_DRV_012.c)、[013](RTC_IT_DRV_013.c)、[014](RTC_IT_DRV_014.c) |
| `HAL_RTC_GetState` | [001](RTC_IT_DRV_001.c)、[002](RTC_IT_DRV_002.c)、[003](RTC_IT_DRV_003.c)、[004](RTC_IT_DRV_004.c)、[005](RTC_IT_DRV_005.c)、[006](RTC_IT_DRV_006.c)、[007](RTC_IT_DRV_007.c)、[008](RTC_IT_DRV_008.c)、[009](RTC_IT_DRV_009.c)、[010](RTC_IT_DRV_010.c)、[011](RTC_IT_DRV_011.c)、[012](RTC_IT_DRV_012.c)、[013](RTC_IT_DRV_013.c)、[014](RTC_IT_DRV_014.c) |
| `HAL_RTC_GetTime` | [001](RTC_IT_DRV_001.c)、[002](RTC_IT_DRV_002.c)、[003](RTC_IT_DRV_003.c)、[004](RTC_IT_DRV_004.c)、[005](RTC_IT_DRV_005.c)、[006](RTC_IT_DRV_006.c)、[007](RTC_IT_DRV_007.c)、[008](RTC_IT_DRV_008.c)、[009](RTC_IT_DRV_009.c)、[010](RTC_IT_DRV_010.c)、[011](RTC_IT_DRV_011.c)、[012](RTC_IT_DRV_012.c)、[013](RTC_IT_DRV_013.c)、[014](RTC_IT_DRV_014.c) |
| `HAL_RTC_Init` | [001](RTC_IT_DRV_001.c)、[002](RTC_IT_DRV_002.c)、[003](RTC_IT_DRV_003.c)、[004](RTC_IT_DRV_004.c)、[005](RTC_IT_DRV_005.c)、[006](RTC_IT_DRV_006.c)、[007](RTC_IT_DRV_007.c)、[008](RTC_IT_DRV_008.c)、[009](RTC_IT_DRV_009.c)、[010](RTC_IT_DRV_010.c)、[011](RTC_IT_DRV_011.c)、[012](RTC_IT_DRV_012.c)、[013](RTC_IT_DRV_013.c)、[014](RTC_IT_DRV_014.c) |
| `HAL_RTC_MspDeInit` | [012](RTC_IT_DRV_012.c)、[014](RTC_IT_DRV_014.c) |
| `HAL_RTC_MspInit` | [012](RTC_IT_DRV_012.c)、[014](RTC_IT_DRV_014.c) |
| `HAL_RTC_SetAlarm` | [006](RTC_IT_DRV_006.c)、[007](RTC_IT_DRV_007.c)、[008](RTC_IT_DRV_008.c)、[009](RTC_IT_DRV_009.c)、[010](RTC_IT_DRV_010.c)、[011](RTC_IT_DRV_011.c)、[013](RTC_IT_DRV_013.c)、[014](RTC_IT_DRV_014.c) |
| `HAL_RTC_SetAlarm_IT` | [001](RTC_IT_DRV_001.c)、[002](RTC_IT_DRV_002.c)、[006](RTC_IT_DRV_006.c)、[008](RTC_IT_DRV_008.c)、[009](RTC_IT_DRV_009.c)、[010](RTC_IT_DRV_010.c)、[014](RTC_IT_DRV_014.c) |
| `HAL_RTC_SetDate` | [001](RTC_IT_DRV_001.c)、[002](RTC_IT_DRV_002.c)、[003](RTC_IT_DRV_003.c)、[004](RTC_IT_DRV_004.c)、[006](RTC_IT_DRV_006.c)、[008](RTC_IT_DRV_008.c)、[009](RTC_IT_DRV_009.c)、[010](RTC_IT_DRV_010.c)、[011](RTC_IT_DRV_011.c)、[012](RTC_IT_DRV_012.c)、[013](RTC_IT_DRV_013.c)、[014](RTC_IT_DRV_014.c) |
| `HAL_RTC_SetTime` | [001](RTC_IT_DRV_001.c)、[002](RTC_IT_DRV_002.c)、[003](RTC_IT_DRV_003.c)、[004](RTC_IT_DRV_004.c)、[006](RTC_IT_DRV_006.c)、[008](RTC_IT_DRV_008.c)、[009](RTC_IT_DRV_009.c)、[010](RTC_IT_DRV_010.c)、[011](RTC_IT_DRV_011.c)、[012](RTC_IT_DRV_012.c)、[013](RTC_IT_DRV_013.c)、[014](RTC_IT_DRV_014.c) |
| `HAL_RTC_TimeStructInit` | [001](RTC_IT_DRV_001.c)、[002](RTC_IT_DRV_002.c)、[003](RTC_IT_DRV_003.c)、[004](RTC_IT_DRV_004.c)、[006](RTC_IT_DRV_006.c)、[008](RTC_IT_DRV_008.c)、[009](RTC_IT_DRV_009.c)、[010](RTC_IT_DRV_010.c)、[011](RTC_IT_DRV_011.c)、[012](RTC_IT_DRV_012.c)、[013](RTC_IT_DRV_013.c)、[014](RTC_IT_DRV_014.c) |
| `HAL_RTC_WakeUpCmd` | [002](RTC_IT_DRV_002.c)、[011](RTC_IT_DRV_011.c)、[014](RTC_IT_DRV_014.c) |
| `IS_RTC_ALARMDATE` | [007](RTC_IT_DRV_007.c)、[014](RTC_IT_DRV_014.c) |
| `IS_RTC_ALARMTIME` | [007](RTC_IT_DRV_007.c)、[014](RTC_IT_DRV_014.c) |
| `IS_RTC_ALL_INSTANCE` | [011](RTC_IT_DRV_011.c)、[014](RTC_IT_DRV_014.c) |
| `IS_RTC_CENTURY` | [014](RTC_IT_DRV_014.c) |
| `IS_RTC_DATE` | [014](RTC_IT_DRV_014.c) |
| `IS_RTC_DIVISION` | [005](RTC_IT_DRV_005.c)、[014](RTC_IT_DRV_014.c) |
| `IS_RTC_FORMAT` | [014](RTC_IT_DRV_014.c) |
| `IS_RTC_HOURS` | [014](RTC_IT_DRV_014.c) |
| `IS_RTC_INIT_STRUCT_OK` | [005](RTC_IT_DRV_005.c)、[014](RTC_IT_DRV_014.c) |
| `IS_RTC_MINUTES` | [014](RTC_IT_DRV_014.c) |
| `IS_RTC_MONTH` | [014](RTC_IT_DRV_014.c) |
| `IS_RTC_SECONDS` | [014](RTC_IT_DRV_014.c) |
| `IS_RTC_TENOFSECOND` | [014](RTC_IT_DRV_014.c) |
| `IS_RTC_WEEKDAY` | [014](RTC_IT_DRV_014.c) |
| `IS_RTC_YEAR` | [014](RTC_IT_DRV_014.c) |
| `RTC_CheckState` | [013](RTC_IT_DRV_013.c) |
| `RTC_HandleIsValid` | [013](RTC_IT_DRV_013.c) |
| `RTC_IRQ_Handler` | [001](RTC_IT_DRV_001.c)、[002](RTC_IT_DRV_002.c)、[003](RTC_IT_DRV_003.c)、[004](RTC_IT_DRV_004.c)、[005](RTC_IT_DRV_005.c)、[006](RTC_IT_DRV_006.c)、[007](RTC_IT_DRV_007.c)、[008](RTC_IT_DRV_008.c)、[009](RTC_IT_DRV_009.c)、[010](RTC_IT_DRV_010.c)、[011](RTC_IT_DRV_011.c)、[012](RTC_IT_DRV_012.c)、[013](RTC_IT_DRV_013.c)、[014](RTC_IT_DRV_014.c) |
| `RTC_LockHandle` | [013](RTC_IT_DRV_013.c) |
| `RTC_UnlockHandle` | [013](RTC_IT_DRV_013.c) |
| `__HAL_RTC_CLEAR_FLAG` | [008](RTC_IT_DRV_008.c)、[009](RTC_IT_DRV_009.c)、[010](RTC_IT_DRV_010.c)、[014](RTC_IT_DRV_014.c) |
| `__HAL_RTC_DISABLE` | [011](RTC_IT_DRV_011.c)、[014](RTC_IT_DRV_014.c) |
| `__HAL_RTC_DISABLE_IT` | [008](RTC_IT_DRV_008.c)、[009](RTC_IT_DRV_009.c)、[010](RTC_IT_DRV_010.c)、[014](RTC_IT_DRV_014.c) |
| `__HAL_RTC_ENABLE` | [011](RTC_IT_DRV_011.c)、[014](RTC_IT_DRV_014.c) |
| `__HAL_RTC_ENABLE_IT` | [008](RTC_IT_DRV_008.c)、[014](RTC_IT_DRV_014.c) |
| `__HAL_RTC_GET_FLAG` | [008](RTC_IT_DRV_008.c)、[010](RTC_IT_DRV_010.c)、[014](RTC_IT_DRV_014.c) |
| `__HAL_RTC_GET_IT_SOURCE` | [008](RTC_IT_DRV_008.c)、[011](RTC_IT_DRV_011.c)、[014](RTC_IT_DRV_014.c) |
| `__HAL_RTC_RESET_HANDLE_STATE` | [011](RTC_IT_DRV_011.c)、[012](RTC_IT_DRV_012.c)、[014](RTC_IT_DRV_014.c) |
| `__HAL_RTC_WAKEUPTIMER_DISABLE` | [011](RTC_IT_DRV_011.c) |
| `__HAL_RTC_WAKEUPTIMER_ENABLE` | [011](RTC_IT_DRV_011.c) |

