/**
 * @file    RTC_IT_DRV_002.c
 * @brief   HAL RTC integration test case 002: RTC alarm wake-up from sleep mode (reference case 002).
 *
 * One-to-one HAL library port of the reference test case RTC_IT_DRV_002.c of the
 * chip vendor: the RTC alarm is used as the wake-up source of the PMU and the core
 * is put into sleep mode; the alarm interrupt wakes it up again. Only HAL library
 * APIs are used.
 *
 * Tested functionality:
 *   HAL_RTC_Init() / HAL_RTC_Cmd()
 *   HAL_RTC_SetTime() / HAL_RTC_GetTime()
 *   HAL_RTC_SetDate() / HAL_RTC_GetDate()
 *   HAL_RTC_AlarmStructInit() / HAL_RTC_SetAlarm_IT()
 *   HAL_RTC_WakeUpCmd()
 *   HAL_RTC_AlarmIRQHandler() / HAL_RTC_AlarmEventCallback()
 *   HAL_RTC_GetState() / HAL_RTC_GetError()
 *   HAL_PMU_Init() / HAL_PMU_WakeUpSourceCmd() / HAL_PMU_PowerModeConfig()
 *   HAL_PMU_GetFlagStatus() / HAL_PMU_GetWakeUpFlag() / HAL_PMU_ClearFlag()
 *   HAL_PLIC_Init() (RTC alarm interrupt line)
 *
 * Expected behaviour:
 *   - the wake-up gate (WUCR.WUTE) reads back enabled and the PMU wake-up source
 *     register (WKEN) contains the RTC bit before the mode is entered;
 *   - the core enters sleep mode and the RTC alarm brings it back: the calendar
 *     read after the wake is the alarm instant, and the wake-up source register
 *     of the PMU reports the RTC;
 *   - the sleep entry consumes the alarm configuration of this device (ALRMTR
 *     and ALRMDR read back as zero afterwards), so CR.ALRMT is not asserted again
 *     and the alarm callback is not expected to run for this wake-up;
 *   - after the wake-up the RTC wake-up flag is reported and cleared, and the
 *     wake-up source is verified.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* RTC divider coefficient. 1785 is the project baseline of the reference test
 * cases of this chip, 1638 is the other value documented by the library SRS;
 * both are legal hardware values (the driver only checks the 27 bit field
 * width). No test below depends on the resulting absolute frequency: the
 * checks are register read-backs or "the counter moved" observations. */
#define TEST_RTC_DIVISION           (1785U)

/* Calendar value used by the cases that need a known starting point */
#define TEST_TIME_HOURS             (15U)
#define TEST_TIME_MINUTES           (48U)
#define TEST_TIME_SECONDS           (0U)
#define TEST_TIME_TOS               (0U)
#define TEST_DATE_CENTURY           (20U)
#define TEST_DATE_YEAR              (25U)
#define TEST_DATE_MONTH             (RTC_Month_July)
#define TEST_DATE_DATE              (21U)
#define TEST_DATE_WEEKDAY           (RTC_Weekday_Monday)

/* Polling slice of the wait loops (ms) */
#define TEST_POLL_MS                (10U)

/* Reporting period of the final idle loop (ms) */
#define TEST_IDLE_MS                (1000U)

/* Alarm offset of this case (s): the reference case wakes the core 20 s after
 * the calendar has been programmed */
#define TEST_WAKE_OFFSET_S          (20U)

/* Private variables ---------------------------------------------------------*/
static RTC_HandleTypeDef hrtc_dev;          /*!< RTC device handle            */
static RTC_InitTypeDef   rtc_init;          /*!< RTC configuration structure  */
static uint32            failures = 0U;     /*!< failed checks                */

/* Alarm interrupt bookkeeping (filled by the overridden weak callback) */
static volatile uint32   alarm_events = 0U; /*!< callback entries             */
static volatile uint32   alarm_cr_seen = 0U;/*!< CR register at callback time */

/* PMU handle and the wake-up report of this case */
static HAL_PMU_HandleTypeDef hpmu_dev;
static volatile uint32       source_flag_seen = 0U;
static RTC_AlarmTypeDef      alarm;

/* Last calendar read back by the report helpers */
static uint8 r_time_hours;
static uint8 r_time_minutes;
static uint8 r_time_seconds;
static uint8 r_time_tos;
static uint8 r_date_century;
static uint8 r_date_year;
static uint8 r_date_month;
static uint8 r_date_date;
static uint8 r_date_weekday;

/* Private function prototypes -----------------------------------------------*/
static void Check(const char *name, uint32 condition);
static void SystemClock_Init(void);
static void PMU_Init(void);
static void ReportWakeUpFlags(void);
static void Rtc_Handle_Setup(void);
static HAL_StatusTypeDef Rtc_Start(void);
static HAL_StatusTypeDef Rtc_SetCalendar(uint8 hours, uint8 minutes, uint8 seconds, uint8 tos,
                                         uint8 century, uint8 year, uint8 month, uint8 date,
                                         uint8 weekday);
static HAL_StatusTypeDef Rtc_GetCalendar(void);
static uint8 Rtc_MonthToNumber(uint8 month);
static const char *Rtc_WeekdayName(uint8 weekday);
static void Rtc_PrintCalendar(const char *tag);
static void Plc_RouteRtcIrq(void);

/* Exported interrupt entry ------------------------------------------------*/
/**
 * @brief  RTC interrupt entry, called by the shared PLIC dispatch table.
 * @note   Overrides the weak RTC_IRQ_Handler() of the PLIC driver; it hands the
 *         event to the HAL RTC interrupt handler, which clears the alarm flag
 *         and then calls HAL_RTC_AlarmEventCallback().
 */
void RTC_IRQ_Handler(void)
{
    HAL_RTC_AlarmIRQHandler(&hrtc_dev);
}

/**
 * @brief  Alarm event callback (weak function of the HAL RTC driver).
 * @note   Counts the events and snapshots CR so that the cases can observe the
 *         flag state the driver left behind. It must not block and must not
 *         call a locking RTC interface (interrupt context).
 * @param  hrtc pointer to a RTC_HandleTypeDef structure.
 * @retval None
 */
void HAL_RTC_AlarmEventCallback(RTC_HandleTypeDef *hrtc)
{
    UNUSED(hrtc);

    alarm_events++;
    alarm_cr_seen = hrtc_dev.Instance->CR;
}

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock tree */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n\r\n==== RTC_IT_DRV_002: RTC alarm wake-up from sleep mode (reference case 002) ====\r\n");
    printf("Data : %s\r\n", __DATE__);
    printf("Time : %s\r\n", __TIME__);

        /* ---- Step 1: PMU initialization ------------------------------------ */
        PMU_Init();

        /* Report a wake-up left over by a previous run (sleep mode keeps the RAM
           content, but a flag left set by an earlier run must not be mistaken for
           the event of this run). */
        ReportWakeUpFlags();

        /* ---- Step 2: RTC and its alarm interrupt --------------------------- */
        Plc_RouteRtcIrq();
        Check("RTC init", (Rtc_Start() == HAL_OK));

        Check("calendar programmed",
              (Rtc_SetCalendar(TEST_TIME_HOURS, TEST_TIME_MINUTES, TEST_TIME_SECONDS,
                               TEST_TIME_TOS, TEST_DATE_CENTURY, TEST_DATE_YEAR,
                               TEST_DATE_MONTH, TEST_DATE_DATE,
                               TEST_DATE_WEEKDAY) == HAL_OK));
        (void)Rtc_GetCalendar();
        Check("calendar read back", ((r_time_hours == TEST_TIME_HOURS) &&
                                     (r_time_seconds == TEST_TIME_SECONDS) &&
                                     (r_date_date == TEST_DATE_DATE)));
        Rtc_PrintCalendar("start");

        /* Alarm a few seconds ahead on the very same day: the time-of-day fields
           and the date are compared, so the event is unique. */
        __HAL_CLEAR_STRUCT(&alarm);
        HAL_RTC_AlarmStructInit(&alarm);
        alarm.RTC_AlarmTime.RTC_Hours         = TEST_TIME_HOURS;
        alarm.RTC_AlarmTime.RTC_Minutes       = TEST_TIME_MINUTES;
        alarm.RTC_AlarmTime.RTC_Seconds       = TEST_TIME_SECONDS + TEST_WAKE_OFFSET_S;
        alarm.RTC_AlarmTime.RTC_TenthOfSecond = TEST_TIME_TOS;
        alarm.RTC_AlarmDate.RTC_WeekDay       = TEST_DATE_WEEKDAY;
        alarm.RTC_AlarmDate.RTC_Century       = TEST_DATE_CENTURY;
        alarm.RTC_AlarmDate.RTC_Year          = TEST_DATE_YEAR;
        alarm.RTC_AlarmDate.RTC_Month         = TEST_DATE_MONTH;
        alarm.RTC_AlarmDate.RTC_Date          = TEST_DATE_DATE;
        alarm.RTC_AlarmTimeCompEn = RTC_AlarmTime_Hours | RTC_AlarmTime_Minutes |
                                    RTC_AlarmTime_Seconds | RTC_AlarmTime_TenOfSecond;
        alarm.RTC_AlarmDataCompEn = RTC_AlarmDate_Year | RTC_AlarmDate_Month |
                                    RTC_AlarmDate_Date;
        Check("alarm programmed (interrupt enabled)",
              (HAL_RTC_SetAlarm_IT(&hrtc_dev, &alarm, RTC_FORMAT_BIN) == HAL_OK));

        /* Wake-up gate of the RTC and the calendar itself */
        HAL_RTC_WakeUpCmd(&hrtc_dev, ENABLE);
        Check("wake-up enable bit set", ((RTC->WUCR & RTC_WUCR_WUTE) != 0U));
        Check("calendar enabled", (HAL_RTC_Cmd(&hrtc_dev, ENABLE) == HAL_OK));

        /* ---- Step 3: enable the RTC wake-up source of the PMU -------------- */
        Check("PMU wake-up source (RTC) enabled",
              (HAL_PMU_WakeUpSourceCmd(&hpmu_dev, HAL_PMU_WKSOURCE_RTC, ENABLE) == HAL_OK));
        printf("WKEN = 0x%X before entering sleep\r\n",
               PRINT_U32(hpmu_dev.Instance->WKEN));
        Check("WKEN holds the RTC wake-up source",
              ((hpmu_dev.Instance->WKEN & (uint32)HAL_PMU_WKSOURCE_RTC) != 0U));

        /* ---- Step 4: enter sleep mode (the RTC alarm wakes the core) ------- */
        printf("entering sleep mode, RTC alarm in %u s\r\n",
               PRINT_U32(TEST_WAKE_OFFSET_S));
        Check("sleep mode accepted",
              (HAL_PMU_PowerModeConfig(&hpmu_dev, HAL_PMU_POWERMODE_SLEEP) == HAL_OK));

        /* ---- Step 5: back from sleep --------------------------------------- */
        printf("woken up, alarm events = %u\r\n", PRINT_U32(alarm_events));
        printf("after the wake: ALRMTR = 0x%X, ALRMDR = 0x%X\r\n",
               PRINT_U32(RTC->ALRMTR), PRINT_U32(RTC->ALRMDR));

        /* The sleep entry of this device consumes the alarm configuration: after
           the wake ALRMTR and ALRMDR read back as zero, so the match condition no
           longer exists, CR.ALRMT is not asserted again and the callback is not
           entered (the ISR is not even taken). The wake-up itself is proven by
           the calendar having reached the alarm instant and, independently, by
           the wake-up source reported by the PMU in step 5b. */
        Check("RTC state is READY after the wake-up",
              (HAL_RTC_GetState(&hrtc_dev) == HAL_RTC_STATE_READY));
        Rtc_PrintCalendar("after");
        Check("calendar reached the alarm instant",
              ((r_time_hours == TEST_TIME_HOURS) && (r_time_minutes == TEST_TIME_MINUTES) &&
               (r_time_seconds == (uint8)(TEST_TIME_SECONDS + TEST_WAKE_OFFSET_S)) &&
               (r_date_date == TEST_DATE_DATE)));

        /* ---- Step 5b: the wake-up flag of the PMU reports the source ------- */
        ReportWakeUpFlags();
        Check("RTC wake-up flag reported by the PMU", (source_flag_seen != 0U));

        /* ---- Step 6: the wake-up gate can be closed again ------------------ */
        HAL_RTC_WakeUpCmd(&hrtc_dev, DISABLE);
        Check("wake-up enable bit cleared", ((RTC->WUCR & RTC_WUCR_WUTE) == 0U));
        Check("alarm interrupt disabled again",
              (HAL_OK == HAL_PMU_WakeUpSourceCmd(&hpmu_dev, HAL_PMU_WKSOURCE_RTC, DISABLE)));
    /* ---- summary ------------------------------------------------------- */
    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(failures));

    /* Idle: keep the calendar observable on the console */
    while (1)
    {
        Rtc_PrintCalendar("idle");
        delay_ms(TEST_IDLE_MS);
    }
}

/* Private functions --------------------------------------------------------*/
/**
 * @brief  PMU wake-up flag table: flag selector, clear value and source name.
 * @note  Every wake-up flag of the PMU is listed, so an unexpected wake-up
 *        source is reported instead of being silently ignored.
 */
typedef struct
{
    uint32      Flag;                       /*!< PMU_FLAG_xxx selector        */
    uint32      Clear;                      /*!< PMU_CLEAR_xxx write value    */
    const char *Name;                       /*!< wake-up source name          */
} WakeUpFlagTypeDef;

static const WakeUpFlagTypeDef wakeup_flags[] =
{
    { PMU_FLAG_IWDGWK, PMU_CLEAR_IWDGWKF, "IWDG" },
    { PMU_FLAG_RTCWK,  PMU_CLEAR_RTCWKF,  "RTC"  },
    { PMU_FLAG_PH0WK,  PMU_CLEAR_PH0WKF,  "PH0"  },
    { PMU_FLAG_PH1WK,  PMU_CLEAR_PH1WKF,  "PH1"  },
    { PMU_FLAG_PH2WK,  PMU_CLEAR_PH2WKF,  "PH2"  },
    { PMU_FLAG_PH3WK,  PMU_CLEAR_PH3WKF,  "PH3"  },
    { PMU_FLAG_PH4WK,  PMU_CLEAR_PH4WKF,  "PH4"  },
    { PMU_FLAG_PH5WK,  PMU_CLEAR_PH5WKF,  "PH5"  },
    { PMU_FLAG_PH6WK,  PMU_CLEAR_PH6WKF,  "PH6"  },
    { PMU_FLAG_PH7WK,  PMU_CLEAR_PH7WKF,  "PH7"  },
    { PMU_FLAG_PH8WK,  PMU_CLEAR_PH8WKF,  "PH8"  },
    { PMU_FLAG_PH9WK,  PMU_CLEAR_PH9WKF,  "PH9"  },
    { PMU_FLAG_FOCUR,  PMU_CLEAR_FOCURF,  "FOCU" },
};

/**
 * @brief  Read every PMU wake-up flag; print and clear the ones that are set.
 * @note   The flag of the expected source additionally arms the "expected
 *         wake-up source reported" check, and the clear operation is verified
 *         afterwards (the wake-up flags are cleared by writing one to WKFR).
 * @param  None
 * @retval None
 */
static void ReportWakeUpFlags(void)
{
    uint32 index;
    uint32 count;

    count = (uint32)(sizeof(wakeup_flags) / sizeof(wakeup_flags[0]));

    for (index = 0U; index < count; index++)
    {
        if (HAL_PMU_GetFlagStatus(&hpmu_dev, wakeup_flags[index].Flag) != 0U)
        {
            printf("%s wake up!\r\n", wakeup_flags[index].Name);
            (void)HAL_PMU_ClearFlag(&hpmu_dev, wakeup_flags[index].Clear);

            if (wakeup_flags[index].Flag == (uint32)PMU_FLAG_RTCWK)
            {
                source_flag_seen = 1U;
            }
        }
    }

    (void)HAL_PMU_ClearFlag(&hpmu_dev, PMU_CLEAR_RTCWKF);
    printf("WKFR = 0x%X after clearing the reported flags\r\n",
           PRINT_U32(hpmu_dev.Instance->WKFR));
    Check("wake-up flag acknowledged (WKFR cleared)",
          (HAL_PMU_GetFlagStatus(&hpmu_dev, PMU_FLAG_RTCWK) == 0U));
}

/**
 * @brief  Initialize the PMU handle.
 * @note   HAL_PMU_Init() must run before the wake-up source API: it is gated on
 *         the handle state and refuses to work on a RESET handle.
 * @param  None
 * @retval None
 */
static void PMU_Init(void)
{
    __HAL_CLEAR_STRUCT(&hpmu_dev);
    hpmu_dev.Instance = PMU;

    Check("PMU init", (HAL_PMU_Init(&hpmu_dev) == HAL_OK));
    printf("PMU state = %u (1 = READY), error = %u\r\n",
           PRINT_U32(HAL_PMU_GetState(&hpmu_dev)),
           PRINT_U32(HAL_PMU_GetError(&hpmu_dev)));
}

/**
 * @brief  Prepare the RTC handle and its configuration structure.
 * @note   The configuration structure metafields (Size / Version / reserved
 *         words) are mandatory: HAL_RTC_Init() validates them at run time and
 *         rejects a structure that does not carry them.
 * @param  None
 * @retval None
 */
static void Rtc_Handle_Setup(void)
{
    __HAL_CLEAR_STRUCT(&hrtc_dev);
    hrtc_dev.Instance = RTC;

    __HAL_CLEAR_STRUCT(&rtc_init);
    rtc_init.Size     = sizeof(RTC_InitTypeDef);
    rtc_init.Version  = RTC_INIT_VERSION;
    rtc_init.Division = TEST_RTC_DIVISION;
    hrtc_dev.Init     = rtc_init;
}

/**
 * @brief  Initialize the RTC and report its state.
 * @param  None
 * @retval HAL status of the initialization.
 */
static HAL_StatusTypeDef Rtc_Start(void)
{
    HAL_StatusTypeDef status;

    Rtc_Handle_Setup();
    status = HAL_RTC_Init(&hrtc_dev);
    printf("RTC state = %u (1 = READY), error = %u\r\n",
           PRINT_U32(HAL_RTC_GetState(&hrtc_dev)),
           PRINT_U32(HAL_RTC_GetError(&hrtc_dev)));

    return status;
}

/**
 * @brief  Write the calendar (time and date) of the RTC.
 * @param  hours / minutes / seconds / tos: time fields.
 * @param  century / year / month / date / weekday: date fields.
 * @retval HAL_OK when both writes succeeded.
 */
static HAL_StatusTypeDef Rtc_SetCalendar(uint8 hours, uint8 minutes, uint8 seconds, uint8 tos,
                                         uint8 century, uint8 year, uint8 month, uint8 date,
                                         uint8 weekday)
{
    RTC_TimeTypeDef time;
    RTC_DateTypeDef dateS;
    HAL_StatusTypeDef status;

    __HAL_CLEAR_STRUCT(&time);
    __HAL_CLEAR_STRUCT(&dateS);
    HAL_RTC_TimeStructInit(&time);
    HAL_RTC_DateStructInit(&dateS);

    time.RTC_Hours         = hours;
    time.RTC_Minutes       = minutes;
    time.RTC_Seconds       = seconds;
    time.RTC_TenthOfSecond = tos;

    dateS.RTC_WeekDay = weekday;
    dateS.RTC_Century = century;
    dateS.RTC_Year    = year;
    dateS.RTC_Month   = month;
    dateS.RTC_Date    = date;

    status = HAL_RTC_SetTime(&hrtc_dev, &time, RTC_FORMAT_BIN);
    if (status == HAL_OK)
    {
        status = HAL_RTC_SetDate(&hrtc_dev, &dateS, RTC_FORMAT_BIN);
    }

    return status;
}

/**
 * @brief  Read the calendar into the report globals.
 * @param  None
 * @retval HAL status of the read (HAL_ERROR when a read was refused).
 */
static HAL_StatusTypeDef Rtc_GetCalendar(void)
{
    RTC_TimeTypeDef time;
    RTC_DateTypeDef dateS;
    HAL_StatusTypeDef status;

    __HAL_CLEAR_STRUCT(&time);
    __HAL_CLEAR_STRUCT(&dateS);

    status = HAL_RTC_GetTime(&hrtc_dev, &time, RTC_FORMAT_BIN);
    if (status == HAL_OK)
    {
        status = HAL_RTC_GetDate(&hrtc_dev, &dateS, RTC_FORMAT_BIN);
    }
    if (status != HAL_OK)
    {
        return status;
    }

    r_time_hours   = time.RTC_Hours;
    r_time_minutes = time.RTC_Minutes;
    r_time_seconds = time.RTC_Seconds;
    r_time_tos     = time.RTC_TenthOfSecond;

    r_date_century = dateS.RTC_Century;
    r_date_year    = dateS.RTC_Year;
    r_date_month   = dateS.RTC_Month;
    r_date_date    = dateS.RTC_Date;
    r_date_weekday = dateS.RTC_WeekDay;

    return HAL_OK;
}

/**
 * @brief  Translate a month constant to its number (1-12).
 * @param  month: month (RTC_Month_xxx).
 * @retval uint8: month number, or 0 when the value is unknown.
 */
static uint8 Rtc_MonthToNumber(uint8 month)
{
    uint8 result;

    switch (month)
    {
        case RTC_Month_January:   result = 1U;  break;
        case RTC_Month_February:  result = 2U;  break;
        case RTC_Month_March:     result = 3U;  break;
        case RTC_Month_April:     result = 4U;  break;
        case RTC_Month_May:       result = 5U;  break;
        case RTC_Month_June:      result = 6U;  break;
        case RTC_Month_July:      result = 7U;  break;
        case RTC_Month_August:    result = 8U;  break;
        case RTC_Month_September: result = 9U;  break;
        case RTC_Month_October:   result = 10U; break;
        case RTC_Month_November:  result = 11U; break;
        case RTC_Month_December:  result = 12U; break;
        default:                  result = 0U;  break;
    }

    return result;
}

/**
 * @brief  Translate a weekday constant to its name.
 * @param  weekday: weekday (RTC_Weekday_xxx).
 * @retval const char*: weekday name, or "?" when the value is unknown.
 */
static const char *Rtc_WeekdayName(uint8 weekday)
{
    switch (weekday)
    {
        case RTC_Weekday_Monday:    return "Monday";
        case RTC_Weekday_Tuesday:   return "Tuesday";
        case RTC_Weekday_Wednesday: return "Wednesday";
        case RTC_Weekday_Thursday:  return "Thursday";
        case RTC_Weekday_Friday:    return "Friday";
        case RTC_Weekday_Saturday:  return "Saturday";
        case RTC_Weekday_Sunday:    return "Sunday";
        default:                    return "?";
    }
}

/**
 * @brief  Read and print the calendar.
 * @param  tag: text printed in front of the value (may be NULL).
 * @retval None
 */
static void Rtc_PrintCalendar(const char *tag)
{
    if (Rtc_GetCalendar() != HAL_OK)
    {
        printf("%s calendar read refused (state = %u)\r\n",
               ((tag != NULL_PTR) ? tag : ""),
               PRINT_U32(HAL_RTC_GetState(&hrtc_dev)));
        return;
    }

    printf("%s %02u-%02u-%02u %02u:%02u:%02u.%u %s\r\n",
           ((tag != NULL_PTR) ? tag : ""),
           PRINT_U32(r_date_century), PRINT_U32(Rtc_MonthToNumber(r_date_month)),
           PRINT_U32(r_date_date), PRINT_U32(r_time_hours), PRINT_U32(r_time_minutes),
           PRINT_U32(r_time_seconds), PRINT_U32(r_time_tos),
           Rtc_WeekdayName(r_date_weekday));
}

/**
 * @brief  Route the RTC alarm interrupt line through the PLIC.
 * @note   The RTC alarm is the only interrupt source of the module; the shared
 *         trap entry dispatches it to RTC_IRQ_Handler() overridden above.
 * @param  None
 * @retval None
 */
static void Plc_RouteRtcIrq(void)
{
    PLIC_InitTypeDef plic_init;

    __HAL_CLEAR_STRUCT(&plic_init);
    plic_init.Size               = sizeof(plic_init);
    plic_init.Version            = PLIC_INIT_VERSION;
    plic_init.PLIC_IRQChannel    = RTC_IRQn;
    plic_init.PLIC_IRQPriority   = 1U;
    plic_init.PLIC_IRQChannelCmd = ENABLE;
    HAL_PLIC_Init(&plic_init);

    Check("RTC interrupt routed in the PLIC",
          (PLIC->AXI_PLIC_PRIORITY[RTC_IRQn - 1U] == 1U));
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition == 0U)
    {
        failures++;
    }
    printf("%-44s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Configure the system clock tree using the HAL SMU driver.
 * @note   Clock tree shared by every integration test suite of this library:
 *         OSC 20 MHz as the PLL source, PLLDivR = 0x04 / PLLDivN = 0x14 /
 *         PLLDivF = 0xB4 / PLLDivQ = 0x01, then AXI4Bus3 = /2, APBBus0 = /2,
 *         APBBus1 = /2 and CANX2 = /8. The bus dividers are written first and
 *         the PLL is switched in afterwards, which is the order the chip
 *         requires (see HAL_SMU_OscConfig()).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;
    HAL_SMU_HandleTypeDef hsmu_clk;

    /* Enable the bus clock gates */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* The RTC lives in the always-on APB-BusS domain: it has no clock gate of
       its own, the module switch of the configuration file is enough. */

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Bus dividers first (the system clock is still the power-on source) */
    __HAL_CLEAR_STRUCT(&SMU_ClockInitStruct);
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;
    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) and switch to it; the
       call also programs the EFLASH controller clock before the switch. */
    __HAL_CLEAR_STRUCT(&SMU_OscInitStruct);
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
