/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_crc.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.2
 * Date:   2026/09/17
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/09/17     1.2     align the resource lock and the RTOS support with
 *                                                       the architecture specification (sections 13 and
 *                                                       21): give the lock helper a Timeout and a NULL
 *                                                       mutex guard (RTOS-11) and export it as
 *                                                       CRC_LockHandle / CRC_UnlockHandle in the shared
 *                                                       section, run the MSP callbacks outside the locked
 *                                                       region (LOCK-06) with the MSP init on the first
 *                                                       initialization only (MSP-04) and before the
 *                                                       register programming, and add the ARCH-CONST-09
 *                                                       state gate to the register accessing APIs
 *     ANSILIC APPLICATION GROUP  2026/08/24     1.1     fix input format, instance validation and transaction locking
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.0     build this module
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Cyclic Redundancy
 *                  Check (CRC) computation unit, as a HAL peripheral driver
 *                  of this library:
 *                  - Initialization and de-initialization: HAL_CRC_Init /
 *                    HAL_CRC_DeInit, configuration structure handling;
 *                  - CRC computation: single data word, word / half-word /
 *                    byte blocks (calculate and accumulate);
 *                  - Peripheral control: reset, independent data register
 *                    access, result read-back.
 *                  The CRC unit of the AS32x601 computes a programmable
 *                  polynomial CRC (7 / 8 / 16 / 32-bit degree) over a
 *                  configurable data size (8 / 16 / 32-bit), with
 *                  configurable input data reversal, output reversal and
 *                  output XOR.
 * @complexity  Medium
 *              State machine + lock, polling only (no interrupt / DMA modes).
 */
#ifndef __AS32X601_HAL_CRC_H
#define __AS32X601_HAL_CRC_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "as32x601.h"               /* CRC_TypeDef, CRC register bits         */
#include "as32x601_hal_def.h"       /* HAL_StatusTypeDef, HAL_LockTypeDef     */

/**
 * @brief CRC HAL driver module version.
 * @note  0x0100U = V1.0. Bumped only on breaking API changes (architecture
 *        spec COMPAT-13/14/15).
 */
#define __HAL_CRC_MODULE_VERSION  0x0100U

/* Exported types ------------------------------------------------------------*/

/** @defgroup CRC_Exported_Types CRC Exported Types
  * @{
  */

/**
 * @brief CRC calculated data size enumeration.
 */
typedef enum
{
    CRC_SIZE_8B  = 0x00U,    /*!< Calculate data size of 8-bit  */
    CRC_SIZE_16B = 0x01U,    /*!< Calculate data size of 16-bit */
    CRC_SIZE_32B = 0x02U     /*!< Calculate data size of 32-bit */
} CRC_SizeTypeDef;

/**
 * @brief CRC input data reversal mode enumeration.
 */
typedef enum
{
    CRC_IREVERSE_NONE  = 0x00U,  /*!< Does not affect the bit order       */
    CRC_IREVERSE_BYTE  = 0x01U,  /*!< Perform bit reversal by byte        */
    CRC_IREVERSE_HALF  = 0x02U,  /*!< Perform bit reversal by half-word   */
    CRC_IREVERSE_WORD  = 0x03U   /*!< Perform bit reversal by word        */
} CRC_IReverseTypeDef;

/**
 * @brief CRC polynomial size enumeration.
 */
typedef enum
{
    CRC_POLYSIZE_32B = 0x00U,    /*!< 32-bit polynomial */
    CRC_POLYSIZE_16B = 0x01U,    /*!< 16-bit polynomial */
    CRC_POLYSIZE_8B  = 0x02U,    /*!< 8-bit polynomial  */
    CRC_POLYSIZE_7B  = 0x03U     /*!< 7-bit polynomial  */
} CRC_PolySizeTypeDef;

/**
 * @brief CRC configuration structure definition.
 * @note  This structure follows the Version+Size compatibility mechanism
 *        (architecture spec section 22): the user must clear the structure
 *        (__HAL_CLEAR_STRUCT / memset), set the Size and Version metafields
 *        before filling the business fields (see HAL_CRC_StructInit()).
 */
typedef struct
{
    uint32              Size;           /*!< sizeof(CRC_InitTypeDef), must be set by the user
                                             after clearing the structure           */
    uint32              Version;        /*!< Structure semantic version: @ref CRC_INIT_VERSION
                                             (CRC_INIT_V1 = 0x0100U)                */
    CRC_SizeTypeDef     CRC_Size;       /*!< Calculated data size: CRC_SIZE_8B / 16B / 32B  */
    uint32              CRC_OXOR;       /*!< Output XOR: CRC_OXOR_DISABLE / CRC_OXOR_ENABLE  */
    uint32              CRC_OReverse;   /*!< Output reversal: CRC_OREVERSE_NOT / CRC_OREVERSE_BIT */
    CRC_IReverseTypeDef CRC_IReverse;   /*!< Input reversal mode: CRC_IREVERSE_xxx            */
    CRC_PolySizeTypeDef CRC_PolySize;   /*!< Polynomial size: CRC_POLYSIZE_32B / 16B / 8B / 7B */
    uint32              CRC_INIT;       /*!< Initial value of the CRC calculation              */
    uint32              CRC_Poly;       /*!< Generating polynomial                              */
    uint32              CRC_XOR;        /*!< XOR value applied to the calculation result       */
    uint32              Reserved[2];    /*!< Reserved for future extension (must be 0)          */
} CRC_InitTypeDef;

/**
 * @brief CRC / init structure version macros.
 * @note  CRC_INIT_V1 is the current version. Future versions (e.g. V2 with
 *        new fields) must be appended after the existing fields without
 *        changing the layout (architecture spec section 22.5).
 */
#define CRC_INIT_V1  0x0100U   /*!< CRC Init structure version V1.0 */
#define CRC_INIT_VERSION  CRC_INIT_V1   /*!< Current CRC Init structure version */

typedef enum
{
    HAL_CRC_STATE_RESET     = 0x00U, /*!< Peripheral not initialized              */
    HAL_CRC_STATE_READY     = 0x01U, /*!< Peripheral initialized and ready        */
    HAL_CRC_STATE_BUSY      = 0x02U, /*!< An internal process is ongoing          */
    HAL_CRC_STATE_ERROR     = 0x03U  /*!< Error state                             */
} HAL_CRC_StateTypeDef;

/**
 * @brief CRC handle structure definition.
 */
typedef struct __HAL_CRC_HandleTypeDef
{
    CRC_TypeDef         *Instance;      /*!< CRC registers base address           */
    CRC_InitTypeDef     Init;           /*!< CRC configuration parameters         */
    HAL_LockTypeDef     Lock;           /*!< Locking object                       */
    __IO HAL_CRC_StateTypeDef State;    /*!< CRC communication state              */
    __IO uint32         ErrorCode;      /*!< CRC error code                       */
    uint32              InputDataFormat;/*!< Input data format (see HAL_CRC_INPUTDATA_FORMAT_xxx) */
#if (USE_RTOS == 1)
    HAL_MutexTypeDef    LockMutex;      /*!< RTOS mutex handle (created by the
                                             user porting layer, e.g. in
                                             HAL_CRC_MspInit)                   */
#endif /* USE_RTOS */
} HAL_CRC_HandleTypeDef;

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @defgroup CRC_Exported_Constants CRC Exported Constants
  * @{
  */

/** @defgroup CRC_Error_Code CRC Error Code
  * @{
  */
#define HAL_CRC_ERROR_NONE            ((uint32)0x00000000U)  /*!< No error            */
#define HAL_CRC_ERROR_INVALID_PARAM   ((uint32)0x00000001U)  /*!< Invalid parameter: a
                                                                  configuration or an input
                                                                  data format was rejected
                                                                  by HAL_CRC_Init() /
                                                                  HAL_CRC_Accumulate() /
                                                                  HAL_CRC_Calculate()     */
#define HAL_CRC_ERROR_TIMEOUT         ((uint32)0x00000002U)  /*!< Flag wait timeout.
                                                                  Reserved: this driver has no
                                                                  blocking wait, so it is never
                                                                  produced                       */
/**
  * @}
  */

/** @defgroup CRC_Output_XOR CRC Output XOR
  * @{
  */
#define CRC_OXOR_DISABLE   ((uint32)0x00000000U)  /*!< Output non XOR */
#define CRC_OXOR_ENABLE    ((uint32)0x00000001U)  /*!< Output XOR     */
/**
  * @}
  */

/** @defgroup CRC_Output_Reversal CRC Output Reversal
  * @{
  */
#define CRC_OREVERSE_NOT  ((uint32)0x00000000U)  /*!< Output data is not reversed */
#define CRC_OREVERSE_BIT  ((uint32)0x00000001U)  /*!< Output data bit inversion   */
/**
  * @}
  */

/** @defgroup CRC_Polynomials CRC Polynomials
  * @{
  */
#define CRC_POLY_7MMC     ((uint32)0x00000009U)  /*!< Polynomial CRC-7/MMC     */
#define CRC_POLY_8        ((uint32)0x00000007U)  /*!< Polynomial CRC-8         */
#define CRC_POLY_8MAXIM   ((uint32)0x00000031U)  /*!< Polynomial CRC-8/MAXIM   */
#define CRC_POLY_16IBM    ((uint32)0x00008005U)  /*!< Polynomial CRC-16/IBM    */
#define CRC_POLY_16XMODEM ((uint32)0x00001021U)  /*!< Polynomial CRC-16/XMODEM */
#define CRC_POLY_16DNP    ((uint32)0x00003D65U)  /*!< Polynomial CRC-16/DNP    */
#define CRC_POLY_32       ((uint32)0x04C11DB7U)  /*!< Polynomial CRC-32        */
#define CRC_POLY_32C      ((uint32)0x1EDC6F41U)  /*!< Polynomial CRC-32/C      */
/**
  * @}
  */

/** @defgroup CRC_Input_Data_Format CRC Input Data Format
  * @{
  */
#define HAL_CRC_INPUTDATA_FORMAT_BYTES       ((uint32)0x00000000U)  /*!< Input data is a stream of bytes      */
#define HAL_CRC_INPUTDATA_FORMAT_HALFWORDS   ((uint32)0x00000001U)  /*!< Input data is a stream of half-words */
#define HAL_CRC_INPUTDATA_FORMAT_WORDS       ((uint32)0x00000002U)  /*!< Input data is a stream of words      */
/**
  * @}
  */

/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/

/** @addtogroup CRC_Exported_Functions
  * @{
  */

/** @addtogroup CRC_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Fills each CRC_InitStruct member with its default value.
 * @param  CRC_InitStruct: pointer to a CRC_InitTypeDef structure which will
 *         be initialized (32-bit data size, no XOR, no reversal, 32-bit
 *         polynomial, init 0, CRC-32 polynomial, XOR 0).
 * @retval None
 */
void HAL_CRC_StructInit(CRC_InitTypeDef *CRC_InitStruct);

/**
 * @brief  Initializes the CRC according to the specified parameters in the
 *         CRC_InitStruct of the handle.
 * @note   The CRC clock gating must be configured by the user in
 *         HAL_CRC_MspInit().
 * @note   The low level initialization callback runs only on the first call
 *         (while the handle is in the reset state) and before the handle is
 *         locked (architecture rules MSP-04 and LOCK-06), hence the peripheral
 *         clock is enabled before the configuration registers are programmed;
 *         an override may create an RTOS mutex and call other HAL APIs.
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (invalid handle or rejected
 *         configuration) / HAL_BUSY (the handle is already locked)
 */
HAL_StatusTypeDef HAL_CRC_Init(HAL_CRC_HandleTypeDef *hcrc);

/**
 * @brief  De-initializes the CRC peripheral.
 * @note   The low level de-initialization callback runs after the handle lock
 *         has been released (architecture rule LOCK-06), so an override may
 *         call other HAL APIs.
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_CRC_DeInit(HAL_CRC_HandleTypeDef *hcrc);

/**
 * @brief  Initializes the CRC MSP. Weak empty function; the user implements
 *         the low level hardware initialization (CRC clock enable through
 *         the SMU bus clock configuration).
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @retval None
 */
void HAL_CRC_MspInit(HAL_CRC_HandleTypeDef *hcrc);

/**
 * @brief  De-initializes the CRC MSP. Weak empty function; the user
 *         implements the low level hardware de-initialization.
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @retval None
 */
void HAL_CRC_MspDeInit(HAL_CRC_HandleTypeDef *hcrc);

/**
  * @}
  */

/** @addtogroup CRC_Exported_Functions_Group2 CRC computation functions
  * @{
  */

/**
 * @brief  Computes the 32-bit CRC of a single data word.
 * @note   Protected by the handle lock and gated by the handle state
 *         (ARCH-CONST-09): the call returns 0 without touching the peripheral
 *         while the handle is busy with another operation or was never
 *         initialized with HAL_CRC_Init().
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @param  Data: data word to compute its CRC.
 * @retval uint32: 32-bit CRC value.
 */
uint32 HAL_CRC_CalcCRC(HAL_CRC_HandleTypeDef *hcrc, uint32 Data);

/**
 * @brief  Computes the 32-bit CRC of a buffer of data words (32-bit).
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @param  pBuffer: pointer to the buffer containing the data to be computed.
 * @param  BufferLength: number of words in the buffer.
 * @retval uint32: 32-bit CRC value.
 */
uint32 HAL_CRC_CalcWordBlockCRC(HAL_CRC_HandleTypeDef *hcrc, uint32 *pBuffer, uint32 BufferLength);

/**
 * @brief  Computes the 32-bit CRC of a buffer of data half-words (16-bit).
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @param  pBuffer: pointer to the buffer containing the data to be computed.
 * @param  BufferLength: number of half-words in the buffer.
 * @retval uint32: 32-bit CRC value.
 */
uint32 HAL_CRC_CalcHalfBlockCRC(HAL_CRC_HandleTypeDef *hcrc, uint16 *pBuffer, uint32 BufferLength);

/**
 * @brief  Computes the 32-bit CRC of a buffer of data bytes (8-bit).
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @param  pBuffer: pointer to the buffer containing the data to be computed.
 * @param  BufferLength: number of bytes in the buffer.
 * @retval uint32: 32-bit CRC value.
 */
uint32 HAL_CRC_CalcByteBlockCRC(HAL_CRC_HandleTypeDef *hcrc, uint8 *pBuffer, uint32 BufferLength);

/**
 * @brief  Computes the 32-bit CRC of a buffer of data in the configured
 *         input data format, continuing from the current CRC value
 *         (accumulate mode).
 * @note   Protected by the handle lock and gated by the handle state
 *         (ARCH-CONST-09); an unsupported input data format is rejected and
 *         reported through HAL_CRC_GetError() (HAL_CRC_ERROR_INVALID_PARAM).
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @param  pBuffer: pointer to the buffer containing the data to be computed.
 * @param  BufferLength: number of elements (bytes / half-words / words
 *         according to the configured input data format).
 * @retval uint32: 32-bit CRC value.
 */
uint32 HAL_CRC_Accumulate(HAL_CRC_HandleTypeDef *hcrc, const void *pBuffer, uint32 BufferLength);

/**
 * @brief  Computes the 32-bit CRC of a buffer of data in the configured
 *         input data format, resetting the CRC unit first (calculate mode).
 * @note   Protected by the handle lock and gated by the handle state
 *         (ARCH-CONST-09); an unsupported input data format is rejected and
 *         reported through HAL_CRC_GetError() (HAL_CRC_ERROR_INVALID_PARAM).
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @param  pBuffer: pointer to the buffer containing the data to be computed.
 * @param  BufferLength: number of elements (bytes / half-words / words
 *         according to the configured input data format).
 * @retval uint32: 32-bit CRC value.
 */
uint32 HAL_CRC_Calculate(HAL_CRC_HandleTypeDef *hcrc, const void *pBuffer, uint32 BufferLength);

/**
  * @}
  */

/** @addtogroup CRC_Exported_Functions_Group3 Peripheral Control functions
  * @{
  */

/**
 * @brief  Resets the CRC computation unit (init registers to the configured
 *         initial value).
 * @note   Protected by the handle lock and gated by the handle state
 *         (ARCH-CONST-09).
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @retval None
 */
void HAL_CRC_Reset(HAL_CRC_HandleTypeDef *hcrc);

/**
 * @brief  Stores an 8-bit data in the independent data (ID) register.
 * @note   Protected by the handle lock and gated by the handle state
 *         (ARCH-CONST-09).
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @param  IDValue: 8-bit value to be stored in the ID register.
 * @retval None
 */
void HAL_CRC_SetIDRegister(HAL_CRC_HandleTypeDef *hcrc, uint8 IDValue);

/**
 * @brief  Returns the 8-bit data stored in the independent data (ID)
 *         register.
 * @note   Read back through the handle lock, so that it cannot interleave with
 *         the register sequence of a computation.
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @retval uint8: 8-bit value of the ID register.
 */
uint8 HAL_CRC_GetIDRegister(HAL_CRC_HandleTypeDef *hcrc);

/**
 * @brief  Returns the current CRC value.
 * @note   Read back through the handle lock, so that it cannot interleave with
 *         the register sequence of a computation. Use the value returned by
 *         HAL_CRC_Calculate() / HAL_CRC_Accumulate() when a result consistent
 *         with a finished block is required.
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @retval uint32: 32-bit CRC value.
 */
uint32 HAL_CRC_GetCRC(HAL_CRC_HandleTypeDef *hcrc);

/**
 * @brief  Returns the CRC handle state.
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @retval HAL_CRC_StateTypeDef: the current handle state (HAL_CRC_STATE_xxx).
 */
HAL_CRC_StateTypeDef HAL_CRC_GetState(HAL_CRC_HandleTypeDef *hcrc);

/**
 * @brief  Returns the CRC error code.
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @retval uint32: the CRC error code (HAL_CRC_ERROR_xxx).
 */
uint32 HAL_CRC_GetError(HAL_CRC_HandleTypeDef *hcrc);

/**
  * @}
  */

/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/

/** @defgroup CRC_Private_Macros CRC Private Macros
  * @{
  */

/**
 * @brief  Check that the CRC calculated data size is valid.
 */
#define IS_CRC_SIZE(SIZE) (((SIZE) == CRC_SIZE_8B) || ((SIZE) == CRC_SIZE_16B) || \
                           ((SIZE) == CRC_SIZE_32B))

/**
 * @brief  Check that the CRC output XOR value is valid.
 */
#define IS_CRC_OXOR(OXOR) (((OXOR) == CRC_OXOR_DISABLE) || ((OXOR) == CRC_OXOR_ENABLE))

/**
 * @brief  Check that the CRC output reversal value is valid.
 */
#define IS_CRC_OREVERSE(OREVERSE) (((OREVERSE) == CRC_OREVERSE_NOT) || ((OREVERSE) == CRC_OREVERSE_BIT))

/**
 * @brief  Check that the CRC input reversal value is valid.
 */
#define IS_CRC_IREVERSE(IREVERSE) (((IREVERSE) == CRC_IREVERSE_NONE) || ((IREVERSE) == CRC_IREVERSE_BYTE) || \
                                   ((IREVERSE) == CRC_IREVERSE_HALF) || ((IREVERSE) == CRC_IREVERSE_WORD))

/**
 * @brief  Check that the CRC polynomial size is valid.
 */
#define IS_CRC_POLYSIZE(POLYSIZE) (((POLYSIZE) == CRC_POLYSIZE_32B) || ((POLYSIZE) == CRC_POLYSIZE_16B) || \
                                   ((POLYSIZE) == CRC_POLYSIZE_8B)  || ((POLYSIZE) == CRC_POLYSIZE_7B))

/**
 * @brief  Check that the CRC input data format is valid.
 */
#define IS_CRC_INPUTDATA_FORMAT(FORMAT) (((FORMAT) == HAL_CRC_INPUTDATA_FORMAT_BYTES) || \
                                         ((FORMAT) == HAL_CRC_INPUTDATA_FORMAT_HALFWORDS) || \
                                         ((FORMAT) == HAL_CRC_INPUTDATA_FORMAT_WORDS))

/**
 * @brief  Check that the CRC peripheral instance is valid.
 */
#define IS_CRC_INSTANCE(INSTANCE) ((INSTANCE) == CRC)

/**
  * @}
  */

/* Shared internal functions --------------------------------------------------*/

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_CRC_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the acquisition is bounded by the Timeout parameter (RTOS
 *         ticks, which with the usual 1 ms tick is the same quantity as the
 *         millisecond Timeout of the public API); HAL_MAX_DELAY waits forever.
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS, wait expired) /
 *         HAL_ERROR (RTOS, mutex not created) / HAL_BUSY (bare metal, the
 *         handle is already locked).
 */
HAL_StatusTypeDef CRC_LockHandle(HAL_CRC_HandleTypeDef *hcrc, uint32 Timeout);

/**
 * @brief  Unlock the handle.
 * @param  hcrc: pointer to a HAL_CRC_HandleTypeDef structure.
 * @retval None
 */
void CRC_UnlockHandle(HAL_CRC_HandleTypeDef *hcrc);

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_CRC_H */

/*****END OF FILE*****/
