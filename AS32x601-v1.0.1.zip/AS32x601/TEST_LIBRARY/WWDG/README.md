# WWDG 应用与测试参考

供 skill 按需求检索 AS32x601 HAL 窗口看门狗（WWDG）示例。别名/关键词：窗口看门狗、WWDG0、WWDG1、四通道、窗口值、上窗口、喂狗过早、bark、FCU 告警、超时复位。共有 10 个独立用例。

HAL 依据：[头文件](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_wwdg.h)、[实现](../../HAL_LIBRARY/peripherals/src/as32x601_hal_wwdg.c)。原测试工程的 4_HAL_LIBRARY 未提供，尚不能确认原始链接版本；文中标出的源码与当前 SDK 差异须先解决再迁移。

WWDG 自身没有中断线；本组用例通过 FCU 的 WWDG 通道取得 bark（告警/复位），涉及“中断处理”时必须同时配置 FCU。


## 实例与相关资源

本模块不单独列出外部通信引脚组。按实际功能核对实例、时钟、中断、内存或数据通路；关联 GPIO、定时器或其他外设时，再读取对应分支的引脚资料。具体资源与案例配置见下文。

## 生成前需确认的参数

已有工程、板级资料或用户已明确的值直接复用。仅对影响本次实现的缺失选择使用参数卡询问并等待答复；案例配置不能代替实际接线或应用参数。

| 参数 | 需要核对或确认的内容 |
|---|---|
| 窗口参数 | 实际外设时钟、计数分频、喂狗窗口和超时 |
| 异常处理 | 提前唤醒中断、复位行为及验证方式 |

## 按需求选择

| 用户需求 / 检索关键词 | 推荐用例 | 选择条件 / 需要补充的逻辑 |
|---|---|---|
| 最短路径：编程通道、启动、喂狗 | [001](WWDG_IT_DRV_001.c) | 预分频扫描，固定 DIV/BVAL；应用只保留目标参数。启动前 `HAL_WWDG_Init()` 只置 PSC/窗口使能，还要 `HAL_WWDG_Cmd(WWDG_EN_CFG, ENABLE)` |
| 选择分频值；理解四个通道相互独立 | [002](WWDG_IT_DRV_002.c) | 扫 4 个通道 × 不同分频。每个实例必须**独立句柄**，否则第二个实例的时钟不会打开 |
| 选择超时重装值 BVAL | [003](WWDG_IT_DRV_003.c) | BVAL 1000/5000/30000/65535；周期按公式换算 |
| 窗口看门狗：喂狗过早触发 bark | [004](WWDG_IT_DRV_004.c) | 本芯片语义：计数器向上计，`CNT >= WD.WDCNT` 时刷新只重装；`CNT < WD.WDCNT` 时刷新触发 bark。这仍属于过早刷新触发告警；差异是向上计数，是否复位取决于 FCU |
| 关闭/打开预分频块 | [005](WWDG_IT_DRV_005.c) | `WWDG_EN_PSC`；关闭时计数器冻结在 0 |
| 关闭/打开配置块 | [006](WWDG_IT_DRV_006.c) | `WWDG_EN_CFG`；遍历 4 个通道 |
| 超时后复位整机 | [007](WWDG_IT_DRV_007.c) | FCU 配成 `GLOBAL_SOFTWARE_RESET`；靠备份 RAM 守卫字识别复位。会真实复位，调试器不能停在核上 |
| 使用第二个实例 WWDG1 | [008](WWDG_IT_DRV_008.c) | WWDG1 由 APBBus1 供时钟，上电时 `SMU.APB1CFGR.WWDG1EN = 0`；必须让 MspInit 打开门控 |
| 周期喂狗不触发；停止喂狗后 bark | [009](WWDG_IT_DRV_009.c) | 两个实例轮流喂狗。强调一实例一句柄；共享句柄在冷启动时表现为 `HAL_WWDG_Init()` 回读失败 |
| 参数/句柄/写保护/导出宏自检 | [010](WWDG_IT_DRV_010.c) | 防御性自检，不是应用模板；配置故意放慢，保证宏检查期间不 bark |
| 不需要窗口约束的硬件看门狗 | [IWDG](../IWDG/README.md) | IWDG 也是硬件外设，不等于纯软件定时监控 |

## 实现要点与案例配置

- 实例与通道：`WWDG0`、`WWDG1` 两个实例，各 4 个通道（0–3）。通道参数 `Prescaler`、`Divider`、`Reload`（`TO.BVAL`）、窗口值 `WD.WDCNT` 分别编程；同一实例的预分频和超时是共享配置，分频按通道独立（002 验证）。
- 时钟：WWDG0 取自 `F_apb`，本套件经 PLL 后为 22.5 MHz；WWDG1 取自 APBBus1，同为 22.5 MHz。WWDG1 的 SMU 门控在常开域、上电为 0，冷启动时必须由 `HAL_WWDG_MspInit()` 打开并释放复位。
- 周期公式（源码实际使用）：`T = (PSCNUM + 1) × DIVNUM × BVAL / F_apb` 秒；窗口判定用计数器当前值与 `WD.WDCNT` 比较。
- 初始化顺序：`HAL_Init()` → 系统时钟 → `delay_init()` / 串口 → PD4 标记引脚 →（需要 bark/复位时）FCU 通道配置 → `__HAL_CLEAR_STRUCT`、`Instance = WWDG0/WWDG1`、填 `WWDG_InitTypeDef` → `HAL_WWDG_Init()` → `HAL_WWDG_Cmd(&hwwdg, WWDG_EN_CFG, ENABLE)`。`HAL_WWDG_Init()` 置位预分频和窗口使能，但不启动配置块。
- bark / 复位链：WWDG 超时 → FCU 通道 →（中断模式）PLIC → 应用 ISR；或 FCU 故障动作 → 全局软件复位。001–006、008、009 用 FCU 中断并配合 `HAL_WWDG_GetBKStatus()` 判断是哪个通道；007 用全局软件复位。
- 证据边界：配置回读、计数器值和 bark 标志能证明编程与计时语义；PD4 可用示波器直接测 bark 时刻；系统复位只能靠备份 RAM 守卫字和重启后的现场确认。源码 002 记录了 2026-11-12 的板上观察：周期低于约 20 ms 时，WWDG → FCU → PLIC → ISR 链路的延迟可达标称值的数倍，而 bark 时计数器已准确到 BVAL，说明计数本身正常、观测链路有延迟；该记录属于源码历史，本次未复测。短周期定时请以引脚测量为准。

## 验证方法与适用边界

- **每个实例一个句柄**：`HAL_WWDG_MspInit()` 只在句柄处于复位态时执行，共享一个句柄会让第二个实例的时钟门控始终关闭，表现为写寄存器被丢弃、`HAL_WWDG_Init()` 回读失败。该问题在冷启动（WWDG1 门控为 0）时才会暴露。
- 窗口方向：本芯片计数器向上计，`CNT < WD.WDCNT` 时刷新会立即 bark。不要照搬“计数器向下、喂狗过早复位”的其他厂商模型。
- `HAL_WWDG_Init()` 会自动使能预分频块和窗口计数器，但配置块仍由 `HAL_WWDG_Cmd(WWDG_EN_CFG, ENABLE)` 启动；停止看门狗要显式禁用配置块。
- 写保护块被锁定时，`HAL_WWDG_Init()` / `HAL_WWDG_Cmd()` 会因回读不一致返回 `HAL_ERROR`；010 显示锁定预分频块会拒绝 Init，锁定配置块会拒绝启动，两者仍允许操作另一块。
- 007 会真实复位；守卫字必须放在备份 RAM（普通 SRAM 会被复位清掉），且第二次运行要清除守卫字，否则下次上电又会进入恢复分支。
- 喂狗周期要留出余量；FCU 转发和中断延迟会让“刚好卡在窗口边缘”的喂狗不可靠。短周期场合用引脚/示波器验证，不要只信软件时间戳。
- PD4 是示例的标记脚，应用可删除；若保留，注意与目标板其他功能复用冲突。

## 按接口与辅助宏检索

| 接口 / 宏 | 参考用例 |
|---|---|
| `HAL_WWDG_Init` | [001](WWDG_IT_DRV_001.c)、[008](WWDG_IT_DRV_008.c)、[010](WWDG_IT_DRV_010.c) |
| `HAL_WWDG_Cmd` | [005](WWDG_IT_DRV_005.c)、[006](WWDG_IT_DRV_006.c)、[009](WWDG_IT_DRV_009.c) |
| `HAL_WWDG_LockCmd` | [010](WWDG_IT_DRV_010.c) |
| `HAL_WWDG_Refresh` | [004](WWDG_IT_DRV_004.c)、[009](WWDG_IT_DRV_009.c) |
| `HAL_WWDG_GetCounter` | [004](WWDG_IT_DRV_004.c)、[005](WWDG_IT_DRV_005.c) |
| `HAL_WWDG_GetBKStatus` | [002](WWDG_IT_DRV_002.c)、[006](WWDG_IT_DRV_006.c)、[009](WWDG_IT_DRV_009.c) |
| `WWDG_EN_PSC` / `WWDG_EN_CFG` / `WWDG_EN_WD` | [005](WWDG_IT_DRV_005.c)、[006](WWDG_IT_DRV_006.c) |
| `WWDG_LOCK_PSC` / `WWDG_LOCK_CFG` | [010](WWDG_IT_DRV_010.c) |
| `HAL_FCU_Init` / `HAL_FCU_FAULT_GLOBAL_SOFTWARE_RESET` | [007](WWDG_IT_DRV_007.c) |


本次为源码静态整理，未重新编译、未上板；源码里的历史测试注释不代表本次验证结果。
