/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):  	Xiamen Guoke Anxin Technology Co., LTD
 * FileName:     	as32x601_trapentry_gcc.S
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.3
 * Date:			2026/10/08
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/17     1.0     refactor per AS32_HAL_trap_entry_requirements_specification V3.1:
 *                                                       full ABI context save (GPRs + FP + fcsr),
 *                                                       mstatus/mepc snapshot, mcause decode,
 *                                                       PLIC claim/complete handshake, weak dispatch,
 *                                                       stack-underflow guard -> fatal
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.1     optional dedicated interrupt stack for RTOS
 *                                                       (HAL_INTERRUPT_STACK_SIZE>0): mscratch swap
 *                                                       between task sp and ISR stack top, stack
 *                                                       guard against _isr_stack_bottom, self-contained
 *                                                       .bss.isr_stack section
 *     ANSILIC APPLICATION GROUP  2026/10/08     1.3     harden the entry: align the dedicated interrupt-stack
                                                         top to 16 bytes, point both reserved dispatch-table
                                                         slots at 0 so a hit completes the claimed source
                                                         before the hook runs, and keep the single
                                                         Default_Int_Handler definition in the C weak stub
                                                         (referenced strongly here); the version aligns with
                                                         the IAR file, whose 1.2 fixed its interrupt-stack
                                                         section directive
 * Description:     This file provides the RISC-V trap/interrupt entry functions
 *                  for the AS32x601 (GCC/GAS toolchain).
 *
 *                  Pipeline (per AS32_HAL_trap_entry_requirements_specification V3.1):
 *                    TrapEntry (CB-ENTRY)
 *                      -> SAVE_CONTEXT (CB-SAVE)
 *                      -> mcause decode (CB-DECODE)
 *                      -> interrupt path: MSI/MTI direct dispatch,
 *                         MEI: PLIC claim -> dispatch table -> complete (CB-DISPATCH),
 *                         table miss -> pending clear + default hook (CB-DEFAULT)
 *                      -> exception path: mtval snapshot, exception table dispatch (CB-EXCEPT),
 *                         unregistered/unknown -> fatal loop (CB-FATAL)
 *                      -> RESTORE_CONTEXT (CB-RESTORE) -> mret (CB-RETURN)
 *
 *                  Nesting policy: NOT nested (interrupts stay disabled during
 *                  the whole trap processing; matches as32x601_core.h INTNEST=0).
 *                  Vector mode: direct (startup configures mtvec = TrapEntry).
 */

#define REGBYTES  4
#define STORE     sw
#define LOAD      lw

/* ============================================================================
 * RTOS support: dedicated interrupt stack switch
 * ----------------------------------------------------------------------------
 * HAL_INTERRUPT_STACK_SIZE:
 *   0 (default) : no stack switch.  The trap frame is pushed on the task
 *                 stack (original behaviour, fine for bare-metal single-task
 *                 applications).
 *   > 0         : the trap entry switches to a dedicated interrupt stack of
 *                 HAL_INTERRUPT_STACK_SIZE bytes (defined below in .bss) so
 *                 that interrupt handling no longer consumes the task stack
 *                 (required for RTOS where task stacks are small and may be
 *                 switched by the scheduler).
 *
 * Configuration source (priority order):
 *   1. "as32x601_hal_conf.h" (the user copies as32x601_hal_conf_template.h
 *      into the application folder and tunes USE_RTOS there; this file is
 *      auto-included through __has_include when found on the include path
 *      and HAL_INTERRUPT_STACK_SIZE is derived from USE_RTOS).
 *   2. Build option -DHAL_INTERRUPT_STACK_SIZE=xxx (overrides the file).
 *   If neither is present the default 0 applies (bare-metal behaviour).
 *
 * Mechanism (standard RISC-V mscratch swap):
 *   - mscratch holds the interrupt stack TOP in normal (non-trap) context;
 *     the startup file initializes it (csrw mscratch, _isr_stack_top) before
 *     enabling global interrupts.
 *   - On trap entry:  csrrw sp, mscratch, sp
 *       -> sp = interrupt stack top, mscratch = task sp (saved for return).
 *   - On trap exit:   csrrw sp, mscratch, sp
 *       -> sp = task sp, mscratch = interrupt stack top (self-restored).
 *   - While a dedicated ISR stack is used, mscratch no longer carries the
 *     frame base; handlers that need to rewrite the frame mepc slot (e.g.
 *     ECall_Handler) access it through sp directly.
 * ==========================================================================*/
#if defined(__has_include)
    #if __has_include("as32x601_hal_conf.h")
        #include "as32x601_hal_conf.h"
    #endif
#endif /* defined(__has_include) */

#ifndef HAL_INTERRUPT_STACK_SIZE
    #define HAL_INTERRUPT_STACK_SIZE 0
#endif /* HAL_INTERRUPT_STACK_SIZE */

/* A dedicated interrupt stack is mandatory once a scheduler owns the task
 * stacks: without it the trap frame would be built on a task stack that may be
 * switched away mid-handler.  A missing configuration header must therefore
 * fail here, loudly, instead of silently degrading to the bare-metal layout.
 * The same gate is present in both startup files. */
#if defined(USE_RTOS) && (USE_RTOS == 1U) && (HAL_INTERRUPT_STACK_SIZE == 0)
    #error "USE_RTOS is enabled but HAL_INTERRUPT_STACK_SIZE is zero; put as32x601_hal_conf.h on the include path"
#endif /* defined(USE_RTOS) && (USE_RTOS == 1U) && (HAL_INTERRUPT_STACK_SIZE == 0) */

/* The reserved interrupt-stack range is a multiple of 16 bytes.  The trap
 * entry hands _isr_stack_top straight to sp and the psABI requires 16-byte
 * alignment at every handler call, so a configured size that is not a
 * multiple of 16 is rounded up here rather than left to an assembler
 * alignment directive (the IAR assembler has no position-counter alignment). */
#define ISR_STACK_BYTES      (((HAL_INTERRUPT_STACK_SIZE) + 15) / 16 * 16)

/* PLIC base address (Core-Local Interruptor), see as32x601_addrmap.h:
 *   +0x000 AXI_PLIC_ID      read = claim (pending source ID), write = complete
 *   +0x004 AXI_PLIC_PRIORITY[64]
 *   +0x104 AXI_PLIC_EN[2]
 */
#define PLIC_BASE  0x30020000

/* ============================================================================
 * FPU adaptive configuration (per RISC-V_FPU context-save adaptation doc)
 * Uses the standard __riscv_flen macro to detect FPU mode:
 *   64 = D extension (fsd/fld, 8-byte alignment), 32 = F extension (fsw/flw),
 *   not defined = no FPU (skip float register save entirely)
 * ==========================================================================*/
#if defined(__riscv_flen)
    #if __riscv_flen == 64
        #define FSTORE              fsd
        #define FLOAD               fld
        #define FPREGBYTES          8
    #else
        #define FSTORE              fsw
        #define FLOAD               flw
        #define FPREGBYTES          4
    #endif
    #define HAS_FPU                 1
#else
    #define HAS_FPU                 0
#endif

/* Number of registers saved in the context:
 *   GPRs: x1 (ra), x4-x31 (tp + caller/callee-saved ABI set), 29 in total;
 *         sp (x2) and gp (x3) are NOT saved (unchanged during trap processing).
 *   FPRs: f0-f7, f10-f17, f28-f31 (FP caller-saved ABI set), 20 in total.
 */
#define CTX_GENERAL_REGS            29
#define CTX_FP_REGS                 20

/* Stack frame layout (save order):
 *   [0..115]  GPR area        x1, x4..x31 (29 * 4B)
 *   [FP..]    FP area         20 FPRs (aligned to FPREGBYTES, if HAS_FPU)
 *   [FCSR]    fcsr snapshot   4B (if HAS_FPU)
 *   [MSTATUS] mstatus snapshot (taken before FPU FS enable, if HAS_FPU)
 *   [MEPC]    mepc snapshot   mret return target; frame slot so a recoverable
 *                             exception handler may rewrite it via mscratch
 *   [MTVAL]   mtval snapshot  written by the exception path only (diagnostic)
 *   Frame total aligned to 16B so that sp keeps the RISC-V psABI 16-byte
 *   alignment at the handler call point (jalr rd, handler) - required for
 *   any 64-bit stack data / nested calls inside the handler.
 *   Restore order is the exact reverse of the save order.
 */
#if HAS_FPU
    #define OFFSET_FP_START   (((CTX_GENERAL_REGS * REGBYTES) + (FPREGBYTES - 1)) & ~(FPREGBYTES - 1))
    #define OFFSET_FCSR       (OFFSET_FP_START + CTX_FP_REGS * FPREGBYTES)
    #define OFFSET_MSTATUS    (OFFSET_FCSR + 4)
    #define OFFSET_MEPC       (OFFSET_MSTATUS + 4)
    #define OFFSET_MTVAL      (OFFSET_MEPC + 4)
#else
    #define OFFSET_MSTATUS    (CTX_GENERAL_REGS * REGBYTES)
    #define OFFSET_MEPC       (OFFSET_MSTATUS + 4)
    #define OFFSET_MTVAL      (OFFSET_MEPC + 4)
#endif
#define STACK_FRAME_SIZE  (((OFFSET_MTVAL + 4) + 15) & ~15)

    .section .text.entry
    .align   2
    .global  TrapEntry
    .global  SetMstatusMie
    .global  ResetMstatusMie
    .extern  Default_Int_Handler

/* Weak references to per-source interrupt handlers (defined by driver/user,
 * else resolved to 0 -> dispatch falls back to Default_Int_Handler).
 * Source IDs follow PLICIRQn_TypeDef in as32x601_plic.h. */
    .weak EFLASH_IRQ_Handler
    .weak FCU_IRQ_Handler
    .weak DMA0_IRQ_Handler
    .weak DMA1_IRQ_Handler
    .weak TIM0_IRQ_Handler
    .weak CANFD0_IRQ_Handler
    .weak CANFD1_IRQ_Handler
    .weak ADC0_IRQ_Handler
    .weak ADC1_IRQ_Handler
    .weak GPIOA_IRQ_Handler
    .weak GPIOB_IRQ_Handler
    .weak GPIOC_IRQ_Handler
    .weak PKA_IRQ_Handler
    .weak SPACC_IRQ_Handler
    .weak TRNG_IRQ_Handler
    .weak TIM1_IRQ_Handler
    .weak CANFD2_IRQ_Handler
    .weak CANFD3_IRQ_Handler
    .weak GPIOD_IRQ_Handler
    .weak GPIOE_IRQ_Handler
    .weak GPIOF_IRQ_Handler
    .weak GPIOG_IRQ_Handler
    .weak MAC_IRQ_Handler
    .weak SPI0_IRQ_Handler
    .weak SPI1_IRQ_Handler
    .weak SPI2_IRQ_Handler
    .weak I2C0_IRQ_Handler
    .weak I2C1_IRQ_Handler
    .weak USART0_IRQ_Handler
    .weak USART1_IRQ_Handler
    .weak USART2_IRQ_Handler
    .weak USART3_IRQ_Handler
    .weak TIM2_IRQ_Handler
    .weak TIM3_IRQ_Handler
    .weak TIM4_IRQ_Handler
    .weak SPI3_IRQ_Handler
    .weak SPI4_IRQ_Handler
    .weak SPI5_IRQ_Handler
    .weak I2C2_IRQ_Handler
    .weak I2C3_IRQ_Handler
    .weak USART4_IRQ_Handler
    .weak USART5_IRQ_Handler
    .weak USART6_IRQ_Handler
    .weak USART7_IRQ_Handler
    .weak TIM5_IRQ_Handler
    .weak TIM6_IRQ_Handler
    .weak TIM7_IRQ_Handler
    .weak GPIOH_IRQ_Handler
    .weak RTC_IRQ_Handler
/* Machine software / timer interrupt handlers */
    .weak MSoftWare_IRQ_Handler
    .weak MTimer_IRQ_Handler
/* Weak references to exception handlers (mcause exception code based) */
    .weak InstAddrMisalign_Handler
    .weak InstAccessFault_Handler
    .weak IllegalInst_Handler
    .weak Breakpoint_Handler
    .weak LoadAddrMisalign_Handler
    .weak LoadAccessFault_Handler
    .weak StoreAMOAddrMisalign_Handler
    .weak StoreAMOAccessFault_Handler
    .weak ECall_Handler
    .weak InstPageFault_Handler
    .weak LoadPageFault_Handler
    .weak StoreAMOPageFault_Handler

/*
 * SAVE_CONTEXT: save the full ABI integer context, the FP caller-saved
 * context (if FPU enabled), the mstatus snapshot and the mepc snapshot to
 * the stack frame.
 * Save order: GPRs -> mstatus (pre-FS) -> mepc -> mscratch(frame base) ->
 *             FS=Dirty -> FPRs -> fcsr.  Internal (CSR) registers are saved
 *             only as far as they are used by mret / the FPU state.
 */
.macro SAVE_CONTEXT
#if (HAL_INTERRUPT_STACK_SIZE > 0)
    /* Switch to the dedicated interrupt stack (RTOS mode).  The swap saves
     * the task sp into mscratch and puts sp on the ISR stack top. */
    csrrw    sp, mscratch, sp
#endif

    addi sp, sp, -STACK_FRAME_SIZE

    STORE x1,   0 * REGBYTES(sp)
    STORE x4,   1 * REGBYTES(sp)
    STORE x5,   2 * REGBYTES(sp)
    STORE x6,   3 * REGBYTES(sp)
    STORE x7,   4 * REGBYTES(sp)
    STORE x8,   5 * REGBYTES(sp)
    STORE x9,   6 * REGBYTES(sp)
    STORE x10,  7 * REGBYTES(sp)
    STORE x11,  8 * REGBYTES(sp)
    STORE x12,  9 * REGBYTES(sp)
    STORE x13, 10 * REGBYTES(sp)
    STORE x14, 11 * REGBYTES(sp)
    STORE x15, 12 * REGBYTES(sp)
    STORE x16, 13 * REGBYTES(sp)
    STORE x17, 14 * REGBYTES(sp)
    STORE x18, 15 * REGBYTES(sp)
    STORE x19, 16 * REGBYTES(sp)
    STORE x20, 17 * REGBYTES(sp)
    STORE x21, 18 * REGBYTES(sp)
    STORE x22, 19 * REGBYTES(sp)
    STORE x23, 20 * REGBYTES(sp)
    STORE x24, 21 * REGBYTES(sp)
    STORE x25, 22 * REGBYTES(sp)
    STORE x26, 23 * REGBYTES(sp)
    STORE x27, 24 * REGBYTES(sp)
    STORE x28, 25 * REGBYTES(sp)
    STORE x29, 26 * REGBYTES(sp)
    STORE x30, 27 * REGBYTES(sp)
    STORE x31, 28 * REGBYTES(sp)

    /* Snapshot mstatus BEFORE enabling FPU, so MPIE/MPP and the original
     * FS field are faithfully restored (mret depends on MPIE/MPP).
     * NOTE: on trap entry the hardware cleared MIE, so this snapshot has
     * MIE=0; restoring it keeps interrupts disabled until mret. */
    csrr     t0, mstatus
    STORE    t0, OFFSET_MSTATUS(sp)

    /* Snapshot mepc (the mret return target).  It is restored right before
     * mret; a recoverable exception handler that needs to redirect the
     * return may instead rewrite this frame slot (frame base = sp). */
    csrr     t0, mepc
    STORE    t0, OFFSET_MEPC(sp)

#if (HAL_INTERRUPT_STACK_SIZE > 0)
    /* RTOS mode: mscratch holds the task sp (see the swap above), so it is
     * not available as a frame-base pointer.  Handlers access the frame
     * through sp directly (sp is the frame base; it is not modified inside
     * the trap handler). */
#else
    /* Bare-metal mode: expose the frame base to handlers via mscratch
     * (valid only during trap processing; unused outside the trap path). */
    csrw     mscratch, sp
#endif

#if HAS_FPU
    /* Enable FPU (mstatus.FS = 11 Dirty) before float stores; the trap
     * entry does not depend on the FS value left by the startup */
    li       t0, 0x6000
    csrs     mstatus, t0

    FSTORE f0,  (OFFSET_FP_START + 0  * FPREGBYTES)(sp)
    FSTORE f1,  (OFFSET_FP_START + 1  * FPREGBYTES)(sp)
    FSTORE f2,  (OFFSET_FP_START + 2  * FPREGBYTES)(sp)
    FSTORE f3,  (OFFSET_FP_START + 3  * FPREGBYTES)(sp)
    FSTORE f4,  (OFFSET_FP_START + 4  * FPREGBYTES)(sp)
    FSTORE f5,  (OFFSET_FP_START + 5  * FPREGBYTES)(sp)
    FSTORE f6,  (OFFSET_FP_START + 6  * FPREGBYTES)(sp)
    FSTORE f7,  (OFFSET_FP_START + 7  * FPREGBYTES)(sp)
    FSTORE f10, (OFFSET_FP_START + 8  * FPREGBYTES)(sp)
    FSTORE f11, (OFFSET_FP_START + 9  * FPREGBYTES)(sp)
    FSTORE f12, (OFFSET_FP_START + 10 * FPREGBYTES)(sp)
    FSTORE f13, (OFFSET_FP_START + 11 * FPREGBYTES)(sp)
    FSTORE f14, (OFFSET_FP_START + 12 * FPREGBYTES)(sp)
    FSTORE f15, (OFFSET_FP_START + 13 * FPREGBYTES)(sp)
    FSTORE f16, (OFFSET_FP_START + 14 * FPREGBYTES)(sp)
    FSTORE f17, (OFFSET_FP_START + 15 * FPREGBYTES)(sp)
    FSTORE f28, (OFFSET_FP_START + 16 * FPREGBYTES)(sp)
    FSTORE f29, (OFFSET_FP_START + 17 * FPREGBYTES)(sp)
    FSTORE f30, (OFFSET_FP_START + 18 * FPREGBYTES)(sp)
    FSTORE f31, (OFFSET_FP_START + 19 * FPREGBYTES)(sp)

    /* Save FP control/status register (rounding mode + exception flags) */
    csrr     t0, fcsr
    STORE    t0, OFFSET_FCSR(sp)
#endif

    /* Stack-underflow guard (TRAP-REQ-002 abnormal path): the frame base
     * must stay inside the stack region, otherwise the save has overflowed
     * the stack and we go fatal (context stays on the stack for diagnosis).
     * t0/t1 are scratch; their original values are already in the frame.
     * In RTOS mode the checked region is the dedicated interrupt stack;
     * in bare-metal mode it is the task stack. */
#if (HAL_INTERRUPT_STACK_SIZE > 0)
    la       t0, _isr_stack_bottom
#else
    la       t0, _stack_bottom
#endif
    bltu     sp, t0, trap_fatal
.endm

/*
 * RESTORE_CONTEXT: restore fcsr/FPRs (FS still Dirty), restore the mstatus
 * snapshot, restore the mepc snapshot, then restore the GPRs in reverse
 * save order, deallocate the frame and return with mret.
 *
 * The mstatus snapshot was taken right after trap entry, so MIE=0 in it:
 * restoring it keeps interrupts disabled for the remainder of the restore
 * sequence (no re-enable window before mret - mret itself re-enables MIE
 * from MPIE).  mepc is therefore never overwritten between its restore and
 * mret, and the frame mepc value is honored exactly.
 *
 * Recoverable exception handlers (e.g. ECall_Handler) that need to change
 * the return address must rewrite the frame mepc slot instead of the
 * hardware register:  csrr t0, mscratch ; lw t1, OFFSET_MEPC(t0) ; ...
 * (the frame base was stored in mscratch by SAVE_CONTEXT).
 */
.macro RESTORE_CONTEXT
#if HAS_FPU
    LOAD     t0, OFFSET_FCSR(sp)
    csrw     fcsr, t0

    FLOAD f0,  (OFFSET_FP_START + 0  * FPREGBYTES)(sp)
    FLOAD f1,  (OFFSET_FP_START + 1  * FPREGBYTES)(sp)
    FLOAD f2,  (OFFSET_FP_START + 2  * FPREGBYTES)(sp)
    FLOAD f3,  (OFFSET_FP_START + 3  * FPREGBYTES)(sp)
    FLOAD f4,  (OFFSET_FP_START + 4  * FPREGBYTES)(sp)
    FLOAD f5,  (OFFSET_FP_START + 5  * FPREGBYTES)(sp)
    FLOAD f6,  (OFFSET_FP_START + 6  * FPREGBYTES)(sp)
    FLOAD f7,  (OFFSET_FP_START + 7  * FPREGBYTES)(sp)
    FLOAD f10, (OFFSET_FP_START + 8  * FPREGBYTES)(sp)
    FLOAD f11, (OFFSET_FP_START + 9  * FPREGBYTES)(sp)
    FLOAD f12, (OFFSET_FP_START + 10 * FPREGBYTES)(sp)
    FLOAD f13, (OFFSET_FP_START + 11 * FPREGBYTES)(sp)
    FLOAD f14, (OFFSET_FP_START + 12 * FPREGBYTES)(sp)
    FLOAD f15, (OFFSET_FP_START + 13 * FPREGBYTES)(sp)
    FLOAD f16, (OFFSET_FP_START + 14 * FPREGBYTES)(sp)
    FLOAD f17, (OFFSET_FP_START + 15 * FPREGBYTES)(sp)
    FLOAD f28, (OFFSET_FP_START + 16 * FPREGBYTES)(sp)
    FLOAD f29, (OFFSET_FP_START + 17 * FPREGBYTES)(sp)
    FLOAD f30, (OFFSET_FP_START + 18 * FPREGBYTES)(sp)
    FLOAD f31, (OFFSET_FP_START + 19 * FPREGBYTES)(sp)
#endif

    /* Restore the mstatus snapshot (restores original FS/MPIE/MPP; the
     * snapshot MIE=0 keeps interrupts disabled until mret) */
    LOAD     t0, OFFSET_MSTATUS(sp)
    csrw     mstatus, t0

    /* Restore the mepc snapshot (mret return target).  Interrupts are
     * still disabled here (see above), so no nested trap can overwrite
     * mepc before mret. */
    LOAD     t0, OFFSET_MEPC(sp)
    csrw     mepc, t0

    LOAD x31, 28 * REGBYTES(sp)
    LOAD x30, 27 * REGBYTES(sp)
    LOAD x29, 26 * REGBYTES(sp)
    LOAD x28, 25 * REGBYTES(sp)
    LOAD x27, 24 * REGBYTES(sp)
    LOAD x26, 23 * REGBYTES(sp)
    LOAD x25, 22 * REGBYTES(sp)
    LOAD x24, 21 * REGBYTES(sp)
    LOAD x23, 20 * REGBYTES(sp)
    LOAD x22, 19 * REGBYTES(sp)
    LOAD x21, 18 * REGBYTES(sp)
    LOAD x20, 17 * REGBYTES(sp)
    LOAD x19, 16 * REGBYTES(sp)
    LOAD x18, 15 * REGBYTES(sp)
    LOAD x17, 14 * REGBYTES(sp)
    LOAD x16, 13 * REGBYTES(sp)
    LOAD x15, 12 * REGBYTES(sp)
    LOAD x14, 11 * REGBYTES(sp)
    LOAD x13, 10 * REGBYTES(sp)
    LOAD x12,  9 * REGBYTES(sp)
    LOAD x11,  8 * REGBYTES(sp)
    LOAD x10,  7 * REGBYTES(sp)
    LOAD x9,   6 * REGBYTES(sp)
    LOAD x8,   5 * REGBYTES(sp)
    LOAD x7,   4 * REGBYTES(sp)
    LOAD x6,   3 * REGBYTES(sp)
    LOAD x5,   2 * REGBYTES(sp)
    LOAD x4,   1 * REGBYTES(sp)
    LOAD x1,   0 * REGBYTES(sp)

    addi     sp, sp, STACK_FRAME_SIZE
#if (HAL_INTERRUPT_STACK_SIZE > 0)
    /* Switch back to the task stack.  The swap restores sp to the saved
     * task sp and puts the interrupt stack top back into mscratch for the
     * next trap. */
    csrrw    sp, mscratch, sp
#endif
    mret
.endm

/*
 * TrapEntry - unified trap/interrupt entry (CB-ENTRY / CB-SAVE / CB-DECODE)
 * Saves the full context, then decodes mcause:
 *   bit31=1 -> interrupt (MSI=3 / MTI=7 / MEI=11, others fatal)
 *   bit31=0 -> exception (dispatched via the exception table)
 */
TrapEntry:
    SAVE_CONTEXT

    csrr     a0, mcause
    bge      a0, zero, trap_exception

    /* ----- interrupt path ----- */
    li       t0, 0xfff
    and      a1, a0, t0               /* a1 = interrupt cause code */
    li       t0, 3                    /* machine software interrupt */
    beq      a1, t0, trap_msi
    li       t0, 7                    /* machine timer interrupt */
    beq      a1, t0, trap_mti
    li       t0, 11                   /* machine external interrupt (PLIC) */
    beq      a1, t0, trap_mei
    j        trap_fatal               /* reserved/illegal interrupt code */

    /* MSI: dispatch to the (weak) software interrupt handler */
trap_msi:
    la       t2, MSoftWare_IRQ_Handler
    beqz     t2, trap_fatal
    jalr     ra, t2
    j        trap_restore

    /* MTI: dispatch to the (weak) timer interrupt handler */
trap_mti:
    la       t2, MTimer_IRQ_Handler
    beqz     t2, trap_fatal
    jalr     ra, t2
    j        trap_restore

    /* MEI: PLIC claim -> dispatch table -> complete (CB-DISPATCH) */
trap_mei:
    li       t0, PLIC_BASE
    lw       a1, 0(t0)                /* claim: read AXI_PLIC_ID -> source ID */
    beqz     a1, trap_restore         /* spurious (None) -> nothing to complete */
    li       t0, 50                   /* highest valid source ID (RTC_IRQn) */
    bgtu     a1, t0, trap_default_irq /* out-of-range source -> default */
    mv       s0, a1                   /* keep ID across the handler call */
    la       t0, irq_table
    slli     t1, a1, 2
    add      t0, t0, t1
    lw       t2, 0(t0)                /* handler address or 0 */
    beqz     t2, trap_default_irq     /* table miss -> default */
    jalr     ra, t2                   /* call the registered handler */
    li       t0, PLIC_BASE
    sw       s0, 0(t0)                /* complete: write source ID back */
    j        trap_restore

    /* Unregistered source: clear the pending flag (mandatory, no storm),
     * then call the weak default hook (default = fatal loop; a user
     * override may return -> ignore policy). (CB-DEFAULT) */
trap_default_irq:
    li       t0, PLIC_BASE
    sw       a1, 0(t0)                /* complete: clear pending */
    call     Default_Int_Handler
    j        trap_restore             /* reached only if hook returns */

    /* ----- exception path (CB-EXCEPT) ----- */
trap_exception:
    csrr     t0, mtval                /* retain fault address for diagnostics */
    STORE    t0, OFFSET_MTVAL(sp)
    li       t0, 0xfff
    and      a1, a0, t0               /* a1 = exception code */
    li       t0, 15
    bgtu     a1, t0, trap_fatal       /* reserved/illegal code -> fatal */
    la       t0, exc_table
    slli     t1, a1, 2
    add      t0, t0, t1
    lw       t2, 0(t0)
    beqz     t2, trap_fatal           /* unregistered -> fatal */
    jalr     ra, t2                   /* recoverable handler (may fix mepc) */
    j        trap_restore

trap_restore:
    RESTORE_CONTEXT

    /* Fatal handling: preserve the context on the stack and spin.
     * No return instruction is executed (CB-FATAL). */
trap_fatal:
    j        trap_fatal
    .align 2

/*
 * Dispatch table for external interrupt sources (ID 0..50).
 * Entry 0 (None) is unreachable (spurious claim returns before lookup) and
 * entry 19 names the id the controller reserves.  Both hold 0 on purpose: the
 * default path completes the claimed source before the hook runs, whereas a hit
 * on Default_Int_Handler would call the hook straight away and leave the source
 * pending - an interrupt storm as soon as the hook is overridden with a
 * returning ignore policy.
 * Entries are weak references: unresolved handlers resolve to 0 and the
 * dispatch falls back to trap_default_irq.
 */
irq_table:
    .word 0                           /*  0 None: unreachable, claim 0 returns early */
    .word EFLASH_IRQ_Handler          /*  1 */
    .word FCU_IRQ_Handler             /*  2 */
    .word DMA0_IRQ_Handler            /*  3 */
    .word DMA1_IRQ_Handler            /*  4 */
    .word TIM0_IRQ_Handler            /*  5 */
    .word CANFD0_IRQ_Handler          /*  6 */
    .word CANFD1_IRQ_Handler          /*  7 */
    .word ADC0_IRQ_Handler            /*  8 */
    .word ADC1_IRQ_Handler            /*  9 */
    .word GPIOA_IRQ_Handler           /* 10 */
    .word GPIOB_IRQ_Handler           /* 11 */
    .word GPIOC_IRQ_Handler           /* 12 */
    .word PKA_IRQ_Handler             /* 13 */
    .word SPACC_IRQ_Handler           /* 14 */
    .word TRNG_IRQ_Handler            /* 15 */
    .word TIM1_IRQ_Handler            /* 16 */
    .word CANFD2_IRQ_Handler          /* 17 */
    .word CANFD3_IRQ_Handler          /* 18 */
    .word 0                           /* 19 reserved: default path completes first */
    .word GPIOD_IRQ_Handler           /* 20 */
    .word GPIOE_IRQ_Handler           /* 21 */
    .word GPIOF_IRQ_Handler           /* 22 */
    .word GPIOG_IRQ_Handler           /* 23 */
    .word MAC_IRQ_Handler             /* 24 */
    .word SPI0_IRQ_Handler            /* 25 */
    .word SPI1_IRQ_Handler            /* 26 */
    .word SPI2_IRQ_Handler            /* 27 */
    .word I2C0_IRQ_Handler            /* 28 */
    .word I2C1_IRQ_Handler            /* 29 */
    .word USART0_IRQ_Handler          /* 30 */
    .word USART1_IRQ_Handler          /* 31 */
    .word USART2_IRQ_Handler          /* 32 */
    .word USART3_IRQ_Handler          /* 33 */
    .word TIM2_IRQ_Handler            /* 34 */
    .word TIM3_IRQ_Handler            /* 35 */
    .word TIM4_IRQ_Handler            /* 36 */
    .word SPI3_IRQ_Handler            /* 37 */
    .word SPI4_IRQ_Handler            /* 38 */
    .word SPI5_IRQ_Handler            /* 39 */
    .word I2C2_IRQ_Handler            /* 40 */
    .word I2C3_IRQ_Handler            /* 41 */
    .word USART4_IRQ_Handler          /* 42 */
    .word USART5_IRQ_Handler          /* 43 */
    .word USART6_IRQ_Handler          /* 44 */
    .word USART7_IRQ_Handler          /* 45 */
    .word TIM5_IRQ_Handler            /* 46 */
    .word TIM6_IRQ_Handler            /* 47 */
    .word TIM7_IRQ_Handler            /* 48 */
    .word GPIOH_IRQ_Handler           /* 49 */
    .word RTC_IRQ_Handler             /* 50 */

/*
 * Exception dispatch table (mcause exception code 0..15).
 * Codes 8/9 are U/S-mode ECALL: AS32x601 runs M-mode only (no U/S mode),
 * so they are never generated on this chip and kept as reserved (0 -> fatal).
 * Codes 10/14 are architecturally reserved.
 */
    .align 2
exc_table:
    .word InstAddrMisalign_Handler      /*  0 */
    .word InstAccessFault_Handler       /*  1 */
    .word IllegalInst_Handler           /*  2 */
    .word Breakpoint_Handler            /*  3 */
    .word LoadAddrMisalign_Handler      /*  4 */
    .word LoadAccessFault_Handler       /*  5 */
    .word StoreAMOAddrMisalign_Handler  /*  6 */
    .word StoreAMOAccessFault_Handler   /*  7 */
    .word 0                             /*  8 U-mode ECALL (no U/S mode) */
    .word 0                             /*  9 S-mode ECALL (no U/S mode) */
    .word 0                             /* 10 reserved */
    .word ECall_Handler                 /* 11 */
    .word InstPageFault_Handler         /* 12 */
    .word LoadPageFault_Handler         /* 13 */
    .word 0                             /* 14 reserved */
    .word StoreAMOPageFault_Handler     /* 15 */

/*
 * SetMstatusMie - enable global interrupts (mstatus.MIE = 1)
 */
SetMstatusMie:
    csrsi    mstatus, 0x08
    ret

/*
 * ResetMstatusMie - disable global interrupts (mstatus.MIE = 0)
 */
ResetMstatusMie:
    csrci    mstatus, 0x08
    ret

/*
 * Default_Int_Handler is deliberately not defined in this file.  Its single
 * definition is the C __weak stub in as32x601_hal_plic.c (a fatal spin loop),
 * which keeps two properties:
 *   - exactly one definition in the image, so the hook that wins cannot depend
 *     on the object order of the link, and
 *   - a user strong definition still overrides it in the documented way.
 * It is referenced strongly above, so a build that drops the PLIC module fails
 * at link time instead of calling address 0 from the dispatch path.
 */

#if (HAL_INTERRUPT_STACK_SIZE > 0)
/* ============================================================================
 * Dedicated interrupt stack (RTOS mode, HAL_INTERRUPT_STACK_SIZE > 0).
 * Placed in a .bss sub-section so the linker script rule *(.bss .bss.*)
 * picks it up (zero-initialized, cleared by the startup bss loop).
 *   _isr_stack_bottom : low address (guard symbol)
 *   _isr_stack_top    : high address = initial sp; it is 16-byte aligned for any
 *                       configured size because ISR_STACK_BYTES rounds the range
 *                       up (the trap entry hands this value to sp before any C
 *                       handler runs)
 * ==========================================================================*/
    .section .bss.isr_stack, "aw", @nobits
    .align   4
    .global  _isr_stack_bottom
    .global  _isr_stack_top
_isr_stack_bottom:
    .space   ISR_STACK_BYTES
_isr_stack_top:
#endif /* (HAL_INTERRUPT_STACK_SIZE > 0) */
