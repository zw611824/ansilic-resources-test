/**
 * @file    DAC_IT_DRV_009.c
 * @brief   HAL DAC integration test case 009 (HAL_DAC_DeInit).
 *
 * Extension case of the DAC integration test suite: it covers the
 * de-initialization interface, which the one-to-one ports of the reference
 * cases exercise only implicitly.
 * Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_DAC_DeInit()              (register restore, state, idempotency)
 *   HAL_DAC_GetState() / HAL_DAC_GetError()
 *   HAL_DAC_Init()                (re-initialization after a de-initialization)
 *   the MSP callbacks            (the de-initialization runs after the unlock)
 *
 * Test procedure:
 *   1. Initialize DAC0, enable the data path, write a data value and program
 *      the comparator, so that every register owns a non default value;
 *   2. De-initialize and read the registers back: the enable / mode /
 *      reference fields have to be cleared, DAC_DOUT / DAC_CLK_DIV /
 *      DAC_CMP_CTRL have to return to their reset values and the state has to
 *      be RESET;
 *   3. Check that the reset bit DAC_CTRL.RESETN is not modified by the
 *      de-initialization (it belongs to HAL_DAC_ResetCmd()); the bit is read
 *      from the snapshot the MSP callback takes at its entrance, because the
 *      bus reset asserted by that callback clears the whole register file;
 *   4. Call the interface a second time (accepted, idempotent in terms of the
 *      register state) and with a NULL handle;
 *   5. Initialize again and check that the module works after the cycle.
 *
 * Expected behaviour:
 *   - the de-initialization returns the module to its reset configuration and
 *     the handle to the RESET state;
 *   - a second de-initialization is accepted and leaves the registers at their
 *     reset values; the interface has no state gate (it must stay callable in
 *     any state so that a failed initialization can be undone), so it runs the
 *     low level de-initialization once per accepted call (DAC-REQ-014);
 *   - the module can be initialized again afterwards;
 *   - every check prints [PASS] and "summary : failures = 0".
 *
 * @note   The MSP de-initialization of this suite closes the instance clock
 *         gate, so the case has to open it again (Dac_PeriphClockEnable())
 *         before the cleared registers are read back: an access to a
 *         peripheral whose gate is closed stalls the bus.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define -----------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* DAC output pins and comparator input pins of this suite, taken from the
 * device IO map (ioDoc): DAC0_OUT = PE4, DAC1_OUT = PC13,
 * CMP0_P = PE2, CMP0_N = PE3. */
#define TEST_DAC0_PORT              GPIOE
#define TEST_DAC0_PIN               GPIO_PIN_4
#define TEST_DAC0_SOURCE            GPIO_PinSource4
#define TEST_DAC1_PORT              GPIOC
#define TEST_DAC1_PIN               GPIO_PIN_13
#define TEST_DAC1_SOURCE            GPIO_PinSource13
#define TEST_CMP_PORT               GPIOE
#define TEST_CMP_P_PIN              GPIO_PIN_2
#define TEST_CMP_N_PIN              GPIO_PIN_3
#define TEST_CMP_P_SOURCE           GPIO_PinSource2
#define TEST_CMP_N_SOURCE           GPIO_PinSource3

/* Private variables ---------------------------------------------------------*/
static volatile uint32 check_failures = 0U;  /*!< failed check counter        */
static HAL_SMU_HandleTypeDef hsmu_clk;       /*!< SMU handle (clock tree)     */
static DAC_HandleTypeDef hadac_dev;          /*!< DAC under test              */

/* MSP callback bookkeeping (defined with the callbacks at the end of the file) */
extern uint32 Dac_MspInitCount;
extern uint32 Dac_MspDeInitCount;
extern uint32 Dac_MspStateAtInit;
extern uint32 Dac_MspLockAtInit;
extern uint32 Dac_MspStateAtDeInit;
extern uint32 Dac_MspCtrlAtDeInit;

/* Private function prototypes -----------------------------------------------*/
/* Shared helpers of this suite (defined at the end of this file) */
void Check(const char *name, uint32 condition);
void Summary(void);
void SystemClock_Init(void);
void Dac_PeriphClockEnable(DAC_TypeDef *instance);
void Dac_PinConfig(DAC_TypeDef *instance);
void Dac_InitStruct_Default(DAC_InitTypeDef *p_init);
HAL_StatusTypeDef Dac_Config(DAC_TypeDef *instance, FunctionalState enable, uint32 divider);
HAL_StatusTypeDef Dac_ConfigComparator(DAC_HandleTypeDef *hdac, uint32 cmp_enable, uint32 cmp_mode, uint32 cmp_hys);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    uint32 deinit_before;
    uint32 resetn_before;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== DAC_IT_DRV_009 : HAL_DAC_DeInit ===\r\n");

    /* ---- Step 1: a fully programmed module --------------------------- */
    Check("HAL_DAC_Init() returns HAL_OK", (Dac_Config(DAC0, ENABLE, 0x1EU) == HAL_OK));
    hadac_dev.Init.DAC_Mode     = DAC_OUTPUTBUFFER_DISABLE;
    hadac_dev.Init.DAC_VrefMode = DAC_VREF_MD_AVD;
    Check("the bypass mode and the AVD reference are programmed",
          (HAL_DAC_Init(&hadac_dev) == HAL_OK));
    Check("HAL_DAC_Start() returns HAL_OK", (HAL_DAC_Start(&hadac_dev) == HAL_OK));
    Check("HAL_DAC_SetValue(0xA5) returns HAL_OK",
          (HAL_DAC_SetValue(&hadac_dev, 0xA5U) == HAL_OK));
    Check("the comparator is programmed CMP_P / 330 mV / enabled",
          (Dac_ConfigComparator(&hadac_dev, DAC_CMP_ENABLE, DAC_CMP_MD_CMP_P,
                                DAC_CMP_HYS_330MV) == HAL_OK));
    Check("every register holds a non default value before the de-init",
          (((DAC0->CTRL & (DAC_CTRL_EN | DAC_CTRL_MD | DAC_CTRL_VREF_MD)) != 0U) &&
           (DAC0->DOUT == 0xA5U) && (DAC0->CLK_DIV == 0x1EU) &&
           (DAC0->CMP_CTRL != 0U)) ? 1U : 0U);

    resetn_before = (uint32)DAC0->CTRL & DAC_CTRL_RESETN;

    /* ---- Step 2: the de-initialization ------------------------------- */
    deinit_before = Dac_MspDeInitCount;
    Check("HAL_DAC_DeInit() returns HAL_OK", (HAL_DAC_DeInit(&hadac_dev) == HAL_OK));
    Check("the state is RESET after the de-initialization",
          (HAL_DAC_GetState(&hadac_dev) == HAL_DAC_STATE_RESET) ? 1U : 0U);
    Check("the error code is NONE after the de-initialization",
          (HAL_DAC_GetError(&hadac_dev) == HAL_DAC_ERROR_NONE) ? 1U : 0U);
    Check("the low level de-initialization ran exactly once",
          (Dac_MspDeInitCount == (deinit_before + 1U)) ? 1U : 0U);
    Check("the low level de-initialization ran with the handle in the RESET state",
          (Dac_MspStateAtDeInit == HAL_DAC_STATE_RESET) ? 1U : 0U);

    /* The MSP de-initialization closed the clock gate: open it again before
     * the registers are read back */
    Dac_PeriphClockEnable(DAC0);

    Check("CTRL.EN / MD / VREF_MD are cleared by the de-initialization",
          ((DAC0->CTRL & (DAC_CTRL_EN | DAC_CTRL_MD | DAC_CTRL_VREF_MD)) == 0U) ? 1U : 0U);
    Check("DAC_DOUT is back to its reset value",
          (DAC0->DOUT == 0x00U) ? 1U : 0U);
    Check("DAC_CLK_DIV is back to its reset value",
          (DAC0->CLK_DIV == 0x00U) ? 1U : 0U);
    Check("DAC_CMP_CTRL is back to its reset value",
          (DAC0->CMP_CTRL == 0x00U) ? 1U : 0U);
    /* The low level callback asserts the SMU bus reset (DAC-REQ-014: the reset
     * state belongs to the MSP callback, not to the driver) and that reset
     * clears the whole register file including DAC_CTRL.RESETN. The bit can
     * therefore only be observed as the driver left it at the entrance of the
     * callback (the Dac_MspCtrlAtDeInit snapshot), not after the callback has
     * run; the re-opened clock gate shows the hardware reset value instead. */
    Check("CTRL.RESETN was not modified by the de-initialization",
          (((Dac_MspCtrlAtDeInit & DAC_CTRL_RESETN) == resetn_before) &&
           (((uint32)DAC0->CTRL & DAC_CTRL_RESETN) == 0U)) ? 1U : 0U);

    /* ---- Step 3: idempotency and the NULL handle --------------------- */
    deinit_before = Dac_MspDeInitCount;
    Check("a second HAL_DAC_DeInit() is accepted (idempotent)",
          (HAL_DAC_DeInit(&hadac_dev) == HAL_OK));
    /* The interface deliberately has no state gate (DAC-REQ-014: it stays
     * callable in any state so that a failed initialization can always be
     * undone), therefore every accepted call runs the low level
     * de-initialization exactly once. */
    Check("every accepted de-initialization runs the low level one once",
          (Dac_MspDeInitCount == (deinit_before + 1U)) ? 1U : 0U);
    Check("HAL_DAC_DeInit(NULL) returns HAL_ERROR",
          (HAL_DAC_DeInit(NULL_PTR) == HAL_ERROR));

    /* ---- Step 4: the module works again ------------------------------ */
    Check("the module can be initialized again", (Dac_Config(DAC0, ENABLE, 0x1EU) == HAL_OK));
    Check("the state is READY again",
          (HAL_DAC_GetState(&hadac_dev) == HAL_DAC_STATE_READY) ? 1U : 0U);
    Check("the data path works after the initialization cycle",
          ((HAL_DAC_SetValue(&hadac_dev, 0x5AU) == HAL_OK) &&
           ((uint32)DAC0->DOUT == 0x5AU)) ? 1U : 0U);
    Check("the comparator can be configured again",
          (Dac_ConfigComparator(&hadac_dev, DAC_CMP_ENABLE, DAC_CMP_MD_CMP_P,
                                DAC_CMP_HYS_33MV) == HAL_OK));

    Summary();

    for (;;)
    {
        /* Keep the console alive for the observation */
        printf("state = %u, error = 0x%08X, CTRL = 0x%02X, DOUT = %u, CMP_CTRL = 0x%02X\r\n",
               PRINT_U32(HAL_DAC_GetState(&hadac_dev)),
               PRINT_U32(HAL_DAC_GetError(&hadac_dev)),
               PRINT_U32(DAC0->CTRL),
               PRINT_U32(DAC0->DOUT),
               PRINT_U32(DAC0->CMP_CTRL));
        delay_ms(2000U);
    }
}
/*****END OF FILE*****/

/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the other integration tests of this library:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2 and
 *         CANX2 by 8, which gives core 180 MHz, AXILiteBus1 (the DAC0 clock)
 *         and AXILiteBus2 (the DAC1 clock) 45 MHz and APB 22.5 MHz.
 * @note   Clock tree order: the dividers are written while the system clock
 *         is still the power on source (FIRC), then the PLL is configured and
 *         the system clock is switched to it. That last call programs the
 *         flash controller clock before the switch (the core keeps fetching
 *         from the flash) and updates SystemCoreClock afterwards.
 * @param  None
 * @retval None
 */
void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef    SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks of this suite (the DAC / comparator pins) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Enable the clock gate of a DAC instance and release its bus reset.
 * @note   The default MSP callbacks of the DAC driver are empty by design (the
 *         clock gate belongs to the application), therefore this suite performs
 *         the gate and bus reset handling itself. The macros drive
 *         SMU->ALB1CFGR (DAC0) / SMU->ALB2CFGR (DAC1), which is a different
 *         reset domain than the module reset bit DAC_CTRL.RESETN handled by
 *         HAL_DAC_ResetCmd().
 * @param  instance: DAC0 or DAC1
 * @retval None
 */
void Dac_PeriphClockEnable(DAC_TypeDef *instance)
{
    if (instance == DAC0)
    {
        __HAL_SMU_DAC0_CLK_ENABLE();
        __HAL_SMU_DAC0_FORCE_RESET();
        __HAL_SMU_DAC0_RELEASE_RESET();
    }
    else
    {
        __HAL_SMU_DAC1_CLK_ENABLE();
        __HAL_SMU_DAC1_FORCE_RESET();
        __HAL_SMU_DAC1_RELEASE_RESET();
    }
}

/**
 * @brief  Configure a group of pins as analog pins.
 * @note   Every pin of the mask is configured on its own, so that the
 *         multiplexer register of each pin is programmed with the "plain pin"
 *         alternate function before the pin is switched to the analog mode.
 * @param  port: GPIO port the pins belong to
 * @param  pins: pin mask (GPIO_PIN_x or a combination)
 * @retval None
 */
static void Gpio_AnalogConfig(GPIO_TypeDef *port, uint32 pins)
{
    GPIO_InitTypeDef gpio_init;
    uint32 i;
    uint32 pin;

    __HAL_CLEAR_STRUCT(&gpio_init);
    gpio_init.Size         = sizeof(gpio_init);
    gpio_init.Version      = GPIO_INIT_VERSION;
    gpio_init.Pull         = GPIO_NOPULL;
    gpio_init.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;
    gpio_init.Mode         = GPIO_MODE_ANALOG;
    gpio_init.Alternate    = GPIO_AF_Pin_x;

    for (i = 0U; i < 16U; i++)
    {
        pin = (uint32)(1UL << i);
        if ((pins & pin) != 0U)
        {
            HAL_GPIO_PinAFConfig(port, i, GPIO_AF_Pin_x);
            gpio_init.Pin = pin;
            (void)HAL_GPIO_Init(port, &gpio_init);
        }
    }
}

/**
 * @brief  Configure the analog pins of one DAC instance.
 * @note   DAC0 drives PE4 and uses the comparator inputs CMP0_P (PE2) and
 *         CMP0_N (PE3); DAC1 drives PC13. The pin map comes from the device IO
 *         map (ioDoc.xlsx, column "analog function").
 * @param  instance: DAC0 or DAC1
 * @retval None
 */
void Dac_PinConfig(DAC_TypeDef *instance)
{
    if (instance == DAC0)
    {
        Gpio_AnalogConfig(TEST_DAC0_PORT, TEST_DAC0_PIN);
        Gpio_AnalogConfig(TEST_CMP_PORT, TEST_CMP_P_PIN | TEST_CMP_N_PIN);
    }
    else
    {
        Gpio_AnalogConfig(TEST_DAC1_PORT, TEST_DAC1_PIN);
    }
}

/**
 * @brief  Fill a DAC init structure with the configuration of the reference
 *         test project (the baseline every case starts from).
 * @note   The structure meta fields (Size / Version) are filled by
 *         HAL_DAC_StructInit(), and the initialization interface validates
 *         them at run time, so this helper is the only place where the
 *         baseline is built.
 * @param  p_init: pointer to the init structure to fill
 * @retval None
 */
void Dac_InitStruct_Default(DAC_InitTypeDef *p_init)
{
    HAL_DAC_StructInit(p_init);

    p_init->DAC_Enable       = DISABLE;
    p_init->DAC_Mode         = DAC_OUTPUTBUFFER_ENABLE;
    p_init->DAC_VrefMode     = DAC_VREF_MD_VREFP;
    p_init->DAC_ClockDivider = 0x1EU;      /* the divider of the reference case */
}

/**
 * @brief  Configure and initialize one DAC instance.
 * @note   HAL_DAC_Init() does not release the module reset (DAC_CTRL.RESETN
 *         resets to 0), so HAL_DAC_ResetCmd() is called afterwards to release
 *         it: without that call HAL_DAC_Start() / HAL_DAC_SetValue() report
 *         HAL_ERROR. The clear+settle delay follows the sequence documented by
 *         the driver (release the reset, wait for the data path to settle).
 * @param  instance: DAC0 or DAC1
 * @param  enable: initial value of the DAC enable field (ENABLE / DISABLE)
 * @param  divider: clock divide ratio (1 to 0xFF)
 * @retval HAL status of HAL_DAC_Init()
 */
HAL_StatusTypeDef Dac_Config(DAC_TypeDef *instance, FunctionalState enable, uint32 divider)
{
    DAC_InitTypeDef dac_init;
    HAL_StatusTypeDef status;

    Dac_PinConfig(instance);

    __HAL_CLEAR_STRUCT(&hadac_dev);
    hadac_dev.Instance = instance;

    Dac_InitStruct_Default(&dac_init);
    dac_init.DAC_Enable       = enable;
    dac_init.DAC_ClockDivider = divider;
    hadac_dev.Init = dac_init;

    status = HAL_DAC_Init(&hadac_dev);
    if (status == HAL_OK)
    {
        (void)HAL_DAC_ResetCmd(&hadac_dev, 1U);
        delay_ms(20U);
    }

    return status;
}

/**
 * @brief  Configure the comparator of one DAC instance.
 * @param  hdac: DAC handle
 * @param  cmp_enable: DAC_CMP_ENABLE / DAC_CMP_DISABLE
 * @param  cmp_mode: DAC_CMP_MD_DACO / DAC_CMP_MD_CMP_P
 * @param  cmp_hys: DAC_CMP_HYS_xMV (0 to 7)
 * @retval HAL status of HAL_DAC_ConfigComparator()
 */
HAL_StatusTypeDef Dac_ConfigComparator(DAC_HandleTypeDef *hdac, uint32 cmp_enable,
                                       uint32 cmp_mode, uint32 cmp_hys)
{
    DAC_CMPConfTypeDef cmp_conf;

    HAL_DAC_CMPStructInit(&cmp_conf);
    cmp_conf.CMP_Enable     = cmp_enable;
    cmp_conf.CMP_Mode       = cmp_mode;
    cmp_conf.CMP_Hysteresis = cmp_hys;

    return HAL_DAC_ConfigComparator(hdac, &cmp_conf);
}

/* MSP callback bookkeeping -------------------------------------------------*/

uint32 Dac_MspInitCount    = 0U;   /*!< HAL_DAC_MspInit() call counter        */
uint32 Dac_MspDeInitCount  = 0U;   /*!< HAL_DAC_MspDeInit() call counter      */
uint32 Dac_MspStateAtInit  = 0xFFU;/*!< handle state observed in MspInit      */
uint32 Dac_MspLockAtInit   = 0xFFU;/*!< handle lock observed in MspInit       */
uint32 Dac_MspStateAtDeInit= 0xFFU;/*!< handle state observed in MspDeInit    */
uint32 Dac_MspCtrlAtDeInit = 0U;   /*!< DAC_CTRL observed in MspDeInit        */

/**
 * @brief  Initialize the low level hardware of the DAC (strong override of the
 *         weak callback of the driver).
 * @note   Records the call and the handle fields it observes, so that the
 *         cases can assert the MSP contract: the callback runs once per
 *         initialization, before the handle is locked (LOCK-06) and while the
 *         handle is still in the RESET state (MSP-04).
 * @param  hdac: DAC handle
 * @retval None
 */
void HAL_DAC_MspInit(DAC_HandleTypeDef *hdac)
{
    if (hdac == NULL_PTR)
    {
        return;
    }

    Dac_MspInitCount++;
    Dac_MspStateAtInit = (uint32)hdac->State;
    Dac_MspLockAtInit  = (uint32)hdac->Lock;

    Dac_PeriphClockEnable(hdac->Instance);
}

/**
 * @brief  De-initialize the low level hardware of the DAC (strong override of
 *         the weak callback of the driver).
 * @note   The callback runs after the handle has been unlocked (LOCK-06) and
 *         after the state has been set back to RESET.
 * @param  hdac: DAC handle
 * @retval None
 */
void HAL_DAC_MspDeInit(DAC_HandleTypeDef *hdac)
{
    if (hdac == NULL_PTR)
    {
        return;
    }

    Dac_MspDeInitCount++;
    Dac_MspStateAtDeInit = (uint32)hdac->State;

    /* Snapshot the control register before the bus reset below clears it: this
     * is the value the driver left behind, i.e. the only observation point of
     * the "the de-initialization does not touch DAC_CTRL.RESETN" contract */
    Dac_MspCtrlAtDeInit = (uint32)hdac->Instance->CTRL;

    if (hdac->Instance == DAC0)
    {
        __HAL_SMU_DAC0_FORCE_RESET();
        __HAL_SMU_DAC0_CLK_DISABLE();
    }
    else
    {
        __HAL_SMU_DAC1_FORCE_RESET();
        __HAL_SMU_DAC1_CLK_DISABLE();
    }
}
