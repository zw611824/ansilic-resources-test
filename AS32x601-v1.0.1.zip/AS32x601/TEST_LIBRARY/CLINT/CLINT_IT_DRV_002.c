/**
 * @file    CLINT_IT_DRV_002.c
 * @brief   HAL CLINT integration test case 002 (init / de-init / state).
 *
 * One-to-one HAL library port of the original AS32x601 standard-library
 * test case CLINT_IT_DRV_002.c. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_CLINT_Init()
 *   HAL_CLINT_DeInit()
 *   HAL_CLINT_GetState()
 *   HAL_CLINT_GetError()
 *   HAL_CLINT_GetTimerComparator() (the planned instant is forgotten by both
 *   the initialization and the de-initialization)
 *
 * Test procedure:
 *   1. Call the API with a NULL handle (defensive path);
 *   2. Initialize the CLINT and read back the handle state / error code;
 *   3. Initialize the CLINT a second time (already initialized);
 *   4. Program a planned instant, then de-initialize the CLINT and read back
 *      the handle state / error code and the comparator mirror;
 *   5. Initialize the CLINT again (recovery);
 *   6. Repeat steps 1..5 periodically.
 *
 * Expected behaviour:
 *   - A NULL handle is rejected with HAL_ERROR and leaves the getters safe
 *     (GetState(NULL) = RESET, GetError(NULL) = NONE);
 *   - After HAL_CLINT_Init() the state is READY and the error code is NONE;
 *   - After HAL_CLINT_DeInit() the state is RESET and the error code is NONE;
 *   - The comparator mirror is cleared by both HAL_CLINT_Init() and
 *     HAL_CLINT_DeInit(), so no stale planned instant can survive;
 *   - Every check prints PASS.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Period of the whole check sequence */
#define TEST_PERIOD_MS              (2000U)

/* Private variables ---------------------------------------------------------*/
static HAL_CLINT_HandleTypeDef hclint;      /*!< CLINT handle                 */
static uint32 check_count = 0U;             /*!< executed checks              */
static uint32 fail_count  = 0U;             /*!< failed checks                */

static HAL_SMU_HandleTypeDef hsmu_clk;   /*!< SMU handle (lock / state / error) */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void test_check(const char *name, int ok);
static void clint_CheckSequence(void);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== CLINT_IT_DRV_002: init / de-init / state ===\r\n");

    while (1)
    {
        clint_CheckSequence();

        printf("checks = %u, failed = %u\r\n\r\n",
               PRINT_U32(check_count), PRINT_U32(fail_count));

        check_count = 0U;
        fail_count  = 0U;

        delay_ms(TEST_PERIOD_MS);
    }
}

/**
 * @brief  Run the CLINT init / de-init / state check sequence once.
 * @param  None
 * @retval None
 */
static void clint_CheckSequence(void)
{
    HAL_CLINT_HandleTypeDef safe;

    /* Step 1: NULL handle protection */
    test_check("HAL_CLINT_Init(NULL) = HAL_ERROR",
               (HAL_CLINT_Init(NULL_PTR) == HAL_ERROR));
    test_check("HAL_CLINT_GetState(NULL) = RESET",
               (HAL_CLINT_GetState(NULL_PTR) == HAL_CLINT_STATE_RESET));
    test_check("HAL_CLINT_GetError(NULL) = NONE",
               (HAL_CLINT_GetError(NULL_PTR) == HAL_CLINT_ERROR_NONE));

    /* Step 2: normal initialization */
    hclint.Instance = CLINT;
    test_check("HAL_CLINT_Init() = HAL_OK",
               (HAL_CLINT_Init(&hclint) == HAL_OK));
    test_check("state after init = READY",
               (HAL_CLINT_GetState(&hclint) == HAL_CLINT_STATE_READY));
    test_check("error after init = NONE",
               (HAL_CLINT_GetError(&hclint) == HAL_CLINT_ERROR_NONE));

    /* Step 3: initialize an already initialized peripheral */
    test_check("HAL_CLINT_Init() again = HAL_OK",
               (HAL_CLINT_Init(&hclint) == HAL_OK));
    test_check("state stays READY",
               (HAL_CLINT_GetState(&hclint) == HAL_CLINT_STATE_READY));

    /* Step 4: program a planned instant through the comparator, so that the
     * de-initialization below has something to forget.  The comparator
     * registers are write only, hence the value is observed on the software
     * mirror that the driver keeps in step with them. */
    HAL_CLINT_SetTimerComparator(&hclint, HAL_CLINT_ReadTimerValue(&hclint) + 1000000U);
    test_check("mirror non zero after programming a comparator",
               (HAL_CLINT_GetTimerComparator(&hclint) != 0U));

    /* Step 5: de-initialization */
    test_check("HAL_CLINT_DeInit() = HAL_OK",
               (HAL_CLINT_DeInit(&hclint) == HAL_OK));
    test_check("state after de-init = RESET",
               (HAL_CLINT_GetState(&hclint) == HAL_CLINT_STATE_RESET));
    test_check("error after de-init = NONE",
               (HAL_CLINT_GetError(&hclint) == HAL_CLINT_ERROR_NONE));
    test_check("mirror forgotten by de-init = 0",
               (HAL_CLINT_GetTimerComparator(&hclint) == 0U));

    /* Step 6: NULL handle protection on the de-initialization path */
    test_check("HAL_CLINT_DeInit(NULL) = HAL_ERROR",
               (HAL_CLINT_DeInit(NULL_PTR) == HAL_ERROR));

    /* Step 7: recovery - the peripheral can be initialized again */
    test_check("HAL_CLINT_Init() after de-init = HAL_OK",
               (HAL_CLINT_Init(&hclint) == HAL_OK));
    test_check("state after recovery = READY",
               (HAL_CLINT_GetState(&hclint) == HAL_CLINT_STATE_READY));

    /* Step 8: a second, independent handle is initialized from scratch.  The
     * structure is cleared first, so every field the driver does not program
     * itself (e.g. the comparator mirror) starts from a defined value. */
    __HAL_CLEAR_STRUCT(&safe);
    safe.Instance = CLINT;
    test_check("second handle HAL_CLINT_Init() = HAL_OK",
               (HAL_CLINT_Init(&safe) == HAL_OK));
    test_check("second handle state = READY",
               (HAL_CLINT_GetState(&safe) == HAL_CLINT_STATE_READY));
    test_check("second handle mirror = 0",
               (HAL_CLINT_GetTimerComparator(&safe) == 0U));
}

/**
 * @brief  Print the result of one check and update the statistics.
 * @param  name: check description.
 * @param  ok: non-zero when the check passed.
 * @retval None
 */
static void test_check(const char *name, int ok)
{
    check_count++;

    if (ok == 0)
    {
        fail_count++;
    }

    printf("  [%s] %s\r\n", (ok != 0) ? "PASS" : "FAIL", name);
}

/**
 * @brief  Configure the system clock tree using the HAL SMU driver.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef  SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef   SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it (CLKFRQ above), so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Clock tree order: this is the order the chip requires, and the vendor
       test case uses the same one.
         1. Write the bus clock dividers while the system clock is still the
            power-on source (FIRC), so that the new divider values are already
            in place when the faster clock arrives. Writing them AFTER the
            switch instead leaves the buses at their reset dividers for a
            moment at the new core clock: at 180 MHz that is
            AXI4Bus3 = 90 MHz and APBBus0 = 45 MHz, right at their ratings, and
            the core does not survive it (measured on the board: the core
            trapped before the divider write was reached, so no output was
            produced at all).
         2. Program the EFLASH controller clock: the controller must already
            know the final frequency while the code still runs from the flash.
         3. Then configure the PLL and switch the system clock to it; this call
            also updates SystemCoreClock and re-initializes the HAL time base. */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
