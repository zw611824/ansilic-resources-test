/**
 * @file    CRC_IT_DRV_002.c
 * @brief   HAL CRC integration test case 002 (word / half-word / byte blocks).
 *
 * HAL library extension case: the reference library only offers the single
 * word entry plus the three block entries, so this case verifies that the
 * block services and the runtime-format services agree with each other.
 *
 * Tested functionality:
 *   HAL_CRC_StructInit() / HAL_CRC_Init()
 *   HAL_CRC_CalcWordBlockCRC()
 *   HAL_CRC_CalcHalfBlockCRC()
 *   HAL_CRC_CalcByteBlockCRC()
 *   HAL_CRC_Accumulate()
 *   HAL_CRC_Calculate()
 *   HAL_CRC_CalcCRC()
 *   HAL_CRC_Reset()
 *   HAL_CRC_GetCRC() / HAL_CRC_GetState() / HAL_CRC_GetError()
 *
 * Test procedure:
 *   1. initialize the handle with the CRC-32 default configuration and the
 *      word input data format;
 *   2. word block: reset, feed four words through HAL_CRC_CalcWordBlockCRC()
 *      and compare with (a) the same data fed element by element through
 *      HAL_CRC_CalcCRC() and (b) HAL_CRC_Calculate() on the same buffer;
 *   3. accumulation across blocks: two consecutive word blocks must equal a
 *      single calculate over the concatenated buffer;
 *   4. half-word block: compare with HAL_CRC_Accumulate() in the half-word
 *      format (both write 16-bit elements, so they must agree);
 *   5. byte block: compare with HAL_CRC_Accumulate() in the byte format;
 *   6. zero length feeds nothing and returns the current accumulator;
 *   7. a NULL buffer is rejected (returns 0, records INVALID_PARAM, leaves the
 *      handle state and the accumulator untouched).
 *
 * Expected behaviour:
 *   every equivalence below holds and the summary prints
 *   "summary : failures = 0".
 *
 * Note:
 *   The element write width is part of the CRC definition: the dedicated block
 *   services write 32 / 16 / 8-bit elements, and the format driven services
 *   write the element width selected by HAL_CRC_INPUTDATA_FORMAT_*. A block
 *   service therefore only agrees with the format driven service of the same
 *   element width, which is what the checks below compare.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
#define TEST_BAUDRATE                  (115200U)   /*!< console baud rate        */
#define TEST_ROUND_DELAY_MS            (2000U)     /*!< delay between two rounds */

#define TEST_WORD_COUNT                (4U)        /*!< 32-bit element count     */
#define TEST_HALF_COUNT                (8U)        /*!< 16-bit element count     */
#define TEST_BYTE_COUNT                (8U)        /*!< 8-bit element count      */

/* Private variables ---------------------------------------------------------*/
static volatile uint32 check_failures = 0U;   /*!< failed check counter           */
static HAL_SMU_HandleTypeDef hsmu_clk;        /*!< SMU handle (clock tree)        */

/** @brief CRC handle used by this case. */
HAL_CRC_HandleTypeDef hcrc_dev;

/* MSP callback bookkeeping (written by the shared MSP callbacks) */
uint32 Crc_MspInitCount   = 0U;               /*!< HAL_CRC_MspInit() calls        */
uint32 Crc_MspDeInitCount = 0U;               /*!< HAL_CRC_MspDeInit() calls      */
uint32 Crc_MspStateAtInit = 0xFFFFFFFFU;      /*!< handle state seen in the MSP   */
uint32 Crc_MspLockAtInit  = 0xFFFFFFFFU;      /*!< handle lock seen in the MSP    */

/* Test pattern: the same bytes viewed as words / half-words / bytes.
 * The block services take a non-const element pointer (the hardware reads the
 * buffer only, but the API keeps the plain pointer of the reference library),
 * so the patterns are plain arrays and are never written by this case. */
static uint32 test_words[TEST_WORD_COUNT] =
{
    0x11223344U, 0x55667788U, 0x99AABBCCU, 0xDDEEFF00U
};

static uint32 test_words_second[TEST_WORD_COUNT] =
{
    0x0F1E2D3CU, 0x4B5A6978U, 0x8796A5B4U, 0xC3D2E1F0U
};

static uint16 test_halfs[TEST_HALF_COUNT] =
{
    0x1234U, 0x5678U, 0x9ABCU, 0xDEF0U, 0x0F1EU, 0x2D3CU, 0x4B5AU, 0x6978U
};

static uint8 test_bytes[TEST_BYTE_COUNT] =
{
    0x01U, 0x23U, 0x45U, 0x67U, 0x89U, 0xABU, 0xCDU, 0xEFU
};

/* Shared helpers of this suite (defined at the end of this file) */
void Check(const char *name, uint32 condition);
void Summary(void);
void SystemClock_Init(void);
void Crc_ClockEnable(void);



/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    CRC_InitTypeDef   crc_init;
    HAL_StatusTypeDef status;
    uint32 round = 0U;
    uint32 by_block;
    uint32 by_element;
    uint32 by_calculate;
    uint32 first_half;
    uint32 accumulator;
    uint32 index;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== CRC_IT_DRV_002 : word / half-word / byte blocks ===\r\n");

    /* Handle preparation */
    __HAL_CLEAR_STRUCT(&hcrc_dev);
    hcrc_dev.Instance = CRC;
    HAL_CRC_StructInit(&crc_init);
    Check("HAL_CRC_StructInit() fills the Size metafield",
          (crc_init.Size == (uint32)sizeof(CRC_InitTypeDef)) ? 1U : 0U);
    Check("HAL_CRC_StructInit() fills the Version metafield",
          (crc_init.Version == CRC_INIT_VERSION) ? 1U : 0U);
    hcrc_dev.Init = crc_init;
    hcrc_dev.InputDataFormat = HAL_CRC_INPUTDATA_FORMAT_WORDS;

    status = HAL_CRC_Init(&hcrc_dev);
    Check("HAL_CRC_Init() returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("the handle is READY", (HAL_CRC_GetState(&hcrc_dev) == HAL_CRC_STATE_READY) ? 1U : 0U);

    for (;;)
    {
        /* ---------------- word block ------------------------------------- */
        HAL_CRC_Reset(&hcrc_dev);
        by_block = HAL_CRC_CalcWordBlockCRC(&hcrc_dev, (uint32 *)test_words, TEST_WORD_COUNT);

        HAL_CRC_Reset(&hcrc_dev);
        by_element = 0U;
        for (index = 0U; index < TEST_WORD_COUNT; index++)
        {
            by_element = HAL_CRC_CalcCRC(&hcrc_dev, test_words[index]);
        }

        by_calculate = HAL_CRC_Calculate(&hcrc_dev, test_words, TEST_WORD_COUNT);

        printf("word block      : 0x%08X (per element 0x%08X, calculate 0x%08X)\r\n",
               (unsigned int)by_block, (unsigned int)by_element, (unsigned int)by_calculate);
        if (round == 0U)
        {
            Check("CalcWordBlockCRC() equals the per-element CalcCRC() sequence",
                  (by_block == by_element) ? 1U : 0U);
            Check("CalcWordBlockCRC() equals Calculate() on the same buffer",
                  (by_block == by_calculate) ? 1U : 0U);
            Check("the result is not the untouched initial value",
                  (by_block != hcrc_dev.Init.CRC_INIT) ? 1U : 0U);
        }

        /* ---------------- accumulation across two blocks ------------------- */
        HAL_CRC_Reset(&hcrc_dev);
        (void)HAL_CRC_CalcWordBlockCRC(&hcrc_dev, (uint32 *)test_words, TEST_WORD_COUNT);
        first_half = HAL_CRC_CalcWordBlockCRC(&hcrc_dev, (uint32 *)test_words_second, TEST_WORD_COUNT);

        {
            uint32 concatenated[TEST_WORD_COUNT * 2U];
            for (index = 0U; index < TEST_WORD_COUNT; index++)
            {
                concatenated[index] = test_words[index];
                concatenated[index + TEST_WORD_COUNT] = test_words_second[index];
            }
            by_calculate = HAL_CRC_Calculate(&hcrc_dev, concatenated, TEST_WORD_COUNT * 2U);
        }
        if (round == 0U)
        {
            Check("two consecutive word blocks equal one calculate over both",
                  (first_half == by_calculate) ? 1U : 0U);
        }

        /* ---------------- half-word block --------------------------------- */
        HAL_CRC_Reset(&hcrc_dev);
        by_block = HAL_CRC_CalcHalfBlockCRC(&hcrc_dev, (uint16 *)test_halfs, TEST_HALF_COUNT);

        hcrc_dev.InputDataFormat = HAL_CRC_INPUTDATA_FORMAT_HALFWORDS;
        HAL_CRC_Reset(&hcrc_dev);
        by_element = HAL_CRC_Accumulate(&hcrc_dev, test_halfs, TEST_HALF_COUNT);
        hcrc_dev.InputDataFormat = HAL_CRC_INPUTDATA_FORMAT_WORDS;

        printf("half-word block : 0x%08X (accumulate 0x%08X)\r\n", (unsigned int)by_block, (unsigned int)by_element);
        if (round == 0U)
        {
            Check("CalcHalfBlockCRC() equals Accumulate() in the half-word format",
                  (by_block == by_element) ? 1U : 0U);
        }

        /* ---------------- byte block -------------------------------------- */
        HAL_CRC_Reset(&hcrc_dev);
        by_block = HAL_CRC_CalcByteBlockCRC(&hcrc_dev, (uint8 *)test_bytes, TEST_BYTE_COUNT);

        hcrc_dev.InputDataFormat = HAL_CRC_INPUTDATA_FORMAT_BYTES;
        HAL_CRC_Reset(&hcrc_dev);
        by_element = HAL_CRC_Accumulate(&hcrc_dev, test_bytes, TEST_BYTE_COUNT);
        hcrc_dev.InputDataFormat = HAL_CRC_INPUTDATA_FORMAT_WORDS;

        printf("byte block      : 0x%08X (accumulate 0x%08X)\r\n", (unsigned int)by_block, (unsigned int)by_element);
        if (round == 0U)
        {
            Check("CalcByteBlockCRC() equals Accumulate() in the byte format",
                  (by_block == by_element) ? 1U : 0U);
            Check("the byte block result differs from the half-word block result",
                  (by_block != 0U) ? 1U : 0U);
        }

        /* ---------------- zero length feeds nothing ------------------------ */
        HAL_CRC_Reset(&hcrc_dev);
        (void)HAL_CRC_CalcCRC(&hcrc_dev, 0x12345678U);
        accumulator = HAL_CRC_GetCRC(&hcrc_dev);
        by_element = HAL_CRC_CalcWordBlockCRC(&hcrc_dev, (uint32 *)test_words, 0U);
        if (round == 0U)
        {
            Check("a zero-length word block returns the current accumulator",
                  (by_element == accumulator) ? 1U : 0U);
            Check("a zero-length block does not advance the accumulator",
                  (HAL_CRC_GetCRC(&hcrc_dev) == accumulator) ? 1U : 0U);
        }

        /* ---------------- NULL buffer rejection --------------------------- */
        accumulator = HAL_CRC_GetCRC(&hcrc_dev);
        hcrc_dev.ErrorCode = HAL_CRC_ERROR_NONE;

        Check("CalcWordBlockCRC(NULL) returns 0",
              (HAL_CRC_CalcWordBlockCRC(&hcrc_dev, NULL, TEST_WORD_COUNT) == 0U) ? 1U : 0U);
        Check("CalcWordBlockCRC(NULL) records INVALID_PARAM",
              (HAL_CRC_GetError(&hcrc_dev) == HAL_CRC_ERROR_INVALID_PARAM) ? 1U : 0U);
        Check("CalcWordBlockCRC(NULL) keeps the handle READY",
              (HAL_CRC_GetState(&hcrc_dev) == HAL_CRC_STATE_READY) ? 1U : 0U);
        Check("CalcWordBlockCRC(NULL) leaves the accumulator unchanged",
              (HAL_CRC_GetCRC(&hcrc_dev) == accumulator) ? 1U : 0U);

        hcrc_dev.ErrorCode = HAL_CRC_ERROR_NONE;
        Check("CalcHalfBlockCRC(NULL) returns 0",
              (HAL_CRC_CalcHalfBlockCRC(&hcrc_dev, NULL, TEST_HALF_COUNT) == 0U) ? 1U : 0U);
        Check("CalcHalfBlockCRC(NULL) records INVALID_PARAM",
              (HAL_CRC_GetError(&hcrc_dev) == HAL_CRC_ERROR_INVALID_PARAM) ? 1U : 0U);

        hcrc_dev.ErrorCode = HAL_CRC_ERROR_NONE;
        Check("CalcByteBlockCRC(NULL) returns 0",
              (HAL_CRC_CalcByteBlockCRC(&hcrc_dev, NULL, TEST_BYTE_COUNT) == 0U) ? 1U : 0U);
        Check("CalcByteBlockCRC(NULL) records INVALID_PARAM",
              (HAL_CRC_GetError(&hcrc_dev) == HAL_CRC_ERROR_INVALID_PARAM) ? 1U : 0U);

        hcrc_dev.ErrorCode = HAL_CRC_ERROR_NONE;
        Check("Accumulate(NULL) returns 0",
              (HAL_CRC_Accumulate(&hcrc_dev, NULL, TEST_WORD_COUNT) == 0U) ? 1U : 0U);
        Check("Accumulate(NULL) records INVALID_PARAM",
              (HAL_CRC_GetError(&hcrc_dev) == HAL_CRC_ERROR_INVALID_PARAM) ? 1U : 0U);

        hcrc_dev.ErrorCode = HAL_CRC_ERROR_NONE;
        Check("Calculate(NULL) returns 0",
              (HAL_CRC_Calculate(&hcrc_dev, NULL, TEST_WORD_COUNT) == 0U) ? 1U : 0U);
        Check("Calculate(NULL) records INVALID_PARAM",
              (HAL_CRC_GetError(&hcrc_dev) == HAL_CRC_ERROR_INVALID_PARAM) ? 1U : 0U);

        /* A rejected call must not disturb the configuration either */
        Check("the control register still holds the CRC-32 data size",
              ((CRC->CR & CRC_CR_SIZE) == ((uint32)CRC_SIZE_32B << CRC_CR_SIZE_Pos)) ? 1U : 0U);

        if (round == 0U)
        {
            Summary();
        }

        round++;
        delay_ms(TEST_ROUND_DELAY_MS);
    }
}

/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the other integration tests of this library:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2 and
 *         CANX2 by 8, which gives core 180 MHz and APB 22.5 MHz (the console
 *         USART and the CRC unit are clocked from APBBus0 / APBBus1).
 * @param  None
 * @retval None
 */
void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks (console pins of USART0 on GPIOD) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Open the clock gate of the CRC unit and release its reset.
 * @param  None
 * @retval None
 */
void Crc_ClockEnable(void)
{
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_CRC_CLK_ENABLE();
    __HAL_SMU_CRC_FORCE_RESET();
    __HAL_SMU_CRC_RELEASE_RESET();
}

/* MSP callbacks ------------------------------------------------------------*/

/**
 * @brief  Initialize the CRC MSP (clock gate and reset release).
 * @param  hcrc: CRC handle
 * @retval None
 */
void HAL_CRC_MspInit(HAL_CRC_HandleTypeDef *hcrc)
{
    Crc_MspInitCount++;
    Crc_MspStateAtInit = (uint32)hcrc->State;
    Crc_MspLockAtInit  = (uint32)hcrc->Lock;

    Crc_ClockEnable();
}

/**
 * @brief  De-initialize the CRC MSP (the clock gate is left open).
 * @param  hcrc: CRC handle
 * @retval None
 */
void HAL_CRC_MspDeInit(HAL_CRC_HandleTypeDef *hcrc)
{
    Crc_MspDeInitCount++;

    (void)hcrc;
}

/*****END OF FILE*****/
