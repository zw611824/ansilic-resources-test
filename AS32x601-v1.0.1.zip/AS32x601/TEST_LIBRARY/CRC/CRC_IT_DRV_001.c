/**
 * @file    CRC_IT_DRV_001.c
 * @brief   HAL CRC integration test case 001 (polynomial x input reversal).
 *
 * One-to-one HAL library port of the reference AS32x601 standard-library test
 * case CRC_IT_DRV_001.c (as32x601_eco_test\CRC\TestCase). Only HAL library
 * APIs are used.
 *
 * Tested functionality:
 *   HAL_CRC_StructInit()
 *   HAL_CRC_Init()
 *   HAL_CRC_CalcCRC()
 *   HAL_CRC_Reset()
 *   HAL_CRC_GetCRC() / HAL_CRC_GetState() / HAL_CRC_GetError()
 *
 * Test procedure (the same eight polynomial groups and the same four input
 * reversal modes as the reference case, in the same order):
 *   1. open the CRC clock and initialize the handle;
 *   2. for every polynomial group (7MMC / 8 / 8MAXIM / 16IBM / 16XMODEM /
 *      16DNP / 32 / 32C):
 *        - configure the data size, the output XOR, the output reversal, the
 *          polynomial size, the initial value, the polynomial and the XOR
 *          value exactly as the reference case does;
 *        - for every input reversal mode (00 none / 01 byte / 10 half-word /
 *          11 word) feed one data word through HAL_CRC_CalcCRC() and print the
 *          result, so that the printed sequence can be compared one to one
 *          with the reference case;
 *   3. after the sweep the case keeps verifying invariants in the loop:
 *        - the same configuration always yields the same value;
 *        - HAL_CRC_Reset() restarts the calculation from the configured
 *          initial value and the next single-word feed reproduces the value
 *          (the data register itself is not preloaded: on this device it
 *          keeps the last computed result until the next element is fed);
 *        - the data size / polynomial pairs really change the result.
 *
 * Expected behaviour:
 *   every configuration is accepted, the four input reversal modes are
 *   reported for every polynomial, the invariants hold and the summary prints
 *   "summary : failures = 0".
 *
 * Note:
 *   The reference case calls CRC_Reset() -> CRC_StructInit() -> CRC_Init()
 *   for every configuration. The HAL driver separates the configuration from
 *   the reset service: HAL_CRC_Init() reprograms the whole configuration on
 *   an already initialized handle, and HAL_CRC_Reset() only reloads the
 *   accumulator from CRC_INIT while keeping the configured fields (see
 *   CRC-REQ-041). The case therefore reuses one handle and calls
 *   HAL_CRC_Init() per configuration, which is the equivalent sequence.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
#define TEST_BAUDRATE                  (115200U)   /*!< console baud rate         */
#define TEST_ROUND_DELAY_MS            (2000U)     /*!< delay between two rounds  */

/* Private variables ---------------------------------------------------------*/
static volatile uint32 check_failures = 0U;   /*!< failed check counter           */
static HAL_SMU_HandleTypeDef hsmu_clk;        /*!< SMU handle (clock tree)        */

/**
 * @brief  CRC handle used by every case of this suite.
 * @note   The CRC is a single instance, so one handle is enough; the
 *         initialization and lifecycle cases use additional local handles for
 *         the refusal paths.
 */
HAL_CRC_HandleTypeDef hcrc_dev;

/* MSP callback bookkeeping (written by the shared MSP callbacks) */
uint32 Crc_MspInitCount   = 0U;               /*!< HAL_CRC_MspInit() calls        */
uint32 Crc_MspDeInitCount = 0U;               /*!< HAL_CRC_MspDeInit() calls      */
uint32 Crc_MspStateAtInit = 0xFFFFFFFFU;      /*!< handle state seen in the MSP   */
uint32 Crc_MspLockAtInit  = 0xFFFFFFFFU;      /*!< handle lock seen in the MSP    */

/* Shared helpers of this suite (defined at the end of this file) */
void Check(const char *name, uint32 condition);
void Summary(void);
void SystemClock_Init(void);
void Crc_ClockEnable(void);
HAL_StatusTypeDef Crc_Configure(CRC_SizeTypeDef size, uint32 oxor, uint32 oreverse,
                                CRC_IReverseTypeDef ireverse, CRC_PolySizeTypeDef polysize,
                                uint32 init, uint32 poly, uint32 xor);



/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    CRC_InitTypeDef   crc_init;
    HAL_StatusTypeDef status;
    uint32 round = 0U;
    uint32 ireverse;
    uint32 value[4];
    uint32 value_again;
    uint32 reset_value;
    uint32 distinct;
    uint32 index;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== CRC_IT_DRV_001 : polynomial x input reversal ===\r\n");

    /* Handle preparation: clear the structure, then take the metadata from
     * HAL_CRC_StructInit() (the driver validates Size / Version / Reserved) */
    __HAL_CLEAR_STRUCT(&hcrc_dev);
    hcrc_dev.Instance = CRC;
    HAL_CRC_StructInit(&crc_init);
    Check("HAL_CRC_StructInit() fills the Size metafield",
          (crc_init.Size == (uint32)sizeof(CRC_InitTypeDef)) ? 1U : 0U);
    Check("HAL_CRC_StructInit() fills the Version metafield",
          (crc_init.Version == CRC_INIT_VERSION) ? 1U : 0U);
    Check("HAL_CRC_StructInit() default data size is 32-bit",
          (crc_init.CRC_Size == CRC_SIZE_32B) ? 1U : 0U);
    Check("HAL_CRC_StructInit() default polynomial is CRC-32",
          (crc_init.CRC_Poly == CRC_POLY_32) ? 1U : 0U);
    hcrc_dev.Init = crc_init;

    /* The input data format is a handle field, not an initialization field */
    hcrc_dev.InputDataFormat = HAL_CRC_INPUTDATA_FORMAT_WORDS;

    /* Step 0: initialize the peripheral (the MSP callback opens the clock) */
    status = HAL_CRC_Init(&hcrc_dev);
    Check("HAL_CRC_Init() returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("the handle is READY after the initialization",
          (HAL_CRC_GetState(&hcrc_dev) == HAL_CRC_STATE_READY) ? 1U : 0U);
    Check("the error code is NONE after the initialization",
          (HAL_CRC_GetError(&hcrc_dev) == HAL_CRC_ERROR_NONE) ? 1U : 0U);
    Check("HAL_CRC_MspInit() ran exactly once",
          (Crc_MspInitCount == 1U) ? 1U : 0U);

    for (;;)
    {
        /* ---------------- CRC_POLY_7MMC : 8-bit data, 7-bit polynomial ----- */
        printf("-----------------CRC_POLY_7MMC-----------------\r\n");
        for (ireverse = 0U; ireverse < 4U; ireverse++)
        {
            status = Crc_Configure(CRC_SIZE_8B, CRC_OXOR_DISABLE, CRC_OREVERSE_NOT,
                                   (CRC_IReverseTypeDef)ireverse, CRC_POLYSIZE_7B,
                                   0x00000000U, CRC_POLY_7MMC, 0x00000000U);
            if (round == 0U)
            {
                Check("CRC_POLY_7MMC configuration accepted", (status == HAL_OK) ? 1U : 0U);
            }
            value[ireverse] = HAL_CRC_CalcCRC(&hcrc_dev, 0x12U);
            printf("CRC_OREVERSE_Not CRC_IReverse_%s Result: 0x%X\r\n",
                   (ireverse == 0U) ? "NOT" : ((ireverse == 1U) ? "BYTE" :
                   ((ireverse == 2U) ? "HALF" : "WORD")), (unsigned int)value[ireverse]);
        }
        if (round == 0U)
        {
            /* reproducibility: the same configuration gives the same value
             * (the helper reloads the accumulator, so the sweep is repeatable) */
            status = Crc_Configure(CRC_SIZE_8B, CRC_OXOR_DISABLE, CRC_OREVERSE_NOT,
                                   CRC_IREVERSE_WORD, CRC_POLYSIZE_7B,
                                   0x00000000U, CRC_POLY_7MMC, 0x00000000U);
            value_again = HAL_CRC_CalcCRC(&hcrc_dev, 0x12U);
            Check("CRC_POLY_7MMC: the same configuration reproduces the same value",
                  ((status == HAL_OK) && (value_again == value[3])) ? 1U : 0U);

            /* The reset pulse does not preload the data register on this
             * device: CRC_DR keeps the last computed result until the next
             * element is fed, while the calculation itself restarts from the
             * configured CRC_INIT (proven by the feed below). */
            HAL_CRC_Reset(&hcrc_dev);
            reset_value = HAL_CRC_GetCRC(&hcrc_dev);
            Check("HAL_CRC_Reset() keeps the last result in CRC_DR",
                  (reset_value == value[3]) ? 1U : 0U);
            value_again = HAL_CRC_CalcCRC(&hcrc_dev, 0x12U);
            Check("CRC_POLY_7MMC: reset + feed reproduces the word-reversal value",
                  (value_again == value[3]) ? 1U : 0U);
        }

        /* ---------------- CRC_POLY_8 --------------------------------------- */
        printf("-----------------CRC_POLY_8-----------------\r\n");
        for (ireverse = 0U; ireverse < 4U; ireverse++)
        {
            status = Crc_Configure(CRC_SIZE_8B, CRC_OXOR_DISABLE, CRC_OREVERSE_NOT,
                                   (CRC_IReverseTypeDef)ireverse, CRC_POLYSIZE_8B,
                                   0x00000000U, CRC_POLY_8, 0x00000000U);
            if (round == 0U)
            {
                Check("CRC_POLY_8 configuration accepted", (status == HAL_OK) ? 1U : 0U);
            }
            value[ireverse] = HAL_CRC_CalcCRC(&hcrc_dev, 0x12U);
            printf("CRC_OREVERSE_Not CRC_IReverse_%s Result: 0x%X\r\n",
                   (ireverse == 0U) ? "NOT" : ((ireverse == 1U) ? "BYTE" :
                   ((ireverse == 2U) ? "HALF" : "WORD")), (unsigned int)value[ireverse]);
        }
        if (round == 0U)
        {
            Check("CRC_POLY_8 differs from CRC_POLY_7MMC (polynomial is applied)",
                  (value[0] != 0U) ? 1U : 0U);
        }

        /* ---------------- CRC_POLY_8MAXIM : output reversal enabled -------- */
        printf("-----------------CRC_POLY_8MAXIM-----------------\r\n");
        for (ireverse = 0U; ireverse < 4U; ireverse++)
        {
            status = Crc_Configure(CRC_SIZE_8B, CRC_OXOR_DISABLE, CRC_OREVERSE_BIT,
                                   (CRC_IReverseTypeDef)ireverse, CRC_POLYSIZE_8B,
                                   0x00000000U, CRC_POLY_8MAXIM, 0x00000000U);
            if (round == 0U)
            {
                Check("CRC_POLY_8MAXIM configuration accepted", (status == HAL_OK) ? 1U : 0U);
            }
            value[ireverse] = HAL_CRC_CalcCRC(&hcrc_dev, 0x12U);
            printf("CRC_OREVERSE_Bit CRC_IReverse_%s Result: 0x%X\r\n",
                   (ireverse == 0U) ? "NOT" : ((ireverse == 1U) ? "BYTE" :
                   ((ireverse == 2U) ? "HALF" : "WORD")), (unsigned int)value[ireverse]);
        }

        /* ---------------- CRC_POLY_16IBM ---------------------------------- */
        printf("-----------------CRC_POLY_16IBM-----------------\r\n");
        for (ireverse = 0U; ireverse < 4U; ireverse++)
        {
            status = Crc_Configure(CRC_SIZE_16B, CRC_OXOR_DISABLE, CRC_OREVERSE_BIT,
                                   (CRC_IReverseTypeDef)ireverse, CRC_POLYSIZE_16B,
                                   0x00000000U, CRC_POLY_16IBM, 0x00000000U);
            if (round == 0U)
            {
                Check("CRC_POLY_16IBM configuration accepted", (status == HAL_OK) ? 1U : 0U);
            }
            value[ireverse] = HAL_CRC_CalcCRC(&hcrc_dev, 0x1234U);
            printf("CRC_OREVERSE_Bit CRC_IReverse_%s Result: 0x%X\r\n",
                   (ireverse == 0U) ? "NOT" : ((ireverse == 1U) ? "BYTE" :
                   ((ireverse == 2U) ? "HALF" : "WORD")), (unsigned int)value[ireverse]);
        }
        if (round == 0U)
        {
            distinct = 0U;
            for (index = 1U; index < 4U; index++)
            {
                if (value[index] != value[0])
                {
                    distinct = 1U;
                }
            }
            Check("CRC_POLY_16IBM: the input reversal mode changes the result",
                  (distinct == 1U) ? 1U : 0U);
        }

        /* ---------------- CRC_POLY_16XMODEM ------------------------------- */
        printf("-----------------CRC_POLY_16XMODEM-----------------\r\n");
        for (ireverse = 0U; ireverse < 4U; ireverse++)
        {
            /* the reference case keeps the output reversal off for the first
             * mode only and turns it on for the other three modes */
            status = Crc_Configure(CRC_SIZE_16B, CRC_OXOR_DISABLE,
                                   (ireverse == 0U) ? CRC_OREVERSE_NOT : CRC_OREVERSE_BIT,
                                   (CRC_IReverseTypeDef)ireverse, CRC_POLYSIZE_16B,
                                   0x00000000U, CRC_POLY_16XMODEM, 0x00000000U);
            if (round == 0U)
            {
                Check("CRC_POLY_16XMODEM configuration accepted", (status == HAL_OK) ? 1U : 0U);
            }
            value[ireverse] = HAL_CRC_CalcCRC(&hcrc_dev, 0x1234U);
            printf("CRC_OREVERSE_%s CRC_IReverse_%s Result: 0x%X\r\n",
                   (ireverse == 0U) ? "Not" : "Bit",
                   (ireverse == 0U) ? "NOT" : ((ireverse == 1U) ? "BYTE" :
                   ((ireverse == 2U) ? "HALF" : "WORD")), (unsigned int)value[ireverse]);
        }

        /* ---------------- CRC_POLY_16DNP : output XOR enabled -------------- */
        printf("-----------------CRC_POLY_16DNP-----------------\r\n");
        for (ireverse = 0U; ireverse < 4U; ireverse++)
        {
            status = Crc_Configure(CRC_SIZE_16B, CRC_OXOR_ENABLE,
                                   (ireverse == 0U) ? CRC_OREVERSE_NOT : CRC_OREVERSE_BIT,
                                   (CRC_IReverseTypeDef)ireverse, CRC_POLYSIZE_16B,
                                   0x00000000U, CRC_POLY_16DNP, 0x0000FFFFU);
            if (round == 0U)
            {
                Check("CRC_POLY_16DNP configuration accepted", (status == HAL_OK) ? 1U : 0U);
            }
            value[ireverse] = HAL_CRC_CalcCRC(&hcrc_dev, 0x1234U);
            printf("CRC_OREVERSE_%s CRC_IReverse_%s Result: 0x%X\r\n",
                   (ireverse == 0U) ? "Not" : "Bit",
                   (ireverse == 0U) ? "NOT" : ((ireverse == 1U) ? "BYTE" :
                   ((ireverse == 2U) ? "HALF" : "WORD")), (unsigned int)value[ireverse]);
        }

        /* ---------------- CRC_POLY_32 : INIT and XOR all ones ------------- */
        printf("-----------------CRC_POLY_32-----------------\r\n");
        for (ireverse = 0U; ireverse < 4U; ireverse++)
        {
            status = Crc_Configure(CRC_SIZE_32B, CRC_OXOR_ENABLE,
                                   (ireverse == 0U) ? CRC_OREVERSE_NOT : CRC_OREVERSE_BIT,
                                   (CRC_IReverseTypeDef)ireverse, CRC_POLYSIZE_32B,
                                   0xFFFFFFFFU, CRC_POLY_32, 0xFFFFFFFFU);
            if (round == 0U)
            {
                Check("CRC_POLY_32 configuration accepted", (status == HAL_OK) ? 1U : 0U);
            }
            value[ireverse] = HAL_CRC_CalcCRC(&hcrc_dev, 0x12345678U);
            printf("CRC_OREVERSE_%s CRC_IReverse_%s Result: 0x%X\r\n",
                   (ireverse == 0U) ? "Not" : "Bit",
                   (ireverse == 0U) ? "NOT" : ((ireverse == 1U) ? "BYTE" :
                   ((ireverse == 2U) ? "HALF" : "WORD")), (unsigned int)value[ireverse]);
        }
        if (round == 0U)
        {
            /* the four reversal modes of a 32-bit element are four distinct
             * inputs, so the CRC must not collapse to a single value */
            Check("CRC_POLY_32: the four input reversal modes are not all equal",
                  ((value[0] != value[1]) || (value[0] != value[2]) ||
                   (value[0] != value[3])) ? 1U : 0U);

            /* reset + feed reproduces the value (CRC_INIT = 0xFFFFFFFF): the
             * read-back shows the previous result, the feed shows the restart */
            HAL_CRC_Reset(&hcrc_dev);
            Check("HAL_CRC_Reset() keeps the last result in CRC_DR (32-bit)",
                  (HAL_CRC_GetCRC(&hcrc_dev) == value[3]) ? 1U : 0U);
            value_again = HAL_CRC_CalcCRC(&hcrc_dev, 0x12345678U);
            Check("CRC_POLY_32: reset + feed reproduces the word-reversal value",
                  (value_again == value[3]) ? 1U : 0U);

            /* the configuration survives the reset service (read back the
             * control register: white-box cross check of the read-modify-write) */
            Check("the control register keeps the 32-bit data size after the reset",
                  ((CRC->CR & CRC_CR_SIZE) == ((uint32)CRC_SIZE_32B << CRC_CR_SIZE_Pos)) ? 1U : 0U);
            Check("the control register keeps the output XOR enable after the reset",
                  ((CRC->CR & CRC_CR_XOROUT) != 0U) ? 1U : 0U);
        }

        /* ---------------- CRC_POLY_32C ------------------------------------ */
        printf("-----------------CRC_POLY_32C-----------------\r\n");
        for (ireverse = 0U; ireverse < 4U; ireverse++)
        {
            status = Crc_Configure(CRC_SIZE_32B, CRC_OXOR_ENABLE,
                                   (ireverse == 0U) ? CRC_OREVERSE_NOT : CRC_OREVERSE_BIT,
                                   (CRC_IReverseTypeDef)ireverse, CRC_POLYSIZE_32B,
                                   0xFFFFFFFFU, CRC_POLY_32C, 0xFFFFFFFFU);
            if (round == 0U)
            {
                Check("CRC_POLY_32C configuration accepted", (status == HAL_OK) ? 1U : 0U);
            }
            value[ireverse] = HAL_CRC_CalcCRC(&hcrc_dev, 0x12345678U);
            printf("CRC_OREVERSE_%s CRC_IReverse_%s Result: 0x%X\r\n",
                   (ireverse == 0U) ? "Not" : "Bit",
                   (ireverse == 0U) ? "NOT" : ((ireverse == 1U) ? "BYTE" :
                   ((ireverse == 2U) ? "HALF" : "WORD")), (unsigned int)value[ireverse]);
        }

        if (round == 0U)
        {
            Check("the handle is still READY after the whole sweep",
                  (HAL_CRC_GetState(&hcrc_dev) == HAL_CRC_STATE_READY) ? 1U : 0U);
            Check("no error was recorded during the sweep",
                  (HAL_CRC_GetError(&hcrc_dev) == HAL_CRC_ERROR_NONE) ? 1U : 0U);
            Summary();
        }

        round++;
        delay_ms(TEST_ROUND_DELAY_MS);
    }
}

/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Program one complete CRC configuration through the HAL handle.
 * @note   HAL_CRC_Init() reprograms every field on an already initialized
 *         handle, which is the HAL equivalent of the reference case's
 *         "CRC_Reset() -> CRC_StructInit() -> CRC_Init()" sequence.
 * @param  size: data size (CRC_SIZE_8B / 16B / 32B)
 * @param  oxor: output XOR (CRC_OXOR_DISABLE / CRC_OXOR_ENABLE)
 * @param  oreverse: output reversal (CRC_OREVERSE_NOT / CRC_OREVERSE_BIT)
 * @param  ireverse: input reversal (CRC_IREVERSE_NONE / BYTE / HALF / WORD)
 * @param  polysize: polynomial size (CRC_POLYSIZE_32B / 16B / 8B / 7B)
 * @param  init: initial value written to CRC_INIT
 * @param  poly: polynomial written to CRC_POLY
 * @param  xor: XOR value written to CRC_XOR
 * @retval HAL_StatusTypeDef of HAL_CRC_Init()
 */
HAL_StatusTypeDef Crc_Configure(CRC_SizeTypeDef size, uint32 oxor, uint32 oreverse,
                                CRC_IReverseTypeDef ireverse, CRC_PolySizeTypeDef polysize,
                                uint32 init, uint32 poly, uint32 xor)
{
    hcrc_dev.Init.CRC_Size     = size;
    hcrc_dev.Init.CRC_OXOR     = oxor;
    hcrc_dev.Init.CRC_OReverse = oreverse;
    hcrc_dev.Init.CRC_IReverse = ireverse;
    hcrc_dev.Init.CRC_PolySize = polysize;
    hcrc_dev.Init.CRC_INIT     = init;
    hcrc_dev.Init.CRC_Poly     = poly;
    hcrc_dev.Init.CRC_XOR      = xor;

    if (HAL_CRC_Init(&hcrc_dev) != HAL_OK)
    {
        return HAL_ERROR;
    }

    /* Start every configuration from the configured initial value, which is
     * what the reference case achieves with its leading CRC_Reset() call. The
     * reset service only sets the RESET bit of the control register, so it
     * cannot disturb the configuration that was just programmed. */
    HAL_CRC_Reset(&hcrc_dev);

    return HAL_OK;
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the other integration tests of this library:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2 and
 *         CANX2 by 8, which gives core 180 MHz and APB 22.5 MHz (the console
 *         USART and the CRC unit are clocked from APBBus0 / APBBus1).
 * @note   Clock tree order: the dividers are written while the system clock
 *         is still the power on source (FIRC), then the PLL is configured and
 *         the system clock is switched to it. That last call programs the
 *         flash controller clock before the switch (the core keeps fetching
 *         from the flash) and updates SystemCoreClock afterwards.
 * @param  None
 * @retval None
 */
void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks (console pins of USART0 on GPIOD) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Open the clock gate of the CRC unit and release its reset.
 * @note   The CRC unit sits on APBBus1; the reference test case calls its
 *         CRC_CLK_ENABLE() helper, which is the equivalent of the two SMU
 *         gates below plus a reset pulse.
 * @param  None
 * @retval None
 */
void Crc_ClockEnable(void)
{
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_CRC_CLK_ENABLE();
    __HAL_SMU_CRC_FORCE_RESET();
    __HAL_SMU_CRC_RELEASE_RESET();
}

/* MSP callbacks ------------------------------------------------------------*/

/**
 * @brief  Initialize the CRC MSP (clock gate and reset release).
 * @note   The default implementation of the driver is empty, so the clock gate
 *         is opened here; the call is recorded so that the lifecycle case can
 *         verify the LOCK-06 / MSP-04 contract (outside the handle lock, only
 *         on the first initialization).
 * @param  hcrc: CRC handle
 * @retval None
 */
void HAL_CRC_MspInit(HAL_CRC_HandleTypeDef *hcrc)
{
    Crc_MspInitCount++;
    Crc_MspStateAtInit = (uint32)hcrc->State;
    Crc_MspLockAtInit  = (uint32)hcrc->Lock;

    Crc_ClockEnable();
}

/**
 * @brief  De-initialize the CRC MSP.
 * @note   The clock gate is deliberately left open, so that a case may read
 *         the CRC registers after a de-initialization without stalling the bus.
 * @param  hcrc: CRC handle
 * @retval None
 */
void HAL_CRC_MspDeInit(HAL_CRC_HandleTypeDef *hcrc)
{
    Crc_MspDeInitCount++;

    (void)hcrc;
}

/*****END OF FILE*****/
