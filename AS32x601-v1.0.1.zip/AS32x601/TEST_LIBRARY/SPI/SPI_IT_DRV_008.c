/**
 * @file    SPI_IT_DRV_008.c
 * @brief   HAL SPI integration test case 008 (transmit FIFO full flag).
 *
 * HAL library port of the original AS32x601 standard-library test case
 * SPI_IT_DRV_008.c, which drives SPI3 in master mode and checks the transmit
 * buffer full flag (SR.TXF) before and while filling the transmit FIFO. Only
 * HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_SPI_StructInit()
 *   HAL_SPI_Init()
 *   HAL_SPI_ResetFIFO()
 *   HAL_SPI_NSSConfig()         (asserts SPI_Slave0 around every transfer)
 *   HAL_SPI_Cmd()
 *   HAL_SPI_GetFlagStatus()     (SPI_Flag_TXF, SPI_Flag_RXE)
 *   HAL_SPI_SendData()
 *   HAL_SPI_ReceiveData()
 *   HAL_SPI_GetState() / HAL_SPI_GetError()
 *   HAL_SPI_MspInit()           (overridden: clock gate, reset pulse, pins)
 *
 * Test procedure:
 *   1. initialize SPI3 in master mode (8 bit, Motorola mode 0, back-to-back
 *      transmission, divider /512) and reset both FIFOs;
 *   2. check that SR.TXF (transmit buffer full) is clear on an empty FIFO;
 *   3. write frames back to back until SR.TXF reports the FIFO as full; the
 *      received frames are drained on the fly so that the receive overflow does
 *      not disturb the measurement;
 *   4. report the number of frames that fit into the FIFO and check that the
 *      flag is set at the end.
 *
 * Expected behaviour:
 *   - SR.TXF is clear at the start;
 *   - SR.TXF becomes set after a finite number of back-to-back writes (the
 *     depth of the transmit FIFO);
 *   - the count equals 32 frames, which is the depth of the transmit FIFO of
 *     the controller (the data FIFOs are 32 words deep);
 *   - every check prints [PASS] and "summary : failures = 0".
 *
 * Note:
 *   - The reference test case looped "while TXF is set" (i.e. it stopped as
 *     soon as the buffer was full) and then printed that the buffer was full,
 *     which contradicts the loop condition. The case here states the intent
 *     explicitly: fill the FIFO, then assert the flag.
 *   - The original also initialised the PLIC for the SPI line while it enabled
 *     no interrupt at all; that leftover is removed.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console: USART0 on GPIOD pin 8 (TX) / pin 9 (RX), 115200 8N1 */
#define TEST_BAUDRATE                   (115200U)

/* Device under test: SPI3 (as in the reference test case)
 *   CS0  = PC10   SCK  = PD3   MOSI = PD1   MISO = PD2
 */
#define TEST_SPI                        SPI3
#define TEST_CS_PORT                    GPIOC
#define TEST_CS_PIN                     GPIO_PIN_10
#define TEST_CS_SOURCE                  GPIO_PinSource10
#define TEST_SCK_PORT                   GPIOD
#define TEST_SCK_PIN                    GPIO_PIN_3
#define TEST_SCK_SOURCE                 GPIO_PinSource3
#define TEST_MOSI_PORT                  GPIOD
#define TEST_MOSI_PIN                   GPIO_PIN_1
#define TEST_MOSI_SOURCE                GPIO_PinSource1
#define TEST_MISO_PORT                  GPIOD
#define TEST_MISO_PIN                   GPIO_PIN_2
#define TEST_MISO_SOURCE                GPIO_PinSource2
#define TEST_PIN_AF                     GPIO_AF_SPI3

/* Measurement bounds */
#define TXF_WRITE_LIMIT                 (64U)   /*!< safety bound of the fill loop */
#define FIFO_DEPTH_DOC                  (32U)   /*!< documented FIFO depth         */
#define TX_PATTERN                      (0xAAU)
#define ROUNDS                          (3U)
#define RETRY_PERIOD_MS                 (1000U)

/* Private variables ---------------------------------------------------------*/
static SPI_HandleTypeDef hspi_dev;              /*!< device under test      */
static HAL_SMU_HandleTypeDef hsmu_clk;          /*!< SMU handle (clock tree) */
static volatile uint32 check_failures = 0U;     /*!< failed check counter    */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void Check(const char *name, uint32 condition);
static void Summary(void);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    SPI_InitTypeDef spi_init;
    HAL_StatusTypeDef status;
    uint32 round;
    uint32 writes;
    uint32 initial_txf;
    uint32 final_txf;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock tree */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART (USART0 on GPIOD pin 8 / pin 9) */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== SPI_IT_DRV_008 : transmit FIFO full flag (SPI3) ===\r\n");

    /* Step 1: initialize the device under test */
    __HAL_CLEAR_STRUCT(&hspi_dev);
    HAL_SPI_StructInit(&spi_init);
    spi_init.SPI_CLKDiv       = SPI_CLKDiv512;
    spi_init.SPI_Mode         = SPI_Mode_Master;
    spi_init.SPI_FrameSize    = SPI_FrameSize_8b;
    spi_init.SPI_MotorolaMode = SPI_Motorola_Mode0;
    spi_init.SPI_TransMode    = SPI_TransBToB;

    hspi_dev.Instance = TEST_SPI;
    hspi_dev.Init     = spi_init;

    status = HAL_SPI_Init(&hspi_dev);
    /* The slave select is not part of the initialization: SSR
     * resets to 0 (no slave selected) and HAL_SPI_Init() does not
     * touch it, so the selection has to be programmed here. */
    HAL_SPI_ResetFIFO(&hspi_dev, SPI_RESETFIFO_TXANDRX);
    HAL_SPI_NSSConfig(&hspi_dev, SPI_Slave0, SPI_ENABLE);
    Check("HAL_SPI_Init returns HAL_OK", (uint32)((status == HAL_OK) ? 1U : 0U));
    Check("state after init is READY",
          (uint32)((HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_READY) ? 1U : 0U));

    for (round = 1U; round <= ROUNDS; round++)
    {
        printf("\r\n-- round %u --\r\n", PRINT_U32(round));

        /* Start every round from an empty FIFO pair */
        HAL_SPI_ResetFIFO(&hspi_dev, SPI_RESETFIFO_TXANDRX);
        HAL_SPI_Cmd(&hspi_dev, SPI_ENABLE);

        /* Step 2: an empty transmit FIFO must not report "full" */
        initial_txf = HAL_SPI_GetFlagStatus(&hspi_dev, SPI_Flag_TXF);
        printf("SR           : 0x%08X (TXF %u, RXE %u)\r\n",
               PRINT_U32((uint32)TEST_SPI->SR),
               PRINT_U32(initial_txf),
               PRINT_U32(HAL_SPI_GetFlagStatus(&hspi_dev, SPI_Flag_RXE)));
        Check("SR.TXF is clear on an empty transmit FIFO",
              (uint32)((initial_txf == 0U) ? 1U : 0U));
        Check("SR.RXE is set on an empty receive FIFO",
              (uint32)((HAL_SPI_GetFlagStatus(&hspi_dev, SPI_Flag_RXE) != 0U) ? 1U : 0U));

        /* Step 3: fill the transmit FIFO, draining the received frames on the
         * way so that a receive overflow cannot disturb the measurement */
        writes = 0U;
        while (writes < TXF_WRITE_LIMIT)
        {
            if (HAL_SPI_GetFlagStatus(&hspi_dev, SPI_Flag_TXF) != 0U)
            {
                break;
            }

            HAL_SPI_SendData(&hspi_dev, TX_PATTERN);
            writes++;

            if (HAL_SPI_GetFlagStatus(&hspi_dev, SPI_Flag_RXE) == 0U)
            {
                (void)HAL_SPI_ReceiveData(&hspi_dev);
            }
        }

        final_txf = HAL_SPI_GetFlagStatus(&hspi_dev, SPI_Flag_TXF);
        printf("frames written into the FIFO : %u\r\n", PRINT_U32(writes));
        printf("TXF at the end               : %u\r\n", PRINT_U32(final_txf));
        printf("SR at the end                : 0x%08X\r\n",
               PRINT_U32((uint32)TEST_SPI->SR));

        /* Step 4: the FIFO must be full now */
        Check("SR.TXF is set after filling the transmit FIFO",
              (uint32)((final_txf != 0U) ? 1U : 0U));
        Check("the FIFO accepted at least one frame",
              (uint32)((writes >= 1U) ? 1U : 0U));
        /* /512 keeps one frame on the wire for ~114 us against a few us to
         * queue the whole FIFO, so nothing drains during the fill loop and the
         * count is exactly the FIFO depth. */
        Check("the FIFO depth is 32 frames",
              (uint32)((writes == FIFO_DEPTH_DOC) ? 1U : 0U));

        /* Leave the peripheral in a clean state: both FIFOs empty */
        HAL_SPI_ResetFIFO(&hspi_dev, SPI_RESETFIFO_TXANDRX);
        Check("SR.TXF is cleared again after the FIFO reset",
              (uint32)((HAL_SPI_GetFlagStatus(&hspi_dev, SPI_Flag_TXF) == 0U) ? 1U : 0U));

        delay_ms(RETRY_PERIOD_MS);
    }

    /* Release the slave select, so the lines are not left asserted */
    HAL_SPI_NSSConfig(&hspi_dev, SPI_Slave0, SPI_DISABLE);

    Summary();

    while (1)
    {
        delay_ms(1000U);
    }
}

/**
 * @brief  Report the result of one check.
 * @param  name: short description of the check.
 * @param  condition: 0 = FAIL, non zero = PASS.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("%-50s : [PASS]\r\n", name);
    }
    else
    {
        check_failures++;
        printf("%-50s : [FAIL]\r\n", name);
    }
}

/**
 * @brief  Print the accumulated failure counter.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(check_failures));
}

/**
 * @brief  MSP initialization of the device under test.
 * @note   Strong override of the weak driver callback.
 * @param  hspi: SPI handle of the device under test.
 * @retval None
 */
void HAL_SPI_MspInit(SPI_HandleTypeDef *hspi)
{
    GPIO_InitTypeDef gpio;

    if (hspi->Instance != TEST_SPI)
    {
        return;
    }

    /* Peripheral clock gate and reset pulse */
    __HAL_SMU_SPI3_CLK_ENABLE();
    __HAL_SMU_SPI3_FORCE_RESET();
    __HAL_SMU_SPI3_RELEASE_RESET();

    /* Port clock gates used by this case */
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&gpio);
    gpio.Size         = sizeof(gpio);
    gpio.Version      = GPIO_INIT_VERSION;
    gpio.Pull         = GPIO_NOPULL;
    gpio.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    gpio.Alternate    = TEST_PIN_AF;

    /* CS0 (driven by the SSR register) */
    HAL_GPIO_PinAFConfig(TEST_CS_PORT, TEST_CS_SOURCE, TEST_PIN_AF);
    gpio.Pin  = TEST_CS_PIN;
    gpio.Mode = GPIO_MODE_AF_PP;
    HAL_GPIO_Init(TEST_CS_PORT, &gpio);

    /* SCK */
    HAL_GPIO_PinAFConfig(TEST_SCK_PORT, TEST_SCK_SOURCE, TEST_PIN_AF);
    gpio.Pin = TEST_SCK_PIN;
    HAL_GPIO_Init(TEST_SCK_PORT, &gpio);

    /* MOSI */
    HAL_GPIO_PinAFConfig(TEST_MOSI_PORT, TEST_MOSI_SOURCE, TEST_PIN_AF);
    gpio.Pin = TEST_MOSI_PIN;
    HAL_GPIO_Init(TEST_MOSI_PORT, &gpio);

    /* MISO: alternate function input, floating */
    HAL_GPIO_PinAFConfig(TEST_MISO_PORT, TEST_MISO_SOURCE, TEST_PIN_AF);
    gpio.Pin  = TEST_MISO_PIN;
    gpio.Mode = GPIO_MODE_INPUT;
    HAL_GPIO_Init(TEST_MISO_PORT, &gpio);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the CLINT / CMU / MPU / USART integration tests.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef    SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the same set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls (PMU_CheckState) */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
