/**
 * @file    WWDG_IT_DRV_010.c
 * @brief   HAL WWDG integration test case 010 (API contract self check).
 *
 * Extension case of this suite: it walks the whole public surface of the HAL
 * WWDG driver without arming a channel for its whole timeout, so it can be run
 * on any board and repeated as often as needed.
 *
 * Tested functionality:
 *   HAL_WWDG_Init() / HAL_WWDG_MspInit()      (metafields, run time checks,
 *                                              default clock / reset release)
 *   HAL_WWDG_Refresh() / HAL_WWDG_GetCounter() / HAL_WWDG_GetBKStatus()
 *   HAL_WWDG_Cmd() / HAL_WWDG_LockCmd()       (selectors, write protection)
 *   HAL_WWDG_GetState() / HAL_WWDG_GetError()
 *   __HAL_WWDG_* macros and IS_WWDG_* checks
 *   WWDG_HandleIsValid() / WWDG_CheckState() / WWDG_LockHandle() /
 *   WWDG_UnlockHandle()                        (shared internal helpers)
 *
 * Test procedure:
 *   1. structure contract: the metafields (Size / Version / Reserved) and the
 *      run time range checks of HAL_WWDG_Init() reject an invalid
 *      configuration with HAL_ERROR + HAL_WWDG_ERROR_INVALID_PARAM, without
 *      touching a register and without leaving the reset state;
 *   2. a valid configuration is accepted and reads back as written, and the
 *      default MSP callback has enabled the instance clock and released its
 *      reset;
 *   3. empty handle and not initialized handle: every entry point answers the
 *      documented value (HAL_ERROR / RESET / 0 / NONE) and writes nothing;
 *   4. selector validation of HAL_WWDG_Cmd() and HAL_WWDG_LockCmd();
 *   5. hardware write protection: a locked prescaler block makes
 *      HAL_WWDG_Init() fail, a locked configuration block makes
 *      HAL_WWDG_Cmd(WWDG_EN_CFG) fail, and both accept their other block;
 *   6. macro and helper contract: the exported macros, the IS_WWDG_* range
 *      checks and the four shared internal helpers.
 *
 * Expected behaviour:
 *   every documented refusal is reported (no silent success), the registers
 *   are never touched by a refused call and every check prints [PASS] with
 *   "summary : failures = 0".
 *
 * Note:
 *   The configuration of this case is deliberately slow (prescaler 255,
 *   divider 1000, timeout value 65535, about 11.4 s) so that the channel can
 *   be started by the __HAL_WWDG_START() macro check without any risk of a
 *   bark before the macro is exercised and the channel is disabled again.
 */

/* Includes ------------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
#define TEST_BAUDRATE                 (115200U)
#define TEST_PD4_PORT                 GPIOD       /*!< marker pin port (PD4)    */
#define TEST_PD4_PIN                  GPIO_PIN_4  /*!< marker pin of the case   */
#define TEST_PD4_ON                   GPIO_PIN_SET
#define TEST_PD4_OFF                  GPIO_PIN_RESET
#define TEST_SLOW_PRESCALER           (255U)      /*!< no bark during the case  */
#define TEST_SLOW_DIVIDER             (1000U)
#define TEST_SLOW_COUNTER             (65535U)

/* Private variables ---------------------------------------------------------*/
static volatile uint32        check_failures = 0U;
static HAL_SMU_HandleTypeDef  hsmu_clk;
static HAL_PMU_HandleTypeDef  hpmu_dev;

WWDG_HandleTypeDef     hwwdg_dev;
HAL_FCU_HandleTypeDef  hfcu_dev;

volatile uint32 test_bark_count   = 0U;
volatile uint32 test_bark_mask    = 0U;
volatile uint32 test_bark_counter = 0U;
volatile uint32 test_bark_mcycle  = 0U;

void Check(const char *name, uint32 condition);
void Summary(void);
void SystemClock_Init(void);
void Test_Pd4Init(void);
void Test_Pd4Set(GPIO_PinState state);
uint32 Test_McycleNow(void);
uint32 Test_McycleToUs(uint32 cycles);
void Test_BarkReset(void);
HAL_StatusTypeDef Test_WaitBark(uint32 timeout_ms);
HAL_StatusTypeDef Test_WwdgApply(uint32 prescaler, uint32 divider, uint32 counter,
                                 uint32 window, WWDG_Channel_TypeDef *instance);
void Test_FcuConfig(HAL_FCU_ChannelTypeDef channel,
                    HAL_FCU_FaultActionTypeDef fault_action,
                    HAL_FCU_AlarmActionTypeDef alarm_action,
                    HAL_FCU_FaultLevelTypeDef level);
void Test_PlicEnable(uint32 priority);

/* Register snapshot of the channel under test (the counter is left out: it
 * runs as soon as the channel is started) */
static uint32 snapshot[5];

/**
 * @brief  Capture the configuration registers of the channel under test.
 * @param  None
 * @retval None
 */
static void SnapTake(void)
{
    snapshot[0] = READ_REG(WWDG0->PSC);
    snapshot[1] = READ_REG(WWDG0_Channel0->CFG);
    snapshot[2] = READ_REG(WWDG0_Channel0->DIV);
    snapshot[3] = READ_REG(WWDG0_Channel0->TO);
    snapshot[4] = READ_REG(WWDG0_Channel0->WD);
}

/**
 * @brief  Compare the configuration registers with the last snapshot.
 * @param  None
 * @retval 1 when nothing changed, 0 otherwise
 */
static uint32 SnapSame(void)
{
    if (snapshot[0] != READ_REG(WWDG0->PSC))            { return 0U; }
    if (snapshot[1] != READ_REG(WWDG0_Channel0->CFG))   { return 0U; }
    if (snapshot[2] != READ_REG(WWDG0_Channel0->DIV))   { return 0U; }
    if (snapshot[3] != READ_REG(WWDG0_Channel0->TO))    { return 0U; }
    if (snapshot[4] != READ_REG(WWDG0_Channel0->WD))    { return 0U; }
    return 1U;
}

/**
 * @brief  Program the slow configuration used by this case.
 * @param  None
 * @retval HAL_StatusTypeDef of HAL_WWDG_Init()
 */
static HAL_StatusTypeDef ApplySlow(void)
{
    return Test_WwdgApply(TEST_SLOW_PRESCALER, TEST_SLOW_DIVIDER,
                          TEST_SLOW_COUNTER, 0U, WWDG0_Channel0);
}

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    HAL_StatusTypeDef status;
    WWDG_HandleTypeDef reset_handle;
    uint32 rounds = 0U;

    HAL_Init();
    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);

    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== WWDG_IT_DRV_010 : API contract self check ===\r\n");

    Test_Pd4Init();
    Test_Pd4Set(TEST_PD4_ON);

    /* The bark source is configured but the case never reaches the timeout;
     * the FCU keeps the configuration of the other cases in the same tree */
    Test_FcuConfig(HAL_FCU_CHANNEL_WWDG0, HAL_FCU_FAULT_INTERRUPT,
                   HAL_FCU_ALARM_INTERRUPT, HAL_FCU_FAULT_LEVEL_ALARM);
    Test_PlicEnable(1U);

    for (;;)
    {
        printf("-- round %u --\r\n", PRINT_U32(rounds));

        /* ------------------------------------------------------------------
         * Group 1: structure contract and run time validation
         * ------------------------------------------------------------------ */
        printf("section A : structure contract\r\n");

        __HAL_CLEAR_STRUCT(&hwwdg_dev);
        hwwdg_dev.Instance = WWDG0_Channel0;

        SnapTake();

        status = ApplySlow();
        Check("Init : a valid configuration is accepted", (status == HAL_OK) ? 1U : 0U);
        Check("Init : the handle is READY after a valid configuration",
              (HAL_WWDG_GetState(&hwwdg_dev) == HAL_WWDG_STATE_READY) ? 1U : 0U);
        Check("Init : the error code is NONE after a valid configuration",
              (HAL_WWDG_GetError(&hwwdg_dev) == HAL_WWDG_ERROR_NONE) ? 1U : 0U);
        Check("Init : the default MSP released the WWDG0 clock and its reset",
              (((READ_REG(SMU->APB0CFGR) & SMU_APB0CFGR_WWDG0EN) != 0U) &&
               ((READ_REG(SMU->APB0CFGR) & SMU_APB0CFGR_WWDG0RST) != 0U)) ? 1U : 0U);
        Check("Init : PSC.PSCNUM reads back as written",
              (((READ_REG(WWDG0->PSC) & WWDG_PSC_PSCNUM) >> WWDG_PSC_PSCNUM_Pos) ==
               TEST_SLOW_PRESCALER) ? 1U : 0U);
        Check("Init : DIV.DIVNUM reads back as written",
              ((READ_REG(WWDG0_Channel0->DIV) & WWDG_DIV_DIVNUM) == TEST_SLOW_DIVIDER) ? 1U : 0U);
        Check("Init : TO.BVAL reads back as written",
              ((READ_REG(WWDG0_Channel0->TO) & WWDG_TO_BVAL) == TEST_SLOW_COUNTER) ? 1U : 0U);
        Check("Init : WD.WDCNT reads back as written (window disabled)",
              ((READ_REG(WWDG0_Channel0->WD) & WWDG_WD_WDCNT) == 0U) ? 1U : 0U);
        Check("Init : PSC.EN and WD.WDEN are set by the initialization",
              (((READ_REG(WWDG0->PSC) & WWDG_PSC_EN) != 0U) &&
               ((READ_REG(WWDG0_Channel0->WD) & WWDG_WD_WDEN) != 0U)) ? 1U : 0U);

        /* Hand made configurations: a local handle keeps the live one intact */
        __HAL_CLEAR_STRUCT(&reset_handle);
        reset_handle.Instance = WWDG0_Channel0;

        SnapTake();

        reset_handle.Init.Size       = (uint32)sizeof(WWDG_InitTypeDef);
        reset_handle.Init.Version    = WWDG_INIT_VERSION;
        reset_handle.Init.Prescaler  = 10U;
        reset_handle.Init.Divider    = 10U;
        reset_handle.Init.Counter    = 1000U;
        reset_handle.Init.Window     = 0U;
        reset_handle.Init.Reserved[0] = 0U;
        reset_handle.Init.Reserved[1] = 0U;

        reset_handle.Init.Size = 0U;
        status = HAL_WWDG_Init(&reset_handle);
        Check("Init : a wrong Size metafield is refused",
              ((status == HAL_ERROR) &&
               ((reset_handle.ErrorCode & HAL_WWDG_ERROR_INVALID_PARAM) != 0U)) ? 1U : 0U);
        reset_handle.Init.Size = (uint32)sizeof(WWDG_InitTypeDef);

        reset_handle.Init.Version = 0U;
        status = HAL_WWDG_Init(&reset_handle);
        Check("Init : a wrong Version metafield is refused", (status == HAL_ERROR) ? 1U : 0U);
        reset_handle.Init.Version = WWDG_INIT_VERSION;

        reset_handle.Init.Reserved[0] = 1U;
        status = HAL_WWDG_Init(&reset_handle);
        Check("Init : a non zero Reserved word is refused", (status == HAL_ERROR) ? 1U : 0U);
        reset_handle.Init.Reserved[0] = 0U;

        reset_handle.Init.Prescaler = 0x100U;
        status = HAL_WWDG_Init(&reset_handle);
        Check("Init : a prescaler above the field width is refused",
              (status == HAL_ERROR) ? 1U : 0U);
        reset_handle.Init.Prescaler = 10U;

        reset_handle.Init.Divider = 1U;
        status = HAL_WWDG_Init(&reset_handle);
        Check("Init : a divider below 2 is refused", (status == HAL_ERROR) ? 1U : 0U);
        reset_handle.Init.Divider = 10U;

        reset_handle.Init.Counter = 0U;
        status = HAL_WWDG_Init(&reset_handle);
        Check("Init : a timeout value of 0 is refused", (status == HAL_ERROR) ? 1U : 0U);
        reset_handle.Init.Counter = 1000U;

        reset_handle.Init.Window = 1000U;
        status = HAL_WWDG_Init(&reset_handle);
        Check("Init : a window value equal to the timeout value is refused",
              (status == HAL_ERROR) ? 1U : 0U);

        Check("Init : the refused calls did not touch a register", SnapSame());
        Check("Init : the refused calls left the handle in the reset state",
              (HAL_WWDG_GetState(&reset_handle) == HAL_WWDG_STATE_RESET) ? 1U : 0U);

        reset_handle.Init.Window = 999U;
        status = HAL_WWDG_Init(&reset_handle);
        Check("Init : a window value just below the timeout value is accepted",
              (status == HAL_OK) ? 1U : 0U);
        (void)HAL_WWDG_Cmd(&reset_handle, WWDG_EN_CFG, DISABLE);

        __HAL_WWDG_RESET_HANDLE_STATE(&reset_handle);
        Check("Macro : __HAL_WWDG_RESET_HANDLE_STATE() clears the state",
              (reset_handle.State == HAL_WWDG_STATE_RESET) ? 1U : 0U);

        /* ------------------------------------------------------------------
         * Group 2: empty handle and not initialized handle
         * ------------------------------------------------------------------ */
        printf("section B : empty and not initialized handles\r\n");

        SnapTake();

        Check("NULL : HAL_WWDG_Init() answers HAL_ERROR",
              (HAL_WWDG_Init(NULL_PTR) == HAL_ERROR) ? 1U : 0U);
        Check("NULL : HAL_WWDG_Refresh() answers HAL_ERROR",
              (HAL_WWDG_Refresh(NULL_PTR) == HAL_ERROR) ? 1U : 0U);
        Check("NULL : HAL_WWDG_GetCounter() answers 0",
              (HAL_WWDG_GetCounter(NULL_PTR) == 0U) ? 1U : 0U);
        Check("NULL : HAL_WWDG_GetBKStatus() answers RESET",
              (HAL_WWDG_GetBKStatus(NULL_PTR, WWDG_FLAG_BK0) == RESET) ? 1U : 0U);
        Check("NULL : HAL_WWDG_GetState() answers RESET",
              (HAL_WWDG_GetState(NULL_PTR) == HAL_WWDG_STATE_RESET) ? 1U : 0U);
        Check("NULL : HAL_WWDG_GetError() answers NONE",
              (HAL_WWDG_GetError(NULL_PTR) == HAL_WWDG_ERROR_NONE) ? 1U : 0U);
        Check("NULL : HAL_WWDG_Cmd() answers HAL_ERROR",
              (HAL_WWDG_Cmd(NULL_PTR, WWDG_EN_CFG, ENABLE) == HAL_ERROR) ? 1U : 0U);
        Check("NULL : HAL_WWDG_LockCmd() answers HAL_ERROR",
              (HAL_WWDG_LockCmd(NULL_PTR, WWDG_LOCK_CFG, ENABLE) == HAL_ERROR) ? 1U : 0U);

        Check("NULL : the calls did not touch a register", SnapSame());

        __HAL_CLEAR_STRUCT(&reset_handle);
        reset_handle.Instance = WWDG0_Channel0;

        SnapTake();

        Check("RESET : HAL_WWDG_Refresh() answers HAL_ERROR",
              (HAL_WWDG_Refresh(&reset_handle) == HAL_ERROR) ? 1U : 0U);
        Check("RESET : HAL_WWDG_Cmd() answers HAL_ERROR",
              (HAL_WWDG_Cmd(&reset_handle, WWDG_EN_CFG, ENABLE) == HAL_ERROR) ? 1U : 0U);
        Check("RESET : HAL_WWDG_LockCmd() answers HAL_ERROR",
              (HAL_WWDG_LockCmd(&reset_handle, WWDG_LOCK_CFG, ENABLE) == HAL_ERROR) ? 1U : 0U);
        Check("RESET : the calls did not touch a register", SnapSame());
        Check("RESET : the handle state is unchanged",
              (HAL_WWDG_GetState(&reset_handle) == HAL_WWDG_STATE_RESET) ? 1U : 0U);

        /* ------------------------------------------------------------------
         * Group 3: selector validation and write protection
         * ------------------------------------------------------------------ */
        printf("section C : selectors and write protection\r\n");

        status = HAL_WWDG_Cmd(&hwwdg_dev, 0x12345678U, ENABLE);
        Check("Cmd : an unknown selector is refused",
              ((status == HAL_ERROR) &&
               ((HAL_WWDG_GetError(&hwwdg_dev) & HAL_WWDG_ERROR_INVALID_PARAM) != 0U)) ? 1U : 0U);

        status = HAL_WWDG_LockCmd(&hwwdg_dev, 0x12345678U, ENABLE);
        Check("LockCmd : an unknown selector is refused",
              ((status == HAL_ERROR) &&
               ((HAL_WWDG_GetError(&hwwdg_dev) & HAL_WWDG_ERROR_INVALID_PARAM) != 0U)) ? 1U : 0U);

        /* Hardware limitation found on the board (2026-11-12): PSC.LOCK
         * (bit1) and CFG.LOCK (bit1) are reserved on this device. A write
         * of 1 does not stick -- the bit reads back 0 and the prescaler
         * keeps being writable -- so the watchdog has no write protection
         * in hardware. The driver reads the bit back after the write, which
         * means a lock request is answered with HAL_ERROR +
         * INVALID_PARAM instead of a success the hardware did not apply.
         * That is exactly what the reference implementation cannot report
         * (it calls the request done) and what this case now pins down. */
        status = HAL_WWDG_LockCmd(&hwwdg_dev, WWDG_LOCK_PSC, ENABLE);
        Check("LockCmd : PSC.LOCK is reserved, the driver reports HAL_ERROR",
              ((status == HAL_ERROR) &&
               ((READ_REG(WWDG0->PSC) & WWDG_PSC_LOCK) == 0U)) ? 1U : 0U);
        Check("LockCmd : the reserved lock bit is flagged as invalid",
              ((HAL_WWDG_GetError(&hwwdg_dev) & HAL_WWDG_ERROR_INVALID_PARAM) != 0U) ? 1U : 0U);

        SnapTake();
        status = ApplySlow();
        Check("Init : the configuration is accepted (no hardware lock)",
              (status == HAL_OK) ? 1U : 0U);
        Check("Init : the prescaler is written although LOCK was requested",
              (((READ_REG(WWDG0->PSC) & WWDG_PSC_PSCNUM) >> WWDG_PSC_PSCNUM_Pos) ==
               TEST_SLOW_PRESCALER) ? 1U : 0U);

        status = HAL_WWDG_LockCmd(&hwwdg_dev, WWDG_LOCK_PSC, DISABLE);
        Check("LockCmd : clearing a reserved lock bit is accepted",
              ((status == HAL_OK) &&
               ((READ_REG(WWDG0->PSC) & WWDG_PSC_LOCK) == 0U)) ? 1U : 0U);

        status = HAL_WWDG_LockCmd(&hwwdg_dev, WWDG_LOCK_CFG, ENABLE);
        Check("LockCmd : CFG.LOCK is reserved, the driver reports HAL_ERROR",
              ((status == HAL_ERROR) &&
               ((READ_REG(WWDG0_Channel0->CFG) & WWDG_CFG_LOCK) == 0U)) ? 1U : 0U);

        status = HAL_WWDG_Cmd(&hwwdg_dev, WWDG_EN_CFG, DISABLE);
        Check("Cmd : the configuration block still accepts a request",
              (status == HAL_OK) ? 1U : 0U);
        status = HAL_WWDG_Cmd(&hwwdg_dev, WWDG_EN_CFG, ENABLE);
        Check("Cmd : the enable request is not blocked by a lock bit",
              (status == HAL_OK) ? 1U : 0U);

        status = HAL_WWDG_Cmd(&hwwdg_dev, WWDG_EN_PSC, DISABLE);
        Check("Cmd : the prescaler block accepts a request",
              (status == HAL_OK) ? 1U : 0U);
        (void)HAL_WWDG_Cmd(&hwwdg_dev, WWDG_EN_PSC, ENABLE);

        status = HAL_WWDG_LockCmd(&hwwdg_dev, WWDG_LOCK_CFG, DISABLE);
        Check("LockCmd : clearing the configuration lock bit is accepted",
              ((status == HAL_OK) &&
               ((READ_REG(WWDG0_Channel0->CFG) & WWDG_CFG_LOCK) == 0U)) ? 1U : 0U);

        /* ------------------------------------------------------------------
         * Group 4: read paths, macros and helpers
         * ------------------------------------------------------------------ */
        printf("section D : read paths, macros and helpers\r\n");

        Check("Read : HAL_WWDG_GetBKStatus() refuses an unknown flag",
              (HAL_WWDG_GetBKStatus(&hwwdg_dev, 0x10U) == RESET) ? 1U : 0U);
        Check("Read : HAL_WWDG_GetState() reports the live handle",
              (HAL_WWDG_GetState(&hwwdg_dev) == HAL_WWDG_STATE_READY) ? 1U : 0U);

        status = HAL_WWDG_Refresh(&hwwdg_dev);
        Check("Refresh : the call returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
        Check("Refresh : the handle stays READY", (HAL_WWDG_GetState(&hwwdg_dev) ==
                                                   HAL_WWDG_STATE_READY) ? 1U : 0U);

        Check("Macro : __HAL_WWDG_MODULE_VERSION is 0x0100",
              (__HAL_WWDG_MODULE_VERSION == 0x0100U) ? 1U : 0U);
        Check("Macro : __HAL_WWDG_GET_COUNTER() reads the channel counter",
              ((__HAL_WWDG_GET_COUNTER(&hwwdg_dev)) ==
               HAL_WWDG_GetCounter(&hwwdg_dev)) ? 1U : 0U);

        __HAL_WWDG_RELOAD_COUNTER(&hwwdg_dev);
        Check("Macro : __HAL_WWDG_RELOAD_COUNTER() reloads the counter",
              (HAL_WWDG_GetCounter(&hwwdg_dev) == 0U) ? 1U : 0U);

        __HAL_WWDG_START(&hwwdg_dev);
        Check("Macro : __HAL_WWDG_START() sets CFG.EN",
              ((READ_REG(WWDG0_Channel0->CFG) & WWDG_CFG_EN) != 0U) ? 1U : 0U);
        (void)HAL_WWDG_Cmd(&hwwdg_dev, WWDG_EN_CFG, DISABLE);
        Check("Cmd : the configuration block can be disabled again",
              ((READ_REG(WWDG0_Channel0->CFG) & WWDG_CFG_EN) == 0U) ? 1U : 0U);

        Check("Macro : __HAL_WWDG_GET_FLAG() answers RESET without a bark",
              (__HAL_WWDG_GET_FLAG(&hwwdg_dev, WWDG_FLAG_BK0) == RESET) ? 1U : 0U);

        Check("Check : IS_WWDG_PRESCALER_RANGE() accepts 0 and 255",
              ((IS_WWDG_PRESCALER_RANGE(0U) != 0U) &&
               (IS_WWDG_PRESCALER_RANGE(255U) != 0U)) ? 1U : 0U);
        Check("Check : IS_WWDG_PRESCALER_RANGE() refuses 256",
              (IS_WWDG_PRESCALER_RANGE(256U) == 0U) ? 1U : 0U);
        Check("Check : IS_WWDG_PRESCALER() requires 2",
              ((IS_WWDG_PRESCALER(2U) != 0U) && (IS_WWDG_PRESCALER(1U) == 0U)) ? 1U : 0U);
        Check("Check : IS_WWDG_DIVIDER() requires 2",
              ((IS_WWDG_DIVIDER(2U) != 0U) && (IS_WWDG_DIVIDER(1U) == 0U)) ? 1U : 0U);
        Check("Check : IS_WWDG_COUNTER() requires 1",
              ((IS_WWDG_COUNTER(1U) != 0U) && (IS_WWDG_COUNTER(0U) == 0U)) ? 1U : 0U);
        Check("Check : IS_WWDG_WINDOW() accepts 0 and 0xFFFF",
              ((IS_WWDG_WINDOW(0U) != 0U) && (IS_WWDG_WINDOW(0xFFFFU) != 0U)) ? 1U : 0U);
        Check("Check : IS_WWDG_BARK_FLAG() accepts a mask, not single bits only",
              ((IS_WWDG_BARK_FLAG(WWDG_FLAG_BK0 | WWDG_FLAG_BK2) != 0U) &&
               (IS_WWDG_BARK_FLAG(0U) == 0U)) ? 1U : 0U);
        Check("Check : IS_WWDG_EN() / IS_WWDG_LOCK() accept their selectors",
              ((IS_WWDG_EN(WWDG_EN_CFG) != 0U) &&
               (IS_WWDG_EN(0U) == 0U) &&
               (IS_WWDG_LOCK(WWDG_LOCK_PSC) != 0U) &&
               (IS_WWDG_LOCK(0U) == 0U)) ? 1U : 0U);

        Check("Helper : WWDG_HandleIsValid() accepts a live handle",
              (WWDG_HandleIsValid(&hwwdg_dev) != 0U) ? 1U : 0U);
        Check("Helper : WWDG_HandleIsValid() refuses an empty handle",
              (WWDG_HandleIsValid(NULL_PTR) == 0U) ? 1U : 0U);
        Check("Helper : WWDG_CheckState() accepts a READY handle",
              (WWDG_CheckState(&hwwdg_dev) == HAL_OK) ? 1U : 0U);
        Check("Helper : WWDG_CheckState() refuses a RESET handle",
              (WWDG_CheckState(&reset_handle) == HAL_ERROR) ? 1U : 0U);

        status = WWDG_LockHandle(&hwwdg_dev, 0U);
        Check("Helper : the first WWDG_LockHandle() succeeds", (status == HAL_OK) ? 1U : 0U);
        status = WWDG_LockHandle(&hwwdg_dev, 0U);
        Check("Helper : a nested WWDG_LockHandle() reports HAL_BUSY",
              (status == HAL_BUSY) ? 1U : 0U);
        WWDG_UnlockHandle(&hwwdg_dev);
        status = WWDG_LockHandle(&hwwdg_dev, 0U);
        Check("Helper : the lock is free again after WWDG_UnlockHandle()",
              (status == HAL_OK) ? 1U : 0U);
        WWDG_UnlockHandle(&hwwdg_dev);

        /* Leave the device in a quiet state for the next round */
        (void)HAL_WWDG_Cmd(&hwwdg_dev, WWDG_EN_CFG, DISABLE);

        Summary();
        rounds++;
        delay_ms(2000U);
    }
}

/* ==========================================================================*/
/*  Shared helpers of the suite (identical in every case of this suite)       */
/* ==========================================================================*/

/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the other integration tests of this library:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2 and
 *         CANX2 by 8, which gives core 180 MHz and APB 22.5 MHz. WWDG0 is
 *         clocked from APBBus0 and WWDG1 from APBBus1, so both watchdog
 *         instances run from the same 22.5 MHz in this tree.
 * @note   Clock tree order: the dividers are written while the system clock
 *         is still the power on source (FIRC), then the PLL is configured and
 *         the system clock is switched to it. That last call programs the
 *         flash controller clock before the switch (the core keeps fetching
 *         from the flash) and updates SystemCoreClock afterwards.
 * @param  None
 * @retval None
 */
void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks (console pins of USART0 and the PD4 marker pin) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu_dev);
    hpmu_dev.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu_dev);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu_dev, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu_dev, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Configure the PD4 marker pin as a push-pull output.
 * @note   The reference test case drives PD4 to be able to measure the bark
 *         time on a scope: the pin is set before the watchdog is started and
 *         cleared inside the FCU interrupt handler.
 * @param  None
 * @retval None
 */
void Test_Pd4Init(void)
{
    GPIO_InitTypeDef gpio_init;

    __HAL_CLEAR_STRUCT(&gpio_init);
    HAL_GPIO_StructInit(&gpio_init);
    gpio_init.Pin          = TEST_PD4_PIN;
    gpio_init.Mode         = GPIO_MODE_OUTPUT_PP;
    gpio_init.Pull         = GPIO_NOPULL;
    gpio_init.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    gpio_init.Alternate    = 0U;

    HAL_GPIO_Init(TEST_PD4_PORT, &gpio_init);
}

/**
 * @brief  Drive the PD4 marker pin.
 * @param  state: GPIO_PIN_SET (watchdog armed, waiting) / GPIO_PIN_RESET (bark)
 * @retval None
 */
void Test_Pd4Set(GPIO_PinState state)
{
    HAL_GPIO_WritePin(TEST_PD4_PORT, TEST_PD4_PIN, state);
}

/**
 * @brief  Read the cycle counter (low 32 bits).
 * @note   The core runs at 180 MHz in this test, so the 32-bit counter wraps
 *         after about 23.8 s: every measurement of the suite is far shorter,
 *         and an unsigned difference stays correct across a wrap.
 * @param  None
 * @retval The mcycle value
 */
uint32 Test_McycleNow(void)
{
    return (uint32)csr_read(CSR_MCYCLE);
}

/**
 * @brief  Convert a cycle count into microseconds.
 * @param  cycles: number of core cycles
 * @retval The equivalent number of microseconds
 */
uint32 Test_McycleToUs(uint32 cycles)
{
    uint32 per_us = SystemCoreClock / 1000000U;

    if (per_us == 0U)
    {
        per_us = 1U;
    }

    return cycles / per_us;
}

/**
 * @brief  Clear the bark observation of the previous round.
 * @param  None
 * @retval None
 */
void Test_BarkReset(void)
{
    test_bark_count   = 0U;
    test_bark_mask    = 0U;
    test_bark_counter = 0U;
    test_bark_mcycle  = 0U;
}

/**
 * @brief  Wait (bounded) until the FCU handler observed a bark.
 * @param  timeout_ms: budget in milliseconds
 * @retval HAL_StatusTypeDef: HAL_OK when a bark arrived / HAL_TIMEOUT
 */
HAL_StatusTypeDef Test_WaitBark(uint32 timeout_ms)
{
    uint32 tickstart = HAL_GetTick();

    while (test_bark_count == 0U)
    {
        if ((HAL_GetTick() - tickstart) > timeout_ms)
        {
            return HAL_TIMEOUT;
        }
    }

    return HAL_OK;
}

/**
 * @brief  Program one watchdog channel through HAL_WWDG_Init().
 * @note   The driver has no HAL_WWDG_StructInit(): the configuration
 *         structure follows the Version+Size mechanism, so the metafields are
 *         filled here (the business fields are overwritten on every call).
 * @param  prescaler: PSC.PSCNUM value (0..255)
 * @param  divider:   DIV.DIVNUM value (2..65535)
 * @param  counter:   TO.BVAL timeout value (1..65535)
 * @param  window:    WD.WDCNT window value (0..65534, 0 = plain watchdog)
 * @param  instance:  channel register base (WWDG0_Channel0 .. WWDG1_Channel3)
 * @retval HAL_StatusTypeDef of HAL_WWDG_Init()
 */
HAL_StatusTypeDef Test_WwdgApply(uint32 prescaler, uint32 divider, uint32 counter,
                                 uint32 window, WWDG_Channel_TypeDef *instance)
{
    hwwdg_dev.Instance        = instance;
    hwwdg_dev.Init.Size       = (uint32)sizeof(WWDG_InitTypeDef);
    hwwdg_dev.Init.Version    = WWDG_INIT_VERSION;
    hwwdg_dev.Init.Prescaler  = prescaler;
    hwwdg_dev.Init.Divider    = divider;
    hwwdg_dev.Init.Counter    = counter;
    hwwdg_dev.Init.Window     = window;
    hwwdg_dev.Init.Reserved[0] = 0U;
    hwwdg_dev.Init.Reserved[1] = 0U;

    return HAL_WWDG_Init(&hwwdg_dev);
}

/**
 * @brief  Configure one FCU channel for the watchdog bark.
 * @note   MaskEnable = FCU_DISABLE unmasks the channel (an enabled mask keeps
 *         the channel silent), which is the configuration of the reference
 *         test case.
 * @param  channel:      FCU channel of the watchdog (WWDG0 / WWDG1)
 * @param  fault_action: action at fault level
 * @param  alarm_action: action at alarm level
 * @param  level:        fault level of the channel
 * @retval None
 */
void Test_FcuConfig(HAL_FCU_ChannelTypeDef channel,
                    HAL_FCU_FaultActionTypeDef fault_action,
                    HAL_FCU_AlarmActionTypeDef alarm_action,
                    HAL_FCU_FaultLevelTypeDef level)
{
    FCU_InitTypeDef fcu_init;

    __HAL_CLEAR_STRUCT(&hfcu_dev);
    hfcu_dev.Instance = FCU;

    HAL_FCU_StructInit(&fcu_init);
    fcu_init.Channel           = channel;
    fcu_init.FaultToResetCount = 0U;
    fcu_init.AlarmToFaultCount = 0U;
    fcu_init.FaultAction       = fault_action;
    fcu_init.AlarmAction       = alarm_action;
    fcu_init.FaultLevel        = level;
    fcu_init.MaskEnable        = FCU_DISABLE;

    hfcu_dev.Init = fcu_init;

    (void)HAL_FCU_Init(&hfcu_dev);
    (void)HAL_FCU_Cmd(&hfcu_dev, channel, FCU_ENABLE);
}

/**
 * @brief  Enable the FCU interrupt source in the PLIC.
 * @param  priority: source priority (1..63, larger = higher priority)
 * @retval None
 */
void Test_PlicEnable(uint32 priority)
{
    PLIC_InitTypeDef plic_init;

    __HAL_CLEAR_STRUCT(&plic_init);
    plic_init.Size               = (uint32)sizeof(PLIC_InitTypeDef);
    plic_init.Version            = PLIC_INIT_VERSION;
    plic_init.PLIC_IRQChannel    = FCU_IRQn;
    plic_init.PLIC_IRQPriority   = priority;
    plic_init.PLIC_IRQChannelCmd = PLIC_ENABLE;
    (void)HAL_PLIC_Init(&plic_init);
}

/**
 * @brief  Return the instance level register block of a channel.
 * @param  instance: channel register base
 * @retval WWDG0 or WWDG1
 */
static WWDG_TypeDef *Test_Periph(WWDG_Channel_TypeDef *instance)
{
    if ((instance == WWDG0_Channel0) || (instance == WWDG0_Channel1) ||
        (instance == WWDG0_Channel2) || (instance == WWDG0_Channel3))
    {
        return WWDG0;
    }

    return WWDG1;
}

/**
 * @brief  FCU interrupt handler: record the bark, then acknowledge the source.
 * @note   The reference test case uses this handler to drive PD4 low and to
 *         read the bark flags. The handler runs outside the driver locks: the
 *         read-only queries (HAL_FCU_GetAlarmStatus / HAL_FCU_GetFaultStatus /
 *         HAL_WWDG_GetCounter / HAL_WWDG_GetBKStatus) and the clear family
 *         (HAL_FCU_ClearFcuStatus) are interrupt safe by design.
 * @note   The bark instant is stamped with the cycle counter, so the case can
 *         compare the measured timeout with the programmed one.
 * @param  None
 * @retval None
 */
void FCU_IRQ_Handler(void)
{
    uint32 status0;
    uint32 status1;

    status0 = HAL_FCU_GetAlarmStatus(&hfcu_dev, HAL_FCU_CHANNEL_WWDG0) |
              HAL_FCU_GetFaultStatus(&hfcu_dev, HAL_FCU_CHANNEL_WWDG0);
    status1 = HAL_FCU_GetAlarmStatus(&hfcu_dev, HAL_FCU_CHANNEL_WWDG1) |
              HAL_FCU_GetFaultStatus(&hfcu_dev, HAL_FCU_CHANNEL_WWDG1);

    if ((status0 != 0U) || (status1 != 0U))
    {
        test_bark_mcycle  = Test_McycleNow();
        test_bark_counter = (uint32)HAL_WWDG_GetCounter(&hwwdg_dev);
        test_bark_mask    = (uint32)(READ_REG(Test_Periph(hwwdg_dev.Instance)->DSTA) &
                                     (WWDG_DSTA_BK0 | WWDG_DSTA_BK1 |
                                      WWDG_DSTA_BK2 | WWDG_DSTA_BK3));
        test_bark_count++;

        /* Marker pin: the bark pulls PD4 low (the scope reference) */
        Test_Pd4Set(TEST_PD4_OFF);
    }

    if (status0 != 0U)
    {
        (void)HAL_FCU_ClearFcuStatus(&hfcu_dev, HAL_FCU_CHANNEL_WWDG0);
    }
    if (status1 != 0U)
    {
        (void)HAL_FCU_ClearFcuStatus(&hfcu_dev, HAL_FCU_CHANNEL_WWDG1);
    }
}

/*****END OF FILE*****/
