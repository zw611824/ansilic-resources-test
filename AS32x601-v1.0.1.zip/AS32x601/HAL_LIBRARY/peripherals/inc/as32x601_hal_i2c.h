/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_i2c.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.5
 * Date:   2026/11/02
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.1     align with the source
 *                                                       file V1.1: the
 *                                                       blocking IO functions
 *                                                       accept both acknowledge
 *                                                       outcomes and the early
 *                                                       master STOP
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.2     align with the source
 *                                                       file V1.2: the blocking
 *                                                       IO functions add a
 *                                                       runtime transfer
 *                                                       parameter check before
 *                                                       the lock is taken
 *     ANSILIC APPLICATION GROUP  2026/09/17     1.3     align with the source file V1.3: expose the shared
 *                                                       lock helpers
 *                                                       (I2C_LockHandle /
 *                                                       I2C_UnlockHandle, with a
 *                                                       Timeout parameter and a
 *                                                       NULL mutex guard -
 *                                                       RTOS-11) and the shared
 *                                                       state check
 *                                                       (I2C_CheckState,
 *                                                       ARCH-CONST-09) in the
 *                                                       shared internal section,
 *                                                       and document the LOCK-06
 *                                                       MSP callback ordering
 *                                                       and the state gate of
 *                                                       the register accessing
 *                                                       APIs
 *     ANSILIC APPLICATION GROUP  2026/09/18     1.4     align with the source file V1.4: add the public
 *                                                       peripheral control APIs
 *                                                       (HAL_I2C_Cmd,
 *                                                       HAL_I2C_ITInit,
 *                                                       HAL_I2C_GetITStatus and
 *                                                       the interrupt safe
 *                                                       HAL_I2C_ClearITPendingBit),
 *                                                       add
 *                                                       HAL_I2C_ERROR_INVALID_PARAM
 *                                                       with the documented
 *                                                       runtime parameter checks
 *                                                       and the reserved error
 *                                                       codes, and add the
 *                                                       (BLOCKING) /
 *                                                       (NON-BLOCKING)
 *                                                       annotations
 *     ANSILIC APPLICATION GROUP  2026/11/02     1.5     align with the source file V1.5: add the interrupt
 *                                                       safe low level bus
 *                                                       functions
 *                                                       (HAL_I2C_ITStructInit,
 *                                                       HAL_I2C_GenerateStart /
 *                                                       GenerateStop /
 *                                                       StartClear /
 *                                                       Send7bitAddress /
 *                                                       AcknowledgeConfig /
 *                                                       SendData / ReceiveData /
 *                                                       GetFlagStatus /
 *                                                       CheckStatus), which take
 *                                                       no lock and no state gate
 *                                                       (ARCH-CONST-19 /
 *                                                       LOCK-04) so that a user
 *                                                       I2Cx_IRQ_Handler can drive
 *                                                       the bus step by step
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Inter-Integrated
 *                  Circuit (I2C) interface, as a HAL peripheral driver of
 *                  this library:
 *                  - Initialization and de-initialization: HAL_I2C_Init /
 *                    HAL_I2C_DeInit, configuration structure handling;
 *                  - IO operation functions (polling): master transmit /
 *                    receive, slave transmit / receive with timeout;
 *                  - Peripheral control: enable / disable (HAL_I2C_Cmd),
 *                    interrupt source configuration and acknowledgement
 *                    (HAL_I2C_ITInit / HAL_I2C_GetITStatus /
 *                    HAL_I2C_ClearITPendingBit);
 *                  - Interrupt safe low level bus functions: the atomic bus
 *                    steps (HAL_I2C_GenerateStart / HAL_I2C_GenerateStop /
 *                    HAL_I2C_StartClear / HAL_I2C_Send7bitAddress /
 *                    HAL_I2C_AcknowledgeConfig / HAL_I2C_SendData /
 *                    HAL_I2C_ReceiveData) and the running state queries
 *                    (HAL_I2C_GetFlagStatus / HAL_I2C_CheckStatus), so that
 *                    a user I2Cx_IRQ_Handler can drive the bus byte by byte
 *                    without taking the lock;
 *                  - State and error reporting: HAL_I2C_GetState /
 *                    HAL_I2C_GetError.
 *                  The I2C controller of the AS32x601 is a state-machine
 *                  based interface (status register STATE field); the
 *                  polling IO functions drive the state machine step by
 *                  step (start -> address -> data -> stop) and report the
 *                  transfer outcome through the handle state and error code.
 * @complexity  Medium
 *              Blocking (polling) transfers driving a register level state
 *              machine; no _IT / _DMA transfer variants. The interrupt
 *              sources themselves can be configured and acknowledged through
 *              the dedicated control APIs listed above.
 */
#ifndef __AS32X601_HAL_I2C_H
#define __AS32X601_HAL_I2C_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "as32x601.h"               /* I2C_TypeDef, I2C register bits         */
#include "as32x601_hal_def.h"       /* HAL_StatusTypeDef, HAL_LockTypeDef     */

/* Exported constants --------------------------------------------------------*/

/**
 * @brief I2C HAL driver module version.
 * @note  0x0100U = V1.0. Bumped only on breaking API changes (architecture
 *        spec COMPAT-13/14/15).
 */
#define __HAL_I2C_MODULE_VERSION  0x0100U

/* Exported types ------------------------------------------------------------*/

/** @defgroup I2C_Exported_Types I2C Exported Types
  * @{
  */

/**
 * @brief I2C configuration structure definition.
 * @note  The controller uses a byte-wide register set: the clock scale
 *        selects a fixed PCLK divider, and an extra 8-bit division factor
 *        pair (low / high) applies when the /8 scale is selected.
 */
typedef struct
{
    uint32 Size;                /*!< sizeof(I2C_InitTypeDef), set by the user
                                     after clearing the structure */
    uint32 Version;             /*!< Structure semantic version: @ref I2C_INIT_VERSION
                                     (I2C_INIT_V1 = 0x0100U) */
    uint32 I2C_ClockScale;      /*!< Clock selection: I2C_CLOCKSCALE_xxx       */
    uint8  I2C_ICLKDIVL;        /*!< Division coefficient low (for /8 scale)   */
    uint8  I2C_ICLKDIVH;        /*!< Division coefficient high (for /8 scale)  */
    uint32 I2C_EN;              /*!< I2C enable: I2C_ENABLE / I2C_DISABLE      */
    uint8  I2C_SlaveAddress;    /*!< Own slave address (7 bits, 0x00..0x7F)    */
    uint32 I2C_Ack;             /*!< Assert acknowledge: I2C_ACK / I2C_NACK   */
    uint32 Reserved[2];         /*!< Reserved for future extension (must be 0) */
} I2C_InitTypeDef;

/**
 * @brief I2C init structure version macros.
 * @note  I2C_INIT_V1 is the current version. Future versions must be
 *        appended after the existing fields (architecture spec section 22.5).
 */
#define I2C_INIT_V1  0x0100U   /*!< I2C Init structure version V1.0 */
#define I2C_INIT_VERSION  I2C_INIT_V1   /*!< Current I2C Init structure version */

/**
 * @brief I2C interrupt configuration structure definition.
 */
typedef struct
{
    uint32 ERRN;                   /*!< Transmission error interrupt enable       */
    uint32 SIEN;                   /*!< Sequential operation interrupt enable     */
    uint32 TXEN;                   /*!< Send idle interrupt enable                */
    uint32 RXEN;                   /*!< Receive idle interrupt enable             */
} I2C_IRQTypeDef;

/**
 * @brief HAL I2C state structures definition.
 */
typedef enum
{
    HAL_I2C_STATE_RESET    = 0x00U, /*!< Peripheral not initialized               */
    HAL_I2C_STATE_READY    = 0x01U, /*!< Peripheral initialized and ready         */
    HAL_I2C_STATE_BUSY     = 0x02U, /*!< An internal process is ongoing           */
    HAL_I2C_STATE_BUSY_TX  = 0x03U, /*!< Data transmission is ongoing             */
    HAL_I2C_STATE_BUSY_RX  = 0x04U, /*!< Data reception is ongoing                */
    HAL_I2C_STATE_TIMEOUT  = 0x05U, /*!< Timeout state                            */
    HAL_I2C_STATE_ERROR    = 0x06U  /*!< Error state                              */
} HAL_I2C_StateTypeDef;

/**
 * @brief I2C handle structure definition.
 * @note  Field order follows the architecture spec HANDLE-02:
 *        Instance -> Init -> Lock -> State -> ErrorCode -> module fields.
 *        The transfer counter fields modified by the ISR / DMA callbacks
 *        are declared as __IO (HANDLE-03).
 */
typedef struct __I2C_HandleTypeDef
{
    I2C_TypeDef            *Instance;      /*!< I2C registers base address        */
    I2C_InitTypeDef        Init;           /*!< I2C communication parameters      */
    HAL_LockTypeDef        Lock;           /*!< Locking object                    */
    __IO HAL_I2C_StateTypeDef State;       /*!< I2C communication state           */
    __IO uint32            ErrorCode;      /*!< I2C error code                    */
    uint8                  *pTxBuffPtr;    /*!< Pointer to I2C Tx buffer          */
    __IO uint16            TxXferSize;     /*!< I2C Tx transfer size (bytes)      */
    __IO uint16            TxXferCount;    /*!< I2C Tx transfer counter           */
    uint8                  *pRxBuffPtr;    /*!< Pointer to I2C Rx buffer          */
    __IO uint16            RxXferSize;     /*!< I2C Rx transfer size (bytes)      */
    __IO uint16            RxXferCount;    /*!< I2C Rx transfer counter           */
#if (USE_RTOS == 1)
    HAL_MutexTypeDef       LockMutex;      /*!< RTOS mutex handle (created by the
                                                user porting layer, e.g. in
                                                HAL_I2C_MspInit)                */
#endif /* USE_RTOS */
} I2C_HandleTypeDef;

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @defgroup I2C_Exported_Constants I2C Exported Constants
  * @{
  */

/** @defgroup I2C_Error_Code I2C Error Code
  * @{
  */
#define HAL_I2C_ERROR_NONE         ((uint32)0x00000000U)  /*!< No error                    */
#define HAL_I2C_ERROR_BERR         ((uint32)0x00000001U)  /*!< Bus error (reserved: the
                                                               polling state machine of this
                                                               driver never reports it)     */
#define HAL_I2C_ERROR_ARLO         ((uint32)0x00000002U)  /*!< Arbitration loss error
                                                               (reserved: see above)        */
#define HAL_I2C_ERROR_AF           ((uint32)0x00000004U)  /*!< Acknowledge failure error
                                                               (reserved: see above)        */
#define HAL_I2C_ERROR_TIMEOUT      ((uint32)0x00000008U)  /*!< Timeout error               */
#define HAL_I2C_ERROR_SIZE         ((uint32)0x00000010U)  /*!< Size management error
                                                               (reserved: see above)        */
#define HAL_I2C_ERROR_INVALID_PARAM ((uint32)0x00000020U) /*!< Invalid call parameter      */
/**
  * @}
  */

/** @defgroup I2C_Enable_Value I2C Enable Value
  * @{
  */
#define I2C_ENABLE     1U           /*!< Enable the I2C peripheral / function    */
#define I2C_DISABLE    0U           /*!< Disable the I2C peripheral / function   */
/**
  * @}
  */

/** @defgroup I2C_Acknowledge I2C Acknowledge
  * @{
  */
#define I2C_ACK        ((uint32)0x00000004U)  /*!< Send ACK when receiving data      */
#define I2C_NACK       ((uint32)0x00000000U)  /*!< Send NACK when receiving data     */
/**
  * @}
  */

/** @defgroup I2C_Read_Write I2C Read Write
  * @{
  */
#define I2C_READ       ((uint32)0x00000001U)  /*!< I2C read direction                */
#define I2C_WRITE      ((uint32)0x00000000U)  /*!< I2C write direction               */
/**
  * @}
  */

/** @defgroup I2C_Clock_Scale I2C Clock Scale
  * @{
  */
#define I2C_CLOCKSCALE_PCLK_256   ((uint32)0x00000000U)  /*!< PCLK / 256                 */
#define I2C_CLOCKSCALE_PCLK_224   ((uint32)0x00000001U)  /*!< PCLK / 224                 */
#define I2C_CLOCKSCALE_PCLK_192   ((uint32)0x00000002U)  /*!< PCLK / 192                 */
#define I2C_CLOCKSCALE_PCLK_160   ((uint32)0x00000003U)  /*!< PCLK / 160                 */
#define I2C_CLOCKSCALE_PCLK_96    ((uint32)0x00000080U)  /*!< PCLK / 96                  */
#define I2C_CLOCKSCALE_PCLK_120   ((uint32)0x00000081U)  /*!< PCLK / 120                 */
#define I2C_CLOCKSCALE_PCLK_60    ((uint32)0x00000082U)  /*!< PCLK / 60                  */
#define I2C_CLOCKSCALE_PCLK_8     ((uint32)0x00000083U)  /*!< PCLK / 8 / DIV (DIV_L/H)   */
/**
  * @}
  */

/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/

/** @addtogroup I2C_Exported_Functions
  * @{
  */

/** @addtogroup I2C_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Fills each I2C_InitStruct member with its default value. (NON-BLOCKING)
 * @param  I2C_InitStruct: pointer to an I2C_InitTypeDef structure which will
 *         be initialized (clock /256, disabled, slave address 0, NACK).
 * @retval None
 */
void HAL_I2C_StructInit(I2C_InitTypeDef *I2C_InitStruct);

/**
 * @brief  Initializes the I2C according to the specified parameters in the (NON-BLOCKING)
 *         I2C_InitStruct of the handle.
 * @note   The I2C clock gating and the pin multiplexing must be configured
 *         by the user in HAL_I2C_MspInit(); the callback runs on the first
 *         initialization (while the handle is in the reset state) and before
 *         the first register access (architecture rules MSP-04 and LOCK-06),
 *         so an override may create an RTOS mutex and call other HAL APIs.
 * @note   Protected by the handle lock. A configuration parameter that is
 *         rejected at run time reports HAL_I2C_ERROR_INVALID_PARAM and leaves
 *         the handle state untouched, so a corrected configuration can be
 *         initialized directly afterwards.
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_I2C_Init(I2C_HandleTypeDef *hi2c);

/**
 * @brief  De-initializes the I2C peripheral. (NON-BLOCKING)
 * @note   The low level de-initialization callback runs after the handle lock
 *         has been released (architecture rule LOCK-06), so an override may
 *         call other HAL APIs.
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_I2C_DeInit(I2C_HandleTypeDef *hi2c);

/**
 * @brief  Initializes the I2C MSP. Weak empty function; the user implements
 *         the low level hardware initialization (I2C clock enable through
 *         the SMU bus clock configuration, GPIO pin configuration).
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @retval None
 */
void HAL_I2C_MspInit(I2C_HandleTypeDef *hi2c);

/**
 * @brief  De-initializes the I2C MSP. Weak empty function; the user
 *         implements the low level hardware de-initialization.
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @retval None
 */
void HAL_I2C_MspDeInit(I2C_HandleTypeDef *hi2c);

/**
  * @}
  */

/** @addtogroup I2C_Exported_Functions_Group2 IO operation functions
  * @brief    Polling mode IO operations
  * @{
  */

/**
 * @brief  Transmits in master mode an amount of data in blocking mode. (BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  DevAddress: target device address (7 bits, 0x00..0x7F).
 * @param  pData: pointer to the data buffer to transmit.
 * @param  Size: amount of data to be sent, in bytes.
 * @param  Timeout: maximum waiting time in ms (HAL_MAX_DELAY for infinite).
 * @note   The transfer parameters (data pointer, size, device address) are
 *         validated at run time before the lock is taken: a rejected call
 *         reports HAL_I2C_ERROR_INVALID_PARAM and leaves the handle state
 *         untouched.
 * @note   Protected by the handle lock and gated by the handle state
 *         (ARCH-CONST-09): the call is rejected with HAL_BUSY while another
 *         transfer is ongoing and with HAL_ERROR while the handle has not
 *         been initialized. The timeout / error states are accepted so that a
 *         failed transfer can be retried directly; the RTOS build yields the
 *         CPU inside the wait loops (RTOS-04).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_I2C_Master_Transmit(I2C_HandleTypeDef *hi2c, uint16 DevAddress,
                                          uint8 *pData, uint16 Size,
                                          uint32 Timeout);

/**
 * @brief  Receives in master mode an amount of data in blocking mode. (BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  DevAddress: target device address (7 bits, 0x00..0x7F).
 * @param  pData: pointer to the data buffer to store the received data.
 * @param  Size: amount of data to be received, in bytes.
 * @param  Timeout: maximum waiting time in ms (HAL_MAX_DELAY for infinite).
 * @note   Protected by the handle lock and gated by the handle state
 *         (ARCH-CONST-09), parameter validation and RTOS behaviour as in
 *         HAL_I2C_Master_Transmit().
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_I2C_Master_Receive(I2C_HandleTypeDef *hi2c, uint16 DevAddress,
                                         uint8 *pData, uint16 Size,
                                         uint32 Timeout);

/**
 * @brief  Transmits in slave mode an amount of data in blocking mode. (BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  pData: pointer to the data buffer to transmit.
 * @param  Size: amount of data to be sent, in bytes.
 * @param  Timeout: maximum waiting time in ms (HAL_MAX_DELAY for infinite).
 * @note   Protected by the handle lock and gated by the handle state
 *         (ARCH-CONST-09), parameter validation and RTOS behaviour as in
 *         HAL_I2C_Master_Transmit().
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_I2C_Slave_Transmit(I2C_HandleTypeDef *hi2c, uint8 *pData, uint16 Size,
                                         uint32 Timeout);

/**
 * @brief  Receives in slave mode an amount of data in blocking mode. (BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  pData: pointer to the data buffer to store the received data.
 * @param  Size: amount of data to be received, in bytes.
 * @param  Timeout: maximum waiting time in ms (HAL_MAX_DELAY for infinite).
 * @note   Protected by the handle lock and gated by the handle state
 *         (ARCH-CONST-09), parameter validation and RTOS behaviour as in
 *         HAL_I2C_Master_Transmit().
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_I2C_Slave_Receive(I2C_HandleTypeDef *hi2c, uint8 *pData, uint16 Size,
                                        uint32 Timeout);

/**
  * @}
  */

/** @addtogroup I2C_Exported_Functions_Group3 Peripheral Control functions
  * @{
  */

/**
 * @brief  Return the I2C handle state. (NON-BLOCKING)
 * @note   Read only access, deliberately not protected by the handle lock: it
 *         is a single field read and stays callable from an interrupt service
 *         routine.
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @retval HAL_I2C_StateTypeDef: the current handle state.
 */
HAL_I2C_StateTypeDef HAL_I2C_GetState(I2C_HandleTypeDef *hi2c);

/**
 * @brief  Return the I2C error code. (NON-BLOCKING)
 * @note   Read only access, deliberately not protected by the handle lock (see
 *         HAL_I2C_GetState()): callable from an interrupt service routine.
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @retval uint32: the I2C error code (HAL_I2C_ERROR_xxx).
 */
uint32 HAL_I2C_GetError(I2C_HandleTypeDef *hi2c);

/**
 * @brief  Enables or disables the specified I2C peripheral. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  NewState: ENABLE or DISABLE.
 * @note   Protected by the handle lock and gated by the handle state
 *         (ARCH-CONST-09): the call is rejected with HAL_BUSY while another
 *         transfer is ongoing and with HAL_ERROR while the handle has not been
 *         initialized.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_I2C_Cmd(I2C_HandleTypeDef *hi2c, FunctionalState NewState);

/**
 * @brief  Initializes the I2C interrupts according to the specified (NON-BLOCKING)
 *         parameters in the I2C_IRQStruct.
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  I2C_IRQStruct: pointer to an I2C_IRQTypeDef structure.
 * @note   Protected by the handle lock and gated by the handle state
 *         (ARCH-CONST-09). A configuration value that is rejected at run time
 *         reports HAL_I2C_ERROR_INVALID_PARAM and leaves the interrupt control
 *         register untouched.
 * @note   The interrupt service routine is provided by the user (the weak
 *         I2Cx_IRQ_Handler entry point of the interrupt controller module); it
 *         queries the serial interrupt flag with HAL_I2C_GetITStatus() and
 *         clears it with HAL_I2C_ClearITPendingBit(), both of which are safe
 *         to call from an interrupt service routine. The polling APIs of this
 *         driver drive the same serial interrupt flag internally.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_I2C_ITInit(I2C_HandleTypeDef *hi2c, I2C_IRQTypeDef *I2C_IRQStruct);

/**
 * @brief  Returns the serial interrupt flag state. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @note   Read only access, deliberately not protected by the handle lock: it
 *         is a single register read and stays callable from an interrupt
 *         service routine.
 * @retval uint32: 1 if the serial interrupt flag is set, 0 otherwise.
 */
uint32 HAL_I2C_GetITStatus(I2C_HandleTypeDef *hi2c);

/**
 * @brief  Clears the serial interrupt flag (IICI bit). (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @note   Interrupt safe by design: no lock and no state gate (ARCH-CONST-19 /
 *         LOCK-04), so a pending serial interrupt can always be acknowledged
 *         from the user I2Cx_IRQ_Handler entry point - gating it on the handle
 *         state would leave the flag set and re-enter the interrupt forever.
 * @retval None
 */
void HAL_I2C_ClearITPendingBit(I2C_HandleTypeDef *hi2c);

/**
  * @}
  */

/** @addtogroup I2C_Exported_Functions_Group4 Interrupt safe low level bus functions
  * @brief    Atomic bus steps and running state queries of the transfer
  *           sequences, published as public APIs so that a user
  *           I2Cx_IRQ_Handler entry point can drive the bus step by step.
  * @note     Interrupt safe by design: these functions take no lock and have
  *           no state gate (ARCH-CONST-19 / LOCK-04). The polling APIs of this
  *           module execute the same helpers while the lock is already held,
  *           so the bus sequence is identical in polling and interrupt mode.
  * @{
  */

/**
 * @brief  Fills each I2C_IRQStruct member with its default value. (NON-BLOCKING)
 * @param  I2C_IRQStruct: pointer to an I2C_IRQTypeDef structure which will be
 *         initialized (all four interrupt sources disabled).
 * @note   Interrupt safe by design: no lock and no state gate (ARCH-CONST-19 /
 *         LOCK-04). A NULL pointer is ignored.
 * @retval None
 */
void HAL_I2C_ITStructInit(I2C_IRQTypeDef *I2C_IRQStruct);

/**
 * @brief  Generates an I2C START condition. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @note   Interrupt safe by design: no lock and no state gate (ARCH-CONST-19 /
 *         LOCK-04), so the START step can be driven from an interrupt service
 *         routine.
 * @retval None
 */
void HAL_I2C_GenerateStart(I2C_HandleTypeDef *hi2c);

/**
 * @brief  Generates an I2C STOP condition. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @note   Interrupt safe by design: no lock and no state gate (ARCH-CONST-19 /
 *         LOCK-04); used to release the bus at the end of a sequence.
 * @retval None
 */
void HAL_I2C_GenerateStop(I2C_HandleTypeDef *hi2c);

/**
 * @brief  Clears the START flag of the I2C control register. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @note   Interrupt safe by design: no lock and no state gate (ARCH-CONST-19 /
 *         LOCK-04).
 * @retval None
 */
void HAL_I2C_StartClear(I2C_HandleTypeDef *hi2c);

/**
 * @brief  Sends a 7-bit slave address with the read / write direction. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  DevAddress: the 7-bit device address (0x00..0x7F).
 * @param  Direction: I2C_READ or I2C_WRITE.
 * @note   Interrupt safe by design: no lock and no state gate (ARCH-CONST-19 /
 *         LOCK-04).
 * @retval None
 */
void HAL_I2C_Send7bitAddress(I2C_HandleTypeDef *hi2c, uint8 DevAddress, uint32 Direction);

/**
 * @brief  Configures whether an ACK or a NACK is sent when receiving data. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  AckState: I2C_ACK or I2C_NACK.
 * @note   Interrupt safe by design: no lock and no state gate (ARCH-CONST-19 /
 *         LOCK-04), so the acknowledge policy of an interrupted receive can be
 *         changed from the interrupt service routine.
 * @retval None
 */
void HAL_I2C_AcknowledgeConfig(I2C_HandleTypeDef *hi2c, uint32 AckState);

/**
 * @brief  Writes a single data byte to the I2C data register. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  Data: the data byte to transmit.
 * @note   Interrupt safe by design: no lock and no state gate (ARCH-CONST-19 /
 *         LOCK-04), so the next byte of an interrupted transfer can be staged
 *         from the interrupt service routine.
 * @retval None
 */
void HAL_I2C_SendData(I2C_HandleTypeDef *hi2c, uint8 Data);

/**
 * @brief  Reads the data byte from the I2C data register. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @note   Interrupt safe by design: no lock and no state gate (ARCH-CONST-19 /
 *         LOCK-04), so the received byte of an interrupted transfer can be
 *         fetched from the interrupt service routine.
 * @retval uint8: the received data byte (0 when hi2c is NULL).
 */
uint8 HAL_I2C_ReceiveData(I2C_HandleTypeDef *hi2c);

/**
 * @brief  Returns the running state code of the I2C state machine. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @note   Read only register access, interrupt safe by design: no lock and no
 *         state gate (ARCH-CONST-19 / LOCK-04).
 * @retval uint32: the running state code (the I2C_STATE_xxx constants), 0 when
 *         hi2c is NULL.
 */
uint32 HAL_I2C_GetFlagStatus(I2C_HandleTypeDef *hi2c);

/**
 * @brief  Checks whether the I2C is in the given running state. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  Status: the running state code to check (I2C_STATE_xxx).
 * @note   Read only register access, interrupt safe by design: no lock and no
 *         state gate (ARCH-CONST-19 / LOCK-04).
 * @retval uint32: 1 if the I2C is in the state, 0 otherwise (0 when hi2c is
 *         NULL).
 */
uint32 HAL_I2C_CheckStatus(I2C_HandleTypeDef *hi2c, uint8 Status);

/**
  * @}
  */

/**
  * @}
  */

/* Exported constants: I2C running states (STAT.STATE[4:0]) ------------------*/
/** @defgroup I2C_Running_States I2C Running States
  * @{
  */
#define I2C_STATE_MASTER_START_READY                    ((uint8)0x01U)  /*!< START transmitted          */
#define I2C_STATE_MASTER_START_REPEAT                   ((uint8)0x02U)  /*!< Repeated START transmitted */
#define I2C_STATE_MSEND_WADDR_ACK                       ((uint8)0x03U)  /*!< Address+W sent, ACK        */
#define I2C_STATE_MSEND_WADDR_NACK                      ((uint8)0x04U)  /*!< Address+W sent, NACK       */
#define I2C_STATE_MSEND_DATA_ACK                        ((uint8)0x05U)  /*!< Data sent, ACK             */
#define I2C_STATE_MSEND_DATA_NACK                       ((uint8)0x06U)  /*!< Data sent, NACK            */
#define I2C_STATE_MSEND_ARBITRATION_LOST                ((uint8)0x07U)  /*!< Arbitration lost           */
#define I2C_STATE_MSEND_RADDR_ACK                       ((uint8)0x08U)  /*!< Address+R sent, ACK        */
#define I2C_STATE_MSEND_RADDR_NACK                      ((uint8)0x09U)  /*!< Address+R sent, NACK       */
#define I2C_STATE_MREAD_DATA_ACK                        ((uint8)0x0AU)  /*!< Data received, ACK sent    */
#define I2C_STATE_MREAD_DATA_NACK                       ((uint8)0x0BU)  /*!< Data received, NACK sent   */
#define I2C_STATE_SREV_WADDR_ACK                        ((uint8)0x0CU)  /*!< Addressed as slave, W, ACK */
#define I2C_STATE_SWADDR_ERROR_ACK                      ((uint8)0x0DU)  /*!< Address arbitration lost   */
#define I2C_STATE_SREV_BROADCAST_ACK                    ((uint8)0x0EU)  /*!< General call received      */
#define I2C_STATE_SADDR_ERROR_REV_BROADCAST_ACK         ((uint8)0x0FU)  /*!< General call + arbitr. lost*/
#define I2C_STATE_SREV_DATA_ACK                         ((uint8)0x10U)  /*!< Addressed, data received   */
#define I2C_STATE_SREV_DATA_NACK                        ((uint8)0x11U)  /*!< Addressed, data NACK       */
#define I2C_STATE_SREV_BROADCASTDATA_ACK                ((uint8)0x12U)  /*!< General call data received */
#define I2C_STATE_SREV_BROADCASTDATA_NACK               ((uint8)0x13U)  /*!< General call data NACK     */
#define I2C_STATE_SREV_STOP_MESSAGE                     ((uint8)0x14U)  /*!< STOP / repeated START rcvd */
#define I2C_STATE_SREV_RADDR_ACK                        ((uint8)0x15U)  /*!< Addressed as slave, R, ACK */
#define I2C_STATE_SRADDR_ERROR_ACK                      ((uint8)0x16U)  /*!< R address arbitration lost */
#define I2C_STATE_SSEND_DATA_ACK                        ((uint8)0x17U)  /*!< Slave data sent, ACK       */
#define I2C_STATE_SSEND_DATA_NACK                       ((uint8)0x18U)  /*!< Slave data sent, NACK      */
#define I2C_STATE_SSEND_LASTDATA_ACK                    ((uint8)0x19U)  /*!< Last data sent, ACK        */
#define I2C_STATE_MASTER_STOP_OVER                      ((uint8)0x1CU)  /*!< STOP transmitted           */
#define I2C_STATE_BUS_IDLE                              ((uint8)0x1FU)  /*!< Idle state                 */
/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/

/** @defgroup I2C_Private_Macros I2C Private Macros
  * @{
  */

/**
 * @brief  Check that the I2C peripheral instance is one of I2C0..I2C3.
 */
#define IS_I2C_ALL_PERIPH(PERIPH) (((PERIPH) == I2C0) || \
                                   ((PERIPH) == I2C1) || \
                                   ((PERIPH) == I2C2) || \
                                   ((PERIPH) == I2C3))

/**
 * @brief  Check that the I2C clock scale is a valid value.
 */
#define IS_I2C_CLOCKSCALE(SCALE)  (((SCALE) == I2C_CLOCKSCALE_PCLK_256) || \
                                   ((SCALE) == I2C_CLOCKSCALE_PCLK_224) || \
                                   ((SCALE) == I2C_CLOCKSCALE_PCLK_192) || \
                                   ((SCALE) == I2C_CLOCKSCALE_PCLK_160) || \
                                   ((SCALE) == I2C_CLOCKSCALE_PCLK_96)  || \
                                   ((SCALE) == I2C_CLOCKSCALE_PCLK_120) || \
                                   ((SCALE) == I2C_CLOCKSCALE_PCLK_60)  || \
                                   ((SCALE) == I2C_CLOCKSCALE_PCLK_8))

/**
 * @brief  Check that the I2C acknowledge flag is a valid value.
 */
#define IS_I2C_ACK_FLAG(FLAG) (((FLAG) == I2C_ACK) || ((FLAG) == I2C_NACK))

/**
 * @brief  Check that the I2C read / write direction is a valid value.
 */
#define IS_I2C_DIRECTION(DIRECTION) (((DIRECTION) == I2C_READ) || ((DIRECTION) == I2C_WRITE))

/**
 * @brief  Check that the I2C running state is a valid value.
 */
#define IS_I2C_STATE(STATE)     (((STATE) == I2C_STATE_MASTER_START_READY)         || \
                                 ((STATE) == I2C_STATE_MASTER_START_REPEAT)        || \
                                 ((STATE) == I2C_STATE_MSEND_WADDR_ACK)            || \
                                 ((STATE) == I2C_STATE_MSEND_WADDR_NACK)           || \
                                 ((STATE) == I2C_STATE_MSEND_DATA_ACK)             || \
                                 ((STATE) == I2C_STATE_MSEND_DATA_NACK)            || \
                                 ((STATE) == I2C_STATE_MSEND_ARBITRATION_LOST)     || \
                                 ((STATE) == I2C_STATE_MSEND_RADDR_ACK)            || \
                                 ((STATE) == I2C_STATE_MSEND_RADDR_NACK)           || \
                                 ((STATE) == I2C_STATE_MREAD_DATA_ACK)             || \
                                 ((STATE) == I2C_STATE_MREAD_DATA_NACK)            || \
                                 ((STATE) == I2C_STATE_SREV_WADDR_ACK)             || \
                                 ((STATE) == I2C_STATE_SWADDR_ERROR_ACK)           || \
                                 ((STATE) == I2C_STATE_SREV_BROADCAST_ACK)         || \
                                 ((STATE) == I2C_STATE_SADDR_ERROR_REV_BROADCAST_ACK) || \
                                 ((STATE) == I2C_STATE_SREV_DATA_ACK)              || \
                                 ((STATE) == I2C_STATE_SREV_DATA_NACK)             || \
                                 ((STATE) == I2C_STATE_SREV_BROADCASTDATA_ACK)     || \
                                 ((STATE) == I2C_STATE_SREV_BROADCASTDATA_NACK)    || \
                                 ((STATE) == I2C_STATE_SREV_STOP_MESSAGE)          || \
                                 ((STATE) == I2C_STATE_SREV_RADDR_ACK)             || \
                                 ((STATE) == I2C_STATE_SRADDR_ERROR_ACK)           || \
                                 ((STATE) == I2C_STATE_SSEND_DATA_ACK)             || \
                                 ((STATE) == I2C_STATE_SSEND_DATA_NACK)            || \
                                 ((STATE) == I2C_STATE_SSEND_LASTDATA_ACK)         || \
                                 ((STATE) == I2C_STATE_MASTER_STOP_OVER)           || \
                                 ((STATE) == I2C_STATE_BUS_IDLE))

/**
  * @}
  */

/* Shared internal functions --------------------------------------------------*/

/**
 * @brief  Check the handle state before a register access (ARCH-CONST-09).
 * @note   Returns HAL_BUSY while a transfer is ongoing (BUSY / BUSY_TX /
 *         BUSY_RX) and HAL_ERROR while the handle has not been initialized
 *         (HAL_I2C_Init() is required first). The timeout / error states are
 *         recoverable and are accepted, so a failed transfer can be retried
 *         without a DeInit / Init round trip (STATE-06).
 * @note   Not static: exported as part of the shared internal interface of the
 *         module (architecture spec section 9.6, Tier 3 helpers shared across
 *         the translation units of the module).
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef I2C_CheckState(I2C_HandleTypeDef *hi2c);

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_I2C_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the acquisition is bounded by the Timeout parameter (RTOS
 *         ticks, which with the usual 1 ms tick is the same quantity as the
 *         millisecond Timeout of the public API); HAL_MAX_DELAY waits forever.
 *         A mutex that was never created is reported as HAL_ERROR instead of
 *         being passed to the porting layer as a NULL handle.
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS, wait expired) /
 *         HAL_ERROR (RTOS, mutex not created) / HAL_BUSY (bare metal, the
 *         handle is already locked).
 */
HAL_StatusTypeDef I2C_LockHandle(I2C_HandleTypeDef *hi2c, uint32 Timeout);

/**
 * @brief  Unlock the handle.
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @retval None
 */
void I2C_UnlockHandle(I2C_HandleTypeDef *hi2c);

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_I2C_H */

/*****END OF FILE*****/
