/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:        as32x601.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.7
 * Date:            2026/11/05
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/10     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/03     1.1     unify _DPos naming: every <F>_Pos
 *                                                       references its own <F>_DPos (584
 *                                                       fields + 6 direct-value); fix _DPOS
 *                                                       case (SPACC_OFFSET_SRC/DST) and
 *                                                       block titles (SMU_SR, SECKEY1)
 *     ANSILIC APPLICATION GROUP  2026/09/03     1.2     format/alignment cleanup: strip
 *                                                       trailing whitespace, expand tabs,
 *                                                       fix 'UL <<' spacing, '}Name;' spacing,
 *                                                       align bit-def block value/comment
 *                                                       columns, add missing struct-member
 *                                                       offset comments (MPU/DMA/IWDG/WWDG,
 *                                                       per SVD) and DAC _Msk value comments
 *     ANSILIC APPLICATION GROUP  2026/09/03     1.3     spec-compliance fixes: add 'U' suffix
 *                                                       to all _DPos (391), change _Msk and
 *                                                       field-value masks to 'UL' (20), complete
 *                                                       I2C_CTRL_CLK / I2C_CTRL_IICSTA four-tuples
 *                                                       (own _Pos, self-reference), fix DMA/CRC
 *                                                       RESERVED offset-comment ranges, add ADC
 *                                                       constant macro comments
 *     ANSILIC APPLICATION GROUP  2026/09/16     1.4     drop the redundant '*_DPos' alias lines that 1.1 added: every
 *                                                       '<F>_Pos' references the canonical '<F>_DPos' of its field again
 *                                                       (585 alias lines removed - 564 keep the device-layer field name,
 *                                                       21 realigned within DMA/I2C where the field name is not given),
 *                                                       _DPos 2507 -> 1922, no change to the value of any macro
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.5     map the C11 static assertion spelling
 *                                                       to the C++ keyword for a C++
 *                                                       translation unit, so that the header
 *                                                       and the drivers that include it build
 *                                                       as C++; the assertions themselves are
 *                                                       unchanged
 *     ANSILIC APPLICATION GROUP  2026/10/08     1.6     review fixes: correct the WWDG_DSTA bark flag
 *                                                       positions (BK1..3 _DPos were copied from BK0, so
 *                                                       all four masks collapsed onto bit 0), give the 14
 *                                                       structs that inherited the GPIO brief text their
 *                                                       own description, spell the SPACC reserved members
 *                                                       RESERVEDn as the requirement states, and re-align
 *                                                       every struct member line (type - name - comment
 *                                                       columns consistent, inner padding of the member
 *                                                       comments removed, header tabs expanded) without
 *                                                       changing any macro value or member order
 *     ANSILIC APPLICATION GROUP  2026/11/05     1.7     PKA review fixes from the chip
 *                                                       manual (ch.31): spell the PKA
 *                                                       entry-point masks as
 *                                                       PKA_ENTRY_PNT_ADDR_* (the
 *                                                       historical spelling dropped the
 *                                                       "Y") and keep the old name as
 *                                                       compatibility aliases; mark
 *                                                       STAT[29:0] and IRQ_EN[29:0] /
 *                                                       [31] as the reserved bits the
 *                                                       manual declares them to be and
 *                                                       record that STAT.DONE is
 *                                                       write-one-to-clear; document
 *                                                       what the manual does and does
 *                                                       not say about STACK_PNTR.  No
 *                                                       macro value changes.
 * Description:     This file contains the device-level definitions for the
 *                  AS32x601 MCU, including the interrupt number, peripheral
 *                  register structures, peripheral memory map, peripheral
 *                  declaration and register bit definitions.
 */
#ifndef AS32X601_H
#define AS32X601_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stddef.h>   /* offsetof: used by CHIP-08 register-struct layout assertions */
#include "core_riscv.h"

/* The register layout assertions below are written with the C11 spelling of
 * the static assertion. C++ spells the same construct with its own keyword
 * and does not accept the C identifier, so the spelling is mapped for a C++
 * translation unit: every assertion keeps its meaning, and the header as
 * well as the drivers that include it stay compilable from C and C++. */
#ifdef __cplusplus
    #ifndef _Static_assert
        #define _Static_assert static_assert
    #endif /* _Static_assert */
#endif /* __cplusplus */

/******************************************************************************
 *  CHIP IDENTIFICATION / CAPABILITY MACROS (architecture spec COMPAT-06/07)
 *****************************************************************************/
/**
 * @brief AS32x device chip ID (4 hex digits).
 * @note  Value kept by the architecture specification for cross-chip
 *        compatibility: 0x0601U for the AS32x601.
 */
#define AS32X_CHIP_ID                    0x0601U

/**
 * @brief Chip capability macros (module feature capability).
 * @note  Named "<MODULE>_HAS_<FEATURE>", value 1U (supported) or 0U (not
 *        supported); a quantity capability uses a decimal number. Consumed
 *        by the HAL module .c files with
 *        "#if defined(MODULE_HAS_FEATURE) && (MODULE_HAS_FEATURE == 1U)".
 */
#define GPIO_HAS_EXTI                    1U      /*!< GPIO external interrupt     */
#define CMU_HAS_CLOCK_MONITOR            1U      /*!< CMU clock monitor           */
#define SMU_HAS_CLOCK_TREE               1U      /*!< SMU clock tree / PLL        */
#define USART_HAS_FIFO                   0U      /*!< USART has no FIFO           */
#define SPI_HAS_QUAD_MODE                0U      /*!< SPI has no quad mode        */
#define ADC_HAS_DIFF_MODE                4U      /*!< ADC differential inputs     */
#define TIMER_MAX_CHANNELS               6U      /*!< Advanced timers 6 channels  */

/******************************************************************************
 *  DEVICE INTERRUPT NUMBER DEFINITIONS
 *****************************************************************************/
/**
 * @brief AS32x601 Interrupt Number Definition, according to the PLIC interrupt
 *        source ID.
 */
typedef enum
{
/******  AS32x601 specific Interrupt Numbers *********************************/
    None        = 0x00,  /*!< No interrupt                                                   */
    EFLASH_IRQn = 0x01,  /*!< Embedded Flash interrupt                                       */
    FCU_IRQn    = 0x02,  /*!< Flash control unit interrupt                                   */
    DMA0_IRQn   = 0x03,  /*!< DMA0 interrupt                                                 */
    DMA1_IRQn   = 0x04,  /*!< DMA1 interrupt                                                 */
    TIM0_IRQn   = 0x05,  /*!< TIM0 interrupt                                                 */
    CANFD0_IRQn = 0x06,  /*!< CANFD0 interrupt                                               */
    CANFD1_IRQn = 0x07,  /*!< CANFD1 interrupt                                               */
    ADC0_IRQn   = 0x08,  /*!< ADC0 interrupt                                                 */
    ADC1_IRQn   = 0x09,  /*!< ADC1 interrupt                                                 */
    GPIOA_IRQn  = 0x0A,  /*!< GPIOA interrupt                                                */
    GPIOB_IRQn  = 0x0B,  /*!< GPIOB interrupt                                                */
    GPIOC_IRQn  = 0x0C,  /*!< GPIOC interrupt                                                */
    PKA_IRQn    = 0x0D,  /*!< PKA interrupt                                                  */
    SPACC_IRQn  = 0x0E,  /*!< SPACC interrupt                                                */
    TRNG_IRQn   = 0x0F,  /*!< TRNG interrupt                                                 */
    TIM1_IRQn   = 0x10,  /*!< TIM1 interrupt                                                 */
    CANFD2_IRQn = 0x11,  /*!< CANFD2 interrupt                                               */
    CANFD3_IRQn = 0x12,  /*!< CANFD3 interrupt                                               */
    /* ADC2_IRQn = 0x13, */  /*!< ADC2 interrupt (reserved, no ADC2 peripheral)          */
    GPIOD_IRQn  = 0x14,  /*!< GPIOD interrupt                                                */
    GPIOE_IRQn  = 0x15,  /*!< GPIOE interrupt                                                */
    GPIOF_IRQn  = 0x16,  /*!< GPIOF interrupt                                                */
    GPIOG_IRQn  = 0x17,  /*!< GPIOG interrupt                                                */
    MAC_IRQn    = 0x18,  /*!< MAC interrupt                                                  */
    SPI0_IRQn   = 0x19,  /*!< SPI0 interrupt                                                 */
    SPI1_IRQn   = 0x1A,  /*!< SPI1 interrupt                                                 */
    SPI2_IRQn   = 0x1B,  /*!< SPI2 interrupt                                                 */
    I2C0_IRQn   = 0x1C,  /*!< I2C0 interrupt                                                 */
    I2C1_IRQn   = 0x1D,  /*!< I2C1 interrupt                                                 */
    USART0_IRQn = 0x1E,  /*!< USART0 interrupt                                               */
    USART1_IRQn = 0x1F,  /*!< USART1 interrupt                                               */
    USART2_IRQn = 0x20,  /*!< USART2 interrupt                                               */
    USART3_IRQn = 0x21,  /*!< USART3 interrupt                                               */
    TIM2_IRQn   = 0x22,  /*!< TIM2 interrupt                                                 */
    TIM3_IRQn   = 0x23,  /*!< TIM3 interrupt                                                 */
    TIM4_IRQn   = 0x24,  /*!< TIM4 interrupt                                                 */
    SPI3_IRQn   = 0x25,  /*!< SPI3 interrupt                                                 */
    SPI4_IRQn   = 0x26,  /*!< SPI4 interrupt                                                 */
    SPI5_IRQn   = 0x27,  /*!< SPI5 interrupt                                                 */
    I2C2_IRQn   = 0x28,  /*!< I2C2 interrupt                                                 */
    I2C3_IRQn   = 0x29,  /*!< I2C3 interrupt                                                 */
    USART4_IRQn = 0x2A,  /*!< USART4 interrupt                                               */
    USART5_IRQn = 0x2B,  /*!< USART5 interrupt                                               */
    USART6_IRQn = 0x2C,  /*!< USART6 interrupt                                               */
    USART7_IRQn = 0x2D,  /*!< USART7 interrupt                                               */
    TIM5_IRQn   = 0x2E,  /*!< TIM5 interrupt                                                 */
    TIM6_IRQn   = 0x2F,  /*!< TIM6 interrupt                                                 */
    TIM7_IRQn   = 0x30,  /*!< TIM7 interrupt                                                 */
    GPIOH_IRQn  = 0x31,  /*!< GPIOH interrupt                                                */
    RTC_IRQn    = 0x32   /*!< RTC interrupt                                                  */
} IRQn_Type;

/******************************************************************************
 *  PERIPHERAL REGISTER STRUCTURES
 *****************************************************************************/

/*
 * @brief MPU I-Port registers structure
 */
typedef struct
{
    __IO uint32 PTEN;     /* PTEN  Protection enable,  Address offset: 0x00 */
    __IO uint32 RPTEN;    /* RPTEN  Read protection enable,  Address offset: 0x04 */
    __IO uint32 RPTS;     /* RPTS  Read protection status,  Address offset: 0x08 */
} MPU_IPort_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(MPU_IPort_TypeDef) == 0x0CU, "MPU_IPort_TypeDef size mismatch!");
_Static_assert(offsetof(MPU_IPort_TypeDef, PTEN) == 0x00U, "MPU_IPort_TypeDef PTEN offset mismatch!");
_Static_assert(offsetof(MPU_IPort_TypeDef, RPTS) == 0x08U, "MPU_IPort_TypeDef RPTS offset mismatch!");

/*
 * @brief MPU / D-Port / P-Port registers structure
 */
typedef struct
{
    __IO uint32 PTEN;     /* PTEN  Protection enable,  Address offset: 0x00 */
    __IO uint32 WPTEN;    /* WPTEN  Write protection enable,  Address offset: 0x04 */
    __IO uint32 RPTEN;    /* RPTEN  Read protection enable,  Address offset: 0x08 */
    __IO uint32 WPTS;     /* WPTS  Write protection status,  Address offset: 0x0C */
    __IO uint32 RPTS;     /* RPTS  Read protection status,  Address offset: 0x10 */
} MPU_DPort_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(MPU_DPort_TypeDef) == 0x14U, "MPU_DPort_TypeDef size mismatch!");
_Static_assert(offsetof(MPU_DPort_TypeDef, PTEN) == 0x00U, "MPU_DPort_TypeDef PTEN offset mismatch!");
_Static_assert(offsetof(MPU_DPort_TypeDef, WPTS) == 0x0CU, "MPU_DPort_TypeDef WPTS offset mismatch!");
_Static_assert(offsetof(MPU_DPort_TypeDef, RPTS) == 0x10U, "MPU_DPort_TypeDef RPTS offset mismatch!");

typedef MPU_DPort_TypeDef MPU_PPort_TypeDef;

typedef MPU_DPort_TypeDef MPU_DMAPort_TypeDef;

/*
 * @brief MPU  Channel registers structure
 */
typedef struct
{
    __IO uint32 SADDR;    /* SADDR  Start address,  Address offset: 0x00 */
    __IO uint32 EADDR;    /* EADDR  End address,  Address offset: 0x04 */
} MPU_Channel_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(MPU_Channel_TypeDef) == 0x08U, "MPU_Channel_TypeDef size mismatch!");
_Static_assert(offsetof(MPU_Channel_TypeDef, SADDR) == 0x00U, "MPU_Channel_TypeDef SADDR offset mismatch!");
_Static_assert(offsetof(MPU_Channel_TypeDef, EADDR) == 0x04U, "MPU_Channel_TypeDef EADDR offset mismatch!");

/*
 * @brief FCU registers structure
 */
typedef struct
{
    __IO uint32 CFG[42];    /* FCU_CFGx  Config register,  Address offset: 0x00~0xA4 */
    __IO uint32 SFTR;       /* FCU_SFTR  Software Fault Trigger register,  Address offset: 0xA8 */
    __I uint32 SFSTA;       /* FCU_SFSTA  Software Fault Status register,  Address offset: 0xAC */
    __IO uint32 SFCNT;      /* FCU_SFCNT  Software Fault Count register,  Address offset: 0xB0 */
    __IO uint32 SFCLR;      /* FCU_SFCLR  Software Fault Clear register,  Address offset: 0xB4 */
    __I uint32 ALARM0;      /* FCU_ALARM0  Fault Alert register  Address offset: 0xB8*/
    __I uint32 ALARM1;      /* FCU_ALARM1  Fault Alert register  Address offset: 0xBC*/
    __I uint32 FAULT0;      /* FCU_FAULT0  Fault Source register  Address offset: 0xC0*/
    __I uint32 FAULT1;      /* FCU_FAULT1  Fault Source register  Address offset: 0xC4*/
    __IO uint32 CLEAR0;     /* FCU_CLEAR0  Fault/Alarm Clear register  Address offset: 0xC8*/
    __IO uint32 CLEAR1;     /* FCU_CLEAR1  Fault/Alarm Clear register  Address offset: 0xCC*/
    __IO uint32 OCLR;       /* FCU_OCLR  Bus Timeout/ECC Clear register  Address offset: 0xD0*/
} FCU_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(FCU_TypeDef) == 0xD4U, "FCU_TypeDef size mismatch!");
_Static_assert(offsetof(FCU_TypeDef, CFG) == 0x00U, "FCU_TypeDef CFG offset mismatch!");
_Static_assert(offsetof(FCU_TypeDef, SFTR) == 0xA8U, "FCU_TypeDef SFTR offset mismatch!");
_Static_assert(offsetof(FCU_TypeDef, FAULT0) == 0xC0U, "FCU_TypeDef FAULT0 offset mismatch!");

/*
 * @brief CMU registers structure
 */
typedef struct
{
    __IO uint32 CR;      /* CMU_cmuCR  Control register,  Address offset: 0x00 */
    __IO uint32 CCR;     /* CMU_cmuRCCR  Counter configuration register,  Address offset: 0x04 */
    __IO uint32 HTCR;    /* CMU_cmuHTCR  High threshold configuration register,  Address offset: 0x08 */
    __IO uint32 LTCR;    /* CMU_cmuLTCR  Low threshold configuration register,  Address offset: 0x0C */
    __IO uint32 SR;      /* CMU_cmuSR  Status register,  Address offset: 0x10 */
} CMU_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(CMU_TypeDef) == 0x14U, "CMU_TypeDef size mismatch!");
_Static_assert(offsetof(CMU_TypeDef, CR) == 0x00U, "CMU_TypeDef CR offset mismatch!");
_Static_assert(offsetof(CMU_TypeDef, CCR) == 0x04U, "CMU_TypeDef CCR offset mismatch!");
_Static_assert(offsetof(CMU_TypeDef, SR) == 0x10U, "CMU_TypeDef SR offset mismatch!");

/*
* @brief General Purpose DMA channel registers structure
*/
typedef struct
{
    __IO uint32 CHCTL;      /* DMA_CHCTL  DMA channel x configuration register,  Address offset: 0x00 */
    __IO uint32 CHCNT;      /* DMA_CHNT  DMA channel x number of data register,  Address offset: 0x04 */
    __IO uint32 CHPADDR;    /* DMA_CHPADDR DMA channel x peripheral address register, Address offset: 0x08 */
    __IO uint32 CHMADDR;    /* DMA_CHMADDR DMA channel x memory address register,  Address offset: 0x0C */
} DMA_Channel_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(DMA_Channel_TypeDef) == 0x10U, "DMA_Channel_TypeDef size mismatch!");
_Static_assert(offsetof(DMA_Channel_TypeDef, CHCTL) == 0x00U, "DMA_Channel_TypeDef CHCTL offset mismatch!");
_Static_assert(offsetof(DMA_Channel_TypeDef, CHMADDR) == 0x0CU, "DMA_Channel_TypeDef CHMADDR offset mismatch!");

/*
* @brief General Purpose DMA registers structure
*/
typedef struct
{
    __IO uint32 CHEN;              /* DMA_CHEN  DMA channel enable register,  Address offset: 0x00 */
    uint32 RESERVED[64];           /* Reserved,  Address offset: 0x04 - 0x100 */
    __IO uint32 PTCH0;             /* DMA_PTCH0  DMA peripheral interface register0,  Address offset: 0x104 */
    __IO uint32 PTCH1;             /* DMA_PTCH1  DMA peripheral interface register1,  Address offset: 0x108 */
    __IO uint32 CCR;               /* DMA_CCR  DMA control and status register,  Address offset: 0x10C */
    __IO uint32 ERR_INT_RAW;       /* DMA_ERR_INT_RAW  DMA error interrupt raw status register,  Address offset: 0x110 */
    __IO uint32 ERR_INT_FORCE;     /* DMA_ERR_INT_FORCE  DMA error interrupt force register,  Address offset: 0x114 */
    __IO uint32 ERR_INT_MASK;      /* DMA_ERR_INT_MASK  DMA error interrupt mask register,  Address offset: 0x118 */
    __IO uint32 ERR_INT_STATUS;    /* DMA_ERR_INT_STATUS  DMA error interrupt status register,  Address offset: 0x11C */
    __IO uint32 FTF_INT_RAW;       /* DMA_FTF_INT_RAW  DMA full transfer interrupt raw status register,  Address offset: 0x120 */
    __IO uint32 FTF_INT_FORCE;     /* DMA_FTF_INT_FORCE  DMA full transfer interrupt force register,  Address offset: 0x124 */
    __IO uint32 FTF_INT_MASK;      /* DMA_FTF_INT_MASK  DMA full transfer interrupt mask register,  Address offset: 0x128 */
    __IO uint32 FTF_INT_STATUS;    /* DMA_FTF_INT_STATUS  DMA full transfer interrupt status register,  Address offset: 0x12C */
    __IO uint32 HTF_INT_RAW;       /* DMA_HTF_INT_RAW  DMA half transfer interrupt raw status register,  Address offset: 0x130 */
    __IO uint32 HTF_INT_FORCE;     /* DMA_HTF_INT_FORCE  DMA half transfer interrupt force register,  Address offset: 0x134 */
    __IO uint32 HTF_INT_MASK;      /* DMA_HTF_INT_MASK  DMA half transfer interrupt mask register,  Address offset: 0x138 */
    __IO uint32 HTF_INT_STATUS;    /* DMA_HTF_INT_STATUS  DMA half transfer interrupt status register,  Address offset: 0x13C */
    __IO uint32 WDG_INT_RAW;       /* DMA_WDG_INT_RAW  DMA watchdog interrupt raw status register,  Address offset: 0x140 */
    __IO uint32 WDG_INT_FORCE;     /* DMA_WDG_INT_FORCE  DMA watchdog interrupt force register,  Address offset: 0x144 */
    __IO uint32 WDG_INT_MASK;      /* DMA_WDG_INT_MASK  DMA watchdog interrupt mask register,  Address offset: 0x148 */
    __IO uint32 WDG_INT_STATUS;    /* DMA_WDG_INT_STATUS  DMA watchdog interrupt status register,  Address offset: 0x14C */
} DMA_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(DMA_TypeDef) == 0x150U, "DMA_TypeDef size mismatch!");
_Static_assert(offsetof(DMA_TypeDef, CHEN) == 0x00U, "DMA_TypeDef CHEN offset mismatch!");
_Static_assert(offsetof(DMA_TypeDef, CCR) == 0x10CU, "DMA_TypeDef CCR offset mismatch!");
_Static_assert(offsetof(DMA_TypeDef, ERR_INT_STATUS) == 0x11CU, "DMA_TypeDef ERR_INT_STATUS offset mismatch!");
_Static_assert(offsetof(DMA_TypeDef, FTF_INT_STATUS) == 0x12CU, "DMA_TypeDef FTF_INT_STATUS offset mismatch!");

/*
 * @brief System Management Unit registers structure
 */
typedef struct
{
    __IO uint32 PLLCFGR;     /* SMU_pllCfgReg  PLL divide and reset configuration registers,  Address offset: 0x00 */
    __IO uint32 FIRCCFGR;    /* SMU_fircCfgReg  Internal clock and reset configuration registers,  Address offset: 0x04 */
    __IO uint32 BUSCFGR;     /* SMU_busClkDivReg  BUS clock and reset configuration registers,  Address offset: 0x08 */
    __I uint32 SR;           /* SMU_smuState  SMU state registers,  Address offset: 0x0C */
    __IO uint32 AB0CFGR;     /* SMU_ab0CfgReg  AB0 bus clock and reset configuration register,  Address offset: 0x10 */
    __IO uint32 AB1CFGR;     /* SMU_ab1CfgReg  AB1 bus clock and reset configuration register,  Address offset: 0x14 */
    __IO uint32 AB3CFGR;     /* SMU_ab3CfgReg  AB3 bus clock and reset configuration registers,  Address offset: 0x18 */
    __IO uint32 ALB0CFGR;    /* SMU_alb0CfgReg  ALB0 bus clock and reset configuration registers,  Address offset: 0x1C */
    __IO uint32 ALB1CFGR;    /* SMU_alb1CfgReg  ALB1 bus clock and reset configuration registers,  Address offset: 0x20 */
    __IO uint32 ALB2CFGR;    /* SMU_alb2CfgReg  ALB2 bus clock and reset configuration registers,  Address offset: 0x24 */
    __IO uint32 APB0CFGR;    /* SMU_apb0CfgReg  APB0 bus clock and reset configuration registers,  Address offset: 0x28 */
    __IO uint32 APB1CFGR;    /* SMU_apb1CfgReg  APB1 bus clock and reset configuration registers,  Address offset: 0x2c */
    __IO uint32 OTHCFGR;     /* SMU_othCfgReg  Other modules configuration registers,  Address offset: 0x30 */
    __IO uint32 BUSTCFGR;    /* SMU_busMonReg  BUS timeout configuration registers,  Address offset: 0x34 */
} SMU_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(SMU_TypeDef) == 0x38U, "SMU_TypeDef size mismatch!");
_Static_assert(offsetof(SMU_TypeDef, PLLCFGR) == 0x00U, "SMU_TypeDef PLLCFGR offset mismatch!");
_Static_assert(offsetof(SMU_TypeDef, ALB0CFGR) == 0x1CU, "SMU_TypeDef ALB0CFGR offset mismatch!");
_Static_assert(offsetof(SMU_TypeDef, BUSTCFGR) == 0x34U, "SMU_TypeDef BUSTCFGR offset mismatch!");

/*
 * @brief CLINT registers structure
 */
typedef struct
{
    __IO uint32 SOFTICR;       /* CLINT_SOFT  Soft interrupt control register,  Address offset: 0x0000 */
    uint32 RESERVED0[4095];    /* Reserved,  Address offset: 0x04 - 0x3FFC */
    __O uint32 CMPLR;          /* CLINT_CMP_L  Compare registers with lower 32 bits,  Address offset: 0x4000 */
    __O uint32 CMPHR;          /* CLINT_CMP_H  Compare registers with 32 higher bits,  Address offset: 0x4004 */
    uint32 RESERVED1[8188];    /* Reserved,  Address offset: 0x4008 - 0xBFF4 */
    __I uint32 RDTIMELR;       /* CLINT_DR_TIME_L  Real-time counter low 32 bit register,  Address offset: 0XBFF8 */
    __I uint32 RDTIMEHR;       /* CLINT_DR_TIME_H  Real-time counter high 32 bit register, Address offset: 0XBFFC */
} CLINT_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(CLINT_TypeDef) == 0xC000U, "CLINT_TypeDef size mismatch!");
_Static_assert(offsetof(CLINT_TypeDef, SOFTICR) == 0x0000U, "CLINT_TypeDef SOFTICR offset mismatch!");
_Static_assert(offsetof(CLINT_TypeDef, CMPLR) == 0x4000U, "CLINT_TypeDef CMPLR offset mismatch!");
_Static_assert(offsetof(CLINT_TypeDef, RDTIMELR) == 0xBFF8U, "CLINT_TypeDef RDTIMELR offset mismatch!");

/*
 * @brief PLIC registers structure
 */
typedef struct
{
    __IO uint32 AXI_PLIC_ID;              /* Interrupt source ID numer registers,  Address offset: 0x00 */
    __IO uint32 AXI_PLIC_PRIORITY[64];    /* Interrupt source priority register 0 - 63,  Address offset: 0x04 - 0x100 */
    __IO uint32 AXI_PLIC_EN[2];           /* Interrupt source enable registe 0 - 1,  Address offset: 0x0104 - 0x0108 */
} PLIC_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(PLIC_TypeDef) == 0x10CU, "PLIC_TypeDef size mismatch!");
_Static_assert(offsetof(PLIC_TypeDef, AXI_PLIC_ID) == 0x00U, "PLIC_TypeDef AXI_PLIC_ID offset mismatch!");
_Static_assert(offsetof(PLIC_TypeDef, AXI_PLIC_EN) == 0x104U, "PLIC_TypeDef AXI_PLIC_EN offset mismatch!");

/*
 * @brief CRC registers structure
 */
typedef struct
{
    __IO uint32 TR;        /* RRTC_TIME  RTC time register,  Address offset: 0x00 */
    __IO uint32 DR;        /* RRTC_DATE  RTC date register,  Address offset: 0x04 */
    __IO uint32 ALRMTR;    /* RRTC_TALRM  RTC alarm time register,  Address offset: 0x08 */
    __IO uint32 ALRMDR;    /* RRTC_DALRM  RTC alarm date register,  Address offset: 0x0C */
    __IO uint32 CR;        /* RRTC_CTRL  RTC control register,  Address offset: 0x10 */
    __IO uint32 WUCR;      /* RRTC_WKPC  RTC wake-up control register,  Address offset: 0x14 */
} RTC_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(RTC_TypeDef) == 0x18U, "RTC_TypeDef size mismatch!");
_Static_assert(offsetof(RTC_TypeDef, TR) == 0x00U, "RTC_TypeDef TR offset mismatch!");
_Static_assert(offsetof(RTC_TypeDef, CR) == 0x10U, "RTC_TypeDef CR offset mismatch!");

/*
 * @brief General Purpose I/O registers structure
 */
typedef struct
{
    __IO uint32 RWM0CR;     /* GPIO_RW0  Read/write mode control register 0,  Address offset: 0x00 */
    __IO uint32 IM0CR;      /* GPIO_IM0  Input mode control register 0,  Address offset: 0x04 */
    __IO uint32 OMCR;       /* GPIO_OM  Output mode control register,  Address offset: 0x08 */
    __IO uint32 OICR;       /* GPIO_OSTR0  Output intensity control register 0,  Address offset: 0x0C */
    __IO uint32 MI0SR;      /* GPIO_PM0  Multiplex interface select register 0,  Address offset: 0x10 */
    __IO uint32 MI1SR;      /* GPIO_PM1  Multiplex interface select register 1,  Address offset: 0x14 */
    __O uint32 OPBR;        /* GPIO_OBS  Output position bit register,  Address offset: 0x18 */
    __O uint32 OBCR;        /* GPIO_OBC  Output bit clear register,  Address offset: 0x1C */
    __O uint32 OBTR;        /* GPIO_OBT  Output bit flip register,  Address offset: 0x20 */
    __IO uint32 OCR;        /* GPIO_OC  Output control register,  Address offset: 0x24 */
    __I uint32 IRR;         /* GPIO_RD  Read interface register,  Address offset: 0x28 */
    __IO uint32 ITYPE0R;    /* GPIO_ITYPE0  Interrupt type register 0,  Address offset: 0x2C */
    __IO uint32 IRSR;       /* GPIO_INTCFG_INT_RAW  Interrupt Raw status Register,  Address offset: 0x30 */
    __IO uint32 IFR;        /* GPIO_intCfg_INT_FORCE  Interrupt Force Register,  Address offset: 0x34 */
    __IO uint32 IMR;        /* GPIO_intCfg_INT_MASK  Interrupt Mask Register,  Address offset: 0x38 */
    __IO uint32 ISR;        /* GPIO_intCfg_INT_STATUS Interrupt status Register,  Address offset: 0x3C */
} GPIO_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(GPIO_TypeDef) == 0x40U, "GPIO_TypeDef size mismatch!");
_Static_assert(offsetof(GPIO_TypeDef, OPBR) == 0x18U, "GPIO_TypeDef OPBR offset mismatch!");
_Static_assert(offsetof(GPIO_TypeDef, OBCR) == 0x1CU, "GPIO_TypeDef OBCR offset mismatch!");
_Static_assert(offsetof(GPIO_TypeDef, OBTR) == 0x20U, "GPIO_TypeDef OBTR offset mismatch!");
_Static_assert(offsetof(GPIO_TypeDef, OCR) == 0x24U, "GPIO_TypeDef OCR offset mismatch!");
_Static_assert(offsetof(GPIO_TypeDef, IRSR) == 0x30U, "GPIO_TypeDef IRSR offset mismatch!");
_Static_assert(offsetof(GPIO_TypeDef, IFR) == 0x34U, "GPIO_TypeDef IFR offset mismatch!");
_Static_assert(offsetof(GPIO_TypeDef, IMR) == 0x38U, "GPIO_TypeDef IMR offset mismatch!");
_Static_assert(offsetof(GPIO_TypeDef, ISR) == 0x3CU, "GPIO_TypeDef ISR offset mismatch!");

/*
 * @brief GPIOH mapping registers structure
 */
typedef struct
{
    __IO uint32 RWM0CR;     /* GPIO_RW0  Read/write mode control register 0,  Address offset: 0x00 */
    __IO uint32 IM0CR;      /* GPIO_IM0  Input mode control register 0,  Address offset: 0x04 */
    __IO uint32 OMCR;       /* GPIO_OM  Output mode control register,  Address offset: 0x08 */
    __IO uint32 OICR;       /* GPIO_OSTR0  Output intensity control register 0,  Address offset: 0x0C */
    __IO uint32 MI0SR;      /* GPIO_PM0  Multiplex interface select register 0,  Address offset: 0x10 */
    __O uint32 OPBR;        /* GPIO_OBS  Output position bit register,  Address offset: 0x14 */
    __O uint32 OBCR;        /* GPIO_OBC  Output bit clear register,  Address offset: 0x18 */
    __O uint32 OBTR;        /* GPIO_OBT  Output bit flip register,  Address offset: 0x1C */
    __IO uint32 OCR;        /* GPIO_OC  Output control register,  Address offset: 0x20 */
    __I uint32 IRR;         /* GPIO_RD  Read interface register,  Address offset: 0x24 */
    __IO uint32 ITYPE0R;    /* GPIO_ITYPE0  Interrupt type register 0,  Address offset: 0x28 */
    __IO uint32 IRSR;       /* GPIO_INTCFG_INT_RAW  Interrupt Raw status Register,  Address offset: 0x2C */
    __IO uint32 IFR;        /* GPIO_intCfg_INT_FORCE  Interrupt Force Register,  Address offset: 0x30 */
    __IO uint32 IMR;        /* GPIO_intCfg_INT_MASK  Interrupt Mask Register,  Address offset: 0x34 */
    __IO uint32 ISR;        /* GPIO_intCfg_INT_STATUS Interrupt status Register,  Address offset: 0x38 */
} GPIOHMAPPING_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(GPIOHMAPPING_TypeDef) == 0x3CU, "GPIOHMAPPING_TypeDef size mismatch!");
_Static_assert(offsetof(GPIOHMAPPING_TypeDef, OCR) == 0x20U, "GPIOHMAPPING_TypeDef OCR offset mismatch!");
_Static_assert(offsetof(GPIOHMAPPING_TypeDef, IRSR) == 0x2CU, "GPIOHMAPPING_TypeDef IRSR offset mismatch!");
_Static_assert(offsetof(GPIOHMAPPING_TypeDef, ISR) == 0x38U, "GPIOHMAPPING_TypeDef ISR offset mismatch!");

/*
 * @brief Power management unit registers structure
 */
typedef struct
{
    __IO uint32 LDOCR;    /* PMU_PW  PMU LDO configuration register,  Address offset: 0x00 */
    __I uint32 LDOSR;     /* PMU_PS  PMU LDO status register,  Address offset: 0x04 */
    __IO uint32 VDCR;     /* PMU_VD  PMU voltage detection configuration register,  Address offset: 0x08 */
    __IO uint32 OCR;      /* PMU_CA  PMU oscillator configuration register,  Address offset: 0x0C */
    __IO uint32 PMCR;     /* PMU_MODE  PMU power mode configuration register,  Address offset: 0x10 */
    __IO uint32 WKFR;     /* PMU_WKP  PMU wake up flag register,  Address offset: 0x14 */
    __IO uint32 WKEN;     /* PMU_WKEN  PMU wake up channel enable register,  Address offset: 0x18 */
} PMU_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(PMU_TypeDef) == 0x1CU, "PMU_TypeDef size mismatch!");
_Static_assert(offsetof(PMU_TypeDef, LDOCR) == 0x00U, "PMU_TypeDef LDOCR offset mismatch!");
_Static_assert(offsetof(PMU_TypeDef, PMCR) == 0x10U, "PMU_TypeDef PMCR offset mismatch!");
_Static_assert(offsetof(PMU_TypeDef, WKEN) == 0x18U, "PMU_TypeDef WKEN offset mismatch!");

/*
 * @brief IWDG registers structure
 */
typedef struct
{
    __IO uint32 PSC;    /* PSC  Prescaler,  Address offset: 0x00 */
    __IO uint32 CFG;    /* CFG  Configuration,  Address offset: 0x04 */
    __IO uint32 DIV;    /* DIV  Divider,  Address offset: 0x08 */
    __IO uint32 TO;     /* TO  Timeout,  Address offset: 0x0C */
    __I uint32 CNT;     /* CNT  Counter,  Address offset: 0x10 */
    __IO uint32 CLR;    /* CLR  Clear,  Address offset: 0x14 */
} IWDG_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(IWDG_TypeDef) == 0x18U, "IWDG_TypeDef size mismatch!");
_Static_assert(offsetof(IWDG_TypeDef, PSC) == 0x00U, "IWDG_TypeDef PSC offset mismatch!");
_Static_assert(offsetof(IWDG_TypeDef, CLR) == 0x14U, "IWDG_TypeDef CLR offset mismatch!");

/*
 * @brief Timer registers structure
 */
typedef struct
{
    __IO uint32 CR1;      /* TIMx control register 1,  Address offset: 0x00 */
    __IO uint32 CR2;      /* TIMx control register 2,  Address offset: 0x04 */
    __IO uint32 SMCR;     /* TIMx slave mode control register,  Address offset: 0x08 */
    __IO uint32 DIER;     /* TIMx DMA/interrupt enable register,  Address offset: 0x0C */
    __IO uint32 SR;       /* TIMx status register,  Address offset: 0x10 */
    __IO uint32 EGR;      /* TIMx event generation register,  Address offset: 0x14 */
    __IO uint32 CCMR1;    /* TIMx capture/compare mode register 1,  Address offset: 0x18 */
    __IO uint32 CCMR2;    /* TIMx capture/compare mode register 2,  Address offset: 0x1C */
    __IO uint32 CCMR3;    /* TIMx capture/compare mode register 3,  Address offset: 0x20 */
    __IO uint32 CCER;     /* TIMx capture/compare enable register,  Address offset: 0x24 */
    __IO uint32 CNT;      /* TIMx counter,  Address offset: 0x28 */
    __IO uint32 PSC;      /* TIMx prescaler,  Address offset: 0x2C */
    __IO uint32 ARR;      /* TIMx auto-reload register,  Address offset: 0x30 */
    __IO uint32 RCR;      /* TIMx repetition counter register,  Address offset: 0x34 */
    __IO uint32 CCR1;     /* TIMx capture/compare register 1,  Address offset: 0x38 */
    __IO uint32 CCR2;     /* TIMx capture/compare register 2,  Address offset: 0x3C */
    __IO uint32 CCR3;     /* TIMx capture/compare register 3,  Address offset: 0x40 */
    __IO uint32 CCR4;     /* TIMx capture/compare register 4,  Address offset: 0x44 */
    __IO uint32 CCR5;     /* TIMx capture/compare register 5,  Address offset: 0x48 */
    __IO uint32 CCR6;     /* TIMx capture/compare register 6,  Address offset: 0x4C */
    __IO uint32 BDTR;     /* TIMx break and dead-time register,  Address offset: 0x50 */
    __IO uint32 DCR;      /* TIMx DMA control register,  Address offset: 0x54 */
    __IO uint32 DMAR;     /* TIMx DMA address for full transfer,  Address offset: 0x58 */
    __IO uint32 AF1;      /* TIMx alternate function option register 1,  Address offset: 0x5C */
} TIM_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(TIM_TypeDef) == 0x60U, "TIM_TypeDef size mismatch!");
_Static_assert(offsetof(TIM_TypeDef, CR1) == 0x00U, "TIM_TypeDef CR1 offset mismatch!");
_Static_assert(offsetof(TIM_TypeDef, DIER) == 0x0CU, "TIM_TypeDef DIER offset mismatch!");
_Static_assert(offsetof(TIM_TypeDef, SR) == 0x10U, "TIM_TypeDef SR offset mismatch!");
_Static_assert(offsetof(TIM_TypeDef, CCMR1) == 0x18U, "TIM_TypeDef CCMR1 offset mismatch!");
_Static_assert(offsetof(TIM_TypeDef, CNT) == 0x28U, "TIM_TypeDef CNT offset mismatch!");
_Static_assert(offsetof(TIM_TypeDef, PSC) == 0x2CU, "TIM_TypeDef PSC offset mismatch!");
_Static_assert(offsetof(TIM_TypeDef, ARR) == 0x30U, "TIM_TypeDef ARR offset mismatch!");
_Static_assert(offsetof(TIM_TypeDef, CCR1) == 0x38U, "TIM_TypeDef CCR1 offset mismatch!");
_Static_assert(offsetof(TIM_TypeDef, BDTR) == 0x50U, "TIM_TypeDef BDTR offset mismatch!");

/*
 * @brief CAN FD transmit message registers structure
 */
typedef struct
{
    __IO uint32 TB_ID;      /* TB*-ID Register.  Address offset: 0x100, 0x148 ... */
    __IO uint32 TB_DLC;     /* TB*-DLC Register.  Address offset: 0x104, 0x14C ... */
    __IO uint32 TB_DW0;     /* TB*-DW0 Register.  Address offset: 0x108, 0x150 ... */
    __IO uint32 TB_DW1;     /* TB*-DW1 Register.  Address offset: 0x10C, 0x154 ... */
    __IO uint32 TB_DW2;     /* TB*-DW2 Register.  Address offset: 0x110, 0x158 ... */
    __IO uint32 TB_DW3;     /* TB*-DW3 Register.  Address offset: 0x114, 0x15C ... */
    __IO uint32 TB_DW4;     /* TB*-DW4 Register.  Address offset: 0x118, 0x160 ... */
    __IO uint32 TB_DW5;     /* TB*-DW5 Register.  Address offset: 0x11C, 0x164 ... */
    __IO uint32 TB_DW6;     /* TB*-DW6 Register.  Address offset: 0x120, 0x168 ... */
    __IO uint32 TB_DW7;     /* TB*-DW7 Register.  Address offset: 0x124, 0x16C ... */
    __IO uint32 TB_DW8;     /* TB*-DW8 Register.  Address offset: 0x128, 0x170 ... */
    __IO uint32 TB_DW9;     /* TB*-DW9 Register.  Address offset: 0x12C, 0x174 ... */
    __IO uint32 TB_DW10;    /* TB*-DW10 Register.  Address offset: 0x130, 0x178 ... */
    __IO uint32 TB_DW11;    /* TB*-DW11 Register.  Address offset: 0x134, 0x17C ... */
    __IO uint32 TB_DW12;    /* TB*-DW12 Register.  Address offset: 0x138, 0x180 ... */
    __IO uint32 TB_DW13;    /* TB*-DW13 Register.  Address offset: 0x13C, 0x184 ... */
    __IO uint32 TB_DW14;    /* TB*-DW14 Register.  Address offset: 0x140, 0x188 ... */
    __IO uint32 TB_DW15;    /* TB*-DW15 Register.  Address offset: 0x144, 0x18C ... */
} CANFD_TxMessageTypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(CANFD_TxMessageTypeDef) == 0x48U, "CANFD_TxMessageTypeDef size mismatch!");
_Static_assert(offsetof(CANFD_TxMessageTypeDef, TB_ID) == 0x00U, "CANFD_TxMessageTypeDef TB_ID offset mismatch!");
_Static_assert(offsetof(CANFD_TxMessageTypeDef, TB_DW0) == 0x08U, "CANFD_TxMessageTypeDef TB_DW0 offset mismatch!");

/*
 * @brief CAN FD receive filter registers structure
 */
typedef struct
{
    __IO uint32 AFMR;    /* Acceptance Filter Mask registers.  Address offset: 0xA00, 0xA08 ... */
    __IO uint32 AFIR;    /* Acceptance Filter ID registers.  Address offset: 0xA04, 0xA0C ... */
} CANFD_RxfilterTypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(CANFD_RxfilterTypeDef) == 0x08U, "CANFD_RxfilterTypeDef size mismatch!");
_Static_assert(offsetof(CANFD_RxfilterTypeDef, AFMR) == 0x00U, "CANFD_RxfilterTypeDef AFMR offset mismatch!");
_Static_assert(offsetof(CANFD_RxfilterTypeDef, AFIR) == 0x04U, "CANFD_RxfilterTypeDef AFIR offset mismatch!");

/*
 * @brief CAN FD receive message registers structure
 */
typedef struct
{
    __I uint32 RB_ID;      /* RB*-ID Register.  Address offset: 0x2100, 0x2148 ... */
    __I uint32 RB_DLC;     /* RB*-DLC Register.  Address offset: 0x2104, 0x214C ... */
    __I uint32 RB_DW0;     /* RB*-DW0 Register.  Address offset: 0x2108, 0x2150 ... */
    __I uint32 RB_DW1;     /* RB*-DW1 Register.  Address offset: 0x210C, 0x2154 ... */
    __I uint32 RB_DW2;     /* RB*-DW2 Register.  Address offset: 0x2110, 0x2158 ... */
    __I uint32 RB_DW3;     /* RB*-DW3 Register.  Address offset: 0x2114, 0x215C ... */
    __I uint32 RB_DW4;     /* RB*-DW4 Register.  Address offset: 0x2118, 0x2160 ... */
    __I uint32 RB_DW5;     /* RB*-DW5 Register.  Address offset: 0x211C, 0x2164 ... */
    __I uint32 RB_DW6;     /* RB*-DW6 Register.  Address offset: 0x2120, 0x2168 ... */
    __I uint32 RB_DW7;     /* RB*-DW7 Register.  Address offset: 0x2124, 0x216C ... */
    __I uint32 RB_DW8;     /* RB*-DW8 Register.  Address offset: 0x2128, 0x2170 ... */
    __I uint32 RB_DW9;     /* RB*-DW9 Register.  Address offset: 0x212C, 0x2174 ... */
    __I uint32 RB_DW10;    /* RB*-DW10 Register.  Address offset: 0x2130, 0x2178 ... */
    __I uint32 RB_DW11;    /* RB*-DW11 Register.  Address offset: 0x2134, 0x217C ... */
    __I uint32 RB_DW12;    /* RB*-DW12 Register.  Address offset: 0x2138, 0x2180 ... */
    __I uint32 RB_DW13;    /* RB*-DW13 Register.  Address offset: 0x213C, 0x2184 ... */
    __I uint32 RB_DW14;    /* RB*-DW14 Register.  Address offset: 0x2140, 0x2188 ... */
    __I uint32 RB_DW15;    /* RB*-DW15 Register.  Address offset: 0x2144, 0x218C ... */
} CANFD_RxMessageTypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(CANFD_RxMessageTypeDef) == 0x48U, "CANFD_RxMessageTypeDef size mismatch!");
_Static_assert(offsetof(CANFD_RxMessageTypeDef, RB_ID) == 0x00U, "CANFD_RxMessageTypeDef RB_ID offset mismatch!");
_Static_assert(offsetof(CANFD_RxMessageTypeDef, RB_DW0) == 0x08U, "CANFD_RxMessageTypeDef RB_DW0 offset mismatch!");

/*
 * @brief CAN FD controller registers structure
 */
typedef struct
{
    __IO uint32 SRR;                          /* Software Reset Register.  Address offset: 0x00 */
    __IO uint32 MSR;                          /* Mode Select Register.  Address offset: 0x04 */
    __IO uint32 APBRPR;                       /* Arbitration Phase (Nominal) Baud Rate Prescaler Register.  Address offset: 0x08 */
    __IO uint32 APBTR;                        /* Arbitration Phase (Nominal) Bit Timing Register.  Address offset: 0x0C */
    __I uint32 ECR;                           /* Error Count Register.  Address offset: 0x10 */
    __IO uint32 ESR;                          /* Error Status Register.  Address offset: 0x14 */
    __I uint32 SR;                            /* Status Register.  Address offset: 0x18 */
    __I uint32 ISR;                           /* Interrupt Status Register.  Address offset: 0x1C */
    __IO uint32 IER;                          /* Interrupt Enable Register.  Address offset: 0x20 */
    __O uint32 ICR;                           /* Interrupt Clear Register.  Address offset: 0x24 */
    __IO uint32 TSR;                          /* Timestamp Register.  Address offset: 0x28 */
    uint32 RESERVED0[23];                     /* Reserved.  Address offset: 0x2C - 0x84 */
    __IO uint32 DPBRPR;                       /* Data Phase Baud Rate Prescaler Register.  Address offset: 0x88 */
    __IO uint32 DPBTR;                        /* Data Phase Bit Timing Register.  Address offset: 0x8C */
    __IO uint32 TRR;                          /* TX Buffer Ready Request Register.  Address offset: 0x90 */
    __IO uint32 ERRS;                         /* Interrupt Enable TX Buffer Ready Request Served/Cleared.  Address offset: 0x94 */
    __IO uint32 TCR;                          /* TX Buffer Cancel Request.  Address offset: 0x98 */
    __IO uint32 ECRS;                         /* Interrupt Enable TX Buffer Cancellation Served/Cleared.  Address offset: 0x9C */
    uint32 RESERVED6;                         /* Reserved.  Address offset: 0xA0 */
    uint32 RESERVED1[15];                     /* Reserved.  Address offset: 0xA4 - 0xDC */
    __IO uint32 AFR;                          /* Acceptance Filter (Control) Register.  Address offset: 0xE0 */
    uint32 RESERVED2;                         /* Reserved.  Address offset: 0xE4 */
    __IO uint32 RFSR;                         /* RX FIFO Status Register.  Address offset: 0xE8 */
    uint32 RESERVED3[5];                      /* Reserved.  Address offset: 0xEC - 0xFC */
    CANFD_TxMessageTypeDef TxMessage[32];     /* CAN FD TX Message Space Register Descriptions.  Address offset: 0x100 - 0x9FC */
    CANFD_RxfilterTypeDef Rxfiltering[32];    /* ID Filter-Mask Pairs.  Address offset: 0xA00 - 0xAFC */
    uint32 RESERVED4[1344];                   /* Reserved.  Address offset: 0xB00 - 0x1FFC */
    uint32 RESERVED5[64];                     /* Reserved.  Address offset: 0x2000 - 0x20FC */
    CANFD_RxMessageTypeDef RxMessage[64];     /* CAN FD RX Message Space (Sequential/FIFO Buffers-RX FIFO) Register Descriptions.  Address offset: 0x2100 - 0x32FC */
} CANFD_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(CANFD_TypeDef) == 0x3300U, "CANFD_TypeDef size mismatch!");
_Static_assert(offsetof(CANFD_TypeDef, SR) == 0x18U, "CANFD_TypeDef SR offset mismatch!");
_Static_assert(offsetof(CANFD_TypeDef, ISR) == 0x1CU, "CANFD_TypeDef ISR offset mismatch!");
_Static_assert(offsetof(CANFD_TypeDef, IER) == 0x20U, "CANFD_TypeDef IER offset mismatch!");
_Static_assert(offsetof(CANFD_TypeDef, TRR) == 0x90U, "CANFD_TypeDef TRR offset mismatch!");
_Static_assert(offsetof(CANFD_TypeDef, AFR) == 0xE0U, "CANFD_TypeDef AFR offset mismatch!");
_Static_assert(offsetof(CANFD_TypeDef, RFSR) == 0xE8U, "CANFD_TypeDef RFSR offset mismatch!");

/* @name ADC registers constants */
#define ADC_CLOCK_FREQ_MAX_RUNTIME (40000000U)  /* Maximum runtime clock frequency (Hz) */
#define ADC_REGULAR_SEQ_NUM (16U)               /* Number of regular sequence channels */
#define ADC_INJECT_SEQ_NUM (4U)                 /* Number of injected sequence channels */
#define ADC_SAMPLE_REG_NUM (3U)                 /* Number of sample time registers */

/*
 * @brief Analog to digital converter registers structure
 */
typedef struct
{
    __IO uint32 STATE;                        /* ADC Status Register,  Address offset: 0x00 */
    __IO uint32 CTRL0;                        /* ADC Control Register 0,  Address offset: 0x04 */
    __IO uint32 CTRL1;                        /* ADC Control Register 1,  Address offset: 0x08 */
    __IO uint32 AMOCR;                        /* ADC Analog monitor Configure Register,  Address offset: 0x0C */
    __IO uint32 AMOHR;                        /* ADC AMO High Threshold Register,  Address offset: 0x10 */
    __IO uint32 AMOLR;                        /* ADC AMO Low Threshold Register,  Address offset: 0x14 */
    __IO uint32 SPT[ADC_SAMPLE_REG_NUM];      /* ADC Sample Time Selection Register,  Address offset: 0x18 - 0x20 */
    __IO uint32 CONFIG;                       /* ADC Configure Register,  Address offset: 0x24 */
    __IO uint32 SQL;                          /* ADC Regular Sequence Length Register,  Address offset: 0x28 */
    uint32 RESERVED0;                         /* ADC Reserved,  Address offset: 0x2C */
    __IO uint32 IOFR[ADC_INJECT_SEQ_NUM];     /* ADC Injection Group Offset Register,  Address offset: 0x30 - 0x3C */
    __IO uint32 RSQR[ADC_REGULAR_SEQ_NUM];    /* ADC Regular Group Sequence Configure Register,  Address offset: 0x40 - 0x7C */
    __IO uint32 ISQR[ADC_INJECT_SEQ_NUM];     /* ADC Injection Group Sequence Configure Register, Address offset: 0x80 - 0x8C */
    __I uint32 RDR[ADC_REGULAR_SEQ_NUM];      /* ADC Regular Group Data Register,  Address offset: 0x90 - 0xCC */
    __I uint32 IDR[ADC_INJECT_SEQ_NUM];       /* ADC Injection Group Data Register,  Address offset: 0xD0 - 0xDC */
} ADC_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(ADC_TypeDef) == 0xE0U, "ADC_TypeDef size mismatch!");
_Static_assert(offsetof(ADC_TypeDef, STATE) == 0x00U, "ADC_TypeDef STATE offset mismatch!");
_Static_assert(offsetof(ADC_TypeDef, CTRL0) == 0x04U, "ADC_TypeDef CTRL0 offset mismatch!");
_Static_assert(offsetof(ADC_TypeDef, CONFIG) == 0x24U, "ADC_TypeDef CONFIG offset mismatch!");
_Static_assert(offsetof(ADC_TypeDef, RSQR) == 0x40U, "ADC_TypeDef RSQR offset mismatch!");
_Static_assert(offsetof(ADC_TypeDef, ISQR) == 0x80U, "ADC_TypeDef ISQR offset mismatch!");
_Static_assert(offsetof(ADC_TypeDef, RDR) == 0x90U, "ADC_TypeDef RDR offset mismatch!");

/*
 * @brief Digital to analog converter registers structure
 */
typedef struct
{
    __IO uint8 CTRL;        /* DAC Control Register,  Address offset: 0x00 */
    uint8 RESERVED0[3];     /* DAC Reserved,  Address offset: 0x01 - 0x03 */
    __IO uint8 DOUT;        /* DAC Data Register,  Address offset: 0x04 */
    uint8 RESERVED1[3];     /* DAC Reserved,  Address offset: 0x05 - 0x07 */
    __IO uint8 CLK_DIV;     /* DAC Clock Division Register,  Address offset: 0x08 */
    uint8 RESERVED2[3];     /* DAC Reserved,  Address offset: 0x09 - 0x0B */
    __IO uint8 CMP_CTRL;    /* DAC Comparator Control Register,  Address offset: 0x0C */
    uint8 RESERVED3[3];     /* DAC Reserved,  Address offset: 0x0D - 0x0F */
} DAC_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(DAC_TypeDef) == 0x10U, "DAC_TypeDef size mismatch!");
_Static_assert(offsetof(DAC_TypeDef, CTRL) == 0x00U, "DAC_TypeDef CTRL offset mismatch!");
_Static_assert(offsetof(DAC_TypeDef, DOUT) == 0x04U, "DAC_TypeDef DOUT offset mismatch!");
_Static_assert(offsetof(DAC_TypeDef, CMP_CTRL) == 0x0CU, "DAC_TypeDef CMP_CTRL offset mismatch!");

/*
 * @brief Security algorithm coprocessor registers structure
 */
typedef struct
{
    __IO uint32 IRQ_EN;           /* SPACC Interrupt Enable Register,  Address offset: 0x00 */
    __IO uint32 IRQ_STAT;         /* SPACC Interrupt Status Register,  Address offset: 0x04 */
    __IO uint32 IRQ_CTRL;         /* SPACC Interrupt Control Register,  Address offset: 0x08 */
    __IO uint32 FIFO_STAT;        /* SPACC FIFO Status Register,  Address offset: 0x0C */
    __IO uint32 RESERVED0[4];     /* SPACC Reserved,  Address offset: 0x10 - 0x1C */
    __IO uint32 SRC_PTR;          /* SPACC Source Pointer Register,  Address offset: 0x20 */
    __IO uint32 DST_PTR;          /* SPACC Destination Pointer Register,  Address offset: 0x24 */
    __IO uint32 OFFSET;           /* SPACC Offset Register,  Address offset: 0x28 */
    __IO uint32 PRE_AAD_LEN;      /* SPACC Prefixed AAD Length Register,  Address offset: 0x2C */
    __IO uint32 POST_AAD_LEN;     /* SPACC Postfixed AAD Length Register,  Address offset: 0x30 */
    __IO uint32 PROC_LEN;         /* SPACC Packet Length Register,  Address offset: 0x34 */
    __IO uint32 ICV_LEN;          /* SPACC ICV Length Register,  Address offset: 0x38 */
    __IO uint32 ICV_OFFSET;       /* SPACC ICV Offset Register,  Address offset: 0x3C */
    __IO uint32 IV_OFFSET;        /* SPACC IV Offset Register,  Address offset: 0x40 */
    __IO uint32 SW_CTRL;          /* SPACC Software Control Register,  Address offset: 0x44 */
    __IO uint32 AUX_INFO;         /* SPACC Auxiliary Information Register,  Address offset: 0x48 */
    __IO uint32 CTRL;             /* SPACC Control Register,  Address offset: 0x4C */
    __IO uint32 STAT_POP;         /* SPACC Status FIFO POP Register,  Address offset: 0x50 */
    __IO uint32 STATUS;           /* SPACC Status FIFO Register,  Address offset: 0x54 */
    __IO uint32 RESERVED1[10];    /* SPACC Reserved,  Address offset: 0x58 - 0x7C */
    __IO uint32 STAT_WD_CTRL;     /* SPACC Status Watchdog Register,  Address offset: 0x80 */
    __IO uint32 RESERVED2[31];    /* SPACC Reserved,  Address offset: 0x84 - 0xFC */
    __IO uint32 KEY_SZ;           /* SPACC Key Size Register,  Address offset: 0x100 */
} SPACC_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(SPACC_TypeDef) == 0x104U, "SPACC_TypeDef size mismatch!");
_Static_assert(offsetof(SPACC_TypeDef, IRQ_EN) == 0x00U, "SPACC_TypeDef IRQ_EN offset mismatch!");
_Static_assert(offsetof(SPACC_TypeDef, CTRL) == 0x4CU, "SPACC_TypeDef CTRL offset mismatch!");
_Static_assert(offsetof(SPACC_TypeDef, KEY_SZ) == 0x100U, "SPACC_TypeDef KEY_SZ offset mismatch!");

/*
 * @note  STACK_PNTR (offset 0x10) is not listed as its own register section in
 *        the chip manual, but the manual does confirm the register exists: the
 *        control / status block is 384 bytes and therefore covers 0x10, the PKA
 *        worked example clears the F-Stack by writing *, and the RTN_CODE
 *        description requires clearing the register after an abnormal stop.
 *        The member and its bit block are therefore kept.
 * @brief Public key accelerator registers structure
 */
typedef struct
{
    __IO uint32 CTRL;               /* PKA Control Register,  Address offset: 0x00 */
    __IO uint32 ENTRY_PNT;          /* PKA Program Entry Point Register,  Address offset: 0x04 */
    __IO uint32 RTN_CODE;           /* PKA Return Code Register,  Address offset: 0x08 */
    __IO uint32 RESERVED0;          /* PKA Reserved,  Address offset: 0x0C */
    __IO uint32 STACK_PNTR;         /* PKA Stack Pointer (F-Stack) Register,  Address offset: 0x10 */
    __IO uint32 INSTR_SINCE_GO;     /* PKA Instructions Since GO Register,  Address offset: 0x14 */
    __IO uint32 RESERVED1;          /* PKA Reserved,  Address offset: 0x18 */
    __IO uint32 CONFIG;             /* Sets Configuration State Within The PKA,  Address offset: 0x1C */
    __IO uint32 STAT;               /* PKA Status Register,  Address offset: 0x20 */
    __IO uint32 FLAGS;              /* PKA Falgs Register,  Address offset: 0x24 */
    __IO uint32 WATCHDOG;           /* PKA Watchdog Register,  Address offset: 0x28 */
    __IO uint32 CYCLES_SINCE_GO;    /* PKA Cycles Since GO Register,  Address offset: 0x2C */
    __IO uint32 RESERVED2[4];       /* PKA Reserved,  Address offset: 0x30 - 0x3C */
    __IO uint32 IRQ_EN;             /* PKA Interrupt Enable Register,  Address offset: 0x40 */
} PKA_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(PKA_TypeDef) == 0x44U, "PKA_TypeDef size mismatch!");
_Static_assert(offsetof(PKA_TypeDef, CTRL) == 0x00U, "PKA_TypeDef CTRL offset mismatch!");
_Static_assert(offsetof(PKA_TypeDef, CONFIG) == 0x1CU, "PKA_TypeDef CONFIG offset mismatch!");
_Static_assert(offsetof(PKA_TypeDef, IRQ_EN) == 0x40U, "PKA_TypeDef IRQ_EN offset mismatch!");

/*
 * @brief True random number generator registers structure
 */
typedef struct
{
    __IO uint32 CTRL;            /* TRNG Control Register,  Address offset: 0x00 */
    __IO uint32 RESERVED0[3];    /* TRNG Reserved,  Address offset: 0x04 - 0x0C */
    __IO uint32 IE;              /* TRNG Interrupt Enable Register,  Address offset: 0x10 */
    __IO uint32 ISTAT;           /* TRNG Interrupt Status Register,  Address offset: 0x14 */
    __IO uint32 RESERVED1[3];    /* TRNG Reserved,  Address offset: 0x18 - 0x20 */
    __I uint32 RAND0;            /* TRNG Random Number Register 0,  Address offset: 0x24 */
    __I uint32 RAND1;            /* TRNG Random Number Register 1,  Address offset: 0x28 */
    __I uint32 RAND2;            /* TRNG Random Number Register 2,  Address offset: 0x2C */
    __I uint32 RAND3;            /* TRNG Random Number Register 3,  Address offset: 0x30 */
} TRNG_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(TRNG_TypeDef) == 0x34U, "TRNG_TypeDef size mismatch!");
_Static_assert(offsetof(TRNG_TypeDef, CTRL) == 0x00U, "TRNG_TypeDef CTRL offset mismatch!");
_Static_assert(offsetof(TRNG_TypeDef, IE) == 0x10U, "TRNG_TypeDef IE offset mismatch!");
_Static_assert(offsetof(TRNG_TypeDef, ISTAT) == 0x14U, "TRNG_TypeDef ISTAT offset mismatch!");
_Static_assert(offsetof(TRNG_TypeDef, RAND0) == 0x24U, "TRNG_TypeDef RAND0 offset mismatch!");

/*
 * @brief Embedded flash controller registers structure
 */
typedef struct
{
    __IO uint32 SR;         /* EFLASH_STATE  EFlash state register,  Address offset: 0x00 */
    __IO uint32 UNLKR;      /* EFLASH_KEY  EFlash Unlock register,  Address offset: 0x04 */
    __IO uint32 CR;         /* EFLASH_CNFG  EFlash configuration register,  Address offset: 0x08 */
    __IO uint32 CIDR;       /* EFLASH_CMD  EFlash command ID register,  Address offset: 0x0C */
    __IO uint32 AR;         /* EFLASH_ADDR  EFlash address register,  Address offset: 0x10 */
    __IO uint32 DLR;        /* EFLASH_LEN  EFlash Data length register,  Address offset: 0x14 */
    uint32 RESERVED0[2];    /* Reserved,  Address offset: 0x18 - 0x1C */
    __IO uint32 DR0;        /* EFLASH_DATA0  EFlash data register 0,  Address offset: 0x20 */
    __IO uint32 DR1;        /* EFLASH_DATA1  EFlash data register 1,  Address offset: 0x24 */
    uint32 RESERVED1[2];    /* Reserved,  Address offset: 0x28 - 0x2C */
    __IO uint32 CTR;        /* EFLASH_START  EFlash command triggers register,  Address offset: 0x30 */
    __IO uint32 PWPR;       /* EFLASH_PPROT  EFlash P-Flash Write protected register,  Address offset: 0x34 */
    __IO uint32 DWPR;       /* EFLASH_DPROT  EFlash D-Flash Write protected register,  Address offset: 0x38 */
    __IO uint32 EAR;        /* EFLASH_ECC_ADDR  EFlash ECC 2-bit error address register,  Address offset: 0x3C */
    __I uint32 SECR;        /* EFLASH_SEC  EFlash security register,  Address offset: 0x40 */
    __IO uint32 SECKEY0;    /* EFLASH_SECKEY0  EFlash security key register 0,  Address offset: 0x44 */
    __IO uint32 SECKEY1;    /* EFLASH_SECKEY1  EFlash security key register 1,  Address offset: 0x48 */
} FLASH_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(FLASH_TypeDef) == 0x4CU, "FLASH_TypeDef size mismatch!");
_Static_assert(offsetof(FLASH_TypeDef, SR) == 0x00U, "FLASH_TypeDef SR offset mismatch!");
_Static_assert(offsetof(FLASH_TypeDef, CR) == 0x08U, "FLASH_TypeDef CR offset mismatch!");
_Static_assert(offsetof(FLASH_TypeDef, CIDR) == 0x0CU, "FLASH_TypeDef CIDR offset mismatch!");
_Static_assert(offsetof(FLASH_TypeDef, AR) == 0x10U, "FLASH_TypeDef AR offset mismatch!");
_Static_assert(offsetof(FLASH_TypeDef, DLR) == 0x14U, "FLASH_TypeDef DLR offset mismatch!");
_Static_assert(offsetof(FLASH_TypeDef, DR0) == 0x20U, "FLASH_TypeDef DR0 offset mismatch!");
_Static_assert(offsetof(FLASH_TypeDef, CTR) == 0x30U, "FLASH_TypeDef CTR offset mismatch!");
_Static_assert(offsetof(FLASH_TypeDef, SECR) == 0x40U, "FLASH_TypeDef SECR offset mismatch!");

/*
 * @brief QSPI registers structure
 */
typedef struct
{
    __IO uint32 CR;       /* QSPI_CR  QSPI control register,  Address offset: 0x00 */
    __IO uint32 CCR;      /* QSPI_CCR  QSPI communication configuration register,  Address offset: 0x04 */
    __I uint32 SR;        /* QSPI_SR  QSPI status register,  Address offset: 0x08 */
    __O uint32 FCR;       /* QSPI_FCR  QSPI flag clear register,  Address offset: 0x0C */
    __IO uint32 AR;       /* QSPI_AR  QSPI address register,  Address offset: 0x10 */
    __IO uint32 ABR;      /* QSPI_ABR  QSPI alternate byte register,  Address offset: 0x14 */
    __IO uint32 DR;       /* QSPI_DR  QSPI data register,  Address offset: 0x18 */
    __IO uint32 DLR;      /* QSPI_DLR  QSPI data length register,  Address offset: 0x1C */
    __IO uint32 TOR;      /* QSPI_TOR  QSPI timeout register,  Address offset: 0x20 */
    __IO uint32 PIR;      /* QSPI_PIR  QSPI polling interval register,  Address offset: 0x24 */
    __IO uint32 PSMAR;    /* QSPI_PSMAR  QSPI polling status matching register,  Address offset: 0x28 */
    __IO uint32 PSMKR;    /* QSPI_PSMKR  QSPI polling status mask register,  Address offset: 0x2C */
} QSPI_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(QSPI_TypeDef) == 0x30U, "QSPI_TypeDef size mismatch!");
_Static_assert(offsetof(QSPI_TypeDef, CR) == 0x00U, "QSPI_TypeDef CR offset mismatch!");
_Static_assert(offsetof(QSPI_TypeDef, CCR) == 0x04U, "QSPI_TypeDef CCR offset mismatch!");
_Static_assert(offsetof(QSPI_TypeDef, SR) == 0x08U, "QSPI_TypeDef SR offset mismatch!");
_Static_assert(offsetof(QSPI_TypeDef, FCR) == 0x0CU, "QSPI_TypeDef FCR offset mismatch!");
_Static_assert(offsetof(QSPI_TypeDef, AR) == 0x10U, "QSPI_TypeDef AR offset mismatch!");
_Static_assert(offsetof(QSPI_TypeDef, DR) == 0x18U, "QSPI_TypeDef DR offset mismatch!");
_Static_assert(offsetof(QSPI_TypeDef, DLR) == 0x1CU, "QSPI_TypeDef DLR offset mismatch!");
_Static_assert(offsetof(QSPI_TypeDef, TOR) == 0x20U, "QSPI_TypeDef TOR offset mismatch!");

/*
 * @brief EMAC registers structure
 */
typedef struct
{
    __IO uint32 BUS_MODE;          /* BUS_MODE  BUS MODE register,  Address offset: 0x00 */
    __IO uint32 RESERVED0;         /* Reserved,  Address offset: 0x04 */
    __IO uint32 TX_POLL;           /* TX_POLL  Transmit Poll Demand register,  Address offset: 0x08 */
    __IO uint32 RESERVED1;         /* Reserved,  Address offset: 0x0C */
    __IO uint32 RX_POLL;           /* RX_POLL  Receive Poll Demand register,  Address offset: 0x10 */
    __IO uint32 RESERVED2;         /* Reserved,  Address offset: 0x14 */
    __IO uint32 RDES_BASE_ADDR;    /* RDES_BASE_ADDR  Receive Descriptor List Address register,  Address offset: 0x18 */
    __IO uint32 RESERVED3;         /* Reserved,  Address offset: 0x1C */
    __IO uint32 TDES_BASE_ADDR;    /* TDES_BASE_ADDR  Transmit Descriptor List Address register,  Address offset: 0x20 */
    __IO uint32 RESERVED4;         /* Reserved,  Address offset: 0x24 */
    __IO uint32 STATUS;            /* STATUS  Status register,  Address offset: 0x28 */
    __IO uint32 RESERVED5;         /* Reserved,  Address offset: 0x2C */
    __IO uint32 OPT_MODE;          /* OPT_MODE  Operation Mode register,  Address offset: 0x30 */
    __IO uint32 RESERVED6;         /* Reserved,  Address offset: 0x34 */
    __IO uint32 INT_ENABLE;        /* INT_ENABLE  Interrupt Enable register,  Address offset: 0x38 */
    __IO uint32 RESERVED7;         /* Reserved,  Address offset: 0x3C */
    __IO uint32 FRAME_CNT;         /* FRAME_CNT  Frame and Counter Overflow register,  Address offset: 0x40 */
    __IO uint32 RESERVED8;         /* Reserved,  Address offset: 0x44 */
    __IO uint32 MDIO_CTRL0;        /* MDIO_CTRL0  MDIO Control register 0,  Address offset: 0x48 */
    __IO uint32 RESERVED9;         /* Reserved,  Address offset: 0x4C */
    __IO uint32 MDIO_CTRL1;        /* MDIO_CTRL1  MDIO Control register 1,  Address offset: 0x50 */
    __IO uint32 RESERVED10;        /* Reserved,  Address offset: 0x54 */
    __IO uint32 TIMER_CTRL;        /* TIMER_CTRL  General Timer and Interrupt Suppression Control register,  Address offset: 0x58 */
} MAC_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(MAC_TypeDef) == 0x5CU, "MAC_TypeDef size mismatch!");
_Static_assert(offsetof(MAC_TypeDef, BUS_MODE) == 0x00U, "MAC_TypeDef BUS_MODE offset mismatch!");
_Static_assert(offsetof(MAC_TypeDef, OPT_MODE) == 0x30U, "MAC_TypeDef OPT_MODE offset mismatch!");
_Static_assert(offsetof(MAC_TypeDef, FRAME_CNT) == 0x40U, "MAC_TypeDef FRAME_CNT offset mismatch!");
_Static_assert(offsetof(MAC_TypeDef, TIMER_CTRL) == 0x58U, "MAC_TypeDef TIMER_CTRL offset mismatch!");

/*
 * @brief SPI registers structure
 */
typedef struct
{
    __IO uint32 CR0;      /* SPI_Ctrl0  Control register 0,  Address offset: 0x00 */
    __O uint32 IFCR;      /* SPI_IntClear  Interrupt clear register,  Address offset: 0x04 */
    __I uint32 RXDR;      /* SPI_Rxdata  Receive data register,  Address offset: 0x08 */
    __O uint32 TXDR;      /* SPI_Txdata  Transmit data register,  Address offset: 0x0C */
    __I uint32 ISR;       /* SPI_IntSr  Interrupt status register,  Address offset: 0x10 */
    __I uint32 IRSR;      /* SPI_IntRaw  Interrupt the raw status register,  Address offset: 0x14 */
    __IO uint32 IER;      /* SPI_Ctrl1  Control register 1,  Address offset: 0x18 */
    __O uint32 CR1;       /* SPI_Command  Buffer reset control register,  Address offset: 0x1C */
    __I uint32 SR;        /* SPI_Status  Status register,  Address offset: 0x20 */
    __O uint32 SSR;       /* SPI_SSel  Slave select register,  Address offset: 0x24 */
    __O uint32 TXEDR;     /* SPI_TxdataLast  End of send data register,  Address offset: 0x28 */
    __IO uint32 CLKCR;    /* SPI_CfgClk  Clock division configuration register,  Address offset: 0x2C */
    __IO uint32 CFG;      /* SPI_Mode  Mode register,  Address offset: 0x30 */
} SPI_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(SPI_TypeDef) == 0x34U, "SPI_TypeDef size mismatch!");
_Static_assert(offsetof(SPI_TypeDef, CR0) == 0x00U, "SPI_TypeDef CR0 offset mismatch!");
_Static_assert(offsetof(SPI_TypeDef, RXDR) == 0x08U, "SPI_TypeDef RXDR offset mismatch!");
_Static_assert(offsetof(SPI_TypeDef, TXDR) == 0x0CU, "SPI_TypeDef TXDR offset mismatch!");
_Static_assert(offsetof(SPI_TypeDef, ISR) == 0x10U, "SPI_TypeDef ISR offset mismatch!");
_Static_assert(offsetof(SPI_TypeDef, SR) == 0x20U, "SPI_TypeDef SR offset mismatch!");
_Static_assert(offsetof(SPI_TypeDef, CLKCR) == 0x2CU, "SPI_TypeDef CLKCR offset mismatch!");
_Static_assert(offsetof(SPI_TypeDef, CFG) == 0x30U, "SPI_TypeDef CFG offset mismatch!");

/*
 * @brief Inter integrated circuit registers structure
 */
typedef struct
{
    __IO uint8 CTLR;       /* I2C Control Register.  Address offset: 0x00 */
    uint8 RESERVED0[3];    /* I2C Reserved,  Address offset: 0x01 - 0x03 */
    __I uint8 STAT;        /* I2C Status Register.  Address offset: 0x04 */
    uint8 RESERVED1[3];    /* I2C Reserved,  Address offset: 0x05 - 0x07 */
    __IO uint8 DATA;       /* I2C Data Register.  Address offset: 0x08 */
    uint8 RESERVED2[3];    /* I2C Reserved,  Address offset: 0x09 - 0x0B */
    __IO uint8 ADDR;       /* I2C Slave Address Register.  Address offset: 0x0C */
    uint8 RESERVED3[3];    /* I2C Reserved,  Address offset: 0x0D - 0x0F */
    __IO uint8 DIV_L;      /* I2C Frequency division coefficient register low.  Address offset: 0x10 */
    uint8 RESERVED4[3];    /* I2C Reserved,  Address offset: 0x11 - 0x13 */
    __IO uint8 IRQC;       /* I2C Interrupt control register.  Address offset: 0x14 */
    uint8 RESERVED5[3];    /* I2C Reserved,  Address offset: 0x15 - 0x17 */
    __IO uint8 DIV_H;      /* I2C Frequency division coefficient register high.  Address offset: 0x18 */
} I2C_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(I2C_TypeDef) == 0x19U, "I2C_TypeDef size mismatch!");
_Static_assert(offsetof(I2C_TypeDef, CTLR) == 0x00U, "I2C_TypeDef CTLR offset mismatch!");
_Static_assert(offsetof(I2C_TypeDef, STAT) == 0x04U, "I2C_TypeDef STAT offset mismatch!");
_Static_assert(offsetof(I2C_TypeDef, DATA) == 0x08U, "I2C_TypeDef DATA offset mismatch!");
_Static_assert(offsetof(I2C_TypeDef, ADDR) == 0x0CU, "I2C_TypeDef ADDR offset mismatch!");
_Static_assert(offsetof(I2C_TypeDef, IRQC) == 0x14U, "I2C_TypeDef IRQC offset mismatch!");

/*
 * @brief Universal synchronous asynchronous receiver transmitter registers structure
 */
typedef struct
{
    __IO uint32 CR1;       /* USART_CTRL1  USART control register 1,  Address offset: 0x00 */
    __IO uint32 CR2;       /* USART_CTRL2  USART control register 2,  Address offset: 0x04 */
    __IO uint32 CR3;       /* USART_CTRL3  USART control register 3,  Address offset: 0x08 */
    __IO uint32 BRR;       /* USART_BRR  USART baud rate register,  Address offset: 0x0C */
    uint32 RESERVED[2];    /* USART Reserved,  Address offset: 0x10 - 0x14 */
    __O uint32 RQR;        /* USART_RQR  USART request register,  Address offset: 0x18 */
    __I uint32 ISR;        /* USART_ISR  USART interrupt and status register,  Address offset: 0x1C */
    __O uint32 ICR;        /* USART_ICR  USART interrupt flag clear register,  Address offset: 0x20 */
    __I uint32 RDR;        /* USART_RDR  USART receive data register,  Address offset: 0x24 */
    __IO uint32 TDR;       /* USART_TDR  USART transmit data register,  Address offset: 0x28 */
} USART_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(USART_TypeDef) == 0x2CU, "USART_TypeDef size mismatch!");
_Static_assert(offsetof(USART_TypeDef, CR1) == 0x00U, "USART_TypeDef CR1 offset mismatch!");
_Static_assert(offsetof(USART_TypeDef, BRR) == 0x0CU, "USART_TypeDef BRR offset mismatch!");
_Static_assert(offsetof(USART_TypeDef, RQR) == 0x18U, "USART_TypeDef RQR offset mismatch!");
_Static_assert(offsetof(USART_TypeDef, ISR) == 0x1CU, "USART_TypeDef ISR offset mismatch!");
_Static_assert(offsetof(USART_TypeDef, ICR) == 0x20U, "USART_TypeDef ICR offset mismatch!");
_Static_assert(offsetof(USART_TypeDef, RDR) == 0x24U, "USART_TypeDef RDR offset mismatch!");
_Static_assert(offsetof(USART_TypeDef, TDR) == 0x28U, "USART_TypeDef TDR offset mismatch!");

/*
 * @brief WWDG registers structure
 */
typedef struct
{
    __IO uint32 PSC;    /* PSC  Prescaler,  Address offset: 0x00 */
    __I uint32 DSTA;    /* DSTA  Status,  Address offset: 0x04 */
} WWDG_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(WWDG_TypeDef) == 0x08U, "WWDG_TypeDef size mismatch!");
_Static_assert(offsetof(WWDG_TypeDef, PSC) == 0x00U, "WWDG_TypeDef PSC offset mismatch!");
_Static_assert(offsetof(WWDG_TypeDef, DSTA) == 0x04U, "WWDG_TypeDef DSTA offset mismatch!");

/*
 * @brief WWDG registers structure
 */
typedef struct
{
    __IO uint32 CFG;    /* CFG  Configuration,  Address offset: 0x00 */
    __IO uint32 DIV;    /* DIV  Divider,  Address offset: 0x04 */
    __IO uint32 TO;     /* TO  Timeout,  Address offset: 0x08 */
    __IO uint32 CNT;    /* CNT  Counter,  Address offset: 0x0C */
    __IO uint32 CLR;    /* CLR  Clear,  Address offset: 0x10 */
    __IO uint32 WD;     /* WD  Watchdog channel,  Address offset: 0x14 */
} WWDG_Channel_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(WWDG_Channel_TypeDef) == 0x18U, "WWDG_Channel_TypeDef size mismatch!");
_Static_assert(offsetof(WWDG_Channel_TypeDef, CFG) == 0x00U, "WWDG_Channel_TypeDef CFG offset mismatch!");
_Static_assert(offsetof(WWDG_Channel_TypeDef, CLR) == 0x10U, "WWDG_Channel_TypeDef CLR offset mismatch!");
_Static_assert(offsetof(WWDG_Channel_TypeDef, WD) == 0x14U, "WWDG_Channel_TypeDef WD offset mismatch!");

/*
 * @brief CRC registers structure
 */
typedef struct
{
    __IO uint32 DR;        /* CRC_DR  CRC data register,  Address offset: 0x00 */
    __IO uint8 IDR;        /* CRC_IDR  CRC independent data register,  Address offset: 0x04 */
    uint8 RESERVED0[3];    /* Reserved,  Address offset: 0x05 - 0x07 */
    __IO uint32 CR;        /* CRC_CR  CRC control register,  Address offset: 0x08 */
    __IO uint32 INIT;      /* CRC_INIT  CRC initial vector register,  Address offset: 0x0C */
    __O uint32 POLY;       /* CRC_POLY  CRC generates polynomial registers,  Address offset: 0x10 */
    __O uint32 XOR;        /* CRC_XOR  CRC XOR polynomial register,  Address offset: 0x14 */
} CRC_TypeDef;

/* CHIP-08 static layout assertions (size + code-dependency offsets) */
_Static_assert(sizeof(CRC_TypeDef) == 0x18U, "CRC_TypeDef size mismatch!");
_Static_assert(offsetof(CRC_TypeDef, DR) == 0x00U, "CRC_TypeDef DR offset mismatch!");
_Static_assert(offsetof(CRC_TypeDef, IDR) == 0x04U, "CRC_TypeDef IDR offset mismatch!");
_Static_assert(offsetof(CRC_TypeDef, CR) == 0x08U, "CRC_TypeDef CR offset mismatch!");

/******************************************************************************
 *  PERIPHERAL MEMORY MAP
 *****************************************************************************/
#define AXI_Bus0_BASE                   ((uint32)0x00000000)
#define BOOT_ROM_BASE                   ((uint32)AXI_Bus0_BASE + 0x00000000)
#define P_FLASH_Main_BASE               ((uint32)AXI_Bus0_BASE + 0x01000000)
#define P_FLASH_Info_BASE               ((uint32)AXI_Bus0_BASE + 0x01200000)
#define D_FLASH_Main_BASE               ((uint32)AXI_Bus0_BASE + 0x02000000)
#define D_FLASH_Info_BASE               ((uint32)AXI_Bus0_BASE + 0x02080000)
#define QSPI_FLASH_BASE                 ((uint32)AXI_Bus0_BASE + 0x10000000)
#define AXI_Bus1_BASE                   ((uint32)0x20000000)
#define SRAM0_BASE                      ((uint32)AXI_Bus1_BASE + 0x00000000)
#define SRAM1_BASE                      ((uint32)AXI_Bus1_BASE + 0x00020000)
#define SRAM2_BASE                      ((uint32)AXI_Bus1_BASE + 0x00040000)
#define SRAM3_BASE                      ((uint32)AXI_Bus1_BASE + 0x00060000)
#define AXi_Bus2_BASE                   ((uint32)0x30000000)
#define AXILite4_Bus0_BASE              ((uint32)0x30000000)
#define MPU0_IBUS_BASE                  ((uint32)AXILite4_Bus0_BASE + 0x00000000)
#define MPU1_DBUS_BASE                  ((uint32)AXILite4_Bus0_BASE + 0x00000400)
#define MPU2_PBUS_BASE                  ((uint32)AXILite4_Bus0_BASE + 0x00000800)
#define MPU3_DMA0_BASE                  ((uint32)AXILite4_Bus0_BASE + 0x00000C00)
#define MPU4_DMA1_BASE                  ((uint32)AXILite4_Bus0_BASE + 0x00001000)
#define FCU_BASE                        ((uint32)AXILite4_Bus0_BASE + 0x00002000)
#define CMU0_BASE                       ((uint32)AXILite4_Bus0_BASE + 0x00003000)
#define CMU1_BASE                       ((uint32)AXILite4_Bus0_BASE + 0x00003400)
#define CMU2_BASE                       ((uint32)AXILite4_Bus0_BASE + 0x00003800)
#define CMU3_BASE                       ((uint32)AXILite4_Bus0_BASE + 0x00003C00)
#define DMA0_CFG_BASE                   ((uint32)AXILite4_Bus0_BASE + 0x00004000)
#define DMA1_CFG_BASE                   ((uint32)AXILite4_Bus0_BASE + 0x00004400)
#define SMU_BASE                        ((uint32)AXILite4_Bus0_BASE + 0x00006000)
#define CLINT_BASE                      ((uint32)AXILite4_Bus0_BASE + 0x00010000)
#define PLIC_BASE                       ((uint32)AXILite4_Bus0_BASE + 0x00020000)
#define APB_BusS_BASE                   ((uint32)0x30100000)
#define BACKUP_RAM_BASE                 ((uint32)APB_BusS_BASE + 0x00000000)
#define RTC_BASE                        ((uint32)APB_BusS_BASE + 0x00001000)
#define GPIOH_BASE                      ((uint32)APB_BusS_BASE + 0x00002000)
#define PMU_BASE                        ((uint32)APB_BusS_BASE + 0x00003000)
#define IWDG_BASE                       ((uint32)APB_BusS_BASE + 0x00004000)
#define AXI_Bus3_BASE                   ((uint32)0x40000000)
#define AXILite4_Bus1_BASE              ((uint32)0x41000000)
#define TIM0_BASE                       ((uint32)AXILite4_Bus1_BASE + 0x00000000)
#define CANFD0_BASE                     ((uint32)AXILite4_Bus1_BASE + 0x00010000)
#define CANFD1_BASE                     ((uint32)AXILite4_Bus1_BASE + 0x00020000)
#define ADC0_BASE                       ((uint32)AXILite4_Bus1_BASE + 0x00001000)
#define ADC1_BASE                       ((uint32)AXILite4_Bus1_BASE + 0x00002000)
#define DAC_CMP0_BASE                   ((uint32)AXILite4_Bus1_BASE + 0x00003000)
#define GPIOA_BASE                      ((uint32)AXILite4_Bus1_BASE + 0x00004000)
#define GPIOB_BASE                      ((uint32)AXILite4_Bus1_BASE + 0x00005000)
#define GPIOC_BASE                      ((uint32)AXILite4_Bus1_BASE + 0x00006000)
#define DSE_BASE                        ((uint32)AXILite4_Bus1_BASE + 0x00100000)
#define SPACC_BASE                      ((uint32)AXILite4_Bus1_BASE + 0x00100000)
#define PKA_BASE                        ((uint32)AXILite4_Bus1_BASE + 0x00140000)
#define TRNG_BASE                       ((uint32)AXILite4_Bus1_BASE + 0x00150000)
#define REG_BASE                        ((uint32)AXILite4_Bus1_BASE + 0x00160000)
#define AXILite4_Bus2_BASE              ((uint32)0x42000000)
#define TIM1_BASE                       ((uint32)AXILite4_Bus2_BASE + 0x00000000)
#define CANFD2_BASE                     ((uint32)AXILite4_Bus2_BASE + 0x00010000)
#define CANFD3_BASE                     ((uint32)AXILite4_Bus2_BASE + 0x00020000)
#define DAC_CMP1_BASE                   ((uint32)AXILite4_Bus2_BASE + 0x00002000)
#define GPIOD_BASE                      ((uint32)AXILite4_Bus2_BASE + 0x00003000)
#define GPIOE_BASE                      ((uint32)AXILite4_Bus2_BASE + 0x00004000)
#define GPIOF_BASE                      ((uint32)AXILite4_Bus2_BASE + 0x00005000)
#define GPIOG_BASE                      ((uint32)AXILite4_Bus2_BASE + 0x00006000)
#define FLASH_CTRL_BASE                 ((uint32)AXILite4_Bus2_BASE + 0x00100000)
#define QSPI_CTRL_BASE                  ((uint32)AXILite4_Bus2_BASE + 0x00100800)
#define APBBus0_BASE                    ((uint32)0x50000000)
#define MAC_BASE                        ((uint32)APBBus0_BASE + 0x00000000)
#define SPI0_BASE                       ((uint32)APBBus0_BASE + 0x00001000)
#define SPI1_BASE                       ((uint32)APBBus0_BASE + 0x00002000)
#define SPI2_BASE                       ((uint32)APBBus0_BASE + 0x00003000)
#define IIC_IIS0_BASE                   ((uint32)APBBus0_BASE + 0x00004000)
#define IIC_IIS1_BASE                   ((uint32)APBBus0_BASE + 0x00005000)
#define USART0_BASE                     ((uint32)APBBus0_BASE + 0x00006000)
#define USART1_BASE                     ((uint32)APBBus0_BASE + 0x00007000)
#define USART2_BASE                     ((uint32)APBBus0_BASE + 0x00008000)
#define USART3_BASE                     ((uint32)APBBus0_BASE + 0x00009000)
#define TIM2_BASE                       ((uint32)APBBus0_BASE + 0x0000A000)
#define TIM3_BASE                       ((uint32)APBBus0_BASE + 0x0000B000)
#define TIM4_BASE                       ((uint32)APBBus0_BASE + 0x0000C000)
#define WWDG0_BASE                      ((uint32)APBBus0_BASE + 0x0000D000)
#define APBBus1_BASE                    ((uint32)0x51000000)
#define SPI3_BASE                       ((uint32)APBBus1_BASE + 0x00000000)
#define SPI4_BASE                       ((uint32)APBBus1_BASE + 0x00001000)
#define SPI5_BASE                       ((uint32)APBBus1_BASE + 0x00002000)
#define IIC_IIS2_BASE                   ((uint32)APBBus1_BASE + 0x00003000)
#define IIC_IIS3_BASE                   ((uint32)APBBus1_BASE + 0x00004000)
#define USART4_BASE                     ((uint32)APBBus1_BASE + 0x00005000)
#define USART5_BASE                     ((uint32)APBBus1_BASE + 0x00006000)
#define USART6_BASE                     ((uint32)APBBus1_BASE + 0x00007000)
#define USART7_BASE                     ((uint32)APBBus1_BASE + 0x00008000)
#define TIM5_BASE                       ((uint32)APBBus1_BASE + 0x00009000)
#define TIM6_BASE                       ((uint32)APBBus1_BASE + 0x0000A000)
#define TIM7_BASE                       ((uint32)APBBus1_BASE + 0x0000B000)
#define WWDG1_BASE                      ((uint32)APBBus1_BASE + 0x0000C000)
#define CRC_BASE                        ((uint32)APBBus1_BASE + 0x0000D000)


/******************************************************************************
 *  PERIPHERAL DECLARATION
 *****************************************************************************/

#define MPU0_IBUS       ((MPU_IPort_TypeDef *)(MPU0_IBUS_BASE))
#define MPU1_DBUS       ((MPU_DPort_TypeDef *)(MPU1_DBUS_BASE))
#define MPU2_PBUS       ((MPU_PPort_TypeDef *)(MPU2_PBUS_BASE))
#define MPU3_DMA0       ((MPU_DMAPort_TypeDef *)(MPU3_DMA0_BASE))
#define MPU4_DMA1       ((MPU_DMAPort_TypeDef *)(MPU4_DMA1_BASE))
#define MPU0_Channel0   ((MPU_Channel_TypeDef *)(MPU0_IBUS_BASE+0x0CU))
#define MPU0_Channel1   ((MPU_Channel_TypeDef *)(MPU0_IBUS_BASE+0x14U))
#define MPU0_Channel2   ((MPU_Channel_TypeDef *)(MPU0_IBUS_BASE+0x1CU))
#define MPU0_Channel3   ((MPU_Channel_TypeDef *)(MPU0_IBUS_BASE+0x24U))
#define MPU0_Channel4   ((MPU_Channel_TypeDef *)(MPU0_IBUS_BASE+0x2CU))
#define MPU0_Channel5   ((MPU_Channel_TypeDef *)(MPU0_IBUS_BASE+0x34U))
#define MPU0_Channel6   ((MPU_Channel_TypeDef *)(MPU0_IBUS_BASE+0x3CU))
#define MPU0_Channel7   ((MPU_Channel_TypeDef *)(MPU0_IBUS_BASE+0x44U))
#define MPU0_Channel8   ((MPU_Channel_TypeDef *)(MPU0_IBUS_BASE+0x4CU))
#define MPU0_Channel9   ((MPU_Channel_TypeDef *)(MPU0_IBUS_BASE+0x54U))
#define MPU0_Channel10  ((MPU_Channel_TypeDef *)(MPU0_IBUS_BASE+0x5CU))
#define MPU0_Channel11  ((MPU_Channel_TypeDef *)(MPU0_IBUS_BASE+0x64U))
#define MPU0_Channel12  ((MPU_Channel_TypeDef *)(MPU0_IBUS_BASE+0x6CU))
#define MPU0_Channel13  ((MPU_Channel_TypeDef *)(MPU0_IBUS_BASE+0x74U))
#define MPU0_Channel14  ((MPU_Channel_TypeDef *)(MPU0_IBUS_BASE+0x7CU))
#define MPU0_Channel15  ((MPU_Channel_TypeDef *)(MPU0_IBUS_BASE+0x84U))
#define MPU1_Channel0   ((MPU_Channel_TypeDef *)(MPU1_DBUS_BASE+0x14U))
#define MPU1_Channel1   ((MPU_Channel_TypeDef *)(MPU1_DBUS_BASE+0x1CU))
#define MPU1_Channel2   ((MPU_Channel_TypeDef *)(MPU1_DBUS_BASE+0x24U))
#define MPU1_Channel3   ((MPU_Channel_TypeDef *)(MPU1_DBUS_BASE+0x2CU))
#define MPU1_Channel4   ((MPU_Channel_TypeDef *)(MPU1_DBUS_BASE+0x34U))
#define MPU1_Channel5   ((MPU_Channel_TypeDef *)(MPU1_DBUS_BASE+0x3CU))
#define MPU1_Channel6   ((MPU_Channel_TypeDef *)(MPU1_DBUS_BASE+0x44U))
#define MPU1_Channel7   ((MPU_Channel_TypeDef *)(MPU1_DBUS_BASE+0x4CU))
#define MPU1_Channel8   ((MPU_Channel_TypeDef *)(MPU1_DBUS_BASE+0x54U))
#define MPU1_Channel9   ((MPU_Channel_TypeDef *)(MPU1_DBUS_BASE+0x5CU))
#define MPU1_Channel10  ((MPU_Channel_TypeDef *)(MPU1_DBUS_BASE+0x64U))
#define MPU1_Channel11  ((MPU_Channel_TypeDef *)(MPU1_DBUS_BASE+0x6CU))
#define MPU1_Channel12  ((MPU_Channel_TypeDef *)(MPU1_DBUS_BASE+0x74U))
#define MPU1_Channel13  ((MPU_Channel_TypeDef *)(MPU1_DBUS_BASE+0x7CU))
#define MPU1_Channel14  ((MPU_Channel_TypeDef *)(MPU1_DBUS_BASE+0x84U))
#define MPU1_Channel15  ((MPU_Channel_TypeDef *)(MPU1_DBUS_BASE+0x8CU))
#define MPU2_Channel0   ((MPU_Channel_TypeDef *)(MPU2_PBUS_BASE+0x14U))
#define MPU2_Channel1   ((MPU_Channel_TypeDef *)(MPU2_PBUS_BASE+0x1CU))
#define MPU2_Channel2   ((MPU_Channel_TypeDef *)(MPU2_PBUS_BASE+0x24U))
#define MPU2_Channel3   ((MPU_Channel_TypeDef *)(MPU2_PBUS_BASE+0x2CU))
#define MPU2_Channel4   ((MPU_Channel_TypeDef *)(MPU2_PBUS_BASE+0x34U))
#define MPU2_Channel5   ((MPU_Channel_TypeDef *)(MPU2_PBUS_BASE+0x3CU))
#define MPU2_Channel6   ((MPU_Channel_TypeDef *)(MPU2_PBUS_BASE+0x44U))
#define MPU2_Channel7   ((MPU_Channel_TypeDef *)(MPU2_PBUS_BASE+0x4CU))
#define MPU2_Channel8   ((MPU_Channel_TypeDef *)(MPU2_PBUS_BASE+0x54U))
#define MPU2_Channel9   ((MPU_Channel_TypeDef *)(MPU2_PBUS_BASE+0x5CU))
#define MPU2_Channel10  ((MPU_Channel_TypeDef *)(MPU2_PBUS_BASE+0x64U))
#define MPU2_Channel11  ((MPU_Channel_TypeDef *)(MPU2_PBUS_BASE+0x6CU))
#define MPU2_Channel12  ((MPU_Channel_TypeDef *)(MPU2_PBUS_BASE+0x74U))
#define MPU2_Channel13  ((MPU_Channel_TypeDef *)(MPU2_PBUS_BASE+0x7CU))
#define MPU2_Channel14  ((MPU_Channel_TypeDef *)(MPU2_PBUS_BASE+0x84U))
#define MPU2_Channel15  ((MPU_Channel_TypeDef *)(MPU2_PBUS_BASE+0x8CU))
#define MPU3_Channel0   ((MPU_Channel_TypeDef *)(MPU3_DMA0_BASE+0x14U))
#define MPU3_Channel1   ((MPU_Channel_TypeDef *)(MPU3_DMA0_BASE+0x1CU))
#define MPU3_Channel2   ((MPU_Channel_TypeDef *)(MPU3_DMA0_BASE+0x24U))
#define MPU3_Channel3   ((MPU_Channel_TypeDef *)(MPU3_DMA0_BASE+0x2CU))
#define MPU3_Channel4   ((MPU_Channel_TypeDef *)(MPU3_DMA0_BASE+0x34U))
#define MPU3_Channel5   ((MPU_Channel_TypeDef *)(MPU3_DMA0_BASE+0x3CU))
#define MPU3_Channel6   ((MPU_Channel_TypeDef *)(MPU3_DMA0_BASE+0x44U))
#define MPU3_Channel7   ((MPU_Channel_TypeDef *)(MPU3_DMA0_BASE+0x4CU))
#define MPU4_Channel0   ((MPU_Channel_TypeDef *)(MPU4_DMA1_BASE+0x14U))
#define MPU4_Channel1   ((MPU_Channel_TypeDef *)(MPU4_DMA1_BASE+0x1CU))
#define MPU4_Channel2   ((MPU_Channel_TypeDef *)(MPU4_DMA1_BASE+0x24U))
#define MPU4_Channel3   ((MPU_Channel_TypeDef *)(MPU4_DMA1_BASE+0x2CU))
#define MPU4_Channel4   ((MPU_Channel_TypeDef *)(MPU4_DMA1_BASE+0x34U))
#define MPU4_Channel5   ((MPU_Channel_TypeDef *)(MPU4_DMA1_BASE+0x3CU))
#define MPU4_Channel6   ((MPU_Channel_TypeDef *)(MPU4_DMA1_BASE+0x44U))
#define MPU4_Channel7   ((MPU_Channel_TypeDef *)(MPU4_DMA1_BASE+0x4CU))
#define FCU             ((FCU_TypeDef *)FCU_BASE)
#define CMU_FIRC        ((CMU_TypeDef *)CMU0_BASE)
#define CMU_PLLQ        ((CMU_TypeDef *)CMU1_BASE)
#define CMU_PLLR        ((CMU_TypeDef *)CMU2_BASE)
#define CMU_OSC         ((CMU_TypeDef *)CMU3_BASE)
#define DMA0            ((DMA_TypeDef *) (DMA0_CFG_BASE))
#define DMA0_Channel0   ((DMA_Channel_TypeDef *)(DMA0_CFG_BASE+0x04))
#define DMA0_Channel1   ((DMA_Channel_TypeDef *)(DMA0_CFG_BASE+0x14))
#define DMA0_Channel2   ((DMA_Channel_TypeDef *)(DMA0_CFG_BASE+0x24))
#define DMA0_Channel3   ((DMA_Channel_TypeDef *)(DMA0_CFG_BASE+0x34))
#define DMA0_Channel4   ((DMA_Channel_TypeDef *)(DMA0_CFG_BASE+0x44))
#define DMA0_Channel5   ((DMA_Channel_TypeDef *)(DMA0_CFG_BASE+0x54))
#define DMA0_Channel6   ((DMA_Channel_TypeDef *)(DMA0_CFG_BASE+0x64))
#define DMA0_Channel7   ((DMA_Channel_TypeDef *)(DMA0_CFG_BASE+0x74))
#define DMA0_Channel8   ((DMA_Channel_TypeDef *)(DMA0_CFG_BASE+0X84))
#define DMA0_Channel9   ((DMA_Channel_TypeDef *)(DMA0_CFG_BASE+0x94))
#define DMA0_Channel10  ((DMA_Channel_TypeDef *)(DMA0_CFG_BASE+0xa4))
#define DMA0_Channel11  ((DMA_Channel_TypeDef *)(DMA0_CFG_BASE+0xb4))
#define DMA0_Channel12  ((DMA_Channel_TypeDef *)(DMA0_CFG_BASE+0xc4))
#define DMA0_Channel13  ((DMA_Channel_TypeDef *)(DMA0_CFG_BASE+0xd4))
#define DMA0_Channel14  ((DMA_Channel_TypeDef *)(DMA0_CFG_BASE+0xe4))
#define DMA0_Channel15  ((DMA_Channel_TypeDef *)(DMA0_CFG_BASE+0xf4))
#define DMA1            ((DMA_TypeDef *)(DMA1_CFG_BASE))
#define DMA1_Channel0   ((DMA_Channel_TypeDef *)(DMA1_CFG_BASE+0x04))
#define DMA1_Channel1   ((DMA_Channel_TypeDef *)(DMA1_CFG_BASE+0x14))
#define DMA1_Channel2   ((DMA_Channel_TypeDef *)(DMA1_CFG_BASE+0x24))
#define DMA1_Channel3   ((DMA_Channel_TypeDef *)(DMA1_CFG_BASE+0x34))
#define DMA1_Channel4   ((DMA_Channel_TypeDef *)(DMA1_CFG_BASE+0x44))
#define DMA1_Channel5   ((DMA_Channel_TypeDef *)(DMA1_CFG_BASE+0x54))
#define DMA1_Channel6   ((DMA_Channel_TypeDef *)(DMA1_CFG_BASE+0x64))
#define DMA1_Channel7   ((DMA_Channel_TypeDef *)(DMA1_CFG_BASE+0x74))
#define DMA1_Channel8   ((DMA_Channel_TypeDef *)(DMA1_CFG_BASE+0X84))
#define DMA1_Channel9   ((DMA_Channel_TypeDef *)(DMA1_CFG_BASE+0x94))
#define DMA1_Channel10  ((DMA_Channel_TypeDef *)(DMA1_CFG_BASE+0xa4))
#define DMA1_Channel11  ((DMA_Channel_TypeDef *)(DMA1_CFG_BASE+0xb4))
#define DMA1_Channel12  ((DMA_Channel_TypeDef *)(DMA1_CFG_BASE+0xc4))
#define DMA1_Channel13  ((DMA_Channel_TypeDef *)(DMA1_CFG_BASE+0xd4))
#define DMA1_Channel14  ((DMA_Channel_TypeDef *)(DMA1_CFG_BASE+0xe4))
#define DMA1_Channel15  ((DMA_Channel_TypeDef *)(DMA1_CFG_BASE+0xf4))
#define SMU             ((SMU_TypeDef *)SMU_BASE)
#define CLINT           ((CLINT_TypeDef *)CLINT_BASE)
#define PLIC            ((PLIC_TypeDef *)PLIC_BASE)
#define RTC             ((RTC_TypeDef *)RTC_BASE)
#define GPIOA           ((GPIO_TypeDef *)GPIOA_BASE)
#define GPIOB           ((GPIO_TypeDef *)GPIOB_BASE)
#define GPIOC           ((GPIO_TypeDef *)GPIOC_BASE)
#define GPIOD           ((GPIO_TypeDef *)GPIOD_BASE)
#define GPIOE           ((GPIO_TypeDef *)GPIOE_BASE)
#define GPIOF           ((GPIO_TypeDef *)GPIOF_BASE)
#define GPIOG           ((GPIO_TypeDef *)GPIOG_BASE)
#define GPIOH           ((GPIO_TypeDef *)GPIOH_BASE)
#define GPIOHMAP        ((GPIOHMAPPING_TypeDef *)GPIOH_BASE)
#define PMU             ((PMU_TypeDef*)PMU_BASE)
#define IWDG            ((IWDG_TypeDef *)(IWDG_BASE))
#define TIM0            ((TIM_TypeDef*)TIM0_BASE)
#define TIM1            ((TIM_TypeDef*)TIM1_BASE)
#define TIM2            ((TIM_TypeDef*)TIM2_BASE)
#define TIM3            ((TIM_TypeDef*)TIM3_BASE)
#define TIM4            ((TIM_TypeDef*)TIM4_BASE)
#define TIM5            ((TIM_TypeDef*)TIM5_BASE)
#define TIM6            ((TIM_TypeDef*)TIM6_BASE)
#define TIM7            ((TIM_TypeDef*)TIM7_BASE)
#define CANFD0          ((CANFD_TypeDef *) CANFD0_BASE)
#define CANFD1          ((CANFD_TypeDef *) CANFD1_BASE)
#define CANFD2          ((CANFD_TypeDef *) CANFD2_BASE)
#define CANFD3          ((CANFD_TypeDef *) CANFD3_BASE)
#define ADC0            ((ADC_TypeDef*)ADC0_BASE)
#define ADC1            ((ADC_TypeDef*)ADC1_BASE)
#define DAC0            ((DAC_TypeDef*)DAC_CMP0_BASE)
#define DAC1            ((DAC_TypeDef*)DAC_CMP1_BASE)
#define SPACC           ((SPACC_TypeDef*)SPACC_BASE)
#define PKA             ((PKA_TypeDef*)PKA_BASE)
#define TRNG            ((TRNG_TypeDef*)TRNG_BASE)
#define EFLASH          ((FLASH_TypeDef *)FLASH_CTRL_BASE)
#define QSPI            ((QSPI_TypeDef *)QSPI_CTRL_BASE)
#define MAC             ((MAC_TypeDef*)MAC_BASE)
#define SPI0            ((SPI_TypeDef *)SPI0_BASE)
#define SPI1            ((SPI_TypeDef *)SPI1_BASE)
#define SPI2            ((SPI_TypeDef *)SPI2_BASE)
#define SPI3            ((SPI_TypeDef *)SPI3_BASE)
#define SPI4            ((SPI_TypeDef *)SPI4_BASE)
#define SPI5            ((SPI_TypeDef *)SPI5_BASE)
#define I2C0            ((I2C_TypeDef*)IIC_IIS0_BASE)
#define I2C1            ((I2C_TypeDef*)IIC_IIS1_BASE)
#define I2C2            ((I2C_TypeDef*)IIC_IIS2_BASE)
#define I2C3            ((I2C_TypeDef*)IIC_IIS3_BASE)
#define USART0          ((USART_TypeDef*)USART0_BASE)
#define USART1          ((USART_TypeDef*)USART1_BASE)
#define USART2          ((USART_TypeDef*)USART2_BASE)
#define USART3          ((USART_TypeDef*)USART3_BASE)
#define USART4          ((USART_TypeDef*)USART4_BASE)
#define USART5          ((USART_TypeDef*)USART5_BASE)
#define USART6          ((USART_TypeDef*)USART6_BASE)
#define USART7          ((USART_TypeDef*)USART7_BASE)
#define WWDG0           ((WWDG_TypeDef *)(WWDG0_BASE))
#define WWDG1           ((WWDG_TypeDef *)(WWDG1_BASE))
#define WWDG0_Channel0  ((WWDG_Channel_TypeDef *)(WWDG0_BASE+0x08U))
#define WWDG0_Channel1  ((WWDG_Channel_TypeDef *)(WWDG0_BASE+0x20U))
#define WWDG0_Channel2  ((WWDG_Channel_TypeDef *)(WWDG0_BASE+0x38U))
#define WWDG0_Channel3  ((WWDG_Channel_TypeDef *)(WWDG0_BASE+0x50U))
#define WWDG1_Channel0  ((WWDG_Channel_TypeDef *)(WWDG1_BASE+0x08U))
#define WWDG1_Channel1  ((WWDG_Channel_TypeDef *)(WWDG1_BASE+0x20U))
#define WWDG1_Channel2  ((WWDG_Channel_TypeDef *)(WWDG1_BASE+0x38U))
#define WWDG1_Channel3  ((WWDG_Channel_TypeDef *)(WWDG1_BASE+0x50U))
#define CRC             ((CRC_TypeDef *)CRC_BASE)


/******************************************************************************
 *  PERIPHERAL REGISTERS BITS DEFINITION
 *****************************************************************************/

/* @name MPU register bits definition */
/******************  Bit definition for MPU_PTEN register  *******************/
#define MPU_PTEN_EN0_DPos       (0U)
#define MPU_PTEN_EN0_Pos        MPU_PTEN_EN0_DPos
#define MPU_PTEN_EN0_Msk        (0x1UL << MPU_PTEN_EN0_Pos)                /* 0x00000001 */
#define MPU_PTEN_EN0            MPU_PTEN_EN0_Msk                           /* Enable MPU Channel 0. */

#define MPU_PTEN_EN1_DPos       (1U)
#define MPU_PTEN_EN1_Pos        MPU_PTEN_EN1_DPos
#define MPU_PTEN_EN1_Msk        (0x1UL << MPU_PTEN_EN1_Pos)                /* 0x00000002 */
#define MPU_PTEN_EN1            MPU_PTEN_EN1_Msk                           /* Enable MPU Channel 1. */

#define MPU_PTEN_EN2_DPos       (2U)
#define MPU_PTEN_EN2_Pos        MPU_PTEN_EN2_DPos
#define MPU_PTEN_EN2_Msk        (0x1UL << MPU_PTEN_EN2_Pos)                /* 0x00000004 */
#define MPU_PTEN_EN2            MPU_PTEN_EN2_Msk                           /* Enable MPU Channel 2. */

#define MPU_PTEN_EN3_DPos       (3U)
#define MPU_PTEN_EN3_Pos        MPU_PTEN_EN3_DPos
#define MPU_PTEN_EN3_Msk        (0x1UL << MPU_PTEN_EN3_Pos)                /* 0x00000008 */
#define MPU_PTEN_EN3            MPU_PTEN_EN3_Msk                           /* Enable MPU Channel 3. */

#define MPU_PTEN_EN4_DPos       (4U)
#define MPU_PTEN_EN4_Pos        MPU_PTEN_EN4_DPos
#define MPU_PTEN_EN4_Msk        (0x1UL << MPU_PTEN_EN4_Pos)                /* 0x00000010 */
#define MPU_PTEN_EN4            MPU_PTEN_EN4_Msk                           /* Enable MPU Channel 4. */

#define MPU_PTEN_EN5_DPos       (5U)
#define MPU_PTEN_EN5_Pos        MPU_PTEN_EN5_DPos
#define MPU_PTEN_EN5_Msk        (0x1UL << MPU_PTEN_EN5_Pos)                /* 0x00000020 */
#define MPU_PTEN_EN5            MPU_PTEN_EN5_Msk                           /* Enable MPU Channel 5. */

#define MPU_PTEN_EN6_DPos       (6U)
#define MPU_PTEN_EN6_Pos        MPU_PTEN_EN6_DPos
#define MPU_PTEN_EN6_Msk        (0x1UL << MPU_PTEN_EN6_Pos)                /* 0x00000040 */
#define MPU_PTEN_EN6            MPU_PTEN_EN6_Msk                           /* Enable MPU Channel 6. */

#define MPU_PTEN_EN7_DPos       (7U)
#define MPU_PTEN_EN7_Pos        MPU_PTEN_EN7_DPos
#define MPU_PTEN_EN7_Msk        (0x1UL << MPU_PTEN_EN7_Pos)                /* 0x00000080 */
#define MPU_PTEN_EN7            MPU_PTEN_EN7_Msk                           /* Enable MPU Channel 7. */

#define MPU_PTEN_EN8_DPos       (8U)
#define MPU_PTEN_EN8_Pos        MPU_PTEN_EN8_DPos
#define MPU_PTEN_EN8_Msk        (0x1UL << MPU_PTEN_EN8_Pos)                /* 0x00000100 */
#define MPU_PTEN_EN8            MPU_PTEN_EN8_Msk                           /* Enable MPU Channel 8. */

#define MPU_PTEN_EN9_DPos       (9U)
#define MPU_PTEN_EN9_Pos        MPU_PTEN_EN9_DPos
#define MPU_PTEN_EN9_Msk        (0x1UL << MPU_PTEN_EN9_Pos)                /* 0x00000200 */
#define MPU_PTEN_EN9            MPU_PTEN_EN9_Msk                           /* Enable MPU Channel 9. */

#define MPU_PTEN_EN10_DPos      (10U)
#define MPU_PTEN_EN10_Pos       MPU_PTEN_EN10_DPos
#define MPU_PTEN_EN10_Msk       (0x1UL << MPU_PTEN_EN10_Pos)               /* 0x00000400 */
#define MPU_PTEN_EN10           MPU_PTEN_EN10_Msk                          /* Enable MPU Channel 10. */

#define MPU_PTEN_EN11_DPos      (11U)
#define MPU_PTEN_EN11_Pos       MPU_PTEN_EN11_DPos
#define MPU_PTEN_EN11_Msk       (0x1UL << MPU_PTEN_EN11_Pos)               /* 0x00000800 */
#define MPU_PTEN_EN11           MPU_PTEN_EN11_Msk                          /* Enable MPU Channel 11. */

#define MPU_PTEN_EN12_DPos      (12U)
#define MPU_PTEN_EN12_Pos       MPU_PTEN_EN12_DPos
#define MPU_PTEN_EN12_Msk       (0x1UL << MPU_PTEN_EN12_Pos)               /* 0x00001000 */
#define MPU_PTEN_EN12           MPU_PTEN_EN12_Msk                          /* Enable MPU Channel 12. */

#define MPU_PTEN_EN13_DPos      (13U)
#define MPU_PTEN_EN13_Pos       MPU_PTEN_EN13_DPos
#define MPU_PTEN_EN13_Msk       (0x1UL << MPU_PTEN_EN13_Pos)               /* 0x00002000 */
#define MPU_PTEN_EN13           MPU_PTEN_EN13_Msk                          /* Enable MPU Channel 13. */

#define MPU_PTEN_EN14_DPos      (14U)
#define MPU_PTEN_EN14_Pos       MPU_PTEN_EN14_DPos
#define MPU_PTEN_EN14_Msk       (0x1UL << MPU_PTEN_EN14_Pos)               /* 0x00004000 */
#define MPU_PTEN_EN14           MPU_PTEN_EN14_Msk                          /* Enable MPU Channel 14. */

#define MPU_PTEN_EN15_DPos      (15U)
#define MPU_PTEN_EN15_Pos       MPU_PTEN_EN15_DPos
#define MPU_PTEN_EN15_Msk       (0x1UL << MPU_PTEN_EN15_Pos)               /* 0x00008000 */
#define MPU_PTEN_EN15           MPU_PTEN_EN15_Msk                          /* Enable MPU Channel 15. */

/******************  Bit definition for MPU_WPTEN register  *******************/
#define MPU_WPTEN_EN0_DPos       (0U)
#define MPU_WPTEN_EN0_Pos        MPU_WPTEN_EN0_DPos
#define MPU_WPTEN_EN0_Msk        (0x1UL << MPU_WPTEN_EN0_Pos)                /* 0x00000001 */
#define MPU_WPTEN_EN0            MPU_WPTEN_EN0_Msk                           /* Write Protection Enable signal 0. */

#define MPU_WPTEN_EN1_DPos       (1U)
#define MPU_WPTEN_EN1_Pos        MPU_WPTEN_EN1_DPos
#define MPU_WPTEN_EN1_Msk        (0x1UL << MPU_WPTEN_EN1_Pos)                /* 0x00000002 */
#define MPU_WPTEN_EN1            MPU_WPTEN_EN1_Msk                           /* Write Protection Enable signal 1. */

#define MPU_WPTEN_EN2_DPos       (2U)
#define MPU_WPTEN_EN2_Pos        MPU_WPTEN_EN2_DPos
#define MPU_WPTEN_EN2_Msk        (0x1UL << MPU_WPTEN_EN2_Pos)                /* 0x00000004 */
#define MPU_WPTEN_EN2            MPU_WPTEN_EN2_Msk                           /* Write Protection Enable signal 2. */

#define MPU_WPTEN_EN3_DPos       (3U)
#define MPU_WPTEN_EN3_Pos        MPU_WPTEN_EN3_DPos
#define MPU_WPTEN_EN3_Msk        (0x1UL << MPU_WPTEN_EN3_Pos)                /* 0x00000008 */
#define MPU_WPTEN_EN3            MPU_WPTEN_EN3_Msk                           /* Write Protection Enable signal 3. */

#define MPU_WPTEN_EN4_DPos       (4U)
#define MPU_WPTEN_EN4_Pos        MPU_WPTEN_EN4_DPos
#define MPU_WPTEN_EN4_Msk        (0x1UL << MPU_WPTEN_EN4_Pos)                /* 0x00000010 */
#define MPU_WPTEN_EN4            MPU_WPTEN_EN4_Msk                           /* Write Protection Enable signal 4. */

#define MPU_WPTEN_EN5_DPos       (5U)
#define MPU_WPTEN_EN5_Pos        MPU_WPTEN_EN5_DPos
#define MPU_WPTEN_EN5_Msk        (0x1UL << MPU_WPTEN_EN5_Pos)                /* 0x00000020 */
#define MPU_WPTEN_EN5            MPU_WPTEN_EN5_Msk                           /* Write Protection Enable signal 5. */

#define MPU_WPTEN_EN6_DPos       (6U)
#define MPU_WPTEN_EN6_Pos        MPU_WPTEN_EN6_DPos
#define MPU_WPTEN_EN6_Msk        (0x1UL << MPU_WPTEN_EN6_Pos)                /* 0x00000040 */
#define MPU_WPTEN_EN6            MPU_WPTEN_EN6_Msk                           /* Write Protection Enable signal 6. */

#define MPU_WPTEN_EN7_DPos       (7U)
#define MPU_WPTEN_EN7_Pos        MPU_WPTEN_EN7_DPos
#define MPU_WPTEN_EN7_Msk        (0x1UL << MPU_WPTEN_EN7_Pos)                /* 0x00000080 */
#define MPU_WPTEN_EN7            MPU_WPTEN_EN7_Msk                           /* Write Protection Enable signal 7. */

#define MPU_WPTEN_EN8_DPos       (8U)
#define MPU_WPTEN_EN8_Pos        MPU_WPTEN_EN8_DPos
#define MPU_WPTEN_EN8_Msk        (0x1UL << MPU_WPTEN_EN8_Pos)                /* 0x00000100 */
#define MPU_WPTEN_EN8            MPU_WPTEN_EN8_Msk                           /* Write Protection Enable signal 8. */

#define MPU_WPTEN_EN9_DPos       (9U)
#define MPU_WPTEN_EN9_Pos        MPU_WPTEN_EN9_DPos
#define MPU_WPTEN_EN9_Msk        (0x1UL << MPU_WPTEN_EN9_Pos)                /* 0x00000200 */
#define MPU_WPTEN_EN9            MPU_WPTEN_EN9_Msk                           /* Write Protection Enable signal 9. */

#define MPU_WPTEN_EN10_DPos      (10U)
#define MPU_WPTEN_EN10_Pos       MPU_WPTEN_EN10_DPos
#define MPU_WPTEN_EN10_Msk       (0x1UL << MPU_WPTEN_EN10_Pos)               /* 0x00000400 */
#define MPU_WPTEN_EN10           MPU_WPTEN_EN10_Msk                          /* Write Protection Enable signal 10. */

#define MPU_WPTEN_EN11_DPos      (11U)
#define MPU_WPTEN_EN11_Pos       MPU_WPTEN_EN11_DPos
#define MPU_WPTEN_EN11_Msk       (0x1UL << MPU_WPTEN_EN11_Pos)               /* 0x00000800 */
#define MPU_WPTEN_EN11           MPU_WPTEN_EN11_Msk                          /* Write Protection Enable signal 11. */

#define MPU_WPTEN_EN12_DPos      (12U)
#define MPU_WPTEN_EN12_Pos       MPU_WPTEN_EN12_DPos
#define MPU_WPTEN_EN12_Msk       (0x1UL << MPU_WPTEN_EN12_Pos)               /* 0x00001000 */
#define MPU_WPTEN_EN12           MPU_WPTEN_EN12_Msk                          /* Write Protection Enable signal 12. */

#define MPU_WPTEN_EN13_DPos      (13U)
#define MPU_WPTEN_EN13_Pos       MPU_WPTEN_EN13_DPos
#define MPU_WPTEN_EN13_Msk       (0x1UL << MPU_WPTEN_EN13_Pos)               /* 0x00002000 */
#define MPU_WPTEN_EN13           MPU_WPTEN_EN13_Msk                          /* Write Protection Enable signal 13. */

#define MPU_WPTEN_EN14_DPos      (14U)
#define MPU_WPTEN_EN14_Pos       MPU_WPTEN_EN14_DPos
#define MPU_WPTEN_EN14_Msk       (0x1UL << MPU_WPTEN_EN14_Pos)               /* 0x00004000 */
#define MPU_WPTEN_EN14           MPU_WPTEN_EN14_Msk                          /* Write Protection Enable signal 14. */

#define MPU_WPTEN_EN15_DPos      (15U)
#define MPU_WPTEN_EN15_Pos       MPU_WPTEN_EN15_DPos
#define MPU_WPTEN_EN15_Msk       (0x1UL << MPU_WPTEN_EN15_Pos)               /* 0x00008000 */
#define MPU_WPTEN_EN15           MPU_WPTEN_EN15_Msk                          /* Write Protection Enable signal 15. */

/******************  Bit definition for MPU_RPTEN register  *******************/
#define MPU_RPTEN_EN0_DPos       (0U)
#define MPU_RPTEN_EN0_Pos        MPU_RPTEN_EN0_DPos
#define MPU_RPTEN_EN0_Msk        (0x1UL << MPU_RPTEN_EN0_Pos)                /* 0x00000001 */
#define MPU_RPTEN_EN0            MPU_RPTEN_EN0_Msk                           /* Read Protection Enable signal 0. */

#define MPU_RPTEN_EN1_DPos       (1U)
#define MPU_RPTEN_EN1_Pos        MPU_RPTEN_EN1_DPos
#define MPU_RPTEN_EN1_Msk        (0x1UL << MPU_RPTEN_EN1_Pos)                /* 0x00000002 */
#define MPU_RPTEN_EN1            MPU_RPTEN_EN1_Msk                           /* Read Protection Enable signal 1. */

#define MPU_RPTEN_EN2_DPos       (2U)
#define MPU_RPTEN_EN2_Pos        MPU_RPTEN_EN2_DPos
#define MPU_RPTEN_EN2_Msk        (0x1UL << MPU_RPTEN_EN2_Pos)                /* 0x00000004 */
#define MPU_RPTEN_EN2            MPU_RPTEN_EN2_Msk                           /* Read Protection Enable signal 2. */

#define MPU_RPTEN_EN3_DPos       (3U)
#define MPU_RPTEN_EN3_Pos        MPU_RPTEN_EN3_DPos
#define MPU_RPTEN_EN3_Msk        (0x1UL << MPU_RPTEN_EN3_Pos)                /* 0x00000008 */
#define MPU_RPTEN_EN3            MPU_RPTEN_EN3_Msk                           /* Read Protection Enable signal 3. */

#define MPU_RPTEN_EN4_DPos       (4U)
#define MPU_RPTEN_EN4_Pos        MPU_RPTEN_EN4_DPos
#define MPU_RPTEN_EN4_Msk        (0x1UL << MPU_RPTEN_EN4_Pos)                /* 0x00000010 */
#define MPU_RPTEN_EN4            MPU_RPTEN_EN4_Msk                           /* Read Protection Enable signal 4. */

#define MPU_RPTEN_EN5_DPos       (5U)
#define MPU_RPTEN_EN5_Pos        MPU_RPTEN_EN5_DPos
#define MPU_RPTEN_EN5_Msk        (0x1UL << MPU_RPTEN_EN5_Pos)                /* 0x00000020 */
#define MPU_RPTEN_EN5            MPU_RPTEN_EN5_Msk                           /* Read Protection Enable signal 5. */

#define MPU_RPTEN_EN6_DPos       (6U)
#define MPU_RPTEN_EN6_Pos        MPU_RPTEN_EN6_DPos
#define MPU_RPTEN_EN6_Msk        (0x1UL << MPU_RPTEN_EN6_Pos)                /* 0x00000040 */
#define MPU_RPTEN_EN6            MPU_RPTEN_EN6_Msk                           /* Read Protection Enable signal 6. */

#define MPU_RPTEN_EN7_DPos       (7U)
#define MPU_RPTEN_EN7_Pos        MPU_RPTEN_EN7_DPos
#define MPU_RPTEN_EN7_Msk        (0x1UL << MPU_RPTEN_EN7_Pos)                /* 0x00000080 */
#define MPU_RPTEN_EN7            MPU_RPTEN_EN7_Msk                           /* Read Protection Enable signal 7. */

#define MPU_RPTEN_EN8_DPos       (8U)
#define MPU_RPTEN_EN8_Pos        MPU_RPTEN_EN8_DPos
#define MPU_RPTEN_EN8_Msk        (0x1UL << MPU_RPTEN_EN8_Pos)                /* 0x00000100 */
#define MPU_RPTEN_EN8            MPU_RPTEN_EN8_Msk                           /* Read Protection Enable signal 8. */

#define MPU_RPTEN_EN9_DPos       (9U)
#define MPU_RPTEN_EN9_Pos        MPU_RPTEN_EN9_DPos
#define MPU_RPTEN_EN9_Msk        (0x1UL << MPU_RPTEN_EN9_Pos)                /* 0x00000200 */
#define MPU_RPTEN_EN9            MPU_RPTEN_EN9_Msk                           /* Read Protection Enable signal 9. */

#define MPU_RPTEN_EN10_DPos      (10U)
#define MPU_RPTEN_EN10_Pos       MPU_RPTEN_EN10_DPos
#define MPU_RPTEN_EN10_Msk       (0x1UL << MPU_RPTEN_EN10_Pos)               /* 0x00000400 */
#define MPU_RPTEN_EN10           MPU_RPTEN_EN10_Msk                          /* Read Protection Enable signal 10. */

#define MPU_RPTEN_EN11_DPos      (11U)
#define MPU_RPTEN_EN11_Pos       MPU_RPTEN_EN11_DPos
#define MPU_RPTEN_EN11_Msk       (0x1UL << MPU_RPTEN_EN11_Pos)               /* 0x00000800 */
#define MPU_RPTEN_EN11           MPU_RPTEN_EN11_Msk                          /* Read Protection Enable signal 11. */

#define MPU_RPTEN_EN12_DPos      (12U)
#define MPU_RPTEN_EN12_Pos       MPU_RPTEN_EN12_DPos
#define MPU_RPTEN_EN12_Msk       (0x1UL << MPU_RPTEN_EN12_Pos)               /* 0x00001000 */
#define MPU_RPTEN_EN12           MPU_RPTEN_EN12_Msk                          /* Read Protection Enable signal 12. */

#define MPU_RPTEN_EN13_DPos      (13U)
#define MPU_RPTEN_EN13_Pos       MPU_RPTEN_EN13_DPos
#define MPU_RPTEN_EN13_Msk       (0x1UL << MPU_RPTEN_EN13_Pos)               /* 0x00002000 */
#define MPU_RPTEN_EN13           MPU_RPTEN_EN13_Msk                          /* Read Protection Enable signal 13. */

#define MPU_RPTEN_EN14_DPos      (14U)
#define MPU_RPTEN_EN14_Pos       MPU_RPTEN_EN14_DPos
#define MPU_RPTEN_EN14_Msk       (0x1UL << MPU_RPTEN_EN14_Pos)               /* 0x00004000 */
#define MPU_RPTEN_EN14           MPU_RPTEN_EN14_Msk                          /* Read Protection Enable signal 14. */

#define MPU_RPTEN_EN15_DPos      (15U)
#define MPU_RPTEN_EN15_Pos       MPU_RPTEN_EN15_DPos
#define MPU_RPTEN_EN15_Msk       (0x1UL << MPU_RPTEN_EN15_Pos)               /* 0x00008000 */
#define MPU_RPTEN_EN15           MPU_RPTEN_EN15_Msk                          /* Read Protection Enable signal 15. */

/******************  Bit definition for MPU_WPTS register  *******************/
#define MPU_WPTS_STA0_DPos       (0U)
#define MPU_WPTS_STA0_Pos        MPU_WPTS_STA0_DPos
#define MPU_WPTS_STA0_Msk        (0x1UL << MPU_WPTS_STA0_Pos)                /* 0x00000001 */
#define MPU_WPTS_STA0            MPU_WPTS_STA0_Msk                           /* Write Protection Status 0. */

#define MPU_WPTS_STA1_DPos       (1U)
#define MPU_WPTS_STA1_Pos        MPU_WPTS_STA1_DPos
#define MPU_WPTS_STA1_Msk        (0x1UL << MPU_WPTS_STA1_Pos)                /* 0x00000002 */
#define MPU_WPTS_STA1            MPU_WPTS_STA1_Msk                           /* Write Protection Status 1. */

#define MPU_WPTS_STA2_DPos       (2U)
#define MPU_WPTS_STA2_Pos        MPU_WPTS_STA2_DPos
#define MPU_WPTS_STA2_Msk        (0x1UL << MPU_WPTS_STA2_Pos)                /* 0x00000004 */
#define MPU_WPTS_STA2            MPU_WPTS_STA2_Msk                           /* Write Protection Status 2. */

#define MPU_WPTS_STA3_DPos       (3U)
#define MPU_WPTS_STA3_Pos        MPU_WPTS_STA3_DPos
#define MPU_WPTS_STA3_Msk        (0x1UL << MPU_WPTS_STA3_Pos)                /* 0x00000008 */
#define MPU_WPTS_STA3            MPU_WPTS_STA3_Msk                           /* Write Protection Status 3. */

#define MPU_WPTS_STA4_DPos       (4U)
#define MPU_WPTS_STA4_Pos        MPU_WPTS_STA4_DPos
#define MPU_WPTS_STA4_Msk        (0x1UL << MPU_WPTS_STA4_Pos)                /* 0x00000010 */
#define MPU_WPTS_STA4            MPU_WPTS_STA4_Msk                           /* Write Protection Status 4. */

#define MPU_WPTS_STA5_DPos       (5U)
#define MPU_WPTS_STA5_Pos        MPU_WPTS_STA5_DPos
#define MPU_WPTS_STA5_Msk        (0x1UL << MPU_WPTS_STA5_Pos)                /* 0x00000020 */
#define MPU_WPTS_STA5            MPU_WPTS_STA5_Msk                           /* Write Protection Status 5. */

#define MPU_WPTS_STA6_DPos       (6U)
#define MPU_WPTS_STA6_Pos        MPU_WPTS_STA6_DPos
#define MPU_WPTS_STA6_Msk        (0x1UL << MPU_WPTS_STA6_Pos)                /* 0x00000040 */
#define MPU_WPTS_STA6            MPU_WPTS_STA6_Msk                           /* Write Protection Status 6. */

#define MPU_WPTS_STA7_DPos       (7U)
#define MPU_WPTS_STA7_Pos        MPU_WPTS_STA7_DPos
#define MPU_WPTS_STA7_Msk        (0x1UL << MPU_WPTS_STA7_Pos)                /* 0x00000080 */
#define MPU_WPTS_STA7            MPU_WPTS_STA7_Msk                           /* Write Protection Status 7. */

#define MPU_WPTS_STA8_DPos       (8U)
#define MPU_WPTS_STA8_Pos        MPU_WPTS_STA8_DPos
#define MPU_WPTS_STA8_Msk        (0x1UL << MPU_WPTS_STA8_Pos)                /* 0x00000100 */
#define MPU_WPTS_STA8            MPU_WPTS_STA8_Msk                           /* Write Protection Status 8. */

#define MPU_WPTS_STA9_DPos       (9U)
#define MPU_WPTS_STA9_Pos        MPU_WPTS_STA9_DPos
#define MPU_WPTS_STA9_Msk        (0x1UL << MPU_WPTS_STA9_Pos)                /* 0x00000200 */
#define MPU_WPTS_STA9            MPU_WPTS_STA9_Msk                           /* Write Protection Status 9. */

#define MPU_WPTS_STA10_DPos      (10U)
#define MPU_WPTS_STA10_Pos       MPU_WPTS_STA10_DPos
#define MPU_WPTS_STA10_Msk       (0x1UL << MPU_WPTS_STA10_Pos)               /* 0x00000400 */
#define MPU_WPTS_STA10           MPU_WPTS_STA10_Msk                          /* Write Protection Status 10. */

#define MPU_WPTS_STA11_DPos      (11U)
#define MPU_WPTS_STA11_Pos       MPU_WPTS_STA11_DPos
#define MPU_WPTS_STA11_Msk       (0x1UL << MPU_WPTS_STA11_Pos)               /* 0x00000800 */
#define MPU_WPTS_STA11           MPU_WPTS_STA11_Msk                          /* Write Protection Status 11. */

#define MPU_WPTS_STA12_DPos      (12U)
#define MPU_WPTS_STA12_Pos       MPU_WPTS_STA12_DPos
#define MPU_WPTS_STA12_Msk       (0x1UL << MPU_WPTS_STA12_Pos)               /* 0x00001000 */
#define MPU_WPTS_STA12           MPU_WPTS_STA12_Msk                          /* Write Protection Status 12. */

#define MPU_WPTS_STA13_DPos      (13U)
#define MPU_WPTS_STA13_Pos       MPU_WPTS_STA13_DPos
#define MPU_WPTS_STA13_Msk       (0x1UL << MPU_WPTS_STA13_Pos)               /* 0x00002000 */
#define MPU_WPTS_STA13           MPU_WPTS_STA13_Msk                          /* Write Protection Status 13. */

#define MPU_WPTS_STA14_DPos      (14U)
#define MPU_WPTS_STA14_Pos       MPU_WPTS_STA14_DPos
#define MPU_WPTS_STA14_Msk       (0x1UL << MPU_WPTS_STA14_Pos)               /* 0x00004000 */
#define MPU_WPTS_STA14           MPU_WPTS_STA14_Msk                          /* Write Protection Status 14. */

#define MPU_WPTS_STA15_DPos      (15U)
#define MPU_WPTS_STA15_Pos       MPU_WPTS_STA15_DPos
#define MPU_WPTS_STA15_Msk       (0x1UL << MPU_WPTS_STA15_Pos)               /* 0x00008000 */
#define MPU_WPTS_STA15           MPU_WPTS_STA15_Msk                          /* Write Protection Status 15. */

/******************  Bit definition for MPU_RPTS register  *******************/
#define MPU_RPTS_STA0_DPos       (0U)
#define MPU_RPTS_STA0_Pos        MPU_RPTS_STA0_DPos
#define MPU_RPTS_STA0_Msk        (0x1UL << MPU_RPTS_STA0_Pos)                /* 0x00000001 */
#define MPU_RPTS_STA0            MPU_RPTS_STA0_Msk                           /* Read Protection Status 0. */

#define MPU_RPTS_STA1_DPos       (1U)
#define MPU_RPTS_STA1_Pos        MPU_RPTS_STA1_DPos
#define MPU_RPTS_STA1_Msk        (0x1UL << MPU_RPTS_STA1_Pos)                /* 0x00000002 */
#define MPU_RPTS_STA1            MPU_RPTS_STA1_Msk                           /* Read Protection Status 1. */

#define MPU_RPTS_STA2_DPos       (2U)
#define MPU_RPTS_STA2_Pos        MPU_RPTS_STA2_DPos
#define MPU_RPTS_STA2_Msk        (0x1UL << MPU_RPTS_STA2_Pos)                /* 0x00000004 */
#define MPU_RPTS_STA2            MPU_RPTS_STA2_Msk                           /* Read Protection Status 2. */

#define MPU_RPTS_STA3_DPos       (3U)
#define MPU_RPTS_STA3_Pos        MPU_RPTS_STA3_DPos
#define MPU_RPTS_STA3_Msk        (0x1UL << MPU_RPTS_STA3_Pos)                /* 0x00000008 */
#define MPU_RPTS_STA3            MPU_RPTS_STA3_Msk                           /* Read Protection Status 3. */

#define MPU_RPTS_STA4_DPos       (4U)
#define MPU_RPTS_STA4_Pos        MPU_RPTS_STA4_DPos
#define MPU_RPTS_STA4_Msk        (0x1UL << MPU_RPTS_STA4_Pos)                /* 0x00000010 */
#define MPU_RPTS_STA4            MPU_RPTS_STA4_Msk                           /* Read Protection Status 4. */

#define MPU_RPTS_STA5_DPos       (5U)
#define MPU_RPTS_STA5_Pos        MPU_RPTS_STA5_DPos
#define MPU_RPTS_STA5_Msk        (0x1UL << MPU_RPTS_STA5_Pos)                /* 0x00000020 */
#define MPU_RPTS_STA5            MPU_RPTS_STA5_Msk                           /* Read Protection Status 5. */

#define MPU_RPTS_STA6_DPos       (6U)
#define MPU_RPTS_STA6_Pos        MPU_RPTS_STA6_DPos
#define MPU_RPTS_STA6_Msk        (0x1UL << MPU_RPTS_STA6_Pos)                /* 0x00000040 */
#define MPU_RPTS_STA6            MPU_RPTS_STA6_Msk                           /* Read Protection Status 6. */

#define MPU_RPTS_STA7_DPos       (7U)
#define MPU_RPTS_STA7_Pos        MPU_RPTS_STA7_DPos
#define MPU_RPTS_STA7_Msk        (0x1UL << MPU_RPTS_STA7_Pos)                /* 0x00000080 */
#define MPU_RPTS_STA7            MPU_RPTS_STA7_Msk                           /* Read Protection Status 7. */

#define MPU_RPTS_STA8_DPos       (8U)
#define MPU_RPTS_STA8_Pos        MPU_RPTS_STA8_DPos
#define MPU_RPTS_STA8_Msk        (0x1UL << MPU_RPTS_STA8_Pos)                /* 0x00000100 */
#define MPU_RPTS_STA8            MPU_RPTS_STA8_Msk                           /* Read Protection Status 8. */

#define MPU_RPTS_STA9_DPos       (9U)
#define MPU_RPTS_STA9_Pos        MPU_RPTS_STA9_DPos
#define MPU_RPTS_STA9_Msk        (0x1UL << MPU_RPTS_STA9_Pos)                /* 0x00000200 */
#define MPU_RPTS_STA9            MPU_RPTS_STA9_Msk                           /* Read Protection Status 9. */

#define MPU_RPTS_STA10_DPos      (10U)
#define MPU_RPTS_STA10_Pos       MPU_RPTS_STA10_DPos
#define MPU_RPTS_STA10_Msk       (0x1UL << MPU_RPTS_STA10_Pos)               /* 0x00000400 */
#define MPU_RPTS_STA10           MPU_RPTS_STA10_Msk                          /* Read Protection Status 10. */

#define MPU_RPTS_STA11_DPos      (11U)
#define MPU_RPTS_STA11_Pos       MPU_RPTS_STA11_DPos
#define MPU_RPTS_STA11_Msk       (0x1UL << MPU_RPTS_STA11_Pos)               /* 0x00000800 */
#define MPU_RPTS_STA11           MPU_RPTS_STA11_Msk                          /* Read Protection Status 11. */

#define MPU_RPTS_STA12_DPos      (12U)
#define MPU_RPTS_STA12_Pos       MPU_RPTS_STA12_DPos
#define MPU_RPTS_STA12_Msk       (0x1UL << MPU_RPTS_STA12_Pos)               /* 0x00001000 */
#define MPU_RPTS_STA12           MPU_RPTS_STA12_Msk                          /* Read Protection Status 12. */

#define MPU_RPTS_STA13_DPos      (13U)
#define MPU_RPTS_STA13_Pos       MPU_RPTS_STA13_DPos
#define MPU_RPTS_STA13_Msk       (0x1UL << MPU_RPTS_STA13_Pos)               /* 0x00002000 */
#define MPU_RPTS_STA13           MPU_RPTS_STA13_Msk                          /* Read Protection Status 13. */

#define MPU_RPTS_STA14_DPos      (14U)
#define MPU_RPTS_STA14_Pos       MPU_RPTS_STA14_DPos
#define MPU_RPTS_STA14_Msk       (0x1UL << MPU_RPTS_STA14_Pos)               /* 0x00004000 */
#define MPU_RPTS_STA14           MPU_RPTS_STA14_Msk                          /* Read Protection Status 14. */

#define MPU_RPTS_STA15_DPos      (15U)
#define MPU_RPTS_STA15_Pos       MPU_RPTS_STA15_DPos
#define MPU_RPTS_STA15_Msk       (0x1UL << MPU_RPTS_STA15_Pos)               /* 0x00008000 */
#define MPU_RPTS_STA15           MPU_RPTS_STA15_Msk                          /* Read Protection Status 15. */

/******************  Bit definition for MPU_SADDR0 register  *******************/
#define MPU_SADDR0_ADDR_DPos      (0U)
#define MPU_SADDR0_ADDR_Pos       MPU_SADDR0_ADDR_DPos
#define MPU_SADDR0_ADDR_Msk       (0xFFFFFFFFUL << MPU_SADDR0_ADDR_Pos)        /* 0xFFFFFFFF */
#define MPU_SADDR0_ADDR           MPU_SADDR0_ADDR_Msk                          /* Start address 0. */

/******************  Bit definition for MPU_EADDR0 register  *******************/
#define MPU_EADDR0_ADDR_DPos      (0U)
#define MPU_EADDR0_ADDR_Pos       MPU_EADDR0_ADDR_DPos
#define MPU_EADDR0_ADDR_Msk       (0xFFFFFFFFUL << MPU_EADDR0_ADDR_Pos)        /* 0xFFFFFFFF */
#define MPU_EADDR0_ADDR           MPU_EADDR0_ADDR_Msk                          /* End address 0. */


/******************  Bit definition for MPU_SADDR1 register  *******************/
#define MPU_SADDR1_ADDR_DPos      (0U)
#define MPU_SADDR1_ADDR_Pos       MPU_SADDR1_ADDR_DPos
#define MPU_SADDR1_ADDR_Msk       (0xFFFFFFFFUL << MPU_SADDR1_ADDR_Pos)        /* 0xFFFFFFFF */
#define MPU_SADDR1_ADDR           MPU_SADDR1_ADDR_Msk                          /* Start address 1. */

/******************  Bit definition for MPU_EADDR1 register  *******************/
#define MPU_EADDR1_ADDR_DPos      (0U)
#define MPU_EADDR1_ADDR_Pos       MPU_EADDR1_ADDR_DPos
#define MPU_EADDR1_ADDR_Msk       (0xFFFFFFFFUL << MPU_EADDR1_ADDR_Pos)        /* 0xFFFFFFFF */
#define MPU_EADDR1_ADDR           MPU_EADDR1_ADDR_Msk                          /* End address 1. */

/******************  Bit definition for MPU_SADDR2 register  *******************/
#define MPU_SADDR2_ADDR_DPos      (0U)
#define MPU_SADDR2_ADDR_Pos       MPU_SADDR2_ADDR_DPos
#define MPU_SADDR2_ADDR_Msk       (0xFFFFFFFFUL << MPU_SADDR2_ADDR_Pos)        /* 0xFFFFFFFF */
#define MPU_SADDR2_ADDR           MPU_SADDR2_ADDR_Msk                          /* Start address 2. */

/******************  Bit definition for MPU_EADDR2 register  *******************/
#define MPU_EADDR2_ADDR_DPos      (0U)
#define MPU_EADDR2_ADDR_Pos       MPU_EADDR2_ADDR_DPos
#define MPU_EADDR2_ADDR_Msk       (0xFFFFFFFFUL << MPU_EADDR2_ADDR_Pos)        /* 0xFFFFFFFF */
#define MPU_EADDR2_ADDR           MPU_EADDR2_ADDR_Msk                          /* End address 2. */


/******************  Bit definition for MPU_SADDR3 register  *******************/
#define MPU_SADDR3_ADDR_DPos      (0U)
#define MPU_SADDR3_ADDR_Pos       MPU_SADDR3_ADDR_DPos
#define MPU_SADDR3_ADDR_Msk       (0xFFFFFFFFUL << MPU_SADDR3_ADDR_Pos)        /* 0xFFFFFFFF */
#define MPU_SADDR3_ADDR           MPU_SADDR3_ADDR_Msk                          /* Start address 3. */

/******************  Bit definition for MPU_EADDR3 register  *******************/
#define MPU_EADDR3_ADDR_DPos      (0U)
#define MPU_EADDR3_ADDR_Pos       MPU_EADDR3_ADDR_DPos
#define MPU_EADDR3_ADDR_Msk       (0xFFFFFFFFUL << MPU_EADDR3_ADDR_Pos)        /* 0xFFFFFFFF */
#define MPU_EADDR3_ADDR           MPU_EADDR3_ADDR_Msk                          /* End address 3. */


/******************  Bit definition for MPU_SADDR4 register  *******************/
#define MPU_SADDR4_ADDR_DPos      (0U)
#define MPU_SADDR4_ADDR_Pos       MPU_SADDR4_ADDR_DPos
#define MPU_SADDR4_ADDR_Msk       (0xFFFFFFFFUL << MPU_SADDR4_ADDR_Pos)        /* 0xFFFFFFFF */
#define MPU_SADDR4_ADDR           MPU_SADDR4_ADDR_Msk                          /* Start address 4. */

/******************  Bit definition for MPU_EADDR4 register  *******************/
#define MPU_EADDR4_ADDR_DPos      (0U)
#define MPU_EADDR4_ADDR_Pos       MPU_EADDR4_ADDR_DPos
#define MPU_EADDR4_ADDR_Msk       (0xFFFFFFFFUL << MPU_EADDR4_ADDR_Pos)        /* 0xFFFFFFFF */
#define MPU_EADDR4_ADDR           MPU_EADDR4_ADDR_Msk                          /* End address 4. */


/******************  Bit definition for MPU_SADDR5 register  *******************/
#define MPU_SADDR5_ADDR_DPos      (0U)
#define MPU_SADDR5_ADDR_Pos       MPU_SADDR5_ADDR_DPos
#define MPU_SADDR5_ADDR_Msk       (0xFFFFFFFFUL << MPU_SADDR5_ADDR_Pos)        /* 0xFFFFFFFF */
#define MPU_SADDR5_ADDR           MPU_SADDR5_ADDR_Msk                          /* Start address 5. */

/******************  Bit definition for MPU_EADDR5 register  *******************/
#define MPU_EADDR5_ADDR_DPos      (0U)
#define MPU_EADDR5_ADDR_Pos       MPU_EADDR5_ADDR_DPos
#define MPU_EADDR5_ADDR_Msk       (0xFFFFFFFFUL << MPU_EADDR5_ADDR_Pos)        /* 0xFFFFFFFF */
#define MPU_EADDR5_ADDR           MPU_EADDR5_ADDR_Msk                          /* End address 5. */


/******************  Bit definition for MPU_SADDR6 register  *******************/
#define MPU_SADDR6_ADDR_DPos      (0U)
#define MPU_SADDR6_ADDR_Pos       MPU_SADDR6_ADDR_DPos
#define MPU_SADDR6_ADDR_Msk       (0xFFFFFFFFUL << MPU_SADDR6_ADDR_Pos)        /* 0xFFFFFFFF */
#define MPU_SADDR6_ADDR           MPU_SADDR6_ADDR_Msk                          /* Start address 6. */

/******************  Bit definition for MPU_EADDR6 register  *******************/
#define MPU_EADDR6_ADDR_DPos      (0U)
#define MPU_EADDR6_ADDR_Pos       MPU_EADDR6_ADDR_DPos
#define MPU_EADDR6_ADDR_Msk       (0xFFFFFFFFUL << MPU_EADDR6_ADDR_Pos)        /* 0xFFFFFFFF */
#define MPU_EADDR6_ADDR           MPU_EADDR6_ADDR_Msk                          /* End address 6. */


/******************  Bit definition for MPU_SADDR7 register  *******************/
#define MPU_SADDR7_ADDR_DPos      (0U)
#define MPU_SADDR7_ADDR_Pos       MPU_SADDR7_ADDR_DPos
#define MPU_SADDR7_ADDR_Msk       (0xFFFFFFFFUL << MPU_SADDR7_ADDR_Pos)        /* 0xFFFFFFFF */
#define MPU_SADDR7_ADDR           MPU_SADDR7_ADDR_Msk                          /* Start address 7. */

/******************  Bit definition for MPU_EADDR7 register  *******************/
#define MPU_EADDR7_ADDR_DPos      (0U)
#define MPU_EADDR7_ADDR_Pos       MPU_EADDR7_ADDR_DPos
#define MPU_EADDR7_ADDR_Msk       (0xFFFFFFFFUL << MPU_EADDR7_ADDR_Pos)        /* 0xFFFFFFFF */
#define MPU_EADDR7_ADDR           MPU_EADDR7_ADDR_Msk                          /* End address 7. */


/******************  Bit definition for MPU_SADDR8 register  *******************/
#define MPU_SADDR8_ADDR_DPos      (0U)
#define MPU_SADDR8_ADDR_Pos       MPU_SADDR8_ADDR_DPos
#define MPU_SADDR8_ADDR_Msk       (0xFFFFFFFFUL << MPU_SADDR8_ADDR_Pos)        /* 0xFFFFFFFF */
#define MPU_SADDR8_ADDR           MPU_SADDR8_ADDR_Msk                          /* Start address 8. */

/******************  Bit definition for MPU_EADDR8 register  *******************/
#define MPU_EADDR8_ADDR_DPos      (0U)
#define MPU_EADDR8_ADDR_Pos       MPU_EADDR8_ADDR_DPos
#define MPU_EADDR8_ADDR_Msk       (0xFFFFFFFFUL << MPU_EADDR8_ADDR_Pos)        /* 0xFFFFFFFF */
#define MPU_EADDR8_ADDR           MPU_EADDR8_ADDR_Msk                          /* End address 8. */


/******************  Bit definition for MPU_SADDR9 register  *******************/
#define MPU_SADDR9_ADDR_DPos      (0U)
#define MPU_SADDR9_ADDR_Pos       MPU_SADDR9_ADDR_DPos
#define MPU_SADDR9_ADDR_Msk       (0xFFFFFFFFUL << MPU_SADDR9_ADDR_Pos)        /* 0xFFFFFFFF */
#define MPU_SADDR9_ADDR           MPU_SADDR9_ADDR_Msk                          /* Start address 9. */

/******************  Bit definition for MPU_EADDR9 register  *******************/
#define MPU_EADDR9_ADDR_DPos      (0U)
#define MPU_EADDR9_ADDR_Pos       MPU_EADDR9_ADDR_DPos
#define MPU_EADDR9_ADDR_Msk       (0xFFFFFFFFUL << MPU_EADDR9_ADDR_Pos)        /* 0xFFFFFFFF */
#define MPU_EADDR9_ADDR           MPU_EADDR9_ADDR_Msk                          /* End address 9. */


/******************  Bit definition for MPU_SADDR10 register  *******************/
#define MPU_SADDR10_ADDR_DPos     (0U)
#define MPU_SADDR10_ADDR_Pos      MPU_SADDR10_ADDR_DPos
#define MPU_SADDR10_ADDR_Msk      (0xFFFFFFFFUL << MPU_SADDR10_ADDR_Pos)       /* 0xFFFFFFFF */
#define MPU_SADDR10_ADDR          MPU_SADDR10_ADDR_Msk                         /* Start address 10. */

/******************  Bit definition for MPU_EADDR10 register  *******************/
#define MPU_EADDR10_ADDR_DPos     (0U)
#define MPU_EADDR10_ADDR_Pos      MPU_EADDR10_ADDR_DPos
#define MPU_EADDR10_ADDR_Msk      (0xFFFFFFFFUL << MPU_EADDR10_ADDR_Pos)       /* 0xFFFFFFFF */
#define MPU_EADDR10_ADDR          MPU_EADDR10_ADDR_Msk                         /* End address 10. */


/******************  Bit definition for MPU_SADDR11 register  *******************/
#define MPU_SADDR11_ADDR_DPos     (0U)
#define MPU_SADDR11_ADDR_Pos      MPU_SADDR11_ADDR_DPos
#define MPU_SADDR11_ADDR_Msk      (0xFFFFFFFFUL << MPU_SADDR11_ADDR_Pos)       /* 0xFFFFFFFF */
#define MPU_SADDR11_ADDR          MPU_SADDR11_ADDR_Msk                         /* Start address 11. */

/******************  Bit definition for MPU_EADDR11 register  *******************/
#define MPU_EADDR11_ADDR_DPos     (0U)
#define MPU_EADDR11_ADDR_Pos      MPU_EADDR11_ADDR_DPos
#define MPU_EADDR11_ADDR_Msk      (0xFFFFFFFFUL << MPU_EADDR11_ADDR_Pos)       /* 0xFFFFFFFF */
#define MPU_EADDR11_ADDR          MPU_EADDR11_ADDR_Msk                         /* End address 11. */


/******************  Bit definition for MPU_SADDR12 register  *******************/
#define MPU_SADDR12_ADDR_DPos     (0U)
#define MPU_SADDR12_ADDR_Pos      MPU_SADDR12_ADDR_DPos
#define MPU_SADDR12_ADDR_Msk      (0xFFFFFFFFUL << MPU_SADDR12_ADDR_Pos)       /* 0xFFFFFFFF */
#define MPU_SADDR12_ADDR          MPU_SADDR12_ADDR_Msk                         /* Start address 12. */

/******************  Bit definition for MPU_EADDR12 register  *******************/
#define MPU_EADDR12_ADDR_DPos     (0U)
#define MPU_EADDR12_ADDR_Pos      MPU_EADDR12_ADDR_DPos
#define MPU_EADDR12_ADDR_Msk      (0xFFFFFFFFUL << MPU_EADDR12_ADDR_Pos)       /* 0xFFFFFFFF */
#define MPU_EADDR12_ADDR          MPU_EADDR12_ADDR_Msk                         /* End address 12. */


/******************  Bit definition for MPU_SADDR13 register  *******************/
#define MPU_SADDR13_ADDR_DPos     (0U)
#define MPU_SADDR13_ADDR_Pos      MPU_SADDR13_ADDR_DPos
#define MPU_SADDR13_ADDR_Msk      (0xFFFFFFFFUL << MPU_SADDR13_ADDR_Pos)       /* 0xFFFFFFFF */
#define MPU_SADDR13_ADDR          MPU_SADDR13_ADDR_Msk                         /* Start address 13. */

/******************  Bit definition for MPU_EADDR13 register  *******************/
#define MPU_EADDR13_ADDR_DPos     (0U)
#define MPU_EADDR13_ADDR_Pos      MPU_EADDR13_ADDR_DPos
#define MPU_EADDR13_ADDR_Msk      (0xFFFFFFFFUL << MPU_EADDR13_ADDR_Pos)       /* 0xFFFFFFFF */
#define MPU_EADDR13_ADDR          MPU_EADDR13_ADDR_Msk                         /* End address 13. */


/******************  Bit definition for MPU_SADDR14 register  *******************/
#define MPU_SADDR14_ADDR_DPos     (0U)
#define MPU_SADDR14_ADDR_Pos      MPU_SADDR14_ADDR_DPos
#define MPU_SADDR14_ADDR_Msk      (0xFFFFFFFFUL << MPU_SADDR14_ADDR_Pos)       /* 0xFFFFFFFF */
#define MPU_SADDR14_ADDR          MPU_SADDR14_ADDR_Msk                         /* Start address 14. */

/******************  Bit definition for MPU_EADDR14 register  *******************/
#define MPU_EADDR14_ADDR_DPos     (0U)
#define MPU_EADDR14_ADDR_Pos      MPU_EADDR14_ADDR_DPos
#define MPU_EADDR14_ADDR_Msk      (0xFFFFFFFFUL << MPU_EADDR14_ADDR_Pos)       /* 0xFFFFFFFF */
#define MPU_EADDR14_ADDR          MPU_EADDR14_ADDR_Msk                         /* End address 14. */


/******************  Bit definition for MPU_SADDR15 register  *******************/
#define MPU_SADDR15_ADDR_DPos     (0U)
#define MPU_SADDR15_ADDR_Pos      MPU_SADDR15_ADDR_DPos
#define MPU_SADDR15_ADDR_Msk      (0xFFFFFFFFUL << MPU_SADDR15_ADDR_Pos)       /* 0xFFFFFFFF */
#define MPU_SADDR15_ADDR          MPU_SADDR15_ADDR_Msk                         /* Start address 15. */

/******************  Bit definition for MPU_EADDR15 register  *******************/
#define MPU_EADDR15_ADDR_DPos     (0U)
#define MPU_EADDR15_ADDR_Pos      MPU_EADDR15_ADDR_DPos
#define MPU_EADDR15_ADDR_Msk      (0xFFFFFFFFUL << MPU_EADDR15_ADDR_Pos)       /* 0xFFFFFFFF */
#define MPU_EADDR15_ADDR          MPU_EADDR15_ADDR_Msk                         /* End address 15. */

/* @name FCU register bits definition */
/******************  Bits definition for FCU_CFGx register  *****************/
#define FCU_CFG_EN_DPos             (0U)
#define FCU_CFG_EN_Pos              FCU_CFG_EN_DPos
#define FCU_CFG_EN_Msk              (0x1UL << FCU_CFG_EN_Pos)               /* 0x00000001 */
#define FCU_CFG_EN                  FCU_CFG_EN_Msk                          /* CFG[0] bit (FCU channel enable) */

#define FCU_CFG_MASK_DPos           (1U)
#define FCU_CFG_MASK_Pos            FCU_CFG_MASK_DPos
#define FCU_CFG_MASK_Msk            (0x1UL << FCU_CFG_MASK_Pos)             /* 0x00000002 */
#define FCU_CFG_MASK                FCU_CFG_MASK_Msk                        /* CFG[1] bit (FCU channel mask config) */

#define FCU_CFG_LEVEL_DPos          (2U)
#define FCU_CFG_LEVEL_Pos           FCU_CFG_LEVEL_DPos
#define FCU_CFG_LEVEL_Msk           (0x3UL << FCU_CFG_LEVEL_Pos)            /* 0x0000000C */
#define FCU_CFG_LEVEL               FCU_CFG_LEVEL_Msk                       /* CFG[3:2] bits (FCU channel fault level) */

#define FCU_CFG_AACT_DPos           (4U)
#define FCU_CFG_AACT_Pos            FCU_CFG_AACT_DPos
#define FCU_CFG_AACT_Msk            (0x1UL << FCU_CFG_AACT_Pos)             /* 0x00000010 */
#define FCU_CFG_AACT                FCU_CFG_AACT_Msk                        /* CFG[4] bit (FCU channel alarm action) */

#define FCU_CFG_FACT_DPos           (5U)
#define FCU_CFG_FACT_Pos            FCU_CFG_FACT_DPos
#define FCU_CFG_FACT_Msk            (0x3UL << FCU_CFG_FACT_Pos)             /* 0x00000050 */
#define FCU_CFG_FACT                FCU_CFG_FACT_Msk                        /* CFG[6:5] bits (FCU channel alarm action) */

#define FCU_CFG_ATF_CNT_DPos        (7U)
#define FCU_CFG_ATF_CNT_Pos         FCU_CFG_ATF_CNT_DPos
#define FCU_CFG_ATF_CNT_Msk         (0xFFUL << FCU_CFG_ATF_CNT_Pos)         /* 0x00007F80 */
#define FCU_CFG_ATF_CNT             FCU_CFG_ATF_CNT_Msk                     /* CFG[14:7] bits (FCU channel alarm to fault count) */

#define FCU_CFG_FOCU_CNT_DPos       (15U)
#define FCU_CFG_FOCU_CNT_Pos        FCU_CFG_FOCU_CNT_DPos
#define FCU_CFG_FOCU_CNT_Msk        (0xFFUL << FCU_CFG_FOCU_CNT_Pos)        /* 0x000000FF */
#define FCU_CFG_FOCU_CNT            FCU_CFG_FOCU_CNT_Msk                    /* CFG[22:15] bits (FCU channel fault to reset count) */

/******************  Bits definition for FCU_SFTR register  *****************/
#define FCU_SFTR_TRIG0_DPos         (0U)
#define FCU_SFTR_TRIG0_Pos          FCU_SFTR_TRIG0_DPos
#define FCU_SFTR_TRIG0_Msk          (0x1UL << FCU_SFTR_TRIG0_Pos)           /* 0x00000001 */
#define FCU_SFTR_TRIG0              FCU_SFTR_TRIG0_Msk                      /* Software fault channel 0 trigger bit */

#define FCU_SFTR_TRIG1_DPos         (1U)
#define FCU_SFTR_TRIG1_Pos          FCU_SFTR_TRIG1_DPos
#define FCU_SFTR_TRIG1_Msk          (0x1UL << FCU_SFTR_TRIG1_Pos)           /* 0x00000002 */
#define FCU_SFTR_TRIG1              FCU_SFTR_TRIG1_Msk                      /* Software fault channel 1 trigger bit */

#define FCU_SFTR_TRIG2_DPos         (2U)
#define FCU_SFTR_TRIG2_Pos          FCU_SFTR_TRIG2_DPos
#define FCU_SFTR_TRIG2_Msk          (0x1UL << FCU_SFTR_TRIG2_Pos)           /* 0x00000004 */
#define FCU_SFTR_TRIG2              FCU_SFTR_TRIG2_Msk                      /* Software fault channel 2 trigger bit */

#define FCU_SFTR_TRIG3_DPos         (3U)
#define FCU_SFTR_TRIG3_Pos          FCU_SFTR_TRIG3_DPos
#define FCU_SFTR_TRIG3_Msk          (0x1UL << FCU_SFTR_TRIG3_Pos)           /* 0x00000008 */
#define FCU_SFTR_TRIG3              FCU_SFTR_TRIG3_Msk                      /* Software fault channel 3 trigger bit */

/******************  Bits definition for FCU_SFSTA register  *****************/

#define FCU_SFSTA_STA0_DPos        (0U)
#define FCU_SFSTA_STA0_Pos         FCU_SFSTA_STA0_DPos
#define FCU_SFSTA_STA0_Msk         (0x1UL << FCU_SFSTA_STA0_Pos)            /* 0x00000001 */
#define FCU_SFSTA_STA0             FCU_SFSTA_STA0_Msk                       /* Software fault channel 0 status bit */

#define FCU_SFSTA_STA1_DPos        (1U)
#define FCU_SFSTA_STA1_Pos         FCU_SFSTA_STA1_DPos
#define FCU_SFSTA_STA1_Msk         (0x1UL << FCU_SFSTA_STA1_Pos)            /* 0x00000002 */
#define FCU_SFSTA_STA1             FCU_SFSTA_STA1_Msk                       /* Software fault channel 1 status bit */

#define FCU_SFSTA_STA2_DPos        (2U)
#define FCU_SFSTA_STA2_Pos         FCU_SFSTA_STA2_DPos
#define FCU_SFSTA_STA2_Msk         (0x1UL << FCU_SFSTA_STA2_Pos)            /* 0x00000004 */
#define FCU_SFSTA_STA2             FCU_SFSTA_STA2_Msk                       /* Software fault channel 2 status bit */

#define FCU_SFSTA_STA3_DPos        (3U)
#define FCU_SFSTA_STA3_Pos         FCU_SFSTA_STA3_DPos
#define FCU_SFSTA_STA3_Msk         (0x1UL << FCU_SFSTA_STA3_Pos)            /* 0x00000008 */
#define FCU_SFSTA_STA3             FCU_SFSTA_STA3_Msk                       /* Software fault channel 3 status bit */

/******************  Bits definition for FCU_SFCNT register  *****************/

#define FCU_SFCNT_CNT0_DPos        (0U)
#define FCU_SFCNT_CNT0_Pos         FCU_SFCNT_CNT0_DPos
#define FCU_SFCNT_CNT0_Msk         (0xFFUL << FCU_SFCNT_CNT0_Pos)        /* 0x000000FF */
#define FCU_SFCNT_CNT0             FCU_SFCNT_CNT0_Msk                    /* SFCNT[7:0] bits (Software fault channel 0 count) */

#define FCU_SFCNT_CNT1_DPos        (8U)
#define FCU_SFCNT_CNT1_Pos         FCU_SFCNT_CNT1_DPos
#define FCU_SFCNT_CNT1_Msk         (0xFFUL << FCU_SFCNT_CNT1_Pos)        /* 0x0000FF00 */
#define FCU_SFCNT_CNT1             FCU_SFCNT_CNT1_Msk                    /* SFCNT[15:8] bits (Software fault channel 1 count) */

#define FCU_SFCNT_CNT2_DPos        (16U)
#define FCU_SFCNT_CNT2_Pos         FCU_SFCNT_CNT2_DPos
#define FCU_SFCNT_CNT2_Msk         (0xFFUL << FCU_SFCNT_CNT2_Pos)        /* 0x00FF0000 */
#define FCU_SFCNT_CNT2             FCU_SFCNT_CNT2_Msk                    /* SFCNT[23:16] bits (Software fault channel 2 count) */

#define FCU_SFCNT_CNT3_DPos        (24U)
#define FCU_SFCNT_CNT3_Pos         FCU_SFCNT_CNT3_DPos
#define FCU_SFCNT_CNT3_Msk         (0xFFUL << FCU_SFCNT_CNT3_Pos)        /* 0xFF000000 */
#define FCU_SFCNT_CNT3             FCU_SFCNT_CNT3_Msk                    /* SFCNT[31:24] bits (Software fault channel 3 count) */

/******************  Bits definition for FCU_SFCLR register  *****************/

#define FCU_SFCLR_CLR0_DPos        (0U)
#define FCU_SFCLR_CLR0_Pos         FCU_SFCLR_CLR0_DPos
#define FCU_SFCLR_CLR0_Msk         (0x1UL << FCU_SFCLR_CLR0_Pos)         /* 0x00000001 */
#define FCU_SFCLR_CLR0             FCU_SFCLR_CLR0_Msk                    /* Software fault channel 0 clear bit */

#define FCU_SFCLR_CLR1_DPos        (1U)
#define FCU_SFCLR_CLR1_Pos         FCU_SFCLR_CLR1_DPos
#define FCU_SFCLR_CLR1_Msk         (0x1UL << FCU_SFCLR_CLR1_Pos)         /* 0x00000002 */
#define FCU_SFCLR_CLR1             FCU_SFCLR_CLR1_Msk                    /* Software fault channel 1 clear bit */

#define FCU_SFCLR_CLR2_DPos        (2U)
#define FCU_SFCLR_CLR2_Pos         FCU_SFCLR_CLR2_DPos
#define FCU_SFCLR_CLR2_Msk         (0x1UL << FCU_SFCLR_CLR2_Pos)         /* 0x00000004 */
#define FCU_SFCLR_CLR2             FCU_SFCLR_CLR2_Msk                    /* Software fault channel 2 clear bit */

#define FCU_SFCLR_CLR3_DPos        (3U)
#define FCU_SFCLR_CLR3_Pos         FCU_SFCLR_CLR3_DPos
#define FCU_SFCLR_CLR3_Msk         (0x1UL << FCU_SFCLR_CLR3_Pos)         /* 0x00000008 */
#define FCU_SFCLR_CLR3             FCU_SFCLR_CLR3_Msk                    /* Software fault channel 3 clear bit */

/******************  Bits definition for FCU_ALARM0 register  *****************/

#define FCU_ALARM0_A0_DPos          (0U)
#define FCU_ALARM0_A0_Pos           FCU_ALARM0_A0_DPos
#define FCU_ALARM0_A0_Msk           (0x1UL << FCU_ALARM0_A0_Pos)          /* 0x00000001 */
#define FCU_ALARM0_A0               FCU_ALARM0_A0_Msk                     /* FCU Channel 0 alarm bit */

#define FCU_ALARM0_A1_DPos          (1U)
#define FCU_ALARM0_A1_Pos           FCU_ALARM0_A1_DPos
#define FCU_ALARM0_A1_Msk           (0x1UL << FCU_ALARM0_A1_Pos)          /* 0x00000002 */
#define FCU_ALARM0_A1               FCU_ALARM0_A1_Msk                     /* FCU Channel 1 alarm bit */

#define FCU_ALARM0_A2_DPos          (2U)
#define FCU_ALARM0_A2_Pos           FCU_ALARM0_A2_DPos
#define FCU_ALARM0_A2_Msk           (0x1UL << FCU_ALARM0_A2_Pos)          /* 0x00000004 */
#define FCU_ALARM0_A2               FCU_ALARM0_A2_Msk                     /* FCU Channel 2 alarm bit */

#define FCU_ALARM0_A3_DPos          (3U)
#define FCU_ALARM0_A3_Pos           FCU_ALARM0_A3_DPos
#define FCU_ALARM0_A3_Msk           (0x1UL << FCU_ALARM0_A3_Pos)          /* 0x00000008 */
#define FCU_ALARM0_A3               FCU_ALARM0_A3_Msk                     /* FCU Channel 3 alarm bit */

#define FCU_ALARM0_A4_DPos          (4U)
#define FCU_ALARM0_A4_Pos           FCU_ALARM0_A4_DPos
#define FCU_ALARM0_A4_Msk           (0x1UL << FCU_ALARM0_A4_Pos)          /* 0x00000010 */
#define FCU_ALARM0_A4               FCU_ALARM0_A4_Msk                     /* FCU Channel 4 alarm bit */

#define FCU_ALARM0_A5_DPos          (5U)
#define FCU_ALARM0_A5_Pos           FCU_ALARM0_A5_DPos
#define FCU_ALARM0_A5_Msk           (0x1UL << FCU_ALARM0_A5_Pos)          /* 0x00000020 */
#define FCU_ALARM0_A5               FCU_ALARM0_A5_Msk                     /* FCU Channel 5 alarm bit */

#define FCU_ALARM0_A6_DPos          (6U)
#define FCU_ALARM0_A6_Pos           FCU_ALARM0_A6_DPos
#define FCU_ALARM0_A6_Msk           (0x1UL << FCU_ALARM0_A6_Pos)          /* 0x00000040 */
#define FCU_ALARM0_A6               FCU_ALARM0_A6_Msk                     /* FCU Channel 6 alarm bit */

#define FCU_ALARM0_A7_DPos          (7U)
#define FCU_ALARM0_A7_Pos           FCU_ALARM0_A7_DPos
#define FCU_ALARM0_A7_Msk           (0x1UL << FCU_ALARM0_A7_Pos)          /* 0x00000080 */
#define FCU_ALARM0_A7               FCU_ALARM0_A7_Msk                     /* FCU Channel 7 alarm bit */

#define FCU_ALARM0_A8_DPos          (8U)
#define FCU_ALARM0_A8_Pos           FCU_ALARM0_A8_DPos
#define FCU_ALARM0_A8_Msk           (0x1UL << FCU_ALARM0_A8_Pos)          /* 0x00000100 */
#define FCU_ALARM0_A8               FCU_ALARM0_A8_Msk                     /* FCU Channel 8 alarm bit */

#define FCU_ALARM0_A9_DPos          (9U)
#define FCU_ALARM0_A9_Pos           FCU_ALARM0_A9_DPos
#define FCU_ALARM0_A9_Msk           (0x1UL << FCU_ALARM0_A9_Pos)          /* 0x00000200 */
#define FCU_ALARM0_A9               FCU_ALARM0_A9_Msk                     /* FCU Channel 9 alarm bit */

#define FCU_ALARM0_A10_DPos         (10U)
#define FCU_ALARM0_A10_Pos          FCU_ALARM0_A10_DPos
#define FCU_ALARM0_A10_Msk          (0x1UL << FCU_ALARM0_A10_Pos)         /* 0x00000400 */
#define FCU_ALARM0_A10              FCU_ALARM0_A10_Msk                    /* FCU Channel 10 alarm bit */

#define FCU_ALARM0_A11_DPos         (11U)
#define FCU_ALARM0_A11_Pos          FCU_ALARM0_A11_DPos
#define FCU_ALARM0_A11_Msk          (0x1UL << FCU_ALARM0_A11_Pos)         /* 0x00000800 */
#define FCU_ALARM0_A11              FCU_ALARM0_A11_Msk                    /* FCU Channel 11 alarm bit */

#define FCU_ALARM0_A12_DPos         (12U)
#define FCU_ALARM0_A12_Pos          FCU_ALARM0_A12_DPos
#define FCU_ALARM0_A12_Msk          (0x1UL << FCU_ALARM0_A12_Pos)         /* 0x00001000 */
#define FCU_ALARM0_A12              FCU_ALARM0_A12_Msk                    /* FCU Channel 12 alarm bit */

#define FCU_ALARM0_A13_DPos         (13U)
#define FCU_ALARM0_A13_Pos          FCU_ALARM0_A13_DPos
#define FCU_ALARM0_A13_Msk          (0x1UL << FCU_ALARM0_A13_Pos)         /* 0x00002000 */
#define FCU_ALARM0_A13              FCU_ALARM0_A13_Msk                    /* FCU Channel 13 alarm bit */

#define FCU_ALARM0_A14_DPos         (14U)
#define FCU_ALARM0_A14_Pos          FCU_ALARM0_A14_DPos
#define FCU_ALARM0_A14_Msk          (0x1UL << FCU_ALARM0_A14_Pos)         /* 0x00004000 */
#define FCU_ALARM0_A14              FCU_ALARM0_A14_Msk                    /* FCU Channel 14 alarm bit */

#define FCU_ALARM0_A15_DPos         (15U)
#define FCU_ALARM0_A15_Pos          FCU_ALARM0_A15_DPos
#define FCU_ALARM0_A15_Msk          (0x1UL << FCU_ALARM0_A15_Pos)         /* 0x00008000 */
#define FCU_ALARM0_A15              FCU_ALARM0_A15_Msk                    /* FCU Channel 15 alarm bit */

#define FCU_ALARM0_A16_DPos         (16U)
#define FCU_ALARM0_A16_Pos          FCU_ALARM0_A16_DPos
#define FCU_ALARM0_A16_Msk          (0x1UL << FCU_ALARM0_A16_Pos)         /* 0x00010000 */
#define FCU_ALARM0_A16              FCU_ALARM0_A16_Msk                    /* FCU Channel 16 alarm bit */

#define FCU_ALARM0_A17_DPos         (17U)
#define FCU_ALARM0_A17_Pos          FCU_ALARM0_A17_DPos
#define FCU_ALARM0_A17_Msk          (0x1UL << FCU_ALARM0_A17_Pos)         /* 0x00020000 */
#define FCU_ALARM0_A17              FCU_ALARM0_A17_Msk                    /* FCU Channel 17 alarm bit */

#define FCU_ALARM0_A18_DPos         (18U)
#define FCU_ALARM0_A18_Pos          FCU_ALARM0_A18_DPos
#define FCU_ALARM0_A18_Msk          (0x1UL << FCU_ALARM0_A18_Pos)         /* 0x00040000 */
#define FCU_ALARM0_A18              FCU_ALARM0_A18_Msk                    /* FCU Channel 18 alarm bit */

#define FCU_ALARM0_A19_DPos         (19U)
#define FCU_ALARM0_A19_Pos          FCU_ALARM0_A19_DPos
#define FCU_ALARM0_A19_Msk          (0x1UL << FCU_ALARM0_A19_Pos)         /* 0x00080000 */
#define FCU_ALARM0_A19              FCU_ALARM0_A19_Msk                    /* FCU Channel 19 alarm bit */

#define FCU_ALARM0_A20_DPos         (20U)
#define FCU_ALARM0_A20_Pos          FCU_ALARM0_A20_DPos
#define FCU_ALARM0_A20_Msk          (0x1UL << FCU_ALARM0_A20_Pos)         /* 0x00100000 */
#define FCU_ALARM0_A20              FCU_ALARM0_A20_Msk                    /* FCU Channel 20 alarm bit */

#define FCU_ALARM0_A21_DPos         (21U)
#define FCU_ALARM0_A21_Pos          FCU_ALARM0_A21_DPos
#define FCU_ALARM0_A21_Msk          (0x1UL << FCU_ALARM0_A21_Pos)         /* 0x00200000 */
#define FCU_ALARM0_A21              FCU_ALARM0_A21_Msk                    /* FCU Channel 21 alarm bit */

#define FCU_ALARM0_A22_DPos         (22U)
#define FCU_ALARM0_A22_Pos          FCU_ALARM0_A22_DPos
#define FCU_ALARM0_A22_Msk          (0x1UL << FCU_ALARM0_A22_Pos)         /* 0x00400000 */
#define FCU_ALARM0_A22              FCU_ALARM0_A22_Msk                    /* FCU Channel 22 alarm bit */

#define FCU_ALARM0_A23_DPos         (23U)
#define FCU_ALARM0_A23_Pos          FCU_ALARM0_A23_DPos
#define FCU_ALARM0_A23_Msk          (0x1UL << FCU_ALARM0_A23_Pos)         /* 0x00800000 */
#define FCU_ALARM0_A23              FCU_ALARM0_A23_Msk                    /* FCU Channel 23 alarm bit */

#define FCU_ALARM0_A24_DPos         (24U)
#define FCU_ALARM0_A24_Pos          FCU_ALARM0_A24_DPos
#define FCU_ALARM0_A24_Msk          (0x1UL << FCU_ALARM0_A24_Pos)         /* 0x01000000 */
#define FCU_ALARM0_A24              FCU_ALARM0_A24_Msk                    /* FCU Channel 24 alarm bit */

#define FCU_ALARM0_A25_DPos         (25U)
#define FCU_ALARM0_A25_Pos          FCU_ALARM0_A25_DPos
#define FCU_ALARM0_A25_Msk          (0x1UL << FCU_ALARM0_A25_Pos)         /* 0x02000000 */
#define FCU_ALARM0_A25              FCU_ALARM0_A25_Msk                    /* FCU Channel 25 alarm bit */

#define FCU_ALARM0_A26_DPos         (26U)
#define FCU_ALARM0_A26_Pos          FCU_ALARM0_A26_DPos
#define FCU_ALARM0_A26_Msk          (0x1UL << FCU_ALARM0_A26_Pos)         /* 0x04000000 */
#define FCU_ALARM0_A26              FCU_ALARM0_A26_Msk                    /* FCU Channel 26 alarm bit */

#define FCU_ALARM0_A27_DPos         (27U)
#define FCU_ALARM0_A27_Pos          FCU_ALARM0_A27_DPos
#define FCU_ALARM0_A27_Msk          (0x1UL << FCU_ALARM0_A27_Pos)         /* 0x08000000 */
#define FCU_ALARM0_A27              FCU_ALARM0_A27_Msk                    /* FCU Channel 27 alarm bit */

#define FCU_ALARM0_A28_DPos         (28U)
#define FCU_ALARM0_A28_Pos          FCU_ALARM0_A28_DPos
#define FCU_ALARM0_A28_Msk          (0x1UL << FCU_ALARM0_A28_Pos)         /* 0x10000000 */
#define FCU_ALARM0_A28              FCU_ALARM0_A28_Msk                    /* FCU Channel 28 alarm bit */

#define FCU_ALARM0_A29_DPos         (29U)
#define FCU_ALARM0_A29_Pos          FCU_ALARM0_A29_DPos
#define FCU_ALARM0_A29_Msk          (0x1UL << FCU_ALARM0_A29_Pos)         /* 0x20000000 */
#define FCU_ALARM0_A29              FCU_ALARM0_A29_Msk                    /* FCU Channel 29 alarm bit */

#define FCU_ALARM0_A30_DPos         (30U)
#define FCU_ALARM0_A30_Pos          FCU_ALARM0_A30_DPos
#define FCU_ALARM0_A30_Msk          (0x1UL << FCU_ALARM0_A30_Pos)         /* 0x40000000 */
#define FCU_ALARM0_A30              FCU_ALARM0_A30_Msk                    /* FCU Channel 30 alarm bit */

#define FCU_ALARM0_A31_DPos         (31U)
#define FCU_ALARM0_A31_Pos          FCU_ALARM0_A31_DPos
#define FCU_ALARM0_A31_Msk          (0x1UL << FCU_ALARM0_A31_Pos)         /* 0x80000000 */
#define FCU_ALARM0_A31              FCU_ALARM0_A31_Msk                    /* FCU Channel 31 alarm bit */

/******************  Bits definition for FCU_ALARM1 register  *****************/

#define FCU_ALARM1_A32_DPos         (0U)
#define FCU_ALARM1_A32_Pos          FCU_ALARM1_A32_DPos
#define FCU_ALARM1_A32_Msk          (0x1UL << FCU_ALARM1_A32_Pos)         /* 0x00000001 */
#define FCU_ALARM1_A32              FCU_ALARM1_A32_Msk                    /* FCU Channel 32 alarm bit */

#define FCU_ALARM1_A33_DPos         (1U)
#define FCU_ALARM1_A33_Pos          FCU_ALARM1_A33_DPos
#define FCU_ALARM1_A33_Msk          (0x1UL << FCU_ALARM1_A33_Pos)         /* 0x00000002 */
#define FCU_ALARM1_A33              FCU_ALARM1_A33_Msk                    /* FCU Channel 33 alarm bit */

#define FCU_ALARM1_A34_DPos         (2U)
#define FCU_ALARM1_A34_Pos          FCU_ALARM1_A34_DPos
#define FCU_ALARM1_A34_Msk          (0x1UL << FCU_ALARM1_A34_Pos)         /* 0x00000004 */
#define FCU_ALARM1_A34              FCU_ALARM1_A34_Msk                    /* FCU Channel 34 alarm bit */

#define FCU_ALARM1_A35_DPos         (3U)
#define FCU_ALARM1_A35_Pos          FCU_ALARM1_A35_DPos
#define FCU_ALARM1_A35_Msk          (0x1UL << FCU_ALARM1_A35_Pos)         /* 0x00000008 */
#define FCU_ALARM1_A35              FCU_ALARM1_A35_Msk                    /* FCU Channel 35 alarm bit */

#define FCU_ALARM1_A36_DPos         (4U)
#define FCU_ALARM1_A36_Pos          FCU_ALARM1_A36_DPos
#define FCU_ALARM1_A36_Msk          (0x1UL << FCU_ALARM1_A36_Pos)         /* 0x00000010 */
#define FCU_ALARM1_A36              FCU_ALARM1_A36_Msk                    /* FCU Channel 36 alarm bit */

#define FCU_ALARM1_A37_DPos         (5U)
#define FCU_ALARM1_A37_Pos          FCU_ALARM1_A37_DPos
#define FCU_ALARM1_A37_Msk          (0x1UL << FCU_ALARM1_A37_Pos)         /* 0x00000020 */
#define FCU_ALARM1_A37              FCU_ALARM1_A37_Msk                    /* FCU Channel 37 alarm bit */

#define FCU_ALARM1_A38_DPos         (6U)
#define FCU_ALARM1_A38_Pos          FCU_ALARM1_A38_DPos
#define FCU_ALARM1_A38_Msk          (0x1UL << FCU_ALARM1_A38_Pos)         /* 0x00000040 */
#define FCU_ALARM1_A38              FCU_ALARM1_A38_Msk                    /* FCU Channel 38 alarm bit */

#define FCU_ALARM1_A39_DPos         (7U)
#define FCU_ALARM1_A39_Pos          FCU_ALARM1_A39_DPos
#define FCU_ALARM1_A39_Msk          (0x1UL << FCU_ALARM1_A39_Pos)         /* 0x00000080 */
#define FCU_ALARM1_A39              FCU_ALARM1_A39_Msk                    /* FCU Channel 39 alarm bit */

#define FCU_ALARM1_A40_DPos         (8U)
#define FCU_ALARM1_A40_Pos          FCU_ALARM1_A40_DPos
#define FCU_ALARM1_A40_Msk          (0x1UL << FCU_ALARM1_A40_Pos)         /* 0x00000100 */
#define FCU_ALARM1_A40              FCU_ALARM1_A40_Msk                    /* FCU Channel 40 alarm bit */

#define FCU_ALARM1_A41_DPos         (9U)
#define FCU_ALARM1_A41_Pos          FCU_ALARM1_A41_DPos
#define FCU_ALARM1_A41_Msk          (0x1UL << FCU_ALARM1_A41_Pos)         /* 0x00000200 */
#define FCU_ALARM1_A41              FCU_ALARM1_A41_Msk                    /* FCU Channel 41 alarm bit */

/******************  Bits definition for FCU_FAULT0 register  *****************/

#define FCU_FAULT0_F0_DPos          (0U)
#define FCU_FAULT0_F0_Pos           FCU_FAULT0_F0_DPos
#define FCU_FAULT0_F0_Msk           (0x1UL << FCU_FAULT0_F0_Pos)          /* 0x00000001 */
#define FCU_FAULT0_F0               FCU_FAULT0_F0_Msk                     /* FCU Channel 0 fault bit */

#define FCU_FAULT0_F1_DPos          (1U)
#define FCU_FAULT0_F1_Pos           FCU_FAULT0_F1_DPos
#define FCU_FAULT0_F1_Msk           (0x1UL << FCU_FAULT0_F1_Pos)          /* 0x00000002 */
#define FCU_FAULT0_F1               FCU_FAULT0_F1_Msk                     /* FCU Channel 1 fault bit */

#define FCU_FAULT0_F2_DPos          (2U)
#define FCU_FAULT0_F2_Pos           FCU_FAULT0_F2_DPos
#define FCU_FAULT0_F2_Msk           (0x1UL << FCU_FAULT0_F2_Pos)          /* 0x00000004 */
#define FCU_FAULT0_F2               FCU_FAULT0_F2_Msk                     /* FCU Channel 2 fault bit */

#define FCU_FAULT0_F3_DPos          (3U)
#define FCU_FAULT0_F3_Pos           FCU_FAULT0_F3_DPos
#define FCU_FAULT0_F3_Msk           (0x1UL << FCU_FAULT0_F3_Pos)          /* 0x00000008 */
#define FCU_FAULT0_F3               FCU_FAULT0_F3_Msk                     /* FCU Channel 3 fault bit */

#define FCU_FAULT0_F4_DPos          (4U)
#define FCU_FAULT0_F4_Pos           FCU_FAULT0_F4_DPos
#define FCU_FAULT0_F4_Msk           (0x1UL << FCU_FAULT0_F4_Pos)          /* 0x00000010 */
#define FCU_FAULT0_F4               FCU_FAULT0_F4_Msk                     /* FCU Channel 4 fault bit */

#define FCU_FAULT0_F5_DPos          (5U)
#define FCU_FAULT0_F5_Pos           FCU_FAULT0_F5_DPos
#define FCU_FAULT0_F5_Msk           (0x1UL << FCU_FAULT0_F5_Pos)          /* 0x00000020 */
#define FCU_FAULT0_F5               FCU_FAULT0_F5_Msk                     /* FCU Channel 5 fault bit */

#define FCU_FAULT0_F6_DPos          (6U)
#define FCU_FAULT0_F6_Pos           FCU_FAULT0_F6_DPos
#define FCU_FAULT0_F6_Msk           (0x1UL << FCU_FAULT0_F6_Pos)          /* 0x00000040 */
#define FCU_FAULT0_F6               FCU_FAULT0_F6_Msk                     /* FCU Channel 6 fault bit */

#define FCU_FAULT0_F7_DPos          (7U)
#define FCU_FAULT0_F7_Pos           FCU_FAULT0_F7_DPos
#define FCU_FAULT0_F7_Msk           (0x1UL << FCU_FAULT0_F7_Pos)          /* 0x00000080 */
#define FCU_FAULT0_F7               FCU_FAULT0_F7_Msk                     /* FCU Channel 7 fault bit */

#define FCU_FAULT0_F8_DPos          (8U)
#define FCU_FAULT0_F8_Pos           FCU_FAULT0_F8_DPos
#define FCU_FAULT0_F8_Msk           (0x1UL << FCU_FAULT0_F8_Pos)          /* 0x00000100 */
#define FCU_FAULT0_F8               FCU_FAULT0_F8_Msk                     /* FCU Channel 8 fault bit */

#define FCU_FAULT0_F9_DPos          (9U)
#define FCU_FAULT0_F9_Pos           FCU_FAULT0_F9_DPos
#define FCU_FAULT0_F9_Msk           (0x1UL << FCU_FAULT0_F9_Pos)          /* 0x00000200 */
#define FCU_FAULT0_F9               FCU_FAULT0_F9_Msk                     /* FCU Channel 9 fault bit */

#define FCU_FAULT0_F10_DPos         (10U)
#define FCU_FAULT0_F10_Pos          FCU_FAULT0_F10_DPos
#define FCU_FAULT0_F10_Msk          (0x1UL << FCU_FAULT0_F10_Pos)         /* 0x00000400 */
#define FCU_FAULT0_F10              FCU_FAULT0_F10_Msk                    /* FCU Channel 10 fault bit */

#define FCU_FAULT0_F11_DPos         (11U)
#define FCU_FAULT0_F11_Pos          FCU_FAULT0_F11_DPos
#define FCU_FAULT0_F11_Msk          (0x1UL << FCU_FAULT0_F11_Pos)         /* 0x00000800 */
#define FCU_FAULT0_F11              FCU_FAULT0_F11_Msk                    /* FCU Channel 11 fault bit */

#define FCU_FAULT0_F12_DPos         (12U)
#define FCU_FAULT0_F12_Pos          FCU_FAULT0_F12_DPos
#define FCU_FAULT0_F12_Msk          (0x1UL << FCU_FAULT0_F12_Pos)         /* 0x00001000 */
#define FCU_FAULT0_F12              FCU_FAULT0_F12_Msk                    /* FCU Channel 12 fault bit */

#define FCU_FAULT0_F13_DPos         (13U)
#define FCU_FAULT0_F13_Pos          FCU_FAULT0_F13_DPos
#define FCU_FAULT0_F13_Msk          (0x1UL << FCU_FAULT0_F13_Pos)         /* 0x00002000 */
#define FCU_FAULT0_F13              FCU_FAULT0_F13_Msk                    /* FCU Channel 13 fault bit */

#define FCU_FAULT0_F14_DPos         (14U)
#define FCU_FAULT0_F14_Pos          FCU_FAULT0_F14_DPos
#define FCU_FAULT0_F14_Msk          (0x1UL << FCU_FAULT0_F14_Pos)         /* 0x00004000 */
#define FCU_FAULT0_F14              FCU_FAULT0_F14_Msk                    /* FCU Channel 14 fault bit */

#define FCU_FAULT0_F15_DPos         (15U)
#define FCU_FAULT0_F15_Pos          FCU_FAULT0_F15_DPos
#define FCU_FAULT0_F15_Msk          (0x1UL << FCU_FAULT0_F15_Pos)         /* 0x00008000 */
#define FCU_FAULT0_F15              FCU_FAULT0_F15_Msk                    /* FCU Channel 15 fault bit */

#define FCU_FAULT0_F16_DPos         (16U)
#define FCU_FAULT0_F16_Pos          FCU_FAULT0_F16_DPos
#define FCU_FAULT0_F16_Msk          (0x1UL << FCU_FAULT0_F16_Pos)         /* 0x00010000 */
#define FCU_FAULT0_F16              FCU_FAULT0_F16_Msk                    /* FCU Channel 16 fault bit */

#define FCU_FAULT0_F17_DPos         (17U)
#define FCU_FAULT0_F17_Pos          FCU_FAULT0_F17_DPos
#define FCU_FAULT0_F17_Msk          (0x1UL << FCU_FAULT0_F17_Pos)         /* 0x00020000 */
#define FCU_FAULT0_F17              FCU_FAULT0_F17_Msk                    /* FCU Channel 17 fault bit */

#define FCU_FAULT0_F18_DPos         (18U)
#define FCU_FAULT0_F18_Pos          FCU_FAULT0_F18_DPos
#define FCU_FAULT0_F18_Msk          (0x1UL << FCU_FAULT0_F18_Pos)         /* 0x00040000 */
#define FCU_FAULT0_F18              FCU_FAULT0_F18_Msk                    /* FCU Channel 18 fault bit */

#define FCU_FAULT0_F19_DPos         (19U)
#define FCU_FAULT0_F19_Pos          FCU_FAULT0_F19_DPos
#define FCU_FAULT0_F19_Msk          (0x1UL << FCU_FAULT0_F19_Pos)         /* 0x00080000 */
#define FCU_FAULT0_F19              FCU_FAULT0_F19_Msk                    /* FCU Channel 19 fault bit */

#define FCU_FAULT0_F20_DPos         (20U)
#define FCU_FAULT0_F20_Pos          FCU_FAULT0_F20_DPos
#define FCU_FAULT0_F20_Msk          (0x1UL << FCU_FAULT0_F20_Pos)         /* 0x00100000 */
#define FCU_FAULT0_F20              FCU_FAULT0_F20_Msk                    /* FCU Channel 20 fault bit */

#define FCU_FAULT0_F21_DPos         (21U)
#define FCU_FAULT0_F21_Pos          FCU_FAULT0_F21_DPos
#define FCU_FAULT0_F21_Msk          (0x1UL << FCU_FAULT0_F21_Pos)         /* 0x00200000 */
#define FCU_FAULT0_F21              FCU_FAULT0_F21_Msk                    /* FCU Channel 21 fault bit */

#define FCU_FAULT0_F22_DPos         (22U)
#define FCU_FAULT0_F22_Pos          FCU_FAULT0_F22_DPos
#define FCU_FAULT0_F22_Msk          (0x1UL << FCU_FAULT0_F22_Pos)         /* 0x00400000 */
#define FCU_FAULT0_F22              FCU_FAULT0_F22_Msk                    /* FCU Channel 22 fault bit */

#define FCU_FAULT0_F23_DPos         (23U)
#define FCU_FAULT0_F23_Pos          FCU_FAULT0_F23_DPos
#define FCU_FAULT0_F23_Msk          (0x1UL << FCU_FAULT0_F23_Pos)         /* 0x00800000 */
#define FCU_FAULT0_F23              FCU_FAULT0_F23_Msk                    /* FCU Channel 23 fault bit */

#define FCU_FAULT0_F24_DPos         (24U)
#define FCU_FAULT0_F24_Pos          FCU_FAULT0_F24_DPos
#define FCU_FAULT0_F24_Msk          (0x1UL << FCU_FAULT0_F24_Pos)         /* 0x01000000 */
#define FCU_FAULT0_F24              FCU_FAULT0_F24_Msk                    /* FCU Channel 24 fault bit */

#define FCU_FAULT0_F25_DPos         (25U)
#define FCU_FAULT0_F25_Pos          FCU_FAULT0_F25_DPos
#define FCU_FAULT0_F25_Msk          (0x1UL << FCU_FAULT0_F25_Pos)         /* 0x02000000 */
#define FCU_FAULT0_F25              FCU_FAULT0_F25_Msk                    /* FCU Channel 25 fault bit */

#define FCU_FAULT0_F26_DPos         (26U)
#define FCU_FAULT0_F26_Pos          FCU_FAULT0_F26_DPos
#define FCU_FAULT0_F26_Msk          (0x1UL << FCU_FAULT0_F26_Pos)         /* 0x04000000 */
#define FCU_FAULT0_F26              FCU_FAULT0_F26_Msk                    /* FCU Channel 26 fault bit */

#define FCU_FAULT0_F27_DPos         (27U)
#define FCU_FAULT0_F27_Pos          FCU_FAULT0_F27_DPos
#define FCU_FAULT0_F27_Msk          (0x1UL << FCU_FAULT0_F27_Pos)         /* 0x08000000 */
#define FCU_FAULT0_F27              FCU_FAULT0_F27_Msk                    /* FCU Channel 27 fault bit */

#define FCU_FAULT0_F28_DPos         (28U)
#define FCU_FAULT0_F28_Pos          FCU_FAULT0_F28_DPos
#define FCU_FAULT0_F28_Msk          (0x1UL << FCU_FAULT0_F28_Pos)         /* 0x10000000 */
#define FCU_FAULT0_F28              FCU_FAULT0_F28_Msk                    /* FCU Channel 28 fault bit */

#define FCU_FAULT0_F29_DPos         (29U)
#define FCU_FAULT0_F29_Pos          FCU_FAULT0_F29_DPos
#define FCU_FAULT0_F29_Msk          (0x1UL << FCU_FAULT0_F29_Pos)         /* 0x20000000 */
#define FCU_FAULT0_F29              FCU_FAULT0_F29_Msk                    /* FCU Channel 29 fault bit */

#define FCU_FAULT0_F30_DPos         (30U)
#define FCU_FAULT0_F30_Pos          FCU_FAULT0_F30_DPos
#define FCU_FAULT0_F30_Msk          (0x1UL << FCU_FAULT0_F30_Pos)         /* 0x40000000 */
#define FCU_FAULT0_F30              FCU_FAULT0_F30_Msk                    /* FCU Channel 30 fault bit */

#define FCU_FAULT0_F31_DPos         (31U)
#define FCU_FAULT0_F31_Pos          FCU_FAULT0_F31_DPos
#define FCU_FAULT0_F31_Msk          (0x1UL << FCU_FAULT0_F31_Pos)         /* 0x80000000 */
#define FCU_FAULT0_F31              FCU_FAULT0_F31_Msk                    /* FCU Channel 31 fault bit */

/******************  Bits definition for FCU_FAULT1 register  *****************/

#define FCU_FAULT1_F32_DPos         (0U)
#define FCU_FAULT1_F32_Pos          FCU_FAULT1_F32_DPos
#define FCU_FAULT1_F32_Msk          (0x1UL << FCU_FAULT1_F32_Pos)         /* 0x00000001 */
#define FCU_FAULT1_F32              FCU_FAULT1_F32_Msk                    /* FCU Channel 32 fault bit */

#define FCU_FAULT1_F33_DPos         (1U)
#define FCU_FAULT1_F33_Pos          FCU_FAULT1_F33_DPos
#define FCU_FAULT1_F33_Msk          (0x1UL << FCU_FAULT1_F33_Pos)         /* 0x00000002 */
#define FCU_FAULT1_F33              FCU_FAULT1_F33_Msk                    /* FCU Channel 33 fault bit */

#define FCU_FAULT1_F34_DPos         (2U)
#define FCU_FAULT1_F34_Pos          FCU_FAULT1_F34_DPos
#define FCU_FAULT1_F34_Msk          (0x1UL << FCU_FAULT1_F34_Pos)         /* 0x00000004 */
#define FCU_FAULT1_F34              FCU_FAULT1_F34_Msk                    /* FCU Channel 34 fault bit */

#define FCU_FAULT1_F35_DPos         (3U)
#define FCU_FAULT1_F35_Pos          FCU_FAULT1_F35_DPos
#define FCU_FAULT1_F35_Msk          (0x1UL << FCU_FAULT1_F35_Pos)         /* 0x00000008 */
#define FCU_FAULT1_F35              FCU_FAULT1_F35_Msk                    /* FCU Channel 35 fault bit */

#define FCU_FAULT1_F36_DPos         (4U)
#define FCU_FAULT1_F36_Pos          FCU_FAULT1_F36_DPos
#define FCU_FAULT1_F36_Msk          (0x1UL << FCU_FAULT1_F36_Pos)         /* 0x00000010 */
#define FCU_FAULT1_F36              FCU_FAULT1_F36_Msk                    /* FCU Channel 36 fault bit */

#define FCU_FAULT1_F37_DPos         (5U)
#define FCU_FAULT1_F37_Pos          FCU_FAULT1_F37_DPos
#define FCU_FAULT1_F37_Msk          (0x1UL << FCU_FAULT1_F37_Pos)         /* 0x00000020 */
#define FCU_FAULT1_F37              FCU_FAULT1_F37_Msk                    /* FCU Channel 37 fault bit */

#define FCU_FAULT1_F38_DPos         (6U)
#define FCU_FAULT1_F38_Pos          FCU_FAULT1_F38_DPos
#define FCU_FAULT1_F38_Msk          (0x1UL << FCU_FAULT1_F38_Pos)         /* 0x00000040 */
#define FCU_FAULT1_F38              FCU_FAULT1_F38_Msk                    /* FCU Channel 38 fault bit */

#define FCU_FAULT1_F39_DPos         (7U)
#define FCU_FAULT1_F39_Pos          FCU_FAULT1_F39_DPos
#define FCU_FAULT1_F39_Msk          (0x1UL << FCU_FAULT1_F39_Pos)         /* 0x00000080 */
#define FCU_FAULT1_F39              FCU_FAULT1_F39_Msk                    /* FCU Channel 39 fault bit */

#define FCU_FAULT1_F40_DPos         (8U)
#define FCU_FAULT1_F40_Pos          FCU_FAULT1_F40_DPos
#define FCU_FAULT1_F40_Msk          (0x1UL << FCU_FAULT1_F40_Pos)         /* 0x00000100 */
#define FCU_FAULT1_F40              FCU_FAULT1_F40_Msk                    /* FCU Channel 40 fault bit */

#define FCU_FAULT1_F41_DPos         (9U)
#define FCU_FAULT1_F41_Pos          FCU_FAULT1_F41_DPos
#define FCU_FAULT1_F41_Msk          (0x1UL << FCU_FAULT1_F41_Pos)         /* 0x00000200 */
#define FCU_FAULT1_F41              FCU_FAULT1_F41_Msk                    /* FCU Channel 41 fault bit */

/******************  Bits definition for FCU_CLEAR0 register  *****************/

#define FCU_CLEAR0_C0_DPos          (0U)
#define FCU_CLEAR0_C0_Pos           FCU_CLEAR0_C0_DPos
#define FCU_CLEAR0_C0_Msk           (0x1UL << FCU_CLEAR0_C0_Pos)          /* 0x00000001 */
#define FCU_CLEAR0_C0               FCU_CLEAR0_C0_Msk                     /* FCU Channel 0 clear bit */

#define FCU_CLEAR0_C1_DPos          (1U)
#define FCU_CLEAR0_C1_Pos           FCU_CLEAR0_C1_DPos
#define FCU_CLEAR0_C1_Msk           (0x1UL << FCU_CLEAR0_C1_Pos)          /* 0x00000002 */
#define FCU_CLEAR0_C1               FCU_CLEAR0_C1_Msk                     /* FCU Channel 1 clear bit */

#define FCU_CLEAR0_C2_DPos          (2U)
#define FCU_CLEAR0_C2_Pos           FCU_CLEAR0_C2_DPos
#define FCU_CLEAR0_C2_Msk           (0x1UL << FCU_CLEAR0_C2_Pos)          /* 0x00000004 */
#define FCU_CLEAR0_C2               FCU_CLEAR0_C2_Msk                     /* FCU Channel 2 clear bit */

#define FCU_CLEAR0_C3_DPos          (3U)
#define FCU_CLEAR0_C3_Pos           FCU_CLEAR0_C3_DPos
#define FCU_CLEAR0_C3_Msk           (0x1UL << FCU_CLEAR0_C3_Pos)          /* 0x00000008 */
#define FCU_CLEAR0_C3               FCU_CLEAR0_C3_Msk                     /* FCU Channel 3 clear bit */

#define FCU_CLEAR0_C4_DPos          (4U)
#define FCU_CLEAR0_C4_Pos           FCU_CLEAR0_C4_DPos
#define FCU_CLEAR0_C4_Msk           (0x1UL << FCU_CLEAR0_C4_Pos)          /* 0x00000010 */
#define FCU_CLEAR0_C4               FCU_CLEAR0_C4_Msk                     /* FCU Channel 4 clear bit */

#define FCU_CLEAR0_C5_DPos          (5U)
#define FCU_CLEAR0_C5_Pos           FCU_CLEAR0_C5_DPos
#define FCU_CLEAR0_C5_Msk           (0x1UL << FCU_CLEAR0_C5_Pos)          /* 0x00000020 */
#define FCU_CLEAR0_C5               FCU_CLEAR0_C5_Msk                     /* FCU Channel 5 clear bit */

#define FCU_CLEAR0_C6_DPos          (6U)
#define FCU_CLEAR0_C6_Pos           FCU_CLEAR0_C6_DPos
#define FCU_CLEAR0_C6_Msk           (0x1UL << FCU_CLEAR0_C6_Pos)          /* 0x00000040 */
#define FCU_CLEAR0_C6               FCU_CLEAR0_C6_Msk                     /* FCU Channel 6 clear bit */

#define FCU_CLEAR0_C7_DPos          (7U)
#define FCU_CLEAR0_C7_Pos           FCU_CLEAR0_C7_DPos
#define FCU_CLEAR0_C7_Msk           (0x1UL << FCU_CLEAR0_C7_Pos)          /* 0x00000080 */
#define FCU_CLEAR0_C7               FCU_CLEAR0_C7_Msk                     /* FCU Channel 7 clear bit */

#define FCU_CLEAR0_C8_DPos          (8U)
#define FCU_CLEAR0_C8_Pos           FCU_CLEAR0_C8_DPos
#define FCU_CLEAR0_C8_Msk           (0x1UL << FCU_CLEAR0_C8_Pos)          /* 0x00000100 */
#define FCU_CLEAR0_C8               FCU_CLEAR0_C8_Msk                     /* FCU Channel 8 clear bit */

#define FCU_CLEAR0_C9_DPos          (9U)
#define FCU_CLEAR0_C9_Pos           FCU_CLEAR0_C9_DPos
#define FCU_CLEAR0_C9_Msk           (0x1UL << FCU_CLEAR0_C9_Pos)          /* 0x00000200 */
#define FCU_CLEAR0_C9               FCU_CLEAR0_C9_Msk                     /* FCU Channel 9 clear bit */

#define FCU_CLEAR0_C10_DPos         (10U)
#define FCU_CLEAR0_C10_Pos          FCU_CLEAR0_C10_DPos
#define FCU_CLEAR0_C10_Msk          (0x1UL << FCU_CLEAR0_C10_Pos)         /* 0x00000400 */
#define FCU_CLEAR0_C10              FCU_CLEAR0_C10_Msk                    /* FCU Channel 10 clear bit */

#define FCU_CLEAR0_C11_DPos         (11U)
#define FCU_CLEAR0_C11_Pos          FCU_CLEAR0_C11_DPos
#define FCU_CLEAR0_C11_Msk          (0x1UL << FCU_CLEAR0_C11_Pos)         /* 0x00000800 */
#define FCU_CLEAR0_C11              FCU_CLEAR0_C11_Msk                    /* FCU Channel 11 clear bit */

#define FCU_CLEAR0_C12_DPos         (12U)
#define FCU_CLEAR0_C12_Pos          FCU_CLEAR0_C12_DPos
#define FCU_CLEAR0_C12_Msk          (0x1UL << FCU_CLEAR0_C12_Pos)         /* 0x00001000 */
#define FCU_CLEAR0_C12              FCU_CLEAR0_C12_Msk                    /* FCU Channel 12 clear bit */

#define FCU_CLEAR0_C13_DPos         (13U)
#define FCU_CLEAR0_C13_Pos          FCU_CLEAR0_C13_DPos
#define FCU_CLEAR0_C13_Msk          (0x1UL << FCU_CLEAR0_C13_Pos)         /* 0x00002000 */
#define FCU_CLEAR0_C13              FCU_CLEAR0_C13_Msk                    /* FCU Channel 13 clear bit */

#define FCU_CLEAR0_C14_DPos         (14U)
#define FCU_CLEAR0_C14_Pos          FCU_CLEAR0_C14_DPos
#define FCU_CLEAR0_C14_Msk          (0x1UL << FCU_CLEAR0_C14_Pos)         /* 0x00004000 */
#define FCU_CLEAR0_C14              FCU_CLEAR0_C14_Msk                    /* FCU Channel 14 clear bit */

#define FCU_CLEAR0_C15_DPos         (15U)
#define FCU_CLEAR0_C15_Pos          FCU_CLEAR0_C15_DPos
#define FCU_CLEAR0_C15_Msk          (0x1UL << FCU_CLEAR0_C15_Pos)         /* 0x00008000 */
#define FCU_CLEAR0_C15              FCU_CLEAR0_C15_Msk                    /* FCU Channel 15 clear bit */

#define FCU_CLEAR0_C16_DPos         (16U)
#define FCU_CLEAR0_C16_Pos          FCU_CLEAR0_C16_DPos
#define FCU_CLEAR0_C16_Msk          (0x1UL << FCU_CLEAR0_C16_Pos)         /* 0x00010000 */
#define FCU_CLEAR0_C16              FCU_CLEAR0_C16_Msk                    /* FCU Channel 16 clear bit */

#define FCU_CLEAR0_C17_DPos         (17U)
#define FCU_CLEAR0_C17_Pos          FCU_CLEAR0_C17_DPos
#define FCU_CLEAR0_C17_Msk          (0x1UL << FCU_CLEAR0_C17_Pos)         /* 0x00020000 */
#define FCU_CLEAR0_C17              FCU_CLEAR0_C17_Msk                    /* FCU Channel 17 clear bit */

#define FCU_CLEAR0_C18_DPos         (18U)
#define FCU_CLEAR0_C18_Pos          FCU_CLEAR0_C18_DPos
#define FCU_CLEAR0_C18_Msk          (0x1UL << FCU_CLEAR0_C18_Pos)         /* 0x00040000 */
#define FCU_CLEAR0_C18              FCU_CLEAR0_C18_Msk                    /* FCU Channel 18 clear bit */

#define FCU_CLEAR0_C19_DPos         (19U)
#define FCU_CLEAR0_C19_Pos          FCU_CLEAR0_C19_DPos
#define FCU_CLEAR0_C19_Msk          (0x1UL << FCU_CLEAR0_C19_Pos)         /* 0x00080000 */
#define FCU_CLEAR0_C19              FCU_CLEAR0_C19_Msk                    /* FCU Channel 19 clear bit */

#define FCU_CLEAR0_C20_DPos         (20U)
#define FCU_CLEAR0_C20_Pos          FCU_CLEAR0_C20_DPos
#define FCU_CLEAR0_C20_Msk          (0x1UL << FCU_CLEAR0_C20_Pos)         /* 0x00100000 */
#define FCU_CLEAR0_C20              FCU_CLEAR0_C20_Msk                    /* FCU Channel 20 clear bit */

#define FCU_CLEAR0_C21_DPos         (21U)
#define FCU_CLEAR0_C21_Pos          FCU_CLEAR0_C21_DPos
#define FCU_CLEAR0_C21_Msk          (0x1UL << FCU_CLEAR0_C21_Pos)         /* 0x00200000 */
#define FCU_CLEAR0_C21              FCU_CLEAR0_C21_Msk                    /* FCU Channel 21 clear bit */

#define FCU_CLEAR0_C22_DPos         (22U)
#define FCU_CLEAR0_C22_Pos          FCU_CLEAR0_C22_DPos
#define FCU_CLEAR0_C22_Msk          (0x1UL << FCU_CLEAR0_C22_Pos)         /* 0x00400000 */
#define FCU_CLEAR0_C22              FCU_CLEAR0_C22_Msk                    /* FCU Channel 22 clear bit */

#define FCU_CLEAR0_C23_DPos         (23U)
#define FCU_CLEAR0_C23_Pos          FCU_CLEAR0_C23_DPos
#define FCU_CLEAR0_C23_Msk          (0x1UL << FCU_CLEAR0_C23_Pos)         /* 0x00800000 */
#define FCU_CLEAR0_C23              FCU_CLEAR0_C23_Msk                    /* FCU Channel 23 clear bit */

#define FCU_CLEAR0_C24_DPos         (24U)
#define FCU_CLEAR0_C24_Pos          FCU_CLEAR0_C24_DPos
#define FCU_CLEAR0_C24_Msk          (0x1UL << FCU_CLEAR0_C24_Pos)         /* 0x01000000 */
#define FCU_CLEAR0_C24              FCU_CLEAR0_C24_Msk                    /* FCU Channel 24 clear bit */

#define FCU_CLEAR0_C25_DPos         (25U)
#define FCU_CLEAR0_C25_Pos          FCU_CLEAR0_C25_DPos
#define FCU_CLEAR0_C25_Msk          (0x1UL << FCU_CLEAR0_C25_Pos)         /* 0x02000000 */
#define FCU_CLEAR0_C25              FCU_CLEAR0_C25_Msk                    /* FCU Channel 25 clear bit */

#define FCU_CLEAR0_C26_DPos         (26U)
#define FCU_CLEAR0_C26_Pos          FCU_CLEAR0_C26_DPos
#define FCU_CLEAR0_C26_Msk          (0x1UL << FCU_CLEAR0_C26_Pos)         /* 0x04000000 */
#define FCU_CLEAR0_C26              FCU_CLEAR0_C26_Msk                    /* FCU Channel 26 clear bit */

#define FCU_CLEAR0_C27_DPos         (27U)
#define FCU_CLEAR0_C27_Pos          FCU_CLEAR0_C27_DPos
#define FCU_CLEAR0_C27_Msk          (0x1UL << FCU_CLEAR0_C27_Pos)         /* 0x08000000 */
#define FCU_CLEAR0_C27              FCU_CLEAR0_C27_Msk                    /* FCU Channel 27 clear bit */

#define FCU_CLEAR0_C28_DPos         (28U)
#define FCU_CLEAR0_C28_Pos          FCU_CLEAR0_C28_DPos
#define FCU_CLEAR0_C28_Msk          (0x1UL << FCU_CLEAR0_C28_Pos)         /* 0x10000000 */
#define FCU_CLEAR0_C28              FCU_CLEAR0_C28_Msk                    /* FCU Channel 28 clear bit */

#define FCU_CLEAR0_C29_DPos         (29U)
#define FCU_CLEAR0_C29_Pos          FCU_CLEAR0_C29_DPos
#define FCU_CLEAR0_C29_Msk          (0x1UL << FCU_CLEAR0_C29_Pos)         /* 0x20000000 */
#define FCU_CLEAR0_C29              FCU_CLEAR0_C29_Msk                    /* FCU Channel 29 clear bit */

#define FCU_CLEAR0_C30_DPos         (30U)
#define FCU_CLEAR0_C30_Pos          FCU_CLEAR0_C30_DPos
#define FCU_CLEAR0_C30_Msk          (0x1UL << FCU_CLEAR0_C30_Pos)         /* 0x40000000 */
#define FCU_CLEAR0_C30              FCU_CLEAR0_C30_Msk                    /* FCU Channel 30 clear bit */

#define FCU_CLEAR0_C31_DPos         (31U)
#define FCU_CLEAR0_C31_Pos          FCU_CLEAR0_C31_DPos
#define FCU_CLEAR0_C31_Msk          (0x1UL << FCU_CLEAR0_C31_Pos)         /* 0x80000000 */
#define FCU_CLEAR0_C31              FCU_CLEAR0_C31_Msk                    /* FCU Channel 31 clear bit */

/******************  Bits definition for FCU_CLEAR1 register  *****************/

#define FCU_CLEAR1_C32_DPos         (0U)
#define FCU_CLEAR1_C32_Pos          FCU_CLEAR1_C32_DPos
#define FCU_CLEAR1_C32_Msk          (0x1UL << FCU_CLEAR1_C32_Pos)         /* 0x00000001 */
#define FCU_CLEAR1_C32              FCU_CLEAR1_C32_Msk                    /* FCU Channel 32 clear bit */

#define FCU_CLEAR1_C33_DPos         (1U)
#define FCU_CLEAR1_C33_Pos          FCU_CLEAR1_C33_DPos
#define FCU_CLEAR1_C33_Msk          (0x1UL << FCU_CLEAR1_C33_Pos)         /* 0x00000002 */
#define FCU_CLEAR1_C33              FCU_CLEAR1_C33_Msk                    /* FCU Channel 33 clear bit */

#define FCU_CLEAR1_C34_DPos         (2U)
#define FCU_CLEAR1_C34_Pos          FCU_CLEAR1_C34_DPos
#define FCU_CLEAR1_C34_Msk          (0x1UL << FCU_CLEAR1_C34_Pos)         /* 0x00000004 */
#define FCU_CLEAR1_C34              FCU_CLEAR1_C34_Msk                    /* FCU Channel 34 clear bit */

#define FCU_CLEAR1_C35_DPos         (3U)
#define FCU_CLEAR1_C35_Pos          FCU_CLEAR1_C35_DPos
#define FCU_CLEAR1_C35_Msk          (0x1UL << FCU_CLEAR1_C35_Pos)         /* 0x00000008 */
#define FCU_CLEAR1_C35              FCU_CLEAR1_C35_Msk                    /* FCU Channel 35 clear bit */

#define FCU_CLEAR1_C36_DPos         (4U)
#define FCU_CLEAR1_C36_Pos          FCU_CLEAR1_C36_DPos
#define FCU_CLEAR1_C36_Msk          (0x1UL << FCU_CLEAR1_C36_Pos)         /* 0x00000010 */
#define FCU_CLEAR1_C36              FCU_CLEAR1_C36_Msk                    /* FCU Channel 36 clear bit */

#define FCU_CLEAR1_C37_DPos         (5U)
#define FCU_CLEAR1_C37_Pos          FCU_CLEAR1_C37_DPos
#define FCU_CLEAR1_C37_Msk          (0x1UL << FCU_CLEAR1_C37_Pos)         /* 0x00000020 */
#define FCU_CLEAR1_C37              FCU_CLEAR1_C37_Msk                    /* FCU Channel 37 clear bit */

#define FCU_CLEAR1_C38_DPos         (6U)
#define FCU_CLEAR1_C38_Pos          FCU_CLEAR1_C38_DPos
#define FCU_CLEAR1_C38_Msk          (0x1UL << FCU_CLEAR1_C38_Pos)         /* 0x00000040 */
#define FCU_CLEAR1_C38              FCU_CLEAR1_C38_Msk                    /* FCU Channel 38 clear bit */

#define FCU_CLEAR1_C39_DPos         (7U)
#define FCU_CLEAR1_C39_Pos          FCU_CLEAR1_C39_DPos
#define FCU_CLEAR1_C39_Msk          (0x1UL << FCU_CLEAR1_C39_Pos)         /* 0x00000080 */
#define FCU_CLEAR1_C39              FCU_CLEAR1_C39_Msk                    /* FCU Channel 39 clear bit */

#define FCU_CLEAR1_C40_DPos         (8U)
#define FCU_CLEAR1_C40_Pos          FCU_CLEAR1_C40_DPos
#define FCU_CLEAR1_C40_Msk          (0x1UL << FCU_CLEAR1_C40_Pos)         /* 0x00000100 */
#define FCU_CLEAR1_C40              FCU_CLEAR1_C40_Msk                    /* FCU Channel 40 clear bit */

#define FCU_CLEAR1_C41_DPos         (9U)
#define FCU_CLEAR1_C41_Pos          FCU_CLEAR1_C41_DPos
#define FCU_CLEAR1_C41_Msk          (0x1UL << FCU_CLEAR1_C41_Pos)         /* 0x00000200 */
#define FCU_CLEAR1_C41              FCU_CLEAR1_C41_Msk                    /* FCU Channel 41 clear bit */
/******************  Bits definition for FCU_OCLR register  *****************/

#define FCU_OCLR_ECCC_DPos          (0U)
#define FCU_OCLR_ECCC_Pos           FCU_OCLR_ECCC_DPos
#define FCU_OCLR_ECCC_Msk           (0x1UL << FCU_OCLR_ECCC_Pos)          /* 0x00000001 */
#define FCU_OCLR_ECCC               FCU_OCLR_ECCC_Msk                     /* Bus timeout count fault clear bit */

#define FCU_OCLR_BTOC_DPos          (1U)
#define FCU_OCLR_BTOC_Pos           FCU_OCLR_BTOC_DPos
#define FCU_OCLR_BTOC_Msk           (0x1UL << FCU_OCLR_BTOC_Pos)          /* 0x00000002 */
#define FCU_OCLR_BTOC               FCU_OCLR_BTOC_Msk                     /* ECC controller fault clear bit */

/* @name CMU register bits definition */
/******************  Bits definition for CMU_CR register  *****************/
#define CMU_CR_MODE_DPos            (0U)
#define CMU_CR_MODE_Pos             CMU_CR_MODE_DPos
#define CMU_CR_MODE_Msk             (0x7UL << CMU_CR_MODE_Pos)                  /* 0x00000007 */
#define CMU_CR_MODE                 CMU_CR_MODE_Msk                             /* MODE[2:0] bits (Clock monitoring enabled) */

/******************  Bits definition for CMU_CCR register  *****************/
#define CMU_CCR_WINLEN_DPos         (0U)
#define CMU_CCR_WINLEN_Pos          CMU_CCR_WINLEN_DPos
#define CMU_CCR_WINLEN_Msk          (0xFFFFFFUL << CMU_CCR_WINLEN_Pos)          /* 0x00FFFFFF */
#define CMU_CCR_WINLEN              CMU_CCR_WINLEN_Msk                          /* WINLEN[23:0] bits (Reference Count Window Length) */

/******************  Bits definition for CMU_HTCR register  *****************/
#define CMU_HTCR_HFREF_DPos         (0U)
#define CMU_HTCR_HFREF_Pos          CMU_HTCR_HFREF_DPos
#define CMU_HTCR_HFREF_Msk          (0xFFFFFFUL << CMU_HTCR_HFREF_Pos)          /* 0x00FFFFFF */
#define CMU_HTCR_HFREF              CMU_HTCR_HFREF_Msk                          /* HFREF[23:0] bits (High frequency reference threshold) */

/******************  Bits definition for CMU_LTCR register  *****************/
#define CMU_LTCR_LFREF_DPos         (0U)
#define CMU_LTCR_LFREF_Pos          CMU_LTCR_LFREF_DPos
#define CMU_LTCR_LFREF_Msk          (0xFFFFFFUL << CMU_LTCR_LFREF_Pos)          /* 0x00FFFFFF */
#define CMU_LTCR_LFREF              CMU_LTCR_LFREF_Msk                          /* LFREF[23:0] bits (Low frequency reference threshold) */

/******************  Bits definition for CMU_SR register  *****************/
#define CMU_SR_FLL_DPos             (0U)
#define CMU_SR_FLL_Pos              CMU_SR_FLL_DPos
#define CMU_SR_FLL_Msk              (0x1UL << CMU_SR_FLL_Pos)                   /* 0x00000001 */
#define CMU_SR_FLL                  CMU_SR_FLL_Msk                              /* Frequency below the low frequency reference threshold state */

#define CMU_SR_FHH_DPos             (1U)
#define CMU_SR_FHH_Pos              CMU_SR_FHH_DPos
#define CMU_SR_FHH_Msk              (0x1UL << CMU_SR_FHH_Pos)                   /* 0x00000002 */
#define CMU_SR_FHH                  CMU_SR_FHH_Msk                              /* State where the frequency is greater than the high-frequency reference threshold */

#define CMU_SR_LOSSCLK_DPos         (2U)
#define CMU_SR_LOSSCLK_Pos          CMU_SR_LOSSCLK_DPos
#define CMU_SR_LOSSCLK_Msk          (0x1UL << CMU_SR_LOSSCLK_Pos)               /* 0x00000004 */
#define CMU_SR_LOSSCLK              CMU_SR_LOSSCLK_Msk                          /* Clock loss status */

#define CMU_SR_CHCDONE_DPos         (3U)
#define CMU_SR_CHCDONE_Pos          CMU_SR_CHCDONE_DPos
#define CMU_SR_CHCDONE_Msk          (0x1UL << CMU_SR_CHCDONE_Pos)               /* 0x00000008 */
#define CMU_SR_CHCDONE              CMU_SR_CHCDONE_Msk                          /* Status Detection */

#define CMU_SR_WORK_DPos            (4U)
#define CMU_SR_WORK_Pos             CMU_SR_WORK_DPos
#define CMU_SR_WORK_Msk             (0x1UL << CMU_SR_WORK_Pos)                  /* 0x00000010 */
#define CMU_SR_WORK                 CMU_SR_WORK_Msk                             /* Working condition */

/* @name DMA register bits definition */
/******************  Bits definition for DMA_CHEN register  *****************/
#define DMA_CHEN_EN0_DPos           (0U)
#define DMA_CHEN_EN0_Pos            DMA_CHEN_EN0_DPos
#define DMA_CHEN_EN0_Msk            (0x01UL << DMA_CHEN_EN0_Pos)                    /* 0x00000001 */
#define DMA_CHEN_EN0                DMA_CHEN_EN0_Msk                                /* DMA channel 0 enable */

#define DMA_CHEN_EN1_DPos           (1U)
#define DMA_CHEN_EN1_Pos            DMA_CHEN_EN1_DPos
#define DMA_CHEN_EN1_Msk            (0x01UL << DMA_CHEN_EN1_Pos)                    /* 0x00000002 */
#define DMA_CHEN_EN1                DMA_CHEN_EN1_Msk                                /* DMA channel 1 enable */

#define DMA_CHEN_EN2_DPos           (2U)
#define DMA_CHEN_EN2_Pos            DMA_CHEN_EN2_DPos
#define DMA_CHEN_EN2_Msk            (0x01UL << DMA_CHEN_EN2_Pos)                    /* 0x00000004 */
#define DMA_CHEN_EN2                DMA_CHEN_EN2_Msk                                /* DMA channel 2 enable */

#define DMA_CHEN_EN3_DPos           (3U)
#define DMA_CHEN_EN3_Pos            DMA_CHEN_EN3_DPos
#define DMA_CHEN_EN3_Msk            (0x01UL << DMA_CHEN_EN3_Pos)                    /* 0x00000008 */
#define DMA_CHEN_EN3                DMA_CHEN_EN3_Msk                                /* DMA channel 3 enable */

#define DMA_CHEN_EN4_DPos           (4U)
#define DMA_CHEN_EN4_Pos            DMA_CHEN_EN4_DPos
#define DMA_CHEN_EN4_Msk            (0x01UL << DMA_CHEN_EN4_Pos)                    /* 0x00000010 */
#define DMA_CHEN_EN4                DMA_CHEN_EN4_Msk                                /* DMA channel 4 enable */

#define DMA_CHEN_EN5_DPos           (5U)
#define DMA_CHEN_EN5_Pos            DMA_CHEN_EN5_DPos
#define DMA_CHEN_EN5_Msk            (0x01UL << DMA_CHEN_EN5_Pos)                    /* 0x00000020 */
#define DMA_CHEN_EN5                DMA_CHEN_EN5_Msk                                /* DMA channel 5 enable */

#define DMA_CHEN_EN6_DPos           (6U)
#define DMA_CHEN_EN6_Pos            DMA_CHEN_EN6_DPos
#define DMA_CHEN_EN6_Msk            (0x01UL << DMA_CHEN_EN6_Pos)                    /* 0x00000040 */
#define DMA_CHEN_EN6                DMA_CHEN_EN6_Msk                                /* DMA channel 6 enable */

#define DMA_CHEN_EN7_DPos           (7U)
#define DMA_CHEN_EN7_Pos            DMA_CHEN_EN7_DPos
#define DMA_CHEN_EN7_Msk            (0x01UL << DMA_CHEN_EN7_Pos)                    /* 0x00000080 */
#define DMA_CHEN_EN7                DMA_CHEN_EN7_Msk                                /* DMA channel 7 enable */

#define DMA_CHEN_EN8_DPos           (8U)
#define DMA_CHEN_EN8_Pos            DMA_CHEN_EN8_DPos
#define DMA_CHEN_EN8_Msk            (0x01UL << DMA_CHEN_EN8_Pos)                    /* 0x00000100 */
#define DMA_CHEN_EN8                DMA_CHEN_EN8_Msk                                /* DMA channel 8 enable */

#define DMA_CHEN_EN9_DPos           (9U)
#define DMA_CHEN_EN9_Pos            DMA_CHEN_EN9_DPos
#define DMA_CHEN_EN9_Msk            (0x01UL << DMA_CHEN_EN9_Pos)                    /* 0x00000200 */
#define DMA_CHEN_EN9                DMA_CHEN_EN9_Msk                                /* DMA channel 9 enable */

#define DMA_CHEN_EN10_DPos          (10U)
#define DMA_CHEN_EN10_Pos           DMA_CHEN_EN10_DPos
#define DMA_CHEN_EN10_Msk           (0x01UL << DMA_CHEN_EN10_Pos)                   /* 0x00000400 */
#define DMA_CHEN_EN10               DMA_CHEN_EN10_Msk                               /* DMA channel 10 enable */

#define DMA_CHEN_EN11_DPos          (11U)
#define DMA_CHEN_EN11_Pos           DMA_CHEN_EN11_DPos
#define DMA_CHEN_EN11_Msk           (0x01UL << DMA_CHEN_EN11_DPos)                  /* 0x00000800 */
#define DMA_CHEN_EN11               DMA_CHEN_EN11_Msk                               /* DMA channel 11 enable */

#define DMA_CHEN_EN12_DPos          (12U)
#define DMA_CHEN_EN12_Pos           DMA_CHEN_EN12_DPos
#define DMA_CHEN_EN12_Msk           (0x01UL << DMA_CHEN_EN12_Pos)                   /* 0x00001000 */
#define DMA_CHEN_EN12               DMA_CHEN_EN12_Msk                               /* DMA channel 7 enable */

#define DMA_CHEN_EN13_DPos          (13U)
#define DMA_CHEN_EN13_Pos           DMA_CHEN_EN13_DPos
#define DMA_CHEN_EN13_Msk           (0x01UL << DMA_CHEN_EN13_Pos)                   /* 0x00002000 */
#define DMA_CHEN_EN13               DMA_CHEN_EN13_Msk                               /* DMA channel 13 enable */

#define DMA_CHEN_EN14_DPos          (14U)
#define DMA_CHEN_EN14_Pos           DMA_CHEN_EN14_DPos
#define DMA_CHEN_EN14_Msk           (0x01UL << DMA_CHEN_EN14_Pos)                   /* 0x00004000 */
#define DMA_CHEN_EN14               DMA_CHEN_EN14_Msk                               /* DMA channel 14 enable */

#define DMA_CHEN_EN15_DPos          (15U)
#define DMA_CHEN_EN15_Pos           DMA_CHEN_EN15_DPos
#define DMA_CHEN_EN15_Msk           (0x01UL << DMA_CHEN_EN15_Pos)                   /* 0x00008000 */
#define DMA_CHEN_EN15               DMA_CHEN_EN15_Msk                               /* DMA channel 15 enable */

/******************  Bits definition for DMA_CH0CTL register  *****************/
#define DMA_CH0CTL_M2M_DPos          (0U)
#define DMA_CH0CTL_M2M_Pos           DMA_CH0CTL_M2M_DPos
#define DMA_CH0CTL_M2M_Msk           (0x01UL << DMA_CH0CTL_M2M_Pos)                      /* 0x00000001 */
#define DMA_CH0CTL_M2M               DMA_CH0CTL_M2M_Msk                                  /* DMA channel 0 memory-to-memory transfer mode */

#define DMA_CH0CTL_DIR_DPos          (1U)
#define DMA_CH0CTL_DIR_Pos           DMA_CH0CTL_DIR_DPos
#define DMA_CH0CTL_DIR_Msk           (0x01UL << DMA_CH0CTL_DIR_Pos)                      /* 0x00000002 */
#define DMA_CH0CTL_DIR               DMA_CH0CTL_DIR_Msk                                  /* DMA channel 0 data transfer direction */

#define DMA_CH0CTL_CMEN_DPos         (2U)
#define DMA_CH0CTL_CIRC_Pos          DMA_CH0CTL_CMEN_DPos
#define DMA_CH0CTL_CIRC_Msk          (0x01UL << DMA_CH0CTL_CIRC_Pos)                     /* 0x00000004 */
#define DMA_CH0CTL_CIRC              DMA_CH0CTL_CIRC_Msk                                 /* DMA channel 0 circular mode */

#define DMA_CH0CTL_PNAGA_DPos        (3U)
#define DMA_CH0CTL_PINC_Pos          DMA_CH0CTL_PNAGA_DPos
#define DMA_CH0CTL_PINC_Msk          (0x01UL << DMA_CH0CTL_PINC_Pos)                     /* 0x00000008 */
#define DMA_CH0CTL_PINC              DMA_CH0CTL_PINC_Msk                                 /* DMA channel 0 peripheral address increment */

#define DMA_CH0CTL_MNAGA_DPos        (4U)
#define DMA_CH0CTL_MINC_Pos          DMA_CH0CTL_MNAGA_DPos
#define DMA_CH0CTL_MINC_Msk          (0x01UL << DMA_CH0CTL_MINC_Pos)                     /* 0x00000010 */
#define DMA_CH0CTL_MINC              DMA_CH0CTL_MINC_Msk                                 /* DMA channel 0 memory address increment */

#define DMA_CH0CTL_PWIDTH_DPos       (5U)
#define DMA_CH0CTL_PSIZE_Pos         DMA_CH0CTL_PWIDTH_DPos
#define DMA_CH0CTL_PSIZE_Msk         (0x03UL << DMA_CH0CTL_PSIZE_Pos)                    /* 0x00000060 */
#define DMA_CH0CTL_PSIZE             DMA_CH0CTL_PSIZE_Msk                                /* PWIDTH reg[1:0] bits( DMA channel 0 peripheral data width) */
#define DMA_CH0CTL_PSIZE_0           (0x01UL << DMA_CH0CTL_PSIZE_Pos)                    /* 0x00000020 */
#define DMA_CH0CTL_PSIZE_1           (0x02UL << DMA_CH0CTL_PSIZE_Pos)                    /* 0x00000040 */

#define DMA_CH0CTL_MWIDTH_DPos       (7U)
#define DMA_CH0CTL_MSIZE_Pos         DMA_CH0CTL_MWIDTH_DPos
#define DMA_CH0CTL_MSIZE_Msk         (0x03UL << DMA_CH0CTL_MSIZE_Pos)                    /* 0x00000180 */
#define DMA_CH0CTL_MSIZE             DMA_CH0CTL_MSIZE_Msk                                /* MWIDTH reg[1:0] bits( DMA channel 0 memory data width) */
#define DMA_CH0CTL_MSIZE_0           (0x01UL << DMA_CH0CTL_MSIZE_Pos)                    /* 0x00000080 */
#define DMA_CH0CTL_MSIZE_1           (0x02UL << DMA_CH0CTL_MSIZE_Pos)                    /* 0x00000100 */

#define DMA_CH0CTL_PRIO_DPos         (9U)
#define DMA_CH0CTL_PRIO_Pos          DMA_CH0CTL_PRIO_DPos
#define DMA_CH0CTL_PRIO_Msk          (0x03UL << DMA_CH0CTL_PRIO_Pos)                     /* 0x00000600 */
#define DMA_CH0CTL_PRIO              DMA_CH0CTL_PRIO_Msk                                 /* PRIO reg[1:0] bits( DMA channel 0 priority level) */
#define DMA_CH0CTL_PRIO_0            (0x01UL << DMA_CH0CTL_PRIO_Pos)                     /* 0x00000200 */
#define DMA_CH0CTL_PRIO_1            (0x02UL << DMA_CH0CTL_PRIO_Pos)                     /* 0x00000400 */

/******************  Bits definition for DMA_CH0CNT register  *****************/
#define DMA_CH0CNT_CNT_DPos          (0U)
#define DMA_CH0CNT_CNT_Pos           DMA_CH0CNT_CNT_DPos
#define DMA_CH0CNT_CNT_Msk           (0xFFFFUL << DMA_CH0CNT_CNT_Pos)                      /* 0x0000ffff */
#define DMA_CH0CNT_CNT               DMA_CH0CNT_CNT_Msk                                    /* DMA channel 0 number of data to transfer */

/******************  Bits definition for DMA_CH0PADDR register  *****************/
#define DMA_CH0PADDR_PADDR_DPos      (0U)
#define DMA_CH0PADDR_PADDR_Pos       DMA_CH0PADDR_PADDR_DPos
#define DMA_CH0PADDR_PADDR_Msk       (0xffffffffUL << DMA_CH0PADDR_PADDR_Pos)             /* 0xffffffff */
#define DMA_CH0PADDR_PADDR           DMA_CH0PADDR_PADDR_Msk                               /* DMA channel 0 peripheral address */

/******************  Bits definition for DMA_CH0MADDR register  *****************/
#define DMA_CH0MADDR_MADDR_DPos      (0U)
#define DMA_CH0MADDR_MADDR_Pos       DMA_CH0MADDR_MADDR_DPos
#define DMA_CH0MADDR_MADDR_Msk       (0xffffffffUL << DMA_CH0MADDR_MADDR_Pos)                   /* 0xffffffff */
#define DMA_CH0MADDR_MADDR           DMA_CH0MADDR_MADDR_Msk                                     /* DMA channel 0 memory address */

/******************  Bits definition for DMA_CH1CTL register  *****************/
#define DMA_CH1CTL_M2M_DPos          (0U)
#define DMA_CH1CTL_M2M_Pos           DMA_CH1CTL_M2M_DPos
#define DMA_CH1CTL_M2M_Msk           (0x01UL << DMA_CH1CTL_M2M_Pos)                      /* 0x00000001 */
#define DMA_CH1CTL_M2M               DMA_CH1CTL_M2M_Msk                                  /* DMA channel 1 memory-to-memory transfer mode */

#define DMA_CH1CTL_DIR_DPos          (1U)
#define DMA_CH1CTL_DIR_Pos           DMA_CH1CTL_DIR_DPos
#define DMA_CH1CTL_DIR_Msk           (0x01UL << DMA_CH1CTL_DIR_Pos)                      /* 0x00000002 */
#define DMA_CH1CTL_DIR               DMA_CH1CTL_DIR_Msk                                  /* DMA channel 1 data transfer direction */

#define DMA_CH1CTL_CMEN_DPos         (2U)
#define DMA_CH1CTL_CIRC_Pos          DMA_CH1CTL_CMEN_DPos
#define DMA_CH1CTL_CIRC_Msk          (0x01UL << DMA_CH1CTL_CIRC_Pos)                     /* 0x00000004 */
#define DMA_CH1CTL_CIRC              DMA_CH1CTL_CIRC_Msk                                 /* DMA channel 1 circular mode */

#define DMA_CH1CTL_PNAGA_DPos        (3U)
#define DMA_CH1CTL_PINC_Pos          DMA_CH1CTL_PNAGA_DPos
#define DMA_CH1CTL_PINC_Msk          (0x01UL << DMA_CH1CTL_PINC_Pos)                     /* 0x00000008 */
#define DMA_CH1CTL_PINC              DMA_CH1CTL_PINC_Msk                                 /* DMA channel 1 peripheral address increment */

#define DMA_CH1CTL_MNAGA_DPos        (4U)
#define DMA_CH1CTL_MINC_Pos          DMA_CH1CTL_MNAGA_DPos
#define DMA_CH1CTL_MINC_Msk          (0x01UL << DMA_CH1CTL_MINC_Pos)                     /* 0x00000010 */
#define DMA_CH1CTL_MINC              DMA_CH1CTL_MINC_Msk                                 /* DMA channel 1 memory address increment */

#define DMA_CH1CTL_PWIDTH_DPos       (5U)
#define DMA_CH1CTL_PSIZE_Pos         DMA_CH1CTL_PWIDTH_DPos
#define DMA_CH1CTL_PSIZE_Msk         (0x03UL << DMA_CH1CTL_PSIZE_Pos)                    /* 0x00000060 */
#define DMA_CH1CTL_PSIZE             DMA_CH1CTL_PSIZE_Msk                                /* PWIDTH reg[1:0] bits( DMA channel 1 peripheral data width) */
#define DMA_CH1CTL_PSIZE_0           (0x01UL << DMA_CH1CTL_PSIZE_Pos)                    /* 0x00000020 */
#define DMA_CH1CTL_PSIZE_1           (0x02UL << DMA_CH1CTL_PSIZE_Pos)                    /* 0x00000040 */

#define DMA_CH1CTL_MWIDTH_DPos       (7U)
#define DMA_CH1CTL_MSIZE_Pos         DMA_CH1CTL_MWIDTH_DPos
#define DMA_CH1CTL_MSIZE_Msk         (0x03UL << DMA_CH1CTL_MSIZE_Pos)                    /* 0x00000180 */
#define DMA_CH1CTL_MSIZE             DMA_CH1CTL_MSIZE_Msk                                /* MWIDTH reg[1:0] bits( DMA channel 1 memory data width) */
#define DMA_CH1CTL_MSIZE_0           (0x01UL << DMA_CH1CTL_MSIZE_Pos)                    /* 0x00000080 */
#define DMA_CH1CTL_MSIZE_1           (0x02UL << DMA_CH1CTL_MSIZE_Pos)                    /* 0x00000100 */

#define DMA_CH1CTL_PRIO_DPos         (9U)
#define DMA_CH1CTL_PRIO_Pos          DMA_CH1CTL_PRIO_DPos
#define DMA_CH1CTL_PRIO_Msk          (0x03UL << DMA_CH1CTL_PRIO_Pos)                     /* 0x00000600 */
#define DMA_CH1CTL_PRIO              DMA_CH1CTL_PRIO_Msk                                 /* PRIO reg[1:0] bits(DMA channel 1 priority level) */
#define DMA_CH1CTL_PRIO_0            (0x01UL << DMA_CH1CTL_PRIO_Pos)                     /* 0x00000200 */
#define DMA_CH1CTL_PRIO_1            (0x02UL << DMA_CH1CTL_PRIO_Pos)                     /* 0x00000400 */

/******************  Bits definition for DMA_CH1CNT register  *****************/
#define DMA_CH1CNT_CNT_DPos          (0U)
#define DMA_CH1CNT_CNT_Pos           DMA_CH1CNT_CNT_DPos
#define DMA_CH1CNT_CNT_Msk           (0xFFFFUL << DMA_CH1CNT_CNT_Pos)                      /* 0x0000ffff */
#define DMA_CH1CNT_CNT               DMA_CH1CNT_CNT_Msk                                    /* DMA channel 1 number of data to transfer */

/******************  Bits definition for DMA_CH1PADDR register  *****************/
#define DMA_CH1PADDR_PADDR_DPos      (0U)
#define DMA_CH1PADDR_PADDR_Pos       DMA_CH1PADDR_PADDR_DPos
#define DMA_CH1PADDR_PADDR_Msk       (0xffffffffUL << DMA_CH1PADDR_PADDR_Pos)             /* 0xffffffff */
#define DMA_CH1PADDR_PADDR           DMA_CH1PADDR_PADDR_Msk                               /* DMA channel 1 peripheral address */

/******************  Bits definition for DMA_CH1MADDR register  *****************/
#define DMA_CH1MADDR_MADDR_DPos      (0U)
#define DMA_CH1MADDR_MADDR_Pos       DMA_CH1MADDR_MADDR_DPos
#define DMA_CH1MADDR_MADDR_Msk       (0xffffffffUL << DMA_CH1MADDR_MADDR_Pos)                   /* 0xffffffff */
#define DMA_CH1MADDR_MADDR           DMA_CH1MADDR_MADDR_Msk                                     /* DMA channel 1 memory address */

/******************  Bits definition for DMA_CH2CTL register  *****************/
#define DMA_CH2CTL_M2M_DPos          (0U)
#define DMA_CH2CTL_M2M_Pos           DMA_CH2CTL_M2M_DPos
#define DMA_CH2CTL_M2M_Msk           (0x01UL << DMA_CH2CTL_M2M_Pos)                      /* 0x00000001 */
#define DMA_CH2CTL_M2M               DMA_CH2CTL_M2M_Msk                                  /* DMA channel 2 memory-to-memory transfer mode */

#define DMA_CH2CTL_DIR_DPos          (1U)
#define DMA_CH2CTL_DIR_Pos           DMA_CH2CTL_DIR_DPos
#define DMA_CH2CTL_DIR_Msk           (0x01UL << DMA_CH2CTL_DIR_Pos)                      /* 0x00000002 */
#define DMA_CH2CTL_DIR               DMA_CH2CTL_DIR_Msk                                  /* DMA channel 2 data transfer direction */

#define DMA_CH2CTL_CMEN_DPos         (2U)
#define DMA_CH2CTL_CIRC_Pos          DMA_CH2CTL_CMEN_DPos
#define DMA_CH2CTL_CIRC_Msk          (0x01UL << DMA_CH2CTL_CIRC_Pos)                     /* 0x00000004 */
#define DMA_CH2CTL_CIRC              DMA_CH2CTL_CIRC_Msk                                 /* DMA channel 2 circular mode */

#define DMA_CH2CTL_PNAGA_DPos        (3U)
#define DMA_CH2CTL_PINC_Pos          DMA_CH2CTL_PNAGA_DPos
#define DMA_CH2CTL_PINC_Msk          (0x01UL << DMA_CH2CTL_PINC_Pos)                     /* 0x00000008 */
#define DMA_CH2CTL_PINC              DMA_CH2CTL_PINC_Msk                                 /* DMA channel 2 peripheral address increment */

#define DMA_CH2CTL_MNAGA_DPos        (4U)
#define DMA_CH2CTL_MINC_Pos          DMA_CH2CTL_MNAGA_DPos
#define DMA_CH2CTL_MINC_Msk          (0x01UL << DMA_CH2CTL_MINC_Pos)                     /* 0x00000010 */
#define DMA_CH2CTL_MINC              DMA_CH2CTL_MINC_Msk                                 /* DMA channel 2 memory address increment */

#define DMA_CH2CTL_PWIDTH_DPos       (5U)
#define DMA_CH2CTL_PSIZE_Pos         DMA_CH2CTL_PWIDTH_DPos
#define DMA_CH2CTL_PSIZE_Msk         (0x03UL << DMA_CH2CTL_PSIZE_Pos)                    /* 0x00000060 */
#define DMA_CH2CTL_PSIZE             DMA_CH2CTL_PSIZE_Msk                                /* PWIDTH reg[1:0] bits( DMA channel 2 peripheral data width) */
#define DMA_CH2CTL_PSIZE_0           (0x01UL << DMA_CH2CTL_PSIZE_Pos)                    /* 0x00000020 */
#define DMA_CH2CTL_PSIZE_1           (0x02UL << DMA_CH2CTL_PSIZE_Pos)                    /* 0x00000040 */

#define DMA_CH2CTL_MWIDTH_DPos       (7U)
#define DMA_CH2CTL_MSIZE_Pos         DMA_CH2CTL_MWIDTH_DPos
#define DMA_CH2CTL_MSIZE_Msk         (0x03UL << DMA_CH2CTL_MSIZE_Pos)                    /* 0x00000180 */
#define DMA_CH2CTL_MSIZE             DMA_CH2CTL_MSIZE_Msk                                /* MWIDTH reg[1:0] bits( DMA channel 2 memory data width) */
#define DMA_CH2CTL_MSIZE_0           (0x01UL << DMA_CH2CTL_MSIZE_Pos)                    /* 0x00000080 */
#define DMA_CH2CTL_MSIZE_1           (0x02UL << DMA_CH2CTL_MSIZE_Pos)                    /* 0x00000100 */

#define DMA_CH2CTL_PRIO_DPos         (9U)
#define DMA_CH2CTL_PRIO_Pos          DMA_CH2CTL_PRIO_DPos
#define DMA_CH2CTL_PRIO_Msk          (0x03UL << DMA_CH2CTL_PRIO_Pos)                     /* 0x00000600 */
#define DMA_CH2CTL_PRIO              DMA_CH2CTL_PRIO_Msk                                 /* PRIO reg[1:0] bits(DMA channel 2 priority level) */
#define DMA_CH2CTL_PRIO_0            (0x01UL << DMA_CH2CTL_PRIO_Pos)                     /* 0x00000200 */
#define DMA_CH2CTL_PRIO_1            (0x02UL << DMA_CH2CTL_PRIO_Pos)                     /* 0x00000400 */

/******************  Bits definition for DMA_CH2CNT register  *****************/
#define DMA_CH2CNT_CNT_DPos          (0U)
#define DMA_CH2CNT_CNT_Pos           DMA_CH2CNT_CNT_DPos
#define DMA_CH2CNT_CNT_Msk           (0xFFFFUL << DMA_CH2CNT_CNT_Pos)                      /* 0x0000ffff */
#define DMA_CH2CNT_CNT               DMA_CH2CNT_CNT_Msk                                    /* DMA channel 2 number of data to transfer */

/******************  Bits definition for DMA_CH2PADDR register  *****************/
#define DMA_CH2PADDR_PADDR_DPos      (0U)
#define DMA_CH2PADDR_PADDR_Pos       DMA_CH2PADDR_PADDR_DPos
#define DMA_CH2PADDR_PADDR_Msk       (0xffffffffUL << DMA_CH2PADDR_PADDR_Pos)             /* 0xffffffff */
#define DMA_CH2PADDR_PADDR           DMA_CH2PADDR_PADDR_Msk                               /* DMA channel 2 peripheral address */

/******************  Bits definition for DMA_CH2MADDR register  *****************/
#define DMA_CH2MADDR_MADDR_DPos      (0U)
#define DMA_CH2MADDR_MADDR_Pos       DMA_CH2MADDR_MADDR_DPos
#define DMA_CH2MADDR_MADDR_Msk       (0xffffffffUL << DMA_CH2MADDR_MADDR_Pos)                   /* 0xffffffff */
#define DMA_CH2MADDR_MADDR           DMA_CH2MADDR_MADDR_Msk                                     /* DMA channel 2 memory address */

/******************  Bits definition for DMA_CH3CTL register  *****************/
#define DMA_CH3CTL_M2M_DPos          (0U)
#define DMA_CH3CTL_M2M_Pos           DMA_CH3CTL_M2M_DPos
#define DMA_CH3CTL_M2M_Msk           (0x01UL << DMA_CH3CTL_M2M_Pos)                      /* 0x00000001 */
#define DMA_CH3CTL_M2M               DMA_CH3CTL_M2M_Msk                                  /* DMA channel 3 memory-to-memory transfer mode */

#define DMA_CH3CTL_DIR_DPos          (1U)
#define DMA_CH3CTL_DIR_Pos           DMA_CH3CTL_DIR_DPos
#define DMA_CH3CTL_DIR_Msk           (0x01UL << DMA_CH3CTL_DIR_Pos)                      /* 0x00000002 */
#define DMA_CH3CTL_DIR               DMA_CH3CTL_DIR_Msk                                  /* DMA channel 3 data transfer direction */

#define DMA_CH3CTL_CMEN_DPos         (2U)
#define DMA_CH3CTL_CIRC_Pos          DMA_CH3CTL_CMEN_DPos
#define DMA_CH3CTL_CIRC_Msk          (0x01UL << DMA_CH3CTL_CIRC_Pos)                     /* 0x00000004 */
#define DMA_CH3CTL_CIRC              DMA_CH3CTL_CIRC_Msk                                 /* DMA channel 3 circular mode */

#define DMA_CH3CTL_PNAGA_DPos        (3U)
#define DMA_CH3CTL_PINC_Pos          DMA_CH3CTL_PNAGA_DPos
#define DMA_CH3CTL_PINC_Msk          (0x01UL << DMA_CH3CTL_PINC_Pos)                     /* 0x00000008 */
#define DMA_CH3CTL_PINC              DMA_CH3CTL_PINC_Msk                                 /* DMA channel 3 peripheral address increment */

#define DMA_CH3CTL_MNAGA_DPos        (4U)
#define DMA_CH3CTL_MINC_Pos          DMA_CH3CTL_MNAGA_DPos
#define DMA_CH3CTL_MINC_Msk          (0x01UL << DMA_CH3CTL_MINC_Pos)                     /* 0x00000010 */
#define DMA_CH3CTL_MINC              DMA_CH3CTL_MINC_Msk                                 /* DMA channel 3 memory address increment */

#define DMA_CH3CTL_PWIDTH_DPos       (5U)
#define DMA_CH3CTL_PSIZE_Pos         DMA_CH3CTL_PWIDTH_DPos
#define DMA_CH3CTL_PSIZE_Msk         (0x03UL << DMA_CH3CTL_PSIZE_Pos)                    /* 0x00000060 */
#define DMA_CH3CTL_PSIZE             DMA_CH3CTL_PSIZE_Msk                                /* PWIDTH reg[1:0] bits( DMA channel 3 peripheral data width) */
#define DMA_CH3CTL_PSIZE_0           (0x01UL << DMA_CH3CTL_PSIZE_Pos)                    /* 0x00000020 */
#define DMA_CH3CTL_PSIZE_1           (0x02UL << DMA_CH3CTL_PSIZE_Pos)                    /* 0x00000040 */

#define DMA_CH3CTL_MWIDTH_DPos       (7U)
#define DMA_CH3CTL_MSIZE_Pos         DMA_CH3CTL_MWIDTH_DPos
#define DMA_CH3CTL_MSIZE_Msk         (0x03UL << DMA_CH3CTL_MSIZE_Pos)                    /* 0x00000180 */
#define DMA_CH3CTL_MSIZE             DMA_CH3CTL_MSIZE_Msk                                /* MWIDTH reg[1:0] bits( DMA channel 3 memory data width) */
#define DMA_CH3CTL_MSIZE_0           (0x01UL << DMA_CH3CTL_MSIZE_Pos)                    /* 0x00000080 */
#define DMA_CH3CTL_MSIZE_1           (0x02UL << DMA_CH3CTL_MSIZE_Pos)                    /* 0x00000100 */

#define DMA_CH3CTL_PRIO_DPos         (9U)
#define DMA_CH3CTL_PRIO_Pos          DMA_CH3CTL_PRIO_DPos
#define DMA_CH3CTL_PRIO_Msk          (0x03UL << DMA_CH3CTL_PRIO_Pos)                     /* 0x00000600 */
#define DMA_CH3CTL_PRIO              DMA_CH3CTL_PRIO_Msk                                 /* PRIO reg[1:0] bits(DMA channel 3 priority level) */
#define DMA_CH3CTL_PRIO_0            (0x01UL << DMA_CH3CTL_PRIO_Pos)                     /* 0x00000200 */
#define DMA_CH3CTL_PRIO_1            (0x02UL << DMA_CH3CTL_PRIO_Pos)                     /* 0x00000400 */

/******************  Bits definition for DMA_CH3CNT register  *****************/
#define DMA_CH3CNT_CNT_DPos          (0U)
#define DMA_CH3CNT_CNT_Pos           DMA_CH3CNT_CNT_DPos
#define DMA_CH3CNT_CNT_Msk           (0xFFFFUL << DMA_CH3CNT_CNT_Pos)                      /* 0x0000ffff */
#define DMA_CH3CNT_CNT               DMA_CH3CNT_CNT_Msk                                    /* DMA channel 3 number of data to transfer */

/******************  Bits definition for DMA_CH3PADDR register  *****************/
#define DMA_CH3PADDR_PADDR_DPos      (0U)
#define DMA_CH3PADDR_PADDR_Pos       DMA_CH3PADDR_PADDR_DPos
#define DMA_CH3PADDR_PADDR_Msk       (0xffffffffUL << DMA_CH3PADDR_PADDR_Pos)             /* 0xffffffff */
#define DMA_CH3PADDR_PADDR           DMA_CH3PADDR_PADDR_Msk                               /* DMA channel 3 peripheral address */

/******************  Bits definition for DMA_CH3MADDR register  *****************/
#define DMA_CH3MADDR_MADDR_DPos      (0U)
#define DMA_CH3MADDR_MADDR_Pos       DMA_CH3MADDR_MADDR_DPos
#define DMA_CH3MADDR_MADDR_Msk       (0xffffffffUL << DMA_CH3MADDR_MADDR_Pos)                   /* 0xffffffff */
#define DMA_CH3MADDR_MADDR           DMA_CH3MADDR_MADDR_Msk                                     /* DMA channel 3 memory address */


/******************  Bits definition for DMA_CH4CTL register  *****************/
#define DMA_CH4CTL_M2M_DPos          (0U)
#define DMA_CH4CTL_M2M_Pos           DMA_CH4CTL_M2M_DPos
#define DMA_CH4CTL_M2M_Msk           (0x01UL << DMA_CH4CTL_M2M_Pos)                      /* 0x00000001 */
#define DMA_CH4CTL_M2M               DMA_CH4CTL_M2M_Msk                                  /* DMA channel 4 memory-to-memory transfer mode */

#define DMA_CH4CTL_DIR_DPos          (1U)
#define DMA_CH4CTL_DIR_Pos           DMA_CH4CTL_DIR_DPos
#define DMA_CH4CTL_DIR_Msk           (0x01UL << DMA_CH4CTL_DIR_Pos)                      /* 0x00000002 */
#define DMA_CH4CTL_DIR               DMA_CH4CTL_DIR_Msk                                  /* DMA channel 4 data transfer direction */

#define DMA_CH4CTL_CMEN_DPos         (2U)
#define DMA_CH4CTL_CIRC_Pos          DMA_CH4CTL_CMEN_DPos
#define DMA_CH4CTL_CIRC_Msk          (0x01UL << DMA_CH4CTL_CIRC_Pos)                     /* 0x00000004 */
#define DMA_CH4CTL_CIRC              DMA_CH4CTL_CIRC_Msk                                 /* DMA channel 4 circular mode */

#define DMA_CH4CTL_PNAGA_DPos        (3U)
#define DMA_CH4CTL_PINC_Pos          DMA_CH4CTL_PNAGA_DPos
#define DMA_CH4CTL_PINC_Msk          (0x01UL << DMA_CH4CTL_PINC_Pos)                     /* 0x00000008 */
#define DMA_CH4CTL_PINC              DMA_CH4CTL_PINC_Msk                                 /* DMA channel 4 peripheral address increment */

#define DMA_CH4CTL_MNAGA_DPos        (4U)
#define DMA_CH4CTL_MINC_Pos          DMA_CH4CTL_MNAGA_DPos
#define DMA_CH4CTL_MINC_Msk          (0x01UL << DMA_CH4CTL_MINC_Pos)                     /* 0x00000010 */
#define DMA_CH4CTL_MINC              DMA_CH4CTL_MINC_Msk                                 /* DMA channel 4 memory address increment */

#define DMA_CH4CTL_PWIDTH_DPos       (5U)
#define DMA_CH4CTL_PSIZE_Pos         DMA_CH4CTL_PWIDTH_DPos
#define DMA_CH4CTL_PSIZE_Msk         (0x03UL << DMA_CH4CTL_PSIZE_Pos)                    /* 0x00000060 */
#define DMA_CH4CTL_PSIZE             DMA_CH4CTL_PSIZE_Msk                                /* PWIDTH reg[1:0] bits( DMA channel 4 peripheral data width) */
#define DMA_CH4CTL_PSIZE_0           (0x01UL << DMA_CH4CTL_PSIZE_Pos)                    /* 0x00000020 */
#define DMA_CH4CTL_PSIZE_1           (0x02UL << DMA_CH4CTL_PSIZE_Pos)                    /* 0x00000040 */

#define DMA_CH4CTL_MWIDTH_DPos       (7U)
#define DMA_CH4CTL_MSIZE_Pos         DMA_CH4CTL_MWIDTH_DPos
#define DMA_CH4CTL_MSIZE_Msk         (0x03UL << DMA_CH4CTL_MSIZE_Pos)                    /* 0x00000180 */
#define DMA_CH4CTL_MSIZE             DMA_CH4CTL_MSIZE_Msk                                /* MWIDTH reg[1:0] bits( DMA channel 4 memory data width) */
#define DMA_CH4CTL_MSIZE_0           (0x01UL << DMA_CH4CTL_MSIZE_Pos)                    /* 0x00000080 */
#define DMA_CH4CTL_MSIZE_1           (0x02UL << DMA_CH4CTL_MSIZE_Pos)                    /* 0x00000100 */

#define DMA_CH4CTL_PRIO_DPos         (9U)
#define DMA_CH4CTL_PRIO_Pos          DMA_CH4CTL_PRIO_DPos
#define DMA_CH4CTL_PRIO_Msk          (0x03UL << DMA_CH4CTL_PRIO_Pos)                     /* 0x00000600 */
#define DMA_CH4CTL_PRIO              DMA_CH4CTL_PRIO_Msk                                 /* PRIO reg[1:0] bits(DMA channel 4 priority level) */
#define DMA_CH4CTL_PRIO_0            (0x01UL << DMA_CH4CTL_PRIO_Pos)                     /* 0x00000200 */
#define DMA_CH4CTL_PRIO_1            (0x02UL << DMA_CH4CTL_PRIO_Pos)                     /* 0x00000400 */

/******************  Bits definition for DMA_CH4CNT register  *****************/
#define DMA_CH4CNT_CNT_DPos          (0U)
#define DMA_CH4CNT_CNT_Pos           DMA_CH4CNT_CNT_DPos
#define DMA_CH4CNT_CNT_Msk           (0xFFFFUL << DMA_CH4CNT_CNT_Pos)                      /* 0x0000ffff */
#define DMA_CH4CNT_CNT               DMA_CH4CNT_CNT_Msk                                    /* DMA channel 4 number of data to transfer */

/******************  Bits definition for DMA_CH4PADDR register  *****************/
#define DMA_CH4PADDR_PADDR_DPos      (0U)
#define DMA_CH4PADDR_PADDR_Pos       DMA_CH4PADDR_PADDR_DPos
#define DMA_CH4PADDR_PADDR_Msk       (0xffffffffUL << DMA_CH4PADDR_PADDR_Pos)             /* 0xffffffff */
#define DMA_CH4PADDR_PADDR           DMA_CH4PADDR_PADDR_Msk                               /* DMA channel 4 peripheral address */

/******************  Bits definition for DMA_CH4MADDR register  *****************/
#define DMA_CH4MADDR_MADDR_DPos      (0U)
#define DMA_CH4MADDR_MADDR_Pos       DMA_CH4MADDR_MADDR_DPos
#define DMA_CH4MADDR_MADDR_Msk       (0xffffffffUL << DMA_CH4MADDR_MADDR_Pos)                   /* 0xffffffff */
#define DMA_CH4MADDR_MADDR           DMA_CH4MADDR_MADDR_Msk                                     /* DMA channel 4 memory address */



/******************  Bits definition for DMA_CH5CTL register  *****************/
#define DMA_CH5CTL_M2M_DPos          (0U)
#define DMA_CH5CTL_M2M_Pos           DMA_CH5CTL_M2M_DPos
#define DMA_CH5CTL_M2M_Msk           (0x01UL << DMA_CH5CTL_M2M_Pos)                      /* 0x00000001 */
#define DMA_CH5CTL_M2M               DMA_CH5CTL_M2M_Msk                                  /* DMA channel 5 memory-to-memory transfer mode */

#define DMA_CH5CTL_DIR_DPos          (1U)
#define DMA_CH5CTL_DIR_Pos           DMA_CH5CTL_DIR_DPos
#define DMA_CH5CTL_DIR_Msk           (0x01UL << DMA_CH5CTL_DIR_Pos)                      /* 0x00000002 */
#define DMA_CH5CTL_DIR               DMA_CH5CTL_DIR_Msk                                  /* DMA channel 5 data transfer direction */

#define DMA_CH5CTL_CMEN_DPos         (2U)
#define DMA_CH5CTL_CIRC_Pos          DMA_CH5CTL_CMEN_DPos
#define DMA_CH5CTL_CIRC_Msk          (0x01UL << DMA_CH5CTL_CIRC_Pos)                     /* 0x00000004 */
#define DMA_CH5CTL_CIRC              DMA_CH5CTL_CIRC_Msk                                 /* DMA channel 5 circular mode */

#define DMA_CH5CTL_PNAGA_DPos        (3U)
#define DMA_CH5CTL_PINC_Pos          DMA_CH5CTL_PNAGA_DPos
#define DMA_CH5CTL_PINC_Msk          (0x01UL << DMA_CH5CTL_PINC_Pos)                     /* 0x00000008 */
#define DMA_CH5CTL_PINC              DMA_CH5CTL_PINC_Msk                                 /* DMA channel 5 peripheral address increment */

#define DMA_CH5CTL_MNAGA_DPos        (4U)
#define DMA_CH5CTL_MINC_Pos          DMA_CH5CTL_MNAGA_DPos
#define DMA_CH5CTL_MINC_Msk          (0x01UL << DMA_CH5CTL_MINC_Pos)                     /* 0x00000010 */
#define DMA_CH5CTL_MINC              DMA_CH5CTL_MINC_Msk                                 /* DMA channel 5 memory address increment */

#define DMA_CH5CTL_PWIDTH_DPos       (5U)
#define DMA_CH5CTL_PSIZE_Pos         DMA_CH5CTL_PWIDTH_DPos
#define DMA_CH5CTL_PSIZE_Msk         (0x03UL << DMA_CH5CTL_PSIZE_Pos)                    /* 0x00000060 */
#define DMA_CH5CTL_PSIZE             DMA_CH5CTL_PSIZE_Msk                                /* PWIDTH reg[1:0] bits( DMA channel 5 peripheral data width) */
#define DMA_CH5CTL_PSIZE_0           (0x01UL << DMA_CH5CTL_PSIZE_Pos)                    /* 0x00000020 */
#define DMA_CH5CTL_PSIZE_1           (0x02UL << DMA_CH5CTL_PSIZE_Pos)                    /* 0x00000040 */

#define DMA_CH5CTL_MWIDTH_DPos       (7U)
#define DMA_CH5CTL_MSIZE_Pos         DMA_CH5CTL_MWIDTH_DPos
#define DMA_CH5CTL_MSIZE_Msk         (0x03UL << DMA_CH5CTL_MSIZE_Pos)                    /* 0x00000180 */
#define DMA_CH5CTL_MSIZE             DMA_CH5CTL_MSIZE_Msk                                /* MWIDTH reg[1:0] bits( DMA channel 5 memory data width) */
#define DMA_CH5CTL_MSIZE_0           (0x01UL << DMA_CH5CTL_MSIZE_Pos)                    /* 0x00000080 */
#define DMA_CH5CTL_MSIZE_1           (0x02UL << DMA_CH5CTL_MSIZE_Pos)                    /* 0x00000100 */

#define DMA_CH5CTL_PRIO_DPos         (9U)
#define DMA_CH5CTL_PRIO_Pos          DMA_CH5CTL_PRIO_DPos
#define DMA_CH5CTL_PRIO_Msk          (0x03UL << DMA_CH5CTL_PRIO_Pos)                     /* 0x00000600 */
#define DMA_CH5CTL_PRIO              DMA_CH5CTL_PRIO_Msk                                 /* PRIO reg[1:0] bits(DMA channel 5 priority level) */
#define DMA_CH5CTL_PRIO_0            (0x01UL << DMA_CH5CTL_PRIO_Pos)                     /* 0x00000200 */
#define DMA_CH5CTL_PRIO_1            (0x02UL << DMA_CH5CTL_PRIO_Pos)                     /* 0x00000400 */

/******************  Bits definition for DMA_CH5CNT register  *****************/
#define DMA_CH5CNT_CNT_DPos          (0U)
#define DMA_CH5CNT_CNT_Pos           DMA_CH5CNT_CNT_DPos
#define DMA_CH5CNT_CNT_Msk           (0xFFFFUL << DMA_CH5CNT_CNT_Pos)                      /* 0x0000ffff */
#define DMA_CH5CNT_CNT               DMA_CH5CNT_CNT_Msk                                    /* DMA channel 5 number of data to transfer */

/******************  Bits definition for DMA_CH5PADDR register  *****************/
#define DMA_CH5PADDR_PADDR_DPos      (0U)
#define DMA_CH5PADDR_PADDR_Pos       DMA_CH5PADDR_PADDR_DPos
#define DMA_CH5PADDR_PADDR_Msk       (0xffffffffUL << DMA_CH5PADDR_PADDR_Pos)             /* 0xffffffff */
#define DMA_CH5PADDR_PADDR           DMA_CH5PADDR_PADDR_Msk                               /* DMA channel 5 peripheral address */

/******************  Bits definition for DMA_CH5MADDR register  *****************/
#define DMA_CH5MADDR_MADDR_DPos      (0U)
#define DMA_CH5MADDR_MADDR_Pos       DMA_CH5MADDR_MADDR_DPos
#define DMA_CH5MADDR_MADDR_Msk       (0xffffffffUL << DMA_CH5MADDR_MADDR_Pos)                   /* 0xffffffff */
#define DMA_CH5MADDR_MADDR           DMA_CH5MADDR_MADDR_Msk                                     /* DMA channel 5 memory address */


/******************  Bits definition for DMA_CH6CTL register  *****************/
#define DMA_CH6CTL_M2M_DPos          (0U)
#define DMA_CH6CTL_M2M_Pos           DMA_CH6CTL_M2M_DPos
#define DMA_CH6CTL_M2M_Msk           (0x01UL << DMA_CH6CTL_M2M_Pos)                      /* 0x00000001 */
#define DMA_CH6CTL_M2M               DMA_CH6CTL_M2M_Msk                                  /* DMA channel 6 memory-to-memory transfer mode */

#define DMA_CH6CTL_DIR_DPos          (1U)
#define DMA_CH6CTL_DIR_Pos           DMA_CH6CTL_DIR_DPos
#define DMA_CH6CTL_DIR_Msk           (0x01UL << DMA_CH6CTL_DIR_Pos)                      /* 0x00000002 */
#define DMA_CH6CTL_DIR               DMA_CH6CTL_DIR_Msk                                  /* DMA channel 6 data transfer direction */

#define DMA_CH6CTL_CMEN_DPos         (2U)
#define DMA_CH6CTL_CIRC_Pos          DMA_CH6CTL_CMEN_DPos
#define DMA_CH6CTL_CIRC_Msk          (0x01UL << DMA_CH6CTL_CIRC_Pos)                     /* 0x00000004 */
#define DMA_CH6CTL_CIRC              DMA_CH6CTL_CIRC_Msk                                 /* DMA channel 6 circular mode */

#define DMA_CH6CTL_PNAGA_DPos        (3U)
#define DMA_CH6CTL_PINC_Pos          DMA_CH6CTL_PNAGA_DPos
#define DMA_CH6CTL_PINC_Msk          (0x01UL << DMA_CH6CTL_PINC_Pos)                     /* 0x00000008 */
#define DMA_CH6CTL_PINC              DMA_CH6CTL_PINC_Msk                                 /* DMA channel 6 peripheral address increment */

#define DMA_CH6CTL_MNAGA_DPos        (4U)
#define DMA_CH6CTL_MINC_Pos          DMA_CH6CTL_MNAGA_DPos
#define DMA_CH6CTL_MINC_Msk          (0x01UL << DMA_CH6CTL_MINC_Pos)                     /* 0x00000010 */
#define DMA_CH6CTL_MINC              DMA_CH6CTL_MINC_Msk                                 /* DMA channel 6 memory address increment */

#define DMA_CH6CTL_PWIDTH_DPos       (5U)
#define DMA_CH6CTL_PSIZE_Pos         DMA_CH6CTL_PWIDTH_DPos
#define DMA_CH6CTL_PSIZE_Msk         (0x03UL << DMA_CH6CTL_PSIZE_Pos)                    /* 0x00000060 */
#define DMA_CH6CTL_PSIZE             DMA_CH6CTL_PSIZE_Msk                                /* PWIDTH reg[1:0] bits( DMA channel 6 peripheral data width) */
#define DMA_CH6CTL_PSIZE_0           (0x01UL << DMA_CH6CTL_PSIZE_Pos)                    /* 0x00000020 */
#define DMA_CH6CTL_PSIZE_1           (0x02UL << DMA_CH6CTL_PSIZE_Pos)                    /* 0x00000040 */

#define DMA_CH6CTL_MWIDTH_DPos       (7U)
#define DMA_CH6CTL_MSIZE_Pos         DMA_CH6CTL_MWIDTH_DPos
#define DMA_CH6CTL_MSIZE_Msk         (0x03UL << DMA_CH6CTL_MSIZE_Pos)                    /* 0x00000180 */
#define DMA_CH6CTL_MSIZE             DMA_CH6CTL_MSIZE_Msk                                /* MWIDTH reg[1:0] bits( DMA channel 6 memory data width) */
#define DMA_CH6CTL_MSIZE_0           (0x01UL << DMA_CH6CTL_MSIZE_Pos)                    /* 0x00000080 */
#define DMA_CH6CTL_MSIZE_1           (0x02UL << DMA_CH6CTL_MSIZE_Pos)                    /* 0x00000100 */

#define DMA_CH6CTL_PRIO_DPos         (9U)
#define DMA_CH6CTL_PRIO_Pos          DMA_CH6CTL_PRIO_DPos
#define DMA_CH6CTL_PRIO_Msk          (0x03UL << DMA_CH6CTL_PRIO_Pos)                     /* 0x00000600 */
#define DMA_CH6CTL_PRIO              DMA_CH6CTL_PRIO_Msk                                 /* PRIO reg[1:0] bits(DMA channel 6 priority level) */
#define DMA_CH6CTL_PRIO_0            (0x01UL << DMA_CH6CTL_PRIO_Pos)                     /* 0x00000200 */
#define DMA_CH6CTL_PRIO_1            (0x02UL << DMA_CH6CTL_PRIO_Pos)                     /* 0x00000400 */

/******************  Bits definition for DMA_CH6CNT register  *****************/
#define DMA_CH6CNT_CNT_DPos          (0U)
#define DMA_CH6CNT_CNT_Pos           DMA_CH6CNT_CNT_DPos
#define DMA_CH6CNT_CNT_Msk           (0xFFFFUL << DMA_CH6CNT_CNT_Pos)                      /* 0x0000ffff */
#define DMA_CH6CNT_CNT               DMA_CH6CNT_CNT_Msk                                    /* DMA channel 6 number of data to transfer */

/******************  Bits definition for DMA_CH6PADDR register  *****************/
#define DMA_CH6PADDR_PADDR_DPos      (0U)
#define DMA_CH6PADDR_PADDR_Pos       DMA_CH6PADDR_PADDR_DPos
#define DMA_CH6PADDR_PADDR_Msk       (0xffffffffUL << DMA_CH6PADDR_PADDR_Pos)             /* 0xffffffff */
#define DMA_CH6PADDR_PADDR           DMA_CH6PADDR_PADDR_Msk                               /* DMA channel 6 peripheral address */

/******************  Bits definition for DMA_CH6MADDR register  *****************/
#define DMA_CH6MADDR_MADDR_DPos      (0U)
#define DMA_CH6MADDR_MADDR_Pos       DMA_CH6MADDR_MADDR_DPos
#define DMA_CH6MADDR_MADDR_Msk       (0xffffffffUL << DMA_CH6MADDR_MADDR_Pos)                   /* 0xffffffff */
#define DMA_CH6MADDR_MADDR           DMA_CH6MADDR_MADDR_Msk                                     /* DMA channel 6 memory address */



/******************  Bits definition for DMA_CH7CTL register  *****************/
#define DMA_CH7CTL_M2M_DPos          (0U)
#define DMA_CH7CTL_M2M_Pos           DMA_CH7CTL_M2M_DPos
#define DMA_CH7CTL_M2M_Msk           (0x01UL << DMA_CH7CTL_M2M_Pos)                      /* 0x00000001 */
#define DMA_CH7CTL_M2M               DMA_CH7CTL_M2M_Msk                                  /* DMA channel 7 memory-to-memory transfer mode */

#define DMA_CH7CTL_DIR_DPos          (1U)
#define DMA_CH7CTL_DIR_Pos           DMA_CH7CTL_DIR_DPos
#define DMA_CH7CTL_DIR_Msk           (0x01UL << DMA_CH7CTL_DIR_Pos)                      /* 0x00000002 */
#define DMA_CH7CTL_DIR               DMA_CH7CTL_DIR_Msk                                  /* DMA channel 7 data transfer direction */

#define DMA_CH7CTL_CMEN_DPos         (2U)
#define DMA_CH7CTL_CIRC_Pos          DMA_CH7CTL_CMEN_DPos
#define DMA_CH7CTL_CIRC_Msk          (0x01UL << DMA_CH7CTL_CIRC_Pos)                     /* 0x00000004 */
#define DMA_CH7CTL_CIRC              DMA_CH7CTL_CIRC_Msk                                 /* DMA channel 7 circular mode */

#define DMA_CH7CTL_PNAGA_DPos        (3U)
#define DMA_CH7CTL_PINC_Pos          DMA_CH7CTL_PNAGA_DPos
#define DMA_CH7CTL_PINC_Msk          (0x01UL << DMA_CH7CTL_PINC_Pos)                     /* 0x00000008 */
#define DMA_CH7CTL_PINC              DMA_CH7CTL_PINC_Msk                                 /* DMA channel 7 peripheral address increment */

#define DMA_CH7CTL_MNAGA_DPos        (4U)
#define DMA_CH7CTL_MINC_Pos          DMA_CH7CTL_MNAGA_DPos
#define DMA_CH7CTL_MINC_Msk          (0x01UL << DMA_CH7CTL_MINC_Pos)                     /* 0x00000010 */
#define DMA_CH7CTL_MINC              DMA_CH7CTL_MINC_Msk                                 /* DMA channel 7 memory address increment */

#define DMA_CH7CTL_PWIDTH_DPos       (5U)
#define DMA_CH7CTL_PSIZE_Pos         DMA_CH7CTL_PWIDTH_DPos
#define DMA_CH7CTL_PSIZE_Msk         (0x03UL << DMA_CH7CTL_PSIZE_Pos)                    /* 0x00000060 */
#define DMA_CH7CTL_PSIZE             DMA_CH7CTL_PSIZE_Msk                                /* PWIDTH reg[1:0] bits( DMA channel 7 peripheral data width) */
#define DMA_CH7CTL_PSIZE_0           (0x01UL << DMA_CH7CTL_PSIZE_Pos)                    /* 0x00000020 */
#define DMA_CH7CTL_PSIZE_1           (0x02UL << DMA_CH7CTL_PSIZE_Pos)                    /* 0x00000040 */

#define DMA_CH7CTL_MWIDTH_DPos       (7U)
#define DMA_CH7CTL_MSIZE_Pos         DMA_CH7CTL_MWIDTH_DPos
#define DMA_CH7CTL_MSIZE_Msk         (0x03UL << DMA_CH7CTL_MSIZE_Pos)                    /* 0x00000180 */
#define DMA_CH7CTL_MSIZE             DMA_CH7CTL_MSIZE_Msk                                /* MWIDTH reg[1:0] bits( DMA channel 7 memory data width) */
#define DMA_CH7CTL_MSIZE_0           (0x01UL << DMA_CH7CTL_MSIZE_Pos)                    /* 0x00000080 */
#define DMA_CH7CTL_MSIZE_1           (0x02UL << DMA_CH7CTL_MSIZE_Pos)                    /* 0x00000100 */

#define DMA_CH7CTL_PRIO_DPos         (9U)
#define DMA_CH7CTL_PRIO_Pos          DMA_CH7CTL_PRIO_DPos
#define DMA_CH7CTL_PRIO_Msk          (0x03UL << DMA_CH7CTL_PRIO_Pos)                     /* 0x00000600 */
#define DMA_CH7CTL_PRIO              DMA_CH7CTL_PRIO_Msk                                 /* PRIO reg[1:0] bits(DMA channel 7 priority level) */
#define DMA_CH7CTL_PRIO_0            (0x01UL << DMA_CH7CTL_PRIO_Pos)                     /* 0x00000200 */
#define DMA_CH7CTL_PRIO_1            (0x02UL << DMA_CH7CTL_PRIO_Pos)                     /* 0x00000400 */

/******************  Bits definition for DMA_CH7CNT register  *****************/
#define DMA_CH7CNT_CNT_DPos          (0U)
#define DMA_CH7CNT_CNT_Pos           DMA_CH7CNT_CNT_DPos
#define DMA_CH7CNT_CNT_Msk           (0xFFFFUL << DMA_CH7CNT_CNT_Pos)                      /* 0x0000ffff */
#define DMA_CH7CNT_CNT               DMA_CH7CNT_CNT_Msk                                    /* DMA channel 7 number of data to transfer */

/******************  Bits definition for DMA_CH7PADDR register  *****************/
#define DMA_CH7PADDR_PADDR_DPos      (0U)
#define DMA_CH7PADDR_PADDR_Pos       DMA_CH7PADDR_PADDR_DPos
#define DMA_CH7PADDR_PADDR_Msk       (0xffffffffUL << DMA_CH7PADDR_PADDR_Pos)             /* 0xffffffff */
#define DMA_CH7PADDR_PADDR           DMA_CH7PADDR_PADDR_Msk                               /* DMA channel 7 peripheral address */

/******************  Bits definition for DMA_CH7MADDR register  *****************/
#define DMA_CH7MADDR_MADDR_DPos      (0U)
#define DMA_CH7MADDR_MADDR_Pos       DMA_CH7MADDR_MADDR_DPos
#define DMA_CH7MADDR_MADDR_Msk       (0xffffffffUL << DMA_CH7MADDR_MADDR_Pos)                   /* 0xffffffff */
#define DMA_CH7MADDR_MADDR           DMA_CH7MADDR_MADDR_Msk                                     /* DMA channel 7 memory address */


/******************  Bits definition for DMA_CH8CTL register  *****************/
#define DMA_CH8CTL_M2M_DPos          (0U)
#define DMA_CH8CTL_M2M_Pos           DMA_CH8CTL_M2M_DPos
#define DMA_CH8CTL_M2M_Msk           (0x01UL << DMA_CH8CTL_M2M_Pos)                      /* 0x00000001 */
#define DMA_CH8CTL_M2M               DMA_CH8CTL_M2M_Msk                                  /* DMA channel 8 memory-to-memory transfer mode */

#define DMA_CH8CTL_DIR_DPos          (1U)
#define DMA_CH8CTL_DIR_Pos           DMA_CH8CTL_DIR_DPos
#define DMA_CH8CTL_DIR_Msk           (0x01UL << DMA_CH8CTL_DIR_Pos)                      /* 0x00000002 */
#define DMA_CH8CTL_DIR               DMA_CH8CTL_DIR_Msk                                  /* DMA channel 8 data transfer direction */

#define DMA_CH8CTL_CMEN_DPos         (2U)
#define DMA_CH8CTL_CIRC_Pos          DMA_CH8CTL_CMEN_DPos
#define DMA_CH8CTL_CIRC_Msk          (0x01UL << DMA_CH8CTL_CIRC_Pos)                     /* 0x00000004 */
#define DMA_CH8CTL_CIRC              DMA_CH8CTL_CIRC_Msk                                 /* DMA channel 8 circular mode */

#define DMA_CH8CTL_PNAGA_DPos        (3U)
#define DMA_CH8CTL_PINC_Pos          DMA_CH8CTL_PNAGA_DPos
#define DMA_CH8CTL_PINC_Msk          (0x01UL << DMA_CH8CTL_PINC_Pos)                     /* 0x00000008 */
#define DMA_CH8CTL_PINC              DMA_CH8CTL_PINC_Msk                                 /* DMA channel 8 peripheral address increment */

#define DMA_CH8CTL_MNAGA_DPos        (4U)
#define DMA_CH8CTL_MINC_Pos          DMA_CH8CTL_MNAGA_DPos
#define DMA_CH8CTL_MINC_Msk          (0x01UL << DMA_CH8CTL_MINC_Pos)                     /* 0x00000010 */
#define DMA_CH8CTL_MINC              DMA_CH8CTL_MINC_Msk                                 /* DMA channel 8 memory address increment */

#define DMA_CH8CTL_PWIDTH_DPos       (5U)
#define DMA_CH8CTL_PSIZE_Pos         DMA_CH8CTL_PWIDTH_DPos
#define DMA_CH8CTL_PSIZE_Msk         (0x03UL << DMA_CH8CTL_PSIZE_Pos)                    /* 0x00000060 */
#define DMA_CH8CTL_PSIZE             DMA_CH8CTL_PSIZE_Msk                                /* PWIDTH reg[1:0] bits( DMA channel 8 peripheral data width) */
#define DMA_CH8CTL_PSIZE_0           (0x01UL << DMA_CH8CTL_PSIZE_Pos)                    /* 0x00000020 */
#define DMA_CH8CTL_PSIZE_1           (0x02UL << DMA_CH8CTL_PSIZE_Pos)                    /* 0x00000040 */

#define DMA_CH8CTL_MWIDTH_DPos       (7U)
#define DMA_CH8CTL_MSIZE_Pos         DMA_CH8CTL_MWIDTH_DPos
#define DMA_CH8CTL_MSIZE_Msk         (0x03UL << DMA_CH8CTL_MSIZE_Pos)                    /* 0x00000180 */
#define DMA_CH8CTL_MSIZE             DMA_CH8CTL_MSIZE_Msk                                /* MWIDTH reg[1:0] bits( DMA channel 8 memory data width) */
#define DMA_CH8CTL_MSIZE_0           (0x01UL << DMA_CH8CTL_MSIZE_Pos)                    /* 0x00000080 */
#define DMA_CH8CTL_MSIZE_1           (0x02UL << DMA_CH8CTL_MSIZE_Pos)                    /* 0x00000100 */

#define DMA_CH8CTL_PRIO_DPos         (9U)
#define DMA_CH8CTL_PRIO_Pos          DMA_CH8CTL_PRIO_DPos
#define DMA_CH8CTL_PRIO_Msk          (0x03UL << DMA_CH8CTL_PRIO_Pos)                     /* 0x00000600 */
#define DMA_CH8CTL_PRIO              DMA_CH8CTL_PRIO_Msk                                 /* PRIO reg[1:0] bits(DMA channel 8 priority level) */
#define DMA_CH8CTL_PRIO_0            (0x01UL << DMA_CH8CTL_PRIO_Pos)                     /* 0x00000200 */
#define DMA_CH8CTL_PRIO_1            (0x02UL << DMA_CH8CTL_PRIO_Pos)                     /* 0x00000400 */

/******************  Bits definition for DMA_CH8CNT register  *****************/
#define DMA_CH8CNT_CNT_DPos          (0U)
#define DMA_CH8CNT_CNT_Pos           DMA_CH8CNT_CNT_DPos
#define DMA_CH8CNT_CNT_Msk           (0xFFFFUL << DMA_CH8CNT_CNT_Pos)                      /* 0x0000ffff */
#define DMA_CH8CNT_CNT               DMA_CH8CNT_CNT_Msk                                    /* DMA channel 8 number of data to transfer */

/******************  Bits definition for DMA_CH8PADDR register  *****************/
#define DMA_CH8PADDR_PADDR_DPos      (0U)
#define DMA_CH8PADDR_PADDR_Pos       DMA_CH8PADDR_PADDR_DPos
#define DMA_CH8PADDR_PADDR_Msk       (0xffffffffUL << DMA_CH8PADDR_PADDR_Pos)             /* 0xffffffff */
#define DMA_CH8PADDR_PADDR           DMA_CH8PADDR_PADDR_Msk                               /* DMA channel 8 peripheral address */

/******************  Bits definition for DMA_CH8MADDR register  *****************/
#define DMA_CH8MADDR_MADDR_DPos      (0U)
#define DMA_CH8MADDR_MADDR_Pos       DMA_CH8MADDR_MADDR_DPos
#define DMA_CH8MADDR_MADDR_Msk       (0xffffffffUL << DMA_CH8MADDR_MADDR_Pos)                   /* 0xffffffff */
#define DMA_CH8MADDR_MADDR           DMA_CH8MADDR_MADDR_Msk                                     /* DMA channel 8 memory address */


/******************  Bits definition for DMA_CH9CTL register  *****************/
#define DMA_CH9CTL_M2M_DPos          (0U)
#define DMA_CH9CTL_M2M_Pos           DMA_CH9CTL_M2M_DPos
#define DMA_CH9CTL_M2M_Msk           (0x01UL << DMA_CH9CTL_M2M_Pos)                      /* 0x00000001 */
#define DMA_CH9CTL_M2M               DMA_CH9CTL_M2M_Msk                                  /* DMA channel 9 memory-to-memory transfer mode */

#define DMA_CH9CTL_DIR_DPos          (1U)
#define DMA_CH9CTL_DIR_Pos           DMA_CH9CTL_DIR_DPos
#define DMA_CH9CTL_DIR_Msk           (0x01UL << DMA_CH9CTL_DIR_Pos)                      /* 0x00000002 */
#define DMA_CH9CTL_DIR               DMA_CH9CTL_DIR_Msk                                  /* DMA channel 9 data transfer direction */

#define DMA_CH9CTL_CMEN_DPos         (2U)
#define DMA_CH9CTL_CIRC_Pos          DMA_CH9CTL_CMEN_DPos
#define DMA_CH9CTL_CIRC_Msk          (0x01UL << DMA_CH9CTL_CIRC_Pos)                     /* 0x00000004 */
#define DMA_CH9CTL_CIRC              DMA_CH9CTL_CIRC_Msk                                 /* DMA channel 9 circular mode */

#define DMA_CH9CTL_PNAGA_DPos        (3U)
#define DMA_CH9CTL_PINC_Pos          DMA_CH9CTL_PNAGA_DPos
#define DMA_CH9CTL_PINC_Msk          (0x01UL << DMA_CH9CTL_PINC_Pos)                     /* 0x00000008 */
#define DMA_CH9CTL_PINC              DMA_CH9CTL_PINC_Msk                                 /* DMA channel 9 peripheral address increment */

#define DMA_CH9CTL_MNAGA_DPos        (4U)
#define DMA_CH9CTL_MINC_Pos          DMA_CH9CTL_MNAGA_DPos
#define DMA_CH9CTL_MINC_Msk          (0x01UL << DMA_CH9CTL_MINC_Pos)                     /* 0x00000010 */
#define DMA_CH9CTL_MINC              DMA_CH9CTL_MINC_Msk                                 /* DMA channel 9 memory address increment */

#define DMA_CH9CTL_PWIDTH_DPos       (5U)
#define DMA_CH9CTL_PSIZE_Pos         DMA_CH9CTL_PWIDTH_DPos
#define DMA_CH9CTL_PSIZE_Msk         (0x03UL << DMA_CH9CTL_PSIZE_Pos)                    /* 0x00000060 */
#define DMA_CH9CTL_PSIZE             DMA_CH9CTL_PSIZE_Msk                                /* PWIDTH reg[1:0] bits( DMA channel 9 peripheral data width) */
#define DMA_CH9CTL_PSIZE_0           (0x01UL << DMA_CH9CTL_PSIZE_Pos)                    /* 0x00000020 */
#define DMA_CH9CTL_PSIZE_1           (0x02UL << DMA_CH9CTL_PSIZE_Pos)                    /* 0x00000040 */

#define DMA_CH9CTL_MWIDTH_DPos       (7U)
#define DMA_CH9CTL_MSIZE_Pos         DMA_CH9CTL_MWIDTH_DPos
#define DMA_CH9CTL_MSIZE_Msk         (0x03UL << DMA_CH9CTL_MSIZE_Pos)                    /* 0x00000180 */
#define DMA_CH9CTL_MSIZE             DMA_CH9CTL_MSIZE_Msk                                /* MWIDTH reg[1:0] bits( DMA channel 9 memory data width) */
#define DMA_CH9CTL_MSIZE_0           (0x01UL << DMA_CH9CTL_MSIZE_Pos)                    /* 0x00000080 */
#define DMA_CH9CTL_MSIZE_1           (0x02UL << DMA_CH9CTL_MSIZE_Pos)                    /* 0x00000100 */

#define DMA_CH9CTL_PRIO_DPos         (9U)
#define DMA_CH9CTL_PRIO_Pos          DMA_CH9CTL_PRIO_DPos
#define DMA_CH9CTL_PRIO_Msk          (0x03UL << DMA_CH9CTL_PRIO_Pos)                     /* 0x00000600 */
#define DMA_CH9CTL_PRIO              DMA_CH9CTL_PRIO_Msk                                 /* PRIO reg[1:0] bits(DMA channel 9 priority level)  */
#define DMA_CH9CTL_PRIO_0            (0x01UL << DMA_CH9CTL_PRIO_Pos)                     /* 0x00000200 */
#define DMA_CH9CTL_PRIO_1            (0x02UL << DMA_CH9CTL_PRIO_Pos)                     /* 0x00000400 */

/******************  Bits definition for DMA_CH9CNT register  *****************/
#define DMA_CH9CNT_CNT_DPos          (0U)
#define DMA_CH9CNT_CNT_Pos           DMA_CH9CNT_CNT_DPos
#define DMA_CH9CNT_CNT_Msk           (0xFFFFUL << DMA_CH9CNT_CNT_Pos)                      /* 0x0000ffff */
#define DMA_CH9CNT_CNT               DMA_CH9CNT_CNT_Msk                                    /* DMA channel 9 number of data to transfer */

/******************  Bits definition for DMA_CH9PADDR register  *****************/
#define DMA_CH9PADDR_PADDR_DPos      (0U)
#define DMA_CH9PADDR_PADDR_Pos       DMA_CH9PADDR_PADDR_DPos
#define DMA_CH9PADDR_PADDR_Msk       (0xffffffffUL << DMA_CH9PADDR_PADDR_Pos)             /* 0xffffffff */
#define DMA_CH9PADDR_PADDR           DMA_CH9PADDR_PADDR_Msk                               /* DMA channel 9 peripheral address */

/******************  Bits definition for DMA_CH9MADDR register  *****************/
#define DMA_CH9MADDR_MADDR_DPos      (0U)
#define DMA_CH9MADDR_MADDR_Pos       DMA_CH9MADDR_MADDR_DPos
#define DMA_CH9MADDR_MADDR_Msk       (0xffffffffUL << DMA_CH9MADDR_MADDR_Pos)                   /* 0xffffffff */
#define DMA_CH9MADDR_MADDR           DMA_CH9MADDR_MADDR_Msk                                     /* DMA channel 9 memory address */



/******************  Bits definition for DMA_CH10CTL register  *****************/
#define DMA_CH10CTL_M2M_DPos          (0U)
#define DMA_CH10CTL_M2M_Pos           DMA_CH10CTL_M2M_DPos
#define DMA_CH10CTL_M2M_Msk           (0x01UL << DMA_CH10CTL_M2M_Pos)                      /* 0x00000001 */
#define DMA_CH10CTL_M2M               DMA_CH10CTL_M2M_Msk                                  /* DMA channel 10 memory-to-memory transfer mode */

#define DMA_CH10CTL_DIR_DPos          (1U)
#define DMA_CH10CTL_DIR_Pos           DMA_CH10CTL_DIR_DPos
#define DMA_CH10CTL_DIR_Msk           (0x01UL << DMA_CH10CTL_DIR_Pos)                      /* 0x00000002 */
#define DMA_CH10CTL_DIR               DMA_CH10CTL_DIR_Msk                                  /* DMA channel 10 data transfer direction */

#define DMA_CH10CTL_CMEN_DPos         (2U)
#define DMA_CH10CTL_CIRC_Pos          DMA_CH10CTL_CMEN_DPos
#define DMA_CH10CTL_CIRC_Msk          (0x01UL << DMA_CH10CTL_CIRC_Pos)                     /* 0x00000004 */
#define DMA_CH10CTL_CIRC              DMA_CH10CTL_CIRC_Msk                                 /* DMA channel 10 circular mode */

#define DMA_CH10CTL_PNAGA_DPos        (3U)
#define DMA_CH10CTL_PINC_Pos          DMA_CH10CTL_PNAGA_DPos
#define DMA_CH10CTL_PINC_Msk          (0x01UL << DMA_CH10CTL_PINC_Pos)                     /* 0x00000008 */
#define DMA_CH10CTL_PINC              DMA_CH10CTL_PINC_Msk                                 /* DMA channel 10 peripheral address increment */

#define DMA_CH10CTL_MNAGA_DPos        (4U)
#define DMA_CH10CTL_MINC_Pos          DMA_CH10CTL_MNAGA_DPos
#define DMA_CH10CTL_MINC_Msk          (0x01UL << DMA_CH10CTL_MINC_Pos)                     /* 0x00000010 */
#define DMA_CH10CTL_MINC              DMA_CH10CTL_MINC_Msk                                 /* DMA channel 10 memory address increment */

#define DMA_CH10CTL_PWIDTH_DPos       (5U)
#define DMA_CH10CTL_PSIZE_Pos         DMA_CH10CTL_PWIDTH_DPos
#define DMA_CH10CTL_PSIZE_Msk         (0x03UL << DMA_CH10CTL_PSIZE_Pos)                    /* 0x00000060 */
#define DMA_CH10CTL_PSIZE             DMA_CH10CTL_PSIZE_Msk                                /* PWIDTH reg[1:0] bits( DMA channel 10 peripheral data width) */
#define DMA_CH10CTL_PSIZE_0           (0x01UL << DMA_CH10CTL_PSIZE_Pos)                    /* 0x00000020 */
#define DMA_CH10CTL_PSIZE_1           (0x02UL << DMA_CH10CTL_PSIZE_Pos)                    /* 0x00000040 */

#define DMA_CH10CTL_MWIDTH_DPos       (7U)
#define DMA_CH10CTL_MSIZE_Pos         DMA_CH10CTL_MWIDTH_DPos
#define DMA_CH10CTL_MSIZE_Msk         (0x03UL << DMA_CH10CTL_MSIZE_Pos)                    /* 0x00000180 */
#define DMA_CH10CTL_MSIZE             DMA_CH10CTL_MSIZE_Msk                                /* MWIDTH reg[1:0] bits( DMA channel 10 memory data width) */
#define DMA_CH10CTL_MSIZE_0           (0x01UL << DMA_CH10CTL_MSIZE_Pos)                    /* 0x00000080 */
#define DMA_CH10CTL_MSIZE_1           (0x02UL << DMA_CH10CTL_MSIZE_Pos)                    /* 0x00000100 */

#define DMA_CH10CTL_PRIO_DPos         (9U)
#define DMA_CH10CTL_PRIO_Pos          DMA_CH10CTL_PRIO_DPos
#define DMA_CH10CTL_PRIO_Msk          (0x03UL << DMA_CH10CTL_PRIO_Pos)                     /* 0x00000600 */
#define DMA_CH10CTL_PRIO              DMA_CH10CTL_PRIO_Msk                                 /* PRIO reg[1:0] bits(DMA channel 10 priority level) */
#define DMA_CH10CTL_PRIO_0            (0x01UL << DMA_CH10CTL_PRIO_Pos)                     /* 0x00000200 */
#define DMA_CH10CTL_PRIO_1            (0x02UL << DMA_CH10CTL_PRIO_Pos)                     /* 0x00000400 */

/******************  Bits definition for DMA_CH10CNT register  *****************/
#define DMA_CH10CNT_CNT_DPos          (0U)
#define DMA_CH10CNT_CNT_Pos           DMA_CH10CNT_CNT_DPos
#define DMA_CH10CNT_CNT_Msk           (0xFFFFUL << DMA_CH10CNT_CNT_Pos)                      /* 0x0000ffff */
#define DMA_CH10CNT_CNT               DMA_CH10CNT_CNT_Msk                                    /* DMA channel 10 number of data to transfer */

/******************  Bits definition for DMA_CH10PADDR register  *****************/
#define DMA_CH10PADDR_PADDR_DPos      (0U)
#define DMA_CH10PADDR_PADDR_Pos       DMA_CH10PADDR_PADDR_DPos
#define DMA_CH10PADDR_PADDR_Msk       (0xffffffffUL << DMA_CH10PADDR_PADDR_Pos)            /* 0xffffffff */
#define DMA_CH10PADDR_PADDR           DMA_CH10PADDR_PADDR_Msk                              /* DMA channel 10 peripheral address */

/******************  Bits definition for DMA_CH10MADDR register  *****************/
#define DMA_CH10MADDR_MADDR_DPos      (0U)
#define DMA_CH10MADDR_MADDR_Pos       DMA_CH10MADDR_MADDR_DPos
#define DMA_CH10MADDR_MADDR_Msk       (0xffffffffUL << DMA_CH10MADDR_MADDR_Pos)                    /* 0xffffffff */
#define DMA_CH10MADDR_MADDR           DMA_CH10MADDR_MADDR_Msk                                      /* DMA channel 10 memory address */


/******************  Bits definition for DMA_CH11CTL register  *****************/
#define DMA_CH11CTL_M2M_DPos          (0U)
#define DMA_CH11CTL_M2M_Pos           DMA_CH11CTL_M2M_DPos
#define DMA_CH11CTL_M2M_Msk           (0x01UL << DMA_CH11CTL_M2M_Pos)                      /* 0x00000001 */
#define DMA_CH11CTL_M2M               DMA_CH11CTL_M2M_Msk                                  /* DMA channel 11 memory-to-memory transfer mode */

#define DMA_CH11CTL_DIR_DPos          (1U)
#define DMA_CH11CTL_DIR_Pos           DMA_CH11CTL_DIR_DPos
#define DMA_CH11CTL_DIR_Msk           (0x01UL << DMA_CH11CTL_DIR_Pos)                      /* 0x00000002 */
#define DMA_CH11CTL_DIR               DMA_CH11CTL_DIR_Msk                                  /* DMA channel 11 data transfer direction */

#define DMA_CH11CTL_CMEN_DPos         (2U)
#define DMA_CH11CTL_CIRC_Pos          DMA_CH11CTL_CMEN_DPos
#define DMA_CH11CTL_CIRC_Msk          (0x01UL << DMA_CH11CTL_CIRC_Pos)                     /* 0x00000004 */
#define DMA_CH11CTL_CIRC              DMA_CH11CTL_CIRC_Msk                                 /* DMA channel 11 circular mode */

#define DMA_CH11CTL_PNAGA_DPos        (3U)
#define DMA_CH11CTL_PINC_Pos          DMA_CH11CTL_PNAGA_DPos
#define DMA_CH11CTL_PINC_Msk          (0x01UL << DMA_CH11CTL_PINC_Pos)                     /* 0x00000008 */
#define DMA_CH11CTL_PINC              DMA_CH11CTL_PINC_Msk                                 /* DMA channel 11 peripheral address increment */

#define DMA_CH11CTL_MNAGA_DPos        (4U)
#define DMA_CH11CTL_MINC_Pos          DMA_CH11CTL_MNAGA_DPos
#define DMA_CH11CTL_MINC_Msk          (0x01UL << DMA_CH11CTL_MINC_Pos)                     /* 0x00000010 */
#define DMA_CH11CTL_MINC              DMA_CH11CTL_MINC_Msk                                 /* DMA channel 11 memory address increment */

#define DMA_CH11CTL_PWIDTH_DPos       (5U)
#define DMA_CH11CTL_PSIZE_Pos         DMA_CH11CTL_PWIDTH_DPos
#define DMA_CH11CTL_PSIZE_Msk         (0x03UL << DMA_CH11CTL_PSIZE_Pos)                    /* 0x00000060 */
#define DMA_CH11CTL_PSIZE             DMA_CH11CTL_PSIZE_Msk                                /* PWIDTH reg[1:0] bits( DMA channel 11 peripheral data width) */
#define DMA_CH11CTL_PSIZE_0           (0x01UL << DMA_CH11CTL_PSIZE_Pos)                    /* 0x00000020 */
#define DMA_CH11CTL_PSIZE_1           (0x02UL << DMA_CH11CTL_PSIZE_Pos)                    /* 0x00000040 */

#define DMA_CH11CTL_MWIDTH_DPos       (7U)
#define DMA_CH11CTL_MSIZE_Pos         DMA_CH11CTL_MWIDTH_DPos
#define DMA_CH11CTL_MSIZE_Msk         (0x03UL << DMA_CH11CTL_MSIZE_Pos)                    /* 0x00000180 */
#define DMA_CH11CTL_MSIZE             DMA_CH11CTL_MSIZE_Msk                                /* MWIDTH reg[1:0] bits( DMA channel 11 memory data width) */
#define DMA_CH11CTL_MSIZE_0           (0x01UL << DMA_CH11CTL_MSIZE_Pos)                    /* 0x00000080 */
#define DMA_CH11CTL_MSIZE_1           (0x02UL << DMA_CH11CTL_MSIZE_Pos)                    /* 0x00000100 */

#define DMA_CH11CTL_PRIO_DPos         (9U)
#define DMA_CH11CTL_PRIO_Pos          DMA_CH11CTL_PRIO_DPos
#define DMA_CH11CTL_PRIO_Msk          (0x03UL << DMA_CH11CTL_PRIO_Pos)                     /* 0x00000600 */
#define DMA_CH11CTL_PRIO              DMA_CH11CTL_PRIO_Msk                                 /* PRIO reg[1:0] bits(DMA channel 11 priority level) */
#define DMA_CH11CTL_PRIO_0            (0x01UL << DMA_CH11CTL_PRIO_Pos)                     /* 0x00000200 */
#define DMA_CH11CTL_PRIO_1            (0x02UL << DMA_CH11CTL_PRIO_Pos)                     /* 0x00000400 */

/******************  Bits definition for DMA_CH11CNT register  *****************/
#define DMA_CH11CNT_CNT_DPos          (0U)
#define DMA_CH11CNT_CNT_Pos           DMA_CH11CNT_CNT_DPos
#define DMA_CH11CNT_CNT_Msk           (0xFFFFUL << DMA_CH11CNT_CNT_Pos)                      /* 0x0000ffff */
#define DMA_CH11CNT_CNT               DMA_CH11CNT_CNT_Msk                                    /* DMA channel 11 number of data to transfer */

/******************  Bits definition for DMA_CH11PADDR register  *****************/
#define DMA_CH11PADDR_PADDR_DPos      (0U)
#define DMA_CH11PADDR_PADDR_Pos       DMA_CH11PADDR_PADDR_DPos
#define DMA_CH11PADDR_PADDR_Msk       (0xffffffffUL << DMA_CH11PADDR_PADDR_Pos)            /* 0xffffffff */
#define DMA_CH11PADDR_PADDR           DMA_CH11PADDR_PADDR_Msk                              /* DMA channel 11 peripheral address */

/******************  Bits definition for DMA_CH11MADDR register  *****************/
#define DMA_CH11MADDR_MADDR_DPos      (0U)
#define DMA_CH11MADDR_MADDR_Pos       DMA_CH11MADDR_MADDR_DPos
#define DMA_CH11MADDR_MADDR_Msk       (0xffffffffUL << DMA_CH11MADDR_MADDR_Pos)                    /* 0xffffffff */
#define DMA_CH11MADDR_MADDR           DMA_CH11MADDR_MADDR_Msk                                      /* DMA channel 11 memory address */



/******************  Bits definition for DMA_CH12CTL register  *****************/
#define DMA_CH12CTL_M2M_DPos          (0U)
#define DMA_CH12CTL_M2M_Pos           DMA_CH12CTL_M2M_DPos
#define DMA_CH12CTL_M2M_Msk           (0x01UL << DMA_CH12CTL_M2M_Pos)                      /* 0x00000001 */
#define DMA_CH12CTL_M2M               DMA_CH12CTL_M2M_Msk                                  /* DMA channel 12 memory-to-memory transfer mode */

#define DMA_CH12CTL_DIR_DPos          (1U)
#define DMA_CH12CTL_DIR_Pos           DMA_CH12CTL_DIR_DPos
#define DMA_CH12CTL_DIR_Msk           (0x01UL << DMA_CH12CTL_DIR_Pos)                      /* 0x00000002 */
#define DMA_CH12CTL_DIR               DMA_CH12CTL_DIR_Msk                                  /* DMA channel 12 data transfer direction */

#define DMA_CH12CTL_CMEN_DPos         (2U)
#define DMA_CH12CTL_CIRC_Pos          DMA_CH12CTL_CMEN_DPos
#define DMA_CH12CTL_CIRC_Msk          (0x01UL << DMA_CH12CTL_CIRC_Pos)                     /* 0x00000004 */
#define DMA_CH12CTL_CIRC              DMA_CH12CTL_CIRC_Msk                                 /* DMA channel 12 circular mode */

#define DMA_CH12CTL_PNAGA_DPos        (3U)
#define DMA_CH12CTL_PINC_Pos          DMA_CH12CTL_PNAGA_DPos
#define DMA_CH12CTL_PINC_Msk          (0x01UL << DMA_CH12CTL_PINC_Pos)                     /* 0x00000008 */
#define DMA_CH12CTL_PINC              DMA_CH12CTL_PINC_Msk                                 /* DMA channel 12 peripheral address increment */

#define DMA_CH12CTL_MNAGA_DPos        (4U)
#define DMA_CH12CTL_MINC_Pos          DMA_CH12CTL_MNAGA_DPos
#define DMA_CH12CTL_MINC_Msk          (0x01UL << DMA_CH12CTL_MINC_Pos)                     /* 0x00000010 */
#define DMA_CH12CTL_MINC              DMA_CH12CTL_MINC_Msk                                 /* DMA channel 12 memory address increment */

#define DMA_CH12CTL_PWIDTH_DPos       (5U)
#define DMA_CH12CTL_PSIZE_Pos         DMA_CH12CTL_PWIDTH_DPos
#define DMA_CH12CTL_PSIZE_Msk         (0x03UL << DMA_CH12CTL_PSIZE_Pos)                    /* 0x00000060 */
#define DMA_CH12CTL_PSIZE             DMA_CH12CTL_PSIZE_Msk                                /* PWIDTH reg[1:0] bits( DMA channel 12 peripheral data width) */
#define DMA_CH12CTL_PSIZE_0           (0x01UL << DMA_CH12CTL_PSIZE_Pos)                    /* 0x00000020 */
#define DMA_CH12CTL_PSIZE_1           (0x02UL << DMA_CH12CTL_PSIZE_Pos)                    /* 0x00000040 */

#define DMA_CH12CTL_MWIDTH_DPos       (7U)
#define DMA_CH12CTL_MSIZE_Pos         DMA_CH12CTL_MWIDTH_DPos
#define DMA_CH12CTL_MSIZE_Msk         (0x03UL << DMA_CH12CTL_MSIZE_Pos)                    /* 0x00000180 */
#define DMA_CH12CTL_MSIZE             DMA_CH12CTL_MSIZE_Msk                                /* MWIDTH reg[1:0] bits( DMA channel 12 memory data width) */
#define DMA_CH12CTL_MSIZE_0           (0x01UL << DMA_CH12CTL_MSIZE_Pos)                    /* 0x00000080 */
#define DMA_CH12CTL_MSIZE_1           (0x02UL << DMA_CH12CTL_MSIZE_Pos)                    /* 0x00000100 */

#define DMA_CH12CTL_PRIO_DPos         (9U)
#define DMA_CH12CTL_PRIO_Pos          DMA_CH12CTL_PRIO_DPos
#define DMA_CH12CTL_PRIO_Msk          (0x03UL << DMA_CH12CTL_PRIO_Pos)                     /* 0x00000600 */
#define DMA_CH12CTL_PRIO              DMA_CH12CTL_PRIO_Msk                                 /* PRIO reg[1:0] bits(DMA channel 12 priority level) */
#define DMA_CH12CTL_PRIO_0            (0x01UL << DMA_CH12CTL_PRIO_Pos)                     /* 0x00000200 */
#define DMA_CH12CTL_PRIO_1            (0x02UL << DMA_CH12CTL_PRIO_Pos)                     /* 0x00000400 */

/******************  Bits definition for DMA_CH12CNT register  *****************/
#define DMA_CH12CNT_CNT_DPos          (0U)
#define DMA_CH12CNT_CNT_Pos           DMA_CH12CNT_CNT_DPos
#define DMA_CH12CNT_CNT_Msk           (0xFFFFUL << DMA_CH12CNT_CNT_Pos)                      /* 0x0000ffff */
#define DMA_CH12CNT_CNT               DMA_CH12CNT_CNT_Msk                                    /* DMA channel 12 number of data to transfer */

/******************  Bits definition for DMA_CH12PADDR register  *****************/
#define DMA_CH12PADDR_PADDR_DPos      (0U)
#define DMA_CH12PADDR_PADDR_Pos       DMA_CH12PADDR_PADDR_DPos
#define DMA_CH12PADDR_PADDR_Msk       (0xffffffffUL << DMA_CH12PADDR_PADDR_Pos)            /* 0xffffffff */
#define DMA_CH12PADDR_PADDR           DMA_CH12PADDR_PADDR_Msk                              /* DMA channel 12 peripheral address */

/******************  Bits definition for DMA_CH12MADDR register  *****************/
#define DMA_CH12MADDR_MADDR_DPos      (0U)
#define DMA_CH12MADDR_MADDR_Pos       DMA_CH12MADDR_MADDR_DPos
#define DMA_CH12MADDR_MADDR_Msk       (0xffffffffUL << DMA_CH12MADDR_MADDR_Pos)                    /* 0xffffffff */
#define DMA_CH12MADDR_MADDR           DMA_CH12MADDR_MADDR_Msk                                      /* DMA channel 12 memory address */


/******************  Bits definition for DMA_CH13CTL register  *****************/
#define DMA_CH13CTL_M2M_DPos          (0U)
#define DMA_CH13CTL_M2M_Pos           DMA_CH13CTL_M2M_DPos
#define DMA_CH13CTL_M2M_Msk           (0x01UL << DMA_CH13CTL_M2M_Pos)                      /* 0x00000001 */
#define DMA_CH13CTL_M2M               DMA_CH13CTL_M2M_Msk                                  /* DMA channel 13 memory-to-memory transfer mode */

#define DMA_CH13CTL_DIR_DPos          (1U)
#define DMA_CH13CTL_DIR_Pos           DMA_CH13CTL_DIR_DPos
#define DMA_CH13CTL_DIR_Msk           (0x01UL << DMA_CH13CTL_DIR_Pos)                      /* 0x00000002 */
#define DMA_CH13CTL_DIR               DMA_CH13CTL_DIR_Msk                                  /* DMA channel 13 data transfer direction */

#define DMA_CH13CTL_CMEN_DPos         (2U)
#define DMA_CH13CTL_CIRC_Pos          DMA_CH13CTL_CMEN_DPos
#define DMA_CH13CTL_CIRC_Msk          (0x01UL << DMA_CH13CTL_CIRC_Pos)                     /* 0x00000004 */
#define DMA_CH13CTL_CIRC              DMA_CH13CTL_CIRC_Msk                                 /* DMA channel 13 circular mode */

#define DMA_CH13CTL_PNAGA_DPos        (3U)
#define DMA_CH13CTL_PINC_Pos          DMA_CH13CTL_PNAGA_DPos
#define DMA_CH13CTL_PINC_Msk          (0x01UL << DMA_CH13CTL_PINC_Pos)                     /* 0x00000008 */
#define DMA_CH13CTL_PINC              DMA_CH13CTL_PINC_Msk                                 /* DMA channel 13 peripheral address increment */

#define DMA_CH13CTL_MNAGA_DPos        (4U)
#define DMA_CH13CTL_MINC_Pos          DMA_CH13CTL_MNAGA_DPos
#define DMA_CH13CTL_MINC_Msk          (0x01UL << DMA_CH13CTL_MINC_Pos)                     /* 0x00000010 */
#define DMA_CH13CTL_MINC              DMA_CH13CTL_MINC_Msk                                 /* DMA channel 13 memory address increment */

#define DMA_CH13CTL_PWIDTH_DPos       (5U)
#define DMA_CH13CTL_PSIZE_Pos         DMA_CH13CTL_PWIDTH_DPos
#define DMA_CH13CTL_PSIZE_Msk         (0x03UL << DMA_CH13CTL_PSIZE_Pos)                    /* 0x00000060 */
#define DMA_CH13CTL_PSIZE             DMA_CH13CTL_PSIZE_Msk                                /* PWIDTH reg[1:0] bits( DMA channel 13 peripheral data width) */
#define DMA_CH13CTL_PSIZE_0           (0x01UL << DMA_CH13CTL_PSIZE_Pos)                    /* 0x00000020 */
#define DMA_CH13CTL_PSIZE_1           (0x02UL << DMA_CH13CTL_PSIZE_Pos)                    /* 0x00000040 */

#define DMA_CH13CTL_MWIDTH_DPos       (7U)
#define DMA_CH13CTL_MSIZE_Pos         DMA_CH13CTL_MWIDTH_DPos
#define DMA_CH13CTL_MSIZE_Msk         (0x03UL << DMA_CH13CTL_MSIZE_Pos)                    /* 0x00000180 */
#define DMA_CH13CTL_MSIZE             DMA_CH13CTL_MSIZE_Msk                                /* MWIDTH reg[1:0] bits( DMA channel 13 memory data width) */
#define DMA_CH13CTL_MSIZE_0           (0x01UL << DMA_CH13CTL_MSIZE_Pos)                    /* 0x00000080 */
#define DMA_CH13CTL_MSIZE_1           (0x02UL << DMA_CH13CTL_MSIZE_Pos)                    /* 0x00000100 */

#define DMA_CH13CTL_PRIO_DPos         (9U)
#define DMA_CH13CTL_PRIO_Pos          DMA_CH13CTL_PRIO_DPos
#define DMA_CH13CTL_PRIO_Msk          (0x03UL << DMA_CH13CTL_PRIO_Pos)                     /* 0x00000600 */
#define DMA_CH13CTL_PRIO              DMA_CH13CTL_PRIO_Msk                                 /* PRIO reg[1:0] bits(DMA channel 13 priority level) */
#define DMA_CH13CTL_PRIO_0            (0x01UL << DMA_CH13CTL_PRIO_Pos)                     /* 0x00000200 */
#define DMA_CH13CTL_PRIO_1            (0x02UL << DMA_CH13CTL_PRIO_Pos)                     /* 0x00000400 */

/******************  Bits definition for DMA_CH13CNT register  *****************/
#define DMA_CH13CNT_CNT_DPos          (0U)
#define DMA_CH13CNT_CNT_Pos           DMA_CH13CNT_CNT_DPos
#define DMA_CH13CNT_CNT_Msk           (0xFFFFUL << DMA_CH13CNT_CNT_Pos)                      /* 0x0000ffff */
#define DMA_CH13CNT_CNT               DMA_CH13CNT_CNT_Msk                                    /* DMA channel 13 number of data to transfer */

/******************  Bits definition for DMA_CH13PADDR register  *****************/
#define DMA_CH13PADDR_PADDR_DPos      (0U)
#define DMA_CH13PADDR_PADDR_Pos       DMA_CH13PADDR_PADDR_DPos
#define DMA_CH13PADDR_PADDR_Msk       (0xffffffffUL << DMA_CH13PADDR_PADDR_Pos)            /* 0xffffffff */
#define DMA_CH13PADDR_PADDR           DMA_CH13PADDR_PADDR_Msk                              /* DMA channel 13 peripheral address */

/******************  Bits definition for DMA_CH13MADDR register  *****************/
#define DMA_CH13MADDR_MADDR_DPos      (0U)
#define DMA_CH13MADDR_MADDR_Pos       DMA_CH13MADDR_MADDR_DPos
#define DMA_CH13MADDR_MADDR_Msk       (0xffffffffUL << DMA_CH13MADDR_MADDR_Pos)                    /* 0xffffffff */
#define DMA_CH13MADDR_MADDR           DMA_CH13MADDR_MADDR_Msk                                      /* DMA channel 13 memory address */



/******************  Bits definition for DMA_CH14CTL register  *****************/
#define DMA_CH14CTL_M2M_DPos          (0U)
#define DMA_CH14CTL_M2M_Pos           DMA_CH14CTL_M2M_DPos
#define DMA_CH14CTL_M2M_Msk           (0x01UL << DMA_CH14CTL_M2M_Pos)                      /* 0x00000001 */
#define DMA_CH14CTL_M2M               DMA_CH14CTL_M2M_Msk                                  /* DMA channel 14 memory-to-memory transfer mode */

#define DMA_CH14CTL_DIR_DPos          (1U)
#define DMA_CH14CTL_DIR_Pos           DMA_CH14CTL_DIR_DPos
#define DMA_CH14CTL_DIR_Msk           (0x01UL << DMA_CH14CTL_DIR_Pos)                      /* 0x00000002 */
#define DMA_CH14CTL_DIR               DMA_CH14CTL_DIR_Msk                                  /* DMA channel 14 data transfer direction */

#define DMA_CH14CTL_CMEN_DPos         (2U)
#define DMA_CH14CTL_CIRC_Pos          DMA_CH14CTL_CMEN_DPos
#define DMA_CH14CTL_CIRC_Msk          (0x01UL << DMA_CH14CTL_CIRC_Pos)                     /* 0x00000004 */
#define DMA_CH14CTL_CIRC              DMA_CH14CTL_CIRC_Msk                                 /* DMA channel 14 circular mode */

#define DMA_CH14CTL_PNAGA_DPos        (3U)
#define DMA_CH14CTL_PINC_Pos          DMA_CH14CTL_PNAGA_DPos
#define DMA_CH14CTL_PINC_Msk          (0x01UL << DMA_CH14CTL_PINC_Pos)                     /* 0x00000008 */
#define DMA_CH14CTL_PINC              DMA_CH14CTL_PINC_Msk                                 /* DMA channel 14 peripheral address increment */

#define DMA_CH14CTL_MNAGA_DPos        (4U)
#define DMA_CH14CTL_MINC_Pos          DMA_CH14CTL_MNAGA_DPos
#define DMA_CH14CTL_MINC_Msk          (0x01UL << DMA_CH14CTL_MINC_Pos)                     /* 0x00000010 */
#define DMA_CH14CTL_MINC              DMA_CH14CTL_MINC_Msk                                 /* DMA channel 14 memory address increment */

#define DMA_CH14CTL_PWIDTH_DPos       (5U)
#define DMA_CH14CTL_PSIZE_Pos         DMA_CH14CTL_PWIDTH_DPos
#define DMA_CH14CTL_PSIZE_Msk         (0x03UL << DMA_CH14CTL_PSIZE_Pos)                    /* 0x00000060 */
#define DMA_CH14CTL_PSIZE             DMA_CH14CTL_PSIZE_Msk                                /* PWIDTH reg[1:0] bits( DMA channel 14 peripheral data width) */
#define DMA_CH14CTL_PSIZE_0           (0x01UL << DMA_CH14CTL_PSIZE_Pos)                    /* 0x00000020 */
#define DMA_CH14CTL_PSIZE_1           (0x02UL << DMA_CH14CTL_PSIZE_Pos)                    /* 0x00000040 */

#define DMA_CH14CTL_MWIDTH_DPos       (7U)
#define DMA_CH14CTL_MSIZE_Pos         DMA_CH14CTL_MWIDTH_DPos
#define DMA_CH14CTL_MSIZE_Msk         (0x03UL << DMA_CH14CTL_MSIZE_Pos)                    /* 0x00000180 */
#define DMA_CH14CTL_MSIZE             DMA_CH14CTL_MSIZE_Msk                                /* MWIDTH reg[1:0] bits( DMA channel 14 memory data width) */
#define DMA_CH14CTL_MSIZE_0           (0x01UL << DMA_CH14CTL_MSIZE_Pos)                    /* 0x00000080 */
#define DMA_CH14CTL_MSIZE_1           (0x02UL << DMA_CH14CTL_MSIZE_Pos)                    /* 0x00000100 */

#define DMA_CH14CTL_PRIO_DPos         (9U)
#define DMA_CH14CTL_PRIO_Pos          DMA_CH14CTL_PRIO_DPos
#define DMA_CH14CTL_PRIO_Msk          (0x03UL << DMA_CH14CTL_PRIO_Pos)                     /* 0x00000600 */
#define DMA_CH14CTL_PRIO              DMA_CH14CTL_PRIO_Msk                                 /* PRIO reg[1:0] bits(DMA channel 14 priority level) */
#define DMA_CH14CTL_PRIO_0            (0x01UL << DMA_CH14CTL_PRIO_Pos)                     /* 0x00000200 */
#define DMA_CH14CTL_PRIO_1            (0x02UL << DMA_CH14CTL_PRIO_Pos)                     /* 0x00000400 */

/******************  Bits definition for DMA_CH14CNT register  *****************/
#define DMA_CH14CNT_CNT_DPos          (0U)
#define DMA_CH14CNT_CNT_Pos           DMA_CH14CNT_CNT_DPos
#define DMA_CH14CNT_CNT_Msk           (0xFFFFUL << DMA_CH14CNT_CNT_Pos)                      /* 0x0000ffff */
#define DMA_CH14CNT_CNT               DMA_CH14CNT_CNT_Msk                                    /* DMA channel 14 number of data to transfer */

/******************  Bits definition for DMA_CH14PADDR register  *****************/
#define DMA_CH14PADDR_PADDR_DPos      (0U)
#define DMA_CH14PADDR_PADDR_Pos       DMA_CH14PADDR_PADDR_DPos
#define DMA_CH14PADDR_PADDR_Msk       (0xffffffffUL << DMA_CH14PADDR_PADDR_Pos)            /* 0xffffffff */
#define DMA_CH14PADDR_PADDR           DMA_CH14PADDR_PADDR_Msk                              /* DMA channel 14 peripheral address */

/******************  Bits definition for DMA_CH14MADDR register  *****************/
#define DMA_CH14MADDR_MADDR_DPos      (0U)
#define DMA_CH14MADDR_MADDR_Pos       DMA_CH14MADDR_MADDR_DPos
#define DMA_CH14MADDR_MADDR_Msk       (0xffffffffUL << DMA_CH14MADDR_MADDR_Pos)                    /* 0xffffffff */
#define DMA_CH14MADDR_MADDR           DMA_CH14MADDR_MADDR_Msk                                      /* DMA channel 14 memory address */


/******************  Bits definition for DMA_CH15CTL register  *****************/
#define DMA_CH15CTL_M2M_DPos          (0U)
#define DMA_CH15CTL_M2M_Pos           DMA_CH15CTL_M2M_DPos
#define DMA_CH15CTL_M2M_Msk           (0x01UL << DMA_CH15CTL_M2M_Pos)                      /* 0x00000001 */
#define DMA_CH15CTL_M2M               DMA_CH15CTL_M2M_Msk                                  /* DMA channel 15 memory-to-memory transfer mode */

#define DMA_CH15CTL_DIR_DPos          (1U)
#define DMA_CH15CTL_DIR_Pos           DMA_CH15CTL_DIR_DPos
#define DMA_CH15CTL_DIR_Msk           (0x01UL << DMA_CH15CTL_DIR_Pos)                      /* 0x00000002 */
#define DMA_CH15CTL_DIR               DMA_CH15CTL_DIR_Msk                                  /* DMA channel 15 data transfer direction */

#define DMA_CH15CTL_CMEN_DPos         (2U)
#define DMA_CH15CTL_CIRC_Pos          DMA_CH15CTL_CMEN_DPos
#define DMA_CH15CTL_CIRC_Msk          (0x01UL << DMA_CH15CTL_CIRC_Pos)                     /* 0x00000004 */
#define DMA_CH15CTL_CIRC              DMA_CH15CTL_CIRC_Msk                                 /* DMA channel 15 circular mode */

#define DMA_CH15CTL_PNAGA_DPos        (3U)
#define DMA_CH15CTL_PINC_Pos          DMA_CH15CTL_PNAGA_DPos
#define DMA_CH15CTL_PINC_Msk          (0x01UL << DMA_CH15CTL_PINC_Pos)                     /* 0x00000008 */
#define DMA_CH15CTL_PINC              DMA_CH15CTL_PINC_Msk                                 /* DMA channel 15 peripheral address increment */

#define DMA_CH15CTL_MNAGA_DPos        (4U)
#define DMA_CH15CTL_MINC_Pos          DMA_CH15CTL_MNAGA_DPos
#define DMA_CH15CTL_MINC_Msk          (0x01UL << DMA_CH15CTL_MINC_Pos)                     /* 0x00000010 */
#define DMA_CH15CTL_MINC              DMA_CH15CTL_MINC_Msk                                 /* DMA channel 15 memory address increment */

#define DMA_CH15CTL_PWIDTH_DPos       (5U)
#define DMA_CH15CTL_PSIZE_Pos         DMA_CH15CTL_PWIDTH_DPos
#define DMA_CH15CTL_PSIZE_Msk         (0x03UL << DMA_CH15CTL_PSIZE_Pos)                    /* 0x00000060 */
#define DMA_CH15CTL_PSIZE             DMA_CH15CTL_PSIZE_Msk                                /* PWIDTH reg[1:0] bits( DMA channel 15 peripheral data width) */
#define DMA_CH15CTL_PSIZE_0           (0x01UL << DMA_CH15CTL_PSIZE_Pos)                    /* 0x00000020 */
#define DMA_CH15CTL_PSIZE_1           (0x02UL << DMA_CH15CTL_PSIZE_Pos)                    /* 0x00000040 */

#define DMA_CH15CTL_MWIDTH_DPos       (7U)
#define DMA_CH15CTL_MSIZE_Pos         DMA_CH15CTL_MWIDTH_DPos
#define DMA_CH15CTL_MSIZE_Msk         (0x03UL << DMA_CH15CTL_MSIZE_Pos)                    /* 0x00000180 */
#define DMA_CH15CTL_MSIZE             DMA_CH15CTL_MSIZE_Msk                                /* MWIDTH reg[1:0] bits( DMA channel 15 memory data width) */
#define DMA_CH15CTL_MSIZE_0           (0x01UL << DMA_CH15CTL_MSIZE_Pos)                    /* 0x00000080 */
#define DMA_CH15CTL_MSIZE_1           (0x02UL << DMA_CH15CTL_MSIZE_Pos)                    /* 0x00000100 */

#define DMA_CH15CTL_PRIO_DPos         (9U)
#define DMA_CH15CTL_PRIO_Pos          DMA_CH15CTL_PRIO_DPos
#define DMA_CH15CTL_PRIO_Msk          (0x03UL << DMA_CH15CTL_PRIO_Pos)                     /* 0x00000600 */
#define DMA_CH15CTL_PRIO              DMA_CH15CTL_PRIO_Msk                                 /*PRIO reg[1:0] bits(DMA channel 15 priority level) */
#define DMA_CH15CTL_PRIO_0            (0x01UL << DMA_CH15CTL_PRIO_Pos)                     /* 0x00000200 */
#define DMA_CH15CTL_PRIO_1            (0x02UL << DMA_CH15CTL_PRIO_Pos)                     /* 0x00000400 */

/******************  Bits definition for DMA_CH15CNT register  *****************/
#define DMA_CH15CNT_CNT_DPos          (0U)
#define DMA_CH15CNT_CNT_Pos           DMA_CH15CNT_CNT_DPos
#define DMA_CH15CNT_CNT_Msk           (0xFFFFUL << DMA_CH15CNT_CNT_Pos)                      /* 0x0000ffff */
#define DMA_CH15CNT_CNT               DMA_CH15CNT_CNT_Msk                                    /* DMA channel 15 number of data to transfer */

/******************  Bits definition for DMA_CH15PADDR register  *****************/
#define DMA_CH15PADDR_PADDR_DPos      (0U)
#define DMA_CH15PADDR_PADDR_Pos       DMA_CH15PADDR_PADDR_DPos
#define DMA_CH15PADDR_PADDR_Msk       (0xffffffffUL << DMA_CH15PADDR_PADDR_Pos)            /* 0xffffffff */
#define DMA_CH15PADDR_PADDR           DMA_CH15PADDR_PADDR_Msk                              /* DMA channel 15 peripheral address */

/******************  Bits definition for DMA_CH15MADDR register  *****************/
#define DMA_CH15MADDR_MADDR_DPos      (0U)
#define DMA_CH15MADDR_MADDR_Pos       DMA_CH15MADDR_MADDR_DPos
#define DMA_CH15MADDR_MADDR_Msk       (0xffffffffUL << DMA_CH15MADDR_MADDR_Pos)                    /* 0xffffffff */
#define DMA_CH15MADDR_MADDR           DMA_CH15MADDR_MADDR_Msk                                      /* DMA channel 15 memory address */

/******************  Bits definition for DMA_PTCH0 register  *****************/
#define DMA_PTCH0_CH0PT_DPos          (0U)
#define DMA_PTCH0_CH0PT_Pos           DMA_PTCH0_CH0PT_DPos
#define DMA_PTCH0_CH0PT_Msk           (0x0fUL <<DMA_PTCH0_CH0PT_Pos)                   /* 0x0000000f */
#define DMA_PTCH0_CH0PT               DMA_PTCH0_CH0PT_Msk                              /* DMA channel 0 peripheral interface */

#define DMA_PTCH0_CH1PT_DPos          (4U)
#define DMA_PTCH0_CH1PT_Pos           DMA_PTCH0_CH1PT_DPos
#define DMA_PTCH0_CH1PT_Msk           (0x0fUL <<DMA_PTCH0_CH1PT_Pos)                   /* 0x000000f0 */
#define DMA_PTCH0_CH1PT               DMA_PTCH0_CH1PT_Msk                              /* DMA channel 1 peripheral interface */

#define DMA_PTCH0_CH2PT_DPos          (8U)
#define DMA_PTCH0_CH2PT_Pos           DMA_PTCH0_CH2PT_DPos
#define DMA_PTCH0_CH2PT_Msk           (0x0fUL <<DMA_PTCH0_CH2PT_Pos)                   /* 0x00000f00 */
#define DMA_PTCH0_CH2PT               DMA_PTCH0_CH2PT_Msk                              /* DMA channel 2 peripheral interface */

#define DMA_PTCH0_CH3PT_DPos          (12U)
#define DMA_PTCH0_CH3PT_Pos           DMA_PTCH0_CH3PT_DPos
#define DMA_PTCH0_CH3PT_Msk           (0x0fUL <<DMA_PTCH0_CH3PT_Pos)                   /* 0x0000f000 */
#define DMA_PTCH0_CH3PT               DMA_PTCH0_CH3PT_Msk                              /* DMA channel 3 peripheral interface */

#define DMA_PTCH0_CH4PT_DPos          (16U)
#define DMA_PTCH0_CH4PT_Pos           DMA_PTCH0_CH4PT_DPos
#define DMA_PTCH0_CH4PT_Msk           (0x0fUL <<DMA_PTCH0_CH4PT_Pos)                   /* 0x000f0000 */
#define DMA_PTCH0_CH4PT               DMA_PTCH0_CH4PT_Msk                              /* DMA  channel 4 peripheral interface */

#define DMA_PTCH0_CH5PT_DPos          (20U)
#define DMA_PTCH0_CH5PT_Pos           DMA_PTCH0_CH5PT_DPos
#define DMA_PTCH0_CH5PT_Msk           (0x0fUL <<DMA_PTCH0_CH5PT_Pos)                   /* 0x00f00000 */
#define DMA_PTCH0_CH5PT               DMA_PTCH0_CH5PT_Msk                              /* DMA  channel 5 peripheral interface */

#define DMA_PTCH0_CH6PT_DPos          (24U)
#define DMA_PTCH0_CH6PT_Pos           DMA_PTCH0_CH6PT_DPos
#define DMA_PTCH0_CH6PT_Msk           (0x0fUL <<DMA_PTCH0_CH6PT_Pos)                   /* 0x0f000000 */
#define DMA_PTCH0_CH6PT               DMA_PTCH0_CH6PT_Msk                              /* DMA  channel 6 peripheral interface */

#define DMA_PTCH0_CH7PT_DPos          (28U)
#define DMA_PTCH0_CH7PT_Pos           DMA_PTCH0_CH7PT_DPos
#define DMA_PTCH0_CH7PT_Msk           (0x0fUL <<DMA_PTCH0_CH7PT_Pos)                   /* 0xf0000000 */
#define DMA_PTCH0_CH7PT               DMA_PTCH0_CH7PT_Msk                              /* DMA  channel 7 peripheral interface */

/******************  Bits definition for DMA_PTCH1 register  *****************/
#define DMA_PTCH1_CH8PT_DPos           (0U)
#define DMA_PTCH1_CH8PT_Pos            DMA_PTCH1_CH8PT_DPos
#define DMA_PTCH1_CH8PT_Msk            (0x0fUL <<DMA_PTCH1_CH8PT_Pos)                    /* 0x0000000f */
#define DMA_PTCH1_CH8PT                DMA_PTCH1_CH8PT_Msk                               /* DMA  channel 8 peripheral interface */

#define DMA_PTCH1_CH9PT_DPos           (4U)
#define DMA_PTCH1_CH9PT_Pos            DMA_PTCH1_CH9PT_DPos
#define DMA_PTCH1_CH9PT_Msk            (0x0fUL <<DMA_PTCH1_CH9PT_Pos)                    /* 0x000000f0 */
#define DMA_PTCH1_CH9PT                DMA_PTCH1_CH9PT_Msk                               /* DMA  channel 9 peripheral interface */

#define DMA_PTCH1_CH10PT_DPos          (8U)
#define DMA_PTCH1_CH10PT_Pos           DMA_PTCH1_CH10PT_DPos
#define DMA_PTCH1_CH10PT_Msk           (0x0fUL <<DMA_PTCH1_CH10PT_Pos)                   /* 0x00000f00 */
#define DMA_PTCH1_CH10PT               DMA_PTCH1_CH10PT_Msk                              /* DMA  channel 10 peripheral interface */

#define DMA_PTCH1_CH11PT_DPos          (12U)
#define DMA_PTCH1_CH11PT_Pos           DMA_PTCH1_CH11PT_DPos
#define DMA_PTCH1_CH11PT_Msk           (0x0fUL <<DMA_PTCH1_CH11PT_Pos)                   /* 0x0000f000 */
#define DMA_PTCH1_CH11PT               DMA_PTCH1_CH11PT_Msk                              /* DMA  channel 11 peripheral interface */

#define DMA_PTCH1_CH7PT_DPos           (16U)
#define DMA_PTCH1_CH7PT_Pos            DMA_PTCH1_CH7PT_DPos
#define DMA_PTCH1_CH7PT_Msk            (0x0fUL <<DMA_PTCH1_CH7PT_Pos)                    /* 0x000f0000 */
#define DMA_PTCH1_CH7PT                DMA_PTCH1_CH7PT_Msk                               /* DMA  channel 7 peripheral interface */

#define DMA_PTCH1_CH13PT_DPos          (20U)
#define DMA_PTCH1_CH13PT_Pos           DMA_PTCH1_CH13PT_DPos
#define DMA_PTCH1_CH13PT_Msk           (0x0fUL <<DMA_PTCH1_CH13PT_Pos)                   /* 0x00f00000 */
#define DMA_PTCH1_CH13PT               DMA_PTCH1_CH13PT_Msk                              /* DMA  channel 13 peripheral interface */


#define DMA_PTCH1_CH14PT_DPos          (24U)
#define DMA_PTCH1_CH14PT_Pos           DMA_PTCH1_CH14PT_DPos
#define DMA_PTCH1_CH14PT_Msk           (0x0fUL <<DMA_PTCH1_CH14PT_Pos)                   /* 0x0f000000 */
#define DMA_PTCH1_CH14PT               DMA_PTCH1_CH14PT_Msk                              /* DMA  channel 14 peripheral interface */


#define DMA_PTCH1_CH15PT_DPos          (28U)
#define DMA_PTCH1_CH15PT_Pos           DMA_PTCH1_CH15PT_DPos
#define DMA_PTCH1_CH15PT_Msk           (0x0fUL <<DMA_PTCH1_CH15PT_Pos)                   /* 0xf0000000 */
#define DMA_PTCH1_CH15PT               DMA_PTCH1_CH15PT_Msk                              /* DMA  channel 15 peripheral interface */

/******************  Bits definition for DMA_CCR register  *****************/

#define DMA_CCR_DEN_DPos                  (0U)
#define DMA_CCR_DEN_Pos                   DMA_CCR_DEN_DPos
#define DMA_CCR_DEN_Msk                   (0x01UL <<DMA_CCR_DEN_Pos)                            /* 0x00000001 */
#define DMA_CCR_DEN                       DMA_CCR_DEN_Msk                                       /* Dual-core lock step enabled */

#define DMA_CCR_DRDY_DPos                 (1U)
#define DMA_CCR_DRDY_Pos                  DMA_CCR_DRDY_DPos
#define DMA_CCR_DRDY_Msk                  (0x01UL <<DMA_CCR_DRDY_Pos)                           /* 0x00000002 */
#define DMA_CCR_DRDY                      DMA_CCR_DRDY_Msk                                      /* Dual-core lock step ready status*/

#define DMA_CCR_DERR_DPos                 (2U)
#define DMA_CCR_DERR_Pos                  DMA_CCR_DERR_DPos
#define DMA_CCR_DERR_Msk                  (0x01UL <<DMA_CCR_DERR_Pos)                           /* 0x00000004 */
#define DMA_CCR_DERR                      DMA_CCR_DERR_Msk                                      /* Dual-core lock step error status*/

#define DMA_CCR_WDEN_DPos                 (3U)
#define DMA_CCR_WDEN_Pos                  DMA_CCR_WDEN_DPos
#define DMA_CCR_WDEN_Msk                  (0x01UL <<DMA_CCR_WDEN_Pos)                           /* 0x00000008 */
#define DMA_CCR_WDEN                      DMA_CCR_WDEN_Msk                                      /* Watch dog enable*/

#define DMA_CCR_WDCNT_DPos                (4U)
#define DMA_CCR_WDCNT_Pos                 DMA_CCR_WDCNT_DPos
#define DMA_CCR_WDCNT_Msk                 (0xffffUL <<DMA_CCR_WDCNT_Pos)                        /* 0x000FFFF0 */
#define DMA_CCR_WDCNT                     DMA_CCR_WDCNT_Msk                                     /* Watchdog threshold*/


/******************  Bits definition for DMA_ERR_INT_RAW register  *****************/
#define DMA_ERR_INT_RAW_ERR_RAW0_DPos   (0U)
#define DMA_ERR_INT_RAW_RAW0_Pos        DMA_ERR_INT_RAW_ERR_RAW0_DPos
#define DMA_ERR_INT_RAW_RAW0_Msk        (0x01UL <<DMA_ERR_INT_RAW_RAW0_Pos)                    /* 0x00000001 */
#define DMA_ERR_INT_RAW_RAW0            DMA_ERR_INT_RAW_RAW0_Msk                               /* DMA channel 0 error interrupt raw status */

#define DMA_ERR_INT_RAW_ERR_RAW1_DPos   (1U)
#define DMA_ERR_INT_RAW_RAW1_Pos        DMA_ERR_INT_RAW_ERR_RAW1_DPos
#define DMA_ERR_INT_RAW_RAW1_Msk        (0x01UL <<DMA_ERR_INT_RAW_RAW1_Pos)                    /* 0x00000002 */
#define DMA_ERR_INT_RAW_RAW1            DMA_ERR_INT_RAW_RAW1_Msk                               /* DMA channel 1 error interrupt raw status */

#define DMA_ERR_INT_RAW_ERR_RAW2_DPos   (2U)
#define DMA_ERR_INT_RAW_RAW2_Pos        DMA_ERR_INT_RAW_ERR_RAW2_DPos
#define DMA_ERR_INT_RAW_RAW2_Msk        (0x01UL <<DMA_ERR_INT_RAW_RAW2_Pos)                    /* 0x00000004 */
#define DMA_ERR_INT_RAW_RAW2            DMA_ERR_INT_RAW_RAW2_Msk                               /* DMA channel 2 error interrupt raw status */

#define DMA_ERR_INT_RAW_ERR_RAW3_DPos   (3U)
#define DMA_ERR_INT_RAW_RAW3_Pos        DMA_ERR_INT_RAW_ERR_RAW3_DPos
#define DMA_ERR_INT_RAW_RAW3_Msk        (0x01UL <<DMA_ERR_INT_RAW_RAW3_Pos)                    /* 0x00000008 */
#define DMA_ERR_INT_RAW_RAW3            DMA_ERR_INT_RAW_RAW3_Msk                               /* DMA channel 3 error interrupt raw status */

#define DMA_ERR_INT_RAW_ERR_RAW4_DPos   (4U)
#define DMA_ERR_INT_RAW_RAW4_Pos        DMA_ERR_INT_RAW_ERR_RAW4_DPos
#define DMA_ERR_INT_RAW_RAW4_Msk        (0x01UL <<DMA_ERR_INT_RAW_RAW4_Pos)                    /* 0x00000010 */
#define DMA_ERR_INT_RAW_RAW4            DMA_ERR_INT_RAW_RAW4_Msk                               /* DMA channel 4 error interrupt raw status */

#define DMA_ERR_INT_RAW_ERR_RAW5_DPos   (5U)
#define DMA_ERR_INT_RAW_RAW5_Pos        DMA_ERR_INT_RAW_ERR_RAW5_DPos
#define DMA_ERR_INT_RAW_RAW5_Msk        (0x01UL <<DMA_ERR_INT_RAW_RAW5_Pos)                    /* 0x00000020 */
#define DMA_ERR_INT_RAW_RAW5            DMA_ERR_INT_RAW_RAW5_Msk                               /* DMA channel 5 error interrupt raw status */

#define DMA_ERR_INT_RAW_ERR_RAW6_DPos   (6U)
#define DMA_ERR_INT_RAW_RAW6_Pos        DMA_ERR_INT_RAW_ERR_RAW6_DPos
#define DMA_ERR_INT_RAW_RAW6_Msk        (0x01UL <<DMA_ERR_INT_RAW_RAW6_Pos)                    /* 0x00000040 */
#define DMA_ERR_INT_RAW_RAW6            DMA_ERR_INT_RAW_RAW6_Msk                               /* DMA channel 6 error interrupt raw status */

#define DMA_ERR_INT_RAW_ERR_RAW7_DPos   (7U)
#define DMA_ERR_INT_RAW_RAW7_Pos        DMA_ERR_INT_RAW_ERR_RAW7_DPos
#define DMA_ERR_INT_RAW_RAW7_Msk        (0x01UL <<DMA_ERR_INT_RAW_RAW7_Pos)                    /* 0x00000080 */
#define DMA_ERR_INT_RAW_RAW7            DMA_ERR_INT_RAW_RAW7_Msk                               /* DMA channel 7 error interrupt raw status */

#define DMA_ERR_INT_RAW_ERR_RAW8_DPos   (8U)
#define DMA_ERR_INT_RAW_RAW8_Pos        DMA_ERR_INT_RAW_ERR_RAW8_DPos
#define DMA_ERR_INT_RAW_RAW8_Msk        (0x01UL <<DMA_ERR_INT_RAW_RAW8_Pos)                    /* 0x00000100 */
#define DMA_ERR_INT_RAW_RAW8            DMA_ERR_INT_RAW_RAW8_Msk                               /* DMA channel 8 error interrupt raw status */

#define DMA_ERR_INT_RAW_ERR_RAW9_DPos   (9U)
#define DMA_ERR_INT_RAW_RAW9_Pos        DMA_ERR_INT_RAW_ERR_RAW9_DPos
#define DMA_ERR_INT_RAW_RAW9_Msk        (0x01UL <<DMA_ERR_INT_RAW_RAW9_Pos)                    /* 0x00000200 */
#define DMA_ERR_INT_RAW_RAW9            DMA_ERR_INT_RAW_RAW9_Msk                               /* DMA channel 9 error interrupt raw status */

#define DMA_ERR_INT_RAW_ERR_RAW10_DPos  (10U)
#define DMA_ERR_INT_RAW_RAW10_Pos       DMA_ERR_INT_RAW_ERR_RAW10_DPos
#define DMA_ERR_INT_RAW_RAW10_Msk       (0x01UL <<DMA_ERR_INT_RAW_RAW10_Pos)                   /* 0x00000400 */
#define DMA_ERR_INT_RAW_RAW10           DMA_ERR_INT_RAW_RAW10_Msk                              /* DMA channel 10 error interrupt raw status */

#define DMA_ERR_INT_RAW_ERR_RAW11_DPos  (11U)
#define DMA_ERR_INT_RAW_RAW11_Pos       DMA_ERR_INT_RAW_ERR_RAW11_DPos
#define DMA_ERR_INT_RAW_RAW11_Msk       (0x01UL <<DMA_ERR_INT_RAW_RAW11_Pos)                   /* 0x00000800 */
#define DMA_ERR_INT_RAW_RAW11           DMA_ERR_INT_RAW_RAW11_Msk                              /* DMA channel 11 error interrupt raw status */

#define DMA_ERR_INT_RAW_ERR_RAW12_DPos  (12U)
#define DMA_ERR_INT_RAW_RAW12_Pos       DMA_ERR_INT_RAW_ERR_RAW12_DPos
#define DMA_ERR_INT_RAW_RAW12_Msk       (0x01UL <<DMA_ERR_INT_RAW_RAW12_Pos)                   /* 0x00001000 */
#define DMA_ERR_INT_RAW_RAW12           DMA_ERR_INT_RAW_RAW12_Msk                              /* DMA channel 12 error interrupt raw status */

#define DMA_ERR_INT_RAW_ERR_RAW13_DPos  (13U)
#define DMA_ERR_INT_RAW_RAW13_Pos       DMA_ERR_INT_RAW_ERR_RAW13_DPos
#define DMA_ERR_INT_RAW_RAW13_Msk       (0x01UL <<DMA_ERR_INT_RAW_RAW13_Pos)                   /* 0x00002000 */
#define DMA_ERR_INT_RAW_RAW13           DMA_ERR_INT_RAW_RAW13_Msk                              /* DMA channel 13 error interrupt raw status */

#define DMA_ERR_INT_RAW_ERR_RAW14_DPos  (14U)
#define DMA_ERR_INT_RAW_RAW14_Pos       DMA_ERR_INT_RAW_ERR_RAW14_DPos
#define DMA_ERR_INT_RAW_RAW14_Msk       (0x01UL <<DMA_ERR_INT_RAW_RAW14_Pos)                   /* 0x00004000 */
#define DMA_ERR_INT_RAW_RAW14           DMA_ERR_INT_RAW_RAW14_Msk                              /* DMA channel 14 error interrupt raw status */

#define DMA_ERR_INT_RAW_ERR_RAW15_DPos  (15U)
#define DMA_ERR_INT_RAW_RAW15_Pos       DMA_ERR_INT_RAW_ERR_RAW15_DPos
#define DMA_ERR_INT_RAW_RAW15_Msk       (0x01UL <<DMA_ERR_INT_RAW_RAW15_Pos)                   /* 0x00008000 */
#define DMA_ERR_INT_RAW_RAW15           DMA_ERR_INT_RAW_RAW15_Msk                              /* DMA channel 15 error interrupt raw status */


/******************  Bits definition for DMA_ERR_INT_FORCE register  *****************/
#define DMA_ERR_INT_FORCE_FORCE0_DPos   (0U)
#define DMA_ERR_INT_FORCE_FORCE0_Pos    DMA_ERR_INT_FORCE_FORCE0_DPos
#define DMA_ERR_INT_FORCE_FORCE0_Msk    (0x01UL <<DMA_ERR_INT_FORCE_FORCE0_Pos)                    /* 0x00000001 */
#define DMA_ERR_INT_FORCE_FORCE0        DMA_ERR_INT_FORCE_FORCE0_Msk                               /* DMA channel 0 error interrupt force */

#define DMA_ERR_INT_FORCE_FORCE1_DPos   (1U)
#define DMA_ERR_INT_FORCE_FORCE1_Pos    DMA_ERR_INT_FORCE_FORCE1_DPos
#define DMA_ERR_INT_FORCE_FORCE1_Msk    (0x01UL <<DMA_ERR_INT_FORCE_FORCE1_Pos)                    /* 0x00000002 */
#define DMA_ERR_INT_FORCE_FORCE1        DMA_ERR_INT_FORCE_FORCE1_Msk                               /* DMA channel 1 error interrupt force */

#define DMA_ERR_INT_FORCE_FORCE2_DPos   (2U)
#define DMA_ERR_INT_FORCE_FORCE2_Pos    DMA_ERR_INT_FORCE_FORCE2_DPos
#define DMA_ERR_INT_FORCE_FORCE2_Msk    (0x01UL <<DMA_ERR_INT_FORCE_FORCE2_Pos)                    /* 0x00000004 */
#define DMA_ERR_INT_FORCE_FORCE2        DMA_ERR_INT_FORCE_FORCE2_Msk                               /* DMA channel 2 error interrupt force */

#define DMA_ERR_INT_FORCE_FORCE6_DPos   (6U)
#define DMA_ERR_INT_FORCE_FORCE6_Pos    DMA_ERR_INT_FORCE_FORCE6_DPos
#define DMA_ERR_INT_FORCE_FORCE6_Msk    (0x01UL <<DMA_ERR_INT_FORCE_FORCE6_Pos)                    /* 0x00000040 */
#define DMA_ERR_INT_FORCE_FORCE6        DMA_ERR_INT_FORCE_FORCE6_Msk                               /* DMA channel 6 error interrupt force */

#define DMA_ERR_INT_FORCE_FORCE4_DPos   (4U)
#define DMA_ERR_INT_FORCE_FORCE4_Pos    DMA_ERR_INT_FORCE_FORCE4_DPos
#define DMA_ERR_INT_FORCE_FORCE4_Msk    (0x01UL <<DMA_ERR_INT_FORCE_FORCE4_Pos)                    /* 0x00000010 */
#define DMA_ERR_INT_FORCE_FORCE4        DMA_ERR_INT_FORCE_FORCE4_Msk                               /* DMA channel 4 error interrupt force */

#define DMA_ERR_INT_FORCE_FORCE5_DPos   (5U)
#define DMA_ERR_INT_FORCE_FORCE5_Pos    DMA_ERR_INT_FORCE_FORCE5_DPos
#define DMA_ERR_INT_FORCE_FORCE5_Msk    (0x01UL <<DMA_ERR_INT_FORCE_FORCE5_Pos)                    /* 0x00000020 */
#define DMA_ERR_INT_FORCE_FORCE5        DMA_ERR_INT_FORCE_FORCE5_Msk                               /* DMA channel 5 error interrupt force */


#define DMA_ERR_INT_FORCE_FORCE7_DPos   (7U)
#define DMA_ERR_INT_FORCE_FORCE7_Pos    DMA_ERR_INT_FORCE_FORCE7_DPos
#define DMA_ERR_INT_FORCE_FORCE7_Msk    (0x01UL <<DMA_ERR_INT_FORCE_FORCE7_Pos)                    /* 0x00000080 */
#define DMA_ERR_INT_FORCE_FORCE7        DMA_ERR_INT_FORCE_FORCE7_Msk                               /* DMA channel 7 error interrupt force */

#define DMA_ERR_INT_FORCE_FORCE8_DPos   (8U)
#define DMA_ERR_INT_FORCE_FORCE8_Pos    DMA_ERR_INT_FORCE_FORCE8_DPos
#define DMA_ERR_INT_FORCE_FORCE8_Msk    (0x01UL <<DMA_ERR_INT_FORCE_FORCE8_Pos)                    /* 0x00000100 */
#define DMA_ERR_INT_FORCE_FORCE8        DMA_ERR_INT_FORCE_FORCE8_Msk                               /* DMA channel 8 error interrupt force */

#define DMA_ERR_INT_FORCE_FORCE9_DPos   (9U)
#define DMA_ERR_INT_FORCE_FORCE9_Pos    DMA_ERR_INT_FORCE_FORCE9_DPos
#define DMA_ERR_INT_FORCE_FORCE9_Msk    (0x01UL <<DMA_ERR_INT_FORCE_FORCE9_Pos)                    /* 0x00000200 */
#define DMA_ERR_INT_FORCE_FORCE9        DMA_ERR_INT_FORCE_FORCE9_Msk                               /* DMA channel 9 error interrupt force */

#define DMA_ERR_INT_FORCE_FORCE10_DPos  (10U)
#define DMA_ERR_INT_FORCE_FORCE10_Pos   DMA_ERR_INT_FORCE_FORCE10_DPos
#define DMA_ERR_INT_FORCE_FORCE10_Msk   (0x01UL <<DMA_ERR_INT_FORCE_FORCE10_Pos)                   /* 0x00000400 */
#define DMA_ERR_INT_FORCE_FORCE10       DMA_ERR_INT_FORCE_FORCE10_Msk                              /* DMA channel 10 error interrupt force */

#define DMA_ERR_INT_FORCE_FORCE11_DPos  (11U)
#define DMA_ERR_INT_FORCE_FORCE11_Pos   DMA_ERR_INT_FORCE_FORCE11_DPos
#define DMA_ERR_INT_FORCE_FORCE11_Msk   (0x01UL <<DMA_ERR_INT_FORCE_FORCE11_Pos)                   /* 0x00000800 */
#define DMA_ERR_INT_FORCE_FORCE11       DMA_ERR_INT_FORCE_FORCE11_Msk                              /* DMA channel 11 error interrupt force */

#define DMA_ERR_INT_FORCE_FORCE12_DPos  (12U)
#define DMA_ERR_INT_FORCE_FORCE12_Pos   DMA_ERR_INT_FORCE_FORCE12_DPos
#define DMA_ERR_INT_FORCE_FORCE12_Msk   (0x01UL <<DMA_ERR_INT_FORCE_FORCE12_Pos)                   /* 0x00001000 */
#define DMA_ERR_INT_FORCE_FORCE12       DMA_ERR_INT_FORCE_FORCE12_Msk                              /* DMA channel 12 error interrupt force */

#define DMA_ERR_INT_FORCE_FORCE13_DPos  (13U)
#define DMA_ERR_INT_FORCE_FORCE13_Pos   DMA_ERR_INT_FORCE_FORCE13_DPos
#define DMA_ERR_INT_FORCE_FORCE13_Msk   (0x01UL <<DMA_ERR_INT_FORCE_FORCE13_Pos)                   /* 0x00002000 */
#define DMA_ERR_INT_FORCE_FORCE13       DMA_ERR_INT_FORCE_FORCE13_Msk                              /* DMA channel 13 error interrupt force */

#define DMA_ERR_INT_FORCE_FORCE14_DPos  (14U)
#define DMA_ERR_INT_FORCE_FORCE14_Pos   DMA_ERR_INT_FORCE_FORCE14_DPos
#define DMA_ERR_INT_FORCE_FORCE14_Msk   (0x01UL <<DMA_ERR_INT_FORCE_FORCE14_Pos)                   /* 0x00004000 */
#define DMA_ERR_INT_FORCE_FORCE14       DMA_ERR_INT_FORCE_FORCE14_Msk                              /* DMA channel 14 error interrupt force */

#define DMA_ERR_INT_FORCE_FORCE15_DPos  (15U)
#define DMA_ERR_INT_FORCE_FORCE15_Pos   DMA_ERR_INT_FORCE_FORCE15_DPos
#define DMA_ERR_INT_FORCE_FORCE15_Msk   (0x01UL <<DMA_ERR_INT_FORCE_FORCE15_Pos)                   /* 0x00008000 */
#define DMA_ERR_INT_FORCE_FORCE15       DMA_ERR_INT_FORCE_FORCE15_Msk                              /* DMA channel 15 error interrupt force */

/******************  Bits definition for DMA_ERR_INT_MASK register  *****************/
#define DMA_ERR_INT_MASK_MASK0_DPos   (0U)
#define DMA_ERR_INT_MASK_MASK0_Pos    DMA_ERR_INT_MASK_MASK0_DPos
#define DMA_ERR_INT_MASK_MASK0_Msk    (0x01UL <<DMA_ERR_INT_MASK_MASK0_Pos)                    /* 0x00000001 */
#define DMA_ERR_INT_MASK_MASK0        DMA_ERR_INT_MASK_MASK0_Msk                               /* DMA channel 0 error interrupt mask */

#define DMA_ERR_INT_MASK_MASK1_DPos   (1U)
#define DMA_ERR_INT_MASK_MASK1_Pos    DMA_ERR_INT_MASK_MASK1_DPos
#define DMA_ERR_INT_MASK_MASK1_Msk    (0x01UL <<DMA_ERR_INT_MASK_MASK1_Pos)                    /* 0x00000002 */
#define DMA_ERR_INT_MASK_MASK1        DMA_ERR_INT_MASK_MASK1_Msk                               /* DMA channel 1 error interrupt mask */

#define DMA_ERR_INT_MASK_MASK2_DPos   (2U)
#define DMA_ERR_INT_MASK_MASK2_Pos    DMA_ERR_INT_MASK_MASK2_DPos
#define DMA_ERR_INT_MASK_MASK2_Msk    (0x01UL <<DMA_ERR_INT_MASK_MASK2_Pos)                    /* 0x00000004 */
#define DMA_ERR_INT_MASK_MASK2        DMA_ERR_INT_MASK_MASK2_Msk                               /* DMA channel 2 error interrupt mask */

#define DMA_ERR_INT_MASK_MASK6_DPos   (6U)
#define DMA_ERR_INT_MASK_MASK6_Pos    DMA_ERR_INT_MASK_MASK6_DPos
#define DMA_ERR_INT_MASK_MASK6_Msk    (0x01UL <<DMA_ERR_INT_MASK_MASK6_Pos)                    /* 0x00000040 */
#define DMA_ERR_INT_MASK_MASK6        DMA_ERR_INT_MASK_MASK6_Msk                               /* DMA channel 6 error interrupt mask */

#define DMA_ERR_INT_MASK_MASK4_DPos   (4U)
#define DMA_ERR_INT_MASK_MASK4_Pos    DMA_ERR_INT_MASK_MASK4_DPos
#define DMA_ERR_INT_MASK_MASK4_Msk    (0x01UL <<DMA_ERR_INT_MASK_MASK4_Pos)                    /* 0x00000010 */
#define DMA_ERR_INT_MASK_MASK4        DMA_ERR_INT_MASK_MASK4_Msk                               /* DMA channel 4 error interrupt mask */

#define DMA_ERR_INT_MASK_MASK5_DPos   (5U)
#define DMA_ERR_INT_MASK_MASK5_Pos    DMA_ERR_INT_MASK_MASK5_DPos
#define DMA_ERR_INT_MASK_MASK5_Msk    (0x01UL <<DMA_ERR_INT_MASK_MASK5_Pos)                    /* 0x00000020 */
#define DMA_ERR_INT_MASK_MASK5        DMA_ERR_INT_MASK_MASK5_Msk                               /* DMA channel 5 error interrupt mask */


#define DMA_ERR_INT_MASK_MASK7_DPos   (7U)
#define DMA_ERR_INT_MASK_MASK7_Pos    DMA_ERR_INT_MASK_MASK7_DPos
#define DMA_ERR_INT_MASK_MASK7_Msk    (0x01UL <<DMA_ERR_INT_MASK_MASK7_Pos)                    /* 0x00000080 */
#define DMA_ERR_INT_MASK_MASK7        DMA_ERR_INT_MASK_MASK7_Msk                               /* DMA channel 7 error interrupt mask */

#define DMA_ERR_INT_MASK_MASK8_DPos   (8U)
#define DMA_ERR_INT_MASK_MASK8_Pos    DMA_ERR_INT_MASK_MASK8_DPos
#define DMA_ERR_INT_MASK_MASK8_Msk    (0x01UL <<DMA_ERR_INT_MASK_MASK8_Pos)                    /* 0x00000100 */
#define DMA_ERR_INT_MASK_MASK8        DMA_ERR_INT_MASK_MASK8_Msk                               /* DMA channel 8 error interrupt mask */

#define DMA_ERR_INT_MASK_MASK9_DPos   (9U)
#define DMA_ERR_INT_MASK_MASK9_Pos    DMA_ERR_INT_MASK_MASK9_DPos
#define DMA_ERR_INT_MASK_MASK9_Msk    (0x01UL <<DMA_ERR_INT_MASK_MASK9_Pos)                    /* 0x00000200 */
#define DMA_ERR_INT_MASK_MASK9        DMA_ERR_INT_MASK_MASK9_Msk                               /* DMA channel 9 error interrupt mask */

#define DMA_ERR_INT_MASK_MASK10_DPos  (10U)
#define DMA_ERR_INT_MASK_MASK10_Pos   DMA_ERR_INT_MASK_MASK10_DPos
#define DMA_ERR_INT_MASK_MASK10_Msk   (0x01UL <<DMA_ERR_INT_MASK_MASK10_Pos)                   /* 0x00000400 */
#define DMA_ERR_INT_MASK_MASK10       DMA_ERR_INT_MASK_MASK10_Msk                              /* DMA channel 10 error interrupt mask */

#define DMA_ERR_INT_MASK_MASK11_DPos  (11U)
#define DMA_ERR_INT_MASK_MASK11_Pos   DMA_ERR_INT_MASK_MASK11_DPos
#define DMA_ERR_INT_MASK_MASK11_Msk   (0x01UL <<DMA_ERR_INT_MASK_MASK11_Pos)                   /* 0x00000800 */
#define DMA_ERR_INT_MASK_MASK11       DMA_ERR_INT_MASK_MASK11_Msk                              /* DMA channel 11 error interrupt mask */

#define DMA_ERR_INT_MASK_MASK12_DPos  (12U)
#define DMA_ERR_INT_MASK_MASK12_Pos   DMA_ERR_INT_MASK_MASK12_DPos
#define DMA_ERR_INT_MASK_MASK12_Msk   (0x01UL <<DMA_ERR_INT_MASK_MASK12_Pos)                   /* 0x00001000 */
#define DMA_ERR_INT_MASK_MASK12       DMA_ERR_INT_MASK_MASK12_Msk                              /* DMA channel 12 error interrupt mask */

#define DMA_ERR_INT_MASK_MASK13_DPos  (13U)
#define DMA_ERR_INT_MASK_MASK13_Pos   DMA_ERR_INT_MASK_MASK13_DPos
#define DMA_ERR_INT_MASK_MASK13_Msk   (0x01UL <<DMA_ERR_INT_MASK_MASK13_Pos)                   /* 0x00002000 */
#define DMA_ERR_INT_MASK_MASK13       DMA_ERR_INT_MASK_MASK13_Msk                              /* DMA channel 13 error interrupt mask */

#define DMA_ERR_INT_MASK_MASK14_DPos  (14U)
#define DMA_ERR_INT_MASK_MASK14_Pos   DMA_ERR_INT_MASK_MASK14_DPos
#define DMA_ERR_INT_MASK_MASK14_Msk   (0x01UL <<DMA_ERR_INT_MASK_MASK14_Pos)                   /* 0x00004000 */
#define DMA_ERR_INT_MASK_MASK14       DMA_ERR_INT_MASK_MASK14_Msk                              /* DMA channel 14 error interrupt mask */

#define DMA_ERR_INT_MASK_MASK15_DPos  (15U)
#define DMA_ERR_INT_MASK_MASK15_Pos   DMA_ERR_INT_MASK_MASK15_DPos
#define DMA_ERR_INT_MASK_MASK15_Msk   (0x01UL <<DMA_ERR_INT_MASK_MASK15_Pos)                   /* 0x00008000 */
#define DMA_ERR_INT_MASK_MASK15       DMA_ERR_INT_MASK_MASK15_Msk                              /* DMA channel 15 error interrupt mask */

/******************  Bits definition for DMA_ERR_INT_STATUS register  *****************/
#define DMA_ERR_INT_STATUS_STATUS0_DPos   (0U)
#define DMA_ERR_INT_STATUS_STAT0_Pos      DMA_ERR_INT_STATUS_STATUS0_DPos
#define DMA_ERR_INT_STATUS_STAT0_Msk      (0x01UL <<DMA_ERR_INT_STATUS_STAT0_Pos)                    /* 0x00000001 */
#define DMA_ERR_INT_STATUS_STAT0          DMA_ERR_INT_STATUS_STAT0_Msk                               /* DMA channel 0 error interrupt status */

#define DMA_ERR_INT_STATUS_STATUS1_DPos   (1U)
#define DMA_ERR_INT_STATUS_STAT1_Pos      DMA_ERR_INT_STATUS_STATUS1_DPos
#define DMA_ERR_INT_STATUS_STAT1_Msk      (0x01UL <<DMA_ERR_INT_STATUS_STAT1_Pos)                    /* 0x00000002 */
#define DMA_ERR_INT_STATUS_STAT1          DMA_ERR_INT_STATUS_STAT1_Msk                               /* DMA channel 1 error interrupt status */

#define DMA_ERR_INT_STATUS_STATUS2_DPos   (2U)
#define DMA_ERR_INT_STATUS_STAT2_Pos      DMA_ERR_INT_STATUS_STATUS2_DPos
#define DMA_ERR_INT_STATUS_STAT2_Msk      (0x01UL <<DMA_ERR_INT_STATUS_STAT2_Pos)                    /* 0x00000004 */
#define DMA_ERR_INT_STATUS_STAT2          DMA_ERR_INT_STATUS_STAT2_Msk                               /* DMA channel 2 error interrupt status */

#define DMA_ERR_INT_STATUS_STATUS6_DPos   (6U)
#define DMA_ERR_INT_STATUS_STAT6_Pos      DMA_ERR_INT_STATUS_STATUS6_DPos
#define DMA_ERR_INT_STATUS_STAT6_Msk      (0x01UL <<DMA_ERR_INT_STATUS_STAT6_Pos)                    /* 0x00000040 */
#define DMA_ERR_INT_STATUS_STAT6          DMA_ERR_INT_STATUS_STAT6_Msk                               /* DMA channel 6 error interrupt status */

#define DMA_ERR_INT_STATUS_STATUS4_DPos   (4U)
#define DMA_ERR_INT_STATUS_STAT4_Pos      DMA_ERR_INT_STATUS_STATUS4_DPos
#define DMA_ERR_INT_STATUS_STAT4_Msk      (0x01UL <<DMA_ERR_INT_STATUS_STAT4_Pos)                    /* 0x00000010 */
#define DMA_ERR_INT_STATUS_STAT4          DMA_ERR_INT_STATUS_STAT4_Msk                               /* DMA channel 4 error interrupt status */

#define DMA_ERR_INT_STATUS_STATUS5_DPos   (5U)
#define DMA_ERR_INT_STATUS_STAT5_Pos      DMA_ERR_INT_STATUS_STATUS5_DPos
#define DMA_ERR_INT_STATUS_STAT5_Msk      (0x01UL <<DMA_ERR_INT_STATUS_STAT5_Pos)                    /* 0x00000020 */
#define DMA_ERR_INT_STATUS_STAT5          DMA_ERR_INT_STATUS_STAT5_Msk                               /* DMA channel 5 error interrupt status */


#define DMA_ERR_INT_STATUS_STATUS7_DPos   (7U)
#define DMA_ERR_INT_STATUS_STAT7_Pos      DMA_ERR_INT_STATUS_STATUS7_DPos
#define DMA_ERR_INT_STATUS_STAT7_Msk      (0x01UL <<DMA_ERR_INT_STATUS_STAT7_Pos)                    /* 0x00000080 */
#define DMA_ERR_INT_STATUS_STAT7          DMA_ERR_INT_STATUS_STAT7_Msk                               /* DMA channel 7 error interrupt status */

#define DMA_ERR_INT_STATUS_STATUS8_DPos   (8U)
#define DMA_ERR_INT_STATUS_STAT8_Pos      DMA_ERR_INT_STATUS_STATUS8_DPos
#define DMA_ERR_INT_STATUS_STAT8_Msk      (0x01UL <<DMA_ERR_INT_STATUS_STAT8_Pos)                    /* 0x00000100 */
#define DMA_ERR_INT_STATUS_STAT8          DMA_ERR_INT_STATUS_STAT8_Msk                               /* DMA channel 8 error interrupt status */

#define DMA_ERR_INT_STATUS_STATUS9_DPos   (9U)
#define DMA_ERR_INT_STATUS_STAT9_Pos      DMA_ERR_INT_STATUS_STATUS9_DPos
#define DMA_ERR_INT_STATUS_STAT9_Msk      (0x01UL <<DMA_ERR_INT_STATUS_STAT9_Pos)                    /* 0x00000200 */
#define DMA_ERR_INT_STATUS_STAT9          DMA_ERR_INT_STATUS_STAT9_Msk                               /* DMA channel 9 error interrupt status */

#define DMA_ERR_INT_STATUS_STATUS10_DPos  (10U)
#define DMA_ERR_INT_STATUS_STAT10_Pos     DMA_ERR_INT_STATUS_STATUS10_DPos
#define DMA_ERR_INT_STATUS_STAT10_Msk     (0x01UL <<DMA_ERR_INT_STATUS_STAT10_Pos)                   /* 0x00000400 */
#define DMA_ERR_INT_STATUS_STAT10         DMA_ERR_INT_STATUS_STAT10_Msk                              /* DMA channel 10 error interrupt status */

#define DMA_ERR_INT_STATUS_STATUS11_DPos  (11U)
#define DMA_ERR_INT_STATUS_STAT11_Pos     DMA_ERR_INT_STATUS_STATUS11_DPos
#define DMA_ERR_INT_STATUS_STAT11_Msk     (0x01UL <<DMA_ERR_INT_STATUS_STAT11_Pos)                   /* 0x00000800 */
#define DMA_ERR_INT_STATUS_STAT11         DMA_ERR_INT_STATUS_STAT11_Msk                              /* DMA channel 11 error interrupt status */

#define DMA_ERR_INT_STATUS_STATUS12_DPos  (12U)
#define DMA_ERR_INT_STATUS_STAT12_Pos     DMA_ERR_INT_STATUS_STATUS12_DPos
#define DMA_ERR_INT_STATUS_STAT12_Msk     (0x01UL <<DMA_ERR_INT_STATUS_STAT12_Pos)                   /* 0x00001000 */
#define DMA_ERR_INT_STATUS_STAT12         DMA_ERR_INT_STATUS_STAT12_Msk                              /* DMA channel 12 error interrupt status */

#define DMA_ERR_INT_STATUS_STATUS13_DPos  (13U)
#define DMA_ERR_INT_STATUS_STAT13_Pos     DMA_ERR_INT_STATUS_STATUS13_DPos
#define DMA_ERR_INT_STATUS_STAT13_Msk     (0x01UL <<DMA_ERR_INT_STATUS_STAT13_Pos)                   /* 0x00002000 */
#define DMA_ERR_INT_STATUS_STAT13         DMA_ERR_INT_STATUS_STAT13_Msk                              /* DMA channel 13 error interrupt status */

#define DMA_ERR_INT_STATUS_STATUS14_DPos  (14U)
#define DMA_ERR_INT_STATUS_STAT14_Pos     DMA_ERR_INT_STATUS_STATUS14_DPos
#define DMA_ERR_INT_STATUS_STAT14_Msk     (0x01UL <<DMA_ERR_INT_STATUS_STAT14_Pos)                   /* 0x00004000 */
#define DMA_ERR_INT_STATUS_STAT14         DMA_ERR_INT_STATUS_STAT14_Msk                              /* DMA channel 14 error interrupt status */

#define DMA_ERR_INT_STATUS_STATUS15_DPos  (15U)
#define DMA_ERR_INT_STATUS_STAT15_Pos     DMA_ERR_INT_STATUS_STATUS15_DPos
#define DMA_ERR_INT_STATUS_STAT15_Msk     (0x01UL <<DMA_ERR_INT_STATUS_STAT15_Pos)                   /* 0x00008000 */
#define DMA_ERR_INT_STATUS_STAT15         DMA_ERR_INT_STATUS_STAT15_Msk                              /* DMA channel 15 error interrupt status */



/******************  Bits definition for DMA_FTF_INT_RAW register  *****************/
#define DMA_FTF_INT_RAW_FTF_RAW0_DPos   (0U)
#define DMA_FTF_INT_RAW_RAW0_Pos        DMA_FTF_INT_RAW_FTF_RAW0_DPos
#define DMA_FTF_INT_RAW_RAW0_Msk        (0x01UL <<DMA_FTF_INT_RAW_RAW0_Pos)                    /* 0x00000001 */
#define DMA_FTF_INT_RAW_RAW0            DMA_FTF_INT_RAW_RAW0_Msk                               /* DMA channel 0 tranfer commplete interrupt raw status */

#define DMA_FTF_INT_RAW_FTF_RAW1_DPos   (1U)
#define DMA_FTF_INT_RAW_RAW1_Pos        DMA_FTF_INT_RAW_FTF_RAW1_DPos
#define DMA_FTF_INT_RAW_RAW1_Msk        (0x01UL <<DMA_FTF_INT_RAW_RAW1_Pos)                    /* 0x00000002 */
#define DMA_FTF_INT_RAW_RAW1            DMA_FTF_INT_RAW_RAW1_Msk                               /* DMA channel 1 tranfer commplete interrupt raw status */

#define DMA_FTF_INT_RAW_FTF_RAW2_DPos   (2U)
#define DMA_FTF_INT_RAW_RAW2_Pos        DMA_FTF_INT_RAW_FTF_RAW2_DPos
#define DMA_FTF_INT_RAW_RAW2_Msk        (0x01UL <<DMA_FTF_INT_RAW_RAW2_Pos)                    /* 0x00000004 */
#define DMA_FTF_INT_RAW_RAW2            DMA_FTF_INT_RAW_RAW2_Msk                               /* DMA channel 2 tranfer commplete interrupt raw status */

#define DMA_FTF_INT_RAW_FTF_RAW3_DPos   (3U)
#define DMA_FTF_INT_RAW_RAW3_Pos        DMA_FTF_INT_RAW_FTF_RAW3_DPos
#define DMA_FTF_INT_RAW_RAW3_Msk        (0x01UL <<DMA_FTF_INT_RAW_RAW3_Pos)                    /* 0x00000008 */
#define DMA_FTF_INT_RAW_RAW3            DMA_FTF_INT_RAW_RAW3_Msk                               /* DMA channel 6 tranfer commplete interrupt raw status */

#define DMA_FTF_INT_RAW_FTF_RAW4_DPos   (4U)
#define DMA_FTF_INT_RAW_RAW4_Pos        DMA_FTF_INT_RAW_FTF_RAW4_DPos
#define DMA_FTF_INT_RAW_RAW4_Msk        (0x01UL <<DMA_FTF_INT_RAW_RAW4_Pos)                    /* 0x00000010 */
#define DMA_FTF_INT_RAW_RAW4            DMA_FTF_INT_RAW_RAW4_Msk                               /* DMA channel 4 tranfer commplete interrupt raw status */

#define DMA_FTF_INT_RAW_FTF_RAW5_DPos   (5U)
#define DMA_FTF_INT_RAW_RAW5_Pos        DMA_FTF_INT_RAW_FTF_RAW5_DPos
#define DMA_FTF_INT_RAW_RAW5_Msk        (0x01UL <<DMA_FTF_INT_RAW_RAW5_Pos)                    /* 0x00000020 */
#define DMA_FTF_INT_RAW_RAW5            DMA_FTF_INT_RAW_RAW5_Msk                               /* DMA channel 5 tranfer commplete interrupt raw status */

#define DMA_FTF_INT_RAW_FTF_RAW6_DPos   (6U)
#define DMA_FTF_INT_RAW_RAW6_Pos        DMA_FTF_INT_RAW_FTF_RAW6_DPos
#define DMA_FTF_INT_RAW_RAW6_Msk        (0x01UL <<DMA_FTF_INT_RAW_RAW6_Pos)                    /* 0x00000040 */
#define DMA_FTF_INT_RAW_RAW6            DMA_FTF_INT_RAW_RAW6_Msk                               /* DMA channel 6 tranfer commplete interrupt raw status */

#define DMA_FTF_INT_RAW_FTF_RAW7_DPos   (7U)
#define DMA_FTF_INT_RAW_RAW7_Pos        DMA_FTF_INT_RAW_FTF_RAW7_DPos
#define DMA_FTF_INT_RAW_RAW7_Msk        (0x01UL <<DMA_FTF_INT_RAW_RAW7_Pos)                    /* 0x00000080 */
#define DMA_FTF_INT_RAW_RAW7            DMA_FTF_INT_RAW_RAW7_Msk                               /* DMA channel 7 tranfer commplete interrupt raw status */

#define DMA_FTF_INT_RAW_FTF_RAW8_DPos   (8U)
#define DMA_FTF_INT_RAW_RAW8_Pos        DMA_FTF_INT_RAW_FTF_RAW8_DPos
#define DMA_FTF_INT_RAW_RAW8_Msk        (0x01UL <<DMA_FTF_INT_RAW_RAW8_Pos)                    /* 0x00000100 */
#define DMA_FTF_INT_RAW_RAW8            DMA_FTF_INT_RAW_RAW8_Msk                               /* DMA channel 8 tranfer commplete interrupt raw status */

#define DMA_FTF_INT_RAW_FTF_RAW9_DPos   (9U)
#define DMA_FTF_INT_RAW_RAW9_Pos        DMA_FTF_INT_RAW_FTF_RAW9_DPos
#define DMA_FTF_INT_RAW_RAW9_Msk        (0x01UL <<DMA_FTF_INT_RAW_RAW9_Pos)                    /* 0x00000200 */
#define DMA_FTF_INT_RAW_RAW9            DMA_FTF_INT_RAW_RAW9_Msk                               /* DMA channel 9 tranfer commplete interrupt raw status */

#define DMA_FTF_INT_RAW_FTF_RAW10_DPos  (10U)
#define DMA_FTF_INT_RAW_RAW10_Pos       DMA_FTF_INT_RAW_FTF_RAW10_DPos
#define DMA_FTF_INT_RAW_RAW10_Msk       (0x01UL <<DMA_FTF_INT_RAW_RAW10_Pos)                   /* 0x00000400 */
#define DMA_FTF_INT_RAW_RAW10           DMA_FTF_INT_RAW_RAW10_Msk                              /* DMA channel 10 tranfer commplete interrupt raw status */

#define DMA_FTF_INT_RAW_FTF_RAW11_DPos  (11U)
#define DMA_FTF_INT_RAW_RAW11_Pos       DMA_FTF_INT_RAW_FTF_RAW11_DPos
#define DMA_FTF_INT_RAW_RAW11_Msk       (0x01UL <<DMA_FTF_INT_RAW_RAW11_Pos)                   /* 0x00000800 */
#define DMA_FTF_INT_RAW_RAW11           DMA_FTF_INT_RAW_RAW11_Msk                              /* DMA channel 11 tranfer commplete interrupt raw status */

#define DMA_FTF_INT_RAW_FTF_RAW12_DPos  (12U)
#define DMA_FTF_INT_RAW_RAW12_Pos       DMA_FTF_INT_RAW_FTF_RAW12_DPos
#define DMA_FTF_INT_RAW_RAW12_Msk       (0x01UL <<DMA_FTF_INT_RAW_RAW12_Pos)                   /* 0x00001000 */
#define DMA_FTF_INT_RAW_RAW12           DMA_FTF_INT_RAW_RAW12_Msk                              /* DMA channel 12 tranfer commplete interrupt raw status */

#define DMA_FTF_INT_RAW_FTF_RAW13_DPos  (13U)
#define DMA_FTF_INT_RAW_RAW13_Pos       DMA_FTF_INT_RAW_FTF_RAW13_DPos
#define DMA_FTF_INT_RAW_RAW13_Msk       (0x01UL <<DMA_FTF_INT_RAW_RAW13_Pos)                   /* 0x00002000 */
#define DMA_FTF_INT_RAW_RAW13           DMA_FTF_INT_RAW_RAW13_Msk                              /* DMA channel 13 tranfer commplete interrupt raw status */

#define DMA_FTF_INT_RAW_FTF_RAW14_DPos  (14U)
#define DMA_FTF_INT_RAW_RAW14_Pos       DMA_FTF_INT_RAW_FTF_RAW14_DPos
#define DMA_FTF_INT_RAW_RAW14_Msk       (0x01UL <<DMA_FTF_INT_RAW_RAW14_Pos)                   /* 0x00004000 */
#define DMA_FTF_INT_RAW_RAW14           DMA_FTF_INT_RAW_RAW14_Msk                              /* DMA channel 14 tranfer commplete interrupt raw status */

#define DMA_FTF_INT_RAW_FTF_RAW15_DPos  (15U)
#define DMA_FTF_INT_RAW_RAW15_Pos       DMA_FTF_INT_RAW_FTF_RAW15_DPos
#define DMA_FTF_INT_RAW_RAW15_Msk       (0x01UL <<DMA_FTF_INT_RAW_RAW15_Pos)                   /* 0x00008000 */
#define DMA_FTF_INT_RAW_RAW15           DMA_FTF_INT_RAW_RAW15_Msk                              /* DMA channel 15 tranfer commplete interrupt raw status */


/******************  Bits definition for DMA_FTF_INT_FORCE register  *****************/
#define DMA_FTF_INT_FORCE_FORCE0_DPos   (0U)
#define DMA_FTF_INT_FORCE_FORCE0_Pos    DMA_FTF_INT_FORCE_FORCE0_DPos
#define DMA_FTF_INT_FORCE_FORCE0_Msk    (0x01UL <<DMA_FTF_INT_FORCE_FORCE0_Pos)                    /* 0x00000001 */
#define DMA_FTF_INT_FORCE_FORCE0        DMA_FTF_INT_FORCE_FORCE0_Msk                               /* DMA channel 0 tranfer commplete interrupt force */

#define DMA_FTF_INT_FORCE_FORCE1_DPos   (1U)
#define DMA_FTF_INT_FORCE_FORCE1_Pos    DMA_FTF_INT_FORCE_FORCE1_DPos
#define DMA_FTF_INT_FORCE_FORCE1_Msk    (0x01UL <<DMA_FTF_INT_FORCE_FORCE1_Pos)                    /* 0x00000002 */
#define DMA_FTF_INT_FORCE_FORCE1        DMA_FTF_INT_FORCE_FORCE1_Msk                               /* DMA channel 1 tranfer commplete interrupt force */

#define DMA_FTF_INT_FORCE_FORCE2_DPos   (2U)
#define DMA_FTF_INT_FORCE_FORCE2_Pos    DMA_FTF_INT_FORCE_FORCE2_DPos
#define DMA_FTF_INT_FORCE_FORCE2_Msk    (0x01UL <<DMA_FTF_INT_FORCE_FORCE2_Pos)                    /* 0x00000004 */
#define DMA_FTF_INT_FORCE_FORCE2        DMA_FTF_INT_FORCE_FORCE2_Msk                               /* DMA channel 2 tranfer commplete interrupt force */

#define DMA_FTF_INT_FORCE_FORCE6_DPos   (6U)
#define DMA_FTF_INT_FORCE_FORCE6_Pos    DMA_FTF_INT_FORCE_FORCE6_DPos
#define DMA_FTF_INT_FORCE_FORCE6_Msk    (0x01UL <<DMA_FTF_INT_FORCE_FORCE6_Pos)                    /* 0x00000040 */
#define DMA_FTF_INT_FORCE_FORCE6        DMA_FTF_INT_FORCE_FORCE6_Msk                               /* DMA channel 6 tranfer commplete interrupt force */

#define DMA_FTF_INT_FORCE_FORCE4_DPos   (4U)
#define DMA_FTF_INT_FORCE_FORCE4_Pos    DMA_FTF_INT_FORCE_FORCE4_DPos
#define DMA_FTF_INT_FORCE_FORCE4_Msk    (0x01UL <<DMA_FTF_INT_FORCE_FORCE4_Pos)                    /* 0x00000010 */
#define DMA_FTF_INT_FORCE_FORCE4        DMA_FTF_INT_FORCE_FORCE4_Msk                               /* DMA channel 4 tranfer commplete interrupt force */

#define DMA_FTF_INT_FORCE_FORCE5_DPos   (5U)
#define DMA_FTF_INT_FORCE_FORCE5_Pos    DMA_FTF_INT_FORCE_FORCE5_DPos
#define DMA_FTF_INT_FORCE_FORCE5_Msk    (0x01UL <<DMA_FTF_INT_FORCE_FORCE5_Pos)                    /* 0x00000020 */
#define DMA_FTF_INT_FORCE_FORCE5        DMA_FTF_INT_FORCE_FORCE5_Msk                               /* DMA channel 5 tranfer commplete interrupt force */


#define DMA_FTF_INT_FORCE_FORCE7_DPos   (7U)
#define DMA_FTF_INT_FORCE_FORCE7_Pos    DMA_FTF_INT_FORCE_FORCE7_DPos
#define DMA_FTF_INT_FORCE_FORCE7_Msk    (0x01UL <<DMA_FTF_INT_FORCE_FORCE7_Pos)                    /* 0x00000080 */
#define DMA_FTF_INT_FORCE_FORCE7        DMA_FTF_INT_FORCE_FORCE7_Msk                               /* DMA channel 7 tranfer commplete interrupt force */

#define DMA_FTF_INT_FORCE_FORCE8_DPos   (8U)
#define DMA_FTF_INT_FORCE_FORCE8_Pos    DMA_FTF_INT_FORCE_FORCE8_DPos
#define DMA_FTF_INT_FORCE_FORCE8_Msk    (0x01UL <<DMA_FTF_INT_FORCE_FORCE8_Pos)                    /* 0x00000100 */
#define DMA_FTF_INT_FORCE_FORCE8        DMA_FTF_INT_FORCE_FORCE8_Msk                               /* DMA channel 8 tranfer commplete interrupt force */

#define DMA_FTF_INT_FORCE_FORCE9_DPos   (9U)
#define DMA_FTF_INT_FORCE_FORCE9_Pos    DMA_FTF_INT_FORCE_FORCE9_DPos
#define DMA_FTF_INT_FORCE_FORCE9_Msk    (0x01UL <<DMA_FTF_INT_FORCE_FORCE9_Pos)                    /* 0x00000200 */
#define DMA_FTF_INT_FORCE_FORCE9        DMA_FTF_INT_FORCE_FORCE9_Msk                               /* DMA channel 9 tranfer commplete interrupt force */

#define DMA_FTF_INT_FORCE_FORCE10_DPos  (10U)
#define DMA_FTF_INT_FORCE_FORCE10_Pos   DMA_FTF_INT_FORCE_FORCE10_DPos
#define DMA_FTF_INT_FORCE_FORCE10_Msk   (0x01UL <<DMA_FTF_INT_FORCE_FORCE10_Pos)                   /* 0x00000400 */
#define DMA_FTF_INT_FORCE_FORCE10       DMA_FTF_INT_FORCE_FORCE10_Msk                              /* DMA channel 10 tranfer commplete interrupt force */

#define DMA_FTF_INT_FORCE_FORCE11_DPos  (11U)
#define DMA_FTF_INT_FORCE_FORCE11_Pos   DMA_FTF_INT_FORCE_FORCE11_DPos
#define DMA_FTF_INT_FORCE_FORCE11_Msk   (0x01UL <<DMA_FTF_INT_FORCE_FORCE11_Pos)                   /* 0x00000800 */
#define DMA_FTF_INT_FORCE_FORCE11       DMA_FTF_INT_FORCE_FORCE11_Msk                              /* DMA channel 11 tranfer commplete interrupt force */

#define DMA_FTF_INT_FORCE_FORCE12_DPos  (12U)
#define DMA_FTF_INT_FORCE_FORCE12_Pos   DMA_FTF_INT_FORCE_FORCE12_DPos
#define DMA_FTF_INT_FORCE_FORCE12_Msk   (0x01UL <<DMA_FTF_INT_FORCE_FORCE12_Pos)                   /* 0x00001000 */
#define DMA_FTF_INT_FORCE_FORCE12       DMA_FTF_INT_FORCE_FORCE12_Msk                              /* DMA channel 12 tranfer commplete interrupt force */

#define DMA_FTF_INT_FORCE_FORCE13_DPos  (13U)
#define DMA_FTF_INT_FORCE_FORCE13_Pos   DMA_FTF_INT_FORCE_FORCE13_DPos
#define DMA_FTF_INT_FORCE_FORCE13_Msk   (0x01UL <<DMA_FTF_INT_FORCE_FORCE13_Pos)                   /* 0x00002000 */
#define DMA_FTF_INT_FORCE_FORCE13       DMA_FTF_INT_FORCE_FORCE13_Msk                              /* DMA channel 13 tranfer commplete interrupt force */

#define DMA_FTF_INT_FORCE_FORCE14_DPos  (14U)
#define DMA_FTF_INT_FORCE_FORCE14_Pos   DMA_FTF_INT_FORCE_FORCE14_DPos
#define DMA_FTF_INT_FORCE_FORCE14_Msk   (0x01UL <<DMA_FTF_INT_FORCE_FORCE14_Pos)                   /* 0x00004000 */
#define DMA_FTF_INT_FORCE_FORCE14       DMA_FTF_INT_FORCE_FORCE14_Msk                              /* DMA channel 14 tranfer commplete interrupt force */

#define DMA_FTF_INT_FORCE_FORCE15_DPos  (15U)
#define DMA_FTF_INT_FORCE_FORCE15_Pos   DMA_FTF_INT_FORCE_FORCE15_DPos
#define DMA_FTF_INT_FORCE_FORCE15_Msk   (0x01UL <<DMA_FTF_INT_FORCE_FORCE15_Pos)                   /* 0x00008000 */
#define DMA_FTF_INT_FORCE_FORCE15       DMA_FTF_INT_FORCE_FORCE15_Msk                              /* DMA channel 15 tranfer commplete interrupt force */

/******************  Bits definition for DMA_FTF_INT_MASK register  *****************/
#define DMA_FTF_INT_MASK_MASK0_DPos   (0U)
#define DMA_FTF_INT_MASK_MASK0_Pos    DMA_FTF_INT_MASK_MASK0_DPos
#define DMA_FTF_INT_MASK_MASK0_Msk    (0x01UL <<DMA_FTF_INT_MASK_MASK0_Pos)                    /* 0x00000001 */
#define DMA_FTF_INT_MASK_MASK0        DMA_FTF_INT_MASK_MASK0_Msk                               /* DMA channel 0 tranfer commplete interrupt mask */

#define DMA_FTF_INT_MASK_MASK1_DPos   (1U)
#define DMA_FTF_INT_MASK_MASK1_Pos    DMA_FTF_INT_MASK_MASK1_DPos
#define DMA_FTF_INT_MASK_MASK1_Msk    (0x01UL <<DMA_FTF_INT_MASK_MASK1_Pos)                    /* 0x00000002 */
#define DMA_FTF_INT_MASK_MASK1        DMA_FTF_INT_MASK_MASK1_Msk                               /* DMA channel 1 tranfer commplete interrupt mask */

#define DMA_FTF_INT_MASK_MASK2_DPos   (2U)
#define DMA_FTF_INT_MASK_MASK2_Pos    DMA_FTF_INT_MASK_MASK2_DPos
#define DMA_FTF_INT_MASK_MASK2_Msk    (0x01UL <<DMA_FTF_INT_MASK_MASK2_Pos)                    /* 0x00000004 */
#define DMA_FTF_INT_MASK_MASK2        DMA_FTF_INT_MASK_MASK2_Msk                               /* DMA channel 2 tranfer commplete interrupt mask */

#define DMA_FTF_INT_MASK_MASK3_DPos   (3U)
#define DMA_FTF_INT_MASK_MASK3_Pos    DMA_FTF_INT_MASK_MASK3_DPos
#define DMA_FTF_INT_MASK_MASK3_Msk    (0x01UL <<DMA_FTF_INT_MASK_MASK3_Pos)                    /* 0x00000008 */
#define DMA_FTF_INT_MASK_MASK3        DMA_FTF_INT_MASK_MASK3_Msk                               /* DMA channel 3 tranfer commplete interrupt mask */

#define DMA_FTF_INT_MASK_MASK4_DPos   (4U)
#define DMA_FTF_INT_MASK_MASK4_Pos    DMA_FTF_INT_MASK_MASK4_DPos
#define DMA_FTF_INT_MASK_MASK4_Msk    (0x01UL <<DMA_FTF_INT_MASK_MASK4_Pos)                    /* 0x00000010 */
#define DMA_FTF_INT_MASK_MASK4        DMA_FTF_INT_MASK_MASK4_Msk                               /* DMA channel 4 tranfer commplete interrupt mask */

#define DMA_FTF_INT_MASK_MASK5_DPos   (5U)
#define DMA_FTF_INT_MASK_MASK5_Pos    DMA_FTF_INT_MASK_MASK5_DPos
#define DMA_FTF_INT_MASK_MASK5_Msk    (0x01UL <<DMA_FTF_INT_MASK_MASK5_Pos)                    /* 0x00000020 */
#define DMA_FTF_INT_MASK_MASK5        DMA_FTF_INT_MASK_MASK5_Msk                               /* DMA channel 5 tranfer commplete interrupt mask */

#define DMA_FTF_INT_MASK_MASK6_DPos   (6U)
#define DMA_FTF_INT_MASK_MASK6_Pos    DMA_FTF_INT_MASK_MASK6_DPos
#define DMA_FTF_INT_MASK_MASK6_Msk    (0x01UL <<DMA_FTF_INT_MASK_MASK6_Pos)                    /* 0x00000040 */
#define DMA_FTF_INT_MASK_MASK6        DMA_FTF_INT_MASK_MASK6_Msk                               /* DMA channel 6 tranfer commplete interrupt mask */

#define DMA_FTF_INT_MASK_MASK7_DPos   (7U)
#define DMA_FTF_INT_MASK_MASK7_Pos    DMA_FTF_INT_MASK_MASK7_DPos
#define DMA_FTF_INT_MASK_MASK7_Msk    (0x01UL <<DMA_FTF_INT_MASK_MASK7_Pos)                    /* 0x00000080 */
#define DMA_FTF_INT_MASK_MASK7        DMA_FTF_INT_MASK_MASK7_Msk                               /* DMA channel 7 tranfer commplete interrupt mask */

#define DMA_FTF_INT_MASK_MASK8_DPos   (8U)
#define DMA_FTF_INT_MASK_MASK8_Pos    DMA_FTF_INT_MASK_MASK8_DPos
#define DMA_FTF_INT_MASK_MASK8_Msk    (0x01UL <<DMA_FTF_INT_MASK_MASK8_Pos)                    /* 0x00000100 */
#define DMA_FTF_INT_MASK_MASK8        DMA_FTF_INT_MASK_MASK8_Msk                               /* DMA channel 8 tranfer commplete interrupt mask */

#define DMA_FTF_INT_MASK_MASK9_DPos   (9U)
#define DMA_FTF_INT_MASK_MASK9_Pos    DMA_FTF_INT_MASK_MASK9_DPos
#define DMA_FTF_INT_MASK_MASK9_Msk    (0x01UL <<DMA_FTF_INT_MASK_MASK9_Pos)                    /* 0x00000200 */
#define DMA_FTF_INT_MASK_MASK9        DMA_FTF_INT_MASK_MASK9_Msk                               /* DMA channel 9 tranfer commplete interrupt mask */

#define DMA_FTF_INT_MASK_MASK10_DPos  (10U)
#define DMA_FTF_INT_MASK_MASK10_Pos   DMA_FTF_INT_MASK_MASK10_DPos
#define DMA_FTF_INT_MASK_MASK10_Msk   (0x01UL <<DMA_FTF_INT_MASK_MASK10_Pos)                   /* 0x00000400 */
#define DMA_FTF_INT_MASK_MASK10       DMA_FTF_INT_MASK_MASK10_Msk                              /* DMA channel 10 tranfer commplete interrupt mask */

#define DMA_FTF_INT_MASK_MASK11_DPos  (11U)
#define DMA_FTF_INT_MASK_MASK11_Pos   DMA_FTF_INT_MASK_MASK11_DPos
#define DMA_FTF_INT_MASK_MASK11_Msk   (0x01UL <<DMA_FTF_INT_MASK_MASK11_Pos)                   /* 0x00000800 */
#define DMA_FTF_INT_MASK_MASK11       DMA_FTF_INT_MASK_MASK11_Msk                              /* DMA channel 11 tranfer commplete interrupt mask */

#define DMA_FTF_INT_MASK_MASK12_DPos  (12U)
#define DMA_FTF_INT_MASK_MASK12_Pos   DMA_FTF_INT_MASK_MASK12_DPos
#define DMA_FTF_INT_MASK_MASK12_Msk   (0x01UL <<DMA_FTF_INT_MASK_MASK12_Pos)                   /* 0x00001000 */
#define DMA_FTF_INT_MASK_MASK12       DMA_FTF_INT_MASK_MASK12_Msk                              /* DMA channel 12 tranfer commplete interrupt mask */

#define DMA_FTF_INT_MASK_MASK13_DPos  (13U)
#define DMA_FTF_INT_MASK_MASK13_Pos   DMA_FTF_INT_MASK_MASK13_DPos
#define DMA_FTF_INT_MASK_MASK13_Msk   (0x01UL <<DMA_FTF_INT_MASK_MASK13_Pos)                   /* 0x00002000 */
#define DMA_FTF_INT_MASK_MASK13       DMA_FTF_INT_MASK_MASK13_Msk                              /* DMA channel 13 tranfer commplete interrupt mask */

#define DMA_FTF_INT_MASK_MASK14_DPos  (14U)
#define DMA_FTF_INT_MASK_MASK14_Pos   DMA_FTF_INT_MASK_MASK14_DPos
#define DMA_FTF_INT_MASK_MASK14_Msk   (0x01UL <<DMA_FTF_INT_MASK_MASK14_Pos)                   /* 0x00004000 */
#define DMA_FTF_INT_MASK_MASK14       DMA_FTF_INT_MASK_MASK14_Msk                              /* DMA channel 14 tranfer commplete interrupt mask */

#define DMA_FTF_INT_MASK_MASK15_DPos  (15U)
#define DMA_FTF_INT_MASK_MASK15_Pos   DMA_FTF_INT_MASK_MASK15_DPos
#define DMA_FTF_INT_MASK_MASK15_Msk   (0x01UL <<DMA_FTF_INT_MASK_MASK15_Pos)                   /* 0x00008000 */
#define DMA_FTF_INT_MASK_MASK15       DMA_FTF_INT_MASK_MASK15_Msk                              /* DMA channel 15 tranfer commplete interrupt mask */

/******************  Bits definition for DMA_FTF_INT_STATUS register  *****************/
#define DMA_FTF_INT_STATUS_STATUS0_DPos   (0U)
#define DMA_FTF_INT_STATUS_STAT0_Pos      DMA_FTF_INT_STATUS_STATUS0_DPos
#define DMA_FTF_INT_STATUS_STAT0_Msk      (0x01UL <<DMA_FTF_INT_STATUS_STAT0_Pos)                    /* 0x00000001 */
#define DMA_FTF_INT_STATUS_STAT0          DMA_FTF_INT_STATUS_STAT0_Msk                               /* DMA channel 0 tranfer commplete interrupt status */

#define DMA_FTF_INT_STATUS_STATUS1_DPos   (1U)
#define DMA_FTF_INT_STATUS_STAT1_Pos      DMA_FTF_INT_STATUS_STATUS1_DPos
#define DMA_FTF_INT_STATUS_STAT1_Msk      (0x01UL <<DMA_FTF_INT_STATUS_STAT1_Pos)                    /* 0x00000002 */
#define DMA_FTF_INT_STATUS_STAT1          DMA_FTF_INT_STATUS_STAT1_Msk                               /* DMA channel 1 tranfer commplete interrupt status */

#define DMA_FTF_INT_STATUS_STATUS2_DPos   (2U)
#define DMA_FTF_INT_STATUS_STAT2_Pos      DMA_FTF_INT_STATUS_STATUS2_DPos
#define DMA_FTF_INT_STATUS_STAT2_Msk      (0x01UL <<DMA_FTF_INT_STATUS_STAT2_Pos)                    /* 0x00000004 */
#define DMA_FTF_INT_STATUS_STAT2          DMA_FTF_INT_STATUS_STAT2_Msk                               /* DMA channel 2 tranfer commplete interrupt status */

#define DMA_FTF_INT_STATUS_STATUS6_DPos   (6U)
#define DMA_FTF_INT_STATUS_STAT6_Pos      DMA_FTF_INT_STATUS_STATUS6_DPos
#define DMA_FTF_INT_STATUS_STAT6_Msk      (0x01UL <<DMA_FTF_INT_STATUS_STAT6_Pos)                    /* 0x00000040 */
#define DMA_FTF_INT_STATUS_STAT6          DMA_FTF_INT_STATUS_STAT6_Msk                               /* DMA channel 6 tranfer commplete interrupt status */

#define DMA_FTF_INT_STATUS_STATUS4_DPos   (4U)
#define DMA_FTF_INT_STATUS_STAT4_Pos      DMA_FTF_INT_STATUS_STATUS4_DPos
#define DMA_FTF_INT_STATUS_STAT4_Msk      (0x01UL <<DMA_FTF_INT_STATUS_STAT4_Pos)                    /* 0x00000010 */
#define DMA_FTF_INT_STATUS_STAT4          DMA_FTF_INT_STATUS_STAT4_Msk                               /* DMA channel 4 tranfer commplete interrupt status */

#define DMA_FTF_INT_STATUS_STATUS5_DPos   (5U)
#define DMA_FTF_INT_STATUS_STAT5_Pos      DMA_FTF_INT_STATUS_STATUS5_DPos
#define DMA_FTF_INT_STATUS_STAT5_Msk      (0x01UL <<DMA_FTF_INT_STATUS_STAT5_Pos)                    /* 0x00000020 */
#define DMA_FTF_INT_STATUS_STAT5          DMA_FTF_INT_STATUS_STAT5_Msk                               /* DMA channel 5 tranfer commplete interrupt status */


#define DMA_FTF_INT_STATUS_STATUS7_DPos   (7U)
#define DMA_FTF_INT_STATUS_STAT7_Pos      DMA_FTF_INT_STATUS_STATUS7_DPos
#define DMA_FTF_INT_STATUS_STAT7_Msk      (0x01UL <<DMA_FTF_INT_STATUS_STAT7_Pos)                    /* 0x00000080 */
#define DMA_FTF_INT_STATUS_STAT7          DMA_FTF_INT_STATUS_STAT7_Msk                               /* DMA channel 7 tranfer commplete interrupt status */

#define DMA_FTF_INT_STATUS_STATUS8_DPos   (8U)
#define DMA_FTF_INT_STATUS_STAT8_Pos      DMA_FTF_INT_STATUS_STATUS8_DPos
#define DMA_FTF_INT_STATUS_STAT8_Msk      (0x01UL <<DMA_FTF_INT_STATUS_STAT8_Pos)                    /* 0x00000100 */
#define DMA_FTF_INT_STATUS_STAT8          DMA_FTF_INT_STATUS_STAT8_Msk                               /* DMA channel 8 tranfer commplete interrupt status */

#define DMA_FTF_INT_STATUS_STATUS9_DPos   (9U)
#define DMA_FTF_INT_STATUS_STAT9_Pos      DMA_FTF_INT_STATUS_STATUS9_DPos
#define DMA_FTF_INT_STATUS_STAT9_Msk      (0x01UL <<DMA_FTF_INT_STATUS_STAT9_Pos)                    /* 0x00000200 */
#define DMA_FTF_INT_STATUS_STAT9          DMA_FTF_INT_STATUS_STAT9_Msk                               /* DMA channel 9 tranfer commplete interrupt status */

#define DMA_FTF_INT_STATUS_STATUS10_DPos  (10U)
#define DMA_FTF_INT_STATUS_STAT10_Pos     DMA_FTF_INT_STATUS_STATUS10_DPos
#define DMA_FTF_INT_STATUS_STAT10_Msk     (0x01UL <<DMA_FTF_INT_STATUS_STAT10_Pos)                   /* 0x00000400 */
#define DMA_FTF_INT_STATUS_STAT10         DMA_FTF_INT_STATUS_STAT10_Msk                              /* DMA channel 10 tranfer commplete interrupt status */

#define DMA_FTF_INT_STATUS_STATUS11_DPos  (11U)
#define DMA_FTF_INT_STATUS_STAT11_Pos     DMA_FTF_INT_STATUS_STATUS11_DPos
#define DMA_FTF_INT_STATUS_STAT11_Msk     (0x01UL <<DMA_FTF_INT_STATUS_STAT11_Pos)                   /* 0x00000800 */
#define DMA_FTF_INT_STATUS_STAT11         DMA_FTF_INT_STATUS_STAT11_Msk                              /* DMA channel 11 tranfer commplete interrupt status */

#define DMA_FTF_INT_STATUS_STATUS12_DPos  (12U)
#define DMA_FTF_INT_STATUS_STAT12_Pos     DMA_FTF_INT_STATUS_STATUS12_DPos
#define DMA_FTF_INT_STATUS_STAT12_Msk     (0x01UL <<DMA_FTF_INT_STATUS_STAT12_Pos)                   /* 0x00001000 */
#define DMA_FTF_INT_STATUS_STAT12         DMA_FTF_INT_STATUS_STAT12_Msk                              /* DMA channel 12 tranfer commplete interrupt status */

#define DMA_FTF_INT_STATUS_STATUS13_DPos  (13U)
#define DMA_FTF_INT_STATUS_STAT13_Pos     DMA_FTF_INT_STATUS_STATUS13_DPos
#define DMA_FTF_INT_STATUS_STAT13_Msk     (0x01UL <<DMA_FTF_INT_STATUS_STAT13_Pos)                   /* 0x00002000 */
#define DMA_FTF_INT_STATUS_STAT13         DMA_FTF_INT_STATUS_STAT13_Msk                              /* DMA channel 13 tranfer commplete interrupt status */

#define DMA_FTF_INT_STATUS_STATUS14_DPos  (14U)
#define DMA_FTF_INT_STATUS_STAT14_Pos     DMA_FTF_INT_STATUS_STATUS14_DPos
#define DMA_FTF_INT_STATUS_STAT14_Msk     (0x01UL <<DMA_FTF_INT_STATUS_STAT14_Pos)                   /* 0x00004000 */
#define DMA_FTF_INT_STATUS_STAT14         DMA_FTF_INT_STATUS_STAT14_Msk                              /* DMA channel 14 tranfer commplete interrupt status */

#define DMA_FTF_INT_STATUS_STATUS15_DPos  (15U)
#define DMA_FTF_INT_STATUS_STAT15_Pos     DMA_FTF_INT_STATUS_STATUS15_DPos
#define DMA_FTF_INT_STATUS_STAT15_Msk     (0x01UL <<DMA_FTF_INT_STATUS_STAT15_Pos)                   /* 0x00008000 */
#define DMA_FTF_INT_STATUS_STAT15         DMA_FTF_INT_STATUS_STAT15_Msk                              /* DMA channel 15 tranfer commplete interrupt status */



/******************  Bits definition for DMA_HTF_INT_RAW register  *****************/
#define DMA_HTF_INT_RAW_HTF_RAW0_DPos   (0U)
#define DMA_HTF_INT_RAW_RAW0_Pos        DMA_HTF_INT_RAW_HTF_RAW0_DPos
#define DMA_HTF_INT_RAW_RAW0_Msk        (0x01UL <<DMA_HTF_INT_RAW_RAW0_Pos)                    /* 0x00000001 */
#define DMA_HTF_INT_RAW_RAW0            DMA_HTF_INT_RAW_RAW0_Msk                               /* DMA channel 0 half tranfer interrput raw status */

#define DMA_HTF_INT_RAW_HTF_RAW1_DPos   (1U)
#define DMA_HTF_INT_RAW_RAW1_Pos        DMA_HTF_INT_RAW_HTF_RAW1_DPos
#define DMA_HTF_INT_RAW_RAW1_Msk        (0x01UL <<DMA_HTF_INT_RAW_RAW1_Pos)                    /* 0x00000002 */
#define DMA_HTF_INT_RAW_RAW1            DMA_HTF_INT_RAW_RAW1_Msk                               /* DMA channel 1 half tranfer interrput raw status */

#define DMA_HTF_INT_RAW_HTF_RAW2_DPos   (2U)
#define DMA_HTF_INT_RAW_RAW2_Pos        DMA_HTF_INT_RAW_HTF_RAW2_DPos
#define DMA_HTF_INT_RAW_RAW2_Msk        (0x01UL <<DMA_HTF_INT_RAW_RAW2_Pos)                    /* 0x00000004 */
#define DMA_HTF_INT_RAW_RAW2            DMA_HTF_INT_RAW_RAW2_Msk                               /* DMA channel 2 half tranfer interrput raw status */

#define DMA_HTF_INT_RAW_HTF_RAW3_DPos   (3U)
#define DMA_HTF_INT_RAW_RAW3_Pos        DMA_HTF_INT_RAW_HTF_RAW3_DPos
#define DMA_HTF_INT_RAW_RAW3_Msk        (0x01UL <<DMA_HTF_INT_RAW_RAW3_Pos)                    /* 0x00000008 */
#define DMA_HTF_INT_RAW_RAW3            DMA_HTF_INT_RAW_RAW3_Msk                               /* DMA channel 3 half tranfer interrput raw status */

#define DMA_HTF_INT_RAW_HTF_RAW4_DPos   (4U)
#define DMA_HTF_INT_RAW_RAW4_Pos        DMA_HTF_INT_RAW_HTF_RAW4_DPos
#define DMA_HTF_INT_RAW_RAW4_Msk        (0x01UL <<DMA_HTF_INT_RAW_RAW4_Pos)                    /* 0x00000010 */
#define DMA_HTF_INT_RAW_RAW4            DMA_HTF_INT_RAW_RAW4_Msk                               /* DMA channel 4 half tranfer interrput raw status */

#define DMA_HTF_INT_RAW_HTF_RAW5_DPos   (5U)
#define DMA_HTF_INT_RAW_RAW5_Pos        DMA_HTF_INT_RAW_HTF_RAW5_DPos
#define DMA_HTF_INT_RAW_RAW5_Msk        (0x01UL <<DMA_HTF_INT_RAW_RAW5_Pos)                    /* 0x00000020 */
#define DMA_HTF_INT_RAW_RAW5            DMA_HTF_INT_RAW_RAW5_Msk                               /* DMA channel 5 half tranfer interrput raw status */

#define DMA_HTF_INT_RAW_HTF_RAW6_DPos   (6U)
#define DMA_HTF_INT_RAW_RAW6_Pos        DMA_HTF_INT_RAW_HTF_RAW6_DPos
#define DMA_HTF_INT_RAW_RAW6_Msk        (0x01UL <<DMA_HTF_INT_RAW_RAW6_Pos)                    /* 0x00000040 */
#define DMA_HTF_INT_RAW_RAW6            DMA_HTF_INT_RAW_RAW6_Msk                               /* DMA channel 6 half tranfer interrput raw status */

#define DMA_HTF_INT_RAW_HTF_RAW7_DPos   (7U)
#define DMA_HTF_INT_RAW_RAW7_Pos        DMA_HTF_INT_RAW_HTF_RAW7_DPos
#define DMA_HTF_INT_RAW_RAW7_Msk        (0x01UL <<DMA_HTF_INT_RAW_RAW7_Pos)                    /* 0x00000080 */
#define DMA_HTF_INT_RAW_RAW7            DMA_HTF_INT_RAW_RAW7_Msk                               /* DMA channel 7 half tranfer interrput raw status */

#define DMA_HTF_INT_RAW_HTF_RAW8_DPos   (8U)
#define DMA_HTF_INT_RAW_RAW8_Pos        DMA_HTF_INT_RAW_HTF_RAW8_DPos
#define DMA_HTF_INT_RAW_RAW8_Msk        (0x01UL <<DMA_HTF_INT_RAW_RAW8_Pos)                    /* 0x00000100 */
#define DMA_HTF_INT_RAW_RAW8            DMA_HTF_INT_RAW_RAW8_Msk                               /* DMA channel 8 half tranfer interrput raw status */

#define DMA_HTF_INT_RAW_HTF_RAW9_DPos   (9U)
#define DMA_HTF_INT_RAW_RAW9_Pos        DMA_HTF_INT_RAW_HTF_RAW9_DPos
#define DMA_HTF_INT_RAW_RAW9_Msk        (0x01UL <<DMA_HTF_INT_RAW_RAW9_Pos)                    /* 0x00000200 */
#define DMA_HTF_INT_RAW_RAW9            DMA_HTF_INT_RAW_RAW9_Msk                               /* DMA channel 9 half tranfer interrput raw status */

#define DMA_HTF_INT_RAW_HTF_RAW10_DPos  (10U)
#define DMA_HTF_INT_RAW_RAW10_Pos       DMA_HTF_INT_RAW_HTF_RAW10_DPos
#define DMA_HTF_INT_RAW_RAW10_Msk       (0x01UL <<DMA_HTF_INT_RAW_RAW10_Pos)                   /* 0x00000400 */
#define DMA_HTF_INT_RAW_RAW10           DMA_HTF_INT_RAW_RAW10_Msk                              /* DMA channel 10 half tranfer interrput raw status */

#define DMA_HTF_INT_RAW_HTF_RAW11_DPos  (11U)
#define DMA_HTF_INT_RAW_RAW11_Pos       DMA_HTF_INT_RAW_HTF_RAW11_DPos
#define DMA_HTF_INT_RAW_RAW11_Msk       (0x01UL <<DMA_HTF_INT_RAW_RAW11_Pos)                   /* 0x00000800 */
#define DMA_HTF_INT_RAW_RAW11           DMA_HTF_INT_RAW_RAW11_Msk                              /* DMA channel 11 half tranfer interrput raw status */

#define DMA_HTF_INT_RAW_HTF_RAW12_DPos  (12U)
#define DMA_HTF_INT_RAW_RAW12_Pos       DMA_HTF_INT_RAW_HTF_RAW12_DPos
#define DMA_HTF_INT_RAW_RAW12_Msk       (0x01UL <<DMA_HTF_INT_RAW_RAW12_Pos)                   /* 0x00001000 */
#define DMA_HTF_INT_RAW_RAW12           DMA_HTF_INT_RAW_RAW12_Msk                              /* DMA channel 12 half tranfer interrput raw status */

#define DMA_HTF_INT_RAW_HTF_RAW13_DPos  (13U)
#define DMA_HTF_INT_RAW_RAW13_Pos       DMA_HTF_INT_RAW_HTF_RAW13_DPos
#define DMA_HTF_INT_RAW_RAW13_Msk       (0x01UL <<DMA_HTF_INT_RAW_RAW13_Pos)                   /* 0x00002000 */
#define DMA_HTF_INT_RAW_RAW13           DMA_HTF_INT_RAW_RAW13_Msk                              /* DMA channel 13 half tranfer interrput raw status */

#define DMA_HTF_INT_RAW_HTF_RAW14_DPos  (14U)
#define DMA_HTF_INT_RAW_RAW14_Pos       DMA_HTF_INT_RAW_HTF_RAW14_DPos
#define DMA_HTF_INT_RAW_RAW14_Msk       (0x01UL <<DMA_HTF_INT_RAW_RAW14_Pos)                   /* 0x00004000 */
#define DMA_HTF_INT_RAW_RAW14           DMA_HTF_INT_RAW_RAW14_Msk                              /* DMA channel 14 half tranfer interrput raw status */

#define DMA_HTF_INT_RAW_HTF_RAW15_DPos  (15U)
#define DMA_HTF_INT_RAW_RAW15_Pos       DMA_HTF_INT_RAW_HTF_RAW15_DPos
#define DMA_HTF_INT_RAW_RAW15_Msk       (0x01UL <<DMA_HTF_INT_RAW_RAW15_Pos)                   /* 0x00008000 */
#define DMA_HTF_INT_RAW_RAW15           DMA_HTF_INT_RAW_RAW15_Msk                              /* DMA channel 15 half tranfer interrput raw status */


/******************  Bits definition for DMA_HTF_INT_FORCE register  *****************/
#define DMA_HTF_INT_FORCE_FORCE0_DPos   (0U)
#define DMA_HTF_INT_FORCE_FORCE0_Pos    DMA_HTF_INT_FORCE_FORCE0_DPos
#define DMA_HTF_INT_FORCE_FORCE0_Msk    (0x01UL <<DMA_HTF_INT_FORCE_FORCE0_Pos)                    /* 0x00000001 */
#define DMA_HTF_INT_FORCE_FORCE0        DMA_HTF_INT_FORCE_FORCE0_Msk                               /* DMA channel 0 half tranfer interrput force */

#define DMA_HTF_INT_FORCE_FORCE1_DPos   (1U)
#define DMA_HTF_INT_FORCE_FORCE1_Pos    DMA_HTF_INT_FORCE_FORCE1_DPos
#define DMA_HTF_INT_FORCE_FORCE1_Msk    (0x01UL <<DMA_HTF_INT_FORCE_FORCE1_Pos)                    /* 0x00000002 */
#define DMA_HTF_INT_FORCE_FORCE1        DMA_HTF_INT_FORCE_FORCE1_Msk                               /* DMA channel 1 half tranfer interrput force */

#define DMA_HTF_INT_FORCE_FORCE2_DPos   (2U)
#define DMA_HTF_INT_FORCE_FORCE2_Pos    DMA_HTF_INT_FORCE_FORCE2_DPos
#define DMA_HTF_INT_FORCE_FORCE2_Msk    (0x01UL <<DMA_HTF_INT_FORCE_FORCE2_Pos)                    /* 0x00000004 */
#define DMA_HTF_INT_FORCE_FORCE2        DMA_HTF_INT_FORCE_FORCE2_Msk                               /* DMA channel 2 half tranfer interrput force */

#define DMA_HTF_INT_FORCE_FORCE6_DPos   (6U)
#define DMA_HTF_INT_FORCE_FORCE6_Pos    DMA_HTF_INT_FORCE_FORCE6_DPos
#define DMA_HTF_INT_FORCE_FORCE6_Msk    (0x01UL <<DMA_HTF_INT_FORCE_FORCE6_Pos)                    /* 0x00000040 */
#define DMA_HTF_INT_FORCE_FORCE6        DMA_HTF_INT_FORCE_FORCE6_Msk                               /* DMA channel 6 half tranfer interrput force */

#define DMA_HTF_INT_FORCE_FORCE4_DPos   (4U)
#define DMA_HTF_INT_FORCE_FORCE4_Pos    DMA_HTF_INT_FORCE_FORCE4_DPos
#define DMA_HTF_INT_FORCE_FORCE4_Msk    (0x01UL <<DMA_HTF_INT_FORCE_FORCE4_Pos)                    /* 0x00000010 */
#define DMA_HTF_INT_FORCE_FORCE4        DMA_HTF_INT_FORCE_FORCE4_Msk                               /* DMA channel 4 half tranfer interrput force */

#define DMA_HTF_INT_FORCE_FORCE5_DPos   (5U)
#define DMA_HTF_INT_FORCE_FORCE5_Pos    DMA_HTF_INT_FORCE_FORCE5_DPos
#define DMA_HTF_INT_FORCE_FORCE5_Msk    (0x01UL <<DMA_HTF_INT_FORCE_FORCE5_Pos)                    /* 0x00000020 */
#define DMA_HTF_INT_FORCE_FORCE5        DMA_HTF_INT_FORCE_FORCE5_Msk                               /* DMA channel 5 half tranfer interrput force */


#define DMA_HTF_INT_FORCE_FORCE7_DPos   (7U)
#define DMA_HTF_INT_FORCE_FORCE7_Pos    DMA_HTF_INT_FORCE_FORCE7_DPos
#define DMA_HTF_INT_FORCE_FORCE7_Msk    (0x01UL <<DMA_HTF_INT_FORCE_FORCE7_Pos)                    /* 0x00000080 */
#define DMA_HTF_INT_FORCE_FORCE7        DMA_HTF_INT_FORCE_FORCE7_Msk                               /* DMA channel 7 half tranfer interrput force */

#define DMA_HTF_INT_FORCE_FORCE8_DPos   (8U)
#define DMA_HTF_INT_FORCE_FORCE8_Pos    DMA_HTF_INT_FORCE_FORCE8_DPos
#define DMA_HTF_INT_FORCE_FORCE8_Msk    (0x01UL <<DMA_HTF_INT_FORCE_FORCE8_Pos)                    /* 0x00000100 */
#define DMA_HTF_INT_FORCE_FORCE8        DMA_HTF_INT_FORCE_FORCE8_Msk                               /* DMA channel 8 half tranfer interrput force */

#define DMA_HTF_INT_FORCE_FORCE9_DPos   (9U)
#define DMA_HTF_INT_FORCE_FORCE9_Pos    DMA_HTF_INT_FORCE_FORCE9_DPos
#define DMA_HTF_INT_FORCE_FORCE9_Msk    (0x01UL <<DMA_HTF_INT_FORCE_FORCE9_Pos)                    /* 0x00000200 */
#define DMA_HTF_INT_FORCE_FORCE9        DMA_HTF_INT_FORCE_FORCE9_Msk                               /* DMA channel 9 half tranfer interrput force */

#define DMA_HTF_INT_FORCE_FORCE10_DPos  (10U)
#define DMA_HTF_INT_FORCE_FORCE10_Pos   DMA_HTF_INT_FORCE_FORCE10_DPos
#define DMA_HTF_INT_FORCE_FORCE10_Msk   (0x01UL <<DMA_HTF_INT_FORCE_FORCE10_Pos)                   /* 0x00000400 */
#define DMA_HTF_INT_FORCE_FORCE10       DMA_HTF_INT_FORCE_FORCE10_Msk                              /* DMA channel 10 half tranfer interrput force */

#define DMA_HTF_INT_FORCE_FORCE11_DPos  (11U)
#define DMA_HTF_INT_FORCE_FORCE11_Pos   DMA_HTF_INT_FORCE_FORCE11_DPos
#define DMA_HTF_INT_FORCE_FORCE11_Msk   (0x01UL <<DMA_HTF_INT_FORCE_FORCE11_Pos)                   /* 0x00000800 */
#define DMA_HTF_INT_FORCE_FORCE11       DMA_HTF_INT_FORCE_FORCE11_Msk                              /* DMA channel 11 half tranfer interrput force */

#define DMA_HTF_INT_FORCE_FORCE12_DPos  (12U)
#define DMA_HTF_INT_FORCE_FORCE12_Pos   DMA_HTF_INT_FORCE_FORCE12_DPos
#define DMA_HTF_INT_FORCE_FORCE12_Msk   (0x01UL <<DMA_HTF_INT_FORCE_FORCE12_Pos)                   /* 0x00001000 */
#define DMA_HTF_INT_FORCE_FORCE12       DMA_HTF_INT_FORCE_FORCE12_Msk                              /* DMA channel 12 half tranfer interrput force */

#define DMA_HTF_INT_FORCE_FORCE13_DPos  (13U)
#define DMA_HTF_INT_FORCE_FORCE13_Pos   DMA_HTF_INT_FORCE_FORCE13_DPos
#define DMA_HTF_INT_FORCE_FORCE13_Msk   (0x01UL <<DMA_HTF_INT_FORCE_FORCE13_Pos)                   /* 0x00002000 */
#define DMA_HTF_INT_FORCE_FORCE13       DMA_HTF_INT_FORCE_FORCE13_Msk                              /* DMA channel 13 half tranfer interrput force */

#define DMA_HTF_INT_FORCE_FORCE14_DPos  (14U)
#define DMA_HTF_INT_FORCE_FORCE14_Pos   DMA_HTF_INT_FORCE_FORCE14_DPos
#define DMA_HTF_INT_FORCE_FORCE14_Msk   (0x01UL <<DMA_HTF_INT_FORCE_FORCE14_Pos)                   /* 0x00004000 */
#define DMA_HTF_INT_FORCE_FORCE14       DMA_HTF_INT_FORCE_FORCE14_Msk                              /* DMA channel 14 half tranfer interrput force */

#define DMA_HTF_INT_FORCE_FORCE15_DPos  (15U)
#define DMA_HTF_INT_FORCE_FORCE15_Pos   DMA_HTF_INT_FORCE_FORCE15_DPos
#define DMA_HTF_INT_FORCE_FORCE15_Msk   (0x01UL <<DMA_HTF_INT_FORCE_FORCE15_Pos)                   /* 0x00008000 */
#define DMA_HTF_INT_FORCE_FORCE15       DMA_HTF_INT_FORCE_FORCE15_Msk                              /* DMA channel 15 half tranfer interrput force */

/******************  Bits definition for DMA_HTF_INT_MASK register  *****************/
#define DMA_HTF_INT_MASK_MASK0_DPos   (0U)
#define DMA_HTF_INT_MASK_MASK0_Pos    DMA_HTF_INT_MASK_MASK0_DPos
#define DMA_HTF_INT_MASK_MASK0_Msk    (0x01UL <<DMA_HTF_INT_MASK_MASK0_Pos)                    /* 0x00000001 */
#define DMA_HTF_INT_MASK_MASK0        DMA_HTF_INT_MASK_MASK0_Msk                               /* DMA channel 0 half tranfer interrput mask */

#define DMA_HTF_INT_MASK_MASK1_DPos   (1U)
#define DMA_HTF_INT_MASK_MASK1_Pos    DMA_HTF_INT_MASK_MASK1_DPos
#define DMA_HTF_INT_MASK_MASK1_Msk    (0x01UL <<DMA_HTF_INT_MASK_MASK1_Pos)                    /* 0x00000002 */
#define DMA_HTF_INT_MASK_MASK1        DMA_HTF_INT_MASK_MASK1_Msk                               /* DMA channel 1 half tranfer interrput mask */

#define DMA_HTF_INT_MASK_MASK2_DPos   (2U)
#define DMA_HTF_INT_MASK_MASK2_Pos    DMA_HTF_INT_MASK_MASK2_DPos
#define DMA_HTF_INT_MASK_MASK2_Msk    (0x01UL <<DMA_HTF_INT_MASK_MASK2_Pos)                    /* 0x00000004 */
#define DMA_HTF_INT_MASK_MASK2        DMA_HTF_INT_MASK_MASK2_Msk                               /* DMA channel 2 half tranfer interrput mask */

#define DMA_HTF_INT_MASK_MASK3_DPos   (3U)
#define DMA_HTF_INT_MASK_MASK3_Pos    DMA_HTF_INT_MASK_MASK3_DPos
#define DMA_HTF_INT_MASK_MASK3_Msk    (0x01UL <<DMA_HTF_INT_MASK_MASK3_Pos)                    /* 0x00000008 */
#define DMA_HTF_INT_MASK_MASK3        DMA_HTF_INT_MASK_MASK3_Msk                               /* DMA channel 3 half tranfer interrput mask */

#define DMA_HTF_INT_MASK_MASK4_DPos   (4U)
#define DMA_HTF_INT_MASK_MASK4_Pos    DMA_HTF_INT_MASK_MASK4_DPos
#define DMA_HTF_INT_MASK_MASK4_Msk    (0x01UL <<DMA_HTF_INT_MASK_MASK4_Pos)                    /* 0x00000010 */
#define DMA_HTF_INT_MASK_MASK4        DMA_HTF_INT_MASK_MASK4_Msk                               /* DMA channel 4 half tranfer interrput mask */

#define DMA_HTF_INT_MASK_MASK5_DPos   (5U)
#define DMA_HTF_INT_MASK_MASK5_Pos    DMA_HTF_INT_MASK_MASK5_DPos
#define DMA_HTF_INT_MASK_MASK5_Msk    (0x01UL <<DMA_HTF_INT_MASK_MASK5_Pos)                    /* 0x00000020 */
#define DMA_HTF_INT_MASK_MASK5        DMA_HTF_INT_MASK_MASK5_Msk                               /* DMA channel 5 half tranfer interrput mask */

#define DMA_HTF_INT_MASK_MASK6_DPos   (6U)
#define DMA_HTF_INT_MASK_MASK6_Pos    DMA_HTF_INT_MASK_MASK6_DPos
#define DMA_HTF_INT_MASK_MASK6_Msk    (0x01UL <<DMA_HTF_INT_MASK_MASK6_Pos)                    /* 0x00000040 */
#define DMA_HTF_INT_MASK_MASK6        DMA_HTF_INT_MASK_MASK6_Msk                               /* DMA channel 6 half tranfer interrput mask */

#define DMA_HTF_INT_MASK_MASK7_DPos   (7U)
#define DMA_HTF_INT_MASK_MASK7_Pos    DMA_HTF_INT_MASK_MASK7_DPos
#define DMA_HTF_INT_MASK_MASK7_Msk    (0x01UL <<DMA_HTF_INT_MASK_MASK7_Pos)                    /* 0x00000080 */
#define DMA_HTF_INT_MASK_MASK7        DMA_HTF_INT_MASK_MASK7_Msk                               /* DMA channel 7 half tranfer interrput mask */

#define DMA_HTF_INT_MASK_MASK8_DPos   (8U)
#define DMA_HTF_INT_MASK_MASK8_Pos    DMA_HTF_INT_MASK_MASK8_DPos
#define DMA_HTF_INT_MASK_MASK8_Msk    (0x01UL <<DMA_HTF_INT_MASK_MASK8_Pos)                    /* 0x00000100 */
#define DMA_HTF_INT_MASK_MASK8        DMA_HTF_INT_MASK_MASK8_Msk                               /* DMA channel 8 half tranfer interrput mask */

#define DMA_HTF_INT_MASK_MASK9_DPos   (9U)
#define DMA_HTF_INT_MASK_MASK9_Pos    DMA_HTF_INT_MASK_MASK9_DPos
#define DMA_HTF_INT_MASK_MASK9_Msk    (0x01UL <<DMA_HTF_INT_MASK_MASK9_Pos)                    /* 0x00000200 */
#define DMA_HTF_INT_MASK_MASK9        DMA_HTF_INT_MASK_MASK9_Msk                               /* DMA channel 9 half tranfer interrput mask */

#define DMA_HTF_INT_MASK_MASK10_DPos  (10U)
#define DMA_HTF_INT_MASK_MASK10_Pos   DMA_HTF_INT_MASK_MASK10_DPos
#define DMA_HTF_INT_MASK_MASK10_Msk   (0x01UL <<DMA_HTF_INT_MASK_MASK10_Pos)                   /* 0x00000400 */
#define DMA_HTF_INT_MASK_MASK10       DMA_HTF_INT_MASK_MASK10_Msk                              /* DMA channel 10 half tranfer interrput mask */

#define DMA_HTF_INT_MASK_MASK11_DPos  (11U)
#define DMA_HTF_INT_MASK_MASK11_Pos   DMA_HTF_INT_MASK_MASK11_DPos
#define DMA_HTF_INT_MASK_MASK11_Msk   (0x01UL <<DMA_HTF_INT_MASK_MASK11_Pos)                   /* 0x00000800 */
#define DMA_HTF_INT_MASK_MASK11       DMA_HTF_INT_MASK_MASK11_Msk                              /* DMA channel 11 half tranfer interrput mask */

#define DMA_HTF_INT_MASK_MASK12_DPos  (12U)
#define DMA_HTF_INT_MASK_MASK12_Pos   DMA_HTF_INT_MASK_MASK12_DPos
#define DMA_HTF_INT_MASK_MASK12_Msk   (0x01UL <<DMA_HTF_INT_MASK_MASK12_Pos)                   /* 0x00001000 */
#define DMA_HTF_INT_MASK_MASK12       DMA_HTF_INT_MASK_MASK12_Msk                              /* DMA channel 12 half tranfer interrput mask */

#define DMA_HTF_INT_MASK_MASK13_DPos  (13U)
#define DMA_HTF_INT_MASK_MASK13_Pos   DMA_HTF_INT_MASK_MASK13_DPos
#define DMA_HTF_INT_MASK_MASK13_Msk   (0x01UL <<DMA_HTF_INT_MASK_MASK13_Pos)                   /* 0x00002000 */
#define DMA_HTF_INT_MASK_MASK13       DMA_HTF_INT_MASK_MASK13_Msk                              /* DMA channel 13 half tranfer interrput mask */

#define DMA_HTF_INT_MASK_MASK14_DPos  (14U)
#define DMA_HTF_INT_MASK_MASK14_Pos   DMA_HTF_INT_MASK_MASK14_DPos
#define DMA_HTF_INT_MASK_MASK14_Msk   (0x01UL <<DMA_HTF_INT_MASK_MASK14_Pos)                   /* 0x00004000 */
#define DMA_HTF_INT_MASK_MASK14       DMA_HTF_INT_MASK_MASK14_Msk                              /* DMA channel 14 half tranfer interrput mask */

#define DMA_HTF_INT_MASK_MASK15_DPos  (15U)
#define DMA_HTF_INT_MASK_MASK15_Pos   DMA_HTF_INT_MASK_MASK15_DPos
#define DMA_HTF_INT_MASK_MASK15_Msk   (0x01UL <<DMA_HTF_INT_MASK_MASK15_Pos)                   /* 0x00008000 */
#define DMA_HTF_INT_MASK_MASK15       DMA_HTF_INT_MASK_MASK15_Msk                              /* DMA channel 15 half tranfer interrput mask */

/******************  Bits definition for DMA_HTF_INT_STATUS register  *****************/
#define DMA_HTF_INT_STATUS_STATUS0_DPos   (0U)
#define DMA_HTF_INT_STATUS_STAT0_Pos      DMA_HTF_INT_STATUS_STATUS0_DPos
#define DMA_HTF_INT_STATUS_STAT0_Msk      (0x01UL <<DMA_HTF_INT_STATUS_STAT0_Pos)                    /* 0x00000001 */
#define DMA_HTF_INT_STATUS_STAT0          DMA_HTF_INT_STATUS_STAT0_Msk                               /* DMA channel 0 half tranfer interrput status */

#define DMA_HTF_INT_STATUS_STATUS1_DPos   (1U)
#define DMA_HTF_INT_STATUS_STAT1_Pos      DMA_HTF_INT_STATUS_STATUS1_DPos
#define DMA_HTF_INT_STATUS_STAT1_Msk      (0x01UL <<DMA_HTF_INT_STATUS_STAT1_Pos)                    /* 0x00000002 */
#define DMA_HTF_INT_STATUS_STAT1          DMA_HTF_INT_STATUS_STAT1_Msk                               /* DMA channel 1 half tranfer interrput status */

#define DMA_HTF_INT_STATUS_STATUS2_DPos   (2U)
#define DMA_HTF_INT_STATUS_STAT2_Pos      DMA_HTF_INT_STATUS_STATUS2_DPos
#define DMA_HTF_INT_STATUS_STAT2_Msk      (0x01UL <<DMA_HTF_INT_STATUS_STAT2_Pos)                    /* 0x00000004 */
#define DMA_HTF_INT_STATUS_STAT2          DMA_HTF_INT_STATUS_STAT2_Msk                               /* DMA channel 2 half tranfer interrput status */

#define DMA_HTF_INT_STATUS_STATUS6_DPos   (6U)
#define DMA_HTF_INT_STATUS_STAT6_Pos      DMA_HTF_INT_STATUS_STATUS6_DPos
#define DMA_HTF_INT_STATUS_STAT6_Msk      (0x01UL <<DMA_HTF_INT_STATUS_STAT6_Pos)                    /* 0x00000040 */
#define DMA_HTF_INT_STATUS_STAT6          DMA_HTF_INT_STATUS_STAT6_Msk                               /* DMA channel 6 half tranfer interrput status */

#define DMA_HTF_INT_STATUS_STATUS4_DPos   (4U)
#define DMA_HTF_INT_STATUS_STAT4_Pos      DMA_HTF_INT_STATUS_STATUS4_DPos
#define DMA_HTF_INT_STATUS_STAT4_Msk      (0x01UL <<DMA_HTF_INT_STATUS_STAT4_Pos)                    /* 0x00000010 */
#define DMA_HTF_INT_STATUS_STAT4          DMA_HTF_INT_STATUS_STAT4_Msk                               /* DMA channel 4 half tranfer interrput status */

#define DMA_HTF_INT_STATUS_STATUS5_DPos   (5U)
#define DMA_HTF_INT_STATUS_STAT5_Pos      DMA_HTF_INT_STATUS_STATUS5_DPos
#define DMA_HTF_INT_STATUS_STAT5_Msk      (0x01UL <<DMA_HTF_INT_STATUS_STAT5_Pos)                    /* 0x00000020 */
#define DMA_HTF_INT_STATUS_STAT5          DMA_HTF_INT_STATUS_STAT5_Msk                               /* DMA channel 5 half tranfer interrput status */


#define DMA_HTF_INT_STATUS_STATUS7_DPos   (7U)
#define DMA_HTF_INT_STATUS_STAT7_Pos      DMA_HTF_INT_STATUS_STATUS7_DPos
#define DMA_HTF_INT_STATUS_STAT7_Msk      (0x01UL <<DMA_HTF_INT_STATUS_STAT7_Pos)                    /* 0x00000080 */
#define DMA_HTF_INT_STATUS_STAT7          DMA_HTF_INT_STATUS_STAT7_Msk                               /* DMA channel 7 half tranfer interrput status */

#define DMA_HTF_INT_STATUS_STATUS8_DPos   (8U)
#define DMA_HTF_INT_STATUS_STAT8_Pos      DMA_HTF_INT_STATUS_STATUS8_DPos
#define DMA_HTF_INT_STATUS_STAT8_Msk      (0x01UL <<DMA_HTF_INT_STATUS_STAT8_Pos)                    /* 0x00000100 */
#define DMA_HTF_INT_STATUS_STAT8          DMA_HTF_INT_STATUS_STAT8_Msk                               /* DMA channel 8 half tranfer interrput status */

#define DMA_HTF_INT_STATUS_STATUS9_DPos   (9U)
#define DMA_HTF_INT_STATUS_STAT9_Pos      DMA_HTF_INT_STATUS_STATUS9_DPos
#define DMA_HTF_INT_STATUS_STAT9_Msk      (0x01UL <<DMA_HTF_INT_STATUS_STAT9_Pos)                    /* 0x00000200 */
#define DMA_HTF_INT_STATUS_STAT9          DMA_HTF_INT_STATUS_STAT9_Msk                               /* DMA channel 9 half tranfer interrput status */

#define DMA_HTF_INT_STATUS_STATUS10_DPos  (10U)
#define DMA_HTF_INT_STATUS_STAT10_Pos     DMA_HTF_INT_STATUS_STATUS10_DPos
#define DMA_HTF_INT_STATUS_STAT10_Msk     (0x01UL <<DMA_HTF_INT_STATUS_STAT10_Pos)                   /* 0x00000400 */
#define DMA_HTF_INT_STATUS_STAT10         DMA_HTF_INT_STATUS_STAT10_Msk                              /* DMA channel 10 half tranfer interrput status */

#define DMA_HTF_INT_STATUS_STATUS11_DPos  (11U)
#define DMA_HTF_INT_STATUS_STAT11_Pos     DMA_HTF_INT_STATUS_STATUS11_DPos
#define DMA_HTF_INT_STATUS_STAT11_Msk     (0x01UL <<DMA_HTF_INT_STATUS_STAT11_Pos)                   /* 0x00000800 */
#define DMA_HTF_INT_STATUS_STAT11         DMA_HTF_INT_STATUS_STAT11_Msk                              /* DMA channel 11 half tranfer interrput status */

#define DMA_HTF_INT_STATUS_STATUS12_DPos  (12U)
#define DMA_HTF_INT_STATUS_STAT12_Pos     DMA_HTF_INT_STATUS_STATUS12_DPos
#define DMA_HTF_INT_STATUS_STAT12_Msk     (0x01UL <<DMA_HTF_INT_STATUS_STAT12_Pos)                   /* 0x00001000 */
#define DMA_HTF_INT_STATUS_STAT12         DMA_HTF_INT_STATUS_STAT12_Msk                              /* DMA channel 12 half tranfer interrput status */

#define DMA_HTF_INT_STATUS_STATUS13_DPos  (13U)
#define DMA_HTF_INT_STATUS_STAT13_Pos     DMA_HTF_INT_STATUS_STATUS13_DPos
#define DMA_HTF_INT_STATUS_STAT13_Msk     (0x01UL <<DMA_HTF_INT_STATUS_STAT13_Pos)                   /* 0x00002000 */
#define DMA_HTF_INT_STATUS_STAT13         DMA_HTF_INT_STATUS_STAT13_Msk                              /* DMA channel 13 half tranfer interrput status */

#define DMA_HTF_INT_STATUS_STATUS14_DPos  (14U)
#define DMA_HTF_INT_STATUS_STAT14_Pos     DMA_HTF_INT_STATUS_STATUS14_DPos
#define DMA_HTF_INT_STATUS_STAT14_Msk     (0x01UL <<DMA_HTF_INT_STATUS_STAT14_Pos)                   /* 0x00004000 */
#define DMA_HTF_INT_STATUS_STAT14         DMA_HTF_INT_STATUS_STAT14_Msk                              /* DMA channel 14 half tranfer interrput status */

#define DMA_HTF_INT_STATUS_STATUS15_DPos  (15U)
#define DMA_HTF_INT_STATUS_STAT15_Pos     DMA_HTF_INT_STATUS_STATUS15_DPos
#define DMA_HTF_INT_STATUS_STAT15_Msk     (0x01UL <<DMA_HTF_INT_STATUS_STAT15_Pos)                   /* 0x00008000 */
#define DMA_HTF_INT_STATUS_STAT15         DMA_HTF_INT_STATUS_STAT15_Msk                              /* DMA channel 15 half tranfer interrput status */


/******************  Bits definition for DMA_WDG_INT_RAW register  *****************/
#define DMA_WDG_INT_RAW_RAW_DPos         (0U)
#define DMA_WDG_INT_RAW_RAW_Pos          DMA_WDG_INT_RAW_RAW_DPos
#define DMA_WDG_INT_RAW_RAW_Msk          (0x01UL <<DMA_WDG_INT_RAW_RAW_Pos)                         /* 0x00000001 */
#define DMA_WDG_INT_RAW_RAW              DMA_WDG_INT_RAW_RAW_Msk                                    /* DMA  watch dog interrput raw status */

/******************  Bits definition for DMA_WDG_INT_FORCE register  *****************/
#define DMA_WDG_INT_FORCE_FORCE_DPos     (0U)
#define DMA_WDG_INT_FORCE_FORCE_Pos      DMA_WDG_INT_FORCE_FORCE_DPos
#define DMA_WDG_INT_FORCE_FORCE_Msk      (0x01UL <<DMA_WDG_INT_FORCE_FORCE_Pos)                     /* 0x00000001 */
#define DMA_WDG_INT_FORCE_FORCE          DMA_WDG_INT_FORCE_FORCE_Msk                                /* DMA  watch dog interrput force */

/******************  Bits definition for DMA_WDG_INT_MASK register  *****************/
#define DMA_WDG_INT_MASK_MASK_DPos       (0U)
#define DMA_WDG_INT_MASK_MASK_Pos        DMA_WDG_INT_MASK_MASK_DPos
#define DMA_WDG_INT_MASK_MASK_Msk        (0x01UL <<DMA_WDG_INT_MASK_MASK_Pos)                       /* 0x00000001 */
#define DMA_WDG_INT_MASK_MASK            DMA_WDG_INT_MASK_MASK_Msk                                  /* DMA  watch dog interrput mask */

/******************  Bits definition for DMA_WDG_INT_STATUS register  *****************/
#define DMA_WDG_INT_STATUS_STATUS_DPos   (0U)
#define DMA_WDG_INT_STATUS_STAT_Pos      DMA_WDG_INT_STATUS_STATUS_DPos
#define DMA_WDG_INT_STATUS_STAT_Msk      (0x01UL <<DMA_WDG_INT_STATUS_STAT_Pos)                    /* 0x00000001 */
#define DMA_WDG_INT_STATUS_STAT          DMA_WDG_INT_STATUS_STAT_Msk                               /* DMA watch dog interrput status */

/* @name SMU register bits definition */
/******************  Bits definition for SMU_PLLCFGR register  *****************/
#define SMU_PLLCFGR_pllDivN_DPos        (0U)
#define SMU_PLLCFGR_PLLN_Pos            SMU_PLLCFGR_pllDivN_DPos
#define SMU_PLLCFGR_PLLN_Msk            (0x3FUL << SMU_PLLCFGR_PLLN_Pos)        /* 0x0000003F */
#define SMU_PLLCFGR_PLLN                SMU_PLLCFGR_PLLN_Msk                    /* PLLN[5:0] bits (Input frequency division control signal) */
#define SMU_PLLCFGR_PLLN_0              (0x01UL << SMU_PLLCFGR_PLLN_Pos)        /* 0x00000001 */
#define SMU_PLLCFGR_PLLN_1              (0x02UL << SMU_PLLCFGR_PLLN_Pos)        /* 0x00000002 */
#define SMU_PLLCFGR_PLLN_2              (0x04UL << SMU_PLLCFGR_PLLN_Pos)        /* 0x00000004 */
#define SMU_PLLCFGR_PLLN_3              (0x08UL << SMU_PLLCFGR_PLLN_Pos)        /* 0x00000008 */
#define SMU_PLLCFGR_PLLN_4              (0x10UL << SMU_PLLCFGR_PLLN_Pos)        /* 0x00000010 */
#define SMU_PLLCFGR_PLLN_5              (0x20UL << SMU_PLLCFGR_PLLN_Pos)        /* 0x00000020 */

#define SMU_PLLCFGR_pllDivF_DPos        (6U)
#define SMU_PLLCFGR_PLLF_Pos            SMU_PLLCFGR_pllDivF_DPos
#define SMU_PLLCFGR_PLLF_Msk            (0x1FFUL << SMU_PLLCFGR_PLLF_Pos)       /* 0x00007FC0 */
#define SMU_PLLCFGR_PLLF                SMU_PLLCFGR_PLLF_Msk                    /* PLLF[8:0] bits (Feedback clock control signal) */
#define SMU_PLLCFGR_PLLF_0              (0x01UL << SMU_PLLCFGR_PLLF_Pos)        /* 0x00000040 */
#define SMU_PLLCFGR_PLLF_1              (0x02UL << SMU_PLLCFGR_PLLF_Pos)        /* 0x00000080 */
#define SMU_PLLCFGR_PLLF_2              (0x04UL << SMU_PLLCFGR_PLLF_Pos)        /* 0x00000100 */
#define SMU_PLLCFGR_PLLF_3              (0x08UL << SMU_PLLCFGR_PLLF_Pos)        /* 0x00000200 */
#define SMU_PLLCFGR_PLLF_4              (0x10UL << SMU_PLLCFGR_PLLF_Pos)        /* 0x00000400 */
#define SMU_PLLCFGR_PLLF_5              (0x20UL << SMU_PLLCFGR_PLLF_Pos)        /* 0x00000800 */
#define SMU_PLLCFGR_PLLF_6              (0x40UL << SMU_PLLCFGR_PLLF_Pos)        /* 0x00001000 */
#define SMU_PLLCFGR_PLLF_7              (0x80UL << SMU_PLLCFGR_PLLF_Pos)        /* 0x00002000 */
#define SMU_PLLCFGR_PLLF_8              (0x100UL << SMU_PLLCFGR_PLLF_Pos)       /* 0x00004000 */

#define SMU_PLLCFGR_pllDivQ_DPos        (15U)
#define SMU_PLLCFGR_PLLQ_Pos            SMU_PLLCFGR_pllDivQ_DPos
#define SMU_PLLCFGR_PLLQ_Msk            (0xFUL << SMU_PLLCFGR_PLLQ_Pos)         /* 0x00078000 */
#define SMU_PLLCFGR_PLLQ                SMU_PLLCFGR_PLLQ_Msk                    /* PLLQ[4:0] bits (Output frequency division control signal of CLK_Q) */
#define SMU_PLLCFGR_PLLQ_0              (0x01UL << SMU_PLLCFGR_PLLQ_Pos)        /* 0x00008000 */
#define SMU_PLLCFGR_PLLQ_1              (0x02UL << SMU_PLLCFGR_PLLQ_Pos)        /* 0x00010000 */
#define SMU_PLLCFGR_PLLQ_2              (0x04UL << SMU_PLLCFGR_PLLQ_Pos)        /* 0x00020000 */
#define SMU_PLLCFGR_PLLQ_3              (0x08UL << SMU_PLLCFGR_PLLQ_Pos)        /* 0x00040000 */

#define SMU_PLLCFGR_pllDivR_DPos        (19U)
#define SMU_PLLCFGR_PLLR_Pos            SMU_PLLCFGR_pllDivR_DPos
#define SMU_PLLCFGR_PLLR_Msk            (0x7UL << SMU_PLLCFGR_PLLR_Pos)         /* 0x00380000 */
#define SMU_PLLCFGR_PLLR                SMU_PLLCFGR_PLLR_Msk                    /* PLLQ[3:0] bits (Output frequency division control signal of CLK_R) */
#define SMU_PLLCFGR_PLLR_0              (0x01UL << SMU_PLLCFGR_PLLR_Pos)        /* 0x00080000 */
#define SMU_PLLCFGR_PLLR_1              (0x02UL << SMU_PLLCFGR_PLLR_Pos)        /* 0x00100000 */
#define SMU_PLLCFGR_PLLR_2              (0x04UL << SMU_PLLCFGR_PLLR_Pos)        /* 0x00200000 */

#define SMU_PLLCFGR_pllEn_DPos          (22U)
#define SMU_PLLCFGR_PLLEN_Pos           SMU_PLLCFGR_pllEn_DPos
#define SMU_PLLCFGR_PLLEN_Msk           (0x1UL << SMU_PLLCFGR_PLLEN_Pos)        /* 0x00400000 */
#define SMU_PLLCFGR_PLLEN               SMU_PLLCFGR_PLLEN_Msk                   /* PLL clock enable */

#define SMU_PLLCFGR_pllRstn_DPos        (23U)
#define SMU_PLLCFGR_PLLRST_Pos          SMU_PLLCFGR_pllRstn_DPos
#define SMU_PLLCFGR_PLLRST_Msk          (0x1UL << SMU_PLLCFGR_PLLRST_Pos)       /* 0x00800000 */
#define SMU_PLLCFGR_PLLRST              SMU_PLLCFGR_PLLRST_Msk                  /* PLL clock reset signal */

#define SMU_PLLCFGR_pllUpdate_DPos      (24U)
#define SMU_PLLCFGR_PLLUF_Pos           SMU_PLLCFGR_pllUpdate_DPos
#define SMU_PLLCFGR_PLLUF_Msk           (0x1UL << SMU_PLLCFGR_PLLUF_Pos)        /* 0x01000000 */
#define SMU_PLLCFGR_PLLUF               SMU_PLLCFGR_PLLUF_Msk                   /* Update PLL frequency enable */


/******************  Bits definition for SMU_FIRCCFGR register  *****************/
#define SMU_FIRCCFGR_fircTF_DPos        (0U)
#define SMU_FIRCCFGR_FIRCTF_Pos         SMU_FIRCCFGR_fircTF_DPos
#define SMU_FIRCCFGR_FIRCTF_Msk         (0x3FUL << SMU_FIRCCFGR_FIRCTF_Pos)     /* 0x0000003F */
#define SMU_FIRCCFGR_FIRCTF             SMU_FIRCCFGR_FIRCTF_Msk                 /* FIRCTF[5:0] bits (FIRC oscillator frequency adjustment) */
#define SMU_FIRCCFGR_FIRCTF_0           (0x01UL << SMU_FIRCCFGR_FIRCTF_Pos)     /* 0x00000001 */
#define SMU_FIRCCFGR_FIRCTF_1           (0x02UL << SMU_FIRCCFGR_FIRCTF_Pos)     /* 0x00000002 */
#define SMU_FIRCCFGR_FIRCTF_2           (0x04UL << SMU_FIRCCFGR_FIRCTF_Pos)     /* 0x00000004 */
#define SMU_FIRCCFGR_FIRCTF_3           (0x08UL << SMU_FIRCCFGR_FIRCTF_Pos)     /* 0x00000008 */
#define SMU_FIRCCFGR_FIRCTF_4           (0x10UL << SMU_FIRCCFGR_FIRCTF_Pos)     /* 0x00000010 */
#define SMU_FIRCCFGR_FIRCTF_5           (0x20UL << SMU_FIRCCFGR_FIRCTF_Pos)     /* 0x00000020 */

#define SMU_FIRCCFGR_fircPdOsc_DPos     (6U)
#define SMU_FIRCCFGR_FIRCON_Pos         SMU_FIRCCFGR_fircPdOsc_DPos
#define SMU_FIRCCFGR_FIRCON_Msk         (0x1UL << SMU_FIRCCFGR_FIRCON_Pos)      /* 0x00000040 */
#define SMU_FIRCCFGR_FIRCON             SMU_FIRCCFGR_FIRCON_Msk                 /* FIRC oscillator switch */

#define SMU_FIRCCFGR_fircRdy_DPos       (7U)
#define SMU_FIRCCFGR_FIRCRDY_Pos        SMU_FIRCCFGR_fircRdy_DPos
#define SMU_FIRCCFGR_FIRCRDY_Msk        (0x1UL << SMU_FIRCCFGR_FIRCRDY_Pos)     /* 0x00000080 */
#define SMU_FIRCCFGR_FIRCRDY            SMU_FIRCCFGR_FIRCRDY_Msk                /* FIRC oscillator preparation position */


/******************  Bits definition for SMU_BUSCFGR register  *****************/
#define SMU_BUSCFGR_pllClkSel_DPos      (0U)
#define SMU_BUSCFGR_PLLSEL_Pos          SMU_BUSCFGR_pllClkSel_DPos
#define SMU_BUSCFGR_PLLSEL_Msk          (0x1UL << SMU_BUSCFGR_PLLSEL_Pos)       /* 0x00000001 */
#define SMU_BUSCFGR_PLLSEL              SMU_BUSCFGR_PLLSEL_Msk                  /* PLL clock selection */

#define SMU_BUSCFGR_sysClkSel_DPos      (1U)
#define SMU_BUSCFGR_SYSSEL_Pos          SMU_BUSCFGR_sysClkSel_DPos
#define SMU_BUSCFGR_SYSSEL_Msk          (0x3UL << SMU_BUSCFGR_SYSSEL_Pos)       /* 0x00000006 */
#define SMU_BUSCFGR_SYSSEL              SMU_BUSCFGR_SYSSEL_Msk                  /* SYSSEL[1:0] bits (System clock selection) */
#define SMU_BUSCFGR_SYSSEL_0            (0x01UL << SMU_BUSCFGR_SYSSEL_Pos)      /* 0x00000002 */
#define SMU_BUSCFGR_SYSSEL_1            (0x02UL << SMU_BUSCFGR_SYSSEL_Pos)      /* 0x00000004 */

#define SMU_BUSCFGR_axi4Bus3Div_DPos    (9U)
#define SMU_BUSCFGR_AXI4BUS3DIV_Pos     SMU_BUSCFGR_axi4Bus3Div_DPos
#define SMU_BUSCFGR_AXI4BUS3DIV_Msk     (0x3UL << SMU_BUSCFGR_AXI4BUS3DIV_Pos)  /* 0x00000600 */
#define SMU_BUSCFGR_AXI4BUS3DIV         SMU_BUSCFGR_AXI4BUS3DIV_Msk             /* AXI4BUS3DIV[1:0] bits (Axi4Bus3 clock division ratio) */
#define SMU_BUSCFGR_AXI4BUS3DIV_0       (0x01UL << SMU_BUSCFGR_AXI4BUS3DIV_Pos) /* 0x00000200 */
#define SMU_BUSCFGR_AXI4BUS3DIV_1       (0x02UL << SMU_BUSCFGR_AXI4BUS3DIV_Pos) /* 0x00000400 */

#define SMU_BUSCFGR_apbBus0Div_DPos     (11U)
#define SMU_BUSCFGR_APBBUS0DIV_Pos      SMU_BUSCFGR_apbBus0Div_DPos
#define SMU_BUSCFGR_APBBUS0DIV_Msk      (0xFUL << SMU_BUSCFGR_APBBUS0DIV_Pos)   /* 0x00007800 */
#define SMU_BUSCFGR_APBBUS0DIV          SMU_BUSCFGR_APBBUS0DIV_Msk              /* APBBUS0DIV[3:0] bits (ApbBus0 clock division ratio) */
#define SMU_BUSCFGR_APBBUS0DIV_0        (0x01UL << SMU_BUSCFGR_APBBUS0DIV_Pos)  /* 0x00000800 */
#define SMU_BUSCFGR_APBBUS0DIV_1        (0x02UL << SMU_BUSCFGR_APBBUS0DIV_Pos)  /* 0x00001000 */
#define SMU_BUSCFGR_APBBUS0DIV_2        (0x04UL << SMU_BUSCFGR_APBBUS0DIV_Pos)  /* 0x00002000 */
#define SMU_BUSCFGR_APBBUS0DIV_3        (0x08UL << SMU_BUSCFGR_APBBUS0DIV_Pos)  /* 0x00004000 */

#define SMU_BUSCFGR_apbBus1Div_DPos     (15U)
#define SMU_BUSCFGR_APBBUS1DIV_Pos      SMU_BUSCFGR_apbBus1Div_DPos
#define SMU_BUSCFGR_APBBUS1DIV_Msk      (0xFUL << SMU_BUSCFGR_APBBUS1DIV_Pos)   /* 0x00078000 */
#define SMU_BUSCFGR_APBBUS1DIV          SMU_BUSCFGR_APBBUS1DIV_Msk              /* APBBUS1DIV[3:0] bits (ApbBus1 clock division ratio) */
#define SMU_BUSCFGR_APBBUS1DIV_0        (0x01UL << SMU_BUSCFGR_APBBUS1DIV_Pos)  /* 0x00008000 */
#define SMU_BUSCFGR_APBBUS1DIV_1        (0x02UL << SMU_BUSCFGR_APBBUS1DIV_Pos)  /* 0x00010000 */
#define SMU_BUSCFGR_APBBUS1DIV_2        (0x04UL << SMU_BUSCFGR_APBBUS1DIV_Pos)  /* 0x00020000 */
#define SMU_BUSCFGR_APBBUS1DIV_3        (0x08UL << SMU_BUSCFGR_APBBUS1DIV_Pos)  /* 0x00040000 */

#define SMU_BUSCFGR_canClkX2Div_DPos    (19U)
#define SMU_BUSCFGR_CANX2DIV_Pos        SMU_BUSCFGR_canClkX2Div_DPos
#define SMU_BUSCFGR_CANX2DIV_Msk        (0xFUL << SMU_BUSCFGR_CANX2DIV_Pos)     /* 0x00780000 */
#define SMU_BUSCFGR_CANX2DIV            SMU_BUSCFGR_CANX2DIV_Msk                /* CANX2DIV[3:0] bits (CANX2 clock division ratio) */
#define SMU_BUSCFGR_CANX2DIV_0          (0x01UL << SMU_BUSCFGR_CANX2DIV_Pos)    /* 0x00080000 */
#define SMU_BUSCFGR_CANX2DIV_1          (0x02UL << SMU_BUSCFGR_CANX2DIV_Pos)    /* 0x00100000 */
#define SMU_BUSCFGR_CANX2DIV_2          (0x04UL << SMU_BUSCFGR_CANX2DIV_Pos)    /* 0x00200000 */
#define SMU_BUSCFGR_CANX2DIV_3          (0x08UL << SMU_BUSCFGR_CANX2DIV_Pos)    /* 0x00400000 */


/******************  Bits definition for SMU_SR register  *****************/
#define SMU_SR_pllLock_DPos             (0U)
#define SMU_SR_PLLLOCK_Pos              SMU_SR_pllLock_DPos
#define SMU_SR_PLLLOCK_Msk              (0x1UL << SMU_SR_PLLLOCK_Pos)           /* 0x00000001 */
#define SMU_SR_PLLLOCK                  SMU_SR_PLLLOCK_Msk                      /* PLL clock lock */

#define SMU_SR_eflashInitDone_DPos      (1U)
#define SMU_SR_EFLASHICS_Pos            SMU_SR_eflashInitDone_DPos
#define SMU_SR_EFLASHICS_Msk            (0x1UL << SMU_SR_EFLASHICS_Pos)         /* 0x00000002 */
#define SMU_SR_EFLASHICS                SMU_SR_EFLASHICS_Msk                    /* EFLASH initialization completion signal */

#define SMU_SR_workState_DPos           (2U)
#define SMU_SR_MCUSM_Pos                SMU_SR_workState_DPos
#define SMU_SR_MCUSM_Msk                (0x3UL << SMU_SR_MCUSM_Pos)             /* 0x0000000C */
#define SMU_SR_MCUSM                    SMU_SR_MCUSM_Msk                        /* MCUSM[1:0] bits (MCU startup mode) */
#define SMU_SR_MCUSM_0                  (0x01UL << SMU_SR_MCUSM_Pos)            /* 0x00000004 */
#define SMU_SR_MCUSM_1                  (0x02UL << SMU_SR_MCUSM_Pos)            /* 0x00000008 */

#define SMU_SR_lowPower_DPos            (4U)
#define SMU_SR_LPWRF_Pos                SMU_SR_lowPower_DPos
#define SMU_SR_LPWRF_Msk                (0x1UL << SMU_SR_LPWRF_Pos)             /* 0x00000010 */
#define SMU_SR_LPWRF                    SMU_SR_LPWRF_Msk                        /* Low power mode flag */

#define SMU_SR_busState_DPos            (5U)
#define SMU_SR_BUSS_Pos                 SMU_SR_busState_DPos
#define SMU_SR_BUSS_Msk                 (0x7UL << SMU_SR_BUSS_Pos)              /* 0x000000E0 */
#define SMU_SR_BUSS                     SMU_SR_BUSS_Msk                         /* BUSS[2:0] bits (Bus state) */
#define SMU_SR_BUSS_0                   (0x01UL << SMU_SR_BUSS_Pos)             /* 0x00000020 */
#define SMU_SR_BUSS_1                   (0x02UL << SMU_SR_BUSS_Pos)             /* 0x00000040 */
#define SMU_SR_BUSS_2                   (0x04UL << SMU_SR_BUSS_Pos)             /* 0x00000080 */

#define SMU_SR_sramRdy_DPos             (8U)
#define SMU_SR_SRAMRDY_Pos              SMU_SR_sramRdy_DPos
#define SMU_SR_SRAMRDY_Msk              (0xFUL << SMU_SR_SRAMRDY_Pos)           /* 0x00000F00 */
#define SMU_SR_SRAMRDY                  SMU_SR_SRAMRDY_Msk                      /* SRAMRDY[3:0] bits (SRAM ready) */
#define SMU_SR_SRAMRDY_0                (0x01UL << SMU_SR_SRAMRDY_Pos)          /* 0x00000100 */
#define SMU_SR_SRAMRDY_1                (0x02UL << SMU_SR_SRAMRDY_Pos)          /* 0x00000200 */
#define SMU_SR_SRAMRDY_2                (0x04UL << SMU_SR_SRAMRDY_Pos)          /* 0x00000400 */
#define SMU_SR_SRAMRDY_3                (0x08UL << SMU_SR_SRAMRDY_Pos)          /* 0x00000800 */


/******************  Bits definition for SMU_AB0CFGR register  *****************/
#define SMU_AB0CFGR_QSPIEN_DPos         (0U)
#define SMU_AB0CFGR_QSPIEN_Pos          SMU_AB0CFGR_QSPIEN_DPos
#define SMU_AB0CFGR_QSPIEN_Msk          (0x1UL << SMU_AB0CFGR_QSPIEN_Pos)       /* 0x00000001 */
#define SMU_AB0CFGR_QSPIEN              SMU_AB0CFGR_QSPIEN_Msk                  /* QSPI clock enable */

#define SMU_AB0CFGR_QSPIRST_DPos        (1U)
#define SMU_AB0CFGR_QSPIRST_Pos         SMU_AB0CFGR_QSPIRST_DPos
#define SMU_AB0CFGR_QSPIRST_Msk         (0x1UL << SMU_AB0CFGR_QSPIRST_Pos)      /* 0x00000002 */
#define SMU_AB0CFGR_QSPIRST             SMU_AB0CFGR_QSPIRST_Msk                 /* QSPI reset */

#define SMU_AB0CFGR_EFLASHEN_DPos       (2U)
#define SMU_AB0CFGR_EFLASHEN_Pos        SMU_AB0CFGR_EFLASHEN_DPos
#define SMU_AB0CFGR_EFLASHEN_Msk        (0x1UL << SMU_AB0CFGR_EFLASHEN_Pos)     /* 0x00000004 */
#define SMU_AB0CFGR_EFLASHEN            SMU_AB0CFGR_EFLASHEN_Msk                /* EFLASH clock enable */

#define SMU_AB0CFGR_EFLASHRST_DPos      (3U)
#define SMU_AB0CFGR_EFLASHRST_Pos       SMU_AB0CFGR_EFLASHRST_DPos
#define SMU_AB0CFGR_EFLASHRST_Msk       (0x1UL << SMU_AB0CFGR_EFLASHRST_Pos)    /* 0x00000008 */
#define SMU_AB0CFGR_EFLASHRST           SMU_AB0CFGR_EFLASHRST_Msk               /* EFLASH reset */

#define SMU_AB0CFGR_QSPIUEN_DPos        (4U)
#define SMU_AB0CFGR_QSPIUEN_Pos         SMU_AB0CFGR_QSPIUEN_DPos
#define SMU_AB0CFGR_QSPIUEN_Msk         (0x1UL << SMU_AB0CFGR_QSPIUEN_Pos)      /* 0x00000010 */
#define SMU_AB0CFGR_QSPIUEN             SMU_AB0CFGR_QSPIUEN_Msk                 /* QSPI Clock update Enable */

#define SMU_AB0CFGR_EFLASHUEN_DPos      (5U)
#define SMU_AB0CFGR_EFLASHUEN_Pos       SMU_AB0CFGR_EFLASHUEN_DPos
#define SMU_AB0CFGR_EFLASHUEN_Msk       (0x1UL << SMU_AB0CFGR_EFLASHUEN_Pos)    /* 0x00000020 */
#define SMU_AB0CFGR_EFLASHUEN           SMU_AB0CFGR_EFLASHUEN_Msk               /* EFLASH clock update enable */


/******************  Bits definition for SMU_AB1CFGR register  *****************/
#define SMU_AB1CFGR_DMA0EN_DPos         (0U)
#define SMU_AB1CFGR_DMA0EN_Pos          SMU_AB1CFGR_DMA0EN_DPos
#define SMU_AB1CFGR_DMA0EN_Msk          (0x1UL << SMU_AB1CFGR_DMA0EN_Pos)       /* 0x00000001 */
#define SMU_AB1CFGR_DMA0EN              SMU_AB1CFGR_DMA0EN_Msk                  /* DMA0 clock enable */

#define SMU_AB1CFGR_DMA0RST_DPos        (1U)
#define SMU_AB1CFGR_DMA0RST_Pos         SMU_AB1CFGR_DMA0RST_DPos
#define SMU_AB1CFGR_DMA0RST_Msk         (0x1UL << SMU_AB1CFGR_DMA0RST_Pos)      /* 0x00000002 */
#define SMU_AB1CFGR_DMA0RST             SMU_AB1CFGR_DMA0RST_Msk                 /* DMA0 reset */

#define SMU_AB1CFGR_DMA1EN_DPos         (2U)
#define SMU_AB1CFGR_DMA1EN_Pos          SMU_AB1CFGR_DMA1EN_DPos
#define SMU_AB1CFGR_DMA1EN_Msk          (0x1UL << SMU_AB1CFGR_DMA1EN_Pos)       /* 0x00000004 */
#define SMU_AB1CFGR_DMA1EN              SMU_AB1CFGR_DMA1EN_Msk                  /* DMA1 clock enable */

#define SMU_AB1CFGR_DMA1RST_DPos        (3U)
#define SMU_AB1CFGR_DMA1RST_Pos         SMU_AB1CFGR_DMA1RST_DPos
#define SMU_AB1CFGR_DMA1RST_Msk         (0x1UL << SMU_AB1CFGR_DMA1RST_Pos)      /* 0x00000008 */
#define SMU_AB1CFGR_DMA1RST             SMU_AB1CFGR_DMA1RST_Msk                 /* DMA1 reset */

#define SMU_AB1CFGR_SRAM0EN_DPos        (4U)
#define SMU_AB1CFGR_SRAM0EN_Pos         SMU_AB1CFGR_SRAM0EN_DPos
#define SMU_AB1CFGR_SRAM0EN_Msk         (0x1UL << SMU_AB1CFGR_SRAM0EN_Pos)      /* 0x00000010 */
#define SMU_AB1CFGR_SRAM0EN             SMU_AB1CFGR_SRAM0EN_Msk                 /* SRAM0 clock enable */

#define SMU_AB1CFGR_SRAM0RST_DPos       (5U)
#define SMU_AB1CFGR_SRAM0RST_Pos        SMU_AB1CFGR_SRAM0RST_DPos
#define SMU_AB1CFGR_SRAM0RST_Msk        (0x1UL << SMU_AB1CFGR_SRAM0RST_Pos)     /* 0x00000020 */
#define SMU_AB1CFGR_SRAM0RST            SMU_AB1CFGR_SRAM0RST_Msk                /* SRAM0 reset */

#define SMU_AB1CFGR_SRAM1EN_DPos        (6U)
#define SMU_AB1CFGR_SRAM1EN_Pos         SMU_AB1CFGR_SRAM1EN_DPos
#define SMU_AB1CFGR_SRAM1EN_Msk         (0x1UL << SMU_AB1CFGR_SRAM1EN_Pos)      /* 0x00000040 */
#define SMU_AB1CFGR_SRAM1EN             SMU_AB1CFGR_SRAM1EN_Msk                 /* SRAM1 clock enable */

#define SMU_AB1CFGR_SRAM1RST_DPos       (7U)
#define SMU_AB1CFGR_SRAM1RST_Pos        SMU_AB1CFGR_SRAM1RST_DPos
#define SMU_AB1CFGR_SRAM1RST_Msk        (0x1UL << SMU_AB1CFGR_SRAM1RST_Pos)     /* 0x00000080 */
#define SMU_AB1CFGR_SRAM1RST            SMU_AB1CFGR_SRAM1RST_Msk                /* SRAM1 reset */

#define SMU_AB1CFGR_SRAM2EN_DPos        (8U)
#define SMU_AB1CFGR_SRAM2EN_Pos         SMU_AB1CFGR_SRAM2EN_DPos
#define SMU_AB1CFGR_SRAM2EN_Msk         (0x1UL << SMU_AB1CFGR_SRAM2EN_Pos)      /* 0x00000100 */
#define SMU_AB1CFGR_SRAM2EN             SMU_AB1CFGR_SRAM2EN_Msk                 /* SRAM2 clock enable */

#define SMU_AB1CFGR_SRAM2RST_DPos       (9U)
#define SMU_AB1CFGR_SRAM2RST_Pos        SMU_AB1CFGR_SRAM2RST_DPos
#define SMU_AB1CFGR_SRAM2RST_Msk        (0x1UL << SMU_AB1CFGR_SRAM2RST_Pos)     /* 0x00000200 */
#define SMU_AB1CFGR_SRAM2RST            SMU_AB1CFGR_SRAM2RST_Msk                /* SRAM2 reset */

#define SMU_AB1CFGR_SRAM3EN_DPos        (10U)
#define SMU_AB1CFGR_SRAM3EN_Pos         SMU_AB1CFGR_SRAM3EN_DPos
#define SMU_AB1CFGR_SRAM3EN_Msk         (0x1UL << SMU_AB1CFGR_SRAM3EN_Pos)      /* 0x00000400 */
#define SMU_AB1CFGR_SRAM3EN             SMU_AB1CFGR_SRAM3EN_Msk                 /* SRAM3 clock enable */

#define SMU_AB1CFGR_SRAM3RST_DPos       (11U)
#define SMU_AB1CFGR_SRAM3RST_Pos        SMU_AB1CFGR_SRAM3RST_DPos
#define SMU_AB1CFGR_SRAM3RST_Msk        (0x1UL << SMU_AB1CFGR_SRAM3RST_Pos)     /* 0x00000800 */
#define SMU_AB1CFGR_SRAM3RST            SMU_AB1CFGR_SRAM3RST_Msk                /* SRAM3 reset */


/******************  Bits definition for SMU_AB3CFGR register  *****************/
#define SMU_AB3CFGR_AXI4TOAPB0EN_DPos   (2U)
#define SMU_AB3CFGR_AXI4TOAPB0EN_Pos    SMU_AB3CFGR_AXI4TOAPB0EN_DPos
#define SMU_AB3CFGR_AXI4TOAPB0EN_Msk    (0x1UL << SMU_AB3CFGR_AXI4TOAPB0EN_Pos) /* 0x00000004 */
#define SMU_AB3CFGR_AXI4TOAPB0EN        SMU_AB3CFGR_AXI4TOAPB0EN_Msk            /* AXI4 to APB0 clock enable */

#define SMU_AB3CFGR_AXI4TOAPB0RST_DPos  (3U)
#define SMU_AB3CFGR_AXI4TOAPB0RST_Pos   SMU_AB3CFGR_AXI4TOAPB0RST_DPos
#define SMU_AB3CFGR_AXI4TOAPB0RST_Msk   (0x1UL << SMU_AB3CFGR_AXI4TOAPB0RST_Pos)/* 0x00000008 */
#define SMU_AB3CFGR_AXI4TOAPB0RST       SMU_AB3CFGR_AXI4TOAPB0RST_Msk           /* AXI4 to APB0 reset */

#define SMU_AB3CFGR_AXI4TOAPB1EN_DPos   (4U)
#define SMU_AB3CFGR_AXI4TOAPB1EN_Pos    SMU_AB3CFGR_AXI4TOAPB1EN_DPos
#define SMU_AB3CFGR_AXI4TOAPB1EN_Msk    (0x1UL << SMU_AB3CFGR_AXI4TOAPB1EN_Pos) /* 0x00000010 */
#define SMU_AB3CFGR_AXI4TOAPB1EN        SMU_AB3CFGR_AXI4TOAPB1EN_Msk            /* AXI4 to APB1 clock enable */

#define SMU_AB3CFGR_AXI4TOAPB1RST_DPos  (5U)
#define SMU_AB3CFGR_AXI4TOAPB1RST_Pos   SMU_AB3CFGR_AXI4TOAPB1RST_DPos
#define SMU_AB3CFGR_AXI4TOAPB1RST_Msk   (0x1UL << SMU_AB3CFGR_AXI4TOAPB1RST_Pos)/* 0x00000020 */
#define SMU_AB3CFGR_AXI4TOAPB1RST       SMU_AB3CFGR_AXI4TOAPB1RST_Msk           /* AXI4 to APB1 reset */

#define SMU_AB3CFGR_AXIBUS3EN_DPos      (6U)
#define SMU_AB3CFGR_AXIBUS3EN_Pos       SMU_AB3CFGR_AXIBUS3EN_DPos
#define SMU_AB3CFGR_AXIBUS3EN_Msk       (0x1UL << SMU_AB3CFGR_AXIBUS3EN_Pos)    /* 0x00000040 */
#define SMU_AB3CFGR_AXIBUS3EN           SMU_AB3CFGR_AXIBUS3EN_Msk               /* AxiBux3 clock enable */

#define SMU_AB3CFGR_AXIBUS3RST_DPos     (7U)
#define SMU_AB3CFGR_AXIBUS3RST_Pos      SMU_AB3CFGR_AXIBUS3RST_DPos
#define SMU_AB3CFGR_AXIBUS3RST_Msk      (0x1UL << SMU_AB3CFGR_AXIBUS3RST_Pos)   /* 0x00000080 */
#define SMU_AB3CFGR_AXIBUS3RST          SMU_AB3CFGR_AXIBUS3RST_Msk              /* AxiBux3 reset */


/******************  Bits definition for SMU_ALB0CFGR register  *****************/
#define SMU_ALB0CFGR_FCUEN_DPos         (0U)
#define SMU_ALB0CFGR_FCUEN_Pos          SMU_ALB0CFGR_FCUEN_DPos
#define SMU_ALB0CFGR_FCUEN_Msk          (0x1UL << SMU_ALB0CFGR_FCUEN_Pos)       /* 0x00000001 */
#define SMU_ALB0CFGR_FCUEN              SMU_ALB0CFGR_FCUEN_Msk                  /* FCU clock enable */

#define SMU_ALB0CFGR_FCURST_DPos        (1U)
#define SMU_ALB0CFGR_FCURST_Pos         SMU_ALB0CFGR_FCURST_DPos
#define SMU_ALB0CFGR_FCURST_Msk         (0x1UL << SMU_ALB0CFGR_FCURST_Pos)      /* 0x00000002 */
#define SMU_ALB0CFGR_FCURST             SMU_ALB0CFGR_FCURST_Msk                 /* FCU reset */

#define SMU_ALB0CFGR_CMU0EN_DPos        (2U)
#define SMU_ALB0CFGR_CMU0EN_Pos         SMU_ALB0CFGR_CMU0EN_DPos
#define SMU_ALB0CFGR_CMU0EN_Msk         (0x1UL << SMU_ALB0CFGR_CMU0EN_Pos)      /* 0x00000004 */
#define SMU_ALB0CFGR_CMU0EN             SMU_ALB0CFGR_CMU0EN_Msk                 /* CMU0 clock enable */

#define SMU_ALB0CFGR_CMU0RST_DPos       (3U)
#define SMU_ALB0CFGR_CMU0RST_Pos        SMU_ALB0CFGR_CMU0RST_DPos
#define SMU_ALB0CFGR_CMU0RST_Msk        (0x1UL << SMU_ALB0CFGR_CMU0RST_Pos)     /* 0x00000008 */
#define SMU_ALB0CFGR_CMU0RST            SMU_ALB0CFGR_CMU0RST_Msk                /* CMU0 reset */

#define SMU_ALB0CFGR_CMU1EN_DPos        (4U)
#define SMU_ALB0CFGR_CMU1EN_Pos         SMU_ALB0CFGR_CMU1EN_DPos
#define SMU_ALB0CFGR_CMU1EN_Msk         (0x1UL << SMU_ALB0CFGR_CMU1EN_Pos)      /* 0x00000010 */
#define SMU_ALB0CFGR_CMU1EN             SMU_ALB0CFGR_CMU1EN_Msk                 /* CMU1 clock enable */

#define SMU_ALB0CFGR_CMU1RST_DPos       (5U)
#define SMU_ALB0CFGR_CMU1RST_Pos        SMU_ALB0CFGR_CMU1RST_DPos
#define SMU_ALB0CFGR_CMU1RST_Msk        (0x1UL << SMU_ALB0CFGR_CMU1RST_Pos)     /* 0x00000020 */
#define SMU_ALB0CFGR_CMU1RST            SMU_ALB0CFGR_CMU1RST_Msk                /* CMU1 reset */

#define SMU_ALB0CFGR_CMU2EN_DPos        (6U)
#define SMU_ALB0CFGR_CMU2EN_Pos         SMU_ALB0CFGR_CMU2EN_DPos
#define SMU_ALB0CFGR_CMU2EN_Msk         (0x1UL << SMU_ALB0CFGR_CMU2EN_Pos)      /* 0x00000040 */
#define SMU_ALB0CFGR_CMU2EN             SMU_ALB0CFGR_CMU2EN_Msk                 /* CMU2 clock enable */

#define SMU_ALB0CFGR_CMU2RST_DPos       (7U)
#define SMU_ALB0CFGR_CMU2RST_Pos        SMU_ALB0CFGR_CMU2RST_DPos
#define SMU_ALB0CFGR_CMU2RST_Msk        (0x1UL << SMU_ALB0CFGR_CMU2RST_Pos)     /* 0x00000080 */
#define SMU_ALB0CFGR_CMU2RST            SMU_ALB0CFGR_CMU2RST_Msk                /* CMU2 reset */

#define SMU_ALB0CFGR_CMU3EN_DPos        (8U)
#define SMU_ALB0CFGR_CMU3EN_Pos         SMU_ALB0CFGR_CMU3EN_DPos
#define SMU_ALB0CFGR_CMU3EN_Msk         (0x1UL << SMU_ALB0CFGR_CMU3EN_Pos)      /* 0x00000100 */
#define SMU_ALB0CFGR_CMU3EN             SMU_ALB0CFGR_CMU3EN_Msk                 /* CMU3 clock enable */

#define SMU_ALB0CFGR_CMU3RST_DPos       (9U)
#define SMU_ALB0CFGR_CMU3RST_Pos        SMU_ALB0CFGR_CMU3RST_DPos
#define SMU_ALB0CFGR_CMU3RST_Msk        (0x1UL << SMU_ALB0CFGR_CMU3RST_Pos)     /* 0x00000200 */
#define SMU_ALB0CFGR_CMU3RST            SMU_ALB0CFGR_CMU3RST_Msk                /* CMU3 reset */

#define SMU_ALB0CFGR_PLICEN_DPos        (10U)
#define SMU_ALB0CFGR_PLICEN_Pos         SMU_ALB0CFGR_PLICEN_DPos
#define SMU_ALB0CFGR_PLICEN_Msk         (0x1UL << SMU_ALB0CFGR_PLICEN_Pos)      /* 0x00000400 */
#define SMU_ALB0CFGR_PLICEN             SMU_ALB0CFGR_PLICEN_Msk                 /* PLIC clock enable */

#define SMU_ALB0CFGR_PLICRST_DPos       (11U)
#define SMU_ALB0CFGR_PLICRST_Pos        SMU_ALB0CFGR_PLICRST_DPos
#define SMU_ALB0CFGR_PLICRST_Msk        (0x1UL << SMU_ALB0CFGR_PLICRST_Pos)     /* 0x00000800 */
#define SMU_ALB0CFGR_PLICRST            SMU_ALB0CFGR_PLICRST_Msk                /* PLIC reset */

#define SMU_ALB0CFGR_CLINTEN_DPos       (12U)
#define SMU_ALB0CFGR_CLINTEN_Pos        SMU_ALB0CFGR_CLINTEN_DPos
#define SMU_ALB0CFGR_CLINTEN_Msk        (0x1UL << SMU_ALB0CFGR_CLINTEN_Pos)     /* 0x00001000 */
#define SMU_ALB0CFGR_CLINTEN            SMU_ALB0CFGR_CLINTEN_Msk                /* CLINT clock enable */

#define SMU_ALB0CFGR_CLINTRST_DPos      (13U)
#define SMU_ALB0CFGR_CLINTRST_Pos       SMU_ALB0CFGR_CLINTRST_DPos
#define SMU_ALB0CFGR_CLINTRST_Msk       (0x1UL << SMU_ALB0CFGR_CLINTRST_Pos)    /* 0x00002000 */
#define SMU_ALB0CFGR_CLINTRST           SMU_ALB0CFGR_CLINTRST_Msk               /* CLINT reset */


/******************  Bits definition for SMU_ALB1CFGR register  *****************/
#define SMU_ALB1CFGR_HTIM0EN_DPos         (0U)
#define SMU_ALB1CFGR_HTIM0EN_Pos          SMU_ALB1CFGR_HTIM0EN_DPos
#define SMU_ALB1CFGR_HTIM0EN_Msk          (0x1UL << SMU_ALB1CFGR_HTIM0EN_Pos)         /* 0x00000001 */
#define SMU_ALB1CFGR_HTIM0EN              SMU_ALB1CFGR_HTIM0EN_Msk                    /* HTIM0 clock enable */

#define SMU_ALB1CFGR_HTIM0RST_DPos        (1U)
#define SMU_ALB1CFGR_HTIM0RST_Pos         SMU_ALB1CFGR_HTIM0RST_DPos
#define SMU_ALB1CFGR_HTIM0RST_Msk         (0x1UL << SMU_ALB1CFGR_HTIM0RST_Pos)        /* 0x00000002 */
#define SMU_ALB1CFGR_HTIM0RST             SMU_ALB1CFGR_HTIM0RST_Msk                   /* HTIM0 reset */

#define SMU_ALB1CFGR_CANFD0EN_DPos        (2U)
#define SMU_ALB1CFGR_CANFD0EN_Pos         SMU_ALB1CFGR_CANFD0EN_DPos
#define SMU_ALB1CFGR_CANFD0EN_Msk         (0x1UL << SMU_ALB1CFGR_CANFD0EN_Pos)        /* 0x00000004 */
#define SMU_ALB1CFGR_CANFD0EN             SMU_ALB1CFGR_CANFD0EN_Msk                   /* CANFD0 clock enable */

#define SMU_ALB1CFGR_CANFD0RST_DPos       (3U)
#define SMU_ALB1CFGR_CANFD0RST_Pos        SMU_ALB1CFGR_CANFD0RST_DPos
#define SMU_ALB1CFGR_CANFD0RST_Msk        (0x1UL << SMU_ALB1CFGR_CANFD0RST_Pos)       /* 0x00000008 */
#define SMU_ALB1CFGR_CANFD0RST            SMU_ALB1CFGR_CANFD0RST_Msk                  /* CANFD0 reset */

#define SMU_ALB1CFGR_CANFD1EN_DPos        (4U)
#define SMU_ALB1CFGR_CANFD1EN_Pos         SMU_ALB1CFGR_CANFD1EN_DPos
#define SMU_ALB1CFGR_CANFD1EN_Msk         (0x1UL << SMU_ALB1CFGR_CANFD1EN_Pos)        /* 0x00000010 */
#define SMU_ALB1CFGR_CANFD1EN             SMU_ALB1CFGR_CANFD1EN_Msk                   /* CANFD1 clock enable */

#define SMU_ALB1CFGR_CANFD1RST_DPos       (5U)
#define SMU_ALB1CFGR_CANFD1RST_Pos        SMU_ALB1CFGR_CANFD1RST_DPos
#define SMU_ALB1CFGR_CANFD1RST_Msk        (0x1UL << SMU_ALB1CFGR_CANFD1RST_Pos)       /* 0x00000020 */
#define SMU_ALB1CFGR_CANFD1RST            SMU_ALB1CFGR_CANFD1RST_Msk                  /* CANFD1 reset */

#define SMU_ALB1CFGR_ADC0EN_DPos          (6U)
#define SMU_ALB1CFGR_ADC0EN_Pos           SMU_ALB1CFGR_ADC0EN_DPos
#define SMU_ALB1CFGR_ADC0EN_Msk           (0x1UL << SMU_ALB1CFGR_ADC0EN_Pos)          /* 0x00000040 */
#define SMU_ALB1CFGR_ADC0EN               SMU_ALB1CFGR_ADC0EN_Msk                     /* ADC0 clock enable */

#define SMU_ALB1CFGR_ADC0RST_DPos         (7U)
#define SMU_ALB1CFGR_ADC0RST_Pos          SMU_ALB1CFGR_ADC0RST_DPos
#define SMU_ALB1CFGR_ADC0RST_Msk          (0x1UL << SMU_ALB1CFGR_ADC0RST_Pos)         /* 0x00000080 */
#define SMU_ALB1CFGR_ADC0RST              SMU_ALB1CFGR_ADC0RST_Msk                    /* ADC0 reset */

#define SMU_ALB1CFGR_ADC1EN_DPos          (8U)
#define SMU_ALB1CFGR_ADC1EN_Pos           SMU_ALB1CFGR_ADC1EN_DPos
#define SMU_ALB1CFGR_ADC1EN_Msk           (0x1UL << SMU_ALB1CFGR_ADC1EN_Pos)          /* 0x00000100 */
#define SMU_ALB1CFGR_ADC1EN               SMU_ALB1CFGR_ADC1EN_Msk                     /* ADC1 clock enable */

#define SMU_ALB1CFGR_ADC1RST_DPos         (9U)
#define SMU_ALB1CFGR_ADC1RST_Pos          SMU_ALB1CFGR_ADC1RST_DPos
#define SMU_ALB1CFGR_ADC1RST_Msk          (0x1UL << SMU_ALB1CFGR_ADC1RST_Pos)         /* 0x00000200 */
#define SMU_ALB1CFGR_ADC1RST              SMU_ALB1CFGR_ADC1RST_Msk                    /* ADC1 reset */

#define SMU_ALB1CFGR_DAC0EN_DPos          (10U)
#define SMU_ALB1CFGR_DAC0EN_Pos           SMU_ALB1CFGR_DAC0EN_DPos
#define SMU_ALB1CFGR_DAC0EN_Msk           (0x1UL << SMU_ALB1CFGR_DAC0EN_Pos)          /* 0x00000400 */
#define SMU_ALB1CFGR_DAC0EN               SMU_ALB1CFGR_DAC0EN_Msk                     /* DAC0 clock enable */

#define SMU_ALB1CFGR_DAC0RST_DPos         (11U)
#define SMU_ALB1CFGR_DAC0RST_Pos          SMU_ALB1CFGR_DAC0RST_DPos
#define SMU_ALB1CFGR_DAC0RST_Msk          (0x1UL << SMU_ALB1CFGR_DAC0RST_Pos)         /* 0x00000800 */
#define SMU_ALB1CFGR_DAC0RST              SMU_ALB1CFGR_DAC0RST_Msk                    /* DAC0 reset */

#define SMU_ALB1CFGR_GPIOAEN_DPos         (12U)
#define SMU_ALB1CFGR_GPIOAEN_Pos          SMU_ALB1CFGR_GPIOAEN_DPos
#define SMU_ALB1CFGR_GPIOAEN_Msk          (0x1UL << SMU_ALB1CFGR_GPIOAEN_Pos)         /* 0x00001000 */
#define SMU_ALB1CFGR_GPIOAEN              SMU_ALB1CFGR_GPIOAEN_Msk                    /* GPIOA clock enable */

#define SMU_ALB1CFGR_GPIOARST_DPos        (13U)
#define SMU_ALB1CFGR_GPIOARST_Pos         SMU_ALB1CFGR_GPIOARST_DPos
#define SMU_ALB1CFGR_GPIOARST_Msk         (0x1UL << SMU_ALB1CFGR_GPIOARST_Pos)        /* 0x00002000 */
#define SMU_ALB1CFGR_GPIOARST             SMU_ALB1CFGR_GPIOARST_Msk                   /* GPIOA reset */

#define SMU_ALB1CFGR_GPIOBEN_DPos         (14U)
#define SMU_ALB1CFGR_GPIOBEN_Pos          SMU_ALB1CFGR_GPIOBEN_DPos
#define SMU_ALB1CFGR_GPIOBEN_Msk          (0x1UL << SMU_ALB1CFGR_GPIOBEN_Pos)         /* 0x00004000 */
#define SMU_ALB1CFGR_GPIOBEN              SMU_ALB1CFGR_GPIOBEN_Msk                    /* GPIOB clock enable */

#define SMU_ALB1CFGR_GPIOBRST_DPos        (15U)
#define SMU_ALB1CFGR_GPIOBRST_Pos         SMU_ALB1CFGR_GPIOBRST_DPos
#define SMU_ALB1CFGR_GPIOBRST_Msk         (0x1UL << SMU_ALB1CFGR_GPIOBRST_Pos)        /* 0x00008000 */
#define SMU_ALB1CFGR_GPIOBRST             SMU_ALB1CFGR_GPIOBRST_Msk                   /* GPIOB reset */

#define SMU_ALB1CFGR_GPIOCEN_DPos         (16U)
#define SMU_ALB1CFGR_GPIOCEN_Pos          SMU_ALB1CFGR_GPIOCEN_DPos
#define SMU_ALB1CFGR_GPIOCEN_Msk          (0x1UL << SMU_ALB1CFGR_GPIOCEN_Pos)         /* 0x00010000 */
#define SMU_ALB1CFGR_GPIOCEN              SMU_ALB1CFGR_GPIOCEN_Msk                    /* GPIOC clock enable */

#define SMU_ALB1CFGR_GPIOCRST_DPos        (17U)
#define SMU_ALB1CFGR_GPIOCRST_Pos         SMU_ALB1CFGR_GPIOCRST_DPos
#define SMU_ALB1CFGR_GPIOCRST_Msk         (0x1UL << SMU_ALB1CFGR_GPIOCRST_Pos)        /* 0x00020000 */
#define SMU_ALB1CFGR_GPIOCRST             SMU_ALB1CFGR_GPIOCRST_Msk                   /* GPIOC reset */

#define SMU_ALB1CFGR_DSEEN_DPos           (18U)
#define SMU_ALB1CFGR_DSEEN_Pos            SMU_ALB1CFGR_DSEEN_DPos
#define SMU_ALB1CFGR_DSEEN_Msk            (0x01UL << SMU_ALB1CFGR_DSEEN_Pos)          /* 0x00040000 */
#define SMU_ALB1CFGR_DSEEN                SMU_ALB1CFGR_DSEEN_Msk                      /* DSE clock enable */

#define SMU_ALB1CFGR_DSERST_DPos          (19U)
#define SMU_ALB1CFGR_DSERST_Pos           SMU_ALB1CFGR_DSERST_DPos
#define SMU_ALB1CFGR_DSERST_Msk           (0x01UL << SMU_ALB1CFGR_DSERST_Pos)         /* 0x00080000 */
#define SMU_ALB1CFGR_DSERST               SMU_ALB1CFGR_DSERST_Msk                     /* DSE reset */

#define SMU_ALB1CFGR_AXILITEBUS1EN_DPos   (20U)
#define SMU_ALB1CFGR_AXILITEBUS1EN_Pos    SMU_ALB1CFGR_AXILITEBUS1EN_DPos
#define SMU_ALB1CFGR_AXILITEBUS1EN_Msk    (0x1UL << SMU_ALB1CFGR_AXILITEBUS1EN_Pos)   /* 0x00100000 */
#define SMU_ALB1CFGR_AXILITEBUS1EN        SMU_ALB1CFGR_AXILITEBUS1EN_Msk              /* AXILiteBUS1 clock enable */

#define SMU_ALB1CFGR_AXILITEBUS1RST_DPos  (21U)
#define SMU_ALB1CFGR_AXILITEBUS1RST_Pos   SMU_ALB1CFGR_AXILITEBUS1RST_DPos
#define SMU_ALB1CFGR_AXILITEBUS1RST_Msk   (0x1UL << SMU_ALB1CFGR_AXILITEBUS1RST_Pos)  /* 0x00200000 */
#define SMU_ALB1CFGR_AXILITEBUS1RST       SMU_ALB1CFGR_AXILITEBUS1RST_Msk             /* AXILiteBUS1 reset */


/******************  Bits definition for SMU_ALB2CFGR register  *****************/
#define SMU_ALB2CFGR_HTIM1EN_DPos         (0U)
#define SMU_ALB2CFGR_HTIM1EN_Pos          SMU_ALB2CFGR_HTIM1EN_DPos
#define SMU_ALB2CFGR_HTIM1EN_Msk          (0x1UL << SMU_ALB2CFGR_HTIM1EN_Pos)         /* 0x00000001 */
#define SMU_ALB2CFGR_HTIM1EN              SMU_ALB2CFGR_HTIM1EN_Msk                    /* HTIM1 clock enable */

#define SMU_ALB2CFGR_HTIM1RST_DPos        (1U)
#define SMU_ALB2CFGR_HTIM1RST_Pos         SMU_ALB2CFGR_HTIM1RST_DPos
#define SMU_ALB2CFGR_HTIM1RST_Msk         (0x1UL << SMU_ALB2CFGR_HTIM1RST_Pos)        /* 0x00000002 */
#define SMU_ALB2CFGR_HTIM1RST             SMU_ALB2CFGR_HTIM1RST_Msk                   /* HTIM1 reset */

#define SMU_ALB2CFGR_CANFD2EN_DPos        (2U)
#define SMU_ALB2CFGR_CANFD2EN_Pos         SMU_ALB2CFGR_CANFD2EN_DPos
#define SMU_ALB2CFGR_CANFD2EN_Msk         (0x1UL << SMU_ALB2CFGR_CANFD2EN_Pos)        /* 0x00000004 */
#define SMU_ALB2CFGR_CANFD2EN             SMU_ALB2CFGR_CANFD2EN_Msk                   /* CANFD2 clock enable */

#define SMU_ALB2CFGR_CANFD2RST_DPos       (3U)
#define SMU_ALB2CFGR_CANFD2RST_Pos        SMU_ALB2CFGR_CANFD2RST_DPos
#define SMU_ALB2CFGR_CANFD2RST_Msk        (0x1UL << SMU_ALB2CFGR_CANFD2RST_Pos)       /* 0x00000008 */
#define SMU_ALB2CFGR_CANFD2RST            SMU_ALB2CFGR_CANFD2RST_Msk                  /* CANFD2 reset */

#define SMU_ALB2CFGR_CANFD3EN_DPos        (4U)
#define SMU_ALB2CFGR_CANFD3EN_Pos         SMU_ALB2CFGR_CANFD3EN_DPos
#define SMU_ALB2CFGR_CANFD3EN_Msk         (0x1UL << SMU_ALB2CFGR_CANFD3EN_Pos)        /* 0x00000010 */
#define SMU_ALB2CFGR_CANFD3EN             SMU_ALB2CFGR_CANFD3EN_Msk                   /* CANFD3 clock enable */

#define SMU_ALB2CFGR_CANFD3RST_DPos       (5U)
#define SMU_ALB2CFGR_CANFD3RST_Pos        SMU_ALB2CFGR_CANFD3RST_DPos
#define SMU_ALB2CFGR_CANFD3RST_Msk        (0x1UL << SMU_ALB2CFGR_CANFD3RST_Pos)       /* 0x00000020 */
#define SMU_ALB2CFGR_CANFD3RST            SMU_ALB2CFGR_CANFD3RST_Msk                  /* CANFD3 reset */

#define SMU_ALB2CFGR_DAC1EN_DPos          (8U)
#define SMU_ALB2CFGR_DAC1EN_Pos           SMU_ALB2CFGR_DAC1EN_DPos
#define SMU_ALB2CFGR_DAC1EN_Msk           (0x1UL << SMU_ALB2CFGR_DAC1EN_Pos)          /* 0x00000100 */
#define SMU_ALB2CFGR_DAC1EN               SMU_ALB2CFGR_DAC1EN_Msk                     /* DAC1 clock enable */

#define SMU_ALB2CFGR_DAC1RST_DPos         (9U)
#define SMU_ALB2CFGR_DAC1RST_Pos          SMU_ALB2CFGR_DAC1RST_DPos
#define SMU_ALB2CFGR_DAC1RST_Msk          (0x1UL << SMU_ALB2CFGR_DAC1RST_Pos)         /* 0x00000200 */
#define SMU_ALB2CFGR_DAC1RST              SMU_ALB2CFGR_DAC1RST_Msk                    /* DAC1 reset */

#define SMU_ALB2CFGR_GPIODEN_DPos         (10U)
#define SMU_ALB2CFGR_GPIODEN_Pos          SMU_ALB2CFGR_GPIODEN_DPos
#define SMU_ALB2CFGR_GPIODEN_Msk          (0x1UL << SMU_ALB2CFGR_GPIODEN_Pos)         /* 0x00000400 */
#define SMU_ALB2CFGR_GPIODEN              SMU_ALB2CFGR_GPIODEN_Msk                    /* GPIOD clock enable */

#define SMU_ALB2CFGR_GPIODRST_DPos        (11U)
#define SMU_ALB2CFGR_GPIODRST_Pos         SMU_ALB2CFGR_GPIODRST_DPos
#define SMU_ALB2CFGR_GPIODRST_Msk         (0x1UL << SMU_ALB2CFGR_GPIODRST_Pos)        /* 0x00000800 */
#define SMU_ALB2CFGR_GPIODRST             SMU_ALB2CFGR_GPIODRST_Msk                   /* GPIOD reset */

#define SMU_ALB2CFGR_GPIOEEN_DPos         (12U)
#define SMU_ALB2CFGR_GPIOEEN_Pos          SMU_ALB2CFGR_GPIOEEN_DPos
#define SMU_ALB2CFGR_GPIOEEN_Msk          (0x1UL << SMU_ALB2CFGR_GPIOEEN_Pos)         /* 0x00001000 */
#define SMU_ALB2CFGR_GPIOEEN              SMU_ALB2CFGR_GPIOEEN_Msk                    /* GPIOE clock enable */

#define SMU_ALB2CFGR_GPIOERST_DPos        (13U)
#define SMU_ALB2CFGR_GPIOERST_Pos         SMU_ALB2CFGR_GPIOERST_DPos
#define SMU_ALB2CFGR_GPIOERST_Msk         (0x1UL << SMU_ALB2CFGR_GPIOERST_Pos)        /* 0x00002000 */
#define SMU_ALB2CFGR_GPIOERST             SMU_ALB2CFGR_GPIOERST_Msk                   /* GPIOE reset */

#define SMU_ALB2CFGR_GPIOFEN_DPos         (14U)
#define SMU_ALB2CFGR_GPIOFEN_Pos          SMU_ALB2CFGR_GPIOFEN_DPos
#define SMU_ALB2CFGR_GPIOFEN_Msk          (0x1UL << SMU_ALB2CFGR_GPIOFEN_Pos)         /* 0x00004000 */
#define SMU_ALB2CFGR_GPIOFEN              SMU_ALB2CFGR_GPIOFEN_Msk                    /* GPIOF clock enable */

#define SMU_ALB2CFGR_GPIOFRST_DPos        (15U)
#define SMU_ALB2CFGR_GPIOFRST_Pos         SMU_ALB2CFGR_GPIOFRST_DPos
#define SMU_ALB2CFGR_GPIOFRST_Msk         (0x1UL << SMU_ALB2CFGR_GPIOFRST_Pos)        /* 0x00008000 */
#define SMU_ALB2CFGR_GPIOFRST             SMU_ALB2CFGR_GPIOFRST_Msk                   /* GPIOF reset */

#define SMU_ALB2CFGR_GPIOGEN_DPos         (16U)
#define SMU_ALB2CFGR_GPIOGEN_Pos          SMU_ALB2CFGR_GPIOGEN_DPos
#define SMU_ALB2CFGR_GPIOGEN_Msk          (0x1UL << SMU_ALB2CFGR_GPIOGEN_Pos)         /* 0x00010000 */
#define SMU_ALB2CFGR_GPIOGEN              SMU_ALB2CFGR_GPIOGEN_Msk                    /* GPIOG clock enable */

#define SMU_ALB2CFGR_GPIOGRST_DPos        (17U)
#define SMU_ALB2CFGR_GPIOGRST_Pos         SMU_ALB2CFGR_GPIOGRST_DPos
#define SMU_ALB2CFGR_GPIOGRST_Msk         (0x1UL << SMU_ALB2CFGR_GPIOGRST_Pos)        /* 0x00020000 */
#define SMU_ALB2CFGR_GPIOGRST             SMU_ALB2CFGR_GPIOGRST_Msk                   /* GPIOG reset */

#define SMU_ALB2CFGR_AXILITEBUS2EN_DPos   (18U)
#define SMU_ALB2CFGR_AXILITEBUS2EN_Pos    SMU_ALB2CFGR_AXILITEBUS2EN_DPos
#define SMU_ALB2CFGR_AXILITEBUS2EN_Msk    (0x1UL << SMU_ALB2CFGR_AXILITEBUS2EN_Pos)   /* 0x00040000 */
#define SMU_ALB2CFGR_AXILITEBUS2EN        SMU_ALB2CFGR_AXILITEBUS2EN_Msk              /* AXILite Bus2 clock enable */

#define SMU_ALB2CFGR_AXILITEBUS2RST_DPos  (19U)
#define SMU_ALB2CFGR_AXILITEBUS2RST_Pos   SMU_ALB2CFGR_AXILITEBUS2RST_DPos
#define SMU_ALB2CFGR_AXILITEBUS2RST_Msk   (0x1UL << SMU_ALB2CFGR_AXILITEBUS2RST_Pos)  /* 0x00080000 */
#define SMU_ALB2CFGR_AXILITEBUS2RST       SMU_ALB2CFGR_AXILITEBUS2RST_Msk             /* AXILite Bus2 reset */


/******************  Bits definition for SMU_APB0CFGR register  *****************/
#define SMU_APB0CFGR_MACEN_DPos         (0U)
#define SMU_APB0CFGR_MACEN_Pos          SMU_APB0CFGR_MACEN_DPos
#define SMU_APB0CFGR_MACEN_Msk          (0x1UL << SMU_APB0CFGR_MACEN_Pos)       /* 0x00000001 */
#define SMU_APB0CFGR_MACEN              SMU_APB0CFGR_MACEN_Msk                  /* MAC clock enable */

#define SMU_APB0CFGR_MACRST_DPos        (1U)
#define SMU_APB0CFGR_MACRST_Pos         SMU_APB0CFGR_MACRST_DPos
#define SMU_APB0CFGR_MACRST_Msk         (0x1UL << SMU_APB0CFGR_MACRST_Pos)      /* 0x00000002 */
#define SMU_APB0CFGR_MACRST             SMU_APB0CFGR_MACRST_Msk                 /* MAC reset */

#define SMU_APB0CFGR_SPI0EN_DPos        (2U)
#define SMU_APB0CFGR_SPI0EN_Pos         SMU_APB0CFGR_SPI0EN_DPos
#define SMU_APB0CFGR_SPI0EN_Msk         (0x1UL << SMU_APB0CFGR_SPI0EN_Pos)      /* 0x00000004 */
#define SMU_APB0CFGR_SPI0EN             SMU_APB0CFGR_SPI0EN_Msk                 /* SPI0 clock enable */

#define SMU_APB0CFGR_SPI0RST_DPos       (3U)
#define SMU_APB0CFGR_SPI0RST_Pos        SMU_APB0CFGR_SPI0RST_DPos
#define SMU_APB0CFGR_SPI0RST_Msk        (0x1UL << SMU_APB0CFGR_SPI0RST_Pos)     /* 0x00000008 */
#define SMU_APB0CFGR_SPI0RST            SMU_APB0CFGR_SPI0RST_Msk                /* SPI0 reset */

#define SMU_APB0CFGR_SPI1EN_DPos        (4U)
#define SMU_APB0CFGR_SPI1EN_Pos         SMU_APB0CFGR_SPI1EN_DPos
#define SMU_APB0CFGR_SPI1EN_Msk         (0x1UL << SMU_APB0CFGR_SPI1EN_Pos)      /* 0x00000010 */
#define SMU_APB0CFGR_SPI1EN             SMU_APB0CFGR_SPI1EN_Msk                 /* SPI1 clock enable */

#define SMU_APB0CFGR_SPI1RST_DPos       (5U)
#define SMU_APB0CFGR_SPI1RST_Pos        SMU_APB0CFGR_SPI1RST_DPos
#define SMU_APB0CFGR_SPI1RST_Msk        (0x1UL << SMU_APB0CFGR_SPI1RST_Pos)     /* 0x00000020 */
#define SMU_APB0CFGR_SPI1RST            SMU_APB0CFGR_SPI1RST_Msk                /* SPI1 reset */

#define SMU_APB0CFGR_SPI2EN_DPos        (6U)
#define SMU_APB0CFGR_SPI2EN_Pos         SMU_APB0CFGR_SPI2EN_DPos
#define SMU_APB0CFGR_SPI2EN_Msk         (0x1UL << SMU_APB0CFGR_SPI2EN_Pos)      /* 0x00000040 */
#define SMU_APB0CFGR_SPI2EN             SMU_APB0CFGR_SPI2EN_Msk                 /* SPI2 clock enable */

#define SMU_APB0CFGR_SPI2RST_DPos       (7U)
#define SMU_APB0CFGR_SPI2RST_Pos        SMU_APB0CFGR_SPI2RST_DPos
#define SMU_APB0CFGR_SPI2RST_Msk        (0x1UL << SMU_APB0CFGR_SPI2RST_Pos)     /* 0x00000080 */
#define SMU_APB0CFGR_SPI2RST            SMU_APB0CFGR_SPI2RST_Msk                /* SPI2 reset */

#define SMU_APB0CFGR_IIC0EN_DPos        (8U)
#define SMU_APB0CFGR_IIC0EN_Pos         SMU_APB0CFGR_IIC0EN_DPos
#define SMU_APB0CFGR_IIC0EN_Msk         (0x1UL << SMU_APB0CFGR_IIC0EN_Pos)      /* 0x00000100 */
#define SMU_APB0CFGR_IIC0EN             SMU_APB0CFGR_IIC0EN_Msk                 /* IIC0 clock enable */

#define SMU_APB0CFGR_IIC0RST_DPos       (9U)
#define SMU_APB0CFGR_IIC0RST_Pos        SMU_APB0CFGR_IIC0RST_DPos
#define SMU_APB0CFGR_IIC0RST_Msk        (0x1UL << SMU_APB0CFGR_IIC0RST_Pos)     /* 0x00000200 */
#define SMU_APB0CFGR_IIC0RST            SMU_APB0CFGR_IIC0RST_Msk                /* IIC0 reset */

#define SMU_APB0CFGR_IIC1EN_DPos        (10U)
#define SMU_APB0CFGR_IIC1EN_Pos         SMU_APB0CFGR_IIC1EN_DPos
#define SMU_APB0CFGR_IIC1EN_Msk         (0x1UL << SMU_APB0CFGR_IIC1EN_Pos)      /* 0x00000400 */
#define SMU_APB0CFGR_IIC1EN             SMU_APB0CFGR_IIC1EN_Msk                 /* IIC1 clock enable */

#define SMU_APB0CFGR_IIC1RST_DPos       (11U)
#define SMU_APB0CFGR_IIC1RST_Pos        SMU_APB0CFGR_IIC1RST_DPos
#define SMU_APB0CFGR_IIC1RST_Msk        (0x1UL << SMU_APB0CFGR_IIC1RST_Pos)     /* 0x00000800 */
#define SMU_APB0CFGR_IIC1RST            SMU_APB0CFGR_IIC1RST_Msk                /* IIC1 reset */

#define SMU_APB0CFGR_USART0EN_DPos      (12U)
#define SMU_APB0CFGR_USART0EN_Pos       SMU_APB0CFGR_USART0EN_DPos
#define SMU_APB0CFGR_USART0EN_Msk       (0x1UL << SMU_APB0CFGR_USART0EN_Pos)    /* 0x00001000 */
#define SMU_APB0CFGR_USART0EN           SMU_APB0CFGR_USART0EN_Msk               /* USART0 clock enable */

#define SMU_APB0CFGR_USART0RST_DPos     (13U)
#define SMU_APB0CFGR_USART0RST_Pos      SMU_APB0CFGR_USART0RST_DPos
#define SMU_APB0CFGR_USART0RST_Msk      (0x1UL << SMU_APB0CFGR_USART0RST_Pos)   /* 0x00002000 */
#define SMU_APB0CFGR_USART0RST          SMU_APB0CFGR_USART0RST_Msk              /* USART0 reset */

#define SMU_APB0CFGR_USART1EN_DPos      (14U)
#define SMU_APB0CFGR_USART1EN_Pos       SMU_APB0CFGR_USART1EN_DPos
#define SMU_APB0CFGR_USART1EN_Msk       (0x1UL << SMU_APB0CFGR_USART1EN_Pos)    /* 0x00004000 */
#define SMU_APB0CFGR_USART1EN           SMU_APB0CFGR_USART1EN_Msk               /* USART1 clock enable */

#define SMU_APB0CFGR_USART1RST_DPos     (15U)
#define SMU_APB0CFGR_USART1RST_Pos      SMU_APB0CFGR_USART1RST_DPos
#define SMU_APB0CFGR_USART1RST_Msk      (0x1UL << SMU_APB0CFGR_USART1RST_Pos)   /* 0x00008000 */
#define SMU_APB0CFGR_USART1RST          SMU_APB0CFGR_USART1RST_Msk              /* USART1 reset */

#define SMU_APB0CFGR_USART2EN_DPos      (16U)
#define SMU_APB0CFGR_USART2EN_Pos       SMU_APB0CFGR_USART2EN_DPos
#define SMU_APB0CFGR_USART2EN_Msk       (0x1UL << SMU_APB0CFGR_USART2EN_Pos)    /* 0x00010000 */
#define SMU_APB0CFGR_USART2EN           SMU_APB0CFGR_USART2EN_Msk               /* USART2 clock enable */

#define SMU_APB0CFGR_USART2RST_DPos     (17U)
#define SMU_APB0CFGR_USART2RST_Pos      SMU_APB0CFGR_USART2RST_DPos
#define SMU_APB0CFGR_USART2RST_Msk      (0x1UL << SMU_APB0CFGR_USART2RST_Pos)   /* 0x00020000 */
#define SMU_APB0CFGR_USART2RST          SMU_APB0CFGR_USART2RST_Msk              /* USART2 reset */

#define SMU_APB0CFGR_USART3EN_DPos      (18U)
#define SMU_APB0CFGR_USART3EN_Pos       SMU_APB0CFGR_USART3EN_DPos
#define SMU_APB0CFGR_USART3EN_Msk       (0x1UL << SMU_APB0CFGR_USART3EN_Pos)    /* 0x00040000 */
#define SMU_APB0CFGR_USART3EN           SMU_APB0CFGR_USART3EN_Msk               /* USART3 clock enable */

#define SMU_APB0CFGR_USART3RST_DPos     (19U)
#define SMU_APB0CFGR_USART3RST_Pos      SMU_APB0CFGR_USART3RST_DPos
#define SMU_APB0CFGR_USART3RST_Msk      (0x1UL << SMU_APB0CFGR_USART3RST_Pos)   /* 0x00080000 */
#define SMU_APB0CFGR_USART3RST          SMU_APB0CFGR_USART3RST_Msk              /* USART3 reset */

#define SMU_APB0CFGR_HTIM2EN_DPos       (20U)
#define SMU_APB0CFGR_HTIM2EN_Pos        SMU_APB0CFGR_HTIM2EN_DPos
#define SMU_APB0CFGR_HTIM2EN_Msk        (0x1UL << SMU_APB0CFGR_HTIM2EN_Pos)     /* 0x00100000 */
#define SMU_APB0CFGR_HTIM2EN            SMU_APB0CFGR_HTIM2EN_Msk                /* HTIM2 clock enable */

#define SMU_APB0CFGR_HTIM2RST_DPos      (21U)
#define SMU_APB0CFGR_HTIM2RST_Pos       SMU_APB0CFGR_HTIM2RST_DPos
#define SMU_APB0CFGR_HTIM2RST_Msk       (0x1UL << SMU_APB0CFGR_HTIM2RST_Pos)    /* 0x00200000 */
#define SMU_APB0CFGR_HTIM2RST           SMU_APB0CFGR_HTIM2RST_Msk               /* HTIM2 reset */

#define SMU_APB0CFGR_TIM3EN_DPos        (22U)
#define SMU_APB0CFGR_TIM3EN_Pos         SMU_APB0CFGR_TIM3EN_DPos
#define SMU_APB0CFGR_TIM3EN_Msk         (0x1UL << SMU_APB0CFGR_TIM3EN_Pos)      /* 0x00400000 */
#define SMU_APB0CFGR_TIM3EN             SMU_APB0CFGR_TIM3EN_Msk                 /* TIM3 clock enable */

#define SMU_APB0CFGR_TIM3RST_DPos       (23U)
#define SMU_APB0CFGR_TIM3RST_Pos        SMU_APB0CFGR_TIM3RST_DPos
#define SMU_APB0CFGR_TIM3RST_Msk        (0x1UL << SMU_APB0CFGR_TIM3RST_Pos)     /* 0x00800000 */
#define SMU_APB0CFGR_TIM3RST            SMU_APB0CFGR_TIM3RST_Msk                /* TIM3 reset */

#define SMU_APB0CFGR_TIM4EN_DPos        (24U)
#define SMU_APB0CFGR_TIM4EN_Pos         SMU_APB0CFGR_TIM4EN_DPos
#define SMU_APB0CFGR_TIM4EN_Msk         (0x1UL << SMU_APB0CFGR_TIM4EN_Pos)      /* 0x01000000 */
#define SMU_APB0CFGR_TIM4EN             SMU_APB0CFGR_TIM4EN_Msk                 /* TIM4 clock enable */

#define SMU_APB0CFGR_TIM4RST_DPos       (25U)
#define SMU_APB0CFGR_TIM4RST_Pos        SMU_APB0CFGR_TIM4RST_DPos
#define SMU_APB0CFGR_TIM4RST_Msk        (0x1UL << SMU_APB0CFGR_TIM4RST_Pos)     /* 0x02000000 */
#define SMU_APB0CFGR_TIM4RST            SMU_APB0CFGR_TIM4RST_Msk                /* TIM4 reset */

#define SMU_APB0CFGR_WWDG0EN_DPos       (26U)
#define SMU_APB0CFGR_WWDG0EN_Pos        SMU_APB0CFGR_WWDG0EN_DPos
#define SMU_APB0CFGR_WWDG0EN_Msk        (0x1UL << SMU_APB0CFGR_WWDG0EN_Pos)     /* 0x04000000 */
#define SMU_APB0CFGR_WWDG0EN            SMU_APB0CFGR_WWDG0EN_Msk                /* WWDG0 clock enable */

#define SMU_APB0CFGR_WWDG0RST_DPos      (27U)
#define SMU_APB0CFGR_WWDG0RST_Pos       SMU_APB0CFGR_WWDG0RST_DPos
#define SMU_APB0CFGR_WWDG0RST_Msk       (0x1UL << SMU_APB0CFGR_WWDG0RST_Pos)    /* 0x08000000 */
#define SMU_APB0CFGR_WWDG0RST           SMU_APB0CFGR_WWDG0RST_Msk               /* WWDG0 reset */

#define SMU_APB0CFGR_APBBUS0EN_DPos     (30U)
#define SMU_APB0CFGR_APBBUS0EN_Pos      SMU_APB0CFGR_APBBUS0EN_DPos
#define SMU_APB0CFGR_APBBUS0EN_Msk      (0x1UL << SMU_APB0CFGR_APBBUS0EN_Pos)   /* 0x40000000 */
#define SMU_APB0CFGR_APBBUS0EN          SMU_APB0CFGR_APBBUS0EN_Msk              /* APBBUS0 clock enable */

#define SMU_APB0CFGR_APBBUS0RST_DPos    (31U)
#define SMU_APB0CFGR_APBBUS0RST_Pos     SMU_APB0CFGR_APBBUS0RST_DPos
#define SMU_APB0CFGR_APBBUS0RST_Msk     (0x1UL << SMU_APB0CFGR_APBBUS0RST_Pos)  /* 0x80000000 */
#define SMU_APB0CFGR_APBBUS0RST         SMU_APB0CFGR_APBBUS0RST_Msk             /* APBBUS0 reset */


/******************  Bits definition for SMU_APB1CFGR register  *****************/
#define SMU_APB1CFGR_SPI3EN_DPos        (0U)
#define SMU_APB1CFGR_SPI3EN_Pos         SMU_APB1CFGR_SPI3EN_DPos
#define SMU_APB1CFGR_SPI3EN_Msk         (0x1UL << SMU_APB1CFGR_SPI3EN_Pos)      /* 0x00000001 */
#define SMU_APB1CFGR_SPI3EN             SMU_APB1CFGR_SPI3EN_Msk                 /* SPI3 clock enable */

#define SMU_APB1CFGR_SPI3RST_DPos       (1U)
#define SMU_APB1CFGR_SPI3RST_Pos        SMU_APB1CFGR_SPI3RST_DPos
#define SMU_APB1CFGR_SPI3RST_Msk        (0x1UL << SMU_APB1CFGR_SPI3RST_Pos)     /* 0x00000002 */
#define SMU_APB1CFGR_SPI3RST            SMU_APB1CFGR_SPI3RST_Msk                /* SPI3 reset */

#define SMU_APB1CFGR_SPI4EN_DPos        (2U)
#define SMU_APB1CFGR_SPI4EN_Pos         SMU_APB1CFGR_SPI4EN_DPos
#define SMU_APB1CFGR_SPI4EN_Msk         (0x1UL << SMU_APB1CFGR_SPI4EN_Pos)      /* 0x00000004 */
#define SMU_APB1CFGR_SPI4EN             SMU_APB1CFGR_SPI4EN_Msk                 /* SPI4 clock enable */

#define SMU_APB1CFGR_SPI4RST_DPos       (3U)
#define SMU_APB1CFGR_SPI4RST_Pos        SMU_APB1CFGR_SPI4RST_DPos
#define SMU_APB1CFGR_SPI4RST_Msk        (0x1UL << SMU_APB1CFGR_SPI4RST_Pos)     /* 0x00000008 */
#define SMU_APB1CFGR_SPI4RST            SMU_APB1CFGR_SPI4RST_Msk                /* SPI4 reset */

#define SMU_APB1CFGR_SPI5EN_DPos        (4U)
#define SMU_APB1CFGR_SPI5EN_Pos         SMU_APB1CFGR_SPI5EN_DPos
#define SMU_APB1CFGR_SPI5EN_Msk         (0x1UL << SMU_APB1CFGR_SPI5EN_Pos)      /* 0x00000010 */
#define SMU_APB1CFGR_SPI5EN             SMU_APB1CFGR_SPI5EN_Msk                 /* SPI5 clock enable */

#define SMU_APB1CFGR_SPI5RST_DPos       (5U)
#define SMU_APB1CFGR_SPI5RST_Pos        SMU_APB1CFGR_SPI5RST_DPos
#define SMU_APB1CFGR_SPI5RST_Msk        (0x1UL << SMU_APB1CFGR_SPI5RST_Pos)     /* 0x00000020 */
#define SMU_APB1CFGR_SPI5RST            SMU_APB1CFGR_SPI5RST_Msk                /* SPI5 reset */

#define SMU_APB1CFGR_IIC2EN_DPos        (6U)
#define SMU_APB1CFGR_IIC2EN_Pos         SMU_APB1CFGR_IIC2EN_DPos
#define SMU_APB1CFGR_IIC2EN_Msk         (0x1UL << SMU_APB1CFGR_IIC2EN_Pos)      /* 0x00000040 */
#define SMU_APB1CFGR_IIC2EN             SMU_APB1CFGR_IIC2EN_Msk                 /* IIC2 clock enable */

#define SMU_APB1CFGR_IIC2RST_DPos       (7U)
#define SMU_APB1CFGR_IIC2RST_Pos        SMU_APB1CFGR_IIC2RST_DPos
#define SMU_APB1CFGR_IIC2RST_Msk        (0x1UL << SMU_APB1CFGR_IIC2RST_Pos)     /* 0x00000080 */
#define SMU_APB1CFGR_IIC2RST            SMU_APB1CFGR_IIC2RST_Msk                /* IIC2 reset */

#define SMU_APB1CFGR_IIC3EN_DPos        (8U)
#define SMU_APB1CFGR_IIC3EN_Pos         SMU_APB1CFGR_IIC3EN_DPos
#define SMU_APB1CFGR_IIC3EN_Msk         (0x1UL << SMU_APB1CFGR_IIC3EN_Pos)      /* 0x00000100 */
#define SMU_APB1CFGR_IIC3EN             SMU_APB1CFGR_IIC3EN_Msk                 /* IIC3 clock enable */

#define SMU_APB1CFGR_IIC3RST_DPos       (9U)
#define SMU_APB1CFGR_IIC3RST_Pos        SMU_APB1CFGR_IIC3RST_DPos
#define SMU_APB1CFGR_IIC3RST_Msk        (0x1UL << SMU_APB1CFGR_IIC3RST_Pos)     /* 0x00000200 */
#define SMU_APB1CFGR_IIC3RST            SMU_APB1CFGR_IIC3RST_Msk                /* IIC3 reset */

#define SMU_APB1CFGR_USART4EN_DPos      (10U)
#define SMU_APB1CFGR_USART4EN_Pos       SMU_APB1CFGR_USART4EN_DPos
#define SMU_APB1CFGR_USART4EN_Msk       (0x1UL << SMU_APB1CFGR_USART4EN_Pos)    /* 0x00000400 */
#define SMU_APB1CFGR_USART4EN           SMU_APB1CFGR_USART4EN_Msk               /* USART4 clock enable */

#define SMU_APB1CFGR_USART4RST_DPos     (11U)
#define SMU_APB1CFGR_USART4RST_Pos      SMU_APB1CFGR_USART4RST_DPos
#define SMU_APB1CFGR_USART4RST_Msk      (0x1UL << SMU_APB1CFGR_USART4RST_Pos)   /* 0x00000800 */
#define SMU_APB1CFGR_USART4RST          SMU_APB1CFGR_USART4RST_Msk              /* USART4 reset */

#define SMU_APB1CFGR_USART5EN_DPos      (12U)
#define SMU_APB1CFGR_USART5EN_Pos       SMU_APB1CFGR_USART5EN_DPos
#define SMU_APB1CFGR_USART5EN_Msk       (0x1UL << SMU_APB1CFGR_USART5EN_Pos)    /* 0x00001000 */
#define SMU_APB1CFGR_USART5EN           SMU_APB1CFGR_USART5EN_Msk               /* USART5 clock enable */

#define SMU_APB1CFGR_USART5RST_DPos     (13U)
#define SMU_APB1CFGR_USART5RST_Pos      SMU_APB1CFGR_USART5RST_DPos
#define SMU_APB1CFGR_USART5RST_Msk      (0x1UL << SMU_APB1CFGR_USART5RST_Pos)   /* 0x00002000 */
#define SMU_APB1CFGR_USART5RST          SMU_APB1CFGR_USART5RST_Msk              /* USART5 reset */

#define SMU_APB1CFGR_USART6EN_DPos      (14U)
#define SMU_APB1CFGR_USART6EN_Pos       SMU_APB1CFGR_USART6EN_DPos
#define SMU_APB1CFGR_USART6EN_Msk       (0x1UL << SMU_APB1CFGR_USART6EN_Pos)    /* 0x00004000 */
#define SMU_APB1CFGR_USART6EN           SMU_APB1CFGR_USART6EN_Msk               /* USART6 clock enable */

#define SMU_APB1CFGR_USART6RST_DPos     (15U)
#define SMU_APB1CFGR_USART6RST_Pos      SMU_APB1CFGR_USART6RST_DPos
#define SMU_APB1CFGR_USART6RST_Msk      (0x1UL << SMU_APB1CFGR_USART6RST_Pos)   /* 0x00008000 */
#define SMU_APB1CFGR_USART6RST          SMU_APB1CFGR_USART6RST_Msk              /* USART6 reset */

#define SMU_APB1CFGR_USART7EN_DPos      (16U)
#define SMU_APB1CFGR_USART7EN_Pos       SMU_APB1CFGR_USART7EN_DPos
#define SMU_APB1CFGR_USART7EN_Msk       (0x1UL << SMU_APB1CFGR_USART7EN_Pos)    /* 0x00010000 */
#define SMU_APB1CFGR_USART7EN           SMU_APB1CFGR_USART7EN_Msk               /* USART7 clock enable */

#define SMU_APB1CFGR_USART7RST_DPos     (17U)
#define SMU_APB1CFGR_USART7RST_Pos      SMU_APB1CFGR_USART7RST_DPos
#define SMU_APB1CFGR_USART7RST_Msk      (0x1UL << SMU_APB1CFGR_USART7RST_Pos)   /* 0x00020000 */
#define SMU_APB1CFGR_USART7RST          SMU_APB1CFGR_USART7RST_Msk              /* USART7 reset */

#define SMU_APB1CFGR_HTIM5EN_DPos       (18U)
#define SMU_APB1CFGR_HTIM5EN_Pos        SMU_APB1CFGR_HTIM5EN_DPos
#define SMU_APB1CFGR_HTIM5EN_Msk        (0x1UL << SMU_APB1CFGR_HTIM5EN_Pos)     /* 0x00040000 */
#define SMU_APB1CFGR_HTIM5EN            SMU_APB1CFGR_HTIM5EN_Msk                /* HTIM5 clock enable */

#define SMU_APB1CFGR_HTIM5RST_DPos      (19U)
#define SMU_APB1CFGR_HTIM5RST_Pos       SMU_APB1CFGR_HTIM5RST_DPos
#define SMU_APB1CFGR_HTIM5RST_Msk       (0x1UL << SMU_APB1CFGR_HTIM5RST_Pos)    /* 0x00080000 */
#define SMU_APB1CFGR_HTIM5RST           SMU_APB1CFGR_HTIM5RST_Msk               /* HTIM5 reset */

#define SMU_APB1CFGR_TIM6EN_DPos        (20U)
#define SMU_APB1CFGR_TIM6EN_Pos         SMU_APB1CFGR_TIM6EN_DPos
#define SMU_APB1CFGR_TIM6EN_Msk         (0x1UL << SMU_APB1CFGR_TIM6EN_Pos)      /* 0x00100000 */
#define SMU_APB1CFGR_TIM6EN             SMU_APB1CFGR_TIM6EN_Msk                 /* TIM6 clock enable */

#define SMU_APB1CFGR_TIM6RST_DPos       (21U)
#define SMU_APB1CFGR_TIM6RST_Pos        SMU_APB1CFGR_TIM6RST_DPos
#define SMU_APB1CFGR_TIM6RST_Msk        (0x1UL << SMU_APB1CFGR_TIM6RST_Pos)     /* 0x00200000 */
#define SMU_APB1CFGR_TIM6RST            SMU_APB1CFGR_TIM6RST_Msk                /* TIM6 reset */

#define SMU_APB1CFGR_TIM7EN_DPos        (22U)
#define SMU_APB1CFGR_TIM7EN_Pos         SMU_APB1CFGR_TIM7EN_DPos
#define SMU_APB1CFGR_TIM7EN_Msk         (0x1UL << SMU_APB1CFGR_TIM7EN_Pos)      /* 0x00400000 */
#define SMU_APB1CFGR_TIM7EN             SMU_APB1CFGR_TIM7EN_Msk                 /* TIM7 clock enable */

#define SMU_APB1CFGR_TIM7RST_DPos       (23U)
#define SMU_APB1CFGR_TIM7RST_Pos        SMU_APB1CFGR_TIM7RST_DPos
#define SMU_APB1CFGR_TIM7RST_Msk        (0x1UL << SMU_APB1CFGR_TIM7RST_Pos)     /* 0x00800000 */
#define SMU_APB1CFGR_TIM7RST            SMU_APB1CFGR_TIM7RST_Msk                /* TIM7 reset */

#define SMU_APB1CFGR_WWDG1EN_DPos       (24U)
#define SMU_APB1CFGR_WWDG1EN_Pos        SMU_APB1CFGR_WWDG1EN_DPos
#define SMU_APB1CFGR_WWDG1EN_Msk        (0x1UL << SMU_APB1CFGR_WWDG1EN_Pos)     /* 0x01000000 */
#define SMU_APB1CFGR_WWDG1EN            SMU_APB1CFGR_WWDG1EN_Msk                /* WWDG1 clock enable */

#define SMU_APB1CFGR_WWDG1RST_DPos      (25U)
#define SMU_APB1CFGR_WWDG1RST_Pos       SMU_APB1CFGR_WWDG1RST_DPos
#define SMU_APB1CFGR_WWDG1RST_Msk       (0x1UL << SMU_APB1CFGR_WWDG1RST_Pos)    /* 0x02000000 */
#define SMU_APB1CFGR_WWDG1RST           SMU_APB1CFGR_WWDG1RST_Msk               /* WWDG1 reset */

#define SMU_APB1CFGR_CRCEN_DPos         (26U)
#define SMU_APB1CFGR_CRCEN_Pos          SMU_APB1CFGR_CRCEN_DPos
#define SMU_APB1CFGR_CRCEN_Msk          (0x1UL << SMU_APB1CFGR_CRCEN_Pos)       /* 0x04000000 */
#define SMU_APB1CFGR_CRCEN              SMU_APB1CFGR_CRCEN_Msk                  /* CRC clock enable */

#define SMU_APB1CFGR_CRCRST_DPos        (27U)
#define SMU_APB1CFGR_CRCRST_Pos         SMU_APB1CFGR_CRCRST_DPos
#define SMU_APB1CFGR_CRCRST_Msk         (0x1UL << SMU_APB1CFGR_CRCRST_Pos)      /* 0x08000000 */
#define SMU_APB1CFGR_CRCRST             SMU_APB1CFGR_CRCRST_Msk                 /* CRC reset */

#define SMU_APB1CFGR_APBBUS1EN_DPos     (28U)
#define SMU_APB1CFGR_APBBUS1EN_Pos      SMU_APB1CFGR_APBBUS1EN_DPos
#define SMU_APB1CFGR_APBBUS1EN_Msk      (0x1UL << SMU_APB1CFGR_APBBUS1EN_Pos)   /* 0x10000000 */
#define SMU_APB1CFGR_APBBUS1EN          SMU_APB1CFGR_APBBUS1EN_Msk              /* APB1BUS1 clock enable */

#define SMU_APB1CFGR_APBBUS1RST_DPos    (29U)
#define SMU_APB1CFGR_APBBUS1RST_Pos     SMU_APB1CFGR_APBBUS1RST_DPos
#define SMU_APB1CFGR_APBBUS1RST_Msk     (0x1UL << SMU_APB1CFGR_APBBUS1RST_Pos)  /* 0x20000000 */
#define SMU_APB1CFGR_APBBUS1RST         SMU_APB1CFGR_APBBUS1RST_Msk             /* APB1BUS1 reset */


/******************  Bits definition for SMU_OTHCFGR register  *****************/
#define SMU_OTHCFGR_dclsEnable_DPos     (0U)
#define SMU_OTHCFGR_DCLSEN_Pos          SMU_OTHCFGR_dclsEnable_DPos
#define SMU_OTHCFGR_DCLSEN_Msk          (0x1UL << SMU_OTHCFGR_DCLSEN_Pos)       /* 0x00000001 */
#define SMU_OTHCFGR_DCLSEN              SMU_OTHCFGR_DCLSEN_Msk                  /* Dual core enable */

#define SMU_OTHCFGR_eccEnable_DPos      (1U)
#define SMU_OTHCFGR_ECCEN_Pos           SMU_OTHCFGR_eccEnable_DPos
#define SMU_OTHCFGR_ECCEN_Msk           (0x1UL << SMU_OTHCFGR_ECCEN_Pos)        /* 0x00000002 */
#define SMU_OTHCFGR_ECCEN               SMU_OTHCFGR_ECCEN_Msk                   /* ECC enable */

#define SMU_OTHCFGR_timerBreak_DPos     (2U)
#define SMU_OTHCFGR_TIMBKEN_Pos         SMU_OTHCFGR_timerBreak_DPos
#define SMU_OTHCFGR_TIMBKEN_Msk         (0xFUL << SMU_OTHCFGR_TIMBKEN_Pos)      /* 0x0000003C */
#define SMU_OTHCFGR_TIMBKEN             SMU_OTHCFGR_TIMBKEN_Msk                 /* TIMBKEN[3:0] bits (Advanced Timer Brake Enable) */
#define SMU_OTHCFGR_TIMBKEN_0           (0x01UL << SMU_OTHCFGR_TIMBKEN_Pos)     /* 0x00000004 */
#define SMU_OTHCFGR_TIMBKEN_1           (0x02UL << SMU_OTHCFGR_TIMBKEN_Pos)     /* 0x00000008 */
#define SMU_OTHCFGR_TIMBKEN_2           (0x04UL << SMU_OTHCFGR_TIMBKEN_Pos)     /* 0x00000010 */
#define SMU_OTHCFGR_TIMBKEN_3           (0x08UL << SMU_OTHCFGR_TIMBKEN_Pos)     /* 0x00000020 */

#define SMU_OTHCFGR_clrTimeOutFlag_DPos (6U)
#define SMU_OTHCFGR_TIMEOUTCF_Pos       SMU_OTHCFGR_clrTimeOutFlag_DPos
#define SMU_OTHCFGR_TIMEOUTCF_Msk       (0x1UL << SMU_OTHCFGR_TIMEOUTCF_Pos)    /* 0x00000040 */
#define SMU_OTHCFGR_TIMEOUTCF           SMU_OTHCFGR_TIMEOUTCF_Msk               /* Clear timeout flag */

#define SMU_OTHCFGR_sramLowPowerEn_DPos (8U)
#define SMU_OTHCFGR_SRAMLPEN_Pos        SMU_OTHCFGR_sramLowPowerEn_DPos
#define SMU_OTHCFGR_SRAMLPEN_Msk        (0xFUL << SMU_OTHCFGR_SRAMLPEN_Pos)     /* 0x00000F00 */
#define SMU_OTHCFGR_SRAMLPEN            SMU_OTHCFGR_SRAMLPEN_Msk                /* SRAMLPEN[3:0] bits (SRAM Low Power Enable Signal) */
#define SMU_OTHCFGR_SRAMLPEN_0          (0x01UL << SMU_OTHCFGR_SRAMLPEN_Pos)    /* 0x00000100 */
#define SMU_OTHCFGR_SRAMLPEN_1          (0x02UL << SMU_OTHCFGR_SRAMLPEN_Pos)    /* 0x00000200 */
#define SMU_OTHCFGR_SRAMLPEN_2          (0x04UL << SMU_OTHCFGR_SRAMLPEN_Pos)    /* 0x00000400 */
#define SMU_OTHCFGR_SRAMLPEN_3          (0x08UL << SMU_OTHCFGR_SRAMLPEN_Pos)    /* 0x00000800 */

#define SMU_OTHCFGR_clkOutMux_DPos      (12U)
#define SMU_OTHCFGR_CLKOUTMUX_Pos       SMU_OTHCFGR_clkOutMux_DPos
#define SMU_OTHCFGR_CLKOUTMUX_Msk       (0x7UL << SMU_OTHCFGR_CLKOUTMUX_Pos)    /* 0x00007000 */
#define SMU_OTHCFGR_CLKOUTMUX           SMU_OTHCFGR_CLKOUTMUX_Msk               /* CLKOUTMUX[2:0] bits (Clock Output Mux Select) */
#define SMU_OTHCFGR_CLKOUTMUX_0         (0x01UL << SMU_OTHCFGR_CLKOUTMUX_Pos)   /* 0x00001000 */
#define SMU_OTHCFGR_CLKOUTMUX_1         (0x02UL << SMU_OTHCFGR_CLKOUTMUX_Pos)   /* 0x00002000 */
#define SMU_OTHCFGR_CLKOUTMUX_2         (0x04UL << SMU_OTHCFGR_CLKOUTMUX_Pos)   /* 0x00004000 */


/******************  Bits definition for SMU_BUSTCFGR register  *****************/
#define SMU_BUSTCFGR_busTimeOutNum_DPos (0U)
#define SMU_BUSTCFGR_BUSTIMEOUTNUM_Pos  SMU_BUSTCFGR_busTimeOutNum_DPos
#define SMU_BUSTCFGR_BUSTIMEOUTNUM_Msk  (0xFFFFUL << SMU_BUSTCFGR_BUSTIMEOUTNUM_Pos)    /* 0x0000FFFF */
#define SMU_BUSTCFGR_BUSTIMEOUTNUM      SMU_BUSTCFGR_BUSTIMEOUTNUM_Msk                  /* BUSTIMEOUTNUM[15:0] bits (Bus Timeout Counter) */
#define SMU_BUSTCFGR_BUSTIMEOUTNUM_0    (0x0001UL << SMU_BUSTCFGR_BUSTIMEOUTNUM_Pos)    /* 0x00000001*/
#define SMU_BUSTCFGR_BUSTIMEOUTNUM_1    (0x0002UL << SMU_BUSTCFGR_BUSTIMEOUTNUM_Pos)    /* 0x00000002*/
#define SMU_BUSTCFGR_BUSTIMEOUTNUM_2    (0x0004UL << SMU_BUSTCFGR_BUSTIMEOUTNUM_Pos)    /* 0x00000004*/
#define SMU_BUSTCFGR_BUSTIMEOUTNUM_3    (0x0008UL << SMU_BUSTCFGR_BUSTIMEOUTNUM_Pos)    /* 0x00000008*/
#define SMU_BUSTCFGR_BUSTIMEOUTNUM_4    (0x0010UL << SMU_BUSTCFGR_BUSTIMEOUTNUM_Pos)    /* 0x00000010*/
#define SMU_BUSTCFGR_BUSTIMEOUTNUM_5    (0x0020UL << SMU_BUSTCFGR_BUSTIMEOUTNUM_Pos)    /* 0x00000020*/
#define SMU_BUSTCFGR_BUSTIMEOUTNUM_6    (0x0040UL << SMU_BUSTCFGR_BUSTIMEOUTNUM_Pos)    /* 0x00000040*/
#define SMU_BUSTCFGR_BUSTIMEOUTNUM_7    (0x0080UL << SMU_BUSTCFGR_BUSTIMEOUTNUM_Pos)    /* 0x00000080*/
#define SMU_BUSTCFGR_BUSTIMEOUTNUM_8    (0x0100UL << SMU_BUSTCFGR_BUSTIMEOUTNUM_Pos)    /* 0x00000100*/
#define SMU_BUSTCFGR_BUSTIMEOUTNUM_9    (0x0200UL << SMU_BUSTCFGR_BUSTIMEOUTNUM_Pos)    /* 0x00000200*/
#define SMU_BUSTCFGR_BUSTIMEOUTNUM_10   (0x0400UL << SMU_BUSTCFGR_BUSTIMEOUTNUM_Pos)    /* 0x00000400*/
#define SMU_BUSTCFGR_BUSTIMEOUTNUM_11   (0x0800UL << SMU_BUSTCFGR_BUSTIMEOUTNUM_Pos)    /* 0x00000800*/
#define SMU_BUSTCFGR_BUSTIMEOUTNUM_12   (0x1000UL << SMU_BUSTCFGR_BUSTIMEOUTNUM_Pos)    /* 0x00001000*/
#define SMU_BUSTCFGR_BUSTIMEOUTNUM_13   (0x2000UL << SMU_BUSTCFGR_BUSTIMEOUTNUM_Pos)    /* 0x00002000*/
#define SMU_BUSTCFGR_BUSTIMEOUTNUM_14   (0x4000UL << SMU_BUSTCFGR_BUSTIMEOUTNUM_Pos)    /* 0x00004000*/
#define SMU_BUSTCFGR_BUSTIMEOUTNUM_15   (0x8000UL << SMU_BUSTCFGR_BUSTIMEOUTNUM_Pos)    /* 0x00008000*/

#define SMU_BUSTCFGR_busMonEn_DPos      (16U)
#define SMU_BUSTCFGR_BUSTIMEOUTEN_Pos   SMU_BUSTCFGR_busMonEn_DPos
#define SMU_BUSTCFGR_BUSTIMEOUTEN_Msk   (0x1UL << SMU_BUSTCFGR_BUSTIMEOUTEN_Pos)        /* 0x00010000 */
#define SMU_BUSTCFGR_BUSTIMEOUTEN       SMU_BUSTCFGR_BUSTIMEOUTEN_Msk                   /* Bus Timeout Enable */

/* @name CLINT register bits definition */
/******************  Bits definition for CLINT_SOFTICR register  *****************/
#define CLINT_SOFTICR_SOFT_DPos     (0U)
#define CLINT_SOFTICR_SOFT_Pos      CLINT_SOFTICR_SOFT_DPos
#define CLINT_SOFTICR_SOFT_Msk      (0x1UL << CLINT_SOFTICR_SOFT_Pos)               /* 0x00000001 */
#define CLINT_SOFTICR_SOFT          CLINT_SOFTICR_SOFT_Msk                          /* Writing 1 will trigger a soft interrupt. */

/******************  Bits definition for CLINT_CMPLR register  *****************/
#define CLINT_CMPLR_CMP_DPos        (0U)
#define CLINT_CMPLR_CMP_Pos         CLINT_CMPLR_CMP_DPos
#define CLINT_CMPLR_CMP_Msk         (0xFFFFFFFFUL << CLINT_CMPLR_CMP_Pos)           /* 0xFFFFFFFF */
#define CLINT_CMPLR_CMP             CLINT_CMPLR_CMP_Msk                             /* CMP[31:0] bits (Comparator value that generates a timer interrupt when the real-time counter is equal to this value.) */

/******************  Bits definition for CLINT_CMPHR register  *****************/
#define CLINT_CMPHR_CMP_DPos        (0U)
#define CLINT_CMPHR_CMP_Pos         CLINT_CMPHR_CMP_DPos
#define CLINT_CMPHR_CMP_Msk         (0xFFFFFFFFUL << CLINT_CMPHR_CMP_Pos)           /* 0xFFFFFFFF */
#define CLINT_CMPHR_CMP             CLINT_CMPHR_CMP_Msk                             /* CMP[31:0] bits (Comparator value that generates a timer interrupt when the real-time counter is equal to this value.) */

/******************  Bits definition for CLINT_RDTIMELR register  *****************/
#define CLINT_RDTIMELR_DRTIME_DPos  (0U)
#define CLINT_RDTIMELR_DRTIME_Pos   CLINT_RDTIMELR_DRTIME_DPos
#define CLINT_RDTIMELR_DRTIME_Msk   (0xFFFFFFFFUL << CLINT_RDTIMELR_DRTIME_Pos)     /* 0xFFFFFFFF */
#define CLINT_RDTIMELR_DRTIME       CLINT_RDTIMELR_DRTIME_Msk                       /* DRTIME[31:0] bits (Real-time counter low 32 bit) */

/******************  Bits definition for CLINT_RDTIMEHR register  *****************/
#define CLINT_RDTIMEHR_DRTIME_DPos  (0U)
#define CLINT_RDTIMEHR_DRTIME_Pos   CLINT_RDTIMEHR_DRTIME_DPos
#define CLINT_RDTIMEHR_DRTIME_Msk   (0xFFFFFFFFUL << CLINT_RDTIMEHR_DRTIME_Pos)     /* 0xFFFFFFFF */
#define CLINT_RDTIMEHR_DRTIME       CLINT_RDTIMEHR_DRTIME_Msk                       /* DRTIME[31:0] bits (Real-time counter high 32 bit) */

/* @name RTC register bits definition */
/******************  Bits definition for RTC_TR register  *****************/
#define RTC_TR_TOS_DPos             (0U)
#define RTC_TR_TOS_Pos              RTC_TR_TOS_DPos
#define RTC_TR_TOS_Msk              (0xFUL << RTC_TR_TOS_Pos)                   /* 0x0000000F */
#define RTC_TR_TOS                  RTC_TR_TOS_Msk                              /* TOS[3:0] bits (tenth of a second) */

#define RTC_TR_S_DPos               (4U)
#define RTC_TR_SU_Pos               RTC_TR_S_DPos
#define RTC_TR_SU_Msk               (0xFUL << RTC_TR_SU_Pos)                    /* 0x000000F0 */
#define RTC_TR_SU                   RTC_TR_SU_Msk                               /* SU[3:0] bits (Second units) */

#define RTC_TR_TS_DPos              (8U)
#define RTC_TR_ST_Pos               RTC_TR_TS_DPos
#define RTC_TR_ST_Msk               (0x7UL << RTC_TR_ST_Pos)                    /* 0x00000700 */
#define RTC_TR_ST                   RTC_TR_ST_Msk                               /* ST[2:0] bits (Second tens) */

#define RTC_TR_M_DPos               (11U)
#define RTC_TR_MNU_Pos              RTC_TR_M_DPos
#define RTC_TR_MNU_Msk              (0xFUL << RTC_TR_MNU_Pos)                   /* 0x00007800 */
#define RTC_TR_MNU                  RTC_TR_MNU_Msk                              /* MNU[3:0] bits (Minute units) */

#define RTC_TR_TM_DPos              (15U)
#define RTC_TR_MNT_Pos              RTC_TR_TM_DPos
#define RTC_TR_MNT_Msk              (0x7UL << RTC_TR_MNT_Pos)                   /* 0x00038000 */
#define RTC_TR_MNT                  RTC_TR_MNT_Msk                              /* MNT[2:0] bits (Minute tens) */

#define RTC_TR_H_DPos               (18U)
#define RTC_TR_HU_Pos               RTC_TR_H_DPos
#define RTC_TR_HU_Msk               (0xFUL << RTC_TR_HU_Pos)                    /* 0x003C0000 */
#define RTC_TR_HU                   RTC_TR_HU_Msk                               /* HU[3:0] bits (Hour units) */

#define RTC_TR_TH_DPos              (22U)
#define RTC_TR_HT_Pos               RTC_TR_TH_DPos
#define RTC_TR_HT_Msk               (0x3UL << RTC_TR_HT_Pos)                    /* 0x00C00000 */
#define RTC_TR_HT                   RTC_TR_HT_Msk                               /* HT[1:0] bits (Hour tens) */

#define RTC_TR_DOW_DPos             (24U)
#define RTC_TR_WDU_Pos              RTC_TR_DOW_DPos
#define RTC_TR_WDU_Msk              (0x7UL << RTC_TR_WDU_Pos)                   /* 0x07000000 */
#define RTC_TR_WDU                  RTC_TR_WDU_Msk                              /* WDU[2:0] bits (Week day units) */


/******************  Bits definition for RTC_DR register  *****************/
#define RTC_DR_D_DPos               (0U)
#define RTC_DR_DU_Pos               RTC_DR_D_DPos
#define RTC_DR_DU_Msk               (0xFUL << RTC_DR_DU_Pos)                    /* 0x0000000F */
#define RTC_DR_DU                   RTC_DR_DU_Msk                               /* DU[3:0] bits (Date units) */

#define RTC_DR_TD_DPos              (4U)
#define RTC_DR_DT_Pos               RTC_DR_TD_DPos
#define RTC_DR_DT_Msk               (0x3UL << RTC_DR_DT_Pos)                    /* 0x00000030 */
#define RTC_DR_DT                   RTC_DR_DT_Msk                               /* DT[1:0] bits (Date tens) */

#define RTC_DR_M_DPos               (6U)
#define RTC_DR_MU_Pos               RTC_DR_M_DPos
#define RTC_DR_MU_Msk               (0xFUL << RTC_DR_MU_Pos)                    /* 0x000003C0 */
#define RTC_DR_MU                   RTC_DR_MU_Msk                               /* MU[3:0] bits (Month units) */

#define RTC_DR_TM_DPos              (10U)
#define RTC_DR_MT_Pos               RTC_DR_TM_DPos
#define RTC_DR_MT_Msk               (0x1UL << RTC_DR_MT_Pos)                    /* 0x00000400 */
#define RTC_DR_MT                   RTC_DR_MT_Msk                               /* Month tens */

#define RTC_DR_Y_DPos               (11U)
#define RTC_DR_YU_Pos               RTC_DR_Y_DPos
#define RTC_DR_YU_Msk               (0xFUL << RTC_DR_YU_Pos)                    /* 0x00007800 */
#define RTC_DR_YU                   RTC_DR_YU_Msk                               /* YU[3:0] bits (Year units) */

#define RTC_DR_TY_DPos              (15U)
#define RTC_DR_YT_Pos               RTC_DR_TY_DPos
#define RTC_DR_YT_Msk               (0xFUL << RTC_DR_YT_Pos)                    /* 0x00078000 */
#define RTC_DR_YT                   RTC_DR_YT_Msk                               /* YT[3:0] bits (Year tens) */

#define RTC_DR_C_DPos               (19U)
#define RTC_DR_CU_Pos               RTC_DR_C_DPos
#define RTC_DR_CU_Msk               (0xFUL << RTC_DR_CU_Pos)                    /* 0x00780000 */
#define RTC_DR_CU                   RTC_DR_CU_Msk                               /* CU[3:0] bits (Century units) */

#define RTC_DR_TC_DPos              (23U)
#define RTC_DR_CT_Pos               RTC_DR_TC_DPos
#define RTC_DR_CT_Msk               (0xFUL << RTC_DR_CT_Pos)                    /* 0x07800000 */
#define RTC_DR_CT                   RTC_DR_CT_Msk                               /* CT[3:0] bits (Century tens) */

/******************  Bits definition for RTC_ALRMTR register  *****************/
#define RTC_ALRMTR_TOS_DPos         (0U)
#define RTC_ALRMTR_TOS_Pos          RTC_ALRMTR_TOS_DPos
#define RTC_ALRMTR_TOS_Msk          (0xFUL << RTC_ALRMTR_TOS_Pos)               /* 0x0000000F */
#define RTC_ALRMTR_TOS              RTC_ALRMTR_TOS_Msk                          /* TOS[3:0] bits (tenth of a second) */

#define RTC_ALRMTR_S_DPos           (4U)
#define RTC_ALRMTR_SU_Pos           RTC_ALRMTR_S_DPos
#define RTC_ALRMTR_SU_Msk           (0xFUL << RTC_ALRMTR_SU_Pos)                /* 0x000000F0 */
#define RTC_ALRMTR_SU               RTC_ALRMTR_SU_Msk                           /* SU[3:0] bits (Second units) */

#define RTC_ALRMTR_TS_DPos          (8U)
#define RTC_ALRMTR_ST_Pos           RTC_ALRMTR_TS_DPos
#define RTC_ALRMTR_ST_Msk           (0x7UL << RTC_ALRMTR_ST_Pos)                /* 0x00000700 */
#define RTC_ALRMTR_ST               RTC_ALRMTR_ST_Msk                           /* ST[2:0] bits (Second tens) */

#define RTC_ALRMTR_M_DPos           (11U)
#define RTC_ALRMTR_MNU_Pos          RTC_ALRMTR_M_DPos
#define RTC_ALRMTR_MNU_Msk          (0xFUL << RTC_ALRMTR_MNU_Pos)               /* 0x00007800 */
#define RTC_ALRMTR_MNU              RTC_ALRMTR_MNU_Msk                          /* MNU[3:0] bits (Minute units) */

#define RTC_ALRMTR_TM_DPos          (15U)
#define RTC_ALRMTR_MNT_Pos          RTC_ALRMTR_TM_DPos
#define RTC_ALRMTR_MNT_Msk          (0x7UL << RTC_ALRMTR_MNT_Pos)               /* 0x00038000 */
#define RTC_ALRMTR_MNT              RTC_ALRMTR_MNT_Msk                          /* MNT[2:0] bits (Minute tens) */

#define RTC_ALRMTR_H_DPos           (18U)
#define RTC_ALRMTR_HU_Pos           RTC_ALRMTR_H_DPos
#define RTC_ALRMTR_HU_Msk           (0xFUL << RTC_ALRMTR_HU_Pos)                /* 0x003C0000 */
#define RTC_ALRMTR_HU               RTC_ALRMTR_HU_Msk                           /* HU[3:0] bits (Hour units) */

#define RTC_ALRMTR_TH_DPos          (22U)
#define RTC_ALRMTR_HT_Pos           RTC_ALRMTR_TH_DPos
#define RTC_ALRMTR_HT_Msk           (0x3UL << RTC_ALRMTR_HT_Pos)                /* 0x00C00000 */
#define RTC_ALRMTR_HT               RTC_ALRMTR_HT_Msk                           /* HT[1:0] bits (Hour tens) */

#define RTC_ALRMTR_DOW_DPos         (24U)
#define RTC_ALRMTR_WDU_Pos          RTC_ALRMTR_DOW_DPos
#define RTC_ALRMTR_WDU_Msk          (0x7UL << RTC_ALRMTR_WDU_Pos)               /* 0x07000000 */
#define RTC_ALRMTR_WDU              RTC_ALRMTR_WDU_Msk                          /* WDU[2:0] bits (Week day units) */

#define RTC_ALRMTR_CTOS_DPos        (27U)
#define RTC_ALRMTR_TOSCE_Pos        RTC_ALRMTR_CTOS_DPos
#define RTC_ALRMTR_TOSCE_Msk        (0x1UL << RTC_ALRMTR_TOSCE_Pos)             /* 0x08000000 */
#define RTC_ALRMTR_TOSCE            RTC_ALRMTR_TOSCE_Msk                        /* One tenth of a second comparison enable */

#define RTC_ALRMTR_CS_DPos          (28U)
#define RTC_ALRMTR_SCE_Pos          RTC_ALRMTR_CS_DPos
#define RTC_ALRMTR_SCE_Msk          (0x1UL << RTC_ALRMTR_SCE_Pos)               /* 0x10000000 */
#define RTC_ALRMTR_SCE              RTC_ALRMTR_SCE_Msk                          /* Second comparison enable */

#define RTC_ALRMTR_CM_DPos          (29U)
#define RTC_ALRMTR_MCE_Pos          RTC_ALRMTR_CM_DPos
#define RTC_ALRMTR_MCE_Msk          (0x1UL << RTC_ALRMTR_MCE_Pos)               /* 0x20000000 */
#define RTC_ALRMTR_MCE              RTC_ALRMTR_MCE_Msk                          /* Minute comparison enable */

#define RTC_ALRMTR_CH_DPos          (30U)
#define RTC_ALRMTR_HCE_Pos          RTC_ALRMTR_CH_DPos
#define RTC_ALRMTR_HCE_Msk          (0x1UL << RTC_ALRMTR_HCE_Pos)               /* 0x40000000 */
#define RTC_ALRMTR_HCE              RTC_ALRMTR_HCE_Msk                          /* Hour comparison enable */

#define RTC_ALRMTR_CDOW_DPos        (31U)
#define RTC_ALRMTR_WDCE_Pos         RTC_ALRMTR_CDOW_DPos
#define RTC_ALRMTR_WDCE_Msk         (0x1UL << RTC_ALRMTR_WDCE_Pos)              /* 0x80000000 */
#define RTC_ALRMTR_WDCE             RTC_ALRMTR_WDCE_Msk                         /* Week day comparison enable */

/******************  Bits definition for RTC_ALRMDR register  *****************/
#define RTC_ALRMDR_D_DPos           (0U)
#define RTC_ALRMDR_DU_Pos           RTC_ALRMDR_D_DPos
#define RTC_ALRMDR_DU_Msk           (0xFUL << RTC_ALRMDR_DU_Pos)                /* 0x0000000F */
#define RTC_ALRMDR_DU               RTC_ALRMDR_DU_Msk                           /* DU[3:0] bits (Date units) */

#define RTC_ALRMDR_TD_DPos          (4U)
#define RTC_ALRMDR_DT_Pos           RTC_ALRMDR_TD_DPos
#define RTC_ALRMDR_DT_Msk           (0x3UL << RTC_ALRMDR_DT_Pos)                /* 0x00000030 */
#define RTC_ALRMDR_DT               RTC_ALRMDR_DT_Msk                           /* DT[1:0] bits (Date tens) */

#define RTC_ALRMDR_M_DPos           (6U)
#define RTC_ALRMDR_MU_Pos           RTC_ALRMDR_M_DPos
#define RTC_ALRMDR_MU_Msk           (0xFUL << RTC_ALRMDR_MU_Pos)                /* 0x000003C0 */
#define RTC_ALRMDR_MU               RTC_ALRMDR_MU_Msk                           /* MU[3:0] bits (Month units) */

#define RTC_ALRMDR_TM_DPos          (10U)
#define RTC_ALRMDR_MT_Pos           RTC_ALRMDR_TM_DPos
#define RTC_ALRMDR_MT_Msk           (0x1UL << RTC_ALRMDR_MT_Pos)                /* 0x00000400 */
#define RTC_ALRMDR_MT               RTC_ALRMDR_MT_Msk                           /* Month tens */

#define RTC_ALRMDR_Y_DPos           (11U)
#define RTC_ALRMDR_YU_Pos           RTC_ALRMDR_Y_DPos
#define RTC_ALRMDR_YU_Msk           (0xFUL << RTC_ALRMDR_YU_Pos)                /* 0x00007800 */
#define RTC_ALRMDR_YU               RTC_ALRMDR_YU_Msk                           /* YU[3:0] bits (Year units) */

#define RTC_ALRMDR_TY_DPos          (15U)
#define RTC_ALRMDR_YT_Pos           RTC_ALRMDR_TY_DPos
#define RTC_ALRMDR_YT_Msk           (0xFUL << RTC_ALRMDR_YT_Pos)                /* 0x00078000 */
#define RTC_ALRMDR_YT               RTC_ALRMDR_YT_Msk                           /* YT[3:0] bits (Year tens) */

#define RTC_ALRMDR_C_DPos           (19U)
#define RTC_ALRMDR_CU_Pos           RTC_ALRMDR_C_DPos
#define RTC_ALRMDR_CU_Msk           (0xFUL << RTC_ALRMDR_CU_Pos)                /* 0x00780000 */
#define RTC_ALRMDR_CU               RTC_ALRMDR_CU_Msk                           /* CU[3:0] bits (Century units) */

#define RTC_ALRMDR_TC_DPos          (23U)
#define RTC_ALRMDR_CT_Pos           RTC_ALRMDR_TC_DPos
#define RTC_ALRMDR_CT_Msk           (0xFUL << RTC_ALRMDR_CT_Pos)                /* 0x07800000 */
#define RTC_ALRMDR_CT               RTC_ALRMDR_CT_Msk                           /* CT[3:0] bits (Century tens) */

#define RTC_ALRMDR_CD_DPos          (27U)
#define RTC_ALRMDR_DCE_Pos          RTC_ALRMDR_CD_DPos
#define RTC_ALRMDR_DCE_Msk          (0x1UL << RTC_ALRMDR_DCE_Pos)               /* 0x08000000 */
#define RTC_ALRMDR_DCE              RTC_ALRMDR_DCE_Msk                          /* Date comparison enable */

#define RTC_ALRMDR_CM_DPos          (28U)
#define RTC_ALRMDR_MCE_Pos          RTC_ALRMDR_CM_DPos
#define RTC_ALRMDR_MCE_Msk          (0x1UL << RTC_ALRMDR_MCE_Pos)               /* 0x10000000 */
#define RTC_ALRMDR_MCE              RTC_ALRMDR_MCE_Msk                          /* Month comparison enable */

#define RTC_ALRMDR_CY_DPos          (29U)
#define RTC_ALRMDR_YCE_Pos          RTC_ALRMDR_CY_DPos
#define RTC_ALRMDR_YCE_Msk          (0x1UL << RTC_ALRMDR_YCE_Pos)               /* 0x20000000 */
#define RTC_ALRMDR_YCE              RTC_ALRMDR_YCE_Msk                          /* Year comparison enable */

#define RTC_ALRMDR_CC_DPos          (30U)
#define RTC_ALRMDR_CCE_Pos          RTC_ALRMDR_CC_DPos
#define RTC_ALRMDR_CCE_Msk          (0x1UL << RTC_ALRMDR_CCE_Pos)               /* 0x40000000 */
#define RTC_ALRMDR_CCE              RTC_ALRMDR_CCE_Msk                          /* Century comparison enable */

/******************  Bits definition for RTC_CR register  *****************/
#define RTC_CR_DIV_DPos             (0U)
#define RTC_CR_DIV_Pos              RTC_CR_DIV_DPos
#define RTC_CR_DIV_Msk              (0x7FFFFFFUL << RTC_CR_DIV_Pos)             /* 0x07FFFFFF */
#define RTC_CR_DIV                  RTC_CR_DIV_Msk                              /* RTC clock divider */

#define RTC_CR_INTE_DPos            (29U)
#define RTC_CR_IE_Pos               RTC_CR_INTE_DPos
#define RTC_CR_IE_Msk               (0x1UL << RTC_CR_IE_Pos)                    /* 0x20000000 */
#define RTC_CR_IE                   RTC_CR_IE_Msk                               /* Interrupt enable position */

#define RTC_CR_ALRM_DPos            (30U)
#define RTC_CR_ALRMT_Pos            RTC_CR_ALRM_DPos
#define RTC_CR_ALRMT_Msk            (0x1UL << RTC_CR_ALRMT_Pos)                 /* 0x40000000 */
#define RTC_CR_ALRMT                RTC_CR_ALRMT_Msk                            /* Alarm trigger position */

#define RTC_CR_EN_DPos              (31U)
#define RTC_CR_EN_Pos               RTC_CR_EN_DPos
#define RTC_CR_EN_Msk               (0x1UL << RTC_CR_EN_Pos)                    /* 0x80000000 */
#define RTC_CR_EN                   RTC_CR_EN_Msk                               /* RTC enable position */

/******************  Bits definition for RTC_WUCR register  *****************/
#define RTC_WUCR_WKPE_DPos          (0U)
#define RTC_WUCR_WUTE_Pos           RTC_WUCR_WKPE_DPos
#define RTC_WUCR_WUTE_Msk           (0x1UL << RTC_WUCR_WUTE_Pos)                /* 0x00000001 */
#define RTC_WUCR_WUTE               RTC_WUCR_WUTE_Msk                           /* Wakeup timer enable */

/* @name GPIO register bits definition */
/******************  Bits definition for GPIO_RWM0CR register  *****************/
#define GPIO_RWM0CR_RW0_DPos        (0U)
#define GPIO_RWM0CR_MODER0_Pos      GPIO_RWM0CR_RW0_DPos
#define GPIO_RWM0CR_MODER0_Msk      (0x03UL << GPIO_RWM0CR_MODER0_Pos)          /* 0x00000003 */
#define GPIO_RWM0CR_MODER0          GPIO_RWM0CR_MODER0_Msk                      /* RW[1:0] bits (Control the read and write mode of Control 0) */
#define GPIO_RWM0CR_MODER0_0        (0x01UL << GPIO_RWM0CR_MODER0_Pos)          /* 0x00000001 */
#define GPIO_RWM0CR_MODER0_1        (0x02UL << GPIO_RWM0CR_MODER0_Pos)          /* 0x00000002 */

#define GPIO_RWM0CR_RW1_DPos        (2U)
#define GPIO_RWM0CR_MODER1_Pos      GPIO_RWM0CR_RW1_DPos
#define GPIO_RWM0CR_MODER1_Msk      (0x03UL << GPIO_RWM0CR_MODER1_Pos)          /* 0x0000000C */
#define GPIO_RWM0CR_MODER1          GPIO_RWM0CR_MODER1_Msk                      /* RW1[1:0] bits (Control the read and write mode of Channel 1) */
#define GPIO_RWM0CR_MODER1_0        (0x01UL << GPIO_RWM0CR_MODER1_Pos)          /* 0x00000004 */
#define GPIO_RWM0CR_MODER1_1        (0x02UL << GPIO_RWM0CR_MODER1_Pos)          /* 0x00000008 */

#define GPIO_RWM0CR_RW2_DPos        (4U)
#define GPIO_RWM0CR_MODER2_Pos      GPIO_RWM0CR_RW2_DPos
#define GPIO_RWM0CR_MODER2_Msk      (0x03UL << GPIO_RWM0CR_MODER2_Pos)          /* 0x00000030 */
#define GPIO_RWM0CR_MODER2          GPIO_RWM0CR_MODER2_Msk                      /* RW2[1:0] bits (Control the read and write mode of Channel 2) */
#define GPIO_RWM0CR_MODER2_0        (0x01UL << GPIO_RWM0CR_MODER2_Pos)          /* 0x00000010 */
#define GPIO_RWM0CR_MODER2_1        (0x02UL << GPIO_RWM0CR_MODER2_Pos)          /* 0x00000020 */

#define GPIO_RWM0CR_RW3_DPos        (6U)
#define GPIO_RWM0CR_MODER3_Pos      GPIO_RWM0CR_RW3_DPos
#define GPIO_RWM0CR_MODER3_Msk      (0x03UL << GPIO_RWM0CR_MODER3_Pos)          /* 0x000000C0 */
#define GPIO_RWM0CR_MODER3          GPIO_RWM0CR_MODER3_Msk                      /* RW3[1:0] bits (Control the read and write mode of Channel 3) */
#define GPIO_RWM0CR_MODER3_0        (0x01UL << GPIO_RWM0CR_MODER3_Pos)          /* 0x00000040 */
#define GPIO_RWM0CR_MODER3_1        (0x02UL << GPIO_RWM0CR_MODER3_Pos)          /* 0x00000080 */

#define GPIO_RWM0CR_RW4_DPos        (8U)
#define GPIO_RWM0CR_MODER4_Pos      GPIO_RWM0CR_RW4_DPos
#define GPIO_RWM0CR_MODER4_Msk      (0x03UL << GPIO_RWM0CR_MODER4_Pos)          /* 0x00000300 */
#define GPIO_RWM0CR_MODER4          GPIO_RWM0CR_MODER4_Msk                      /* RW4[1:0] bits (Control the read and write mode of Channel 4) */
#define GPIO_RWM0CR_MODER4_0        (0x01UL << GPIO_RWM0CR_MODER4_Pos)          /* 0x00000100 */
#define GPIO_RWM0CR_MODER4_1        (0x02UL << GPIO_RWM0CR_MODER4_Pos)          /* 0x00000200 */

#define GPIO_RWM0CR_RW5_DPos        (10U)
#define GPIO_RWM0CR_MODER5_Pos      GPIO_RWM0CR_RW5_DPos
#define GPIO_RWM0CR_MODER5_Msk      (0x03UL << GPIO_RWM0CR_MODER5_Pos)          /* 0x00000C00 */
#define GPIO_RWM0CR_MODER5          GPIO_RWM0CR_MODER5_Msk                      /* RW5[1:0] bits (Control the read and write mode of Channel 5) */
#define GPIO_RWM0CR_MODER5_0        (0x01UL << GPIO_RWM0CR_MODER5_Pos)          /* 0x00000400 */
#define GPIO_RWM0CR_MODER5_1        (0x02UL << GPIO_RWM0CR_MODER5_Pos)          /* 0x00000800 */

#define GPIO_RWM0CR_RW6_DPos        (12U)
#define GPIO_RWM0CR_MODER6_Pos      GPIO_RWM0CR_RW6_DPos
#define GPIO_RWM0CR_MODER6_Msk      (0x03UL << GPIO_RWM0CR_MODER6_Pos)          /* 0x00003000 */
#define GPIO_RWM0CR_MODER6          GPIO_RWM0CR_MODER6_Msk                      /* RW6[1:0] bits (Control the read and write mode of Channel 6) */
#define GPIO_RWM0CR_MODER6_0        (0x01UL << GPIO_RWM0CR_MODER6_Pos)          /* 0x00001000 */
#define GPIO_RWM0CR_MODER6_1        (0x02UL << GPIO_RWM0CR_MODER6_Pos)          /* 0x00002000 */

#define GPIO_RWM0CR_RW7_DPos        (14U)
#define GPIO_RWM0CR_MODER7_Pos      GPIO_RWM0CR_RW7_DPos
#define GPIO_RWM0CR_MODER7_Msk      (0x03UL << GPIO_RWM0CR_MODER7_Pos)          /* 0x0000C000 */
#define GPIO_RWM0CR_MODER7          GPIO_RWM0CR_MODER7_Msk                      /* RW7[1:0] bits (Control the read and write mode of Channel 7) */
#define GPIO_RWM0CR_MODER7_0        (0x01UL << GPIO_RWM0CR_MODER7_Pos)          /* 0x00004000 */
#define GPIO_RWM0CR_MODER7_1        (0x02UL << GPIO_RWM0CR_MODER7_Pos)          /* 0x00008000 */

#define GPIO_RWM0CR_RW8_DPos        (16U)
#define GPIO_RWM0CR_MODER8_Pos      GPIO_RWM0CR_RW8_DPos
#define GPIO_RWM0CR_MODER8_Msk      (0x03UL << GPIO_RWM0CR_MODER8_Pos)          /* 0x00030000 */
#define GPIO_RWM0CR_MODER8          GPIO_RWM0CR_MODER8_Msk                      /* RW8[1:0] bits (Control the read and write mode of Channel 8) */
#define GPIO_RWM0CR_MODER8_0        (0x01UL << GPIO_RWM0CR_MODER8_Pos)          /* 0x00010000 */
#define GPIO_RWM0CR_MODER8_1        (0x02UL << GPIO_RWM0CR_MODER8_Pos)          /* 0x00020000 */

#define GPIO_RWM0CR_RW9_DPos        (18U)
#define GPIO_RWM0CR_MODER9_Pos      GPIO_RWM0CR_RW9_DPos
#define GPIO_RWM0CR_MODER9_Msk      (0x03UL << GPIO_RWM0CR_MODER9_Pos)          /* 0x000C0000 */
#define GPIO_RWM0CR_MODER9          GPIO_RWM0CR_MODER9_Msk                      /* RW9[1:0] bits (Control the read and write mode of Channel 9) */
#define GPIO_RWM0CR_MODER9_0        (0x01UL << GPIO_RWM0CR_MODER9_Pos)          /* 0x00040000 */
#define GPIO_RWM0CR_MODER9_1        (0x02UL << GPIO_RWM0CR_MODER9_Pos)          /* 0x00080000 */

#define GPIO_RWM0CR_RW10_DPos       (20U)
#define GPIO_RWM0CR_MODER10_Pos     GPIO_RWM0CR_RW10_DPos
#define GPIO_RWM0CR_MODER10_Msk     (0x03UL << GPIO_RWM0CR_MODER10_Pos)         /* 0x00300000 */
#define GPIO_RWM0CR_MODER10         GPIO_RWM0CR_MODER10_Msk                     /* RW10[1:0] bits (Control the read and write mode of Channel 10) */
#define GPIO_RWM0CR_MODER10_0       (0x01UL << GPIO_RWM0CR_MODER10_Pos)         /* 0x00100000 */
#define GPIO_RWM0CR_MODER10_1       (0x02UL << GPIO_RWM0CR_MODER10_Pos)         /* 0x00200000 */

#define GPIO_RWM0CR_RW11_DPos       (22U)
#define GPIO_RWM0CR_MODER11_Pos     GPIO_RWM0CR_RW11_DPos
#define GPIO_RWM0CR_MODER11_Msk     (0x03UL << GPIO_RWM0CR_MODER11_Pos)         /* 0x00C00000 */
#define GPIO_RWM0CR_MODER11         GPIO_RWM0CR_MODER11_Msk                     /* RW11[1:0] bits (Control the read and write mode of Channel 11) */
#define GPIO_RWM0CR_MODER11_0       (0x01UL << GPIO_RWM0CR_MODER11_Pos)         /* 0x00400000 */
#define GPIO_RWM0CR_MODER11_1       (0x02UL << GPIO_RWM0CR_MODER11_Pos)         /* 0x00800000 */

#define GPIO_RWM0CR_RW12_DPos       (24U)
#define GPIO_RWM0CR_MODER12_Pos     GPIO_RWM0CR_RW12_DPos
#define GPIO_RWM0CR_MODER12_Msk     (0x03UL << GPIO_RWM0CR_MODER12_Pos)         /* 0x03000000 */
#define GPIO_RWM0CR_MODER12         GPIO_RWM0CR_MODER12_Msk                     /* RW12[1:0] bits (Control the read and write mode of Channel 12) */
#define GPIO_RWM0CR_MODER12_0       (0x01UL << GPIO_RWM0CR_MODER12_Pos)         /* 0x01000000 */
#define GPIO_RWM0CR_MODER12_1       (0x02UL << GPIO_RWM0CR_MODER12_Pos)         /* 0x02000000 */

#define GPIO_RWM0CR_RW13_DPos       (26U)
#define GPIO_RWM0CR_MODER13_Pos     GPIO_RWM0CR_RW13_DPos
#define GPIO_RWM0CR_MODER13_Msk     (0x03UL << GPIO_RWM0CR_MODER13_Pos)         /* 0x0C000000 */
#define GPIO_RWM0CR_MODER13         GPIO_RWM0CR_MODER13_Msk                     /* RW13[1:0] bits (Control the read and write mode of Channel 13) */
#define GPIO_RWM0CR_MODER13_0       (0x01UL << GPIO_RWM0CR_MODER13_Pos)         /* 0x04000000 */
#define GPIO_RWM0CR_MODER13_1       (0x02UL << GPIO_RWM0CR_MODER13_Pos)         /* 0x08000000 */

#define GPIO_RWM0CR_RW14_DPos       (28U)
#define GPIO_RWM0CR_MODER14_Pos     GPIO_RWM0CR_RW14_DPos
#define GPIO_RWM0CR_MODER14_Msk     (0x03UL << GPIO_RWM0CR_MODER14_Pos)         /* 0x30000000 */
#define GPIO_RWM0CR_MODER14         GPIO_RWM0CR_MODER14_Msk                     /* RW14[1:0] bits (Control the read and write mode of Channel 14) */
#define GPIO_RWM0CR_MODER14_0       (0x01UL << GPIO_RWM0CR_MODER14_Pos)         /* 0x10000000 */
#define GPIO_RWM0CR_MODER14_1       (0x02UL << GPIO_RWM0CR_MODER14_Pos)         /* 0x20000000 */

#define GPIO_RWM0CR_RW15_DPos       (30U)
#define GPIO_RWM0CR_MODER15_Pos     GPIO_RWM0CR_RW15_DPos
#define GPIO_RWM0CR_MODER15_Msk     (0x03UL << GPIO_RWM0CR_MODER15_Pos)         /* 0xC0000000 */
#define GPIO_RWM0CR_MODER15         GPIO_RWM0CR_MODER15_Msk                     /* RW15[1:0] bits (Control the read and write mode of Channel 15) */
#define GPIO_RWM0CR_MODER15_0       (0x01UL << GPIO_RWM0CR_MODER15_Pos)         /* 0x40000000 */
#define GPIO_RWM0CR_MODER15_1       (0x02UL << GPIO_RWM0CR_MODER15_Pos)         /* 0x80000000 */


/******************  Bits definition for GPIO_IM0CR register  *****************/
#define GPIO_IM0CR_iMode0_DPos      (0U)
#define GPIO_IM0CR_PUPDR0_Pos       GPIO_IM0CR_iMode0_DPos
#define GPIO_IM0CR_PUPDR0_Msk       (0x03UL << GPIO_IM0CR_PUPDR0_Pos)           /* 0x00000003 */
#define GPIO_IM0CR_PUPDR0           GPIO_IM0CR_PUPDR0_Msk                       /* iMode[1:0] bits (Channel 0 input mode control) */
#define GPIO_IM0CR_PUPDR0_0         (0x01UL << GPIO_IM0CR_PUPDR0_Pos)           /* 0x00000001 */
#define GPIO_IM0CR_PUPDR0_1         (0x02UL << GPIO_IM0CR_PUPDR0_Pos)           /* 0x00000002 */

#define GPIO_IM0CR_iMode1_DPos      (2U)
#define GPIO_IM0CR_PUPDR1_Pos       GPIO_IM0CR_iMode1_DPos
#define GPIO_IM0CR_PUPDR1_Msk       (0x03UL << GPIO_IM0CR_PUPDR1_Pos)           /* 0x0000000C */
#define GPIO_IM0CR_PUPDR1           GPIO_IM0CR_PUPDR1_Msk                       /* iMode1[1:0] bits (Channel 1 input mode control) */
#define GPIO_IM0CR_PUPDR1_0         (0x01UL << GPIO_IM0CR_PUPDR1_Pos)           /* 0x00000004 */
#define GPIO_IM0CR_PUPDR1_1         (0x02UL << GPIO_IM0CR_PUPDR1_Pos)           /* 0x00000008 */

#define GPIO_IM0CR_iMode2_DPos      (4U)
#define GPIO_IM0CR_PUPDR2_Pos       GPIO_IM0CR_iMode2_DPos
#define GPIO_IM0CR_PUPDR2_Msk       (0x03UL << GPIO_IM0CR_PUPDR2_Pos)           /* 0x00000030 */
#define GPIO_IM0CR_PUPDR2           GPIO_IM0CR_PUPDR2_Msk                       /* iMode2[1:0] bits (Channel 2 input mode control) */
#define GPIO_IM0CR_PUPDR2_0         (0x01UL << GPIO_IM0CR_PUPDR2_Pos)           /* 0x00000010 */
#define GPIO_IM0CR_PUPDR2_1         (0x02UL << GPIO_IM0CR_PUPDR2_Pos)           /* 0x00000020 */

#define GPIO_IM0CR_iMode3_DPos      (6U)
#define GPIO_IM0CR_PUPDR3_Pos       GPIO_IM0CR_iMode3_DPos
#define GPIO_IM0CR_PUPDR3_Msk       (0x03UL << GPIO_IM0CR_PUPDR3_Pos)           /* 0x000000C0 */
#define GPIO_IM0CR_PUPDR3           GPIO_IM0CR_PUPDR3_Msk                       /* iMode3[1:0] bits (Channel 3 input mode control) */
#define GPIO_IM0CR_PUPDR3_0         (0x01UL << GPIO_IM0CR_PUPDR3_Pos)           /* 0x00000040 */
#define GPIO_IM0CR_PUPDR3_1         (0x02UL << GPIO_IM0CR_PUPDR3_Pos)           /* 0x00000080 */

#define GPIO_IM0CR_iMode4_DPos      (8U)
#define GPIO_IM0CR_PUPDR4_Pos       GPIO_IM0CR_iMode4_DPos
#define GPIO_IM0CR_PUPDR4_Msk       (0x03UL << GPIO_IM0CR_PUPDR4_Pos)           /* 0x00000300 */
#define GPIO_IM0CR_PUPDR4           GPIO_IM0CR_PUPDR4_Msk                       /* iMode4[1:0] bits (Channel 4 input mode control) */
#define GPIO_IM0CR_PUPDR4_0         (0x01UL << GPIO_IM0CR_PUPDR4_Pos)           /* 0x00000100 */
#define GPIO_IM0CR_PUPDR4_1         (0x02UL << GPIO_IM0CR_PUPDR4_Pos)           /* 0x00000200 */

#define GPIO_IM0CR_iMode5_DPos      (10U)
#define GPIO_IM0CR_PUPDR5_Pos       GPIO_IM0CR_iMode5_DPos
#define GPIO_IM0CR_PUPDR5_Msk       (0x03UL << GPIO_IM0CR_PUPDR5_Pos)           /* 0x00000C00 */
#define GPIO_IM0CR_PUPDR5           GPIO_IM0CR_PUPDR5_Msk                       /* iMode5[1:0] bits (Channel 5 input mode control) */
#define GPIO_IM0CR_PUPDR5_0         (0x01UL << GPIO_IM0CR_PUPDR5_Pos)           /* 0x00000400 */
#define GPIO_IM0CR_PUPDR5_1         (0x02UL << GPIO_IM0CR_PUPDR5_Pos)           /* 0x00000800 */

#define GPIO_IM0CR_iMode6_DPos      (12U)
#define GPIO_IM0CR_PUPDR6_Pos       GPIO_IM0CR_iMode6_DPos
#define GPIO_IM0CR_PUPDR6_Msk       (0x03UL << GPIO_IM0CR_PUPDR6_Pos)           /* 0x00003000 */
#define GPIO_IM0CR_PUPDR6           GPIO_IM0CR_PUPDR6_Msk                       /* iMode6[1:0] bits (Channel 6 input mode control) */
#define GPIO_IM0CR_PUPDR6_0         (0x01UL << GPIO_IM0CR_PUPDR6_Pos)           /* 0x00001000 */
#define GPIO_IM0CR_PUPDR6_1         (0x02UL << GPIO_IM0CR_PUPDR6_Pos)           /* 0x00002000 */

#define GPIO_IM0CR_iMode7_DPos      (14U)
#define GPIO_IM0CR_PUPDR7_Pos       GPIO_IM0CR_iMode7_DPos
#define GPIO_IM0CR_PUPDR7_Msk       (0x03UL << GPIO_IM0CR_PUPDR7_Pos)           /* 0x0000C000 */
#define GPIO_IM0CR_PUPDR7           GPIO_IM0CR_PUPDR7_Msk                       /* iMode7[1:0] bits (Channel 7 input mode control) */
#define GPIO_IM0CR_PUPDR7_0         (0x01UL << GPIO_IM0CR_PUPDR7_Pos)           /* 0x00004000 */
#define GPIO_IM0CR_PUPDR7_1         (0x02UL << GPIO_IM0CR_PUPDR7_Pos)           /* 0x00008000 */

#define GPIO_IM0CR_iMode8_DPos      (16U)
#define GPIO_IM0CR_PUPDR8_Pos       GPIO_IM0CR_iMode8_DPos
#define GPIO_IM0CR_PUPDR8_Msk       (0x03UL << GPIO_IM0CR_PUPDR8_Pos)           /* 0x00030000 */
#define GPIO_IM0CR_PUPDR8           GPIO_IM0CR_PUPDR8_Msk                       /* iMode8[1:0] bits (Channel 8 input mode control) */
#define GPIO_IM0CR_PUPDR8_0         (0x01UL << GPIO_IM0CR_PUPDR8_Pos)           /* 0x00010000 */
#define GPIO_IM0CR_PUPDR8_1         (0x02UL << GPIO_IM0CR_PUPDR8_Pos)           /* 0x00020000 */

#define GPIO_IM0CR_iMode9_DPos      (18U)
#define GPIO_IM0CR_PUPDR9_Pos       GPIO_IM0CR_iMode9_DPos
#define GPIO_IM0CR_PUPDR9_Msk       (0x03UL << GPIO_IM0CR_PUPDR9_Pos)           /* 0x000C0000 */
#define GPIO_IM0CR_PUPDR9           GPIO_IM0CR_PUPDR9_Msk                       /* iMode9[1:0] bits (Channel 9 input mode control) */
#define GPIO_IM0CR_PUPDR9_0         (0x01UL << GPIO_IM0CR_PUPDR9_Pos)           /* 0x00040000 */
#define GPIO_IM0CR_PUPDR9_1         (0x02UL << GPIO_IM0CR_PUPDR9_Pos)           /* 0x00080000 */

#define GPIO_IM0CR_iMode10_DPos     (20U)
#define GPIO_IM0CR_PUPDR10_Pos      GPIO_IM0CR_iMode10_DPos
#define GPIO_IM0CR_PUPDR10_Msk      (0x03UL << GPIO_IM0CR_PUPDR10_Pos)          /* 0x00300000 */
#define GPIO_IM0CR_PUPDR10          GPIO_IM0CR_PUPDR10_Msk                      /* iMode10[1:0] bits (Channel 10 input mode control) */
#define GPIO_IM0CR_PUPDR10_0        (0x01UL << GPIO_IM0CR_PUPDR10_Pos)          /* 0x00100000 */
#define GPIO_IM0CR_PUPDR10_1        (0x02UL << GPIO_IM0CR_PUPDR10_Pos)          /* 0x00200000 */

#define GPIO_IM0CR_iMode11_DPos     (22U)
#define GPIO_IM0CR_PUPDR11_Pos      GPIO_IM0CR_iMode11_DPos
#define GPIO_IM0CR_PUPDR11_Msk      (0x03UL << GPIO_IM0CR_PUPDR11_Pos)          /* 0x00C00000 */
#define GPIO_IM0CR_PUPDR11          GPIO_IM0CR_PUPDR11_Msk                      /* iMode11[1:0] bits (Channel 11 input mode control) */
#define GPIO_IM0CR_PUPDR11_0        (0x01UL << GPIO_IM0CR_PUPDR11_Pos)          /* 0x00400000 */
#define GPIO_IM0CR_PUPDR11_1        (0x02UL << GPIO_IM0CR_PUPDR11_Pos)          /* 0x00800000 */

#define GPIO_IM0CR_iMode12_DPos     (24U)
#define GPIO_IM0CR_PUPDR12_Pos      GPIO_IM0CR_iMode12_DPos
#define GPIO_IM0CR_PUPDR12_Msk      (0x03UL << GPIO_IM0CR_PUPDR12_Pos)          /* 0x03000000 */
#define GPIO_IM0CR_PUPDR12          GPIO_IM0CR_PUPDR12_Msk                      /* iMode12[1:0] bits (Channel 12 input mode control) */
#define GPIO_IM0CR_PUPDR12_0        (0x01UL << GPIO_IM0CR_PUPDR12_Pos)          /* 0x01000000 */
#define GPIO_IM0CR_PUPDR12_1        (0x02UL << GPIO_IM0CR_PUPDR12_Pos)          /* 0x02000000 */

#define GPIO_IM0CR_iMode13_DPos     (26U)
#define GPIO_IM0CR_PUPDR13_Pos      GPIO_IM0CR_iMode13_DPos
#define GPIO_IM0CR_PUPDR13_Msk      (0x03UL << GPIO_IM0CR_PUPDR13_Pos)          /* 0x0C000000 */
#define GPIO_IM0CR_PUPDR13          GPIO_IM0CR_PUPDR13_Msk                      /* iMode13[1:0] bits (Channel 13 input mode control) */
#define GPIO_IM0CR_PUPDR13_0        (0x01UL << GPIO_IM0CR_PUPDR13_Pos)          /* 0x04000000 */
#define GPIO_IM0CR_PUPDR13_1        (0x02UL << GPIO_IM0CR_PUPDR13_Pos)          /* 0x08000000 */

#define GPIO_IM0CR_iMode14_DPos     (28U)
#define GPIO_IM0CR_PUPDR14_Pos      GPIO_IM0CR_iMode14_DPos
#define GPIO_IM0CR_PUPDR14_Msk      (0x03UL << GPIO_IM0CR_PUPDR14_Pos)          /* 0x30000000 */
#define GPIO_IM0CR_PUPDR14          GPIO_IM0CR_PUPDR14_Msk                      /* iMode14[1:0] bits (Channel 14 input mode control) */
#define GPIO_IM0CR_PUPDR14_0        (0x01UL << GPIO_IM0CR_PUPDR14_Pos)          /* 0x10000000 */
#define GPIO_IM0CR_PUPDR14_1        (0x02UL << GPIO_IM0CR_PUPDR14_Pos)          /* 0x20000000 */

#define GPIO_IM0CR_iMode15_DPos     (30U)
#define GPIO_IM0CR_PUPDR15_Pos      GPIO_IM0CR_iMode15_DPos
#define GPIO_IM0CR_PUPDR15_Msk      (0x03UL << GPIO_IM0CR_PUPDR15_Pos)          /* 0xC0000000 */
#define GPIO_IM0CR_PUPDR15          GPIO_IM0CR_PUPDR15_Msk                      /* iMode15[1:0] bits (Channel 15 input mode control) */
#define GPIO_IM0CR_PUPDR15_0        (0x01UL << GPIO_IM0CR_PUPDR15_Pos)          /* 0x40000000 */
#define GPIO_IM0CR_PUPDR15_1        (0x02UL << GPIO_IM0CR_PUPDR15_Pos)          /* 0x80000000 */


/******************  Bits definition for GPIO_OMCR register  *****************/
#define GPIO_OMCR_oMode0_DPos       (0U)
#define GPIO_OMCR_OT0_Pos           GPIO_OMCR_oMode0_DPos
#define GPIO_OMCR_OT0_Msk           (0x01UL << GPIO_OMCR_OT0_Pos)               /* 0x00000001 */
#define GPIO_OMCR_OT0               GPIO_OMCR_OT0_Msk                           /* Channel 0 output mode control */

#define GPIO_OMCR_oMode1_DPos       (1U)
#define GPIO_OMCR_OT1_Pos           GPIO_OMCR_oMode1_DPos
#define GPIO_OMCR_OT1_Msk           (0x01UL << GPIO_OMCR_OT1_Pos)               /* 0x00000002 */
#define GPIO_OMCR_OT1               GPIO_OMCR_OT1_Msk                           /* Channel 1 output mode control */

#define GPIO_OMCR_oMode2_DPos       (2U)
#define GPIO_OMCR_OT2_Pos           GPIO_OMCR_oMode2_DPos
#define GPIO_OMCR_OT2_Msk           (0x01UL << GPIO_OMCR_OT2_Pos)               /* 0x00000004 */
#define GPIO_OMCR_OT2               GPIO_OMCR_OT2_Msk                           /* Channel 2 output mode control */

#define GPIO_OMCR_oMode3_DPos       (3U)
#define GPIO_OMCR_OT3_Pos           GPIO_OMCR_oMode3_DPos
#define GPIO_OMCR_OT3_Msk           (0x01UL << GPIO_OMCR_OT3_Pos)               /* 0x00000008 */
#define GPIO_OMCR_OT3               GPIO_OMCR_OT3_Msk                           /* Channel 3 output mode control */

#define GPIO_OMCR_oMode4_DPos       (4U)
#define GPIO_OMCR_OT4_Pos           GPIO_OMCR_oMode4_DPos
#define GPIO_OMCR_OT4_Msk           (0x01UL << GPIO_OMCR_OT4_Pos)               /* 0x00000010 */
#define GPIO_OMCR_OT4               GPIO_OMCR_OT4_Msk                           /* Channel 4 output mode control */

#define GPIO_OMCR_oMode5_DPos       (5U)
#define GPIO_OMCR_OT5_Pos           GPIO_OMCR_oMode5_DPos
#define GPIO_OMCR_OT5_Msk           (0x01UL << GPIO_OMCR_OT5_Pos)               /* 0x00000020 */
#define GPIO_OMCR_OT5               GPIO_OMCR_OT5_Msk                           /* Channel 5 output mode control */

#define GPIO_OMCR_oMode6_DPos       (6U)
#define GPIO_OMCR_OT6_Pos           GPIO_OMCR_oMode6_DPos
#define GPIO_OMCR_OT6_Msk           (0x01UL << GPIO_OMCR_OT6_Pos)               /* 0x00000040 */
#define GPIO_OMCR_OT6               GPIO_OMCR_OT6_Msk                           /* Channel 6 output mode control */

#define GPIO_OMCR_oMode7_DPos       (7U)
#define GPIO_OMCR_OT7_Pos           GPIO_OMCR_oMode7_DPos
#define GPIO_OMCR_OT7_Msk           (0x01UL << GPIO_OMCR_OT7_Pos)               /* 0x00000080 */
#define GPIO_OMCR_OT7               GPIO_OMCR_OT7_Msk                           /* Channel 7 output mode control */

#define GPIO_OMCR_oMode8_DPos       (8U)
#define GPIO_OMCR_OT8_Pos           GPIO_OMCR_oMode8_DPos
#define GPIO_OMCR_OT8_Msk           (0x01UL << GPIO_OMCR_OT8_Pos)               /* 0x00000100 */
#define GPIO_OMCR_OT8               GPIO_OMCR_OT8_Msk                           /* Channel 8 output mode control */

#define GPIO_OMCR_oMode9_DPos       (9U)
#define GPIO_OMCR_OT9_Pos           GPIO_OMCR_oMode9_DPos
#define GPIO_OMCR_OT9_Msk           (0x01UL << GPIO_OMCR_OT9_Pos)               /* 0x00000200 */
#define GPIO_OMCR_OT9               GPIO_OMCR_OT9_Msk                           /* Channel 9 output mode control */

#define GPIO_OMCR_oMode10_DPos      (10U)
#define GPIO_OMCR_OT10_Pos          GPIO_OMCR_oMode10_DPos
#define GPIO_OMCR_OT10_Msk          (0x01UL << GPIO_OMCR_OT10_Pos)              /* 0x00000400 */
#define GPIO_OMCR_OT10              GPIO_OMCR_OT10_Msk                          /* Channel 10 output mode control */

#define GPIO_OMCR_oMode11_DPos      (11U)
#define GPIO_OMCR_OT11_Pos          GPIO_OMCR_oMode11_DPos
#define GPIO_OMCR_OT11_Msk          (0x01UL << GPIO_OMCR_OT11_Pos)              /* 0x00000800 */
#define GPIO_OMCR_OT11              GPIO_OMCR_OT11_Msk                          /* Channel 11 output mode control */

#define GPIO_OMCR_oMode12_DPos      (12U)
#define GPIO_OMCR_OT12_Pos          GPIO_OMCR_oMode12_DPos
#define GPIO_OMCR_OT12_Msk          (0x01UL << GPIO_OMCR_OT12_Pos)              /* 0x00001000 */
#define GPIO_OMCR_OT12              GPIO_OMCR_OT12_Msk                          /* Channel 12 output mode control */

#define GPIO_OMCR_oMode13_DPos      (13U)
#define GPIO_OMCR_OT13_Pos          GPIO_OMCR_oMode13_DPos
#define GPIO_OMCR_OT13_Msk          (0x01UL << GPIO_OMCR_OT13_Pos)              /* 0x00002000 */
#define GPIO_OMCR_OT13              GPIO_OMCR_OT13_Msk                          /* Channel 13 output mode control */

#define GPIO_OMCR_oMode14_DPos      (14U)
#define GPIO_OMCR_OT14_Pos          GPIO_OMCR_oMode14_DPos
#define GPIO_OMCR_OT14_Msk          (0x01UL << GPIO_OMCR_OT14_Pos)              /* 0x00004000 */
#define GPIO_OMCR_OT14              GPIO_OMCR_OT14_Msk                          /* Channel 14 output mode control */

#define GPIO_OMCR_oMode15_DPos      (15U)
#define GPIO_OMCR_OT15_Pos          GPIO_OMCR_oMode15_DPos
#define GPIO_OMCR_OT15_Msk          (0x01UL << GPIO_OMCR_OT15_Pos)              /* 0x00008000 */
#define GPIO_OMCR_OT15              GPIO_OMCR_OT15_Msk                          /* Channel 15 output mode control */


/******************  Bits definition for GPIO_OICR register  *****************/
#define GPIO_OICR_oStrength0_DPos   (0U)
#define GPIO_OICR_OSTRENGTH0_Pos    GPIO_OICR_oStrength0_DPos
#define GPIO_OICR_OSTRENGTH0_Msk    (0x03UL << GPIO_OICR_OSTRENGTH0_Pos)        /* 0x00000003 */
#define GPIO_OICR_OSTRENGTH0        GPIO_OICR_OSTRENGTH0_Msk                    /* oStrength0[1:0] bits (Channel 0 output strength control) */
#define GPIO_OICR_OSTRENGTH0_0      (0x01UL << GPIO_OICR_OSTRENGTH0_Pos)        /* 0x00000001 */
#define GPIO_OICR_OSTRENGTH0_1      (0x02UL << GPIO_OICR_OSTRENGTH0_Pos)        /* 0x00000002 */

#define GPIO_OICR_oStrength1_DPos   (2U)
#define GPIO_OICR_OSTRENGTH1_Pos    GPIO_OICR_oStrength1_DPos
#define GPIO_OICR_OSTRENGTH1_Msk    (0x03UL << GPIO_OICR_OSTRENGTH1_Pos)        /* 0x0000000C */
#define GPIO_OICR_OSTRENGTH1        GPIO_OICR_OSTRENGTH1_Msk                    /* oStrength1[1:0] bits (Channel 1 output strength control) */
#define GPIO_OICR_OSTRENGTH1_0      (0x01UL << GPIO_OICR_OSTRENGTH1_Pos)        /* 0x00000004 */
#define GPIO_OICR_OSTRENGTH1_1      (0x02UL << GPIO_OICR_OSTRENGTH1_Pos)        /* 0x00000008 */

#define GPIO_OICR_oStrength2_DPos   (4U)
#define GPIO_OICR_OSTRENGTH2_Pos    GPIO_OICR_oStrength2_DPos
#define GPIO_OICR_OSTRENGTH2_Msk    (0x03UL << GPIO_OICR_OSTRENGTH2_Pos)        /* 0x00000030 */
#define GPIO_OICR_OSTRENGTH2        GPIO_OICR_OSTRENGTH2_Msk                    /* oStrength2[1:0] bits (Channel 2 output strength control) */
#define GPIO_OICR_OSTRENGTH2_0      (0x01UL << GPIO_OICR_OSTRENGTH2_Pos)        /* 0x00000010 */
#define GPIO_OICR_OSTRENGTH2_1      (0x02UL << GPIO_OICR_OSTRENGTH2_Pos)        /* 0x00000020 */

#define GPIO_OICR_oStrength3_DPos   (6U)
#define GPIO_OICR_OSTRENGTH3_Pos    GPIO_OICR_oStrength3_DPos
#define GPIO_OICR_OSTRENGTH3_Msk    (0x03UL << GPIO_OICR_OSTRENGTH3_Pos)        /* 0x000000C0 */
#define GPIO_OICR_OSTRENGTH3        GPIO_OICR_OSTRENGTH3_Msk                    /* oStrength3[1:0] bits (Channel 3 output strength control) */
#define GPIO_OICR_OSTRENGTH3_0      (0x01UL << GPIO_OICR_OSTRENGTH3_Pos)        /* 0x00000040 */
#define GPIO_OICR_OSTRENGTH3_1      (0x02UL << GPIO_OICR_OSTRENGTH3_Pos)        /* 0x00000080 */

#define GPIO_OICR_oStrength4_DPos   (8U)
#define GPIO_OICR_OSTRENGTH4_Pos    GPIO_OICR_oStrength4_DPos
#define GPIO_OICR_OSTRENGTH4_Msk    (0x03UL << GPIO_OICR_OSTRENGTH4_Pos)        /* 0x00000300 */
#define GPIO_OICR_OSTRENGTH4        GPIO_OICR_OSTRENGTH4_Msk                    /* oStrength4[1:0] bits (Channel 4 output strength control) */
#define GPIO_OICR_OSTRENGTH4_0      (0x01UL << GPIO_OICR_OSTRENGTH4_Pos)        /* 0x00000100 */
#define GPIO_OICR_OSTRENGTH4_1      (0x02UL << GPIO_OICR_OSTRENGTH4_Pos)        /* 0x00000200 */

#define GPIO_OICR_oStrength5_DPos   (10U)
#define GPIO_OICR_OSTRENGTH5_Pos    GPIO_OICR_oStrength5_DPos
#define GPIO_OICR_OSTRENGTH5_Msk    (0x03UL << GPIO_OICR_OSTRENGTH5_Pos)        /* 0x00000C00 */
#define GPIO_OICR_OSTRENGTH5        GPIO_OICR_OSTRENGTH5_Msk                    /* oStrength5[1:0] bits (Channel 5 output strength control) */
#define GPIO_OICR_OSTRENGTH5_0      (0x01UL << GPIO_OICR_OSTRENGTH5_Pos)        /* 0x00000400 */
#define GPIO_OICR_OSTRENGTH5_1      (0x02UL << GPIO_OICR_OSTRENGTH5_Pos)        /* 0x00000800 */

#define GPIO_OICR_oStrength6_DPos   (12U)
#define GPIO_OICR_OSTRENGTH6_Pos    GPIO_OICR_oStrength6_DPos
#define GPIO_OICR_OSTRENGTH6_Msk    (0x03UL << GPIO_OICR_OSTRENGTH6_Pos)        /* 0x00003000 */
#define GPIO_OICR_OSTRENGTH6        GPIO_OICR_OSTRENGTH6_Msk                    /* oStrength6[1:0] bits (Channel 6 output strength control) */
#define GPIO_OICR_OSTRENGTH6_0      (0x01UL << GPIO_OICR_OSTRENGTH6_Pos)        /* 0x00001000 */
#define GPIO_OICR_OSTRENGTH6_1      (0x02UL << GPIO_OICR_OSTRENGTH6_Pos)        /* 0x00002000 */

#define GPIO_OICR_oStrength7_DPos   (14U)
#define GPIO_OICR_OSTRENGTH7_Pos    GPIO_OICR_oStrength7_DPos
#define GPIO_OICR_OSTRENGTH7_Msk    (0x03UL << GPIO_OICR_OSTRENGTH7_Pos)        /* 0x0000C000 */
#define GPIO_OICR_OSTRENGTH7        GPIO_OICR_OSTRENGTH7_Msk                    /* oStrength7[1:0] bits (Channel 7 output strength control) */
#define GPIO_OICR_OSTRENGTH7_0      (0x01UL << GPIO_OICR_OSTRENGTH7_Pos)        /* 0x00004000 */
#define GPIO_OICR_OSTRENGTH7_1      (0x02UL << GPIO_OICR_OSTRENGTH7_Pos)        /* 0x00008000 */

#define GPIO_OICR_oStrength8_DPos   (16U)
#define GPIO_OICR_OSTRENGTH8_Pos    GPIO_OICR_oStrength8_DPos
#define GPIO_OICR_OSTRENGTH8_Msk    (0x03UL << GPIO_OICR_OSTRENGTH8_Pos)        /* 0x00030000 */
#define GPIO_OICR_OSTRENGTH8        GPIO_OICR_OSTRENGTH8_Msk                    /* oStrength8[1:0] bits (Channel 8 output strength control) */
#define GPIO_OICR_OSTRENGTH8_0      (0x01UL << GPIO_OICR_OSTRENGTH8_Pos)        /* 0x00010000 */
#define GPIO_OICR_OSTRENGTH8_1      (0x02UL << GPIO_OICR_OSTRENGTH8_Pos)        /* 0x00020000 */

#define GPIO_OICR_oStrength9_DPos   (18U)
#define GPIO_OICR_OSTRENGTH9_Pos    GPIO_OICR_oStrength9_DPos
#define GPIO_OICR_OSTRENGTH9_Msk    (0x03UL << GPIO_OICR_OSTRENGTH9_Pos)        /* 0x000C0000 */
#define GPIO_OICR_OSTRENGTH9        GPIO_OICR_OSTRENGTH9_Msk                    /* oStrength9[1:0] bits (Channel 9 output strength control) */
#define GPIO_OICR_OSTRENGTH9_0      (0x01UL << GPIO_OICR_OSTRENGTH9_Pos)        /* 0x00040000 */
#define GPIO_OICR_OSTRENGTH9_1      (0x02UL << GPIO_OICR_OSTRENGTH9_Pos)        /* 0x00080000 */

#define GPIO_OICR_oStrength10_DPos  (20U)
#define GPIO_OICR_OSTRENGTH10_Pos   GPIO_OICR_oStrength10_DPos
#define GPIO_OICR_OSTRENGTH10_Msk   (0x03UL << GPIO_OICR_OSTRENGTH10_Pos)       /* 0x00300000 */
#define GPIO_OICR_OSTRENGTH10       GPIO_OICR_OSTRENGTH10_Msk                   /* oStrength10[1:0] bits (Channel 10 output strength control) */
#define GPIO_OICR_OSTRENGTH10_0     (0x01UL << GPIO_OICR_OSTRENGTH10_Pos)       /* 0x00100000 */
#define GPIO_OICR_OSTRENGTH10_1     (0x02UL << GPIO_OICR_OSTRENGTH10_Pos)       /* 0x00200000 */

#define GPIO_OICR_oStrength11_DPos  (22U)
#define GPIO_OICR_OSTRENGTH11_Pos   GPIO_OICR_oStrength11_DPos
#define GPIO_OICR_OSTRENGTH11_Msk   (0x03UL << GPIO_OICR_OSTRENGTH11_Pos)       /* 0x00C00000 */
#define GPIO_OICR_OSTRENGTH11       GPIO_OICR_OSTRENGTH11_Msk                   /* oStrength11[1:0] bits (Channel 11 output strength control) */
#define GPIO_OICR_OSTRENGTH11_0     (0x01UL << GPIO_OICR_OSTRENGTH11_Pos)       /* 0x00400000 */
#define GPIO_OICR_OSTRENGTH11_1     (0x02UL << GPIO_OICR_OSTRENGTH11_Pos)       /* 0x00800000 */

#define GPIO_OICR_oStrength12_DPos  (24U)
#define GPIO_OICR_OSTRENGTH12_Pos   GPIO_OICR_oStrength12_DPos
#define GPIO_OICR_OSTRENGTH12_Msk   (0x03UL << GPIO_OICR_OSTRENGTH12_Pos)       /* 0x03000000 */
#define GPIO_OICR_OSTRENGTH12       GPIO_OICR_OSTRENGTH12_Msk                   /* oStrength12[1:0] bits (Channel 12 output strength control) */
#define GPIO_OICR_OSTRENGTH12_0     (0x01UL << GPIO_OICR_OSTRENGTH12_Pos)       /* 0x01000000 */
#define GPIO_OICR_OSTRENGTH12_1     (0x02UL << GPIO_OICR_OSTRENGTH12_Pos)       /* 0x02000000 */

#define GPIO_OICR_oStrength13_DPos  (26U)
#define GPIO_OICR_OSTRENGTH13_Pos   GPIO_OICR_oStrength13_DPos
#define GPIO_OICR_OSTRENGTH13_Msk   (0x03UL << GPIO_OICR_OSTRENGTH13_Pos)       /* 0x0C000000 */
#define GPIO_OICR_OSTRENGTH13       GPIO_OICR_OSTRENGTH13_Msk                   /* oStrength13[1:0] bits (Channel 12 output strength control) */
#define GPIO_OICR_OSTRENGTH13_0     (0x01UL << GPIO_OICR_OSTRENGTH13_Pos)       /* 0x04000000 */
#define GPIO_OICR_OSTRENGTH13_1     (0x02UL << GPIO_OICR_OSTRENGTH13_Pos)       /* 0x08000000 */

#define GPIO_OICR_oStrength14_DPos  (28U)
#define GPIO_OICR_OSTRENGTH14_Pos   GPIO_OICR_oStrength14_DPos
#define GPIO_OICR_OSTRENGTH14_Msk   (0x03UL << GPIO_OICR_OSTRENGTH14_Pos)       /* 0x30000000 */
#define GPIO_OICR_OSTRENGTH14       GPIO_OICR_OSTRENGTH14_Msk                   /* oStrength14[1:0] bits (Channel 14 output strength control) */
#define GPIO_OICR_OSTRENGTH14_0     (0x01UL << GPIO_OICR_OSTRENGTH14_Pos)       /* 0x10000000 */
#define GPIO_OICR_OSTRENGTH14_1     (0x02UL << GPIO_OICR_OSTRENGTH14_Pos)       /* 0x20000000 */

#define GPIO_OICR_oStrength15_DPos  (30U)
#define GPIO_OICR_OSTRENGTH15_Pos   GPIO_OICR_oStrength15_DPos
#define GPIO_OICR_OSTRENGTH15_Msk   (0x03UL << GPIO_OICR_OSTRENGTH15_Pos)       /* 0xC0000000 */
#define GPIO_OICR_OSTRENGTH15       GPIO_OICR_OSTRENGTH15_Msk                   /* oStrength15[1:0] bits (Channel 15 output strength control) */
#define GPIO_OICR_OSTRENGTH15_0     (0x01UL << GPIO_OICR_OSTRENGTH15_Pos)       /* 0x40000000 */
#define GPIO_OICR_OSTRENGTH15_1     (0x02UL << GPIO_OICR_OSTRENGTH15_Pos)       /* 0x80000000 */


/******************  Bits definition for GPIO_MI0SR register  *****************/
#define GPIO_MI0SR_perpMux0_DPos    (0U)
#define GPIO_MI0SR_AFR0_Pos         GPIO_MI0SR_perpMux0_DPos
#define GPIO_MI0SR_AFR0_Msk         (0x07UL << GPIO_MI0SR_AFR0_Pos)             /* 0x00000007 */
#define GPIO_MI0SR_AFR0             GPIO_MI0SR_AFR0_Msk                         /* perpMux0[2:0] bits (Channel 0 multiplexing interface selection) */
#define GPIO_MI0SR_AFR0_0           (0x01UL << GPIO_MI0SR_AFR0_Pos)             /* 0x00000001 */
#define GPIO_MI0SR_AFR0_1           (0x02UL << GPIO_MI0SR_AFR0_Pos)             /* 0x00000002 */
#define GPIO_MI0SR_AFR0_2           (0x03UL << GPIO_MI0SR_AFR0_Pos)             /* 0x00000004 */

#define GPIO_MI0SR_perpMux1_DPos    (3U)
#define GPIO_MI0SR_AFR1_Pos         GPIO_MI0SR_perpMux1_DPos
#define GPIO_MI0SR_AFR1_Msk         (0x07UL << GPIO_MI0SR_AFR1_Pos)             /* 0x00000038 */
#define GPIO_MI0SR_AFR1             GPIO_MI0SR_AFR1_Msk                         /* perpMux1[2:0] bits (Channel 1 multiplexing interface selection) */
#define GPIO_MI0SR_AFR1_0           (0x01UL << GPIO_MI0SR_AFR1_Pos)             /* 0x00000008 */
#define GPIO_MI0SR_AFR1_1           (0x02UL << GPIO_MI0SR_AFR1_Pos)             /* 0x00000010 */
#define GPIO_MI0SR_AFR1_2           (0x03UL << GPIO_MI0SR_AFR1_Pos)             /* 0x00000020 */

#define GPIO_MI0SR_perpMux2_DPos    (6U)
#define GPIO_MI0SR_AFR2_Pos         GPIO_MI0SR_perpMux2_DPos
#define GPIO_MI0SR_AFR2_Msk         (0x07UL << GPIO_MI0SR_AFR2_Pos)             /* 0x000001C0 */
#define GPIO_MI0SR_AFR2             GPIO_MI0SR_AFR2_Msk                         /* perpMux2[2:0] bits (Channel 2 multiplexing interface selection) */
#define GPIO_MI0SR_AFR2_0           (0x01UL << GPIO_MI0SR_AFR2_Pos)             /* 0x00000040 */
#define GPIO_MI0SR_AFR2_1           (0x02UL << GPIO_MI0SR_AFR2_Pos)             /* 0x00000080 */
#define GPIO_MI0SR_AFR2_2           (0x03UL << GPIO_MI0SR_AFR2_Pos)             /* 0x00000100 */

#define GPIO_MI0SR_perpMux3_DPos    (9U)
#define GPIO_MI0SR_AFR3_Pos         GPIO_MI0SR_perpMux3_DPos
#define GPIO_MI0SR_AFR3_Msk         (0x07UL << GPIO_MI0SR_AFR3_Pos)             /* 0x00000E00 */
#define GPIO_MI0SR_AFR3             GPIO_MI0SR_AFR3_Msk                         /* perpMux3[2:0] bits (Channel 3 multiplexing interface selection) */
#define GPIO_MI0SR_AFR3_0           (0x01UL << GPIO_MI0SR_AFR3_Pos)             /* 0x00000200 */
#define GPIO_MI0SR_AFR3_1           (0x02UL << GPIO_MI0SR_AFR3_Pos)             /* 0x00000400 */
#define GPIO_MI0SR_AFR3_2           (0x03UL << GPIO_MI0SR_AFR3_Pos)             /* 0x00000800 */

#define GPIO_MI0SR_perpMux4_DPos    (12U)
#define GPIO_MI0SR_AFR4_Pos         GPIO_MI0SR_perpMux4_DPos
#define GPIO_MI0SR_AFR4_Msk         (0x07UL << GPIO_MI0SR_AFR4_Pos)             /* 0x00007400 */
#define GPIO_MI0SR_AFR4             GPIO_MI0SR_AFR4_Msk                         /* perpMux4[2:0] bits (Channel 4 multiplexing interface selection) */
#define GPIO_MI0SR_AFR4_0           (0x01UL << GPIO_MI0SR_AFR4_Pos)             /* 0x00001000 */
#define GPIO_MI0SR_AFR4_1           (0x02UL << GPIO_MI0SR_AFR4_Pos)             /* 0x00002000 */
#define GPIO_MI0SR_AFR4_2           (0x03UL << GPIO_MI0SR_AFR4_Pos)             /* 0x00004000 */

#define GPIO_MI0SR_perpMux5_DPos    (15U)
#define GPIO_MI0SR_AFR5_Pos         GPIO_MI0SR_perpMux5_DPos
#define GPIO_MI0SR_AFR5_Msk         (0x07UL << GPIO_MI0SR_AFR5_Pos)             /* 0x000B0000 */
#define GPIO_MI0SR_AFR5             GPIO_MI0SR_AFR5_Msk                         /* perpMux5[2:0] bits (Channel 5 multiplexing interface selection) */
#define GPIO_MI0SR_AFR5_0           (0x01UL << GPIO_MI0SR_AFR5_Pos)             /* 0x00080000 */
#define GPIO_MI0SR_AFR5_1           (0x02UL << GPIO_MI0SR_AFR5_Pos)             /* 0x00010000 */
#define GPIO_MI0SR_AFR5_2           (0x03UL << GPIO_MI0SR_AFR5_Pos)             /* 0x00020000 */

#define GPIO_MI0SR_perpMux6_DPos    (18U)
#define GPIO_MI0SR_AFR6_Pos         GPIO_MI0SR_perpMux6_DPos
#define GPIO_MI0SR_AFR6_Msk         (0x07UL << GPIO_MI0SR_AFR6_Pos)             /* 0x001C0000 */
#define GPIO_MI0SR_AFR6             GPIO_MI0SR_AFR6_Msk                         /* perpMux6[2:0] bits (Channel 6 multiplexing interface selection) */
#define GPIO_MI0SR_AFR6_0           (0x01UL << GPIO_MI0SR_AFR6_Pos)             /* 0x00040000 */
#define GPIO_MI0SR_AFR6_1           (0x02UL << GPIO_MI0SR_AFR6_Pos)             /* 0x00080000 */
#define GPIO_MI0SR_AFR6_2           (0x03UL << GPIO_MI0SR_AFR6_Pos)             /* 0x00100000 */

#define GPIO_MI0SR_perpMux7_DPos    (21U)
#define GPIO_MI0SR_AFR7_Pos         GPIO_MI0SR_perpMux7_DPos
#define GPIO_MI0SR_AFR7_Msk         (0x07UL << GPIO_MI0SR_AFR7_Pos)             /* 0x00E00000 */
#define GPIO_MI0SR_AFR7             GPIO_MI0SR_AFR7_Msk                         /* perpMux7[2:0] bits (Channel 7 multiplexing interface selection) */
#define GPIO_MI0SR_AFR7_0           (0x01UL << GPIO_MI0SR_AFR7_Pos)             /* 0x00200000 */
#define GPIO_MI0SR_AFR7_1           (0x02UL << GPIO_MI0SR_AFR7_Pos)             /* 0x00400000 */
#define GPIO_MI0SR_AFR7_2           (0x03UL << GPIO_MI0SR_AFR7_Pos)             /* 0x00800000 */

#define GPIO_MI0SR_perpMux8_DPos    (24U)
#define GPIO_MI0SR_AFR8_Pos         GPIO_MI0SR_perpMux8_DPos
#define GPIO_MI0SR_AFR8_Msk         (0x07UL << GPIO_MI0SR_AFR8_Pos)             /* 0x07000000 */
#define GPIO_MI0SR_AFR8             GPIO_MI0SR_AFR8_Msk                         /* perpMux8[2:0] bits (Channel 8 multiplexing interface selection) */
#define GPIO_MI0SR_AFR8_0           (0x01UL << GPIO_MI0SR_AFR8_Pos)             /* 0x01000000 */
#define GPIO_MI0SR_AFR8_1           (0x02UL << GPIO_MI0SR_AFR8_Pos)             /* 0x02000000 */
#define GPIO_MI0SR_AFR8_2           (0x03UL << GPIO_MI0SR_AFR8_Pos)             /* 0x04000000 */

#define GPIO_MI0SR_perpMux9_DPos    (27U)
#define GPIO_MI0SR_AFR9_Pos         GPIO_MI0SR_perpMux9_DPos
#define GPIO_MI0SR_AFR9_Msk         (0x07UL << GPIO_MI0SR_AFR9_Pos)             /* 0x38000000 */
#define GPIO_MI0SR_AFR9             GPIO_MI0SR_AFR9_Msk                         /* perpMux9[2:0] bits (Channel 9 multiplexing interface selection) */
#define GPIO_MI0SR_AFR9_0           (0x01UL << GPIO_MI0SR_AFR9_Pos)             /* 0x08000000 */
#define GPIO_MI0SR_AFR9_1           (0x02UL << GPIO_MI0SR_AFR9_Pos)             /* 0x10000000 */
#define GPIO_MI0SR_AFR9_2           (0x03UL << GPIO_MI0SR_AFR9_Pos)             /* 0x20000000 */


/******************  Bits definition for GPIO_MI1SR register  *****************/
#define GPIO_MI1SR_perpMux10_DPos   (0U)
#define GPIO_MI1SR_AFR10_Pos        GPIO_MI1SR_perpMux10_DPos
#define GPIO_MI1SR_AFR10_Msk        (0x07UL << GPIO_MI1SR_AFR10_Pos)            /* 0x00000007 */
#define GPIO_MI1SR_AFR10            GPIO_MI1SR_AFR10_Msk                        /* perpMux10[2:0] bits (Channel 10 multiplexing interface selection) */
#define GPIO_MI1SR_AFR10_0          (0x01UL << GPIO_MI1SR_AFR10_Pos)            /* 0x00000001 */
#define GPIO_MI1SR_AFR10_1          (0x02UL << GPIO_MI1SR_AFR10_Pos)            /* 0x00000002 */
#define GPIO_MI1SR_AFR10_2          (0x03UL << GPIO_MI1SR_AFR10_Pos)            /* 0x00000004 */

#define GPIO_MI1SR_perpMux11_DPos   (3U)
#define GPIO_MI1SR_AFR11_Pos        GPIO_MI1SR_perpMux11_DPos
#define GPIO_MI1SR_AFR11_Msk        (0x07UL << GPIO_MI1SR_AFR11_Pos)            /* 0x00000038 */
#define GPIO_MI1SR_AFR11            GPIO_MI1SR_AFR11_Msk                        /* perpMux11[2:0] bits (Channel 11 multiplexing interface selection) */
#define GPIO_MI1SR_AFR11_0          (0x01UL << GPIO_MI1SR_AFR11_Pos)            /* 0x00000008 */
#define GPIO_MI1SR_AFR11_1          (0x02UL << GPIO_MI1SR_AFR11_Pos)            /* 0x00000010 */
#define GPIO_MI1SR_AFR11_2          (0x03UL << GPIO_MI1SR_AFR11_Pos)            /* 0x00000020 */

#define GPIO_MI1SR_perpMux12_DPos   (6U)
#define GPIO_MI1SR_AFR12_Pos        GPIO_MI1SR_perpMux12_DPos
#define GPIO_MI1SR_AFR12_Msk        (0x07UL << GPIO_MI1SR_AFR12_Pos)            /* 0x000001C0 */
#define GPIO_MI1SR_AFR12            GPIO_MI1SR_AFR12_Msk                        /* perpMux12[2:0] bits (Channel 12 multiplexing interface selection) */
#define GPIO_MI1SR_AFR12_0          (0x01UL << GPIO_MI1SR_AFR12_Pos)            /* 0x00000040 */
#define GPIO_MI1SR_AFR12_1          (0x02UL << GPIO_MI1SR_AFR12_Pos)            /* 0x00000080 */
#define GPIO_MI1SR_AFR12_2          (0x03UL << GPIO_MI1SR_AFR12_Pos)            /* 0x00000100 */

#define GPIO_MI1SR_perpMux13_DPos   (9U)
#define GPIO_MI1SR_AFR13_Pos        GPIO_MI1SR_perpMux13_DPos
#define GPIO_MI1SR_AFR13_Msk        (0x07UL << GPIO_MI1SR_AFR13_Pos)            /* 0x00000E00 */
#define GPIO_MI1SR_AFR13            GPIO_MI1SR_AFR13_Msk                        /* perpMux13[2:0] bits (Channel 13 multiplexing interface selection) */
#define GPIO_MI1SR_AFR13_0          (0x01UL << GPIO_MI1SR_AFR13_Pos)            /* 0x00000200 */
#define GPIO_MI1SR_AFR13_1          (0x02UL << GPIO_MI1SR_AFR13_Pos)            /* 0x00000400 */
#define GPIO_MI1SR_AFR13_2          (0x03UL << GPIO_MI1SR_AFR13_Pos)            /* 0x00000800 */

#define GPIO_MI1SR_perpMux14_DPos   (12U)
#define GPIO_MI1SR_AFR14_Pos        GPIO_MI1SR_perpMux14_DPos
#define GPIO_MI1SR_AFR14_Msk        (0x07UL << GPIO_MI1SR_AFR14_Pos)            /* 0x00007000 */
#define GPIO_MI1SR_AFR14            GPIO_MI1SR_AFR14_Msk                        /* perpMux14[2:0] bits (Channel 14 multiplexing interface selection) */
#define GPIO_MI1SR_AFR14_0          (0x01UL << GPIO_MI1SR_AFR14_Pos)            /* 0x00001000 */
#define GPIO_MI1SR_AFR14_1          (0x02UL << GPIO_MI1SR_AFR14_Pos)            /* 0x00002000 */
#define GPIO_MI1SR_AFR14_2          (0x03UL << GPIO_MI1SR_AFR14_Pos)            /* 0x00004000 */

#define GPIO_MI1SR_perpMux15_DPos   (15U)
#define GPIO_MI1SR_AFR15_Pos        GPIO_MI1SR_perpMux15_DPos
#define GPIO_MI1SR_AFR15_Msk        (0x07UL << GPIO_MI1SR_AFR15_Pos)            /* 0x00030000 */
#define GPIO_MI1SR_AFR15            GPIO_MI1SR_AFR15_Msk                        /* perpMux15[2:0] bits (Channel 15 multiplexing interface selection) */
#define GPIO_MI1SR_AFR15_0          (0x01UL << GPIO_MI1SR_AFR15_Pos)            /* 0x00008000 */
#define GPIO_MI1SR_AFR15_1          (0x02UL << GPIO_MI1SR_AFR15_Pos)            /* 0x00010000 */
#define GPIO_MI1SR_AFR15_2          (0x03UL << GPIO_MI1SR_AFR15_Pos)            /* 0x00020000 */


/******************  Bits definition for GPIO_OPBR register  *****************/
#define GPIO_OPBR_oBitSet0_DPos     (0U)
#define GPIO_OPBR_ODH0_Pos          GPIO_OPBR_oBitSet0_DPos
#define GPIO_OPBR_ODH0_Msk          (0x01UL << GPIO_OPBR_ODH0_Pos)              /* 0x00000001 */
#define GPIO_OPBR_ODH0              GPIO_OPBR_ODH0_Msk                          /* Channel 0 output set */

#define GPIO_OPBR_oBitSet1_DPos     (1U)
#define GPIO_OPBR_ODH1_Pos          GPIO_OPBR_oBitSet1_DPos
#define GPIO_OPBR_ODH1_Msk          (0x01UL << GPIO_OPBR_ODH1_Pos)              /* 0x00000002 */
#define GPIO_OPBR_ODH1              GPIO_OPBR_ODH1_Msk                          /* Channel 1 output set */

#define GPIO_OPBR_oBitSet2_DPos     (2U)
#define GPIO_OPBR_ODH2_Pos          GPIO_OPBR_oBitSet2_DPos
#define GPIO_OPBR_ODH2_Msk          (0x01UL << GPIO_OPBR_ODH2_Pos)              /* 0x00000004 */
#define GPIO_OPBR_ODH2              GPIO_OPBR_ODH2_Msk                          /* Channel 2 output set */

#define GPIO_OPBR_oBitSet3_DPos     (3U)
#define GPIO_OPBR_ODH3_Pos          GPIO_OPBR_oBitSet3_DPos
#define GPIO_OPBR_ODH3_Msk          (0x01UL << GPIO_OPBR_ODH3_Pos)              /* 0x00000008 */
#define GPIO_OPBR_ODH3              GPIO_OPBR_ODH3_Msk                          /* Channel 3 output set */

#define GPIO_OPBR_oBitSet4_DPos     (4U)
#define GPIO_OPBR_ODH4_Pos          GPIO_OPBR_oBitSet4_DPos
#define GPIO_OPBR_ODH4_Msk          (0x01UL << GPIO_OPBR_ODH4_Pos)              /* 0x00000010 */
#define GPIO_OPBR_ODH4              GPIO_OPBR_ODH4_Msk                          /* Channel 4 output set */

#define GPIO_OPBR_oBitSet5_DPos     (5U)
#define GPIO_OPBR_ODH5_Pos          GPIO_OPBR_oBitSet5_DPos
#define GPIO_OPBR_ODH5_Msk          (0x01UL << GPIO_OPBR_ODH5_Pos)              /* 0x00000020 */
#define GPIO_OPBR_ODH5              GPIO_OPBR_ODH5_Msk                          /* Channel 5 output set */

#define GPIO_OPBR_oBitSet6_DPos     (6U)
#define GPIO_OPBR_ODH6_Pos          GPIO_OPBR_oBitSet6_DPos
#define GPIO_OPBR_ODH6_Msk          (0x01UL << GPIO_OPBR_ODH6_Pos)              /* 0x00000040 */
#define GPIO_OPBR_ODH6              GPIO_OPBR_ODH6_Msk                          /* Channel 6 output set */

#define GPIO_OPBR_oBitSet7_DPos     (7U)
#define GPIO_OPBR_ODH7_Pos          GPIO_OPBR_oBitSet7_DPos
#define GPIO_OPBR_ODH7_Msk          (0x01UL << GPIO_OPBR_ODH7_Pos)              /* 0x00000080 */
#define GPIO_OPBR_ODH7              GPIO_OPBR_ODH7_Msk                          /* Channel 7 output set */

#define GPIO_OPBR_oBitSet8_DPos     (8U)
#define GPIO_OPBR_ODH8_Pos          GPIO_OPBR_oBitSet8_DPos
#define GPIO_OPBR_ODH8_Msk          (0x01UL << GPIO_OPBR_ODH8_Pos)              /* 0x00000100 */
#define GPIO_OPBR_ODH8              GPIO_OPBR_ODH8_Msk                          /* Channel 8 output set */

#define GPIO_OPBR_oBitSet9_DPos     (9U)
#define GPIO_OPBR_ODH9_Pos          GPIO_OPBR_oBitSet9_DPos
#define GPIO_OPBR_ODH9_Msk          (0x01UL << GPIO_OPBR_ODH9_Pos)              /* 0x00000200 */
#define GPIO_OPBR_ODH9              GPIO_OPBR_ODH9_Msk                          /* Channel 9 output set */

#define GPIO_OPBR_oBitSet10_DPos    (10U)
#define GPIO_OPBR_ODH10_Pos         GPIO_OPBR_oBitSet10_DPos
#define GPIO_OPBR_ODH10_Msk         (0x01UL << GPIO_OPBR_ODH10_Pos)             /* 0x00000400 */
#define GPIO_OPBR_ODH10             GPIO_OPBR_ODH10_Msk                         /* Channel 10 output set */

#define GPIO_OPBR_oBitSet11_DPos    (11U)
#define GPIO_OPBR_ODH11_Pos         GPIO_OPBR_oBitSet11_DPos
#define GPIO_OPBR_ODH11_Msk         (0x01UL << GPIO_OPBR_ODH11_Pos)             /* 0x00000800 */
#define GPIO_OPBR_ODH11             GPIO_OPBR_ODH11_Msk                         /* Channel 11 output set */

#define GPIO_OPBR_oBitSet12_DPos    (12U)
#define GPIO_OPBR_ODH12_Pos         GPIO_OPBR_oBitSet12_DPos
#define GPIO_OPBR_ODH12_Msk         (0x01UL << GPIO_OPBR_ODH12_Pos)             /* 0x00001000 */
#define GPIO_OPBR_ODH12             GPIO_OPBR_ODH12_Msk                         /* Channel 12 output set */

#define GPIO_OPBR_oBitSet13_DPos    (13U)
#define GPIO_OPBR_ODH13_Pos         GPIO_OPBR_oBitSet13_DPos
#define GPIO_OPBR_ODH13_Msk         (0x01UL << GPIO_OPBR_ODH13_Pos)             /* 0x00002000 */
#define GPIO_OPBR_ODH13             GPIO_OPBR_ODH13_Msk                         /* Channel 13 output set */

#define GPIO_OPBR_oBitSet14_DPos    (14U)
#define GPIO_OPBR_ODH14_Pos         GPIO_OPBR_oBitSet14_DPos
#define GPIO_OPBR_ODH14_Msk         (0x01UL << GPIO_OPBR_ODH14_Pos)             /* 0x00004000 */
#define GPIO_OPBR_ODH14             GPIO_OPBR_ODH14_Msk                         /* Channel 14 output set */

#define GPIO_OPBR_oBitSet15_DPos    (15U)
#define GPIO_OPBR_ODH15_Pos         GPIO_OPBR_oBitSet15_DPos
#define GPIO_OPBR_ODH15_Msk         (0x01UL << GPIO_OPBR_ODH15_Pos)             /* 0x00008000 */
#define GPIO_OPBR_ODH15             GPIO_OPBR_ODH15_Msk                         /* Channel 15 output set */


/******************  Bits definition for GPIO_OBCR register  *****************/
#define GPIO_OBCR_oBitClear0_DPos   (0U)
#define GPIO_OBCR_ODL0_Pos          GPIO_OBCR_oBitClear0_DPos
#define GPIO_OBCR_ODL0_Msk          (0x01UL << GPIO_OBCR_ODL0_Pos)              /* 0x00000001 */
#define GPIO_OBCR_ODL0              GPIO_OBCR_ODL0_Msk                          /* Channel 0 output clear */

#define GPIO_OBCR_oBitClear1_DPos   (1U)
#define GPIO_OBCR_ODL1_Pos          GPIO_OBCR_oBitClear1_DPos
#define GPIO_OBCR_ODL1_Msk          (0x01UL << GPIO_OBCR_ODL1_Pos)              /* 0x00000002 */
#define GPIO_OBCR_ODL1              GPIO_OBCR_ODL1_Msk                          /* Channel 1 output clear */

#define GPIO_OBCR_oBitClear2_DPos   (2U)
#define GPIO_OBCR_ODL2_Pos          GPIO_OBCR_oBitClear2_DPos
#define GPIO_OBCR_ODL2_Msk          (0x01UL << GPIO_OBCR_ODL2_Pos)              /* 0x00000004 */
#define GPIO_OBCR_ODL2              GPIO_OBCR_ODL2_Msk                          /* Channel 2 output clear */

#define GPIO_OBCR_oBitClear3_DPos   (3U)
#define GPIO_OBCR_ODL3_Pos          GPIO_OBCR_oBitClear3_DPos
#define GPIO_OBCR_ODL3_Msk          (0x01UL << GPIO_OBCR_ODL3_Pos)              /* 0x00000008 */
#define GPIO_OBCR_ODL3              GPIO_OBCR_ODL3_Msk                          /* Channel 3 output clear */

#define GPIO_OBCR_oBitClear4_DPos   (4U)
#define GPIO_OBCR_ODL4_Pos          GPIO_OBCR_oBitClear4_DPos
#define GPIO_OBCR_ODL4_Msk          (0x01UL << GPIO_OBCR_ODL4_Pos)              /* 0x00000010 */
#define GPIO_OBCR_ODL4              GPIO_OBCR_ODL4_Msk                          /* Channel 4 output clear */

#define GPIO_OBCR_oBitClear5_DPos   (5U)
#define GPIO_OBCR_ODL5_Pos          GPIO_OBCR_oBitClear5_DPos
#define GPIO_OBCR_ODL5_Msk          (0x01UL << GPIO_OBCR_ODL5_Pos)              /* 0x00000020 */
#define GPIO_OBCR_ODL5              GPIO_OBCR_ODL5_Msk                          /* Channel 5 output clear */

#define GPIO_OBCR_oBitClear6_DPos   (6U)
#define GPIO_OBCR_ODL6_Pos          GPIO_OBCR_oBitClear6_DPos
#define GPIO_OBCR_ODL6_Msk          (0x01UL << GPIO_OBCR_ODL6_Pos)              /* 0x00000040 */
#define GPIO_OBCR_ODL6              GPIO_OBCR_ODL6_Msk                          /* Channel 6 output clear */

#define GPIO_OBCR_oBitClear7_DPos   (7U)
#define GPIO_OBCR_ODL7_Pos          GPIO_OBCR_oBitClear7_DPos
#define GPIO_OBCR_ODL7_Msk          (0x01UL << GPIO_OBCR_ODL7_Pos)              /* 0x00000080 */
#define GPIO_OBCR_ODL7              GPIO_OBCR_ODL7_Msk                          /* Channel 7 output clear */

#define GPIO_OBCR_oBitClear8_DPos   (8U)
#define GPIO_OBCR_ODL8_Pos          GPIO_OBCR_oBitClear8_DPos
#define GPIO_OBCR_ODL8_Msk          (0x01UL << GPIO_OBCR_ODL8_Pos)              /* 0x00000100 */
#define GPIO_OBCR_ODL8              GPIO_OBCR_ODL8_Msk                          /* Channel 8 output clear */

#define GPIO_OBCR_oBitClear9_DPos   (9U)
#define GPIO_OBCR_ODL9_Pos          GPIO_OBCR_oBitClear9_DPos
#define GPIO_OBCR_ODL9_Msk          (0x01UL << GPIO_OBCR_ODL9_Pos)              /* 0x00000200 */
#define GPIO_OBCR_ODL9              GPIO_OBCR_ODL9_Msk                          /* Channel 9 output clear */

#define GPIO_OBCR_oBitClear10_DPos  (10U)
#define GPIO_OBCR_ODL10_Pos         GPIO_OBCR_oBitClear10_DPos
#define GPIO_OBCR_ODL10_Msk         (0x01UL << GPIO_OBCR_ODL10_Pos)             /* 0x00000400 */
#define GPIO_OBCR_ODL10             GPIO_OBCR_ODL10_Msk                         /* Channel 10 output clear */

#define GPIO_OBCR_oBitClear11_DPos  (11U)
#define GPIO_OBCR_ODL11_Pos         GPIO_OBCR_oBitClear11_DPos
#define GPIO_OBCR_ODL11_Msk         (0x01UL << GPIO_OBCR_ODL11_Pos)             /* 0x00000800 */
#define GPIO_OBCR_ODL11             GPIO_OBCR_ODL11_Msk                         /* Channel 11 output clear */

#define GPIO_OBCR_oBitClear12_DPos  (12U)
#define GPIO_OBCR_ODL12_Pos         GPIO_OBCR_oBitClear12_DPos
#define GPIO_OBCR_ODL12_Msk         (0x01UL << GPIO_OBCR_ODL12_Pos)             /* 0x00001000 */
#define GPIO_OBCR_ODL12             GPIO_OBCR_ODL12_Msk                         /* Channel 12 output clear */

#define GPIO_OBCR_oBitClear13_DPos  (13U)
#define GPIO_OBCR_ODL13_Pos         GPIO_OBCR_oBitClear13_DPos
#define GPIO_OBCR_ODL13_Msk         (0x01UL << GPIO_OBCR_ODL13_Pos)             /* 0x00002000 */
#define GPIO_OBCR_ODL13             GPIO_OBCR_ODL13_Msk                         /* Channel 13 output clear */

#define GPIO_OBCR_oBitClear14_DPos  (14U)
#define GPIO_OBCR_ODL14_Pos         GPIO_OBCR_oBitClear14_DPos
#define GPIO_OBCR_ODL14_Msk         (0x01UL << GPIO_OBCR_ODL14_Pos)             /* 0x00004000 */
#define GPIO_OBCR_ODL14             GPIO_OBCR_ODL14_Msk                         /* Channel 14 output clear */

#define GPIO_OBCR_oBitClear15_DPos  (15U)
#define GPIO_OBCR_ODL15_Pos         GPIO_OBCR_oBitClear15_DPos
#define GPIO_OBCR_ODL15_Msk         (0x01UL << GPIO_OBCR_ODL15_Pos)             /* 0x00008000 */
#define GPIO_OBCR_ODL15             GPIO_OBCR_ODL15_Msk                         /* Channel 15 output clear */


/******************  Bits definition for GPIO_OBTR register  *****************/
#define GPIO_OBTR_oBitTrigger0_DPos   (0U)
#define GPIO_OBTR_ODT0_Pos            GPIO_OBTR_oBitTrigger0_DPos
#define GPIO_OBTR_ODT0_Msk            (0x01UL << GPIO_OBTR_ODT0_Pos)            /* 0x00000001 */
#define GPIO_OBTR_ODT0                GPIO_OBTR_ODT0_Msk                        /* Channel 0 output toggle */

#define GPIO_OBTR_oBitTrigger1_DPos   (1U)
#define GPIO_OBTR_ODT1_Pos            GPIO_OBTR_oBitTrigger1_DPos
#define GPIO_OBTR_ODT1_Msk            (0x01UL << GPIO_OBTR_ODT1_Pos)            /* 0x00000002 */
#define GPIO_OBTR_ODT1                GPIO_OBTR_ODT1_Msk                        /* Channel 1 output toggle */

#define GPIO_OBTR_oBitTrigger2_DPos   (2U)
#define GPIO_OBTR_ODT2_Pos            GPIO_OBTR_oBitTrigger2_DPos
#define GPIO_OBTR_ODT2_Msk            (0x01UL << GPIO_OBTR_ODT2_Pos)            /* 0x00000004 */
#define GPIO_OBTR_ODT2                GPIO_OBTR_ODT2_Msk                        /* Channel 2 output toggle */

#define GPIO_OBTR_oBitTrigger3_DPos   (3U)
#define GPIO_OBTR_ODT3_Pos            GPIO_OBTR_oBitTrigger3_DPos
#define GPIO_OBTR_ODT3_Msk            (0x01UL << GPIO_OBTR_ODT3_Pos)            /* 0x00000008 */
#define GPIO_OBTR_ODT3                GPIO_OBTR_ODT3_Msk                        /* Channel 3 output toggle */

#define GPIO_OBTR_oBitTrigger4_DPos   (4U)
#define GPIO_OBTR_ODT4_Pos            GPIO_OBTR_oBitTrigger4_DPos
#define GPIO_OBTR_ODT4_Msk            (0x01UL << GPIO_OBTR_ODT4_Pos)            /* 0x00000010 */
#define GPIO_OBTR_ODT4                GPIO_OBTR_ODT4_Msk                        /* Channel 4 output toggle */

#define GPIO_OBTR_oBitTrigger5_DPos   (5U)
#define GPIO_OBTR_ODT5_Pos            GPIO_OBTR_oBitTrigger5_DPos
#define GPIO_OBTR_ODT5_Msk            (0x01UL << GPIO_OBTR_ODT5_Pos)            /* 0x00000020 */
#define GPIO_OBTR_ODT5                GPIO_OBTR_ODT5_Msk                        /* Channel 5 output toggle */

#define GPIO_OBTR_oBitTrigger_DPos    (6U)
#define GPIO_OBTR_ODT6_Pos            GPIO_OBTR_oBitTrigger_DPos
#define GPIO_OBTR_ODT6_Msk            (0x01UL << GPIO_OBTR_ODT6_Pos)            /* 0x00000040 */
#define GPIO_OBTR_ODT6                GPIO_OBTR_ODT6_Msk                        /* Channel 6 output toggle */

#define GPIO_OBTR_oBitTrigger7_DPos   (7U)
#define GPIO_OBTR_ODT7_Pos            GPIO_OBTR_oBitTrigger7_DPos
#define GPIO_OBTR_ODT7_Msk            (0x01UL << GPIO_OBTR_ODT7_Pos)            /* 0x00000080 */
#define GPIO_OBTR_ODT7                GPIO_OBTR_ODT7_Msk                        /* Channel 7 output toggle */

#define GPIO_OBTR_oBitTrigger8_DPos   (8U)
#define GPIO_OBTR_ODT8_Pos            GPIO_OBTR_oBitTrigger8_DPos
#define GPIO_OBTR_ODT8_Msk            (0x01UL << GPIO_OBTR_ODT8_Pos)            /* 0x00000100 */
#define GPIO_OBTR_ODT8                GPIO_OBTR_ODT8_Msk                        /* Channel 8 output toggle */

#define GPIO_OBTR_oBitTrigger9_DPos   (9U)
#define GPIO_OBTR_ODT9_Pos            GPIO_OBTR_oBitTrigger9_DPos
#define GPIO_OBTR_ODT9_Msk            (0x01UL << GPIO_OBTR_ODT9_Pos)            /* 0x00000200 */
#define GPIO_OBTR_ODT9                GPIO_OBTR_ODT9_Msk                        /* Channel 9 output toggle */

#define GPIO_OBTR_oBitTrigger10_DPos  (10U)
#define GPIO_OBTR_ODT10_Pos           GPIO_OBTR_oBitTrigger10_DPos
#define GPIO_OBTR_ODT10_Msk           (0x01UL << GPIO_OBTR_ODT10_Pos)           /* 0x00000400 */
#define GPIO_OBTR_ODT10               GPIO_OBTR_ODT10_Msk                       /* Channel 10 output toggle */

#define GPIO_OBTR_oBitTrigger11_DPos  (11U)
#define GPIO_OBTR_ODT11_Pos           GPIO_OBTR_oBitTrigger11_DPos
#define GPIO_OBTR_ODT11_Msk           (0x01UL << GPIO_OBTR_ODT11_Pos)           /* 0x00000800 */
#define GPIO_OBTR_ODT11               GPIO_OBTR_ODT11_Msk                       /* Channel 11 output toggle */

#define GPIO_OBTR_oBitTrigger12_DPos  (12U)
#define GPIO_OBTR_ODT12_Pos           GPIO_OBTR_oBitTrigger12_DPos
#define GPIO_OBTR_ODT12_Msk           (0x01UL << GPIO_OBTR_ODT12_Pos)           /* 0x00001000 */
#define GPIO_OBTR_ODT12               GPIO_OBTR_ODT12_Msk                       /* Channel 12 output toggle */

#define GPIO_OBTR_oBitTrigger13_DPos  (13U)
#define GPIO_OBTR_ODT13_Pos           GPIO_OBTR_oBitTrigger13_DPos
#define GPIO_OBTR_ODT13_Msk           (0x01UL << GPIO_OBTR_ODT13_Pos)           /* 0x00002000 */
#define GPIO_OBTR_ODT13               GPIO_OBTR_ODT13_Msk                       /* Channel 13 output toggle */

#define GPIO_OBTR_oBitTrigger14_DPos  (14U)
#define GPIO_OBTR_ODT14_Pos           GPIO_OBTR_oBitTrigger14_DPos
#define GPIO_OBTR_ODT14_Msk           (0x01UL << GPIO_OBTR_ODT14_Pos)           /* 0x00004000 */
#define GPIO_OBTR_ODT14               GPIO_OBTR_ODT14_Msk                       /* Channel 14 output toggle */

#define GPIO_OBTR_oBitTrigger15_DPos  (15U)
#define GPIO_OBTR_ODT15_Pos           GPIO_OBTR_oBitTrigger15_DPos
#define GPIO_OBTR_ODT15_Msk           (0x01UL << GPIO_OBTR_ODT15_Pos)           /* 0x00008000 */
#define GPIO_OBTR_ODT15               GPIO_OBTR_ODT15_Msk                       /* Channel 15 output toggle */


/******************  Bits definition for GPIO_OCR register  *****************/
#define GPIO_OCR_oCtrl0_DPos        (0U)
#define GPIO_OCR_ODR0_Pos           GPIO_OCR_oCtrl0_DPos
#define GPIO_OCR_ODR0_Msk           (0x01UL << GPIO_OCR_ODR0_Pos)               /* 0x00000001 */
#define GPIO_OCR_ODR0               GPIO_OCR_ODR0_Msk                           /* Channel 0 output control */


#define GPIO_OCR_oCtrl1_DPos        (1U)
#define GPIO_OCR_ODR1_Pos           GPIO_OCR_oCtrl1_DPos
#define GPIO_OCR_ODR1_Msk           (0x01UL << GPIO_OCR_ODR1_Pos)               /* 0x00000002 */
#define GPIO_OCR_ODR1               GPIO_OCR_ODR1_Msk                           /* Channel 1 output control */

#define GPIO_OCR_oCtrl2_DPos        (2U)
#define GPIO_OCR_ODR2_Pos           GPIO_OCR_oCtrl2_DPos
#define GPIO_OCR_ODR2_Msk           (0x01UL << GPIO_OCR_ODR2_Pos)               /* 0x00000004 */
#define GPIO_OCR_ODR2               GPIO_OCR_ODR2_Msk                           /* Channel 2 output control */

#define GPIO_OCR_oCtrl3_DPos        (3U)
#define GPIO_OCR_ODR3_Pos           GPIO_OCR_oCtrl3_DPos
#define GPIO_OCR_ODR3_Msk           (0x01UL << GPIO_OCR_ODR3_Pos)               /* 0x00000008 */
#define GPIO_OCR_ODR3               GPIO_OCR_ODR3_Msk                           /* Channel 3 output control */

#define GPIO_OCR_oCtrl4_DPos        (4U)
#define GPIO_OCR_ODR4_Pos           GPIO_OCR_oCtrl4_DPos
#define GPIO_OCR_ODR4_Msk           (0x01UL << GPIO_OCR_ODR4_Pos)               /* 0x00000010 */
#define GPIO_OCR_ODR4               GPIO_OCR_ODR4_Msk                           /* Channel 4 output control */

#define GPIO_OCR_oCtrl5_DPos        (5U)
#define GPIO_OCR_ODR5_Pos           GPIO_OCR_oCtrl5_DPos
#define GPIO_OCR_ODR5_Msk           (0x01UL << GPIO_OCR_ODR5_Pos)               /* 0x00000020 */
#define GPIO_OCR_ODR5               GPIO_OCR_ODR5_Msk                           /* Channel 5 output control */

#define GPIO_OCR_oCtrl6_DPos        (6U)
#define GPIO_OCR_ODR6_Pos           GPIO_OCR_oCtrl6_DPos
#define GPIO_OCR_ODR6_Msk           (0x01UL << GPIO_OCR_ODR6_Pos)               /* 0x00000000 */
#define GPIO_OCR_ODR6               GPIO_OCR_ODR6_Msk                           /* Channel 6 output control */

#define GPIO_OCR_oCtrl7_DPos        (7U)
#define GPIO_OCR_ODR7_Pos           GPIO_OCR_oCtrl7_DPos
#define GPIO_OCR_ODR7_Msk           (0x01UL << GPIO_OCR_ODR7_Pos)               /* 0x00000040 */
#define GPIO_OCR_ODR7               GPIO_OCR_ODR7_Msk                           /* Channel 7 output control */

#define GPIO_OCR_oCtrl8_DPos        (8U)
#define GPIO_OCR_ODR8_Pos           GPIO_OCR_oCtrl8_DPos
#define GPIO_OCR_ODR8_Msk           (0x01UL << GPIO_OCR_ODR8_Pos)               /* 0x00000080 */
#define GPIO_OCR_ODR8               GPIO_OCR_ODR8_Msk                           /* Channel 8 output control */

#define GPIO_OCR_oCtrl9_DPos        (9U)
#define GPIO_OCR_ODR9_Pos           GPIO_OCR_oCtrl9_DPos
#define GPIO_OCR_ODR9_Msk           (0x01UL << GPIO_OCR_ODR9_Pos)               /* 0x00000100 */
#define GPIO_OCR_ODR9               GPIO_OCR_ODR9_Msk                           /* Channel 9 output control */

#define GPIO_OCR_oCtrl10_DPos       (10U)
#define GPIO_OCR_ODR10_Pos          GPIO_OCR_oCtrl10_DPos
#define GPIO_OCR_ODR10_Msk          (0x01UL << GPIO_OCR_ODR10_Pos)              /* 0x00000200 */
#define GPIO_OCR_ODR10              GPIO_OCR_ODR10_Msk                          /* Channel 0 output control */

#define GPIO_OCR_oCtrl11_DPos       (11U)
#define GPIO_OCR_ODR11_Pos          GPIO_OCR_oCtrl11_DPos
#define GPIO_OCR_ODR11_Msk          (0x01UL << GPIO_OCR_ODR11_Pos)              /* 0x00000400 */
#define GPIO_OCR_ODR11              GPIO_OCR_ODR11_Msk                          /* Channel 11 output control */

#define GPIO_OCR_oCtrl12_DPos       (12U)
#define GPIO_OCR_ODR12_Pos          GPIO_OCR_oCtrl12_DPos
#define GPIO_OCR_ODR12_Msk          (0x01UL << GPIO_OCR_ODR12_Pos)              /* 0x00000800 */
#define GPIO_OCR_ODR12              GPIO_OCR_ODR12_Msk                          /* Channel 12 output control */

#define GPIO_OCR_oCtrl13_DPos       (13U)
#define GPIO_OCR_ODR13_Pos          GPIO_OCR_oCtrl13_DPos
#define GPIO_OCR_ODR13_Msk          (0x01UL << GPIO_OCR_ODR13_Pos)              /* 0x00001000 */
#define GPIO_OCR_ODR13              GPIO_OCR_ODR13_Msk                          /* Channel 13 output control */

#define GPIO_OCR_oCtrl14_DPos       (14U)
#define GPIO_OCR_ODR14_Pos          GPIO_OCR_oCtrl14_DPos
#define GPIO_OCR_ODR14_Msk          (0x01UL << GPIO_OCR_ODR14_Pos)              /* 0x00002000 */
#define GPIO_OCR_ODR14              GPIO_OCR_ODR14_Msk                          /* Channel 14 output control */

#define GPIO_OCR_oCtrl15_DPos       (15U)
#define GPIO_OCR_ODR15_Pos          GPIO_OCR_oCtrl15_DPos
#define GPIO_OCR_ODR15_Msk          (0x01UL << GPIO_OCR_ODR15_Pos)              /* 0x00004000 */
#define GPIO_OCR_ODR15              GPIO_OCR_ODR15_Msk                          /* Channel 15 output control */


/******************  Bits definition for GPIO_IRR register  *****************/
#define GPIO_IRR_rdCh0_DPos         (0U)
#define GPIO_IRR_IDR0_Pos           GPIO_IRR_rdCh0_DPos
#define GPIO_IRR_IDR0_Msk           (0x01UL << GPIO_IRR_IDR0_Pos)               /* 0x00000001 */
#define GPIO_IRR_IDR0               GPIO_IRR_IDR0_Msk                           /* Channel 0 input read */

#define GPIO_IRR_rdCh1_DPos         (1U)
#define GPIO_IRR_IDR1_Pos           GPIO_IRR_rdCh1_DPos
#define GPIO_IRR_IDR1_Msk           (0x01UL << GPIO_IRR_IDR1_Pos)               /* 0x00000002 */
#define GPIO_IRR_IDR1               GPIO_IRR_IDR1_Msk                           /* Channel 1 input read */

#define GPIO_IRR_rdCh2_DPos         (2U)
#define GPIO_IRR_IDR2_Pos           GPIO_IRR_rdCh2_DPos
#define GPIO_IRR_IDR2_Msk           (0x01UL << GPIO_IRR_IDR2_Pos)               /* 0x00000004 */
#define GPIO_IRR_IDR2               GPIO_IRR_IDR2_Msk                           /* Channel 2 input read */

#define GPIO_IRR_rdCh3_DPos         (3U)
#define GPIO_IRR_IDR3_Pos           GPIO_IRR_rdCh3_DPos
#define GPIO_IRR_IDR3_Msk           (0x01UL << GPIO_IRR_IDR3_Pos)               /* 0x00000008 */
#define GPIO_IRR_IDR3               GPIO_IRR_IDR3_Msk                           /* Channel 3 input read */

#define GPIO_IRR_rdCh4_DPos         (4U)
#define GPIO_IRR_IDR4_Pos           GPIO_IRR_rdCh4_DPos
#define GPIO_IRR_IDR4_Msk           (0x01UL << GPIO_IRR_IDR4_Pos)               /* 0x00000010 */
#define GPIO_IRR_IDR4               GPIO_IRR_IDR4_Msk                           /* Channel 4 input read */

#define GPIO_IRR_rdCh5_DPos         (5U)
#define GPIO_IRR_IDR5_Pos           GPIO_IRR_rdCh5_DPos
#define GPIO_IRR_IDR5_Msk           (0x01UL << GPIO_IRR_IDR5_Pos)               /* 0x00000020 */
#define GPIO_IRR_IDR5               GPIO_IRR_IDR5_Msk                           /* Channel 5 input read */

#define GPIO_IRR_rdCh6_DPos         (6U)
#define GPIO_IRR_IDR6_Pos           GPIO_IRR_rdCh6_DPos
#define GPIO_IRR_IDR6_Msk           (0x01UL << GPIO_IRR_IDR6_Pos)               /* 0x00000040 */
#define GPIO_IRR_IDR6               GPIO_IRR_IDR6_Msk                           /* Channel 6 input read */

#define GPIO_IRR_rdCh7_DPos         (7U)
#define GPIO_IRR_IDR7_Pos           GPIO_IRR_rdCh7_DPos
#define GPIO_IRR_IDR7_Msk           (0x01UL << GPIO_IRR_IDR7_Pos)               /* 0x00000080 */
#define GPIO_IRR_IDR7               GPIO_IRR_IDR7_Msk                           /* Channel 7 input read */

#define GPIO_IRR_rdCh8_DPos         (8U)
#define GPIO_IRR_IDR8_Pos           GPIO_IRR_rdCh8_DPos
#define GPIO_IRR_IDR8_Msk           (0x01UL << GPIO_IRR_IDR8_Pos)               /* 0x00000100 */
#define GPIO_IRR_IDR8               GPIO_IRR_IDR8_Msk                           /* Channel 8 input read */

#define GPIO_IRR_rdCh9_DPos         (9U)
#define GPIO_IRR_IDR9_Pos           GPIO_IRR_rdCh9_DPos
#define GPIO_IRR_IDR9_Msk           (0x01UL << GPIO_IRR_IDR9_Pos)               /* 0x00000200 */
#define GPIO_IRR_IDR9               GPIO_IRR_IDR9_Msk                           /* Channel 9 input read */

#define GPIO_IRR_rdCh10_DPos        (10U)
#define GPIO_IRR_IDR10_Pos          GPIO_IRR_rdCh10_DPos
#define GPIO_IRR_IDR10_Msk          (0x01UL << GPIO_IRR_IDR10_Pos)              /* 0x00000400 */
#define GPIO_IRR_IDR10              GPIO_IRR_IDR10_Msk                          /* Channel 10 input read */

#define GPIO_IRR_rdCh11_DPos        (11U)
#define GPIO_IRR_IDR11_Pos          GPIO_IRR_rdCh11_DPos
#define GPIO_IRR_IDR11_Msk          (0x01UL << GPIO_IRR_IDR11_Pos)              /* 0x00000800 */
#define GPIO_IRR_IDR11              GPIO_IRR_IDR11_Msk                          /* Channel 11 input read */

#define GPIO_IRR_rdCh12_DPos        (12U)
#define GPIO_IRR_IDR12_Pos          GPIO_IRR_rdCh12_DPos
#define GPIO_IRR_IDR12_Msk          (0x01UL << GPIO_IRR_IDR12_Pos)              /* 0x00001000 */
#define GPIO_IRR_IDR12              GPIO_IRR_IDR12_Msk                          /* Channel 12 input read */

#define GPIO_IRR_rdCh13_DPos        (13U)
#define GPIO_IRR_IDR13_Pos          GPIO_IRR_rdCh13_DPos
#define GPIO_IRR_IDR13_Msk          (0x01UL << GPIO_IRR_IDR13_Pos)              /* 0x00002000 */
#define GPIO_IRR_IDR13              GPIO_IRR_IDR13_Msk                          /* Channel 13 input read */

#define GPIO_IRR_rdCh14_DPos        (14U)
#define GPIO_IRR_IDR14_Pos          GPIO_IRR_rdCh14_DPos
#define GPIO_IRR_IDR14_Msk          (0x01UL << GPIO_IRR_IDR14_Pos)              /* 0x00004000 */
#define GPIO_IRR_IDR14              GPIO_IRR_IDR14_Msk                          /* Channel 14 input read */

#define GPIO_IRR_rdCh15_DPos        (15U)
#define GPIO_IRR_IDR15_Pos          GPIO_IRR_rdCh15_DPos
#define GPIO_IRR_IDR15_Msk          (0x01UL << GPIO_IRR_IDR15_Pos)              /* 0x00008000 */
#define GPIO_IRR_IDR15              GPIO_IRR_IDR15_Msk                          /* Channel 15 input read */


/******************  Bits definition for GPIO_ITYPE0R register  *****************/
#define GPIO_ITYPE0R_intType0_DPos  (0U)
#define GPIO_ITYPE0R_ITEN0_Pos      GPIO_ITYPE0R_intType0_DPos
#define GPIO_ITYPE0R_ITEN0_Msk      (0x03UL << GPIO_ITYPE0R_ITEN0_Pos)          /* 0x00000003 */
#define GPIO_ITYPE0R_ITEN0          GPIO_ITYPE0R_ITEN0_Msk                      /* intType0[1:0] bits (Select the channel 0 interrupt type) */
#define GPIO_ITYPE0R_ITEN0_0        (0x01UL << GPIO_ITYPE0R_ITEN0_Pos)          /* 0x00000001 */
#define GPIO_ITYPE0R_ITEN0_1        (0x02UL << GPIO_ITYPE0R_ITEN0_Pos)          /* 0x00000002 */

#define GPIO_ITYPE0R_intType1_DPos  (2U)
#define GPIO_ITYPE0R_ITEN1_Pos      GPIO_ITYPE0R_intType1_DPos
#define GPIO_ITYPE0R_ITEN1_Msk      (0x03UL << GPIO_ITYPE0R_ITEN1_Pos)          /* 0x0000000C */
#define GPIO_ITYPE0R_ITEN1          GPIO_ITYPE0R_ITEN1_Msk                      /* intType1[1:0] bits (Select the channel 1 interrupt type) */
#define GPIO_ITYPE0R_ITEN1_0        (0x01UL << GPIO_ITYPE0R_ITEN1_Pos)          /* 0x00000004 */
#define GPIO_ITYPE0R_ITEN1_1        (0x02UL << GPIO_ITYPE0R_ITEN1_Pos)          /* 0x00000008 */

#define GPIO_ITYPE0R_intType2_DPos  (4U)
#define GPIO_ITYPE0R_ITEN2_Pos      GPIO_ITYPE0R_intType2_DPos
#define GPIO_ITYPE0R_ITEN2_Msk      (0x03UL << GPIO_ITYPE0R_ITEN2_Pos)          /* 0x00000030 */
#define GPIO_ITYPE0R_ITEN2          GPIO_ITYPE0R_ITEN2_Msk                      /* intType2[1:0] bits (Select the channel 2 interrupt type) */
#define GPIO_ITYPE0R_ITEN2_0        (0x01UL << GPIO_ITYPE0R_ITEN2_Pos)          /* 0x00000010 */
#define GPIO_ITYPE0R_ITEN2_1        (0x02UL << GPIO_ITYPE0R_ITEN2_Pos)          /* 0x00000020 */

#define GPIO_ITYPE0R_intType3_DPos  (6U)
#define GPIO_ITYPE0R_ITEN3_Pos      GPIO_ITYPE0R_intType3_DPos
#define GPIO_ITYPE0R_ITEN3_Msk      (0x03UL << GPIO_ITYPE0R_ITEN3_Pos)          /* 0x000000C0 */
#define GPIO_ITYPE0R_ITEN3          GPIO_ITYPE0R_ITEN3_Msk                      /* intType3[1:0] bits (Select the channel 3 interrupt type) */
#define GPIO_ITYPE0R_ITEN3_0        (0x01UL << GPIO_ITYPE0R_ITEN3_Pos)          /* 0x00000040 */
#define GPIO_ITYPE0R_ITEN3_1        (0x02UL << GPIO_ITYPE0R_ITEN3_Pos)          /* 0x00000080 */

#define GPIO_ITYPE0R_intType4_DPos  (8U)
#define GPIO_ITYPE0R_ITEN4_Pos      GPIO_ITYPE0R_intType4_DPos
#define GPIO_ITYPE0R_ITEN4_Msk      (0x03UL << GPIO_ITYPE0R_ITEN4_Pos)          /* 0x00000300 */
#define GPIO_ITYPE0R_ITEN4          GPIO_ITYPE0R_ITEN4_Msk                      /* intType4[1:0] bits (Select the channel 4 interrupt type) */
#define GPIO_ITYPE0R_ITEN4_0        (0x01UL << GPIO_ITYPE0R_ITEN4_Pos)          /* 0x00000100 */
#define GPIO_ITYPE0R_ITEN4_1        (0x02UL << GPIO_ITYPE0R_ITEN4_Pos)          /* 0x00000200 */

#define GPIO_ITYPE0R_intType5_DPos  (10U)
#define GPIO_ITYPE0R_ITEN5_Pos      GPIO_ITYPE0R_intType5_DPos
#define GPIO_ITYPE0R_ITEN5_Msk      (0x03UL << GPIO_ITYPE0R_ITEN5_Pos)          /* 0x00000C00 */
#define GPIO_ITYPE0R_ITEN5          GPIO_ITYPE0R_ITEN5_Msk                      /* intType5[1:0] bits (Select the channel 5 interrupt type) */
#define GPIO_ITYPE0R_ITEN5_0        (0x01UL << GPIO_ITYPE0R_ITEN5_Pos)          /* 0x00000400 */
#define GPIO_ITYPE0R_ITEN5_1        (0x02UL << GPIO_ITYPE0R_ITEN5_Pos)          /* 0x00000800 */

#define GPIO_ITYPE0R_intType6_DPos  (12U)
#define GPIO_ITYPE0R_ITEN6_Pos      GPIO_ITYPE0R_intType6_DPos
#define GPIO_ITYPE0R_ITEN6_Msk      (0x03UL << GPIO_ITYPE0R_ITEN6_Pos)          /* 0x00003000 */
#define GPIO_ITYPE0R_ITEN6          GPIO_ITYPE0R_ITEN6_Msk                      /* intType6[1:0] bits (Select the channel 6 interrupt type) */
#define GPIO_ITYPE0R_ITEN6_0        (0x01UL << GPIO_ITYPE0R_ITEN6_Pos)          /* 0x00001000 */
#define GPIO_ITYPE0R_ITEN6_1        (0x02UL << GPIO_ITYPE0R_ITEN6_Pos)          /* 0x00002000 */

#define GPIO_ITYPE0R_intType7_DPos  (14U)
#define GPIO_ITYPE0R_ITEN7_Pos      GPIO_ITYPE0R_intType7_DPos
#define GPIO_ITYPE0R_ITEN7_Msk      (0x03UL << GPIO_ITYPE0R_ITEN7_Pos)          /* 0x0000C000 */
#define GPIO_ITYPE0R_ITEN7          GPIO_ITYPE0R_ITEN7_Msk                      /* intType7[1:0] bits (Select the channel 7 interrupt type) */
#define GPIO_ITYPE0R_ITEN7_0        (0x01UL << GPIO_ITYPE0R_ITEN7_Pos)          /* 0x00004000 */
#define GPIO_ITYPE0R_ITEN7_1        (0x02UL << GPIO_ITYPE0R_ITEN7_Pos)          /* 0x00008000 */

#define GPIO_ITYPE0R_intType8_DPos  (16U)
#define GPIO_ITYPE0R_ITEN8_Pos      GPIO_ITYPE0R_intType8_DPos
#define GPIO_ITYPE0R_ITEN8_Msk      (0x03UL << GPIO_ITYPE0R_ITEN8_Pos)          /* 0x00030000 */
#define GPIO_ITYPE0R_ITEN8          GPIO_ITYPE0R_ITEN8_Msk                      /* intType8[1:0] bits (Select the channel 8 interrupt type) */
#define GPIO_ITYPE0R_ITEN8_0        (0x01UL << GPIO_ITYPE0R_ITEN8_Pos)          /* 0x00010000 */
#define GPIO_ITYPE0R_ITEN8_1        (0x02UL << GPIO_ITYPE0R_ITEN8_Pos)          /* 0x00020000 */

#define GPIO_ITYPE0R_intType9_DPos  (18U)
#define GPIO_ITYPE0R_ITEN9_Pos      GPIO_ITYPE0R_intType9_DPos
#define GPIO_ITYPE0R_ITEN9_Msk      (0x03UL << GPIO_ITYPE0R_ITEN9_Pos)          /* 0x000C0000 */
#define GPIO_ITYPE0R_ITEN9          GPIO_ITYPE0R_ITEN9_Msk                      /* intType9[1:0] bits (Select the channel 9 interrupt type) */
#define GPIO_ITYPE0R_ITEN9_0        (0x01UL << GPIO_ITYPE0R_ITEN9_Pos)          /* 0x00040000 */
#define GPIO_ITYPE0R_ITEN9_1        (0x02UL << GPIO_ITYPE0R_ITEN9_Pos)          /* 0x00080000 */

#define GPIO_ITYPE0R_intType10_DPos (20U)
#define GPIO_ITYPE0R_ITEN10_Pos     GPIO_ITYPE0R_intType10_DPos
#define GPIO_ITYPE0R_ITEN10_Msk     (0x03UL << GPIO_ITYPE0R_ITEN10_Pos)         /* 0x00300000 */
#define GPIO_ITYPE0R_ITEN10         GPIO_ITYPE0R_ITEN10_Msk                     /* intType10[1:0] bits (Select the channel 10 interrupt type) */
#define GPIO_ITYPE0R_ITEN10_0       (0x01UL << GPIO_ITYPE0R_ITEN10_Pos)         /* 0x00100000 */
#define GPIO_ITYPE0R_ITEN10_1       (0x02UL << GPIO_ITYPE0R_ITEN10_Pos)         /* 0x00200000 */

#define GPIO_ITYPE0R_intType11_DPos (22U)
#define GPIO_ITYPE0R_ITEN11_Pos     GPIO_ITYPE0R_intType11_DPos
#define GPIO_ITYPE0R_ITEN11_Msk     (0x03UL << GPIO_ITYPE0R_ITEN11_Pos)         /* 0x00C00000 */
#define GPIO_ITYPE0R_ITEN11         GPIO_ITYPE0R_ITEN11_Msk                     /* intType11[1:0] bits (Select the channel 11 interrupt type) */
#define GPIO_ITYPE0R_ITEN11_0       (0x01UL << GPIO_ITYPE0R_ITEN11_Pos)         /* 0x00400000 */
#define GPIO_ITYPE0R_ITEN11_1       (0x02UL << GPIO_ITYPE0R_ITEN11_Pos)         /* 0x00800000 */

#define GPIO_ITYPE0R_intType12_DPos (24U)
#define GPIO_ITYPE0R_ITEN12_Pos     GPIO_ITYPE0R_intType12_DPos
#define GPIO_ITYPE0R_ITEN12_Msk     (0x03UL << GPIO_ITYPE0R_ITEN12_Pos)         /* 0x03000000 */
#define GPIO_ITYPE0R_ITEN12         GPIO_ITYPE0R_ITEN12_Msk                     /* intType12[1:0] bits (Select the channel 12 interrupt type) */
#define GPIO_ITYPE0R_ITEN12_0       (0x01UL << GPIO_ITYPE0R_ITEN12_Pos)         /* 0x01000000 */
#define GPIO_ITYPE0R_ITEN12_1       (0x02UL << GPIO_ITYPE0R_ITEN12_Pos)         /* 0x02000000 */

#define GPIO_ITYPE0R_intType13_DPos (26U)
#define GPIO_ITYPE0R_ITEN13_Pos     GPIO_ITYPE0R_intType13_DPos
#define GPIO_ITYPE0R_ITEN13_Msk     (0x03UL << GPIO_ITYPE0R_ITEN13_Pos)         /* 0x0C000000 */
#define GPIO_ITYPE0R_ITEN13         GPIO_ITYPE0R_ITEN13_Msk                     /* intType13[1:0] bits (Select the channel 13 interrupt type) */
#define GPIO_ITYPE0R_ITEN13_0       (0x01UL << GPIO_ITYPE0R_ITEN13_Pos)         /* 0x04000000 */
#define GPIO_ITYPE0R_ITEN13_1       (0x02UL << GPIO_ITYPE0R_ITEN13_Pos)         /* 0x08000000 */

#define GPIO_ITYPE0R_intType14_DPos (28U)
#define GPIO_ITYPE0R_ITEN14_Pos     GPIO_ITYPE0R_intType14_DPos
#define GPIO_ITYPE0R_ITEN14_Msk     (0x03UL << GPIO_ITYPE0R_ITEN14_Pos)         /* 0x30000000 */
#define GPIO_ITYPE0R_ITEN14         GPIO_ITYPE0R_ITEN14_Msk                     /* intType14[1:0] bits (Select the channel 14 interrupt type) */
#define GPIO_ITYPE0R_ITEN14_0       (0x01UL << GPIO_ITYPE0R_ITEN14_Pos)         /* 0x10000000 */
#define GPIO_ITYPE0R_ITEN14_1       (0x02UL << GPIO_ITYPE0R_ITEN14_Pos)         /* 0x20000000 */

#define GPIO_ITYPE0R_intType15_DPos (30U)
#define GPIO_ITYPE0R_ITEN15_Pos     GPIO_ITYPE0R_intType15_DPos
#define GPIO_ITYPE0R_ITEN15_Msk     (0x03UL << GPIO_ITYPE0R_ITEN15_Pos)         /* 0xC0000000 */
#define GPIO_ITYPE0R_ITEN15         GPIO_ITYPE0R_ITEN15_Msk                     /* intType15[1:0] bits (Select the channel 15 interrupt type) */
#define GPIO_ITYPE0R_ITEN15_0       (0x01UL << GPIO_ITYPE0R_ITEN15_Pos)         /* 0x40000000 */
#define GPIO_ITYPE0R_ITEN15_1       (0x02UL << GPIO_ITYPE0R_ITEN15_Pos)         /* 0x80000000 */


/******************  Bits definition for GPIO_IRSR register  *****************/
#define GPIO_IRSR_Irq0_raw_DPos     (0U)
#define GPIO_IRSR_IRSR0_Pos         GPIO_IRSR_Irq0_raw_DPos
#define GPIO_IRSR_IRSR0_Msk         (0x01UL << GPIO_IRSR_IRSR0_Pos)             /* 0x00000001 */
#define GPIO_IRSR_IRSR0             GPIO_IRSR_IRSR0_Msk                         /* Interrupt Raw status of channel 0 */

#define GPIO_IRSR_Irq1_raw_DPos     (1U)
#define GPIO_IRSR_IRSR1_Pos         GPIO_IRSR_Irq1_raw_DPos
#define GPIO_IRSR_IRSR1_Msk         (0x01UL << GPIO_IRSR_IRSR1_Pos)             /* 0x00000002 */
#define GPIO_IRSR_IRSR1             GPIO_IRSR_IRSR1_Msk                         /* Interrupt Raw status of channel 1 */

#define GPIO_IRSR_Irq2_raw_DPos     (2U)
#define GPIO_IRSR_IRSR2_Pos         GPIO_IRSR_Irq2_raw_DPos
#define GPIO_IRSR_IRSR2_Msk         (0x01UL << GPIO_IRSR_IRSR2_Pos)             /* 0x00000004 */
#define GPIO_IRSR_IRSR2             GPIO_IRSR_IRSR2_Msk                         /* Interrupt Raw status of channel 2 */

#define GPIO_IRSR_Irq3_raw_DPos     (3U)
#define GPIO_IRSR_IRSR3_Pos         GPIO_IRSR_Irq3_raw_DPos
#define GPIO_IRSR_IRSR3_Msk         (0x01UL << GPIO_IRSR_IRSR3_Pos)             /* 0x00000008 */
#define GPIO_IRSR_IRSR3             GPIO_IRSR_IRSR3_Msk                         /* Interrupt Raw status of channel 3 */

#define GPIO_IRSR_Irq4_raw_DPos     (4U)
#define GPIO_IRSR_IRSR4_Pos         GPIO_IRSR_Irq4_raw_DPos
#define GPIO_IRSR_IRSR4_Msk         (0x01UL << GPIO_IRSR_IRSR4_Pos)             /* 0x00000010 */
#define GPIO_IRSR_IRSR4             GPIO_IRSR_IRSR4_Msk                         /* Interrupt Raw status of channel 4 */

#define GPIO_IRSR_Irq5_raw_DPos     (5U)
#define GPIO_IRSR_IRSR5_Pos         GPIO_IRSR_Irq5_raw_DPos
#define GPIO_IRSR_IRSR5_Msk         (0x01UL << GPIO_IRSR_IRSR5_Pos)             /* 0x00000020 */
#define GPIO_IRSR_IRSR5             GPIO_IRSR_IRSR5_Msk                         /* Interrupt Raw status of channel 5 */

#define GPIO_IRSR_Irq6_raw_DPos     (6U)
#define GPIO_IRSR_IRSR6_Pos         GPIO_IRSR_Irq6_raw_DPos
#define GPIO_IRSR_IRSR6_Msk         (0x01UL << GPIO_IRSR_IRSR6_Pos)             /* 0x00000040 */
#define GPIO_IRSR_IRSR6             GPIO_IRSR_IRSR6_Msk                         /* Interrupt Raw status of channel 6 */

#define GPIO_IRSR_Irq7_raw_DPos     (7U)
#define GPIO_IRSR_IRSR7_Pos         GPIO_IRSR_Irq7_raw_DPos
#define GPIO_IRSR_IRSR7_Msk         (0x01UL << GPIO_IRSR_IRSR7_Pos)             /* 0x00000080 */
#define GPIO_IRSR_IRSR7             GPIO_IRSR_IRSR7_Msk                         /* Interrupt Raw status of channel 7 */

#define GPIO_IRSR_Irq8_raw_DPos     (8U)
#define GPIO_IRSR_IRSR8_Pos         GPIO_IRSR_Irq8_raw_DPos
#define GPIO_IRSR_IRSR8_Msk         (0x01UL << GPIO_IRSR_IRSR8_Pos)             /* 0x00000100 */
#define GPIO_IRSR_IRSR8             GPIO_IRSR_IRSR8_Msk                         /* Interrupt Raw status of channel 8 */

#define GPIO_IRSR_Irq9_raw_DPos     (9U)
#define GPIO_IRSR_IRSR9_Pos         GPIO_IRSR_Irq9_raw_DPos
#define GPIO_IRSR_IRSR9_Msk         (0x01UL << GPIO_IRSR_IRSR9_Pos)             /* 0x00000200 */
#define GPIO_IRSR_IRSR9             GPIO_IRSR_IRSR9_Msk                         /* Interrupt Raw status of channel 9 */

#define GPIO_IRSR_Irq10_raw_DPos    (10U)
#define GPIO_IRSR_IRSR10_Pos        GPIO_IRSR_Irq10_raw_DPos
#define GPIO_IRSR_IRSR10_Msk        (0x01UL << GPIO_IRSR_IRSR10_Pos)            /* 0x00000400 */
#define GPIO_IRSR_IRSR10            GPIO_IRSR_IRSR10_Msk                        /* Interrupt Raw status of channel 10 */

#define GPIO_IRSR_Irq11_raw_DPos    (11U)
#define GPIO_IRSR_IRSR11_Pos        GPIO_IRSR_Irq11_raw_DPos
#define GPIO_IRSR_IRSR11_Msk        (0x01UL << GPIO_IRSR_IRSR11_Pos)            /* 0x00000800 */
#define GPIO_IRSR_IRSR11            GPIO_IRSR_IRSR11_Msk                        /* Interrupt Raw status of channel 11 */

#define GPIO_IRSR_Irq12_raw_DPos    (12U)
#define GPIO_IRSR_IRSR12_Pos        GPIO_IRSR_Irq12_raw_DPos
#define GPIO_IRSR_IRSR12_Msk        (0x01UL << GPIO_IRSR_IRSR12_Pos)            /* 0x00001000 */
#define GPIO_IRSR_IRSR12            GPIO_IRSR_IRSR12_Msk                        /* Interrupt Raw status of channel 12 */

#define GPIO_IRSR_Irq13_raw_DPos    (13U)
#define GPIO_IRSR_IRSR13_Pos        GPIO_IRSR_Irq13_raw_DPos
#define GPIO_IRSR_IRSR13_Msk        (0x01UL << GPIO_IRSR_IRSR13_Pos)            /* 0x00002000 */
#define GPIO_IRSR_IRSR13            GPIO_IRSR_IRSR13_Msk                        /* Interrupt Raw status of channel 13 */

#define GPIO_IRSR_Irq14_raw_DPos    (14U)
#define GPIO_IRSR_IRSR14_Pos        GPIO_IRSR_Irq14_raw_DPos
#define GPIO_IRSR_IRSR14_Msk        (0x01UL << GPIO_IRSR_IRSR14_Pos)            /* 0x00004000 */
#define GPIO_IRSR_IRSR14            GPIO_IRSR_IRSR14_Msk                        /* Interrupt Raw status of channel 14 */

#define GPIO_IRSR_Irq15_raw_DPos    (15U)
#define GPIO_IRSR_IRSR15_Pos        GPIO_IRSR_Irq15_raw_DPos
#define GPIO_IRSR_IRSR15_Msk        (0x01UL << GPIO_IRSR_IRSR15_Pos)            /* 0x00008000 */
#define GPIO_IRSR_IRSR15            GPIO_IRSR_IRSR15_Msk                        /* Interrupt Raw status of channel 15 */


/******************  Bits definition for GPIO_IFR register  *****************/
#define GPIO_IFR_Irq0_force_DPos    (0U)
#define GPIO_IFR_IFR0_Pos           GPIO_IFR_Irq0_force_DPos
#define GPIO_IFR_IFR0_Msk           (0x01UL << GPIO_IFR_IFR0_Pos)               /* 0x00000001 */
#define GPIO_IFR_IFR0               GPIO_IFR_IFR0_Msk                           /* Channel 0 interrupt force */

#define GPIO_IFR_Irq1_force_DPos    (1U)
#define GPIO_IFR_IFR1_Pos           GPIO_IFR_Irq1_force_DPos
#define GPIO_IFR_IFR1_Msk           (0x01UL << GPIO_IFR_IFR1_Pos)               /* 0x00000002 */
#define GPIO_IFR_IFR1               GPIO_IFR_IFR1_Msk                           /* Channel 1 interrupt force */

#define GPIO_IFR_Irq2_force_DPos    (2U)
#define GPIO_IFR_IFR2_Pos           GPIO_IFR_Irq2_force_DPos
#define GPIO_IFR_IFR2_Msk           (0x01UL << GPIO_IFR_IFR2_Pos)               /* 0x00000004 */
#define GPIO_IFR_IFR2               GPIO_IFR_IFR2_Msk                           /* Channel 2 interrupt force */

#define GPIO_IFR_Irq3_force_DPos    (3U)
#define GPIO_IFR_IFR3_Pos           GPIO_IFR_Irq3_force_DPos
#define GPIO_IFR_IFR3_Msk           (0x01UL << GPIO_IFR_IFR3_Pos)               /* 0x00000008 */
#define GPIO_IFR_IFR3               GPIO_IFR_IFR3_Msk                           /* Channel 3 interrupt force */

#define GPIO_IFR_Irq4_force_DPos    (4U)
#define GPIO_IFR_IFR4_Pos           GPIO_IFR_Irq4_force_DPos
#define GPIO_IFR_IFR4_Msk           (0x01UL << GPIO_IFR_IFR4_Pos)               /* 0x00000010 */
#define GPIO_IFR_IFR4               GPIO_IFR_IFR4_Msk                           /* Channel 4 interrupt force */

#define GPIO_IFR_Irq5_force_DPos    (5U)
#define GPIO_IFR_IFR5_Pos           GPIO_IFR_Irq5_force_DPos
#define GPIO_IFR_IFR5_Msk           (0x01UL << GPIO_IFR_IFR5_Pos)               /* 0x00000020 */
#define GPIO_IFR_IFR5               GPIO_IFR_IFR5_Msk                           /* Channel 5 interrupt force */

#define GPIO_IFR_Irq6_force_DPos    (6U)
#define GPIO_IFR_IFR6_Pos           GPIO_IFR_Irq6_force_DPos
#define GPIO_IFR_IFR6_Msk           (0x01UL << GPIO_IFR_IFR6_Pos)               /* 0x00000040 */
#define GPIO_IFR_IFR6               GPIO_IFR_IFR6_Msk                           /* Channel 6 interrupt force */

#define GPIO_IFR_Irq7_force_DPos    (7U)
#define GPIO_IFR_IFR7_Pos           GPIO_IFR_Irq7_force_DPos
#define GPIO_IFR_IFR7_Msk           (0x01UL << GPIO_IFR_IFR7_Pos)               /* 0x00000080 */
#define GPIO_IFR_IFR7               GPIO_IFR_IFR7_Msk                           /* Channel 7 interrupt force */

#define GPIO_IFR_Irq8_force_DPos    (8U)
#define GPIO_IFR_IFR8_Pos           GPIO_IFR_Irq8_force_DPos
#define GPIO_IFR_IFR8_Msk           (0x01UL << GPIO_IFR_IFR8_Pos)               /* 0x00000100 */
#define GPIO_IFR_IFR8               GPIO_IFR_IFR8_Msk                           /* Channel 8 interrupt force */

#define GPIO_IFR_Irq9_force_DPos    (9U)
#define GPIO_IFR_IFR9_Pos           GPIO_IFR_Irq9_force_DPos
#define GPIO_IFR_IFR9_Msk           (0x01UL << GPIO_IFR_IFR9_Pos)               /* 0x00000200 */
#define GPIO_IFR_IFR9               GPIO_IFR_IFR9_Msk                           /* Channel 9 interrupt force */

#define GPIO_IFR_Irq10_force_DPos   (10U)
#define GPIO_IFR_IFR10_Pos          GPIO_IFR_Irq10_force_DPos
#define GPIO_IFR_IFR10_Msk          (0x01UL << GPIO_IFR_IFR10_Pos)              /* 0x00000400 */
#define GPIO_IFR_IFR10              GPIO_IFR_IFR10_Msk                          /* Channel 10 interrupt force */

#define GPIO_IFR_Irq11_force_DPos   (11U)
#define GPIO_IFR_IFR11_Pos          GPIO_IFR_Irq11_force_DPos
#define GPIO_IFR_IFR11_Msk          (0x01UL << GPIO_IFR_IFR11_Pos)              /* 0x00000800 */
#define GPIO_IFR_IFR11              GPIO_IFR_IFR11_Msk                          /* Channel 11 interrupt force */

#define GPIO_IFR_Irq12_force_DPos   (12U)
#define GPIO_IFR_IFR12_Pos          GPIO_IFR_Irq12_force_DPos
#define GPIO_IFR_IFR12_Msk          (0x01UL << GPIO_IFR_IFR12_Pos)              /* 0x00001000 */
#define GPIO_IFR_IFR12              GPIO_IFR_IFR12_Msk                          /* Channel 12 interrupt force */

#define GPIO_IFR_Irq13_force_DPos   (13U)
#define GPIO_IFR_IFR13_Pos          GPIO_IFR_Irq13_force_DPos
#define GPIO_IFR_IFR13_Msk          (0x01UL << GPIO_IFR_IFR13_Pos)              /* 0x00002000 */
#define GPIO_IFR_IFR13              GPIO_IFR_IFR13_Msk                          /* Channel 13 interrupt force */

#define GPIO_IFR_Irq14_force_DPos   (14U)
#define GPIO_IFR_IFR14_Pos          GPIO_IFR_Irq14_force_DPos
#define GPIO_IFR_IFR14_Msk          (0x01UL << GPIO_IFR_IFR14_Pos)              /* 0x00004000 */
#define GPIO_IFR_IFR14              GPIO_IFR_IFR14_Msk                          /* Channel 14 interrupt force */

#define GPIO_IFR_Irq15_force_DPos   (15U)
#define GPIO_IFR_IFR15_Pos          GPIO_IFR_Irq15_force_DPos
#define GPIO_IFR_IFR15_Msk          (0x01UL << GPIO_IFR_IFR15_Pos)              /* 0x00008000 */
#define GPIO_IFR_IFR15              GPIO_IFR_IFR15_Msk                          /* Channel 15 interrupt force */


/******************  Bits definition for GPIO_IMR register  *****************/
#define GPIO_IMR_Irq0_mask_DPos     (0U)
#define GPIO_IMR_IMR0_Pos           GPIO_IMR_Irq0_mask_DPos
#define GPIO_IMR_IMR0_Msk           (0x01UL << GPIO_IMR_IMR0_Pos)               /* 0x00000001 */
#define GPIO_IMR_IMR0               GPIO_IMR_IMR0_Msk                           /* Channel 0 interrupt mask */

#define GPIO_IMR_Irq1_mask_DPos     (1U)
#define GPIO_IMR_IMR1_Pos           GPIO_IMR_Irq1_mask_DPos
#define GPIO_IMR_IMR1_Msk           (0x01UL << GPIO_IMR_IMR1_Pos)               /* 0x00000002 */
#define GPIO_IMR_IMR1               GPIO_IMR_IMR1_Msk                           /* Channel 1 interrupt mask */

#define GPIO_IMR_Irq2_mask_DPos     (2U)
#define GPIO_IMR_IMR2_Pos           GPIO_IMR_Irq2_mask_DPos
#define GPIO_IMR_IMR2_Msk           (0x01UL << GPIO_IMR_IMR2_Pos)               /* 0x00000004 */
#define GPIO_IMR_IMR2               GPIO_IMR_IMR2_Msk                           /* Channel 2 interrupt mask */

#define GPIO_IMR_Irq3_mask_DPos     (3U)
#define GPIO_IMR_IMR3_Pos           GPIO_IMR_Irq3_mask_DPos
#define GPIO_IMR_IMR3_Msk           (0x01UL << GPIO_IMR_IMR3_Pos)               /* 0x00000008 */
#define GPIO_IMR_IMR3               GPIO_IMR_IMR3_Msk                           /* Channel 3 interrupt mask */

#define GPIO_IMR_Irq4_mask_DPos     (4U)
#define GPIO_IMR_IMR4_Pos           GPIO_IMR_Irq4_mask_DPos
#define GPIO_IMR_IMR4_Msk           (0x01UL << GPIO_IMR_IMR4_Pos)               /* 0x00000010 */
#define GPIO_IMR_IMR4               GPIO_IMR_IMR4_Msk                           /* Channel 4 interrupt mask */

#define GPIO_IMR_Irq5_mask_DPos     (5U)
#define GPIO_IMR_IMR5_Pos           GPIO_IMR_Irq5_mask_DPos
#define GPIO_IMR_IMR5_Msk           (0x01UL << GPIO_IMR_IMR5_Pos)               /* 0x00000020 */
#define GPIO_IMR_IMR5               GPIO_IMR_IMR5_Msk                           /* Channel 5 interrupt mask */

#define GPIO_IMR_Irq6_mask_DPos     (6U)
#define GPIO_IMR_IMR6_Pos           GPIO_IMR_Irq6_mask_DPos
#define GPIO_IMR_IMR6_Msk           (0x01UL << GPIO_IMR_IMR6_Pos)               /* 0x00000040 */
#define GPIO_IMR_IMR6               GPIO_IMR_IMR6_Msk                           /* Channel 6 interrupt mask */

#define GPIO_IMR_Irq7_mask_DPos     (7U)
#define GPIO_IMR_IMR7_Pos           GPIO_IMR_Irq7_mask_DPos
#define GPIO_IMR_IMR7_Msk           (0x01UL << GPIO_IMR_IMR7_Pos)               /* 0x00000080 */
#define GPIO_IMR_IMR7               GPIO_IMR_IMR7_Msk                           /* Channel 7 interrupt mask */

#define GPIO_IMR_Irq8_mask_DPos     (8U)
#define GPIO_IMR_IMR8_Pos           GPIO_IMR_Irq8_mask_DPos
#define GPIO_IMR_IMR8_Msk           (0x01UL << GPIO_IMR_IMR8_Pos)               /* 0x00000100 */
#define GPIO_IMR_IMR8               GPIO_IMR_IMR8_Msk                           /* Channel 8 interrupt mask */

#define GPIO_IMR_Irq9_mask_DPos     (9U)
#define GPIO_IMR_IMR9_Pos           GPIO_IMR_Irq9_mask_DPos
#define GPIO_IMR_IMR9_Msk           (0x01UL << GPIO_IMR_IMR9_Pos)               /* 0x00000200 */
#define GPIO_IMR_IMR9               GPIO_IMR_IMR9_Msk                           /* Channel 9 interrupt mask */

#define GPIO_IMR_Irq10_mask_DPos    (10U)
#define GPIO_IMR_IMR10_Pos          GPIO_IMR_Irq10_mask_DPos
#define GPIO_IMR_IMR10_Msk          (0x01UL << GPIO_IMR_IMR10_Pos)              /* 0x00000400 */
#define GPIO_IMR_IMR10              GPIO_IMR_IMR10_Msk                          /* Channel 10 interrupt mask */

#define GPIO_IMR_Irq11_mask_DPos    (11U)
#define GPIO_IMR_IMR11_Pos          GPIO_IMR_Irq11_mask_DPos
#define GPIO_IMR_IMR11_Msk          (0x01UL << GPIO_IMR_IMR11_Pos)              /* 0x00000800 */
#define GPIO_IMR_IMR11              GPIO_IMR_IMR11_Msk                          /* Channel 11 interrupt mask */

#define GPIO_IMR_Irq12_mask_DPos    (12U)
#define GPIO_IMR_IMR12_Pos          GPIO_IMR_Irq12_mask_DPos
#define GPIO_IMR_IMR12_Msk          (0x01UL << GPIO_IMR_IMR12_Pos)              /* 0x00001000 */
#define GPIO_IMR_IMR12              GPIO_IMR_IMR12_Msk                          /* Channel 12 interrupt mask */

#define GPIO_IMR_Irq13_mask_DPos    (13U)
#define GPIO_IMR_IMR13_Pos          GPIO_IMR_Irq13_mask_DPos
#define GPIO_IMR_IMR13_Msk          (0x01UL << GPIO_IMR_IMR13_Pos)              /* 0x00002000 */
#define GPIO_IMR_IMR13              GPIO_IMR_IMR13_Msk                          /* Channel 13 interrupt mask */

#define GPIO_IMR_Irq14_mask_DPos    (14U)
#define GPIO_IMR_IMR14_Pos          GPIO_IMR_Irq14_mask_DPos
#define GPIO_IMR_IMR14_Msk          (0x01UL << GPIO_IMR_IMR14_Pos)              /* 0x00004000 */
#define GPIO_IMR_IMR14              GPIO_IMR_IMR14_Msk                          /* Channel 14 interrupt mask */

#define GPIO_IMR_Irq15_mask_DPos    (15U)
#define GPIO_IMR_IMR15_Pos          GPIO_IMR_Irq15_mask_DPos
#define GPIO_IMR_IMR15_Msk          (0x01UL << GPIO_IMR_IMR15_Pos)              /* 0x00008000 */
#define GPIO_IMR_IMR15              GPIO_IMR_IMR15_Msk                          /* Channel 15 interrupt mask */


/******************  Bits definition for GPIO_ISR register  *****************/
#define GPIO_ISR_Irq0_status_DPos   (0U)
#define GPIO_ISR_ISR0_Pos           GPIO_ISR_Irq0_status_DPos
#define GPIO_ISR_ISR0_Msk           (0x01UL << GPIO_ISR_ISR0_Pos)               /* 0x00000001 */
#define GPIO_ISR_ISR0               GPIO_ISR_ISR0_Msk                           /* Channel 0 interrupt status */

#define GPIO_ISR_Irq1_status_DPos   (1U)
#define GPIO_ISR_ISR1_Pos           GPIO_ISR_Irq1_status_DPos
#define GPIO_ISR_ISR1_Msk           (0x01UL << GPIO_ISR_ISR1_Pos)               /* 0x00000002 */
#define GPIO_ISR_ISR1               GPIO_ISR_ISR1_Msk                           /* Channel 1 interrupt status */

#define GPIO_ISR_Irq2_status_DPos   (2U)
#define GPIO_ISR_ISR2_Pos           GPIO_ISR_Irq2_status_DPos
#define GPIO_ISR_ISR2_Msk           (0x01UL << GPIO_ISR_ISR2_Pos)               /* 0x00000004 */
#define GPIO_ISR_ISR2               GPIO_ISR_ISR2_Msk                           /* Channel 2 interrupt status */

#define GPIO_ISR_Irq3_status_DPos   (3U)
#define GPIO_ISR_ISR3_Pos           GPIO_ISR_Irq3_status_DPos
#define GPIO_ISR_ISR3_Msk           (0x01UL << GPIO_ISR_ISR3_Pos)               /* 0x00000008 */
#define GPIO_ISR_ISR3               GPIO_ISR_ISR3_Msk                           /* Channel 3 interrupt status */

#define GPIO_ISR_Irq4_status_DPos   (4U)
#define GPIO_ISR_ISR4_Pos           GPIO_ISR_Irq4_status_DPos
#define GPIO_ISR_ISR4_Msk           (0x01UL << GPIO_ISR_ISR4_Pos)               /* 0x00000010 */
#define GPIO_ISR_ISR4               GPIO_ISR_ISR4_Msk                           /* Channel 4 interrupt status */

#define GPIO_ISR_Irq5_status_DPos   (5U)
#define GPIO_ISR_ISR5_Pos           GPIO_ISR_Irq5_status_DPos
#define GPIO_ISR_ISR5_Msk           (0x01UL << GPIO_ISR_ISR5_Pos)               /* 0x00000020 */
#define GPIO_ISR_ISR5               GPIO_ISR_ISR5_Msk                           /* Channel 5 interrupt status */

#define GPIO_ISR_Irq6_status_DPos   (6U)
#define GPIO_ISR_ISR6_Pos           GPIO_ISR_Irq6_status_DPos
#define GPIO_ISR_ISR6_Msk           (0x01UL << GPIO_ISR_ISR6_Pos)               /* 0x00000040 */
#define GPIO_ISR_ISR6               GPIO_ISR_ISR6_Msk                           /* Channel 6 interrupt status */

#define GPIO_ISR_Irq7_status_DPos   (7U)
#define GPIO_ISR_ISR7_Pos           GPIO_ISR_Irq7_status_DPos
#define GPIO_ISR_ISR7_Msk           (0x01UL << GPIO_ISR_ISR7_Pos)               /* 0x00000080 */
#define GPIO_ISR_ISR7               GPIO_ISR_ISR7_Msk                           /* Channel 7 interrupt status */

#define GPIO_ISR_Irq8_status_DPos   (8U)
#define GPIO_ISR_ISR8_Pos           GPIO_ISR_Irq8_status_DPos
#define GPIO_ISR_ISR8_Msk           (0x01UL << GPIO_ISR_ISR8_Pos)               /* 0x00000100 */
#define GPIO_ISR_ISR8               GPIO_ISR_ISR8_Msk                           /* Channel 8 interrupt status */

#define GPIO_ISR_Irq9_status_DPos   (9U)
#define GPIO_ISR_ISR9_Pos           GPIO_ISR_Irq9_status_DPos
#define GPIO_ISR_ISR9_Msk           (0x01UL << GPIO_ISR_ISR9_Pos)               /* 0x00000200 */
#define GPIO_ISR_ISR9               GPIO_ISR_ISR9_Msk                           /* Channel 9 interrupt status */

#define GPIO_ISR_Irq10_status_DPos  (10U)
#define GPIO_ISR_ISR10_Pos          GPIO_ISR_Irq10_status_DPos
#define GPIO_ISR_ISR10_Msk          (0x01UL << GPIO_ISR_ISR10_Pos)              /* 0x00000400 */
#define GPIO_ISR_ISR10              GPIO_ISR_ISR10_Msk                          /* Channel 10 interrupt status */

#define GPIO_ISR_Irq11_status_DPos  (11U)
#define GPIO_ISR_ISR11_Pos          GPIO_ISR_Irq11_status_DPos
#define GPIO_ISR_ISR11_Msk          (0x01UL << GPIO_ISR_ISR11_Pos)              /* 0x00000800 */
#define GPIO_ISR_ISR11              GPIO_ISR_ISR11_Msk                          /* Channel 11 interrupt status */

#define GPIO_ISR_Irq12_status_DPos  (12U)
#define GPIO_ISR_ISR12_Pos          GPIO_ISR_Irq12_status_DPos
#define GPIO_ISR_ISR12_Msk          (0x01UL << GPIO_ISR_ISR12_Pos)              /* 0x00001000 */
#define GPIO_ISR_ISR12              GPIO_ISR_ISR12_Msk                          /* Channel 12 interrupt status */

#define GPIO_ISR_Irq13_status_DPos  (13U)
#define GPIO_ISR_ISR13_Pos          GPIO_ISR_Irq13_status_DPos
#define GPIO_ISR_ISR13_Msk          (0x01UL << GPIO_ISR_ISR13_Pos)              /* 0x00002000 */
#define GPIO_ISR_ISR13              GPIO_ISR_ISR13_Msk                          /* Channel 13 interrupt status */

#define GPIO_ISR_Irq14_status_DPos  (14U)
#define GPIO_ISR_ISR14_Pos          GPIO_ISR_Irq14_status_DPos
#define GPIO_ISR_ISR14_Msk          (0x01UL << GPIO_ISR_ISR14_Pos)              /* 0x00004000 */
#define GPIO_ISR_ISR14              GPIO_ISR_ISR14_Msk                          /* Channel 14 interrupt status */

#define GPIO_ISR_Irq15_status_DPos  (15U)
#define GPIO_ISR_ISR15_Pos          GPIO_ISR_Irq15_status_DPos
#define GPIO_ISR_ISR15_Msk          (0x01UL << GPIO_ISR_ISR15_Pos)              /* 0x00008000 */
#define GPIO_ISR_ISR15              GPIO_ISR_ISR15_Msk                          /* Channel 15 interrupt status */

/* @name PMU register bits definition */
/******************  Bit definition for PMU_LDOCR register  *******************/
#define PMU_LDOCR_EN_3V3_DPos           (0U)
#define PMU_LDOCR_3V3LDOEN_Pos          PMU_LDOCR_EN_3V3_DPos
#define PMU_LDOCR_3V3LDOEN_Msk          (0x1UL << PMU_LDOCR_3V3LDOEN_Pos)       /* 0x00000001 */
#define PMU_LDOCR_3V3LDOEN              PMU_LDOCR_3V3LDOEN_Msk                  /* 3.3V LDO Enable */

#define PMU_LDOCR_BP_3V3_DPos           (1U)
#define PMU_LDOCR_3V3LDOBYP_Pos         PMU_LDOCR_BP_3V3_DPos
#define PMU_LDOCR_3V3LDOBYP_Msk         (0x1UL << PMU_LDOCR_3V3LDOBYP_Pos)      /* 0x00000002 */
#define PMU_LDOCR_3V3LDOBYP             PMU_LDOCR_3V3LDOBYP_Msk                 /* 3.3V LDO Bypass */

#define PMU_LDOCR_ADJ_3V3_DPos          (2U)
#define PMU_LDOCR_3V3LDOVOS_Pos         PMU_LDOCR_ADJ_3V3_DPos
#define PMU_LDOCR_3V3LDOVOS_Msk         (0xFUL << PMU_LDOCR_3V3LDOVOS_Pos)      /* 0x0000003C */
#define PMU_LDOCR_3V3LDOVOS             PMU_LDOCR_3V3LDOVOS_Msk                 /* 3V3LDOVOS [3:0] (3.3V LDO Voltage Scaling) */
#define PMU_LDOCR_3V3LDOVOS_0           (0x01UL << PMU_LDOCR_3V3LDOVOS_Pos)     /* 0x00000004 */
#define PMU_LDOCR_3V3LDOVOS_1           (0x02UL << PMU_LDOCR_3V3LDOVOS_Pos)     /* 0x00000008 */
#define PMU_LDOCR_3V3LDOVOS_2           (0x04UL << PMU_LDOCR_3V3LDOVOS_Pos)     /* 0x00000010 */
#define PMU_LDOCR_3V3LDOVOS_3           (0x08UL << PMU_LDOCR_3V3LDOVOS_Pos)     /* 0x00000020 */

#define PMU_LDOCR_EN_2V5_DPos           (6U)
#define PMU_LDOCR_2V5LDOEN_Pos          PMU_LDOCR_EN_2V5_DPos
#define PMU_LDOCR_2V5LDOEN_Msk          (0x1UL << PMU_LDOCR_2V5LDOEN_Pos)       /* 0x00000040 */
#define PMU_LDOCR_2V5LDOEN              PMU_LDOCR_2V5LDOEN_Msk                  /* 2.5V LDO Enable */

#define PMU_LDOCR_ADJ_2V5_DPos          (7U)
#define PMU_LDOCR_2V5LDOVOS_Pos         PMU_LDOCR_ADJ_2V5_DPos
#define PMU_LDOCR_2V5LDOVOS_Msk         (0xFUL << PMU_LDOCR_2V5LDOVOS_Pos)      /* 0x00000780 */
#define PMU_LDOCR_2V5LDOVOS             PMU_LDOCR_2V5LDOVOS_Msk                 /* 2V5LDOVOS [3:0] (2.5V LDO Voltage Scaling) */
#define PMU_LDOCR_2V5LDOVOS_0           (0x01UL << PMU_LDOCR_2V5LDOVOS_Pos)     /* 0x00000080 */
#define PMU_LDOCR_2V5LDOVOS_1           (0x02UL << PMU_LDOCR_2V5LDOVOS_Pos)     /* 0x00000100 */
#define PMU_LDOCR_2V5LDOVOS_2           (0x04UL << PMU_LDOCR_2V5LDOVOS_Pos)     /* 0x00000200 */
#define PMU_LDOCR_2V5LDOVOS_3           (0x08UL << PMU_LDOCR_2V5LDOVOS_Pos)     /* 0x00000400 */

#define PMU_LDOCR_EN_1V2A_DPos          (11U)
#define PMU_LDOCR_1V2LDOEN_Pos          PMU_LDOCR_EN_1V2A_DPos
#define PMU_LDOCR_1V2LDOEN_Msk          (0x1UL << PMU_LDOCR_1V2LDOEN_Pos)       /* 0x00000800 */
#define PMU_LDOCR_1V2LDOEN              PMU_LDOCR_1V2LDOEN_Msk                  /* 1.2V LDO Enable */

#define PMU_LDOCR_EN_VREF_DPos          (12U)
#define PMU_LDOCR_1V2VREFEN_Pos         PMU_LDOCR_EN_VREF_DPos
#define PMU_LDOCR_1V2VREFEN_Msk         (0x1UL << PMU_LDOCR_1V2VREFEN_Pos)      /* 0x00001000 */
#define PMU_LDOCR_1V2VREFEN             PMU_LDOCR_1V2VREFEN_Msk                 /* 1.2V Flash Reference Voltage Source Enable */

#define PMU_LDOCR_ADJ_VREF_DPos         (13U)
#define PMU_LDOCR_1V2VREFS_Pos          PMU_LDOCR_ADJ_VREF_DPos
#define PMU_LDOCR_1V2VREFS_Msk          (0xFUL << PMU_LDOCR_1V2VREFS_Pos)       /* 0x0001E000 */
#define PMU_LDOCR_1V2VREFS              PMU_LDOCR_1V2VREFS_Msk                  /* 1V2VREFS [3:0] (1.2V Reference Voltage Source Scaling) */
#define PMU_LDOCR_1V2VREFS_0            (0x01UL << PMU_LDOCR_1V2VREFS_Pos)      /* 0x00002000 */
#define PMU_LDOCR_1V2VREFS_1            (0x02UL << PMU_LDOCR_1V2VREFS_Pos)      /* 0x00004000 */
#define PMU_LDOCR_1V2VREFS_2            (0x04UL << PMU_LDOCR_1V2VREFS_Pos)      /* 0x00008000 */
#define PMU_LDOCR_1V2VREFS_3            (0x08UL << PMU_LDOCR_1V2VREFS_Pos)      /* 0x00010000 */

#define PMU_LDOCR_ADJ_1V2A_DPos         (17U)
#define PMU_LDOCR_1V2LDOVOS_Pos         PMU_LDOCR_ADJ_1V2A_DPos
#define PMU_LDOCR_1V2LDOVOS_Msk         (0xFUL << PMU_LDOCR_1V2LDOVOS_Pos)      /* 0x001E0000 */
#define PMU_LDOCR_1V2LDOVOS             PMU_LDOCR_1V2LDOVOS_Msk                 /* 1V2LDOVOS [3:0] (1.2V LDO Voltage Scaling) */
#define PMU_LDOCR_1V2LDOVOS_0           (0x01UL << PMU_LDOCR_1V2LDOVOS_Pos)     /* 0x00020000 */
#define PMU_LDOCR_1V2LDOVOS_1           (0x02UL << PMU_LDOCR_1V2LDOVOS_Pos)     /* 0x00040000 */
#define PMU_LDOCR_1V2LDOVOS_2           (0x04UL << PMU_LDOCR_1V2LDOVOS_Pos)     /* 0x00080000 */
#define PMU_LDOCR_1V2LDOVOS_3           (0x08UL << PMU_LDOCR_1V2LDOVOS_Pos)     /* 0x00100000 */

#define PMU_LDOCR_ADJ_1V2B_DPos         (21U)
#define PMU_LDOCR_1V2BLDOVOS_Pos        PMU_LDOCR_ADJ_1V2B_DPos
#define PMU_LDOCR_1V2BLDOVOS_Msk        (0xFUL << PMU_LDOCR_1V2BLDOVOS_Pos)     /* 0x01E00000 */
#define PMU_LDOCR_1V2BLDOVOS            PMU_LDOCR_1V2BLDOVOS_Msk                /* 1V2BLDOVOS [3:0] (1.2V Backup LDO Voltage Scaling) */
#define PMU_LDOCR_1V2BLDOVOS_0          (0x01UL << PMU_LDOCR_1V2BLDOVOS_Pos)    /* 0x00200000 */
#define PMU_LDOCR_1V2BLDOVOS_1          (0x02UL << PMU_LDOCR_1V2BLDOVOS_Pos)    /* 0x00400000 */
#define PMU_LDOCR_1V2BLDOVOS_2          (0x04UL << PMU_LDOCR_1V2BLDOVOS_Pos)    /* 0x00800000 */
#define PMU_LDOCR_1V2BLDOVOS_3          (0x08UL << PMU_LDOCR_1V2BLDOVOS_Pos)    /* 0x01000000 */


/******************  Bit definition for PMU_LDOSR register  *******************/
#define PMU_LDOSR_RDY_3V3_DPos          (0U)
#define PMU_LDOSR_3V3LDORDY_Pos         PMU_LDOSR_RDY_3V3_DPos
#define PMU_LDOSR_3V3LDORDY_Msk         (0x1UL << PMU_LDOSR_3V3LDORDY_Pos)      /* 0x00000001 */
#define PMU_LDOSR_3V3LDORDY             PMU_LDOSR_3V3LDORDY_Msk                 /* 3.3V LDO Voltage Ready Flag */

#define PMU_LDOSR_RDY_2V5_DPos          (1U)
#define PMU_LDOSR_2V5LDORDY_Pos         PMU_LDOSR_RDY_2V5_DPos
#define PMU_LDOSR_2V5LDORDY_Msk         (0x1UL << PMU_LDOSR_2V5LDORDY_Pos)      /* 0x00000002 */
#define PMU_LDOSR_2V5LDORDY             PMU_LDOSR_2V5LDORDY_Msk                 /* 2.5V LDO Voltage Ready Flag */

#define PMU_LDOSR_RDY_1V2A_DPos         (2U)
#define PMU_LDOSR_1V2LDORDY_Pos         PMU_LDOSR_RDY_1V2A_DPos
#define PMU_LDOSR_1V2LDORDY_Msk         (0x1UL << PMU_LDOSR_1V2LDORDY_Pos)      /* 0x00000004 */
#define PMU_LDOSR_1V2LDORDY             PMU_LDOSR_1V2LDORDY_Msk                 /* 1.2V LDO Voltage Ready Flag */

#define PMU_LDOSR_RDY_1V2B_DPos         (3U)
#define PMU_LDOSR_1V2BLDORDY_Pos        PMU_LDOSR_RDY_1V2B_DPos
#define PMU_LDOSR_1V2BLDORDY_Msk        (0x1UL << PMU_LDOSR_1V2BLDORDY_Pos)     /* 0x00000008 */
#define PMU_LDOSR_1V2BLDORDY            PMU_LDOSR_1V2BLDORDY_Msk                /* 1.2V Backup LDO Voltage Ready Flag */


/******************  Bit definition for PMU_VDCR register  *******************/
#define PMU_VDCR_EN_LVR_DPos            (0U)
#define PMU_VDCR_LVREN_Pos              PMU_VDCR_EN_LVR_DPos
#define PMU_VDCR_LVREN_Msk              (0x1UL << PMU_VDCR_LVREN_Pos)           /* 0x00000001 */
#define PMU_VDCR_LVREN                  PMU_VDCR_LVREN_Msk                      /* Low Voltage Reset Enable */

#define PMU_VDCR_EN_HVD_DPos            (1U)
#define PMU_VDCR_HVDEN_Pos              PMU_VDCR_EN_HVD_DPos
#define PMU_VDCR_HVDEN_Msk              (0x1UL << PMU_VDCR_HVDEN_Pos)           /* 0x00000002 */
#define PMU_VDCR_HVDEN                  PMU_VDCR_HVDEN_Msk                      /* High Voltage Detect Enable */

#define PMU_VDCR_ADJ_HVD_DPos           (2U)
#define PMU_VDCR_HVDTS_Pos              PMU_VDCR_ADJ_HVD_DPos
#define PMU_VDCR_HVDTS_Msk              (0x1FUL << PMU_VDCR_HVDTS_Pos)          /* 0x0000007C */
#define PMU_VDCR_HVDTS                  PMU_VDCR_HVDTS_Msk                      /* HVDTS [4:0] (High Voltage Detect Threshold Scaling) */
#define PMU_VDCR_HVDTS_0                (0x01UL << PMU_VDCR_HVDTS_Pos)          /* 0x00000004 */
#define PMU_VDCR_HVDTS_1                (0x02UL << PMU_VDCR_HVDTS_Pos)          /* 0x00000008 */
#define PMU_VDCR_HVDTS_2                (0x04UL << PMU_VDCR_HVDTS_Pos)          /* 0x00000010 */
#define PMU_VDCR_HVDTS_3                (0x08UL << PMU_VDCR_HVDTS_Pos)          /* 0x00000020 */
#define PMU_VDCR_HVDTS_4                (0x10UL << PMU_VDCR_HVDTS_Pos)          /* 0x00000040 */

#define PMU_VDCR_EN_LVD_DPos            (7U)
#define PMU_VDCR_LVDEN_Pos              PMU_VDCR_EN_LVD_DPos
#define PMU_VDCR_LVDEN_Msk              (0x1UL << PMU_VDCR_LVDEN_Pos)           /* 0x00000080 */
#define PMU_VDCR_LVDEN                  PMU_VDCR_LVDEN_Msk                      /* Low Voltage Detect Enable */

#define PMU_VDCR_ADJ_LVD_DPos           (8U)
#define PMU_VDCR_LVDTS_Pos              PMU_VDCR_ADJ_LVD_DPos
#define PMU_VDCR_LVDTS_Msk              (0x1FUL << PMU_VDCR_LVDTS_Pos)          /* 0x00001F00 */
#define PMU_VDCR_LVDTS                  PMU_VDCR_LVDTS_Msk                      /* LVDTS [4:0] (Low Voltage Detect Threshold Scaling) */
#define PMU_VDCR_LVDTS_0                (0x01UL << PMU_VDCR_LVDTS_Pos)          /* 0x00000100 */
#define PMU_VDCR_LVDTS_1                (0x02UL << PMU_VDCR_LVDTS_Pos)          /* 0x00000200 */
#define PMU_VDCR_LVDTS_2                (0x04UL << PMU_VDCR_LVDTS_Pos)          /* 0x00000400 */
#define PMU_VDCR_LVDTS_3                (0x08UL << PMU_VDCR_LVDTS_Pos)          /* 0x00000800 */
#define PMU_VDCR_LVDTS_4                (0x10UL << PMU_VDCR_LVDTS_Pos)          /* 0x00001000 */


/******************  Bit definition for PMU_OCR register  *******************/
#define PMU_OCR_EN_RC16_DPos            (0U)
#define PMU_OCR_IRC16MEN_Pos            PMU_OCR_EN_RC16_DPos
#define PMU_OCR_IRC16MEN_Msk            (0x1UL << PMU_OCR_IRC16MEN_Pos)         /* 0x00000001 */
#define PMU_OCR_IRC16MEN                PMU_OCR_IRC16MEN_Msk                    /* Internal RC 16MHz Clock Enable */

#define PMU_OCR_ADJ_32K_DPos            (1U)
#define PMU_OCR_RC32KFS_Pos             PMU_OCR_ADJ_32K_DPos
#define PMU_OCR_RC32KFS_Msk             (0x3FUL << PMU_OCR_RC32KFS_Pos)         /* 0x0000007E */
#define PMU_OCR_RC32KFS                 PMU_OCR_RC32KFS_Msk                     /* RC32KFS [5:0] (RC 32KHz Clock Frequency Scaling) */
#define PMU_OCR_RC32KFS_0               (0x01UL << PMU_OCR_RC32KFS_Pos)         /* 0x00000002 */
#define PMU_OCR_RC32KFS_1               (0x02UL << PMU_OCR_RC32KFS_Pos)         /* 0x00000004 */
#define PMU_OCR_RC32KFS_2               (0x04UL << PMU_OCR_RC32KFS_Pos)         /* 0x00000008 */
#define PMU_OCR_RC32KFS_3               (0x08UL << PMU_OCR_RC32KFS_Pos)         /* 0x00000010 */
#define PMU_OCR_RC32KFS_4               (0x10UL << PMU_OCR_RC32KFS_Pos)         /* 0x00000020 */
#define PMU_OCR_RC32KFS_5               (0x20UL << PMU_OCR_RC32KFS_Pos)         /* 0x00000040 */


/******************  Bit definition for PMU_PMCR register  *******************/
#define PMU_PMCR_MD_CFG_DPos            (0U)
#define PMU_PMCR_POWMC_Pos              PMU_PMCR_MD_CFG_DPos
#define PMU_PMCR_POWMC_Msk              (0x3UL << PMU_PMCR_POWMC_Pos)           /* 0x00000003 */
#define PMU_PMCR_POWMC                  PMU_PMCR_POWMC_Msk                      /* POWMC [1:0] (Power Mode Config) */
#define PMU_PMCR_POWMC_0                (0x01UL << PMU_PMCR_POWMC_Pos)          /* 0x00000001 */
#define PMU_PMCR_POWMC_1                (0x02UL << PMU_PMCR_POWMC_Pos)          /* 0x00000002 */


/******************  Bit definition for PMU_WKFR register  *******************/
#define PMU_WKFR_WKSIG_DPos             (0U)
#define PMU_WKFR_WKCC_Pos               PMU_WKFR_WKSIG_DPos
#define PMU_WKFR_WKCC_Msk               (0x3FFFUL << PMU_WKFR_WKCC_Pos)         /* 0x00003FFF */
#define PMU_WKFR_WKCC                   PMU_WKFR_WKCC_Msk                       /* WKCC [13:0] (Wake Up Channel Config) */
#define PMU_WKFR_WKCC_0                 (0x0001UL << PMU_WKFR_WKCC_Pos)         /* 0x00000001 */
#define PMU_WKFR_WKCC_1                 (0x0002UL << PMU_WKFR_WKCC_Pos)         /* 0x00000002 */
#define PMU_WKFR_WKCC_2                 (0x0004UL << PMU_WKFR_WKCC_Pos)         /* 0x00000004 */
#define PMU_WKFR_WKCC_3                 (0x0008UL << PMU_WKFR_WKCC_Pos)         /* 0x00000008 */
#define PMU_WKFR_WKCC_4                 (0x0010UL << PMU_WKFR_WKCC_Pos)         /* 0x00000010 */
#define PMU_WKFR_WKCC_5                 (0x0020UL << PMU_WKFR_WKCC_Pos)         /* 0x00000020 */
#define PMU_WKFR_WKCC_6                 (0x0040UL << PMU_WKFR_WKCC_Pos)         /* 0x00000040 */
#define PMU_WKFR_WKCC_7                 (0x0080UL << PMU_WKFR_WKCC_Pos)         /* 0x00000080 */
#define PMU_WKFR_WKCC_8                 (0x0100UL << PMU_WKFR_WKCC_Pos)         /* 0x00000100 */
#define PMU_WKFR_WKCC_9                 (0x0200UL << PMU_WKFR_WKCC_Pos)         /* 0x00000200 */
#define PMU_WKFR_WKCC_10                (0x0400UL << PMU_WKFR_WKCC_Pos)         /* 0x00000400 */
#define PMU_WKFR_WKCC_11                (0x0800UL << PMU_WKFR_WKCC_Pos)         /* 0x00000800 */
#define PMU_WKFR_WKCC_12                (0x1000UL << PMU_WKFR_WKCC_Pos)         /* 0x00001000 */
#define PMU_WKFR_WKCC_13                (0x2000UL << PMU_WKFR_WKCC_Pos)         /* 0x00002000 */

#define PMU_WKFR_FOCUS_DPos             (14U)
#define PMU_WKFR_FOCURF_Pos             PMU_WKFR_FOCUS_DPos
#define PMU_WKFR_FOCURF_Msk             (0x1UL << PMU_WKFR_FOCURF_Pos)          /* 0x00004000 */
#define PMU_WKFR_FOCURF                 PMU_WKFR_FOCURF_Msk                     /* FOCU Reset Flag */


/******************  Bit definition for PMU_WKEN register  *******************/
#define PMU_WKEN_WKEN_DPos              (0U)
#define PMU_WKEN_WKEN_Pos               PMU_WKEN_WKEN_DPos
#define PMU_WKEN_WKEN_Msk               (0x3FFFUL << PMU_WKEN_WKEN_Pos)         /* 0x00003FFF */
#define PMU_WKEN_WKEN                   PMU_WKEN_WKEN_Msk                       /* WKEN [13:0] (Wake Up Channel Enable) */
#define PMU_WKEN_WKEN_0                 (0x0001UL << PMU_WKEN_WKEN_Pos)         /* 0x00000001 */
#define PMU_WKEN_WKEN_1                 (0x0002UL << PMU_WKEN_WKEN_Pos)         /* 0x00000002 */
#define PMU_WKEN_WKEN_2                 (0x0004UL << PMU_WKEN_WKEN_Pos)         /* 0x00000004 */
#define PMU_WKEN_WKEN_3                 (0x0008UL << PMU_WKEN_WKEN_Pos)         /* 0x00000008 */
#define PMU_WKEN_WKEN_4                 (0x0010UL << PMU_WKEN_WKEN_Pos)         /* 0x00000010 */
#define PMU_WKEN_WKEN_5                 (0x0020UL << PMU_WKEN_WKEN_Pos)         /* 0x00000020 */
#define PMU_WKEN_WKEN_6                 (0x0040UL << PMU_WKEN_WKEN_Pos)         /* 0x00000040 */
#define PMU_WKEN_WKEN_7                 (0x0080UL << PMU_WKEN_WKEN_Pos)         /* 0x00000080 */
#define PMU_WKEN_WKEN_8                 (0x0100UL << PMU_WKEN_WKEN_Pos)         /* 0x00000100 */
#define PMU_WKEN_WKEN_9                 (0x0200UL << PMU_WKEN_WKEN_Pos)         /* 0x00000200 */
#define PMU_WKEN_WKEN_10                (0x0400UL << PMU_WKEN_WKEN_Pos)         /* 0x00000400 */
#define PMU_WKEN_WKEN_11                (0x0800UL << PMU_WKEN_WKEN_Pos)         /* 0x00000800 */
#define PMU_WKEN_WKEN_12                (0x1000UL << PMU_WKEN_WKEN_Pos)         /* 0x00001000 */
#define PMU_WKEN_WKEN_13                (0x2000UL << PMU_WKEN_WKEN_Pos)         /* 0x00002000 */

/* @name IWDG register bits definition */
/******************  Bit definition for IWDG_PSC register  *******************/
#define IWDG_PSC_EN_DPos        (0U)
#define IWDG_PSC_EN_Pos         IWDG_PSC_EN_DPos
#define IWDG_PSC_EN_Msk         (0x1UL << IWDG_PSC_EN_Pos)               /* 0x00000001 */
#define IWDG_PSC_EN             IWDG_PSC_EN_Msk                          /* Enable Independent watchdog prescaler. */

#define IWDG_PSC_LOCK_DPos      (1U)
#define IWDG_PSC_LOCK_Pos       IWDG_PSC_LOCK_DPos
#define IWDG_PSC_LOCK_Msk       (0x1UL << IWDG_PSC_LOCK_Pos)             /* 0x00000002 */
#define IWDG_PSC_LOCK           IWDG_PSC_LOCK_Msk                        /*Independent watchdog prescaler lock. */

#define IWDG_PSC_PSCNUM_DPos    (2U)
#define IWDG_PSC_PSCNUM_Pos     IWDG_PSC_PSCNUM_DPos
#define IWDG_PSC_PSCNUM_Msk     (0xffUL << IWDG_PSC_PSCNUM_Pos)          /* 0x00003fc */
#define IWDG_PSC_PSCNUM         IWDG_PSC_PSCNUM_Msk                      /*Independent watchdog prescaler number. */

/******************  Bit definition for IWDG_CFG register  *******************/
#define IWDG_CFG_EN_DPos       (0U)
#define IWDG_CFG_EN_Pos        IWDG_CFG_EN_DPos
#define IWDG_CFG_EN_Msk        (0x1UL << IWDG_CFG_EN_Pos)                  /* 0x00000001 */
#define IWDG_CFG_EN            IWDG_CFG_EN_Msk                             /* Enable Independent watchdog configuration. */

#define IWDG_CFG_LOCK_DPos     (1U)
#define IWDG_CFG_LOCK_Pos      IWDG_CFG_LOCK_DPos
#define IWDG_CFG_LOCK_Msk      (0x1UL << IWDG_CFG_LOCK_Pos)                /* 0x00000002 */
#define IWDG_CFG_LOCK          IWDG_CFG_LOCK_Msk                           /*Independent watchdog prescaler lock. */

/******************  Bit definition for IWDG_DIV register  *******************/
#define IWDG_DIV_DIVNUM_DPos    (0U)
#define IWDG_DIV_DIVNUM_Pos     IWDG_DIV_DIVNUM_DPos
#define IWDG_DIV_DIVNUM_Msk     (0xffffUL << IWDG_DIV_DIVNUM_Pos)            /* 0x0000ffff */
#define IWDG_DIV_DIVNUM         IWDG_DIV_DIVNUM_Msk                          /*Independent watchdog divider number. */

/******************  Bit definition for IWDG_TO register  *******************/
#define IWDG_TO_BVAL_DPos       (0U)
#define IWDG_TO_BVAL_Pos        IWDG_TO_BVAL_DPos
#define IWDG_TO_BVAL_Msk        (0xffffUL << IWDG_TO_BVAL_Pos)            /* 0x0000ffff */
#define IWDG_TO_BVAL            IWDG_TO_BVAL_Msk                          /*Independent watchdog configure timeout period. */

/******************  Bit definition for IWDG_CNT register  *******************/
#define IWDG_CNT_CNTNUM_DPos         (0U)
#define IWDG_CNT_CNTNUM_Pos          IWDG_CNT_CNTNUM_DPos
#define IWDG_CNT_CNTNUM_Msk          (0xffffUL << IWDG_CNT_CNTNUM_Pos)            /* 0x0000ffff */
#define IWDG_CNT_CNTNUM              IWDG_CNT_CNTNUM_Msk                          /*Independent watchdog counter number. */

/******************  Bit definition for IWDG_CLR register  *******************/
#define IWDG_CLR_CLEARPASS_DPos      (0U)
#define IWDG_CLR_KEY_Pos             IWDG_CLR_CLEARPASS_DPos
#define IWDG_CLR_KEY_Msk             (0xffffffffUL << IWDG_CLR_KEY_Pos)        /* 0xffffffff */
#define IWDG_CLR_KEY                 IWDG_CLR_KEY_Msk                          /*Independent watchdog refreshes the key. */

/* @name TIMER register bits definition */
/*******************  Bit definition for TIM_CR1 register  ********************/
#define TIM_CR1_CEN_DPos          (0U)
#define TIM_CR1_CEN_Pos           TIM_CR1_CEN_DPos
#define TIM_CR1_CEN_Msk           (0x1UL << TIM_CR1_CEN_Pos)                   /* 0x00000001 */
#define TIM_CR1_CEN               TIM_CR1_CEN_Msk                              /* Counter enable */

#define TIM_CR1_UDIS_DPos         (1U)
#define TIM_CR1_UDIS_Pos          TIM_CR1_UDIS_DPos
#define TIM_CR1_UDIS_Msk          (0x1UL << TIM_CR1_UDIS_Pos)                  /* 0x00000002 */
#define TIM_CR1_UDIS              TIM_CR1_UDIS_Msk                             /* Update disable */

#define TIM_CR1_URS_DPos          (2U)
#define TIM_CR1_URS_Pos           TIM_CR1_URS_DPos
#define TIM_CR1_URS_Msk           (0x1UL << TIM_CR1_URS_Pos)                   /* 0x00000004 */
#define TIM_CR1_URS               TIM_CR1_URS_Msk                              /* Update request source */

#define TIM_CR1_OPM_DPos          (3U)
#define TIM_CR1_OPM_Pos           TIM_CR1_OPM_DPos
#define TIM_CR1_OPM_Msk           (0x1UL << TIM_CR1_OPM_Pos)                   /* 0x00000008 */
#define TIM_CR1_OPM               TIM_CR1_OPM_Msk                              /* One pulse mode */

#define TIM_CR1_DIR_DPos          (4U)
#define TIM_CR1_DIR_Pos           TIM_CR1_DIR_DPos
#define TIM_CR1_DIR_Msk           (0x1UL << TIM_CR1_DIR_Pos)                   /* 0x00000010 */
#define TIM_CR1_DIR               TIM_CR1_DIR_Msk                              /* Direction */

#define TIM_CR1_CMS_DPos          (5U)
#define TIM_CR1_CMS_Pos           TIM_CR1_CMS_DPos
#define TIM_CR1_CMS_Msk           (0x3UL << TIM_CR1_CMS_Pos)                   /* 0x00000060 */
#define TIM_CR1_CMS               TIM_CR1_CMS_Msk                              /*CMS[1:0] bits (Center-aligned mode selection) */
#define TIM_CR1_CMS_0             (0x1UL << TIM_CR1_CMS_Pos)                   /* 0x00000020 */
#define TIM_CR1_CMS_1             (0x2UL << TIM_CR1_CMS_Pos)                   /* 0x00000040 */

#define TIM_CR1_ARPE_DPos         (7U)
#define TIM_CR1_ARPE_Pos          TIM_CR1_ARPE_DPos
#define TIM_CR1_ARPE_Msk          (0x1UL << TIM_CR1_ARPE_Pos)                  /* 0x00000080 */
#define TIM_CR1_ARPE              TIM_CR1_ARPE_Msk                             /* Auto-reload preload enable */

#define TIM_CR1_CKD_DPos          (8U)
#define TIM_CR1_CKD_Pos           TIM_CR1_CKD_DPos
#define TIM_CR1_CKD_Msk           (0x3UL << TIM_CR1_CKD_Pos)                   /* 0x00000300 */
#define TIM_CR1_CKD               TIM_CR1_CKD_Msk                              /*CKD[1:0] bits (Clock division) */
#define TIM_CR1_CKD_0             (0x1UL << TIM_CR1_CKD_Pos)                   /* 0x00000100 */
#define TIM_CR1_CKD_1             (0x2UL << TIM_CR1_CKD_Pos)                   /* 0x00000200 */

/*******************  Bit definition for TIM_CR2 register  ********************/
#define TIM_CR2_CCPC_DPos         (0U)
#define TIM_CR2_CCPC_Pos          TIM_CR2_CCPC_DPos
#define TIM_CR2_CCPC_Msk          (0x1UL << TIM_CR2_CCPC_Pos)                  /* 0x00000001 */
#define TIM_CR2_CCPC              TIM_CR2_CCPC_Msk                             /* Capture/compare preloaded control */

#define TIM_CR2_CCUS_DPos         (2U)
#define TIM_CR2_CCUS_Pos          TIM_CR2_CCUS_DPos
#define TIM_CR2_CCUS_Msk          (0x1UL << TIM_CR2_CCUS_Pos)                  /* 0x00000004 */
#define TIM_CR2_CCUS              TIM_CR2_CCUS_Msk                             /* Capture/compare control update selection */

#define TIM_CR2_CCDS_DPos         (3U)
#define TIM_CR2_CCDS_Pos          TIM_CR2_CCDS_DPos
#define TIM_CR2_CCDS_Msk          (0x1UL << TIM_CR2_CCDS_Pos)                  /* 0x00000008 */
#define TIM_CR2_CCDS              TIM_CR2_CCDS_Msk                             /* Capture/compare DMA selection */

#define TIM_CR2_MMS_DPos          (4U)
#define TIM_CR2_MMS_Pos           TIM_CR2_MMS_DPos
#define TIM_CR2_MMS_Msk           (0x7UL << TIM_CR2_MMS_Pos)                   /* 0x00000070 */
#define TIM_CR2_MMS               TIM_CR2_MMS_Msk                              /*MMS[2:0] bits (Master mode selection) */
#define TIM_CR2_MMS_0             (0x1UL << TIM_CR2_MMS_Pos)                   /* 0x00000010 */
#define TIM_CR2_MMS_1             (0x2UL << TIM_CR2_MMS_Pos)                   /* 0x00000020 */
#define TIM_CR2_MMS_2             (0x4UL << TIM_CR2_MMS_Pos)                   /* 0x00000040 */

#define TIM_CR2_TI1S_DPos         (7U)
#define TIM_CR2_TI1S_Pos          TIM_CR2_TI1S_DPos
#define TIM_CR2_TI1S_Msk          (0x1UL << TIM_CR2_TI1S_Pos)                  /* 0x00000080 */
#define TIM_CR2_TI1S              TIM_CR2_TI1S_Msk                             /* TI1 selection */

#define TIM_CR2_OIS1_DPos         (8U)
#define TIM_CR2_OIS1_Pos          TIM_CR2_OIS1_DPos
#define TIM_CR2_OIS1_Msk          (0x1UL << TIM_CR2_OIS1_Pos)                  /* 0x00000100 */
#define TIM_CR2_OIS1              TIM_CR2_OIS1_Msk                             /* Output Idle state 1 (OC1 output) */

#define TIM_CR2_OIS1N_DPos        (9U)
#define TIM_CR2_OIS1N_Pos         TIM_CR2_OIS1N_DPos
#define TIM_CR2_OIS1N_Msk         (0x1UL << TIM_CR2_OIS1N_Pos)                 /* 0x00000200 */
#define TIM_CR2_OIS1N             TIM_CR2_OIS1N_Msk                            /* Output Idle state 1 (OC1N output) */

#define TIM_CR2_OIS2_DPos         (10U)
#define TIM_CR2_OIS2_Pos          TIM_CR2_OIS2_DPos
#define TIM_CR2_OIS2_Msk          (0x1UL << TIM_CR2_OIS2_Pos)                  /* 0x00000400 */
#define TIM_CR2_OIS2              TIM_CR2_OIS2_Msk                             /* Output Idle state 2 (OC2 output) */

#define TIM_CR2_OIS2N_DPos        (11U)
#define TIM_CR2_OIS2N_Pos         TIM_CR2_OIS2N_DPos
#define TIM_CR2_OIS2N_Msk         (0x1UL << TIM_CR2_OIS2N_Pos)                 /* 0x00000800 */
#define TIM_CR2_OIS2N             TIM_CR2_OIS2N_Msk                            /* Output Idle state 2 (OC2N output) */

#define TIM_CR2_OIS3_DPos         (12U)
#define TIM_CR2_OIS3_Pos          TIM_CR2_OIS3_DPos
#define TIM_CR2_OIS3_Msk          (0x1UL << TIM_CR2_OIS3_Pos)                  /* 0x00001000 */
#define TIM_CR2_OIS3              TIM_CR2_OIS3_Msk                             /* Output Idle state 3 (OC3 output) */

#define TIM_CR2_OIS3N_DPos        (13U)
#define TIM_CR2_OIS3N_Pos         TIM_CR2_OIS3N_DPos
#define TIM_CR2_OIS3N_Msk         (0x1UL << TIM_CR2_OIS3N_Pos)                 /* 0x00002000 */
#define TIM_CR2_OIS3N             TIM_CR2_OIS3N_Msk                            /* Output Idle state 3 (OC3N output) */

#define TIM_CR2_OIS4_DPos         (14U)
#define TIM_CR2_OIS4_Pos          TIM_CR2_OIS4_DPos
#define TIM_CR2_OIS4_Msk          (0x1UL << TIM_CR2_OIS4_Pos)                  /* 0x00004000 */
#define TIM_CR2_OIS4              TIM_CR2_OIS4_Msk                             /* Output Idle state 4 (OC4 output) */

#define TIM_CR2_OIS4N_DPos        (15U)
#define TIM_CR2_OIS4N_Pos         TIM_CR2_OIS4N_DPos
#define TIM_CR2_OIS4N_Msk         (0x1UL << TIM_CR2_OIS4N_Pos)                 /* 0x00008000 */
#define TIM_CR2_OIS4N             TIM_CR2_OIS4N_Msk                            /* Output Idle state 4 (OC4N output) */

#define TIM_CR2_OIS5_DPos         (16U)
#define TIM_CR2_OIS5_Pos          TIM_CR2_OIS5_DPos
#define TIM_CR2_OIS5_Msk          (0x1UL << TIM_CR2_OIS5_Pos)                  /* 0x00010000 */
#define TIM_CR2_OIS5              TIM_CR2_OIS5_Msk                             /* Output Idle state 5 (OC5 output) */

#define TIM_CR2_OIS5N_DPos        (17U)
#define TIM_CR2_OIS5N_Pos         TIM_CR2_OIS5N_DPos
#define TIM_CR2_OIS5N_Msk         (0x1UL << TIM_CR2_OIS5N_Pos)                 /* 0x00020000 */
#define TIM_CR2_OIS5N             TIM_CR2_OIS5N_Msk                            /* Output Idle state 5 (OC5N output) */

#define TIM_CR2_OIS6_DPos         (18U)
#define TIM_CR2_OIS6_Pos          TIM_CR2_OIS6_DPos
#define TIM_CR2_OIS6_Msk          (0x1UL << TIM_CR2_OIS6_Pos)                  /* 0x00040000 */
#define TIM_CR2_OIS6              TIM_CR2_OIS6_Msk                             /* Output Idle state 6 (OC6 output) */

#define TIM_CR2_OIS6N_DPos        (19U)
#define TIM_CR2_OIS6N_Pos         TIM_CR2_OIS6N_DPos
#define TIM_CR2_OIS6N_Msk         (0x1UL << TIM_CR2_OIS6N_Pos)                 /* 0x00080000 */
#define TIM_CR2_OIS6N             TIM_CR2_OIS6N_Msk                            /* Output Idle state 6 (OC6N output) */

#define TIM_CR2_MMS2_DPos         (20U)
#define TIM_CR2_MMS2_Pos          TIM_CR2_MMS2_DPos
#define TIM_CR2_MMS2_Msk          (0xFUL << TIM_CR2_MMS2_Pos)                  /* 0x00F00000 */
#define TIM_CR2_MMS2              TIM_CR2_MMS2_Msk                             /*MMS[2:0] bits (Master mode selection 2) */
#define TIM_CR2_MMS2_0            (0x1UL << TIM_CR2_MMS2_Pos)                  /* 0x00100000 */
#define TIM_CR2_MMS2_1            (0x2UL << TIM_CR2_MMS2_Pos)                  /* 0x00200000 */
#define TIM_CR2_MMS2_2            (0x4UL << TIM_CR2_MMS2_Pos)                  /* 0x00400000 */
#define TIM_CR2_MMS2_3            (0x8UL << TIM_CR2_MMS2_Pos)                  /* 0x00800000 */


/*******************  Bit definition for TIM_SMCR register  *******************/
#define TIM_SMCR_SMS_DPos         (0U)
#define TIM_SMCR_SMS_Pos          TIM_SMCR_SMS_DPos
#define TIM_SMCR_SMS_Msk          (0xFUL << TIM_SMCR_SMS_Pos)                  /* 0x0000000F */
#define TIM_SMCR_SMS              TIM_SMCR_SMS_Msk                             /* SMS[3:0] bits (Slave mode selection) */
#define TIM_SMCR_SMS_0            (0x1UL << TIM_SMCR_SMS_Pos)                  /* 0x00000001 */
#define TIM_SMCR_SMS_1            (0x2UL << TIM_SMCR_SMS_Pos)                  /* 0x00000002 */
#define TIM_SMCR_SMS_2            (0x4UL << TIM_SMCR_SMS_Pos)                  /* 0x00000004 */
#define TIM_SMCR_SMS_3            (0x8UL << TIM_SMCR_SMS_Pos)                  /* 0x00000008 */

#define TIM_SMCR_TS_DPos          (4U)
#define TIM_SMCR_TS_Pos           TIM_SMCR_TS_DPos
#define TIM_SMCR_TS_Msk           (0x7UL << TIM_SMCR_TS_Pos)                   /* 0x00000070 */
#define TIM_SMCR_TS               TIM_SMCR_TS_Msk                              /* TS[2:0] bits (Trigger selection) */
#define TIM_SMCR_TS_0             (0x1UL << TIM_SMCR_TS_Pos)                   /* 0x00000010 */
#define TIM_SMCR_TS_1             (0x2UL << TIM_SMCR_TS_Pos)                   /* 0x00000020 */
#define TIM_SMCR_TS_2             (0x4UL << TIM_SMCR_TS_Pos)                   /* 0x00000040 */

#define TIM_SMCR_ETF_DPos         (8U)
#define TIM_SMCR_ETF_Pos          TIM_SMCR_ETF_DPos
#define TIM_SMCR_ETF_Msk          (0xFUL << TIM_SMCR_ETF_Pos)                  /* 0x00000F00 */
#define TIM_SMCR_ETF              TIM_SMCR_ETF_Msk                             /* ETF[3:0] bits (External trigger filter) */
#define TIM_SMCR_ETF_0            (0x1UL << TIM_SMCR_ETF_Pos)                  /* 0x00000100 */
#define TIM_SMCR_ETF_1            (0x2UL << TIM_SMCR_ETF_Pos)                  /* 0x00000200 */
#define TIM_SMCR_ETF_2            (0x4UL << TIM_SMCR_ETF_Pos)                  /* 0x00000400 */
#define TIM_SMCR_ETF_3            (0x8UL << TIM_SMCR_ETF_Pos)                  /* 0x00000800 */

#define TIM_SMCR_ETPS_DPos        (12U)
#define TIM_SMCR_ETPS_Pos         TIM_SMCR_ETPS_DPos
#define TIM_SMCR_ETPS_Msk         (0x3UL << TIM_SMCR_ETPS_Pos)                 /* 0x00003000 */
#define TIM_SMCR_ETPS             TIM_SMCR_ETPS_Msk                            /* ETPS[1:0] bits (External trigger prescaler) */
#define TIM_SMCR_ETPS_0           (0x1UL << TIM_SMCR_ETPS_Pos)
#define TIM_SMCR_ETPS_1           (0x2UL << TIM_SMCR_ETPS_Pos)                 /* 0x00002000 */

#define TIM_SMCR_ECE_DPos         (14U)
#define TIM_SMCR_ECE_Pos          TIM_SMCR_ECE_DPos
#define TIM_SMCR_ECE_Msk          (0x1UL << TIM_SMCR_ECE_Pos)                  /* 0x00004000 */
#define TIM_SMCR_ECE              TIM_SMCR_ECE_Msk                             /* External clock enable */

#define TIM_SMCR_ETP_DPos         (15U)
#define TIM_SMCR_ETP_Pos          TIM_SMCR_ETP_DPos
#define TIM_SMCR_ETP_Msk          (0x1UL << TIM_SMCR_ETP_Pos)                  /* 0x00008000 */
#define TIM_SMCR_ETP              TIM_SMCR_ETP_Msk                             /* External trigger polarity */


/*******************  Bit definition for TIM_DIER register  *******************/
#define TIM_DIER_UIE_DPos         (0U)
#define TIM_DIER_UIE_Pos          TIM_DIER_UIE_DPos
#define TIM_DIER_UIE_Msk          (0x1UL << TIM_DIER_UIE_Pos)                  /* 0x00000001 */
#define TIM_DIER_UIE              TIM_DIER_UIE_Msk                             /* Update interrupt enable */

#define TIM_DIER_TIE_DPos         (2U)
#define TIM_DIER_TIE_Pos          TIM_DIER_TIE_DPos
#define TIM_DIER_TIE_Msk          (0x1UL << TIM_DIER_TIE_Pos)                  /* 0x00000004 */
#define TIM_DIER_TIE              TIM_DIER_TIE_Msk                             /* Trigger interrupt enable */

#define TIM_DIER_BIE_DPos         (3U)
#define TIM_DIER_BIE_Pos          TIM_DIER_BIE_DPos
#define TIM_DIER_BIE_Msk          (0x1UL << TIM_DIER_BIE_Pos)                  /* 0x00000008 */
#define TIM_DIER_BIE              TIM_DIER_BIE_Msk                             /* Break interrupt enable */

#define TIM_DIER_UDE_DPos         (8U)
#define TIM_DIER_UDE_Pos          TIM_DIER_UDE_DPos
#define TIM_DIER_UDE_Msk          (0x1UL << TIM_DIER_UDE_Pos)                  /* 0x00000100 */
#define TIM_DIER_UDE              TIM_DIER_UDE_Msk                             /* Update DMA request enable */

#define TIM_DIER_CC1IE_DPos       (16U)
#define TIM_DIER_CC1IE_Pos        TIM_DIER_CC1IE_DPos
#define TIM_DIER_CC1IE_Msk        (0x1UL << TIM_DIER_CC1IE_Pos)                /* 0x00010000 */
#define TIM_DIER_CC1IE            TIM_DIER_CC1IE_Msk                           /* Capture/Compare 1 interrupt enable */

#define TIM_DIER_CC2IE_DPos       (17U)
#define TIM_DIER_CC2IE_Pos        TIM_DIER_CC2IE_DPos
#define TIM_DIER_CC2IE_Msk        (0x1UL << TIM_DIER_CC2IE_Pos)                /* 0x00020000 */
#define TIM_DIER_CC2IE            TIM_DIER_CC2IE_Msk                           /* Capture/Compare 2 interrupt enable */

#define TIM_DIER_CC3IE_DPos       (18U)
#define TIM_DIER_CC3IE_Pos        TIM_DIER_CC3IE_DPos
#define TIM_DIER_CC3IE_Msk        (0x1UL << TIM_DIER_CC3IE_Pos)                /* 0x00040000 */
#define TIM_DIER_CC3IE            TIM_DIER_CC3IE_Msk

#define TIM_DIER_CC4IE_DPos       (19U)
#define TIM_DIER_CC4IE_Pos        TIM_DIER_CC4IE_DPos
#define TIM_DIER_CC4IE_Msk        (0x1UL << TIM_DIER_CC4IE_Pos)                /* 0x00080000 */
#define TIM_DIER_CC4IE            TIM_DIER_CC4IE_Msk                           /* Capture/Compare 4 interrupt enable */

#define TIM_DIER_CC5IE_DPos       (20U)
#define TIM_DIER_CC5IE_Pos        TIM_DIER_CC5IE_DPos
#define TIM_DIER_CC5IE_Msk        (0x1UL << TIM_DIER_CC5IE_Pos)                /* 0x00100000 */
#define TIM_DIER_CC5IE            TIM_DIER_CC5IE_Msk                           /* Capture/Compare 5 interrupt enable */

#define TIM_DIER_CC6IE_DPos       (21U)
#define TIM_DIER_CC6IE_Pos        TIM_DIER_CC6IE_DPos
#define TIM_DIER_CC6IE_Msk        (0x1UL << TIM_DIER_CC6IE_Pos)                /* 0x00200000 */
#define TIM_DIER_CC6IE            TIM_DIER_CC6IE_Msk                           /* Capture/Compare 6 interrupt enable */

#define TIM_DIER_CC1DE_DPos       (24U)
#define TIM_DIER_CC1DE_Pos        TIM_DIER_CC1DE_DPos
#define TIM_DIER_CC1DE_Msk        (0x1UL << TIM_DIER_CC1DE_Pos)                /* 0x01000000 */
#define TIM_DIER_CC1DE            TIM_DIER_CC1DE_Msk                           /* Capture/Compare 1 DMA request enable */

#define TIM_DIER_CC2DE_DPos       (25U)
#define TIM_DIER_CC2DE_Pos        TIM_DIER_CC2DE_DPos
#define TIM_DIER_CC2DE_Msk        (0x1UL << TIM_DIER_CC2DE_Pos)                /* 0x02000000 */
#define TIM_DIER_CC2DE            TIM_DIER_CC2DE_Msk                           /* Capture/Compare 2 DMA request enable */

#define TIM_DIER_CC3DE_DPos       (26U)
#define TIM_DIER_CC3DE_Pos        TIM_DIER_CC3DE_DPos
#define TIM_DIER_CC3DE_Msk        (0x1UL << TIM_DIER_CC3DE_Pos)                /* 0x04000000 */
#define TIM_DIER_CC3DE            TIM_DIER_CC3DE_Msk                           /* Capture/Compare 3 DMA request enable */

#define TIM_DIER_CC4DE_DPos       (27U)
#define TIM_DIER_CC4DE_Pos        TIM_DIER_CC4DE_DPos
#define TIM_DIER_CC4DE_Msk        (0x1UL << TIM_DIER_CC4DE_Pos)                /* 0x08000000 */
#define TIM_DIER_CC4DE            TIM_DIER_CC4DE_Msk                           /* Capture/Compare 4 DMA request enable */

#define TIM_DIER_CC5DE_DPos       (28U)
#define TIM_DIER_CC5DE_Pos        TIM_DIER_CC5DE_DPos
#define TIM_DIER_CC5DE_Msk        (0x1UL << TIM_DIER_CC5DE_Pos)                /* 0x10000000 */
#define TIM_DIER_CC5DE            TIM_DIER_CC5DE_Msk                           /* Capture/Compare 5 DMA request enable */

#define TIM_DIER_CC6DE_DPos       (29U)
#define TIM_DIER_CC6DE_Pos        TIM_DIER_CC6DE_DPos
#define TIM_DIER_CC6DE_Msk        (0x1UL << TIM_DIER_CC6DE_Pos)                /* 0x20000000 */
#define TIM_DIER_CC6DE            TIM_DIER_CC6DE_Msk                           /* Capture/Compare 6 DMA request enable */


/********************  Bit definition for TIM_SR register  ********************/
#define TIM_SR_UIF_DPos           (0U)
#define TIM_SR_UIF_Pos            TIM_SR_UIF_DPos
#define TIM_SR_UIF_Msk            (0x1UL << TIM_SR_UIF_Pos)                    /* 0x00000001 */
#define TIM_SR_UIF                TIM_SR_UIF_Msk                               /* Update interrupt flag */

#define TIM_SR_TIF_DPos           (2U)
#define TIM_SR_TIF_Pos            TIM_SR_TIF_DPos
#define TIM_SR_TIF_Msk            (0x1UL << TIM_SR_TIF_Pos)                    /* 0x00000004 */
#define TIM_SR_TIF                TIM_SR_TIF_Msk                               /* Trigger interrupt flag */

#define TIM_SR_BIF_DPos           (3U)
#define TIM_SR_BIF_Pos            TIM_SR_BIF_DPos
#define TIM_SR_BIF_Msk            (0x1UL << TIM_SR_BIF_Pos)                    /* 0x00000008 */
#define TIM_SR_BIF                TIM_SR_BIF_Msk                               /* Break interrupt flag */

#define TIM_SR_CC1IF_DPos         (16U)
#define TIM_SR_CC1IF_Pos          TIM_SR_CC1IF_DPos
#define TIM_SR_CC1IF_Msk          (0x1UL << TIM_SR_CC1IF_Pos)                  /* 0x00010000 */
#define TIM_SR_CC1IF              TIM_SR_CC1IF_Msk                             /* Capture/Compare 1 interrupt flag */

#define TIM_SR_CC2IF_DPos         (17U)
#define TIM_SR_CC2IF_Pos          TIM_SR_CC2IF_DPos
#define TIM_SR_CC2IF_Msk          (0x1UL << TIM_SR_CC2IF_Pos)                  /* 0x00020000 */
#define TIM_SR_CC2IF              TIM_SR_CC2IF_Msk                             /* Capture/Compare 2 interrupt flag */

#define TIM_SR_CC3IF_DPos         (18U)
#define TIM_SR_CC3IF_Pos          TIM_SR_CC3IF_DPos
#define TIM_SR_CC3IF_Msk          (0x1UL << TIM_SR_CC3IF_Pos)                  /* 0x00040000 */
#define TIM_SR_CC3IF              TIM_SR_CC3IF_Msk                             /* Capture/Compare 3 interrupt flag */

#define TIM_SR_CC4IF_DPos         (19U)
#define TIM_SR_CC4IF_Pos          TIM_SR_CC4IF_DPos
#define TIM_SR_CC4IF_Msk          (0x1UL << TIM_SR_CC4IF_Pos)                  /* 0x00080000 */
#define TIM_SR_CC4IF              TIM_SR_CC4IF_Msk                             /* Capture/Compare 4 interrupt flag */

#define TIM_SR_CC5IF_DPos         (20U)
#define TIM_SR_CC5IF_Pos          TIM_SR_CC5IF_DPos
#define TIM_SR_CC5IF_Msk          (0x1UL << TIM_SR_CC5IF_Pos)                  /* 0x00100000 */
#define TIM_SR_CC5IF              TIM_SR_CC5IF_Msk                             /* Capture/Compare 5 interrupt flag */

#define TIM_SR_CC6IF_DPos         (21U)
#define TIM_SR_CC6IF_Pos          TIM_SR_CC6IF_DPos
#define TIM_SR_CC6IF_Msk          (0x1UL << TIM_SR_CC6IF_Pos)                  /* 0x00200000 */
#define TIM_SR_CC6IF              TIM_SR_CC6IF_Msk                             /* Capture/Compare 6 interrupt flag */

#define TIM_SR_CC1OF_DPos         (24U)
#define TIM_SR_CC1OF_Pos          TIM_SR_CC1OF_DPos
#define TIM_SR_CC1OF_Msk          (0x1UL << TIM_SR_CC1OF_Pos)                  /* 0x01000000 */
#define TIM_SR_CC1OF              TIM_SR_CC1OF_Msk                             /* Capture/Compare 1 overcapture flag */

#define TIM_SR_CC2OF_DPos         (25U)
#define TIM_SR_CC2OF_Pos          TIM_SR_CC2OF_DPos
#define TIM_SR_CC2OF_Msk          (0x1UL << TIM_SR_CC2OF_Pos)                  /* 0x02000000 */
#define TIM_SR_CC2OF              TIM_SR_CC2OF_Msk                             /* Capture/Compare 2 overcapture flag */

#define TIM_SR_CC3OF_DPos         (26U)
#define TIM_SR_CC3OF_Pos          TIM_SR_CC3OF_DPos
#define TIM_SR_CC3OF_Msk          (0x1UL << TIM_SR_CC3OF_Pos)                  /* 0x04000000 */
#define TIM_SR_CC3OF              TIM_SR_CC3OF_Msk                             /* Capture/Compare 3 overcapture flag */

#define TIM_SR_CC4OF_DPos         (27U)
#define TIM_SR_CC4OF_Pos          TIM_SR_CC4OF_DPos
#define TIM_SR_CC4OF_Msk          (0x1UL << TIM_SR_CC4OF_Pos)                  /* 0x08000000 */
#define TIM_SR_CC4OF              TIM_SR_CC4OF_Msk                             /* Capture/Compare 4 overcapture flag */

#define TIM_SR_CC5OF_DPos         (28U)
#define TIM_SR_CC5OF_Pos          TIM_SR_CC5OF_DPos
#define TIM_SR_CC5OF_Msk          (0x1UL << TIM_SR_CC5OF_Pos)                  /* 0x10000000 */
#define TIM_SR_CC5OF              TIM_SR_CC5OF_Msk                             /* Capture/Compare 5 overcapture flag */

#define TIM_SR_CC6OF_DPos         (29U)
#define TIM_SR_CC6OF_Pos          TIM_SR_CC6OF_DPos
#define TIM_SR_CC6OF_Msk          (0x1UL << TIM_SR_CC6OF_Pos)                  /* 0x20000000 */
#define TIM_SR_CC6OF              TIM_SR_CC6OF_Msk                             /* Capture/Compare 6 overcapture flag */

/*******************  Bit definition for TIM_EGR register  ********************/
#define TIM_EGR_UG_DPos           (0U)
#define TIM_EGR_UG_Pos            TIM_EGR_UG_DPos
#define TIM_EGR_UG_Msk            (0x1UL << TIM_EGR_UG_Pos)                    /* 0x00000001 */
#define TIM_EGR_UG                TIM_EGR_UG_Msk                               /* Update generation */

#define TIM_EGR_COMG_DPos         (1U)
#define TIM_EGR_COMG_Pos          TIM_EGR_COMG_DPos
#define TIM_EGR_COMG_Msk          (0x1UL << TIM_EGR_COMG_Pos)                  /* 0x00000002 */
#define TIM_EGR_COMG              TIM_EGR_COMG_Msk                             /* Capture/Compare control update generation */

#define TIM_EGR_TG_DPos           (2U)
#define TIM_EGR_TG_Pos            TIM_EGR_TG_DPos
#define TIM_EGR_TG_Msk            (0x1UL << TIM_EGR_TG_Pos)                    /* 0x00000004 */
#define TIM_EGR_TG                TIM_EGR_TG_Msk                               /* Trigger generation */

#define TIM_EGR_BG_DPos           (3U)
#define TIM_EGR_BG_Pos            TIM_EGR_BG_DPos
#define TIM_EGR_BG_Msk            (0x1UL << TIM_EGR_BG_Pos)                    /* 0x00000008 */
#define TIM_EGR_BG                TIM_EGR_BG_Msk                               /* Break generation */

#define TIM_EGR_CC1G_DPos         (16U)
#define TIM_EGR_CC1G_Pos          TIM_EGR_CC1G_DPos
#define TIM_EGR_CC1G_Msk          (0x1UL << TIM_EGR_CC1G_Pos)                  /* 0x00010000 */
#define TIM_EGR_CC1G              TIM_EGR_CC1G_Msk                             /* Capture/Compare 1 generation */

#define TIM_EGR_CC2G_DPos         (17U)
#define TIM_EGR_CC2G_Pos          TIM_EGR_CC2G_DPos
#define TIM_EGR_CC2G_Msk          (0x1UL << TIM_EGR_CC2G_Pos)                  /* 0x00020000 */
#define TIM_EGR_CC2G              TIM_EGR_CC2G_Msk                             /* Capture/Compare 2 generation */

#define TIM_EGR_CC3G_DPos         (18U)
#define TIM_EGR_CC3G_Pos          TIM_EGR_CC3G_DPos
#define TIM_EGR_CC3G_Msk          (0x1UL << TIM_EGR_CC3G_Pos)                  /* 0x00040000 */
#define TIM_EGR_CC3G              TIM_EGR_CC3G_Msk                             /* Capture/Compare 3 generation */

#define TIM_EGR_CC4G_DPos         (19U)
#define TIM_EGR_CC4G_Pos          TIM_EGR_CC4G_DPos
#define TIM_EGR_CC4G_Msk          (0x1UL << TIM_EGR_CC4G_Pos)                  /* 0x00080000 */
#define TIM_EGR_CC4G              TIM_EGR_CC4G_Msk                             /* Capture/Compare 4 generation */

#define TIM_EGR_CC5G_DPos         (20U)
#define TIM_EGR_CC5G_Pos          TIM_EGR_CC5G_DPos
#define TIM_EGR_CC5G_Msk          (0x1UL << TIM_EGR_CC5G_Pos)                  /* 0x00100000 */
#define TIM_EGR_CC5G              TIM_EGR_CC5G_Msk                             /* Capture/Compare 5 generation */

#define TIM_EGR_CC6G_DPos         (21U)
#define TIM_EGR_CC6G_Pos          TIM_EGR_CC6G_DPos
#define TIM_EGR_CC6G_Msk          (0x1UL << TIM_EGR_CC6G_Pos)                  /* 0x00200000 */
#define TIM_EGR_CC6G              TIM_EGR_CC6G_Msk                             /* Capture/Compare 6 generation */



/******************  Bit definition for TIM_CCMR1 register  *******************/
#define TIM_CCMR1_CC1S_DPos       (0U)
#define TIM_CCMR1_CC1S_Pos        TIM_CCMR1_CC1S_DPos
#define TIM_CCMR1_CC1S_Msk        (0x3UL << TIM_CCMR1_CC1S_Pos)                /* 0x00000003 */
#define TIM_CCMR1_CC1S            TIM_CCMR1_CC1S_Msk                           /* CC1S[1:0] bits (Capture/Compare 1 selection) */
#define TIM_CCMR1_CC1S_0          (0x1UL << TIM_CCMR1_CC1S_Pos)                /* 0x00000001 */
#define TIM_CCMR1_CC1S_1          (0x2UL << TIM_CCMR1_CC1S_Pos)                /* 0x00000002 */

#define TIM_CCMR1_OC1FE_DPos      (2U)
#define TIM_CCMR1_OC1FE_Pos       TIM_CCMR1_OC1FE_DPos
#define TIM_CCMR1_OC1FE_Msk       (0x1UL << TIM_CCMR1_OC1FE_Pos)               /* 0x00000004 */
#define TIM_CCMR1_OC1FE           TIM_CCMR1_OC1FE_Msk                          /* Output Compare 1 fast enable */

#define TIM_CCMR1_OC1PE_DPos      (3U)
#define TIM_CCMR1_OC1PE_Pos       TIM_CCMR1_OC1PE_DPos
#define TIM_CCMR1_OC1PE_Msk       (0x1UL << TIM_CCMR1_OC1PE_Pos)               /* 0x00000008 */
#define TIM_CCMR1_OC1PE           TIM_CCMR1_OC1PE_Msk                          /* Output Compare 1 preload enable */

#define TIM_CCMR1_OC1M_DPos       (4U)
#define TIM_CCMR1_OC1M_Pos        TIM_CCMR1_OC1M_DPos
#define TIM_CCMR1_OC1M_Msk        (0x1007UL << TIM_CCMR1_OC1M_Pos)             /* 0x00010070 */
#define TIM_CCMR1_OC1M            TIM_CCMR1_OC1M_Msk                           /* OC1M[2:0] bits (Output Compare 1 mode) */
#define TIM_CCMR1_OC1M_0          (0x0001UL << TIM_CCMR1_OC1M_Pos)             /* 0x00000010 */
#define TIM_CCMR1_OC1M_1          (0x0002UL << TIM_CCMR1_OC1M_Pos)             /* 0x00000020 */
#define TIM_CCMR1_OC1M_2          (0x0004UL << TIM_CCMR1_OC1M_Pos)             /* 0x00000040 */
#define TIM_CCMR1_OC1M_3          (0x1000UL << TIM_CCMR1_OC1M_Pos)             /* 0x00010000 */

#define TIM_CCMR1_OC1CE_DPos      (7U)
#define TIM_CCMR1_OC1CE_Pos       TIM_CCMR1_OC1CE_DPos
#define TIM_CCMR1_OC1CE_Msk       (0x1UL << TIM_CCMR1_OC1CE_Pos)               /* 0x00000080 */
#define TIM_CCMR1_OC1CE           TIM_CCMR1_OC1CE_Msk                          /* Output Compare 1 clear enable */

#define TIM_CCMR1_CC2S_DPos       (8U)
#define TIM_CCMR1_CC2S_Pos        TIM_CCMR1_CC2S_DPos
#define TIM_CCMR1_CC2S_Msk        (0x3UL << TIM_CCMR1_CC2S_Pos)                /* 0x00000300 */
#define TIM_CCMR1_CC2S            TIM_CCMR1_CC2S_Msk                           /* CC2S[1:0] bits (Capture/Compare 2 selection) */
#define TIM_CCMR1_CC2S_0          (0x1UL << TIM_CCMR1_CC2S_Pos)                /* 0x00000100 */
#define TIM_CCMR1_CC2S_1          (0x2UL << TIM_CCMR1_CC2S_Pos)                /* 0x00000200 */


#define TIM_CCMR1_OC2FE_DPos      (10U)
#define TIM_CCMR1_OC2FE_Pos       TIM_CCMR1_OC2FE_DPos
#define TIM_CCMR1_OC2FE_Msk       (0x1UL << TIM_CCMR1_OC2FE_Pos)               /* 0x00000400 */
#define TIM_CCMR1_OC2FE           TIM_CCMR1_OC2FE_Msk                          /* Output Compare 2 fast enable */

#define TIM_CCMR1_OC2PE_DPos      (11U)
#define TIM_CCMR1_OC2PE_Pos       TIM_CCMR1_OC2PE_DPos
#define TIM_CCMR1_OC2PE_Msk       (0x1UL << TIM_CCMR1_OC2PE_Pos)               /* 0x00000800 */
#define TIM_CCMR1_OC2PE           TIM_CCMR1_OC2PE_Msk                          /* Output Compare 2 preload enable */

#define TIM_CCMR1_OC2M_DPos       (12U)
#define TIM_CCMR1_OC2M_Pos        TIM_CCMR1_OC2M_DPos
#define TIM_CCMR1_OC2M_Msk        (0x1007UL << TIM_CCMR1_OC2M_Pos)             /* 0x01007000 */
#define TIM_CCMR1_OC2M            TIM_CCMR1_OC2M_Msk                           /* OC2M[2:0] bits (Output Compare 2 mode) */
#define TIM_CCMR1_OC2M_0          (0x0001UL << TIM_CCMR1_OC2M_Pos)             /* 0x00001000 */
#define TIM_CCMR1_OC2M_1          (0x0002UL << TIM_CCMR1_OC2M_Pos)             /* 0x00002000 */
#define TIM_CCMR1_OC2M_2          (0x0004UL << TIM_CCMR1_OC2M_Pos)             /* 0x00004000 */
#define TIM_CCMR1_OC2M_3          (0x1000UL << TIM_CCMR1_OC2M_Pos)             /* 0x01000000 */

#define TIM_CCMR1_OC2CE_DPos      (15U)
#define TIM_CCMR1_OC2CE_Pos       TIM_CCMR1_OC2CE_DPos
#define TIM_CCMR1_OC2CE_Msk       (0x1UL << TIM_CCMR1_OC2CE_Pos)               /* 0x00008000 */
#define TIM_CCMR1_OC2CE           TIM_CCMR1_OC2CE_Msk                          /* Output Compare 2 clear enable */


/*----------------------------------------------------------------------------*/

#define TIM_CCMR1_IC1PSC_DPos     (2U)
#define TIM_CCMR1_IC1PSC_Pos      TIM_CCMR1_IC1PSC_DPos
#define TIM_CCMR1_IC1PSC_Msk      (0x3UL << TIM_CCMR1_IC1PSC_Pos)              /* 0x0000000C */
#define TIM_CCMR1_IC1PSC          TIM_CCMR1_IC1PSC_Msk                         /* IC1PSC[1:0] bits (Input capture 1 prescaler) */
#define TIM_CCMR1_IC1PSC_0        (0x1UL << TIM_CCMR1_IC1PSC_Pos)              /* 0x00000004 */
#define TIM_CCMR1_IC1PSC_1        (0x2UL << TIM_CCMR1_IC1PSC_Pos)              /* 0x00000008 */

#define TIM_CCMR1_IC1F_DPos       (4U)
#define TIM_CCMR1_IC1F_Pos        TIM_CCMR1_IC1F_DPos
#define TIM_CCMR1_IC1F_Msk        (0xFUL << TIM_CCMR1_IC1F_Pos)                /* 0x000000F0 */
#define TIM_CCMR1_IC1F            TIM_CCMR1_IC1F_Msk                           /* IC1F[3:0] bits (Input capture 1 filter) */
#define TIM_CCMR1_IC1F_0          (0x1UL << TIM_CCMR1_IC1F_Pos)                /* 0x00000010 */
#define TIM_CCMR1_IC1F_1          (0x2UL << TIM_CCMR1_IC1F_Pos)                /* 0x00000020 */
#define TIM_CCMR1_IC1F_2          (0x4UL << TIM_CCMR1_IC1F_Pos)                /* 0x00000040 */
#define TIM_CCMR1_IC1F_3          (0x8UL << TIM_CCMR1_IC1F_Pos)                /* 0x00000080 */

#define TIM_CCMR1_IC2PSC_DPos     (10U)
#define TIM_CCMR1_IC2PSC_Pos      TIM_CCMR1_IC2PSC_DPos
#define TIM_CCMR1_IC2PSC_Msk      (0x3UL << TIM_CCMR1_IC2PSC_Pos)              /* 0x00000C00 */
#define TIM_CCMR1_IC2PSC          TIM_CCMR1_IC2PSC_Msk                         /* IC2PSC[1:0] bits (Input capture 2 prescaler) */
#define TIM_CCMR1_IC2PSC_0        (0x1UL << TIM_CCMR1_IC2PSC_Pos)              /* 0x00000400 */
#define TIM_CCMR1_IC2PSC_1        (0x2UL << TIM_CCMR1_IC2PSC_Pos)              /* 0x00000800 */

#define TIM_CCMR1_IC2F_DPos       (12U)
#define TIM_CCMR1_IC2F_Pos        TIM_CCMR1_IC2F_DPos
#define TIM_CCMR1_IC2F_Msk        (0xFUL << TIM_CCMR1_IC2F_Pos)                /* 0x0000F000 */
#define TIM_CCMR1_IC2F            TIM_CCMR1_IC2F_Msk                           /* IC2F[3:0] bits (Input capture 2 filter) */
#define TIM_CCMR1_IC2F_0          (0x1UL << TIM_CCMR1_IC2F_Pos)                /* 0x00001000 */
#define TIM_CCMR1_IC2F_1          (0x2UL << TIM_CCMR1_IC2F_Pos)                /* 0x00002000 */
#define TIM_CCMR1_IC2F_2          (0x4UL << TIM_CCMR1_IC2F_Pos)                /* 0x00004000 */
#define TIM_CCMR1_IC2F_3          (0x8UL << TIM_CCMR1_IC2F_Pos)                /* 0x00008000 */

/******************  Bit definition for TIM_CCMR2 register  *******************/
#define TIM_CCMR2_CC3S_DPos       (0U)
#define TIM_CCMR2_CC3S_Pos        TIM_CCMR2_CC3S_DPos
#define TIM_CCMR2_CC3S_Msk        (0x3UL << TIM_CCMR2_CC3S_Pos)                /* 0x00000003 */
#define TIM_CCMR2_CC3S            TIM_CCMR2_CC3S_Msk                           /* CC3S[1:0] bits (Capture/Compare 3 selection) */
#define TIM_CCMR2_CC3S_0          (0x1UL << TIM_CCMR2_CC3S_Pos)                /* 0x00000001 */
#define TIM_CCMR2_CC3S_1          (0x2UL << TIM_CCMR2_CC3S_Pos)                /* 0x00000002 */

#define TIM_CCMR2_OC3FE_DPos      (2U)
#define TIM_CCMR2_OC3FE_Pos       TIM_CCMR2_OC3FE_DPos
#define TIM_CCMR2_OC3FE_Msk       (0x1UL << TIM_CCMR2_OC3FE_Pos)               /* 0x00000004 */
#define TIM_CCMR2_OC3FE           TIM_CCMR2_OC3FE_Msk                          /* Output compare 3 fast enable */

#define TIM_CCMR2_OC3PE_DPos      (3U)
#define TIM_CCMR2_OC3PE_Pos       TIM_CCMR2_OC3PE_DPos
#define TIM_CCMR2_OC3PE_Msk       (0x1UL << TIM_CCMR2_OC3PE_Pos)               /* 0x00000008 */
#define TIM_CCMR2_OC3PE           TIM_CCMR2_OC3PE_Msk                          /* Output compare 3 preload enable */

#define TIM_CCMR2_OC3M_DPos       (4U)
#define TIM_CCMR2_OC3M_Pos        TIM_CCMR2_OC3M_DPos
#define TIM_CCMR2_OC3M_Msk        (0x1007UL << TIM_CCMR2_OC3M_Pos)             /* 0x00010070 */
#define TIM_CCMR2_OC3M            TIM_CCMR2_OC3M_Msk                           /* OC3M[2:0] bits (Output compare 3 mode) */
#define TIM_CCMR2_OC3M_0          (0x0001UL << TIM_CCMR2_OC3M_Pos)             /* 0x00000010 */
#define TIM_CCMR2_OC3M_1          (0x0002UL << TIM_CCMR2_OC3M_Pos)             /* 0x00000020 */
#define TIM_CCMR2_OC3M_2          (0x0004UL << TIM_CCMR2_OC3M_Pos)             /* 0x00000040 */
#define TIM_CCMR2_OC3M_3          (0x1000UL << TIM_CCMR2_OC3M_Pos)             /* 0x00010000 */

#define TIM_CCMR2_OC3CE_DPos      (7U)
#define TIM_CCMR2_OC3CE_Pos       TIM_CCMR2_OC3CE_DPos
#define TIM_CCMR2_OC3CE_Msk       (0x1UL << TIM_CCMR2_OC3CE_Pos)               /* 0x00000080 */
#define TIM_CCMR2_OC3CE           TIM_CCMR2_OC3CE_Msk

#define TIM_CCMR2_CC4S_DPos       (8U)
#define TIM_CCMR2_CC4S_Pos        TIM_CCMR2_CC4S_DPos
#define TIM_CCMR2_CC4S_Msk        (0x3UL << TIM_CCMR2_CC4S_Pos)                /* 0x00000300 */
#define TIM_CCMR2_CC4S            TIM_CCMR2_CC4S_Msk                           /* CC4S[1:0] bits (Capture/Compare 4 selection) */
#define TIM_CCMR2_CC4S_0          (0x1UL << TIM_CCMR2_CC4S_Pos)                /* 0x00000100 */
#define TIM_CCMR2_CC4S_1          (0x2UL << TIM_CCMR2_CC4S_Pos)                /* 0x00000200 */

#define TIM_CCMR2_OC4FE_DPos      (10U)
#define TIM_CCMR2_OC4FE_Pos       TIM_CCMR2_OC4FE_DPos
#define TIM_CCMR2_OC4FE_Msk       (0x1UL << TIM_CCMR2_OC4FE_Pos)               /* 0x00000400 */
#define TIM_CCMR2_OC4FE           TIM_CCMR2_OC4FE_Msk                          /* Output compare 4 fast enable */

#define TIM_CCMR2_OC4PE_DPos      (11U)
#define TIM_CCMR2_OC4PE_Pos       TIM_CCMR2_OC4PE_DPos
#define TIM_CCMR2_OC4PE_Msk       (0x1UL << TIM_CCMR2_OC4PE_Pos)               /* 0x00000800 */
#define TIM_CCMR2_OC4PE           TIM_CCMR2_OC4PE_Msk                          /* Output compare 4 preload enable */

#define TIM_CCMR2_OC4M_DPos       (12U)
#define TIM_CCMR2_OC4M_Pos        TIM_CCMR2_OC4M_DPos
#define TIM_CCMR2_OC4M_Msk        (0x1007UL << TIM_CCMR2_OC4M_Pos)             /* 0x01007000 */
#define TIM_CCMR2_OC4M            TIM_CCMR2_OC4M_Msk                           /* OC4M[2:0] bits (Output compare 4 mode) */
#define TIM_CCMR2_OC4M_0          (0x0001UL << TIM_CCMR2_OC4M_Pos)             /* 0x00001000 */
#define TIM_CCMR2_OC4M_1          (0x0002UL << TIM_CCMR2_OC4M_Pos)             /* 0x00002000 */
#define TIM_CCMR2_OC4M_2          (0x0004UL << TIM_CCMR2_OC4M_Pos)             /* 0x00004000 */
#define TIM_CCMR2_OC4M_3          (0x1000UL << TIM_CCMR2_OC4M_Pos)             /* 0x01000000 */

#define TIM_CCMR2_OC4CE_DPos      (15U)
#define TIM_CCMR2_OC4CE_Pos       TIM_CCMR2_OC4CE_DPos
#define TIM_CCMR2_OC4CE_Msk       (0x1UL << TIM_CCMR2_OC4CE_Pos)               /* 0x00008000 */
#define TIM_CCMR2_OC4CE           TIM_CCMR2_OC4CE_Msk                          /* Output compare 4 clear enable */


/*----------------------------------------------------------------------------*/

#define TIM_CCMR2_IC3PSC_DPos     (2U)
#define TIM_CCMR2_IC3PSC_Pos      TIM_CCMR2_IC3PSC_DPos
#define TIM_CCMR2_IC3PSC_Msk      (0x3UL << TIM_CCMR2_IC3PSC_Pos)              /* 0x0000000C */
#define TIM_CCMR2_IC3PSC          TIM_CCMR2_IC3PSC_Msk                         /* IC3PSC[1:0] bits (Input capture 3 prescaler) */
#define TIM_CCMR2_IC3PSC_0        (0x1UL << TIM_CCMR2_IC3PSC_Pos)              /* 0x00000004 */
#define TIM_CCMR2_IC3PSC_1        (0x2UL << TIM_CCMR2_IC3PSC_Pos)              /* 0x00000008 */

#define TIM_CCMR2_IC3F_DPos       (4U)
#define TIM_CCMR2_IC3F_Pos        TIM_CCMR2_IC3F_DPos
#define TIM_CCMR2_IC3F_Msk        (0xFUL << TIM_CCMR2_IC3F_Pos)                /* 0x000000F0 */
#define TIM_CCMR2_IC3F            TIM_CCMR2_IC3F_Msk                           /* IC3F[3:0] bits (Input capture 3 filter) */
#define TIM_CCMR2_IC3F_0          (0x1UL << TIM_CCMR2_IC3F_Pos)                /* 0x00000010 */
#define TIM_CCMR2_IC3F_1          (0x2UL << TIM_CCMR2_IC3F_Pos)                /* 0x00000020 */
#define TIM_CCMR2_IC3F_2          (0x4UL << TIM_CCMR2_IC3F_Pos)                /* 0x00000040 */
#define TIM_CCMR2_IC3F_3          (0x8UL << TIM_CCMR2_IC3F_Pos)                /* 0x00000080 */

#define TIM_CCMR2_IC4PSC_DPos     (10U)
#define TIM_CCMR2_IC4PSC_Pos      TIM_CCMR2_IC4PSC_DPos
#define TIM_CCMR2_IC4PSC_Msk      (0x3UL << TIM_CCMR2_IC4PSC_Pos)              /* 0x00000C00 */
#define TIM_CCMR2_IC4PSC          TIM_CCMR2_IC4PSC_Msk                         /* IC4PSC[1:0] bits (Input capture 4 prescaler) */
#define TIM_CCMR2_IC4PSC_0        (0x1UL << TIM_CCMR2_IC4PSC_Pos)              /* 0x00000400 */
#define TIM_CCMR2_IC4PSC_1        (0x2UL << TIM_CCMR2_IC4PSC_Pos)

#define TIM_CCMR2_IC4F_DPos       (12U)
#define TIM_CCMR2_IC4F_Pos        TIM_CCMR2_IC4F_DPos
#define TIM_CCMR2_IC4F_Msk        (0xFUL << TIM_CCMR2_IC4F_Pos)                /* 0x0000F000 */
#define TIM_CCMR2_IC4F            TIM_CCMR2_IC4F_Msk                           /* IC4F[3:0] bits (Input capture 4 filter) */
#define TIM_CCMR2_IC4F_0          (0x1UL << TIM_CCMR2_IC4F_Pos)                /* 0x00001000 */
#define TIM_CCMR2_IC4F_1          (0x2UL << TIM_CCMR2_IC4F_Pos)                /* 0x00002000 */
#define TIM_CCMR2_IC4F_2          (0x4UL << TIM_CCMR2_IC4F_Pos)                /* 0x00004000 */
#define TIM_CCMR2_IC4F_3          (0x8UL << TIM_CCMR2_IC4F_Pos)                /* 0x00008000 */

/******************  Bit definition for TIM_CCMR3 register  *******************/
#define TIM_CCMR3_CC5S_DPos       (0U)
#define TIM_CCMR3_CC5S_Pos        TIM_CCMR3_CC5S_DPos
#define TIM_CCMR3_CC5S_Msk        (0x3UL << TIM_CCMR3_CC5S_Pos)                /* 0x00000003 */
#define TIM_CCMR3_CC5S            TIM_CCMR3_CC5S_Msk                           /* CC5S[1:0] bits (Capture/Compare 5 selection) */
#define TIM_CCMR3_CC5S_0          (0x1UL << TIM_CCMR3_CC5S_Pos)                /* 0x00000001 */
#define TIM_CCMR3_CC5S_1          (0x2UL << TIM_CCMR3_CC5S_Pos)                /* 0x00000002 */

#define TIM_CCMR3_OC5FE_DPos      (2U)
#define TIM_CCMR3_OC5FE_Pos       TIM_CCMR3_OC5FE_DPos
#define TIM_CCMR3_OC5FE_Msk       (0x1UL << TIM_CCMR3_OC5FE_Pos)               /* 0x00000004 */
#define TIM_CCMR3_OC5FE           TIM_CCMR3_OC5FE_Msk                          /* Output compare 5 fast enable */

#define TIM_CCMR3_OC5PE_DPos      (3U)
#define TIM_CCMR3_OC5PE_Pos       TIM_CCMR3_OC5PE_DPos
#define TIM_CCMR3_OC5PE_Msk       (0x1UL << TIM_CCMR3_OC5PE_Pos)               /* 0x00000008 */
#define TIM_CCMR3_OC5PE           TIM_CCMR3_OC5PE_Msk                          /* Output compare 5 preload enable */

#define TIM_CCMR3_OC5M_DPos       (4U)
#define TIM_CCMR3_OC5M_Pos        TIM_CCMR3_OC5M_DPos
#define TIM_CCMR3_OC5M_Msk        (0x1007UL << TIM_CCMR3_OC5M_Pos)             /* 0x00010070 */
#define TIM_CCMR3_OC5M            TIM_CCMR3_OC5M_Msk                           /* OC5M[2:0] bits (Output compare 5 mode) */
#define TIM_CCMR3_OC5M_0          (0x0001UL << TIM_CCMR3_OC5M_Pos)             /* 0x00000010 */
#define TIM_CCMR3_OC5M_1          (0x0002UL << TIM_CCMR3_OC5M_Pos)             /* 0x00000020 */
#define TIM_CCMR3_OC5M_2          (0x0004UL << TIM_CCMR3_OC5M_Pos)             /* 0x00000040 */
#define TIM_CCMR3_OC5M_3          (0x1000UL << TIM_CCMR3_OC5M_Pos)             /* 0x00010000 */

#define TIM_CCMR3_OC5CE_DPos      (7U)
#define TIM_CCMR3_OC5CE_Pos       TIM_CCMR3_OC5CE_DPos
#define TIM_CCMR3_OC5CE_Msk       (0x1UL << TIM_CCMR3_OC5CE_Pos)               /* 0x00000080 */
#define TIM_CCMR3_OC5CE           TIM_CCMR3_OC5CE_Msk

#define TIM_CCMR3_CC6S_DPos       (8U)
#define TIM_CCMR3_CC6S_Pos        TIM_CCMR3_CC6S_DPos
#define TIM_CCMR3_CC6S_Msk        (0x3UL << TIM_CCMR3_CC6S_Pos)                /* 0x00000300 */
#define TIM_CCMR3_CC6S            TIM_CCMR3_CC6S_Msk                           /* CC6S[1:0] bits (Capture/Compare 6 selection) */
#define TIM_CCMR3_CC6S_0          (0x1UL << TIM_CCMR3_CC6S_Pos)                /* 0x00000100 */
#define TIM_CCMR3_CC6S_1          (0x2UL << TIM_CCMR3_CC6S_Pos)                /* 0x00000200 */

#define TIM_CCMR3_OC6FE_DPos      (10U)
#define TIM_CCMR3_OC6FE_Pos       TIM_CCMR3_OC6FE_DPos
#define TIM_CCMR3_OC6FE_Msk       (0x1UL << TIM_CCMR3_OC6FE_Pos)               /* 0x00000400 */
#define TIM_CCMR3_OC6FE           TIM_CCMR3_OC6FE_Msk                          /* Output compare 6 fast enable */

#define TIM_CCMR3_OC6PE_DPos      (11U)
#define TIM_CCMR3_OC6PE_Pos       TIM_CCMR3_OC6PE_DPos
#define TIM_CCMR3_OC6PE_Msk       (0x1UL << TIM_CCMR3_OC6PE_Pos)               /* 0x00000800 */
#define TIM_CCMR3_OC6PE           TIM_CCMR3_OC6PE_Msk                          /* Output compare 6 preload enable */

#define TIM_CCMR3_OC6M_DPos       (12U)
#define TIM_CCMR3_OC6M_Pos        TIM_CCMR3_OC6M_DPos
#define TIM_CCMR3_OC6M_Msk        (0x1007UL << TIM_CCMR3_OC6M_Pos)             /* 0x01007000 */
#define TIM_CCMR3_OC6M            TIM_CCMR3_OC6M_Msk                           /* OC6M[2:0] bits (Output compare 6 mode) */
#define TIM_CCMR3_OC6M_0          (0x0001UL << TIM_CCMR3_OC6M_Pos)             /* 0x00001000 */
#define TIM_CCMR3_OC6M_1          (0x0002UL << TIM_CCMR3_OC6M_Pos)             /* 0x00002000 */
#define TIM_CCMR3_OC6M_2          (0x0004UL << TIM_CCMR3_OC6M_Pos)             /* 0x00004000 */
#define TIM_CCMR3_OC6M_3          (0x1000UL << TIM_CCMR3_OC6M_Pos)             /* 0x01000000 */

#define TIM_CCMR3_OC6CE_DPos      (15U)
#define TIM_CCMR3_OC6CE_Pos       TIM_CCMR3_OC6CE_DPos
#define TIM_CCMR3_OC6CE_Msk       (0x1UL << TIM_CCMR3_OC6CE_Pos)               /* 0x00008000 */
#define TIM_CCMR3_OC6CE           TIM_CCMR3_OC6CE_Msk                          /* Output compare 6 clear enable */

/*----------------------------------------------------------------------------*/

#define TIM_CCMR3_IC5PSC_DPos     (2U)
#define TIM_CCMR3_IC5PSC_Pos      TIM_CCMR3_IC5PSC_DPos
#define TIM_CCMR3_IC5PSC_Msk      (0x3UL << TIM_CCMR3_IC5PSC_Pos)              /* 0x0000000C */
#define TIM_CCMR3_IC5PSC          TIM_CCMR3_IC5PSC_Msk                         /*IC5PSC[1:0] bits (Input capture 5 prescaler) */
#define TIM_CCMR3_IC5PSC_0        (0x1UL << TIM_CCMR3_IC5PSC_Pos)              /* 0x00000004 */
#define TIM_CCMR3_IC5PSC_1        (0x2UL << TIM_CCMR3_IC5PSC_Pos)              /* 0x00000008 */

#define TIM_CCMR3_IC5F_DPos       (4U)
#define TIM_CCMR3_IC5F_Pos        TIM_CCMR3_IC5F_DPos
#define TIM_CCMR3_IC5F_Msk        (0xFUL << TIM_CCMR3_IC5F_Pos)                /* 0x000000F0 */
#define TIM_CCMR3_IC5F            TIM_CCMR3_IC5F_Msk                           /*IC5F[3:0] bits (Input capture 5 filter) */
#define TIM_CCMR3_IC5F_0          (0x1UL << TIM_CCMR3_IC5F_Pos)                /* 0x00000010 */
#define TIM_CCMR3_IC5F_1          (0x2UL << TIM_CCMR3_IC5F_Pos)                /* 0x00000020 */
#define TIM_CCMR3_IC5F_2          (0x4UL << TIM_CCMR3_IC5F_Pos)                /* 0x00000040 */
#define TIM_CCMR3_IC5F_3          (0x8UL << TIM_CCMR3_IC5F_Pos)                /* 0x00000080 */

#define TIM_CCMR3_IC6PSC_DPos     (10U)
#define TIM_CCMR3_IC6PSC_Pos      TIM_CCMR3_IC6PSC_DPos
#define TIM_CCMR3_IC6PSC_Msk      (0x3UL << TIM_CCMR3_IC6PSC_Pos)              /* 0x00000C00 */
#define TIM_CCMR3_IC6PSC          TIM_CCMR3_IC6PSC_Msk                         /*IC6PSC[1:0] bits (Input capture 6 prescaler) */
#define TIM_CCMR3_IC6PSC_0        (0x1UL << TIM_CCMR3_IC6PSC_Pos)              /* 0x00000400 */
#define TIM_CCMR3_IC6PSC_1        (0x2UL << TIM_CCMR3_IC6PSC_Pos)              /* 0x00000800 */

#define TIM_CCMR3_IC6F_DPos       (12U)
#define TIM_CCMR3_IC6F_Pos        TIM_CCMR3_IC6F_DPos
#define TIM_CCMR3_IC6F_Msk        (0xFUL << TIM_CCMR3_IC6F_Pos)                /* 0x0000F000 */
#define TIM_CCMR3_IC6F            TIM_CCMR3_IC6F_Msk                           /* IC6F[3:0] bits (Input capture 6 filter) */
#define TIM_CCMR3_IC6F_0          (0x1UL << TIM_CCMR3_IC6F_Pos)                /* 0x00001000 */
#define TIM_CCMR3_IC6F_1          (0x2UL << TIM_CCMR3_IC6F_Pos)                /* 0x00002000 */
#define TIM_CCMR3_IC6F_2          (0x4UL << TIM_CCMR3_IC6F_Pos)                /* 0x00004000 */
#define TIM_CCMR3_IC6F_3          (0x8UL << TIM_CCMR3_IC6F_Pos)                /* 0x00008000 */

/*******************  Bit definition for TIM_CCER register  *******************/
#define TIM_CCER_CC1E_DPos         (0U)
#define TIM_CCER_CC1E_Pos          TIM_CCER_CC1E_DPos
#define TIM_CCER_CC1E_Msk          (0x1UL << TIM_CCER_CC1E_Pos)                 /* 0x00000001 */
#define TIM_CCER_CC1E              TIM_CCER_CC1E_Msk                            /* Capture/Compare 1 output enable */

#define TIM_CCER_CC1P_DPos         (1U)
#define TIM_CCER_CC1P_Pos          TIM_CCER_CC1P_DPos
#define TIM_CCER_CC1P_Msk          (0x1UL << TIM_CCER_CC1P_Pos)                 /* 0x00000002 */
#define TIM_CCER_CC1P              TIM_CCER_CC1P_Msk                            /* Capture/Compare 1 output polarity */

#define TIM_CCER_CC1NE_DPos        (2U)
#define TIM_CCER_CC1NE_Pos         TIM_CCER_CC1NE_DPos
#define TIM_CCER_CC1NE_Msk         (0x1UL << TIM_CCER_CC1NE_Pos)                /* 0x00000004 */
#define TIM_CCER_CC1NE             TIM_CCER_CC1NE_Msk                           /* Capture/Compare 1 complementary output enable */

#define TIM_CCER_CC1NP_DPos        (3U)
#define TIM_CCER_CC1NP_Pos         TIM_CCER_CC1NP_DPos
#define TIM_CCER_CC1NP_Msk         (0x1UL << TIM_CCER_CC1NP_Pos)                /* 0x00000008 */
#define TIM_CCER_CC1NP             TIM_CCER_CC1NP_Msk                           /* Capture/Compare 1 complementary output polarity */

#define TIM_CCER_CC2E_DPos         (4U)
#define TIM_CCER_CC2E_Pos          TIM_CCER_CC2E_DPos
#define TIM_CCER_CC2E_Msk          (0x1UL << TIM_CCER_CC2E_Pos)                 /* 0x00000010 */
#define TIM_CCER_CC2E              TIM_CCER_CC2E_Msk                            /* Capture/Compare 2 output enable */

#define TIM_CCER_CC2P_DPos         (5U)
#define TIM_CCER_CC2P_Pos          TIM_CCER_CC2P_DPos
#define TIM_CCER_CC2P_Msk          (0x1UL << TIM_CCER_CC2P_Pos)                 /* 0x00000020 */
#define TIM_CCER_CC2P              TIM_CCER_CC2P_Msk                            /* Capture/Compare 2 output polarity */

#define TIM_CCER_CC2NE_DPos        (6U)
#define TIM_CCER_CC2NE_Pos         TIM_CCER_CC2NE_DPos
#define TIM_CCER_CC2NE_Msk         (0x1UL << TIM_CCER_CC2NE_Pos)                /* 0x00000040 */
#define TIM_CCER_CC2NE             TIM_CCER_CC2NE_Msk

#define TIM_CCER_CC2NP_DPos        (7U)
#define TIM_CCER_CC2NP_Pos         TIM_CCER_CC2NP_DPos
#define TIM_CCER_CC2NP_Msk         (0x1UL << TIM_CCER_CC2NP_Pos)                /* 0x00000080 */
#define TIM_CCER_CC2NP             TIM_CCER_CC2NP_Msk                           /* Capture/Compare 2 complementary output polarity */

#define TIM_CCER_CC3E_DPos         (8U)
#define TIM_CCER_CC3E_Pos          TIM_CCER_CC3E_DPos
#define TIM_CCER_CC3E_Msk          (0x1UL << TIM_CCER_CC3E_Pos)                 /* 0x00000100 */
#define TIM_CCER_CC3E              TIM_CCER_CC3E_Msk                            /* Capture/Compare 3 output enable */

#define TIM_CCER_CC3P_DPos         (9U)
#define TIM_CCER_CC3P_Pos          TIM_CCER_CC3P_DPos
#define TIM_CCER_CC3P_Msk          (0x1UL << TIM_CCER_CC3P_Pos)                 /* 0x00000200 */
#define TIM_CCER_CC3P              TIM_CCER_CC3P_Msk                            /* Capture/Compare 3 output polarity */

#define TIM_CCER_CC3NE_DPos        (10U)
#define TIM_CCER_CC3NE_Pos         TIM_CCER_CC3NE_DPos
#define TIM_CCER_CC3NE_Msk         (0x1UL << TIM_CCER_CC3NE_Pos)                /* 0x00000400 */
#define TIM_CCER_CC3NE             TIM_CCER_CC3NE_Msk                           /* Capture/Compare 3 complementary output enable */

#define TIM_CCER_CC3NP_DPos        (11U)
#define TIM_CCER_CC3NP_Pos         TIM_CCER_CC3NP_DPos
#define TIM_CCER_CC3NP_Msk         (0x1UL << TIM_CCER_CC3NP_Pos)                /* 0x00000800 */
#define TIM_CCER_CC3NP             TIM_CCER_CC3NP_Msk                           /* Capture/Compare 3 complementary output polarity */

#define TIM_CCER_CC4E_DPos         (12U)
#define TIM_CCER_CC4E_Pos          TIM_CCER_CC4E_DPos
#define TIM_CCER_CC4E_Msk          (0x1UL << TIM_CCER_CC4E_Pos)                 /* 0x00001000 */
#define TIM_CCER_CC4E              TIM_CCER_CC4E_Msk                            /* Capture/Compare 4 output enable */

#define TIM_CCER_CC4P_DPos         (13U)
#define TIM_CCER_CC4P_Pos          TIM_CCER_CC4P_DPos
#define TIM_CCER_CC4P_Msk          (0x1UL << TIM_CCER_CC4P_Pos)                 /* 0x00002000 */
#define TIM_CCER_CC4P              TIM_CCER_CC4P_Msk

#define TIM_CCER_CC4NE_DPos        (14U)
#define TIM_CCER_CC4NE_Pos         TIM_CCER_CC4NE_DPos
#define TIM_CCER_CC4NE_Msk         (0x1UL << TIM_CCER_CC4NE_Pos)                /* 0x00004000 */
#define TIM_CCER_CC4NE             TIM_CCER_CC4NE_Msk                           /* Capture/Compare 4 complementary output enable */

#define TIM_CCER_CC4NP_DPos        (15U)
#define TIM_CCER_CC4NP_Pos         TIM_CCER_CC4NP_DPos
#define TIM_CCER_CC4NP_Msk         (0x1UL << TIM_CCER_CC4NP_Pos)                /* 0x00008000 */
#define TIM_CCER_CC4NP             TIM_CCER_CC4NP_Msk                           /* Capture/Compare 4 complementary output polarity */

#define TIM_CCER_CC5E_DPos         (16U)
#define TIM_CCER_CC5E_Pos          TIM_CCER_CC5E_DPos
#define TIM_CCER_CC5E_Msk          (0x1UL << TIM_CCER_CC5E_Pos)                 /* 0x00010000 */
#define TIM_CCER_CC5E              TIM_CCER_CC5E_Msk                            /* Capture/Compare 5 output enable */

#define TIM_CCER_CC5P_DPos         (17U)
#define TIM_CCER_CC5P_Pos          TIM_CCER_CC5P_DPos
#define TIM_CCER_CC5P_Msk          (0x1UL << TIM_CCER_CC5P_Pos)                 /* 0x00020000 */
#define TIM_CCER_CC5P              TIM_CCER_CC5P_Msk                            /* Capture/Compare 5 output polarity */

#define TIM_CCER_CC5NE_DPos        (18U)
#define TIM_CCER_CC5NE_Pos         TIM_CCER_CC5NE_DPos
#define TIM_CCER_CC5NE_Msk         (0x1UL << TIM_CCER_CC5NE_Pos)                /* 0x00040000 */
#define TIM_CCER_CC5NE             TIM_CCER_CC5NE_Msk                           /* Capture/Compare 5 complementary output enable */

#define TIM_CCER_CC5NP_DPos        (19U)
#define TIM_CCER_CC5NP_Pos         TIM_CCER_CC5NP_DPos
#define TIM_CCER_CC5NP_Msk         (0x1UL << TIM_CCER_CC5NP_Pos)                /* 0x00080000 */
#define TIM_CCER_CC5NP             TIM_CCER_CC5NP_Msk                           /* Capture/Compare 5 complementary output polarity */

#define TIM_CCER_CC6E_DPos         (20U)
#define TIM_CCER_CC6E_Pos          TIM_CCER_CC6E_DPos
#define TIM_CCER_CC6E_Msk          (0x1UL << TIM_CCER_CC6E_Pos)                 /* 0x00100000 */
#define TIM_CCER_CC6E              TIM_CCER_CC6E_Msk

#define TIM_CCER_CC6P_DPos         (21U)
#define TIM_CCER_CC6P_Pos          TIM_CCER_CC6P_DPos
#define TIM_CCER_CC6P_Msk          (0x1UL << TIM_CCER_CC6P_Pos)                 /* 0x00200000 */
#define TIM_CCER_CC6P              TIM_CCER_CC6P_Msk                            /* Capture/Compare 6 output polarity */

#define TIM_CCER_CC6NE_DPos        (22U)
#define TIM_CCER_CC6NE_Pos         TIM_CCER_CC6NE_DPos
#define TIM_CCER_CC6NE_Msk         (0x1UL << TIM_CCER_CC6NE_Pos)                /* 0x00400000 */
#define TIM_CCER_CC6NE             TIM_CCER_CC6NE_Msk                           /* Capture/Compare 6 complementary output enable */

#define TIM_CCER_CC6NP_DPos        (23U)
#define TIM_CCER_CC6NP_Pos         TIM_CCER_CC6NP_DPos
#define TIM_CCER_CC6NP_Msk         (0x1UL << TIM_CCER_CC6NP_Pos)                /* 0x00800000 */
#define TIM_CCER_CC6NP             TIM_CCER_CC6NP_Msk                           /* Capture/Compare 6 complementary output polarity */


/*******************  Bit definition for TIM_CNT register  ********************/
#define TIM_CNT_CNT_DPos          (0U)
#define TIM_CNT_CNT_Pos           TIM_CNT_CNT_DPos
#define TIM_CNT_CNT_Msk           (0xFFFFFFFFUL << TIM_CNT_CNT_Pos)            /* 0xFFFFFFFF */
#define TIM_CNT_CNT               TIM_CNT_CNT_Msk                              /* Counter value */

/*******************  Bit definition for TIM_PSC register  ********************/
#define TIM_PSC_PSC_DPos          (0U)
#define TIM_PSC_PSC_Pos           TIM_PSC_PSC_DPos
#define TIM_PSC_PSC_Msk           (0xFFFFFFFFUL << TIM_PSC_PSC_Pos)            /* 0xFFFFFFFF */
#define TIM_PSC_PSC               TIM_PSC_PSC_Msk                              /* Prescaler value */

/*******************  Bit definition for TIM_ARR register  ********************/
#define TIM_ARR_ARR_DPos          (0U)
#define TIM_ARR_ARR_Pos           TIM_ARR_ARR_DPos
#define TIM_ARR_ARR_Msk           (0xFFFFFFFFUL << TIM_ARR_ARR_Pos)            /* 0xFFFFFFFF */
#define TIM_ARR_ARR               TIM_ARR_ARR_Msk                              /* Auto-reload value */


/*******************  Bit definition for TIM_RCR register  ********************/
#define TIM_RCR_REP_DPos         (0U)
#define TIM_RCR_REP_Pos          TIM_RCR_REP_DPos
#define TIM_RCR_REP_Msk          (0xFFFFUL << TIM_RCR_REP_Pos)                /* 0x0000FFFF */
#define TIM_RCR_REP              TIM_RCR_REP_Msk                              /* Repetition counter value */

/*******************  Bit definition for TIM_CCR1 register  *******************/
#define TIM_CCR1_CCR1_DPos        (0U)
#define TIM_CCR1_CCR1_Pos         TIM_CCR1_CCR1_DPos
#define TIM_CCR1_CCR1_Msk         (0xFFFFFFFFUL << TIM_CCR1_CCR1_Pos)          /* 0xFFFFFFFF */
#define TIM_CCR1_CCR1             TIM_CCR1_CCR1_Msk                            /* Capture/Compare 1 value */

/*******************  Bit definition for TIM_CCR2 register  *******************/
#define TIM_CCR2_CCR2_DPos        (0U)
#define TIM_CCR2_CCR2_Pos         TIM_CCR2_CCR2_DPos
#define TIM_CCR2_CCR2_Msk         (0xFFFFFFFFUL << TIM_CCR2_CCR2_Pos)          /* 0xFFFFFFFF */
#define TIM_CCR2_CCR2             TIM_CCR2_CCR2_Msk                            /* Capture/Compare 2 value */

/*******************  Bit definition for TIM_CCR3 register  *******************/
#define TIM_CCR3_CCR3_DPos        (0U)
#define TIM_CCR3_CCR3_Pos         TIM_CCR3_CCR3_DPos
#define TIM_CCR3_CCR3_Msk         (0xFFFFFFFFUL << TIM_CCR3_CCR3_Pos)          /* 0xFFFFFFFF */
#define TIM_CCR3_CCR3             TIM_CCR3_CCR3_Msk                            /* Capture/Compare 3 value */

/*******************  Bit definition for TIM_CCR4 register  *******************/
#define TIM_CCR4_CCR4_DPos        (0U)
#define TIM_CCR4_CCR4_Pos         TIM_CCR4_CCR4_DPos
#define TIM_CCR4_CCR4_Msk         (0xFFFFFFFFUL << TIM_CCR4_CCR4_Pos)          /* 0xFFFFFFFF */
#define TIM_CCR4_CCR4             TIM_CCR4_CCR4_Msk                            /* Capture/Compare 4 value */

/*******************  Bit definition for TIM_CCR5 register  *******************/
#define TIM_CCR5_CCR5_DPos        (0U)
#define TIM_CCR5_CCR5_Pos         TIM_CCR5_CCR5_DPos
#define TIM_CCR5_CCR5_Msk         (0xFFFFFFFFUL << TIM_CCR5_CCR5_Pos)          /* 0xFFFFFFFF */
#define TIM_CCR5_CCR5             TIM_CCR5_CCR5_Msk                            /* Capture/Compare 5 value */

/*******************  Bit definition for TIM_CCR6 register  *******************/
#define TIM_CCR6_CCR6_DPos        (0U)
#define TIM_CCR6_CCR6_Pos         TIM_CCR6_CCR6_DPos
#define TIM_CCR6_CCR6_Msk         (0xFFFFFFFFUL << TIM_CCR6_CCR6_Pos)          /* 0xFFFFFFFF */
#define TIM_CCR6_CCR6             TIM_CCR6_CCR6_Msk                            /* Capture/Compare 6 value */

/*******************  Bit definition for TIM_BDTR register  *******************/

#define TIM_BDTR_DTG_DPos         (0U)
#define TIM_BDTR_DTG_Pos          TIM_BDTR_DTG_DPos
#define TIM_BDTR_DTG_Msk          (0xFFUL << TIM_BDTR_DTG_Pos)                 /* 0x000000FF */
#define TIM_BDTR_DTG              TIM_BDTR_DTG_Msk                             /* DTG[0:7] bits (Dead-time generator setup) */
#define TIM_BDTR_DTG_0            (0x01UL << TIM_BDTR_DTG_Pos)                 /* 0x00000001 */
#define TIM_BDTR_DTG_1            (0x02UL << TIM_BDTR_DTG_Pos)                 /* 0x00000002 */
#define TIM_BDTR_DTG_2            (0x04UL << TIM_BDTR_DTG_Pos)                 /* 0x00000004 */
#define TIM_BDTR_DTG_3            (0x08UL << TIM_BDTR_DTG_Pos)                 /* 0x00000008 */
#define TIM_BDTR_DTG_4            (0x10UL << TIM_BDTR_DTG_Pos)                 /* 0x00000010 */
#define TIM_BDTR_DTG_5            (0x20UL << TIM_BDTR_DTG_Pos)                 /* 0x00000020 */
#define TIM_BDTR_DTG_6            (0x40UL << TIM_BDTR_DTG_Pos)                 /* 0x00000040 */
#define TIM_BDTR_DTG_7            (0x80UL << TIM_BDTR_DTG_Pos)                 /* 0x00000080 */

#define TIM_BDTR_OSSI_DPos        (10U)
#define TIM_BDTR_OSSI_Pos         TIM_BDTR_OSSI_DPos
#define TIM_BDTR_OSSI_Msk         (0x1UL << TIM_BDTR_OSSI_Pos)                 /* 0x00000400 */
#define TIM_BDTR_OSSI             TIM_BDTR_OSSI_Msk                            /* Off-state selection for Idle mode */

#define TIM_BDTR_OSSR_DPos        (11U)
#define TIM_BDTR_OSSR_Pos         TIM_BDTR_OSSR_DPos
#define TIM_BDTR_OSSR_Msk         (0x1UL << TIM_BDTR_OSSR_Pos)                 /* 0x00000800 */
#define TIM_BDTR_OSSR             TIM_BDTR_OSSR_Msk                            /* Off-state selection for Run mode */

#define TIM_BDTR_BKE_DPos         (12U)
#define TIM_BDTR_BKE_Pos          TIM_BDTR_BKE_DPos
#define TIM_BDTR_BKE_Msk          (0x1UL << TIM_BDTR_BKE_Pos)                  /* 0x00001000 */
#define TIM_BDTR_BKE              TIM_BDTR_BKE_Msk                             /* Break enable */

#define TIM_BDTR_BKP_DPos         (13U)
#define TIM_BDTR_BKP_Pos          TIM_BDTR_BKP_DPos
#define TIM_BDTR_BKP_Msk          (0x1UL << TIM_BDTR_BKP_Pos)                  /* 0x00002000 */
#define TIM_BDTR_BKP              TIM_BDTR_BKP_Msk

#define TIM_BDTR_AOE_DPos         (14U)
#define TIM_BDTR_AOE_Pos          TIM_BDTR_AOE_DPos
#define TIM_BDTR_AOE_Msk          (0x1UL << TIM_BDTR_AOE_Pos)                  /* 0x00004000 */
#define TIM_BDTR_AOE              TIM_BDTR_AOE_Msk                             /* Automatic output enable */

#define TIM_BDTR_MOE_DPos         (15U)
#define TIM_BDTR_MOE_Pos          TIM_BDTR_MOE_DPos
#define TIM_BDTR_MOE_Msk          (0x1UL << TIM_BDTR_MOE_Pos)                  /* 0x00008000 */
#define TIM_BDTR_MOE              TIM_BDTR_MOE_Msk                             /* Main output enable */

#define TIM_BDTR_BKF_DPos         (16U)
#define TIM_BDTR_BKF_Pos          TIM_BDTR_BKF_DPos
#define TIM_BDTR_BKF_Msk          (0xFUL << TIM_BDTR_BKF_Pos)                  /* 0x000F0000 */
#define TIM_BDTR_BKF              TIM_BDTR_BKF_Msk                             /* Break filter */
#define TIM_BDTR_BKF_0            (0x01UL << TIM_BDTR_BKF_Pos)                 /* 0x00010000 */
#define TIM_BDTR_BKF_1            (0x02UL << TIM_BDTR_BKF_Pos)                 /* 0x00020000 */
#define TIM_BDTR_BKF_2            (0x04UL << TIM_BDTR_BKF_Pos)                 /* 0x00040000 */
#define TIM_BDTR_BKF_3            (0x08UL << TIM_BDTR_BKF_Pos)                 /* 0x00080000 */


/*******************  Bit definition for TIM_DCR register  ********************/
#define TIM_DCR_DBA_DPos          (0U)
#define TIM_DCR_DBA_Pos           TIM_DCR_DBA_DPos
#define TIM_DCR_DBA_Msk           (0x1FUL << TIM_DCR_DBA_Pos)                  /* 0x0000001F */
#define TIM_DCR_DBA               TIM_DCR_DBA_Msk                              /*DBA[4:0] bits (DMA base address) */
#define TIM_DCR_DBA_0             (0x01UL << TIM_DCR_DBA_Pos)                  /* 0x00000001 */
#define TIM_DCR_DBA_1             (0x02UL << TIM_DCR_DBA_Pos)                  /* 0x00000002 */
#define TIM_DCR_DBA_2             (0x04UL << TIM_DCR_DBA_Pos)                  /* 0x00000004 */
#define TIM_DCR_DBA_3             (0x08UL << TIM_DCR_DBA_Pos)                  /* 0x00000008 */
#define TIM_DCR_DBA_4             (0x10UL << TIM_DCR_DBA_Pos)                  /* 0x00000010 */

#define TIM_DCR_DBL_DPos          (8U)
#define TIM_DCR_DBL_Pos           TIM_DCR_DBL_DPos
#define TIM_DCR_DBL_Msk           (0x1FUL << TIM_DCR_DBL_Pos)                  /* 0x00001F00 */
#define TIM_DCR_DBL               TIM_DCR_DBL_Msk                              /*DBL[4:0] bits (DMA burst length) */
#define TIM_DCR_DBL_0             (0x01UL << TIM_DCR_DBL_Pos)                  /* 0x00000100 */
#define TIM_DCR_DBL_1             (0x02UL << TIM_DCR_DBL_Pos)                  /* 0x00000200 */
#define TIM_DCR_DBL_2             (0x04UL << TIM_DCR_DBL_Pos)                  /* 0x00000400 */
#define TIM_DCR_DBL_3             (0x08UL << TIM_DCR_DBL_Pos)                  /* 0x00000800 */
#define TIM_DCR_DBL_4             (0x10UL << TIM_DCR_DBL_Pos)                  /* 0x00001000 */

/*******************  Bit definition for TIM_DMAR register  *******************/
#define TIM_DMAR_DMAB_DPos        (0U)
#define TIM_DMAR_DMAB_Pos         TIM_DMAR_DMAB_DPos
#define TIM_DMAR_DMAB_Msk         (0xFFFFFFFFUL << TIM_DMAR_DMAB_Pos)          /* 0xFFFFFFFF */
#define TIM_DMAR_DMAB             TIM_DMAR_DMAB_Msk                            /* DMA register for burst accesses */

/*******************  Bit definition for TIM_AF1 register  ********************/
#define TIM_AF1_ETRSEL_DPos       (0U)
#define TIM_AF1_ETRSEL_Pos        TIM_AF1_ETRSEL_DPos
#define TIM_AF1_ETRSEL_Msk        (0xFUL << TIM_AF1_ETRSEL_Pos)                /* 0x0000000F */
#define TIM_AF1_ETRSEL            TIM_AF1_ETRSEL_Msk                           /*ETRSEL[3:0] bits (ETR source selection) */
#define TIM_AF1_ETRSEL_0          (0x1UL << TIM_AF1_ETRSEL_Pos)                /* 0x00000001 */
#define TIM_AF1_ETRSEL_1          (0x2UL << TIM_AF1_ETRSEL_Pos)                /* 0x00000002 */
#define TIM_AF1_ETRSEL_2          (0x4UL << TIM_AF1_ETRSEL_Pos)                /* 0x00000004 */
#define TIM_AF1_ETRSEL_3          (0x8UL << TIM_AF1_ETRSEL_Pos)                /* 0x00000008 */

/* @name CANFD register bits definition */
/******************  Bit definition for CANFD_SRR register  *******************/
#define CANFD_SRR_SRST_DPos       (0U)
#define CANFD_SRR_SRST_Pos        CANFD_SRR_SRST_DPos
#define CANFD_SRR_SRST_Msk        (0x1UL << CANFD_SRR_SRST_Pos)                /* 0x00000001 */
#define CANFD_SRR_SRST            CANFD_SRR_SRST_Msk                           /* Reset. */

#define CANFD_SRR_CEN_DPos        (1U)
#define CANFD_SRR_CEN_Pos         CANFD_SRR_CEN_DPos
#define CANFD_SRR_CEN_Msk         (0x1UL << CANFD_SRR_CEN_Pos)                 /* 0x00000002 */
#define CANFD_SRR_CEN             CANFD_SRR_CEN_Msk                            /* CAN Enable. */

/******************  Bit definition for CANFD_MSR register  *******************/
#define CANFD_MSR_SLEEP_DPos      (0U)
#define CANFD_MSR_SLEEP_Pos       CANFD_MSR_SLEEP_DPos
#define CANFD_MSR_SLEEP_Msk       (0x1UL << CANFD_MSR_SLEEP_Pos)               /* 0x00000001 */
#define CANFD_MSR_SLEEP           CANFD_MSR_SLEEP_Msk                          /* Sleep Mode Select/Request. */

#define CANFD_MSR_LBACK_DPos      (1U)
#define CANFD_MSR_LBACK_Pos       CANFD_MSR_LBACK_DPos
#define CANFD_MSR_LBACK_Msk       (0x1UL << CANFD_MSR_LBACK_Pos)               /* 0x00000002 */
#define CANFD_MSR_LBACK           CANFD_MSR_LBACK_Msk                          /* Loopback Mode Select/Request. */

#define CANFD_MSR_SNOOP_DPos      (2U)
#define CANFD_MSR_SNOOP_Pos       CANFD_MSR_SNOOP_DPos
#define CANFD_MSR_SNOOP_Msk       (0x1UL << CANFD_MSR_SNOOP_Pos)               /* 0x00000004 */
#define CANFD_MSR_SNOOP           CANFD_MSR_SNOOP_Msk                          /* SNOOP Mode Select/Request. */

#define CANFD_MSR_BRSD_DPos       (3U)
#define CANFD_MSR_BRSD_Pos        CANFD_MSR_BRSD_DPos
#define CANFD_MSR_BRSD_Msk        (0x1UL << CANFD_MSR_BRSD_Pos)                /* 0x00000008 */
#define CANFD_MSR_BRSD            CANFD_MSR_BRSD_Msk                           /* CAN FD Bit Rate Switch Disable Override. */

#define CANFD_MSR_DAR_DPos        (4U)
#define CANFD_MSR_DAR_Pos         CANFD_MSR_DAR_DPos
#define CANFD_MSR_DAR_Msk         (0x1UL << CANFD_MSR_DAR_Pos)                 /* 0x00000010 */
#define CANFD_MSR_DAR             CANFD_MSR_DAR_Msk                            /* Disable Auto-Retransmission. */

#define CANFD_MSR_DPEE_DPos       (5U)
#define CANFD_MSR_DPEE_Pos        CANFD_MSR_DPEE_DPos
#define CANFD_MSR_DPEE_Msk        (0x1UL << CANFD_MSR_DPEE_Pos)                /* 0x00000020 */
#define CANFD_MSR_DPEE            CANFD_MSR_DPEE_Msk                           /* Disable Protocol Exception Event Detection/Generation. */

#define CANFD_MSR_SBR_DPos        (6U)
#define CANFD_MSR_SBR_Pos         CANFD_MSR_SBR_DPos
#define CANFD_MSR_SBR_Msk         (0x1UL << CANFD_MSR_SBR_Pos)                 /* 0x00000040 */
#define CANFD_MSR_SBR             CANFD_MSR_SBR_Msk                            /* Start Bus-Off Recovery Request. */

#define CANFD_MSR_ABR_DPos        (7U)
#define CANFD_MSR_ABR_Pos         CANFD_MSR_ABR_DPos
#define CANFD_MSR_ABR_Msk         (0x1UL << CANFD_MSR_ABR_Pos)                 /* 0x00000080 */
#define CANFD_MSR_ABR             CANFD_MSR_ABR_Msk                            /* Auto Bus-Off Recovery Request. */

/****************  Bit definition for CANFD_APBRPR register  ******************/
#define CANFD_APBRPR_BRP_DPos     (0U)
#define CANFD_APBRPR_BRP_Pos      CANFD_APBRPR_BRP_DPos
#define CANFD_APBRPR_BRP_Msk      (0xFFUL << CANFD_APBRPR_BRP_Pos)             /* 0x000000FF */
#define CANFD_APBRPR_BRP          CANFD_APBRPR_BRP_Msk                         /* BRP[7:0] bits (Arbitration Phase (Nominal) Baud Rate Prescaler.) */
#define CANFD_APBRPR_BRP_0        (0x1UL << CANFD_APBRPR_BRP_Pos)              /* 0x00000001 */
#define CANFD_APBRPR_BRP_1        (0x2UL << CANFD_APBRPR_BRP_Pos)              /* 0x00000002 */
#define CANFD_APBRPR_BRP_2        (0x4UL << CANFD_APBRPR_BRP_Pos)              /* 0x00000004 */
#define CANFD_APBRPR_BRP_3        (0x8UL << CANFD_APBRPR_BRP_Pos)              /* 0x00000008 */
#define CANFD_APBRPR_BRP_4        (0x10UL << CANFD_APBRPR_BRP_Pos)             /* 0x00000010 */
#define CANFD_APBRPR_BRP_5        (0x20UL << CANFD_APBRPR_BRP_Pos)             /* 0x00000020 */
#define CANFD_APBRPR_BRP_6        (0x40UL << CANFD_APBRPR_BRP_Pos)             /* 0x00000040 */
#define CANFD_APBRPR_BRP_7        (0x80UL << CANFD_APBRPR_BRP_Pos)             /* 0x00000080 */

/****************  Bit definition for CANFD_APBTR register  *******************/
#define CANFD_APBTR_TS1_DPos      (0U)
#define CANFD_APBTR_TS1_Pos       CANFD_APBTR_TS1_DPos
#define CANFD_APBTR_TS1_Msk       (0xFFUL << CANFD_APBTR_TS1_Pos)              /* 0x000000FF */
#define CANFD_APBTR_TS1           CANFD_APBTR_TS1_Msk                          /* TS1[7:0] bits (Time Segment 1) */
#define CANFD_APBTR_TS1_0         (0x1UL << CANFD_APBTR_TS1_Pos)               /* 0x00000001 */
#define CANFD_APBTR_TS1_1         (0x2UL << CANFD_APBTR_TS1_Pos)               /* 0x00000002 */
#define CANFD_APBTR_TS1_2         (0x4UL << CANFD_APBTR_TS1_Pos)               /* 0x00000004 */
#define CANFD_APBTR_TS1_3         (0x8UL << CANFD_APBTR_TS1_Pos)               /* 0x00000008 */
#define CANFD_APBTR_TS1_4         (0x10UL << CANFD_APBTR_TS1_Pos)              /* 0x00000010 */
#define CANFD_APBTR_TS1_5         (0x20UL << CANFD_APBTR_TS1_Pos)              /* 0x00000020 */
#define CANFD_APBTR_TS1_6         (0x40UL << CANFD_APBTR_TS1_Pos)              /* 0x00000040 */
#define CANFD_APBTR_TS1_7         (0x80UL << CANFD_APBTR_TS1_Pos)              /* 0x00000080 */

#define CANFD_APBTR_TS2_DPos      (8U)
#define CANFD_APBTR_TS2_Pos       CANFD_APBTR_TS2_DPos
#define CANFD_APBTR_TS2_Msk       (0x7FUL << CANFD_APBTR_TS2_Pos)              /* 0x00007F00 */
#define CANFD_APBTR_TS2           CANFD_APBTR_TS2_Msk                          /* TS2[6:0] bits (Time Segment 2) */
#define CANFD_APBTR_TS2_0         (0x1UL << CANFD_APBTR_TS2_Pos)               /* 0x00000100 */
#define CANFD_APBTR_TS2_1         (0x2UL << CANFD_APBTR_TS2_Pos)               /* 0x00000200 */
#define CANFD_APBTR_TS2_2         (0x4UL << CANFD_APBTR_TS2_Pos)               /* 0x00000400 */
#define CANFD_APBTR_TS2_3         (0x8UL << CANFD_APBTR_TS2_Pos)               /* 0x00000800 */
#define CANFD_APBTR_TS2_4         (0x10UL << CANFD_APBTR_TS2_Pos)              /* 0x00001000 */
#define CANFD_APBTR_TS2_5         (0x20UL << CANFD_APBTR_TS2_Pos)              /* 0x00002000 */
#define CANFD_APBTR_TS2_6         (0x40UL << CANFD_APBTR_TS2_Pos)              /* 0x00004000 */

#define CANFD_APBTR_SJW_DPos      (16U)
#define CANFD_APBTR_SJW_Pos       CANFD_APBTR_SJW_DPos
#define CANFD_APBTR_SJW_Msk       (0x7FUL << CANFD_APBTR_SJW_Pos)              /* 0x007F0000 */
#define CANFD_APBTR_SJW           CANFD_APBTR_SJW_Msk                          /* SJW[6:0] bits (Synchronization Jump Width) */
#define CANFD_APBTR_SJW_0         (0x1UL << CANFD_APBTR_SJW_Pos)               /* 0x00010000 */
#define CANFD_APBTR_SJW_1         (0x2UL << CANFD_APBTR_SJW_Pos)               /* 0x00020000 */
#define CANFD_APBTR_SJW_2         (0x4UL << CANFD_APBTR_SJW_Pos)               /* 0x00040000 */
#define CANFD_APBTR_SJW_3         (0x8UL << CANFD_APBTR_SJW_Pos)               /* 0x00080000 */
#define CANFD_APBTR_SJW_4         (0x10UL << CANFD_APBTR_SJW_Pos)              /* 0x00100000 */
#define CANFD_APBTR_SJW_5         (0x20UL << CANFD_APBTR_SJW_Pos)              /* 0x00200000 */
#define CANFD_APBTR_SJW_6         (0x40UL << CANFD_APBTR_SJW_Pos)              /* 0x00400000 */

/*****************  Bit definition for CANFD_ECR register  ********************/
#define CANFD_ECR_TEC_DPos        (0U)
#define CANFD_ECR_TEC_Pos         CANFD_ECR_TEC_DPos
#define CANFD_ECR_TEC_Msk         (0xFFUL << CANFD_ECR_TEC_Pos)                /* 0x000000FF */
#define CANFD_ECR_TEC             CANFD_ECR_TEC_Msk                            /* TEC[7:0] bits (Transmit Error Count) */
#define CANFD_ECR_TEC_0           (0x1UL << CANFD_ECR_TEC_Pos)                 /* 0x00000001 */
#define CANFD_ECR_TEC_1           (0x2UL << CANFD_ECR_TEC_Pos)                 /* 0x00000002 */
#define CANFD_ECR_TEC_2           (0x4UL << CANFD_ECR_TEC_Pos)                 /* 0x00000004 */
#define CANFD_ECR_TEC_3           (0x8UL << CANFD_ECR_TEC_Pos)                 /* 0x00000008 */
#define CANFD_ECR_TEC_4           (0x10UL << CANFD_ECR_TEC_Pos)                /* 0x00000010 */
#define CANFD_ECR_TEC_5           (0x20UL << CANFD_ECR_TEC_Pos)                /* 0x00000020 */
#define CANFD_ECR_TEC_6           (0x40UL << CANFD_ECR_TEC_Pos)                /* 0x00000040 */
#define CANFD_ECR_TEC_7           (0x80UL << CANFD_ECR_TEC_Pos)                /* 0x00000080 */

#define CANFD_ECR_REC_DPos        (8U)
#define CANFD_ECR_REC_Pos         CANFD_ECR_REC_DPos
#define CANFD_ECR_REC_Msk         (0xFFUL << CANFD_ECR_REC_Pos)                /* 0x0000FF00 */
#define CANFD_ECR_REC             CANFD_ECR_REC_Msk                            /* REC[7:0] bits (Receive Error Count) */
#define CANFD_ECR_REC_0           (0x1UL << CANFD_ECR_REC_Pos)                 /* 0x00000100 */
#define CANFD_ECR_REC_1           (0x2UL << CANFD_ECR_REC_Pos)                 /* 0x00000200 */
#define CANFD_ECR_REC_2           (0x4UL << CANFD_ECR_REC_Pos)                 /* 0x00000400 */
#define CANFD_ECR_REC_3           (0x8UL << CANFD_ECR_REC_Pos)                 /* 0x00000800 */
#define CANFD_ECR_REC_4           (0x10UL << CANFD_ECR_REC_Pos)                /* 0x00001000 */
#define CANFD_ECR_REC_5           (0x20UL << CANFD_ECR_REC_Pos)                /* 0x00002000 */
#define CANFD_ECR_REC_6           (0x40UL << CANFD_ECR_REC_Pos)                /* 0x00004000 */
#define CANFD_ECR_REC_7           (0x80UL << CANFD_ECR_REC_Pos)                /* 0x00008000 */

/******************  Bit definition for CANFD_ESR register  *******************/
#define CANFD_ESR_CRCER_DPos      (0U)
#define CANFD_ESR_CRCER_Pos       CANFD_ESR_CRCER_DPos
#define CANFD_ESR_CRCER_Msk       (0x1UL << CANFD_ESR_CRCER_Pos)               /* 0x00000001 */
#define CANFD_ESR_CRCER           CANFD_ESR_CRCER_Msk                          /* CRC Error. */

#define CANFD_ESR_FMER_DPos       (1U)
#define CANFD_ESR_FMER_Pos        CANFD_ESR_FMER_DPos
#define CANFD_ESR_FMER_Msk        (0x1UL << CANFD_ESR_FMER_Pos)                /* 0x00000002 */
#define CANFD_ESR_FMER            CANFD_ESR_FMER_Msk                           /* Form Error. */

#define CANFD_ESR_STER_DPos       (2U)
#define CANFD_ESR_STER_Pos        CANFD_ESR_STER_DPos
#define CANFD_ESR_STER_Msk        (0x1UL << CANFD_ESR_STER_Pos)                /* 0x00000004 */
#define CANFD_ESR_STER            CANFD_ESR_STER_Msk                           /* Stuff Error */

#define CANFD_ESR_BERR_DPos       (3U)
#define CANFD_ESR_BERR_Pos        CANFD_ESR_BERR_DPos
#define CANFD_ESR_BERR_Msk        (0x1UL << CANFD_ESR_BERR_Pos)                /* 0x00000008 */
#define CANFD_ESR_BERR            CANFD_ESR_BERR_Msk                           /* Bit Error. */

#define CANFD_ESR_ACKER_DPos      (4U)
#define CANFD_ESR_ACKER_Pos       CANFD_ESR_ACKER_DPos
#define CANFD_ESR_ACKER_Msk       (0x1UL << CANFD_ESR_ACKER_Pos)               /* 0x00000010 */
#define CANFD_ESR_ACKER           CANFD_ESR_ACKER_Msk                          /* ACK Error. */

#define CANFD_ESR_F_CRCER_DPos    (8U)
#define CANFD_ESR_F_CRCER_Pos     CANFD_ESR_F_CRCER_DPos
#define CANFD_ESR_F_CRCER_Msk     (0x1UL << CANFD_ESR_F_CRCER_Pos)             /* 0x00000100 */
#define CANFD_ESR_F_CRCER         CANFD_ESR_F_CRCER_Msk                        /* CRC Error in CAN FD Data Phase. */

#define CANFD_ESR_F_FMER_DPos     (9U)
#define CANFD_ESR_F_FMER_Pos      CANFD_ESR_F_FMER_DPos
#define CANFD_ESR_F_FMER_Msk      (0x1UL << CANFD_ESR_F_FMER_Pos)              /* 0x00000200 */
#define CANFD_ESR_F_FMER          CANFD_ESR_F_FMER_Msk                         /* Form Error in CAN FD Data Phase. */

#define CANFD_ESR_F_STER_DPos     (10U)
#define CANFD_ESR_F_STER_Pos      CANFD_ESR_F_STER_DPos
#define CANFD_ESR_F_STER_Msk      (0x1UL << CANFD_ESR_F_STER_Pos)              /* 0x00000400 */
#define CANFD_ESR_F_STER          CANFD_ESR_F_STER_Msk                         /* Stuff Error in CAN FD Data Phase. */

#define CANFD_ESR_F_BERR_DPos     (11U)
#define CANFD_ESR_F_BERR_Pos      CANFD_ESR_F_BERR_DPos
#define CANFD_ESR_F_BERR_Msk      (0x1UL << CANFD_ESR_F_BERR_Pos)              /* 0x00000800 */
#define CANFD_ESR_F_BERR          CANFD_ESR_F_BERR_Msk                         /* Bit Error in CAN FD Data Phase. */

/*******************  Bit definition for CANFD_SR register  *******************/
#define CANFD_SR_CONFIG_DPos      (0U)
#define CANFD_SR_CONFIG_Pos       CANFD_SR_CONFIG_DPos
#define CANFD_SR_CONFIG_Msk       (0x1UL << CANFD_SR_CONFIG_Pos)               /* 0x00000001 */
#define CANFD_SR_CONFIG           CANFD_SR_CONFIG_Msk                          /* Configuration Mode Indicator. */

#define CANFD_SR_LBACK_DPos       (1U)
#define CANFD_SR_LBACK_Pos        CANFD_SR_LBACK_DPos
#define CANFD_SR_LBACK_Msk        (0x1UL << CANFD_SR_LBACK_Pos)                /* 0x00000002 */
#define CANFD_SR_LBACK            CANFD_SR_LBACK_Msk                           /* Loopback Mode. */

#define CANFD_SR_SLEEP_DPos       (2U)
#define CANFD_SR_SLEEP_Pos        CANFD_SR_SLEEP_DPos
#define CANFD_SR_SLEEP_Msk        (0x1UL << CANFD_SR_SLEEP_DPos)               /* 0x00000004 */
#define CANFD_SR_SLEEP            CANFD_SR_SLEEP_Msk                           /* Sleep Mode. */

#define CANFD_SR_NORMAL_DPos      (3U)
#define CANFD_SR_NORMAL_Pos       CANFD_SR_NORMAL_DPos
#define CANFD_SR_NORMAL_Msk       (0x1UL << CANFD_SR_NORMAL_Pos)               /* 0x00000008 */
#define CANFD_SR_NORMAL           CANFD_SR_NORMAL_Msk                          /* Normal Mode. */

#define CANFD_SR_BIDLE_DPos       (4U)
#define CANFD_SR_BIDLE_Pos        CANFD_SR_BIDLE_DPos
#define CANFD_SR_BIDLE_Msk        (0x1UL << CANFD_SR_BIDLE_DPos)               /* 0x00000010 */
#define CANFD_SR_BIDLE            CANFD_SR_BIDLE_Msk                           /* Bus Idle. */

#define CANFD_SR_BBSY_DPos        (5U)
#define CANFD_SR_BBSY_Pos         CANFD_SR_BBSY_DPos
#define CANFD_SR_BBSY_Msk         (0x1UL << CANFD_SR_BBSY_Pos)                 /* 0x00000020 */
#define CANFD_SR_BBSY             CANFD_SR_BBSY_Msk                            /* Indicates the CAN bus status. */

#define CANFD_SR_ERRWRN_DPos      (6U)
#define CANFD_SR_ERRWRN_Pos       CANFD_SR_ERRWRN_DPos
#define CANFD_SR_ERRWRN_Msk       (0x1UL << CANFD_SR_ERRWRN_Pos)               /* 0x00000040 */
#define CANFD_SR_ERRWRN           CANFD_SR_ERRWRN_Msk                          /* Error Warning. */

#define CANFD_SR_ESTAT_DPos       (7U)
#define CANFD_SR_ESTAT_Pos        CANFD_SR_ESTAT_DPos
#define CANFD_SR_ESTAT_Msk        (0x3UL << CANFD_SR_ESTAT_Pos)                /* 0x00000180 */
#define CANFD_SR_ESTAT            CANFD_SR_ESTAT_Msk                           /* ESTAT[1:0] bits (Error Status.) */
#define CANFD_SR_ESTAT_0          (0x1UL << CANFD_SR_ESTAT_Pos)                /* 0x00000100 */
#define CANFD_SR_ESTAT_1          (0x2UL << CANFD_SR_ESTAT_Pos)                /* 0x00000200 */

#define CANFD_SR_PEE_CONFIG_DPos  (9U)
#define CANFD_SR_PEE_CONFIG_Pos   CANFD_SR_PEE_CONFIG_DPos
#define CANFD_SR_PEE_CONFIG_Msk   (0x1UL << CANFD_SR_PEE_CONFIG_Pos)           /* 0x00000200 */
#define CANFD_SR_PEE_CONFIG       CANFD_SR_PEE_CONFIG_Msk                      /* PEE Mode Indicator. */

#define CANFD_SR_BSFR_CONFIG_DPos (10U)
#define CANFD_SR_BSFR_CONFIG_Pos  CANFD_SR_BSFR_CONFIG_DPos
#define CANFD_SR_BSFR_CONFIG_Msk  (0x1UL << CANFD_SR_BSFR_CONFIG_Pos)          /* 0x00000400 */
#define CANFD_SR_BSFR_CONFIG      CANFD_SR_BSFR_CONFIG_Msk                     /* Bus-Off Recovery Mode Indicator. */

#define CANFD_SR_SNOOP_DPos       (12U)
#define CANFD_SR_SNOOP_Pos        CANFD_SR_SNOOP_DPos
#define CANFD_SR_SNOOP_Msk        (0x1UL << CANFD_SR_SNOOP_Pos)                /* 0x00001000 */
#define CANFD_SR_SNOOP            CANFD_SR_SNOOP_Msk                           /* Snoop Mode. */
#define CANFD_SR_TDCV_DPos        (16U)
#define CANFD_SR_TDCV_Pos         CANFD_SR_TDCV_DPos
#define CANFD_SR_TDCV_Msk         (0x7FUL << CANFD_SR_TDCV_Pos)                /* 0x007F0000 */
#define CANFD_SR_TDCV             CANFD_SR_TDCV_Msk                            /* TDCV[6:0] bits (Transmitter Delay Compensation Value.) */
#define CANFD_SR_TDCV_0           (0x1UL << CANFD_SR_TDCV_Pos)                 /* 0x00010000 */
#define CANFD_SR_TDCV_1           (0x2UL << CANFD_SR_TDCV_Pos)                 /* 0x00020000 */
#define CANFD_SR_TDCV_2           (0x4UL << CANFD_SR_TDCV_Pos)                 /* 0x00040000 */
#define CANFD_SR_TDCV_3           (0x8UL << CANFD_SR_TDCV_Pos)                 /* 0x00080000 */
#define CANFD_SR_TDCV_4           (0x10UL << CANFD_SR_TDCV_Pos)                /* 0x00100000 */
#define CANFD_SR_TDCV_5           (0x20UL << CANFD_SR_TDCV_Pos)                /* 0x00200000 */
#define CANFD_SR_TDCV_6           (0x40UL << CANFD_SR_TDCV_Pos)                /* 0x00400000 */

/******************  Bit definition for CANFD_ISR register  *******************/
#define CANFD_ISR_ARBLST_DPos     (0U)
#define CANFD_ISR_ARBLST_Pos      CANFD_ISR_ARBLST_DPos
#define CANFD_ISR_ARBLST_Msk      (0x1UL << CANFD_ISR_ARBLST_Pos)              /* 0x00000001 */
#define CANFD_ISR_ARBLST          CANFD_ISR_ARBLST_Msk                         /* Arbitration Lost Interrupt. */

#define CANFD_ISR_TXOK_DPos       (1U)
#define CANFD_ISR_TXOK_Pos        CANFD_ISR_TXOK_DPos
#define CANFD_ISR_TXOK_Msk        (0x1UL << CANFD_ISR_TXOK_Pos)                /* 0x00000002 */
#define CANFD_ISR_TXOK            CANFD_ISR_TXOK_Msk                           /* Transmission Successful Interrupt. */

#define CANFD_ISR_PEE_DPos        (2U)
#define CANFD_ISR_PEE_Pos         CANFD_ISR_PEE_DPos
#define CANFD_ISR_PEE_Msk         (0x1UL << CANFD_ISR_PEE_Pos)                 /* 0x00000004 */
#define CANFD_ISR_PEE             CANFD_ISR_PEE_Msk                            /* Protocol Exception Event Interrupt. */

#define CANFD_ISR_BSFRD_DPos      (3U)
#define CANFD_ISR_BSFRD_Pos       CANFD_ISR_BSFRD_DPos
#define CANFD_ISR_BSFRD_Msk       (0x1UL << CANFD_ISR_BSFRD_Pos)               /* 0x00000008 */
#define CANFD_ISR_BSFRD           CANFD_ISR_BSFRD_Msk                          /* Bus-Off Recovery Done Interrupt. */

#define CANFD_ISR_RXOK_DPos       (4U)
#define CANFD_ISR_RXOK_Pos        CANFD_ISR_RXOK_DPos
#define CANFD_ISR_RXOK_Msk        (0x1UL << CANFD_ISR_RXOK_Pos)                /* 0x00000010 */
#define CANFD_ISR_RXOK            CANFD_ISR_RXOK_Msk                           /* New Message Received Interrupt */

#define CANFD_ISR_TSCNT_OFLW_DPos (5U)
#define CANFD_ISR_TSCNT_OFLW_Pos  CANFD_ISR_TSCNT_OFLW_DPos
#define CANFD_ISR_TSCNT_OFLW_Msk  (0x1UL << CANFD_ISR_TSCNT_OFLW_Pos)          /* 0x00000020 */
#define CANFD_ISR_TSCNT_OFLW      CANFD_ISR_TSCNT_OFLW_Msk                     /* Timestamp Counter Overflow Interrupt. */

#define CANFD_ISR_RXFOFLW_DPos    (6U)
#define CANFD_ISR_RXFOFLW_Pos     CANFD_ISR_RXFOFLW_DPos
#define CANFD_ISR_RXFOFLW_Msk     (0x1UL << CANFD_ISR_RXFOFLW_Pos)             /* 0x00000040 */
#define CANFD_ISR_RXFOFLW         CANFD_ISR_RXFOFLW_Msk                        /* RX FIFO-0 Overflow Interrupt (Sequential/FIFO Mode). */

#define CANFD_ISR_ERROE_DPos      (8U)
#define CANFD_ISR_ERROE_Pos       CANFD_ISR_ERROE_DPos
#define CANFD_ISR_ERROE_Msk       (0x1UL << CANFD_ISR_ERROE_Pos)               /* 0x00000100 */
#define CANFD_ISR_ERROE           CANFD_ISR_ERROE_Msk                          /* Error Interrupt */

#define CANFD_ISR_BSOFF_DPos      (9U)
#define CANFD_ISR_BSOFF_Pos       CANFD_ISR_BSOFF_DPos
#define CANFD_ISR_BSOFF_Msk       (0x1UL << CANFD_ISR_BSOFF_Pos)               /* 0x00000200 */
#define CANFD_ISR_BSOFF           CANFD_ISR_BSOFF_Msk                          /* Bus-Off Interrupt. */

#define CANFD_ISR_SLP_DPos        (10U)
#define CANFD_ISR_SLP_Pos         CANFD_ISR_SLP_DPos
#define CANFD_ISR_SLP_Msk         (0x1UL << CANFD_ISR_SLP_Pos)                 /* 0x00000400 */
#define CANFD_ISR_SLP             CANFD_ISR_SLP_Msk                            /* Sleep Interrupt. */

#define CANFD_ISR_WKUP_DPos       (11U)
#define CANFD_ISR_WKUP_Pos        CANFD_ISR_WKUP_DPos
#define CANFD_ISR_WKUP_Msk        (0x1UL << CANFD_ISR_WKUP_Pos)                /* 0x00000800 */
#define CANFD_ISR_WKUP            CANFD_ISR_WKUP_Msk                           /* Wake-Up Interrupt */

#define CANFD_ISR_TXRRS_DPos      (13U)
#define CANFD_ISR_TXRRS_Pos       CANFD_ISR_TXRRS_DPos
#define CANFD_ISR_TXRRS_Msk       (0x1UL << CANFD_ISR_TXRRS_Pos)               /* 0x00002000 */
#define CANFD_ISR_TXRRS           CANFD_ISR_TXRRS_Msk                          /* TX Buffer Ready Request Served Interrupt. */

#define CANFD_ISR_TXCRS_DPos      (14U)
#define CANFD_ISR_TXCRS_Pos       CANFD_ISR_TXCRS_DPos
#define CANFD_ISR_TXCRS_Msk       (0x1UL << CANFD_ISR_TXCRS_Pos)               /* 0x00004000 */
#define CANFD_ISR_TXCRS           CANFD_ISR_TXCRS_Msk                          /* TX Cancellation Request Served Interrupt. */

/******************  Bit definition for CANFD_IER register  *******************/
#define CANFD_IER_EARBLST_DPos      (0U)
#define CANFD_IER_EARBLST_Pos       CANFD_IER_EARBLST_DPos
#define CANFD_IER_EARBLST_Msk       (0x1UL << CANFD_IER_EARBLST_Pos)           /* 0x00000001 */
#define CANFD_IER_EARBLST           CANFD_IER_EARBLST_Msk                      /* Arbitration Lost Interrupt Enable */

#define CANFD_IER_ETXOK_DPos        (1U)
#define CANFD_IER_ETXOK_Pos         CANFD_IER_ETXOK_DPos
#define CANFD_IER_ETXOK_Msk         (0x1UL << CANFD_IER_ETXOK_Pos)             /* 0x00000002 */
#define CANFD_IER_ETXOK             CANFD_IER_ETXOK_Msk                        /* Transmission Successful Interrupt Enable. */

#define CANFD_IER_EPEE_DPos         (2U)
#define CANFD_IER_EPEE_Pos          CANFD_IER_EPEE_DPos
#define CANFD_IER_EPEE_Msk          (0x1UL << CANFD_IER_EPEE_Pos)              /* 0x00000004 */
#define CANFD_IER_EPEE              CANFD_IER_EPEE_Msk                         /* Protocol Exception Event Interrupt Enable. */

#define CANFD_IER_EBSFRD_DPos       (3U)
#define CANFD_IER_EBSFRD_Pos        CANFD_IER_EBSFRD_DPos
#define CANFD_IER_EBSFRD_Msk        (0x1UL << CANFD_IER_EBSFRD_Pos)            /* 0x00000008 */
#define CANFD_IER_EBSFRD            CANFD_IER_EBSFRD_Msk                       /* Bus-Off Recovery Done Interrupt Enable. */

#define CANFD_IER_ERXOK_DPos        (4U)
#define CANFD_IER_ERXOK_Pos         CANFD_IER_ERXOK_DPos
#define CANFD_IER_ERXOK_Msk         (0x1UL << CANFD_IER_ERXOK_Pos)             /* 0x00000010 */
#define CANFD_IER_ERXOK             CANFD_IER_ERXOK_Msk                        /* New Message Received Interrupt Enable. */

#define CANFD_IER_ETSCNT_OFLW_DPos  (5U)
#define CANFD_IER_ETSCNT_OFLW_Pos   CANFD_IER_ETSCNT_OFLW_DPos
#define CANFD_IER_ETSCNT_OFLW_Msk   (0x1UL << CANFD_IER_ETSCNT_OFLW_Pos)       /* 0x00000020 */
#define CANFD_IER_ETSCNT_OFLW       CANFD_IER_ETSCNT_OFLW_Msk                  /* Timestamp Counter Overflow Interrupt Enable. */

#define CANFD_IER_ERXFOFLW_DPos     (6U)
#define CANFD_IER_ERXFOFLW_Pos      CANFD_IER_ERXFOFLW_DPos
#define CANFD_IER_ERXFOFLW_Msk      (0x1UL << CANFD_IER_ERXFOFLW_Pos)          /* 0x00000040 */
#define CANFD_IER_ERXFOFLW          CANFD_IER_ERXFOFLW_Msk                     /* RX FIFO-0 Overflow Interrupt Enable (Sequential/FIFO Mode). */

#define CANFD_IER_EERROR_DPos       (8U)
#define CANFD_IER_EERROR_Pos        CANFD_IER_EERROR_DPos
#define CANFD_IER_EERROR_Msk        (0x1UL << CANFD_IER_EERROR_Pos)            /* 0x00000100 */
#define CANFD_IER_EERROR            CANFD_IER_EERROR_Msk                       /* Error Interrupt Enable. */

#define CANFD_IER_EBSOFF_DPos       (9U)
#define CANFD_IER_EBSOFF_Pos        CANFD_IER_EBSOFF_DPos
#define CANFD_IER_EBSOFF_Msk        (0x1UL << CANFD_IER_EBSOFF_Pos)            /* 0x00000200 */
#define CANFD_IER_EBSOFF            CANFD_IER_EBSOFF_Msk                       /* Bus-Off Interrupt Enable. */

#define CANFD_IER_ESLP_DPos         (10U)
#define CANFD_IER_ESLP_Pos          CANFD_IER_ESLP_DPos
#define CANFD_IER_ESLP_Msk          (0x1UL << CANFD_IER_ESLP_Pos)              /* 0x00000400 */
#define CANFD_IER_ESLP              CANFD_IER_ESLP_Msk                         /* Sleep Interrupt Enable. */

#define CANFD_IER_EWKUP_DPos        (11U)
#define CANFD_IER_EWKUP_Pos         CANFD_IER_EWKUP_DPos
#define CANFD_IER_EWKUP_Msk         (0x1UL << CANFD_IER_EWKUP_Pos)             /* 0x00000800 */
#define CANFD_IER_EWKUP             CANFD_IER_EWKUP_Msk                        /* Wake-Up Interrupt Enable. */

#define CANFD_IER_ETXRRS_DPos       (13U)
#define CANFD_IER_ETXRRS_Pos        CANFD_IER_ETXRRS_DPos
#define CANFD_IER_ETXRRS_Msk        (0x1UL << CANFD_IER_ETXRRS_Pos)            /* 0x00002000 */
#define CANFD_IER_ETXRRS            CANFD_IER_ETXRRS_Msk                       /* TX Buffer Ready Request Served Interrupt Enable. */

#define CANFD_IER_ETXCRS_DPos       (14U)
#define CANFD_IER_ETXCRS_Pos        CANFD_IER_ETXCRS_DPos
#define CANFD_IER_ETXCRS_Msk        (0x1UL << CANFD_IER_ETXCRS_Pos)            /* 0x00004000 */
#define CANFD_IER_ETXCRS            CANFD_IER_ETXCRS_Msk                       /* TX Cancellation Request Served Interrupt Enable. */

/******************  Bit definition for CANFD_ICR register  *******************/
#define CANFD_ICR_CARBLST_DPos      (0U)
#define CANFD_ICR_CARBLST_Pos       CANFD_ICR_CARBLST_DPos
#define CANFD_ICR_CARBLST_Msk       (0x1UL << CANFD_ICR_CARBLST_Pos)           /* 0x00000001 */
#define CANFD_ICR_CARBLST           CANFD_ICR_CARBLST_Msk                      /* Clears Arbitration Lost interrupt */

#define CANFD_ICR_CTXOK_DPos        (1U)
#define CANFD_ICR_CTXOK_Pos         CANFD_ICR_CTXOK_DPos
#define CANFD_ICR_CTXOK_Msk         (0x1UL << CANFD_ICR_CTXOK_Pos)             /* 0x00000002 */
#define CANFD_ICR_CTXOK             CANFD_ICR_CTXOK_Msk                        /* Clears Transmission Successful interrupt */

#define CANFD_ICR_CPEE_DPos         (2U)
#define CANFD_ICR_CPEE_Pos          CANFD_ICR_CPEE_DPos
#define CANFD_ICR_CPEE_Msk          (0x1UL << CANFD_ICR_CPEE_Pos)              /* 0x00000004 */
#define CANFD_ICR_CPEE              CANFD_ICR_CPEE_Msk                         /* Clears Protocol Exception Event interrupt */

#define CANFD_ICR_CBSFRD_DPos       (3U)
#define CANFD_ICR_CBSFRD_Pos        CANFD_ICR_CBSFRD_DPos
#define CANFD_ICR_CBSFRD_Msk        (0x1UL << CANFD_ICR_CBSFRD_Pos)            /* 0x00000008 */
#define CANFD_ICR_CBSFRD            CANFD_ICR_CBSFRD_Msk                       /* Clears Bus-Off Recovery Done interrupt */

#define CANFD_ICR_CRXOK_DPos        (4U)
#define CANFD_ICR_CRXOK_Pos         CANFD_ICR_CRXOK_DPos
#define CANFD_ICR_CRXOK_Msk         (0x1UL << CANFD_ICR_CRXOK_Pos)             /* 0x00000010 */
#define CANFD_ICR_CRXOK             CANFD_ICR_CRXOK_Msk                        /* Clears New Message Received interrupt */

#define CANFD_ICR_CTSCNT_OFLW_DPos  (5U)
#define CANFD_ICR_CTSCNT_OFLW_Pos   CANFD_ICR_CTSCNT_OFLW_DPos
#define CANFD_ICR_CTSCNT_OFLW_Msk   (0x1UL << CANFD_ICR_CTSCNT_OFLW_Pos)       /* 0x00000020 */
#define CANFD_ICR_CTSCNT_OFLW       CANFD_ICR_CTSCNT_OFLW_Msk                  /* Clears Timestamp Counter Overflow Interrupt */

#define CANFD_ICR_CRXFOFLW_DPos     (6U)
#define CANFD_ICR_CRXFOFLW_Pos      CANFD_ICR_CRXFOFLW_DPos
#define CANFD_ICR_CRXFOFLW_Msk      (0x1UL << CANFD_ICR_CRXFOFLW_Pos)          /* 0x00000040 */
#define CANFD_ICR_CRXFOFLW          CANFD_ICR_CRXFOFLW_Msk                     /* Clears RX FIFO-0 Overflow interrupt (Sequential/FIFO Mode). */

#define CANFD_ICR_CERROE_DPos       (8U)
#define CANFD_ICR_CERROE_Pos        CANFD_ICR_CERROE_DPos
#define CANFD_ICR_CERROE_Msk        (0x1UL << CANFD_ICR_CERROE_Pos)            /* 0x00000100 */
#define CANFD_ICR_CERROE            CANFD_ICR_CERROE_Msk                       /* Clears Error interrupt */

#define CANFD_ICR_CBSOFF_DPos       (9U)
#define CANFD_ICR_CBSOFF_Pos        CANFD_ICR_CBSOFF_DPos
#define CANFD_ICR_CBSOFF_Msk        (0x1UL << CANFD_ICR_CBSOFF_Pos)            /* 0x00000200 */
#define CANFD_ICR_CBSOFF            CANFD_ICR_CBSOFF_Msk                       /* Clears Bus-Off interrupt */

#define CANFD_ICR_CSLP_DPos         (10U)
#define CANFD_ICR_CSLP_Pos          CANFD_ICR_CSLP_DPos
#define CANFD_ICR_CSLP_Msk          (0x1UL << CANFD_ICR_CSLP_Pos)              /* 0x00000400 */
#define CANFD_ICR_CSLP              CANFD_ICR_CSLP_Msk                         /* Clears Sleep interrupt */

#define CANFD_ICR_CWKUP_DPos        (11U)
#define CANFD_ICR_CWKUP_Pos         CANFD_ICR_CWKUP_DPos
#define CANFD_ICR_CWKUP_Msk         (0x1UL << CANFD_ICR_CWKUP_Pos)             /* 0x00000800 */
#define CANFD_ICR_CWKUP             CANFD_ICR_CWKUP_Msk                        /* Clears Wake-Up interrupt */

#define CANFD_ICR_CTXRRS_DPos       (13U)
#define CANFD_ICR_CTXRRS_Pos        CANFD_ICR_CTXRRS_DPos
#define CANFD_ICR_CTXRRS_Msk        (0x1UL << CANFD_ICR_CTXRRS_Pos)            /* 0x00002000 */
#define CANFD_ICR_CTXRRS            CANFD_ICR_CTXRRS_Msk                       /* Clears TX Buffer Ready Request Served Interrupt */

#define CANFD_ICR_CTXCRS_DPos       (14U)
#define CANFD_ICR_CTXCRS_Pos        CANFD_ICR_CTXCRS_DPos
#define CANFD_ICR_CTXCRS_Msk        (0x1UL << CANFD_ICR_CTXCRS_Pos)            /* 0x00004000 */
#define CANFD_ICR_CTXCRS            CANFD_ICR_CTXCRS_Msk                       /* Clears TX Cancellation Request Served Interrupt */

/******************  Bit definition for CANFD_TSR register  *******************/
#define CANFD_TSR_CTS_DPos            (0U)
#define CANFD_TSR_CTS_Pos             CANFD_TSR_CTS_DPos
#define CANFD_TSR_CTS_Msk             (0x1UL << CANFD_TSR_CTS_Pos)               /* 0x00000001 */
#define CANFD_TSR_CTS                 CANFD_TSR_CTS_Msk                          /* Clear Timestamp Counter. */

#define CANFD_TSR_TIMESTAMP_CNT_DPos  (16U)
#define CANFD_TSR_TIMESTAMP_CNT_Pos   CANFD_TSR_TIMESTAMP_CNT_DPos
#define CANFD_TSR_TIMESTAMP_CNT_Msk   (0xFFFFUL << CANFD_TSR_TIMESTAMP_CNT_Pos)  /* 0xFFFF0000 */
#define CANFD_TSR_TIMESTAMP_CNT       CANFD_TSR_TIMESTAMP_CNT_Msk                /* TIMESTAMP_CNT[15:0] bits (Timestamp Counter Value.) */
#define CANFD_TSR_TIMESTAMP_CNT_0     (0x1UL << CANFD_TSR_TIMESTAMP_CNT_Pos)     /* 0x00010000 */
#define CANFD_TSR_TIMESTAMP_CNT_1     (0x2UL << CANFD_TSR_TIMESTAMP_CNT_Pos)     /* 0x00020000 */
#define CANFD_TSR_TIMESTAMP_CNT_2     (0x4UL << CANFD_TSR_TIMESTAMP_CNT_Pos)     /* 0x00040000 */
#define CANFD_TSR_TIMESTAMP_CNT_3     (0x8UL << CANFD_TSR_TIMESTAMP_CNT_Pos)     /* 0x00080000 */
#define CANFD_TSR_TIMESTAMP_CNT_4     (0x10UL << CANFD_TSR_TIMESTAMP_CNT_Pos)    /* 0x00100000 */
#define CANFD_TSR_TIMESTAMP_CNT_5     (0x20UL << CANFD_TSR_TIMESTAMP_CNT_Pos)    /* 0x00200000 */
#define CANFD_TSR_TIMESTAMP_CNT_6     (0x40UL << CANFD_TSR_TIMESTAMP_CNT_Pos)    /* 0x00400000 */
#define CANFD_TSR_TIMESTAMP_CNT_7     (0x80UL << CANFD_TSR_TIMESTAMP_CNT_Pos)    /* 0x00800000 */
#define CANFD_TSR_TIMESTAMP_CNT_8     (0x100UL << CANFD_TSR_TIMESTAMP_CNT_Pos)   /* 0x01000000 */
#define CANFD_TSR_TIMESTAMP_CNT_9     (0x200UL << CANFD_TSR_TIMESTAMP_CNT_Pos)   /* 0x02000000 */
#define CANFD_TSR_TIMESTAMP_CNT_10    (0x400UL << CANFD_TSR_TIMESTAMP_CNT_Pos)   /* 0x04000000 */
#define CANFD_TSR_TIMESTAMP_CNT_11    (0x800UL << CANFD_TSR_TIMESTAMP_CNT_Pos)   /* 0x08000000 */
#define CANFD_TSR_TIMESTAMP_CNT_12    (0x1000UL << CANFD_TSR_TIMESTAMP_CNT_Pos)  /* 0x10000000 */
#define CANFD_TSR_TIMESTAMP_CNT_13    (0x2000UL << CANFD_TSR_TIMESTAMP_CNT_Pos)  /* 0x20000000 */
#define CANFD_TSR_TIMESTAMP_CNT_14    (0x4000UL << CANFD_TSR_TIMESTAMP_CNT_Pos)  /* 0x40000000 */
#define CANFD_TSR_TIMESTAMP_CNT_15    (0x8000UL << CANFD_TSR_TIMESTAMP_CNT_Pos)  /* 0x80000000 */

/****************  Bit definition for CANFD_DPBRPR register  ******************/
#define CANFD_DPBRPR_DP_BRP_DPos    (0U)
#define CANFD_DPBRPR_DP_BRP_Pos     CANFD_DPBRPR_DP_BRP_DPos
#define CANFD_DPBRPR_DP_BRP_Msk     (0xFFUL << CANFD_DPBRPR_DP_BRP_Pos)         /* 0x000000FF */
#define CANFD_DPBRPR_DP_BRP         CANFD_DPBRPR_DP_BRP_Msk                     /* DP_BRP[7:0] bits (Data Phase Baud Rate Prescaler) */
#define CANFD_DPBRPR_DP_BRP_0       (0x1UL << CANFD_DPBRPR_DP_BRP_Pos)          /* 0x00000001 */
#define CANFD_DPBRPR_DP_BRP_1       (0x2UL << CANFD_DPBRPR_DP_BRP_Pos)          /* 0x00000002 */
#define CANFD_DPBRPR_DP_BRP_2       (0x4UL << CANFD_DPBRPR_DP_BRP_Pos)          /* 0x00000004 */
#define CANFD_DPBRPR_DP_BRP_3       (0x8UL << CANFD_DPBRPR_DP_BRP_Pos)          /* 0x00000008 */
#define CANFD_DPBRPR_DP_BRP_4       (0x10UL << CANFD_DPBRPR_DP_BRP_Pos)         /* 0x00000010 */
#define CANFD_DPBRPR_DP_BRP_5       (0x20UL << CANFD_DPBRPR_DP_BRP_Pos)         /* 0x00000020 */
#define CANFD_DPBRPR_DP_BRP_6       (0x40UL << CANFD_DPBRPR_DP_BRP_Pos)         /* 0x00000040 */
#define CANFD_DPBRPR_DP_BRP_7       (0x80UL << CANFD_DPBRPR_DP_BRP_Pos)         /* 0x00000080 */

#define CANFD_DPBRPR_TDCOFF_DPos    (8U)
#define CANFD_DPBRPR_TDCOFF_Pos     CANFD_DPBRPR_TDCOFF_DPos
#define CANFD_DPBRPR_TDCOFF_Msk     (0x3FUL << CANFD_DPBRPR_TDCOFF_Pos)         /* 0x00003F00 */
#define CANFD_DPBRPR_TDCOFF         CANFD_DPBRPR_TDCOFF_Msk                     /* TDCOFF[5:0] bits (Transmitter Delay Compensation Offset) */
#define CANFD_DPBRPR_TDCOFF_0       (0x1UL << CANFD_DPBRPR_TDCOFF_Pos)          /* 0x00000100 */
#define CANFD_DPBRPR_TDCOFF_1       (0x2UL << CANFD_DPBRPR_TDCOFF_Pos)          /* 0x00000200 */
#define CANFD_DPBRPR_TDCOFF_2       (0x4UL << CANFD_DPBRPR_TDCOFF_Pos)          /* 0x00000400 */
#define CANFD_DPBRPR_TDCOFF_3       (0x8UL << CANFD_DPBRPR_TDCOFF_Pos)          /* 0x00000800 */
#define CANFD_DPBRPR_TDCOFF_4       (0x10UL << CANFD_DPBRPR_TDCOFF_Pos)         /* 0x00001000 */
#define CANFD_DPBRPR_TDCOFF_5       (0x20UL << CANFD_DPBRPR_TDCOFF_Pos)         /* 0x00002000 */

#define CANFD_DPBRPR_TDC_DPos       (16U)
#define CANFD_DPBRPR_TDC_Pos        CANFD_DPBRPR_TDC_DPos
#define CANFD_DPBRPR_TDC_Msk        (0x1UL << CANFD_DPBRPR_TDC_Pos)             /* 0x00010000 */
#define CANFD_DPBRPR_TDC            CANFD_DPBRPR_TDC_Msk                        /* Transmitter Delay Compensation (TDC) Enable */

/*****************  Bit definition for CANFD_DPBTR register  ******************/
#define CANFD_DPBTR_DP_TS1_DPos   (0U)
#define CANFD_DPBTR_DP_TS1_Pos    CANFD_DPBTR_DP_TS1_DPos
#define CANFD_DPBTR_DP_TS1_Msk    (0x1FUL << CANFD_DPBTR_DP_TS1_Pos)           /* 0x0000001F */
#define CANFD_DPBTR_DP_TS1        CANFD_DPBTR_DP_TS1_Msk                       /* DP_TS1[4:0] bits (Data Phase Time Segment 1) */
#define CANFD_DPBTR_DP_TS1_0      (0x1UL << CANFD_DPBTR_DP_TS1_Pos)            /* 0x00000001 */
#define CANFD_DPBTR_DP_TS1_1      (0x2UL << CANFD_DPBTR_DP_TS1_Pos)            /* 0x00000002 */
#define CANFD_DPBTR_DP_TS1_2      (0x4UL << CANFD_DPBTR_DP_TS1_Pos)            /* 0x00000004 */
#define CANFD_DPBTR_DP_TS1_3      (0x8UL << CANFD_DPBTR_DP_TS1_Pos)            /* 0x00000008 */
#define CANFD_DPBTR_DP_TS1_4      (0x10UL << CANFD_DPBTR_DP_TS1_Pos)           /* 0x00000010 */

#define CANFD_DPBTR_DP_TS2_DPos   (8U)
#define CANFD_DPBTR_DP_TS2_Pos    CANFD_DPBTR_DP_TS2_DPos
#define CANFD_DPBTR_DP_TS2_Msk    (0xFUL << CANFD_DPBTR_DP_TS2_Pos)            /* 0x00000F00 */
#define CANFD_DPBTR_DP_TS2        CANFD_DPBTR_DP_TS2_Msk                       /* DP_TS2[3:0] bits (Data Phase Time Segment 2) */
#define CANFD_DPBTR_DP_TS2_0      (0x1UL << CANFD_DPBTR_DP_TS2_Pos)            /* 0x00000100 */
#define CANFD_DPBTR_DP_TS2_1      (0x2UL << CANFD_DPBTR_DP_TS2_Pos)            /* 0x00000200 */
#define CANFD_DPBTR_DP_TS2_2      (0x4UL << CANFD_DPBTR_DP_TS2_Pos)            /* 0x00000400 */
#define CANFD_DPBTR_DP_TS2_3      (0x8UL << CANFD_DPBTR_DP_TS2_Pos)            /* 0x00000800 */

#define CANFD_DPBTR_DP_SJW_DPos   (16U)
#define CANFD_DPBTR_DP_SJW_Pos    CANFD_DPBTR_DP_SJW_DPos
#define CANFD_DPBTR_DP_SJW_Msk    (0xFUL << CANFD_DPBTR_DP_SJW_Pos)            /* 0x000F0000 */
#define CANFD_DPBTR_DP_SJW        CANFD_DPBTR_DP_SJW_Msk                       /* DP_SJW[3:0] bits (Data Phase Synchronization Jump Width) */
#define CANFD_DPBTR_DP_SJW_0      (0x1UL << CANFD_DPBTR_DP_SJW_Pos)            /* 0x00010000 */
#define CANFD_DPBTR_DP_SJW_1      (0x2UL << CANFD_DPBTR_DP_SJW_Pos)            /* 0x00020000 */
#define CANFD_DPBTR_DP_SJW_2      (0x4UL << CANFD_DPBTR_DP_SJW_Pos)            /* 0x00040000 */
#define CANFD_DPBTR_DP_SJW_3      (0x8UL << CANFD_DPBTR_DP_SJW_Pos)            /* 0x00080000 */

/******************  Bit definition for CANFD_TRR register  *******************/
#define CANFD_TRR_RR_DPos         (0U)
#define CANFD_TRR_RR_Pos          CANFD_TRR_RR_DPos
#define CANFD_TRR_RR_Msk          (0xFFFFFFFFUL << CANFD_TRR_RR_Pos)           /* 0xFFFFFFFF */
#define CANFD_TRR_RR              CANFD_TRR_RR_Msk                             /* RR[31:0] bits (TX Buffer Ready Request) */
#define CANFD_TRR_RR_0            (0x1UL << CANFD_TRR_RR_Pos)                  /* 0x00000001 */
#define CANFD_TRR_RR_1            (0x2UL << CANFD_TRR_RR_Pos)                  /* 0x00000002 */
#define CANFD_TRR_RR_2            (0x4UL << CANFD_TRR_RR_Pos)                  /* 0x00000004 */
#define CANFD_TRR_RR_3            (0x8UL << CANFD_TRR_RR_Pos)                  /* 0x00000008 */
#define CANFD_TRR_RR_4            (0x10UL << CANFD_TRR_RR_Pos)                 /* 0x00000010 */
#define CANFD_TRR_RR_5            (0x20UL << CANFD_TRR_RR_Pos)                 /* 0x00000020 */
#define CANFD_TRR_RR_6            (0x40UL << CANFD_TRR_RR_Pos)                 /* 0x00000040 */
#define CANFD_TRR_RR_7            (0x80UL << CANFD_TRR_RR_Pos)                 /* 0x00000080 */
#define CANFD_TRR_RR_8            (0x100UL << CANFD_TRR_RR_Pos)                /* 0x00000100 */
#define CANFD_TRR_RR_9            (0x200UL << CANFD_TRR_RR_Pos)                /* 0x00000200 */
#define CANFD_TRR_RR_10           (0x400UL << CANFD_TRR_RR_Pos)                /* 0x00000400 */
#define CANFD_TRR_RR_11           (0x800UL << CANFD_TRR_RR_Pos)                /* 0x00000800 */
#define CANFD_TRR_RR_12           (0x1000UL << CANFD_TRR_RR_Pos)               /* 0x00001000 */
#define CANFD_TRR_RR_13           (0x2000UL << CANFD_TRR_RR_Pos)               /* 0x00002000 */
#define CANFD_TRR_RR_14           (0x4000UL << CANFD_TRR_RR_Pos)               /* 0x00004000 */
#define CANFD_TRR_RR_15           (0x8000UL << CANFD_TRR_RR_Pos)               /* 0x00008000 */
#define CANFD_TRR_RR_16           (0x10000UL << CANFD_TRR_RR_Pos)              /* 0x00010000 */
#define CANFD_TRR_RR_17           (0x20000UL << CANFD_TRR_RR_Pos)              /* 0x00020000 */
#define CANFD_TRR_RR_18           (0x40000UL << CANFD_TRR_RR_Pos)              /* 0x00040000 */
#define CANFD_TRR_RR_19           (0x80000UL << CANFD_TRR_RR_Pos)              /* 0x00080000 */
#define CANFD_TRR_RR_20           (0x100000UL << CANFD_TRR_RR_Pos)             /* 0x00100000 */
#define CANFD_TRR_RR_21           (0x200000UL << CANFD_TRR_RR_Pos)             /* 0x00200000 */
#define CANFD_TRR_RR_22           (0x400000UL << CANFD_TRR_RR_Pos)             /* 0x00400000 */
#define CANFD_TRR_RR_23           (0x800000UL << CANFD_TRR_RR_Pos)             /* 0x00800000 */
#define CANFD_TRR_RR_24           (0x1000000UL << CANFD_TRR_RR_Pos)            /* 0x01000000 */
#define CANFD_TRR_RR_25           (0x2000000UL << CANFD_TRR_RR_Pos)            /* 0x02000000 */
#define CANFD_TRR_RR_26           (0x4000000UL << CANFD_TRR_RR_Pos)            /* 0x04000000 */
#define CANFD_TRR_RR_27           (0x8000000UL << CANFD_TRR_RR_Pos)            /* 0x08000000 */
#define CANFD_TRR_RR_28           (0x10000000UL << CANFD_TRR_RR_Pos)           /* 0x10000000 */
#define CANFD_TRR_RR_29           (0x20000000UL << CANFD_TRR_RR_Pos)           /* 0x20000000 */
#define CANFD_TRR_RR_30           (0x40000000UL << CANFD_TRR_RR_Pos)           /* 0x40000000 */
#define CANFD_TRR_RR_31           (0x80000000UL << CANFD_TRR_RR_Pos)           /* 0x80000000 */

/******************  Bit definition for CANFD_ERRS register  ******************/
#define CANFD_ERRS_ERRS_DPos      (0U)
#define CANFD_ERRS_ERRS_Pos       CANFD_ERRS_ERRS_DPos
#define CANFD_ERRS_ERRS_Msk       (0xFFFFFFFFUL << CANFD_ERRS_ERRS_Pos)        /* 0xFFFFFFFF */
#define CANFD_ERRS_ERRS           CANFD_ERRS_ERRS_Msk                          /* ERRS[31:0] bits (TX Buffer Ready Req Served/Cleared Interrupt Enable) */
#define CANFD_ERRS_ERRS_0         (0x1UL << CANFD_ERRS_ERRS_Pos)               /* 0x00000001 */
#define CANFD_ERRS_ERRS_1         (0x2UL << CANFD_ERRS_ERRS_Pos)               /* 0x00000002 */
#define CANFD_ERRS_ERRS_2         (0x4UL << CANFD_ERRS_ERRS_Pos)               /* 0x00000004 */
#define CANFD_ERRS_ERRS_3         (0x8UL << CANFD_ERRS_ERRS_Pos)               /* 0x00000008 */
#define CANFD_ERRS_ERRS_4         (0x10UL << CANFD_ERRS_ERRS_Pos)              /* 0x00000010 */
#define CANFD_ERRS_ERRS_5         (0x20UL << CANFD_ERRS_ERRS_Pos)              /* 0x00000020 */
#define CANFD_ERRS_ERRS_6         (0x40UL << CANFD_ERRS_ERRS_Pos)              /* 0x00000040 */
#define CANFD_ERRS_ERRS_7         (0x80UL << CANFD_ERRS_ERRS_Pos)              /* 0x00000080 */
#define CANFD_ERRS_ERRS_8         (0x100UL << CANFD_ERRS_ERRS_Pos)             /* 0x00000100 */
#define CANFD_ERRS_ERRS_9         (0x200UL << CANFD_ERRS_ERRS_Pos)             /* 0x00000200 */
#define CANFD_ERRS_ERRS_10        (0x400UL << CANFD_ERRS_ERRS_Pos)             /* 0x00000400 */
#define CANFD_ERRS_ERRS_11        (0x800UL << CANFD_ERRS_ERRS_Pos)             /* 0x00000800 */
#define CANFD_ERRS_ERRS_12        (0x1000UL << CANFD_ERRS_ERRS_Pos)            /* 0x00001000 */
#define CANFD_ERRS_ERRS_13        (0x2000UL << CANFD_ERRS_ERRS_Pos)            /* 0x00002000 */
#define CANFD_ERRS_ERRS_14        (0x4000UL << CANFD_ERRS_ERRS_Pos)            /* 0x00004000 */
#define CANFD_ERRS_ERRS_15        (0x8000UL << CANFD_ERRS_ERRS_Pos)            /* 0x00008000 */
#define CANFD_ERRS_ERRS_16        (0x10000UL << CANFD_ERRS_ERRS_Pos)           /* 0x00010000 */
#define CANFD_ERRS_ERRS_17        (0x20000UL << CANFD_ERRS_ERRS_Pos)           /* 0x00020000 */
#define CANFD_ERRS_ERRS_18        (0x40000UL << CANFD_ERRS_ERRS_Pos)           /* 0x00040000 */
#define CANFD_ERRS_ERRS_19        (0x80000UL << CANFD_ERRS_ERRS_Pos)           /* 0x00080000 */
#define CANFD_ERRS_ERRS_20        (0x100000UL << CANFD_ERRS_ERRS_Pos)          /* 0x00100000 */
#define CANFD_ERRS_ERRS_21        (0x200000UL << CANFD_ERRS_ERRS_Pos)          /* 0x00200000 */
#define CANFD_ERRS_ERRS_22        (0x400000UL << CANFD_ERRS_ERRS_Pos)          /* 0x00400000 */
#define CANFD_ERRS_ERRS_23        (0x800000UL << CANFD_ERRS_ERRS_Pos)          /* 0x00800000 */
#define CANFD_ERRS_ERRS_24        (0x1000000UL << CANFD_ERRS_ERRS_Pos)         /* 0x01000000 */
#define CANFD_ERRS_ERRS_25        (0x2000000UL << CANFD_ERRS_ERRS_Pos)         /* 0x02000000 */
#define CANFD_ERRS_ERRS_26        (0x4000000UL << CANFD_ERRS_ERRS_Pos)         /* 0x04000000 */
#define CANFD_ERRS_ERRS_27        (0x8000000UL << CANFD_ERRS_ERRS_Pos)         /* 0x08000000 */
#define CANFD_ERRS_ERRS_28        (0x10000000UL << CANFD_ERRS_ERRS_Pos)        /* 0x10000000 */
#define CANFD_ERRS_ERRS_29        (0x20000000UL << CANFD_ERRS_ERRS_Pos)        /* 0x20000000 */
#define CANFD_ERRS_ERRS_30        (0x40000000UL << CANFD_ERRS_ERRS_Pos)        /* 0x40000000 */
#define CANFD_ERRS_ERRS_31        (0x80000000UL << CANFD_ERRS_ERRS_Pos)        /* 0x80000000 */

/*******************  Bit definition for CANFD_TCR register  ******************/
#define CANFD_TCR_CR_DPos         (0U)
#define CANFD_TCR_CR_Pos          CANFD_TCR_CR_DPos
#define CANFD_TCR_CR_Msk          (0xFFFFFFFFUL << CANFD_TCR_CR_Pos)           /* 0xFFFFFFFF */
#define CANFD_TCR_CR              CANFD_TCR_CR_Msk                             /* CR[31:0] bits (TX Buffer Cancel Request) */
#define CANFD_TCR_CR_0            (0x1UL << CANFD_TCR_CR_Pos)                  /* 0x00000001 */
#define CANFD_TCR_CR_1            (0x2UL << CANFD_TCR_CR_Pos)                  /* 0x00000002 */
#define CANFD_TCR_CR_2            (0x4UL << CANFD_TCR_CR_Pos)                  /* 0x00000004 */
#define CANFD_TCR_CR_3            (0x8UL << CANFD_TCR_CR_Pos)                  /* 0x00000008 */
#define CANFD_TCR_CR_4            (0x10UL << CANFD_TCR_CR_Pos)                 /* 0x00000010 */
#define CANFD_TCR_CR_5            (0x20UL << CANFD_TCR_CR_Pos)                 /* 0x00000020 */
#define CANFD_TCR_CR_6            (0x40UL << CANFD_TCR_CR_Pos)                 /* 0x00000040 */
#define CANFD_TCR_CR_7            (0x80UL << CANFD_TCR_CR_Pos)                 /* 0x00000080 */
#define CANFD_TCR_CR_8            (0x100UL << CANFD_TCR_CR_Pos)                /* 0x00000100 */
#define CANFD_TCR_CR_9            (0x200UL << CANFD_TCR_CR_Pos)                /* 0x00000200 */
#define CANFD_TCR_CR_10           (0x400UL << CANFD_TCR_CR_Pos)                /* 0x00000400 */
#define CANFD_TCR_CR_11           (0x800UL << CANFD_TCR_CR_Pos)                /* 0x00000800 */
#define CANFD_TCR_CR_12           (0x1000UL << CANFD_TCR_CR_Pos)               /* 0x00001000 */
#define CANFD_TCR_CR_13           (0x2000UL << CANFD_TCR_CR_Pos)               /* 0x00002000 */
#define CANFD_TCR_CR_14           (0x4000UL << CANFD_TCR_CR_Pos)               /* 0x00004000 */
#define CANFD_TCR_CR_15           (0x8000UL << CANFD_TCR_CR_Pos)               /* 0x00008000 */
#define CANFD_TCR_CR_16           (0x10000UL << CANFD_TCR_CR_Pos)              /* 0x00010000 */
#define CANFD_TCR_CR_17           (0x20000UL << CANFD_TCR_CR_Pos)              /* 0x00020000 */
#define CANFD_TCR_CR_18           (0x40000UL << CANFD_TCR_CR_Pos)              /* 0x00040000 */
#define CANFD_TCR_CR_19           (0x80000UL << CANFD_TCR_CR_Pos)              /* 0x00080000 */
#define CANFD_TCR_CR_20           (0x100000UL << CANFD_TCR_CR_Pos)             /* 0x00100000 */
#define CANFD_TCR_CR_21           (0x200000UL << CANFD_TCR_CR_Pos)             /* 0x00200000 */
#define CANFD_TCR_CR_22           (0x400000UL << CANFD_TCR_CR_Pos)             /* 0x00400000 */
#define CANFD_TCR_CR_23           (0x800000UL << CANFD_TCR_CR_Pos)             /* 0x00800000 */
#define CANFD_TCR_CR_24           (0x1000000UL << CANFD_TCR_CR_Pos)            /* 0x01000000 */
#define CANFD_TCR_CR_25           (0x2000000UL << CANFD_TCR_CR_Pos)            /* 0x02000000 */
#define CANFD_TCR_CR_26           (0x4000000UL << CANFD_TCR_CR_Pos)            /* 0x04000000 */
#define CANFD_TCR_CR_27           (0x8000000UL << CANFD_TCR_CR_Pos)            /* 0x08000000 */
#define CANFD_TCR_CR_28           (0x10000000UL << CANFD_TCR_CR_Pos)           /* 0x10000000 */
#define CANFD_TCR_CR_29           (0x20000000UL << CANFD_TCR_CR_Pos)           /* 0x20000000 */
#define CANFD_TCR_CR_30           (0x40000000UL << CANFD_TCR_CR_Pos)           /* 0x40000000 */
#define CANFD_TCR_CR_31           (0x80000000UL << CANFD_TCR_CR_Pos)           /* 0x80000000 */

/******************  Bit definition for CANFD_ECRS register  ******************/
#define CANFD_ECRS_ECRS_DPos      (0U)
#define CANFD_ECRS_ECRS_Pos       CANFD_ECRS_ECRS_DPos
#define CANFD_ECRS_ECRS_Msk       (0xFFFFFFFFUL << CANFD_ECRS_ECRS_Pos)        /* 0xFFFFFFFF */
#define CANFD_ECRS_ECRS           CANFD_ECRS_ECRS_Msk                          /* ECRS[31:0] bits (TX Buffer Transmission Served/Cleared Interrupt Enable) */
#define CANFD_ECRS_ECRS_0         (0x1UL << CANFD_ECRS_ECRS_Pos)               /* 0x00000001 */
#define CANFD_ECRS_ECRS_1         (0x2UL << CANFD_ECRS_ECRS_Pos)               /* 0x00000002 */
#define CANFD_ECRS_ECRS_2         (0x4UL << CANFD_ECRS_ECRS_Pos)               /* 0x00000004 */
#define CANFD_ECRS_ECRS_3         (0x8UL << CANFD_ECRS_ECRS_Pos)               /* 0x00000008 */
#define CANFD_ECRS_ECRS_4         (0x10UL << CANFD_ECRS_ECRS_Pos)              /* 0x00000010 */
#define CANFD_ECRS_ECRS_5         (0x20UL << CANFD_ECRS_ECRS_Pos)              /* 0x00000020 */
#define CANFD_ECRS_ECRS_6         (0x40UL << CANFD_ECRS_ECRS_Pos)              /* 0x00000040 */
#define CANFD_ECRS_ECRS_7         (0x80UL << CANFD_ECRS_ECRS_Pos)              /* 0x00000080 */
#define CANFD_ECRS_ECRS_8         (0x100UL << CANFD_ECRS_ECRS_Pos)             /* 0x00000100 */
#define CANFD_ECRS_ECRS_9         (0x200UL << CANFD_ECRS_ECRS_Pos)             /* 0x00000200 */
#define CANFD_ECRS_ECRS_10        (0x400UL << CANFD_ECRS_ECRS_Pos)             /* 0x00000400 */
#define CANFD_ECRS_ECRS_11        (0x800UL << CANFD_ECRS_ECRS_Pos)             /* 0x00000800 */
#define CANFD_ECRS_ECRS_12        (0x1000UL << CANFD_ECRS_ECRS_Pos)            /* 0x00001000 */
#define CANFD_ECRS_ECRS_13        (0x2000UL << CANFD_ECRS_ECRS_Pos)            /* 0x00002000 */
#define CANFD_ECRS_ECRS_14        (0x4000UL << CANFD_ECRS_ECRS_Pos)            /* 0x00004000 */
#define CANFD_ECRS_ECRS_15        (0x8000UL << CANFD_ECRS_ECRS_Pos)            /* 0x00008000 */
#define CANFD_ECRS_ECRS_16        (0x10000UL << CANFD_ECRS_ECRS_Pos)           /* 0x00010000 */
#define CANFD_ECRS_ECRS_17        (0x20000UL << CANFD_ECRS_ECRS_Pos)           /* 0x00020000 */
#define CANFD_ECRS_ECRS_18        (0x40000UL << CANFD_ECRS_ECRS_Pos)           /* 0x00040000 */
#define CANFD_ECRS_ECRS_19        (0x80000UL << CANFD_ECRS_ECRS_Pos)           /* 0x00080000 */
#define CANFD_ECRS_ECRS_20        (0x100000UL << CANFD_ECRS_ECRS_Pos)          /* 0x00100000 */
#define CANFD_ECRS_ECRS_21        (0x200000UL << CANFD_ECRS_ECRS_Pos)          /* 0x00200000 */
#define CANFD_ECRS_ECRS_22        (0x400000UL << CANFD_ECRS_ECRS_Pos)          /* 0x00400000 */
#define CANFD_ECRS_ECRS_23        (0x800000UL << CANFD_ECRS_ECRS_Pos)          /* 0x00800000 */
#define CANFD_ECRS_ECRS_24        (0x1000000UL << CANFD_ECRS_ECRS_Pos)         /* 0x01000000 */
#define CANFD_ECRS_ECRS_25        (0x2000000UL << CANFD_ECRS_ECRS_Pos)         /* 0x02000000 */
#define CANFD_ECRS_ECRS_26        (0x4000000UL << CANFD_ECRS_ECRS_Pos)         /* 0x04000000 */
#define CANFD_ECRS_ECRS_27        (0x8000000UL << CANFD_ECRS_ECRS_Pos)         /* 0x08000000 */
#define CANFD_ECRS_ECRS_28        (0x10000000UL << CANFD_ECRS_ECRS_Pos)        /* 0x10000000 */
#define CANFD_ECRS_ECRS_29        (0x20000000UL << CANFD_ECRS_ECRS_Pos)        /* 0x20000000 */
#define CANFD_ECRS_ECRS_30        (0x40000000UL << CANFD_ECRS_ECRS_Pos)        /* 0x40000000 */
#define CANFD_ECRS_ECRS_31        (0x80000000UL << CANFD_ECRS_ECRS_Pos)        /* 0x80000000 */


/******************  Bit definition for CANFD_AFR register  *******************/
#define CANFD_AFR_UAF_DPos        (0U)
#define CANFD_AFR_UAF_Pos         CANFD_AFR_UAF_DPos
#define CANFD_AFR_UAF_Msk         (0xFFFFFFFFUL << CANFD_AFR_UAF_Pos)          /* 0xFFFFFFFF */
#define CANFD_AFR_UAF             CANFD_AFR_UAF_Msk                            /* UAF[31:0] bits (Use Acceptance Filter Mask Pair) */
#define CANFD_AFR_UAF_0           (0x1UL << CANFD_AFR_UAF_Pos)                 /* 0x00000001 */
#define CANFD_AFR_UAF_1           (0x2UL << CANFD_AFR_UAF_Pos)                 /* 0x00000002 */
#define CANFD_AFR_UAF_2           (0x4UL << CANFD_AFR_UAF_Pos)                 /* 0x00000004 */
#define CANFD_AFR_UAF_3           (0x8UL << CANFD_AFR_UAF_Pos)                 /* 0x00000008 */
#define CANFD_AFR_UAF_4           (0x10UL << CANFD_AFR_UAF_Pos)                /* 0x00000010 */
#define CANFD_AFR_UAF_5           (0x20UL << CANFD_AFR_UAF_Pos)                /* 0x00000020 */
#define CANFD_AFR_UAF_6           (0x40UL << CANFD_AFR_UAF_Pos)                /* 0x00000040 */
#define CANFD_AFR_UAF_7           (0x80UL << CANFD_AFR_UAF_Pos)                /* 0x00000080 */
#define CANFD_AFR_UAF_8           (0x100UL << CANFD_AFR_UAF_Pos)               /* 0x00000100 */
#define CANFD_AFR_UAF_9           (0x200UL << CANFD_AFR_UAF_Pos)               /* 0x00000200 */
#define CANFD_AFR_UAF_10          (0x400UL << CANFD_AFR_UAF_Pos)               /* 0x00000400 */
#define CANFD_AFR_UAF_11          (0x800UL << CANFD_AFR_UAF_Pos)               /* 0x00000800 */
#define CANFD_AFR_UAF_12          (0x1000UL << CANFD_AFR_UAF_Pos)              /* 0x00001000 */
#define CANFD_AFR_UAF_13          (0x2000UL << CANFD_AFR_UAF_Pos)              /* 0x00002000 */
#define CANFD_AFR_UAF_14          (0x4000UL << CANFD_AFR_UAF_Pos)              /* 0x00004000 */
#define CANFD_AFR_UAF_15          (0x8000UL << CANFD_AFR_UAF_Pos)              /* 0x00008000 */
#define CANFD_AFR_UAF_16          (0x10000UL << CANFD_AFR_UAF_Pos)             /* 0x00010000 */
#define CANFD_AFR_UAF_17          (0x20000UL << CANFD_AFR_UAF_Pos)             /* 0x00020000 */
#define CANFD_AFR_UAF_18          (0x40000UL << CANFD_AFR_UAF_Pos)             /* 0x00040000 */
#define CANFD_AFR_UAF_19          (0x80000UL << CANFD_AFR_UAF_Pos)             /* 0x00080000 */
#define CANFD_AFR_UAF_20          (0x100000UL << CANFD_AFR_UAF_Pos)            /* 0x00100000 */
#define CANFD_AFR_UAF_21          (0x200000UL << CANFD_AFR_UAF_Pos)            /* 0x00200000 */
#define CANFD_AFR_UAF_22          (0x400000UL << CANFD_AFR_UAF_Pos)            /* 0x00400000 */
#define CANFD_AFR_UAF_23          (0x800000UL << CANFD_AFR_UAF_Pos)            /* 0x00800000 */
#define CANFD_AFR_UAF_24          (0x1000000UL << CANFD_AFR_UAF_Pos)           /* 0x01000000 */
#define CANFD_AFR_UAF_25          (0x2000000UL << CANFD_AFR_UAF_Pos)           /* 0x02000000 */
#define CANFD_AFR_UAF_26          (0x4000000UL << CANFD_AFR_UAF_Pos)           /* 0x04000000 */
#define CANFD_AFR_UAF_27          (0x8000000UL << CANFD_AFR_UAF_Pos)           /* 0x08000000 */
#define CANFD_AFR_UAF_28          (0x10000000UL << CANFD_AFR_UAF_Pos)          /* 0x10000000 */
#define CANFD_AFR_UAF_29          (0x20000000UL << CANFD_AFR_UAF_Pos)          /* 0x20000000 */
#define CANFD_AFR_UAF_30          (0x40000000UL << CANFD_AFR_UAF_Pos)          /* 0x40000000 */
#define CANFD_AFR_UAF_31          (0x80000000UL << CANFD_AFR_UAF_Pos)          /* 0x80000000 */

/******************  Bit definition for CANFD_RFSR register  ******************/
#define CANFD_RFSR_RI_DPos        (0U)
#define CANFD_RFSR_RI_Pos         CANFD_RFSR_RI_DPos
#define CANFD_RFSR_RI_Msk         (0x3FUL << CANFD_RFSR_RI_Pos)                /* 0x0000001F */
#define CANFD_RFSR_RI             CANFD_RFSR_RI_Msk                            /* RI[5:0] bits (RX FIFO Read Index (0 to 63).) */
#define CANFD_RFSR_RI_0           (0x1UL << CANFD_RFSR_RI_Pos)                 /* 0x00000001 */
#define CANFD_RFSR_RI_1           (0x2UL << CANFD_RFSR_RI_Pos)                 /* 0x00000002 */
#define CANFD_RFSR_RI_2           (0x4UL << CANFD_RFSR_RI_Pos)                 /* 0x00000004 */
#define CANFD_RFSR_RI_3           (0x8UL << CANFD_RFSR_RI_Pos)                 /* 0x00000008 */
#define CANFD_RFSR_RI_4           (0x10UL << CANFD_RFSR_RI_Pos)                /* 0x00000010 */
#define CANFD_RFSR_RI_5           (0x20UL << CANFD_RFSR_RI_Pos)                /* 0x00000020 */

#define CANFD_RFSR_IRI_DPos       (7U)
#define CANFD_RFSR_IRI_Pos        CANFD_RFSR_IRI_DPos
#define CANFD_RFSR_IRI_Msk        (0x1UL << CANFD_RFSR_IRI_Pos)                /* 0x00000080 */
#define CANFD_RFSR_IRI            CANFD_RFSR_IRI_Msk                           /* RX FIFO Increment Read Index by 1. */

#define CANFD_RFSR_FL_DPos        (8U)
#define CANFD_RFSR_FL_Pos         CANFD_RFSR_FL_DPos
#define CANFD_RFSR_FL_Msk         (0x7FUL << CANFD_RFSR_FL_Pos)                /* 0x00003F00 */
#define CANFD_RFSR_FL             CANFD_RFSR_FL_Msk                            /* FL[5:0] bits (RX FIFO Fill Level (0 to 64).) */
#define CANFD_RFSR_FL_0           (0x1UL << CANFD_RFSR_FL_Pos)                 /* 0x00000100 */
#define CANFD_RFSR_FL_1           (0x2UL << CANFD_RFSR_FL_Pos)                 /* 0x00000200 */
#define CANFD_RFSR_FL_2           (0x4UL << CANFD_RFSR_FL_Pos)                 /* 0x00000400 */
#define CANFD_RFSR_FL_3           (0x8UL << CANFD_RFSR_FL_Pos)                 /* 0x00000800 */
#define CANFD_RFSR_FL_4           (0x10UL << CANFD_RFSR_FL_Pos)                /* 0x00001000 */
#define CANFD_RFSR_FL_5           (0x20UL << CANFD_RFSR_FL_Pos)                /* 0x00002000 */
#define CANFD_RFSR_FL_6           (0x40UL << CANFD_RFSR_FL_Pos)                /* 0x00004000 */

/******************  Bit definition for CANFD_TB_ID register  *****************/
#define CANFD_TB_ID_RTR_DPos      (0U)
#define CANFD_TB_ID_RTR_Pos       CANFD_TB_ID_RTR_DPos
#define CANFD_TB_ID_RTR_Msk       (0x1UL << CANFD_TB_ID_RTR_Pos)               /* 0x00000001 */
#define CANFD_TB_ID_RTR           CANFD_TB_ID_RTR_Msk                          /* Remote Transmission Request. */

#define CANFD_TB_ID_EM_ID_DPos    (1U)
#define CANFD_TB_ID_EM_ID_Pos     CANFD_TB_ID_EM_ID_DPos
#define CANFD_TB_ID_EM_ID_Msk     (0x3FFFFUL << CANFD_TB_ID_EM_ID_Pos)         /* 0x0007FFFE */
#define CANFD_TB_ID_EM_ID         CANFD_TB_ID_EM_ID_Msk                        /* ID[17:0] bits (Extended Message ID.) */
#define CANFD_TB_ID_EM_ID_0       (0x1UL << CANFD_TB_ID_EM_ID_Pos)             /* 0x00000002 */
#define CANFD_TB_ID_EM_ID_1       (0x2UL << CANFD_TB_ID_EM_ID_Pos)             /* 0x00000004 */
#define CANFD_TB_ID_EM_ID_2       (0x4UL << CANFD_TB_ID_EM_ID_Pos)             /* 0x00000008 */
#define CANFD_TB_ID_EM_ID_3       (0x8UL << CANFD_TB_ID_EM_ID_Pos)             /* 0x00000010 */
#define CANFD_TB_ID_EM_ID_4       (0x10UL << CANFD_TB_ID_EM_ID_Pos)            /* 0x00000020 */
#define CANFD_TB_ID_EM_ID_5       (0x20UL << CANFD_TB_ID_EM_ID_Pos)            /* 0x00000040 */
#define CANFD_TB_ID_EM_ID_6       (0x40UL << CANFD_TB_ID_EM_ID_Pos)            /* 0x00000080 */
#define CANFD_TB_ID_EM_ID_7       (0x80UL << CANFD_TB_ID_EM_ID_Pos)            /* 0x00000100 */
#define CANFD_TB_ID_EM_ID_8       (0x100UL << CANFD_TB_ID_EM_ID_Pos)           /* 0x00000200 */
#define CANFD_TB_ID_EM_ID_9       (0x200UL << CANFD_TB_ID_EM_ID_Pos)           /* 0x00000400 */
#define CANFD_TB_ID_EM_ID_10      (0x400UL << CANFD_TB_ID_EM_ID_Pos)           /* 0x00000800 */
#define CANFD_TB_ID_EM_ID_11      (0x800UL << CANFD_TB_ID_EM_ID_Pos)           /* 0x00001000 */
#define CANFD_TB_ID_EM_ID_12      (0x1000UL << CANFD_TB_ID_EM_ID_Pos)          /* 0x00002000 */
#define CANFD_TB_ID_EM_ID_13      (0x2000UL << CANFD_TB_ID_EM_ID_Pos)          /* 0x00004000 */
#define CANFD_TB_ID_EM_ID_14      (0x4000UL << CANFD_TB_ID_EM_ID_Pos)          /* 0x00008000 */
#define CANFD_TB_ID_EM_ID_15      (0x8000UL << CANFD_TB_ID_EM_ID_Pos)          /* 0x00010000 */
#define CANFD_TB_ID_EM_ID_16      (0x10000UL << CANFD_TB_ID_EM_ID_Pos)         /* 0x00020000 */
#define CANFD_TB_ID_EM_ID_17      (0x20000UL << CANFD_TB_ID_EM_ID_Pos)         /* 0x00040000 */

#define CANFD_TB_ID_IDE_DPos      (19U)
#define CANFD_TB_ID_IDE_Pos       CANFD_TB_ID_IDE_DPos
#define CANFD_TB_ID_IDE_Msk       (0x1UL << CANFD_TB_ID_IDE_Pos)               /* 0x00080000 */
#define CANFD_TB_ID_IDE           CANFD_TB_ID_IDE_Msk                          /* Identifier Extension. */

#define CANFD_TB_ID_SRR_DPos      (20U)
#define CANFD_TB_ID_SRR_Pos       CANFD_TB_ID_SRR_DPos
#define CANFD_TB_ID_SRR_Msk       (0x1UL << CANFD_TB_ID_SRR_Pos)               /* 0x00100000 */
#define CANFD_TB_ID_SRR           CANFD_TB_ID_SRR_Msk                          /* Substitute Remote Transmission Request. */

#define CANFD_TB_ID_ID_DPos       (21U)
#define CANFD_TB_ID_ID_Pos        CANFD_TB_ID_ID_DPos
#define CANFD_TB_ID_ID_Msk        (0x7FFUL << CANFD_TB_ID_ID_Pos)              /* 0xFFE00000 */
#define CANFD_TB_ID_ID            CANFD_TB_ID_ID_Msk                           /* ID[28:18] bits (Standard Message ID.) */
#define CANFD_TB_ID_ID_0          (0x1UL << CANFD_TB_ID_ID_Pos)                /* 0x00200000 */
#define CANFD_TB_ID_ID_1          (0x2UL << CANFD_TB_ID_ID_Pos)                /* 0x00400000 */
#define CANFD_TB_ID_ID_2          (0x4UL << CANFD_TB_ID_ID_Pos)                /* 0x00800000 */
#define CANFD_TB_ID_ID_3          (0x8UL << CANFD_TB_ID_ID_Pos)                /* 0x01000000 */
#define CANFD_TB_ID_ID_4          (0x10UL << CANFD_TB_ID_ID_Pos)               /* 0x02000000 */
#define CANFD_TB_ID_ID_5          (0x20UL << CANFD_TB_ID_ID_Pos)               /* 0x04000000 */
#define CANFD_TB_ID_ID_6          (0x40UL << CANFD_TB_ID_ID_Pos)               /* 0x08000000 */
#define CANFD_TB_ID_ID_7          (0x80UL << CANFD_TB_ID_ID_Pos)               /* 0x10000000 */
#define CANFD_TB_ID_ID_8          (0x100UL << CANFD_TB_ID_ID_Pos)              /* 0x20000000 */
#define CANFD_TB_ID_ID_9          (0x200UL << CANFD_TB_ID_ID_Pos)              /* 0x40000000 */
#define CANFD_TB_ID_ID_10         (0x400UL << CANFD_TB_ID_ID_Pos)              /* 0x80000000 */

/*****************  Bit definition for CANFD_TB_DLC register  *****************/
#define CANFD_TB_DLC_MM_DPos      (16U)
#define CANFD_TB_DLC_MM_Pos       CANFD_TB_DLC_MM_DPos
#define CANFD_TB_DLC_MM_Msk       (0xFFUL << CANFD_TB_DLC_MM_Pos)              /* 0x00FF0000 */
#define CANFD_TB_DLC_MM           CANFD_TB_DLC_MM_Msk                          /* MM[7:0] bits (Written by CPU during TX Buffer configuration.) */
#define CANFD_TB_DLC_MM_0         (0x1UL << CANFD_TB_DLC_MM_Pos)               /* 0x00010000 */
#define CANFD_TB_DLC_MM_1         (0x2UL << CANFD_TB_DLC_MM_Pos)               /* 0x00020000 */
#define CANFD_TB_DLC_MM_2         (0x4UL << CANFD_TB_DLC_MM_Pos)               /* 0x00040000 */
#define CANFD_TB_DLC_MM_3         (0x8UL << CANFD_TB_DLC_MM_Pos)               /* 0x00080000 */
#define CANFD_TB_DLC_MM_4         (0x10UL << CANFD_TB_DLC_MM_Pos)              /* 0x00100000 */
#define CANFD_TB_DLC_MM_5         (0x20UL << CANFD_TB_DLC_MM_Pos)              /* 0x00200000 */
#define CANFD_TB_DLC_MM_6         (0x40UL << CANFD_TB_DLC_MM_Pos)              /* 0x00400000 */
#define CANFD_TB_DLC_MM_7         (0x80UL << CANFD_TB_DLC_MM_Pos)              /* 0x00800000 */

#define CANFD_TB_DLC_EFC_DPos     (24U)
#define CANFD_TB_DLC_EFC_Pos      CANFD_TB_DLC_EFC_DPos
#define CANFD_TB_DLC_EFC_Msk      (0x1UL << CANFD_TB_DLC_EFC_Pos)              /* 0x01000000 */
#define CANFD_TB_DLC_EFC          CANFD_TB_DLC_EFC_Msk                         /* Event FIFO Control. */

#define CANFD_TB_DLC_BRS_DPos     (26U)
#define CANFD_TB_DLC_BRS_Pos      CANFD_TB_DLC_BRS_DPos
#define CANFD_TB_DLC_BRS_Msk      (0x1UL << CANFD_TB_DLC_BRS_Pos)              /* 0x04000000 */
#define CANFD_TB_DLC_BRS          CANFD_TB_DLC_BRS_Msk                         /* Bit Rate Switch */

#define CANFD_TB_DLC_EDL_DPos     (27U)
#define CANFD_TB_DLC_EDL_Pos      CANFD_TB_DLC_EDL_DPos
#define CANFD_TB_DLC_EDL_Msk      (0x1UL << CANFD_TB_DLC_EDL_Pos)              /* 0x08000000 */
#define CANFD_TB_DLC_EDL          CANFD_TB_DLC_EDL_Msk                         /* Extended Data Length/FD Frame Format. */

#define CANFD_TB_DLC_DLC_DPos     (28U)
#define CANFD_TB_DLC_DLC_Pos      CANFD_TB_DLC_DLC_DPos
#define CANFD_TB_DLC_DLC_Msk      (0xFUL << CANFD_TB_DLC_DLC_Pos)              /* 0xF0000000 */
#define CANFD_TB_DLC_DLC          CANFD_TB_DLC_DLC_Msk                         /* DLC[3:0] bits (Data Length Code.) */
#define CANFD_TB_DLC_DLC_0        (0x1UL << CANFD_TB_DLC_DLC_Pos)              /* 0x10000000 */
#define CANFD_TB_DLC_DLC_1        (0x2UL << CANFD_TB_DLC_DLC_Pos)              /* 0x20000000 */
#define CANFD_TB_DLC_DLC_2        (0x4UL << CANFD_TB_DLC_DLC_Pos)              /* 0x40000000 */
#define CANFD_TB_DLC_DLC_3        (0x8UL << CANFD_TB_DLC_DLC_Pos)              /* 0x80000000 */

/*****************  Bit definition for CANFD_TB_DW register  ******************/
#define CANFD_TB_DW_DB_DPos       (0U)
#define CANFD_TB_DW_DB_Pos        CANFD_TB_DW_DB_DPos
#define CANFD_TB_DW_DB_Msk        (0xFFUL << CANFD_TB_DW_DB_Pos)               /* 0x000000FF */
#define CANFD_TB_DW_DB            CANFD_TB_DW_DB_Msk                           /* Data bytes[7:0] bits (Data Byte.) */
#define CANFD_TB_DW_DB_0          (0x1UL << CANFD_TB_DW_DB_Pos)                /* 0x00000001 */
#define CANFD_TB_DW_DB_1          (0x2UL << CANFD_TB_DW_DB_Pos)                /* 0x00000002 */
#define CANFD_TB_DW_DB_2          (0x4UL << CANFD_TB_DW_DB_Pos)                /* 0x00000004 */
#define CANFD_TB_DW_DB_3          (0x8UL << CANFD_TB_DW_DB_Pos)                /* 0x00000008 */
#define CANFD_TB_DW_DB_4          (0x10UL << CANFD_TB_DW_DB_Pos)               /* 0x00000010 */
#define CANFD_TB_DW_DB_5          (0x20UL << CANFD_TB_DW_DB_Pos)               /* 0x00000020 */
#define CANFD_TB_DW_DB_6          (0x40UL << CANFD_TB_DW_DB_Pos)               /* 0x00000040 */
#define CANFD_TB_DW_DB_7          (0x80UL << CANFD_TB_DW_DB_Pos)               /* 0x00000080 */


/*******************  Bit definition for CANFD_AFMR register  *****************/
#define CANFD_AFMR_AMRTR_DPos     (0U)
#define CANFD_AFMR_AMRTR_Pos      CANFD_AFMR_AMRTR_DPos
#define CANFD_AFMR_AMRTR_Msk      (0x1UL << CANFD_AFMR_AMRTR_Pos)              /* 0x00000001 */
#define CANFD_AFMR_AMRTR          CANFD_AFMR_AMRTR_Msk                         /* Remote Transmission Request Mask. */

#define CANFD_AFMR_EM_AMID_DPos   (1U)
#define CANFD_AFMR_EM_AMID_Pos    CANFD_AFMR_EM_AMID_DPos
#define CANFD_AFMR_EM_AMID_Msk    (0x3FFFFUL << CANFD_AFMR_EM_AMID_Pos)        /* 0x0007FFFE */
#define CANFD_AFMR_EM_AMID        CANFD_AFMR_EM_AMID_Msk                       /* AMID[17:0] bits (Extended Message ID Mask) */
#define CANFD_AFMR_EM_AMID_0      (0x1UL << CANFD_AFMR_EM_AMID_Pos)            /* 0x00000002 */
#define CANFD_AFMR_EM_AMID_1      (0x2UL << CANFD_AFMR_EM_AMID_Pos)            /* 0x00000004 */
#define CANFD_AFMR_EM_AMID_2      (0x4UL << CANFD_AFMR_EM_AMID_Pos)            /* 0x00000008 */
#define CANFD_AFMR_EM_AMID_3      (0x8UL << CANFD_AFMR_EM_AMID_Pos)            /* 0x00000010 */
#define CANFD_AFMR_EM_AMID_4      (0x10UL << CANFD_AFMR_EM_AMID_Pos)           /* 0x00000020 */
#define CANFD_AFMR_EM_AMID_5      (0x20UL << CANFD_AFMR_EM_AMID_Pos)           /* 0x00000040 */
#define CANFD_AFMR_EM_AMID_6      (0x40UL << CANFD_AFMR_EM_AMID_Pos)           /* 0x00000080 */
#define CANFD_AFMR_EM_AMID_7      (0x80UL << CANFD_AFMR_EM_AMID_Pos)           /* 0x00000100 */
#define CANFD_AFMR_EM_AMID_8      (0x100UL << CANFD_AFMR_EM_AMID_Pos)          /* 0x00000200 */
#define CANFD_AFMR_EM_AMID_9      (0x200UL << CANFD_AFMR_EM_AMID_Pos)          /* 0x00000400 */
#define CANFD_AFMR_EM_AMID_10     (0x400UL << CANFD_AFMR_EM_AMID_Pos)          /* 0x00000800 */
#define CANFD_AFMR_EM_AMID_11     (0x800UL << CANFD_AFMR_EM_AMID_Pos)          /* 0x00001000 */
#define CANFD_AFMR_EM_AMID_12     (0x1000UL << CANFD_AFMR_EM_AMID_Pos)         /* 0x00002000 */
#define CANFD_AFMR_EM_AMID_13     (0x2000UL << CANFD_AFMR_EM_AMID_Pos)         /* 0x00004000 */
#define CANFD_AFMR_EM_AMID_14     (0x4000UL << CANFD_AFMR_EM_AMID_Pos)         /* 0x00008000 */
#define CANFD_AFMR_EM_AMID_15     (0x8000UL << CANFD_AFMR_EM_AMID_Pos)         /* 0x00010000 */
#define CANFD_AFMR_EM_AMID_16     (0x10000UL << CANFD_AFMR_EM_AMID_Pos)        /* 0x00020000 */
#define CANFD_AFMR_EM_AMID_17     (0x20000UL << CANFD_AFMR_EM_AMID_Pos)        /* 0x00040000 */

#define CANFD_AFMR_AMIDE_DPos     (19U)
#define CANFD_AFMR_AMIDE_Pos      CANFD_AFMR_AMIDE_DPos
#define CANFD_AFMR_AMIDE_Msk      (0x1UL << CANFD_AFMR_AMIDE_Pos)              /* 0x00080000 */
#define CANFD_AFMR_AMIDE          CANFD_AFMR_AMIDE_Msk                         /* Identifier Extension Mask */

#define CANFD_AFMR_AMSRR_DPos     (20U)
#define CANFD_AFMR_AMSRR_Pos      CANFD_AFMR_AMSRR_DPos
#define CANFD_AFMR_AMSRR_Msk      (0x1UL << CANFD_AFMR_AMSRR_Pos)              /* 0x00100000 */
#define CANFD_AFMR_AMSRR          CANFD_AFMR_AMSRR_Msk                         /* Substitute Remote Transmission Request Mask. */

#define CANFD_AFMR_AMID_DPos      (21U)
#define CANFD_AFMR_AMID_Pos       CANFD_AFMR_AMID_DPos
#define CANFD_AFMR_AMID_Msk       (0x7FFUL << CANFD_AFMR_AMID_Pos)             /* 0xFFE00000 */
#define CANFD_AFMR_AMID           CANFD_AFMR_AMID_Msk                          /* AMID[28:18] bits (Standard Message ID Mask .) */
#define CANFD_AFMR_AMID_0         (0x1UL << CANFD_AFMR_AMID_Pos)               /* 0x00200000 */
#define CANFD_AFMR_AMID_1         (0x2UL << CANFD_AFMR_AMID_Pos)               /* 0x00400000 */
#define CANFD_AFMR_AMID_2         (0x4UL << CANFD_AFMR_AMID_Pos)               /* 0x00800000 */
#define CANFD_AFMR_AMID_3         (0x8UL << CANFD_AFMR_AMID_Pos)               /* 0x01000000 */
#define CANFD_AFMR_AMID_4         (0x10UL << CANFD_AFMR_AMID_Pos)              /* 0x02000000 */
#define CANFD_AFMR_AMID_5         (0x20UL << CANFD_AFMR_AMID_Pos)              /* 0x04000000 */
#define CANFD_AFMR_AMID_6         (0x40UL << CANFD_AFMR_AMID_Pos)              /* 0x08000000 */
#define CANFD_AFMR_AMID_7         (0x80UL << CANFD_AFMR_AMID_Pos)              /* 0x10000000 */
#define CANFD_AFMR_AMID_8         (0x100UL << CANFD_AFMR_AMID_Pos)             /* 0x20000000 */
#define CANFD_AFMR_AMID_9         (0x200UL << CANFD_AFMR_AMID_Pos)             /* 0x40000000 */
#define CANFD_AFMR_AMID_10        (0x400UL << CANFD_AFMR_AMID_Pos)             /* 0x80000000 */

/*******************  Bit definition for CANFD_AFIR register  *****************/
#define CANFD_AFIR_AIRTR_DPos     (0U)
#define CANFD_AFIR_AIRTR_Pos      CANFD_AFIR_AIRTR_DPos
#define CANFD_AFIR_AIRTR_Msk      (0x1UL << CANFD_AFIR_AIRTR_Pos)              /* 0x00000001 */
#define CANFD_AFIR_AIRTR          CANFD_AFIR_AIRTR_Msk                         /* Remote Transmission Request. */

#define CANFD_AFIR_EM_AIID_DPos   (1U)
#define CANFD_AFIR_EM_AIID_Pos    CANFD_AFIR_EM_AIID_DPos
#define CANFD_AFIR_EM_AIID_Msk    (0x3FFFFUL << CANFD_AFIR_EM_AIID_Pos)        /* 0x0007FFFE */
#define CANFD_AFIR_EM_AIID        CANFD_AFIR_EM_AIID_Msk                       /* AIID[17:0] bits (Extended Message ID.) */
#define CANFD_AFIR_EM_AIID_0      (0x1UL << CANFD_AFIR_EM_AIID_Pos)            /* 0x00000002 */
#define CANFD_AFIR_EM_AIID_1      (0x2UL << CANFD_AFIR_EM_AIID_Pos)            /* 0x00000004 */
#define CANFD_AFIR_EM_AIID_2      (0x4UL << CANFD_AFIR_EM_AIID_Pos)            /* 0x00000008 */
#define CANFD_AFIR_EM_AIID_3      (0x8UL << CANFD_AFIR_EM_AIID_Pos)            /* 0x00000010 */
#define CANFD_AFIR_EM_AIID_4      (0x10UL << CANFD_AFIR_EM_AIID_Pos)           /* 0x00000020 */
#define CANFD_AFIR_EM_AIID_5      (0x20UL << CANFD_AFIR_EM_AIID_Pos)           /* 0x00000040 */
#define CANFD_AFIR_EM_AIID_6      (0x40UL << CANFD_AFIR_EM_AIID_Pos)           /* 0x00000080 */
#define CANFD_AFIR_EM_AIID_7      (0x80UL << CANFD_AFIR_EM_AIID_Pos)           /* 0x00000100 */
#define CANFD_AFIR_EM_AIID_8      (0x100UL << CANFD_AFIR_EM_AIID_Pos)          /* 0x00000200 */
#define CANFD_AFIR_EM_AIID_9      (0x200UL << CANFD_AFIR_EM_AIID_Pos)          /* 0x00000400 */
#define CANFD_AFIR_EM_AIID_10     (0x400UL << CANFD_AFIR_EM_AIID_Pos)          /* 0x00000800 */
#define CANFD_AFIR_EM_AIID_11     (0x800UL << CANFD_AFIR_EM_AIID_Pos)          /* 0x00001000 */
#define CANFD_AFIR_EM_AIID_12     (0x1000UL << CANFD_AFIR_EM_AIID_Pos)         /* 0x00002000 */
#define CANFD_AFIR_EM_AIID_13     (0x2000UL << CANFD_AFIR_EM_AIID_Pos)         /* 0x00004000 */
#define CANFD_AFIR_EM_AIID_14     (0x4000UL << CANFD_AFIR_EM_AIID_Pos)         /* 0x00008000 */
#define CANFD_AFIR_EM_AIID_15     (0x8000UL << CANFD_AFIR_EM_AIID_Pos)         /* 0x00010000 */
#define CANFD_AFIR_EM_AIID_16     (0x10000UL << CANFD_AFIR_EM_AIID_Pos)        /* 0x00020000 */
#define CANFD_AFIR_EM_AIID_17     (0x20000UL << CANFD_AFIR_EM_AIID_Pos)        /* 0x00040000 */

#define CANFD_AFIR_AIIDE_DPos     (19U)
#define CANFD_AFIR_AIIDE_Pos      CANFD_AFIR_AIIDE_DPos
#define CANFD_AFIR_AIIDE_Msk      (0x1UL << CANFD_AFIR_AIIDE_Pos)              /* 0x00080000 */
#define CANFD_AFIR_AIIDE          CANFD_AFIR_AIIDE_Msk                         /* Identifier Extension. */

#define CANFD_AFIR_AISRR_DPos     (20U)
#define CANFD_AFIR_AISRR_Pos      CANFD_AFIR_AISRR_DPos
#define CANFD_AFIR_AISRR_Msk      (0x1UL << CANFD_AFIR_AISRR_Pos)              /* 0x00100000 */
#define CANFD_AFIR_AISRR          CANFD_AFIR_AISRR_Msk                         /* Substitute Remote Transmission Request. */

#define CANFD_AFIR_AIID_DPos      (21U)
#define CANFD_AFIR_AIID_Pos       CANFD_AFIR_AIID_DPos
#define CANFD_AFIR_AIID_Msk       (0x7FFUL << CANFD_AFIR_AIID_Pos)             /* 0xFFE00000 */
#define CANFD_AFIR_AIID           CANFD_AFIR_AIID_Msk                          /* AIID[28:18] bits (Standard Message ID.) */
#define CANFD_AFIR_AIID_0         (0x1UL << CANFD_AFIR_AIID_Pos)               /* 0x00200000 */
#define CANFD_AFIR_AIID_1         (0x2UL << CANFD_AFIR_AIID_Pos)               /* 0x00400000 */
#define CANFD_AFIR_AIID_2         (0x4UL << CANFD_AFIR_AIID_Pos)               /* 0x00800000 */
#define CANFD_AFIR_AIID_3         (0x8UL << CANFD_AFIR_AIID_Pos)               /* 0x01000000 */
#define CANFD_AFIR_AIID_4         (0x10UL << CANFD_AFIR_AIID_Pos)              /* 0x02000000 */
#define CANFD_AFIR_AIID_5         (0x20UL << CANFD_AFIR_AIID_Pos)              /* 0x04000000 */
#define CANFD_AFIR_AIID_6         (0x40UL << CANFD_AFIR_AIID_Pos)              /* 0x08000000 */
#define CANFD_AFIR_AIID_7         (0x80UL << CANFD_AFIR_AIID_Pos)              /* 0x10000000 */
#define CANFD_AFIR_AIID_8         (0x100UL << CANFD_AFIR_AIID_Pos)             /* 0x20000000 */
#define CANFD_AFIR_AIID_9         (0x200UL << CANFD_AFIR_AIID_Pos)             /* 0x40000000 */
#define CANFD_AFIR_AIID_10        (0x400UL << CANFD_AFIR_AIID_Pos)             /* 0x80000000 */

/******************  Bit definition for CANFD_RB_ID register  *****************/
#define CANFD_RB_ID_RTR_DPos      (0U)
#define CANFD_RB_ID_RTR_Pos       CANFD_RB_ID_RTR_DPos
#define CANFD_RB_ID_RTR_Msk       (0x1UL << CANFD_RB_ID_RTR_Pos)               /* 0x00000001 */
#define CANFD_RB_ID_RTR           CANFD_RB_ID_RTR_Msk                          /* Remote Transmission Request. */

#define CANFD_RB_ID_EM_ID_DPos    (1U)
#define CANFD_RB_ID_EM_ID_Pos     CANFD_RB_ID_EM_ID_DPos
#define CANFD_RB_ID_EM_ID_Msk     (0x3FFFFUL << CANFD_RB_ID_EM_ID_Pos)         /* 0x0007FFFE */
#define CANFD_RB_ID_EM_ID         CANFD_RB_ID_EM_ID_Msk                        /* ID[17:0] bits (Extended Message ID.) */
#define CANFD_RB_ID_EM_ID_0       (0x1UL << CANFD_RB_ID_EM_ID_Pos)             /* 0x00000002 */
#define CANFD_RB_ID_EM_ID_1       (0x2UL << CANFD_RB_ID_EM_ID_Pos)             /* 0x00000004 */
#define CANFD_RB_ID_EM_ID_2       (0x4UL << CANFD_RB_ID_EM_ID_Pos)             /* 0x00000008 */
#define CANFD_RB_ID_EM_ID_3       (0x8UL << CANFD_RB_ID_EM_ID_Pos)             /* 0x00000010 */
#define CANFD_RB_ID_EM_ID_4       (0x10UL << CANFD_RB_ID_EM_ID_Pos)            /* 0x00000020 */
#define CANFD_RB_ID_EM_ID_5       (0x20UL << CANFD_RB_ID_EM_ID_Pos)            /* 0x00000040 */
#define CANFD_RB_ID_EM_ID_6       (0x40UL << CANFD_RB_ID_EM_ID_Pos)            /* 0x00000080 */
#define CANFD_RB_ID_EM_ID_7       (0x80UL << CANFD_RB_ID_EM_ID_Pos)            /* 0x00000100 */
#define CANFD_RB_ID_EM_ID_8       (0x100UL << CANFD_RB_ID_EM_ID_Pos)           /* 0x00000200 */
#define CANFD_RB_ID_EM_ID_9       (0x200UL << CANFD_RB_ID_EM_ID_Pos)           /* 0x00000400 */
#define CANFD_RB_ID_EM_ID_10      (0x400UL << CANFD_RB_ID_EM_ID_Pos)           /* 0x00000800 */
#define CANFD_RB_ID_EM_ID_11      (0x800UL << CANFD_RB_ID_EM_ID_Pos)           /* 0x00001000 */
#define CANFD_RB_ID_EM_ID_12      (0x1000UL << CANFD_RB_ID_EM_ID_Pos)          /* 0x00002000 */
#define CANFD_RB_ID_EM_ID_13      (0x2000UL << CANFD_RB_ID_EM_ID_Pos)          /* 0x00004000 */
#define CANFD_RB_ID_EM_ID_14      (0x4000UL << CANFD_RB_ID_EM_ID_Pos)          /* 0x00008000 */
#define CANFD_RB_ID_EM_ID_15      (0x8000UL << CANFD_RB_ID_EM_ID_Pos)          /* 0x00010000 */
#define CANFD_RB_ID_EM_ID_16      (0x10000UL << CANFD_RB_ID_EM_ID_Pos)         /* 0x00020000 */
#define CANFD_RB_ID_EM_ID_17      (0x20000UL << CANFD_RB_ID_EM_ID_Pos)         /* 0x00040000 */
#define CANFD_RB_ID_IDE_DPos      (19U)
#define CANFD_RB_ID_IDE_Pos       CANFD_RB_ID_IDE_DPos
#define CANFD_RB_ID_IDE_Msk       (0x1UL << CANFD_RB_ID_IDE_Pos)               /* 0x00080000 */
#define CANFD_RB_ID_IDE           CANFD_RB_ID_IDE_Msk                          /* Identifier Extension. */
#define CANFD_RB_ID_SRR_DPos      (20U)
#define CANFD_RB_ID_SRR_Pos       CANFD_RB_ID_SRR_DPos
#define CANFD_RB_ID_SRR_Msk       (0x1UL << CANFD_RB_ID_SRR_Pos)               /* 0x00100000 */
#define CANFD_RB_ID_SRR           CANFD_RB_ID_SRR_Msk                          /* Substitute Remote Transmission Request. */
#define CANFD_RB_ID_ID_DPos       (21U)
#define CANFD_RB_ID_ID_Pos        CANFD_RB_ID_ID_DPos
#define CANFD_RB_ID_ID_Msk        (0x7FFUL << CANFD_RB_ID_ID_Pos)              /* 0xFFE00000 */
#define CANFD_RB_ID_ID            CANFD_RB_ID_ID_Msk                           /* ID[28:18] bits (Standard Message ID.) */
#define CANFD_RB_ID_ID_0          (0x1UL << CANFD_RB_ID_ID_Pos)                /* 0x00200000 */
#define CANFD_RB_ID_ID_1          (0x2UL << CANFD_RB_ID_ID_Pos)                /* 0x00400000 */
#define CANFD_RB_ID_ID_2          (0x4UL << CANFD_RB_ID_ID_Pos)                /* 0x00800000 */
#define CANFD_RB_ID_ID_3          (0x8UL << CANFD_RB_ID_ID_Pos)                /* 0x01000000 */
#define CANFD_RB_ID_ID_4          (0x10UL << CANFD_RB_ID_ID_Pos)               /* 0x02000000 */
#define CANFD_RB_ID_ID_5          (0x20UL << CANFD_RB_ID_ID_Pos)               /* 0x04000000 */
#define CANFD_RB_ID_ID_6          (0x40UL << CANFD_RB_ID_ID_Pos)               /* 0x08000000 */
#define CANFD_RB_ID_ID_7          (0x80UL << CANFD_RB_ID_ID_Pos)               /* 0x10000000 */
#define CANFD_RB_ID_ID_8          (0x100UL << CANFD_RB_ID_ID_Pos)              /* 0x20000000 */
#define CANFD_RB_ID_ID_9          (0x200UL << CANFD_RB_ID_ID_Pos)              /* 0x40000000 */
#define CANFD_RB_ID_ID_10         (0x400UL << CANFD_RB_ID_ID_Pos)              /* 0x80000000 */

/*****************  Bit definition for CANFD_RB_DLC register  *****************/
#define CANFD_RB_DLC_TS_DPos      (0U)
#define CANFD_RB_DLC_TS_Pos       CANFD_RB_DLC_TS_DPos
#define CANFD_RB_DLC_TS_Msk       (0xFFFFUL << CANFD_RB_DLC_TS_Pos)            /* 0x0000FFFF */
#define CANFD_RB_DLC_TS           CANFD_RB_DLC_TS_Msk                          /* Timestamp[15:0] bits (Timestamp captured after SOF bit.) */
#define CANFD_RB_DLC_TS_0         (0x1UL << CANFD_RB_DLC_TS_Pos)               /* 0x00000001 */
#define CANFD_RB_DLC_TS_1         (0x2UL << CANFD_RB_DLC_TS_Pos)               /* 0x00000002 */
#define CANFD_RB_DLC_TS_2         (0x4UL << CANFD_RB_DLC_TS_Pos)               /* 0x00000004 */
#define CANFD_RB_DLC_TS_3         (0x8UL << CANFD_RB_DLC_TS_Pos)               /* 0x00000008 */
#define CANFD_RB_DLC_TS_4         (0x10UL << CANFD_RB_DLC_TS_Pos)              /* 0x00000010 */
#define CANFD_RB_DLC_TS_5         (0x20UL << CANFD_RB_DLC_TS_Pos)              /* 0x00000020 */
#define CANFD_RB_DLC_TS_6         (0x40UL << CANFD_RB_DLC_TS_Pos)              /* 0x00000040 */
#define CANFD_RB_DLC_TS_7         (0x80UL << CANFD_RB_DLC_TS_Pos)              /* 0x00000080 */
#define CANFD_RB_DLC_TS_8         (0x100UL << CANFD_RB_DLC_TS_Pos)             /* 0x00000100 */
#define CANFD_RB_DLC_TS_9         (0x200UL << CANFD_RB_DLC_TS_Pos)             /* 0x00000200 */
#define CANFD_RB_DLC_TS_10        (0x400UL << CANFD_RB_DLC_TS_Pos)             /* 0x00000400 */
#define CANFD_RB_DLC_TS_11        (0x800UL << CANFD_RB_DLC_TS_Pos)             /* 0x00000800 */
#define CANFD_RB_DLC_TS_12        (0x1000UL << CANFD_RB_DLC_TS_Pos)            /* 0x00001000 */
#define CANFD_RB_DLC_TS_13        (0x2000UL << CANFD_RB_DLC_TS_Pos)            /* 0x00002000 */
#define CANFD_RB_DLC_TS_14        (0x4000UL << CANFD_RB_DLC_TS_Pos)            /* 0x00004000 */
#define CANFD_RB_DLC_TS_15        (0x8000UL << CANFD_RB_DLC_TS_Pos)            /* 0x00008000 */

#define CANFD_RB_DLC_MFI_DPos     (16U)
#define CANFD_RB_DLC_MFI_Pos      CANFD_RB_DLC_MFI_DPos
#define CANFD_RB_DLC_MFI_Msk      (0x1FUL << CANFD_RB_DLC_MFI_Pos)             /* 0x001F0000 */
#define CANFD_RB_DLC_MFI          CANFD_RB_DLC_MFI_Msk                         /* Matched_Filter_Index[4:0] bits (provide the matched filter index for received message.) */
#define CANFD_RB_DLC_MFI_0        (0x1UL << CANFD_RB_DLC_MFI_Pos)              /* 0x00010000 */
#define CANFD_RB_DLC_MFI_1        (0x2UL << CANFD_RB_DLC_MFI_Pos)              /* 0x00020000 */
#define CANFD_RB_DLC_MFI_2        (0x4UL << CANFD_RB_DLC_MFI_Pos)              /* 0x00040000 */
#define CANFD_RB_DLC_MFI_3        (0x8UL << CANFD_RB_DLC_MFI_Pos)              /* 0x00080000 */
#define CANFD_RB_DLC_MFI_4        (0x10UL << CANFD_RB_DLC_MFI_Pos)             /* 0x00100000 */

#define CANFD_RB_DLC_ESI_DPos     (25U)
#define CANFD_RB_DLC_ESI_Pos      CANFD_RB_DLC_ESI_DPos
#define CANFD_RB_DLC_ESI_Msk      (0x1UL << CANFD_RB_DLC_ESI_Pos)              /* 0x02000000 */
#define CANFD_RB_DLC_ESI          CANFD_RB_DLC_ESI_Msk                         /* Error State Indicator. */

#define CANFD_RB_DLC_BRS_DPos     (26U)
#define CANFD_RB_DLC_BRS_Pos      CANFD_RB_DLC_BRS_DPos
#define CANFD_RB_DLC_BRS_Msk      (0x1UL << CANFD_RB_DLC_BRS_Pos)              /* 0x04000000 */
#define CANFD_RB_DLC_BRS          CANFD_RB_DLC_BRS_Msk                         /* Bit Rate Switch */

#define CANFD_RB_DLC_EDL_DPos     (27U)
#define CANFD_RB_DLC_EDL_Pos      CANFD_RB_DLC_EDL_DPos
#define CANFD_RB_DLC_EDL_Msk      (0x1UL << CANFD_RB_DLC_EDL_Pos)              /* 0x08000000 */
#define CANFD_RB_DLC_EDL          CANFD_RB_DLC_EDL_Msk                         /* Extended Data Length/FD Frame Format. */


#define CANFD_RB_DLC_DLC_DPos     (28U)
#define CANFD_RB_DLC_DLC_Pos      CANFD_RB_DLC_DLC_DPos
#define CANFD_RB_DLC_DLC_Msk      (0xFUL << CANFD_RB_DLC_DLC_Pos)              /* 0xF0000000 */
#define CANFD_RB_DLC_DLC          CANFD_RB_DLC_DLC_Msk                         /* DLC[3:0] bits (Data Length Code.) */
#define CANFD_RB_DLC_DLC_0        (0x1UL << CANFD_RB_DLC_DLC_Pos)              /* 0x10000000 */
#define CANFD_RB_DLC_DLC_1        (0x2UL << CANFD_RB_DLC_DLC_Pos)              /* 0x20000000 */
#define CANFD_RB_DLC_DLC_2        (0x4UL << CANFD_RB_DLC_DLC_Pos)              /* 0x40000000 */
#define CANFD_RB_DLC_DLC_3        (0x8UL << CANFD_RB_DLC_DLC_Pos)              /* 0x80000000 */

/*****************  Bit definition for CANFD_RB_DW register  ******************/
#define CANFD_RB_DW_DB_DPos       (0U)
#define CANFD_RB_DW_DB_Pos        CANFD_RB_DW_DB_DPos
#define CANFD_RB_DW_DB_Msk        (0xFFUL << CANFD_RB_DW_DB_Pos)               /* 0x000000FF */
#define CANFD_RB_DW_DB            CANFD_RB_DW_DB_Msk                           /* Data bytes[7:0] bits (Data Byte.) */
#define CANFD_RB_DW_DB_0          (0x1UL << CANFD_RB_DW_DB_Pos)                /* 0x00000001 */
#define CANFD_RB_DW_DB_1          (0x2UL << CANFD_RB_DW_DB_Pos)                /* 0x00000002 */
#define CANFD_RB_DW_DB_2          (0x4UL << CANFD_RB_DW_DB_Pos)                /* 0x00000004 */
#define CANFD_RB_DW_DB_3          (0x8UL << CANFD_RB_DW_DB_Pos)                /* 0x00000008 */
#define CANFD_RB_DW_DB_4          (0x10UL << CANFD_RB_DW_DB_Pos)               /* 0x00000010 */
#define CANFD_RB_DW_DB_5          (0x20UL << CANFD_RB_DW_DB_Pos)               /* 0x00000020 */
#define CANFD_RB_DW_DB_6          (0x40UL << CANFD_RB_DW_DB_Pos)               /* 0x00000040 */
#define CANFD_RB_DW_DB_7          (0x80UL << CANFD_RB_DW_DB_Pos)               /* 0x00000080 */

/* @name ADC register bits definition */
/******************  Bit definition for ADC_STATE register  *******************/
#define ADC_STATE_AMO_DPos        (0U)
#define ADC_STATE_AMO_Pos         ADC_STATE_AMO_DPos
#define ADC_STATE_AMO_Msk         (0x1UL << ADC_STATE_AMO_Pos)                  /* 0x00000001 */
#define ADC_STATE_AMO             ADC_STATE_AMO_Msk                             /* Analog monitor event occurs */

#define ADC_STATE_IDLE_DPos       (1U)
#define ADC_STATE_IDLE_Pos        ADC_STATE_IDLE_DPos
#define ADC_STATE_IDLE_Msk        (0x1UL << ADC_STATE_IDLE_Pos)                 /* 0x00000002 */
#define ADC_STATE_IDLE            ADC_STATE_IDLE_Msk                            /* ADC idle state flag */

#define ADC_STATE_CONVCFT_DPos    (2U)
#define ADC_STATE_CONVCFT_Pos     ADC_STATE_CONVCFT_DPos
#define ADC_STATE_CONVCFT_Msk     (0x1UL << ADC_STATE_CONVCFT_Pos)              /* 0x00000004 */
#define ADC_STATE_CONVCFT         ADC_STATE_CONVCFT_Msk                         /* Convert trigger conflict status */

/******************  Bit definition for ADC_CTRL0 register  *******************/
#define ADC_CTRL0_IAUTO_DPos      (0U)
#define ADC_CTRL0_IAUTO_Pos       ADC_CTRL0_IAUTO_DPos
#define ADC_CTRL0_IAUTO_Msk       (0x1UL << ADC_CTRL0_IAUTO_Pos)                /* 0x00000001 */
#define ADC_CTRL0_IAUTO           ADC_CTRL0_IAUTO_Msk                           /* ADC IAUTO operation mode */

#define ADC_CTRL0_IDISCEN_DPos    (1U)
#define ADC_CTRL0_IDISCEN_Pos     ADC_CTRL0_IDISCEN_DPos
#define ADC_CTRL0_IDISCEN_Msk     (0x1UL << ADC_CTRL0_IDISCEN_Pos)              /* 0x00000002 */
#define ADC_CTRL0_IDISCEN         ADC_CTRL0_IDISCEN_Msk                         /* ADC IDISCEN operation mode */

#define ADC_CTRL0_DISCEN_DPos     (2U)
#define ADC_CTRL0_DISCEN_Pos      ADC_CTRL0_DISCEN_DPos
#define ADC_CTRL0_DISCEN_Msk      (0x1UL << ADC_CTRL0_DISCEN_Pos)               /* 0x00000004 */
#define ADC_CTRL0_DISCEN          ADC_CTRL0_DISCEN_Msk                          /* ADC DISCEN operation mode */

#define ADC_CTRL0_CONT_DPos       (3U)
#define ADC_CTRL0_CONT_Pos        ADC_CTRL0_CONT_DPos
#define ADC_CTRL0_CONT_Msk        (0x1UL << ADC_CTRL0_CONT_Pos)                 /* 0x00000008 */
#define ADC_CTRL0_CONT            ADC_CTRL0_CONT_Msk                            /* ADC CONT operation mode */

#define ADC_CTRL0_SCAN_DPos       (4U)
#define ADC_CTRL0_SCAN_Pos        ADC_CTRL0_SCAN_DPos
#define ADC_CTRL0_SCAN_Msk        (0x1UL << ADC_CTRL0_SCAN_Pos)                 /* 0x00000010 */
#define ADC_CTRL0_SCAN            ADC_CTRL0_SCAN_Msk                            /* ADC SCAN operation mode */

#define ADC_CTRL0_INTERVAL_DPos   (5U)
#define ADC_CTRL0_INTERVAL_Pos    ADC_CTRL0_INTERVAL_DPos
#define ADC_CTRL0_INTERVAL_Msk    (0x1UL << ADC_CTRL0_INTERVAL_Pos)             /* 0x00000020 */
#define ADC_CTRL0_INTERVAL        ADC_CTRL0_INTERVAL_Msk                        /* Interval mode */

#define ADC_CTRL0_DISCNUM_DPos    (6U)
#define ADC_CTRL0_DISCNUM_Pos     ADC_CTRL0_DISCNUM_DPos
#define ADC_CTRL0_DISCNUM_Msk     (0x7UL << ADC_CTRL0_DISCNUM_Pos)              /* 0x000001C0 */
#define ADC_CTRL0_DISCNUM         ADC_CTRL0_DISCNUM_Msk                         /* DISCNUM[2:0] bits (Discontinuous conversion length of channel)*/
#define ADC_CTRL0_DISCNUM_0       (0x1UL << ADC_CTRL0_DISCNUM_Pos)              /* 0x00000040 */
#define ADC_CTRL0_DISCNUM_1       (0x2UL << ADC_CTRL0_DISCNUM_Pos)              /* 0x00000080 */
#define ADC_CTRL0_DISCNUM_2       (0x4UL << ADC_CTRL0_DISCNUM_Pos)              /* 0x00000100 */

#define ADC_CTRL0_ALIGN_DPos      (9U)
#define ADC_CTRL0_ALIGN_Pos       ADC_CTRL0_ALIGN_DPos
#define ADC_CTRL0_ALIGN_Msk       (0x1UL << ADC_CTRL0_ALIGN_Pos)                /* 0x00000200 */
#define ADC_CTRL0_ALIGN           ADC_CTRL0_ALIGN_Msk                           /* Data alignment */

#define ADC_CTRL0_SELDO_DPos      (10U)
#define ADC_CTRL0_SELDO_Pos       ADC_CTRL0_SELDO_DPos
#define ADC_CTRL0_SELDO_Msk       (0x1UL << ADC_CTRL0_SELDO_Pos)                /* 0x00000400 */
#define ADC_CTRL0_SELDO           ADC_CTRL0_SELDO_Msk                           /* data type selection */

#define ADC_CTRL0_DMAEN_DPos      (11U)
#define ADC_CTRL0_DMAEN_Pos       ADC_CTRL0_DMAEN_DPos
#define ADC_CTRL0_DMAEN_Msk       (0x1UL << ADC_CTRL0_DMAEN_Pos)                /* 0x00000800 */
#define ADC_CTRL0_DMAEN           ADC_CTRL0_DMAEN_Msk                           /* DMA function enable */

#define ADC_CTRL0_TRIGEN_DPos     (16U)
#define ADC_CTRL0_TRIGEN_Pos      ADC_CTRL0_TRIGEN_DPos
#define ADC_CTRL0_TRIGEN_Msk      (0x1UL << ADC_CTRL0_TRIGEN_Pos)               /* 0x00010000 */
#define ADC_CTRL0_TRIGEN          ADC_CTRL0_TRIGEN_Msk                          /* Regular group trigger enable */

#define ADC_CTRL0_SWSTART_DPos    (17U)
#define ADC_CTRL0_SWSTART_Pos     ADC_CTRL0_SWSTART_DPos
#define ADC_CTRL0_SWSTART_Msk     (0x1UL << ADC_CTRL0_SWSTART_Pos)              /* 0x00020000 */
#define ADC_CTRL0_SWSTART         ADC_CTRL0_SWSTART_Msk                         /* Software trigger for regular channels */

#define ADC_CTRL0_TRIGSRC_DPos    (18U)
#define ADC_CTRL0_TRIGSRC_Pos     ADC_CTRL0_TRIGSRC_DPos
#define ADC_CTRL0_TRIGSRC_Msk     (0x3FUL << ADC_CTRL0_TRIGSRC_Pos)             /* 0x00FC0000 */
#define ADC_CTRL0_TRIGSRC         ADC_CTRL0_TRIGSRC_Msk                         /* TRIGSRC[5:0] bits (Regular group trigger source select)*/
#define ADC_CTRL0_TRIGSRC_0       (0x1UL << ADC_CTRL0_DISCNUM_Pos)              /* 0x00040000 */
#define ADC_CTRL0_TRIGSRC_1       (0x2UL << ADC_CTRL0_DISCNUM_Pos)              /* 0x00080000 */
#define ADC_CTRL0_TRIGSRC_2       (0x4UL << ADC_CTRL0_DISCNUM_Pos)              /* 0x00100000 */
#define ADC_CTRL0_TRIGSRC_3       (0x8UL << ADC_CTRL0_DISCNUM_Pos)              /* 0x00200000 */
#define ADC_CTRL0_TRIGSRC_4       (0x10UL << ADC_CTRL0_DISCNUM_Pos)             /* 0x00400000 */
#define ADC_CTRL0_TRIGSRC_5       (0x20UL << ADC_CTRL0_DISCNUM_Pos)             /* 0x00800000 */

#define ADC_CTRL0_ITRIGEN_DPos    (24U)
#define ADC_CTRL0_ITRIGEN_Pos     ADC_CTRL0_ITRIGEN_DPos
#define ADC_CTRL0_ITRIGEN_Msk     (0x1UL << ADC_CTRL0_ITRIGEN_Pos)              /* 0x01000000 */
#define ADC_CTRL0_ITRIGEN         ADC_CTRL0_ITRIGEN_Msk                         /* Injection group trigger enable */

#define ADC_CTRL0_ISWSTART_DPos   (25U)
#define ADC_CTRL0_ISWSTART_Pos    ADC_CTRL0_ISWSTART_DPos
#define ADC_CTRL0_ISWSTART_Msk    (0x1UL << ADC_CTRL0_ISWSTART_Pos)             /* 0x02000000 */
#define ADC_CTRL0_ISWSTART        ADC_CTRL0_ISWSTART_Msk                        /* Software trigger for injection channels */

#define ADC_CTRL0_ITRIGSRC_DPos   (26U)
#define ADC_CTRL0_ITRIGSRC_Pos    ADC_CTRL0_ITRIGSRC_DPos
#define ADC_CTRL0_ITRIGSRC_Msk    (0x3FUL << ADC_CTRL0_ITRIGSRC_Pos)            /* 0xFC000000 */
#define ADC_CTRL0_ITRIGSRC        ADC_CTRL0_ITRIGSRC_Msk                        /* ITRIGSRC[5:0] bits (Injection group trigger source select)*/
#define ADC_CTRL0_ITRIGSRC_0      (0x1UL << ADC_CTRL0_ITRIGSRC_Pos)             /* 0x04000000 */
#define ADC_CTRL0_ITRIGSRC_1      (0x2UL << ADC_CTRL0_ITRIGSRC_Pos)             /* 0x08000000 */
#define ADC_CTRL0_ITRIGSRC_2      (0x4UL << ADC_CTRL0_ITRIGSRC_Pos)             /* 0x10000000 */
#define ADC_CTRL0_ITRIGSRC_3      (0x8UL << ADC_CTRL0_ITRIGSRC_Pos)             /* 0x20000000 */
#define ADC_CTRL0_ITRIGSRC_4      (0x10UL << ADC_CTRL0_ITRIGSRC_Pos)            /* 0x40000000 */
#define ADC_CTRL0_ITRIGSRC_5      (0x20UL << ADC_CTRL0_ITRIGSRC_Pos)            /* 0x80000000 */

/******************  Bit definition for ADC_CTRL1 register  *******************/
#define ADC_CTRL1_ADON_DPos       (0U)
#define ADC_CTRL1_ADON_Pos        ADC_CTRL1_ADON_DPos
#define ADC_CTRL1_ADON_Msk        (0x1UL << ADC_CTRL1_ADON_Pos)                 /* 0x00000001 */
#define ADC_CTRL1_ADON            ADC_CTRL1_ADON_Msk                            /* ADC Power on */

#define ADC_CTRL1_RESETN_DPos     (1U)
#define ADC_CTRL1_RESETN_Pos      ADC_CTRL1_RESETN_DPos
#define ADC_CTRL1_RESETN_Msk      (0x1UL << ADC_CTRL1_RESETN_Pos)               /* 0x00000002 */
#define ADC_CTRL1_RESETN          ADC_CTRL1_RESETN_Msk                          /* ADC reset */

#define ADC_CTRL1_PSC_DPos        (2U)
#define ADC_CTRL1_PSC_Pos         ADC_CTRL1_PSC_DPos
#define ADC_CTRL1_PSC_Msk         (0x1FUL << ADC_CTRL1_PSC_Pos)                 /* 0x0000007C */
#define ADC_CTRL1_PSC             ADC_CTRL1_PSC_Msk                             /* PSC[2:0] bits (ADC conversion clock prescaler used to generate ADCCLK)*/
#define ADC_CTRL1_PSC_0           (0x1UL << ADC_CTRL1_PSC_Pos)                  /* 0x00000004 */
#define ADC_CTRL1_PSC_1           (0x2UL << ADC_CTRL1_PSC_Pos)                  /* 0x00000008 */
#define ADC_CTRL1_PSC_2           (0x4UL << ADC_CTRL1_PSC_Pos)                  /* 0x00000010 */
#define ADC_CTRL1_PSC_3           (0x8UL << ADC_CTRL1_PSC_Pos)                  /* 0x00000020 */
#define ADC_CTRL1_PSC_4           (0x10UL << ADC_CTRL1_PSC_Pos)                 /* 0x00000040 */

#define ADC_CTRL1_RESL_DPos       (10U)
#define ADC_CTRL1_RESL_Pos        ADC_CTRL1_RESL_DPos
#define ADC_CTRL1_RESL_Msk        (0x3UL << ADC_CTRL1_RESL_Pos)                  /* 0x00000C00 */
#define ADC_CTRL1_RESL            ADC_CTRL1_RESL_Msk                            /* RESL[1:0] bits (ADC conversion resolution selction)*/
#define ADC_CTRL1_RESL_0          (0x1UL << ADC_CTRL1_RESL_Pos)                  /* 0x00000400 */
#define ADC_CTRL1_RESL_1          (0x2UL << ADC_CTRL1_RESL_Pos)                  /* 0x00000800 */

/******************  Bit definition for ADC_AMOCR register  *******************/
#define ADC_AMOCR_AMOCH_DPos      (0U)
#define ADC_AMOCR_AMOCH_Pos       ADC_AMOCR_AMOCH_DPos
#define ADC_AMOCR_AMOCH_Msk       (0x1FUL << ADC_AMOCR_AMOCH_Pos)               /* 0x0000001F */
#define ADC_AMOCR_AMOCH           ADC_AMOCR_AMOCH_Msk                           /* AMOCH[4:0] bits (Analog monitor detecting channel)*/
#define ADC_AMOCR_AMOCH_0         (0x1UL << ADC_AMOCR_AMOCH_Pos)                /* 0x00000001 */
#define ADC_AMOCR_AMOCH_1         (0x2UL << ADC_AMOCR_AMOCH_Pos)                /* 0x00000002 */
#define ADC_AMOCR_AMOCH_2         (0x4UL << ADC_AMOCR_AMOCH_Pos)                /* 0x00000004 */
#define ADC_AMOCR_AMOCH_3         (0x8UL << ADC_AMOCR_AMOCH_Pos)                /* 0x00000008 */
#define ADC_AMOCR_AMOCH_4         (0x10UL << ADC_AMOCR_AMOCH_Pos)               /* 0x00000010 */

#define ADC_AMOCR_AMOSGL_DPos     (5U)
#define ADC_AMOCR_AMOSGL_Pos      ADC_AMOCR_AMOSGL_DPos
#define ADC_AMOCR_AMOSGL_Msk      (0x1UL << ADC_AMOCR_AMOSGL_Pos)               /* 0x00000020 */
#define ADC_AMOCR_AMOSGL          ADC_AMOCR_AMOSGL_Msk                          /* Analog monitor AMOSGL function configuration */

#define ADC_AMOCR_IAMOEN_DPos     (6U)
#define ADC_AMOCR_IAMOEN_Pos      ADC_AMOCR_IAMOEN_DPos
#define ADC_AMOCR_IAMOEN_Msk      (0x1UL << ADC_AMOCR_IAMOEN_Pos)               /* 0x00000040 */
#define ADC_AMOCR_IAMOEN          ADC_AMOCR_IAMOEN_Msk                          /* Analog monitor IAMOEN function configuration */

#define ADC_AMOCR_AMOEN_DPos      (7U)
#define ADC_AMOCR_AMOEN_Pos       ADC_AMOCR_AMOEN_DPos
#define ADC_AMOCR_AMOEN_Msk       (0x1UL << ADC_AMOCR_AMOEN_Pos)                /* 0x00000080 */
#define ADC_AMOCR_AMOEN           ADC_AMOCR_AMOEN_Msk                           /* Analog monitor AMOEN function configuration */

#define ADC_AMOCR_AMOIE_DPos      (8U)
#define ADC_AMOCR_AMOIE_Pos       ADC_AMOCR_AMOIE_DPos
#define ADC_AMOCR_AMOIE_Msk       (0x1UL << ADC_AMOCR_AMOIE_Pos)                /* 0x00000100 */
#define ADC_AMOCR_AMOIE           ADC_AMOCR_AMOIE_Msk                           /* AMO interrupt function enable */

/******************  Bit definition for ADC_AMOHR register  *******************/
#define ADC_AMOHR_AMOHT_DPos      (0U)
#define ADC_AMOHR_AMOHT_Pos       ADC_AMOHR_AMOHT_DPos
#define ADC_AMOHR_AMOHT_Msk       (0xFFFUL << ADC_AMOHR_AMOHT_Pos)              /* 0x00000FFF */
#define ADC_AMOHR_AMOHT           ADC_AMOHR_AMOHT_Msk                           /* AMOHT[11:0] bits (Analog monitor higher threshold)*/
#define ADC_AMOHR_AMOHT_0         (0x1UL << ADC_AMOHR_AMOHT_Pos)                /* 0x00000001 */
#define ADC_AMOHR_AMOHT_1         (0x2UL << ADC_AMOHR_AMOHT_Pos)                /* 0x00000002 */
#define ADC_AMOHR_AMOHT_2         (0x4UL << ADC_AMOHR_AMOHT_Pos)                /* 0x00000004 */
#define ADC_AMOHR_AMOHT_3         (0x8UL << ADC_AMOHR_AMOHT_Pos)                /* 0x00000008 */
#define ADC_AMOHR_AMOHT_4         (0x10UL << ADC_AMOHR_AMOHT_Pos)               /* 0x00000010 */
#define ADC_AMOHR_AMOHT_5         (0x20UL << ADC_AMOHR_AMOHT_Pos)               /* 0x00000020 */
#define ADC_AMOHR_AMOHT_6         (0x40UL << ADC_AMOHR_AMOHT_Pos)               /* 0x00000040 */
#define ADC_AMOHR_AMOHT_7         (0x80UL << ADC_AMOHR_AMOHT_Pos)               /* 0x00000080 */
#define ADC_AMOHR_AMOHT_8         (0x100UL << ADC_AMOHR_AMOHT_Pos)              /* 0x00000100 */
#define ADC_AMOHR_AMOHT_9         (0x200UL << ADC_AMOHR_AMOHT_Pos)              /* 0x00000200 */
#define ADC_AMOHR_AMOHT_10        (0x400UL << ADC_AMOHR_AMOHT_Pos)              /* 0x00000400 */
#define ADC_AMOHR_AMOHT_11        (0x800UL << ADC_AMOHR_AMOHT_Pos)              /* 0x00000800 */

/******************  Bit definition for ADC_AMOLR register  *******************/
#define ADC_AMOLR_AMOLT_DPos      (0U)
#define ADC_AMOLR_AMOLT_Pos       ADC_AMOLR_AMOLT_DPos
#define ADC_AMOLR_AMOLT_Msk       (0xFFFUL << ADC_AMOLR_AMOLT_Pos)              /* 0x00000FFF */
#define ADC_AMOLR_AMOLT           ADC_AMOLR_AMOLT_Msk                           /* AMOLT[11:0] bits (Analog monitor lower threshold)*/
#define ADC_AMOLR_AMOLT_0         (0x1UL << ADC_AMOLR_AMOLT_Pos)                /* 0x00000001 */
#define ADC_AMOLR_AMOLT_1         (0x2UL << ADC_AMOLR_AMOLT_Pos)                /* 0x00000002 */
#define ADC_AMOLR_AMOLT_2         (0x4UL << ADC_AMOLR_AMOLT_Pos)                /* 0x00000004 */
#define ADC_AMOLR_AMOLT_3         (0x8UL << ADC_AMOLR_AMOLT_Pos)                /* 0x00000008 */
#define ADC_AMOLR_AMOLT_4         (0x10UL << ADC_AMOLR_AMOLT_Pos)               /* 0x00000010 */
#define ADC_AMOLR_AMOLT_5         (0x20UL << ADC_AMOLR_AMOLT_Pos)               /* 0x00000020 */
#define ADC_AMOLR_AMOLT_6         (0x40UL << ADC_AMOLR_AMOLT_Pos)               /* 0x00000040 */
#define ADC_AMOLR_AMOLT_7         (0x80UL << ADC_AMOLR_AMOLT_Pos)               /* 0x00000080 */
#define ADC_AMOLR_AMOLT_8         (0x100UL << ADC_AMOLR_AMOLT_Pos)              /* 0x00000100 */
#define ADC_AMOLR_AMOLT_9         (0x200UL << ADC_AMOLR_AMOLT_Pos)              /* 0x00000200 */
#define ADC_AMOLR_AMOLT_10        (0x400UL << ADC_AMOLR_AMOLT_Pos)              /* 0x00000400 */
#define ADC_AMOLR_AMOLT_11        (0x800UL << ADC_AMOLR_AMOLT_Pos)              /* 0x00000800 */

/*******************  Bit definition for ADC_SPT register  ********************/
#define ADC_SPT_SPT_DPos          (0U)
#define ADC_SPT_SPT_Pos           ADC_SPT_SPT_DPos
#define ADC_SPT_SPT_Msk           (0xFUL << ADC_SPT_SPT_Pos)                    /* 0x0000000F */
#define ADC_SPT_SPT               ADC_SPT_SPT_Msk                               /* SPT[3:0] bits (Sample time selection for each channels)*/
#define ADC_SPT_SPT_0             (0x1UL << ADC_SPT_SPT_Pos)                    /* 0x00000001 */
#define ADC_SPT_SPT_1             (0x2UL << ADC_SPT_SPT_Pos)                    /* 0x00000002 */
#define ADC_SPT_SPT_2             (0x4UL << ADC_SPT_SPT_Pos)                    /* 0x00000004 */
#define ADC_SPT_SPT_3             (0x8UL << ADC_SPT_SPT_Pos)                    /* 0x00000008 */
#define ADC_SPT_Width             (4UL)                                         /* SPT width (4bit) */

/******************  Bit definition for ADC_CONFIG register  ******************/
#define ADC_CONFIG_EN_VREFBI_DPos    (0U)
#define ADC_CONFIG_EN_VREFBI_Pos     ADC_CONFIG_EN_VREFBI_DPos
#define ADC_CONFIG_EN_VREFBI_Msk     (0x1UL << ADC_CONFIG_EN_VREFBI_Pos)        /* 0x00000001 */
#define ADC_CONFIG_EN_VREFBI         ADC_CONFIG_EN_VREFBI_Msk                   /* Built-in reference voltage enable signal */

#define ADC_CONFIG_EN_HIZ_DPos       (1U)
#define ADC_CONFIG_EN_HIZ_Pos        ADC_CONFIG_EN_HIZ_DPos
#define ADC_CONFIG_EN_HIZ_Msk        (0x1UL << ADC_CONFIG_EN_HIZ_Pos)           /* 0x00000002 */
#define ADC_CONFIG_EN_HIZ            ADC_CONFIG_EN_HIZ_Msk                      /* High-resistance state control signal */

#define ADC_CONFIG_SEL_VREFBI_DPos   (2U)
#define ADC_CONFIG_SEL_VREFBI_Pos    ADC_CONFIG_SEL_VREFBI_DPos
#define ADC_CONFIG_SEL_VREFBI_Msk    (0x3UL << ADC_CONFIG_SEL_VREFBI_Pos)       /* 0x0000000C */
#define ADC_CONFIG_SEL_VREFBI        ADC_CONFIG_SEL_VREFBI_Msk                  /* SEL_VREFBI[1:0] bits (Built-in reference output voltage selected signal)*/
#define ADC_CONFIG_SEL_VREFBI_0      (0x1UL << ADC_CONFIG_SEL_VREFBI_Pos)       /* 0x00000004 */
#define ADC_CONFIG_SEL_VREFBI_1      (0x2UL << ADC_CONFIG_SEL_VREFBI_Pos)       /* 0x00000008 */

#define ADC_CONFIG_VTRIM_DPos        (4U)
#define ADC_CONFIG_VTRIM_Pos         ADC_CONFIG_VTRIM_DPos
#define ADC_CONFIG_VTRIM_Msk         (0x1FUL << ADC_CONFIG_VTRIM_Pos)           /* 0x000001F0 */
#define ADC_CONFIG_VTRIM             ADC_CONFIG_VTRIM_Msk                       /* VTRIM[4:0] bits (Built-In reference voltage output control)*/
#define ADC_CONFIG_VTRIM_0           (0x1UL << ADC_CONFIG_VTRIM_Pos)            /* 0x00000010 */
#define ADC_CONFIG_VTRIM_1           (0x2UL << ADC_CONFIG_VTRIM_Pos)            /* 0x00000020 */
#define ADC_CONFIG_VTRIM_2           (0x4UL << ADC_CONFIG_VTRIM_Pos)            /* 0x00000040 */
#define ADC_CONFIG_VTRIM_3           (0x8UL << ADC_CONFIG_VTRIM_Pos)            /* 0x00000080 */
#define ADC_CONFIG_VTRIM_4           (0x10UL << ADC_CONFIG_VTRIM_Pos)           /* 0x00000100 */

#define ADC_CONFIG_TTRIM_DPos        (9U)
#define ADC_CONFIG_TTRIM_Pos         ADC_CONFIG_TTRIM_DPos
#define ADC_CONFIG_TTRIM_Msk         (0xFUL << ADC_CONFIG_TTRIM_Pos)            /* 0x00001E00 */
#define ADC_CONFIG_TTRIM             ADC_CONFIG_TTRIM_Msk                       /* TTRIM[3:0] bits (Built-In reference voltage temperature ratio control)*/
#define ADC_CONFIG_TTRIM_0           (0x1UL << ADC_CONFIG_TTRIM_Pos)            /* 0x00000200 */
#define ADC_CONFIG_TTRIM_1           (0x2UL << ADC_CONFIG_TTRIM_Pos)            /* 0x00000400 */
#define ADC_CONFIG_TTRIM_2           (0x4UL << ADC_CONFIG_TTRIM_Pos)            /* 0x00000800 */
#define ADC_CONFIG_TTRIM_3           (0x8UL << ADC_CONFIG_TTRIM_Pos)            /* 0x00001000 */

#define ADC_CONFIG_SELVI_HD_LS_DPos  (16U)
#define ADC_CONFIG_SELVI_HD_LS_Pos   ADC_CONFIG_SELVI_HD_LS_DPos
#define ADC_CONFIG_SELVI_HD_LS_Msk   (0x1UL << ADC_CONFIG_SELVI_HD_LS_Pos)      /* 0x00010000 */
#define ADC_CONFIG_SELVI_HD_LS       ADC_CONFIG_SELVI_HD_LS_Msk                 /* SAR input type selection */

#define ADC_CONFIG_EN_TS_DPos        (18U)
#define ADC_CONFIG_EN_TS_Pos         ADC_CONFIG_EN_TS_DPos
#define ADC_CONFIG_EN_TS_Msk         (0x1UL << ADC_CONFIG_EN_TS_Pos)            /* 0x00040000 */
#define ADC_CONFIG_EN_TS             ADC_CONFIG_EN_TS_Msk                       /* Temperature sensor enable signal */

#define ADC_CONFIG_EN_BUF_DPos       (19U)
#define ADC_CONFIG_EN_BUF_Pos        ADC_CONFIG_EN_BUF_DPos
#define ADC_CONFIG_EN_BUF_Msk        (0x1UL << ADC_CONFIG_EN_BUF_Pos)           /* 0x00080000 */
#define ADC_CONFIG_EN_BUF            ADC_CONFIG_EN_BUF_Msk                      /* Detected external reference input buffer enable signal */

#define ADC_CONFIG_ALG_MEAN_DPos     (20U)
#define ADC_CONFIG_ALG_MEAN_Pos      ADC_CONFIG_ALG_MEAN_DPos
#define ADC_CONFIG_ALG_MEAN_Msk      (0x3UL << ADC_CONFIG_ALG_MEAN_Pos)         /* 0x00300000 */
#define ADC_CONFIG_ALG_MEAN          ADC_CONFIG_ALG_MEAN_Msk                    /* ALG_MEAN[1:0] bits (Temperature sampling points selection for mean algorithm)*/
#define ADC_CONFIG_ALG_MEAN_0        (0x1UL << ADC_CONFIG_ALG_MEAN_Pos)         /* 0x00100000 */
#define ADC_CONFIG_ALG_MEAN_1        (0x2UL << ADC_CONFIG_ALG_MEAN_Pos)         /* 0x00200000 */

#define ADC_CONFIG_ADJ_TD_OS_DPos    (24U)
#define ADC_CONFIG_ADJ_TD_OS_Pos     ADC_CONFIG_ADJ_TD_OS_DPos
#define ADC_CONFIG_ADJ_TD_OS_Msk     (0xFUL << ADC_CONFIG_ADJ_TD_OS_Pos)        /* 0x0F000000 */
#define ADC_CONFIG_ADJ_TD_OS         ADC_CONFIG_ADJ_TD_OS_Msk                   /* ADJ_TD_OS[3:0] bits (Temperature sensor offset adjustment signal)*/
#define ADC_CONFIG_ADJ_TD_OS_0       (0x1UL << ADC_CONFIG_ADJ_TD_OS_Pos)        /* 0x01000000 */
#define ADC_CONFIG_ADJ_TD_OS_1       (0x2UL << ADC_CONFIG_ADJ_TD_OS_Pos)        /* 0x02000000 */
#define ADC_CONFIG_ADJ_TD_OS_2       (0x4UL << ADC_CONFIG_ADJ_TD_OS_Pos)        /* 0x04000000 */
#define ADC_CONFIG_ADJ_TD_OS_3       (0x8UL << ADC_CONFIG_ADJ_TD_OS_Pos)        /* 0x08000000 */

#define ADC_CONFIG_ADJ_TD_GA_DPos    (28U)
#define ADC_CONFIG_ADJ_TD_GA_Pos     ADC_CONFIG_ADJ_TD_GA_DPos
#define ADC_CONFIG_ADJ_TD_GA_Msk     (0xFUL << ADC_CONFIG_ADJ_TD_GA_Pos)        /* 0xF0000000 */
#define ADC_CONFIG_ADJ_TD_GA         ADC_CONFIG_ADJ_TD_GA_Msk                   /* ADJ_TD_GA[3:0] bits (Temperature sensor gain adjustment signal)*/
#define ADC_CONFIG_ADJ_TD_GA_0       (0x1UL << ADC_CONFIG_ADJ_TD_GA_Pos)        /* 0x10000000 */
#define ADC_CONFIG_ADJ_TD_GA_1       (0x2UL << ADC_CONFIG_ADJ_TD_GA_Pos)        /* 0x20000000 */
#define ADC_CONFIG_ADJ_TD_GA_2       (0x4UL << ADC_CONFIG_ADJ_TD_GA_Pos)        /* 0x40000000 */
#define ADC_CONFIG_ADJ_TD_GA_3       (0x8UL << ADC_CONFIG_ADJ_TD_GA_Pos)        /* 0x80000000 */

/*******************  Bit definition for ADC_SQL register  ********************/
#define ADC_SQL_RSQL_DPos         (0U)
#define ADC_SQL_RSQL_Pos          ADC_SQL_RSQL_DPos
#define ADC_SQL_RSQL_Msk          (0xFUL << ADC_SQL_RSQL_Pos)                   /* 0x0000000F */
#define ADC_SQL_RSQL              ADC_SQL_RSQL_Msk                              /* RSQL[3:0] bits (Length of the regular group)*/
#define ADC_SQL_RSQL_0            (0x1UL << ADC_SQL_RSQL_Pos)                   /* 0x00000001 */
#define ADC_SQL_RSQL_1            (0x2UL << ADC_SQL_RSQL_Pos)                   /* 0x00000002 */
#define ADC_SQL_RSQL_2            (0x4UL << ADC_SQL_RSQL_Pos)                   /* 0x00000004 */
#define ADC_SQL_RSQL_3            (0x8UL << ADC_SQL_RSQL_Pos)                   /* 0x00000008 */

#define ADC_SQL_ISQL_DPos         (8U)
#define ADC_SQL_ISQL_Pos          ADC_SQL_ISQL_DPos
#define ADC_SQL_ISQL_Msk          (0x3UL << ADC_SQL_ISQL_Pos)                   /* 0x00000300 */
#define ADC_SQL_ISQL              ADC_SQL_ISQL_Msk                              /* ISQL[1:0] bits (Length of the injection group)*/
#define ADC_SQL_ISQL_0            (0x1UL << ADC_SQL_ISQL_Pos)                   /* 0x00000100 */
#define ADC_SQL_ISQL_1            (0x2UL << ADC_SQL_ISQL_Pos)                   /* 0x00000200 */

/*******************  Bit definition for ADC_IOFR register  *******************/
#define ADC_IOFR_IOFR_DPos        (0U)
#define ADC_IOFR_IOFR_Pos         ADC_IOFR_IOFR_DPos
#define ADC_IOFR_IOFR_Msk         (0xFFFUL << ADC_IOFR_IOFR_Pos)                /* 0x00000FFF */
#define ADC_IOFR_IOFR             ADC_IOFR_IOFR_Msk                             /* IOFR[11:0] bits (Injection group offset value)*/
#define ADC_IOFR_IOFR_0           (0x1UL << ADC_IOFR_IOFR_Pos)                  /* 0x00000001 */
#define ADC_IOFR_IOFR_1           (0x2UL << ADC_IOFR_IOFR_Pos)                  /* 0x00000002 */
#define ADC_IOFR_IOFR_2           (0x4UL << ADC_IOFR_IOFR_Pos)                  /* 0x00000004 */
#define ADC_IOFR_IOFR_3           (0x8UL << ADC_IOFR_IOFR_Pos)                  /* 0x00000008 */
#define ADC_IOFR_IOFR_4           (0x10UL << ADC_IOFR_IOFR_Pos)                 /* 0x00000010 */
#define ADC_IOFR_IOFR_5           (0x20UL << ADC_IOFR_IOFR_Pos)                 /* 0x00000020 */
#define ADC_IOFR_IOFR_6           (0x40UL << ADC_IOFR_IOFR_Pos)                 /* 0x00000040 */
#define ADC_IOFR_IOFR_7           (0x80UL << ADC_IOFR_IOFR_Pos)                 /* 0x00000080 */
#define ADC_IOFR_IOFR_8           (0x100UL << ADC_IOFR_IOFR_Pos)                /* 0x00000100 */
#define ADC_IOFR_IOFR_9           (0x200UL << ADC_IOFR_IOFR_Pos)                /* 0x00000200 */
#define ADC_IOFR_IOFR_10          (0x400UL << ADC_IOFR_IOFR_Pos)                /* 0x00000400 */
#define ADC_IOFR_IOFR_11          (0x800UL << ADC_IOFR_IOFR_Pos)                /* 0x00000800 */

/*******************  Bit definition for ADC_RSQR register  *******************/
#define ADC_RSQR_SEQ_DPos         (0U)
#define ADC_RSQR_SEQ_Pos          ADC_RSQR_SEQ_DPos
#define ADC_RSQR_SEQ_Msk          (0x1FUL << ADC_RSQR_SEQ_Pos)                  /* 0x0000001F */
#define ADC_RSQR_SEQ              ADC_RSQR_SEQ_Msk                              /* SEQ[4:0] bits (Channel selection for regular group)*/
#define ADC_RSQR_SEQ_0            (0x1UL << ADC_RSQR_SEQ_Pos)                   /* 0x00000001 */
#define ADC_RSQR_SEQ_1            (0x2UL << ADC_RSQR_SEQ_Pos)                   /* 0x00000002 */
#define ADC_RSQR_SEQ_2            (0x4UL << ADC_RSQR_SEQ_Pos)                   /* 0x00000004 */
#define ADC_RSQR_SEQ_3            (0x8UL << ADC_RSQR_SEQ_Pos)                   /* 0x00000008 */
#define ADC_RSQR_SEQ_4            (0x10UL << ADC_RSQR_SEQ_Pos)                  /* 0x00000010 */

#define ADC_RSQR_IE_DPos          (6U)
#define ADC_RSQR_IE_Pos           ADC_RSQR_IE_DPos
#define ADC_RSQR_IE_Msk           (0x1UL << ADC_RSQR_IE_Pos)                    /* 0x00000040 */
#define ADC_RSQR_IE               ADC_RSQR_IE_Msk                               /* EOC interrupt enable */

#define ADC_RSQR_EOC_DPos         (7U)
#define ADC_RSQR_EOC_Pos          ADC_RSQR_EOC_DPos
#define ADC_RSQR_EOC_Msk          (0x1UL << ADC_RSQR_EOC_Pos)                   /* 0x00000080 */
#define ADC_RSQR_EOC              ADC_RSQR_EOC_Msk                              /* Indicate Regular Sequence conversion end */

/*******************  Bit definition for ADC_ISQR register  *******************/
#define ADC_ISQR_SEQ_DPos         (0U)
#define ADC_ISQR_SEQ_Pos          ADC_ISQR_SEQ_DPos
#define ADC_ISQR_SEQ_Msk          (0x1FUL << ADC_ISQR_SEQ_Pos)                  /* 0x0000001F */
#define ADC_ISQR_SEQ              ADC_ISQR_SEQ_Msk                              /* SEQ[4:0] bits (Channel selection for injection group)*/
#define ADC_ISQR_SEQ_0            (0x1UL << ADC_ISQR_SEQ_Pos)                   /* 0x00000001 */
#define ADC_ISQR_SEQ_1            (0x2UL << ADC_ISQR_SEQ_Pos)                   /* 0x00000002 */
#define ADC_ISQR_SEQ_2            (0x4UL << ADC_ISQR_SEQ_Pos)                   /* 0x00000004 */
#define ADC_ISQR_SEQ_3            (0x8UL << ADC_ISQR_SEQ_Pos)                   /* 0x00000008 */
#define ADC_ISQR_SEQ_4            (0x10UL << ADC_ISQR_SEQ_Pos)                  /* 0x00000010 */

#define ADC_ISQR_IE_DPos          (6U)
#define ADC_ISQR_IE_Pos           ADC_ISQR_IE_DPos
#define ADC_ISQR_IE_Msk           (0x1UL << ADC_ISQR_IE_Pos)                    /* 0x00000040 */
#define ADC_ISQR_IE               ADC_ISQR_IE_Msk                               /* EOC interrupt enable */

#define ADC_ISQR_EOC_DPos         (7U)
#define ADC_ISQR_EOC_Pos          ADC_ISQR_EOC_DPos
#define ADC_ISQR_EOC_Msk          (0x1UL << ADC_ISQR_EOC_Pos)                   /* 0x00000080 */
#define ADC_ISQR_EOC              ADC_ISQR_EOC_Msk                              /* Indicate Regular Sequence conversion end */

/*******************  Bit definition for ADC_RDR register  ********************/
#define ADC_RDR_RDR_DPos          (0U)
#define ADC_RDR_RDR_Pos           ADC_RDR_RDR_DPos
#define ADC_RDR_RDR_Msk           (0xFFFFUL << ADC_RDR_RDR_Pos)                 /* 0x0000FFFF */
#define ADC_RDR_RDR               ADC_RDR_RDR_Msk                               /* RDR[15:0] bits (Data register for regular group)*/
#define ADC_RDR_RDR_0             (0x1UL << ADC_RDR_RDR_Pos)                    /* 0x00000001 */
#define ADC_RDR_RDR_1             (0x2UL << ADC_RDR_RDR_Pos)                    /* 0x00000002 */
#define ADC_RDR_RDR_2             (0x4UL << ADC_RDR_RDR_Pos)                    /* 0x00000004 */
#define ADC_RDR_RDR_3             (0x8UL << ADC_RDR_RDR_Pos)                    /* 0x00000008 */
#define ADC_RDR_RDR_4             (0x10UL << ADC_RDR_RDR_Pos)                   /* 0x00000010 */
#define ADC_RDR_RDR_5             (0x20UL << ADC_RDR_RDR_Pos)                   /* 0x00000020 */
#define ADC_RDR_RDR_6             (0x40UL << ADC_RDR_RDR_Pos)                   /* 0x00000040 */
#define ADC_RDR_RDR_7             (0x80UL << ADC_RDR_RDR_Pos)                   /* 0x00000080 */
#define ADC_RDR_RDR_8             (0x100UL << ADC_RDR_RDR_Pos)                  /* 0x00000100 */
#define ADC_RDR_RDR_9             (0x200UL << ADC_RDR_RDR_Pos)                  /* 0x00000200 */
#define ADC_RDR_RDR_10            (0x400UL << ADC_RDR_RDR_Pos)                  /* 0x00000400 */
#define ADC_RDR_RDR_11            (0x800UL << ADC_RDR_RDR_Pos)                  /* 0x00000800 */
#define ADC_RDR_RDR_12            (0x1000UL << ADC_RDR_RDR_Pos)                 /* 0x00001000 */
#define ADC_RDR_RDR_13            (0x2000UL << ADC_RDR_RDR_Pos)                 /* 0x00002000 */
#define ADC_RDR_RDR_14            (0x4000UL << ADC_RDR_RDR_Pos)                 /* 0x00004000 */
#define ADC_RDR_RDR_15            (0x8000UL << ADC_RDR_RDR_Pos)                 /* 0x00008000 */

#define ADC_RDR_CH_DPos           (16U)
#define ADC_RDR_CH_Pos            ADC_RDR_CH_DPos
#define ADC_RDR_CH_Msk            (0x1FUL << ADC_RDR_CH_Pos)                    /* 0x001F0000 */
#define ADC_RDR_CH                ADC_RDR_CH_Msk                                /* CH[4:0] bits (Channel selection for regular group)*/
#define ADC_RDR_CH_0              (0x1UL << ADC_RDR_CH_Pos)                     /* 0x00000001 */
#define ADC_RDR_CH_1              (0x2UL << ADC_RDR_CH_Pos)                     /* 0x00000002 */
#define ADC_RDR_CH_2              (0x4UL << ADC_RDR_CH_Pos)                     /* 0x00000004 */
#define ADC_RDR_CH_3              (0x8UL << ADC_RDR_CH_Pos)                     /* 0x00000008 */
#define ADC_RDR_CH_4              (0x10UL << ADC_RDR_CH_Pos)                    /* 0x00000010 */

#define ADC_RDR_PARITY_DPos       (22U)
#define ADC_RDR_PARITY_Pos        ADC_RDR_PARITY_DPos
#define ADC_RDR_PARITY_Msk        (0x1UL << ADC_RDR_PARITY_Pos)                 /* 0x00400000 */
#define ADC_RDR_PARITY            ADC_RDR_PARITY_Msk                            /* Parity for regular conversion data */

/*******************  Bit definition for ADC_IDR register  ********************/
#define ADC_IDR_IDR_DPos          (0U)
#define ADC_IDR_IDR_Pos           ADC_IDR_IDR_DPos
#define ADC_IDR_IDR_Msk           (0xFFFFUL << ADC_IDR_IDR_Pos)                 /* 0x0000FFFF */
#define ADC_IDR_IDR               ADC_IDR_IDR_Msk                               /* IDR[15:0] bits (Data register for injection group)*/
#define ADC_IDR_IDR_0             (0x1UL << ADC_IDR_IDR_Pos)                    /* 0x00000001 */
#define ADC_IDR_IDR_1             (0x2UL << ADC_IDR_IDR_Pos)                    /* 0x00000002 */
#define ADC_IDR_IDR_2             (0x4UL << ADC_IDR_IDR_Pos)                    /* 0x00000004 */
#define ADC_IDR_IDR_3             (0x8UL << ADC_IDR_IDR_Pos)                    /* 0x00000008 */
#define ADC_IDR_IDR_4             (0x10UL << ADC_IDR_IDR_Pos)                   /* 0x00000010 */
#define ADC_IDR_IDR_5             (0x20UL << ADC_IDR_IDR_Pos)                   /* 0x00000020 */
#define ADC_IDR_IDR_6             (0x40UL << ADC_IDR_IDR_Pos)                   /* 0x00000040 */
#define ADC_IDR_IDR_7             (0x80UL << ADC_IDR_IDR_Pos)                   /* 0x00000080 */
#define ADC_IDR_IDR_8             (0x100UL << ADC_IDR_IDR_Pos)                  /* 0x00000100 */
#define ADC_IDR_IDR_9             (0x200UL << ADC_IDR_IDR_Pos)                  /* 0x00000200 */
#define ADC_IDR_IDR_10            (0x400UL << ADC_IDR_IDR_Pos)                  /* 0x00000400 */
#define ADC_IDR_IDR_11            (0x800UL << ADC_IDR_IDR_Pos)                  /* 0x00000800 */
#define ADC_IDR_IDR_12            (0x1000UL << ADC_IDR_IDR_Pos)                 /* 0x00001000 */
#define ADC_IDR_IDR_13            (0x2000UL << ADC_IDR_IDR_Pos)                 /* 0x00002000 */
#define ADC_IDR_IDR_14            (0x4000UL << ADC_IDR_IDR_Pos)                 /* 0x00004000 */
#define ADC_IDR_IDR_15            (0x8000UL << ADC_IDR_IDR_Pos)                 /* 0x00008000 */

#define ADC_IDR_CH_DPos           (16U)
#define ADC_IDR_CH_Pos            ADC_IDR_CH_DPos
#define ADC_IDR_CH_Msk            (0x1FUL << ADC_IDR_CH_Pos)                    /* 0x001F0000 */
#define ADC_IDR_CH                ADC_IDR_CH_Msk                                /* CH[4:0] bits (Channel selection for injection group)*/
#define ADC_IDR_CH_0              (0x1UL << ADC_IDR_CH_Pos)                     /* 0x00000001 */
#define ADC_IDR_CH_1              (0x2UL << ADC_IDR_CH_Pos)                     /* 0x00000002 */
#define ADC_IDR_CH_2              (0x4UL << ADC_IDR_CH_Pos)                     /* 0x00000004 */
#define ADC_IDR_CH_3              (0x8UL << ADC_IDR_CH_Pos)                     /* 0x00000008 */
#define ADC_IDR_CH_4              (0x10UL << ADC_IDR_CH_Pos)                    /* 0x00000010 */

#define ADC_IDR_PARITY_DPos       (22U)
#define ADC_IDR_PARITY_Pos        ADC_IDR_PARITY_DPos
#define ADC_IDR_PARITY_Msk        (0x1UL << ADC_IDR_PARITY_Pos)                 /* 0x00400000 */
#define ADC_IDR_PARITY            ADC_IDR_PARITY_Msk                            /* Parity for injection conversion data */

/* @name DAC register bits definition */
/******************  Bit definition for DAC_CTRL register  *******************/
#define DAC_CTRL_DAC_EN_DPos        (0U)
#define DAC_CTRL_EN_Pos             DAC_CTRL_DAC_EN_DPos
#define DAC_CTRL_EN_Msk             (0x1UL << DAC_CTRL_EN_Pos)                  /* 0x00000001 */
#define DAC_CTRL_EN                 DAC_CTRL_EN_Msk                             /* DAC enable */

#define DAC_CTRL_DAC_MD_DPos        (1U)
#define DAC_CTRL_MD_Pos             DAC_CTRL_DAC_MD_DPos
#define DAC_CTRL_MD_Msk             (0x1UL << DAC_CTRL_MD_Pos)                  /* 0x00000002 */
#define DAC_CTRL_MD                 DAC_CTRL_MD_Msk                             /* DAC mode */

#define DAC_CTRL_VREF_MD_DPos       (2U)
#define DAC_CTRL_VREF_MD_Pos        DAC_CTRL_VREF_MD_DPos
#define DAC_CTRL_VREF_MD_Msk        (0x1UL << DAC_CTRL_VREF_MD_Pos)             /* 0x00000004 */
#define DAC_CTRL_VREF_MD            DAC_CTRL_VREF_MD_Msk                        /* DAC VREF mode */

#define DAC_CTRL_RESETN_DPos        (3U)
#define DAC_CTRL_RESETN_Pos         DAC_CTRL_RESETN_DPos
#define DAC_CTRL_RESETN_Msk         (0x1UL << DAC_CTRL_RESETN_Pos)              /* 0x00000008 */
#define DAC_CTRL_RESETN             DAC_CTRL_RESETN_Msk                         /* DAC reset */

/******************  Bit definition for DAC_DOUT register  *******************/
#define DAC_DOUT_DOUT_DPos          (0U)
#define DAC_DOUT_DOUT_Pos           DAC_DOUT_DOUT_DPos
#define DAC_DOUT_DOUT_Msk           (0xFFUL << DAC_DOUT_DOUT_Pos)               /* 0x000000FF */
#define DAC_DOUT_DOUT               DAC_DOUT_DOUT_Msk
#define DAC_DOUT_DOUT_0             (0x1UL << DAC_DOUT_DOUT_Pos)                /* 0x00000001 */
#define DAC_DOUT_DOUT_1             (0x2UL << DAC_DOUT_DOUT_Pos)                /* 0x00000002 */
#define DAC_DOUT_DOUT_2             (0x4UL << DAC_DOUT_DOUT_Pos)                /* 0x00000004 */
#define DAC_DOUT_DOUT_3             (0x8UL << DAC_DOUT_DOUT_Pos)                /* 0x00000008 */
#define DAC_DOUT_DOUT_4             (0x10UL << DAC_DOUT_DOUT_Pos)               /* 0x00000010 */
#define DAC_DOUT_DOUT_5             (0x20UL << DAC_DOUT_DOUT_Pos)               /* 0x00000020 */
#define DAC_DOUT_DOUT_6             (0x40UL << DAC_DOUT_DOUT_Pos)               /* 0x00000040 */
#define DAC_DOUT_DOUT_7             (0x80UL << DAC_DOUT_DOUT_Pos)               /* 0x00000080 */

/******************  Bit definition for DAC_CLK_DIV register  *******************/
#define DAC_CLK_DIV_CLK_DIV_NU_DPos (0U)
#define DAC_CLK_DIV_NU_Pos          DAC_CLK_DIV_CLK_DIV_NU_DPos
#define DAC_CLK_DIV_NU_Msk          (0xFFUL << DAC_CLK_DIV_NU_Pos)              /* 0x000000FF */
#define DAC_CLK_DIV_NU              DAC_CLK_DIV_NU_Msk
#define DAC_CLK_DIV_NU_0            (0x1UL << DAC_CLK_DIV_NU_Pos)               /* 0x00000001 */
#define DAC_CLK_DIV_NU_1            (0x2UL << DAC_CLK_DIV_NU_Pos)               /* 0x00000002 */
#define DAC_CLK_DIV_NU_2            (0x4UL << DAC_CLK_DIV_NU_Pos)               /* 0x00000004 */
#define DAC_CLK_DIV_NU_3            (0x8UL << DAC_CLK_DIV_NU_Pos)               /* 0x00000008 */
#define DAC_CLK_DIV_NU_4            (0x10UL << DAC_CLK_DIV_NU_Pos)              /* 0x00000010 */
#define DAC_CLK_DIV_NU_5            (0x20UL << DAC_CLK_DIV_NU_Pos)              /* 0x00000020 */
#define DAC_CLK_DIV_NU_6            (0x40UL << DAC_CLK_DIV_NU_Pos)              /* 0x00000040 */
#define DAC_CLK_DIV_NU_7            (0x80UL << DAC_CLK_DIV_NU_Pos)              /* 0x00000080 */

/******************  Bit definition for DAC_CMP_CTRL register  *******************/
#define DAC_CMP_CTRL_CMP_EN_DPos    (0U)
#define DAC_CMP_CTRL_EN_Pos         DAC_CMP_CTRL_CMP_EN_DPos
#define DAC_CMP_CTRL_EN_Msk         (0x1UL << DAC_CMP_CTRL_EN_Pos)              /* 0x00000001 */
#define DAC_CMP_CTRL_EN             DAC_CMP_CTRL_EN_Msk                         /* DAC comparator enable */

#define DAC_CMP_CTRL_CMP_MD_DPos    (1U)
#define DAC_CMP_CTRL_MD_Pos         DAC_CMP_CTRL_CMP_MD_DPos
#define DAC_CMP_CTRL_MD_Msk         (0x1UL << DAC_CMP_CTRL_MD_Pos)              /* 0x00000002 */
#define DAC_CMP_CTRL_MD             DAC_CMP_CTRL_MD_Msk                         /* DAC comparator mode */

#define DAC_CMP_CTRL_CMP_HYS_DPos   (2U)
#define DAC_CMP_CTRL_HYS_Pos        DAC_CMP_CTRL_CMP_HYS_DPos
#define DAC_CMP_CTRL_HYS_Msk        (0x7UL << DAC_CMP_CTRL_HYS_Pos)             /* 0x0000001C */
#define DAC_CMP_CTRL_HYS            DAC_CMP_CTRL_HYS_Msk                        /* DAC comparator hysteresis */
#define DAC_CMP_CTRL_HYS_0          (0x1UL << DAC_CMP_CTRL_HYS_Pos)             /* 0x00000004 */
#define DAC_CMP_CTRL_HYS_1          (0x2UL << DAC_CMP_CTRL_HYS_Pos)             /* 0x00000008 */
#define DAC_CMP_CTRL_HYS_2          (0x4UL << DAC_CMP_CTRL_HYS_Pos)             /* 0x00000010 */

#define DAC_CMP_CTRL_CMPO_DPos      (5U)
#define DAC_CMP_CTRL_CMPO_Pos       DAC_CMP_CTRL_CMPO_DPos
#define DAC_CMP_CTRL_CMPO_Msk       (0x1UL << DAC_CMP_CTRL_CMPO_Pos)            /* 0x00000020 */
#define DAC_CMP_CTRL_CMPO           DAC_CMP_CTRL_CMPO_Msk

/* @name SPACC register bits definition */
/******************  Bit definition for SPACC_IRQ_EN register  *******************/
#define SPACC_IRQ_EN_CMD0_EN_DPos                           (0U)
#define SPACC_IRQ_EN_CMD0_EN_Pos                            SPACC_IRQ_EN_CMD0_EN_DPos
#define SPACC_IRQ_EN_CMD0_EN_Msk                            (0x1UL << SPACC_IRQ_EN_CMD0_EN_Pos)                 /* 0x00000001 */
#define SPACC_IRQ_EN_CMD0_EN                                SPACC_IRQ_EN_CMD0_EN_Msk                            /* SPACC Command FIFO Priority 0 Interrupt Enable */

#define SPACC_IRQ_EN_CMD1_EN_DPos                           (1U)
#define SPACC_IRQ_EN_CMD1_EN_Pos                            SPACC_IRQ_EN_CMD1_EN_DPos
#define SPACC_IRQ_EN_CMD1_EN_Msk                            (0x1UL << SPACC_IRQ_EN_CMD1_EN_Pos)                 /* 0x00000002 */
#define SPACC_IRQ_EN_CMD1_EN                                SPACC_IRQ_EN_CMD1_EN_Msk                            /* SPACC Command FIFO Priority 1 Interrupt Enable */

#define SPACC_IRQ_EN_CMD2_EN_DPos                           (2U)
#define SPACC_IRQ_EN_CMD2_EN_Pos                            SPACC_IRQ_EN_CMD2_EN_DPos
#define SPACC_IRQ_EN_CMD2_EN_Msk                            (0x1UL << SPACC_IRQ_EN_CMD2_EN_Pos)                 /* 0x00000004 */
#define SPACC_IRQ_EN_CMD2_EN                                SPACC_IRQ_EN_CMD2_EN_Msk                            /* SPACC Command FIFO Priority 2 Interrupt Enable */

#define SPACC_IRQ_EN_STAT_EN_DPos                           (4U)
#define SPACC_IRQ_EN_STAT_EN_Pos                            SPACC_IRQ_EN_STAT_EN_DPos
#define SPACC_IRQ_EN_STAT_EN_Msk                            (0x1UL << SPACC_IRQ_EN_STAT_EN_Pos)                 /* 0x00000010 */
#define SPACC_IRQ_EN_STAT_EN                                SPACC_IRQ_EN_STAT_EN_Msk                            /* SPACC Status FIFO Interrupt Enable */

#define SPACC_IRQ_EN_RC4_DMA_EN_DPos                        (8U)
#define SPACC_IRQ_EN_RC4_DMA_EN_Pos                         SPACC_IRQ_EN_RC4_DMA_EN_DPos
#define SPACC_IRQ_EN_RC4_DMA_EN_Msk                         (0x1UL << SPACC_IRQ_EN_RC4_DMA_EN_Pos)              /* 0x00000100 */
#define SPACC_IRQ_EN_RC4_DMA_EN                             SPACC_IRQ_EN_RC4_DMA_EN_Msk

#define SPACC_IRQ_EN_STAT_WD_EN_DPos                        (12U)
#define SPACC_IRQ_EN_STAT_WD_EN_Pos                         SPACC_IRQ_EN_STAT_WD_EN_DPos
#define SPACC_IRQ_EN_STAT_WD_EN_Msk                         (0x1UL << SPACC_IRQ_EN_STAT_WD_EN_Pos)              /* 0x00001000 */
#define SPACC_IRQ_EN_STAT_WD_EN                             SPACC_IRQ_EN_STAT_WD_EN_Msk                         /* SPACC Status Watchdog Interrupt Enable */

#define SPACC_IRQ_EN_GLBL_EN_DPos                           (31U)
#define SPACC_IRQ_EN_GLBL_EN_Pos                            SPACC_IRQ_EN_GLBL_EN_DPos
#define SPACC_IRQ_EN_GLBL_EN_Msk                            (0x1UL << SPACC_IRQ_EN_GLBL_EN_Pos)                 /* 0x80000000 */
#define SPACC_IRQ_EN_GLBL_EN                                SPACC_IRQ_EN_GLBL_EN_Msk                            /* SPACC Global Enable Control For Interrupt Sources */

/******************  Bit definition for SPACC_IRQ_STAT register  *******************/
#define SPACC_IRQ_STAT_CMD0_DPos                            (0U)
#define SPACC_IRQ_STAT_CMD0_Pos                             SPACC_IRQ_STAT_CMD0_DPos
#define SPACC_IRQ_STAT_CMD0_Msk                             (0x1UL << SPACC_IRQ_STAT_CMD0_Pos)                  /* 0x00000001 */
#define SPACC_IRQ_STAT_CMD0                                 SPACC_IRQ_STAT_CMD0_Msk                             /* SPACC Command FIFO Priority 0 Interrupt Status */

#define SPACC_IRQ_STAT_CMD1_DPos                            (1U)
#define SPACC_IRQ_STAT_CMD1_Pos                             SPACC_IRQ_STAT_CMD1_DPos
#define SPACC_IRQ_STAT_CMD1_Msk                             (0x1UL << SPACC_IRQ_STAT_CMD1_Pos)                  /* 0x00000002 */
#define SPACC_IRQ_STAT_CMD1                                 SPACC_IRQ_STAT_CMD1_Msk                             /* SPACC Command FIFO Priority 1 Interrupt Status */

#define SPACC_IRQ_STAT_CMD2_DPos                            (2U)
#define SPACC_IRQ_STAT_CMD2_Pos                             SPACC_IRQ_STAT_CMD2_DPos
#define SPACC_IRQ_STAT_CMD2_Msk                             (0x1UL << SPACC_IRQ_STAT_CMD2_Pos)                  /* 0x00000004 */
#define SPACC_IRQ_STAT_CMD2                                 SPACC_IRQ_STAT_CMD2_Msk                             /* SPACC Command FIFO Priority 2 Interrupt Status */

#define SPACC_IRQ_STAT_STAT_DPos                            (4U)
#define SPACC_IRQ_STAT_STAT_Pos                             SPACC_IRQ_STAT_STAT_DPos
#define SPACC_IRQ_STAT_STAT_Msk                             (0x1UL << SPACC_IRQ_STAT_STAT_Pos)                  /* 0x00000010 */
#define SPACC_IRQ_STAT_STAT                                 SPACC_IRQ_STAT_STAT_Msk                             /* SPACC Status FIFO Interrupt Status */

#define SPACC_IRQ_STAT_RC4_DMA_DPos                         (8U)
#define SPACC_IRQ_STAT_RC4_DMA_Pos                          SPACC_IRQ_STAT_RC4_DMA_DPos
#define SPACC_IRQ_STAT_RC4_DMA_Msk                          (0x1UL << SPACC_IRQ_STAT_RC4_DMA_Pos)               /* 0x00000100 */
#define SPACC_IRQ_STAT_RC4_DMA                              SPACC_IRQ_STAT_RC4_DMA_Msk

#define SPACC_IRQ_STAT_STAT_WD_DPos                         (12U)
#define SPACC_IRQ_STAT_STAT_WD_Pos                          SPACC_IRQ_STAT_STAT_WD_DPos
#define SPACC_IRQ_STAT_STAT_WD_Msk                          (0x1UL << SPACC_IRQ_STAT_STAT_WD_Pos)               /* 0x00001000 */
#define SPACC_IRQ_STAT_STAT_WD                              SPACC_IRQ_STAT_STAT_WD_Msk                          /* SPACC Status Watchdog Interrupt Status */

/******************  Bit definition for SPACC_IRQ_CTRL register  *******************/
#define SPACC_IRQ_CTRL_CMD0_CNT_DPos                        (0U)
#define SPACC_IRQ_CTRL_CMD0_CNT_Pos                         SPACC_IRQ_CTRL_CMD0_CNT_DPos
#define SPACC_IRQ_CTRL_CMD0_CNT_Msk                         (0xFFUL << SPACC_IRQ_CTRL_CMD0_CNT_Pos)             /* 0x000000FF */
#define SPACC_IRQ_CTRL_CMD0_CNT                             SPACC_IRQ_CTRL_CMD0_CNT_Msk                         /* SPACC FIFO Fill Level To Trigger A CMD0 Interrupt */
#define SPACC_IRQ_CTRL_CMD0_CNT_0                           (0x1UL << SPACC_IRQ_CTRL_CMD0_CNT_Pos)              /* 0x00000001 */
#define SPACC_IRQ_CTRL_CMD0_CNT_1                           (0x2UL << SPACC_IRQ_CTRL_CMD0_CNT_Pos)              /* 0x00000002 */
#define SPACC_IRQ_CTRL_CMD0_CNT_2                           (0x4UL << SPACC_IRQ_CTRL_CMD0_CNT_Pos)              /* 0x00000004 */
#define SPACC_IRQ_CTRL_CMD0_CNT_3                           (0x8UL << SPACC_IRQ_CTRL_CMD0_CNT_Pos)              /* 0x00000008 */
#define SPACC_IRQ_CTRL_CMD0_CNT_4                           (0x10UL << SPACC_IRQ_CTRL_CMD0_CNT_Pos)             /* 0x00000010 */
#define SPACC_IRQ_CTRL_CMD0_CNT_5                           (0x20UL << SPACC_IRQ_CTRL_CMD0_CNT_Pos)             /* 0x00000020 */
#define SPACC_IRQ_CTRL_CMD0_CNT_6                           (0x40UL << SPACC_IRQ_CTRL_CMD0_CNT_Pos)             /* 0x00000040 */
#define SPACC_IRQ_CTRL_CMD0_CNT_7                           (0x80UL << SPACC_IRQ_CTRL_CMD0_CNT_Pos)             /* 0x00000080 */

#define SPACC_IRQ_CTRL_STAT_CNT_DPos                        (16U)
#define SPACC_IRQ_CTRL_STAT_CNT_Pos                         SPACC_IRQ_CTRL_STAT_CNT_DPos
#define SPACC_IRQ_CTRL_STAT_CNT_Msk                         (0xFFUL << SPACC_IRQ_CTRL_STAT_CNT_Pos)             /* 0x00FF0000 */
#define SPACC_IRQ_CTRL_STAT_CNT                             SPACC_IRQ_CTRL_STAT_CNT_Msk                         /* SPACC FIFO Fill Level To Trigger A STAT Interrupt */
#define SPACC_IRQ_CTRL_STAT_CNT_0                           (0x1UL << SPACC_IRQ_CTRL_STAT_CNT_Pos)              /* 0x00010000 */
#define SPACC_IRQ_CTRL_STAT_CNT_1                           (0x2UL << SPACC_IRQ_CTRL_STAT_CNT_Pos)              /* 0x00020000 */
#define SPACC_IRQ_CTRL_STAT_CNT_2                           (0x4UL << SPACC_IRQ_CTRL_STAT_CNT_Pos)              /* 0x00040000 */
#define SPACC_IRQ_CTRL_STAT_CNT_3                           (0x8UL << SPACC_IRQ_CTRL_STAT_CNT_Pos)              /* 0x00080000 */
#define SPACC_IRQ_CTRL_STAT_CNT_4                           (0x10UL << SPACC_IRQ_CTRL_STAT_CNT_Pos)             /* 0x00100000 */
#define SPACC_IRQ_CTRL_STAT_CNT_5                           (0x20UL << SPACC_IRQ_CTRL_STAT_CNT_Pos)             /* 0x00200000 */
#define SPACC_IRQ_CTRL_STAT_CNT_6                           (0x40UL << SPACC_IRQ_CTRL_STAT_CNT_Pos)             /* 0x00400000 */
#define SPACC_IRQ_CTRL_STAT_CNT_7                           (0x80UL << SPACC_IRQ_CTRL_STAT_CNT_Pos)             /* 0x00800000 */

/******************  Bit definition for SPACC_FIFO_STAT register  *******************/
#define SPACC_FIFO_STAT_CMD0_CNT_DPos                       (0U)
#define SPACC_FIFO_STAT_CMD0_CNT_Pos                        SPACC_FIFO_STAT_CMD0_CNT_DPos
#define SPACC_FIFO_STAT_CMD0_CNT_Msk                        (0xFFUL << SPACC_FIFO_STAT_CMD0_CNT_Pos)            /* 0x000000FF */
#define SPACC_FIFO_STAT_CMD0_CNT                            SPACC_FIFO_STAT_CMD0_CNT_Msk                        /* SPACC Current Number Of Commands Enqueued In The CMD0 FIFO */
#define SPACC_FIFO_STAT_CMD0_CNT_0                          (0x1UL << SPACC_FIFO_STAT_CMD0_CNT_Pos)             /* 0x00000001 */
#define SPACC_FIFO_STAT_CMD0_CNT_1                          (0x2UL << SPACC_FIFO_STAT_CMD0_CNT_Pos)             /* 0x00000002 */
#define SPACC_FIFO_STAT_CMD0_CNT_2                          (0x4UL << SPACC_FIFO_STAT_CMD0_CNT_Pos)             /* 0x00000004 */
#define SPACC_FIFO_STAT_CMD0_CNT_3                          (0x8UL << SPACC_FIFO_STAT_CMD0_CNT_Pos)             /* 0x00000008 */
#define SPACC_FIFO_STAT_CMD0_CNT_4                          (0x10UL << SPACC_FIFO_STAT_CMD0_CNT_Pos)            /* 0x00000010 */
#define SPACC_FIFO_STAT_CMD0_CNT_5                          (0x20UL << SPACC_FIFO_STAT_CMD0_CNT_Pos)            /* 0x00000020 */
#define SPACC_FIFO_STAT_CMD0_CNT_6                          (0x40UL << SPACC_FIFO_STAT_CMD0_CNT_Pos)            /* 0x00000040 */
#define SPACC_FIFO_STAT_CMD0_CNT_7                          (0x80UL << SPACC_FIFO_STAT_CMD0_CNT_Pos)            /* 0x00000080 */

#define SPACC_FIFO_STAT_CMD0_FULL_DPos                      (15U)
#define SPACC_FIFO_STAT_CMD0_FULL_Pos                       SPACC_FIFO_STAT_CMD0_FULL_DPos
#define SPACC_FIFO_STAT_CMD0_FULL_Msk                       (0x1UL << SPACC_FIFO_STAT_CMD0_FULL_Pos)            /* 0x00008000 */
#define SPACC_FIFO_STAT_CMD0_FULL                           SPACC_FIFO_STAT_CMD0_FULL_Msk                       /* Flag Indicating That The CMD0 FIFO Is Full */

#define SPACC_FIFO_STAT_STAT_CNT_DPos                       (16U)
#define SPACC_FIFO_STAT_STAT_CNT_Pos                        SPACC_FIFO_STAT_STAT_CNT_DPos
#define SPACC_FIFO_STAT_STAT_CNT_Msk                        (0xFFUL << SPACC_FIFO_STAT_STAT_CNT_Pos)            /* 0x00FF0000 */
#define SPACC_FIFO_STAT_STAT_CNT                            SPACC_FIFO_STAT_STAT_CNT_Msk                        /* SPACC Current Number Of Status Values Enqueued In The STAT FIFO */
#define SPACC_FIFO_STAT_STAT_CNT_0                          (0x1UL << SPACC_FIFO_STAT_STAT_CNT_Pos)             /* 0x00000001 */
#define SPACC_FIFO_STAT_STAT_CNT_1                          (0x2UL << SPACC_FIFO_STAT_STAT_CNT_Pos)             /* 0x00000002 */
#define SPACC_FIFO_STAT_STAT_CNT_2                          (0x4UL << SPACC_FIFO_STAT_STAT_CNT_Pos)             /* 0x00000004 */
#define SPACC_FIFO_STAT_STAT_CNT_3                          (0x8UL << SPACC_FIFO_STAT_STAT_CNT_Pos)             /* 0x00000008 */
#define SPACC_FIFO_STAT_STAT_CNT_4                          (0x10UL << SPACC_FIFO_STAT_STAT_CNT_Pos)            /* 0x00000010 */
#define SPACC_FIFO_STAT_STAT_CNT_5                          (0x20UL << SPACC_FIFO_STAT_STAT_CNT_Pos)            /* 0x00000020 */
#define SPACC_FIFO_STAT_STAT_CNT_6                          (0x40UL << SPACC_FIFO_STAT_STAT_CNT_Pos)            /* 0x00000040 */
#define SPACC_FIFO_STAT_STAT_CNT_7                          (0x80UL << SPACC_FIFO_STAT_STAT_CNT_Pos)            /* 0x00000080 */

#define SPACC_FIFO_STAT_STAT_EMPTY_DPos                     (31U)
#define SPACC_FIFO_STAT_STAT_EMPTY_Pos                      SPACC_FIFO_STAT_STAT_EMPTY_DPos
#define SPACC_FIFO_STAT_STAT_EMPTY_Msk                      (0x1UL << SPACC_FIFO_STAT_STAT_EMPTY_Pos)           /* 0x80000000 */
#define SPACC_FIFO_STAT_STAT_EMPTY                          SPACC_FIFO_STAT_STAT_EMPTY_Msk                      /* Flag Indicating That The STAT FIFO Is Empty */

/******************  Bit definition for SPACC_SRC_PTR register  *******************/
#define SPACC_SRC_PTR_PTR_DPos                              (3U)
#define SPACC_SRC_PTR_PTR_Pos                               SPACC_SRC_PTR_PTR_DPos
#define SPACC_SRC_PTR_PTR_Msk                               (0x1FFFFFFFUL << SPACC_SRC_PTR_PTR_Pos)             /* 0xFFFFFFF8 */
#define SPACC_SRC_PTR_PTR                                   SPACC_SRC_PTR_PTR_Msk                               /* SPACC Pointer To Source Packet Data Structure In System Memory */
#define SPACC_SRC_PTR_PTR_0                                 (0x1UL << SPACC_SRC_PTR_PTR_Pos)                    /* 0x00000008 */
#define SPACC_SRC_PTR_PTR_1                                 (0x2UL << SPACC_SRC_PTR_PTR_Pos)                    /* 0x00000010 */
#define SPACC_SRC_PTR_PTR_2                                 (0x4UL << SPACC_SRC_PTR_PTR_Pos)                    /* 0x00000020 */
#define SPACC_SRC_PTR_PTR_3                                 (0x8UL << SPACC_SRC_PTR_PTR_Pos)                    /* 0x00000040 */
#define SPACC_SRC_PTR_PTR_4                                 (0x10UL << SPACC_SRC_PTR_PTR_Pos)                   /* 0x00000080 */
#define SPACC_SRC_PTR_PTR_5                                 (0x20UL << SPACC_SRC_PTR_PTR_Pos)                   /* 0x00000100 */
#define SPACC_SRC_PTR_PTR_6                                 (0x40UL << SPACC_SRC_PTR_PTR_Pos)                   /* 0x00000200 */
#define SPACC_SRC_PTR_PTR_7                                 (0x80UL << SPACC_SRC_PTR_PTR_Pos)                   /* 0x00000400 */
#define SPACC_SRC_PTR_PTR_8                                 (0x100UL << SPACC_SRC_PTR_PTR_Pos)                  /* 0x00000800 */
#define SPACC_SRC_PTR_PTR_9                                 (0x200UL << SPACC_SRC_PTR_PTR_Pos)                  /* 0x00001000 */
#define SPACC_SRC_PTR_PTR_10                                (0x400UL << SPACC_SRC_PTR_PTR_Pos)                  /* 0x00002000 */
#define SPACC_SRC_PTR_PTR_11                                (0x800UL << SPACC_SRC_PTR_PTR_Pos)                  /* 0x00004000 */
#define SPACC_SRC_PTR_PTR_12                                (0x1000UL << SPACC_SRC_PTR_PTR_Pos)                 /* 0x00008000 */
#define SPACC_SRC_PTR_PTR_13                                (0x2000UL << SPACC_SRC_PTR_PTR_Pos)                 /* 0x00010000 */
#define SPACC_SRC_PTR_PTR_14                                (0x4000UL << SPACC_SRC_PTR_PTR_Pos)                 /* 0x00020000 */
#define SPACC_SRC_PTR_PTR_15                                (0x8000UL << SPACC_SRC_PTR_PTR_Pos)                 /* 0x00040000 */
#define SPACC_SRC_PTR_PTR_16                                (0x10000UL << SPACC_SRC_PTR_PTR_Pos)                /* 0x00080000 */
#define SPACC_SRC_PTR_PTR_17                                (0x20000UL << SPACC_SRC_PTR_PTR_Pos)                /* 0x00100000 */
#define SPACC_SRC_PTR_PTR_18                                (0x40000UL << SPACC_SRC_PTR_PTR_Pos)                /* 0x00200000 */
#define SPACC_SRC_PTR_PTR_19                                (0x80000UL << SPACC_SRC_PTR_PTR_Pos)                /* 0x00400000 */
#define SPACC_SRC_PTR_PTR_20                                (0x100000UL << SPACC_SRC_PTR_PTR_Pos)               /* 0x00800000 */
#define SPACC_SRC_PTR_PTR_21                                (0x200000UL << SPACC_SRC_PTR_PTR_Pos)               /* 0x01000000 */
#define SPACC_SRC_PTR_PTR_22                                (0x400000UL << SPACC_SRC_PTR_PTR_Pos)               /* 0x02000000 */
#define SPACC_SRC_PTR_PTR_23                                (0x800000UL << SPACC_SRC_PTR_PTR_Pos)               /* 0x04000000 */
#define SPACC_SRC_PTR_PTR_24                                (0x1000000UL << SPACC_SRC_PTR_PTR_Pos)              /* 0x08000000 */
#define SPACC_SRC_PTR_PTR_25                                (0x2000000UL << SPACC_SRC_PTR_PTR_Pos)              /* 0x10000000 */
#define SPACC_SRC_PTR_PTR_26                                (0x4000000UL << SPACC_SRC_PTR_PTR_Pos)              /* 0x20000000 */
#define SPACC_SRC_PTR_PTR_27                                (0x8000000UL << SPACC_SRC_PTR_PTR_Pos)              /* 0x40000000 */
#define SPACC_SRC_PTR_PTR_28                                (0x10000000UL << SPACC_SRC_PTR_PTR_Pos)             /* 0x80000000 */

/******************  Bit definition for SPACC_DST_PTR register  *******************/
#define SPACC_DST_PTR_PTR_DPos                              (3U)
#define SPACC_DST_PTR_PTR_Pos                               SPACC_DST_PTR_PTR_DPos
#define SPACC_DST_PTR_PTR_Msk                               (0x1FFFFFFFUL << SPACC_DST_PTR_PTR_Pos)             /* 0xFFFFFFF8 */
#define SPACC_DST_PTR_PTR                                   SPACC_DST_PTR_PTR_Msk                               /* SPACC Pointer To Destination Packet Data Structure In System Memory */
#define SPACC_DST_PTR_PTR_0                                 (0x1UL << SPACC_DST_PTR_PTR_Pos)                    /* 0x00000008 */
#define SPACC_DST_PTR_PTR_1                                 (0x2UL << SPACC_DST_PTR_PTR_Pos)                    /* 0x00000010 */
#define SPACC_DST_PTR_PTR_2                                 (0x4UL << SPACC_DST_PTR_PTR_Pos)                    /* 0x00000020 */
#define SPACC_DST_PTR_PTR_3                                 (0x8UL << SPACC_DST_PTR_PTR_Pos)                    /* 0x00000040 */
#define SPACC_DST_PTR_PTR_4                                 (0x10UL << SPACC_DST_PTR_PTR_Pos)                   /* 0x00000080 */
#define SPACC_DST_PTR_PTR_5                                 (0x20UL << SPACC_DST_PTR_PTR_Pos)                   /* 0x00000100 */
#define SPACC_DST_PTR_PTR_6                                 (0x40UL << SPACC_DST_PTR_PTR_Pos)                   /* 0x00000200 */
#define SPACC_DST_PTR_PTR_7                                 (0x80UL << SPACC_DST_PTR_PTR_Pos)                   /* 0x00000400 */
#define SPACC_DST_PTR_PTR_8                                 (0x100UL << SPACC_DST_PTR_PTR_Pos)                  /* 0x00000800 */
#define SPACC_DST_PTR_PTR_9                                 (0x200UL << SPACC_DST_PTR_PTR_Pos)                  /* 0x00001000 */
#define SPACC_DST_PTR_PTR_10                                (0x400UL << SPACC_DST_PTR_PTR_Pos)                  /* 0x00002000 */
#define SPACC_DST_PTR_PTR_11                                (0x800UL << SPACC_DST_PTR_PTR_Pos)                  /* 0x00004000 */
#define SPACC_DST_PTR_PTR_12                                (0x1000UL << SPACC_DST_PTR_PTR_Pos)                 /* 0x00008000 */
#define SPACC_DST_PTR_PTR_13                                (0x2000UL << SPACC_DST_PTR_PTR_Pos)                 /* 0x00010000 */
#define SPACC_DST_PTR_PTR_14                                (0x4000UL << SPACC_DST_PTR_PTR_Pos)                 /* 0x00020000 */
#define SPACC_DST_PTR_PTR_15                                (0x8000UL << SPACC_DST_PTR_PTR_Pos)                 /* 0x00040000 */
#define SPACC_DST_PTR_PTR_16                                (0x10000UL << SPACC_DST_PTR_PTR_Pos)                /* 0x00080000 */
#define SPACC_DST_PTR_PTR_17                                (0x20000UL << SPACC_DST_PTR_PTR_Pos)                /* 0x00100000 */
#define SPACC_DST_PTR_PTR_18                                (0x40000UL << SPACC_DST_PTR_PTR_Pos)                /* 0x00200000 */
#define SPACC_DST_PTR_PTR_19                                (0x80000UL << SPACC_DST_PTR_PTR_Pos)                /* 0x00400000 */
#define SPACC_DST_PTR_PTR_20                                (0x100000UL << SPACC_DST_PTR_PTR_Pos)               /* 0x00800000 */
#define SPACC_DST_PTR_PTR_21                                (0x200000UL << SPACC_DST_PTR_PTR_Pos)               /* 0x01000000 */
#define SPACC_DST_PTR_PTR_22                                (0x400000UL << SPACC_DST_PTR_PTR_Pos)               /* 0x02000000 */
#define SPACC_DST_PTR_PTR_23                                (0x800000UL << SPACC_DST_PTR_PTR_Pos)               /* 0x04000000 */
#define SPACC_DST_PTR_PTR_24                                (0x1000000UL << SPACC_DST_PTR_PTR_Pos)              /* 0x08000000 */
#define SPACC_DST_PTR_PTR_25                                (0x2000000UL << SPACC_DST_PTR_PTR_Pos)              /* 0x10000000 */
#define SPACC_DST_PTR_PTR_26                                (0x4000000UL << SPACC_DST_PTR_PTR_Pos)              /* 0x20000000 */
#define SPACC_DST_PTR_PTR_27                                (0x8000000UL << SPACC_DST_PTR_PTR_Pos)              /* 0x40000000 */
#define SPACC_DST_PTR_PTR_28                                (0x10000000UL << SPACC_DST_PTR_PTR_Pos)             /* 0x80000000 */

/******************  Bit definition for SPACC_OFFSET register  *******************/
#define SPACC_OFFSET_SRC_DPos                               (0U)
#define SPACC_OFFSET_SRC_Pos                                SPACC_OFFSET_SRC_DPos
#define SPACC_OFFSET_SRC_Msk                                (0xFFFUL << SPACC_OFFSET_SRC_Pos)                   /* 0x00000FFF */
#define SPACC_OFFSET_SRC                                    SPACC_OFFSET_SRC_Msk                                /* SPACC Source Buffer Offset */
#define SPACC_OFFSET_SRC_0                                  (0x1UL << SPACC_OFFSET_SRC_Pos)                     /* 0x00000001 */
#define SPACC_OFFSET_SRC_1                                  (0x2UL << SPACC_OFFSET_SRC_Pos)                     /* 0x00000002 */
#define SPACC_OFFSET_SRC_2                                  (0x4UL << SPACC_OFFSET_SRC_Pos)                     /* 0x00000004 */
#define SPACC_OFFSET_SRC_3                                  (0x8UL << SPACC_OFFSET_SRC_Pos)                     /* 0x00000008 */
#define SPACC_OFFSET_SRC_4                                  (0x10UL << SPACC_OFFSET_SRC_Pos)                    /* 0x00000010 */
#define SPACC_OFFSET_SRC_5                                  (0x20UL << SPACC_OFFSET_SRC_Pos)                    /* 0x00000020 */
#define SPACC_OFFSET_SRC_6                                  (0x40UL << SPACC_OFFSET_SRC_Pos)                    /* 0x00000040 */
#define SPACC_OFFSET_SRC_7                                  (0x80UL << SPACC_OFFSET_SRC_Pos)                    /* 0x00000080 */
#define SPACC_OFFSET_SRC_8                                  (0x100UL << SPACC_OFFSET_SRC_Pos)                   /* 0x00000100 */
#define SPACC_OFFSET_SRC_9                                  (0x200UL << SPACC_OFFSET_SRC_Pos)                   /* 0x00000200 */
#define SPACC_OFFSET_SRC_10                                 (0x400UL << SPACC_OFFSET_SRC_Pos)                   /* 0x00000400 */
#define SPACC_OFFSET_SRC_11                                 (0x800UL << SPACC_OFFSET_SRC_Pos)                   /* 0x00000800 */

#define SPACC_OFFSET_DST_DPos                               (16U)
#define SPACC_OFFSET_DST_Pos                                SPACC_OFFSET_DST_DPos
#define SPACC_OFFSET_DST_Msk                                (0xFFFUL << SPACC_OFFSET_DST_Pos)                   /* 0x0FFF0000 */
#define SPACC_OFFSET_DST                                    SPACC_OFFSET_DST_Msk                                /* SPACC Destination Buffer Offset */
#define SPACC_OFFSET_DST_0                                  (0x1UL << SPACC_OFFSET_DST_Pos)                     /* 0x00000001 */
#define SPACC_OFFSET_DST_1                                  (0x2UL << SPACC_OFFSET_DST_Pos)                     /* 0x00000002 */
#define SPACC_OFFSET_DST_2                                  (0x4UL << SPACC_OFFSET_DST_Pos)                     /* 0x00000004 */
#define SPACC_OFFSET_DST_3                                  (0x8UL << SPACC_OFFSET_DST_Pos)                     /* 0x00000008 */
#define SPACC_OFFSET_DST_4                                  (0x10UL << SPACC_OFFSET_DST_Pos)                    /* 0x00000010 */
#define SPACC_OFFSET_DST_5                                  (0x20UL << SPACC_OFFSET_DST_Pos)                    /* 0x00000020 */
#define SPACC_OFFSET_DST_6                                  (0x40UL << SPACC_OFFSET_DST_Pos)                    /* 0x00000040 */
#define SPACC_OFFSET_DST_7                                  (0x80UL << SPACC_OFFSET_DST_Pos)                    /* 0x00000080 */
#define SPACC_OFFSET_DST_8                                  (0x100UL << SPACC_OFFSET_DST_Pos)                   /* 0x00000100 */
#define SPACC_OFFSET_DST_9                                  (0x200UL << SPACC_OFFSET_DST_Pos)                   /* 0x00000200 */
#define SPACC_OFFSET_DST_10                                 (0x400UL << SPACC_OFFSET_DST_Pos)                   /* 0x00000400 */
#define SPACC_OFFSET_DST_11                                 (0x800UL << SPACC_OFFSET_DST_Pos)                   /* 0x00000800 */

/******************  Bit definition for SPACC_PRE_AAD_LEN register  *******************/
#define SPACC_PRE_AAD_LEN_LEN_DPos                          (0U)
#define SPACC_PRE_AAD_LEN_LEN_Pos                           SPACC_PRE_AAD_LEN_LEN_DPos
#define SPACC_PRE_AAD_LEN_LEN_Msk                           (0x3FFFUL << SPACC_PRE_AAD_LEN_LEN_Pos)             /* 0x00003FFF */
#define SPACC_PRE_AAD_LEN_LEN                               SPACC_PRE_AAD_LEN_LEN_Msk                           /* SPACC Byte Length Of The Prefixed AAD */
#define SPACC_PRE_AAD_LEN_LEN_0                             (0x1UL << SPACC_PRE_AAD_LEN_LEN_Pos)                /* 0x00000001 */
#define SPACC_PRE_AAD_LEN_LEN_1                             (0x2UL << SPACC_PRE_AAD_LEN_LEN_Pos)                /* 0x00000002 */
#define SPACC_PRE_AAD_LEN_LEN_2                             (0x4UL << SPACC_PRE_AAD_LEN_LEN_Pos)                /* 0x00000004 */
#define SPACC_PRE_AAD_LEN_LEN_3                             (0x8UL << SPACC_PRE_AAD_LEN_LEN_Pos)                /* 0x00000008 */
#define SPACC_PRE_AAD_LEN_LEN_4                             (0x10UL << SPACC_PRE_AAD_LEN_LEN_Pos)               /* 0x00000010 */
#define SPACC_PRE_AAD_LEN_LEN_5                             (0x20UL << SPACC_PRE_AAD_LEN_LEN_Pos)               /* 0x00000020 */
#define SPACC_PRE_AAD_LEN_LEN_6                             (0x40UL << SPACC_PRE_AAD_LEN_LEN_Pos)               /* 0x00000040 */
#define SPACC_PRE_AAD_LEN_LEN_7                             (0x80UL << SPACC_PRE_AAD_LEN_LEN_Pos)               /* 0x00000080 */
#define SPACC_PRE_AAD_LEN_LEN_8                             (0x100UL << SPACC_PRE_AAD_LEN_LEN_Pos)              /* 0x00000100 */
#define SPACC_PRE_AAD_LEN_LEN_9                             (0x200UL << SPACC_PRE_AAD_LEN_LEN_Pos)              /* 0x00000200 */
#define SPACC_PRE_AAD_LEN_LEN_10                            (0x400UL << SPACC_PRE_AAD_LEN_LEN_Pos)              /* 0x00000400 */
#define SPACC_PRE_AAD_LEN_LEN_11                            (0x800UL << SPACC_PRE_AAD_LEN_LEN_Pos)              /* 0x00000800 */
#define SPACC_PRE_AAD_LEN_LEN_12                            (0x1000UL << SPACC_PRE_AAD_LEN_LEN_Pos)             /* 0x00001000 */
#define SPACC_PRE_AAD_LEN_LEN_13                            (0x2000UL << SPACC_PRE_AAD_LEN_LEN_Pos)             /* 0x00002000 */

/******************  Bit definition for SPACC_POST_AAD_LEN register  *******************/
#define SPACC_POST_AAD_LEN_LEN_DPos                         (0U)
#define SPACC_POST_AAD_LEN_LEN_Pos                          SPACC_POST_AAD_LEN_LEN_DPos
#define SPACC_POST_AAD_LEN_LEN_Msk                          (0x3FFFUL << SPACC_POST_AAD_LEN_LEN_Pos)            /* 0x00003FFF */
#define SPACC_POST_AAD_LEN_LEN                              SPACC_POST_AAD_LEN_LEN_Msk                          /* SPACC Byte Length Of The Postfix AAD */
#define SPACC_POST_AAD_LEN_LEN_0                            (0x1UL << SPACC_POST_AAD_LEN_LEN_Pos)               /* 0x00000001 */
#define SPACC_POST_AAD_LEN_LEN_1                            (0x2UL << SPACC_POST_AAD_LEN_LEN_Pos)               /* 0x00000002 */
#define SPACC_POST_AAD_LEN_LEN_2                            (0x4UL << SPACC_POST_AAD_LEN_LEN_Pos)               /* 0x00000004 */
#define SPACC_POST_AAD_LEN_LEN_3                            (0x8UL << SPACC_POST_AAD_LEN_LEN_Pos)               /* 0x00000008 */
#define SPACC_POST_AAD_LEN_LEN_4                            (0x10UL << SPACC_POST_AAD_LEN_LEN_Pos)              /* 0x00000010 */
#define SPACC_POST_AAD_LEN_LEN_5                            (0x20UL << SPACC_POST_AAD_LEN_LEN_Pos)              /* 0x00000020 */
#define SPACC_POST_AAD_LEN_LEN_6                            (0x40UL << SPACC_POST_AAD_LEN_LEN_Pos)              /* 0x00000040 */
#define SPACC_POST_AAD_LEN_LEN_7                            (0x80UL << SPACC_POST_AAD_LEN_LEN_Pos)              /* 0x00000080 */
#define SPACC_POST_AAD_LEN_LEN_8                            (0x100UL << SPACC_POST_AAD_LEN_LEN_Pos)             /* 0x00000100 */
#define SPACC_POST_AAD_LEN_LEN_9                            (0x200UL << SPACC_POST_AAD_LEN_LEN_Pos)             /* 0x00000200 */
#define SPACC_POST_AAD_LEN_LEN_10                           (0x400UL << SPACC_POST_AAD_LEN_LEN_Pos)             /* 0x00000400 */
#define SPACC_POST_AAD_LEN_LEN_11                           (0x800UL << SPACC_POST_AAD_LEN_LEN_Pos)             /* 0x00000800 */
#define SPACC_POST_AAD_LEN_LEN_12                           (0x1000UL << SPACC_POST_AAD_LEN_LEN_Pos)            /* 0x00001000 */
#define SPACC_POST_AAD_LEN_LEN_13                           (0x2000UL << SPACC_POST_AAD_LEN_LEN_Pos)            /* 0x00002000 */

/******************  Bit definition for SPACC_PROC_LEN register  *******************/
#define SPACC_PROC_LEN_LEN_DPos                             (0U)
#define SPACC_PROC_LEN_LEN_Pos                              SPACC_PROC_LEN_LEN_DPos
#define SPACC_PROC_LEN_LEN_Msk                              (0x3FFFUL << SPACC_PROC_LEN_LEN_Pos)                /* 0x00003FFF */
#define SPACC_PROC_LEN_LEN                                  SPACC_PROC_LEN_LEN_Msk                              /* SPACC Byte Length Of The Data To Be Processed */
#define SPACC_PROC_LEN_LEN_0                                (0x1UL << SPACC_PROC_LEN_LEN_Pos)                   /* 0x00000001 */
#define SPACC_PROC_LEN_LEN_1                                (0x2UL << SPACC_PROC_LEN_LEN_Pos)                   /* 0x00000002 */
#define SPACC_PROC_LEN_LEN_2                                (0x4UL << SPACC_PROC_LEN_LEN_Pos)                   /* 0x00000004 */
#define SPACC_PROC_LEN_LEN_3                                (0x8UL << SPACC_PROC_LEN_LEN_Pos)                   /* 0x00000008 */
#define SPACC_PROC_LEN_LEN_4                                (0x10UL << SPACC_PROC_LEN_LEN_Pos)                  /* 0x00000010 */
#define SPACC_PROC_LEN_LEN_5                                (0x20UL << SPACC_PROC_LEN_LEN_Pos)                  /* 0x00000020 */
#define SPACC_PROC_LEN_LEN_6                                (0x40UL << SPACC_PROC_LEN_LEN_Pos)                  /* 0x00000040 */
#define SPACC_PROC_LEN_LEN_7                                (0x80UL << SPACC_PROC_LEN_LEN_Pos)                  /* 0x00000080 */
#define SPACC_PROC_LEN_LEN_8                                (0x100UL << SPACC_PROC_LEN_LEN_Pos)                 /* 0x00000100 */
#define SPACC_PROC_LEN_LEN_9                                (0x200UL << SPACC_PROC_LEN_LEN_Pos)                 /* 0x00000200 */
#define SPACC_PROC_LEN_LEN_10                               (0x400UL << SPACC_PROC_LEN_LEN_Pos)                 /* 0x00000400 */
#define SPACC_PROC_LEN_LEN_11                               (0x800UL << SPACC_PROC_LEN_LEN_Pos)                 /* 0x00000800 */
#define SPACC_PROC_LEN_LEN_12                               (0x1000UL << SPACC_PROC_LEN_LEN_Pos)                /* 0x00001000 */
#define SPACC_PROC_LEN_LEN_13                               (0x2000UL << SPACC_PROC_LEN_LEN_Pos)                /* 0x00002000 */

/******************  Bit definition for SPACC_ICV_LEN register  *******************/
#define SPACC_ICV_LEN_LEN_DPos                              (0U)
#define SPACC_ICV_LEN_LEN_Pos                               SPACC_ICV_LEN_LEN_DPos
#define SPACC_ICV_LEN_LEN_Msk                               (0x3FUL << SPACC_ICV_LEN_LEN_Pos)                   /* 0x0000003F */
#define SPACC_ICV_LEN_LEN                                   SPACC_ICV_LEN_LEN_Msk                               /* SPACC Byte Length Of The ICV */
#define SPACC_ICV_LEN_LEN_0                                 (0x1UL << SPACC_ICV_LEN_LEN_Pos)                    /* 0x00000001 */
#define SPACC_ICV_LEN_LEN_1                                 (0x2UL << SPACC_ICV_LEN_LEN_Pos)                    /* 0x00000002 */
#define SPACC_ICV_LEN_LEN_2                                 (0x4UL << SPACC_ICV_LEN_LEN_Pos)                    /* 0x00000004 */
#define SPACC_ICV_LEN_LEN_3                                 (0x8UL << SPACC_ICV_LEN_LEN_Pos)                    /* 0x00000008 */
#define SPACC_ICV_LEN_LEN_4                                 (0x10UL << SPACC_ICV_LEN_LEN_Pos)                   /* 0x00000010 */
#define SPACC_ICV_LEN_LEN_5                                 (0x20UL << SPACC_ICV_LEN_LEN_Pos)                   /* 0x00000020 */

/******************  Bit definition for SPACC_ICV_OFFSET register  *******************/
#define SPACC_ICV_OFFSET_OFFSET_DPos                        (0U)
#define SPACC_ICV_OFFSET_OFFSET_Pos                         SPACC_ICV_OFFSET_OFFSET_DPos
#define SPACC_ICV_OFFSET_OFFSET_Msk                         (0x3FFFUL << SPACC_ICV_OFFSET_OFFSET_Pos)           /* 0x00003FFF */
#define SPACC_ICV_OFFSET_OFFSET                             SPACC_ICV_OFFSET_OFFSET_Msk                         /* SPACC Byte Offset Of The ICV */
#define SPACC_ICV_OFFSET_OFFSET_0                           (0x1UL << SPACC_ICV_OFFSET_OFFSET_Pos)              /* 0x00000001 */
#define SPACC_ICV_OFFSET_OFFSET_1                           (0x2UL << SPACC_ICV_OFFSET_OFFSET_Pos)              /* 0x00000002 */
#define SPACC_ICV_OFFSET_OFFSET_2                           (0x4UL << SPACC_ICV_OFFSET_OFFSET_Pos)              /* 0x00000004 */
#define SPACC_ICV_OFFSET_OFFSET_3                           (0x8UL << SPACC_ICV_OFFSET_OFFSET_Pos)              /* 0x00000008 */
#define SPACC_ICV_OFFSET_OFFSET_4                           (0x10UL << SPACC_ICV_OFFSET_OFFSET_Pos)             /* 0x00000010 */
#define SPACC_ICV_OFFSET_OFFSET_5                           (0x20UL << SPACC_ICV_OFFSET_OFFSET_Pos)             /* 0x00000020 */
#define SPACC_ICV_OFFSET_OFFSET_6                           (0x40UL << SPACC_ICV_OFFSET_OFFSET_Pos)             /* 0x00000040 */
#define SPACC_ICV_OFFSET_OFFSET_7                           (0x80UL << SPACC_ICV_OFFSET_OFFSET_Pos)             /* 0x00000080 */
#define SPACC_ICV_OFFSET_OFFSET_8                           (0x100UL << SPACC_ICV_OFFSET_OFFSET_Pos)            /* 0x00000100 */
#define SPACC_ICV_OFFSET_OFFSET_9                           (0x200UL << SPACC_ICV_OFFSET_OFFSET_Pos)            /* 0x00000200 */
#define SPACC_ICV_OFFSET_OFFSET_10                          (0x400UL << SPACC_ICV_OFFSET_OFFSET_Pos)            /* 0x00000400 */
#define SPACC_ICV_OFFSET_OFFSET_11                          (0x800UL << SPACC_ICV_OFFSET_OFFSET_Pos)            /* 0x00000800 */
#define SPACC_ICV_OFFSET_OFFSET_12                          (0x1000UL << SPACC_ICV_OFFSET_OFFSET_Pos)           /* 0x00001000 */
#define SPACC_ICV_OFFSET_OFFSET_13                          (0x2000UL << SPACC_ICV_OFFSET_OFFSET_Pos)           /* 0x00002000 */

/******************  Bit definition for SPACC_IV_OFFSET register  *******************/
#define SPACC_IV_OFFSET_OFFSET_DPos                         (0U)
#define SPACC_IV_OFFSET_OFFSET_Pos                          SPACC_IV_OFFSET_OFFSET_DPos
#define SPACC_IV_OFFSET_OFFSET_Msk                          (0x3FFFUL << SPACC_IV_OFFSET_OFFSET_Pos)            /* 0x00003FFF */
#define SPACC_IV_OFFSET_OFFSET                              SPACC_IV_OFFSET_OFFSET_Msk                          /* SPACC Byte Offset Of The IV */
#define SPACC_IV_OFFSET_OFFSET_0                            (0x1UL << SPACC_IV_OFFSET_OFFSET_Pos)               /* 0x00000001 */
#define SPACC_IV_OFFSET_OFFSET_1                            (0x2UL << SPACC_IV_OFFSET_OFFSET_Pos)               /* 0x00000002 */
#define SPACC_IV_OFFSET_OFFSET_2                            (0x4UL << SPACC_IV_OFFSET_OFFSET_Pos)               /* 0x00000004 */
#define SPACC_IV_OFFSET_OFFSET_3                            (0x8UL << SPACC_IV_OFFSET_OFFSET_Pos)               /* 0x00000008 */
#define SPACC_IV_OFFSET_OFFSET_4                            (0x10UL << SPACC_IV_OFFSET_OFFSET_Pos)              /* 0x00000010 */
#define SPACC_IV_OFFSET_OFFSET_5                            (0x20UL << SPACC_IV_OFFSET_OFFSET_Pos)              /* 0x00000020 */
#define SPACC_IV_OFFSET_OFFSET_6                            (0x40UL << SPACC_IV_OFFSET_OFFSET_Pos)              /* 0x00000040 */
#define SPACC_IV_OFFSET_OFFSET_7                            (0x80UL << SPACC_IV_OFFSET_OFFSET_Pos)              /* 0x00000080 */
#define SPACC_IV_OFFSET_OFFSET_8                            (0x100UL << SPACC_IV_OFFSET_OFFSET_Pos)             /* 0x00000100 */
#define SPACC_IV_OFFSET_OFFSET_9                            (0x200UL << SPACC_IV_OFFSET_OFFSET_Pos)             /* 0x00000200 */
#define SPACC_IV_OFFSET_OFFSET_10                           (0x400UL << SPACC_IV_OFFSET_OFFSET_Pos)             /* 0x00000400 */
#define SPACC_IV_OFFSET_OFFSET_11                           (0x800UL << SPACC_IV_OFFSET_OFFSET_Pos)             /* 0x00000800 */
#define SPACC_IV_OFFSET_OFFSET_12                           (0x1000UL << SPACC_IV_OFFSET_OFFSET_Pos)            /* 0x00001000 */
#define SPACC_IV_OFFSET_OFFSET_13                           (0x2000UL << SPACC_IV_OFFSET_OFFSET_Pos)            /* 0x00002000 */

#define SPACC_IV_OFFSET_ENABLE_DPos                         (31U)
#define SPACC_IV_OFFSET_ENABLE_Pos                          SPACC_IV_OFFSET_ENABLE_DPos
#define SPACC_IV_OFFSET_ENABLE_Msk                          (0x1UL << SPACC_IV_OFFSET_ENABLE_Pos)               /* 0x80000000 */
#define SPACC_IV_OFFSET_ENABLE                              SPACC_IV_OFFSET_ENABLE_Msk

/******************  Bit definition for SPACC_SW_CTRL register  *******************/
#define SPACC_SW_CTRL_SW_ID_DPos                            (0U)
#define SPACC_SW_CTRL_SW_ID_Pos                             SPACC_SW_CTRL_SW_ID_DPos
#define SPACC_SW_CTRL_SW_ID_Msk                             (0xFFUL << SPACC_SW_CTRL_SW_ID_Pos)                 /* 0x000000FF */
#define SPACC_SW_CTRL_SW_ID                                 SPACC_SW_CTRL_SW_ID_Msk                             /* Software Tag Of Job ID */
#define SPACC_SW_CTRL_SW_ID_0                               (0x1UL << SPACC_SW_CTRL_SW_ID_Pos)                  /* 0x00000001 */
#define SPACC_SW_CTRL_SW_ID_1                               (0x2UL << SPACC_SW_CTRL_SW_ID_Pos)                  /* 0x00000002 */
#define SPACC_SW_CTRL_SW_ID_2                               (0x4UL << SPACC_SW_CTRL_SW_ID_Pos)                  /* 0x00000004 */
#define SPACC_SW_CTRL_SW_ID_3                               (0x8UL << SPACC_SW_CTRL_SW_ID_Pos)                  /* 0x00000008 */
#define SPACC_SW_CTRL_SW_ID_4                               (0x10UL << SPACC_SW_CTRL_SW_ID_Pos)                 /* 0x00000010 */
#define SPACC_SW_CTRL_SW_ID_5                               (0x20UL << SPACC_SW_CTRL_SW_ID_Pos)                 /* 0x00000020 */
#define SPACC_SW_CTRL_SW_ID_6                               (0x40UL << SPACC_SW_CTRL_SW_ID_Pos)                 /* 0x00000040 */
#define SPACC_SW_CTRL_SW_ID_7                               (0x80UL << SPACC_SW_CTRL_SW_ID_Pos)                 /* 0x00000080 */

#define SPACC_SW_CTRL_PRIORITY_DPos                         (30U)
#define SPACC_SW_CTRL_PRIORITY_Pos                          SPACC_SW_CTRL_PRIORITY_DPos
#define SPACC_SW_CTRL_PRIORITY_Msk                          (0x3UL << SPACC_SW_CTRL_PRIORITY_Pos)               /* 0xC0000000 */
#define SPACC_SW_CTRL_PRIORITY                              SPACC_SW_CTRL_PRIORITY_Msk                          /* Selects The Prioritized Command FIFO To Be Used For Command Dispatch */
#define SPACC_SW_CTRL_PRIORITY_0                            (0x1UL << SPACC_SW_CTRL_PRIORITY_Pos)               /* 0x40000000 */
#define SPACC_SW_CTRL_PRIORITY_1                            (0x2UL << SPACC_SW_CTRL_PRIORITY_Pos)               /* 0x80000000 */

/******************  Bit definition for SPACC_AUX_INFO register  *******************/
#define SPACC_AUX_INFO_CBC_CS_SEL_DPos                      (16U)
#define SPACC_AUX_INFO_CBC_CS_SEL_Pos                       SPACC_AUX_INFO_CBC_CS_SEL_DPos
#define SPACC_AUX_INFO_CBC_CS_SEL_Msk                       (0x3UL << SPACC_AUX_INFO_CBC_CS_SEL_Pos)            /* 0x00030000 */
#define SPACC_AUX_INFO_CBC_CS_SEL                           SPACC_AUX_INFO_CBC_CS_SEL_Msk                       /* Selects the CTS mode to apply for SM4-CBC */
#define SPACC_AUX_INFO_CBC_CS_SEL_0                         (0x1UL << SPACC_AUX_INFO_CBC_CS_SEL_Pos)            /* 0x00010000 */
#define SPACC_AUX_INFO_CBC_CS_SEL_1                         (0x2UL << SPACC_AUX_INFO_CBC_CS_SEL_Pos)            /* 0x00020000 */

/******************  Bit definition for SPACC_CTRL register  *******************/
#define SPACC_CTRL_SM4_CIPH_ALG_DPos                        (0U)
#define SPACC_CTRL_SM4_CIPH_ALG_Pos                         SPACC_CTRL_SM4_CIPH_ALG_DPos
#define SPACC_CTRL_SM4_CIPH_ALG_Msk                         (0xFUL << SPACC_CTRL_SM4_CIPH_ALG_Pos)              /* 0x0000000F */
#define SPACC_CTRL_SM4_CIPH_ALG                             SPACC_CTRL_SM4_CIPH_ALG_Msk                         /* Cipher Algorithm To Employ */
#define SPACC_CTRL_SM4_CIPH_ALG_0                           (0x1UL << SPACC_CTRL_SM4_CIPH_ALG_Pos)              /* 0x00000001 */
#define SPACC_CTRL_SM4_CIPH_ALG_1                           (0x2UL << SPACC_CTRL_SM4_CIPH_ALG_Pos)              /* 0x00000002 */
#define SPACC_CTRL_SM4_CIPH_ALG_2                           (0x4UL << SPACC_CTRL_SM4_CIPH_ALG_Pos)              /* 0x00000004 */
#define SPACC_CTRL_SM4_CIPH_ALG_3                           (0x8UL << SPACC_CTRL_SM4_CIPH_ALG_Pos)              /* 0x00000008 */

#define SPACC_CTRL_SM4_CIPH_MODE_DPos                       (4U)
#define SPACC_CTRL_SM4_CIPH_MODE_Pos                        SPACC_CTRL_SM4_CIPH_MODE_DPos
#define SPACC_CTRL_SM4_CIPH_MODE_Msk                        (0xFUL << SPACC_CTRL_SM4_CIPH_MODE_Pos)             /* 0x000000F0 */
#define SPACC_CTRL_SM4_CIPH_MODE                            SPACC_CTRL_SM4_CIPH_MODE_Msk                        /* SM4 Cipher Mode To Use */
#define SPACC_CTRL_SM4_CIPH_MODE_0                          (0x1UL << SPACC_CTRL_SM4_CIPH_MODE_Pos)             /* 0x00000010 */
#define SPACC_CTRL_SM4_CIPH_MODE_1                          (0x2UL << SPACC_CTRL_SM4_CIPH_MODE_Pos)             /* 0x00000020 */
#define SPACC_CTRL_SM4_CIPH_MODE_2                          (0x4UL << SPACC_CTRL_SM4_CIPH_MODE_Pos)             /* 0x00000040 */
#define SPACC_CTRL_SM4_CIPH_MODE_3                          (0x8UL << SPACC_CTRL_SM4_CIPH_MODE_Pos)             /* 0x00000080 */

#define SPACC_CTRL_SM_HASH_ALG_DPos                         (8U)
#define SPACC_CTRL_SM_HASH_ALG_Pos                          SPACC_CTRL_SM_HASH_ALG_DPos
#define SPACC_CTRL_SM_HASH_ALG_Msk                          (0x1FUL << SPACC_CTRL_SM_HASH_ALG_Pos)              /* 0x0001F00 */
#define SPACC_CTRL_SM_HASH_ALG                              SPACC_CTRL_SM_HASH_ALG_Msk                          /* Hash Algorithm To Employ */
#define SPACC_CTRL_SM_HASH_ALG_0                            (0x1UL << SPACC_CTRL_SM_HASH_ALG_Pos)               /* 0x00000100 */
#define SPACC_CTRL_SM_HASH_ALG_1                            (0x2UL << SPACC_CTRL_SM_HASH_ALG_Pos)               /* 0x00000200 */
#define SPACC_CTRL_SM_HASH_ALG_2                            (0x4UL << SPACC_CTRL_SM_HASH_ALG_Pos)               /* 0x00000400 */
#define SPACC_CTRL_SM_HASH_ALG_3                            (0x8UL << SPACC_CTRL_SM_HASH_ALG_Pos)               /* 0x00000800 */
#define SPACC_CTRL_SM_HASH_ALG_4                            (0x10UL << SPACC_CTRL_SM_HASH_ALG_Pos)              /* 0x00001000 */

#define SPACC_CTRL_SM3_HASH_MODE_DPos                       (13U)
#define SPACC_CTRL_SM3_HASH_MODE_Pos                        SPACC_CTRL_SM3_HASH_MODE_DPos
#define SPACC_CTRL_SM3_HASH_MODE_Msk                        (0x3UL << SPACC_CTRL_SM3_HASH_MODE_Pos)             /* 0x00006000 */
#define SPACC_CTRL_SM3_HASH_MODE                            SPACC_CTRL_SM3_HASH_MODE_Msk                        /* SM3 Hash Mode To Use */
#define SPACC_CTRL_SM3_HASH_MODE_0                          (0x1UL << SPACC_CTRL_SM3_HASH_MODE_Pos)             /* 0x00002000 */
#define SPACC_CTRL_SM3_HASH_MODE_1                          (0x2UL << SPACC_CTRL_SM3_HASH_MODE_Pos)             /* 0x00004000 */

#define SPACC_CTRL_ENCRYPT_DPos                             (15U)
#define SPACC_CTRL_ENCRYPT_Pos                              SPACC_CTRL_ENCRYPT_DPos
#define SPACC_CTRL_ENCRYPT_Msk                              (0x1UL << SPACC_CTRL_ENCRYPT_Pos)                   /* 0x00008000 */
#define SPACC_CTRL_ENCRYPT                                  SPACC_CTRL_ENCRYPT_Msk                              /* Transform To Apply */

#define SPACC_CTRL_CTX_IDX_DPos                             (16U)
#define SPACC_CTRL_CTX_IDX_Pos                              SPACC_CTRL_CTX_IDX_DPos
#define SPACC_CTRL_CTX_IDX_Msk                              (0xFFUL << SPACC_CTRL_CTX_IDX_Pos)                  /* 0x00FF0000 */
#define SPACC_CTRL_CTX_IDX                                  SPACC_CTRL_CTX_IDX_Msk                              /* Context Index */
#define SPACC_CTRL_CTX_IDX_0                                (0x1UL << SPACC_CTRL_CTX_IDX_Pos)                   /* 0x00010000 */
#define SPACC_CTRL_CTX_IDX_1                                (0x2UL << SPACC_CTRL_CTX_IDX_Pos)                   /* 0x00020000 */
#define SPACC_CTRL_CTX_IDX_2                                (0x4UL << SPACC_CTRL_CTX_IDX_Pos)                   /* 0x00040000 */
#define SPACC_CTRL_CTX_IDX_3                                (0x8UL << SPACC_CTRL_CTX_IDX_Pos)                   /* 0x00080000 */
#define SPACC_CTRL_CTX_IDX_4                                (0x10UL << SPACC_CTRL_CTX_IDX_Pos)                  /* 0x00100000 */
#define SPACC_CTRL_CTX_IDX_5                                (0x20UL << SPACC_CTRL_CTX_IDX_Pos)                  /* 0x00200000 */
#define SPACC_CTRL_CTX_IDX_6                                (0x40UL << SPACC_CTRL_CTX_IDX_Pos)                  /* 0x00400000 */
#define SPACC_CTRL_CTX_IDX_7                                (0x80UL << SPACC_CTRL_CTX_IDX_Pos)                  /* 0x00800000 */

#define SPACC_CTRL_SEC_KEY_DPos                             (24U)
#define SPACC_CTRL_SEC_KEY_Pos                              SPACC_CTRL_SEC_KEY_DPos
#define SPACC_CTRL_SEC_KEY_Msk                              (0x1UL << SPACC_CTRL_SEC_KEY_Pos)                   /* 0x01000000 */
#define SPACC_CTRL_SEC_KEY                                  SPACC_CTRL_SEC_KEY_Msk                              /* Use The Secure Key Port For Fetching Cipher Key Information */

#define SPACC_CTRL_AAD_COPY_DPos                            (25U)
#define SPACC_CTRL_AAD_COPY_Pos                             SPACC_CTRL_AAD_COPY_DPos
#define SPACC_CTRL_AAD_COPY_Msk                             (0x1UL << SPACC_CTRL_AAD_COPY_Pos)                  /* 0x02000000 */
#define SPACC_CTRL_AAD_COPY                                 SPACC_CTRL_AAD_COPY_Msk                             /* Copy The PRE_AAD To The Destination Buffer */

#define SPACC_CTRL_ICV_PT_DPos                              (26U)
#define SPACC_CTRL_ICV_PT_Pos                               SPACC_CTRL_ICV_PT_DPos
#define SPACC_CTRL_ICV_PT_Msk                               (0x1UL << SPACC_CTRL_ICV_PT_Pos)                    /* 0x04000000 */
#define SPACC_CTRL_ICV_PT                                   SPACC_CTRL_ICV_PT_Msk                               /* ICV Computed Set */

#define SPACC_CTRL_ICV_ENC_DPos                             (27U)
#define SPACC_CTRL_ICV_ENC_Pos                              SPACC_CTRL_ICV_ENC_DPos
#define SPACC_CTRL_ICV_ENC_Msk                              (0x1UL << SPACC_CTRL_ICV_ENC_Pos)                   /* 0x08000000 */
#define SPACC_CTRL_ICV_ENC                                  SPACC_CTRL_ICV_ENC_Msk                              /* ICV Computed Encrypted */

#define SPACC_CTRL_ICV_APPEND_DPos                          (28U)
#define SPACC_CTRL_ICV_APPEND_Pos                           SPACC_CTRL_ICV_APPEND_DPos
#define SPACC_CTRL_ICV_APPEND_Msk                           (0x1UL << SPACC_CTRL_ICV_APPEND_Pos)                /* 0x10000000 */
#define SPACC_CTRL_ICV_APPEND                               SPACC_CTRL_ICV_APPEND_Msk                           /* ICV Computed Appended */

#define SPACC_CTRL_KEY_EXP_DPos                             (29U)
#define SPACC_CTRL_KEY_EXP_Pos                              SPACC_CTRL_KEY_EXP_DPos
#define SPACC_CTRL_KEY_EXP_Msk                              (0x1UL << SPACC_CTRL_KEY_EXP_Pos)                   /* 0x20000000 */
#define SPACC_CTRL_KEY_EXP                                  SPACC_CTRL_KEY_EXP_Msk                              /* Key Expansion */

#define SPACC_CTRL_MSG_BEGIN_DPos                           (30U)
#define SPACC_CTRL_MSG_BEGIN_Pos                            SPACC_CTRL_MSG_BEGIN_DPos
#define SPACC_CTRL_MSG_BEGIN_Msk                            (0x1UL << SPACC_CTRL_MSG_BEGIN_Pos)                 /* 0x40000000 */
#define SPACC_CTRL_MSG_BEGIN                                SPACC_CTRL_MSG_BEGIN_Msk                            /* Begin Flag For Partial Packet Processing */

#define SPACC_CTRL_MSG_END_DPos                             (31U)
#define SPACC_CTRL_MSG_END_Pos                              SPACC_CTRL_MSG_END_DPos
#define SPACC_CTRL_MSG_END_Msk                              (0x1UL << SPACC_CTRL_MSG_END_Pos)                   /* 0x80000000 */
#define SPACC_CTRL_MSG_END                                  SPACC_CTRL_MSG_END_Msk                              /* End Flag For Partial Packet Processing */

/******************  Bit definition for SPACC_STAT_POP register  *******************/
#define SPACC_STAT_POP_POP_DPos                             (0U)
#define SPACC_STAT_POP_POP_Pos                              SPACC_STAT_POP_POP_DPos
#define SPACC_STAT_POP_POP_Msk                              (0x1UL << SPACC_STAT_POP_POP_Pos)                   /* 0x00000001 */
#define SPACC_STAT_POP_POP                                  SPACC_STAT_POP_POP_Msk                              /* SPACC Status FIFO Pop */

/******************  Bit definition for SPACC_STATUS register  *******************/
#define SPACC_STATUS_SW_ID_DPos                             (0U)
#define SPACC_STATUS_SW_ID_Pos                              SPACC_STATUS_SW_ID_DPos
#define SPACC_STATUS_SW_ID_Msk                              (0xFFUL << SPACC_STATUS_SW_ID_Pos)                  /* 0x000000FF */
#define SPACC_STATUS_SW_ID                                  SPACC_STATUS_SW_ID_Msk                              /* Software Tag Of Job ID */
#define SPACC_STATUS_SW_ID_0                                (0x1UL << SPACC_STATUS_SW_ID_Pos)                   /* 0x00000001 */
#define SPACC_STATUS_SW_ID_1                                (0x2UL << SPACC_STATUS_SW_ID_Pos)                   /* 0x00000002 */
#define SPACC_STATUS_SW_ID_2                                (0x4UL << SPACC_STATUS_SW_ID_Pos)                   /* 0x00000004 */
#define SPACC_STATUS_SW_ID_3                                (0x8UL << SPACC_STATUS_SW_ID_Pos)                   /* 0x00000008 */
#define SPACC_STATUS_SW_ID_4                                (0x10UL << SPACC_STATUS_SW_ID_Pos)                  /* 0x00000010 */
#define SPACC_STATUS_SW_ID_5                                (0x20UL << SPACC_STATUS_SW_ID_Pos)                  /* 0x00000020 */
#define SPACC_STATUS_SW_ID_6                                (0x40UL << SPACC_STATUS_SW_ID_Pos)                  /* 0x00000040 */
#define SPACC_STATUS_SW_ID_7                                (0x80UL << SPACC_STATUS_SW_ID_Pos)                  /* 0x00000080 */

#define SPACC_STATUS_RET_CODE_DPos                          (24U)
#define SPACC_STATUS_RET_CODE_Pos                           SPACC_STATUS_RET_CODE_DPos
#define SPACC_STATUS_RET_CODE_Msk                           (0x7UL << SPACC_STATUS_RET_CODE_Pos)                /* 0x07000000 */
#define SPACC_STATUS_RET_CODE                               SPACC_STATUS_RET_CODE_Msk                           /* Result Of Operation */
#define SPACC_STATUS_RET_CODE_0                             (0x1UL << SPACC_STATUS_RET_CODE_Pos)                /* 0x00000001 */
#define SPACC_STATUS_RET_CODE_1                             (0x2UL << SPACC_STATUS_RET_CODE_Pos)                /* 0x00000002 */
#define SPACC_STATUS_RET_CODE_2                             (0x4UL << SPACC_STATUS_RET_CODE_Pos)                /* 0x00000004 */

#define SPACC_STATUS_SEC_CMD_DPos                           (31U)
#define SPACC_STATUS_SEC_CMD_Pos                            SPACC_STATUS_SEC_CMD_DPos
#define SPACC_STATUS_SEC_CMD_Msk                            (0x1UL << SPACC_STATUS_SEC_CMD_Pos)                 /* 0x80000000 */
#define SPACC_STATUS_SEC_CMD                                SPACC_STATUS_SEC_CMD_Msk                            /* Indicates If The Command Executed In Secure Or Normal Mode */

/******************  Bit definition for SPACC_STAT_WD_CTRL register  *******************/
#define SPACC_STAT_WD_CTRL_TIMER_DPos                       (0U)
#define SPACC_STAT_WD_CTRL_TIMER_Pos                        SPACC_STAT_WD_CTRL_TIMER_DPos
#define SPACC_STAT_WD_CTRL_TIMER_Msk                        (0xFFFFFFUL << SPACC_STAT_WD_CTRL_TIMER_Pos)        /* 0x00FFFFFF */
#define SPACC_STAT_WD_CTRL_TIMER                            SPACC_STAT_WD_CTRL_TIMER_Msk                        /* SPACC Status Watchdog Timer */
#define SPACC_STAT_WD_CTRL_TIMER_0                          (0x1UL << SPACC_STAT_WD_CTRL_TIMER_Pos)             /* 0x00000001 */
#define SPACC_STAT_WD_CTRL_TIMER_1                          (0x2UL << SPACC_STAT_WD_CTRL_TIMER_Pos)             /* 0x00000002 */
#define SPACC_STAT_WD_CTRL_TIMER_2                          (0x4UL << SPACC_STAT_WD_CTRL_TIMER_Pos)             /* 0x00000004 */
#define SPACC_STAT_WD_CTRL_TIMER_3                          (0x8UL << SPACC_STAT_WD_CTRL_TIMER_Pos)             /* 0x00000008 */
#define SPACC_STAT_WD_CTRL_TIMER_4                          (0x10UL << SPACC_STAT_WD_CTRL_TIMER_Pos)            /* 0x00000010 */
#define SPACC_STAT_WD_CTRL_TIMER_5                          (0x20UL << SPACC_STAT_WD_CTRL_TIMER_Pos)            /* 0x00000020 */
#define SPACC_STAT_WD_CTRL_TIMER_6                          (0x40UL << SPACC_STAT_WD_CTRL_TIMER_Pos)            /* 0x00000040 */
#define SPACC_STAT_WD_CTRL_TIMER_7                          (0x80UL << SPACC_STAT_WD_CTRL_TIMER_Pos)            /* 0x00000080 */
#define SPACC_STAT_WD_CTRL_TIMER_8                          (0x100UL << SPACC_STAT_WD_CTRL_TIMER_Pos)           /* 0x00000100 */
#define SPACC_STAT_WD_CTRL_TIMER_9                          (0x200UL << SPACC_STAT_WD_CTRL_TIMER_Pos)           /* 0x00000200 */
#define SPACC_STAT_WD_CTRL_TIMER_10                         (0x400UL << SPACC_STAT_WD_CTRL_TIMER_Pos)           /* 0x00000400 */
#define SPACC_STAT_WD_CTRL_TIMER_11                         (0x800UL << SPACC_STAT_WD_CTRL_TIMER_Pos)           /* 0x00000800 */
#define SPACC_STAT_WD_CTRL_TIMER_12                         (0x1000UL << SPACC_STAT_WD_CTRL_TIMER_Pos)          /* 0x00001000 */
#define SPACC_STAT_WD_CTRL_TIMER_13                         (0x2000UL << SPACC_STAT_WD_CTRL_TIMER_Pos)          /* 0x00002000 */
#define SPACC_STAT_WD_CTRL_TIMER_14                         (0x4000UL << SPACC_STAT_WD_CTRL_TIMER_Pos)          /* 0x00004000 */
#define SPACC_STAT_WD_CTRL_TIMER_15                         (0x8000UL << SPACC_STAT_WD_CTRL_TIMER_Pos)          /* 0x00008000 */
#define SPACC_STAT_WD_CTRL_TIMER_16                         (0x10000UL << SPACC_STAT_WD_CTRL_TIMER_Pos)         /* 0x00010000 */
#define SPACC_STAT_WD_CTRL_TIMER_17                         (0x20000UL << SPACC_STAT_WD_CTRL_TIMER_Pos)         /* 0x00020000 */
#define SPACC_STAT_WD_CTRL_TIMER_18                         (0x40000UL << SPACC_STAT_WD_CTRL_TIMER_Pos)         /* 0x00040000 */
#define SPACC_STAT_WD_CTRL_TIMER_19                         (0x80000UL << SPACC_STAT_WD_CTRL_TIMER_Pos)         /* 0x00080000 */
#define SPACC_STAT_WD_CTRL_TIMER_20                         (0x100000UL << SPACC_STAT_WD_CTRL_TIMER_Pos)        /* 0x00100000 */
#define SPACC_STAT_WD_CTRL_TIMER_21                         (0x200000UL << SPACC_STAT_WD_CTRL_TIMER_Pos)        /* 0x00200000 */
#define SPACC_STAT_WD_CTRL_TIMER_22                         (0x400000UL << SPACC_STAT_WD_CTRL_TIMER_Pos)        /* 0x00400000 */
#define SPACC_STAT_WD_CTRL_TIMER_23                         (0x800000UL << SPACC_STAT_WD_CTRL_TIMER_Pos)        /* 0x00800000 */

/******************  Bit definition for SPACC_KEY_SZ register  *******************/
#define SPACC_KEY_SZ_SIZE_DPos                              (0U)
#define SPACC_KEY_SZ_SIZE_Pos                               SPACC_KEY_SZ_SIZE_DPos
#define SPACC_KEY_SZ_SIZE_Msk                               (0xFFUL << SPACC_KEY_SZ_SIZE_Pos)                   /* 0x000000FF */
#define SPACC_KEY_SZ_SIZE                                   SPACC_KEY_SZ_SIZE_Msk                               /* Key Size */
#define SPACC_KEY_SZ_SIZE_0                                 (0x1UL << SPACC_KEY_SZ_SIZE_Pos)                    /* 0x00000001 */
#define SPACC_KEY_SZ_SIZE_1                                 (0x2UL << SPACC_KEY_SZ_SIZE_Pos)                    /* 0x00000002 */
#define SPACC_KEY_SZ_SIZE_2                                 (0x4UL << SPACC_KEY_SZ_SIZE_Pos)                    /* 0x00000004 */
#define SPACC_KEY_SZ_SIZE_3                                 (0x8UL << SPACC_KEY_SZ_SIZE_Pos)                    /* 0x00000008 */
#define SPACC_KEY_SZ_SIZE_4                                 (0x10UL << SPACC_KEY_SZ_SIZE_Pos)                   /* 0x00000010 */
#define SPACC_KEY_SZ_SIZE_5                                 (0x20UL << SPACC_KEY_SZ_SIZE_Pos)                   /* 0x00000020 */
#define SPACC_KEY_SZ_SIZE_6                                 (0x40UL << SPACC_KEY_SZ_SIZE_Pos)                   /* 0x00000040 */
#define SPACC_KEY_SZ_SIZE_7                                 (0x80UL << SPACC_KEY_SZ_SIZE_Pos)                   /* 0x00000080 */

#define SPACC_KEY_SZ_CTX_IDX_DPos                           (8U)
#define SPACC_KEY_SZ_CTX_IDX_Pos                            SPACC_KEY_SZ_CTX_IDX_DPos
#define SPACC_KEY_SZ_CTX_IDX_Msk                            (0xFFUL << SPACC_KEY_SZ_CTX_IDX_Pos)                /* 0x0000FF00 */
#define SPACC_KEY_SZ_CTX_IDX                                SPACC_KEY_SZ_CTX_IDX_Msk                            /* Context Index */
#define SPACC_KEY_SZ_CTX_IDX_0                              (0x1UL << SPACC_KEY_SZ_CTX_IDX_Pos)                 /* 0x00000100 */
#define SPACC_KEY_SZ_CTX_IDX_1                              (0x2UL << SPACC_KEY_SZ_CTX_IDX_Pos)                 /* 0x00000200 */
#define SPACC_KEY_SZ_CTX_IDX_2                              (0x4UL << SPACC_KEY_SZ_CTX_IDX_Pos)                 /* 0x00000400 */
#define SPACC_KEY_SZ_CTX_IDX_3                              (0x8UL << SPACC_KEY_SZ_CTX_IDX_Pos)                 /* 0x00000800 */
#define SPACC_KEY_SZ_CTX_IDX_4                              (0x10UL << SPACC_KEY_SZ_CTX_IDX_Pos)                /* 0x00001000 */
#define SPACC_KEY_SZ_CTX_IDX_5                              (0x20UL << SPACC_KEY_SZ_CTX_IDX_Pos)                /* 0x00002000 */
#define SPACC_KEY_SZ_CTX_IDX_6                              (0x40UL << SPACC_KEY_SZ_CTX_IDX_Pos)                /* 0x00004000 */
#define SPACC_KEY_SZ_CTX_IDX_7                              (0x80UL << SPACC_KEY_SZ_CTX_IDX_Pos)                /* 0x00008000 */

#define SPACC_KEY_SZ_CIPHER_DPos                            (31U)
#define SPACC_KEY_SZ_CIPHER_Pos                             SPACC_KEY_SZ_CIPHER_DPos
#define SPACC_KEY_SZ_CIPHER_Msk                             (0x1UL << SPACC_KEY_SZ_CIPHER_Pos)                  /* 0x80000000 */
#define SPACC_KEY_SZ_CIPHER                                 SPACC_KEY_SZ_CIPHER_Msk                             /* Indicates Whether This Key Size Is A Cipher Key Or A Hash Key */

/* @name PKA register bits definition */
/******************  Bit definition for PKA_CTRL register  *******************/
#define PKA_CTRL_PARTIAL_RADIX_DPos                         (0U)
#define PKA_CTRL_PARTIAL_RADIX_Pos                          PKA_CTRL_PARTIAL_RADIX_DPos
#define PKA_CTRL_PARTIAL_RADIX_Msk                          (0xFFUL << PKA_CTRL_PARTIAL_RADIX_Pos)              /* 0x000000FF */
#define PKA_CTRL_PARTIAL_RADIX                              PKA_CTRL_PARTIAL_RADIX_Msk                          /*  Selects a partial field from within the base radix */
#define PKA_CTRL_PARTIAL_RADIX_0                            (0x01UL << PKA_CTRL_PARTIAL_RADIX_Pos)              /* 0x00000001 */
#define PKA_CTRL_PARTIAL_RADIX_1                            (0x02UL << PKA_CTRL_PARTIAL_RADIX_Pos)              /* 0x00000002 */
#define PKA_CTRL_PARTIAL_RADIX_2                            (0x04UL << PKA_CTRL_PARTIAL_RADIX_Pos)              /* 0x00000004 */
#define PKA_CTRL_PARTIAL_RADIX_3                            (0x08UL << PKA_CTRL_PARTIAL_RADIX_Pos)              /* 0x00000008 */
#define PKA_CTRL_PARTIAL_RADIX_4                            (0x10UL << PKA_CTRL_PARTIAL_RADIX_Pos)              /* 0x00000010 */
#define PKA_CTRL_PARTIAL_RADIX_5                            (0x20UL << PKA_CTRL_PARTIAL_RADIX_Pos)              /* 0x00000020 */
#define PKA_CTRL_PARTIAL_RADIX_6                            (0x40UL << PKA_CTRL_PARTIAL_RADIX_Pos)              /* 0x00000040 */
#define PKA_CTRL_PARTIAL_RADIX_7                            (0x80UL << PKA_CTRL_PARTIAL_RADIX_Pos)              /* 0x00000080 */

#define PKA_CTRL_BASE_RADIX_DPos                            (8U)
#define PKA_CTRL_BASE_RADIX_Pos                             PKA_CTRL_BASE_RADIX_DPos
#define PKA_CTRL_BASE_RADIX_Msk                             (0x7UL << PKA_CTRL_BASE_RADIX_Pos)                  /* 0x00000300 */
#define PKA_CTRL_BASE_RADIX                                 PKA_CTRL_BASE_RADIX_Msk                             /* Sets the size of the base operand size (radix) */
#define PKA_CTRL_BASE_RADIX_0                               (0x01UL << PKA_CTRL_BASE_RADIX_Pos)                 /* 0x00000100 */
#define PKA_CTRL_BASE_RADIX_1                               (0x02UL << PKA_CTRL_BASE_RADIX_Pos)                 /* 0x00000200 */
#define PKA_CTRL_BASE_RADIX_2                               (0x04UL << PKA_CTRL_BASE_RADIX_Pos)                 /* 0x00000400 */

#define PKA_CTRL_M521_MODE_DPos                             (16U)
#define PKA_CTRL_M521_MODE_Pos                              PKA_CTRL_M521_MODE_DPos
#define PKA_CTRL_M521_MODE_Msk                              (0x1FUL << PKA_CTRL_M521_MODE_Pos)                  /* 0x001F0000 */
#define PKA_CTRL_M521_MODE                                  PKA_CTRL_M521_MODE_Msk                              /* Sets operating to Mersenne M-521 */
#define PKA_CTRL_M521_MODE_0                                (0x01UL << PKA_CTRL_M521_MODE_Pos)                  /* 0x00010000 */
#define PKA_CTRL_M521_MODE_1                                (0x02UL << PKA_CTRL_M521_MODE_Pos)                  /* 0x00020000 */
#define PKA_CTRL_M521_MODE_2                                (0x04UL << PKA_CTRL_M521_MODE_Pos)                  /* 0x00040000 */
#define PKA_CTRL_M521_MODE_3                                (0x08UL << PKA_CTRL_M521_MODE_Pos)                  /* 0x00080000 */
#define PKA_CTRL_M521_MODE_4                                (0x10UL << PKA_CTRL_M521_MODE_Pos)                  /* 0x00100000 */

#define PKA_CTRL_STOP_RQST_DPos                             (27U)
#define PKA_CTRL_STOP_RQST_Pos                              PKA_CTRL_STOP_RQST_DPos
#define PKA_CTRL_STOP_RQST_Msk                              (0x1UL << PKA_CTRL_STOP_RQST_Pos)                   /* 0x08000000 */
#define PKA_CTRL_STOP_RQST                                  PKA_CTRL_STOP_RQST_Msk                              /* Requests PKA to halt at the next instruction boundary */

#define PKA_CTRL_GO_DPos                                    (31U)
#define PKA_CTRL_GO_Pos                                     PKA_CTRL_GO_DPos
#define PKA_CTRL_GO_Msk                                     (0x1UL << PKA_CTRL_GO_Pos)                          /* 0x80000000 */
#define PKA_CTRL_GO                                         PKA_CTRL_GO_Msk                                     /* Starts the PKA execution */

/******************  Bit definition for PKA_ENTRY_PNT register  *******************/
#define PKA_ENTRY_PNT_ADDR_DPos                             (0U)
#define PKA_ENTRY_PNT_ADDR_Pos                              PKA_ENTRY_PNT_ADDR_DPos
#define PKA_ENTRY_PNT_ADDR_Msk                              (0xFFFUL << PKA_ENTRY_PNT_ADDR_Pos)                 /* 0x00000FFF */
#define PKA_ENTRY_PNT_ADDR                                  PKA_ENTRY_PNT_ADDR_Msk                              /* Program entry point */
#define PKA_ENTRY_PNT_ADDR_0                                (0x1UL << PKA_ENTRY_PNT_ADDR_Pos)                   /* 0x00000001 */
#define PKA_ENTRY_PNT_ADDR_1                                (0x2UL << PKA_ENTRY_PNT_ADDR_Pos)                   /* 0x00000002 */
#define PKA_ENTRY_PNT_ADDR_2                                (0x4UL << PKA_ENTRY_PNT_ADDR_Pos)                   /* 0x00000004 */
#define PKA_ENTRY_PNT_ADDR_3                                (0x8UL << PKA_ENTRY_PNT_ADDR_Pos)                   /* 0x00000008 */
#define PKA_ENTRY_PNT_ADDR_4                                (0x10UL << PKA_ENTRY_PNT_ADDR_Pos)                  /* 0x00000010 */
#define PKA_ENTRY_PNT_ADDR_5                                (0x20UL << PKA_ENTRY_PNT_ADDR_Pos)                  /* 0x00000020 */
#define PKA_ENTRY_PNT_ADDR_6                                (0x40UL << PKA_ENTRY_PNT_ADDR_Pos)                  /* 0x00000040 */
#define PKA_ENTRY_PNT_ADDR_7                                (0x80UL << PKA_ENTRY_PNT_ADDR_Pos)                  /* 0x00000080 */
#define PKA_ENTRY_PNT_ADDR_8                                (0x100UL << PKA_ENTRY_PNT_ADDR_Pos)                 /* 0x00000100 */
#define PKA_ENTRY_PNT_ADDR_9                                (0x200UL << PKA_ENTRY_PNT_ADDR_Pos)                 /* 0x00000200 */
#define PKA_ENTRY_PNT_ADDR_10                               (0x400UL << PKA_ENTRY_PNT_ADDR_Pos)                 /* 0x00000400 */
#define PKA_ENTRY_PNT_ADDR_11                               (0x800UL << PKA_ENTRY_PNT_ADDR_Pos)                 /* 0x00000800 */
/* Compatibility spellings: the historical macro name dropped the "Y" of the
   register name (ENTRT instead of ENTRY).  They keep existing code compiling;
   new code shall use the PKA_ENTRY_PNT_ADDR_* spelling above. */
#define PKA_ENTRT_PNT_ADDR_DPos                             PKA_ENTRY_PNT_ADDR_DPos
#define PKA_ENTRT_PNT_ADDR_Pos                              PKA_ENTRY_PNT_ADDR_Pos
#define PKA_ENTRT_PNT_ADDR_Msk                              PKA_ENTRY_PNT_ADDR_Msk
#define PKA_ENTRT_PNT_ADDR                                  PKA_ENTRY_PNT_ADDR
#define PKA_ENTRT_PNT_ADDR_0                               PKA_ENTRY_PNT_ADDR_0
#define PKA_ENTRT_PNT_ADDR_1                               PKA_ENTRY_PNT_ADDR_1
#define PKA_ENTRT_PNT_ADDR_2                               PKA_ENTRY_PNT_ADDR_2
#define PKA_ENTRT_PNT_ADDR_3                               PKA_ENTRY_PNT_ADDR_3
#define PKA_ENTRT_PNT_ADDR_4                               PKA_ENTRY_PNT_ADDR_4
#define PKA_ENTRT_PNT_ADDR_5                               PKA_ENTRY_PNT_ADDR_5
#define PKA_ENTRT_PNT_ADDR_6                               PKA_ENTRY_PNT_ADDR_6
#define PKA_ENTRT_PNT_ADDR_7                               PKA_ENTRY_PNT_ADDR_7
#define PKA_ENTRT_PNT_ADDR_8                               PKA_ENTRY_PNT_ADDR_8
#define PKA_ENTRT_PNT_ADDR_9                               PKA_ENTRY_PNT_ADDR_9
#define PKA_ENTRT_PNT_ADDR_10                              PKA_ENTRY_PNT_ADDR_10
#define PKA_ENTRT_PNT_ADDR_11                              PKA_ENTRY_PNT_ADDR_11

/******************  Bit definition for PKA_RTN_CODE register  *******************/
#define PKA_RTN_CODE_STOP_REASON_DPos                       (16U)
#define PKA_RTN_CODE_STOP_REASON_Pos                        PKA_RTN_CODE_STOP_REASON_DPos
#define PKA_RTN_CODE_STOP_REASON_Msk                        (0xFFUL << PKA_RTN_CODE_STOP_REASON_Pos)            /* 0x00FF0000 */
#define PKA_RTN_CODE_STOP_REASON                            PKA_RTN_CODE_STOP_REASON_Msk                        /* Indicates why the PKA stopped */
#define PKA_RTN_CODE_STOP_REASON_0                          (0x1UL << PKA_RTN_CODE_STOP_REASON_Pos)             /* 0x00010000 */
#define PKA_RTN_CODE_STOP_REASON_1                          (0x2UL << PKA_RTN_CODE_STOP_REASON_Pos)             /* 0x00020000 */
#define PKA_RTN_CODE_STOP_REASON_2                          (0x4UL << PKA_RTN_CODE_STOP_REASON_Pos)             /* 0x00040000 */
#define PKA_RTN_CODE_STOP_REASON_3                          (0x8UL << PKA_RTN_CODE_STOP_REASON_Pos)             /* 0x00080000 */
#define PKA_RTN_CODE_STOP_REASON_4                          (0x10UL << PKA_RTN_CODE_STOP_REASON_Pos)            /* 0x00100000 */
#define PKA_RTN_CODE_STOP_REASON_5                          (0x20UL << PKA_RTN_CODE_STOP_REASON_Pos)            /* 0x00200000 */
#define PKA_RTN_CODE_STOP_REASON_6                          (0x40UL << PKA_RTN_CODE_STOP_REASON_Pos)            /* 0x00400000 */
#define PKA_RTN_CODE_STOP_REASON_7                          (0x80UL << PKA_RTN_CODE_STOP_REASON_Pos)            /* 0x00800000 */

#define PKA_RTN_CODE_DPA_EN_DPos                            (27U)
#define PKA_RTN_CODE_DPA_EN_Pos                             PKA_RTN_CODE_DPA_EN_DPos
#define PKA_RTN_CODE_DPA_EN_Msk                             (0x1UL << PKA_RTN_CODE_DPA_EN_Pos)                  /* 0x08000000 */
#define PKA_RTN_CODE_DPA_EN                                 PKA_RTN_CODE_DPA_EN_Msk                             /* Indicates that the core is capable of operating in TA and/or DPA mode. */

#define PKA_RTN_CODE_ZERO_DPos                              (28U)
#define PKA_RTN_CODE_ZERO_Pos                               PKA_RTN_CODE_ZERO_DPos
#define PKA_RTN_CODE_ZERO_Msk                               (0x1UL << PKA_RTN_CODE_ZERO_Pos)                    /* 0x10000000 */
#define PKA_RTN_CODE_ZERO                                   PKA_RTN_CODE_ZERO_Msk                               /* Indicates the state of the zero flag in the sequencer */

#define PKA_RTN_CODE_IRQ_DPos                               (30U)
#define PKA_RTN_CODE_IRQ_Pos                                PKA_RTN_CODE_IRQ_DPos
#define PKA_RTN_CODE_IRQ_Msk                                (0x1UL << PKA_RTN_CODE_IRQ_Pos)                     /* 0x40000000 */
#define PKA_RTN_CODE_IRQ                                    PKA_RTN_CODE_IRQ_Msk                                /* Indicates when the PKA has completed its task */

#define PKA_RTN_CODE_BUSY_DPos                              (31U)
#define PKA_RTN_CODE_BUSY_Pos                               PKA_RTN_CODE_BUSY_DPos
#define PKA_RTN_CODE_BUSY_Msk                               (0x1UL << PKA_RTN_CODE_BUSY_Pos)                    /* 0x80000000 */
#define PKA_RTN_CODE_BUSY                                   PKA_RTN_CODE_BUSY_Msk                               /* Indicates that the PKA is actively executing a program */

/******************  Bit definition for PKA_STACK_PNTR register  *******************/
#define PKA_STACK_PNTR_PNTR_DPos                            (0U)
#define PKA_STACK_PNTR_PNTR_Pos                             PKA_STACK_PNTR_PNTR_DPos
#define PKA_STACK_PNTR_PNTR_Msk                             (0xFFFUL << PKA_STACK_PNTR_PNTR_Pos)                /* 0x00000FFF */
#define PKA_STACK_PNTR_PNTR                                 PKA_STACK_PNTR_PNTR_Msk                             /* Stack pointer */
#define PKA_STACK_PNTR_PNTR_0                               (0x1UL << PKA_STACK_PNTR_PNTR_Pos)                  /* 0x00000001 */
#define PKA_STACK_PNTR_PNTR_1                               (0x2UL << PKA_STACK_PNTR_PNTR_Pos)                  /* 0x00000002 */
#define PKA_STACK_PNTR_PNTR_2                               (0x4UL << PKA_STACK_PNTR_PNTR_Pos)                  /* 0x00000004 */
#define PKA_STACK_PNTR_PNTR_3                               (0x8UL << PKA_STACK_PNTR_PNTR_Pos)                  /* 0x00000008 */
#define PKA_STACK_PNTR_PNTR_4                               (0x10UL << PKA_STACK_PNTR_PNTR_Pos)                 /* 0x00000010 */
#define PKA_STACK_PNTR_PNTR_5                               (0x20UL << PKA_STACK_PNTR_PNTR_Pos)                 /* 0x00000020 */
#define PKA_STACK_PNTR_PNTR_6                               (0x40UL << PKA_STACK_PNTR_PNTR_Pos)                 /* 0x00000040 */
#define PKA_STACK_PNTR_PNTR_7                               (0x80UL << PKA_STACK_PNTR_PNTR_Pos)                 /* 0x00000080 */
#define PKA_STACK_PNTR_PNTR_8                               (0x100UL << PKA_STACK_PNTR_PNTR_Pos)                /* 0x00000100 */
#define PKA_STACK_PNTR_PNTR_9                               (0x200UL << PKA_STACK_PNTR_PNTR_Pos)                /* 0x00000200 */
#define PKA_STACK_PNTR_PNTR_10                              (0x400UL << PKA_STACK_PNTR_PNTR_Pos)                /* 0x00000400 */
#define PKA_STACK_PNTR_PNTR_11                              (0x800UL << PKA_STACK_PNTR_PNTR_Pos)                /* 0x00000800 */

/******************  Bit definition for PKA_INSTR_SINCE_GO register  *******************/
#define PKA_INSTR_SINCE_GO_INSTRS_DPos                      (0U)
#define PKA_INSTR_SINCE_GO_INSTRS_Pos                       PKA_INSTR_SINCE_GO_INSTRS_DPos
#define PKA_INSTR_SINCE_GO_INSTRS_Msk                       (0xFFFFFFFFUL << PKA_INSTR_SINCE_GO_INSTRS_Pos)     /* 0xFFFFFFFF */
#define PKA_INSTR_SINCE_GO_INSTRS                           PKA_INSTR_SINCE_GO_INSTRS_Msk
#define PKA_INSTR_SINCE_GO_INSTRS_0                         (0x1UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)            /* 0x00000001 */
#define PKA_INSTR_SINCE_GO_INSTRS_1                         (0x2UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)            /* 0x00000002 */
#define PKA_INSTR_SINCE_GO_INSTRS_2                         (0x4UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)            /* 0x00000004 */
#define PKA_INSTR_SINCE_GO_INSTRS_3                         (0x8UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)            /* 0x00000008 */
#define PKA_INSTR_SINCE_GO_INSTRS_4                         (0x10UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)           /* 0x00000010 */
#define PKA_INSTR_SINCE_GO_INSTRS_5                         (0x20UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)           /* 0x00000020 */
#define PKA_INSTR_SINCE_GO_INSTRS_6                         (0x40UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)           /* 0x00000040 */
#define PKA_INSTR_SINCE_GO_INSTRS_7                         (0x80UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)           /* 0x00000080 */
#define PKA_INSTR_SINCE_GO_INSTRS_8                         (0x100UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)          /* 0x00000100 */
#define PKA_INSTR_SINCE_GO_INSTRS_9                         (0x200UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)          /* 0x00000200 */
#define PKA_INSTR_SINCE_GO_INSTRS_10                        (0x400UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)          /* 0x00000400 */
#define PKA_INSTR_SINCE_GO_INSTRS_11                        (0x800UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)          /* 0x00000800 */
#define PKA_INSTR_SINCE_GO_INSTRS_12                        (0x1000UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)         /* 0x00001000 */
#define PKA_INSTR_SINCE_GO_INSTRS_13                        (0x2000UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)         /* 0x00002000 */
#define PKA_INSTR_SINCE_GO_INSTRS_14                        (0x4000UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)         /* 0x00004000 */
#define PKA_INSTR_SINCE_GO_INSTRS_15                        (0x8000UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)         /* 0x00008000 */
#define PKA_INSTR_SINCE_GO_INSTRS_16                        (0x10000UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)        /* 0x00010000 */
#define PKA_INSTR_SINCE_GO_INSTRS_17                        (0x20000UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)        /* 0x00020000 */
#define PKA_INSTR_SINCE_GO_INSTRS_18                        (0x40000UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)        /* 0x00040000 */
#define PKA_INSTR_SINCE_GO_INSTRS_19                        (0x80000UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)        /* 0x00080000 */
#define PKA_INSTR_SINCE_GO_INSTRS_20                        (0x100000UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)       /* 0x00100000 */
#define PKA_INSTR_SINCE_GO_INSTRS_21                        (0x200000UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)       /* 0x00200000 */
#define PKA_INSTR_SINCE_GO_INSTRS_22                        (0x400000UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)       /* 0x00400000 */
#define PKA_INSTR_SINCE_GO_INSTRS_23                        (0x800000UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)       /* 0x00800000 */
#define PKA_INSTR_SINCE_GO_INSTRS_24                        (0x1000000UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)      /* 0x01000000 */
#define PKA_INSTR_SINCE_GO_INSTRS_25                        (0x2000000UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)      /* 0x02000000 */
#define PKA_INSTR_SINCE_GO_INSTRS_26                        (0x4000000UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)      /* 0x04000000 */
#define PKA_INSTR_SINCE_GO_INSTRS_27                        (0x8000000UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)      /* 0x08000000 */
#define PKA_INSTR_SINCE_GO_INSTRS_28                        (0x10000000UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)     /* 0x10000000 */
#define PKA_INSTR_SINCE_GO_INSTRS_29                        (0x20000000UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)     /* 0x20000000 */
#define PKA_INSTR_SINCE_GO_INSTRS_30                        (0x40000000UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)     /* 0x40000000 */
#define PKA_INSTR_SINCE_GO_INSTRS_31                        (0x80000000UL << PKA_INSTR_SINCE_GO_INSTRS_Pos)     /* 0x80000000 */

/******************  Bit definition for PKA_CONFIG register  *******************/
#define PKA_CONFIG_ALT_ACCESS_DPos                          (0U)
#define PKA_CONFIG_ALT_ACCESS_Pos                           PKA_CONFIG_ALT_ACCESS_DPos
#define PKA_CONFIG_ALT_ACCESS_Msk                           (0x1UL << PKA_CONFIG_ALT_ACCESS_Pos)                /* 0x00000001 */
#define PKA_CONFIG_ALT_ACCESS                               PKA_CONFIG_ALT_ACCESS_Msk                           /* Enable the alternate access mode */

#define PKA_CONFIG_ENDIAN_SWAP_DPos                         (26U)
#define PKA_CONFIG_ENDIAN_SWAP_Pos                          PKA_CONFIG_ENDIAN_SWAP_DPos
#define PKA_CONFIG_ENDIAN_SWAP_Msk                          (0x1UL << PKA_CONFIG_ENDIAN_SWAP_Pos)               /* 0x04000000 */
#define PKA_CONFIG_ENDIAN_SWAP                              PKA_CONFIG_ENDIAN_SWAP_Msk                          /* Cause the data memory regions to be endian swapped on transfer in or out of core */

/* Note (manual ch.31, PKA): only bit 30 is implemented.  DONE is
   write-one-to-clear (a 1 acknowledges the interrupt, a 0 is a NOP) and bits
   29:0 are reserved and must keep the reset value.  The two SIF masks below
   are kept only as compatibility spellings for code written against the
   historical register header and must not be used as status selectors. */
/******************  Bit definition for PKA_STAT register  *******************/
#define PKA_STAT_SIF_ERR_DPos                               (0U)
#define PKA_STAT_SIF_ERR_Pos                                PKA_STAT_SIF_ERR_DPos
#define PKA_STAT_SIF_ERR_Msk                                (0x1UL << PKA_STAT_SIF_ERR_Pos)                     /* 0x00000001 */
#define PKA_STAT_SIF_ERR                                    PKA_STAT_SIF_ERR_Msk                                /* Reserved bit: STAT[29:0] must keep the reset value (manual ch.31) */

#define PKA_STAT_SIF_SBE_DPos                               (1U)
#define PKA_STAT_SIF_SBE_Pos                                PKA_STAT_SIF_SBE_DPos
#define PKA_STAT_SIF_SBE_Msk                                (0x1UL << PKA_STAT_SIF_SBE_Pos)                     /* 0x00000002 */
#define PKA_STAT_SIF_SBE                                    PKA_STAT_SIF_SBE_Msk                                /* Reserved bit: STAT[29:0] must keep the reset value (manual ch.31) */

#define PKA_STAT_DONE_DPos                                  (30U)
#define PKA_STAT_DONE_Pos                                   PKA_STAT_DONE_DPos
#define PKA_STAT_DONE_Msk                                   (0x1UL << PKA_STAT_DONE_Pos)                        /* 0x40000000 */
#define PKA_STAT_DONE                                       PKA_STAT_DONE_Msk                                   /* Write-one-to-clear: W1 acknowledges, W0 is NOP, R1 pending, R0 none */

/******************  Bit definition for PKA_FLAGS register  *******************/
#define PKA_FLAGS_Z_DPos                                    (0U)
#define PKA_FLAGS_Z_Pos                                     PKA_FLAGS_Z_DPos
#define PKA_FLAGS_Z_Msk                                     (0x1UL << PKA_FLAGS_Z_Pos)                          /* 0x00000001 */
#define PKA_FLAGS_Z                                         PKA_FLAGS_Z_Msk                                     /* Zero flag */

#define PKA_FLAGS_M_DPos                                    (1U)
#define PKA_FLAGS_M_Pos                                     PKA_FLAGS_M_DPos
#define PKA_FLAGS_M_Msk                                     (0x1UL << PKA_FLAGS_M_Pos)                          /* 0x00000002 */
#define PKA_FLAGS_M                                         PKA_FLAGS_M_Msk                                     /* Memory-test flag */

#define PKA_FLAGS_B_DPos                                    (2U)
#define PKA_FLAGS_B_Pos                                     PKA_FLAGS_B_DPos
#define PKA_FLAGS_B_Msk                                     (0x1UL << PKA_FLAGS_B_Pos)                          /* 0x00000004 */
#define PKA_FLAGS_B                                         PKA_FLAGS_B_Msk                                     /* Borrow flag */

#define PKA_FLAGS_C_DPos                                    (3U)
#define PKA_FLAGS_C_Pos                                     PKA_FLAGS_C_DPos
#define PKA_FLAGS_C_Msk                                     (0x1UL << PKA_FLAGS_C_Pos)                          /* 0x00000008 */
#define PKA_FLAGS_C                                         PKA_FLAGS_C_Msk                                     /* Carry flag */

#define PKA_FLAGS_F0_DPos                                   (4U)
#define PKA_FLAGS_F0_Pos                                    PKA_FLAGS_F0_DPos
#define PKA_FLAGS_F0_Msk                                    (0x1UL << PKA_FLAGS_F0_Pos)                         /* 0x00000010 */
#define PKA_FLAGS_F0                                        PKA_FLAGS_F0_Msk                                    /* User flag 0 */

#define PKA_FLAGS_F1_DPos                                   (5U)
#define PKA_FLAGS_F1_Pos                                    PKA_FLAGS_F1_DPos
#define PKA_FLAGS_F1_Msk                                    (0x1UL << PKA_FLAGS_F1_Pos)                         /* 0x00000020 */
#define PKA_FLAGS_F1                                        PKA_FLAGS_F1_Msk                                    /* User flag 1 */

#define PKA_FLAGS_F2_DPos                                   (6U)
#define PKA_FLAGS_F2_Pos                                    PKA_FLAGS_F2_DPos
#define PKA_FLAGS_F2_Msk                                    (0x1UL << PKA_FLAGS_F2_Pos)                         /* 0x00000040 */
#define PKA_FLAGS_F2                                        PKA_FLAGS_F2_Msk                                    /* User flag 2 */

#define PKA_FLAGS_F3_DPos                                   (7U)
#define PKA_FLAGS_F3_Pos                                    PKA_FLAGS_F3_DPos
#define PKA_FLAGS_F3_Msk                                    (0x1UL << PKA_FLAGS_F3_Pos)                         /* 0x00000080 */
#define PKA_FLAGS_F3                                        PKA_FLAGS_F3_Msk                                    /* User flag 3 */

/******************  Bit definition for PKA_WATCHDOG register  *******************/
#define PKA_WATCHDOG_RELOAD_DPos                            (0U)
#define PKA_WATCHDOG_RELOAD_Pos                             PKA_WATCHDOG_RELOAD_DPos
#define PKA_WATCHDOG_RELOAD_Msk                             (0xFFFFFFFFUL << PKA_WATCHDOG_RELOAD_Pos)           /* 0xFFFFFFFF */
#define PKA_WATCHDOG_RELOAD                                 PKA_WATCHDOG_RELOAD_Msk                             /* Reload value for the watchdog timer */
#define PKA_WATCHDOG_RELOAD_0                               (0x1UL << PKA_WATCHDOG_RELOAD_Pos)                  /* 0x00000001 */
#define PKA_WATCHDOG_RELOAD_1                               (0x2UL << PKA_WATCHDOG_RELOAD_Pos)                  /* 0x00000002 */
#define PKA_WATCHDOG_RELOAD_2                               (0x4UL << PKA_WATCHDOG_RELOAD_Pos)                  /* 0x00000004 */
#define PKA_WATCHDOG_RELOAD_3                               (0x8UL << PKA_WATCHDOG_RELOAD_Pos)                  /* 0x00000008 */
#define PKA_WATCHDOG_RELOAD_4                               (0x10UL << PKA_WATCHDOG_RELOAD_Pos)                 /* 0x00000010 */
#define PKA_WATCHDOG_RELOAD_5                               (0x20UL << PKA_WATCHDOG_RELOAD_Pos)                 /* 0x00000020 */
#define PKA_WATCHDOG_RELOAD_6                               (0x40UL << PKA_WATCHDOG_RELOAD_Pos)                 /* 0x00000040 */
#define PKA_WATCHDOG_RELOAD_7                               (0x80UL << PKA_WATCHDOG_RELOAD_Pos)                 /* 0x00000080 */
#define PKA_WATCHDOG_RELOAD_8                               (0x100UL << PKA_WATCHDOG_RELOAD_Pos)                /* 0x00000100 */
#define PKA_WATCHDOG_RELOAD_9                               (0x200UL << PKA_WATCHDOG_RELOAD_Pos)                /* 0x00000200 */
#define PKA_WATCHDOG_RELOAD_10                              (0x400UL << PKA_WATCHDOG_RELOAD_Pos)                /* 0x00000400 */
#define PKA_WATCHDOG_RELOAD_11                              (0x800UL << PKA_WATCHDOG_RELOAD_Pos)                /* 0x00000800 */
#define PKA_WATCHDOG_RELOAD_12                              (0x1000UL << PKA_WATCHDOG_RELOAD_Pos)               /* 0x00001000 */
#define PKA_WATCHDOG_RELOAD_13                              (0x2000UL << PKA_WATCHDOG_RELOAD_Pos)               /* 0x00002000 */
#define PKA_WATCHDOG_RELOAD_14                              (0x4000UL << PKA_WATCHDOG_RELOAD_Pos)               /* 0x00004000 */
#define PKA_WATCHDOG_RELOAD_15                              (0x8000UL << PKA_WATCHDOG_RELOAD_Pos)               /* 0x00008000 */
#define PKA_WATCHDOG_RELOAD_16                              (0x10000UL << PKA_WATCHDOG_RELOAD_Pos)              /* 0x00010000 */
#define PKA_WATCHDOG_RELOAD_17                              (0x20000UL << PKA_WATCHDOG_RELOAD_Pos)              /* 0x00020000 */
#define PKA_WATCHDOG_RELOAD_18                              (0x40000UL << PKA_WATCHDOG_RELOAD_Pos)              /* 0x00040000 */
#define PKA_WATCHDOG_RELOAD_19                              (0x80000UL << PKA_WATCHDOG_RELOAD_Pos)              /* 0x00080000 */
#define PKA_WATCHDOG_RELOAD_20                              (0x100000UL << PKA_WATCHDOG_RELOAD_Pos)             /* 0x00100000 */
#define PKA_WATCHDOG_RELOAD_21                              (0x200000UL << PKA_WATCHDOG_RELOAD_Pos)             /* 0x00200000 */
#define PKA_WATCHDOG_RELOAD_22                              (0x400000UL << PKA_WATCHDOG_RELOAD_Pos)             /* 0x00400000 */
#define PKA_WATCHDOG_RELOAD_23                              (0x800000UL << PKA_WATCHDOG_RELOAD_Pos)             /* 0x00800000 */
#define PKA_WATCHDOG_RELOAD_24                              (0x1000000UL << PKA_WATCHDOG_RELOAD_Pos)            /* 0x01000000 */
#define PKA_WATCHDOG_RELOAD_25                              (0x2000000UL << PKA_WATCHDOG_RELOAD_Pos)            /* 0x02000000 */
#define PKA_WATCHDOG_RELOAD_26                              (0x4000000UL << PKA_WATCHDOG_RELOAD_Pos)            /* 0x04000000 */
#define PKA_WATCHDOG_RELOAD_27                              (0x8000000UL << PKA_WATCHDOG_RELOAD_Pos)            /* 0x08000000 */
#define PKA_WATCHDOG_RELOAD_28                              (0x10000000UL << PKA_WATCHDOG_RELOAD_Pos)           /* 0x10000000 */
#define PKA_WATCHDOG_RELOAD_29                              (0x20000000UL << PKA_WATCHDOG_RELOAD_Pos)           /* 0x20000000 */
#define PKA_WATCHDOG_RELOAD_30                              (0x40000000UL << PKA_WATCHDOG_RELOAD_Pos)           /* 0x40000000 */
#define PKA_WATCHDOG_RELOAD_31                              (0x80000000UL << PKA_WATCHDOG_RELOAD_Pos)           /* 0x80000000 */

/******************  Bit definition for PKA_CYCLES_SINCE_GO register  *******************/
#define PKA_CYCLES_SINCE_GO_CYCLES_DPos                     (0U)
#define PKA_CYCLES_SINCE_GO_Cycles_Pos                      PKA_CYCLES_SINCE_GO_CYCLES_DPos
#define PKA_CYCLES_SINCE_GO_Cycles_Msk                      (0xFFFFFFFFUL << PKA_CYCLES_SINCE_GO_Cycles_Pos)    /* 0xFFFFFFFF */
#define PKA_CYCLES_SINCE_GO_Cycles                          PKA_CYCLES_SINCE_GO_Cycles_Msk                      /* Number of cycles since the last GO command */
#define PKA_CYCLES_SINCE_GO_Cycles_0                        (0x1UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)           /* 0x00000001 */
#define PKA_CYCLES_SINCE_GO_Cycles_1                        (0x2UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)           /* 0x00000002 */
#define PKA_CYCLES_SINCE_GO_Cycles_2                        (0x4UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)           /* 0x00000004 */
#define PKA_CYCLES_SINCE_GO_Cycles_3                        (0x8UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)           /* 0x00000008 */
#define PKA_CYCLES_SINCE_GO_Cycles_4                        (0x10UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)          /* 0x00000010 */
#define PKA_CYCLES_SINCE_GO_Cycles_5                        (0x20UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)          /* 0x00000020 */
#define PKA_CYCLES_SINCE_GO_Cycles_6                        (0x40UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)          /* 0x00000040 */
#define PKA_CYCLES_SINCE_GO_Cycles_7                        (0x80UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)          /* 0x00000080 */
#define PKA_CYCLES_SINCE_GO_Cycles_8                        (0x100UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)         /* 0x00000100 */
#define PKA_CYCLES_SINCE_GO_Cycles_9                        (0x200UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)         /* 0x00000200 */
#define PKA_CYCLES_SINCE_GO_Cycles_10                       (0x400UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)         /* 0x00000400 */
#define PKA_CYCLES_SINCE_GO_Cycles_11                       (0x800UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)         /* 0x00000800 */
#define PKA_CYCLES_SINCE_GO_Cycles_12                       (0x1000UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)        /* 0x00001000 */
#define PKA_CYCLES_SINCE_GO_Cycles_13                       (0x2000UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)        /* 0x00002000 */
#define PKA_CYCLES_SINCE_GO_Cycles_14                       (0x4000UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)        /* 0x00004000 */
#define PKA_CYCLES_SINCE_GO_Cycles_15                       (0x8000UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)        /* 0x00008000 */
#define PKA_CYCLES_SINCE_GO_Cycles_16                       (0x10000UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)       /* 0x00010000 */
#define PKA_CYCLES_SINCE_GO_Cycles_17                       (0x20000UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)       /* 0x00020000 */
#define PKA_CYCLES_SINCE_GO_Cycles_18                       (0x40000UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)       /* 0x00040000 */
#define PKA_CYCLES_SINCE_GO_Cycles_19                       (0x80000UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)       /* 0x00080000 */
#define PKA_CYCLES_SINCE_GO_Cycles_20                       (0x100000UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)      /* 0x00100000 */
#define PKA_CYCLES_SINCE_GO_Cycles_21                       (0x200000UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)      /* 0x00200000 */
#define PKA_CYCLES_SINCE_GO_Cycles_22                       (0x400000UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)      /* 0x00400000 */
#define PKA_CYCLES_SINCE_GO_Cycles_23                       (0x800000UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)      /* 0x00800000 */
#define PKA_CYCLES_SINCE_GO_Cycles_24                       (0x1000000UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)     /* 0x01000000 */
#define PKA_CYCLES_SINCE_GO_Cycles_25                       (0x2000000UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)     /* 0x02000000 */
#define PKA_CYCLES_SINCE_GO_Cycles_26                       (0x4000000UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)     /* 0x04000000 */
#define PKA_CYCLES_SINCE_GO_Cycles_27                       (0x8000000UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)     /* 0x08000000 */
#define PKA_CYCLES_SINCE_GO_Cycles_28                       (0x10000000UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)    /* 0x10000000 */
#define PKA_CYCLES_SINCE_GO_Cycles_29                       (0x20000000UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)    /* 0x20000000 */
#define PKA_CYCLES_SINCE_GO_Cycles_30                       (0x40000000UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)    /* 0x40000000 */
#define PKA_CYCLES_SINCE_GO_Cycles_31                       (0x80000000UL << PKA_CYCLES_SINCE_GO_Cycles_Pos)    /* 0x80000000 */

/* Note (manual ch.31, PKA): only bit 30 (IE) is implemented and it gates the
   O_irq output on STAT.DONE.  Bits 29:0 and bit 31 are reserved and must
   keep the reset value; the SIF and global masks below are compatibility
   spellings only and are never enabled by the HAL driver. */
/******************  Bit definition for PKA_IRQ_EN register  *******************/
#define PKA_IRQ_EN_SIF_ERR_IE_DPos                          (0U)
#define PKA_IRQ_EN_SIF_ERR_IE_Pos                           PKA_IRQ_EN_SIF_ERR_IE_DPos
#define PKA_IRQ_EN_SIF_ERR_IE_Msk                           (0x1UL << PKA_IRQ_EN_SIF_ERR_IE_Pos)                /* 0x00000001 */
#define PKA_IRQ_EN_SIF_ERR_IE                               PKA_IRQ_EN_SIF_ERR_IE_Msk                           /* Reserved bit: IRQ_EN[29:0] must keep the reset value (manual ch.31) */

#define PKA_IRQ_EN_SIF_SBE_IE_DPos                          (1U)
#define PKA_IRQ_EN_SIF_SBE_IE_Pos                           PKA_IRQ_EN_SIF_SBE_IE_DPos
#define PKA_IRQ_EN_SIF_SBE_IE_Msk                           (0x2UL << PKA_IRQ_EN_SIF_SBE_IE_Pos)                /* 0x00000002 */
#define PKA_IRQ_EN_SIF_SBE_IE                               PKA_IRQ_EN_SIF_SBE_IE_Msk                           /* Reserved bit: IRQ_EN[29:0] must keep the reset value (manual ch.31) */

#define PKA_IRQ_EN_DONE_IE_DPos                             (30U)
#define PKA_IRQ_EN_DONE_IE_Pos                              PKA_IRQ_EN_DONE_IE_DPos
#define PKA_IRQ_EN_DONE_IE_Msk                              (0x1UL << PKA_IRQ_EN_DONE_IE_Pos)                   /* 0x40000000 */
#define PKA_IRQ_EN_DONE_IE                                  PKA_IRQ_EN_DONE_IE_Msk                              /* The only implemented source: gates O_irq on STAT.DONE */

#define PKA_IRQ_EN_GLB_IE_DPos                              (31U)
#define PKA_IRQ_EN_GLB_IE_Pos                               PKA_IRQ_EN_GLB_IE_DPos
#define PKA_IRQ_EN_GLB_IE_Msk                               (0x1UL << PKA_IRQ_EN_GLB_IE_Pos)                    /* 0x80000000 */
#define PKA_IRQ_EN_GLB_IE                                   PKA_IRQ_EN_GLB_IE_Msk                               /* Reserved bit: IRQ_EN[31] must keep the reset value (manual ch.31) */

/* @name TRNG register bits definition */
/******************  Bit definition for TRNG_CTRL register  *******************/
#define TRNG_CTRL_CMD_DPos                  (0U)
#define TRNG_CTRL_CMD_Pos                   TRNG_CTRL_CMD_DPos
#define TRNG_CTRL_CMD_Msk                   (0xFUL << TRNG_CTRL_CMD_Pos)            /* 0x0000000F */
#define TRNG_CTRL_CMD                       TRNG_CTRL_CMD_Msk                       /* TRNG Execute A Command */
#define TRNG_CTRL_CMD_0                     (0x1UL << TRNG_CTRL_CMD_Pos)            /* 0x00000001 */
#define TRNG_CTRL_CMD_1                     (0x2UL << TRNG_CTRL_CMD_Pos)            /* 0x00000002 */
#define TRNG_CTRL_CMD_2                     (0x4UL << TRNG_CTRL_CMD_Pos)            /* 0x00000004 */
#define TRNG_CTRL_CMD_3                     (0x8UL << TRNG_CTRL_CMD_Pos)            /* 0x00000008 */

/******************  Bit definition for TRNG_IE register  *******************/
#define TRNG_IE_ZEROIZED_DPos               (0U)
#define TRNG_IE_ZEROIZED_Pos                TRNG_IE_ZEROIZED_DPos
#define TRNG_IE_ZEROIZED_Msk                (0x1UL << TRNG_IE_ZEROIZED_Pos)         /* 0x00000001 */
#define TRNG_IE_ZEROIZED                    TRNG_IE_ZEROIZED_Msk                    /* TRNG Zeroized Interrupt Enable */

#define TRNG_IE_KAT_COMPLETED_DPos          (1U)
#define TRNG_IE_KAT_COMPLETED_Pos           TRNG_IE_KAT_COMPLETED_DPos
#define TRNG_IE_KAT_COMPLETED_Msk           (0x1UL << TRNG_IE_KAT_COMPLETED_Pos)    /* 0x00000002 */
#define TRNG_IE_KAT_COMPLETED               TRNG_IE_KAT_COMPLETED_Msk               /* TRNG KAT Completed Interrupt Enable */

#define TRNG_IE_NOISE_RDY_DPos              (2U)
#define TRNG_IE_NOISE_RDY_Pos               TRNG_IE_NOISE_RDY_DPos
#define TRNG_IE_NOISE_RDY_Msk               (0x1UL << TRNG_IE_NOISE_RDY_Pos)        /* 0x00000004 */
#define TRNG_IE_NOISE_RDY                   TRNG_IE_NOISE_RDY_Msk                   /* TRNG Noise Ready Interrupt Enable */

#define TRNG_IE_ALARMS_DPos                 (3U)
#define TRNG_IE_ALARMS_Pos                  TRNG_IE_ALARMS_DPos
#define TRNG_IE_ALARMS_Msk                  (0x1UL << TRNG_IE_ALARMS_Pos)           /* 0x00000008 */
#define TRNG_IE_ALARMS                      TRNG_IE_ALARMS_Msk                      /* TRNG Alarms Interrupt Enable */

#define TRNG_IE_DONE_DPos                   (4U)
#define TRNG_IE_DONE_Pos                    TRNG_IE_DONE_DPos
#define TRNG_IE_DONE_Msk                    (0x1UL << TRNG_IE_DONE_Pos)             /* 0x00000010 */
#define TRNG_IE_DONE                        TRNG_IE_DONE_Msk                        /*TRNG Done Interrupt Enable */

#define TRNG_IE_GLBL_DPos                   (31U)
#define TRNG_IE_GLBL_Pos                    TRNG_IE_GLBL_DPos
#define TRNG_IE_GLBL_Msk                    (0x1UL << TRNG_IE_GLBL_Pos)             /* 0x80000000 */
#define TRNG_IE_GLBL                        TRNG_IE_GLBL_Msk                        /* TRNG Global Interrupt Enable */

/******************  Bit definition for TRNG_ISTAT register  *******************/
#define TRNG_ISTAT_ZEROIZED_DPos            (0U)
#define TRNG_ISTAT_ZEROIZED_Pos             TRNG_ISTAT_ZEROIZED_DPos
#define TRNG_ISTAT_ZEROIZED_Msk             (0x1UL << TRNG_ISTAT_ZEROIZED_Pos)      /* 0x00000001 */
#define TRNG_ISTAT_ZEROIZED                 TRNG_ISTAT_ZEROIZED_Msk                 /* TRNG Zeroized Interrupt Status */

#define TRNG_ISTAT_KAT_COMPLETED_DPos       (1U)
#define TRNG_ISTAT_KAT_COMPLETED_Pos        TRNG_ISTAT_KAT_COMPLETED_DPos
#define TRNG_ISTAT_KAT_COMPLETED_Msk        (0x1UL << TRNG_ISTAT_KAT_COMPLETED_Pos) /* 0x00000002 */
#define TRNG_ISTAT_KAT_COMPLETED            TRNG_ISTAT_KAT_COMPLETED_Msk            /* TRNG KAT Completed Interrupt Status */

#define TRNG_ISTAT_NOISE_RDY_DPos           (2U)
#define TRNG_ISTAT_NOISE_RDY_Pos            TRNG_ISTAT_NOISE_RDY_DPos
#define TRNG_ISTAT_NOISE_RDY_Msk            (0x1UL << TRNG_ISTAT_NOISE_RDY_Pos)     /* 0x00000004 */
#define TRNG_ISTAT_NOISE_RDY                TRNG_ISTAT_NOISE_RDY_Msk                /* TRNG Noise Ready Interrupt Status */

#define TRNG_ISTAT_ALARMS_DPos              (3U)
#define TRNG_ISTAT_ALARMS_Pos               TRNG_ISTAT_ALARMS_DPos
#define TRNG_ISTAT_ALARMS_Msk               (0x1UL << TRNG_ISTAT_ALARMS_Pos)        /* 0x00000008 */
#define TRNG_ISTAT_ALARMS                   TRNG_ISTAT_ALARMS_Msk                   /* TRNG Alarms Interrupt Status */

#define TRNG_ISTAT_DONE_DPos                (4U)
#define TRNG_ISTAT_DONE_Pos                 TRNG_ISTAT_DONE_DPos
#define TRNG_ISTAT_DONE_Msk                 (0x1UL << TRNG_ISTAT_DONE_Pos)          /* 0x00000010 */
#define TRNG_ISTAT_DONE                     TRNG_ISTAT_DONE_Msk                     /* TRNG Done Interrupt Status */

/******************  Bit definition for TRNG_RAND0 register  *******************/
#define TRNG_RAND0_RAND_DPos                (0U)
#define TRNG_RAND0_RAND_Pos                 TRNG_RAND0_RAND_DPos
#define TRNG_RAND0_RAND_Msk                 (0xFFFFFFFFUL << TRNG_RAND0_RAND_Pos)   /* 0xFFFFFFFF */
#define TRNG_RAND0_RAND                     TRNG_RAND0_RAND_Msk                     /* TRNG Random Number Register 0 */
#define TRNG_RAND0_RAND_0                   (0x1UL << TRNG_RAND0_RAND_Pos)          /* 0x00000001 */
#define TRNG_RAND0_RAND_1                   (0x2UL << TRNG_RAND0_RAND_Pos)          /* 0x00000002 */
#define TRNG_RAND0_RAND_2                   (0x4UL << TRNG_RAND0_RAND_Pos)          /* 0x00000004 */
#define TRNG_RAND0_RAND_3                   (0x8UL << TRNG_RAND0_RAND_Pos)          /* 0x00000008 */
#define TRNG_RAND0_RAND_4                   (0x10UL << TRNG_RAND0_RAND_Pos)         /* 0x00000010 */
#define TRNG_RAND0_RAND_5                   (0x20UL << TRNG_RAND0_RAND_Pos)         /* 0x00000020 */
#define TRNG_RAND0_RAND_6                   (0x40UL << TRNG_RAND0_RAND_Pos)         /* 0x00000040 */
#define TRNG_RAND0_RAND_7                   (0x80UL << TRNG_RAND0_RAND_Pos)         /* 0x00000080 */
#define TRNG_RAND0_RAND_8                   (0x100UL << TRNG_RAND0_RAND_Pos)        /* 0x00000100 */
#define TRNG_RAND0_RAND_9                   (0x200UL << TRNG_RAND0_RAND_Pos)        /* 0x00000200 */
#define TRNG_RAND0_RAND_10                  (0x400UL << TRNG_RAND0_RAND_Pos)        /* 0x00000400 */
#define TRNG_RAND0_RAND_11                  (0x800UL << TRNG_RAND0_RAND_Pos)        /* 0x00000800 */
#define TRNG_RAND0_RAND_12                  (0x1000UL << TRNG_RAND0_RAND_Pos)       /* 0x00001000 */
#define TRNG_RAND0_RAND_13                  (0x2000UL << TRNG_RAND0_RAND_Pos)       /* 0x00002000 */
#define TRNG_RAND0_RAND_14                  (0x4000UL << TRNG_RAND0_RAND_Pos)       /* 0x00004000 */
#define TRNG_RAND0_RAND_15                  (0x8000UL << TRNG_RAND0_RAND_Pos)       /* 0x00008000 */
#define TRNG_RAND0_RAND_16                  (0x10000UL << TRNG_RAND0_RAND_Pos)      /* 0x00010000 */
#define TRNG_RAND0_RAND_17                  (0x20000UL << TRNG_RAND0_RAND_Pos)      /* 0x00020000 */
#define TRNG_RAND0_RAND_18                  (0x40000UL << TRNG_RAND0_RAND_Pos)      /* 0x00040000 */
#define TRNG_RAND0_RAND_19                  (0x80000UL << TRNG_RAND0_RAND_Pos)      /* 0x00080000 */
#define TRNG_RAND0_RAND_20                  (0x100000UL << TRNG_RAND0_RAND_Pos)     /* 0x00100000 */
#define TRNG_RAND0_RAND_21                  (0x200000UL << TRNG_RAND0_RAND_Pos)     /* 0x00200000 */
#define TRNG_RAND0_RAND_22                  (0x400000UL << TRNG_RAND0_RAND_Pos)     /* 0x00400000 */
#define TRNG_RAND0_RAND_23                  (0x800000UL << TRNG_RAND0_RAND_Pos)     /* 0x00800000 */
#define TRNG_RAND0_RAND_24                  (0x1000000UL << TRNG_RAND0_RAND_Pos)    /* 0x01000000 */
#define TRNG_RAND0_RAND_25                  (0x2000000UL << TRNG_RAND0_RAND_Pos)    /* 0x02000000 */
#define TRNG_RAND0_RAND_26                  (0x4000000UL << TRNG_RAND0_RAND_Pos)    /* 0x04000000 */
#define TRNG_RAND0_RAND_27                  (0x8000000UL << TRNG_RAND0_RAND_Pos)    /* 0x08000000 */
#define TRNG_RAND0_RAND_28                  (0x10000000UL << TRNG_RAND0_RAND_Pos)   /* 0x10000000 */
#define TRNG_RAND0_RAND_29                  (0x20000000UL << TRNG_RAND0_RAND_Pos)   /* 0x20000000 */
#define TRNG_RAND0_RAND_30                  (0x40000000UL << TRNG_RAND0_RAND_Pos)   /* 0x40000000 */
#define TRNG_RAND0_RAND_31                  (0x80000000UL << TRNG_RAND0_RAND_Pos)   /* 0x80000000 */

/******************  Bit definition for TRNG_RAND1 register  *******************/
#define TRNG_RAND1_RAND_DPos                (0U)
#define TRNG_RAND1_RAND_Pos                 TRNG_RAND1_RAND_DPos
#define TRNG_RAND1_RAND_Msk                 (0xFFFFFFFFUL << TRNG_RAND1_RAND_Pos)   /* 0xFFFFFFFF */
#define TRNG_RAND1_RAND                     TRNG_RAND1_RAND_Msk                     /* TRNG Random Number Register 1 */
#define TRNG_RAND1_RAND_0                   (0x1UL << TRNG_RAND1_RAND_Pos)          /* 0x00000001 */
#define TRNG_RAND1_RAND_1                   (0x2UL << TRNG_RAND1_RAND_Pos)          /* 0x00000002 */
#define TRNG_RAND1_RAND_2                   (0x4UL << TRNG_RAND1_RAND_Pos)          /* 0x00000004 */
#define TRNG_RAND1_RAND_3                   (0x8UL << TRNG_RAND1_RAND_Pos)          /* 0x00000008 */
#define TRNG_RAND1_RAND_4                   (0x10UL << TRNG_RAND1_RAND_Pos)         /* 0x00000010 */
#define TRNG_RAND1_RAND_5                   (0x20UL << TRNG_RAND1_RAND_Pos)         /* 0x00000020 */
#define TRNG_RAND1_RAND_6                   (0x40UL << TRNG_RAND1_RAND_Pos)         /* 0x00000040 */
#define TRNG_RAND1_RAND_7                   (0x80UL << TRNG_RAND1_RAND_Pos)         /* 0x00000080 */
#define TRNG_RAND1_RAND_8                   (0x100UL << TRNG_RAND1_RAND_Pos)        /* 0x00000100 */
#define TRNG_RAND1_RAND_9                   (0x200UL << TRNG_RAND1_RAND_Pos)        /* 0x00000200 */
#define TRNG_RAND1_RAND_10                  (0x400UL << TRNG_RAND1_RAND_Pos)        /* 0x00000400 */
#define TRNG_RAND1_RAND_11                  (0x800UL << TRNG_RAND1_RAND_Pos)        /* 0x00000800 */
#define TRNG_RAND1_RAND_12                  (0x1000UL << TRNG_RAND1_RAND_Pos)       /* 0x00001000 */
#define TRNG_RAND1_RAND_13                  (0x2000UL << TRNG_RAND1_RAND_Pos)       /* 0x00002000 */
#define TRNG_RAND1_RAND_14                  (0x4000UL << TRNG_RAND1_RAND_Pos)       /* 0x00004000 */
#define TRNG_RAND1_RAND_15                  (0x8000UL << TRNG_RAND1_RAND_Pos)       /* 0x00008000 */
#define TRNG_RAND1_RAND_16                  (0x10000UL << TRNG_RAND1_RAND_Pos)      /* 0x00010000 */
#define TRNG_RAND1_RAND_17                  (0x20000UL << TRNG_RAND1_RAND_Pos)      /* 0x00020000 */
#define TRNG_RAND1_RAND_18                  (0x40000UL << TRNG_RAND1_RAND_Pos)      /* 0x00040000 */
#define TRNG_RAND1_RAND_19                  (0x80000UL << TRNG_RAND1_RAND_Pos)      /* 0x00080000 */
#define TRNG_RAND1_RAND_20                  (0x100000UL << TRNG_RAND1_RAND_Pos)     /* 0x00100000 */
#define TRNG_RAND1_RAND_21                  (0x200000UL << TRNG_RAND1_RAND_Pos)     /* 0x00200000 */
#define TRNG_RAND1_RAND_22                  (0x400000UL << TRNG_RAND1_RAND_Pos)     /* 0x00400000 */
#define TRNG_RAND1_RAND_23                  (0x800000UL << TRNG_RAND1_RAND_Pos)     /* 0x00800000 */
#define TRNG_RAND1_RAND_24                  (0x1000000UL << TRNG_RAND1_RAND_Pos)    /* 0x01000000 */
#define TRNG_RAND1_RAND_25                  (0x2000000UL << TRNG_RAND1_RAND_Pos)    /* 0x02000000 */
#define TRNG_RAND1_RAND_26                  (0x4000000UL << TRNG_RAND1_RAND_Pos)    /* 0x04000000 */
#define TRNG_RAND1_RAND_27                  (0x8000000UL << TRNG_RAND1_RAND_Pos)    /* 0x08000000 */
#define TRNG_RAND1_RAND_28                  (0x10000000UL << TRNG_RAND1_RAND_Pos)   /* 0x10000000 */
#define TRNG_RAND1_RAND_29                  (0x20000000UL << TRNG_RAND1_RAND_Pos)   /* 0x20000000 */
#define TRNG_RAND1_RAND_30                  (0x40000000UL << TRNG_RAND1_RAND_Pos)   /* 0x40000000 */
#define TRNG_RAND1_RAND_31                  (0x80000000UL << TRNG_RAND1_RAND_Pos)   /* 0x80000000 */

/******************  Bit definition for TRNG_RAND2 register  *******************/
#define TRNG_RAND2_RAND_DPos                (0U)
#define TRNG_RAND2_RAND_Pos                 TRNG_RAND2_RAND_DPos
#define TRNG_RAND2_RAND_Msk                 (0xFFFFFFFFUL << TRNG_RAND2_RAND_Pos)   /* 0xFFFFFFFF */
#define TRNG_RAND2_RAND                     TRNG_RAND2_RAND_Msk                     /* TRNG Random Number Register 2 */
#define TRNG_RAND2_RAND_0                   (0x1UL << TRNG_RAND2_RAND_Pos)          /* 0x00000001 */
#define TRNG_RAND2_RAND_1                   (0x2UL << TRNG_RAND2_RAND_Pos)          /* 0x00000002 */
#define TRNG_RAND2_RAND_2                   (0x4UL << TRNG_RAND2_RAND_Pos)          /* 0x00000004 */
#define TRNG_RAND2_RAND_3                   (0x8UL << TRNG_RAND2_RAND_Pos)          /* 0x00000008 */
#define TRNG_RAND2_RAND_4                   (0x10UL << TRNG_RAND2_RAND_Pos)         /* 0x00000010 */
#define TRNG_RAND2_RAND_5                   (0x20UL << TRNG_RAND2_RAND_Pos)         /* 0x00000020 */
#define TRNG_RAND2_RAND_6                   (0x40UL << TRNG_RAND2_RAND_Pos)         /* 0x00000040 */
#define TRNG_RAND2_RAND_7                   (0x80UL << TRNG_RAND2_RAND_Pos)         /* 0x00000080 */
#define TRNG_RAND2_RAND_8                   (0x100UL << TRNG_RAND2_RAND_Pos)        /* 0x00000100 */
#define TRNG_RAND2_RAND_9                   (0x200UL << TRNG_RAND2_RAND_Pos)        /* 0x00000200 */
#define TRNG_RAND2_RAND_10                  (0x400UL << TRNG_RAND2_RAND_Pos)        /* 0x00000400 */
#define TRNG_RAND2_RAND_11                  (0x800UL << TRNG_RAND2_RAND_Pos)        /* 0x00000800 */
#define TRNG_RAND2_RAND_12                  (0x1000UL << TRNG_RAND2_RAND_Pos)       /* 0x00001000 */
#define TRNG_RAND2_RAND_13                  (0x2000UL << TRNG_RAND2_RAND_Pos)       /* 0x00002000 */
#define TRNG_RAND2_RAND_14                  (0x4000UL << TRNG_RAND2_RAND_Pos)       /* 0x00004000 */
#define TRNG_RAND2_RAND_15                  (0x8000UL << TRNG_RAND2_RAND_Pos)       /* 0x00008000 */
#define TRNG_RAND2_RAND_16                  (0x10000UL << TRNG_RAND2_RAND_Pos)      /* 0x00010000 */
#define TRNG_RAND2_RAND_17                  (0x20000UL << TRNG_RAND2_RAND_Pos)      /* 0x00020000 */
#define TRNG_RAND2_RAND_18                  (0x40000UL << TRNG_RAND2_RAND_Pos)      /* 0x00040000 */
#define TRNG_RAND2_RAND_19                  (0x80000UL << TRNG_RAND2_RAND_Pos)      /* 0x00080000 */
#define TRNG_RAND2_RAND_20                  (0x100000UL << TRNG_RAND2_RAND_Pos)     /* 0x00100000 */
#define TRNG_RAND2_RAND_21                  (0x200000UL << TRNG_RAND2_RAND_Pos)     /* 0x00200000 */
#define TRNG_RAND2_RAND_22                  (0x400000UL << TRNG_RAND2_RAND_Pos)     /* 0x00400000 */
#define TRNG_RAND2_RAND_23                  (0x800000UL << TRNG_RAND2_RAND_Pos)     /* 0x00800000 */
#define TRNG_RAND2_RAND_24                  (0x1000000UL << TRNG_RAND2_RAND_Pos)    /* 0x01000000 */
#define TRNG_RAND2_RAND_25                  (0x2000000UL << TRNG_RAND2_RAND_Pos)    /* 0x02000000 */
#define TRNG_RAND2_RAND_26                  (0x4000000UL << TRNG_RAND2_RAND_Pos)    /* 0x04000000 */
#define TRNG_RAND2_RAND_27                  (0x8000000UL << TRNG_RAND2_RAND_Pos)    /* 0x08000000 */
#define TRNG_RAND2_RAND_28                  (0x10000000UL << TRNG_RAND2_RAND_Pos)   /* 0x10000000 */
#define TRNG_RAND2_RAND_29                  (0x20000000UL << TRNG_RAND2_RAND_Pos)   /* 0x20000000 */
#define TRNG_RAND2_RAND_30                  (0x40000000UL << TRNG_RAND2_RAND_Pos)   /* 0x40000000 */
#define TRNG_RAND2_RAND_31                  (0x80000000UL << TRNG_RAND2_RAND_Pos)   /* 0x80000000 */

/******************  Bit definition for TRNG_RAND3 register  *******************/
#define TRNG_RAND3_RAND_DPos                (0U)
#define TRNG_RAND3_RAND_Pos                 TRNG_RAND3_RAND_DPos
#define TRNG_RAND3_RAND_Msk                 (0xFFFFFFFFUL << TRNG_RAND3_RAND_Pos)   /* 0xFFFFFFFF */
#define TRNG_RAND3_RAND                     TRNG_RAND3_RAND_Msk                     /* TRNG Random Number Register 3 */
#define TRNG_RAND3_RAND_0                   (0x1UL << TRNG_RAND3_RAND_Pos)          /* 0x00000001 */
#define TRNG_RAND3_RAND_1                   (0x2UL << TRNG_RAND3_RAND_Pos)          /* 0x00000002 */
#define TRNG_RAND3_RAND_2                   (0x4UL << TRNG_RAND3_RAND_Pos)          /* 0x00000004 */
#define TRNG_RAND3_RAND_3                   (0x8UL << TRNG_RAND3_RAND_Pos)          /* 0x00000008 */
#define TRNG_RAND3_RAND_4                   (0x10UL << TRNG_RAND3_RAND_Pos)         /* 0x00000010 */
#define TRNG_RAND3_RAND_5                   (0x20UL << TRNG_RAND3_RAND_Pos)         /* 0x00000020 */
#define TRNG_RAND3_RAND_6                   (0x40UL << TRNG_RAND3_RAND_Pos)         /* 0x00000040 */
#define TRNG_RAND3_RAND_7                   (0x80UL << TRNG_RAND3_RAND_Pos)         /* 0x00000080 */
#define TRNG_RAND3_RAND_8                   (0x100UL << TRNG_RAND3_RAND_Pos)        /* 0x00000100 */
#define TRNG_RAND3_RAND_9                   (0x200UL << TRNG_RAND3_RAND_Pos)        /* 0x00000200 */
#define TRNG_RAND3_RAND_10                  (0x400UL << TRNG_RAND3_RAND_Pos)        /* 0x00000400 */
#define TRNG_RAND3_RAND_11                  (0x800UL << TRNG_RAND3_RAND_Pos)        /* 0x00000800 */
#define TRNG_RAND3_RAND_12                  (0x1000UL << TRNG_RAND3_RAND_Pos)       /* 0x00001000 */
#define TRNG_RAND3_RAND_13                  (0x2000UL << TRNG_RAND3_RAND_Pos)       /* 0x00002000 */
#define TRNG_RAND3_RAND_14                  (0x4000UL << TRNG_RAND3_RAND_Pos)       /* 0x00004000 */
#define TRNG_RAND3_RAND_15                  (0x8000UL << TRNG_RAND3_RAND_Pos)       /* 0x00008000 */
#define TRNG_RAND3_RAND_16                  (0x10000UL << TRNG_RAND3_RAND_Pos)      /* 0x00010000 */
#define TRNG_RAND3_RAND_17                  (0x20000UL << TRNG_RAND3_RAND_Pos)      /* 0x00020000 */
#define TRNG_RAND3_RAND_18                  (0x40000UL << TRNG_RAND3_RAND_Pos)      /* 0x00040000 */
#define TRNG_RAND3_RAND_19                  (0x80000UL << TRNG_RAND3_RAND_Pos)      /* 0x00080000 */
#define TRNG_RAND3_RAND_20                  (0x100000UL << TRNG_RAND3_RAND_Pos)     /* 0x00100000 */
#define TRNG_RAND3_RAND_21                  (0x200000UL << TRNG_RAND3_RAND_Pos)     /* 0x00200000 */
#define TRNG_RAND3_RAND_22                  (0x400000UL << TRNG_RAND3_RAND_Pos)     /* 0x00400000 */
#define TRNG_RAND3_RAND_23                  (0x800000UL << TRNG_RAND3_RAND_Pos)     /* 0x00800000 */
#define TRNG_RAND3_RAND_24                  (0x1000000UL << TRNG_RAND3_RAND_Pos)    /* 0x01000000 */
#define TRNG_RAND3_RAND_25                  (0x2000000UL << TRNG_RAND3_RAND_Pos)    /* 0x02000000 */
#define TRNG_RAND3_RAND_26                  (0x4000000UL << TRNG_RAND3_RAND_Pos)    /* 0x04000000 */
#define TRNG_RAND3_RAND_27                  (0x8000000UL << TRNG_RAND3_RAND_Pos)    /* 0x08000000 */
#define TRNG_RAND3_RAND_28                  (0x10000000UL << TRNG_RAND3_RAND_Pos)   /* 0x10000000 */
#define TRNG_RAND3_RAND_29                  (0x20000000UL << TRNG_RAND3_RAND_Pos)   /* 0x20000000 */
#define TRNG_RAND3_RAND_30                  (0x40000000UL << TRNG_RAND3_RAND_Pos)   /* 0x40000000 */
#define TRNG_RAND3_RAND_31                  (0x80000000UL << TRNG_RAND3_RAND_Pos)   /* 0x80000000 */

/* @name FLASH register bits definition */
/******************  Bits definition for EFLASH_SR register  *****************/
#define EFLASH_SR_LOCK_DPos             (0U)
#define EFLASH_SR_LOCK_Pos              EFLASH_SR_LOCK_DPos
#define EFLASH_SR_LOCK_Msk              (0x01UL << EFLASH_SR_LOCK_Pos)          /* 0x00000001 */
#define EFLASH_SR_LOCK                  EFLASH_SR_LOCK_Msk                      /* Lock status flag */

#define EFLASH_SR_BUSY_DPos             (1U)
#define EFLASH_SR_BUSY_Pos              EFLASH_SR_BUSY_DPos
#define EFLASH_SR_BUSY_Msk              (0x01UL << EFLASH_SR_BUSY_Pos)          /* 0x00000002 */
#define EFLASH_SR_BUSY                  EFLASH_SR_BUSY_Msk                      /* Busy flag */

#define EFLASH_SR_FINISH_DPos           (2U)
#define EFLASH_SR_FINISH_Pos            EFLASH_SR_FINISH_DPos
#define EFLASH_SR_FINISH_Msk            (0x01UL << EFLASH_SR_FINISH_Pos)        /* 0x00000004 */
#define EFLASH_SR_FINISH                EFLASH_SR_FINISH_Msk                    /* Command finish flag */

#define EFLASH_SR_OPERR_DPos            (3U)
#define EFLASH_SR_OPERR_Pos             EFLASH_SR_OPERR_DPos
#define EFLASH_SR_OPERR_Msk             (0x01UL << EFLASH_SR_OPERR_Pos)         /* 0x00000008 */
#define EFLASH_SR_OPERR                 EFLASH_SR_OPERR_Msk                     /* Operation error flag */

#define EFLASH_SR_ECC1ERR_DPos          (4U)
#define EFLASH_SR_ECC1ERR_Pos           EFLASH_SR_ECC1ERR_DPos
#define EFLASH_SR_ECC1ERR_Msk           (0x01UL << EFLASH_SR_ECC1ERR_Pos)       /* 0x00000010 */
#define EFLASH_SR_ECC1ERR               EFLASH_SR_ECC1ERR_Msk                   /* ECC 1-bit error flag */

#define EFLASH_SR_ECC2ERR_DPos          (5U)
#define EFLASH_SR_ECC2ERR_Pos           EFLASH_SR_ECC2ERR_DPos
#define EFLASH_SR_ECC2ERR_Msk           (0x01UL << EFLASH_SR_ECC2ERR_Pos)       /* 0x00000020 */
#define EFLASH_SR_ECC2ERR               EFLASH_SR_ECC2ERR_Msk                   /* ECC 2-bit error flag */

#define EFLASH_SR_WPERR_DPos            (6U)
#define EFLASH_SR_WPERR_Pos             EFLASH_SR_WPERR_DPos
#define EFLASH_SR_WPERR_Msk             (0x01UL << EFLASH_SR_WPERR_Pos)         /* 0x00000040 */
#define EFLASH_SR_WPERR                 EFLASH_SR_WPERR_Msk                     /* Write protection error flag */

#define EFLASH_SR_SECKEYERR_DPos        (7U)
#define EFLASH_SR_SECKEYERR_Pos         EFLASH_SR_SECKEYERR_DPos
#define EFLASH_SR_SECKEYERR_Msk         (0x01UL << EFLASH_SR_SECKEYERR_Pos)     /* 0x00000080 */
#define EFLASH_SR_SECKEYERR             EFLASH_SR_SECKEYERR_Msk                 /* Flash Security Key verification error flag */

#define EFLASH_SR_CLKSWRDY_DPos         (16U)
#define EFLASH_SR_CLKSWRDY_Pos          EFLASH_SR_CLKSWRDY_DPos
#define EFLASH_SR_CLKSWRDY_Msk          (0x01UL << EFLASH_SR_CLKSWRDY_Pos)      /* 0x00010000 */
#define EFLASH_SR_CLKSWRDY              EFLASH_SR_CLKSWRDY_Msk                  /* Flash clock switching status flag */


/******************  Bits definition for EFLASH_UNLKR register  *****************/
#define EFLASH_UNLKR_KEY_DPos           (0U)
#define EFLASH_UNLKR_UNLKR_Pos          EFLASH_UNLKR_KEY_DPos
#define EFLASH_UNLKR_UNLKR_Msk          (0xFFFFFFFFUL << EFLASH_UNLKR_UNLKR_Pos)    /* 0xFFFFFFFF */
#define EFLASH_UNLKR_UNLKR              EFLASH_UNLKR_UNLKR_Msk                      /* UNLKR[31:0] bits (Unlock flash) */

/******************  Bits definition for EFLASH_CR register  *****************/
#define EFLASH_CR_FINIE_DPos            (0U)
#define EFLASH_CR_FINIE_Pos             EFLASH_CR_FINIE_DPos
#define EFLASH_CR_FINIE_Msk             (0x01UL << EFLASH_CR_FINIE_Pos)         /* 0x00000001 */
#define EFLASH_CR_FINIE                 EFLASH_CR_FINIE_Msk                     /* command finish interrupt enable */

#define EFLASH_CR_OPEIE_DPos            (1U)
#define EFLASH_CR_OPEIE_Pos             EFLASH_CR_OPEIE_DPos
#define EFLASH_CR_OPEIE_Msk             (0x01UL << EFLASH_CR_OPEIE_Pos)         /* 0x00000002 */
#define EFLASH_CR_OPEIE                 EFLASH_CR_OPEIE_Msk                     /* operation error interrupt enable */

#define EFLASH_CR_ECC2EIE_DPos          (2U)
#define EFLASH_CR_ECC2EIE_Pos           EFLASH_CR_ECC2EIE_DPos
#define EFLASH_CR_ECC2EIE_Msk           (0x01UL << EFLASH_CR_ECC2EIE_Pos)       /* 0x00000004 */
#define EFLASH_CR_ECC2EIE               EFLASH_CR_ECC2EIE_Msk                   /* ECC 2 bit error interrupt enable */

#define EFLASH_CR_CLKFRQ_DPos           (16U)
#define EFLASH_CR_CLKFRQ_Pos            EFLASH_CR_CLKFRQ_DPos
#define EFLASH_CR_CLKFRQ_Msk            (0xFFFFUL << EFLASH_CR_CLKFRQ_Pos)      /* 0xFFFF0000 */
#define EFLASH_CR_CLKFRQ                EFLASH_CR_CLKFRQ_Msk                    /* CLKFRQ[15:0] bits (Clock frequency) */

/******************  Bits definition for EFLASH_CIDR register  *****************/
#define EFLASH_CIDR_CMD_DPos            (0U)
#define EFLASH_CIDR_CIDR_Pos            EFLASH_CIDR_CMD_DPos
#define EFLASH_CIDR_CIDR_Msk            (0xFFUL << EFLASH_CIDR_CIDR_Pos)        /* 0x000000FF */
#define EFLASH_CIDR_CIDR                EFLASH_CIDR_CIDR_Msk                    /* CIDR[7:0] bits (Command ID) */

/******************  Bits definition for EFLASH_AR register  *****************/
#define EFLASH_AR_ADDR_DPos             (0U)
#define EFLASH_AR_AR_Pos                EFLASH_AR_ADDR_DPos
#define EFLASH_AR_AR_Msk                (0xFFFFFFFFUL << EFLASH_AR_AR_Pos)      /* 0xFFFFFFFF */
#define EFLASH_AR_AR                    EFLASH_AR_AR_Msk                        /* AR[31:0] bits (Operation address) */

/******************  Bits definition for EFLASH_DLR register  *****************/
#define EFLASH_DLR_LEN_DPos             (0U)
#define EFLASH_DLR_DLR_Pos              EFLASH_DLR_LEN_DPos
#define EFLASH_DLR_DLR_Msk              (0xFFUL << EFLASH_DLR_DLR_Pos)          /* 0x000000FF */
#define EFLASH_DLR_DLR                  EFLASH_DLR_DLR_Msk                      /* DLR[31:0] bits (Data length) */

/******************  Bits definition for EFLASH_DR0 register  *****************/
#define EFLASH_DR0_DATA0_DPos           (0U)
#define EFLASH_DR0_DR0_Pos              EFLASH_DR0_DATA0_DPos
#define EFLASH_DR0_DR0_Msk              (0xFFFFFFFFUL << EFLASH_DR0_DR0_Pos)    /* 0xFFFFFFFF */
#define EFLASH_DR0_DR0                  EFLASH_DR0_DR0_Msk                      /* DR0[31:0] bits (Data register low 32 bit) */

/******************  Bits definition for EFLASH_DR1 register  *****************/
#define EFLASH_DR1_DATA1_DPos           (0U)
#define EFLASH_DR1_DR1_Pos              EFLASH_DR1_DATA1_DPos
#define EFLASH_DR1_DR1_Msk              (0xFFFFFFFFUL << EFLASH_DR1_DR1_Pos)    /* 0xFFFFFFFF */
#define EFLASH_DR1_DR1                  EFLASH_DR1_DR1_Msk                      /* DR1[31:0] bits (Data register high 32 bit) */

/******************  Bits definition for EFLASH_CTR register  *****************/
#define EFLASH_CTR_START_DPos           (0U)
#define EFLASH_CTR_CTR_Pos              EFLASH_CTR_START_DPos
#define EFLASH_CTR_CTR_Msk              (0x01UL << EFLASH_CTR_CTR_Pos)          /* 0x00000000 */
#define EFLASH_CTR_CTR                  EFLASH_CTR_CTR_Msk                      /* Cmmand start */

/******************  Bits definition for EFLASH_PWPR register  *****************/
#define EFLASH_PWPR_PPROT_DPos          (0U)
#define EFLASH_PWPR_PWPR_Pos            EFLASH_PWPR_PPROT_DPos
#define EFLASH_PWPR_PWPR_Msk            (0xFFFFFFFFUL << EFLASH_PWPR_PWPR_Pos)  /* 0xFFFFFFFF */
#define EFLASH_PWPR_PWPR                EFLASH_PWPR_PWPR_Msk                    /* PWPR[31:0] bits (PFlash write protection status value) */

/******************  Bits definition for EFLASH_DWPR register  *****************/
#define EFLASH_DWPR_DPROT_DPos          (0U)
#define EFLASH_DWPR_DWPR_Pos            EFLASH_DWPR_DPROT_DPos
#define EFLASH_DWPR_DWPR_Msk            (0xFFFFFFFFUL << EFLASH_DWPR_DWPR_Pos)  /* 0xFFFFFFFF */
#define EFLASH_DWPR_DWPR                EFLASH_DWPR_DWPR_Msk                    /* DWPR[31:0] bits (DFlash write protection status value) */

/******************  Bits definition for EFLASH_EAR register  *****************/
#define EFLASH_EAR_ECC_ADDR_DPos        (0U)
#define EFLASH_EAR_EAR_Pos              EFLASH_EAR_ECC_ADDR_DPos
#define EFLASH_EAR_EAR_Msk              (0xFFFFFFFFUL << EFLASH_EAR_EAR_Pos)    /* 0xFFFFFFFF */
#define EFLASH_EAR_EAR                  EFLASH_EAR_EAR_Msk                      /* EAR[31:0] bits (ECC 2bit error address) */

/******************  Bits definition for EFLASH_SECR register  *****************/
#define EFLASH_SECR_RPROT_DPos          (0U)
#define EFLASH_SECR_RPROT_Pos           EFLASH_SECR_RPROT_DPos
#define EFLASH_SECR_RPROT_Msk           (0x03UL << EFLASH_SECR_RPROT_Pos)       /* 0x00000003 */
#define EFLASH_SECR_RPROT               EFLASH_SECR_RPROT_Msk                   /* RPROT[1:0] bits (Flash read protection enable flag) */

#define EFLASH_SECR_SECKEYEN_DPos       (0U)
#define EFLASH_SECR_SECKEYEN_Pos        EFLASH_SECR_SECKEYEN_DPos
#define EFLASH_SECR_SECKEYEN_Msk        (0x03UL << EFLASH_SECR_SECKEYEN_Pos)    /* 0x0000000C */
#define EFLASH_SECR_SECKEYEN            EFLASH_SECR_SECKEYEN_Msk                /* RPROT[3:2] bits (Flash security key enable flag) */


/******************  Bits definition for EFLASH_SECKEY0 register  *****************/
#define EFLASH_SECKEY0_SECKEY0_DPos     (0U)
#define EFLASH_SECKEY0_SECKEY0_Pos      EFLASH_SECKEY0_SECKEY0_DPos
#define EFLASH_SECKEY0_SECKEY0_Msk      (0xFFFFFFFFUL << EFLASH_SECKEY0_SECKEY0_Pos)    /* 0xFFFFFFFF */
#define EFLASH_SECKEY0_SECKEY0          EFLASH_SECKEY0_SECKEY0_Msk                      /* SECKEY0[31:0] bits (Flash security key low 32 bits) */

/******************  Bits definition for EFLASH_SECKEY1 register  *****************/
#define EFLASH_SECKEY1_SECKEY1_DPos     (0U)
#define EFLASH_SECKEY1_SECKEY1_Pos      EFLASH_SECKEY1_SECKEY1_DPos
#define EFLASH_SECKEY1_SECKEY1_Msk      (0xFFFFFFFFUL << EFLASH_SECKEY1_SECKEY1_Pos)    /* 0xFFFFFFFF */
#define EFLASH_SECKEY1_SECKEY1          EFLASH_SECKEY1_SECKEY1_Msk                      /* SECKEY1[31:0] bits (Flash security key high 32 bits) */

/* @name QSPI register bits definition */
/******************  Bits definition for QSPI_CR register  *****************/
#define QSPI_CR_EN_DPos                 (0U)
#define QSPI_CR_EN_Pos                  QSPI_CR_EN_DPos
#define QSPI_CR_EN_Msk                  (0x1UL << QSPI_CR_EN_Pos)               /* 0x00000001 */
#define QSPI_CR_EN                      QSPI_CR_EN_Msk                          /* Enable QPSI */

#define QSPI_CR_ABORT_DPos              (1U)
#define QSPI_CR_ABORT_Pos               QSPI_CR_ABORT_DPos
#define QSPI_CR_ABORT_Msk               (0x1UL << QSPI_CR_ABORT_Pos)            /* 0x00000002 */
#define QSPI_CR_ABORT                   QSPI_CR_ABORT_Msk                       /* Abort request */

#define QSPI_CR_CKMODE_DPos             (2U)
#define QSPI_CR_CKMODE_Pos              QSPI_CR_CKMODE_DPos
#define QSPI_CR_CKMODE_Msk              (0x1UL << QSPI_CR_CKMODE_Pos)           /* 0x00000004 */
#define QSPI_CR_CKMODE                  QSPI_CR_CKMODE_Msk                      /* Mode 0/mode 3 */

#define QSPI_CR_CSHT_DPos               (3U)
#define QSPI_CR_CSHT_Pos                QSPI_CR_CSHT_DPos
#define QSPI_CR_CSHT_Msk                (0x7UL << QSPI_CR_CSHT_Pos)             /* 0x00000038 */
#define QSPI_CR_CSHT                    QSPI_CR_CSHT_Msk                        /* CSHT[2:0] bits (Chip select high time) */
#define QSPI_CR_CSHT_0                  (0x01UL << QSPI_CR_CSHT_Pos)            /* 0x00000008 */
#define QSPI_CR_CSHT_1                  (0x02UL << QSPI_CR_CSHT_Pos)            /* 0x00000010 */
#define QSPI_CR_CSHT_2                  (0x04UL << QSPI_CR_CSHT_Pos)            /* 0x00000020 */

#define QSPI_CR_PRESCALER_DPos          (8U)
#define QSPI_CR_PRESCALER_Pos           QSPI_CR_PRESCALER_DPos
#define QSPI_CR_PRESCALER_Msk           (0xFFUL << QSPI_CR_PRESCALER_Pos)       /* 0x0000FF00 */
#define QSPI_CR_PRESCALER               QSPI_CR_PRESCALER_Msk                   /* PRESCALER[7:0] bits (Clock prescaler) */
#define QSPI_CR_PRESCALER_0             (0x01UL << QSPI_CR_PRESCALER_Pos)       /* 0x00000100 */
#define QSPI_CR_PRESCALER_1             (0x02UL << QSPI_CR_PRESCALER_Pos)       /* 0x00000200 */
#define QSPI_CR_PRESCALER_2             (0x04UL << QSPI_CR_PRESCALER_Pos)       /* 0x00000400 */
#define QSPI_CR_PRESCALER_3             (0x08UL << QSPI_CR_PRESCALER_Pos)       /* 0x00000800 */
#define QSPI_CR_PRESCALER_4             (0x10UL << QSPI_CR_PRESCALER_Pos)       /* 0x00001000 */
#define QSPI_CR_PRESCALER_5             (0x20UL << QSPI_CR_PRESCALER_Pos)       /* 0x00002000 */
#define QSPI_CR_PRESCALER_6             (0x40UL << QSPI_CR_PRESCALER_Pos)       /* 0x00004000 */
#define QSPI_CR_PRESCALER_7             (0x80UL << QSPI_CR_PRESCALER_Pos)       /* 0x00008000 */

/******************  Bits definition for QSPI_CCR register  *****************/
#define QSPI_CCR_INST_DPos              (0U)
#define QSPI_CCR_INST_Pos               QSPI_CCR_INST_DPos
#define QSPI_CCR_INST_Msk               (0xFFUL << QSPI_CCR_INST_Pos)           /* 0x000000FF */
#define QSPI_CCR_INST                   QSPI_CCR_INST_Msk                       /* INST[7:0] bits (Instructions sent to the QSPI Flash) */
#define QSPI_CCR_INST_0                 (0x01UL << QSPI_CCR_INST_Pos)           /* 0x00000001 */
#define QSPI_CCR_INST_1                 (0x02UL << QSPI_CCR_INST_Pos)           /* 0x00000002 */
#define QSPI_CCR_INST_2                 (0x04UL << QSPI_CCR_INST_Pos)           /* 0x00000004 */
#define QSPI_CCR_INST_3                 (0x08UL << QSPI_CCR_INST_Pos)           /* 0x00000008 */
#define QSPI_CCR_INST_4                 (0x10UL << QSPI_CCR_INST_Pos)           /* 0x00000010 */
#define QSPI_CCR_INST_5                 (0x20UL << QSPI_CCR_INST_Pos)           /* 0x00000020 */
#define QSPI_CCR_INST_6                 (0x40UL << QSPI_CCR_INST_Pos)           /* 0x00000040 */
#define QSPI_CCR_INST_7                 (0x80UL << QSPI_CCR_INST_Pos)           /* 0x00000080 */

#define QSPI_CCR_IMODE_DPos             (8U)
#define QSPI_CCR_IMODE_Pos              QSPI_CCR_IMODE_DPos
#define QSPI_CCR_IMODE_Msk              (0x3UL << QSPI_CCR_IMODE_Pos)           /* 0x00000300 */
#define QSPI_CCR_IMODE                  QSPI_CCR_IMODE_Msk                      /* IMODE[1:0] bits (Instruction mode) */
#define QSPI_CCR_IMODE_0                (0x01UL << QSPI_CCR_IMODE_Pos)          /* 0x00000100 */
#define QSPI_CCR_IMODE_1                (0x02UL << QSPI_CCR_IMODE_Pos)          /* 0x00000200 */

#define QSPI_CCR_ADMODE_DPos            (10U)
#define QSPI_CCR_ADMODE_Pos             QSPI_CCR_ADMODE_DPos
#define QSPI_CCR_ADMODE_Msk             (0x3UL << QSPI_CCR_ADMODE_Pos)          /* 0x00000C00 */
#define QSPI_CCR_ADMODE                 QSPI_CCR_ADMODE_Msk                     /* ADMODE[1:0] bits (Address mode) */
#define QSPI_CCR_ADMODE_0               (0x01UL << QSPI_CCR_ADMODE_Pos)         /* 0x00000100 */
#define QSPI_CCR_ADMODE_1               (0x02UL << QSPI_CCR_ADMODE_Pos)         /* 0x00000200 */

#define QSPI_CCR_ADSIZE_DPos            (12U)
#define QSPI_CCR_ADSIZE_Pos             QSPI_CCR_ADSIZE_DPos
#define QSPI_CCR_ADSIZE_Msk             (0x3UL << QSPI_CCR_ADSIZE_Pos)          /* 0x00003000 */
#define QSPI_CCR_ADSIZE                 QSPI_CCR_ADSIZE_Msk                     /* ADSIZE [1:0] bits (Address size) */
#define QSPI_CCR_ADSIZE_0               (0x01UL << QSPI_CCR_ADSIZE_Pos)         /* 0x00001000 */
#define QSPI_CCR_ADSIZE_1               (0x02UL << QSPI_CCR_ADSIZE_Pos)         /* 0x00002000 */

#define QSPI_CCR_ABMODE_DPos            (14U)
#define QSPI_CCR_ABMODE_Pos             QSPI_CCR_ABMODE_DPos
#define QSPI_CCR_ABMODE_Msk             (0x3UL << QSPI_CCR_ABMODE_Pos)          /* 0x0000C000 */
#define QSPI_CCR_ABMODE                 QSPI_CCR_ABMODE_Msk                     /* ABMODE [1:0] bits (Alternate bytes mode) */
#define QSPI_CCR_ABMODE_0               (0x01UL << QSPI_CCR_ABMODE_Pos)         /* 0x00004000 */
#define QSPI_CCR_ABMODE_1               (0x02UL << QSPI_CCR_ABMODE_Pos)         /* 0x00008000 */

#define QSPI_CCR_ABSIZE_DPos            (16U)
#define QSPI_CCR_ABSIZE_Pos             QSPI_CCR_ABSIZE_DPos
#define QSPI_CCR_ABSIZE_Msk             (0x3UL << QSPI_CCR_ABSIZE_Pos)          /* 0x00030000 */
#define QSPI_CCR_ABSIZE                 QSPI_CCR_ABSIZE_Msk                     /* ABSIZE [1:0] bits (Alternate bytes size) */
#define QSPI_CCR_ABSIZE_0               (0x01UL << QSPI_CCR_ABSIZE_Pos)         /* 0x00010000 */
#define QSPI_CCR_ABSIZE_1               (0x02UL << QSPI_CCR_ABSIZE_Pos)         /* 0x00020000 */

#define QSPI_CCR_DUMMY_DPos             (18U)
#define QSPI_CCR_DUMMY_Pos              QSPI_CCR_DUMMY_DPos
#define QSPI_CCR_DUMMY_Msk              (0x1FUL << QSPI_CCR_DUMMY_Pos)          /* 0x007C0000 */
#define QSPI_CCR_DUMMY                  QSPI_CCR_DUMMY_Msk                      /* DUMMY [4:0] bits (Dummy cycles) */
#define QSPI_CCR_DUMMY_0                (0x01UL << QSPI_CCR_DUMMY_Pos)          /* 0x00040000 */
#define QSPI_CCR_DUMMY_1                (0x02UL << QSPI_CCR_DUMMY_Pos)          /* 0x00080000 */
#define QSPI_CCR_DUMMY_2                (0x04UL << QSPI_CCR_DUMMY_Pos)          /* 0x00100000 */
#define QSPI_CCR_DUMMY_3                (0x08UL << QSPI_CCR_DUMMY_Pos)          /* 0x00200000 */
#define QSPI_CCR_DUMMY_4                (0x10UL << QSPI_CCR_DUMMY_Pos)          /* 0x00400000 */

#define QSPI_CCR_DMODE_DPos             (23U)
#define QSPI_CCR_DMODE_Pos              QSPI_CCR_DMODE_DPos
#define QSPI_CCR_DMODE_Msk              (0x3UL << QSPI_CCR_DMODE_Pos)           /* 0x01800000 */
#define QSPI_CCR_DMODE                  QSPI_CCR_DMODE_Msk                      /* DMODE [1:0] bits (Data mode) */
#define QSPI_CCR_DMODE_0                (0x01UL << QSPI_CCR_DMODE_Pos)          /* 0x00800000 */
#define QSPI_CCR_DMODE_1                (0x02UL << QSPI_CCR_DMODE_Pos)          /* 0x01000000 */

#define QSPI_CCR_FMODE_DPos             (25U)
#define QSPI_CCR_FMODE_Pos              QSPI_CCR_FMODE_DPos
#define QSPI_CCR_FMODE_Msk              (0x3UL << QSPI_CCR_FMODE_Pos)           /* 0x06000000 */
#define QSPI_CCR_FMODE                  QSPI_CCR_FMODE_Msk                      /* FMODE [1:0] bits (Functional mode) */
#define QSPI_CCR_FMODE_0                (0x01UL << QSPI_CCR_FMODE_Pos)          /* 0x02000000 */
#define QSPI_CCR_FMODE_1                (0x02UL << QSPI_CCR_FMODE_Pos)          /* 0x04000000 */


/******************  Bits definition for QSPI_SR register  *****************/
#define QSPI_SR_BUSY_DPos               (0U)
#define QSPI_SR_BUSY_Pos                QSPI_SR_BUSY_DPos
#define QSPI_SR_BUSY_Msk                (0x1UL << QSPI_SR_BUSY_Pos)             /* 0x00000001 */
#define QSPI_SR_BUSY                    QSPI_SR_BUSY_Msk                        /* Busy */

#define QSPI_SR_FLEVEL_DPos             (1U)
#define QSPI_SR_FLEVEL_Pos              QSPI_SR_FLEVEL_DPos
#define QSPI_SR_FLEVEL_Msk              (0x3FUL << QSPI_SR_FLEVEL_Pos)          /* 0x0000007E */
#define QSPI_SR_FLEVEL                  QSPI_SR_FLEVEL_Msk                      /* FMODE [5:0] bits (FIFO level) */
#define QSPI_SR_FLEVEL_0                (0x01UL << QSPI_SR_FLEVEL_Pos)          /* 0x00000002 */
#define QSPI_SR_FLEVEL_1                (0x02UL << QSPI_SR_FLEVEL_Pos)          /* 0x00000004 */
#define QSPI_SR_FLEVEL_2                (0x04UL << QSPI_SR_FLEVEL_Pos)          /* 0x00000008 */
#define QSPI_SR_FLEVEL_3                (0x08UL << QSPI_SR_FLEVEL_Pos)          /* 0x00000010 */
#define QSPI_SR_FLEVEL_4                (0x10UL << QSPI_SR_FLEVEL_Pos)          /* 0x00000020 */
#define QSPI_SR_FLEVEL_5                (0x20UL << QSPI_SR_FLEVEL_Pos)          /* 0x00000040 */

#define QSPI_SR_TCF_DPos                (7U)
#define QSPI_SR_TCF_Pos                 QSPI_SR_TCF_DPos
#define QSPI_SR_TCF_Msk                 (0x1UL << QSPI_SR_TCF_Pos)              /* 0x00000080 */
#define QSPI_SR_TCF                     QSPI_SR_TCF_Msk                         /* Transfer complete flag */

#define QSPI_SR_TOF_DPos                (8U)
#define QSPI_SR_TOF_Pos                 QSPI_SR_TOF_DPos
#define QSPI_SR_TOF_Msk                 (0x1UL << QSPI_SR_TOF_Pos)              /* 0x00000100 */
#define QSPI_SR_TOF                     QSPI_SR_TOF_Msk                         /* Timeout flag */

#define QSPI_SR_PMF_DPos                (9U)
#define QSPI_SR_PMF_Pos                 QSPI_SR_PMF_DPos
#define QSPI_SR_PMF_Msk                 (0x1UL << QSPI_SR_PMF_Pos)              /* 0x00000200 */
#define QSPI_SR_PMF                     QSPI_SR_PMF_Msk                         /* Polling match flag */


/******************  Bits definition for QSPI_FCR register  *****************/
#define QSPI_FCR_CTCF_DPos              (0U)
#define QSPI_FCR_CTCF_Pos               QSPI_FCR_CTCF_DPos
#define QSPI_FCR_CTCF_Msk               (0x1UL << QSPI_FCR_CTCF_Pos)            /* 0x00000001 */
#define QSPI_FCR_CTCF                   QSPI_FCR_CTCF_Msk                       /* Clear transfer complete flag */

#define QSPI_FCR_CTOF_DPos              (1U)
#define QSPI_FCR_CTOF_Pos               QSPI_FCR_CTOF_DPos
#define QSPI_FCR_CTOF_Msk               (0x1UL << QSPI_FCR_CTOF_Pos)            /* 0x00000002 */
#define QSPI_FCR_CTOF                   QSPI_FCR_CTOF_Msk                       /* Clear timeout flag */

#define QSPI_FCR_CPMF_DPos              (2U)
#define QSPI_FCR_CPMF_Pos               QSPI_FCR_CPMF_DPos
#define QSPI_FCR_CPMF_Msk               (0x1UL << QSPI_FCR_CPMF_Pos)            /* 0x00000004 */
#define QSPI_FCR_CPMF                   QSPI_FCR_CPMF_Msk                       /* Clear polling match flag */


/******************  Bits definition for QSPI_AR register  *****************/
#define QSPI_AR_ADDRESS_DPos            (0U)
#define QSPI_AR_ADDRESS_Pos             QSPI_AR_ADDRESS_DPos
#define QSPI_AR_ADDRESS_Msk             (0xFFFFFFFFUL << QSPI_AR_ADDRESS_Pos)   /* 0xFFFFFFFF */
#define QSPI_AR_ADDRESS                 QSPI_AR_ADDRESS_Msk                     /* The address sent to the QSPI-Flash */

/******************  Bits definition for QSPI_ABR register  *****************/
#define QSPI_ABR_ALTERNATE_DPos         (0U)
#define QSPI_ABR_ALTERNATE_Pos          QSPI_ABR_ALTERNATE_DPos
#define QSPI_ABR_ALTERNATE_Msk          (0xFFFFFFFFUL << QSPI_ABR_ALTERNATE_Pos)    /* 0xFFFFFFFF */
#define QSPI_ABR_ALTERNATE              QSPI_ABR_ALTERNATE_Msk                      /* The alternate bytes for the QSPI-Flash */

/******************  Bits definition for QSPI_DR register  *****************/
#define QSPI_DR_DATA_DPos               (0U)
#define QSPI_DR_DATA_Pos                QSPI_DR_DATA_DPos
#define QSPI_DR_DATA_Msk                (0xFFFFFFFFUL << QSPI_DR_DATA_Pos)      /* 0xFFFFFFFF */
#define QSPI_DR_DATA                    QSPI_DR_DATA_Msk                        /* Alternate bytes */

/******************  Bits definition for QSPI_DLR register  *****************/
#define QSPI_DLR_DATALENGTH_DPos        (0U)
#define QSPI_DLR_DATALENGTH_Pos         QSPI_DLR_DATALENGTH_DPos
#define QSPI_DLR_DATALENGTH_Msk         (0xFFFFFFFFUL << QSPI_DLR_DATALENGTH_Pos)   /* 0xFFFFFFFF */
#define QSPI_DLR_DATALENGTH             QSPI_DLR_DATALENGTH_Msk                     /* Communication data length */

/******************  Bits definition for QSPI_TOR register  *****************/
#define QSPI_TOR_TIMEOUT_DPos           (0U)
#define QSPI_TOR_TIMEOUT_Pos            QSPI_TOR_TIMEOUT_DPos
#define QSPI_TOR_TIMEOUT_Msk            (0xFFFFUL << QSPI_TOR_TIMEOUT_Pos)      /* 0x0000FFFF */
#define QSPI_TOR_TIMEOUT                QSPI_TOR_TIMEOUT_Msk                    /* Timeout duration */

/******************  Bits definition for QSPI_PIR register  *****************/
#define QSPI_PIR_INTERVAL_DPos          (0U)
#define QSPI_PIR_INTERVAL_Pos           QSPI_PIR_INTERVAL_DPos
#define QSPI_PIR_INTERVAL_Msk           (0xFFFFUL << QSPI_PIR_INTERVAL_Pos)     /* 0x0000FFFF */
#define QSPI_PIR_INTERVAL               QSPI_PIR_INTERVAL_Msk                   /* Polling interval */

/******************  Bits definition for QSPI_PSMAR register  *****************/
#define QSPI_PSMAR_MATCH_DPos           (0U)
#define QSPI_PSMAR_MATCH_Pos            QSPI_PSMAR_MATCH_DPos
#define QSPI_PSMAR_MATCH_Msk            (0xFFFFFFFFUL << QSPI_PSMAR_MATCH_Pos)  /* 0xFFFFFFFF */
#define QSPI_PSMAR_MATCH                QSPI_PSMAR_MATCH_Msk                    /* Polling status matching */

/******************  Bits definition for QSPI_PSMKR register  *****************/
#define QSPI_PSMKR_MASK_DPos            (0U)
#define QSPI_PSMKR_MASK_Pos             QSPI_PSMKR_MASK_DPos
#define QSPI_PSMKR_MASK_Msk             (0xFFFFFFFFUL << QSPI_PSMKR_MASK_Pos)   /* 0xFFFFFFFF */
#define QSPI_PSMKR_MASK                 QSPI_PSMKR_MASK_Msk                     /* Polling status masking */

/* @name MAC register bits definition */
/******************  Bit definition for MAC_BUS_MODE register  *******************/
#define MAC_BUS_MODE_SWR_DPos       (0U)
#define MAC_BUS_MODE_SWR_Pos        MAC_BUS_MODE_SWR_DPos
#define MAC_BUS_MODE_SWR_Msk        (0x1UL << MAC_BUS_MODE_SWR_Pos)                /* 0x00000001 */
#define MAC_BUS_MODE_SWR            MAC_BUS_MODE_SWR_Msk                           /* Software Reset. */

#define MAC_BUS_MODE_BAR_DPos       (1U)
#define MAC_BUS_MODE_BAR_Pos        MAC_BUS_MODE_BAR_DPos
#define MAC_BUS_MODE_BAR_Msk        (0x1UL << MAC_BUS_MODE_BAR_Pos)                /* 0x00000002 */
#define MAC_BUS_MODE_BAR            MAC_BUS_MODE_BAR_Msk                           /* BUS Arbitration. */

#define MAC_BUS_MODE_DSL_DPos       (2U)
#define MAC_BUS_MODE_DSL_Pos        MAC_BUS_MODE_DSL_DPos
#define MAC_BUS_MODE_DSL_Msk        (0x1FUL << MAC_BUS_MODE_DSL_Pos)               /* 0x0000007c */
#define MAC_BUS_MODE_DSL            MAC_BUS_MODE_DSL_Msk                           /*DSL[4:0] bits (Descriptor Skip Lenngth) */
#define MAC_BUS_MODE_DSL_0          (0x1UL << MAC_BUS_MODE_DSL_Pos)                /* 0x00000004 */
#define MAC_BUS_MODE_DSL_1          (0x2UL << MAC_BUS_MODE_DSL_Pos)                /* 0x00000008 */
#define MAC_BUS_MODE_DSL_2          (0x4UL << MAC_BUS_MODE_DSL_Pos)                /* 0x00000010 */
#define MAC_BUS_MODE_DSL_3          (0x8UL << MAC_BUS_MODE_DSL_Pos)                /* 0x00000020 */
#define MAC_BUS_MODE_DSL_4          (0x10UL << MAC_BUS_MODE_DSL_Pos)               /* 0x00000040 */

#define MAC_BUS_MODE_BLE_DPos       (7U)
#define MAC_BUS_MODE_BLE_Pos        MAC_BUS_MODE_BLE_DPos
#define MAC_BUS_MODE_BLE_Msk        (0x1UL << MAC_BUS_MODE_BLE_Pos)                /* 0x00000080 */
#define MAC_BUS_MODE_BLE            MAC_BUS_MODE_BLE_Msk                           /* Big-Endian and Little-Endian Select. */

#define MAC_BUS_MODE_PBL_DPos       (8U)
#define MAC_BUS_MODE_PBL_Pos        MAC_BUS_MODE_PBL_DPos
#define MAC_BUS_MODE_PBL_Msk        (0x3FUL << MAC_BUS_MODE_PBL_Pos)               /* 0x00003F00 */
#define MAC_BUS_MODE_PBL            MAC_BUS_MODE_PBL_Msk                           /*PBL[5:0] bits (Programmable Burst Length) */
#define MAC_BUS_MODE_PBL_0          (0x1UL << MAC_BUS_MODE_PBL_Pos)                /* 0x00000100 */
#define MAC_BUS_MODE_PBL_1          (0x2UL << MAC_BUS_MODE_PBL_Pos)                /* 0x00000200 */
#define MAC_BUS_MODE_PBL_2          (0x4UL << MAC_BUS_MODE_PBL_Pos)                /* 0x00000400 */
#define MAC_BUS_MODE_PBL_3          (0x8UL << MAC_BUS_MODE_PBL_Pos)                /* 0x00000800 */
#define MAC_BUS_MODE_PBL_4          (0x10UL << MAC_BUS_MODE_PBL_Pos)               /* 0x00001000 */
#define MAC_BUS_MODE_PBL_5          (0x20UL << MAC_BUS_MODE_PBL_Pos)               /* 0x00002000 */

#define MAC_BUS_MODE_TAP_DPos       (17U)
#define MAC_BUS_MODE_TAP_Pos        MAC_BUS_MODE_TAP_DPos
#define MAC_BUS_MODE_TAP_Msk        (0x07UL << MAC_BUS_MODE_TAP_Pos)               /* 0x000E0000 */
#define MAC_BUS_MODE_TAP            MAC_BUS_MODE_TAP_Msk                           /*TAP[2:0] bits (Transmit Automatic Polling) */
#define MAC_BUS_MODE_TAP_0          (0x1UL << MAC_BUS_MODE_TAP_Pos)                /* 0x00020000 */
#define MAC_BUS_MODE_TAP_1          (0x2UL << MAC_BUS_MODE_TAP_Pos)                /* 0x00040000 */
#define MAC_BUS_MODE_TAP_2          (0x3UL << MAC_BUS_MODE_TAP_Pos)                /* 0x00080000 */

#define MAC_BUS_MODE_DBO_DPos       (20U)
#define MAC_BUS_MODE_DBO_Pos        MAC_BUS_MODE_DBO_DPos
#define MAC_BUS_MODE_DBO_Msk        (0x1UL << MAC_BUS_MODE_DBO_Pos)                /* 0x00100000 */
#define MAC_BUS_MODE_DBO            MAC_BUS_MODE_DBO_Msk                           /* Descriptor Byte Order. */

/******************  Bit definition for MAC_TX_MODE register  *******************/
#define MAC_TX_POLL_RPD_DPos        (0U)
#define MAC_TX_POLL_RPD_Pos         MAC_TX_POLL_RPD_DPos
#define MAC_TX_POLL_RPD_Msk         (0xFFFFFFFFUL << MAC_TX_POLL_RPD_Pos)          /* 0xFFFFFFFF */
#define MAC_TX_POLL_RPD             MAC_TX_POLL_RPD_Msk                            /* Send Poll Descriptor. */

/******************  Bit definition for MAC_RX_MODE register  *******************/
#define MAC_RX_POLL_RPD_DPos        (0U)
#define MAC_RX_POLL_RPD_Pos         MAC_RX_POLL_RPD_DPos
#define MAC_RX_POLL_RPD_Msk         (0xFFFFFFFFUL << MAC_RX_POLL_RPD_Pos)          /* 0xFFFFFFFF */
#define MAC_RX_POLL_RPD             MAC_RX_POLL_RPD_Msk                            /* Receive Poll Descriptor. */

/******************  Bit definition for MAC_RDES_BASE_ADDR register  *******************/
#define MAC_RDES_BASE_ADDR_RLAD_DPos       (0U)
#define MAC_RDES_BASE_ADDR_RLAD_Pos        MAC_RDES_BASE_ADDR_RLAD_DPos
#define MAC_RDES_BASE_ADDR_RLAD_Msk        (0xFFFFFFFFUL << MAC_RDES_BASE_ADDR_RLAD_Pos)   /* 0xFFFFFFFF */
#define MAC_RDES_BASE_ADDR_RLAD            MAC_RDES_BASE_ADDR_RLAD_Msk                     /* Receive List Address Start. */

/******************  Bit definition for MAC_TDES_BASE_ADDR register  *******************/
#define MAC_TDES_BASE_ADDR_RLAD_DPos       (0U)
#define MAC_TDES_BASE_ADDR_RLAD_Pos        MAC_TDES_BASE_ADDR_RLAD_DPos
#define MAC_TDES_BASE_ADDR_RLAD_Msk        (0xFFFFFFFFUL << MAC_TDES_BASE_ADDR_RLAD_Pos)   /* 0xFFFFFFFF */
#define MAC_TDES_BASE_ADDR_RLAD            MAC_TDES_BASE_ADDR_RLAD_Msk                     /* Transmit List Address Start. */

/******************  Bit definition for MAC_STATUS register  ********************/
#define MAC_STATUS_TI_DPos          (0U)
#define MAC_STATUS_TI_Pos           MAC_STATUS_TI_DPos
#define MAC_STATUS_TI_Msk           (0x1UL << MAC_STATUS_TI_Pos)                /* 0x00000001 */
#define MAC_STATUS_TI               MAC_STATUS_TI_Msk                           /* Transmit Interrupt. */

#define MAC_STATUS_TPS_DPos         (1U)
#define MAC_STATUS_TPS_Pos          MAC_STATUS_TPS_DPos
#define MAC_STATUS_TPS_Msk          (0x1UL << MAC_STATUS_TPS_Pos)               /* 0x00000002 */
#define MAC_STATUS_TPS              MAC_STATUS_TPS_Msk                          /* Transmit Process Stopped. */

#define MAC_STATUS_TU_DPos          (2U)
#define MAC_STATUS_TU_Pos           MAC_STATUS_TU_DPos
#define MAC_STATUS_TU_Msk           (0x1UL << MAC_STATUS_TU_Pos)                /* 0x00000004 */
#define MAC_STATUS_TU               MAC_STATUS_TU_Msk                           /* Transmit Buffer Unavailable. */

#define MAC_STATUS_UNF_DPos         (5U)
#define MAC_STATUS_UNF_Pos          MAC_STATUS_UNF_DPos
#define MAC_STATUS_UNF_Msk          (0x1UL << MAC_STATUS_UNF_Pos)               /* 0x00000020 */
#define MAC_STATUS_UNF              MAC_STATUS_UNF_Msk                          /* Transmit Underflow. */

#define MAC_STATUS_RI_DPos          (6U)
#define MAC_STATUS_RI_Pos           MAC_STATUS_RI_DPos
#define MAC_STATUS_RI_Msk           (0x1UL << MAC_STATUS_RI_Pos)                /* 0x00000040 */
#define MAC_STATUS_RI               MAC_STATUS_RI_Msk                           /* Receive Interrupt. */

#define MAC_STATUS_RU_DPos          (7U)
#define MAC_STATUS_RU_Pos           MAC_STATUS_RU_DPos
#define MAC_STATUS_RU_Msk           (0x1UL << MAC_STATUS_RU_Pos)                /* 0x00000080 */
#define MAC_STATUS_RU               MAC_STATUS_RU_Msk                           /* Receive Buffer Unavailable. */

#define MAC_STATUS_RPS_DPos         (8U)
#define MAC_STATUS_RPS_Pos          MAC_STATUS_RPS_DPos
#define MAC_STATUS_RPS_Msk          (0x1UL << MAC_STATUS_RPS_Pos)               /* 0x00000100 */
#define MAC_STATUS_RPS              MAC_STATUS_RPS_Msk                          /* Receive Process Stopped. */

#define MAC_STATUS_ETI_DPos         (10U)
#define MAC_STATUS_ETI_Pos          MAC_STATUS_ETI_DPos
#define MAC_STATUS_ETI_Msk          (0x1UL << MAC_STATUS_ETI_Pos)               /* 0x00000400 */
#define MAC_STATUS_ETI              MAC_STATUS_ETI_Msk                          /* Early Transmit Interrupt. */

#define MAC_STATUS_GTE_DPos         (11U)
#define MAC_STATUS_GTE_Pos          MAC_STATUS_GTE_DPos
#define MAC_STATUS_GTE_Msk          (0x1UL << MAC_STATUS_GTE_Pos)               /* 0x00000800 */
#define MAC_STATUS_GTE              MAC_STATUS_GTE_Msk                          /* General Timer Expiry. */

#define MAC_STATUS_ERI_DPos         (14U)
#define MAC_STATUS_ERI_Pos          MAC_STATUS_ERI_DPos
#define MAC_STATUS_ERI_Msk          (0x1UL << MAC_STATUS_ERI_Pos)               /* 0x00004000 */
#define MAC_STATUS_ERI              MAC_STATUS_ERI_Msk                          /* Early Receive Interrupt. */

#define MAC_STATUS_AIS_DPos         (15U)
#define MAC_STATUS_AIS_Pos          MAC_STATUS_AIS_DPos
#define MAC_STATUS_AIS_Msk          (0x1UL << MAC_STATUS_AIS_Pos)               /* 0x00008000 */
#define MAC_STATUS_AIS              MAC_STATUS_AIS_Msk                          /* Abnormal Interrupt Summary. */

#define MAC_STATUS_NIS_DPos         (16U)
#define MAC_STATUS_NIS_Pos          MAC_STATUS_NIS_DPos
#define MAC_STATUS_NIS_Msk          (0x1UL << MAC_STATUS_NIS_Pos)               /* 0x00010000 */
#define MAC_STATUS_NIS              MAC_STATUS_NIS_Msk                          /* Normal Interrupt Summary. */

#define MAC_STATUS_RS_DPos          (17U)
#define MAC_STATUS_RS_Pos           MAC_STATUS_RS_DPos
#define MAC_STATUS_RS_Msk           (0x7UL << MAC_STATUS_RS_Pos)                /* 0x000E0000 */
#define MAC_STATUS_RS               MAC_STATUS_RS_Msk                           /* RS[2:0] bits (Receive Process State) */
#define MAC_STATUS_RS_0             (0x1UL << MAC_STATUS_RS_Pos)                /* 0x00020000 */
#define MAC_STATUS_RS_1             (0x2UL << MAC_STATUS_RS_Pos)                /* 0x00040000 */
#define MAC_STATUS_RS_2             (0x4UL << MAC_STATUS_RS_Pos)                /* 0x00080000 */

#define MAC_STATUS_TS_DPos          (20U)
#define MAC_STATUS_TS_Pos           MAC_STATUS_TS_DPos
#define MAC_STATUS_TS_Msk           (0x7UL << MAC_STATUS_TS_Pos)                /* 0x00700000 */
#define MAC_STATUS_TS               MAC_STATUS_TS_Msk                           /* TS[2:0] bits (Transmit Process State) */
#define MAC_STATUS_TS_0             (0x1UL << MAC_STATUS_TS_Pos)                /* 0x00100000 */
#define MAC_STATUS_TS_1             (0x2UL << MAC_STATUS_TS_Pos)                /* 0x00200000 */
#define MAC_STATUS_TS_2             (0x4UL << MAC_STATUS_TS_Pos)                /* 0x00400000 */

/******************  Bit definition for MAC_OPT_MODE register  *******************/
#define MAC_OPT_MODE_HP_DPos       (0U)
#define MAC_OPT_MODE_HP_Pos        MAC_OPT_MODE_HP_DPos
#define MAC_OPT_MODE_HP_Msk        (0x1UL << MAC_OPT_MODE_HP_Pos)             /* 0x00000001 */
#define MAC_OPT_MODE_HP            MAC_OPT_MODE_HP_Msk                        /* Hash/Perfect Filter Mode (Read Only). */

#define MAC_OPT_MODE_SR_DPos       (1U)
#define MAC_OPT_MODE_SR_Pos        MAC_OPT_MODE_SR_DPos
#define MAC_OPT_MODE_SR_Msk        (0x1UL << MAC_OPT_MODE_SR_Pos)             /* 0x00000002 */
#define MAC_OPT_MODE_SR            MAC_OPT_MODE_SR_Msk                        /* Start/Stop Receive Command. */

#define MAC_OPT_MODE_HO_DPos       (2U)
#define MAC_OPT_MODE_HO_Pos        MAC_OPT_MODE_HO_DPos
#define MAC_OPT_MODE_HO_Msk        (0x1UL << MAC_OPT_MODE_HO_Pos)             /* 0x00000004 */
#define MAC_OPT_MODE_HO            MAC_OPT_MODE_HO_Msk                        /* Hash Only Filter Mode (Read Only). */

#define MAC_OPT_MODE_PB_DPos       (3U)
#define MAC_OPT_MODE_PB_Pos        MAC_OPT_MODE_PB_DPos
#define MAC_OPT_MODE_PB_Msk        (0x1UL << MAC_OPT_MODE_PB_Pos)             /* 0x00000008 */
#define MAC_OPT_MODE_PB            MAC_OPT_MODE_PB_Msk                        /* Pass Bad Frames. */

#define MAC_OPT_MODE_IF_DPos       (4U)
#define MAC_OPT_MODE_IF_Pos        MAC_OPT_MODE_IF_DPos
#define MAC_OPT_MODE_IF_Msk        (0x1UL << MAC_OPT_MODE_IF_Pos)             /* 0x00000010 */
#define MAC_OPT_MODE_IF            MAC_OPT_MODE_IF_Msk                        /* Inverse Filtering (Read Only). */

#define MAC_OPT_MODE_PR_DPos       (6U)
#define MAC_OPT_MODE_PR_Pos        MAC_OPT_MODE_PR_DPos
#define MAC_OPT_MODE_PR_Msk        (0x1UL << MAC_OPT_MODE_PR_Pos)             /* 0x00000040 */
#define MAC_OPT_MODE_PR            MAC_OPT_MODE_PR_Msk                        /* Promiscuous Mode. */

#define MAC_OPT_MODE_PM_DPos       (7U)
#define MAC_OPT_MODE_PM_Pos        MAC_OPT_MODE_PM_DPos
#define MAC_OPT_MODE_PM_Msk        (0x1UL << MAC_OPT_MODE_PM_Pos)             /* 0x00000080 */
#define MAC_OPT_MODE_PM            MAC_OPT_MODE_PM_Msk                        /* Pass All Multicast. */

#define MAC_OPT_MODE_FD_DPos       (9U)
#define MAC_OPT_MODE_FD_Pos        MAC_OPT_MODE_FD_DPos
#define MAC_OPT_MODE_FD_Msk        (0x1UL << MAC_OPT_MODE_FD_Pos)             /* 0x00000200 */
#define MAC_OPT_MODE_FD            MAC_OPT_MODE_FD_Msk                        /* Full Duplex Mode. */

#define MAC_OPT_MODE_ST_DPos       (13U)
#define MAC_OPT_MODE_ST_Pos        MAC_OPT_MODE_ST_DPos
#define MAC_OPT_MODE_ST_Msk        (0x1UL << MAC_OPT_MODE_ST_Pos)             /* 0x00002000 */
#define MAC_OPT_MODE_ST            MAC_OPT_MODE_ST_Msk                        /* Start/Stop Transmission Command. */

#define MAC_OPT_MODE_TR_DPos       (15U)
#define MAC_OPT_MODE_TR_Pos        MAC_OPT_MODE_TR_DPos
#define MAC_OPT_MODE_TR_Msk        (0x1UL << MAC_OPT_MODE_TR_Pos)             /* 0x00008000 */
#define MAC_OPT_MODE_TR            MAC_OPT_MODE_TR_Msk                        /* Threshold Control Bit. */

#define MAC_OPT_MODE_SF_DPos       (21U)
#define MAC_OPT_MODE_SF_Pos        MAC_OPT_MODE_SF_DPos
#define MAC_OPT_MODE_SF_Msk        (0x1UL << MAC_OPT_MODE_SF_Pos)             /* 0x00200000 */
#define MAC_OPT_MODE_SF            MAC_OPT_MODE_SF_Msk                        /* Store and Forward. */

#define MAC_OPT_MODE_TTM_DPos      (22U)
#define MAC_OPT_MODE_TTM_Pos       MAC_OPT_MODE_TTM_DPos
#define MAC_OPT_MODE_TTM_Msk       (0x1UL << MAC_OPT_MODE_TTM_Pos)            /* 0x00400000 */
#define MAC_OPT_MODE_TTM           MAC_OPT_MODE_TTM_Msk                       /* Transmit Threshold Mode. */

#define MAC_OPT_MODE_RA_DPos       (30U)
#define MAC_OPT_MODE_RA_Pos        MAC_OPT_MODE_RA_DPos
#define MAC_OPT_MODE_RA_Msk        (0x1UL << MAC_OPT_MODE_RA_Pos)             /* 0x40000000 */
#define MAC_OPT_MODE_RA            MAC_OPT_MODE_RA_Msk                        /* Receive All. */

/******************  Bit definition for MAC_INT_ENABLE register  *******************/
#define MAC_INT_ENABLE_TIE_DPos       (0U)
#define MAC_INT_ENABLE_TIE_Pos        MAC_INT_ENABLE_TIE_DPos
#define MAC_INT_ENABLE_TIE_Msk        (0x1UL << MAC_INT_ENABLE_TIE_Pos)             /* 0x00000001 */
#define MAC_INT_ENABLE_TIE            MAC_INT_ENABLE_TIE_Msk                        /* Transmit Interrupt Enable. */

#define MAC_INT_ENABLE_TSE_DPos       (1U)
#define MAC_INT_ENABLE_TSE_Pos        MAC_INT_ENABLE_TSE_DPos
#define MAC_INT_ENABLE_TSE_Msk        (0x1UL << MAC_INT_ENABLE_TSE_Pos)             /* 0x00000002 */
#define MAC_INT_ENABLE_TSE            MAC_INT_ENABLE_TSE_Msk                        /* Transmit Stop Interrupt Enable. */

#define MAC_INT_ENABLE_TUE_DPos       (2U)
#define MAC_INT_ENABLE_TUE_Pos        MAC_INT_ENABLE_TUE_DPos
#define MAC_INT_ENABLE_TUE_Msk        (0x1UL << MAC_INT_ENABLE_TUE_Pos)             /* 0x00000004 */
#define MAC_INT_ENABLE_TUE            MAC_INT_ENABLE_TUE_Msk                        /* Transmit Buffer Unavailable Interrupt Enable. */

#define MAC_INT_ENABLE_UNE_DPos       (5U)
#define MAC_INT_ENABLE_UNE_Pos        MAC_INT_ENABLE_UNE_DPos
#define MAC_INT_ENABLE_UNE_Msk        (0x1UL << MAC_INT_ENABLE_UNE_Pos)             /* 0x00000020 */
#define MAC_INT_ENABLE_UNE            MAC_INT_ENABLE_UNE_Msk                        /* Transmit Underflow Interrupt Enable. */

#define MAC_INT_ENABLE_RIE_DPos       (6U)
#define MAC_INT_ENABLE_RIE_Pos        MAC_INT_ENABLE_RIE_DPos
#define MAC_INT_ENABLE_RIE_Msk        (0x1UL << MAC_INT_ENABLE_RIE_Pos)             /* 0x00000040 */
#define MAC_INT_ENABLE_RIE            MAC_INT_ENABLE_RIE_Msk                        /* Receive Interrupt Enable. */

#define MAC_INT_ENABLE_RUE_DPos       (7U)
#define MAC_INT_ENABLE_RUE_Pos        MAC_INT_ENABLE_RUE_DPos
#define MAC_INT_ENABLE_RUE_Msk        (0x1UL << MAC_INT_ENABLE_RUE_Pos)             /* 0x00000080 */
#define MAC_INT_ENABLE_RUE            MAC_INT_ENABLE_RUE_Msk                        /* Receive Buffer Unavailable Interrupt Enable. */

#define MAC_INT_ENABLE_RSE_DPos       (8U)
#define MAC_INT_ENABLE_RSE_Pos        MAC_INT_ENABLE_RSE_DPos
#define MAC_INT_ENABLE_RSE_Msk        (0x1UL << MAC_INT_ENABLE_RSE_Pos)             /* 0x00000100 */
#define MAC_INT_ENABLE_RSE            MAC_INT_ENABLE_RSE_Msk                        /* Receive Stop Interrupt Enable. */

#define MAC_INT_ENABLE_ETE_DPos       (10U)
#define MAC_INT_ENABLE_ETE_Pos        MAC_INT_ENABLE_ETE_DPos
#define MAC_INT_ENABLE_ETE_Msk        (0x1UL << MAC_INT_ENABLE_ETE_Pos)             /* 0x00000400 */
#define MAC_INT_ENABLE_ETE            MAC_INT_ENABLE_ETE_Msk                        /* Early Transmit Interrupt Enable. */

#define MAC_INT_ENABLE_GTE_DPos       (11U)
#define MAC_INT_ENABLE_GTE_Pos        MAC_INT_ENABLE_GTE_DPos
#define MAC_INT_ENABLE_GTE_Msk        (0x1UL << MAC_INT_ENABLE_GTE_Pos)             /* 0x00000800 */
#define MAC_INT_ENABLE_GTE            MAC_INT_ENABLE_GTE_Msk                        /* General Timer Expiry Interrupt Enable. */

#define MAC_INT_ENABLE_ERE_DPos       (14U)
#define MAC_INT_ENABLE_ERE_Pos        MAC_INT_ENABLE_ERE_DPos
#define MAC_INT_ENABLE_ERE_Msk        (0x1UL << MAC_INT_ENABLE_ERE_Pos)             /* 0x00004000 */
#define MAC_INT_ENABLE_ERE            MAC_INT_ENABLE_ERE_Msk                        /* Early Receive Interrupt Enable. */

#define MAC_INT_ENABLE_AIE_DPos       (15U)
#define MAC_INT_ENABLE_AIE_Pos        MAC_INT_ENABLE_AIE_DPos
#define MAC_INT_ENABLE_AIE_Msk        (0x1UL << MAC_INT_ENABLE_AIE_Pos)             /* 0x00008000 */
#define MAC_INT_ENABLE_AIE            MAC_INT_ENABLE_AIE_Msk                        /* Abnormal Interrupt Enable. */

#define MAC_INT_ENABLE_NIE_DPos       (16U)
#define MAC_INT_ENABLE_NIE_Pos        MAC_INT_ENABLE_NIE_DPos
#define MAC_INT_ENABLE_NIE_Msk        (0x1UL << MAC_INT_ENABLE_NIE_Pos)             /* 0x00010000 */
#define MAC_INT_ENABLE_NIE            MAC_INT_ENABLE_NIE_Msk                        /* Normal Interrupt Summary Enable. */

/******************  Bit definition for MAC_FRAME_CNT register  *******************/
#define MAC_FRAME_CNT_MFC_DPos        (0U)
#define MAC_FRAME_CNT_MFC_Pos         MAC_FRAME_CNT_MFC_DPos
#define MAC_FRAME_CNT_MFC_Msk         (0xFFFFUL << MAC_FRAME_CNT_MFC_Pos)        /* 0x0000FFFF */
#define MAC_FRAME_CNT_MFC             MAC_FRAME_CNT_MFC_Msk                      /* Missed Frame Counter (Read Only). */

#define MAC_FRAME_CNT_MFO_DPos        (16U)
#define MAC_FRAME_CNT_MFO_Pos         MAC_FRAME_CNT_MFO_DPos
#define MAC_FRAME_CNT_MFO_Msk         (0x1UL << MAC_FRAME_CNT_MFO_Pos)           /* 0x00010000 */
#define MAC_FRAME_CNT_MFO             MAC_FRAME_CNT_MFO_Msk                      /* Missed Frame Overflow (Read Only). */

#define MAC_FRAME_CNT_FOC_DPos        (17U)
#define MAC_FRAME_CNT_FOC_Pos         MAC_FRAME_CNT_FOC_DPos
#define MAC_FRAME_CNT_FOC_Msk         (0x7FFUL << MAC_FRAME_CNT_FOC_Pos)         /* 0x00FFFE00 */
#define MAC_FRAME_CNT_FOC             MAC_FRAME_CNT_FOC_Msk                      /* FIFO Overflow Counter (Read Only). */

#define MAC_FRAME_CNT_OCO_DPos        (28U)
#define MAC_FRAME_CNT_OCO_Pos         MAC_FRAME_CNT_OCO_DPos
#define MAC_FRAME_CNT_OCO_Msk         (0x1UL << MAC_FRAME_CNT_OCO_Pos)           /* 0x10000000 */
#define MAC_FRAME_CNT_OCO             MAC_FRAME_CNT_OCO_Msk                      /* Overflow Counter Overflow (Read Only). */

/******************  Bit definition for MAC_MDIO_CTRL0 register  *******************/
#define MAC_MDIO_CTRL0_MDC_DIV_DPos    (0U)
#define MAC_MDIO_CTRL0_MDC_DIV_Pos     MAC_MDIO_CTRL0_MDC_DIV_DPos
#define MAC_MDIO_CTRL0_MDC_DIV_Msk     (0xFFFFUL << MAC_MDIO_CTRL0_MDC_DIV_Pos)    /* 0x0000FFFF */
#define MAC_MDIO_CTRL0_MDC_DIV         MAC_MDIO_CTRL0_MDC_DIV_Msk                  /* MDC Divider (Read/Write). */

#define MAC_MDIO_CTRL0_MDCE_DPos       (16U)
#define MAC_MDIO_CTRL0_MDCE_Pos        MAC_MDIO_CTRL0_MDCE_DPos
#define MAC_MDIO_CTRL0_MDCE_Msk        (0x1UL << MAC_MDIO_CTRL0_MDCE_Pos)          /* 0x00010000 */
#define MAC_MDIO_CTRL0_MDCE            MAC_MDIO_CTRL0_MDCE_Msk                     /* MDIO Enable (Read/Write). */

/******************  Bit definition for MAC_MDIO_CTRL1 register  *******************/
#define MAC_MDIO_CTRL1_RDATA_DPos       (0U)
#define MAC_MDIO_CTRL1_RDATA_Pos        MAC_MDIO_CTRL1_RDATA_DPos
#define MAC_MDIO_CTRL1_RDATA_Msk        (0xFFFFUL << MAC_MDIO_CTRL1_RDATA_Pos)      /* 0x0000FFFF */
#define MAC_MDIO_CTRL1_RDATA            MAC_MDIO_CTRL1_RDATA_Msk                    /* MDIO Read Data. */

#define MAC_MDIO_CTRL1_TURN_DPos        (16U)
#define MAC_MDIO_CTRL1_TURN_Pos         MAC_MDIO_CTRL1_TURN_DPos
#define MAC_MDIO_CTRL1_TURN_Msk         (0x3UL << MAC_MDIO_CTRL1_TURN_Pos)          /* 0x00030000 */
#define MAC_MDIO_CTRL1_TURN             MAC_MDIO_CTRL1_TURN_Msk                     /* TURN[1:0] bits (MDIO Turnaround Time) */
#define MAC_MDIO_CTRL1_TURN_0           (0x1UL << MAC_MDIO_CTRL1_TURN_Pos)          /* 0x00010000 */
#define MAC_MDIO_CTRL1_TURN_1           (0x2UL << MAC_MDIO_CTRL1_TURN_Pos)          /* 0x00020000 */


#define MAC_MDIO_CTRL1_REG_ADDR_DPos    (18U)
#define MAC_MDIO_CTRL1_REG_ADDR_Pos     MAC_MDIO_CTRL1_REG_ADDR_DPos
#define MAC_MDIO_CTRL1_REG_ADDR_Msk     (0x1FUL << MAC_MDIO_CTRL1_REG_ADDR_Pos)     /* 0x007C0000 */
#define MAC_MDIO_CTRL1_REG_ADDR         MAC_MDIO_CTRL1_REG_ADDR_Msk                 /* PHY Register Address. */

#define MAC_MDIO_CTRL1_PHY_ADDR_DPos    (23U)
#define MAC_MDIO_CTRL1_PHY_ADDR_Pos     MAC_MDIO_CTRL1_PHY_ADDR_DPos
#define MAC_MDIO_CTRL1_PHY_ADDR_Msk     (0x1FUL << MAC_MDIO_CTRL1_PHY_ADDR_Pos)     /* 0x0F800000 */
#define MAC_MDIO_CTRL1_PHY_ADDR         MAC_MDIO_CTRL1_PHY_ADDR_Msk                 /* PHY Address. */

#define MAC_MDIO_CTRL1_RDWR_DPos        (28U)
#define MAC_MDIO_CTRL1_RDWR_Pos         MAC_MDIO_CTRL1_RDWR_DPos
#define MAC_MDIO_CTRL1_RDWR_Msk         (0x3UL << MAC_MDIO_CTRL1_RDWR_Pos)          /* 0x30000000 */
#define MAC_MDIO_CTRL1_RDWR             MAC_MDIO_CTRL1_RDWR_Msk                     /* RDWR[1:0] bits (Read/Write Flag) */
#define MAC_MDIO_CTRL1_RDWR_0           (0x1UL << MAC_MDIO_CTRL1_RDWR_Pos)          /* 0x10000000 */
#define MAC_MDIO_CTRL1_RDWR_1           (0x2UL << MAC_MDIO_CTRL1_RDWR_Pos)          /* 0x20000000 */

#define MAC_MDIO_CTRL1_START0_DPos      (30U)
#define MAC_MDIO_CTRL1_START0_Pos       MAC_MDIO_CTRL1_START0_DPos
#define MAC_MDIO_CTRL1_START0_Msk       (0x1UL << MAC_MDIO_CTRL1_START0_Pos)        /* 0x40000000 */
#define MAC_MDIO_CTRL1_START0           MAC_MDIO_CTRL1_START0_Msk                   /* Start bit 0. */

#define MAC_MDIO_CTRL1_ACK_DPos         (31U)
#define MAC_MDIO_CTRL1_ACK_Pos          MAC_MDIO_CTRL1_ACK_DPos
#define MAC_MDIO_CTRL1_ACK_Msk          (0x1UL << MAC_MDIO_CTRL1_ACK_Pos)           /* 0x80000000 */
#define MAC_MDIO_CTRL1_ACK              MAC_MDIO_CTRL1_ACK_Msk                      /* Acknowledge Signal. */

#define MAC_MDIO_CTRL1_START1_DPos      (31U)
#define MAC_MDIO_CTRL1_START1_Pos       MAC_MDIO_CTRL1_START1_DPos
#define MAC_MDIO_CTRL1_START1_Msk       (0x1UL << MAC_MDIO_CTRL1_START1_Pos)        /* 0x80000000 */
#define MAC_MDIO_CTRL1_START1           MAC_MDIO_CTRL1_START1_Msk                   /* Start bit 1. */

/******************  Bit definition for MAC_TIMER_CTRL register  *******************/
#define MAC_TIMER_CTRL_TIM_DPos         (0U)
#define MAC_TIMER_CTRL_TIM_Pos          MAC_TIMER_CTRL_TIM_DPos
#define MAC_TIMER_CTRL_TIM_Msk          (0xFFFFUL << MAC_TIMER_CTRL_TIM_Pos)         /* 0x0000FFFF */
#define MAC_TIMER_CTRL_TIM              MAC_TIMER_CTRL_TIM_Msk                       /* TIM[15:0] bits (Timer Value) */

#define MAC_TIMER_CTRL_CON_DPos         (16U)
#define MAC_TIMER_CTRL_CON_Pos          MAC_TIMER_CTRL_CON_DPos
#define MAC_TIMER_CTRL_CON_Msk          (0x1UL << MAC_TIMER_CTRL_CON_Pos)            /* 0x00010000 */
#define MAC_TIMER_CTRL_CON              MAC_TIMER_CTRL_CON_Msk                       /* Continuous Mode. */

#define MAC_TIMER_CTRL_NRP_DPos         (17U)
#define MAC_TIMER_CTRL_NRP_Pos          MAC_TIMER_CTRL_NRP_DPos
#define MAC_TIMER_CTRL_NRP_Msk          (0x7UL << MAC_TIMER_CTRL_NRP_Pos)            /* 0x000E0000 */
#define MAC_TIMER_CTRL_NRP              MAC_TIMER_CTRL_NRP_Msk                       /* NRP[2:0] bits (Number of Received Packets) */
#define MAC_TIMER_CTRL_NRP_0            (0x1UL << MAC_TIMER_CTRL_NRP_Pos)            /* 0x00020000 */
#define MAC_TIMER_CTRL_NRP_1            (0x2UL << MAC_TIMER_CTRL_NRP_Pos)            /* 0x00040000 */
#define MAC_TIMER_CTRL_NRP_2            (0x4UL << MAC_TIMER_CTRL_NRP_Pos)            /* 0x00080000 */

#define MAC_TIMER_CTRL_RT_DPos          (20U)
#define MAC_TIMER_CTRL_RT_Pos           MAC_TIMER_CTRL_RT_DPos
#define MAC_TIMER_CTRL_RT_Msk           (0xFUL << MAC_TIMER_CTRL_RT_Pos)             /* 0x00F00000 */
#define MAC_TIMER_CTRL_RT               MAC_TIMER_CTRL_RT_Msk                        /* RT[3:0] bits (Receive Timer) */
#define MAC_TIMER_CTRL_RT_0             (0x1UL << MAC_TIMER_CTRL_RT_Pos)             /* 0x00100000 */
#define MAC_TIMER_CTRL_RT_1             (0x2UL << MAC_TIMER_CTRL_RT_Pos)             /* 0x00200000 */
#define MAC_TIMER_CTRL_RT_2             (0x4UL << MAC_TIMER_CTRL_RT_Pos)             /* 0x00400000 */
#define MAC_TIMER_CTRL_RT_3             (0x8UL << MAC_TIMER_CTRL_RT_Pos)             /* 0x00800000 */

#define MAC_TIMER_CTRL_NTP_DPos         (24U)
#define MAC_TIMER_CTRL_NTP_Pos          MAC_TIMER_CTRL_NTP_DPos
#define MAC_TIMER_CTRL_NTP_Msk          (0x7UL << MAC_TIMER_CTRL_NTP_Pos)            /* 0x07000000 */
#define MAC_TIMER_CTRL_NTP              MAC_TIMER_CTRL_NTP_Msk                       /* NTP[2:0] bits (Number of Transmitted Packets) */
#define MAC_TIMER_CTRL_NTP_0            (0x1UL << MAC_TIMER_CTRL_NTP_Pos)            /* 0x01000000 */
#define MAC_TIMER_CTRL_NTP_1            (0x2UL << MAC_TIMER_CTRL_NTP_Pos)            /* 0x02000000 */
#define MAC_TIMER_CTRL_NTP_2            (0x4UL << MAC_TIMER_CTRL_NTP_Pos)            /* 0x04000000 */

#define MAC_TIMER_CTRL_TT_DPos          (27U)
#define MAC_TIMER_CTRL_TT_Pos           MAC_TIMER_CTRL_TT_DPos
#define MAC_TIMER_CTRL_TT_Msk           (0xFUL << MAC_TIMER_CTRL_TT_Pos)             /* 0x78000000 */
#define MAC_TIMER_CTRL_TT               MAC_TIMER_CTRL_TT_Msk                        /* TT[3:0] bits (Transmit Timer) */
#define MAC_TIMER_CTRL_TT_0             (0x1UL << MAC_TIMER_CTRL_TT_Pos)             /* 0x08000000 */
#define MAC_TIMER_CTRL_TT_1             (0x2UL << MAC_TIMER_CTRL_TT_Pos)             /* 0x10000000 */
#define MAC_TIMER_CTRL_TT_2             (0x4UL << MAC_TIMER_CTRL_TT_Pos)             /* 0x20000000 */
#define MAC_TIMER_CTRL_TT_3             (0x8UL << MAC_TIMER_CTRL_TT_Pos)             /* 0x40000000 */

#define MAC_TIMER_CTRL_CS_DPos          (31U)
#define MAC_TIMER_CTRL_CS_Pos           MAC_TIMER_CTRL_CS_DPos
#define MAC_TIMER_CTRL_CS_Msk           (0x1UL << MAC_TIMER_CTRL_CS_Pos)             /* 0x80000000 */
#define MAC_TIMER_CTRL_CS               MAC_TIMER_CTRL_CS_Msk                        /* Cycle Size. */

/* @name SPI register bits definition */
/******************  Bits definition for SPI_CR0 register  *****************/
#define SPI_CR0_ENABLE_DPos         (0U)
#define SPI_CR0_SPE_Pos             SPI_CR0_ENABLE_DPos
#define SPI_CR0_SPE_Msk             (0x01UL << SPI_CR0_SPE_Pos)             /* 0x00000001 */
#define SPI_CR0_SPE                 SPI_CR0_SPE_Msk                         /* Enable SPI */

#define SPI_CR0_MASTER_DPos         (1U)
#define SPI_CR0_MSTR_Pos            SPI_CR0_MASTER_DPos
#define SPI_CR0_MSTR_Msk            (0x01UL << SPI_CR0_MSTR_Pos)            /* 0x00000002 */
#define SPI_CR0_MSTR                SPI_CR0_MSTR_Msk                        /* Select the master/slave mode */

#define SPI_CR0_INTTXDONE_DPos      (3U)
#define SPI_CR0_TDIE_Pos            SPI_CR0_INTTXDONE_DPos
#define SPI_CR0_TDIE_Msk            (0x01UL << SPI_CR0_TDIE_Pos)            /* 0x00000004 */
#define SPI_CR0_TDIE                SPI_CR0_TDIE_Msk                        /* Tx done interrup enable */

#define SPI_CR0_INTRXOVFLOW_DPos    (4U)
#define SPI_CR0_RXOIE_Pos           SPI_CR0_INTRXOVFLOW_DPos
#define SPI_CR0_RXOIE_Msk           (0x01UL << SPI_CR0_RXOIE_Pos)           /* 0x00000008 */
#define SPI_CR0_RXOIE               SPI_CR0_RXOIE_Msk                       /* Rx buffer overflow interrupt enable */

#define SPI_CR0_INTTXURUN_DPos      (5U)
#define SPI_CR0_TXEIE_Pos           SPI_CR0_INTTXURUN_DPos
#define SPI_CR0_TXEIE_Msk           (0x01UL << SPI_CR0_TXEIE_Pos)           /* 0x00000010 */
#define SPI_CR0_TXEIE               SPI_CR0_TXEIE_Msk                       /* Tx buffer empty interrupt enable */


/******************  Bits definition for SPI_IFCR register  *****************/
#define SPI_IFCR_TXDONE_DPos        (0U)
#define SPI_IFCR_TDC_Pos            SPI_IFCR_TXDONE_DPos
#define SPI_IFCR_TDC_Msk            (0x01UL << SPI_IFCR_TDC_Pos)            /* 0x00000001 */
#define SPI_IFCR_TDC                SPI_IFCR_TDC_Msk                        /* Tx done interrup clear */

#define SPI_IFCR_RXOVERFLOW_DPos    (2U)
#define SPI_IFCR_RXOC_Pos           SPI_IFCR_RXOVERFLOW_DPos
#define SPI_IFCR_RXOC_Msk           (0x01UL << SPI_IFCR_RXOC_Pos)           /* 0x00000004 */
#define SPI_IFCR_RXOC               SPI_IFCR_RXOC_Msk                       /* Rx buffer overflow interrupt clear */

#define SPI_IFCR_TXUNDERRUN_DPos    (3U)
#define SPI_IFCR_TXEC_Pos           SPI_IFCR_TXUNDERRUN_DPos
#define SPI_IFCR_TXEC_Msk           (0x01UL << SPI_IFCR_TXEC_Pos)           /* 0x00000008 */
#define SPI_IFCR_TXEC               SPI_IFCR_TXEC_Msk                       /* Tx buffer empty interrupt clear */

#define SPI_IFCR_SSLOW_DPos         (5U)
#define SPI_IFCR_NSSVC_Pos          SPI_IFCR_SSLOW_DPos
#define SPI_IFCR_NSSVC_Msk          (0x01UL << SPI_IFCR_NSSVC_Pos)          /* 0x00000020 */
#define SPI_IFCR_NSSVC              SPI_IFCR_NSSVC_Msk                      /* NSS Voh interrupt clear */

#define SPI_IFCR_RXFFNF_DPos        (6U)
#define SPI_IFCR_RXNEC_Pos          SPI_IFCR_RXFFNF_DPos
#define SPI_IFCR_RXNEC_Msk          (0x01UL << SPI_IFCR_RXNEC_Pos)          /* 0x00000040 */
#define SPI_IFCR_RXNEC              SPI_IFCR_RXNEC_Msk                      /* Rx buffer non-empty interrupt clear */

#define SPI_IFCR_TXFFNF_DPos        (7U)
#define SPI_IFCR_TXNFC_Pos          SPI_IFCR_TXFFNF_DPos
#define SPI_IFCR_TXNFC_Msk          (0x01UL << SPI_IFCR_TXNFC_Pos)          /* 0x00000080 */
#define SPI_IFCR_TXNFC              SPI_IFCR_TXNFC_Msk                      /* Tx buffer non-full interrupt clear */


/******************  Bits definition for SPI_RXDR register  *****************/
#define SPI_RXDR_RXDATA_DPos        (0U)
#define SPI_RXDR_RXDR_Pos           SPI_RXDR_RXDATA_DPos
#define SPI_RXDR_RXDR_Msk           (0xFFFFFFFFUL << SPI_RXDR_RXDR_Pos)     /* 0xFFFFFFFF */
#define SPI_RXDR_RXDR               SPI_RXDR_RXDR_Msk                       /* RXDONE[31:0] bits (Receive data) */


/******************  Bits definition for SPI_TXDR register  *****************/
#define SPI_TXDR_TXDATA_DPos        (0U)
#define SPI_TXDR_TXDR_Pos           SPI_TXDR_TXDATA_DPos
#define SPI_TXDR_TXDR_Msk           (0xFFFFFFFFUL << SPI_TXDR_TXDR_Pos)     /* 0xFFFFFFFF */
#define SPI_TXDR_TXDR               SPI_TXDR_TXDR_Msk                       /* TXDATA[31:0] bits (Transmit data) */


/******************  Bits definition for SPI_ISR register  *****************/
#define SPI_ISR_TXDONE_DPos         (0U)
#define SPI_ISR_TDIS_Pos            SPI_ISR_TXDONE_DPos
#define SPI_ISR_TDIS_Msk            (0x01UL << SPI_ISR_TDIS_Pos)            /* 0x00000001 */
#define SPI_ISR_TDIS                SPI_ISR_TDIS_Msk                        /* The last frame has been sent */

#define SPI_ISR_RXOVERFLOW_DPos     (2U)
#define SPI_ISR_RXOIS_Pos           SPI_ISR_RXOVERFLOW_DPos
#define SPI_ISR_RXOIS_Msk           (0x01UL << SPI_ISR_RXOIS_Pos)           /* 0x00000004 */
#define SPI_ISR_RXOIS               SPI_ISR_RXOIS_Msk                       /* Receive buffer data overflow */

#define SPI_ISR_TXUNDERRUN_DPos     (3U)
#define SPI_ISR_TXEIS_Pos           SPI_ISR_TXUNDERRUN_DPos
#define SPI_ISR_TXEIS_Msk           (0x01UL << SPI_ISR_TXEIS_Pos)           /* 0x00000008 */
#define SPI_ISR_TXEIS               SPI_ISR_TXEIS_Msk                       /* Data in the send buffer is not available */

#define SPI_ISR_SSLOW_DPos          (5U)
#define SPI_ISR_NSSVIS_Pos          SPI_ISR_SSLOW_DPos
#define SPI_ISR_NSSVIS_Msk          (0x01UL << SPI_ISR_NSSVIS_Pos)          /* 0x00000020 */
#define SPI_ISR_NSSVIS              SPI_ISR_NSSVIS_Msk                      /* The chip selection signal is low interrupt */

#define SPI_ISR_RXFFNE_DPos         (6U)
#define SPI_ISR_RXNEIS_Pos          SPI_ISR_RXFFNE_DPos
#define SPI_ISR_RXNEIS_Msk          (0x01UL << SPI_ISR_RXNEIS_Pos)          /* 0x00000040 */
#define SPI_ISR_RXNEIS              SPI_ISR_RXNEIS_Msk                      /* Rx buffer non-empty interrupt */

#define SPI_ISR_TXFFNF_DPos         (7U)
#define SPI_ISR_TXNFIS_Pos          SPI_ISR_TXFFNF_DPos
#define SPI_ISR_TXNFIS_Msk          (0x01UL << SPI_ISR_TXNFIS_Pos)          /* 0x00000080 */
#define SPI_ISR_TXNFIS              SPI_ISR_TXNFIS_Msk                      /* Tx buffer non-full interrupt */


/******************  Bits definition for SPI_IRSR register  *****************/
#define SPI_IRSR_TXDONE_DPos        (0U)
#define SPI_IRSR_TDIRS_Pos          SPI_IRSR_TXDONE_DPos
#define SPI_IRSR_TDIRS_Msk          (0x01UL << SPI_IRSR_TDIRS_Pos)          /* 0x00000001 */
#define SPI_IRSR_TDIRS              SPI_IRSR_TDIRS_Msk                      /* Tx done interrupt raw status */

#define SPI_IRSR_RXOVERFLOW_DPos    (2U)
#define SPI_IRSR_RXOIRS_Pos         SPI_IRSR_RXOVERFLOW_DPos
#define SPI_IRSR_RXOIRS_Msk         (0x01UL << SPI_IRSR_RXOIRS_Pos)         /* 0x00000004 */
#define SPI_IRSR_RXOIRS             SPI_IRSR_RXOIRS_Msk                     /* Rx buffer overflow interrupt raw status */

#define SPI_IRSR_TXUNDERRUN_DPos    (3U)
#define SPI_IRSR_TXEIRS_Pos         SPI_IRSR_TXUNDERRUN_DPos
#define SPI_IRSR_TXEIRS_Msk         (0x01UL << SPI_IRSR_TXEIRS_Pos)         /* 0x00000008 */
#define SPI_IRSR_TXEIRS             SPI_IRSR_TXEIRS_Msk                     /* Tx buffer empty interrupt raw status */

#define SPI_IRSR_SSLOW_DPos         (5U)
#define SPI_IRSR_NSSVIRS_Pos        SPI_IRSR_SSLOW_DPos
#define SPI_IRSR_NSSVIRS_Msk        (0x01UL << SPI_IRSR_NSSVIRS_Pos)        /* 0x00000020 */
#define SPI_IRSR_NSSVIRS            SPI_IRSR_NSSVIRS_Msk                    /* NSS Voh interrupt raw status */

#define SPI_IRSR_RXFFNE_DPos        (6U)
#define SPI_IRSR_RXNEIRS_Pos        SPI_IRSR_RXFFNE_DPos
#define SPI_IRSR_RXNEIRS_Msk        (0x01UL << SPI_IRSR_RXNEIRS_Pos)        /* 0x00000040 */
#define SPI_IRSR_RXNEIRS            SPI_IRSR_RXNEIRS_Msk                    /* Rx buffer non-empty interrupt raw status */

#define SPI_IRSR_TXFFNF_DPos        (7U)
#define SPI_IRSR_TXNFIRS_Pos        SPI_IRSR_TXFFNF_DPos
#define SPI_IRSR_TXNFIRS_Msk        (0x01UL << SPI_IRSR_TXNFIRS_Pos)        /* 0x00000080 */
#define SPI_IRSR_TXNFIRS            SPI_IRSR_TXNFIRS_Msk                    /* Tx buffer non-full interrupt raw status */


/******************  Bits definition for SPI_IER register  *****************/
#define SPI_IER_SSLOW_DPos          (5U)
#define SPI_IER_NSSVIE_Pos          SPI_IER_SSLOW_DPos
#define SPI_IER_NSSVIE_Msk          (0x01UL << SPI_IER_NSSVIE_Pos)          /* 0x00000020 */
#define SPI_IER_NSSVIE              SPI_IER_NSSVIE_Msk                      /* NSS Voh interrupt enable */

#define SPI_IER_RXFFNE_DPos         (6U)
#define SPI_IER_RXNEIE_Pos          SPI_IER_RXFFNE_DPos
#define SPI_IER_RXNEIE_Msk          (0x01UL << SPI_IER_RXNEIE_Pos)          /* 0x00000040 */
#define SPI_IER_RXNEIE              SPI_IER_RXNEIE_Msk                      /* Rx buffer non-empty interrupt enable */

#define SPI_IER_TXFFNF_DPos         (7U)
#define SPI_IER_TXNEIE_Pos          SPI_IER_TXFFNF_DPos
#define SPI_IER_TXNEIE_Msk          (0x01UL << SPI_IER_TXNEIE_Pos)          /* 0x00000080 */
#define SPI_IER_TXNEIE              SPI_IER_TXNEIE_Msk                      /* Tx buffer non-full interrupt enable */


/******************  Bits definition for SPI_CR1 register  *****************/
#define SPI_CR1_RXFIFORST_DPos      (0U)
#define SPI_CR1_RXRE_Pos            SPI_CR1_RXFIFORST_DPos
#define SPI_CR1_RXRE_Msk            (0x01UL << SPI_CR1_RXRE_Pos)            /* 0x00000001 */
#define SPI_CR1_RXRE                SPI_CR1_RXRE_Msk                        /* Reset receive buffer */

#define SPI_CR1_TXFIFORST_DPos      (1U)
#define SPI_CR1_TXRE_Pos            SPI_CR1_TXFIFORST_DPos
#define SPI_CR1_TXRE_Msk            (0x01UL << SPI_CR1_TXRE_Pos)            /* 0x00000002 */
#define SPI_CR1_TXRE                SPI_CR1_TXRE_Msk                        /* Reset transmit buffer */


/******************  Bits definition for SPI_SR register  *****************/
#define SPI_SR_FIRSTFRAME_DPos      (0U)
#define SPI_SR_NFRX_Pos             SPI_SR_FIRSTFRAME_DPos
#define SPI_SR_NFRX_Msk             (0x01UL << SPI_SR_NFRX_Pos)             /* 0x00000001 */
#define SPI_SR_NFRX                 SPI_SR_NFRX_Msk                         /* NSS is effective, the next frame in the receiving buffer is received for the first time */

#define SPI_SR_DONE_DPos            (1U)
#define SPI_SR_DONE_Pos             SPI_SR_DONE_DPos
#define SPI_SR_DONE_Msk             (0x01UL << SPI_SR_DONE_Pos)             /* 0x00000002 */
#define SPI_SR_DONE                 SPI_SR_DONE_Msk                         /* No request for receiving and sending */

#define SPI_SR_RXEMPTY_DPos         (2U)
#define SPI_SR_RXE_Pos              SPI_SR_RXEMPTY_DPos
#define SPI_SR_RXE_Msk              (0x01UL << SPI_SR_RXE_Pos)              /* 0x00000004 */
#define SPI_SR_RXE                  SPI_SR_RXE_Msk                          /* Rx buffer is empty */

#define SPI_SR_TXFULL_DPos          (3U)
#define SPI_SR_TXF_Pos              SPI_SR_TXFULL_DPos
#define SPI_SR_TXF_Msk              (0x01UL << SPI_SR_TXF_Pos)              /* 0x00000008 */
#define SPI_SR_TXF                  SPI_SR_TXF_Msk                          /* Tx buffer is full */

#define SPI_SR_RXOVFLOW_DPos        (4U)
#define SPI_SR_RXO_Pos              SPI_SR_RXOVFLOW_DPos
#define SPI_SR_RXO_Msk              (0x01UL << SPI_SR_RXO_Pos)              /* 0x00000010 */
#define SPI_SR_RXO                  SPI_SR_RXO_Msk                          /* Rx buffer is overflow */

#define SPI_SR_TXUNDERRUN_DPos      (5U)
#define SPI_SR_TXE_Pos              SPI_SR_TXUNDERRUN_DPos
#define SPI_SR_TXE_Msk              (0x01UL << SPI_SR_TXE_Pos)              /* 0x00000020 */
#define SPI_SR_TXE                  SPI_SR_TXE_Msk                          /* Tx buffer is empty */

#define SPI_SR_SSEL_DPos            (6U)
#define SPI_SR_NSSS_Pos             SPI_SR_SSEL_DPos
#define SPI_SR_NSSS_Msk             (0x01UL << SPI_SR_NSSS_Pos)             /* 0x00000040 */
#define SPI_SR_NSSS                 SPI_SR_NSSS_Msk                         /* The state of select slave */

#define SPI_SR_ACTIVE_DPos          (7U)
#define SPI_SR_BUSS_Pos             SPI_SR_ACTIVE_DPos
#define SPI_SR_BUSS_Msk             (0x01UL << SPI_SR_BUSS_Pos)             /* 0x00000080 */
#define SPI_SR_BUSS                 SPI_SR_BUSS_Msk                         /* SPI is still transmitting data */


/******************  Bits definition for SPI_SSR register  *****************/
#define SPI_SSR_SSEL_DPos           (0U)
#define SPI_SSR_SSR_Pos             SPI_SSR_SSEL_DPos
#define SPI_SSR_SSR_Msk             (0xFFUL << SPI_SSR_SSR_Pos)             /* 0x000000FF */
#define SPI_SSR_SSR                 SPI_SSR_SSR_Msk                         /* SSEL[7:0] bits (Slave selection) */


/******************  Bits definition for SPI_TXEDR register  *****************/
#define SPI_TXEDR_TXDATA_LAST_DPos  (0U)
#define SPI_TXEDR_TXEDR_Pos         SPI_TXEDR_TXDATA_LAST_DPos
#define SPI_TXEDR_TXEDR_Msk         (0xFFFFFFFFUL << SPI_TXEDR_TXEDR_Pos)   /* 0xFFFFFFFF */
#define SPI_TXEDR_TXEDR             SPI_TXEDR_TXEDR_Msk                     /* TXDATA_LAST[31:0] bits (Transmitter last frame) */


/******************  Bits definition for SPI_CLKCR register  *****************/
#define SPI_CLKCR_CFG_CLK_DPos      (0U)
#define SPI_CLKCR_CLKCR_Pos         SPI_CLKCR_CFG_CLK_DPos
#define SPI_CLKCR_CLKCR_Msk         (0xFFUL << SPI_CLKCR_CLKCR_Pos)         /* 0x000000FF */
#define SPI_CLKCR_CLKCR             SPI_CLKCR_CLKCR_Msk                     /* CFG_CLK[7:0] bits (Frequency divider) */


/******************  Bits definition for SPI_CFG register  *****************/
#define SPI_CFG_MOT_MODE_DPos       (2U)
#define SPI_CFG_MOTMODESEL_Pos      SPI_CFG_MOT_MODE_DPos
#define SPI_CFG_MOTMODESEL_Msk      (0x03UL << SPI_CFG_MOTMODESEL_Pos)      /* 0x00000006 */
#define SPI_CFG_MOTMODESEL          SPI_CFG_MOTMODESEL_Msk                  /* MOT_MODE[1:0] bits (Motorola mode selection) */

#define SPI_CFG_SSEL_DPos           (4U)
#define SPI_CFG_TRANSMODE_Pos       SPI_CFG_SSEL_DPos
#define SPI_CFG_TRANSMODE_Msk       (0x01UL << SPI_CFG_TRANSMODE_Pos)       /* 0x00000010 */
#define SPI_CFG_TRANSMODE           SPI_CFG_TRANSMODE_Msk                   /* Transmission mode */

#define SPI_CFG_FRAME_SIZE_DPos     (10U)
#define SPI_CFG_FS_Pos              SPI_CFG_FRAME_SIZE_DPos
#define SPI_CFG_FS_Msk              (0x3FUL << SPI_CFG_FS_Pos)              /* 0x0000FC00 */
#define SPI_CFG_FS                  SPI_CFG_FS_Msk                          /* FRAME_SIZE[6:0] bits (SPI frame size) */

/* @name I2C register bits definition */
/*******************  Bit definition for I2C_CTLR register  *******************/
#define I2C_CTRL_IICLK_DPos                 (0U)
#define I2C_CTRL_CLK_Pos                    I2C_CTRL_IICLK_DPos
#define I2C_CTRL_CLK_Msk                    (0x83UL << I2C_CTRL_CLK_Pos)              /* 0x00000083 */
#define I2C_CTRL_CLK                        I2C_CTRL_CLK_Msk                          /* II[2:0] bits (Serial clock rate) */
#define I2C_CTRL_CLK_0                      (0x1UL << I2C_CTRL_CLK_Pos)               /* 0x00000001 */
#define I2C_CTRL_CLK_1                      (0x2UL << I2C_CTRL_CLK_Pos)               /* 0x00000002 */
#define I2C_CTRL_CLK_2                      (0x80UL << I2C_CTRL_CLK_Pos)              /* 0x00000080 */


#define I2C_CTRL_IICAA_DPos                 (2U)
#define I2C_CTRL_AA_Pos                     I2C_CTRL_IICAA_DPos
#define I2C_CTRL_AA_Msk                     (0x1UL << I2C_CTRL_AA_Pos)                /* 0x00000004 */
#define I2C_CTRL_AA                         I2C_CTRL_AA_Msk                           /* The Assert Acknowledge flag */


#define I2C_CTRL_IICI_DPos                  (3U)
#define I2C_CTRL_INT_Pos                    I2C_CTRL_IICI_DPos
#define I2C_CTRL_INT_Msk                    (0x1UL << I2C_CTRL_INT_Pos)               /* 0x00000008 */
#define I2C_CTRL_INT                        I2C_CTRL_INT_Msk                          /* The Serial Interrupt flag */

#define I2C_CTRL_IICSTO_DPos                (4U)
#define I2C_CTRL_STO_Pos                    I2C_CTRL_IICSTO_DPos
#define I2C_CTRL_STO_Msk                    (0x1UL << I2C_CTRL_STO_Pos)               /* 0x00000010 */
#define I2C_CTRL_STO                        I2C_CTRL_STO_Msk                          /* The STOP flag */

#define I2C_CTRL_IICSTA_DPos                (5U)
#define I2C_CTRL_IICSTA_Pos                 I2C_CTRL_IICSTA_DPos
#define I2C_CTRL_STA_Pos                    I2C_CTRL_IICSTA_DPos
#define I2C_CTRL_IICSTA_Msk                 (0x1UL << I2C_CTRL_IICSTA_Pos)            /* 0x00000020 */
#define I2C_CTRL_IICSTA                     I2C_CTRL_IICSTA_Msk                       /* The START flag */

#define I2C_CTRL_IICEN_DPos                 (6U)
#define I2C_CTRL_EN_Pos                     I2C_CTRL_IICEN_DPos
#define I2C_CTRL_EN_Msk                     (0x1UL << I2C_CTRL_EN_Pos)                /* 0x00000040 */
#define I2C_CTRL_EN                         I2C_CTRL_EN_Msk                           /* Enable bit */

/*******************  Bit definition for I2C_STAT register  *******************/
#define I2C_STAT_RXNE_DPos                  (0U)
#define I2C_STAT_RXNE_Pos                   I2C_STAT_RXNE_DPos
#define I2C_STAT_RXNE_Msk                   (0x1UL << I2C_STAT_RXNE_Pos)           /* 0x00000001 */
#define I2C_STAT_RXNE                       I2C_STAT_RXNE_Msk                      /* Receive idle status */

#define I2C_STAT_TXE_DPos                   (1U)
#define I2C_STAT_TXE_Pos                    I2C_STAT_TXE_DPos
#define I2C_STAT_TXE_Msk                    (0x1UL << I2C_STAT_TXE_Pos)            /* 0x00000002 */
#define I2C_STAT_TXE                        I2C_STAT_TXE_Msk                       /* Send idle status */


#define I2C_STAT_ERR_DPos                   (2U)
#define I2C_STAT_ERR_Pos                    I2C_STAT_ERR_DPos
#define I2C_STAT_ERR_Msk                    (0x1UL << I2C_STAT_ERR_Pos)            /* 0x00000004 */
#define I2C_STAT_ERR                        I2C_STAT_ERR_Msk                       /* Transmission TERRor status */

#define I2C_STAT_STATE_DPos                 (3U)
#define I2C_STAT_STATE_Pos                  I2C_STAT_STATE_DPos
#define I2C_STAT_STATE_Msk                  (0x1FUL << I2C_STAT_STATE_Pos)         /* 0x000000F8 */
#define I2C_STAT_STATE                      I2C_STAT_STATE_Msk                     /* STATE[4:0] bits (running state) */
#define I2C_STAT_STATE_0                    (0x1UL << I2C_STAT_STATE_Pos)          /* 0x00000008 */
#define I2C_STAT_STATE_1                    (0x2UL << I2C_STAT_STATE_Pos)          /* 0x00000010 */
#define I2C_STAT_STATE_2                    (0x4UL << I2C_STAT_STATE_Pos)          /* 0x00000020 */
#define I2C_STAT_STATE_3                    (0x8UL << I2C_STAT_STATE_Pos)          /* 0x00000040 */
#define I2C_STAT_STATE_4                    (0x10UL << I2C_STAT_STATE_Pos)         /* 0x00000080 */

/*******************  Bit definition for I2C_DATA register  *******************/
#define I2C_DATA_DATA_DPos                  (0U)
#define I2C_DATA_DATA_Pos                   I2C_DATA_DATA_DPos
#define I2C_DATA_DATA_Msk                   (0xFFUL << I2C_DATA_DATA_Pos)          /* 0x000000FF */
#define I2C_DATA_DATA                       I2C_DATA_DATA_Msk                      /* DATA[7:0] bits (Serial data) */
#define I2C_DATA_DATA_0                     (0x1UL << I2C_DATA_DATA_Pos)           /* 0x00000001 */
#define I2C_DATA_DATA_1                     (0x2UL << I2C_DATA_DATA_Pos)           /* 0x00000002 */
#define I2C_DATA_DATA_2                     (0x4UL << I2C_DATA_DATA_Pos)           /* 0x00000004 */
#define I2C_DATA_DATA_3                     (0x8UL << I2C_DATA_DATA_Pos)           /* 0x00000008 */
#define I2C_DATA_DATA_4                     (0x10UL << I2C_DATA_DATA_Pos)          /* 0x00000010 */
#define I2C_DATA_DATA_5                     (0x20UL << I2C_DATA_DATA_Pos)          /* 0x00000020 */
#define I2C_DATA_DATA_6                     (0x40UL << I2C_DATA_DATA_Pos)          /* 0x00000040 */
#define I2C_DATA_DATA_7                     (0x80UL << I2C_DATA_DATA_Pos)          /* 0x00000080 */

/*******************  Bit definition for I2C_ADDR register  *******************/
#define I2C_ADDR_ADDR_DPos                  (1U)
#define I2C_ADDR_ADDR_Pos                   I2C_ADDR_ADDR_DPos
#define I2C_ADDR_ADDR_Msk                   (0x7FUL << I2C_ADDR_ADDR_Pos)          /* 0x000000FE */
#define I2C_ADDR_ADDR                       I2C_ADDR_ADDR_Msk                      /* ADDR[6:0] bits (Slave Address) */
#define I2C_ADDR_ADDR_0                     (0x1UL << I2C_ADDR_ADDR_Pos)           /* 0x00000002 */
#define I2C_ADDR_ADDR_1                     (0x2UL << I2C_ADDR_ADDR_Pos)           /* 0x00000004 */
#define I2C_ADDR_ADDR_2                     (0x4UL << I2C_ADDR_ADDR_Pos)           /* 0x00000008 */
#define I2C_ADDR_ADDR_3                     (0x8UL << I2C_ADDR_ADDR_Pos)           /* 0x00000010 */
#define I2C_ADDR_ADDR_4                     (0x10UL << I2C_ADDR_ADDR_Pos)          /* 0x00000020 */
#define I2C_ADDR_ADDR_5                     (0x20UL << I2C_ADDR_ADDR_Pos)          /* 0x00000040 */
#define I2C_ADDR_ADDR_6                     (0x40UL << I2C_ADDR_ADDR_Pos)          /* 0x00000080 */

/******************  Bit definition for I2C_DIV_L register  *******************/
#define I2C_DIV_L_DIV_DPos                  (0U)
#define I2C_DIV_L_DIV_Pos                   I2C_DIV_L_DIV_DPos
#define I2C_DIV_L_DIV_Msk                   (0xFFUL << I2C_DIV_L_DIV_Pos)          /* 0x000000FF */
#define I2C_DIV_L_DIV                       I2C_DIV_L_DIV_Msk                      /* DIV[7:0] bits (division factor) */
#define I2C_DIV_L_DIV_0                     (0x1UL << I2C_DIV_L_DIV_Pos)           /* 0x00000001 */
#define I2C_DIV_L_DIV_1                     (0x2UL << I2C_DIV_L_DIV_Pos)           /* 0x00000002 */
#define I2C_DIV_L_DIV_2                     (0x4UL << I2C_DIV_L_DIV_Pos)           /* 0x00000004 */
#define I2C_DIV_L_DIV_3                     (0x8UL << I2C_DIV_L_DIV_Pos)           /* 0x00000008 */
#define I2C_DIV_L_DIV_4                     (0x10UL << I2C_DIV_L_DIV_Pos)          /* 0x00000010 */
#define I2C_DIV_L_DIV_5                     (0x20UL << I2C_DIV_L_DIV_Pos)          /* 0x00000020 */
#define I2C_DIV_L_DIV_6                     (0x40UL << I2C_DIV_L_DIV_Pos)          /* 0x00000040 */
#define I2C_DIV_L_DIV_7                     (0x80UL << I2C_DIV_L_DIV_Pos)          /* 0x00000080 */

/*******************  Bit definition for I2C_IRQC register  *******************/
#define I2C_IRQC_RXNEN_DPos                 (0U)
#define I2C_IRQC_RXNEN_Pos                  I2C_IRQC_RXNEN_DPos
#define I2C_IRQC_RXNEN_Msk                  (0x1UL << I2C_IRQC_RXNEN_Pos)          /* 0x00000001 */
#define I2C_IRQC_RXNEN                      I2C_IRQC_RXNEN_Msk                     /* Receive idle interrupt enable */

#define I2C_IRQC_TXEN_DPos                  (1U)
#define I2C_IRQC_TXEN_Pos                   I2C_IRQC_TXEN_DPos
#define I2C_IRQC_TXEN_Msk                   (0x1UL << I2C_IRQC_TXEN_Pos)           /* 0x00000002 */
#define I2C_IRQC_TXEN                       I2C_IRQC_TXEN_Msk                      /* Send idle interrupt enable */

#define I2C_IRQC_SIEN_DPos                  (2U)
#define I2C_IRQC_SIEN_Pos                   I2C_IRQC_SIEN_DPos
#define I2C_IRQC_SIEN_Msk                   (0x1UL << I2C_IRQC_SIEN_Pos)           /* 0x00000004 */
#define I2C_IRQC_SIEN                       I2C_IRQC_SIEN_Msk                      /* Sequential operation interrupt enable */

#define I2C_IRQC_ERRN_DPos                  (3U)
#define I2C_IRQC_ERRN_Pos                   I2C_IRQC_ERRN_DPos
#define I2C_IRQC_ERRN_Msk                   (0x1UL << I2C_IRQC_ERRN_Pos)           /* 0x00000008 */
#define I2C_IRQC_ERRN                       I2C_IRQC_ERRN_Msk                      /* Transmission error interrupt enable */



/******************  Bit definition for I2C_DIV_H register  *******************/
#define I2C_DIV_H_DIV_DPos              (0U)
#define I2C_DIV_H_DIV_Pos               I2C_DIV_H_DIV_DPos
#define I2C_DIV_H_DIV_Msk               (0xFFUL << I2C_DIV_H_DIV_Pos)          /* 0x000000FF */
#define I2C_DIV_H_DIV                   I2C_DIV_H_DIV_Msk                      /* DIV[7:0] bits (division factor) */
#define I2C_DIV_H_DIV_0                 (0x1UL << I2C_DIV_H_DIV_Pos)           /* 0x00000001 */
#define I2C_DIV_H_DIV_1                 (0x2UL << I2C_DIV_H_DIV_Pos)           /* 0x00000002 */
#define I2C_DIV_H_DIV_2                 (0x4UL << I2C_DIV_H_DIV_Pos)           /* 0x00000004 */
#define I2C_DIV_H_DIV_3                 (0x8UL << I2C_DIV_H_DIV_Pos)           /* 0x00000008 */
#define I2C_DIV_H_DIV_4                 (0x10UL << I2C_DIV_H_DIV_Pos)          /* 0x00000010 */
#define I2C_DIV_H_DIV_5                 (0x20UL << I2C_DIV_H_DIV_Pos)          /* 0x00000020 */
#define I2C_DIV_H_DIV_6                 (0x40UL << I2C_DIV_H_DIV_Pos)          /* 0x00000040 */
#define I2C_DIV_H_DIV_7                 (0x80UL << I2C_DIV_H_DIV_Pos)          /* 0x00000080 */

/* @name USART register bits definition */
/******************  Bit definition for USART_CR1 register  *******************/
#define USART_CR1_UE_DPos               (0U)
#define USART_CR1_UE_Pos                USART_CR1_UE_DPos
#define USART_CR1_UE_Msk                (0x1UL << USART_CR1_UE_Pos)             /* 0x00000001 */
#define USART_CR1_UE                    USART_CR1_UE_Msk                        /* USART Enable */

#define USART_CR1_RE_DPos               (2U)
#define USART_CR1_RE_Pos                USART_CR1_RE_DPos
#define USART_CR1_RE_Msk                (0x1UL << USART_CR1_RE_Pos)             /* 0x00000004 */
#define USART_CR1_RE                    USART_CR1_RE_Msk                        /* Receiver Enable */

#define USART_CR1_TE_DPos               (3U)
#define USART_CR1_TE_Pos                USART_CR1_TE_DPos
#define USART_CR1_TE_Msk                (0x1UL << USART_CR1_TE_Pos)             /* 0x00000008 */
#define USART_CR1_TE                    USART_CR1_TE_Msk                        /* Transmitter Enable */

#define USART_CR1_IDLEIE_DPos           (4U)
#define USART_CR1_IDLEIE_Pos            USART_CR1_IDLEIE_DPos
#define USART_CR1_IDLEIE_Msk            (0x1UL << USART_CR1_IDLEIE_Pos)          /* 0x00000010 */
#define USART_CR1_IDLEIE                USART_CR1_IDLEIE_Msk                    /* IDLE Interrupt Enable */

#define USART_CR1_RXNEIE_RXFNEIE_DPos   (5U)
#define USART_CR1_RXNEIE_RXFNEIE_Pos    USART_CR1_RXNEIE_RXFNEIE_DPos
#define USART_CR1_RXNEIE_RXFNEIE_Msk    (0x1UL << USART_CR1_RXNEIE_RXFNEIE_Pos) /* 0x00000020 */
#define USART_CR1_RXNEIE_RXFNEIE        USART_CR1_RXNEIE_RXFNEIE_Msk            /* RXNE and RX FIFO Not Empty Interrupt Enable */

#define USART_CR1_TCIE_DPos             (6U)
#define USART_CR1_TCIE_Pos              USART_CR1_TCIE_DPos
#define USART_CR1_TCIE_Msk              (0x1UL << USART_CR1_TCIE_Pos)           /* 0x00000040 */
#define USART_CR1_TCIE                  USART_CR1_TCIE_Msk                      /* Transmission Complete Interrupt Enable */

#define USART_CR1_TXEIE_TXFNFIE_DPos    (7U)
#define USART_CR1_TXEIE_TXFNFIE_Pos     USART_CR1_TXEIE_TXFNFIE_DPos
#define USART_CR1_TXEIE_TXFNFIE_Msk     (0x1UL << USART_CR1_TXEIE_TXFNFIE_Pos)  /* 0x00000080 */
#define USART_CR1_TXEIE_TXFNFIE         USART_CR1_TXEIE_TXFNFIE_Msk             /* TXE and TX FIFO Not Full Interrupt Enable */

#define USART_CR1_PEIE_DPos             (8U)
#define USART_CR1_PEIE_Pos              USART_CR1_PEIE_DPos
#define USART_CR1_PEIE_Msk              (0x1UL << USART_CR1_PEIE_Pos)           /* 0x00000100 */
#define USART_CR1_PEIE                  USART_CR1_PEIE_Msk                      /* PE Interrupt Enable */

#define USART_CR1_PS_DPos               (9U)
#define USART_CR1_PS_Pos                USART_CR1_PS_DPos
#define USART_CR1_PS_Msk                (0x1UL << USART_CR1_PS_Pos)             /* 0x00000200 */
#define USART_CR1_PS                    USART_CR1_PS_Msk                        /* Parity Selection */

#define USART_CR1_PCE_DPos              (10U)
#define USART_CR1_PCE_Pos               USART_CR1_PCE_DPos
#define USART_CR1_PCE_Msk               (0x1UL << USART_CR1_PCE_Pos)            /* 0x00000400 */
#define USART_CR1_PCE                   USART_CR1_PCE_Msk                       /* Parity Control Enable */

#define USART_CR1_M_DPos                (12U)
#define USART_CR1_M_Pos                 USART_CR1_M_DPos
#define USART_CR1_M_Msk                 (0x10001UL << USART_CR1_M_Pos)          /* 0x10001000 */
#define USART_CR1_M                     USART_CR1_M_Msk                         /* Word length */

#define USART_CR1_M0_DPos               (12U)
#define USART_CR1_M0_Pos                USART_CR1_M0_DPos
#define USART_CR1_M0_Msk                (0x1UL << USART_CR1_M0_Pos)             /* 0x00001000 */
#define USART_CR1_M0                    USART_CR1_M0_Msk                        /* Word length - Bit 0 */

#define USART_CR1_OVER8_DPos            (15U)
#define USART_CR1_OVER8_Pos             USART_CR1_OVER8_DPos
#define USART_CR1_OVER8_Msk             (0x1UL << USART_CR1_OVER8_Pos)          /* 0x00008000 */
#define USART_CR1_OVER8                 USART_CR1_OVER8_Msk                     /* Oversampling by 8-bit or 16-bit mode */

#define USART_CR1_M1_DPos               (28U)
#define USART_CR1_M1_Pos                USART_CR1_M1_DPos
#define USART_CR1_M1_Msk                (0x1UL << USART_CR1_M1_Pos)             /* 0x10000000 */
#define USART_CR1_M1                    USART_CR1_M1_Msk                        /* Word length - Bit 1 */

#define USART_CR1_FIFOEN_DPos           (29U)
#define USART_CR1_FIFOEN_Pos            USART_CR1_FIFOEN_DPos
#define USART_CR1_FIFOEN_Msk            (0x1UL << USART_CR1_FIFOEN_Pos)         /* 0x20000000 */
#define USART_CR1_FIFOEN                USART_CR1_FIFOEN_Msk                    /* FIFO mode enable */

#define USART_CR1_TXFEIE_DPos           (30U)
#define USART_CR1_TXFEIE_Pos            USART_CR1_TXFEIE_DPos
#define USART_CR1_TXFEIE_Msk            (0x1UL << USART_CR1_TXFEIE_Pos)         /* 0x40000000 */
#define USART_CR1_TXFEIE                USART_CR1_TXFEIE_Msk                    /* TXFIFO empty interrupt enable */

#define USART_CR1_RXFFIE_DPos           (31U)
#define USART_CR1_RXFFIE_Pos            USART_CR1_RXFFIE_DPos
#define USART_CR1_RXFFIE_Msk            (0x1UL << USART_CR1_RXFFIE_Pos)         /* 0x80000000 */
#define USART_CR1_RXFFIE                USART_CR1_RXFFIE_Msk                    /* RXFIFO Full interrupt enable */

/* Legacy define */
#define USART_CR1_RXNEIE                USART_CR1_RXNEIE_RXFNEIE
#define USART_CR1_TXEIE                 USART_CR1_TXEIE_TXFNFIE

/******************  Bit definition for USART_CR2 register  *******************/
#define USART_CR2_SLVEN_DPos            (0U)
#define USART_CR2_SLVEN_Pos             USART_CR2_SLVEN_DPos
#define USART_CR2_SLVEN_Msk             (0x1UL << USART_CR2_SLVEN_Pos)          /* 0x00000001 */
#define USART_CR2_SLVEN                 USART_CR2_SLVEN_Msk                     /* Synchronous Slave mode Enable */

#define USART_CR2_BKNUM_DPos            (1U)
#define USART_CR2_BKNUM_Pos             USART_CR2_BKNUM_DPos
#define USART_CR2_BKNUM_Msk             (0x3UL << USART_CR2_BKNUM_Pos)          /* 0x00000006 */
#define USART_CR2_BKNUM                 USART_CR2_BKNUM_Msk                     /* BKNUM[1:0] bits (Send the length of Break characters) */
#define USART_CR2_BKNUM_0               (0x1UL << USART_CR2_BKNUM_Pos)          /* 0x00000002 */
#define USART_CR2_BKNUM_1               (0x2UL << USART_CR2_BKNUM_Pos)          /* 0x00000004 */

#define USART_CR2_DIS_NSS_DPos          (3U)
#define USART_CR2_DIS_NSS_Pos           USART_CR2_DIS_NSS_DPos
#define USART_CR2_DIS_NSS_Msk           (0x1UL << USART_CR2_DIS_NSS_Pos)        /* 0x00000008 */
#define USART_CR2_DIS_NSS               USART_CR2_DIS_NSS_Msk                   /* Negative Slave Select (NSS) pin management */

#define USART_CR2_LBDIE_DPos            (6U)
#define USART_CR2_LBDIE_Pos             USART_CR2_LBDIE_DPos
#define USART_CR2_LBDIE_Msk             (0x1UL << USART_CR2_LBDIE_Pos)          /* 0x00000040 */
#define USART_CR2_LBDIE                 USART_CR2_LBDIE_Msk                     /* LIN Break Detection Interrupt Enable */

#define USART_CR2_LBCL_DPos             (8U)
#define USART_CR2_LBCL_Pos              USART_CR2_LBCL_DPos
#define USART_CR2_LBCL_Msk              (0x1UL << USART_CR2_LBCL_Pos)            /* 0x00000100 */
#define USART_CR2_LBCL                  USART_CR2_LBCL_Msk                      /* Last Bit Clock pulse */

#define USART_CR2_CPHA_DPos             (9U)
#define USART_CR2_CPHA_Pos              USART_CR2_CPHA_DPos
#define USART_CR2_CPHA_Msk              (0x1UL << USART_CR2_CPHA_Pos)           /* 0x00000200 */
#define USART_CR2_CPHA                  USART_CR2_CPHA_Msk                      /* Clock Phase */

#define USART_CR2_CPOL_DPos             (10U)
#define USART_CR2_CPOL_Pos              USART_CR2_CPOL_DPos
#define USART_CR2_CPOL_Msk              (0x1UL << USART_CR2_CPOL_Pos)           /* 0x00000400 */
#define USART_CR2_CPOL                  USART_CR2_CPOL_Msk                      /* Clock Polarity */

#define USART_CR2_CLKEN_DPos            (11U)
#define USART_CR2_CLKEN_Pos             USART_CR2_CLKEN_DPos
#define USART_CR2_CLKEN_Msk             (0x1UL << USART_CR2_CLKEN_Pos)          /* 0x00000800 */
#define USART_CR2_CLKEN                 USART_CR2_CLKEN_Msk                     /* Clock Enable */

#define USART_CR2_STOP_DPos             (12U)
#define USART_CR2_STOP_Pos              USART_CR2_STOP_DPos
#define USART_CR2_STOP_Msk              (0x3UL << USART_CR2_STOP_Pos)           /* 0x00003000 */
#define USART_CR2_STOP                  USART_CR2_STOP_Msk                      /* STOP[1:0] bits (STOP bits) */
#define USART_CR2_STOP_0                (0x1UL << USART_CR2_STOP_Pos)           /* 0x00001000 */
#define USART_CR2_STOP_1                (0x2UL << USART_CR2_STOP_Pos)           /* 0x00002000 */

#define USART_CR2_LINEN_DPos            (14U)
#define USART_CR2_LINEN_Pos             USART_CR2_LINEN_DPos
#define USART_CR2_LINEN_Msk             (0x1UL << USART_CR2_LINEN_Pos)          /* 0x00004000 */
#define USART_CR2_LINEN                 USART_CR2_LINEN_Msk                     /* LIN mode enable */

#define USART_CR2_RXINV_DPos            (16U)
#define USART_CR2_RXINV_Pos             USART_CR2_RXINV_DPos
#define USART_CR2_RXINV_Msk             (0x1UL << USART_CR2_RXINV_Pos)           /* 0x00010000 */
#define USART_CR2_RXINV                 USART_CR2_RXINV_Msk                     /* RX pin active level inversion */

#define USART_CR2_TXINV_DPos            (17U)
#define USART_CR2_TXINV_Pos             USART_CR2_TXINV_DPos
#define USART_CR2_TXINV_Msk             (0x1UL << USART_CR2_TXINV_Pos)           /* 0x00020000 */
#define USART_CR2_TXINV                 USART_CR2_TXINV_Msk                     /* TX pin active level inversion */

#define USART_CR2_DATAINV_DPos          (18U)
#define USART_CR2_DATAINV_Pos           USART_CR2_DATAINV_DPos
#define USART_CR2_DATAINV_Msk           (0x1UL << USART_CR2_DATAINV_Pos)         /* 0x00040000 */
#define USART_CR2_DATAINV               USART_CR2_DATAINV_Msk                   /* Binary data inversion */

#define USART_CR2_MSBFIRST_DPos         (19U)
#define USART_CR2_MSBFIRST_Pos          USART_CR2_MSBFIRST_DPos
#define USART_CR2_MSBFIRST_Msk          (0x1UL << USART_CR2_MSBFIRST_Pos)       /* 0x00080000 */
#define USART_CR2_MSBFIRST              USART_CR2_MSBFIRST_Msk                  /* Most Significant Bit First */

#define USART_CR2_ABREN_DPos            (20U)
#define USART_CR2_ABREN_Pos             USART_CR2_ABREN_DPos
#define USART_CR2_ABREN_Msk             (0x1UL << USART_CR2_ABREN_Pos)          /* 0x00100000 */
#define USART_CR2_ABREN                 USART_CR2_ABREN_Msk                     /* Auto Baud-Rate Enable*/

#define USART_CR2_ABRMOD_DPos           (21U)
#define USART_CR2_ABRMODE_Pos           USART_CR2_ABRMOD_DPos
#define USART_CR2_ABRMODE_Msk           (0x3UL << USART_CR2_ABRMODE_Pos)         /* 0x00600000 */
#define USART_CR2_ABRMODE               USART_CR2_ABRMODE_Msk                   /* ABRMOD[1:0] bits (Auto Baud-Rate Mode) */
#define USART_CR2_ABRMODE_0             (0x1UL << USART_CR2_ABRMODE_Pos)         /* 0x00200000 */
#define USART_CR2_ABRMODE_1             (0x2UL << USART_CR2_ABRMODE_Pos)         /* 0x00400000 */


/******************  Bit definition for USART_CR3 register  *******************/
#define USART_CR3_EIE_DPos              (0U)
#define USART_CR3_EIE_Pos               USART_CR3_EIE_DPos
#define USART_CR3_EIE_Msk               (0x1UL << USART_CR3_EIE_Pos)            /* 0x00000001 */
#define USART_CR3_EIE                   USART_CR3_EIE_Msk                       /* Error Interrupt Enable */

#define USART_CR3_HDSEL_DPos            (1U)
#define USART_CR3_HDSEL_Pos             USART_CR3_HDSEL_DPos
#define USART_CR3_HDSEL_Msk             (0x1UL << USART_CR3_HDSEL_Pos)           /* 0x00000002 */
#define USART_CR3_HDSEL                 USART_CR3_HDSEL_Msk                     /* Half-Duplex Selection */

#define USART_CR3_DMAR_DPos             (4U)
#define USART_CR3_DMAR_Pos              USART_CR3_DMAR_DPos
#define USART_CR3_DMAR_Msk              (0x1UL << USART_CR3_DMAR_Pos)            /* 0x00000010 */
#define USART_CR3_DMAR                  USART_CR3_DMAR_Msk                      /* DMA Enable Receiver */

#define USART_CR3_DMAT_DPos             (5U)
#define USART_CR3_DMAT_Pos              USART_CR3_DMAT_DPos
#define USART_CR3_DMAT_Msk              (0x1UL << USART_CR3_DMAT_Pos)            /* 0x00000020 */
#define USART_CR3_DMAT                  USART_CR3_DMAT_Msk                      /* DMA Enable Transmitter */

#define USART_CR3_RTSE_DPos             (6U)
#define USART_CR3_RTSE_Pos              USART_CR3_RTSE_DPos
#define USART_CR3_RTSE_Msk              (0x1UL << USART_CR3_RTSE_Pos)           /* 0x00000040 */
#define USART_CR3_RTSE                  USART_CR3_RTSE_Msk                      /* RTS Enable */

#define USART_CR3_CTSE_DPos             (7U)
#define USART_CR3_CTSE_Pos              USART_CR3_CTSE_DPos
#define USART_CR3_CTSE_Msk              (0x1UL << USART_CR3_CTSE_Pos)           /* 0x00000080 */
#define USART_CR3_CTSE                  USART_CR3_CTSE_Msk                      /* CTS Enable */

#define USART_CR3_CTSIE_DPos            (8U)
#define USART_CR3_CTSIE_Pos             USART_CR3_CTSIE_DPos
#define USART_CR3_CTSIE_Msk             (0x1UL << USART_CR3_CTSIE_Pos)          /* 0x00000100 */
#define USART_CR3_CTSIE                 USART_CR3_CTSIE_Msk                     /* CTS Interrupt Enable */

#define USART_CR3_ONEBIT_DPos           (9U)
#define USART_CR3_ONEBIT_Pos            USART_CR3_ONEBIT_DPos
#define USART_CR3_ONEBIT_Msk            (0x1UL << USART_CR3_ONEBIT_Pos)          /* 0x00000200 */
#define USART_CR3_ONEBIT                USART_CR3_ONEBIT_Msk                    /* One sample bit method enable */

#define USART_CR3_OVRDIS_DPos           (10U)
#define USART_CR3_OVRDIS_Pos            USART_CR3_OVRDIS_DPos
#define USART_CR3_OVRDIS_Msk            (0x1UL << USART_CR3_OVRDIS_Pos)          /* 0x00000400 */
#define USART_CR3_OVRDIS                USART_CR3_OVRDIS_Msk                    /* Overrun Disable */

#define USART_CR3_TXFTIE_DPos           (20U)
#define USART_CR3_TXFTIE_Pos            USART_CR3_TXFTIE_DPos
#define USART_CR3_TXFTIE_Msk            (0x1UL << USART_CR3_TXFTIE_Pos)         /* 0x00100000 */
#define USART_CR3_TXFTIE                USART_CR3_TXFTIE_Msk                    /* TXFIFO threshold interrupt enable */

#define USART_CR3_RXFTCFG_DPos          (22U)
#define USART_CR3_RXFTCFG_Pos           USART_CR3_RXFTCFG_DPos
#define USART_CR3_RXFTCFG_Msk           (0x7UL << USART_CR3_RXFTCFG_Pos)        /* 0x01C00000 */
#define USART_CR3_RXFTCFG               USART_CR3_RXFTCFG_Msk                   /* RXFTCFG [2:0]Receive FIFO threshold configuration */
#define USART_CR3_RXFTCFG_0             (0x1UL << USART_CR3_RXFTCFG_Pos)        /* 0x00400000 */
#define USART_CR3_RXFTCFG_1             (0x2UL << USART_CR3_RXFTCFG_Pos)        /* 0x00800000 */
#define USART_CR3_RXFTCFG_2             (0x4UL << USART_CR3_RXFTCFG_Pos)        /* 0x01000000 */

#define USART_CR3_RXFTIE_DPos           (25U)
#define USART_CR3_RXFTIE_Pos            USART_CR3_RXFTIE_DPos
#define USART_CR3_RXFTIE_Msk            (0x1UL << USART_CR3_RXFTIE_Pos)         /* 0x02000000 */
#define USART_CR3_RXFTIE                USART_CR3_RXFTIE_Msk                    /* RXFIFO threshold interrupt enable */

#define USART_CR3_TXFTCFG_DPos          (26U)
#define USART_CR3_TXFTCFG_Pos           USART_CR3_TXFTCFG_DPos
#define USART_CR3_TXFTCFG_Msk           (0x7UL << USART_CR3_TXFTCFG_Pos)        /* 0x1C000000 */
#define USART_CR3_TXFTCFG               USART_CR3_TXFTCFG_Msk                   /* TXFIFO [2:0] threshold configuration */
#define USART_CR3_TXFTCFG_0             (0x1UL << USART_CR3_TXFTCFG_Pos)        /* 0x04000000 */
#define USART_CR3_TXFTCFG_1             (0x2UL << USART_CR3_TXFTCFG_Pos)        /* 0x08000000 */
#define USART_CR3_TXFTCFG_2             (0x4UL << USART_CR3_TXFTCFG_Pos)        /* 0x10000000 */


/******************  Bit definition for USART_BRR register  *******************/
#define USART_BRR_BRR_DPos              (0U)
#define USART_BRR_DIV_Pos               USART_BRR_BRR_DPos
#define USART_BRR_DIV_Msk               (0xFFFFUL << USART_BRR_DIV_Pos)         /* 0x0000FFFF */
#define USART_BRR_DIV                   USART_BRR_DIV_Msk                       /* USARTDIV */

/*******************  Bit definition for USART_RQR register  ******************/
#define USART_RQR_ABRRQ_DPos            (0U)
#define USART_RQR_ABRRQ_Pos             USART_RQR_ABRRQ_DPos
#define USART_RQR_ABRRQ_Msk             (0x1UL << USART_RQR_ABRRQ_Pos)          /* 0x00000001 */
#define USART_RQR_ABRRQ                 USART_RQR_ABRRQ_Msk                     /* Auto-Baud Rate Request */

#define USART_RQR_SBKRQ_DPos            (1U)
#define USART_RQR_SBKRQ_Pos             USART_RQR_SBKRQ_DPos
#define USART_RQR_SBKRQ_Msk             (0x1UL << USART_RQR_SBKRQ_Pos)          /* 0x00000002 */
#define USART_RQR_SBKRQ                 USART_RQR_SBKRQ_Msk                     /* Send Break Request */

#define USART_RQR_RXFRQ_DPos            (3U)
#define USART_RQR_RXFRQ_Pos             USART_RQR_RXFRQ_DPos
#define USART_RQR_RXFRQ_Msk             (0x1UL << USART_RQR_RXFRQ_Pos)          /* 0x00000008 */
#define USART_RQR_RXFRQ                 USART_RQR_RXFRQ_Msk                     /* Receive Data flush Request */

#define USART_RQR_TXFRQ_DPos            (4U)
#define USART_RQR_TXFRQ_Pos             USART_RQR_TXFRQ_DPos
#define USART_RQR_TXFRQ_Msk             (0x1UL << USART_RQR_TXFRQ_Pos)          /* 0x00000010 */
#define USART_RQR_TXFRQ                 USART_RQR_TXFRQ_Msk                     /* Transmit data flush Request */

/*******************  Bit definition for USART_ISR register  ******************/
#define USART_ISR_PE_DPos               (0U)
#define USART_ISR_PE_Pos                USART_ISR_PE_DPos
#define USART_ISR_PE_Msk                (0x1UL << USART_ISR_PE_Pos)             /* 0x00000001 */
#define USART_ISR_PE                    USART_ISR_PE_Msk                        /* Parity Error */

#define USART_ISR_FE_DPos               (1U)
#define USART_ISR_FE_Pos                USART_ISR_FE_DPos
#define USART_ISR_FE_Msk                (0x1UL << USART_ISR_FE_Pos)             /* 0x00000002 */
#define USART_ISR_FE                    USART_ISR_FE_Msk                        /* Framing Error */

#define USART_ISR_NE_DPos               (2U)
#define USART_ISR_NE_Pos                USART_ISR_NE_DPos
#define USART_ISR_NE_Msk                (0x1UL << USART_ISR_NE_Pos)             /* 0x00000004 */
#define USART_ISR_NE                    USART_ISR_NE_Msk                        /* Noise detected Flag */

#define USART_ISR_ORE_DPos              (3U)
#define USART_ISR_ORE_Pos               USART_ISR_ORE_DPos
#define USART_ISR_ORE_Msk               (0x1UL << USART_ISR_ORE_Pos)            /* 0x00000008 */
#define USART_ISR_ORE                   USART_ISR_ORE_Msk                       /* OverRun Error */

#define USART_ISR_IDLE_DPos             (4U)
#define USART_ISR_IDLE_Pos              USART_ISR_IDLE_DPos
#define USART_ISR_IDLE_Msk              (0x1UL << USART_ISR_IDLE_Pos)           /* 0x00000010 */
#define USART_ISR_IDLE                  USART_ISR_IDLE_Msk                      /* IDLE line detected */

#define USART_ISR_RXNE_DPos             (5U)
#define USART_ISR_RXNE_RXFNE_Pos        USART_ISR_RXNE_DPos
#define USART_ISR_RXNE_RXFNE_Msk        (0x1UL << USART_ISR_RXNE_RXFNE_Pos)     /* 0x00000020 */
#define USART_ISR_RXNE_RXFNE            USART_ISR_RXNE_RXFNE_Msk                /* Read Data Register or RX FIFO Not Empty */

#define USART_ISR_TC_DPos               (6U)
#define USART_ISR_TC_Pos                USART_ISR_TC_DPos
#define USART_ISR_TC_Msk                (0x1UL << USART_ISR_TC_Pos)             /* 0x00000040 */
#define USART_ISR_TC                    USART_ISR_TC_Msk                        /* Transmission Complete */

#define USART_ISR_TXE_DPos              (7U)
#define USART_ISR_TXE_TXFNF_Pos         USART_ISR_TXE_DPos
#define USART_ISR_TXE_TXFNF_Msk         (0x1UL << USART_ISR_TXE_TXFNF_Pos)      /* 0x00000080 */
#define USART_ISR_TXE_TXFNF             USART_ISR_TXE_TXFNF_Msk                 /* Transmit Data Register Empty or TX FIFO Not Full Flag */

#define USART_ISR_LBDF_DPos             (8U)
#define USART_ISR_LBDF_Pos              USART_ISR_LBDF_DPos
#define USART_ISR_LBDF_Msk              (0x1UL << USART_ISR_LBDF_Pos)           /* 0x00000100 */
#define USART_ISR_LBDF                  USART_ISR_LBDF_Msk                      /* LIN Break Detection Flag */

#define USART_ISR_CTSIF_DPos            (9U)
#define USART_ISR_CTSIF_Pos             USART_ISR_CTSIF_DPos
#define USART_ISR_CTSIF_Msk             (0x1UL << USART_ISR_CTSIF_Pos)          /* 0x00000200 */
#define USART_ISR_CTSIF                 USART_ISR_CTSIF_Msk                     /* CTS interrupt flag */

#define USART_ISR_CTS_DPos              (10U)
#define USART_ISR_CTS_Pos               USART_ISR_CTS_DPos
#define USART_ISR_CTS_Msk               (0x1UL << USART_ISR_CTS_Pos)            /* 0x00000400 */
#define USART_ISR_CTS                   USART_ISR_CTS_Msk                       /* CTS flag */

#define USART_ISR_ABRE_DPos             (14U)
#define USART_ISR_ABRE_Pos              USART_ISR_ABRE_DPos
#define USART_ISR_ABRE_Msk              (0x1UL << USART_ISR_ABRE_Pos)            /* 0x00004000 */
#define USART_ISR_ABRE                  USART_ISR_ABRE_Msk                      /* Auto-Baud Rate Error */

#define USART_ISR_ABRF_DPos             (15U)
#define USART_ISR_ABRF_Pos              USART_ISR_ABRF_DPos
#define USART_ISR_ABRF_Msk              (0x1UL << USART_ISR_ABRF_Pos)            /* 0x00008000 */
#define USART_ISR_ABRF                  USART_ISR_ABRF_Msk                      /* Auto-Baud Rate Flag */

#define USART_ISR_BUSY_DPos             (16U)
#define USART_ISR_BUSY_Pos              USART_ISR_BUSY_DPos
#define USART_ISR_BUSY_Msk              (0x1UL << USART_ISR_BUSY_Pos)           /* 0x00010000 */
#define USART_ISR_BUSY                  USART_ISR_BUSY_Msk                      /* Busy Flag */

#define USART_ISR_SBKF_DPos             (18U)
#define USART_ISR_SBKF_Pos              USART_ISR_SBKF_DPos
#define USART_ISR_SBKF_Msk              (0x1UL << USART_ISR_SBKF_Pos)            /* 0x00040000 */
#define USART_ISR_SBKF                  USART_ISR_SBKF_Msk                      /* Send Break Flag */

#define USART_ISR_TXFE_DPos             (23U)
#define USART_ISR_TXFE_Pos              USART_ISR_TXFE_DPos
#define USART_ISR_TXFE_Msk              (0x1UL << USART_ISR_TXFE_Pos)           /* 0x00800000 */
#define USART_ISR_TXFE                  USART_ISR_TXFE_Msk                      /* TXFIFO Empty */

#define USART_ISR_RXFF_DPos             (24U)
#define USART_ISR_RXFF_Pos              USART_ISR_RXFF_DPos
#define USART_ISR_RXFF_Msk              (0x1UL << USART_ISR_RXFF_Pos)           /* 0x01000000 */
#define USART_ISR_RXFF                  USART_ISR_RXFF_Msk                      /* RXFIFO Full Flag */

#define USART_ISR_RXFT_DPos             (26U)
#define USART_ISR_RXFT_Pos              USART_ISR_RXFT_DPos
#define USART_ISR_RXFT_Msk              (0x1UL << USART_ISR_RXFT_Pos)           /* 0x04000000 */
#define USART_ISR_RXFT                  USART_ISR_RXFT_Msk                      /* RXFIFO threshold Flag */

#define USART_ISR_TXFT_DPos             (27U)
#define USART_ISR_TXFT_Pos              USART_ISR_TXFT_DPos
#define USART_ISR_TXFT_Msk              (0x1UL << USART_ISR_TXFT_Pos)           /* 0x08000000 */
#define USART_ISR_TXFT                  USART_ISR_TXFT_Msk                      /* TXFIFO threshold Flag */


/*******************  Bit definition for USART_ICR register  ******************/
#define USART_ICR_PECF_DPos             (0U)
#define USART_ICR_PECF_Pos              USART_ICR_PECF_DPos
#define USART_ICR_PECF_Msk              (0x1UL << USART_ICR_PECF_Pos)           /* 0x00000001 */
#define USART_ICR_PECF                  USART_ICR_PECF_Msk                      /* Parity Error Clear Flag */

#define USART_ICR_FECF_DPos             (1U)
#define USART_ICR_FECF_Pos              USART_ICR_FECF_DPos
#define USART_ICR_FECF_Msk              (0x1UL << USART_ICR_FECF_Pos)           /* 0x00000002 */
#define USART_ICR_FECF                  USART_ICR_FECF_Msk                      /* Framing Error Clear Flag */

#define USART_ICR_NECF_DPos             (2U)
#define USART_ICR_NECF_Pos              USART_ICR_NECF_DPos
#define USART_ICR_NECF_Msk              (0x1UL << USART_ICR_NECF_Pos)           /* 0x00000004 */
#define USART_ICR_NECF                  USART_ICR_NECF_Msk                      /* Noise detected Clear Flag */

#define USART_ICR_ORECF_DPos            (3U)
#define USART_ICR_ORECF_Pos             USART_ICR_ORECF_DPos
#define USART_ICR_ORECF_Msk             (0x1UL << USART_ICR_ORECF_Pos)          /* 0x00000008 */
#define USART_ICR_ORECF                 USART_ICR_ORECF_Msk                     /* OverRun Error Clear Flag */

#define USART_ICR_IDLECF_DPos           (4U)
#define USART_ICR_IDLECF_Pos            USART_ICR_IDLECF_DPos
#define USART_ICR_IDLECF_Msk            (0x1UL << USART_ICR_IDLECF_Pos)         /* 0x00000010 */
#define USART_ICR_IDLECF                USART_ICR_IDLECF_Msk                    /* IDLE line detected Clear Flag */

#define USART_ICR_TXFECF_DPos           (5U)
#define USART_ICR_TXFECF_Pos            USART_ICR_TXFECF_DPos
#define USART_ICR_TXFECF_Msk            (0x1UL << USART_ICR_TXFECF_Pos)         /* 0x00000020 */
#define USART_ICR_TXFECF                USART_ICR_TXFECF_Msk                    /* TXFIFO empty clear flag */

#define USART_ICR_TCCF_DPos             (6U)
#define USART_ICR_TCCF_Pos              USART_ICR_TCCF_DPos
#define USART_ICR_TCCF_Msk              (0x1UL << USART_ICR_TCCF_Pos)           /* 0x00000040 */
#define USART_ICR_TCCF                  USART_ICR_TCCF_Msk                      /* Transmission Complete Clear Flag */

#define USART_ICR_LBDCF_DPos            (8U)
#define USART_ICR_LBDCF_Pos             USART_ICR_LBDCF_DPos
#define USART_ICR_LBDCF_Msk             (0x1UL << USART_ICR_LBDCF_Pos)          /* 0x00000100 */
#define USART_ICR_LBDCF                 USART_ICR_LBDCF_Msk                     /* LIN Break Detection Clear Flag */

#define USART_ICR_CTSCF_DPos            (9U)
#define USART_ICR_CTSCF_Pos             USART_ICR_CTSCF_DPos
#define USART_ICR_CTSCF_Msk             (0x1UL << USART_ICR_CTSCF_Pos)          /* 0x00000200 */
#define USART_ICR_CTSCF                 USART_ICR_CTSCF_Msk                     /* CTS Interrupt Clear Flag */

#define USART_ICR_RXFTCF_DPos           (26U)
#define USART_ICR_RXFTCF_Pos            USART_ICR_RXFTCF_DPos
#define USART_ICR_RXFTCF_Msk            (0x1UL << USART_ICR_RXFTCF_Pos)         /* 0x04000000 */
#define USART_ICR_RXFTCF                USART_ICR_RXFTCF_Msk                    /* Clear RXFIFO threshold interrupt flag */

#define USART_ICR_TXFTCF_DPos           (27U)
#define USART_ICR_TXFTCF_Pos            USART_ICR_TXFTCF_DPos
#define USART_ICR_TXFTCF_Msk            (0x1UL << USART_ICR_TXFTCF_Pos)         /* 0x08000000 */
#define USART_ICR_TXFTCF                USART_ICR_TXFTCF_Msk                    /* Clear TXFIFO threshold interrupt flag */


/*******************  Bit definition for USART_RDR register  ******************/
#define USART_RDR_RDR_DPos              (0U)
#define USART_RDR_RDR_Pos               USART_RDR_RDR_DPos
#define USART_RDR_RDR_Msk               (0x1FFUL << USART_RDR_RDR_Pos)          /* 0x000001FF */
#define USART_RDR_RDR                   USART_RDR_RDR_Msk                       /* RDR[8:0] bits (Receive Data value) */

/*******************  Bit definition for USART_TDR register  ******************/
#define USART_TDR_TDR_DPos              (0U)
#define USART_TDR_TDR_Pos               USART_TDR_TDR_DPos
#define USART_TDR_TDR_Msk               (0x1FFUL << USART_TDR_TDR_Pos)          /* 0x000001FF */
#define USART_TDR_TDR                   USART_TDR_TDR_Msk                       /* TDR[8:0] bits (Transmit Data value) */

/* @name WWDG register bits definition */
/******************  Bit definition for WWDG_PSC register  *******************/
#define WWDG_PSC_EN_DPos        (0U)
#define WWDG_PSC_EN_Pos         WWDG_PSC_EN_DPos
#define WWDG_PSC_EN_Msk         (0x1UL << WWDG_PSC_EN_Pos)               /* 0x00000001 */
#define WWDG_PSC_EN             WWDG_PSC_EN_Msk                          /* Enable Independent watchdog prescaler. */

#define WWDG_PSC_LOCK_DPos      (1U)
#define WWDG_PSC_LOCK_Pos       WWDG_PSC_LOCK_DPos
#define WWDG_PSC_LOCK_Msk       (0x1UL << WWDG_PSC_LOCK_Pos)             /* 0x00000002 */
#define WWDG_PSC_LOCK           WWDG_PSC_LOCK_Msk                        /*Independent watchdog prescaler lock. */

#define WWDG_PSC_PSCNUM_DPos    (2U)
#define WWDG_PSC_PSCNUM_Pos     WWDG_PSC_PSCNUM_DPos
#define WWDG_PSC_PSCNUM_Msk     (0xffUL << WWDG_PSC_PSCNUM_Pos)          /* 0x00003fc */
#define WWDG_PSC_PSCNUM         WWDG_PSC_PSCNUM_Msk                      /*Independent watchdog prescaler number. */

/******************  Bit definition for WWDG_DSTA register  *******************/
#define WWDG_DSTA_BK0_DPos       (0U)
#define WWDG_DSTA_BK0_Pos        WWDG_DSTA_BK0_DPos
#define WWDG_DSTA_BK0_Msk        (0x1UL << WWDG_DSTA_BK0_Pos)                /* 0x00000001 */
#define WWDG_DSTA_BK0            WWDG_DSTA_BK0_Msk                           /* The WWDG Channel0 Bark flag . */

#define WWDG_DSTA_BK1_DPos       (1U)
#define WWDG_DSTA_BK1_Pos        WWDG_DSTA_BK1_DPos
#define WWDG_DSTA_BK1_Msk        (0x1UL << WWDG_DSTA_BK1_Pos)                /* 0x00000002 */
#define WWDG_DSTA_BK1            WWDG_DSTA_BK1_Msk                           /* The WWDG Channel1 Bark flag . */

#define WWDG_DSTA_BK2_DPos       (2U)
#define WWDG_DSTA_BK2_Pos        WWDG_DSTA_BK2_DPos
#define WWDG_DSTA_BK2_Msk        (0x1UL << WWDG_DSTA_BK2_Pos)                /* 0x00000004 */
#define WWDG_DSTA_BK2            WWDG_DSTA_BK2_Msk                           /* The WWDG Channel2 Bark flag . */

#define WWDG_DSTA_BK3_DPos       (3U)
#define WWDG_DSTA_BK3_Pos        WWDG_DSTA_BK3_DPos
#define WWDG_DSTA_BK3_Msk        (0x1UL << WWDG_DSTA_BK3_Pos)                /* 0x00000008 */
#define WWDG_DSTA_BK3            WWDG_DSTA_BK3_Msk                           /* The WWDG Channel3 Bark flag . */

/******************  Bit definition for WWDG_CFG register  *******************/
#define WWDG_CFG_EN_DPos         (0U)
#define WWDG_CFG_EN_Pos          WWDG_CFG_EN_DPos
#define WWDG_CFG_EN_Msk          (0x1UL << WWDG_CFG_EN_Pos)                  /* 0x00000001 */
#define WWDG_CFG_EN              WWDG_CFG_EN_Msk                             /* Enable Independent watchdog configuration. */

#define WWDG_CFG_LOCK_DPos       (1U)
#define WWDG_CFG_LOCK_Pos        WWDG_CFG_LOCK_DPos
#define WWDG_CFG_LOCK_Msk        (0x1UL << WWDG_CFG_LOCK_Pos)                /* 0x00000002 */
#define WWDG_CFG_LOCK            WWDG_CFG_LOCK_Msk                           /*Independent watchdog prescaler lock. */

/******************  Bit definition for WWDG_DIV register  *******************/
#define WWDG_DIV_DIVNUM_DPos    (0U)
#define WWDG_DIV_DIVNUM_Pos     WWDG_DIV_DIVNUM_DPos
#define WWDG_DIV_DIVNUM_Msk     (0xffffUL << WWDG_DIV_DIVNUM_Pos)            /* 0x0000ffff */
#define WWDG_DIV_DIVNUM         WWDG_DIV_DIVNUM_Msk                          /*Independent watchdog divider number. */

/******************  Bit definition for WWDG_TO register  *******************/
#define WWDG_TO_BVAL_DPos       (0U)
#define WWDG_TO_BVAL_Pos        WWDG_TO_BVAL_DPos
#define WWDG_TO_BVAL_Msk        (0xffffUL << WWDG_TO_BVAL_Pos)            /* 0x0000ffff */
#define WWDG_TO_BVAL            WWDG_TO_BVAL_Msk                          /*Independent watchdog configure timeout period. */

/******************  Bit definition for WWDG_CNT register  *******************/
#define WWDG_CNT_CNTNUM_DPos    (0U)
#define WWDG_CNT_CNTNUM_Pos     WWDG_CNT_CNTNUM_DPos
#define WWDG_CNT_CNTNUM_Msk     (0xffffUL << WWDG_CNT_CNTNUM_Pos)            /* 0x0000ffff */
#define WWDG_CNT_CNTNUM         WWDG_CNT_CNTNUM_Msk                          /*Independent watchdog counter number. */

/******************  Bit definition for WWDG_CLR register  *******************/
#define WWDG_CLR_CLEARPASS_DPos      (0U)
#define WWDG_CLR_KEY_Pos             WWDG_CLR_CLEARPASS_DPos
#define WWDG_CLR_KEY_Msk             (0xffffffffUL << WWDG_CLR_KEY_Pos)        /* 0xffffffff */
#define WWDG_CLR_KEY                 WWDG_CLR_KEY_Msk                          /*Independent watchdog refreshes the key. */

/******************  Bit definition for WWDG_WD register  *******************/
#define WWDG_WD_WDEN_DPos    (0U)
#define WWDG_WD_WDEN_Pos     WWDG_WD_WDEN_DPos
#define WWDG_WD_WDEN_Msk     (1UL << WWDG_WD_WDEN_Pos)                        /* 0x00000001 */
#define WWDG_WD_WDEN         WWDG_WD_WDEN_Msk                                 /*Enable WWDG Window Counter. */

#define WWDG_WD_WDCNT_DPos   (1U)
#define WWDG_WD_WDCNT_Pos    WWDG_WD_WDCNT_DPos
#define WWDG_WD_WDCNT_Msk    (0xffffUL << WWDG_WD_WDCNT_Pos)                  /* 0x00000001 */
#define WWDG_WD_WDCNT        WWDG_WD_WDCNT_Msk                                /* WWDG Window Counter Value. */

/* @name CRC register bits definition */
/******************  Bits definition for CRC_DR register  *****************/
#define CRC_DR_DATA_DPos            (0U)
#define CRC_DR_DATA_Pos             CRC_DR_DATA_DPos
#define CRC_DR_DATA_Msk             (0xFFFFFFFFUL << CRC_DR_DATA_Pos)           /* 0xFFFFFFFF */
#define CRC_DR_DATA                 CRC_DR_DATA_Msk                             /* DATA[31:0] bits (CRC calculated result bit) */

/******************  Bits definition for CRC_IDR register  *****************/
#define CRC_IDR_IDATA_DPos          (0U)
#define CRC_IDR_IDATA_Pos           CRC_IDR_IDATA_DPos
#define CRC_IDR_IDATA_Msk           (0xFFUL << CRC_IDR_IDATA_Pos)               /* 0x000000FF */
#define CRC_IDR_IDATA               CRC_IDR_IDATA_Msk                           /* IDATA[7:0] bits (Universal 8-bit data register bit) */

/******************  Bits definition for CRC_CR register  *****************/
#define CRC_CR_RESET_DPos           (0U)
#define CRC_CR_RESET_Pos            CRC_CR_RESET_DPos
#define CRC_CR_RESET_Msk            (0x1UL << CRC_CR_RESET_Pos)                 /* 0x00000001 */
#define CRC_CR_RESET                CRC_CR_RESET_Msk                            /* Reset CRC */

#define CRC_CR_POLYSIZE_DPos        (3U)
#define CRC_CR_POLYSIZE_Pos         CRC_CR_POLYSIZE_DPos
#define CRC_CR_POLYSIZE_Msk         (0x3UL << CRC_CR_POLYSIZE_Pos)              /* 0x00000018 */
#define CRC_CR_POLYSIZE             CRC_CR_POLYSIZE_Msk                         /* POLYSIZE[1:0] bits (Polynomial size) */
#define CRC_CR_POLYSIZE_0           (0x01UL << CRC_CR_POLYSIZE_Pos)             /* 0x00000008 */
#define CRC_CR_POLYSIZE_1           (0x02UL << CRC_CR_POLYSIZE_Pos)             /* 0x00000010 */

#define CRC_CR_REV_IN_DPos          (5U)
#define CRC_CR_REVIN_Pos            CRC_CR_REV_IN_DPos
#define CRC_CR_REVIN_Msk            (0x3UL << CRC_CR_REVIN_Pos)                 /* 0x00000060 */
#define CRC_CR_REVIN                CRC_CR_REVIN_Msk                            /* REVIN[1:0] bits (Reverse input data) */
#define CRC_CR_REVIN_0              (0x01UL << CRC_CR_REVIN_Pos)                /* 0x00000020 */
#define CRC_CR_REVIN_1              (0x02UL << CRC_CR_REVIN_Pos)                /* 0x00000040 */

#define CRC_CR_REV_OUT_DPos         (7U)
#define CRC_CR_REVOUT_Pos           CRC_CR_REV_OUT_DPos
#define CRC_CR_REVOUT_Msk           (0x1UL << CRC_CR_REVOUT_Pos)                /* 0x00000080 */
#define CRC_CR_REVOUT               CRC_CR_REVOUT_Msk                           /* Reverse output data */

#define CRC_CR_XOR_OUT_DPos         (8U)
#define CRC_CR_XOROUT_Pos           CRC_CR_XOR_OUT_DPos
#define CRC_CR_XOROUT_Msk           (0x1UL << CRC_CR_XOROUT_Pos)                /* 0x00000100 */
#define CRC_CR_XOROUT               CRC_CR_XOROUT_Msk                           /* Output data XOR */

#define CRC_CR_SIZE_DPos            (16U)
#define CRC_CR_SIZE_Pos             CRC_CR_SIZE_DPos
#define CRC_CR_SIZE_Msk             (0x3UL << CRC_CR_SIZE_Pos)                  /* 0x00030000 */
#define CRC_CR_SIZE                 CRC_CR_SIZE_Msk                             /* SIZE[1:0] bits (Calculate the size of the data) */
#define CRC_CR_SIZE_0               (0x01UL << CRC_CR_SIZE_Pos)                 /* 0x00010000 */
#define CRC_CR_SIZE_1               (0x02UL << CRC_CR_SIZE_Pos)                 /* 0x00020000 */

/******************  Bits definition for CRC_INIT register  *****************/
#define CRC_INIT_INIT_DPos          (0U)
#define CRC_INIT_INIT_Pos           CRC_INIT_INIT_DPos
#define CRC_INIT_INIT_Msk           (0xFFFFFFFFUL << CRC_INIT_INIT_Pos)         /* 0xFFFFFFFF */
#define CRC_INIT_INIT               CRC_INIT_INIT_Msk                           /* INIT[31:0] bits (Initial vector register) */

/******************  Bits definition for CRC_POLY register  *****************/
#define CRC_POLY_POLY_DPos          (0U)
#define CRC_POLY_POLY_Pos           CRC_POLY_POLY_DPos
#define CRC_POLY_POLY_Msk           (0xFFFFFFFFUL << CRC_POLY_POLY_Pos)         /* 0xFFFFFFFF */
#define CRC_POLY_POLY               CRC_POLY_POLY_Msk                           /* POLY[31:0] bits (Generating polynomial register) */

/******************  Bits definition for CRC_XOR register  *****************/
#define CRC_XOR_XOR_DPos            (0U)
#define CRC_XOR_XOR_Pos             CRC_XOR_XOR_DPos
#define CRC_XOR_XOR_Msk             (0xFFFFFFFFUL << CRC_XOR_XOR_Pos)           /* 0xFFFFFFFF */
#define CRC_XOR_XOR                 CRC_XOR_XOR_Msk                             /* XOR[31:0] bits (XOR register) */


#ifdef __cplusplus
}
#endif

#endif

/*****END OF FILE*****/
