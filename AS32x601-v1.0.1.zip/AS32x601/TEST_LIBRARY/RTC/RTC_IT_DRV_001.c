/**
 * @file    RTC_IT_DRV_001.c
 * @brief   HAL RTC integration test case 001: calendar 2024-12-31 23:59:50 + year rollover alarm (reference case 001).
 *
 * One-to-one HAL library port of the reference test case RTC_IT_DRV_001.c of the
 * chip vendor: the calendar is set to the last 10 seconds of 2024 and a single
 * alarm is programmed for 2025-01-01 00:00:00.0, so the alarm fires exactly on the
 * year rollover. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_RTC_Init() / HAL_RTC_Cmd()
 *   HAL_RTC_SetTime() / HAL_RTC_GetTime()
 *   HAL_RTC_SetDate() / HAL_RTC_GetDate()
 *   HAL_RTC_TimeStructInit() / HAL_RTC_DateStructInit()
 *   HAL_RTC_AlarmStructInit() / HAL_RTC_SetAlarm_IT() / HAL_RTC_GetAlarm()
 *   HAL_RTC_AlarmIRQHandler() / HAL_RTC_AlarmEventCallback()
 *   HAL_RTC_GetState() / HAL_RTC_GetError()
 *   HAL_PLIC_Init() (RTC alarm interrupt line)
 *
 * Expected behaviour:
 *   - the calendar read-back matches the programmed value before the wait;
 *   - the alarm comparison enables and match fields survive the read-back;
 *   - the alarm interrupt fires on the year rollover and the first callback runs
 *     at the rollover instant (2025-01-01 00:00:00.0);
 *   - the alarm of this device is level type: the comparison set stays true for
 *     the whole match window (the resolution of the set is the tenth of a
 *     second), so every clear of CR.ALRMT is followed by a new assertion and one
 *     match makes the callback run many times. The case therefore verifies that
 *     the burst is bounded (it stops once the match window has passed) instead
 *     of expecting a single event;
 *   - the calendar then reads 2025-01-01 and the alarm flag is clear.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* RTC divider coefficient. 1785 is the project baseline of the reference test
 * cases of this chip, 1638 is the other value documented by the library SRS;
 * both are legal hardware values (the driver only checks the 27 bit field
 * width). No test below depends on the resulting absolute frequency: the
 * checks are register read-backs or "the counter moved" observations. */
#define TEST_RTC_DIVISION           (1785U)

/* Calendar value used by the cases that need a known starting point */
#define TEST_TIME_HOURS             (15U)
#define TEST_TIME_MINUTES           (48U)
#define TEST_TIME_SECONDS           (0U)
#define TEST_TIME_TOS               (0U)
#define TEST_DATE_CENTURY           (20U)
#define TEST_DATE_YEAR              (25U)
#define TEST_DATE_MONTH             (RTC_Month_July)
#define TEST_DATE_DATE              (21U)
#define TEST_DATE_WEEKDAY           (RTC_Weekday_Monday)

/* Polling slice of the wait loops (ms) */
#define TEST_POLL_MS                (10U)

/* Reporting period of the final idle loop (ms) */
#define TEST_IDLE_MS                (1000U)

/* Bounded wait for the rollover alarm: the reference case waits 10 s, this
 * port allows 20 s and then reports the result instead of waiting forever. */
#define TEST_ALARM_TIMEOUT_MS       (20000U)

/* Settle time of the alarm burst. The level type comparison of this device
 * keeps the match condition true for one tenth of a second, which is the
 * window during which the interrupt is re-asserted after every clear; the
 * burst must have stopped once that window has passed twice. */
#define TEST_BURST_SETTLE_MS        (300U)

/* Private variables ---------------------------------------------------------*/
static RTC_HandleTypeDef hrtc_dev;          /*!< RTC device handle            */
static RTC_InitTypeDef   rtc_init;          /*!< RTC configuration structure  */
static uint32            failures = 0U;     /*!< failed checks                */

/* Alarm interrupt bookkeeping (filled by the overridden weak callback) */
static volatile uint32   alarm_events = 0U; /*!< callback entries             */
static volatile uint32   alarm_cr_seen = 0U;/*!< CR register at callback time */
static volatile uint32   alarm_tr_first = 0U;/*!< TR at the first event       */
static volatile uint32   alarm_dr_first = 0U;/*!< DR at the first event       */
static uint32            alarm_events_settled = 0U;/*!< events after the burst */

/* Alarm structures of this case */
static RTC_AlarmTypeDef alarm;              /*!< alarm configuration          */
static RTC_AlarmTypeDef alarm_read;         /*!< alarm read back              */
static uint32           elapsed;            /*!< wait loop budget (ms)        */

/* Last calendar read back by the report helpers */
static uint8 r_time_hours;
static uint8 r_time_minutes;
static uint8 r_time_seconds;
static uint8 r_time_tos;
static uint8 r_date_century;
static uint8 r_date_year;
static uint8 r_date_month;
static uint8 r_date_date;
static uint8 r_date_weekday;

/* Private function prototypes -----------------------------------------------*/
static void Check(const char *name, uint32 condition);
static void SystemClock_Init(void);
static void Rtc_Handle_Setup(void);
static HAL_StatusTypeDef Rtc_Start(void);
static HAL_StatusTypeDef Rtc_SetCalendar(uint8 hours, uint8 minutes, uint8 seconds, uint8 tos,
                                         uint8 century, uint8 year, uint8 month, uint8 date,
                                         uint8 weekday);
static HAL_StatusTypeDef Rtc_GetCalendar(void);
static uint8 Rtc_RawBcd(uint32 value);
static uint8 Rtc_MonthToNumber(uint8 month);
static const char *Rtc_WeekdayName(uint8 weekday);
static void Rtc_PrintCalendar(const char *tag);
static void Plc_RouteRtcIrq(void);

/* Exported interrupt entry ------------------------------------------------*/
/**
 * @brief  RTC interrupt entry, called by the shared PLIC dispatch table.
 * @note   Overrides the weak RTC_IRQ_Handler() of the PLIC driver; it hands the
 *         event to the HAL RTC interrupt handler, which clears the alarm flag
 *         and then calls HAL_RTC_AlarmEventCallback().
 */
void RTC_IRQ_Handler(void)
{
    HAL_RTC_AlarmIRQHandler(&hrtc_dev);
}

/**
 * @brief  Alarm event callback (weak function of the HAL RTC driver).
 * @note   Counts the events and snapshots CR so that the cases can observe the
 *         flag state the driver left behind. It must not block and must not
 *         call a locking RTC interface (interrupt context).
 * @note   The calendar is snapshotted on the first event, where the rollover
 *         instant is unambiguous. The alarm of this device is level type, so
 *         the first callback is the one that marks the instant the calendar
 *         reached the alarm value; the following callbacks of the same match
 *         window repeat the same instant. HAL_RTC_GetTime() / GetDate() cannot
 *         be used here (they take the handle lock), the registers are read
 *         directly instead.
 * @param  hrtc pointer to a RTC_HandleTypeDef structure.
 * @retval None
 */
void HAL_RTC_AlarmEventCallback(RTC_HandleTypeDef *hrtc)
{
    UNUSED(hrtc);

    alarm_events++;
    alarm_cr_seen = hrtc_dev.Instance->CR;
    if (alarm_events == 1U)
    {
        alarm_tr_first = hrtc_dev.Instance->TR;
        alarm_dr_first = hrtc_dev.Instance->DR;
    }
}

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    uint32 tr_first;                        /*!< first event TR snapshot      */
    uint32 dr_first;                        /*!< first event DR snapshot      */

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock tree */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n\r\n==== RTC_IT_DRV_001: calendar 2024-12-31 23:59:50 + year rollover alarm (reference case 001) ====\r\n");
    printf("Data : %s\r\n", __DATE__);
    printf("Time : %s\r\n", __TIME__);

        /* ---- Step 1: RTC initialization and alarm interrupt routing -------- */
        Plc_RouteRtcIrq();
        Check("RTC init", (Rtc_Start() == HAL_OK));

        /* ---- Step 2: calendar 2024-12-31 23:59:50.0 (last 10 s of 2024) ---- */
        Check("calendar programmed (2024-12-31 23:59:50.0)",
              (Rtc_SetCalendar(23U, 59U, 50U, 0U, 21U, 24U, RTC_Month_December, 31U,
                               RTC_Weekday_Tuesday) == HAL_OK));
        (void)Rtc_GetCalendar();
        Check("calendar read back", ((r_time_hours == 23U) && (r_time_minutes == 59U) &&
                                     (r_time_seconds == 50U) && (r_time_tos == 0U) &&
                                     (r_date_year == 24U) && (r_date_month == RTC_Month_December) &&
                                     (r_date_date == 31U) && (r_date_weekday == RTC_Weekday_Tuesday)));
        Rtc_PrintCalendar("start");

        /* ---- Step 3: alarm 2025-01-01 00:00:00.0 (the year rollover) ------- */
        /* The comparison set of the reference case: the four time-of-day fields
           and year / month / date, so the alarm is a one-shot event (the same
           combination repeats only after a year). */
        __HAL_CLEAR_STRUCT(&alarm);
        HAL_RTC_AlarmStructInit(&alarm);
        alarm.RTC_AlarmTime.RTC_Hours         = 0U;
        alarm.RTC_AlarmTime.RTC_Minutes       = 0U;
        alarm.RTC_AlarmTime.RTC_Seconds       = 0U;
        alarm.RTC_AlarmTime.RTC_TenthOfSecond = 0U;
        alarm.RTC_AlarmDate.RTC_WeekDay       = RTC_Weekday_Wednesday;
        alarm.RTC_AlarmDate.RTC_Century       = 21U;
        alarm.RTC_AlarmDate.RTC_Year          = 25U;
        alarm.RTC_AlarmDate.RTC_Month         = RTC_Month_January;
        alarm.RTC_AlarmDate.RTC_Date          = 1U;
        alarm.RTC_AlarmTimeCompEn = RTC_AlarmTime_Hours | RTC_AlarmTime_Minutes |
                                    RTC_AlarmTime_Seconds | RTC_AlarmTime_TenOfSecond;
        alarm.RTC_AlarmDataCompEn = RTC_AlarmDate_Year | RTC_AlarmDate_Month |
                                    RTC_AlarmDate_Date;
        Check("alarm programmed (2025-01-01 00:00:00.0, interrupt enabled)",
              (HAL_RTC_SetAlarm_IT(&hrtc_dev, &alarm, RTC_FORMAT_BIN) == HAL_OK));
        Check("alarm interrupt enable bit set", ((RTC->CR & RTC_CR_IE) != 0U));
        Check("alarm flag cleared by SetAlarm_IT", ((RTC->CR & RTC_CR_ALRMT) == 0U));

        /* The comparison enables and the match fields must survive the round trip */
        __HAL_CLEAR_STRUCT(&alarm_read);
        Check("alarm read back",
              (HAL_RTC_GetAlarm(&hrtc_dev, &alarm_read, RTC_FORMAT_BIN) == HAL_OK));
        Check("alarm comparison enables read back",
              ((alarm_read.RTC_AlarmTimeCompEn == alarm.RTC_AlarmTimeCompEn) &&
               (alarm_read.RTC_AlarmDataCompEn == alarm.RTC_AlarmDataCompEn)));
        Check("alarm time read back", ((alarm_read.RTC_AlarmTime.RTC_Hours == 0U) &&
                                       (alarm_read.RTC_AlarmTime.RTC_Minutes == 0U) &&
                                       (alarm_read.RTC_AlarmTime.RTC_Seconds == 0U) &&
                                       (alarm_read.RTC_AlarmTime.RTC_TenthOfSecond == 0U)));

        /* ---- Step 4: start the calendar and wait for the rollover ---------- */
        Check("calendar enabled", (HAL_RTC_Cmd(&hrtc_dev, ENABLE) == HAL_OK));
        Check("RTC enable bit set", ((RTC->CR & RTC_CR_EN) != 0U));

        /* The reference case waits 10 s and then reports every 100 ms; this port
           polls the event counter with a bounded timeout (the reference case would
           wait forever when the event never arrives). */
        elapsed = 0U;
        while ((alarm_events == 0U) && (elapsed < TEST_ALARM_TIMEOUT_MS))
        {
            delay_ms(TEST_POLL_MS);
            elapsed += TEST_POLL_MS;

            if ((elapsed % 1000U) == 0U)
            {
                Rtc_PrintCalendar("wait");
            }
        }

        printf("alarm events = %u after %u ms\r\n",
               PRINT_U32(alarm_events), PRINT_U32(elapsed));
        Check("alarm interrupt occurred", (alarm_events > 0U));

        /* The alarm is level type: while the comparison set matches, every clear
         * of CR.ALRMT is followed by a new assertion, so one match makes the
         * callback run many times. What is verified here is that the burst is
         * bounded - it has to stop once the match window (one tenth of a
         * second, the resolution of the comparison set) has passed. */
        delay_ms(TEST_BURST_SETTLE_MS);
        alarm_events_settled = alarm_events;
        delay_ms(TEST_BURST_SETTLE_MS);
        Check("alarm burst bounded after the match window",
              (alarm_events == alarm_events_settled));
        printf("alarm burst = %u events, stopped at %u\r\n",
               PRINT_U32(alarm_events_settled), PRINT_U32(alarm_events));

        /* The first callback must carry the rollover instant: the calendar that
         * the interrupt saw has to be 2025-01-01 00:00:00.0. */
        tr_first = alarm_tr_first;
        dr_first = alarm_dr_first;
        printf("first event  TR=%08X DR=%08X\r\n",
               PRINT_U32(tr_first), PRINT_U32(dr_first));
        Check("alarm fired on 2025-01-01 00:00:00.0",
              ((Rtc_RawBcd((dr_first & (RTC_DR_YT | RTC_DR_YU)) >> RTC_DR_YU_Pos) == 25U) &&
               (Rtc_RawBcd((dr_first & (RTC_DR_MT | RTC_DR_MU)) >> RTC_DR_MU_Pos) == 1U) &&
               (Rtc_RawBcd((dr_first & (RTC_DR_DT | RTC_DR_DU)) >> RTC_DR_DU_Pos) == 1U) &&
               (Rtc_RawBcd((tr_first & (RTC_TR_HT | RTC_TR_HU)) >> RTC_TR_HU_Pos) == 0U) &&
               (Rtc_RawBcd((tr_first & (RTC_TR_MNT | RTC_TR_MNU)) >> RTC_TR_MNU_Pos) == 0U) &&
               (Rtc_RawBcd((tr_first & (RTC_TR_ST | RTC_TR_SU)) >> RTC_TR_SU_Pos) == 0U) &&
               (((tr_first & RTC_TR_TOS) >> RTC_TR_TOS_Pos) == 0U)));

        /* ---- Step 5: the calendar crossed into 2025-01-01 ------------------ */
        Rtc_PrintCalendar("after");
        Check("year rolled over to 2025-01-01",
              ((r_date_century == 21U) && (r_date_year == 25U) &&
               (r_date_month == RTC_Month_January) && (r_date_date == 1U)));
        Check("alarm flag cleared after the event", ((RTC->CR & RTC_CR_ALRMT) == 0U));
        printf("CR at callback time = 0x%X (IE = bit29, ALRMT = bit30)\r\n",
               PRINT_U32(alarm_cr_seen));
    /* ---- summary ------------------------------------------------------- */
    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(failures));

    /* Idle: keep the calendar observable on the console */
    while (1)
    {
        Rtc_PrintCalendar("idle");
        delay_ms(TEST_IDLE_MS);
    }
}

/* Private functions --------------------------------------------------------*/
/**
 * @brief  Prepare the RTC handle and its configuration structure.
 * @note   The configuration structure metafields (Size / Version / reserved
 *         words) are mandatory: HAL_RTC_Init() validates them at run time and
 *         rejects a structure that does not carry them.
 * @param  None
 * @retval None
 */
static void Rtc_Handle_Setup(void)
{
    __HAL_CLEAR_STRUCT(&hrtc_dev);
    hrtc_dev.Instance = RTC;

    __HAL_CLEAR_STRUCT(&rtc_init);
    rtc_init.Size     = sizeof(RTC_InitTypeDef);
    rtc_init.Version  = RTC_INIT_VERSION;
    rtc_init.Division = TEST_RTC_DIVISION;
    hrtc_dev.Init     = rtc_init;
}

/**
 * @brief  Initialize the RTC and report its state.
 * @param  None
 * @retval HAL status of the initialization.
 */
static HAL_StatusTypeDef Rtc_Start(void)
{
    HAL_StatusTypeDef status;

    Rtc_Handle_Setup();
    status = HAL_RTC_Init(&hrtc_dev);
    printf("RTC state = %u (1 = READY), error = %u\r\n",
           PRINT_U32(HAL_RTC_GetState(&hrtc_dev)),
           PRINT_U32(HAL_RTC_GetError(&hrtc_dev)));

    return status;
}

/**
 * @brief  Write the calendar (time and date) of the RTC.
 * @param  hours / minutes / seconds / tos: time fields.
 * @param  century / year / month / date / weekday: date fields.
 * @retval HAL_OK when both writes succeeded.
 */
static HAL_StatusTypeDef Rtc_SetCalendar(uint8 hours, uint8 minutes, uint8 seconds, uint8 tos,
                                         uint8 century, uint8 year, uint8 month, uint8 date,
                                         uint8 weekday)
{
    RTC_TimeTypeDef time;
    RTC_DateTypeDef dateS;
    HAL_StatusTypeDef status;

    __HAL_CLEAR_STRUCT(&time);
    __HAL_CLEAR_STRUCT(&dateS);
    HAL_RTC_TimeStructInit(&time);
    HAL_RTC_DateStructInit(&dateS);

    time.RTC_Hours         = hours;
    time.RTC_Minutes       = minutes;
    time.RTC_Seconds       = seconds;
    time.RTC_TenthOfSecond = tos;

    dateS.RTC_WeekDay = weekday;
    dateS.RTC_Century = century;
    dateS.RTC_Year    = year;
    dateS.RTC_Month   = month;
    dateS.RTC_Date    = date;

    status = HAL_RTC_SetTime(&hrtc_dev, &time, RTC_FORMAT_BIN);
    if (status == HAL_OK)
    {
        status = HAL_RTC_SetDate(&hrtc_dev, &dateS, RTC_FORMAT_BIN);
    }

    return status;
}

/**
 * @brief  Read the calendar into the report globals.
 * @param  None
 * @retval HAL status of the read (HAL_ERROR when a read was refused).
 */
static HAL_StatusTypeDef Rtc_GetCalendar(void)
{
    RTC_TimeTypeDef time;
    RTC_DateTypeDef dateS;
    HAL_StatusTypeDef status;

    __HAL_CLEAR_STRUCT(&time);
    __HAL_CLEAR_STRUCT(&dateS);

    status = HAL_RTC_GetTime(&hrtc_dev, &time, RTC_FORMAT_BIN);
    if (status == HAL_OK)
    {
        status = HAL_RTC_GetDate(&hrtc_dev, &dateS, RTC_FORMAT_BIN);
    }
    if (status != HAL_OK)
    {
        return status;
    }

    r_time_hours   = time.RTC_Hours;
    r_time_minutes = time.RTC_Minutes;
    r_time_seconds = time.RTC_Seconds;
    r_time_tos     = time.RTC_TenthOfSecond;

    r_date_century = dateS.RTC_Century;
    r_date_year    = dateS.RTC_Year;
    r_date_month   = dateS.RTC_Month;
    r_date_date    = dateS.RTC_Date;
    r_date_weekday = dateS.RTC_WeekDay;

    return HAL_OK;
}

/**
 * @brief  Decode a two digit BCD field of a register snapshot.
 * @note   Used for the register snapshot taken in the alarm callback, where the
 *         locking HAL_RTC_GetTime() / GetDate() cannot be called.
 * @param  value: the register field, right aligned (bit 3..0 = units).
 * @retval uint8: the decoded decimal value.
 */
static uint8 Rtc_RawBcd(uint32 value)
{
    return (uint8)((((value >> 4U) & 0x0FU) * 10U) + (value & 0x0FU));
}

/**
 * @brief  Translate a month constant to its number (1-12).
 * @param  month: month (RTC_Month_xxx).
 * @retval uint8: month number, or 0 when the value is unknown.
 */
static uint8 Rtc_MonthToNumber(uint8 month)
{
    uint8 result;

    switch (month)
    {
        case RTC_Month_January:   result = 1U;  break;
        case RTC_Month_February:  result = 2U;  break;
        case RTC_Month_March:     result = 3U;  break;
        case RTC_Month_April:     result = 4U;  break;
        case RTC_Month_May:       result = 5U;  break;
        case RTC_Month_June:      result = 6U;  break;
        case RTC_Month_July:      result = 7U;  break;
        case RTC_Month_August:    result = 8U;  break;
        case RTC_Month_September: result = 9U;  break;
        case RTC_Month_October:   result = 10U; break;
        case RTC_Month_November:  result = 11U; break;
        case RTC_Month_December:  result = 12U; break;
        default:                  result = 0U;  break;
    }

    return result;
}

/**
 * @brief  Translate a weekday constant to its name.
 * @param  weekday: weekday (RTC_Weekday_xxx).
 * @retval const char*: weekday name, or "?" when the value is unknown.
 */
static const char *Rtc_WeekdayName(uint8 weekday)
{
    switch (weekday)
    {
        case RTC_Weekday_Monday:    return "Monday";
        case RTC_Weekday_Tuesday:   return "Tuesday";
        case RTC_Weekday_Wednesday: return "Wednesday";
        case RTC_Weekday_Thursday:  return "Thursday";
        case RTC_Weekday_Friday:    return "Friday";
        case RTC_Weekday_Saturday:  return "Saturday";
        case RTC_Weekday_Sunday:    return "Sunday";
        default:                    return "?";
    }
}

/**
 * @brief  Read and print the calendar.
 * @note   The century and the year are printed explicitly: the leading field of
 *         the date is the century register, so a print without the year cannot
 *         tell a year rollover from a month rollover.
 * @param  tag: text printed in front of the value (may be NULL).
 * @retval None
 */
static void Rtc_PrintCalendar(const char *tag)
{
    if (Rtc_GetCalendar() != HAL_OK)
    {
        printf("%s calendar read refused (state = %u)\r\n",
               ((tag != NULL_PTR) ? tag : ""),
               PRINT_U32(HAL_RTC_GetState(&hrtc_dev)));
        return;
    }

    printf("%s %02u-%02u-%02u %02u:%02u:%02u.%u %s (century=%u year=%u)\r\n",
           ((tag != NULL_PTR) ? tag : ""),
           PRINT_U32(r_date_century), PRINT_U32(Rtc_MonthToNumber(r_date_month)),
           PRINT_U32(r_date_date), PRINT_U32(r_time_hours), PRINT_U32(r_time_minutes),
           PRINT_U32(r_time_seconds), PRINT_U32(r_time_tos),
           Rtc_WeekdayName(r_date_weekday),
           PRINT_U32(r_date_century), PRINT_U32(r_date_year));
}

/**
 * @brief  Route the RTC alarm interrupt line through the PLIC.
 * @note   The RTC alarm is the only interrupt source of the module; the shared
 *         trap entry dispatches it to RTC_IRQ_Handler() overridden above.
 * @param  None
 * @retval None
 */
static void Plc_RouteRtcIrq(void)
{
    PLIC_InitTypeDef plic_init;

    __HAL_CLEAR_STRUCT(&plic_init);
    plic_init.Size               = sizeof(plic_init);
    plic_init.Version            = PLIC_INIT_VERSION;
    plic_init.PLIC_IRQChannel    = RTC_IRQn;
    plic_init.PLIC_IRQPriority   = 1U;
    plic_init.PLIC_IRQChannelCmd = ENABLE;
    HAL_PLIC_Init(&plic_init);

    Check("RTC interrupt routed in the PLIC",
          (PLIC->AXI_PLIC_PRIORITY[RTC_IRQn - 1U] == 1U));
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition == 0U)
    {
        failures++;
    }
    printf("%-44s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Configure the system clock tree using the HAL SMU driver.
 * @note   Clock tree shared by every integration test suite of this library:
 *         OSC 20 MHz as the PLL source, PLLDivR = 0x04 / PLLDivN = 0x14 /
 *         PLLDivF = 0xB4 / PLLDivQ = 0x01, then AXI4Bus3 = /2, APBBus0 = /2,
 *         APBBus1 = /2 and CANX2 = /8. The bus dividers are written first and
 *         the PLL is switched in afterwards, which is the order the chip
 *         requires (see HAL_SMU_OscConfig()).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;
    HAL_SMU_HandleTypeDef hsmu_clk;

    /* Enable the bus clock gates */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* The RTC lives in the always-on APB-BusS domain: it has no clock gate of
       its own, the module switch of the configuration file is enough. */

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Bus dividers first (the system clock is still the power-on source) */
    __HAL_CLEAR_STRUCT(&SMU_ClockInitStruct);
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;
    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) and switch to it; the
       call also programs the EFLASH controller clock before the switch. */
    __HAL_CLEAR_STRUCT(&SMU_OscInitStruct);
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
