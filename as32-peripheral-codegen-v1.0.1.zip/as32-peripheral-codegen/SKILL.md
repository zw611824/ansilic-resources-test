---
name: as32-peripheral-codegen
description: 根据需求和芯片开发库先规划、确认，再生成或增量修改 MCU 外设应用代码，完成编译并维护工程说明；不用于修改 HAL 驱动底层或 IDE 集成。
---

# AS32 应用代码生成

将需求转为有真实芯片开发库/HAL 依据的应用实现。已有工程优先复用，不强制迁移目录。面向用户的方案、参数卡和汇总统一称“芯片开发库”，涉及 HAL 时称“HAL 驱动库”；真实路径、标识符与原始错误保持原样。

进入应用规划或代码生成前，先读取对应阶段参考及 references/workflow.md、references/retrieval-rules.md，已读取且未变化的内容复用。SDK 来源只取用户/当前工程明确引用的位置，或 IDE 配置目录下 sdk/<芯片系列>；不能因工程为空就浏览父目录、相邻工程或 HAL 开发输出目录来猜来源。未找到时报告缺口，按 workflow.md 定向处理。

## 阶段与授权

- 默认先规划：读取 [规划阶段](references/stages/planning.md)，检查工程与 SDK，输出方案并在同一轮打开确认卡等待。用户补充参数或确认推荐值仅更新方案，不授权生成，即使 IDE 已在 Agent 模式也一样。提交生成确认前必须先按 [plan-design.md](references/plan-design.md) 第 5 节落实板级参数；未确认的项先提问，不得直接进入确认卡。
- 首次调用本 Skill 时，“实现/生成一个程序”描述的是任务目标，不跳过规划。先形成可审阅方案、完成板级参数确认，再在同一轮展示方案并打开确认卡，等待“确认生成 / 继续规划”的卡片选择；不要先结束本轮等待用户手打确认，手打文本不是卡片结果。Auto 是执行权限，不是方案确认。只有卡片返回确认生成，才读取 [生成阶段](references/stages/generation.md)。已授权实施中因缺少参数暂停，收到答复后可继续；关键依据缺失时暂停受影响部分。
- 规划阶段默认不写文件，方案和参数调整保留在会话中；只有用户明确要求保存方案时，才按 [project-documentation.md](references/project-documentation.md) 及实际权限处理。只读 Plan/Ask 不写任何文件。文档或已确认方案本身不是生成授权。
- 实施后的检查、编译与修错遵循生成阶段参考及 references/validation-rules.md 的本次执行策略；当前 IDE 权限始终优先，不自行切换模式。

普通事实问答只回答问题。仅为已有实现补画或修订应用流程图时直接按 references/project-flowchart.md 处理，不启动代码生成流程。两个阶段参考均由本 Skill 按当前阶段加载；使用实际发现的 Skill 名和相对根目录路径读取资源，不通过 `..` 访问，不同时执行两个阶段。

## 按需加载

1. 对应阶段参考负责加载 [workflow.md](references/workflow.md)、[retrieval-rules.md](references/retrieval-rules.md) 及该阶段所需规范；同一份资料已读取且未变化时复用。规划表达见 [plan-design.md](references/plan-design.md)，生成组织见 [coding-standard.md](references/coding-standard.md)，复核见 [validation-rules.md](references/validation-rules.md)。
2. 确认芯片后读实际存在的 `chips/<chip>/README.md`。当前仅收录 AS32x601，按匹配 HAL 和案例取证生成；未收录芯片说明资料缺口，不套用其他芯片规则生成代码或具体配置。料号到系列的映射须有依据。
3. 涉及串口输出或 printf 适配时读取 `references/printf-adaptation.md`，并核对当前芯片 README 的适配差异。外设实例、引脚和用法按芯片开发库对应模块 README、真实 HAL 和匹配案例核实，不因目录存在就认定能力已支持。
4. 需要调用 IDE 构建或硬件工具时读 [mcp-tools.md](references/mcp-tools.md)。工具不可用或被拒绝时如实报告。SDK 定位、新旧工程和源码登记见 workflow.md，不修改 SDK 或参考案例。
5. 应用流程图按需加载 [project-flowchart.md](references/project-flowchart.md)，其范围、子页和绘图规则独立于 HAL 驱动设计流程；工程说明仍由 project-documentation.md 定义。
6. `schemas/*.yaml` 是用于记录芯片、需求和案例的 JSON Schema，按需使用；简单任务不另建元数据。

## 交付

保留关键设计决策、依据位置、约束和未决问题，不能仅留在工具输出中。先用通俗中文说明原因，再说明修改及实际验证结果，区分事实、假设和未执行项；仅本轮更新了文字说明或流程图时提供对应文件路径。文字说明详细维护规则由 project-documentation.md 定义，应用流程图由 project-flowchart.md 定义。
