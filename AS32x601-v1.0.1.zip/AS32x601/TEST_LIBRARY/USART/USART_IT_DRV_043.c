/**
 * @file    USART_IT_DRV_043.c
 * @brief   HAL USART integration test case 043 (public API coverage, state gate and parameter checks).
 *
 * HAL library port of the original AS32x601 standard-library test case
 * USART_IT_DRV_043.c, which drives USART7. Only HAL library APIs are
 * used; the register read backs are there to document what was programmed.
 *
 * Tested functionality:
 *   HAL_USART_StructInit()
 *   HAL_USART_ClockStructInit()
 *   HAL_USART_Init()
 *   HAL_USART_DeInit()
 *   HAL_USART_MspInit()
 *   HAL_USART_MspDeInit()
 *   HAL_USART_CheckIdleState()
 *   HAL_USART_Transmit()
 *   HAL_USART_Receive()
 *   HAL_USART_TransmitReceive()
 *   HAL_USART_Transmit_IT()
 *   HAL_USART_Receive_IT()
 *   HAL_USART_TransmitReceive_IT()
 *   HAL_USART_Transmit_DMA()
 *   HAL_USART_Receive_DMA()
 *   HAL_USART_TransmitReceive_DMA()
 *   HAL_USART_DMAPause()
 *   HAL_USART_DMAResume()
 *   HAL_USART_DMAStop()
 *   HAL_USART_EnableFIFO()
 *   HAL_USART_DisableFIFO()
 *   HAL_USART_SetTxFIFOThreshold()
 *   HAL_USART_SetRxFIFOThreshold()
 *   HAL_USART_EnableSlaveMode()
 *   HAL_USART_DisableSlaveMode()
 *   HAL_USART_ConfigNSS()
 *   HAL_USART_LINCmd()
 *   HAL_USART_LINBreakDetectLengthConfig()
 *   HAL_USART_HalfDuplexCmd()
 *   HAL_USART_OneBitMethodCmd()
 *   HAL_USART_SendBreak()
 *   HAL_USART_AutoBaudRateRequest()
 *   HAL_USART_RxDataFlush()
 *   HAL_USART_TxDataFlush()
 *   HAL_USART_ConfigClock()
 *   HAL_USART_ConfigAdvFeature()
 *   HAL_USART_GetState()
 *   HAL_USART_GetError()
 *   USART_HandleIsValid()
 *   USART_LockHandle()
 *   USART_UnlockHandle()
 *   the six transport callbacks and the validation macro family
 *
 * Test procedure:
 *   1. check the structure defaults of the initialization and clock structures;
 *   2. exercise the handle lock and the state gate (locked handle, uninitialized handle);
 *   3. call every public entry point with a NULL handle;
 *   4. feed the initialization entry point with rejected parameters (size, version, baud rate, reserved word);
 *   5. walk the FIFO, NSS, LIN, duplex, sampling, request and clock configuration interfaces and verify every register read back;
 *   6. run the full duplex DMA group with pause / resume / stop;
 *   7. verify the MSP callbacks and the validation macro family;
 *   8. restore the peripheral and print the failure counter.
 *
 * Expected behaviour:
 *   - the structure defaults are 115200 8N1 with TX+RX and no flow control, clock disabled;
 *   - a locked handle reports HAL_BUSY and an uninitialized handle HAL_ERROR from every transfer entry point;
 *   - every public entry point rejects a NULL handle (HAL_ERROR), the state query returns RESET and the error query NONE;
 *   - the rejected initialization calls report HAL_USART_ERROR_INVALID_PARAM and leave the handle uninitialized;
 *   - every configuration interface is confirmed by reading the register back;
 *   - HAL_USART_MspInit() runs once, before the handle is locked, and HAL_USART_MspDeInit() once on de-initialization;
 *   - every check prints [PASS] and "summary : failures = 0".
 *
 * Note:
 *   - Frame parameters: baud rate 115200, word length USART_WORDLENGTH_8B, stop bits USART_STOPBITS_1, parity USART_PARITY_NONE, hardware flow control USART_HWCONTROL_NONE, CPOL USART_POLARITY_LOW, CPHA USART_PHASE_1EDGE.
 *   - This extension case needs no external stimulus: every item is verified through a return value and a register read back.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
/* Console: USART0 on GPIOD pin 8 (TX) / pin 9 (RX), 115200 8N1 */
#define TEST_BAUDRATE                   (115200U)

/* Device under test: the pins are the ones the original test case uses */
#define TEST_USART                      USART7
#define TEST_USART_IRQn                 USART7_IRQn
#define TEST_USART_IRQ_HANDLER          USART7_IRQ_Handler
#define TEST_TX_PORT                    GPIOA
#define TEST_TX_PIN                     GPIO_PIN_6
#define TEST_TX_SOURCE                  GPIO_PinSource6
#define TEST_TX_AF                      GPIO_AF_USART7
#define TEST_RX_PORT                    GPIOA
#define TEST_RX_PIN                     GPIO_PIN_7
#define TEST_RX_SOURCE                  GPIO_PinSource7
#define TEST_RX_AF                      GPIO_AF_USART7

/* Frame parameters of this case */
#define TEST_BAUD_RATE                  (115200U)
#define TEST_WORD_LENGTH                USART_WORDLENGTH_8B
#define TEST_STOP_BITS                  USART_STOPBITS_1
#define TEST_PARITY                     USART_PARITY_NONE
#define TEST_MODE                       (USART_MODE_TX_RX)
#define TEST_OVERSAMPLING               USART_OVERSAMPLING_16
#define TEST_FLOW_CONTROL               USART_HWCONTROL_NONE
#define TEST_CLK_POLARITY               USART_POLARITY_LOW
#define TEST_CLK_PHASE                  USART_PHASE_1EDGE
#define TEST_CLK_LASTBIT                USART_LASTBIT_DISABLE
#define TEST_SYNC_MODE                  (0U)
#define TEST_SLAVE_MODE                 (0U)

/* Frame geometry, pacing and timeouts */
#define TX_FRAME_SIZE                   (8U)
#define RX_BURST_SIZE                   (64U)
#define TX_FRAME_PERIOD_MS              (500U)
#define TRANSFER_TIMEOUT_MS             (2000U)
#define WAIT_SPINS                      (20000000U)
#define RX_WAIT_MS                      (1000U)

/* Private variables --------------------------------------------------------*/
static USART_HandleTypeDef husart_dev;          /*!< device under test       */
static HAL_SMU_HandleTypeDef hsmu_clk;          /*!< SMU handle (clock tree) */
static const uint8 tx_data[TX_FRAME_SIZE] = {0x11U, 0x22U, 0x33U, 0x44U,
                                              0x55U, 0x66U, 0x77U, 0x88U};
static uint8 rx_data[TX_FRAME_SIZE];          /*!< received frame buffer   */
static volatile uint32 check_failures = 0U;     /*!< failed check counter    */
static USART_HandleTypeDef husart_bad;      /*!< handle used for the reject paths  */
static DMA_HandleTypeDef hdma_dev;          /*!< DMA channel 0 (transmit)          */
static DMA_HandleTypeDef hdma_dev2;         /*!< DMA channel 1 (receive)           */
static volatile uint32 msp_init_count = 0U; /*!< HAL_USART_MspInit call counter    */
static volatile uint32 msp_deinit_count = 0U; /*!< HAL_USART_MspDeInit call counter */
static volatile uint32 msp_state_at_init = 0U; /*!< state seen by HAL_USART_MspInit */
static volatile uint32 tx_cplt_count = 0U;  /*!< callback counters (coverage only) */
static volatile uint32 tx_half_count = 0U;
static volatile uint32 rx_cplt_count = 0U;
static volatile uint32 rx_half_count = 0U;
static volatile uint32 txrx_cplt_count = 0U;
static volatile uint32 error_count = 0U;

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void USART_GPIO_Init(void);
static void Check(const char *name, uint32 condition);
static void Summary(void);
static void DMA_Config(void);
static void Restore_Setup(void);
static void USART_PLIC_Init(void);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    USART_InitTypeDef usart_init;
    uint32 expected_brr;
    USART_ClockInitTypeDef clock_init;
    USART_AdvFeatureInitTypeDef adv_init;
    uint32 msp_deinit_baseline;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock tree */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART (USART0 on GPIOD pin 8 / pin 9) */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== USART_IT_DRV_043 : public API coverage, state gate and parameter checks ===\r\n");

    /* Step 1: map and configure the pins of the device under test */
    USART_GPIO_Init();

    /* Step 2: program the frame parameters and initialize the USART */
    (void)HAL_USART_DeInit(&husart_dev);

    HAL_USART_StructInit(&usart_init);
    usart_init.BaudRate            = TEST_BAUD_RATE;
    usart_init.WordLength          = TEST_WORD_LENGTH;
    usart_init.StopBits            = TEST_STOP_BITS;
    usart_init.Parity              = TEST_PARITY;
    usart_init.Mode                = TEST_MODE;
    usart_init.OverSampling        = TEST_OVERSAMPLING;
    usart_init.HardwareFlowControl = TEST_FLOW_CONTROL;
    usart_init.CLKPolarity         = TEST_CLK_POLARITY;
    usart_init.CLKPhase            = TEST_CLK_PHASE;
    usart_init.CLKLastBit          = TEST_CLK_LASTBIT;

    husart_dev.Instance = TEST_USART;
    husart_dev.Init     = usart_init;

    Check("HAL_USART_Init", (uint32)((HAL_USART_Init(&husart_dev) == HAL_OK) ? 1U : 0U));
    Check("state after init is READY",
          (uint32)((HAL_USART_GetState(&husart_dev) == HAL_USART_STATE_READY) ? 1U : 0U));
    Check("error code after init is NONE",
          (uint32)((HAL_USART_GetError(&husart_dev) == HAL_USART_ERROR_NONE) ? 1U : 0U));

    /* Cross check the baud rate divider: the driver computes the divider as
     * BRR = bus clock / baud rate. USART0..USART3 are clocked by APBBus0 and
     * USART4..USART7 by APBBus1. */
    expected_brr = HAL_SMU_GetPCLK1Freq() / TEST_BAUD_RATE;

    printf("bus clock       : %u Hz\r\n", PRINT_U32(HAL_SMU_GetPCLK1Freq()));
    printf("divider         : BRR = %u (expected %u) %s\r\n",
           PRINT_U32((uint32)TEST_USART->BRR), PRINT_U32(expected_brr),
           (((uint32)TEST_USART->BRR == expected_brr) ? "[PASS]" : "[FAIL]"));
    if ((uint32)TEST_USART->BRR != expected_brr)
    {
        check_failures++;
    }

    /* Step 3: enable the FIFO mode, as the original test case does */
    Check("HAL_USART_EnableFIFO",
          (uint32)((HAL_USART_EnableFIFO(&husart_dev) == HAL_OK) ? 1U : 0U));

    /* Interrupt routing of this case */
    USART_PLIC_Init();

    /* ======================================================================
     * Extension case: the public entry points that the 42 ported cases do not
     * reach, plus the handle state gate, the handle lock, the NULL handle
     * protection and the run time parameter checks. No stimulus is needed:
     * every item is verified through the return value and a register read
     * back.
     * ==================================================================== */

    /* ---------------- Group 1: structure defaults ---------------------- */
    /* The two configuration structures are used across the groups: they are
     * cleared here and filled again before every use. */
    __HAL_CLEAR_STRUCT(&clock_init);
    __HAL_CLEAR_STRUCT(&adv_init);

    HAL_USART_StructInit(&usart_init);
    Check("StructInit : Size / Version metafields",
          (uint32)(((usart_init.Size == sizeof(USART_InitTypeDef)) &&
                    (usart_init.Version == USART_INIT_VERSION)) ? 1U : 0U));
    Check("StructInit : 115200, 8N1, TX+RX, no flow control",
          (uint32)(((usart_init.BaudRate == 115200U) &&
                    (usart_init.WordLength == USART_WORDLENGTH_8B) &&
                    (usart_init.StopBits == USART_STOPBITS_1) &&
                    (usart_init.Parity == USART_PARITY_NONE) &&
                    (usart_init.Mode == USART_MODE_TX_RX) &&
                    (usart_init.OverSampling == USART_OVERSAMPLING_16) &&
                    (usart_init.HardwareFlowControl == USART_HWCONTROL_NONE)) ? 1U : 0U));

    HAL_USART_ClockStructInit(&clock_init);
    Check("ClockStructInit : clock off, CPOL low, CPHA 1 edge, no last bit",
          (uint32)(((clock_init.Clock == USART_CLOCK_DISABLE) &&
                    (clock_init.CPOL == USART_POLARITY_LOW) &&
                    (clock_init.CPHA == USART_PHASE_1EDGE) &&
                    (clock_init.LastBit == USART_LASTBIT_DISABLE)) ? 1U : 0U));

    /* ---------------- Group 2: handle lock and state gate -------------- */
    Check("USART_LockHandle : free handle is acquired",
          (uint32)((USART_LockHandle(&husart_dev, HAL_MAX_DELAY) == HAL_OK) ? 1U : 0U));
    Check("USART_LockHandle : a locked handle reports HAL_BUSY",
          (uint32)((USART_LockHandle(&husart_dev, HAL_MAX_DELAY) == HAL_BUSY) ? 1U : 0U));
    Check("state gate : transmit on a locked handle reports HAL_BUSY",
          (uint32)((HAL_USART_Transmit(&husart_dev, (uint8 *)tx_data, TX_FRAME_SIZE, 10U) == HAL_BUSY) ? 1U : 0U));
    USART_UnlockHandle(&husart_dev);
    Check("USART_UnlockHandle : the handle is free again",
          (uint32)((USART_LockHandle(&husart_dev, HAL_MAX_DELAY) == HAL_OK) ? 1U : 0U));
    USART_UnlockHandle(&husart_dev);

    /* A handle that was never initialized is rejected with HAL_ERROR */
    __HAL_CLEAR_STRUCT(&husart_bad);
    husart_bad.Instance = TEST_USART;
    Check("state gate : uninitialized handle is rejected",
          (uint32)((HAL_USART_Transmit(&husart_bad, (uint8 *)tx_data, TX_FRAME_SIZE, 10U) == HAL_ERROR) ? 1U : 0U));
    Check("state gate : CheckIdleState on an uninitialized handle",
          (uint32)((HAL_USART_CheckIdleState(&husart_bad) == HAL_ERROR) ? 1U : 0U));
    Check("CheckIdleState : a READY handle reports HAL_OK",
          (uint32)((HAL_USART_CheckIdleState(&husart_dev) == HAL_OK) ? 1U : 0U));

    /* ---------------- Group 3: NULL handle protection ------------------ */
    Check("NULL handle : Init / DeInit / CheckIdleState rejected",
          (uint32)(((HAL_USART_Init(NULL_PTR) == HAL_ERROR) &&
                    (HAL_USART_DeInit(NULL_PTR) == HAL_ERROR) &&
                    (HAL_USART_CheckIdleState(NULL_PTR) == HAL_ERROR)) ? 1U : 0U));
    Check("NULL handle : blocking IO rejected",
          (uint32)(((HAL_USART_Transmit(NULL_PTR, (uint8 *)tx_data, TX_FRAME_SIZE, 10U) == HAL_ERROR) &&
                    (HAL_USART_Receive(NULL_PTR, rx_data, TX_FRAME_SIZE, 10U) == HAL_ERROR) &&
                    (HAL_USART_TransmitReceive(NULL_PTR, (uint8 *)tx_data, rx_data, TX_FRAME_SIZE, 10U) == HAL_ERROR)) ? 1U : 0U));
    Check("NULL handle : interrupt IO rejected",
          (uint32)(((HAL_USART_Transmit_IT(NULL_PTR, (uint8 *)tx_data, TX_FRAME_SIZE) == HAL_ERROR) &&
                    (HAL_USART_Receive_IT(NULL_PTR, rx_data, TX_FRAME_SIZE) == HAL_ERROR) &&
                    (HAL_USART_TransmitReceive_IT(NULL_PTR, (uint8 *)tx_data, rx_data, TX_FRAME_SIZE) == HAL_ERROR)) ? 1U : 0U));
    Check("NULL handle : DMA IO and control rejected",
          (uint32)(((HAL_USART_Transmit_DMA(NULL_PTR, (uint8 *)tx_data, TX_FRAME_SIZE) == HAL_ERROR) &&
                    (HAL_USART_Receive_DMA(NULL_PTR, rx_data, TX_FRAME_SIZE) == HAL_ERROR) &&
                    (HAL_USART_DMAPause(NULL_PTR) == HAL_ERROR) &&
                    (HAL_USART_DMAResume(NULL_PTR) == HAL_ERROR) &&
                    (HAL_USART_DMAStop(NULL_PTR) == HAL_ERROR)) ? 1U : 0U));
    Check("NULL handle : clock / FIFO / mode interfaces rejected",
          (uint32)(((HAL_USART_ConfigClock(NULL_PTR, &clock_init) == HAL_ERROR) &&
                    (HAL_USART_ConfigAdvFeature(NULL_PTR, &adv_init) == HAL_ERROR) &&
                    (HAL_USART_EnableFIFO(NULL_PTR) == HAL_ERROR) &&
                    (HAL_USART_DisableFIFO(NULL_PTR) == HAL_ERROR) &&
                    (HAL_USART_SetTxFIFOThreshold(NULL_PTR, USART_TXFIFO_THRESHOLD_1_2) == HAL_ERROR) &&
                    (HAL_USART_SetRxFIFOThreshold(NULL_PTR, USART_RXFIFO_THRESHOLD_1_2) == HAL_ERROR)) ? 1U : 0U));
    Check("NULL handle : slave / NSS / LIN / duplex / sampling rejected",
          (uint32)(((HAL_USART_EnableSlaveMode(NULL_PTR) == HAL_ERROR) &&
                    (HAL_USART_DisableSlaveMode(NULL_PTR) == HAL_ERROR) &&
                    (HAL_USART_ConfigNSS(NULL_PTR, USART_NSS_HARDWARE) == HAL_ERROR) &&
                    (HAL_USART_LINCmd(NULL_PTR, ENABLE) == HAL_ERROR) &&
                    (HAL_USART_LINBreakDetectLengthConfig(NULL_PTR, USART_LINBREAKDETECTLENGTH_11B) == HAL_ERROR) &&
                    (HAL_USART_HalfDuplexCmd(NULL_PTR, ENABLE) == HAL_ERROR) &&
                    (HAL_USART_OneBitMethodCmd(NULL_PTR, ENABLE) == HAL_ERROR)) ? 1U : 0U));
    Check("NULL handle : break / autobaud / flush rejected",
          (uint32)(((HAL_USART_SendBreak(NULL_PTR) == HAL_ERROR) &&
                    (HAL_USART_AutoBaudRateRequest(NULL_PTR) == HAL_ERROR) &&
                    (HAL_USART_RxDataFlush(NULL_PTR) == HAL_ERROR) &&
                    (HAL_USART_TxDataFlush(NULL_PTR) == HAL_ERROR)) ? 1U : 0U));
    Check("NULL handle : GetState = RESET, GetError = NONE, not valid",
          (uint32)(((HAL_USART_GetState(NULL_PTR) == HAL_USART_STATE_RESET) &&
                    (HAL_USART_GetError(NULL_PTR) == HAL_USART_ERROR_NONE) &&
                    (USART_HandleIsValid(NULL_PTR) == 0U)) ? 1U : 0U));

    /* ---------------- Group 4: run time parameter check ---------------- */
    HAL_USART_StructInit(&usart_init);
    usart_init.Size = sizeof(USART_InitTypeDef) + 4U;
    husart_bad.Init = usart_init;
    Check("parameter check : wrong Size is rejected",
          (uint32)((HAL_USART_Init(&husart_bad) == HAL_ERROR) ? 1U : 0U));
    Check("parameter check : INVALID_PARAM is reported",
          (uint32)(((HAL_USART_GetError(&husart_bad) & HAL_USART_ERROR_INVALID_PARAM) != 0U) ? 1U : 0U));

    HAL_USART_StructInit(&usart_init);
    usart_init.BaudRate = 0U;
    husart_bad.Init = usart_init;
    Check("parameter check : zero baud rate is rejected",
          (uint32)((HAL_USART_Init(&husart_bad) == HAL_ERROR) ? 1U : 0U));

    HAL_USART_StructInit(&usart_init);
    usart_init.Version = 0xFFFFU;
    husart_bad.Init = usart_init;
    Check("parameter check : unknown structure version is rejected",
          (uint32)((HAL_USART_Init(&husart_bad) == HAL_ERROR) ? 1U : 0U));

    HAL_USART_StructInit(&usart_init);
    usart_init.BaudRate = TEST_BAUD_RATE;
    usart_init.Reserved[0] = 1U;
    husart_bad.Init = usart_init;
    Check("parameter check : non zero reserved word is rejected",
          (uint32)((HAL_USART_Init(&husart_bad) == HAL_ERROR) ? 1U : 0U));
    Check("parameter check : the rejected handle stayed uninitialized",
          (uint32)((HAL_USART_GetState(&husart_bad) == HAL_USART_STATE_RESET) ? 1U : 0U));

    /* ---------------- Group 5: FIFO mode and thresholds ---------------- */
    Check("DisableFIFO : CR1.FIFOEN cleared",
          (uint32)(((HAL_USART_DisableFIFO(&husart_dev) == HAL_OK) &&
                    ((TEST_USART->CR1 & (uint32)USART_CR1_FIFOEN) == 0U)) ? 1U : 0U));
    Check("EnableFIFO : CR1.FIFOEN set",
          (uint32)(((HAL_USART_EnableFIFO(&husart_dev) == HAL_OK) &&
                    ((TEST_USART->CR1 & (uint32)USART_CR1_FIFOEN) != 0U)) ? 1U : 0U));
    Check("SetTxFIFOThreshold : 7/8 stored in CR3",
          (uint32)(((HAL_USART_SetTxFIFOThreshold(&husart_dev, USART_TXFIFO_THRESHOLD_7_8) == HAL_OK) &&
                    ((TEST_USART->CR3 & (uint32)0x1C000000U) == (uint32)USART_TXFIFO_THRESHOLD_7_8)) ? 1U : 0U));
    Check("SetRxFIFOThreshold : 3/4 stored in CR3",
          (uint32)(((HAL_USART_SetRxFIFOThreshold(&husart_dev, USART_RXFIFO_THRESHOLD_3_4) == HAL_OK) &&
                    ((TEST_USART->CR3 & (uint32)0x00C00000U) == (uint32)USART_RXFIFO_THRESHOLD_3_4)) ? 1U : 0U));

    /* ---------------- Group 6: NSS, LIN, duplex, sampling -------------- */
    Check("ConfigNSS : software NSS sets CR2.DIS_NSS",
          (uint32)(((HAL_USART_ConfigNSS(&husart_dev, USART_NSS_SOFTWARE) == HAL_OK) &&
                    ((TEST_USART->CR2 & (uint32)USART_CR2_DIS_NSS) != 0U)) ? 1U : 0U));
    Check("ConfigNSS : hardware NSS clears CR2.DIS_NSS",
          (uint32)(((HAL_USART_ConfigNSS(&husart_dev, USART_NSS_HARDWARE) == HAL_OK) &&
                    ((TEST_USART->CR2 & (uint32)USART_CR2_DIS_NSS) == 0U)) ? 1U : 0U));
    Check("LINBreakDetectLengthConfig : 14 bit break stored in CR2",
          (uint32)(((HAL_USART_LINBreakDetectLengthConfig(&husart_dev, USART_LINBREAKDETECTLENGTH_14B) == HAL_OK) &&
                    ((TEST_USART->CR2 & (uint32)USART_CR2_BKNUM) == (uint32)USART_LINBREAKDETECTLENGTH_14B)) ? 1U : 0U));
    Check("LINCmd : CR2.LINEN follows the request",
          (uint32)(((HAL_USART_LINCmd(&husart_dev, ENABLE) == HAL_OK) &&
                    ((TEST_USART->CR2 & (uint32)USART_CR2_LINEN) != 0U)) ? 1U : 0U));
    Check("LINCmd : LINEN is cleared again",
          (uint32)(((HAL_USART_LINCmd(&husart_dev, DISABLE) == HAL_OK) &&
                    ((TEST_USART->CR2 & (uint32)USART_CR2_LINEN) == 0U)) ? 1U : 0U));
    Check("HalfDuplexCmd : CR3.HDSEL follows the request",
          (uint32)(((HAL_USART_HalfDuplexCmd(&husart_dev, ENABLE) == HAL_OK) &&
                    ((TEST_USART->CR3 & (uint32)USART_CR3_HDSEL) != 0U)) ? 1U : 0U));
    Check("HalfDuplexCmd : HDSEL is cleared again",
          (uint32)(((HAL_USART_HalfDuplexCmd(&husart_dev, DISABLE) == HAL_OK) &&
                    ((TEST_USART->CR3 & (uint32)USART_CR3_HDSEL) == 0U)) ? 1U : 0U));
    Check("OneBitMethodCmd : CR3.ONEBIT follows the request",
          (uint32)(((HAL_USART_OneBitMethodCmd(&husart_dev, ENABLE) == HAL_OK) &&
                    ((TEST_USART->CR3 & (uint32)USART_CR3_ONEBIT) != 0U)) ? 1U : 0U));
    Check("OneBitMethodCmd : ONEBIT is cleared again",
          (uint32)(((HAL_USART_OneBitMethodCmd(&husart_dev, DISABLE) == HAL_OK) &&
                    ((TEST_USART->CR3 & (uint32)USART_CR3_ONEBIT) == 0U)) ? 1U : 0U));

    /* ---------------- Group 7: requests and clock ---------------------- */
    Check("SendBreak : request accepted",
          (uint32)((HAL_USART_SendBreak(&husart_dev) == HAL_OK) ? 1U : 0U));
    Check("AutoBaudRateRequest : request accepted",
          (uint32)((HAL_USART_AutoBaudRateRequest(&husart_dev) == HAL_OK) ? 1U : 0U));
    Check("RxDataFlush / TxDataFlush : requests accepted",
          (uint32)(((HAL_USART_RxDataFlush(&husart_dev) == HAL_OK) &&
                    (HAL_USART_TxDataFlush(&husart_dev) == HAL_OK)) ? 1U : 0U));

    HAL_USART_ClockStructInit(&clock_init);
    clock_init.Clock   = USART_CLOCK_ENABLE;
    clock_init.CPOL    = USART_POLARITY_HIGH;
    clock_init.CPHA    = USART_PHASE_2EDGE;
    clock_init.LastBit = USART_LASTBIT_ENABLE;
    Check("ConfigClock : CLKEN + CPOL + CPHA + LBCL programmed",
          (uint32)(((HAL_USART_ConfigClock(&husart_dev, &clock_init) == HAL_OK) &&
                    ((TEST_USART->CR2 & (uint32)(USART_CR2_CLKEN | USART_CR2_CPOL | USART_CR2_CPHA | USART_CR2_LBCL)) ==
                     (uint32)(USART_CLOCK_ENABLE | USART_POLARITY_HIGH | USART_PHASE_2EDGE | USART_LASTBIT_ENABLE))) ? 1U : 0U));
    clock_init.Clock   = USART_CLOCK_DISABLE;
    clock_init.CPOL    = USART_POLARITY_LOW;
    clock_init.CPHA    = USART_PHASE_1EDGE;
    clock_init.LastBit = USART_LASTBIT_DISABLE;
    Check("ConfigClock : the clock is disabled again",
          (uint32)(((HAL_USART_ConfigClock(&husart_dev, &clock_init) == HAL_OK) &&
                    ((TEST_USART->CR2 & (uint32)USART_CR2_CLKEN) == 0U)) ? 1U : 0U));

    /* ---------------- Group 8: slave mode ----------------------------- */
    Check("EnableSlaveMode : CR2.SLVEN set",
          (uint32)(((HAL_USART_EnableSlaveMode(&husart_dev) == HAL_OK) &&
                    ((TEST_USART->CR2 & (uint32)USART_CR2_SLVEN) != 0U)) ? 1U : 0U));
    Check("DisableSlaveMode : CR2.SLVEN cleared",
          (uint32)(((HAL_USART_DisableSlaveMode(&husart_dev) == HAL_OK) &&
                    ((TEST_USART->CR2 & (uint32)USART_CR2_SLVEN) == 0U)) ? 1U : 0U));

    /* ---------------- Group 9: advanced features ---------------------- */
    __HAL_CLEAR_STRUCT(&adv_init);
    adv_init.AdvFeatureInit   = USART_ADVFEATURE_MSBFIRST_INIT;
    adv_init.MSBFirst         = USART_ADVFEATURE_MSBFIRST_ENABLE;
    Check("ConfigAdvFeature : MSB first sets CR2.MSBFIRST",
          (uint32)(((HAL_USART_ConfigAdvFeature(&husart_dev, &adv_init) == HAL_OK) &&
                    ((TEST_USART->CR2 & (uint32)USART_CR2_MSBFIRST) != 0U)) ? 1U : 0U));
    adv_init.MSBFirst = USART_ADVFEATURE_MSBFIRST_DISABLE;
    Check("ConfigAdvFeature : MSB first is cleared again",
          (uint32)(((HAL_USART_ConfigAdvFeature(&husart_dev, &adv_init) == HAL_OK) &&
                    ((TEST_USART->CR2 & (uint32)USART_CR2_MSBFIRST) == 0U)) ? 1U : 0U));

    /* ---------------- Group 10: full duplex DMA + pause/resume/stop ---- */
    DMA_Config();
    husart_dev.hdmatx = &hdma_dev;
    husart_dev.hdmarx = &hdma_dev2;
    Check("TransmitReceive_DMA accepted",
          (uint32)((HAL_USART_TransmitReceive_DMA(&husart_dev, (uint8 *)tx_data, rx_data,
                                                  TX_FRAME_SIZE) == HAL_OK) ? 1U : 0U));
    Check("DMAPause accepted while the DMA transfer is armed",
          (uint32)((HAL_USART_DMAPause(&husart_dev) == HAL_OK) ? 1U : 0U));
    Check("DMAResume accepted after the pause",
          (uint32)((HAL_USART_DMAResume(&husart_dev) == HAL_OK) ? 1U : 0U));
    Check("DMAStop accepted and the handle is back to READY",
          (uint32)(((HAL_USART_DMAStop(&husart_dev) == HAL_OK) &&
                    (HAL_USART_GetState(&husart_dev) == HAL_USART_STATE_READY)) ? 1U : 0U));

    /* ---------------- Group 11: MSP callbacks and version -------------- */
    Check("MspInit was invoked once for the device under test",
          (uint32)((msp_init_count == 1U) ? 1U : 0U));
    Check("MspInit sampled a handle in the RESET state (MSP-04)",
          (uint32)((msp_state_at_init == (uint32)HAL_USART_STATE_RESET) ? 1U : 0U));
    printf("MSP callbacks   : init = %u (state %u), deinit = %u\r\n",
           PRINT_U32(msp_init_count), PRINT_U32(msp_state_at_init), PRINT_U32(msp_deinit_count));

    /* The prelude de-initializes the (not yet initialized) handle once, so the
     * counter is compared against the value captured just before the call. */
    msp_deinit_baseline = msp_deinit_count;
    Check("DeInit is accepted",
          (uint32)((HAL_USART_DeInit(&husart_dev) == HAL_OK) ? 1U : 0U));
    Check("MspDeInit was invoked once by DeInit",
          (uint32)((msp_deinit_count == (msp_deinit_baseline + 1U)) ? 1U : 0U));
    Check("state after DeInit is RESET",
          (uint32)((HAL_USART_GetState(&husart_dev) == HAL_USART_STATE_RESET) ? 1U : 0U));
    Check("module version macro matches the driver",
          (uint32)((__HAL_USART_MODULE_VERSION == 0x0100U) ? 1U : 0U));

    /* ---------------- Group 12: validation macro family ---------------- */
    Check("validation macros : accepted values",
          (uint32)((IS_USART_ALL_PERIPH(TEST_USART) &&
                    IS_USART_BAUDRATE(115200U) &&
                    IS_USART_WORD_LENGTH(USART_WORDLENGTH_8B) &&
                    IS_USART_STOPBITS(USART_STOPBITS_1) &&
                    IS_USART_PARITY(USART_PARITY_NONE) &&
                    IS_USART_MODE(USART_MODE_TX_RX) &&
                    IS_USART_OVERSAMPLING(USART_OVERSAMPLING_16) &&
                    IS_USART_HARDWARE_FLOW_CONTROL(USART_HWCONTROL_NONE) &&
                    IS_USART_POLARITY(USART_POLARITY_LOW) &&
                    IS_USART_PHASE(USART_PHASE_1EDGE) &&
                    IS_USART_LASTBIT(USART_LASTBIT_DISABLE) &&
                    IS_USART_CLOCK(USART_CLOCK_ENABLE) &&
                    IS_USART_BRR_DIVIDER(195U)) ? 1U : 0U));
    Check("validation macros : rejected values",
          (uint32)(((IS_USART_BAUDRATE(0U) == 0U) &&
                    (IS_USART_PARITY(0x10U) == 0U) &&
                    (IS_USART_STOPBITS(0x20U) == 0U) &&
                    (IS_USART_BRR_DIVIDER(0U) == 0U)) ? 1U : 0U));

    /* Leave the peripheral in a clean, idle state and report the result. The
     * case is self contained, so it is replayed by resetting the board (or by
     * re-running it): the loop below only keeps the console alive. */
    Restore_Setup();
    Summary();

    while (1)
    {
        delay_ms(2000);
        printf("USART_IT_DRV_043 : all API groups finished, failures = %u\r\n",
               PRINT_U32(check_failures));
    }
}

/**
 * @brief  Report the result of one check.
 * @param  name: short description of the check.
 * @param  condition: 0 = FAIL, non zero = PASS.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("%-44s : [PASS]\r\n", name);
    }
    else
    {
        check_failures++;
        printf("%-44s : [FAIL]\r\n", name);
    }
}

/**
 * @brief  Print the accumulated failure counter.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("summary : failures = %u\r\n", PRINT_U32(check_failures));
}
/**
 * @brief  Configure the PLIC source(s) of this case.
 * @param  None
 * @retval None
 */
static void USART_PLIC_Init(void)
{
    PLIC_InitTypeDef plic;

    __HAL_SMU_PLIC_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&plic);
    plic.Size               = sizeof(plic);
    plic.Version            = PLIC_INIT_VERSION;
    plic.PLIC_IRQPriority   = 1U;
    plic.PLIC_IRQChannelCmd = ENABLE;

    plic.PLIC_IRQChannel    = TEST_USART_IRQn;
    HAL_PLIC_Init(&plic);

    /* The DMA controller raises its own interrupt line */
    plic.PLIC_IRQChannel    = DMA1_IRQn;
    HAL_PLIC_Init(&plic);

}

/**
 * @brief  Map and configure the pins of the device under test.
 * @note   The ports are the ones the original test case uses. GPIOH lives in
 *         the always on domain, so the library provides no clock gate for it.
 * @param  None
 * @retval None
 */
static void USART_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    /* Port clock gates used by this case */
    __HAL_SMU_GPIOA_CLK_ENABLE();

    /* TX pin: alternate function push pull */
    HAL_GPIO_PinAFConfig(TEST_TX_PORT, TEST_TX_SOURCE, TEST_TX_AF);
    __HAL_CLEAR_STRUCT(&GPIO_InitStruct);
    GPIO_InitStruct.Size         = sizeof(GPIO_InitStruct);
    GPIO_InitStruct.Version      = GPIO_INIT_VERSION;
    GPIO_InitStruct.Pin          = TEST_TX_PIN;
    GPIO_InitStruct.Mode         = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull         = GPIO_NOPULL;
    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;
    GPIO_InitStruct.Alternate    = TEST_TX_AF;
    HAL_GPIO_Init(TEST_TX_PORT, &GPIO_InitStruct);

    /* RX pin: alternate function input (floating) */
    HAL_GPIO_PinAFConfig(TEST_RX_PORT, TEST_RX_SOURCE, TEST_RX_AF);
    GPIO_InitStruct.Pin       = TEST_RX_PIN;
    GPIO_InitStruct.Mode      = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull      = GPIO_NOPULL;
    GPIO_InitStruct.Alternate = TEST_RX_AF;
    HAL_GPIO_Init(TEST_RX_PORT, &GPIO_InitStruct);

}
/**
 * @brief  USART interrupt handler (weak symbol of the trap entry).
 * @param  None
 * @retval None
 */
void TEST_USART_IRQ_HANDLER(void)
{
    HAL_USART_IRQHandler(&husart_dev);
}
/**
 * @brief  DMA controller interrupt handler (weak symbol of the trap entry).
 * @note   One line is shared by the 16 channels of the controller, so every
 *         active channel handle of the controller is served here.
 * @param  None
 * @retval None
 */
void DMA1_IRQ_Handler(void)
{
    HAL_DMA_IRQHandler(&hdma_dev);
    HAL_DMA_IRQHandler(&hdma_dev2);
}
/**
 * @brief  MSP initialization of the device under test.
 * @note   The callback counts its invocations and samples the handle state, so
 *         that the case can verify that the low level initialization runs
 *         before the handle is locked (LOCK-06) and only for a handle that is
 *         in the RESET state (MSP-04).
 * @param  husart: USART handle.
 * @retval None
 */
void HAL_USART_MspInit(USART_HandleTypeDef *husart)
{
    if (husart == NULL_PTR)
    {
        return;
    }

    if (husart->Instance == TEST_USART)
    {
        msp_init_count++;
        msp_state_at_init = (uint32)husart->State;

        /* Clock gate and reset pulse of the instance under test */
        __HAL_SMU_USART7_CLK_ENABLE();
        __HAL_SMU_USART7_FORCE_RESET();
        __HAL_SMU_USART7_RELEASE_RESET();
    }
}

/**
 * @brief  MSP de-initialization of the device under test (call counter only).
 * @param  husart: USART handle.
 * @retval None
 */
void HAL_USART_MspDeInit(USART_HandleTypeDef *husart)
{
    if (husart == NULL_PTR)
    {
        return;
    }

    if (husart->Instance == TEST_USART)
    {
        msp_deinit_count++;
    }
}

/**
 * @brief  Transmit complete callback (one of the transport callbacks of the
 *         driver that the ported cases do not reach).
 * @param  husart: USART handle.
 * @retval None
 */
void HAL_USART_TxCpltCallback(USART_HandleTypeDef *husart)
{
    if (husart == &husart_dev)
    {
        tx_cplt_count++;
    }
}

/**
 * @brief  Transmit half complete callback.
 * @param  husart: USART handle.
 * @retval None
 */
void HAL_USART_TxHalfCpltCallback(USART_HandleTypeDef *husart)
{
    if (husart == &husart_dev)
    {
        tx_half_count++;
    }
}

/**
 * @brief  Receive complete callback.
 * @param  husart: USART handle.
 * @retval None
 */
void HAL_USART_RxCpltCallback(USART_HandleTypeDef *husart)
{
    if (husart == &husart_dev)
    {
        rx_cplt_count++;
    }
}

/**
 * @brief  Receive half complete callback.
 * @param  husart: USART handle.
 * @retval None
 */
void HAL_USART_RxHalfCpltCallback(USART_HandleTypeDef *husart)
{
    if (husart == &husart_dev)
    {
        rx_half_count++;
    }
}

/**
 * @brief  Full duplex transfer complete callback.
 * @param  husart: USART handle.
 * @retval None
 */
void HAL_USART_TxRxCpltCallback(USART_HandleTypeDef *husart)
{
    if (husart == &husart_dev)
    {
        txrx_cplt_count++;
    }
}

/**
 * @brief  Error callback.
 * @param  husart: USART handle.
 * @retval None
 */
void HAL_USART_ErrorCallback(USART_HandleTypeDef *husart)
{
    if (husart == &husart_dev)
    {
        error_count++;
    }
}

/**
 * @brief  Program the two DMA channels used by the full duplex DMA group.
 * @note   Channel 0 moves the frame from the memory to the transmit register,
 *         channel 1 moves the received bytes to the memory. Both channels are
 *         routed to the request number of the USART (HAL_DMA_ConfigPeriphIF).
 * @param  None
 * @retval None
 */
static void DMA_Config(void)
{
    DMA_InitTypeDef dma_init;

    /* DMA controller clock gate and reset pulse */
    __HAL_SMU_DMA1_CLK_ENABLE();
    __HAL_SMU_DMA1_FORCE_RESET();
    __HAL_SMU_DMA1_RELEASE_RESET();

    /* Channel 0: memory -> USART transmit register */
    __HAL_CLEAR_STRUCT(&hdma_dev);
    hdma_dev.Instance = DMA1_Channel0;

    HAL_DMA_StructInit(&dma_init);
    dma_init.DMA_PeripheralBaseAddr = (uint32)&TEST_USART->TDR;
    dma_init.DMA_MemoryBaseAddr     = (uint32)tx_data;
    dma_init.DMA_DIR                = DMA_MEMORY_TO_PERIPH;
    dma_init.DMA_BufferSize         = TX_FRAME_SIZE;
    dma_init.DMA_PeripheralInc      = DMA_PINC_DISABLE;
    dma_init.DMA_MemoryInc          = DMA_MINC_ENABLE;
    dma_init.DMA_PeripheralDataSize = DMA_PDATAALIGN_BYTE;
    dma_init.DMA_MemoryDataSize     = DMA_MDATAALIGN_BYTE;
    dma_init.DMA_Priority           = DMA_PRIORITY_MEDIUM;
    dma_init.DMA_M2M                = DMA_M2M_Disable;
    dma_init.DMA_Mode               = DMA_NORMAL;
    hdma_dev.Init = dma_init;

    Check("HAL_DMA_Init (transmit channel)",
          (uint32)((HAL_DMA_Init(&hdma_dev) == HAL_OK) ? 1U : 0U));
    HAL_DMA_ConfigPeriphIF(&hdma_dev, USART7_IF);

    /* Channel 1: USART receive register -> memory */
    __HAL_CLEAR_STRUCT(&hdma_dev2);
    hdma_dev2.Instance = DMA1_Channel1;

    HAL_DMA_StructInit(&dma_init);
    dma_init.DMA_PeripheralBaseAddr = (uint32)&TEST_USART->RDR;
    dma_init.DMA_MemoryBaseAddr     = (uint32)rx_data;
    dma_init.DMA_DIR                = DMA_PERIPH_TO_MEMORY;
    dma_init.DMA_BufferSize         = TX_FRAME_SIZE;
    dma_init.DMA_PeripheralInc      = DMA_PINC_DISABLE;
    dma_init.DMA_MemoryInc          = DMA_MINC_ENABLE;
    dma_init.DMA_PeripheralDataSize = DMA_PDATAALIGN_BYTE;
    dma_init.DMA_MemoryDataSize     = DMA_MDATAALIGN_BYTE;
    dma_init.DMA_Priority           = DMA_PRIORITY_MEDIUM;
    dma_init.DMA_M2M                = DMA_M2M_Disable;
    dma_init.DMA_Mode               = DMA_NORMAL;
    hdma_dev2.Init = dma_init;

    Check("HAL_DMA_Init (receive channel)",
          (uint32)((HAL_DMA_Init(&hdma_dev2) == HAL_OK) ? 1U : 0U));
    HAL_DMA_ConfigPeriphIF(&hdma_dev2, USART7_IF);
}

/**
 * @brief  Leave the peripheral in the normal, idle 8N1 state.
 * @param  None
 * @retval None
 */
static void Restore_Setup(void)
{
    USART_InitTypeDef usart_init;

    (void)HAL_USART_DeInit(&husart_dev);

    HAL_USART_StructInit(&usart_init);
    usart_init.BaudRate = TEST_BAUD_RATE;
    husart_dev.Instance = TEST_USART;
    husart_dev.Init     = usart_init;

    (void)HAL_USART_Init(&husart_dev);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the CLINT / CMU / MPU integration tests: PLL
 *         VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2, CANX2 by 8.
 *         With this tree the APB bus clock is 22.5 MHz, which is the reference
 *         the baud rate divider check of every case is computed from.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef    SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the same set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_USART7_CLK_ENABLE();
    __HAL_SMU_USART7_FORCE_RESET();
    __HAL_SMU_USART7_RELEASE_RESET();

    /* Clock gate and reset pulse of the USART under test */
    /* Initialize the PMU before the voltage scaling calls: the LDO API is
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Clock tree order: this is the order the chip requires (and the one the
       reference test case uses):
         1. write the bus dividers while the system clock is still the power on
            source (FIRC), so that the new divider values are already in place
            when the faster clock arrives. Writing them after the switch leaves
            the buses at their reset dividers for a moment at the new core
            clock, which the core does not survive at 180 MHz.
         2. configure the PLL and switch the system clock to it. This call also
            programs the flash controller clock before the switch and update
            SystemCoreClock afterwards. */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
