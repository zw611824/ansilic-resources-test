/**
 * @file    RTC_IT_DRV_009.c
 * @brief   HAL RTC integration test case 009: one-shot alarm interrupt, disable and re-arm.
 *
 * The alarm is programmed a few seconds ahead with the time of day and the date
 * compared, so the match instant is unique: the interrupt fires on that instant
 * only, never again. The case then disables the interrupt from the software (macro
 * level), verifies that the event counter stops, and re-arms the alarm to prove
 * that the interrupt can be enabled again.
 *
 * Tested functionality:
 *   HAL_RTC_SetAlarm_IT() / HAL_RTC_GetAlarm()
 *   HAL_RTC_AlarmIRQHandler() / HAL_RTC_AlarmEventCallback()
 *   HAL_RTC_GetState() / HAL_RTC_GetError()
 *   HAL_RTC_Cmd() / HAL_RTC_SetTime() / HAL_RTC_SetDate() / HAL_RTC_GetTime()
 *   __HAL_RTC_DISABLE_IT() / __HAL_RTC_ENABLE_IT()
 *   HAL_PLIC_Init() (RTC alarm interrupt line)
 *
 * Expected behaviour:
 *   - the alarm fires on its match instant, and the instant does not repeat (the
 *     comparison set contains the date). The alarm of this device is level type
 *     (SRS RTC-REQ-023), so the one match instant produces a burst of callbacks
 *     whose length is bounded by the one tenth of a second match window: the case
 *     verifies that the burst stops instead of expecting a single callback;
 *   - the callback sees the flag cleared by the driver, the calendar has moved past
 *     the alarm instant and the handle is still READY;
 *   - with the interrupt disabled no further event is reported, and after a new
 *     SetAlarm_IT the next event arrives.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* RTC divider coefficient. 1785 is the project baseline of the reference test
 * cases of this chip, 1638 is the other value documented by the library SRS;
 * both are legal hardware values (the driver only checks the 27 bit field
 * width). No test below depends on the resulting absolute frequency: the
 * checks are register read-backs or "the counter moved" observations. */
#define TEST_RTC_DIVISION           (1785U)

/* Calendar value used by the cases that need a known starting point */
#define TEST_TIME_HOURS             (15U)
#define TEST_TIME_MINUTES           (48U)
#define TEST_TIME_SECONDS           (0U)
#define TEST_TIME_TOS               (0U)
#define TEST_DATE_CENTURY           (20U)
#define TEST_DATE_YEAR              (25U)
#define TEST_DATE_MONTH             (RTC_Month_July)
#define TEST_DATE_DATE              (21U)
#define TEST_DATE_WEEKDAY           (RTC_Weekday_Monday)

/* Polling slice of the wait loops (ms) */
#define TEST_POLL_MS                (10U)

/* Reporting period of the final idle loop (ms) */
#define TEST_IDLE_MS                (1000U)

/* Alarm offset of this case (s) and observation windows (ms) */
#define TEST_ALARM_OFFSET_S         (3U)
#define TEST_EVENT_TIMEOUT_MS       (8000U)
#define TEST_REPEAT_MS              (3000U)
#define TEST_QUIET_MS               (500U)

/* Settle time of the event burst. The alarm of this device is level type and
 * the comparison set of this case resolves to one tenth of a second, which is
 * the window during which CR.ALRMT is re-asserted after every clear the driver
 * performs; the burst must have stopped once that window has passed twice. */
#define TEST_SETTLE_MS              (300U)

/* Private variables ---------------------------------------------------------*/
static RTC_HandleTypeDef hrtc_dev;          /*!< RTC device handle            */
static RTC_InitTypeDef   rtc_init;          /*!< RTC configuration structure  */
static uint32            failures = 0U;     /*!< failed checks                */

/* Alarm interrupt bookkeeping (filled by the overridden weak callback) */
static volatile uint32   alarm_events = 0U; /*!< callback entries             */
static volatile uint32   alarm_cr_seen = 0U;/*!< CR register at callback time */

/* Bookkeeping of this case */
static uint32          elapsed;
static uint32          burst_settled;
static uint8           alarm_second;
static RTC_AlarmTypeDef alarm;

/* Last calendar read back by the report helpers */
static uint8 r_time_hours;
static uint8 r_time_minutes;
static uint8 r_time_seconds;
static uint8 r_time_tos;
static uint8 r_date_century;
static uint8 r_date_year;
static uint8 r_date_month;
static uint8 r_date_date;
static uint8 r_date_weekday;

/* Private function prototypes -----------------------------------------------*/
static void Check(const char *name, uint32 condition);
static void SystemClock_Init(void);
static HAL_StatusTypeDef Rtc_SetAlarmAhead(void);
static HAL_StatusTypeDef Rtc_SetAlarmHourOnly(void);
static void Rtc_Handle_Setup(void);
static HAL_StatusTypeDef Rtc_Start(void);
static HAL_StatusTypeDef Rtc_SetCalendar(uint8 hours, uint8 minutes, uint8 seconds, uint8 tos,
                                         uint8 century, uint8 year, uint8 month, uint8 date,
                                         uint8 weekday);
static HAL_StatusTypeDef Rtc_GetCalendar(void);
static uint8 Rtc_MonthToNumber(uint8 month);
static const char *Rtc_WeekdayName(uint8 weekday);
static void Rtc_PrintCalendar(const char *tag);
static void Plc_RouteRtcIrq(void);

/* Exported interrupt entry ------------------------------------------------*/
/**
 * @brief  RTC interrupt entry, called by the shared PLIC dispatch table.
 * @note   Overrides the weak RTC_IRQ_Handler() of the PLIC driver; it hands the
 *         event to the HAL RTC interrupt handler, which clears the alarm flag
 *         and then calls HAL_RTC_AlarmEventCallback().
 */
void RTC_IRQ_Handler(void)
{
    HAL_RTC_AlarmIRQHandler(&hrtc_dev);
}

/**
 * @brief  Alarm event callback (weak function of the HAL RTC driver).
 * @note   Counts the events and snapshots CR so that the cases can observe the
 *         flag state the driver left behind. It must not block and must not
 *         call a locking RTC interface (interrupt context).
 * @param  hrtc pointer to a RTC_HandleTypeDef structure.
 * @retval None
 */
void HAL_RTC_AlarmEventCallback(RTC_HandleTypeDef *hrtc)
{
    UNUSED(hrtc);

    alarm_events++;
    alarm_cr_seen = hrtc_dev.Instance->CR;
}

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock tree */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n\r\n==== RTC_IT_DRV_009: one-shot alarm interrupt, disable and re-arm ====\r\n");
    printf("Data : %s\r\n", __DATE__);
    printf("Time : %s\r\n", __TIME__);

        /* ---- Step 1: initialization --------------------------------------- */
        Plc_RouteRtcIrq();
        Check("RTC init", (Rtc_Start() == HAL_OK));
        Check("calendar programmed",
              (Rtc_SetCalendar(TEST_TIME_HOURS, TEST_TIME_MINUTES, TEST_TIME_SECONDS,
                               TEST_TIME_TOS, TEST_DATE_CENTURY, TEST_DATE_YEAR,
                               TEST_DATE_MONTH, TEST_DATE_DATE,
                               TEST_DATE_WEEKDAY) == HAL_OK));
        Check("calendar enabled", (HAL_RTC_Cmd(&hrtc_dev, ENABLE) == HAL_OK));

        /* ---- Step 2: one-shot alarm a few seconds ahead -------------------- */
        (void)Rtc_GetCalendar();
        Check("alarm programmed (one-shot, date compared)",
              (Rtc_SetAlarmAhead() == HAL_OK));
        printf("alarm set to %02u:%02u:%02u.%u of the same day\r\n",
               PRINT_U32(r_time_hours), PRINT_U32(r_time_minutes),
               PRINT_U32(alarm_second), PRINT_U32(r_time_tos));

        elapsed = 0U;
        while ((alarm_events == 0U) && (elapsed < TEST_EVENT_TIMEOUT_MS))
        {
            delay_ms(TEST_POLL_MS);
            elapsed += TEST_POLL_MS;
        }
        printf("alarm events = %u after %u ms\r\n",
               PRINT_U32(alarm_events), PRINT_U32(elapsed));
        Check("alarm interrupt fired", (alarm_events > 0U));
        /* The alarm of this device is level type (SRS RTC-REQ-023): while the
           comparison set matches - one tenth of a second, the resolution of the
           set - every clear of CR.ALRMT is followed by a new assertion, so one
           match instant makes the callback run many times. What makes this
           alarm a one-shot is that the instant itself does not repeat, which is
           verified by the burst having stopped and never restarting. */
        delay_ms(TEST_SETTLE_MS);
        burst_settled = alarm_events;
        delay_ms(TEST_SETTLE_MS);
        printf("alarm burst = %u events, stopped at %u\r\n",
               PRINT_U32(burst_settled), PRINT_U32(alarm_events));
        Check("one match instant makes a bounded burst", (alarm_events == burst_settled));
        Check("driver cleared the flag before the callback",
              ((alarm_cr_seen & RTC_CR_ALRMT) == 0U));
        Check("driver kept the interrupt enabled",
              ((alarm_cr_seen & RTC_CR_IE) != 0U));
        Check("handle READY after the event",
              (HAL_RTC_GetState(&hrtc_dev) == HAL_RTC_STATE_READY));
        Check("no error reported by the event", (HAL_RTC_GetError(&hrtc_dev) == HAL_RTC_ERROR_NONE));

        /* ---- Step 3: no repeat (the comparison set contains the date) ------ */
        delay_ms(TEST_REPEAT_MS);
        printf("events after %u ms of quiet: %u\r\n",
               PRINT_U32(TEST_REPEAT_MS), PRINT_U32(alarm_events));
        Check("no repeat of the one-shot alarm", (alarm_events == burst_settled));

        /* ---- Step 4: the interrupt can be disabled from the software ------- */
        __HAL_RTC_DISABLE_IT(&hrtc_dev, RTC_IT_ALARM);
        Check("interrupt enable cleared", ((RTC->CR & RTC_CR_IE) == 0U));

        /* Re-arm with an always true condition (hours only) while the interrupt
           is disabled: the flag is set by the hardware but no event is
           delivered. The flag is cleared first, and the alarm is programmed with
           HAL_RTC_SetAlarm() - the interrupt form would enable CR.IE again and
           the still true match would then keep interrupting. */
        __HAL_RTC_CLEAR_FLAG(&hrtc_dev, RTC_FLAG_ALARM);
        Check("wide match armed with the interrupt disabled",
              (Rtc_SetAlarmHourOnly() == HAL_OK));
        Check("the wide match did not re-enable the interrupt",
              ((RTC->CR & RTC_CR_IE) == 0U));
        alarm_events = 0U;
        delay_ms(TEST_QUIET_MS);
        Check("no event while the interrupt is disabled", (alarm_events == 0U));
        Check("the hardware still raised the flag", ((RTC->CR & RTC_CR_ALRMT) != 0U));

        /* ---- Step 5: re-arm the one-shot alarm ----------------------------- */
        (void)Rtc_GetCalendar();
        alarm_events = 0U;
        Check("alarm re-armed",
              (Rtc_SetAlarmAhead() == HAL_OK));
        Check("re-arm consumed the pending flag", ((RTC->CR & RTC_CR_ALRMT) == 0U));

        elapsed = 0U;
        while ((alarm_events == 0U) && (elapsed < TEST_EVENT_TIMEOUT_MS))
        {
            delay_ms(TEST_POLL_MS);
            elapsed += TEST_POLL_MS;
        }
        printf("re-armed alarm events = %u after %u ms\r\n",
               PRINT_U32(alarm_events), PRINT_U32(elapsed));
        Check("re-armed alarm fired", (alarm_events > 0U));

        /* ---- Step 6: closing down ------------------------------------------ */
        /* The match window of the re-armed alarm is let pass before the flag is
           cleared: while the comparison set matches it is re-asserted. */
        delay_ms(TEST_QUIET_MS);
        __HAL_RTC_DISABLE_IT(&hrtc_dev, RTC_IT_ALARM);
        __HAL_RTC_CLEAR_FLAG(&hrtc_dev, RTC_FLAG_ALARM);
        Check("alarm interrupt disabled at the end", ((RTC->CR & RTC_CR_IE) == 0U));
        Check("alarm flag clear at the end", ((RTC->CR & RTC_CR_ALRMT) == 0U));
        Rtc_PrintCalendar("after");
    /* ---- summary ------------------------------------------------------- */
    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(failures));

    /* Idle: keep the calendar observable on the console */
    while (1)
    {
        Rtc_PrintCalendar("idle");
        delay_ms(TEST_IDLE_MS);
    }
}

/* Private functions --------------------------------------------------------*/
/**
 * @brief  Program the one-shot alarm a few seconds ahead of the current time.
 * @note   The time of day and the date are compared, so the match instant does
 *         not repeat within the test window (the handler therefore sees the
 *         event exactly once).
 * @param  None
 * @retval HAL status of the alarm configuration.
 */
static HAL_StatusTypeDef Rtc_SetAlarmAhead(void)
{
    uint32 sum;

    (void)Rtc_GetCalendar();

    sum = (uint32)r_time_seconds + (uint32)TEST_ALARM_OFFSET_S;
    alarm_second = (uint8)(sum % 60U);

    __HAL_CLEAR_STRUCT(&alarm);
    HAL_RTC_AlarmStructInit(&alarm);
    alarm.RTC_AlarmTime.RTC_Hours         = r_time_hours;
    alarm.RTC_AlarmTime.RTC_Minutes       = r_time_minutes;
    alarm.RTC_AlarmTime.RTC_Seconds       = alarm_second;
    alarm.RTC_AlarmTime.RTC_TenthOfSecond = r_time_tos;
    alarm.RTC_AlarmDate.RTC_WeekDay       = r_date_weekday;
    alarm.RTC_AlarmDate.RTC_Century       = r_date_century;
    alarm.RTC_AlarmDate.RTC_Year          = r_date_year;
    alarm.RTC_AlarmDate.RTC_Month         = r_date_month;
    alarm.RTC_AlarmDate.RTC_Date          = r_date_date;
    alarm.RTC_AlarmTimeCompEn = RTC_AlarmTime_Hours | RTC_AlarmTime_Minutes |
                                RTC_AlarmTime_Seconds | RTC_AlarmTime_TenOfSecond;
    alarm.RTC_AlarmDataCompEn = RTC_AlarmDate_Year | RTC_AlarmDate_Month |
                                RTC_AlarmDate_Date;

    return HAL_RTC_SetAlarm_IT(&hrtc_dev, &alarm, RTC_FORMAT_BIN);
}

/**
 * @brief  Arm a wide match (hours only) without touching the interrupt enable.
 * @note   The match condition stays true for the whole hour, so it must never be
 *         combined with an enabled interrupt: HAL_RTC_SetAlarm() keeps the
 *         interrupt enable at its current value (the case disables it before the
 *         call), while HAL_RTC_SetAlarm_IT() would enable it again and the still
 *         true match would keep interrupting for the rest of the hour.
 * @param  None
 * @retval HAL status of the alarm configuration.
 */
static HAL_StatusTypeDef Rtc_SetAlarmHourOnly(void)
{
    (void)Rtc_GetCalendar();

    __HAL_CLEAR_STRUCT(&alarm);
    HAL_RTC_AlarmStructInit(&alarm);
    alarm.RTC_AlarmTime.RTC_Hours         = r_time_hours;
    alarm.RTC_AlarmTime.RTC_Minutes       = r_time_minutes;
    alarm.RTC_AlarmTime.RTC_Seconds       = r_time_seconds;
    alarm.RTC_AlarmTime.RTC_TenthOfSecond = r_time_tos;
    alarm.RTC_AlarmTimeCompEn = RTC_AlarmTime_Hours;
    alarm.RTC_AlarmDataCompEn = RTC_Alarm_None;

    return HAL_RTC_SetAlarm(&hrtc_dev, &alarm, RTC_FORMAT_BIN);
}

/**
 * @brief  Prepare the RTC handle and its configuration structure.
 * @note   The configuration structure metafields (Size / Version / reserved
 *         words) are mandatory: HAL_RTC_Init() validates them at run time and
 *         rejects a structure that does not carry them.
 * @param  None
 * @retval None
 */
static void Rtc_Handle_Setup(void)
{
    __HAL_CLEAR_STRUCT(&hrtc_dev);
    hrtc_dev.Instance = RTC;

    __HAL_CLEAR_STRUCT(&rtc_init);
    rtc_init.Size     = sizeof(RTC_InitTypeDef);
    rtc_init.Version  = RTC_INIT_VERSION;
    rtc_init.Division = TEST_RTC_DIVISION;
    hrtc_dev.Init     = rtc_init;
}

/**
 * @brief  Initialize the RTC and report its state.
 * @param  None
 * @retval HAL status of the initialization.
 */
static HAL_StatusTypeDef Rtc_Start(void)
{
    HAL_StatusTypeDef status;

    Rtc_Handle_Setup();
    status = HAL_RTC_Init(&hrtc_dev);
    printf("RTC state = %u (1 = READY), error = %u\r\n",
           PRINT_U32(HAL_RTC_GetState(&hrtc_dev)),
           PRINT_U32(HAL_RTC_GetError(&hrtc_dev)));

    return status;
}

/**
 * @brief  Write the calendar (time and date) of the RTC.
 * @param  hours / minutes / seconds / tos: time fields.
 * @param  century / year / month / date / weekday: date fields.
 * @retval HAL_OK when both writes succeeded.
 */
static HAL_StatusTypeDef Rtc_SetCalendar(uint8 hours, uint8 minutes, uint8 seconds, uint8 tos,
                                         uint8 century, uint8 year, uint8 month, uint8 date,
                                         uint8 weekday)
{
    RTC_TimeTypeDef time;
    RTC_DateTypeDef dateS;
    HAL_StatusTypeDef status;

    __HAL_CLEAR_STRUCT(&time);
    __HAL_CLEAR_STRUCT(&dateS);
    HAL_RTC_TimeStructInit(&time);
    HAL_RTC_DateStructInit(&dateS);

    time.RTC_Hours         = hours;
    time.RTC_Minutes       = minutes;
    time.RTC_Seconds       = seconds;
    time.RTC_TenthOfSecond = tos;

    dateS.RTC_WeekDay = weekday;
    dateS.RTC_Century = century;
    dateS.RTC_Year    = year;
    dateS.RTC_Month   = month;
    dateS.RTC_Date    = date;

    status = HAL_RTC_SetTime(&hrtc_dev, &time, RTC_FORMAT_BIN);
    if (status == HAL_OK)
    {
        status = HAL_RTC_SetDate(&hrtc_dev, &dateS, RTC_FORMAT_BIN);
    }

    return status;
}

/**
 * @brief  Read the calendar into the report globals.
 * @param  None
 * @retval HAL status of the read (HAL_ERROR when a read was refused).
 */
static HAL_StatusTypeDef Rtc_GetCalendar(void)
{
    RTC_TimeTypeDef time;
    RTC_DateTypeDef dateS;
    HAL_StatusTypeDef status;

    __HAL_CLEAR_STRUCT(&time);
    __HAL_CLEAR_STRUCT(&dateS);

    status = HAL_RTC_GetTime(&hrtc_dev, &time, RTC_FORMAT_BIN);
    if (status == HAL_OK)
    {
        status = HAL_RTC_GetDate(&hrtc_dev, &dateS, RTC_FORMAT_BIN);
    }
    if (status != HAL_OK)
    {
        return status;
    }

    r_time_hours   = time.RTC_Hours;
    r_time_minutes = time.RTC_Minutes;
    r_time_seconds = time.RTC_Seconds;
    r_time_tos     = time.RTC_TenthOfSecond;

    r_date_century = dateS.RTC_Century;
    r_date_year    = dateS.RTC_Year;
    r_date_month   = dateS.RTC_Month;
    r_date_date    = dateS.RTC_Date;
    r_date_weekday = dateS.RTC_WeekDay;

    return HAL_OK;
}

/**
 * @brief  Translate a month constant to its number (1-12).
 * @param  month: month (RTC_Month_xxx).
 * @retval uint8: month number, or 0 when the value is unknown.
 */
static uint8 Rtc_MonthToNumber(uint8 month)
{
    uint8 result;

    switch (month)
    {
        case RTC_Month_January:   result = 1U;  break;
        case RTC_Month_February:  result = 2U;  break;
        case RTC_Month_March:     result = 3U;  break;
        case RTC_Month_April:     result = 4U;  break;
        case RTC_Month_May:       result = 5U;  break;
        case RTC_Month_June:      result = 6U;  break;
        case RTC_Month_July:      result = 7U;  break;
        case RTC_Month_August:    result = 8U;  break;
        case RTC_Month_September: result = 9U;  break;
        case RTC_Month_October:   result = 10U; break;
        case RTC_Month_November:  result = 11U; break;
        case RTC_Month_December:  result = 12U; break;
        default:                  result = 0U;  break;
    }

    return result;
}

/**
 * @brief  Translate a weekday constant to its name.
 * @param  weekday: weekday (RTC_Weekday_xxx).
 * @retval const char*: weekday name, or "?" when the value is unknown.
 */
static const char *Rtc_WeekdayName(uint8 weekday)
{
    switch (weekday)
    {
        case RTC_Weekday_Monday:    return "Monday";
        case RTC_Weekday_Tuesday:   return "Tuesday";
        case RTC_Weekday_Wednesday: return "Wednesday";
        case RTC_Weekday_Thursday:  return "Thursday";
        case RTC_Weekday_Friday:    return "Friday";
        case RTC_Weekday_Saturday:  return "Saturday";
        case RTC_Weekday_Sunday:    return "Sunday";
        default:                    return "?";
    }
}

/**
 * @brief  Read and print the calendar.
 * @param  tag: text printed in front of the value (may be NULL).
 * @retval None
 */
static void Rtc_PrintCalendar(const char *tag)
{
    if (Rtc_GetCalendar() != HAL_OK)
    {
        printf("%s calendar read refused (state = %u)\r\n",
               ((tag != NULL_PTR) ? tag : ""),
               PRINT_U32(HAL_RTC_GetState(&hrtc_dev)));
        return;
    }

    printf("%s %02u-%02u-%02u %02u:%02u:%02u.%u %s\r\n",
           ((tag != NULL_PTR) ? tag : ""),
           PRINT_U32(r_date_century), PRINT_U32(Rtc_MonthToNumber(r_date_month)),
           PRINT_U32(r_date_date), PRINT_U32(r_time_hours), PRINT_U32(r_time_minutes),
           PRINT_U32(r_time_seconds), PRINT_U32(r_time_tos),
           Rtc_WeekdayName(r_date_weekday));
}

/**
 * @brief  Route the RTC alarm interrupt line through the PLIC.
 * @note   The RTC alarm is the only interrupt source of the module; the shared
 *         trap entry dispatches it to RTC_IRQ_Handler() overridden above.
 * @param  None
 * @retval None
 */
static void Plc_RouteRtcIrq(void)
{
    PLIC_InitTypeDef plic_init;

    __HAL_CLEAR_STRUCT(&plic_init);
    plic_init.Size               = sizeof(plic_init);
    plic_init.Version            = PLIC_INIT_VERSION;
    plic_init.PLIC_IRQChannel    = RTC_IRQn;
    plic_init.PLIC_IRQPriority   = 1U;
    plic_init.PLIC_IRQChannelCmd = ENABLE;
    HAL_PLIC_Init(&plic_init);

    Check("RTC interrupt routed in the PLIC",
          (PLIC->AXI_PLIC_PRIORITY[RTC_IRQn - 1U] == 1U));
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition == 0U)
    {
        failures++;
    }
    printf("%-44s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Configure the system clock tree using the HAL SMU driver.
 * @note   Clock tree shared by every integration test suite of this library:
 *         OSC 20 MHz as the PLL source, PLLDivR = 0x04 / PLLDivN = 0x14 /
 *         PLLDivF = 0xB4 / PLLDivQ = 0x01, then AXI4Bus3 = /2, APBBus0 = /2,
 *         APBBus1 = /2 and CANX2 = /8. The bus dividers are written first and
 *         the PLL is switched in afterwards, which is the order the chip
 *         requires (see HAL_SMU_OscConfig()).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;
    HAL_SMU_HandleTypeDef hsmu_clk;

    /* Enable the bus clock gates */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* The RTC lives in the always-on APB-BusS domain: it has no clock gate of
       its own, the module switch of the configuration file is enough. */

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Bus dividers first (the system clock is still the power-on source) */
    __HAL_CLEAR_STRUCT(&SMU_ClockInitStruct);
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;
    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) and switch to it; the
       call also programs the EFLASH controller clock before the switch. */
    __HAL_CLEAR_STRUCT(&SMU_OscInitStruct);
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
