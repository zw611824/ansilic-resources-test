/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___*
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_flash.c
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.7
 * Date:   2026/10/09
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.1     split the erase / write
 *                                                       protection / ECC /
 *                                                       security functions into
 *                                                       the dedicated extended
 *                                                       driver "as32x601_hal_
 *                                                       flash_ex.c / .h"; the
 *                                                       low level command
 *                                                       helpers shared with the
 *                                                       extended driver are no
 *                                                       longer static (they are
 *                                                       declared in "as32x601_
 *                                                       hal_flash.h")
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.2     fix the issues raised
 *                                                       by the full code
 *                                                       review: ClearITPendingBit
 *                                                       now writes '=' instead
 *                                                       of '|=' to the W1C SR
 *                                                       register; Program last
 *                                                       Size wrap-around and
 *                                                       runtime address
 *                                                       alignment check;
 *                                                       GetRegion 32-bit
 *                                                       overflow check; Read
 *                                                       address alignment check;
 *                                                       Init clock frequency
 *                                                       range check (16-bit)
 *                                                       and error state set on
 *                                                       parameter failure
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.3     Read checks the ECC
 *                                                       flags right after each
 *                                                       word (last read no
 *                                                       longer skipped) and
 *                                                       reports ECC1 / ECC2
 *                                                       independently; Init
 *                                                       resets the error code
 *                                                       on entry; FLASH_StartCmd
 *                                                       and HAL_FLASH_Init
 *                                                       documentation list the
 *                                                       HAL_TIMEOUT return
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.4     HAL_FLASH_SetClock-
 *                                                       Frequency documentation
 *                                                       lists the HAL_TIMEOUT
 *                                                       return value (clock
 *                                                       switching timeout);
 *                                                       remove the external
 *                                                       reference descriptions
 *                                                       from the comments
 *     ANSILIC APPLICATION GROUP  2026/09/11     1.5     fix the polarity of the EFLASH reset
 *                                                       bit in HAL_FLASH_MspInit (the reset is
 *                                                       released by setting the bit, not by
 *                                                       clearing it)
 *     ANSILIC APPLICATION GROUP  2026/09/17     1.6     align the resource lock and the RTOS support with the architecture specification (sections 13 and 21):
 *                                                       lock the init / de-init as well (they
 *                                                       change the handle state) and lock the
 *                                                       clock frequency programming, run the MSP
 *                                                       callbacks outside the locked region
 *                                                       (LOCK-06) with the MSP init on the first
 *                                                       initialization only (MSP-04) and before
 *                                                       the first register access, document every
 *                                                       lock failure return as a path where the
 *                                                       lock is not held (LOCK-02), give the lock
 *                                                       helper a Timeout and a NULL mutex guard
 *                                                       (RTOS-11), add the ARCH-CONST-09 state gate
 *                                                       plus the busy state usage (STATE-03) and
 *                                                       the error code clearing of the start
 *                                                       operations (ARCH-CONST-10 / ERR-03);
 *                                                       factor the unlock / lock key sequences and
 *                                                       the CLKFRQ programming into Tier 3 helpers
 *                                                       so that no public API is called while the
 *                                                       lock is held (LOCK-05)
 *     ANSILIC APPLICATION GROUP  2026/10/09     1.7     restore the " *" prefix of the history
 *                                                       continuation lines
 * Description:     This file provides firmware functions to manage the
 *                  functionalities of the embedded FLASH (EFLASH)
 *                  controller of the AS32x601:
 *                  - Initialization and de-initialization;
 *                  - Peripheral control: unlock / lock, clock frequency;
 *                  - Program operation (8-byte write unit, ROM-based);
 *                  - Read operation;
 *                  - Flag and interrupt management.
 *
 *                  The extended functionalities (erase, write protection,
 *                  ECC and security) are provided by this driver.
 */
#include "as32x601_hal.h"          /* module switch from as32x601_hal_conf.h */
#include "as32x601_hal_flash.h"    /* FLASH HAL API and register macros        */

/* The HAL_FLASH_MODULE_ENABLED switch is provided by the user configuration
 * file (as32x601_hal_conf.h, included above through as32x601_hal.h): the
 * whole implementation is compiled only while the module is enabled. */
#ifdef HAL_FLASH_MODULE_ENABLED

/* Private define ------------------------------------------------------------*/

/* Maximum wait duration for the clock frequency switching, in ms */
#define FLASH_CLK_SWITCH_TIMEOUT        ((uint32)1000U)

/* Private function prototypes -----------------------------------------------*/
static HAL_StatusTypeDef FLASH_WaitForLastOperation(HAL_FLASH_HandleTypeDef *hflash, uint32 Timeout);
static void FLASH_SetDataLength(uint32 Length);
static void FLASH_SetLowData(uint32 Data);
static void FLASH_SetHighData(uint32 Data);
static HAL_StatusTypeDef FLASH_UnlockKeys(HAL_FLASH_HandleTypeDef *hflash);
static HAL_StatusTypeDef FLASH_LockKeys(HAL_FLASH_HandleTypeDef *hflash);
static HAL_StatusTypeDef FLASH_SetClockFrequencyInternal(HAL_FLASH_HandleTypeDef *hflash, uint16 ClockFreq);

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Check the handle state before a flash operation.
 * @note   ARCH-CONST-09: a handle that is busy with another operation rejects
 *         the call with HAL_BUSY, and a handle that was never initialized
 *         rejects it with HAL_ERROR (HAL_FLASH_Init() is required first).
 *         The error state is recoverable, a new operation may be called
 *         directly.
 * @note   The lock management (HAL_FLASH_Unlock / HAL_FLASH_Lock) and the
 *         clock frequency programming (HAL_FLASH_SetClockFrequency) are
 *         deliberately not gated: they are the configuration path that
 *         precedes HAL_FLASH_Init() (the chip requires CR.CLKFRQ to be
 *         programmed before the system clock is switched to its final value).
 * @note   Not static: declared in the shared internal functions section of
 *         this header, so the application may reuse the same check.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef FLASH_CheckState(HAL_FLASH_HandleTypeDef *hflash)
{
    if (hflash->State == HAL_FLASH_STATE_BUSY)
    {
        return HAL_BUSY;
    }

    if (hflash->State == HAL_FLASH_STATE_RESET)
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Write the two EFLASH unlock keys and verify the LOCK flag. (Tier 3)
 * @note   Shared by HAL_FLASH_Unlock() and HAL_FLASH_Init(). It performs the
 *         raw register sequence without taking the handle lock: the caller
 *         shall hold it.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR
 */
static HAL_StatusTypeDef FLASH_UnlockKeys(HAL_FLASH_HandleTypeDef *hflash)
{
    /* Already unlocked: nothing to do */
    if ((EFLASH->SR & FLASH_FLAG_LOCK) == 0U)
    {
        return HAL_OK;
    }

    /* Write the two unlock keys */
    EFLASH->UNLKR = FLASH_UNLOCK_KEY1;
    EFLASH->UNLKR = FLASH_UNLOCK_KEY2;

    /* Verify that the unlock sequence succeeded */
    if ((EFLASH->SR & FLASH_FLAG_LOCK) != 0U)
    {
        hflash->ErrorCode |= HAL_FLASH_ERROR_LOCK;
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Write the two inverted EFLASH keys and verify the LOCK flag. (Tier 3)
 * @note   Shared by HAL_FLASH_Lock() and HAL_FLASH_Init(). It performs the raw
 *         register sequence without taking the handle lock: the caller shall
 *         hold it.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR
 */
static HAL_StatusTypeDef FLASH_LockKeys(HAL_FLASH_HandleTypeDef *hflash)
{
    /* Write the inverted keys to lock the controller */
    EFLASH->UNLKR = (uint32)(~(uint32)FLASH_UNLOCK_KEY1);
    EFLASH->UNLKR = (uint32)(~(uint32)FLASH_UNLOCK_KEY2);

    /* Verify that the lock sequence succeeded */
    if ((EFLASH->SR & FLASH_FLAG_LOCK) == 0U)
    {
        hflash->ErrorCode |= HAL_FLASH_ERROR_LOCK;
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Program the EFLASH controller clock frequency (CR.CLKFRQ). (Tier 3)
 * @note   Shared by HAL_FLASH_SetClockFrequency() and HAL_FLASH_Init(). It
 *         performs the raw register sequence and the bounded CLKSWRDY wait
 *         without taking the handle lock: the caller shall hold it. The clock
 *         switch of the AS32x601 is a real hardware operation that is being
 *         waited for, hence the lock is held here on purpose (the wait is
 *         bounded by FLASH_CLK_SWITCH_TIMEOUT).
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  ClockFreq: EFLASH clock frequency in MHz.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_TIMEOUT
 */
static HAL_StatusTypeDef FLASH_SetClockFrequencyInternal(HAL_FLASH_HandleTypeDef *hflash, uint16 ClockFreq)
{
    uint32 tmpreg = 0U;
    uint32 tickstart = 0U;

    /* Wait for the controller to be idle */
    if ((EFLASH->SR & FLASH_FLAG_BUSY) != 0U)
    {
        return HAL_BUSY;
    }

    tmpreg = EFLASH->CR;

    /* Skip the update when the frequency is already programmed */
    if ((uint32)((tmpreg >> EFLASH_CR_CLKFRQ_Pos) & 0xFFFFU) == (uint32)ClockFreq)
    {
        return HAL_OK;
    }

    /* Update the CLKFRQ field */
    tmpreg &= ~((uint32)EFLASH_CR_CLKFRQ);
    tmpreg |= ((uint32)ClockFreq << EFLASH_CR_CLKFRQ_Pos);
    EFLASH->CR = tmpreg;

    /* Wait for the flash controller to complete the internal preparation.
     * ARCH/RTOS-04: let the other tasks of the same priority run instead of
     * busy waiting (empty macro in a bare-metal build) */
    tickstart = HAL_GetTick();
    while ((EFLASH->SR & FLASH_FLAG_CLKSWRDY) == 0U)
    {
        if ((HAL_GetTick() - tickstart) > FLASH_CLK_SWITCH_TIMEOUT)
        {
            hflash->ErrorCode |= HAL_FLASH_ERROR_OPERATION;
            return HAL_TIMEOUT;
        }

#if (USE_RTOS == 1)
        HAL_RTOS_Yield();
#endif /* USE_RTOS */
    }

    return HAL_OK;
}

/**
 * @brief  Check the FLASH handle and its peripheral instance.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
uint32 FLASH_HandleIsValid(const HAL_FLASH_HandleTypeDef *hflash)
{
    return ((hflash != NULL_PTR) && IS_FLASH_INSTANCE(hflash->Instance));
}

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_FLASH_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the acquisition is bounded by the Timeout parameter;
 *         HAL_MAX_DELAY waits forever.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS, wait expired) /
 *         HAL_ERROR (RTOS, mutex not created) / HAL_BUSY (bare metal, the
 *         handle is already locked).
 */
HAL_StatusTypeDef FLASH_LockHandle(HAL_FLASH_HandleTypeDef *hflash, uint32 Timeout)
{
#if (USE_RTOS == 1)
    if (hflash->LockMutex == NULL_PTR)
    {
        /* The porting layer did not create the mutex (e.g. HAL_FLASH_MspInit()
         * was not overridden): report it instead of calling the RTOS with a
         * NULL handle */
        return HAL_ERROR;
    }

    return HAL_MutexAcquire(hflash->LockMutex, Timeout);
#else
    /* Prevent unused argument compilation warning: the bare-metal lock flag
     * either succeeds immediately or reports HAL_BUSY, it never waits */
    UNUSED(Timeout);

    if (hflash->Lock == HAL_LOCKED)
    {
        return HAL_BUSY;
    }
    hflash->Lock = HAL_LOCKED;
    return HAL_OK;
#endif /* USE_RTOS */
}

/**
 * @brief  Unlock the handle.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval None
 */
void FLASH_UnlockHandle(HAL_FLASH_HandleTypeDef *hflash)
{
#if (USE_RTOS == 1)
    (void)HAL_MutexRelease(hflash->LockMutex);
#else
    hflash->Lock = HAL_UNLOCKED;
#endif /* USE_RTOS */
}

/**
 * @brief  Determine the flash region containing the [Address, Address+Length]
 *         range.
 * @param  Address: start address.
 * @param  Length: length in bytes.
 * @retval uint32: FLASH_REGION_xxx, or FLASH_REGION_INVALID when the range
 *         is not fully contained in a single flash region.
 */
uint32 FLASH_GetRegion(uint32 Address, uint32 Length)
{
    uint32 endaddr = 0U;

    /* Defensive overflow check: 'Address + Length' could wrap around and
     * be wrongly accepted as a tiny address range. All flash regions lie
     * well below 0x04000000, so a wrapped range is never a valid one. */
    if (Length > (0xFFFFFFFFU - Address))
    {
        return FLASH_REGION_INVALID;
    }
    endaddr = Address + Length;

    if ((Address >= P_FLASH_Main_BASE) && (endaddr <= (P_FLASH_Main_BASE + PFLASH_MAIN_SIZE)))
    {
        return FLASH_REGION_PFLASH_MAIN;
    }
    if ((Address >= D_FLASH_Main_BASE) && (endaddr <= (D_FLASH_Main_BASE + DFLASH_MAIN_SIZE)))
    {
        return FLASH_REGION_DFLASH_MAIN;
    }
    if ((Address >= P_FLASH_Info_BASE) && (endaddr <= (P_FLASH_Info_BASE + PFLASH_INFO_SIZE)))
    {
        return FLASH_REGION_PFLASH_INFO;
    }
    if ((Address >= D_FLASH_Info_BASE) && (endaddr <= (D_FLASH_Info_BASE + DFLASH_INFO_SIZE)))
    {
        return FLASH_REGION_DFLASH_INFO;
    }

    return FLASH_REGION_INVALID;
}

/**
 * @brief  Return the sector size (bytes) of the given flash region.
 * @note   All AS32x601 flash regions use a 4 KB sector size.
 * @param  Region: flash region (FLASH_REGION_xxx).
 * @retval uint32: sector size in bytes (0 for an invalid region).
 */
uint32 FLASH_GetSectorSize(uint32 Region)
{
    uint32 sectorsize = 0U;

    switch (Region)
    {
        case FLASH_REGION_PFLASH_MAIN:
        case FLASH_REGION_PFLASH_INFO:
            sectorsize = PFLASH_SECTOR_SIZE;
            break;

        case FLASH_REGION_DFLASH_MAIN:
        case FLASH_REGION_DFLASH_INFO:
            sectorsize = DFLASH_SECTOR_SIZE;
            break;

        default:
            sectorsize = 0U;
            break;
    }

    return sectorsize;
}

/**
 * @brief  Set the flash operation command (CIDR register).
 * @param  Cmd: operation command (FLASHCmd_TypeDef).
 * @retval None
 */
void FLASH_SetCommand(FLASHCmd_TypeDef Cmd)
{
    /* Check the parameters */
    assert_param(IS_FLASH_CMD(Cmd));

    EFLASH->CIDR = (uint32)Cmd;
}

/**
 * @brief  Set the flash operation address (AR register).
 * @param  Address: operation address.
 * @retval None
 */
void FLASH_SetAddress(uint32 Address)
{
    /* Check the parameters */
    assert_param((Address % EFLASH_WRITE_UNIT_SIZE) == 0U);

    EFLASH->AR = Address;
}

/**
 * @brief  Launch a flash command and wait for its completion.
 * @note   The command, address, data length and data must have been set
 *         beforehand (FLASH_SetCommand / FLASH_SetAddress /
 *         FLASH_SetDataLength / DR0 / DR1).
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  Timeout: maximum wait duration in ms.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY / HAL_TIMEOUT
 */
HAL_StatusTypeDef FLASH_StartCmd(HAL_FLASH_HandleTypeDef *hflash, uint32 Timeout)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Clear the command finish flag of a potential previous command */
    EFLASH->SR = FLASH_CLEAR_FINISH;

    /* A command shall not be launched while the controller is busy */
    if ((EFLASH->SR & FLASH_FLAG_BUSY) != 0U)
    {
        return HAL_BUSY;
    }

    /* Trigger the command execution */
    EFLASH->CTR = EFLASH_CTR_CTR;

    /* Wait till the FINISH flag is set, watching the error flags */
    status = FLASH_WaitForLastOperation(hflash, Timeout);

    return status;
}

/**
 * @brief  Wait for the last flash command to complete (FINISH flag) with a
 *         timeout, while checking the error flags.
 * @note   The error flags are latched into the handle ErrorCode field.
 *         When Timeout equals HAL_MAX_DELAY the wait never expires; the
 *         error flags still abort the wait as soon as they are raised.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  Timeout: maximum wait duration in ms (HAL_MAX_DELAY = infinite).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_TIMEOUT
 */
static HAL_StatusTypeDef FLASH_WaitForLastOperation(HAL_FLASH_HandleTypeDef *hflash, uint32 Timeout)
{
    uint32 tickstart = HAL_GetTick();
    uint32 sr;

    while ((EFLASH->SR & FLASH_FLAG_FINISH) == 0U)
    {
        sr = EFLASH->SR;
        if ((sr & FLASH_STATE_ERROR_BITS) != 0U)
        {
            /* Report every error flag raised by the controller */
            if ((sr & EFLASH_SR_OPERR) != 0U)
            {
                hflash->ErrorCode |= HAL_FLASH_ERROR_OPERATION;
            }
            if ((sr & EFLASH_SR_ECC1ERR) != 0U)
            {
                hflash->ErrorCode |= HAL_FLASH_ERROR_ECC1;
            }
            if ((sr & EFLASH_SR_ECC2ERR) != 0U)
            {
                hflash->ErrorCode |= HAL_FLASH_ERROR_ECC2;
            }
            if ((sr & EFLASH_SR_WPERR) != 0U)
            {
                hflash->ErrorCode |= HAL_FLASH_ERROR_WRP;
            }
            if ((sr & EFLASH_SR_SECKEYERR) != 0U)
            {
                hflash->ErrorCode |= HAL_FLASH_ERROR_SECKEY;
            }

            return HAL_ERROR;
        }

        /* Timeout check (difference based, wrap-around safe) */
        if ((HAL_GetTick() - tickstart) > Timeout)
        {
            return HAL_TIMEOUT;
        }
    }

    /* Clear the command finish flag for the next command */
    EFLASH->SR = FLASH_CLEAR_FINISH;

    return HAL_OK;
}

/**
 * @brief  Set the flash operation data length (DLR register).
 * @note   The length is expressed in 8-byte units (max EFLASH_PROGRAM_MAXLEN).
 * @param  Length: operation data length, in 8-byte units.
 * @retval None
 */
static void FLASH_SetDataLength(uint32 Length)
{
    /* Check the parameters */
    assert_param((Length > 0U) && (Length <= EFLASH_PROGRAM_MAXLEN));

    EFLASH->DLR = Length;
}

/**
 * @brief  Set the low 32-bit data register (DR0).
 * @param  Data: low 32-bit data.
 * @retval None
 */
static void FLASH_SetLowData(uint32 Data)
{
    EFLASH->DR0 = Data;
}

/**
 * @brief  Set the high 32-bit data register (DR1).
 * @param  Data: high 32-bit data.
 * @retval None
 */
static void FLASH_SetHighData(uint32 Data)
{
    EFLASH->DR1 = Data;
}

/* Exported functions --------------------------------------------------------*/

/** @addtogroup FLASH_Exported_Functions
  * @{
  */

/** @addtogroup FLASH_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Fills each FLASH_InitStruct member with its default value. (NON-BLOCKING)
 * @param  InitStruct: pointer to a FLASH_InitTypeDef structure.
 * @retval None
 */
void HAL_FLASH_StructInit(FLASH_InitTypeDef *InitStruct)
{
    /* Check the parameter */
    if (InitStruct == NULL_PTR)
    {
        return;
    }

    /* FLASH_InitStruct members default value */
    InitStruct->Size       = sizeof(FLASH_InitTypeDef);   /*!< sizeof struct */
    InitStruct->Version    = FLASH_INIT_VERSION;          /*!< V1            */
    InitStruct->ClockFreq  = 0U;   /*!< Skip the clock frequency configuration */
    InitStruct->Reserved[0] = 0U;      /*!< Reserved */
    InitStruct->Reserved[1] = 0U;      /*!< Reserved */
}

/**
 * @brief  Initializes the EFLASH controller according to the parameters in
 *         the Init field of the handle. (NON-BLOCKING)
 * @note   The low level initialization callback runs only on the first call
 *         (while the handle is in the reset state) and before the handle is
 *         locked (architecture rules MSP-04 and LOCK-06), hence the
 *         controller clock and reset are available before the first register
 *         access; an override may create an RTOS mutex and call other HAL
 *         APIs.
 * @note   The optional Init.ClockFreq programming (CR.CLKFRQ) is performed
 *         inside the same locked transaction, through the Tier 3 helpers
 *         (LOCK-05: no public API is called while the lock is held).
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_FLASH_Init(HAL_FLASH_HandleTypeDef *hflash)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the FLASH peripheral handle and instance */
    if (FLASH_HandleIsValid(hflash) == 0U)
    {
        return HAL_ERROR;
    }

    /* Reset the error code: each failure path below sets its own flag, so
     * a second HAL_FLASH_Init() call does not keep a stale error code. */
    hflash->ErrorCode = HAL_FLASH_ERROR_NONE;

    /* LOCK-06 / MSP-04: allocate the lock resource and run the low level
     * initialization BEFORE the handle is locked, and only on the first call
     * (avoid initializing the hardware twice). The MSP callback enables the
     * EFLASH clock and releases its reset, so it has to run before the first
     * register access below. */
    if (hflash->State == HAL_FLASH_STATE_RESET)
    {
        hflash->Lock = HAL_UNLOCKED;

        HAL_FLASH_MspInit(hflash);
    }

    /* The CLKFRQ field is 16-bit wide (CR register), so reject an out-of-range
     * frequency instead of silently truncating it through the uint16 cast
     * below. The check runs before the lock is taken, as a rejected parameter
     * never touches the peripheral. */
    if (hflash->Init.ClockFreq > 0xFFFFU)
    {
        hflash->ErrorCode |= HAL_FLASH_ERROR_PARAM;
        hflash->State = HAL_FLASH_STATE_ERROR;
        return HAL_ERROR;
    }

    /* Process locked */
    if (FLASH_LockHandle(hflash, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Enter the busy state while configuring the controller (STATE-03) */
    hflash->State = HAL_FLASH_STATE_BUSY;

    /* Configure the controller clock frequency when requested: the CLKFRQ
     * field shall match the AXI_Bus0 frequency and be set BEFORE the system
     * clock is switched to its final value. */
    if (hflash->Init.ClockFreq != 0U)
    {
        status = FLASH_UnlockKeys(hflash);
        if (status == HAL_OK)
        {
            status = FLASH_SetClockFrequencyInternal(hflash, (uint16)hflash->Init.ClockFreq);
        }
        (void)FLASH_LockKeys(hflash);
    }

    hflash->State = (status == HAL_OK) ? HAL_FLASH_STATE_READY : HAL_FLASH_STATE_ERROR;

    /* Release Lock */
    FLASH_UnlockHandle(hflash);

    return status;
}

/**
 * @brief  De-initializes the EFLASH controller. (NON-BLOCKING)
 * @note   The low level de-initialization callback runs after the handle lock
 *         has been released (LOCK-06), so an override may call other HAL APIs.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_FLASH_DeInit(HAL_FLASH_HandleTypeDef *hflash)
{
    /* Check the FLASH peripheral handle and instance */
    if (FLASH_HandleIsValid(hflash) == 0U)
    {
        return HAL_ERROR;
    }

    /* Process locked */
    if (FLASH_LockHandle(hflash, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state while tearing the handle
     * down (ARCH-CONST-10 / STATE-03) */
    hflash->ErrorCode = HAL_FLASH_ERROR_NONE;
    hflash->State = HAL_FLASH_STATE_BUSY;

    /* The handle goes back to the reset state so that a following
     * HAL_FLASH_Init() runs the low level initialization again */
    hflash->State = HAL_FLASH_STATE_RESET;

    /* Release Lock */
    FLASH_UnlockHandle(hflash);

    /* LOCK-06 / ARCH-CONST-04: the low level de-initialization runs OUTSIDE
     * the locked region, as the architecture specification requires for the
     * MSP callbacks ("MspDeInit is called after the unlock"). The override may
     * call other HAL APIs (e.g. HAL_GPIO_DeInit()), which is only allowed
     * while the handle lock is not held. */
    HAL_FLASH_MspDeInit(hflash);

    return HAL_OK;
}

/**
 * @brief  Initializes the FLASH MSP. Weak function; the default
 *         implementation enables the EFLASH peripheral clock and releases
 *         its reset through the SMU AB0CFGR register.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_FLASH_MspInit(HAL_FLASH_HandleTypeDef *hflash)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hflash);

    /* Enable the EFLASH peripheral clock and release the EFLASH reset: the
     * reset bit is released by SETTING it (SET = released, CLEAR = reset
     * asserted), which is also what the SMU_AB0CFGR reset value (0x0000000F,
     * EFLASHEN = 1 and EFLASHRST = 1) and
     * __HAL_SMU_EFLASH_RELEASE_RESET() assume. */
    SMU->AB0CFGR |= SMU_AB0CFGR_EFLASHEN;
    SMU->AB0CFGR |= SMU_AB0CFGR_EFLASHRST;
}

/**
 * @brief  De-initializes the FLASH MSP. Weak function; the default
 *         implementation disables the EFLASH peripheral clock.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_FLASH_MspDeInit(HAL_FLASH_HandleTypeDef *hflash)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hflash);

    /* Disable the EFLASH peripheral clock */
    SMU->AB0CFGR &= ~SMU_AB0CFGR_EFLASHEN;
}

/**
  * @}
  */

/** @addtogroup FLASH_Exported_Functions_Group2 Peripheral Control functions
  * @{
  */

/**
 * @brief  Unlocks the EFLASH controller registers. (NON-BLOCKING)
 * @note   Not gated by the handle state (ARCH-CONST-09): unlocking is part of
 *         the configuration path that may legitimately run before
 *         HAL_FLASH_Init().
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_FLASH_Unlock(HAL_FLASH_HandleTypeDef *hflash)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the FLASH peripheral handle and instance */
    if (FLASH_HandleIsValid(hflash) == 0U)
    {
        return HAL_ERROR;
    }

    /* Process locked */
    if (FLASH_LockHandle(hflash, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    status = FLASH_UnlockKeys(hflash);

    /* Release Lock */
    FLASH_UnlockHandle(hflash);

    return status;
}

/**
 * @brief  Locks the EFLASH controller registers. (NON-BLOCKING)
 * @note   Not gated by the handle state (ARCH-CONST-09): locking is part of
 *         the configuration path that may legitimately run before
 *         HAL_FLASH_Init().
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_FLASH_Lock(HAL_FLASH_HandleTypeDef *hflash)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the FLASH peripheral handle and instance */
    if (FLASH_HandleIsValid(hflash) == 0U)
    {
        return HAL_ERROR;
    }

    /* Process locked */
    if (FLASH_LockHandle(hflash, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    status = FLASH_LockKeys(hflash);

    /* Release Lock */
    FLASH_UnlockHandle(hflash);

    return status;
}

/**
 * @brief  Sets the EFLASH controller clock frequency (CR.CLKFRQ field). (BLOCKING)
 * @note   The controller is unlocked and locked again internally, the caller
 *         does not have to manage the EFLASH register lock (the function is
 *         self contained). It may be called before HAL_FLASH_Init() (the chip
 *         requires CLKFRQ to be programmed before the system clock is switched
 *         to its final value), hence it is not gated by the handle state.
 * @note   The bounded wait for the CLKSWRDY flag runs while the handle lock is
 *         held, so that no other operation can interleave with the frequency
 *         switch.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  ClockFreq: EFLASH clock frequency in MHz.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_FLASH_SetClockFrequency(HAL_FLASH_HandleTypeDef *hflash, uint16 ClockFreq)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the FLASH peripheral handle and instance */
    if (FLASH_HandleIsValid(hflash) == 0U)
    {
        return HAL_ERROR;
    }

    /* Process locked */
    if (FLASH_LockHandle(hflash, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    status = FLASH_UnlockKeys(hflash);
    if (status == HAL_OK)
    {
        status = FLASH_SetClockFrequencyInternal(hflash, ClockFreq);
    }
    (void)FLASH_LockKeys(hflash);

    /* Release Lock */
    FLASH_UnlockHandle(hflash);

    return status;
}

/**
  * @}
  */

/** @addtogroup FLASH_Exported_Functions_Group3 Programming operation functions
  * @{
  */

/**
 * @brief  Programs the specified flash region. (NON-BLOCKING)
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  Address: start address to program (8-byte aligned).
 * @param  Size: size in bytes to program (multiple of 8).
 * @param  pData: pointer to the data buffer to program.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_FLASH_Program(HAL_FLASH_HandleTypeDef *hflash, uint32 Address, uint32 Size, const uint32 *pData)
{
    HAL_StatusTypeDef status = HAL_OK;
    uint32 addrcount = 0U;
    uint32 sizetemp = 0U;
    uint32 romsize = 0U;
    uint32 region = FLASH_REGION_INVALID;
    const uint32 *pSrc = pData;

    /* Check the FLASH peripheral handle and instance */
    if (FLASH_HandleIsValid(hflash) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param((Address % EFLASH_WRITE_UNIT_SIZE) == 0U);
    assert_param((Size > 0U) && ((Size % EFLASH_WRITE_UNIT_SIZE) == 0U));
    assert_param(pData != NULL_PTR);
    if (((Address % EFLASH_WRITE_UNIT_SIZE) != 0U) ||
        (Size == 0U) || ((Size % EFLASH_WRITE_UNIT_SIZE) != 0U) || (pData == NULL_PTR))
    {
        hflash->ErrorCode |= HAL_FLASH_ERROR_PARAM;
        return HAL_ERROR;
    }

    /* Check if the controller is busy */
    if ((EFLASH->SR & FLASH_FLAG_BUSY) != 0U)
    {
        return HAL_BUSY;
    }

    /* Determine the target region and the ROM program size */
    region = FLASH_GetRegion(Address, Size);
    if (region == FLASH_REGION_INVALID)
    {
        hflash->ErrorCode |= HAL_FLASH_ERROR_ADDRESS;
        return HAL_ERROR;
    }

    if ((region == FLASH_REGION_PFLASH_MAIN) || (region == FLASH_REGION_PFLASH_INFO))
    {
        romsize = PFLASH_ROM_SIZE;
    }
    else
    {
        romsize = DFLASH_ROM_SIZE;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_FLASH_Init() is
     * required first) */
    status = FLASH_CheckState(hflash);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (FLASH_LockHandle(hflash, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* ERR-03 / ARCH-CONST-10: a start operation clears the error code */
    hflash->ErrorCode = HAL_FLASH_ERROR_NONE;
    hflash->State = HAL_FLASH_STATE_BUSY;

    /* Number of ROM-sized program commands */
    addrcount = Size / romsize;
    if ((Size % romsize) != 0U)
    {
        addrcount += 1U;
    }

    while ((status == HAL_OK) && (addrcount > 0U))
    {
        sizetemp = (Size >= romsize) ? romsize : Size;

        /* Set the address, the data length (in 8-byte units) and the
         * program command */
        FLASH_SetAddress(Address);
        FLASH_SetDataLength(sizetemp / EFLASH_WRITE_UNIT_SIZE);
        FLASH_SetCommand(FLASH_Cmd_Program);

        /* Feed the data register pair (DR0 = low, DR1 = high) with the
         * 8-byte write units */
        while (sizetemp > 0U)
        {
            FLASH_SetLowData(pSrc[0]);
            FLASH_SetHighData(pSrc[1]);
            pSrc += 2U;
            sizetemp -= EFLASH_WRITE_UNIT_SIZE;
        }

        /* Launch the command and wait for completion */
        status = FLASH_StartCmd(hflash, HAL_MAX_DELAY);

        /* Update the address and the remaining size. The last ROM-sized
         * command may be partial (Size < romsize): subtract only what is
         * really left, otherwise the uint32 counter would wrap around. */
        Address += romsize;
        Size -= (Size >= romsize) ? romsize : Size;
        addrcount--;
    }

    hflash->State = (status == HAL_OK) ? HAL_FLASH_STATE_READY : HAL_FLASH_STATE_ERROR;
    FLASH_UnlockHandle(hflash);

    return status;
}

/**
  * @}
  */

/** @addtogroup FLASH_Exported_Functions_Group4 Read operation functions
  * @{
  */

/**
 * @brief  Reads data from the specified flash region. (NON-BLOCKING)
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  Address: start address to read.
 * @param  Size: size in bytes to read (multiple of 4).
 * @param  pData: pointer to the destination buffer.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_FLASH_Read(HAL_FLASH_HandleTypeDef *hflash, uint32 Address, uint32 Size, uint32 *pData)
{
    HAL_StatusTypeDef status = HAL_OK;
    uint32 index = 0U;
    uint32 region = FLASH_REGION_INVALID;

    /* Check the FLASH peripheral handle and instance */
    if (FLASH_HandleIsValid(hflash) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param((Address % 4U) == 0U);
    assert_param((Size > 0U) && ((Size % 4U) == 0U));
    assert_param(pData != NULL_PTR);
    if (((Address % 4U) != 0U) || (Size == 0U) || ((Size % 4U) != 0U) || (pData == NULL_PTR))
    {
        hflash->ErrorCode |= HAL_FLASH_ERROR_PARAM;
        return HAL_ERROR;
    }

    /* The read range shall be fully contained in the P-Flash or D-Flash
     * main / info regions */
    region = FLASH_GetRegion(Address, Size);
    if (region == FLASH_REGION_INVALID)
    {
        hflash->ErrorCode |= HAL_FLASH_ERROR_ADDRESS;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_FLASH_Init() is
     * required first) */
    status = FLASH_CheckState(hflash);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (FLASH_LockHandle(hflash, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* ERR-03 / ARCH-CONST-10: a start operation clears the error code */
    hflash->ErrorCode = HAL_FLASH_ERROR_NONE;
    hflash->State = HAL_FLASH_STATE_BUSY;

    for (index = 0U; index < (Size / 4U); index++)
    {
        pData[index] = *((uint32 *)(Address + (index * 4U)));

        /* A read access may raise an ECC error flag: check right after each
         * read (including the last one) and report both ECC sources when
         * both are set. */
        if ((EFLASH->SR & (FLASH_FLAG_ECC1ERR | FLASH_FLAG_ECC2ERR)) != 0U)
        {
            if ((EFLASH->SR & FLASH_FLAG_ECC1ERR) != 0U)
            {
                hflash->ErrorCode |= HAL_FLASH_ERROR_ECC1;
            }
            if ((EFLASH->SR & FLASH_FLAG_ECC2ERR) != 0U)
            {
                hflash->ErrorCode |= HAL_FLASH_ERROR_ECC2;
            }
            status = HAL_ERROR;
            break;
        }
    }

    hflash->State = (status == HAL_OK) ? HAL_FLASH_STATE_READY : HAL_FLASH_STATE_ERROR;
    FLASH_UnlockHandle(hflash);

    return status;
}

/**
  * @}
  */

/** @addtogroup FLASH_Exported_Functions_Group5 Flag and interrupt management functions
  * @{
  */

/**
 * @brief  Checks whether the specified flash flag is set or not. (NON-BLOCKING)
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  FlashFlag: specifies the flag to check (FLASH_FLAG_xxx).
 * @retval FLASH_FlagStatusTypeDef: FLASH_FLAG_SET / FLASH_FLAG_RESET
 */
FLASH_FlagStatusTypeDef HAL_FLASH_GetFlagStatus(HAL_FLASH_HandleTypeDef *hflash, uint32 FlashFlag)
{
    FLASH_FlagStatusTypeDef bitstatus = FLASH_FLAG_RESET;

    /* Check the parameters */
    if (FLASH_HandleIsValid(hflash) == 0U)
    {
        return FLASH_FLAG_RESET;
    }
    assert_param(IS_FLASH_FLAG(FlashFlag));

    if ((EFLASH->SR & FlashFlag) != 0U)
    {
        bitstatus = FLASH_FLAG_SET;
    }

    return bitstatus;
}

/**
 * @brief  Clears the specified flash flags. (NON-BLOCKING)
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  FlashFlag: specifies the flags to clear (FLASH_CLEAR_xxx).
 * @retval None
 */
void HAL_FLASH_ClearFlagStatus(HAL_FLASH_HandleTypeDef *hflash, uint32 FlashFlag)
{
    /* Check the parameters */
    if (FLASH_HandleIsValid(hflash) == 0U)
    {
        return;
    }
    assert_param(IS_FLASH_CLEAR(FlashFlag));

    /* Write-1-to-clear */
    EFLASH->SR = FlashFlag;
}

/**
 * @brief  Enables or disables the specified flash interrupts. (NON-BLOCKING)
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  FlashIT: specifies the interrupt source (FLASH_IT_xxx).
 * @param  NewState: new state (FLASH_IT_ENABLE / FLASH_IT_DISABLE).
 * @retval None
 */
void HAL_FLASH_ITConfig(HAL_FLASH_HandleTypeDef *hflash, uint32 FlashIT, FLASH_ITStateTypeDef NewState)
{
    /* Check the parameters */
    if (FLASH_HandleIsValid(hflash) == 0U)
    {
        return;
    }
    assert_param(IS_FLASH_IT(FlashIT));

    if (NewState == FLASH_IT_ENABLE)
    {
        /* Enable the selected flash interrupt */
        EFLASH->CR |= FlashIT;
    }
    else
    {
        /* Disable the selected flash interrupt */
        EFLASH->CR &= ~FlashIT;
    }
}

/**
 * @brief  Clears the flash interrupt pending bits. (NON-BLOCKING)
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  FlashIT: specifies the pending bit to clear (FLASH_CLEAR_IT_xxx).
 * @retval None
 */
void HAL_FLASH_ClearITPendingBit(HAL_FLASH_HandleTypeDef *hflash, uint32 FlashIT)
{
    /* Check the parameters */
    if (FLASH_HandleIsValid(hflash) == 0U)
    {
        return;
    }
    assert_param(IS_FLASH_CLEAR_IT(FlashIT));

    /* Write-1-to-clear. The SR flags are cleared with a direct assignment
     * (not a read-modify-write) so that only the requested pending bits are
     * cleared: a '|=' would write 1 to every currently set flag, wiping
     * unrelated pending bits as well (SR is a write-1-to-clear register). */
    EFLASH->SR = FlashIT;
}

/**
  * @}
  */

/** @addtogroup FLASH_Exported_Functions_Group6 State functions
  * @{
  */

/**
 * @brief  Returns the FLASH error code. (NON-BLOCKING)
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval uint32: the error code (HAL_FLASH_ERROR_xxx combination).
 */
uint32 HAL_FLASH_GetError(HAL_FLASH_HandleTypeDef *hflash)
{
    /* Check the FLASH peripheral handle */
    if (hflash == NULL_PTR)
    {
        return HAL_FLASH_ERROR_NONE;
    }

    return hflash->ErrorCode;
}

/**
 * @brief  Returns the FLASH handle state. (NON-BLOCKING)
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval HAL_FLASH_StateTypeDef: the current handle state.
 */
HAL_FLASH_StateTypeDef HAL_FLASH_GetState(HAL_FLASH_HandleTypeDef *hflash)
{
    /* Check the FLASH peripheral handle */
    if (hflash == NULL_PTR)
    {
        return HAL_FLASH_STATE_RESET;
    }

    return hflash->State;
}

/**
  * @}
  */

/**
  * @}
  */

/* Private define ------------------------------------------------------------*/

/* Flash information area base address (write-protection sector) */
#define FLASH_WRITE_PROTECTION_ADDR     (P_FLASH_Info_BASE)

/* Exported functions --------------------------------------------------------*/

/** @addtogroup FLASH_Exported_Functions
  * @{
  */

/** @addtogroup FLASH_Exported_Functions_Group1 Erase operation functions
  * @{
  */

/**
 * @brief  Performs a mass erase / a sector erase / a block erase. (NON-BLOCKING)
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  pEraseInit: pointer to a FLASH_EraseInitTypeDef structure.
 * @param  AddressError: pointer to a uint32 variable that receives the
 *         address of the erase step that failed (optional, may be NULL).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_FLASH_Erase(HAL_FLASH_HandleTypeDef *hflash, FLASH_EraseInitTypeDef *pEraseInit,
                                    uint32 *AddressError)
{
    HAL_StatusTypeDef status = HAL_OK;
    uint32 unit = 0U;
    uint32 tempsize = 0U;
    uint32 currentaddr = 0U;
    uint32 region = FLASH_REGION_INVALID;

    /* Check the FLASH peripheral handle and instance */
    if (FLASH_HandleIsValid(hflash) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    if (pEraseInit == NULL_PTR)
    {
        return HAL_ERROR;
    }
    assert_param(IS_FLASH_TYPEERASE(pEraseInit->TypeErase));
    if (IS_FLASH_TYPEERASE(pEraseInit->TypeErase) == 0U)
    {
        hflash->ErrorCode |= HAL_FLASH_ERROR_PARAM;
        return HAL_ERROR;
    }

    /* ===== Parameter validation that needs no register access =====
     * The whole check is done BEFORE the handle is locked, so that a rejected
     * call neither enters the locked region nor marks the handle busy /
     * errored: the state is left untouched (a READY handle stays READY), and
     * no lock is taken for a call that can never touch the controller. This
     * mirrors the order of HAL_FLASH_Program() / HAL_FLASH_Read(). */
    if (pEraseInit->TypeErase != FLASH_TYPEERASE_MASSERASE)
    {
        assert_param(pEraseInit->Length > 0U);
        assert_param((pEraseInit->Address % EFLASH_WRITE_UNIT_SIZE) == 0U);

        if (pEraseInit->Length == 0U)
        {
            hflash->ErrorCode |= HAL_FLASH_ERROR_PARAM;
            return HAL_ERROR;
        }

        /* The range shall be fully contained in a main region */
        region = FLASH_GetRegion(pEraseInit->Address, pEraseInit->Length);
        if ((region != FLASH_REGION_PFLASH_MAIN) && (region != FLASH_REGION_DFLASH_MAIN))
        {
            hflash->ErrorCode |= HAL_FLASH_ERROR_ADDRESS;
            return HAL_ERROR;
        }

        /* Erase unit: 4 KB sector or 512 KB block */
        if (pEraseInit->TypeErase == FLASH_TYPEERASE_SECTORS)
        {
            unit = FLASH_GetSectorSize(region);
        }
        else
        {
            unit = ((region == FLASH_REGION_PFLASH_MAIN) ? PFLASH_BLOCK_SIZE : DFLASH_BLOCK_SIZE);
        }

        /* The start address shall be aligned on the erase unit (the erase
         * command operates on complete 4 KB sectors / 512 KB blocks). The
         * length may end mid-unit: the last erase step is rounded up to the
         * erase unit. */
        if ((pEraseInit->Address % unit) != 0U)
        {
            hflash->ErrorCode |= HAL_FLASH_ERROR_PARAM;
            return HAL_ERROR;
        }
    }

    /* Check if the controller is busy */
    if ((EFLASH->SR & FLASH_FLAG_BUSY) != 0U)
    {
        return HAL_BUSY;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_FLASH_Init() is
     * required first) */
    status = FLASH_CheckState(hflash);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (FLASH_LockHandle(hflash, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* ERR-03 / ARCH-CONST-10: a start operation clears the error code */
    hflash->ErrorCode = HAL_FLASH_ERROR_NONE;
    hflash->State = HAL_FLASH_STATE_BUSY;

    if (pEraseInit->TypeErase == FLASH_TYPEERASE_MASSERASE)
    {
        /* Erase all the main blocks (P-Flash + D-Flash main regions) */
        FLASH_SetCommand(FLASH_Cmd_AllBlockErase);
        status = FLASH_StartCmd(hflash, HAL_MAX_DELAY);
    }
    else
    {
        currentaddr = pEraseInit->Address;
        tempsize = pEraseInit->Length;

        while ((tempsize > 0U) && (status == HAL_OK))
        {
            /* Set the sector / block erase command and the address */
            FLASH_SetCommand((pEraseInit->TypeErase == FLASH_TYPEERASE_SECTORS) ?
                             FLASH_Cmd_SectorErase : FLASH_Cmd_BlockErase);
            FLASH_SetAddress(currentaddr);

            /* Launch the command and wait for completion */
            status = FLASH_StartCmd(hflash, HAL_MAX_DELAY);

            if (status != HAL_OK)
            {
                if (AddressError != NULL_PTR)
                {
                    *AddressError = currentaddr;
                }
                break;
            }

            /* Move to the next erase unit */
            currentaddr += unit;
            tempsize -= (tempsize >= unit) ? unit : tempsize;
        }
    }

    hflash->State = (status == HAL_OK) ? HAL_FLASH_STATE_READY : HAL_FLASH_STATE_ERROR;
    FLASH_UnlockHandle(hflash);

    return status;
}

/**
 * @brief  Erases the write-protection information sector. (NON-BLOCKING)
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_FLASH_EraseWriteProtection(HAL_FLASH_HandleTypeDef *hflash)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the FLASH peripheral handle and instance */
    if (FLASH_HandleIsValid(hflash) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check if the controller is busy */
    if ((EFLASH->SR & FLASH_FLAG_BUSY) != 0U)
    {
        return HAL_BUSY;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_FLASH_Init() is
     * required first) */
    status = FLASH_CheckState(hflash);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (FLASH_LockHandle(hflash, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* ERR-03 / ARCH-CONST-10: a start operation clears the error code */
    hflash->ErrorCode = HAL_FLASH_ERROR_NONE;
    hflash->State = HAL_FLASH_STATE_BUSY;

    /* Set the write-protection information sector erase command on the
     * P-Flash info base address */
    FLASH_SetCommand(FLASH_Cmd_WPInfoSectorErase);
    FLASH_SetAddress(FLASH_WRITE_PROTECTION_ADDR);

    /* Launch the command and wait for completion */
    status = FLASH_StartCmd(hflash, HAL_MAX_DELAY);

    hflash->State = (status == HAL_OK) ? HAL_FLASH_STATE_READY : HAL_FLASH_STATE_ERROR;
    FLASH_UnlockHandle(hflash);

    return status;
}

/**
  * @}
  */

/** @addtogroup FLASH_Exported_Functions_Group2 Write protection functions
  * @{
  */

/**
 * @brief  Checks the write protection status of a P-Flash area. (NON-BLOCKING)
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  ProtectArea: write protection area (FLASH_WP_AREA1..32).
 * @retval FLASH_FlagStatusTypeDef: FLASH_FLAG_SET / FLASH_FLAG_RESET
 */
FLASH_FlagStatusTypeDef HAL_FLASH_GetPFlashWriteProtStatus(HAL_FLASH_HandleTypeDef *hflash, uint32 ProtectArea)
{
    FLASH_FlagStatusTypeDef bitstatus = FLASH_FLAG_RESET;

    /* Check the parameters */
    if (FLASH_HandleIsValid(hflash) == 0U)
    {
        return FLASH_FLAG_RESET;
    }
    assert_param(IS_PFLASH_WP_AREAx(ProtectArea));

    /* The PWPR register bit is 1 when the area is NOT protected (inverted
     * logic: '0' = protected, '1' = unprotected), so 'SET' means the area
     * is currently unprotected. */
    if ((EFLASH->PWPR & ProtectArea) != 0U)
    {
        bitstatus = FLASH_FLAG_SET;
    }

    return bitstatus;
}

/**
 * @brief  Sets the write protection of a P-Flash area. (NON-BLOCKING)
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  ProtectArea: write protection area (FLASH_WP_AREA1..32).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_FLASH_SetPFlashWriteProtection(HAL_FLASH_HandleTypeDef *hflash, uint32 ProtectArea)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the parameters */
    if (FLASH_HandleIsValid(hflash) == 0U)
    {
        return HAL_ERROR;
    }
    assert_param(IS_PFLASH_WP_AREAx(ProtectArea));
    if (IS_PFLASH_WP_AREAx(ProtectArea) == 0U)
    {
        hflash->ErrorCode |= HAL_FLASH_ERROR_PARAM;
        return HAL_ERROR;
    }

    /* Check if the controller is busy */
    if ((EFLASH->SR & FLASH_FLAG_BUSY) != 0U)
    {
        return HAL_BUSY;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_FLASH_Init() is
     * required first) */
    status = FLASH_CheckState(hflash);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (FLASH_LockHandle(hflash, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* ERR-03 / ARCH-CONST-10: a start operation clears the error code */
    hflash->ErrorCode = HAL_FLASH_ERROR_NONE;
    hflash->State = HAL_FLASH_STATE_BUSY;

    /* Write to the P-Flash write protection register (0 = protected) */
    EFLASH->PWPR &= ~ProtectArea;

    /* Read back and check */
    if ((EFLASH->PWPR & ProtectArea) != 0U)
    {
        status = HAL_ERROR;
    }

    hflash->State = (status == HAL_OK) ? HAL_FLASH_STATE_READY : HAL_FLASH_STATE_ERROR;
    FLASH_UnlockHandle(hflash);

    return status;
}

/**
 * @brief  Resets the write protection of a P-Flash area. (NON-BLOCKING)
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  ProtectArea: write protection area (FLASH_WP_AREA1..32).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_FLASH_ResetPFlashWriteProtection(HAL_FLASH_HandleTypeDef *hflash, uint32 ProtectArea)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the parameters */
    if (FLASH_HandleIsValid(hflash) == 0U)
    {
        return HAL_ERROR;
    }
    assert_param(IS_PFLASH_WP_AREAx(ProtectArea));
    if (IS_PFLASH_WP_AREAx(ProtectArea) == 0U)
    {
        hflash->ErrorCode |= HAL_FLASH_ERROR_PARAM;
        return HAL_ERROR;
    }

    /* Check if the controller is busy */
    if ((EFLASH->SR & FLASH_FLAG_BUSY) != 0U)
    {
        return HAL_BUSY;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_FLASH_Init() is
     * required first) */
    status = FLASH_CheckState(hflash);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (FLASH_LockHandle(hflash, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* ERR-03 / ARCH-CONST-10: a start operation clears the error code */
    hflash->ErrorCode = HAL_FLASH_ERROR_NONE;
    hflash->State = HAL_FLASH_STATE_BUSY;

    /* Write to the P-Flash write protection register (1 = unprotected) */
    EFLASH->PWPR |= ProtectArea;

    /* Read back and check */
    if ((EFLASH->PWPR & ProtectArea) == 0U)
    {
        status = HAL_ERROR;
    }

    hflash->State = (status == HAL_OK) ? HAL_FLASH_STATE_READY : HAL_FLASH_STATE_ERROR;
    FLASH_UnlockHandle(hflash);

    return status;
}

/**
 * @brief  Checks the write protection status of a D-Flash area. (NON-BLOCKING)
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  ProtectArea: write protection area (FLASH_WP_AREA1..8).
 * @retval FLASH_FlagStatusTypeDef: FLASH_FLAG_SET / FLASH_FLAG_RESET
 */
FLASH_FlagStatusTypeDef HAL_FLASH_GetDFlashWriteProtStatus(HAL_FLASH_HandleTypeDef *hflash, uint32 ProtectArea)
{
    FLASH_FlagStatusTypeDef bitstatus = FLASH_FLAG_RESET;

    /* Check the parameters */
    if (FLASH_HandleIsValid(hflash) == 0U)
    {
        return FLASH_FLAG_RESET;
    }
    assert_param(IS_DFLASH_WP_AREAx(ProtectArea));

    /* The DWPR register bit is 1 when the area is NOT protected (inverted
     * logic: '0' = protected, '1' = unprotected), so 'SET' means the area
     * is currently unprotected. */
    if ((EFLASH->DWPR & ProtectArea) != 0U)
    {
        bitstatus = FLASH_FLAG_SET;
    }

    return bitstatus;
}

/**
 * @brief  Sets the write protection of a D-Flash area. (NON-BLOCKING)
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  ProtectArea: write protection area (FLASH_WP_AREA1..8).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_FLASH_SetDFlashWriteProtection(HAL_FLASH_HandleTypeDef *hflash, uint32 ProtectArea)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the parameters */
    if (FLASH_HandleIsValid(hflash) == 0U)
    {
        return HAL_ERROR;
    }
    assert_param(IS_DFLASH_WP_AREAx(ProtectArea));
    if (IS_DFLASH_WP_AREAx(ProtectArea) == 0U)
    {
        hflash->ErrorCode |= HAL_FLASH_ERROR_PARAM;
        return HAL_ERROR;
    }

    /* Check if the controller is busy */
    if ((EFLASH->SR & FLASH_FLAG_BUSY) != 0U)
    {
        return HAL_BUSY;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_FLASH_Init() is
     * required first) */
    status = FLASH_CheckState(hflash);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (FLASH_LockHandle(hflash, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* ERR-03 / ARCH-CONST-10: a start operation clears the error code */
    hflash->ErrorCode = HAL_FLASH_ERROR_NONE;
    hflash->State = HAL_FLASH_STATE_BUSY;

    /* Write to the D-Flash write protection register (0 = protected) */
    EFLASH->DWPR &= ~ProtectArea;

    /* Read back and check */
    if ((EFLASH->DWPR & ProtectArea) != 0U)
    {
        status = HAL_ERROR;
    }

    hflash->State = (status == HAL_OK) ? HAL_FLASH_STATE_READY : HAL_FLASH_STATE_ERROR;
    FLASH_UnlockHandle(hflash);

    return status;
}

/**
 * @brief  Resets the write protection of a D-Flash area. (NON-BLOCKING)
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  ProtectArea: write protection area (FLASH_WP_AREA1..8).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_FLASH_ResetDFlashWriteProtection(HAL_FLASH_HandleTypeDef *hflash, uint32 ProtectArea)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the parameters */
    if (FLASH_HandleIsValid(hflash) == 0U)
    {
        return HAL_ERROR;
    }
    assert_param(IS_DFLASH_WP_AREAx(ProtectArea));
    if (IS_DFLASH_WP_AREAx(ProtectArea) == 0U)
    {
        hflash->ErrorCode |= HAL_FLASH_ERROR_PARAM;
        return HAL_ERROR;
    }

    /* Check if the controller is busy */
    if ((EFLASH->SR & FLASH_FLAG_BUSY) != 0U)
    {
        return HAL_BUSY;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_FLASH_Init() is
     * required first) */
    status = FLASH_CheckState(hflash);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (FLASH_LockHandle(hflash, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* ERR-03 / ARCH-CONST-10: a start operation clears the error code */
    hflash->ErrorCode = HAL_FLASH_ERROR_NONE;
    hflash->State = HAL_FLASH_STATE_BUSY;

    /* Write to the D-Flash write protection register (1 = unprotected) */
    EFLASH->DWPR |= ProtectArea;

    /* Read back and check */
    if ((EFLASH->DWPR & ProtectArea) == 0U)
    {
        status = HAL_ERROR;
    }

    hflash->State = (status == HAL_OK) ? HAL_FLASH_STATE_READY : HAL_FLASH_STATE_ERROR;
    FLASH_UnlockHandle(hflash);

    return status;
}

/**
  * @}
  */

/** @addtogroup FLASH_Exported_Functions_Group3 ECC error management functions
  * @{
  */

/**
 * @brief  Returns the ECC 2-bit error address. (NON-BLOCKING)
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval uint32: ECC 2-bit error address.
 */
uint32 HAL_FLASH_GetECCErrorAddress(HAL_FLASH_HandleTypeDef *hflash)
{
    if (FLASH_HandleIsValid(hflash) == 0U)
    {
        return 0U;
    }

    return EFLASH->EAR;
}

/**
 * @brief  Clears the ECC 2-bit error address register. (NON-BLOCKING)
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval None
 */
void HAL_FLASH_ClearECCErrorAddress(HAL_FLASH_HandleTypeDef *hflash)
{
    if (FLASH_HandleIsValid(hflash) == 0U)
    {
        return;
    }

    EFLASH->EAR = 0x00U;
}

/**
  * @}
  */

/** @addtogroup FLASH_Exported_Functions_Group4 Security functions
  * @{
  */

/**
 * @brief  Checks the security flag status. (NON-BLOCKING)
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  FlashSECFlag: security flag to check (FLASH_SECFLAG_KEY /
 *         FLASH_SECFLAG_RP).
 * @retval FLASH_FlagStatusTypeDef: FLASH_FLAG_SET / FLASH_FLAG_RESET
 */
FLASH_FlagStatusTypeDef HAL_FLASH_GetSECFlagStatus(HAL_FLASH_HandleTypeDef *hflash, uint32 FlashSECFlag)
{
    FLASH_FlagStatusTypeDef bitstatus = FLASH_FLAG_RESET;

    /* Check the parameters */
    if (FLASH_HandleIsValid(hflash) == 0U)
    {
        return FLASH_FLAG_RESET;
    }
    assert_param(IS_FLASH_SECFLAG(FlashSECFlag));

    /* A security flag is reported as "set" while the field is not fully
     * programmed (0 means the feature is active on this chip) */
    if ((EFLASH->SECR & FlashSECFlag) != FlashSECFlag)
    {
        bitstatus = FLASH_FLAG_SET;
    }

    return bitstatus;
}

/**
 * @brief  Enters the flash security key and launches the key verification. (NON-BLOCKING)
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  SEC_KEY0: security key, low 32 bits.
 * @param  SEC_KEY1: security key, high 32 bits.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_FLASH_InputSECKEY(HAL_FLASH_HandleTypeDef *hflash, uint32 SEC_KEY0, uint32 SEC_KEY1)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the FLASH peripheral handle and instance */
    if (FLASH_HandleIsValid(hflash) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check if the controller is busy */
    if ((EFLASH->SR & FLASH_FLAG_BUSY) != 0U)
    {
        return HAL_BUSY;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_FLASH_Init() is
     * required first) */
    status = FLASH_CheckState(hflash);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (FLASH_LockHandle(hflash, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* ERR-03 / ARCH-CONST-10: a start operation clears the error code */
    hflash->ErrorCode = HAL_FLASH_ERROR_NONE;
    hflash->State = HAL_FLASH_STATE_BUSY;

    /* Set the security key verification command and the two key words */
    FLASH_SetCommand(FLASH_Cmd_SecKEYVerif);
    EFLASH->SECKEY0 = SEC_KEY0;
    EFLASH->SECKEY1 = SEC_KEY1;

    /* Launch the command and wait for completion */
    status = FLASH_StartCmd(hflash, HAL_MAX_DELAY);

    hflash->State = (status == HAL_OK) ? HAL_FLASH_STATE_READY : HAL_FLASH_STATE_ERROR;
    FLASH_UnlockHandle(hflash);

    return status;
}

/**
  * @}
  */

/**
  * @}
  */

#endif /* HAL_FLASH_MODULE_ENABLED */

/*****END OF FILE*****/
