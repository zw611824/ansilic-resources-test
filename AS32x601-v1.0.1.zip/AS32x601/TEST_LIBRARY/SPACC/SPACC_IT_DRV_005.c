/**
 * @file    SPACC_IT_DRV_005.c
 * @brief   HAL SPACC integration test case 005 (HAL API coverage self test).
 *
 * HAL API coverage self test (structure defaults, validation, life cycle, context access, interrupt configuration, exported and validation macros).
 *
 * Tested functionality:
 *   the whole exported API of the SPACC driver: HAL_SPACC_StructInit / HAL_SPACC_Init / HAL_SPACC_DeInit / HAL_SPACC_MspInit / HAL_SPACC_MspDeInit / HAL_SPACC_PacketInit / HAL_SPACC_ITConfig / HAL_SPACC_GetITStatus / HAL_SPACC_CommandExecResult / HAL_SPACC_StateFIFOFlag / HAL_SPACC_ReadStatus / HAL_SPACC_WriteContext / HAL_SPACC_ReadContext / HAL_SPACC_IRQHandler / HAL_SPACC_ErrorCallback / HAL_SPACC_GetState / HAL_SPACC_GetError, the shared helpers SPACC_HandleIsValid / SPACC_CheckState / SPACC_LockHandle / SPACC_UnlockHandle, the exported macros (__HAL_SPACC_*) and the validation macros (IS_SPACC_*).
 *
 * Expected behaviour:
 *   every check passes and the summary stays at zero failures; the case does not compare a cryptographic vector and can be run repeatedly.
 *
 * @note    The packet vectors are the ones of the reference test project
 *          (SPACC_IT_DRV_005.c) and are reproduced verbatim, so a case can be
 *          compared one to one with the reference output.
 * @note    The SPACC needs the AXILite4-Bus1 (DSE) clock gate and reset
 *          release: HAL_SPACC_MspInit() is overridden at the end of this file
 *          to do that and to count its calls.
 * @note    The DDT structures are 8-byte aligned through a union with a 64-bit
 *          member, because the driver validates the alignment of the DDT bus
 *          address (SRC_PTR.PTR starts at bit 3).
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Software identifier carried by every submitted task */
#define TEST_SOFTWARE_ID            (0x2DU)

/* Bound of every polling loop (the SPACC completes in microseconds) */
#define TEST_WAIT_GUARD             (20000000U)

/* Reporting period of the final loop (ms) */
#define TEST_POLL_MS                (1000U)

/* Unknown instance used by the handle validation checks */
#define TEST_BAD_INSTANCE           ((SPACC_TypeDef *)0x40000000UL)

/* Processed packet size, in 32-bit words, of this case */
#define TEST_PACKET_WORDS           (8U)

/* Byte-swap helper: the SPACC consumes the packet in the opposite byte order
 * of the C representation, exactly as the reference test project does. */
#define TEST_SWAP32(__VALUE__)      ((((__VALUE__) & 0x000000FFUL) << 24) | \
                                     (((__VALUE__) & 0x0000FF00UL) << 8)  | \
                                     (((__VALUE__) & 0x00FF0000UL) >> 8)  | \
                                     (((__VALUE__) & 0xFF000000UL) >> 24))

/* Private typedef -----------------------------------------------------------*/
/**
 * @brief Data descriptor table (DDT) of a packet segment list.
 * @note  The SPACC reads SRC_PTR / DST_PTR as the bus address of a DDT whose
 *        first pointer is kept on an 8-byte boundary (PTR field starts at bit
 *        3), so the two DDT instances below are wrapped in a union with a
 *        64-bit member to force that alignment on every toolchain.
 */
typedef struct
{
    uint32 *Ptr_0;
    uint32  Len_0;
    uint32 *Ptr_1;
    uint32  Len_1;
} SPACC_DDTTypeDef;

typedef union
{
    SPACC_DDTTypeDef ddt;
    uint64           force_align8;
} SPACC_DDTAlignedTypeDef;

/* Private variables ---------------------------------------------------------*/
static HAL_SPACC_HandleTypeDef hspacc_dev;          /*!< handle under test      */
static HAL_SMU_HandleTypeDef   hsmu_clk;            /*!< SMU handle (clock)     */
static SPACC_InitTypeDef       spacc_init;          /*!< configuration          */
static SPACC_PacketTypeDef     spacc_packet;        /*!< packet descriptor      */
static SPACC_DDTAlignedTypeDef spacc_ddt_src;       /*!< source DDT (8B aligned)*/
static SPACC_DDTAlignedTypeDef spacc_ddt_dst;       /*!< destination DDT        */

/* Accumulated check counters */
static uint32 failures = 0U;
static uint32 checks = 0U;

/* Low level callback instrumentation */
static uint32 msp_init_count = 0U;
static uint32 msp_deinit_count = 0U;
static uint32 error_callback_count = 0U;

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void Section(const char *name);
static void Check(const char *name, uint32 condition);
static void Summary(void);
static void Spacc_StageDdt(uint32 *src, uint32 src_bytes, uint32 *dst, uint32 dst_bytes);
static HAL_StatusTypeDef Spacc_WriteCipherContext(const uint32 *words, uint32 count);
static HAL_StatusTypeDef Spacc_ReadCipherContext(uint32 *words, uint32 count);
static uint32 Spacc_WaitResult(uint32 software_id);
static uint32 Spacc_WaitPending(void);
static void Spacc_Submit(void);
static void Spacc_ResetEvents(void);
static void Spacc_Drain(uint32 limit);


/* AES-128 material used by the self test (key + IV, the values of case 001) */
static const uint32 test_aes_context[12] =
{
    0xae781dadU, 0x18efd7f1U, 0x4acc012aU, 0x75dbeb3aU,
    0x00000000U, 0x00000000U, 0x00000000U, 0x00000000U,
    0x6fac1192U, 0xeb4540ffU, 0xcb5afd0fU, 0xb408d5c5U
};

static uint32          test_src[8];
static uint32          test_dst[8];
static uint32          ctx_read[12];
static uint32          ctx_zero[12];

/**
 * @brief  Stage the descriptor and submit one task with the current configuration.
 * @retval None
 */
static void Spacc_Submit(void)
{
    Spacc_StageDdt(test_src, (uint32)sizeof(test_src), test_dst, (uint32)sizeof(test_dst));
    spacc_packet.SPACC_PROCLen = (uint32)sizeof(test_src);

    HAL_SPACC_PacketInit(&hspacc_dev, &spacc_packet);
    (void)HAL_SPACC_Init(&hspacc_dev, &spacc_init);
}

/**
 * @brief  Clear the error record through one accepted admission.
 * @retval None
 * @note   HAL_SPACC_ERROR_INVALID_PARAM is a sticky flag: it is only cleared by
 *         an accepted HAL_SPACC_Init() or by HAL_SPACC_DeInit(). Every
 *         rejection check of this case is therefore preceded by an accepted
 *         admission, which submits a task; the task is drained here.
 */
static void Spacc_Admit(void)
{
    Spacc_Submit();
    Spacc_Drain(4U);
}

/**
 * @brief  Acknowledge every sticky event flag and empty the status FIFO.
 * @retval None
 * @note   IRQ_STAT is a write-one-to-clear register and the status watchdog
 *         event re-arms on its own threshold, so a flag observed as zero is
 *         only meaningful right after this acknowledgement.
 */
static void Spacc_ResetEvents(void)
{
    WRITE_REG(SPACC->IRQ_EN, 0x00U);
    WRITE_REG(SPACC->IRQ_STAT, (uint32)SPACC_IT_ALL);
    Spacc_Drain(8U);
}

/**
 * @brief  Case 005: HAL API coverage self test.
 * @retval Never (the final loop keeps reporting).
 */
int main(void)
{
    SPACC_InitTypeDef bad;
    uint32            i;
    uint32            err_before;
    uint32            irq_en;
    HAL_StatusTypeDef status;

    HAL_Init();
    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);

    printf("\r\n ***** SPACC HAL API coverage self test (case 005) ***** \r\n");
    printf("Data : %s\r\n", __DATE__);
    printf("Time : %s\r\n", __TIME__);
    delay_ms(500U);

    for (i = 0U; i < (uint32)(sizeof(test_src) / sizeof(test_src[0])); i++)
    {
        test_src[i] = 0x11111111U * (i + 1U);
        test_dst[i] = 0U;
        ctx_zero[i] = 0U;
    }

    /* ------------------------------------------------ module and defaults */
    Section("module version and structure defaults");

    printf("module version = 0x%04X\r\n", PRINT_U32((uint32)__HAL_SPACC_MODULE_VERSION));
    Check("module version is at least V1.0",
          ((uint32)__HAL_SPACC_MODULE_VERSION >= 0x0100U) ? 1U : 0U);

    HAL_SPACC_StructInit(&spacc_init);
    Check("StructInit : Size", (spacc_init.Size == (uint32)sizeof(SPACC_InitTypeDef)) ? 1U : 0U);
    Check("StructInit : Version", (spacc_init.Version == SPACC_INIT_VERSION) ? 1U : 0U);
    Check("StructInit : cipher NULL",
          (spacc_init.SPACC_CipherAlgorithm == SPACC_CIPHER_ALG_NULL) ? 1U : 0U);
    Check("StructInit : cipher mode ECB",
          (spacc_init.SPACC_SM4CipherMode == SPACC_SM4_CIPHER_MODE_ECB) ? 1U : 0U);
    Check("StructInit : hash NULL",
          (spacc_init.SPACC_HashAlgorithm == SPACC_HASH_ALG_NULL) ? 1U : 0U);
    Check("StructInit : SM3 mode raw/shake",
          (spacc_init.SPACC_SM3HashMode == SPACC_SM3_HASH_MODE_RAW_SHAKE) ? 1U : 0U);
    Check("StructInit : decrypt",
          (spacc_init.SPACC_TransferMode == SPACC_TRANS_TO_APPLY_DECRYPT) ? 1U : 0U);
    Check("StructInit : key from context",
          (spacc_init.SPACC_KeyFrom == SPACC_KEY_FROM_CTX) ? 1U : 0U);
    Check("StructInit : AAD not copied",
          (spacc_init.SPACC_AADCopy == SPACC_APP_NOT_COPY) ? 1U : 0U);
    Check("StructInit : ICV over plaintext",
          (spacc_init.SPACC_ICVCompute == SPACC_ICV_COMPUTER_PLAIN) ? 1U : 0U);
    Check("StructInit : ICV not encrypted",
          (spacc_init.SPACC_ICVEncrypt == SPACC_ICV_NOT_ENCRYPT) ? 1U : 0U);
    Check("StructInit : ICV located by offset",
          (spacc_init.SPACC_ICVLocation == SPACC_ICV_LOCATION_OFFSET) ? 1U : 0U);
    Check("StructInit : key not expanded",
          (spacc_init.SPACC_KeyExpand == SPACC_KEY_NOT_EXPAND) ? 1U : 0U);
    Check("StructInit : middle segment",
          ((spacc_init.SPACC_MessageBegin == SPACC_MSG_BEGIN_NOT_FIRST) &&
           (spacc_init.SPACC_MessageEnd == SPACC_MSG_END_NOT_LAST)) ? 1U : 0U);
    Check("StructInit : software ID 0", (spacc_init.SPACC_SoftwareID == 0U) ? 1U : 0U);
    Check("StructInit : command FIFO 0", (spacc_init.SPACC_PriorityCommandFIFO == 0U) ? 1U : 0U);
    Check("StructInit : key size 0", (spacc_init.SPACC_KeySize == 0U) ? 1U : 0U);
    Check("StructInit : key index 0", (spacc_init.SPACC_KeyIndex == 0U) ? 1U : 0U);
    Check("StructInit : hash key type",
          (spacc_init.SPACC_KeyType == SPACC_KEY_TYPE_HASH) ? 1U : 0U);
    Check("StructInit : reserved words cleared",
          ((spacc_init.Reserved[0] == 0U) && (spacc_init.Reserved[1] == 0U)) ? 1U : 0U);
    HAL_SPACC_StructInit(NULL_PTR);
    Check("StructInit of a NULL pointer is a no-op", 1U);

    /* -------------------------------------------------- handle and state */
    Section("handle helpers and state machine");

    __HAL_CLEAR_STRUCT(&hspacc_dev);
    hspacc_dev.Instance = SPACC;
    Check("HandleIsValid accepts the bound handle",
          (SPACC_HandleIsValid(&hspacc_dev) == 1U) ? 1U : 0U);
    Check("HandleIsValid rejects a NULL handle",
          (SPACC_HandleIsValid(NULL_PTR) == 0U) ? 1U : 0U);

    hspacc_dev.Instance = TEST_BAD_INSTANCE;
    Check("HandleIsValid rejects an unknown instance",
          (SPACC_HandleIsValid(&hspacc_dev) == 0U) ? 1U : 0U);
    Check("GetState reports reset for an unknown instance",
          (HAL_SPACC_GetState(&hspacc_dev) == HAL_SPACC_STATE_RESET) ? 1U : 0U);
    Check("GetError reports none for an unknown instance",
          (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_NONE) ? 1U : 0U);
    Check("StateFIFOFlag reports empty for an unknown instance",
          (HAL_SPACC_StateFIFOFlag(&hspacc_dev) == SET) ? 1U : 0U);
    Check("CommandExecResult rejects an unknown instance",
          (HAL_SPACC_CommandExecResult(&hspacc_dev, TEST_SOFTWARE_ID) == RESET) ? 1U : 0U);
    Check("ReadStatus returns zero for an unknown instance",
          (HAL_SPACC_ReadStatus(&hspacc_dev) == 0U) ? 1U : 0U);
    hspacc_dev.Instance = SPACC;

    Check("GetState reports reset on a cleared handle",
          (HAL_SPACC_GetState(&hspacc_dev) == HAL_SPACC_STATE_RESET) ? 1U : 0U);
    Check("CheckState rejects an uninitialized handle",
          (SPACC_CheckState(&hspacc_dev) == HAL_ERROR) ? 1U : 0U);
    hspacc_dev.State = HAL_SPACC_STATE_BUSY;
    Check("CheckState rejects a busy handle",
          (SPACC_CheckState(&hspacc_dev) == HAL_BUSY) ? 1U : 0U);
    hspacc_dev.State = HAL_SPACC_STATE_ERROR;
    Check("CheckState accepts the recoverable error state",
          (SPACC_CheckState(&hspacc_dev) == HAL_OK) ? 1U : 0U);
    hspacc_dev.State = HAL_SPACC_STATE_READY;
    Check("CheckState accepts a ready handle",
          (SPACC_CheckState(&hspacc_dev) == HAL_OK) ? 1U : 0U);
    __HAL_SPACC_RESET_HANDLE_STATE(&hspacc_dev);
    Check("RESET_HANDLE_STATE macro writes the reset state",
          (HAL_SPACC_GetState(&hspacc_dev) == HAL_SPACC_STATE_RESET) ? 1U : 0U);

    /* ------------------------------------------------ parameter rejection */
    Section("Init run time validation (rejected configurations)");

    Check("Init with a NULL handle is refused",
          (HAL_SPACC_Init(NULL_PTR, &spacc_init) == HAL_ERROR) ? 1U : 0U);
    Check("Init with a NULL configuration is refused",
          (HAL_SPACC_Init(&hspacc_dev, NULL_PTR) == HAL_ERROR) ? 1U : 0U);

    /* Prepare a valid configuration and a valid staged packet: every rejection
     * below only flips one field, so a single accepted admission (Spacc_Admit)
     * is enough to clear the sticky error flag in between. */
    HAL_SPACC_StructInit(&spacc_init);
    spacc_init.SPACC_CipherAlgorithm     = SPACC_CIPHER_ALG_AES;
    spacc_init.SPACC_SM4CipherMode       = SPACC_SM4_CIPHER_MODE_ECB;
    spacc_init.SPACC_HashAlgorithm       = SPACC_HASH_ALG_NULL;
    spacc_init.SPACC_TransferMode        = SPACC_TRANS_TO_APPLY_ENCRYPT;
    spacc_init.SPACC_MessageBegin        = SPACC_MSG_BEGIN_FIRST;
    spacc_init.SPACC_MessageEnd          = SPACC_MSG_END_LAST;
    spacc_init.SPACC_SoftwareID          = TEST_SOFTWARE_ID;
    spacc_init.SPACC_KeySize             = 0x10U;
    spacc_init.SPACC_KeyType             = SPACC_KEY_TYPE_CIPHER;

    __HAL_CLEAR_STRUCT(&hspacc_dev);
    hspacc_dev.Instance = SPACC;
    status = Spacc_WriteCipherContext(test_aes_context, 12U);
    Check("cipher context written before the first admission", (status == HAL_OK) ? 1U : 0U);

    Spacc_StageDdt(test_src, (uint32)sizeof(test_src), test_dst, (uint32)sizeof(test_dst));
    spacc_packet.SPACC_PROCLen = (uint32)sizeof(test_src);
    HAL_SPACC_PacketInit(&hspacc_dev, &spacc_packet);
    status = HAL_SPACC_Init(&hspacc_dev, &spacc_init);
    Check("valid configuration accepted", (status == HAL_OK) ? 1U : 0U);
    Check("state is ready", (HAL_SPACC_GetState(&hspacc_dev) == HAL_SPACC_STATE_READY) ? 1U : 0U);
    Check("error code cleared by the accepted admission",
          (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_NONE) ? 1U : 0U);
    Check("low level initialization ran once", (msp_init_count == 1U) ? 1U : 0U);
    Check("task completed with the expected software ID", Spacc_WaitResult(TEST_SOFTWARE_ID));

    Spacc_Admit();
    bad = spacc_init;
    bad.Size = (uint32)sizeof(SPACC_InitTypeDef) - 4U;
    err_before = HAL_SPACC_GetError(&hspacc_dev);
    (void)HAL_SPACC_Init(&hspacc_dev, &bad);
    Check("Init rejects a wrong Size",
          ((err_before == HAL_SPACC_ERROR_NONE) &&
           (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_INVALID_PARAM)) ? 1U : 0U);

    Spacc_Admit();
    bad = spacc_init;
    bad.Version = 0x0200U;
    (void)HAL_SPACC_Init(&hspacc_dev, &bad);
    Check("Init rejects an unknown Version",
          (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_INVALID_PARAM) ? 1U : 0U);

    Spacc_Admit();
    bad = spacc_init;
    bad.Reserved[0] = 1U;
    (void)HAL_SPACC_Init(&hspacc_dev, &bad);
    Check("Init rejects a non zero reserved word",
          (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_INVALID_PARAM) ? 1U : 0U);

    Spacc_Admit();
    bad = spacc_init;
    bad.SPACC_CipherAlgorithm = 0x0AU;
    (void)HAL_SPACC_Init(&hspacc_dev, &bad);
    Check("Init rejects an undefined cipher algorithm",
          (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_INVALID_PARAM) ? 1U : 0U);

    Spacc_Admit();
    bad = spacc_init;
    bad.SPACC_SM4CipherMode = 0x04U;
    (void)HAL_SPACC_Init(&hspacc_dev, &bad);
    Check("Init rejects the reserved cipher mode encoding",
          (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_INVALID_PARAM) ? 1U : 0U);

    Spacc_Admit();
    bad = spacc_init;
    bad.SPACC_HashAlgorithm = 0x1AU;
    (void)HAL_SPACC_Init(&hspacc_dev, &bad);
    Check("Init rejects an undefined hash algorithm",
          (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_INVALID_PARAM) ? 1U : 0U);

    Spacc_Admit();
    bad = spacc_init;
    bad.SPACC_SM3HashMode = 0x03U;
    (void)HAL_SPACC_Init(&hspacc_dev, &bad);
    Check("Init rejects the reserved SM3 mode encoding",
          (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_INVALID_PARAM) ? 1U : 0U);

    Spacc_Admit();
    bad = spacc_init;
    bad.SPACC_TransferMode = 0x02U;
    (void)HAL_SPACC_Init(&hspacc_dev, &bad);
    Check("Init rejects an out of range transfer mode",
          (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_INVALID_PARAM) ? 1U : 0U);

    Spacc_Admit();
    bad = spacc_init;
    bad.SPACC_SoftwareID = 0x100U;
    (void)HAL_SPACC_Init(&hspacc_dev, &bad);
    Check("Init rejects a software ID above eight bits",
          (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_INVALID_PARAM) ? 1U : 0U);

    Spacc_Admit();
    bad = spacc_init;
    bad.SPACC_PriorityCommandFIFO = 0x03U;
    (void)HAL_SPACC_Init(&hspacc_dev, &bad);
    Check("Init rejects the reserved command FIFO encoding",
          (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_INVALID_PARAM) ? 1U : 0U);

    Spacc_Admit();
    bad = spacc_init;
    bad.SPACC_KeySize = 0x100U;
    (void)HAL_SPACC_Init(&hspacc_dev, &bad);
    Check("Init rejects a key size above eight bits",
          (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_INVALID_PARAM) ? 1U : 0U);

    Spacc_Admit();
    bad = spacc_init;
    bad.SPACC_KeyIndex = 0x100U;
    (void)HAL_SPACC_Init(&hspacc_dev, &bad);
    Check("Init rejects a key index above eight bits",
          (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_INVALID_PARAM) ? 1U : 0U);

    Spacc_Admit();
    bad = spacc_init;
    bad.SPACC_ContextIndex = 0x100U;
    (void)HAL_SPACC_Init(&hspacc_dev, &bad);
    Check("Init rejects a context index above eight bits",
          (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_INVALID_PARAM) ? 1U : 0U);

    Spacc_Admit();
    bad = spacc_init;
    bad.SPACC_ICVEncrypt  = SPACC_ICV_ENCRYPT;
    bad.SPACC_ICVCompute  = SPACC_ICV_COMPUTER_PLAIN;
    bad.SPACC_ICVLocation = SPACC_ICV_LOCATION_OFFSET;
    (void)HAL_SPACC_Init(&hspacc_dev, &bad);
    Check("Init rejects the illegal ICV_ENC combination",
          (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_INVALID_PARAM) ? 1U : 0U);

    Spacc_Admit();
    bad = spacc_init;
    bad.SPACC_ICVEncrypt  = SPACC_ICV_ENCRYPT;
    bad.SPACC_ICVCompute  = SPACC_ICV_COMPUTER_CIPHER;
    bad.SPACC_ICVLocation = SPACC_ICV_LOCATION_APPEND;
    (void)HAL_SPACC_Init(&hspacc_dev, &bad);
    Check("Init accepts the legal ICV_ENC combination",
          (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_NONE) ? 1U : 0U);

    /* ------------------------------------------- descriptor rejection set */
    Section("PacketInit run time validation (rejected descriptors)");

    Spacc_Admit();
    Spacc_StageDdt(test_src, (uint32)sizeof(test_src), test_dst, (uint32)sizeof(test_dst));
    spacc_packet.SPACC_SourcePtr = (uint32)(&spacc_ddt_src.ddt) + 4U;
    HAL_SPACC_PacketInit(&hspacc_dev, &spacc_packet);
    Check("PacketInit rejects a misaligned DDT address",
          (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_INVALID_PARAM) ? 1U : 0U);

    Spacc_Admit();
    Spacc_StageDdt(test_src, (uint32)sizeof(test_src), test_dst, (uint32)sizeof(test_dst));
    spacc_packet.SPACC_DestinationPtr = 0U;
    HAL_SPACC_PacketInit(&hspacc_dev, &spacc_packet);
    Check("PacketInit rejects a NULL destination pointer",
          (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_INVALID_PARAM) ? 1U : 0U);

    Spacc_Admit();
    Spacc_StageDdt(test_src, (uint32)sizeof(test_src), test_dst, (uint32)sizeof(test_dst));
    spacc_packet.SPACC_SouPREAADOffset = 0x1000U;
    HAL_SPACC_PacketInit(&hspacc_dev, &spacc_packet);
    Check("PacketInit rejects an offset above twelve bits",
          (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_INVALID_PARAM) ? 1U : 0U);

    Spacc_Admit();
    Spacc_StageDdt(test_src, (uint32)sizeof(test_src), test_dst, (uint32)sizeof(test_dst));
    spacc_packet.SPACC_PREAADLen = 0x4000U;
    HAL_SPACC_PacketInit(&hspacc_dev, &spacc_packet);
    Check("PacketInit rejects a pre-AAD length above fourteen bits",
          (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_INVALID_PARAM) ? 1U : 0U);

    Spacc_Admit();
    Spacc_StageDdt(test_src, (uint32)sizeof(test_src), test_dst, (uint32)sizeof(test_dst));
    spacc_packet.SPACC_ICVLen = 0x40U;
    HAL_SPACC_PacketInit(&hspacc_dev, &spacc_packet);
    Check("PacketInit rejects an ICV length above six bits",
          (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_INVALID_PARAM) ? 1U : 0U);

    Spacc_Admit();
    Spacc_StageDdt(test_src, (uint32)sizeof(test_src), test_dst, (uint32)sizeof(test_dst));
    spacc_packet.SPACC_IVLocation = 0x02U;
    HAL_SPACC_PacketInit(&hspacc_dev, &spacc_packet);
    Check("PacketInit rejects an undefined IV location",
          (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_INVALID_PARAM) ? 1U : 0U);

    Spacc_Admit();
    HAL_SPACC_PacketInit(&hspacc_dev, NULL_PTR);
    Check("PacketInit rejects a NULL descriptor",
          (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_INVALID_PARAM) ? 1U : 0U);

    /* --------------------------------------------------------- context API */
    Section("context memory access");

    Spacc_Admit();
    status = Spacc_WriteCipherContext(test_aes_context, 12U);
    Check("WriteContext accepted", (status == HAL_OK) ? 1U : 0U);
    status = Spacc_ReadCipherContext(ctx_read, 12U);
    Check("ReadContext accepted", (status == HAL_OK) ? 1U : 0U);
    uint32 ctx_ok = 1U;
    for (i = 0U; i < 12U; i++)
    {
        if (ctx_read[i] != test_aes_context[i])
        {
            ctx_ok = 0U;
        }
    }
    Check("context write / read round trip", ctx_ok);

    Check("WriteContext rejects a base that is not a context partition",
          (HAL_SPACC_WriteContext(&hspacc_dev, 0x41100000U, 0U, ctx_zero, 4U) == HAL_ERROR) ? 1U : 0U);
    Check("WriteContext rejects a NULL data pointer",
          (HAL_SPACC_WriteContext(&hspacc_dev, SPACC_CIPHER_CONTEXT_BASE, 0U, NULL_PTR, 4U) == HAL_ERROR) ? 1U : 0U);
    Check("WriteContext rejects a zero word count",
          (HAL_SPACC_WriteContext(&hspacc_dev, SPACC_CIPHER_CONTEXT_BASE, 0U, ctx_zero, 0U) == HAL_ERROR) ? 1U : 0U);
    Check("ReadContext rejects a NULL data pointer",
          (HAL_SPACC_ReadContext(&hspacc_dev, SPACC_CIPHER_CONTEXT_BASE, 0U, NULL_PTR, 4U) == HAL_ERROR) ? 1U : 0U);
    Check("ReadContext rejects a zero word count",
          (HAL_SPACC_ReadContext(&hspacc_dev, SPACC_CIPHER_CONTEXT_BASE, 0U, ctx_read, 0U) == HAL_ERROR) ? 1U : 0U);

    status = HAL_SPACC_WriteContext(&hspacc_dev, SPACC_HASH_CONTEXT_BASE, 0U, ctx_zero, 4U);
    Check("the hash context partition is writable too", (status == HAL_OK) ? 1U : 0U);

    /* -------------------------------------------------------- interrupt API */
    Section("interrupt configuration and status");

    /* IRQ_STAT is a write-one-to-clear register and the status watchdog event
     * re-arms on its own threshold, so every flag is acknowledged before the
     * configuration is observed. */
    Spacc_ResetEvents();

    HAL_SPACC_ITConfig(&hspacc_dev, (uint32)(SPACC_IT_STAT | SPACC_IT_GLBL), ENABLE);
    irq_en = SPACC->IRQ_EN;
    Check("ITConfig accepts the combined STAT | GLBL mask",
          ((irq_en & (uint32)(SPACC_IT_STAT | SPACC_IT_GLBL)) ==
           (uint32)(SPACC_IT_STAT | SPACC_IT_GLBL)) ? 1U : 0U);

    /* GetITStatus reads the raw IRQ_STAT bit. The status FIFO event never raises
     * itself on this device (its watermark register is not implemented), so the
     * acknowledged mask stays RESET; the status watchdog, on the other hand,
     * re-arms as soon as a result is left pending, which proves that a raised
     * sticky bit is reported as SET. */
    SPACC->IRQ_STAT = (uint32)(SPACC_IT_STATE_STAT | SPACC_IT_STATE_STAT_WD);
    Check("GetITStatus reads an acknowledged status mask as RESET",
          (HAL_SPACC_GetITStatus(&hspacc_dev,
                                 (uint32)(SPACC_IT_STATE_STAT | SPACC_IT_STATE_STAT_WD)) == RESET) ? 1U : 0U);

    Spacc_Submit();

    /* Bounded wait: the watchdog threshold is not documented as a time value,
     * and the console report of the previous check already takes milliseconds,
     * so the flag is polled instead of being sampled once. */
    for (i = 0U; (i < 500U) &&
                 (HAL_SPACC_GetITStatus(&hspacc_dev, (uint32)SPACC_IT_STATE_STAT_WD) == RESET); i++)
    {
        delay_ms(1U);
    }

    Check("GetITStatus reads a raised status bit as SET",
          (HAL_SPACC_GetITStatus(&hspacc_dev, (uint32)SPACC_IT_STATE_STAT_WD) == SET) ? 1U : 0U);
    Check("GET_IT reports the same raised event bit",
          (__HAL_SPACC_GET_IT(&hspacc_dev, (uint32)SPACC_IT_STATE_STAT_WD) != RESET) ? 1U : 0U);
    SPACC->IRQ_STAT = (uint32)SPACC_IT_STATE_STAT_WD;

    /* The command FIFO source is the observation point: the RC4 context DMA
     * source of this device does not implement its enable bit, which reads back
     * as zero whatever is written. */
    __HAL_SPACC_ENABLE_IT(&hspacc_dev, (uint32)SPACC_IT_CMD0);
    Check("ENABLE_IT macro sets the requested bit",
          ((SPACC->IRQ_EN & (uint32)SPACC_IT_CMD0) != 0U) ? 1U : 0U);
    __HAL_SPACC_DISABLE_IT(&hspacc_dev, (uint32)SPACC_IT_CMD0);
    Check("DISABLE_IT macro clears the requested bit",
          ((SPACC->IRQ_EN & (uint32)SPACC_IT_CMD0) == 0U) ? 1U : 0U);

    HAL_SPACC_ITConfig(&hspacc_dev, (uint32)SPACC_IT_ALL, DISABLE);
    Check("all event sources disabled",
          ((SPACC->IRQ_EN & (uint32)SPACC_IT_STATUS_SOURCES) == 0U) ? 1U : 0U);
    Check("global gate disabled", ((SPACC->IRQ_EN & (uint32)SPACC_IT_GLBL) == 0U) ? 1U : 0U);

    Spacc_Drain(8U);
    Check("FIFO_STAT empty flag readable through the exported macro",
          (__HAL_SPACC_GET_FLAG(&hspacc_dev, SPACC_FIFO_STAT_STAT_EMPTY) != 0U) ? 1U : 0U);

    /* A disabled source must not raise an event through the handler */
    hspacc_dev.State = HAL_SPACC_STATE_READY;
    HAL_SPACC_IRQHandler(&hspacc_dev);
    Check("handler with no enabled source keeps the state",
          (HAL_SPACC_GetState(&hspacc_dev) == HAL_SPACC_STATE_READY) ? 1U : 0U);
    Check("handler with no enabled source does not call the error callback",
          (error_callback_count == 0U) ? 1U : 0U);

    /* ------------------------------------------------------- status FIFO */
    Section("status FIFO and exported status macro");

    /* Start from an empty FIFO, so the pending result below comes from the
     * submission of this section only. */
    Spacc_ResetEvents();
    Check("the status FIFO is empty after the drain",
          (HAL_SPACC_StateFIFOFlag(&hspacc_dev) == SET) ? 1U : 0U);

    Spacc_Submit();
    Check("a pending result reports the FIFO as non empty",
          (Spacc_WaitPending() != 0U) ? 1U : 0U);

    /* The status FIFO event cannot be raised on this device: IRQ_CTRL only
     * implements the command FIFO watermark (the STAT_CNT field reads back as
     * zero), so the exported macro is exercised on a flag that stays
     * acknowledged. */
    Check("GET_IT reads an acknowledged event bit as RESET",
          (__HAL_SPACC_GET_IT(&hspacc_dev, (uint32)SPACC_IT_STATE_STAT) == RESET) ? 1U : 0U);
    Check("ReadStatus returns a raw status word",
          ((HAL_SPACC_ReadStatus(&hspacc_dev) & (uint32)SPACC_STATUS_SW_ID) == TEST_SOFTWARE_ID) ? 1U : 0U);
    __HAL_SPACC_STAT_POP(&hspacc_dev);
    Check("STAT_POP macro ejects the entry",
          (HAL_SPACC_StateFIFOFlag(&hspacc_dev) == SET) ? 1U : 0U);
    Check("a popped result can no longer be matched",
          (HAL_SPACC_CommandExecResult(&hspacc_dev, TEST_SOFTWARE_ID) == RESET) ? 1U : 0U);

    /* ------------------------------------------------------- lock helpers */
    Section("shared lock helpers");

    Check("LockHandle acquires the bare metal lock",
          (SPACC_LockHandle(&hspacc_dev, 10U) == HAL_OK) ? 1U : 0U);
    Check("LockHandle reports busy on a second acquisition",
          (SPACC_LockHandle(&hspacc_dev, 10U) == HAL_BUSY) ? 1U : 0U);
    SPACC_UnlockHandle(&hspacc_dev);
    Check("the lock is free after the release",
          (SPACC_LockHandle(&hspacc_dev, 10U) == HAL_OK) ? 1U : 0U);
    SPACC_UnlockHandle(&hspacc_dev);

    /* ------------------------------------------------------------ DeInit */
    Section("de-initialization");

    err_before = msp_deinit_count;
    status = HAL_SPACC_DeInit(&hspacc_dev);
    Check("DeInit accepted", (status == HAL_OK) ? 1U : 0U);
    Check("state is reset after DeInit",
          (HAL_SPACC_GetState(&hspacc_dev) == HAL_SPACC_STATE_RESET) ? 1U : 0U);
    Check("error code cleared by DeInit",
          (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_NONE) ? 1U : 0U);
    Check("configuration copy cleared",
          ((hspacc_dev.Init.Size == 0U) && (hspacc_dev.Init.Version == 0U)) ? 1U : 0U);
    Check("low level de-initialization ran once",
          ((msp_deinit_count - err_before) == 1U) ? 1U : 0U);
    Check("interrupt enables cleared by DeInit",
          (SPACC->IRQ_EN == 0U) ? 1U : 0U);
    Check("the de-initialization is idempotent",
          (HAL_SPACC_DeInit(&hspacc_dev) == HAL_OK) ? 1U : 0U);
    Check("a second DeInit does not repeat the teardown callback",
          ((msp_deinit_count - err_before) == 1U) ? 1U : 0U);

    /* --------------------------------------------------------- validation */
    Section("validation macros");

    Check("IS_SPACC_IT accepts a single source",
          (IS_SPACC_IT(SPACC_IT_STAT) != 0U) ? 1U : 0U);
    Check("IS_SPACC_IT accepts a combined mask",
          (IS_SPACC_IT((uint32)(SPACC_IT_STAT | SPACC_IT_GLBL)) != 0U) ? 1U : 0U);
    Check("IS_SPACC_IT rejects an empty mask", (IS_SPACC_IT(0U) == 0U) ? 1U : 0U);
    Check("IS_SPACC_IT rejects an undefined bit",
          (IS_SPACC_IT((uint32)0x00000008U) == 0U) ? 1U : 0U);
    Check("IS_SPACC_IT_STATE accepts a combined event mask",
          (IS_SPACC_IT_STATE((uint32)(SPACC_IT_STATE_STAT | SPACC_IT_STATE_STAT_WD)) != 0U) ? 1U : 0U);
    Check("IS_SPACC_IT_STATE rejects the global gate",
          (IS_SPACC_IT_STATE((uint32)SPACC_IT_GLBL) == 0U) ? 1U : 0U);
    Check("IS_SPACC_CIPHER_ALG domain",
          ((IS_SPACC_CIPHER_ALG(SPACC_CIPHER_ALG_SM4) != 0U) &&
           (IS_SPACC_CIPHER_ALG((uint32)0x0AU) == 0U)) ? 1U : 0U);
    Check("IS_SPACC_HASH_ALG accepts the corrected Poly1305 name",
          (IS_SPACC_HASH_ALG(SPACC_HASH_ALG_POLY1305) != 0U) ? 1U : 0U);
    Check("the historical Poly1305 spelling is an alias",
          (SPACC_HASH_ALG_POIY305 == SPACC_HASH_ALG_POLY1305) ? 1U : 0U);
    Check("the historical CMD0 spelling is an alias",
          ((SPACC_IT_CMDO == SPACC_IT_CMD0) &&
           (SPACC_IT_STATE_CMDO == SPACC_IT_STATE_CMD0)) ? 1U : 0U);
    Check("SPACC_IT_ALL covers the global gate",
          ((SPACC_IT_ALL & (uint32)SPACC_IT_GLBL) != 0U) ? 1U : 0U);
    Check("SPACC_IT_STATUS_SOURCES excludes the global gate",
          ((SPACC_IT_STATUS_SOURCES & (uint32)SPACC_IT_GLBL) == 0U) ? 1U : 0U);

    Section("result");
    Summary();
    printf("***** SPACC HAL API coverage self test %s *****\r\n",
           ((failures == 0U) ? "success" : "failed"));

    for (;;)
    {
        delay_ms(TEST_POLL_MS);
    }
}


/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Report one section of the case.
 * @param  name: section name.
 * @retval None
 */
static void Section(const char *name)
{
    printf("\r\n---- %s ----\r\n", name);
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    checks++;

    if (condition == 0U)
    {
        failures++;
    }

    printf("%-58s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Print the check summary.
 * @retval None
 */
static void Summary(void)
{
    printf("\r\nchecks = %u, failures = %u\r\n", PRINT_U32(checks), PRINT_U32(failures));
    printf("summary : failures = %s\r\n", ((failures == 0U) ? "0 (PASS)" : "NON-ZERO (FAIL)"));
}

/**
 * @brief  Fill the two DDT structures and the pointer fields of the descriptor.
 * @param  src: source buffer.
 * @param  src_bytes: source segment length, in bytes.
 * @param  dst: destination buffer.
 * @param  dst_bytes: destination segment length, in bytes.
 * @retval None
 * @note   Both DDTs describe a single segment, the second entry is the NULL
 *         terminator. The byte counts and every offset of the descriptor are
 *         cleared here; the case overrides the fields it needs afterwards.
 */
static void Spacc_StageDdt(uint32 *src, uint32 src_bytes, uint32 *dst, uint32 dst_bytes)
{
    spacc_ddt_src.ddt.Ptr_0 = src;
    spacc_ddt_src.ddt.Len_0 = src_bytes;
    spacc_ddt_src.ddt.Ptr_1 = NULL_PTR;
    spacc_ddt_src.ddt.Len_1 = 0U;

    spacc_ddt_dst.ddt.Ptr_0 = dst;
    spacc_ddt_dst.ddt.Len_0 = dst_bytes;
    spacc_ddt_dst.ddt.Ptr_1 = NULL_PTR;
    spacc_ddt_dst.ddt.Len_1 = 0U;

    spacc_packet.SPACC_SourcePtr        = (uint32)(&spacc_ddt_src.ddt);
    spacc_packet.SPACC_DestinationPtr   = (uint32)(&spacc_ddt_dst.ddt);
    spacc_packet.SPACC_SouPREAADOffset  = 0U;
    spacc_packet.SPACC_DestPREAADOffset = 0U;
    spacc_packet.SPACC_PREAADLen        = 0U;
    spacc_packet.SPACC_POSTAADLen       = 0U;
    spacc_packet.SPACC_PROCLen          = (TEST_PACKET_WORDS * 4U);
    spacc_packet.SPACC_ICVLen           = 0U;
    spacc_packet.SPACC_ICVOffset        = 0U;
    spacc_packet.SPACC_IVOffset         = 0U;
    spacc_packet.SPACC_IVLocation       = SPACC_IV_LOCATION_CONTEXT;

    CLEAR_CACHE();
}

/**
 * @brief  Write the cipher context (key / IV) through the HAL context API.
 * @param  words: context words in the C representation (big endian wording).
 * @param  count: number of words.
 * @retval HAL status of HAL_SPACC_WriteContext().
 * @note   The values are byte swapped in a local buffer before the transfer,
 *         because the SPACC context store keeps them in the opposite order
 *         (the reference test project writes them through the same swap).
 */
static HAL_StatusTypeDef Spacc_WriteCipherContext(const uint32 *words, uint32 count)
{
    uint32 swapped[16];
    uint32 i;

    for (i = 0U; (i < count) && (i < 16U); i++)
    {
        swapped[i] = TEST_SWAP32(words[i]);
    }

    return HAL_SPACC_WriteContext(&hspacc_dev, SPACC_CIPHER_CONTEXT_BASE, 0U, swapped, count);
}

/**
 * @brief  Read the cipher context and undo the byte swap.
 * @param  words: destination buffer, in the C representation.
 * @param  count: number of words.
 * @retval HAL status of HAL_SPACC_ReadContext().
 */
static HAL_StatusTypeDef Spacc_ReadCipherContext(uint32 *words, uint32 count)
{
    uint32 raw[16];
    uint32 i;
    HAL_StatusTypeDef status;

    status = HAL_SPACC_ReadContext(&hspacc_dev, SPACC_CIPHER_CONTEXT_BASE, 0U, raw, count);

    for (i = 0U; (i < count) && (i < 16U); i++)
    {
        words[i] = TEST_SWAP32(raw[i]);
    }

    return status;
}

/**
 * @brief  Wait for a result and match its software identifier.
 * @param  software_id: identifier of the submitted task.
 * @retval 1 when a result was popped and its identifier matched, 0 otherwise.
 * @note   The wait is bounded, so a silent hardware problem is reported as a
 *         failed check instead of hanging the case.
 */
static uint32 Spacc_WaitResult(uint32 software_id)
{
    uint32 guard = TEST_WAIT_GUARD;

    while ((HAL_SPACC_StateFIFOFlag(&hspacc_dev) == SET) && (guard != 0U))
    {
        guard--;
    }

    CLEAR_CACHE();

    if (guard == 0U)
    {
        return 0U;
    }

    return (HAL_SPACC_CommandExecResult(&hspacc_dev, software_id) == SET) ? 1U : 0U;
}

/**
 * @brief  Wait, with a bound, until the status FIFO holds a result.
 * @retval 1 when a result is pending, 0 when the FIFO stayed empty.
 * @note   The result is left in the FIFO, so the caller can observe the pending
 *         state and eject the entry itself.
 */
static uint32 Spacc_WaitPending(void)
{
    uint32 guard = TEST_WAIT_GUARD;

    while ((HAL_SPACC_StateFIFOFlag(&hspacc_dev) == SET) && (guard != 0U))
    {
        guard--;
    }

    CLEAR_CACHE();

    return (guard != 0U) ? 1U : 0U;
}

/**
 * @brief  Pop every pending result so that the next submission starts clean.
 * @param  limit: maximum number of results to pop.
 * @retval None
 */
static void Spacc_Drain(uint32 limit)
{
    uint32 count = 0U;

    CLEAR_CACHE();

    while ((HAL_SPACC_StateFIFOFlag(&hspacc_dev) == RESET) && (count < limit))
    {
        (void)HAL_SPACC_CommandExecResult(&hspacc_dev, 0U);
        count++;
    }
}

/**
 * @brief  SPACC low level initialization: clock gate and reset release.
 * @param  hspacc: SPACC handle.
 * @retval None
 * @note   The SPACC is clocked by the AXILite4-Bus1 (DSE) domain, gated by the
 *         SMU. The call count lets the cases verify that the callback runs
 *         once, before the handle is locked.
 */
void HAL_SPACC_MspInit(HAL_SPACC_HandleTypeDef *hspacc)
{
    if (hspacc == NULL_PTR)
    {
        return;
    }

    msp_init_count++;

    __HAL_SMU_DSE_CLK_ENABLE();
    __HAL_SMU_DSE_FORCE_RESET();
    __HAL_SMU_DSE_RELEASE_RESET();
}

/**
 * @brief  SPACC low level de-initialization, counted for the life cycle checks.
 * @param  hspacc: SPACC handle.
 * @retval None
 */
void HAL_SPACC_MspDeInit(HAL_SPACC_HandleTypeDef *hspacc)
{
    if (hspacc == NULL_PTR)
    {
        return;
    }

    msp_deinit_count++;
}

/**
 * @brief  SPACC error callback, counted for the interrupt checks.
 * @param  hspacc: SPACC handle.
 * @retval None
 */
void HAL_SPACC_ErrorCallback(HAL_SPACC_HandleTypeDef *hspacc)
{
    (void)hspacc;

    error_callback_count++;
}

/**
 * @brief  Configure the system clock and the bus gates.
 * @retval None
 * @note   Same clock tree as the other HAL integration suites: the PLL is fed
 *         by the external oscillator (VCO 180 MHz) and the buses run at
 *         AXI4Bus3 / 2, APBBus0 / 2, APBBus1 / 2 and CANX2 / 8, which keeps
 *         the console USART on its usual 22.5 MHz.
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    smu_osc;
    SMU_ClockInitTypeDef  smu_clock;
    SMU_ClocksTypeDef     smu_clocks;
    HAL_PMU_HandleTypeDef hpmu;

    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Raise the core rail trim before the PLL is switched: the 1.2 V LDO APIs
     * are gated on the handle state, so the PMU must be initialized first */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    __HAL_CLEAR_STRUCT(&smu_osc);
    smu_osc.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    smu_osc.FIRCState            = SMU_FIRC_ON;
    smu_osc.FIRCCalibrationValue = 0x00U;
    smu_osc.PLL.PLLState         = SMU_PLL_ON;
    smu_osc.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    smu_osc.PLL.PLLDivR          = 0x04U;
    smu_osc.PLL.PLLDivQ          = 0x01U;
    smu_osc.PLL.PLLDivN          = 0x14U;
    smu_osc.PLL.PLLDivF          = 0xB4U;
    smu_osc.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    (void)HAL_SMU_OscConfig(&hsmu_clk, &smu_osc, SMU_TIMEOUT_DEFAULT);

    /* Bus dividers */
    __HAL_CLEAR_STRUCT(&smu_clock);
    smu_clock.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    smu_clock.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    smu_clock.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    smu_clock.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &smu_clock);

    (void)HAL_SMU_GetClocksFreq(&smu_clocks);

    /* The packet descriptor and the context memory are programmable before the
     * first initialization, so the AXILite4-Bus1 (DSE) clock gate and its reset
     * release must already be in place: the gate is not guaranteed to be open
     * after a power-on or a hardware reset, and an access of the unclocked block
     * stalls the bus. HAL_SPACC_MspInit() repeats both operations before the
     * first submission. */
    __HAL_SMU_DSE_CLK_ENABLE();
    __HAL_SMU_DSE_FORCE_RESET();
    __HAL_SMU_DSE_RELEASE_RESET();
}

/*****END OF FILE*****/
