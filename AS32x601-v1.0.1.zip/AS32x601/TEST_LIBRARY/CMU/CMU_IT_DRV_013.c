/**
 * @file    CMU_IT_DRV_013.c
 * @brief   HAL CMU integration test case 013 (init / de-init / status /
 *          error handling / monitoring mode).
 *
 * Extension test case of the HAL CMU driver: it exercises the initialization
 * and de-initialization functions, the configuration structure defaults, the
 * handle state and error reporting, the explicit monitoring mode setter and
 * the parameter validation of the driver. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_CMU_StructInit()
 *   HAL_CMU_Init()
 *   HAL_CMU_DeInit()
 *   HAL_CMU_SetMode()
 *   HAL_CMU_SetWindowLength()
 *   HAL_CMU_SetReferenceThreshold()
 *   HAL_CMU_Cmd()
 *   HAL_CMU_GetFlagStatus()
 *   HAL_CMU_ClearFlag()
 *   HAL_CMU_GetState() / HAL_CMU_GetError()
 *
 * Test procedure:
 *   1. Check the default values and the metafields of HAL_CMU_StructInit();
 *   2. Initialize an instance with HAL_CMU_Init() and check the handle state
 *      (READY) and the error code (NONE);
 *   3. Check that the monitoring stays disabled while the configured mode is
 *      zero (CMU_MODE_0) and that its registers can be read back;
 *   4. Select the monitoring mode explicitly with HAL_CMU_SetMode() and check
 *      the CR.MODE field, then disable the monitoring again;
 *   5. Enable the monitoring with HAL_CMU_Cmd() and check that the mode field
 *      becomes all ones;
 *   6. Check the parameter validation (out-of-range values are rejected with
 *      HAL_CMU_ERROR_INVALID_PARAM), the null handle protection and the state
 *      gate (a control function called before HAL_CMU_Init() is rejected);
 *   7. De-initialize the instance with HAL_CMU_DeInit() and check the state
 *      (RESET) and the reset configuration registers, then initialize it again.
 *
 * Expected behaviour:
 *   - HAL_CMU_StructInit() fills the defaults (monitoring disabled, window
 *     length = CMU_WINLEN_MIN, thresholds zero) and the Size / Version
 *     metafields;
 *   - HAL_CMU_Init() sets the state to READY and the error code to NONE;
 *   - HAL_CMU_SetMode() programs the requested CR.MODE value and keeps the
 *     other CR bits;
 *   - HAL_CMU_Cmd(CMU_ENABLE) sets CR.MODE to all ones;
 *   - the control functions return HAL_ERROR when the handle is NULL or when
 *     the handle has not been initialized (RESET), and HAL_BUSY while another
 *     operation is ongoing (no hard fault);
 *   - HAL_CMU_DeInit() clears the configuration registers and sets the state
 *     to RESET; the instance can be initialized again afterwards.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Configuration used by the checks */
#define TEST_WINDOW_LENGTH          (20000U)
#define TEST_HIGH_THRESHOLD         (19200U)
#define TEST_LOW_THRESHOLD          (12800U)

/* Monitoring mode selected in step 4 */
#define TEST_MODE                   (CMU_MODE_3)

/* Boundary values accepted by the driver (all ones of the 24-bit fields) */
#define TEST_MAX_WINDOW             (0x00FFFFFFU)
#define TEST_MAX_THRESHOLD          (0x00FFFFFFU)

/* Status flag polling period (ms) */
#define TEST_POLL_MS                (500U)

/* Private variables ---------------------------------------------------------*/
static HAL_CMU_HandleTypeDef hcmu_dev;      /*!< CMU device handle            */
static CMU_InitTypeDef       cmu_init;      /*!< CMU configuration structure  */
static uint32                failures = 0U; /*!< failed checks                */

static HAL_SMU_HandleTypeDef hsmu_clk;   /*!< SMU handle (lock / state / error) */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void Check(const char *name, uint32 condition);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    uint32 mode_before;
    uint32 mode_after;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL, 180 MHz core / PLLQ) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== CMU_IT_DRV_013: init / de-init / status / error ===\r\n");

    /* The handle lives in .bss, but it is cleared explicitly so that the
       instance binding never depends on the startup code of the project */
    __HAL_CLEAR_STRUCT(&hcmu_dev);
    hcmu_dev.Instance = CMU_PLLQ;

    while (1)
    {
        /* ---- Step 1: StructInit defaults ------------------------------- */
        printf("\r\n-----------------HAL_CMU_StructInit----------------- \r\n");
        (void)memset(&cmu_init, 0xA5, sizeof(cmu_init));
        HAL_CMU_StructInit(&cmu_init);

        Check("StructInit Size set", (cmu_init.Size == sizeof(CMU_InitTypeDef)));
        Check("StructInit Version set", (cmu_init.Version == CMU_INIT_VERSION));
        Check("StructInit mode = CMU_MODE_0", (cmu_init.MonitoringMode == CMU_MODE_0));
        Check("StructInit window = CMU_WINLEN_MIN",
              (cmu_init.WindowLength == CMU_WINLEN_MIN));
        Check("StructInit high = 0", (cmu_init.HighThreshold == 0U));
        Check("StructInit low = 0", (cmu_init.LowThreshold == 0U));
        Check("StructInit reserved = 0",
              ((cmu_init.Reserved[0] == 0U) && (cmu_init.Reserved[1] == 0U)));

        /* a null pointer must be accepted without touching any memory */
        HAL_CMU_StructInit(NULL_PTR);
        Check("StructInit(NULL) safe", 1U);

        /* ---- Step 2: Init, state and error ----------------------------- */
        printf("\r\n-----------------HAL_CMU_Init----------------- \r\n");
        HAL_CMU_StructInit(&cmu_init);
        cmu_init.MonitoringMode = CMU_MODE_0;
        cmu_init.WindowLength   = TEST_WINDOW_LENGTH;
        cmu_init.HighThreshold  = TEST_HIGH_THRESHOLD;
        cmu_init.LowThreshold   = TEST_LOW_THRESHOLD;
        hcmu_dev.Init = cmu_init;

        Check("Init returns HAL_OK", (HAL_CMU_Init(&hcmu_dev) == HAL_OK));
        Check("state = READY", (HAL_CMU_GetState(&hcmu_dev) == HAL_CMU_STATE_READY));
        Check("error = NONE", (HAL_CMU_GetError(&hcmu_dev) == HAL_CMU_ERROR_NONE));
        Check("Init programmed CCR", (hcmu_dev.Instance->CCR == TEST_WINDOW_LENGTH));
        Check("Init programmed HTCR", (hcmu_dev.Instance->HTCR == TEST_HIGH_THRESHOLD));
        Check("Init programmed LTCR", (hcmu_dev.Instance->LTCR == TEST_LOW_THRESHOLD));

        printf("state = %u, error = %u\r\n",
               PRINT_U32(HAL_CMU_GetState(&hcmu_dev)),
               PRINT_U32(HAL_CMU_GetError(&hcmu_dev)));

        /* ---- Step 3: a zero mode keeps the monitoring disabled --------- */
        printf("\r\n-----------------monitoring disabled (mode 0)----------------- \r\n");
        mode_before = hcmu_dev.Instance->CR & CMU_CR_MODE_Msk;
        Check("CR.MODE = 0 with mode 0", (mode_before == 0U));
        printf("CR = 0x%X (MODE field = 0x%X)\r\n",
               PRINT_U32(hcmu_dev.Instance->CR), PRINT_U32(mode_before));

        /* ---- Step 4: explicit mode selection --------------------------- */
        printf("\r\n-----------------HAL_CMU_SetMode----------------- \r\n");
        HAL_CMU_SetMode(&hcmu_dev, TEST_MODE);
        mode_after = hcmu_dev.Instance->CR & CMU_CR_MODE_Msk;
        Check("SetMode programmed CMU_MODE_3",
              (mode_after == (TEST_MODE << CMU_CR_MODE_Pos)));
        printf("CR = 0x%X (MODE field = 0x%X, expected 0x%X)\r\n",
               PRINT_U32(hcmu_dev.Instance->CR), PRINT_U32(mode_after),
               PRINT_U32(TEST_MODE << CMU_CR_MODE_Pos));

        /* keep the register write-back check of the other setters */
        HAL_CMU_SetWindowLength(&hcmu_dev, TEST_MAX_WINDOW);
        HAL_CMU_SetReferenceThreshold(&hcmu_dev, TEST_MAX_THRESHOLD, 0U);
        Check("SetWindowLength boundary accepted",
              (hcmu_dev.Instance->CCR == TEST_MAX_WINDOW));
        Check("SetReferenceThreshold boundary accepted",
              (hcmu_dev.Instance->HTCR == TEST_MAX_THRESHOLD));

        HAL_CMU_SetMode(&hcmu_dev, CMU_MODE_0);
        Check("SetMode 0 disables the monitoring",
              ((hcmu_dev.Instance->CR & CMU_CR_MODE_Msk) == 0U));

        /* ---- Step 5: Cmd enables with the maximum mode ----------------- */
        printf("\r\n-----------------HAL_CMU_Cmd----------------- \r\n");
        HAL_CMU_Cmd(&hcmu_dev, CMU_ENABLE);
        Check("Cmd(ENABLE) sets CR.MODE all ones",
              ((hcmu_dev.Instance->CR & CMU_CR_MODE_Msk) == CMU_CR_MODE_Msk));
        printf("CR after Cmd(CMU_ENABLE) = 0x%X\r\n", PRINT_U32(hcmu_dev.Instance->CR));

        HAL_CMU_Cmd(&hcmu_dev, CMU_DISABLE);
        Check("Cmd(DISABLE) clears CR.MODE",
              ((hcmu_dev.Instance->CR & CMU_CR_MODE_Msk) == 0U));

        /* ---- Step 6: flag access, parameter and null handle checks ----- */
        printf("\r\n-----------------flags and null handle checks----------------- \r\n");
        (void)HAL_CMU_GetFlagStatus(&hcmu_dev, CMU_FLAG_WORK);
        HAL_CMU_ClearFlag(&hcmu_dev, CMU_CLEAR_FHH);
        Check("GetFlagStatus(FHH) clear after ClearFlag",
              (HAL_CMU_GetFlagStatus(&hcmu_dev, CMU_FLAG_FHH) == 0U));

        /* the parameters outside the documented ranges are rejected at run
         * time and reported through HAL_CMU_ERROR_INVALID_PARAM */
        Check("SetMode(8) rejected + INVALID_PARAM",
              ((HAL_CMU_SetMode(&hcmu_dev, 8U) == HAL_ERROR) &&
               ((HAL_CMU_GetError(&hcmu_dev) & HAL_CMU_ERROR_INVALID_PARAM) != 0U)));
        Check("SetWindowLength(0x1000000) rejected",
              (HAL_CMU_SetWindowLength(&hcmu_dev, 0x1000000U) == HAL_ERROR));
        Check("SetReferenceThreshold(0x1000000) rejected",
              (HAL_CMU_SetReferenceThreshold(&hcmu_dev, 0x1000000U, 1U) == HAL_ERROR));
        Check("ClearFlag(0) rejected", (HAL_CMU_ClearFlag(&hcmu_dev, 0U) == HAL_ERROR));

        Check("Init(NULL) = HAL_ERROR", (HAL_CMU_Init(NULL_PTR) == HAL_ERROR));
        Check("DeInit(NULL) = HAL_ERROR", (HAL_CMU_DeInit(NULL_PTR) == HAL_ERROR));
        Check("GetFlagStatus(NULL) = 0",
              (HAL_CMU_GetFlagStatus(NULL_PTR, CMU_FLAG_FHH) == 0U));
        Check("GetState(NULL) = RESET",
              (HAL_CMU_GetState(NULL_PTR) == HAL_CMU_STATE_RESET));
        Check("GetError(NULL) = NONE",
              (HAL_CMU_GetError(NULL_PTR) == HAL_CMU_ERROR_NONE));

        /* the control functions report the rejected null handle with HAL_ERROR */
        Check("Cmd(NULL) = HAL_ERROR", (HAL_CMU_Cmd(NULL_PTR, CMU_ENABLE) == HAL_ERROR));
        Check("SetMode(NULL) = HAL_ERROR", (HAL_CMU_SetMode(NULL_PTR, CMU_MODE_1) == HAL_ERROR));
        Check("SetWindowLength(NULL) = HAL_ERROR",
              (HAL_CMU_SetWindowLength(NULL_PTR, 1U) == HAL_ERROR));
        Check("SetReferenceThreshold(NULL) = HAL_ERROR",
              (HAL_CMU_SetReferenceThreshold(NULL_PTR, 1U, 1U) == HAL_ERROR));
        Check("ClearFlag(NULL) = HAL_ERROR",
              (HAL_CMU_ClearFlag(NULL_PTR, CMU_CLEAR_FHH) == HAL_ERROR));

        /* the instance is still operational after the rejected calls */
        Check("still READY after NULL calls",
              (HAL_CMU_GetState(&hcmu_dev) == HAL_CMU_STATE_READY));

        /* ---- Step 7: DeInit and re-Init -------------------------------- */
        printf("\r\n-----------------HAL_CMU_DeInit----------------- \r\n");
        Check("DeInit returns HAL_OK", (HAL_CMU_DeInit(&hcmu_dev) == HAL_OK));
        Check("state = RESET", (HAL_CMU_GetState(&hcmu_dev) == HAL_CMU_STATE_RESET));
        Check("DeInit cleared CR", (hcmu_dev.Instance->CR == 0U));
        Check("DeInit cleared CCR", (hcmu_dev.Instance->CCR == 0U));
        Check("DeInit cleared HTCR", (hcmu_dev.Instance->HTCR == 0U));
        Check("DeInit cleared LTCR", (hcmu_dev.Instance->LTCR == 0U));

        /* a control function called before the initialization is rejected by
         * the state gate (the handle is in the RESET state) */
        Check("Cmd before Init = HAL_ERROR",
              (HAL_CMU_Cmd(&hcmu_dev, CMU_ENABLE) == HAL_ERROR));
        Check("SetMode before Init = HAL_ERROR",
              (HAL_CMU_SetMode(&hcmu_dev, CMU_MODE_1) == HAL_ERROR));
        Check("ClearFlag before Init = HAL_ERROR",
              (HAL_CMU_ClearFlag(&hcmu_dev, CMU_CLEAR_FHH) == HAL_ERROR));

        HAL_CMU_StructInit(&cmu_init);
        cmu_init.WindowLength  = TEST_WINDOW_LENGTH;
        cmu_init.HighThreshold = TEST_HIGH_THRESHOLD;
        cmu_init.LowThreshold  = TEST_LOW_THRESHOLD;
        hcmu_dev.Init = cmu_init;
        Check("re-Init after DeInit", (HAL_CMU_Init(&hcmu_dev) == HAL_OK));
        Check("state = READY after re-Init",
              (HAL_CMU_GetState(&hcmu_dev) == HAL_CMU_STATE_READY));

        printf("\r\nsummary : failures = %u\r\n", PRINT_U32(failures));
        delay_ms(TEST_POLL_MS);
    }
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition == 0U)
    {
        failures++;
    }
    printf("%-42s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Initialize the CMU MSP: enable the CMU clock gate and release the
 *         CMU reset.
 * @note   Strong override of the weak HAL_CMU_MspInit() of the driver: it
 *         reproduces the sequence of the original test case
 *         (CMUx_CLK_ENABLE(); CMUx_RESET(); CMUx_SET();), i.e. it enables the
 *         clock, asserts the reset and releases it again, so that the
 *         monitoring registers start from a known state. The driver default
 *         implementation enables the clock and releases the reset by setting
 *         the CMU0-3RST bits (setting = released, clearing = reset asserted).
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @retval None
 */
void HAL_CMU_MspInit(HAL_CMU_HandleTypeDef *hcmu)
{
    if (hcmu->Instance == CMU_FIRC)
    {
        __HAL_SMU_CMU0_CLK_ENABLE();
        __HAL_SMU_CMU0_FORCE_RESET();
        __HAL_SMU_CMU0_RELEASE_RESET();
    }
    else if (hcmu->Instance == CMU_PLLQ)
    {
        __HAL_SMU_CMU1_CLK_ENABLE();
        __HAL_SMU_CMU1_FORCE_RESET();
        __HAL_SMU_CMU1_RELEASE_RESET();
    }
    else if (hcmu->Instance == CMU_PLLR)
    {
        __HAL_SMU_CMU2_CLK_ENABLE();
        __HAL_SMU_CMU2_FORCE_RESET();
        __HAL_SMU_CMU2_RELEASE_RESET();
    }
    else
    {
        __HAL_SMU_CMU3_CLK_ENABLE();
        __HAL_SMU_CMU3_FORCE_RESET();
        __HAL_SMU_CMU3_RELEASE_RESET();
    }
}

/**
 * @brief  Configure the system clock tree using the HAL SMU / PMU drivers.
 * @note   Clock tree order (the order the chip requires): the bus clock
 *         dividers are written while the system clock is still the power-on
 *         source (FIRC), then HAL_SMU_OscConfig() programs the EFLASH
 *         controller clock, switches the system clock to the PLL and lets the
 *         flash clock follow. HAL_SMU_OscConfig() performs the EFLASH
 *         synchronization internally (CLKFRQ + EFLASH_CLK_UPDATE), so no
 *         explicit HAL_FLASH_SetClockFrequency() is needed here.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef  SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef   SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it (CLKFRQ above), so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Clock tree order: this is the order the chip requires, and the vendor
       test case uses the same one.
         1. Write the bus clock dividers while the system clock is still the
            power-on source (FIRC), so that the new divider values are already
            in place when the faster clock arrives. Writing them AFTER the
            switch instead leaves the buses at their reset dividers for a
            moment at the new core clock: at 180 MHz that is
            AXI4Bus3 = 90 MHz and APBBus0 = 45 MHz, right at their ratings, and
            the core does not survive it (measured on the board: the core
            trapped before the divider write was reached, so no output was
            produced at all).
         2. Program the EFLASH controller clock: the controller must already
            know the final frequency while the code still runs from the flash.
         3. Then configure the PLL and switch the system clock to it; this call
            also updates SystemCoreClock and re-initializes the HAL time base. */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
