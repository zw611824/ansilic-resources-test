# AS32x601 芯片规则

具体料号、封装、SDK/HAL 版本、设备头、启动文件、IRQ 分发和资源映射按目标工程核实。目录或专页存在不表示所有外设与模式均已支持。

## 时钟

外部时钟未知时确认实际频率；硬件设计尚未确定时可推荐有依据的输入配置，系统时钟目标单独按需求确定；已有工程、板级资料和用户明确要求优先。SDK 的 `peripherals/inc/as32x601_hal_conf_template.h` 中 `OSC_VALUE=20000000U` 仅为模板占位定义，不证明实物晶振频率或振荡器已启用。

生成时核实振荡器、PLL、分频、Flash/电压及外设时钟限制，不从 20 MHz 输入自动推导 180 MHz 输出。`SystemClock_Init` 是新建应用约定名；时钟配置参考 `TEST_LIBRARY/USART/USART_IT_DRV_024.c` 和 `TEST_LIBRARY/GPIO/GPIO_IT_DRV_008.c`，目录归属、具体实现及已有命名复用遵循 references/coding-standard.md，不照搬案例的文件位置。规划和交付分清输入假设、目标频率、已核实配置及未验证的板级事实。

## 外设资料

- 从 `TEST_LIBRARY/README.md` 进入目标外设 README，按 `references/retrieval-rules.md` 核对引脚、HAL 和匹配案例。ADC、MAC、QSPI 当前提供引脚参考，是否有独立案例以测试库索引为准。

新增专用规则需记录适用料号/版本、来源符号、限制及验证状态；未知项不能作为生成依据。

## 串口与 printf 的开发库差异

通用接入方式见 `references/printf-adaptation.md`（相对于 Skill 根目录）。以下为当前 AS32x601 开发库的观察，使用前对照目标版本核实，不代表板级验证通过：

- 推荐 USART0 或核对其他串口时，从 `TEST_LIBRARY/USART/README.md` 读取目标封装的 TX、RX 和对应 AF，并按工程或用户已确认的接线选用。
- 开发库的 `as32x601_print.c` 固定 USART0 并自行初始化句柄，不能原样叠加到应用的另一套串口初始化上；保留可用的 C 库适配，将输出交给应用的统一发送通道。
- 当前 `HAL_USART_Transmit` 经 `USART_CheckState` 在接收忙状态返回 `HAL_BUSY`；原 print 会忽略发送返回值，初始化失败也可能置 ready。共用收发时核实状态和错误恢复，独立句柄不等于隔离同一实例的寄存器。
- 依据位置：`HAL_LIBRARY/utils/README.md`、配套 `as32x601_print.c`、USART 驱动的 `HAL_USART_Transmit` / `USART_CheckState`、`TEST_LIBRARY/USART/README.md`，以及工程实际 C 库和链接脚本。
