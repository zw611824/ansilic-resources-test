/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:        as32x601_hal_pka.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.4
 * Date:            2026/11/05
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/09/04     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/17     1.1     remove the local IS_FunctionalState_STATE macro (the functional-state check
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.2     align the module with the library
 *                                                       architecture spec (resource lock and
 *                                                       RTOS chapters): give the shared lock
 *                                                       helper a Timeout parameter and a NULL
 *                                                       mutex guard, add the shared handle
 *                                                       validity and state helpers, run the
 *                                                       MSP callbacks outside the locked
 *                                                       region, report the guard path of
 *                                                       every locked entry point, apply the
 *                                                       busy / reset state gate, declare the
 *                                                       invalid parameter and timeout error
 *                                                       codes, validate the arguments at run
 *                                                       time and document the blocking
 *                                                       behaviour of every public prototype
 *                                                       is now provided by IS_FUNCTIONAL_STATE in as32x601_hal_def.h)
 *     ANSILIC APPLICATION GROUP  2026/10/09     1.3     align the module header block with the rest
 *                                                       of the library (value column and the
 *                                                       "Version:" label) and restore the " *"
 *                                                       prefix of the 1.2 history continuation
 *                                                       lines
 *     ANSILIC APPLICATION GROUP  2026/11/05     1.4     review fixes from the chip manual (ch.31) and from the desktop
 *                                                       twin (V1.0, 2026-10-23): PKA_STAT is write-one-to-clear, so
 *                                                       HAL_PKA_ClearStatus() writes the selected mask directly instead
 *                                                       of clearing bits of a read value; only STAT.DONE and IRQ_EN.IE
 *                                                       are implemented, so the status and interrupt selectors are
 *                                                       narrowed to DONE and the SIF / global masks stay as
 *                                                       compatibility spellings that IS_PKA_IT() and IS_PKA_IT_STATE()
 *                                                       reject; IS_PKA_FLAG() became mask style so a combination of
 *                                                       flags is accepted; the operand window is [0x400, 0x1400) and the
 *                                                       micro-code region [0x4000, 0x6000) with a guard that divides the
 *                                                       remaining bytes by the word width instead of multiplying Length
 *                                                       by 4 (a huge Length used to wrap the check open) plus an
 *                                                       alignment test, and HAL_PKA_LoadFirmware() now preflights every
 *                                                       entry against the micro-code region; a hardware-busy gate on
 *                                                       RTN_CODE.BUSY, an Init rollback when the lock cannot be taken,
 *                                                       an idempotent DeInit, field-width validation for the entry point
 *                                                       and the stack pointer, a BLOCKING tag on the three
 *                                                       Length-proportional services, PKA_STOP_REASON_UNKNOWN for an
 *                                                       unknown stop code, and an include of as32x601_hal.h first so a
 *                                                       direct includer sees the same USE_RTOS value (and therefore the
 *                                                       same handle size) as one that reaches this header through the
 *                                                       main HAL header.
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Public Key Accelerator
 *                  (PKA) peripheral:
 *                  - Initialization  (HAL_PKA_Init): configures the CONFIG
 *                    (alternate access / endian swap) and CTRL (partial
 *                    radix / base radix / M521 mode / stop request / GO)
 *                    registers from a PKA_InitTypeDef structure. The GO bit
 *                    is part of the Init structure: writing it to ENABLE
 *                    starts the PKA execution (see the example that
 *                    re-runs PKA_Init with GO enabled / disabled to launch /
 *                    stop an operation);
 *                  - Interrupt / flag management: HAL_PKA_ITConfig()
 *                    (IRQ_EN), HAL_PKA_GetFlagStatus() (FLAGS),
 *                    HAL_PKA_GetStatStatus() (STAT) and
 *                    HAL_PKA_ClearStatus() (STAT). The STAT flags are
 *                    write-0-clear (W0C): the status is cleared by writing a
 *                    0 to the corresponding bit (see the legacy PKA_ClearStatus);
 *                  - Program entry point / stack: HAL_PKA_SetEntryPoint()
 *                    (ENTRY_PNT program entry point) and HAL_PKA_ClearStack()
 *                    (STACK_PNTR stack pointer). The legacy PKA_SetStack wrote
 *                    ENTRY_PNT (a naming / register mismatch bug, fixed here:
 *                    the entry-point register is set by HAL_PKA_SetEntryPoint
 *                    and the stack pointer is cleared by HAL_PKA_ClearStack);
 *                  - Firmware load and operand memory access:
 *                    HAL_PKA_LoadFirmware() writes the PKA micro-code to the
 *                    firmware region and HAL_PKA_WriteData() / ReadData()
 *                    access the wide data register map (operand memory). The
 *                    wide register base address macros (PKA_ECC_ADDR_* /
 *                    PKA_RSA_ADDR_*) are kept so the examples can read &
 *                    write the operands directly.
 *                  - Status / state: HAL_PKA_GetStopReasonCode() returns the
 *                    RTN_CODE.STOP_REASON field, HAL_PKA_GetState() returns
 *                    the handle state.
 *                  This driver depends on as32x601_hal_def.h (HAL common
 *                  types and utilities). The PKA peripheral is clocked by
 *                  the AXILite4-Bus1 (DSE) domain, gated by the SMU (see
 *                  the DSE_CLK_ENABLE() / DSE_RESET() macros of
 *                  as32x601_smu.h): HAL_PKA_MspInit() is provided as an
 *                  empty weak function where the user enables the clock.
 *                  The PKA has a dedicated PLIC interrupt line
 *                  (PKA_IRQn = 0x0D): the user also enables it in
 *                  HAL_PKA_MspInit() and implements PKA_IRQ_Handler()
 *                  calling HAL_PKA_IRQHandler().
 *                  The chip PKA is a command-driven public key accelerator:
 *                  an operation is started by writing the CTRL.GO bit (through
 *                  the Init structure), executed by the PKA micro-code, and its
 *                  completion is observed by polling STAT.DONE (or by the
 *                  PKA_IT_DONE / PKA_IT_SIF_* interrupts).
 * @complexity  Simple
 *              Polling only (command-driven), lock + state machine,
 *              interrupt flag / handler support.
 */
#ifndef __AS32X601_HAL_PKA_H
#define __AS32X601_HAL_PKA_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
/* as32x601_hal.h comes first: it pulls the user configuration (which
 * defines USE_RTOS) before as32x601_hal_def.h selects the lock model,
 * so a translation unit that includes this driver header directly computes
 * the same handle layout as one that reaches it through the main HAL
 * header. */
#include "as32x601_hal.h"           /* HAL foundation: config, types, macros   */
#include "as32x601_hal_def.h"       /* HAL_StatusTypeDef, HAL_LockTypeDef      */
#include "as32x601.h"               /* PKA_TypeDef, PKA, register bits         */

/* Exported constants --------------------------------------------------------*/

/**
 * @brief PKA HAL driver module version.
 * @note  0x0100U = V1.0. Bumped only on breaking API changes (architecture
 *        spec COMPAT-13/14/15).
 */
#define __HAL_PKA_MODULE_VERSION  0x0100U

/* Exported types ------------------------------------------------------------*/

/** @defgroup PKA_Exported_Types PKA Exported Types
  * @{
  */

/**
 * @brief  PKA State structure definition
 * @note   The PKA runs as a command-driven coprocessor: the state is READY
 *         after the control registers are set. While an operation is running
 *         (CTRL.GO set) the state is BUSY; on completion STAT.DONE is set.
 */
typedef enum
{
    HAL_PKA_STATE_RESET   = 0x00U,                   /*!< PKA not yet initialized */
    HAL_PKA_STATE_READY   = 0x01U,                   /*!< PKA initialized and ready */
    HAL_PKA_STATE_BUSY    = 0x02U,                   /*!< PKA operation ongoing */
    HAL_PKA_STATE_ERROR   = 0x03U                    /*!< PKA error state */
} HAL_PKA_StateTypeDef;

/**
 * @brief  PKA Init Structure definition
 * @note   The fields keep the device-layer names (as32x601_pka.h) so that existing
 *         driver code can be migrated without change. The structure is
 *         applied to the CONFIG (alternate access / endian swap) and CTRL
 *         (partial radix / base radix / M521 mode / stop request / GO)
 *         registers by HAL_PKA_Init(). The GO field is a start trigger: the
 *         example fires an operation by re-running PKA_Init with
 *         PKA_Go = PKA_GO_EN (see PKA_Config_GoEnable / GoDisable).
 * @note   This structure follows the Version+Size compatibility mechanism
 *         (architecture spec section 22): the user must clear the structure
 *         (__HAL_CLEAR_STRUCT / memset), set the Size and Version metafields
 *         before filling the business fields (see HAL_PKA_StructInit()).
 */
typedef struct
{
    uint32 Size;                /*!< sizeof(PKA_InitTypeDef), must be set by the user
                                     after clearing the structure              */
    uint32 Version;             /*!< Structure semantic version: @ref PKA_INIT_VERSION
                                     (PKA_INIT_V1 = 0x0100U)                  */
    uint32 PKA_PartialRadix;    /*!< Selects a partial field within the base radix */
    uint32 PKA_BaseRadix;       /*!< Sets the size of the base operand size (radix) */
    uint32 PKA_M521Mode;        /*!< Sets operating to Mersenne M-521 */
    uint32 PKA_StopRqst;        /*!< Requests PKA to halt at the next instruction boundary */
    uint32 PKA_Go;              /*!< Starts the PKA operation */
    uint32 PKA_AltAccess;       /*!< C-memory access */
    uint32 PKA_EndianSwap;      /*!< Enable or disable the endian swap */
    uint32 Reserved[2];         /*!< Reserved for future extension (must be 0) */
} PKA_InitTypeDef;

/**
 * @brief  PKA / init structure version macros.
 * @note   PKA_INIT_V1 is the current version. Future versions (e.g. V2 with
 *         new fields) must be appended after the existing fields without
 *         changing the layout (architecture spec section 22.5).
 */
#define PKA_INIT_V1  0x0100U   /*!< PKA Init structure version V1.0 */
#define PKA_INIT_VERSION  PKA_INIT_V1   /*!< Current PKA Init structure version */

/**
 * @brief  PKA Handle Structure definition
 * @note   The handle keeps the standard HAL handle shape (Instance +
 *         Init + Lock + State + ErrorCode). Init stores the configuration
 *         applied by HAL_PKA_Init(). The PKA is a single-instance
 *         peripheral (Instance points to PKA).
 * @note   Field order follows the architecture spec HANDLE-02:
 *         Instance -> Init -> Lock -> State -> ErrorCode -> module fields.
 */
typedef struct __HAL_PKA_HandleTypeDef
{
    PKA_TypeDef             *Instance;             /*!< Register base address */
    PKA_InitTypeDef          Init;                 /*!< PKA communication parameters */
    HAL_LockTypeDef          Lock;                 /*!< PKA locking object */
    __IO HAL_PKA_StateTypeDef State;               /*!< PKA communication state */
    __IO uint32              ErrorCode;            /*!< PKA error code */
#if (USE_RTOS == 1)
    HAL_MutexTypeDef         LockMutex;            /*!< RTOS mutex handle (created by the
                                                      user porting layer, e.g. in
                                                      HAL_PKA_MspInit)                */
#endif /* USE_RTOS */
} HAL_PKA_HandleTypeDef;

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @defgroup PKA_Exported_Constants PKA Exported Constants
  * @{
  */

/** @defgroup PKA_Error_Code PKA Error Code
  * @{
  */
#define HAL_PKA_ERROR_NONE          ((uint32)0x00000000U) /*!< No error          */
#define HAL_PKA_ERROR_INVALID_PARAM ((uint32)0x00000004U) /*!< Invalid parameter or rejected operation */
#define HAL_PKA_ERROR_TIMEOUT       ((uint32)0x00000008U) /*!< Timeout error (reserved: this module has no blocking wait) */
/**
  * @}
  */

/** @defgroup PKA_Stop_Reason PKA Stop Reason Codes
  * @brief  PKA return code stop reason (RTN_CODE.STOP_REASON, bits 16-23).
  * @{
  */
typedef enum
{
    NORMAL_STOP                   = 0x00U,      /*!< Normal stop */
    INVALID_OP_CODE               = 0x01U,      /*!< Invalid op-code */
    STACK_UNDERFLOW               = 0x02U,      /*!< Stack underflow */
    STACK_OVERFLOW                = 0x03U,      /*!< Stack overflow */
    WATCHDOG                      = 0x04U,      /*!< Watchdog */
    HOST_REQUEST                  = 0x05U,      /*!< Host request */
    MEMORY_PORT_COLLISION         = 0x08U       /*!< Memory port collision */
} PKA_StopReasonEnum;
/* HAL-compatible alias: keeps the device-layer names and the prefix-less
    members for a zero-change migration; _TypeDef follows the HAL suffix.
    convention. */
typedef PKA_StopReasonEnum PKA_StopReasonTypeDef;
/* Prefixed member aliases (PKA_STOP_REASON_*) for the HAL prefix style. */
#define PKA_STOP_REASON_NORMAL_STOP        NORMAL_STOP
#define PKA_STOP_REASON_INVALID_OP_CODE    INVALID_OP_CODE
#define PKA_STOP_REASON_STACK_UNDERFLOW    STACK_UNDERFLOW
#define PKA_STOP_REASON_STACK_OVERFLOW     STACK_OVERFLOW
#define PKA_STOP_REASON_WATCHDOG           WATCHDOG
#define PKA_STOP_REASON_HOST_REQUEST       HOST_REQUEST
#define PKA_STOP_REASON_MEMORY_COLLISION   MEMORY_PORT_COLLISION
/* Out-of-enumeration value returned when RTN_CODE.STOP_REASON holds a code
   the manual reserves (the field is 8 bits wide) or one that matches no
   declared reason.  It is deliberately not an enumerator. */
#define PKA_STOP_REASON_UNKNOWN            ((uint32)0x000000FFU)
/**
  * @}
  */

/** @defgroup PKA_Base_Radix PKA Base Radix selection
  * @brief  Base radix selection definition (CTRL.BASE_RADIX).
  * @{
  */
#define PKA_BASE_RADIX_256                          ((uint32)0x00000002)  /*!< 256-bit */
#define PKA_BASE_RADIX_512                          ((uint32)0x00000003)  /*!< 512-bit */
#define PKA_BASE_RADIX_1024                         ((uint32)0x00000004)  /*!< 1024-bit */
#define PKA_BASE_RADIX_2048                         ((uint32)0x00000005)  /*!< 2048-bit */
#define PKA_BASE_RADIX_4096                         ((uint32)0x00000006)  /*!< 4096-bit */
#define IS_PKA_BASE_RADIX(RADIX)                    (((RADIX) == PKA_BASE_RADIX_256) || \
                                                     ((RADIX) == PKA_BASE_RADIX_512) || \
                                                     ((RADIX) == PKA_BASE_RADIX_1024) || \
                                                     ((RADIX) == PKA_BASE_RADIX_2048) || \
                                                     ((RADIX) == PKA_BASE_RADIX_4096))
/**
  * @}
  */
/** @defgroup PKA_Partial_Radix PKA Partial Radix selection
  * @brief  Partial radix definition (CTRL.PARTIAL_RADIX).  The field is an
  *         effective word count taken from the selected base, not a bitmap:
  *         the manual example sets it to 5 for a 256-bit base to process 5 of
  *         the 8 words, and to 17 to enable the Mersenne M-521 mode
  *         (ceiling(521 / 32) = 17).
  * @{
  */
#define PKA_PARTIAL_RADIX_M521                      ((uint32)0x00000011U)  /*!< 17 words: the M-521 length */
#define PKA_PARTIAL_RADIX_MAX                       ((uint32)0x000000FFU)  /*!< field width of CTRL.PARTIAL_RADIX */
#define IS_PKA_PARTIAL_RADIX(RADIX)                 (((RADIX) != 0U) && \
                                                     ((RADIX) <= PKA_PARTIAL_RADIX_MAX))
/**
  * @}
  */

/** @defgroup PKA_M521_Mode PKA Mersenne M-521 selection
  * @brief  M521 mode definition (CTRL.M521_MODE).  The manual states that the
  *         field must be 9 for the Mersenne M-521 mode and 0 for every other
  *         operand size, and that the field only exists in some
  *         configurations.
  * @{
  */
#define PKA_M521_MODE_NONE                          ((uint32)0x00000000)  /*!< Not an M-521 operation */
#define PKA_M521_MODE_M521                          ((uint32)0x00000009)  /*!< Mersenne M-521 mode */
#define IS_PKA_M521_MODE(MODE)                      (((MODE) == PKA_M521_MODE_NONE) || \
                                                     ((MODE) == PKA_M521_MODE_M521))
/**
  * @}
  */

/** @defgroup PKA_Stop_Rqst PKA Stop Request selection
  * @brief  Stop request selection definition (CTRL.STOP_RQST).
  * @{
  */
#define PKA_STOP_RQST_DIS                           ((uint32)0x00000000)  /*!< Stop request is disabled */
#define PKA_STOP_RQST_EN                            ((uint32)0x00000001)  /*!< Stop request is enabled */
#define IS_PKA_STOP_RQST(RQST)                      (((RQST) == PKA_STOP_RQST_DIS) || \
                                                     ((RQST) == PKA_STOP_RQST_EN))
/**
  * @}
  */

/** @defgroup PKA_Go PKA GO selection
  * @brief  GO selection definition (CTRL.GO).
  * @{
  */
#define PKA_GO_DIS                                  ((uint32)0x00000000)  /*!< Go is disabled */
#define PKA_GO_EN                                   ((uint32)0x00000001)  /*!< Go is enabled */
#define IS_PKA_GO(GO)                               (((GO) == PKA_GO_DIS) || \
                                                     ((GO) == PKA_GO_EN))
/**
  * @}
  */

/** @defgroup PKA_Alt_Access PKA Alternate Access selection
  * @brief  Alternate access selection definition (CONFIG.ALT_ACCESS).
  * @{
  */
#define PKA_ALT_ACCESS_NORMAL                       ((uint32)0x00000000)  /*!< Normal C-memory access */
#define PKA_ALT_ACCESS_DPA                          ((uint32)0x00000001)  /*!< Switch the C-memory read/write-access slot to the DPA shadow memory */
#define IS_PKA_ALT_ACCESS(ACCESS)                   (((ACCESS) == PKA_ALT_ACCESS_NORMAL) || \
                                                     ((ACCESS) == PKA_ALT_ACCESS_DPA))
/**
  * @}
  */

/** @defgroup PKA_Endian_Swap PKA Endian Swap selection
  * @brief  Endian swap selection definition (CONFIG.ENDIAN_SWAP).
  * @{
  */
#define PKA_ENDIAN_SWAP_LITTLE                      ((uint32)0x00000000)  /*!< Little-endian */
#define PKA_ENDIAN_SWAP_BIG                         ((uint32)0x00000001)  /*!< Big-endian */
#define IS_PKA_ENDIAN_SWAP(SWAP)                    (((SWAP) == PKA_ENDIAN_SWAP_LITTLE) || \
                                                     ((SWAP) == PKA_ENDIAN_SWAP_BIG))
/**
  * @}
  */

/** @defgroup PKA_State_Definitions PKA State (STAT) Definitions
  * @brief  PKA status selector (STAT register).  Only DONE is implemented.
  * @note   The manual (ch.31) implements bit 30 only: DONE is
  *         write-one-to-clear (a 1 acknowledges the pending interrupt, a 0 is
  *         a NOP) and bits 29:0 are reserved and must keep the reset value.
  *         The two historical SIF selectors are therefore not offered.
  * @{
  */
#define PKA_STATE_DONE                              PKA_STAT_DONE            /*!< The operation has completed (W1C) */
#define IS_PKA_IT_STATE(STATE)                       ((STATE) == PKA_STATE_DONE)
/**
  * @}
  */

/** @defgroup PKA_Flag_Definitions PKA Flag Definitions
  * @brief  PKA arithmetic flag definitions (FLAGS register). These are read
  *         by HAL_PKA_GetFlagStatus().
  * @{
  */
#define PKA_FLAG_ZERO                               PKA_FLAGS_Z              /*!< Zero flag */
#define PKA_FLAG_MEMORYTEST                         PKA_FLAGS_M              /*!< Memory-test flag */
#define PKA_FLAG_BORROW                             PKA_FLAGS_B              /*!< Borrow flag */
#define PKA_FLAG_CARRY                              PKA_FLAGS_C              /*!< Carry flag */
#define PKA_FLAG_USERFLAG0                          PKA_FLAGS_F0             /*!< User flag 0 */
#define PKA_FLAG_USERFLAG1                          PKA_FLAGS_F1             /*!< User flag 1 */
#define PKA_FLAG_USERFLAG2                          PKA_FLAGS_F2             /*!< User flag 2 */
#define PKA_FLAG_USERFLAG3                          PKA_FLAGS_F3             /*!< User flag 3 */
#define PKA_FLAG_ALL                                (PKA_FLAG_ZERO | PKA_FLAG_MEMORYTEST | \
                                                     PKA_FLAG_BORROW | PKA_FLAG_CARRY | \
                                                     PKA_FLAG_USERFLAG0 | PKA_FLAG_USERFLAG1 | \
                                                     PKA_FLAG_USERFLAG2 | PKA_FLAG_USERFLAG3)
/* Mask style so that a combination of flags is accepted, as the register is a
   bitmap: a non-zero selector with no bit outside PKA_FLAG_ALL. */
#define IS_PKA_FLAG(FLAG)                           (((FLAG) != 0U) && \
                                                     (((FLAG) & ~PKA_FLAG_ALL) == 0U))
/**
  * @}
  */

/** @defgroup PKA_IT_Definitions PKA Interrupt Enable Definitions
  * @brief  PKA interrupt enable definitions.  The values map the IRQ_EN
  *         register bits; the interrupt is enabled with HAL_PKA_ITConfig()
  *         or __HAL_PKA_ENABLE_IT().
  * @note   Only IRQ_EN bit 30 is implemented and it gates the O_irq output on
  *         STAT.DONE.  Bits 29:0 and bit 31 are reserved by the manual, so the
  *         historical SIF and global selectors below exist as compatibility
  *         spellings only: IS_PKA_IT() rejects them and the driver never
  *         enables them.
  * @{
  */
#define PKA_IT_SIF_ERR                              PKA_IRQ_EN_SIF_ERR_IE    /*!< Reserved bit (compatibility only) */
#define PKA_IT_SIF_SBE                              PKA_IRQ_EN_SIF_SBE_IE    /*!< Reserved bit (compatibility only) */
#define PKA_IT_DONE                                 PKA_IRQ_EN_DONE_IE       /*!< Enable interrupt on PKA done */
#define PKA_IT_GLB                                  PKA_IRQ_EN_GLB_IE        /*!< Reserved bit (compatibility only) */
#define PKA_IT_ALL                                  (PKA_IT_DONE)            /*!< Every usable source */
#define IS_PKA_IT(IT)                               (((IT) != 0U) && \
                                                     (((IT) & ~PKA_IT_ALL) == 0U))
/**
  * @}
  */

/** @defgroup PKA_Wide_Register_Map PKA Wide Register Map Base Addresses
  * @brief  PKA wide data register map base addresses. These are the absolute
  *         addresses of the operand (A / B / C / D) memory regions, used by
  *         the RSA / ECC algorithms to read & write the operands. They are
  *         kept from the device-layer header (as32x601_pka.h) so the examples can
  *         access the operands directly (memcpy) without change. The same
  *         regions can be accessed through HAL_PKA_WriteData() / ReadData().
  * @{
  */
/* ECC 256-bit operands */
#define PKA_ECC_ADDR_256_A0                         ((uint32)(PKA_BASE + 0x400))
#define PKA_ECC_ADDR_256_A1                         ((uint32)(PKA_BASE + 0x420))
#define PKA_ECC_ADDR_256_A2                         ((uint32)(PKA_BASE + 0x440))
#define PKA_ECC_ADDR_256_A3                         ((uint32)(PKA_BASE + 0x460))
#define PKA_ECC_ADDR_256_A4                         ((uint32)(PKA_BASE + 0x480))
#define PKA_ECC_ADDR_256_A5                         ((uint32)(PKA_BASE + 0x4A0))
#define PKA_ECC_ADDR_256_A6                         ((uint32)(PKA_BASE + 0x4C0))
#define PKA_ECC_ADDR_256_A7                         ((uint32)(PKA_BASE + 0x4E0))
#define PKA_ECC_ADDR_256_B0                         ((uint32)(PKA_BASE + 0x800))
#define PKA_ECC_ADDR_256_B1                         ((uint32)(PKA_BASE + 0x820))
#define PKA_ECC_ADDR_256_B2                         ((uint32)(PKA_BASE + 0x840))
#define PKA_ECC_ADDR_256_B3                         ((uint32)(PKA_BASE + 0x860))
#define PKA_ECC_ADDR_256_B4                         ((uint32)(PKA_BASE + 0x880))
#define PKA_ECC_ADDR_256_B5                         ((uint32)(PKA_BASE + 0x8A0))
#define PKA_ECC_ADDR_256_B6                         ((uint32)(PKA_BASE + 0x8C0))
#define PKA_ECC_ADDR_256_B7                         ((uint32)(PKA_BASE + 0x8E0))
#define PKA_ECC_ADDR_256_C0                         ((uint32)(PKA_BASE + 0xC00))
#define PKA_ECC_ADDR_256_C1                         ((uint32)(PKA_BASE + 0xC20))
#define PKA_ECC_ADDR_256_C2                         ((uint32)(PKA_BASE + 0xC40))
#define PKA_ECC_ADDR_256_C3                         ((uint32)(PKA_BASE + 0xC60))
#define PKA_ECC_ADDR_256_C4                         ((uint32)(PKA_BASE + 0xC80))
#define PKA_ECC_ADDR_256_C5                         ((uint32)(PKA_BASE + 0xCA0))
#define PKA_ECC_ADDR_256_C6                         ((uint32)(PKA_BASE + 0xCC0))
#define PKA_ECC_ADDR_256_C7                         ((uint32)(PKA_BASE + 0xCE0))
#define PKA_ECC_ADDR_256_D0                         ((uint32)(PKA_BASE + 0x1000))
#define PKA_ECC_ADDR_256_D1                         ((uint32)(PKA_BASE + 0x1020))
#define PKA_ECC_ADDR_256_D2                         ((uint32)(PKA_BASE + 0x1040))
#define PKA_ECC_ADDR_256_D3                         ((uint32)(PKA_BASE + 0x1060))
#define PKA_ECC_ADDR_256_D4                         ((uint32)(PKA_BASE + 0x1080))
#define PKA_ECC_ADDR_256_D5                         ((uint32)(PKA_BASE + 0x10A0))
#define PKA_ECC_ADDR_256_D6                         ((uint32)(PKA_BASE + 0x10C0))
#define PKA_ECC_ADDR_256_D7                         ((uint32)(PKA_BASE + 0x10E0))

/* ECC 512-bit operands */
#define PKA_ECC_ADDR_512_A0                         ((uint32)(PKA_BASE + 0x400))
#define PKA_ECC_ADDR_512_A1                         ((uint32)(PKA_BASE + 0x440))
#define PKA_ECC_ADDR_512_A2                         ((uint32)(PKA_BASE + 0x480))
#define PKA_ECC_ADDR_512_A3                         ((uint32)(PKA_BASE + 0x4C0))
#define PKA_ECC_ADDR_512_A4                         ((uint32)(PKA_BASE + 0x500))
#define PKA_ECC_ADDR_512_A5                         ((uint32)(PKA_BASE + 0x540))
#define PKA_ECC_ADDR_512_A6                         ((uint32)(PKA_BASE + 0x580))
#define PKA_ECC_ADDR_512_A7                         ((uint32)(PKA_BASE + 0x5C0))
#define PKA_ECC_ADDR_512_B0                         ((uint32)(PKA_BASE + 0x800))
#define PKA_ECC_ADDR_512_B1                         ((uint32)(PKA_BASE + 0x840))
#define PKA_ECC_ADDR_512_B2                         ((uint32)(PKA_BASE + 0x880))
#define PKA_ECC_ADDR_512_B3                         ((uint32)(PKA_BASE + 0x8C0))
#define PKA_ECC_ADDR_512_B4                         ((uint32)(PKA_BASE + 0x900))
#define PKA_ECC_ADDR_512_B5                         ((uint32)(PKA_BASE + 0x940))
#define PKA_ECC_ADDR_512_B6                         ((uint32)(PKA_BASE + 0x980))
#define PKA_ECC_ADDR_512_B7                         ((uint32)(PKA_BASE + 0x9C0))
#define PKA_ECC_ADDR_512_C0                         ((uint32)(PKA_BASE + 0xC00))
#define PKA_ECC_ADDR_512_C1                         ((uint32)(PKA_BASE + 0xC40))
#define PKA_ECC_ADDR_512_C2                         ((uint32)(PKA_BASE + 0xC80))
#define PKA_ECC_ADDR_512_C3                         ((uint32)(PKA_BASE + 0xCC0))
#define PKA_ECC_ADDR_512_C4                         ((uint32)(PKA_BASE + 0xD00))
#define PKA_ECC_ADDR_512_C5                         ((uint32)(PKA_BASE + 0xD40))
#define PKA_ECC_ADDR_512_C6                         ((uint32)(PKA_BASE + 0xD80))
#define PKA_ECC_ADDR_512_C7                         ((uint32)(PKA_BASE + 0xDC0))
#define PKA_ECC_ADDR_512_D0                         ((uint32)(PKA_BASE + 0x1000))
#define PKA_ECC_ADDR_512_D1                         ((uint32)(PKA_BASE + 0x1040))
#define PKA_ECC_ADDR_512_D2                         ((uint32)(PKA_BASE + 0x1080))
#define PKA_ECC_ADDR_512_D3                         ((uint32)(PKA_BASE + 0x10C0))
#define PKA_ECC_ADDR_512_D4                         ((uint32)(PKA_BASE + 0x1100))
#define PKA_ECC_ADDR_512_D5                         ((uint32)(PKA_BASE + 0x1140))
#define PKA_ECC_ADDR_512_D6                         ((uint32)(PKA_BASE + 0x1180))
#define PKA_ECC_ADDR_512_D7                         ((uint32)(PKA_BASE + 0x11C0))

/* ECC 1024-bit operands */
#define PKA_ECC_ADDR_1024_A0                        ((uint32)(PKA_BASE + 0x400))
#define PKA_ECC_ADDR_1024_A1                        ((uint32)(PKA_BASE + 0x480))
#define PKA_ECC_ADDR_1024_A2                        ((uint32)(PKA_BASE + 0x500))
#define PKA_ECC_ADDR_1024_A3                        ((uint32)(PKA_BASE + 0x580))
#define PKA_ECC_ADDR_1024_A4                        ((uint32)(PKA_BASE + 0x600))
#define PKA_ECC_ADDR_1024_A5                        ((uint32)(PKA_BASE + 0x680))
#define PKA_ECC_ADDR_1024_A6                        ((uint32)(PKA_BASE + 0x700))
#define PKA_ECC_ADDR_1024_A7                        ((uint32)(PKA_BASE + 0x780))
#define PKA_ECC_ADDR_1024_B0                        ((uint32)(PKA_BASE + 0x800))
#define PKA_ECC_ADDR_1024_B1                        ((uint32)(PKA_BASE + 0x880))
#define PKA_ECC_ADDR_1024_B2                        ((uint32)(PKA_BASE + 0x900))
#define PKA_ECC_ADDR_1024_B3                        ((uint32)(PKA_BASE + 0x980))
#define PKA_ECC_ADDR_1024_B4                        ((uint32)(PKA_BASE + 0xA00))
#define PKA_ECC_ADDR_1024_B5                        ((uint32)(PKA_BASE + 0xA80))
#define PKA_ECC_ADDR_1024_B6                        ((uint32)(PKA_BASE + 0xB00))
#define PKA_ECC_ADDR_1024_B7                        ((uint32)(PKA_BASE + 0xB80))
#define PKA_ECC_ADDR_1024_C0                        ((uint32)(PKA_BASE + 0xC00))
#define PKA_ECC_ADDR_1024_C1                        ((uint32)(PKA_BASE + 0xC80))
#define PKA_ECC_ADDR_1024_C2                        ((uint32)(PKA_BASE + 0xD00))
#define PKA_ECC_ADDR_1024_C3                        ((uint32)(PKA_BASE + 0xD80))
#define PKA_ECC_ADDR_1024_C4                        ((uint32)(PKA_BASE + 0xE00))
#define PKA_ECC_ADDR_1024_C5                        ((uint32)(PKA_BASE + 0xE80))
#define PKA_ECC_ADDR_1024_C6                        ((uint32)(PKA_BASE + 0xF00))
#define PKA_ECC_ADDR_1024_C7                        ((uint32)(PKA_BASE + 0xF80))
#define PKA_ECC_ADDR_1024_D0                        ((uint32)(PKA_BASE + 0x1000))
#define PKA_ECC_ADDR_1024_D1                        ((uint32)(PKA_BASE + 0x1080))
#define PKA_ECC_ADDR_1024_D2                        ((uint32)(PKA_BASE + 0x1100))
#define PKA_ECC_ADDR_1024_D3                        ((uint32)(PKA_BASE + 0x1180))
#define PKA_ECC_ADDR_1024_D4                        ((uint32)(PKA_BASE + 0x1200))
#define PKA_ECC_ADDR_1024_D5                        ((uint32)(PKA_BASE + 0x1280))
#define PKA_ECC_ADDR_1024_D6                        ((uint32)(PKA_BASE + 0x1300))
#define PKA_ECC_ADDR_1024_D7                        ((uint32)(PKA_BASE + 0x1380))

/* RSA 512-bit operands */
#define PKA_RSA_ADDR_512_A0                         ((uint32)(PKA_BASE + 0x400))
#define PKA_RSA_ADDR_512_A1                         ((uint32)(PKA_BASE + 0x440))
#define PKA_RSA_ADDR_512_A2                         ((uint32)(PKA_BASE + 0x480))
#define PKA_RSA_ADDR_512_A3                         ((uint32)(PKA_BASE + 0x4C0))
#define PKA_RSA_ADDR_512_B0                         ((uint32)(PKA_BASE + 0x800))
#define PKA_RSA_ADDR_512_B1                         ((uint32)(PKA_BASE + 0x840))
#define PKA_RSA_ADDR_512_B2                         ((uint32)(PKA_BASE + 0x880))
#define PKA_RSA_ADDR_512_B3                         ((uint32)(PKA_BASE + 0x8C0))
#define PKA_RSA_ADDR_512_C0                         ((uint32)(PKA_BASE + 0xC00))
#define PKA_RSA_ADDR_512_C1                         ((uint32)(PKA_BASE + 0xC40))
#define PKA_RSA_ADDR_512_C2                         ((uint32)(PKA_BASE + 0xC80))
#define PKA_RSA_ADDR_512_C3                         ((uint32)(PKA_BASE + 0xCC0))
#define PKA_RSA_ADDR_512_D0                         ((uint32)(PKA_BASE + 0x1000))
#define PKA_RSA_ADDR_512_D1                         ((uint32)(PKA_BASE + 0x1040))
#define PKA_RSA_ADDR_512_D2                         ((uint32)(PKA_BASE + 0x1080))
#define PKA_RSA_ADDR_512_D3                         ((uint32)(PKA_BASE + 0x10C0))
#define PKA_RSA_ADDR_512_D4                         ((uint32)(PKA_BASE + 0x1100))
#define PKA_RSA_ADDR_512_D5                         ((uint32)(PKA_BASE + 0x1140))
#define PKA_RSA_ADDR_512_D6                         ((uint32)(PKA_BASE + 0x1180))
#define PKA_RSA_ADDR_512_D7                         ((uint32)(PKA_BASE + 0x11C0))

/* RSA 1024-bit operands */
#define PKA_RSA_ADDR_1024_A0                        ((uint32)(PKA_BASE + 0x400))
#define PKA_RSA_ADDR_1024_A1                        ((uint32)(PKA_BASE + 0x480))
#define PKA_RSA_ADDR_1024_A2                        ((uint32)(PKA_BASE + 0x500))
#define PKA_RSA_ADDR_1024_A3                        ((uint32)(PKA_BASE + 0x580))
#define PKA_RSA_ADDR_1024_B0                        ((uint32)(PKA_BASE + 0x800))
#define PKA_RSA_ADDR_1024_B1                        ((uint32)(PKA_BASE + 0x880))
#define PKA_RSA_ADDR_1024_B2                        ((uint32)(PKA_BASE + 0x900))
#define PKA_RSA_ADDR_1024_B3                        ((uint32)(PKA_BASE + 0x980))
#define PKA_RSA_ADDR_1024_C0                        ((uint32)(PKA_BASE + 0xC00))
#define PKA_RSA_ADDR_1024_C1                        ((uint32)(PKA_BASE + 0xC80))
#define PKA_RSA_ADDR_1024_C2                        ((uint32)(PKA_BASE + 0xD00))
#define PKA_RSA_ADDR_1024_C3                        ((uint32)(PKA_BASE + 0xD80))
#define PKA_RSA_ADDR_1024_D0                        ((uint32)(PKA_BASE + 0x1000))
#define PKA_RSA_ADDR_1024_D1                        ((uint32)(PKA_BASE + 0x1080))
#define PKA_RSA_ADDR_1024_D2                        ((uint32)(PKA_BASE + 0x1100))
#define PKA_RSA_ADDR_1024_D3                        ((uint32)(PKA_BASE + 0x1180))
#define PKA_RSA_ADDR_1024_D4                        ((uint32)(PKA_BASE + 0x1200))
#define PKA_RSA_ADDR_1024_D5                        ((uint32)(PKA_BASE + 0x1280))
#define PKA_RSA_ADDR_1024_D6                        ((uint32)(PKA_BASE + 0x1300))
#define PKA_RSA_ADDR_1024_D7                        ((uint32)(PKA_BASE + 0x1380))

/* RSA 2048-bit operands */
#define PKA_RSA_ADDR_2048_A0                        ((uint32)(PKA_BASE + 0x400))
#define PKA_RSA_ADDR_2048_A1                        ((uint32)(PKA_BASE + 0x500))
#define PKA_RSA_ADDR_2048_A2                        ((uint32)(PKA_BASE + 0x600))
#define PKA_RSA_ADDR_2048_A3                        ((uint32)(PKA_BASE + 0x700))
#define PKA_RSA_ADDR_2048_B0                        ((uint32)(PKA_BASE + 0x800))
#define PKA_RSA_ADDR_2048_B1                        ((uint32)(PKA_BASE + 0x900))
#define PKA_RSA_ADDR_2048_B2                        ((uint32)(PKA_BASE + 0xA00))
#define PKA_RSA_ADDR_2048_B3                        ((uint32)(PKA_BASE + 0xB00))
#define PKA_RSA_ADDR_2048_C0                        ((uint32)(PKA_BASE + 0xC00))
#define PKA_RSA_ADDR_2048_C1                        ((uint32)(PKA_BASE + 0xD00))
#define PKA_RSA_ADDR_2048_C2                        ((uint32)(PKA_BASE + 0xE00))
#define PKA_RSA_ADDR_2048_C3                        ((uint32)(PKA_BASE + 0xF00))
#define PKA_RSA_ADDR_2048_D0                        ((uint32)(PKA_BASE + 0x1000))
#define PKA_RSA_ADDR_2048_D1                        ((uint32)(PKA_BASE + 0x1100))
#define PKA_RSA_ADDR_2048_D2                        ((uint32)(PKA_BASE + 0x1200))
#define PKA_RSA_ADDR_2048_D3                        ((uint32)(PKA_BASE + 0x1300))
#define PKA_RSA_ADDR_2048_D4                        ((uint32)(PKA_BASE + 0x1400))
#define PKA_RSA_ADDR_2048_D5                        ((uint32)(PKA_BASE + 0x1500))
#define PKA_RSA_ADDR_2048_D6                        ((uint32)(PKA_BASE + 0x1600))
#define PKA_RSA_ADDR_2048_D7                        ((uint32)(PKA_BASE + 0x1700))

/* RSA 4096-bit operands.

   Note: an operand address at or above 0x1400 lies outside the operand
   window that HAL_PKA_WriteData() / ReadData() accept -- the manual ends
   region D at 0x1400 and lists 0x1380 as the highest operand address.
   The macros below at 0x1400 and above are therefore absolute addresses
   for direct memory access only and cannot be passed as the Address
   argument of those two services. */
#define PKA_RSA_ADDR_4096_A0                        ((uint32)(PKA_BASE + 0x400))
#define PKA_RSA_ADDR_4096_A1                        ((uint32)(PKA_BASE + 0x600))
#define PKA_RSA_ADDR_4096_B0                        ((uint32)(PKA_BASE + 0x800))
#define PKA_RSA_ADDR_4096_B1                        ((uint32)(PKA_BASE + 0xA00))
#define PKA_RSA_ADDR_4096_C0                        ((uint32)(PKA_BASE + 0xC00))
#define PKA_RSA_ADDR_4096_C1                        ((uint32)(PKA_BASE + 0xE00))
#define PKA_RSA_ADDR_4096_D0                        ((uint32)(PKA_BASE + 0x1000))
#define PKA_RSA_ADDR_4096_D1                        ((uint32)(PKA_BASE + 0x1200))
#define PKA_RSA_ADDR_4096_D2                        ((uint32)(PKA_BASE + 0x1400))
#define PKA_RSA_ADDR_4096_D3                        ((uint32)(PKA_BASE + 0x1600))
/**
  * @}
  */

/**
  * @}
  */

/* Exported macros -----------------------------------------------------------*/

/** @defgroup PKA_Exported_Macros PKA Exported Macros
  * @{
  */

/** @brief  Reset PKA handle state
  * @param  __HANDLE__: PKA Handle
  * @retval None
  */
#define __HAL_PKA_RESET_HANDLE_STATE(__HANDLE__) ((__HANDLE__)->State = HAL_PKA_STATE_RESET)

/**
  * @brief  Enables the selected PKA interrupt.
  * @param  __HANDLE__: PKA Handle
  * @param  __IT__: PKA interrupt to enable (PKA_IT_*)
  * @retval None
  */
#define __HAL_PKA_ENABLE_IT(__HANDLE__, __IT__)   SET_BIT((__HANDLE__)->Instance->IRQ_EN, (__IT__))

/**
  * @brief  Disables the selected PKA interrupt.
  * @param  __HANDLE__: PKA Handle
  * @param  __IT__: PKA interrupt to disable (PKA_IT_*)
  * @retval None
  */
#define __HAL_PKA_DISABLE_IT(__HANDLE__, __IT__)  CLEAR_BIT((__HANDLE__)->Instance->IRQ_EN, (__IT__))

/**
  * @brief  Checks whether the specified PKA status flag is set.
  * @note   The STAT flags are write-0-clear (W0C). The SIF_ERR / SIF_SBE /
  *         DONE bits are read from the STAT register.
  * @param  __HANDLE__: PKA Handle
  * @param  __FLAG__: PKA status flag to check (PKA_STATE_*)
  * @retval The new state of __FLAG__ (SET or RESET).
  */
#define __HAL_PKA_GET_STAT(__HANDLE__, __FLAG__)  (READ_BIT((__HANDLE__)->Instance->STAT, (__FLAG__)) != 0U)

/**
  * @brief  Checks whether the specified PKA arithmetic flag is set.
  * @param  __HANDLE__: PKA Handle
  * @param  __FLAG__: PKA flag to check (PKA_FLAG_*)
  * @retval The new state of __FLAG__ (SET or RESET).
  */
#define __HAL_PKA_GET_FLAG(__HANDLE__, __FLAG__)  (READ_BIT((__HANDLE__)->Instance->FLAGS, (__FLAG__)) != 0U)

/**
  * @brief  Starts the PKA operation by writing CTRL.GO.
  * @param  __HANDLE__: PKA Handle
  * @retval None
  */
#define __HAL_PKA_GO(__HANDLE__)                  SET_BIT((__HANDLE__)->Instance->CTRL, PKA_CTRL_GO)

/**
  * @brief  Stops the PKA operation by clearing CTRL.GO.
  * @param  __HANDLE__: PKA Handle
  * @retval None
  */
#define __HAL_PKA_STOP(__HANDLE__)                CLEAR_BIT((__HANDLE__)->Instance->CTRL, PKA_CTRL_GO)

/**
  * @brief  Reads the raw INSTR_SINCE_GO register (instructions executed
  *         since the last GO command).
  * @param  __HANDLE__: PKA Handle
  * @retval Register value.
  */
#define __HAL_PKA_GET_INSTR_SINCE_GO(__HANDLE__)  READ_REG((__HANDLE__)->Instance->INSTR_SINCE_GO)

/**
  * @brief  Reads the raw CYCLES_SINCE_GO register (cycles since GO).
  * @param  __HANDLE__: PKA Handle
  * @retval Register value.
  */
#define __HAL_PKA_GET_CYCLES_SINCE_GO(__HANDLE__) READ_REG((__HANDLE__)->Instance->CYCLES_SINCE_GO)

/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/

/** @defgroup PKA_Exported_Functions PKA Exported Functions
  * @{
  */

/** @defgroup PKA_Exported_Functions_Group1 Initialization and de-initialization functions
  *  @brief    Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Fills each PKA_InitStruct member with its default value (NON-BLOCKING)
 *         (partial radix = 17, base radix = 256, GO disabled, normal
 *         alternate access, little-endian).
 * @param  Init: pointer to a PKA_InitTypeDef structure which will be
 *         initialized.
 * @retval None
 */
void HAL_PKA_StructInit(PKA_InitTypeDef *Init);

/**
 * @brief  Initializes the PKA peripheral according to the specified (NON-BLOCKING)
 *         parameters in the PKA_InitStruct of the handle.
 * @note   The operation is started / stopped by the CTRL.GO field of the
 *         Init structure: re-running the init with PKA_Go = PKA_GO_EN /
 *         PKA_GO_DIS launches / halts the PKA execution.
 * @note   The DSE clock gating and the PLIC interrupt line must be
 *         configured by the user in HAL_PKA_MspInit().
 * @param  hpka: pointer to a PKA_HandleTypeDef structure.
 * @param  Init: pointer to a PKA_InitTypeDef structure that contains the
 *         configuration for the PKA control registers.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_PKA_Init(HAL_PKA_HandleTypeDef *hpka, const PKA_InitTypeDef *Init);

/**
 * @brief  De-initializes the PKA peripheral. (NON-BLOCKING)
 * @note   Disables the interrupts and resets the CONFIG / CTRL / STACK_PNTR
 *         registers. The STAT status flags are not cleared here (they are
 *         write-0-clear by HAL_PKA_ClearStatus()).
 * @param  hpka: pointer to a PKA_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_PKA_DeInit(HAL_PKA_HandleTypeDef *hpka);

/**
 * @brief  Initializes the PKA MSP. Weak empty function; the user (NON-BLOCKING)
 *         implements the low level hardware initialization (DSE clock
 *         enable through the SMU, PLIC interrupt enable).
 * @param  hpka: pointer to a PKA_HandleTypeDef structure.
 * @retval None
 */
void HAL_PKA_MspInit(HAL_PKA_HandleTypeDef *hpka);

/**
 * @brief  De-initializes the PKA MSP. Weak empty function; the user (NON-BLOCKING)
 *         implements the low level hardware de-initialization.
 * @param  hpka: pointer to a PKA_HandleTypeDef structure.
 * @retval None
 */
void HAL_PKA_MspDeInit(HAL_PKA_HandleTypeDef *hpka);

/**
  * @}
  */

/** @defgroup PKA_Exported_Functions_Group2 IO operation functions
  *  @brief    IO operation functions
  * @{
  */

/**
 * @brief  Enables or disables the selected PKA interrupt. (NON-BLOCKING)
 * @param  hpka: pointer to a PKA_HandleTypeDef structure.
 * @param  ITType: PKA interrupt type (PKA_IT_*).
 * @param  NewState: ENABLE or DISABLE.
 * @retval None
 */
void HAL_PKA_ITConfig(HAL_PKA_HandleTypeDef *hpka, uint32 ITType, FunctionalState NewState);

/**
 * @brief  Checks whether the specified PKA status flag is set. (NON-BLOCKING)
 * @param  hpka: pointer to a PKA_HandleTypeDef structure.
 * @param  Stat: PKA status flag to check (PKA_STATE_*).
 * @retval FlagStatus: SET or RESET.
 */
FlagStatus HAL_PKA_GetStatStatus(HAL_PKA_HandleTypeDef *hpka, uint32 Stat);

/**
 * @brief  Checks whether the specified PKA arithmetic flag is set. (NON-BLOCKING)
 * @param  hpka: pointer to a PKA_HandleTypeDef structure.
 * @param  Flag: PKA flag to check (PKA_FLAG_*).
 * @retval FlagStatus: SET or RESET.
 */
FlagStatus HAL_PKA_GetFlagStatus(HAL_PKA_HandleTypeDef *hpka, uint32 Flag);

/**
 * @brief  Clears the PKA status flags (write-one-to-clear). (NON-BLOCKING)
 * @note   STAT.DONE is write-one-to-clear: writing a 1 to the selected bit
 *         acknowledges the pending interrupt, writing a 0 is a NOP.  The
 *         selected mask is written directly, never read-modified-written, so
 *         an unselected bit is never disturbed.  Only PKA_STATE_DONE is
 *         accepted because STAT[29:0] is reserved.
 * @param  hpka: pointer to a PKA_HandleTypeDef structure.
 * @param  Stat: PKA status flag to clear (PKA_STATE_*).
 * @retval None
 */
void HAL_PKA_ClearStatus(HAL_PKA_HandleTypeDef *hpka, uint32 Stat);

/**
 * @brief  Sets the PKA program entry point. (NON-BLOCKING)
 * @param  hpka: pointer to a PKA_HandleTypeDef structure.
 * @param  EntryPoint: program entry point (ENTRY_PNT.ADDR).
 * @retval None
 */
void HAL_PKA_SetEntryPoint(HAL_PKA_HandleTypeDef *hpka, uint32 EntryPoint);

/**
 * @brief  Clears the PKA stack pointer. (NON-BLOCKING)
 * @note   The manual requires clearing STACK_PNTR before a new operation
 *         after an abnormal stop (RTN_CODE.STOP_REASON different from zero).
 * @param  hpka: pointer to a PKA_HandleTypeDef structure.
 * @retval None
 */
void HAL_PKA_ClearStack(HAL_PKA_HandleTypeDef *hpka);

/**
 * @brief  Sets the PKA stack pointer. (NON-BLOCKING)
 * @note   The chip manual describes STACK_PNTR only indirectly: the control
 *         and status block is 384 bytes, so offset 0x10 belongs to it; the
 *         worked PKA example clears the F-Stack with a write to it; and the
 *         RTN_CODE description requires clearing it before a new operation
 *         after an abnormal stop.  The register is therefore implemented, but
 *         its bit layout is not documented field by field.
 * @note   Only the PNTR field is written and the value is validated against
 *         the field width.
 * @param  hpka: pointer to a PKA_HandleTypeDef structure.
 * @param  StackPointer: stack pointer (STACK_PNTR.PNTR).
 * @retval None
 */
void HAL_PKA_SetStackPointer(HAL_PKA_HandleTypeDef *hpka, uint32 StackPointer);

/**
 * @brief  Returns the PKA stop reason code (RTN_CODE.STOP_REASON). (NON-BLOCKING)
 * @note   A code that the manual reserves, or one that matches no declared
 *         reason, is returned as PKA_STOP_REASON_UNKNOWN instead of being
 *         folded into a known reason.
 * @param  hpka: pointer to a PKA_HandleTypeDef structure.
 * @retval PKA_StopReasonEnum: the stop reason code, or an out-of-enumeration
 *         value when the code is unknown.
 */
PKA_StopReasonEnum HAL_PKA_GetStopReasonCode(HAL_PKA_HandleTypeDef *hpka);

/**
 * @brief  Loads the PKA micro-code firmware. (BLOCKING)
 * @note   (BLOCKING) because the handle stays locked for one word per entry of
 *         Length.
 * @note   Every entry is validated before the first write: FirmwareAddr[i]
 *         must be a 4-byte aligned byte offset inside the micro-code region
 *         [PKA_FIRMWARE_OFFSET, PKA_FIRMWARE_END), that is 0x4000 up to but
 *         excluding 0x6000, and Length must not exceed
 *         PKA_FIRMWARE_WORDS_MAX (2048).  One invalid entry rejects the whole
 *         call without writing anything, so this path can no longer reach an
 *         arbitrary register.
 * @param  hpka: pointer to a PKA_HandleTypeDef structure.
 * @param  FirmwareAddr: pointer to the array of byte offsets of each
 *                       firmware entry.
 * @param  FirmwareData: pointer to the array of data values to write.
 * @param  Length: number of firmware entries to write.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_PKA_LoadFirmware(HAL_PKA_HandleTypeDef *hpka, const uint32 *FirmwareAddr,
                                       const uint32 *FirmwareData, uint32 Length);

/**
 * @brief  Writes data to the PKA wide data register map (operand memory). (BLOCKING)
 * @note   (BLOCKING) because the handle stays locked for one word per element
 *         of Length.
 * @note   Address is a byte offset from PKA_BASE inside the operand window
 *         [PKA_OPERAND_WINDOW_FIRST, PKA_OPERAND_WINDOW_END), that is 0x400 up
 *         to but excluding 0x1400, and it must be 4-byte aligned; Data must be
 *         4-byte aligned as well.  The upper bound is expressed as the
 *         remaining bytes divided by the word width, so a huge Length cannot
 *         wrap the check open.  Passing an absolute operand address
 *         (PKA_OPERAND_x_ADDR) instead of an offset is rejected.
 * @param  hpka: pointer to a PKA_HandleTypeDef structure.
 * @param  Address: byte offset from PKA_BASE inside the operand window.
 * @param  Data: pointer to the buffer to write.
 * @param  Length: number of 32-bit words to write.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_PKA_WriteData(HAL_PKA_HandleTypeDef *hpka, uint32 Address,
                                   const uint32 *Data, uint32 Length);

/**
 * @brief  Reads data from the PKA wide data register map (operand memory). (BLOCKING)
 * @note   (BLOCKING) because the handle stays locked for one word per element
 *         of Length.
 * @note   Address and Data obey the same window, alignment and wrap-around
 *         rules as HAL_PKA_WriteData().  Every bound is checked before the
 *         first read, so a rejected call leaves the output buffer untouched.
 * @param  hpka: pointer to a PKA_HandleTypeDef structure.
 * @param  Address: byte offset from PKA_BASE inside the operand window.
 * @param  Data: pointer to the buffer to store the read data.
 * @param  Length: number of 32-bit words to read.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_PKA_ReadData(HAL_PKA_HandleTypeDef *hpka, uint32 Address,
                                  uint32 *Data, uint32 Length);

/**
 * @brief  Handles the PKA interrupt request. (NON-BLOCKING)
 * @param  hpka: pointer to a PKA_HandleTypeDef structure.
 * @retval None
 */
void HAL_PKA_IRQHandler(HAL_PKA_HandleTypeDef *hpka);

/**
 * @brief  PKA error callback (WEAK). (NON-BLOCKING)
 * @note   Only STAT.DONE and IRQ_EN.IE are implemented by the peripheral, so
 *         the interrupt entry has no error source of its own to report.  An
 *         abnormal stop is reported through HAL_PKA_GetStopReasonCode(); the
 *         hook is kept so that an application which raises it from its own
 *         error detection keeps compiling.
 * @param  hpka: pointer to a PKA_HandleTypeDef structure.
 * @retval None
 */
void HAL_PKA_ErrorCallback(HAL_PKA_HandleTypeDef *hpka);

/**
  * @}
  */

/** @defgroup PKA_Exported_Functions_Group3 Peripheral State functions
  *  @brief    Peripheral State functions
  * @{
  */

/**
 * @brief  Returns the PKA handle state. (NON-BLOCKING)
 * @param  hpka: pointer to a PKA_HandleTypeDef structure.
 * @retval HAL_PKA_StateTypeDef: the current handle state.
 */
HAL_PKA_StateTypeDef HAL_PKA_GetState(HAL_PKA_HandleTypeDef *hpka);

/**
 * @brief  Returns the PKA error code. (NON-BLOCKING)
 * @param  hpka: pointer to a PKA_HandleTypeDef structure.
 * @retval uint32: the PKA error code (HAL_PKA_ERROR_xxx).
 */
uint32 HAL_PKA_GetError(HAL_PKA_HandleTypeDef *hpka);

/**
  * @}
  */
/**
  * @}
  */

/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/
/** @defgroup PKA_Private_Macros PKA Private Macros
  * @{
  */
#define IS_PKA_ALL_INSTANCE(INSTANCE) (((INSTANCE) == PKA))
/* Device-layer-compatible periph check alias (as32x601_pka.h uses IS_PKA_ALL_PERIPH) */
#define IS_PKA_ALL_PERIPH IS_PKA_ALL_INSTANCE
/* A configuration switch field accepts only its two declared values. */
#define IS_PKA_BINARY_VALUE(VALUE)                  (((VALUE) <= 1U))
/* ENTRY_PNT.ADDR holds a word index inside the 12-bit address field. */
#define IS_PKA_ENTRY_POINT(POINT)                   ((POINT) <= (PKA_ENTRY_PNT_ADDR_Msk >> PKA_ENTRY_PNT_ADDR_Pos))
/* STACK_PNTR.PNTR is a 12-bit pointer field. */
#define IS_PKA_STACK_POINTER(POINTER)               ((POINTER) <= (PKA_STACK_PNTR_PNTR_Msk >> PKA_STACK_PNTR_PNTR_Pos))
/* Operand window and firmware region geometry, in bytes below PKA_BASE.
   The manual (ch.31, tables 31.2 / 31.3) maps the control and status block to
   0x0..0x17F, the operand memory to A 0x400, B 0x800, C 0xC00 and D 0x1000
   with 1024 bytes each, and the micro-code region to 0x4000 with 8192 bytes;
   the highest operand address listed is 0x1380.  The two regions are separate
   validation domains and must not share one another's bounds. */
#define PKA_OPERAND_A_OFFSET                        ((uint32)0x00000400U)  /*!< Operand region A start */
#define PKA_OPERAND_B_OFFSET                        ((uint32)0x00000800U)  /*!< Operand region B start */
#define PKA_OPERAND_C_OFFSET                        ((uint32)0x00000C00U)  /*!< Operand region C start */
#define PKA_OPERAND_D_OFFSET                        ((uint32)0x00001000U)  /*!< Operand region D start */
#define PKA_OPERAND_REGION_SIZE                     ((uint32)0x00000400U)  /*!< One region, 1024 bytes */
#define PKA_OPERAND_WINDOW_FIRST                    (PKA_OPERAND_A_OFFSET)
#define PKA_OPERAND_WINDOW_SIZE                     ((uint32)0x00001000U)  /*!< 4096 bytes, 1024 words */
#define PKA_OPERAND_WINDOW_END                      (PKA_OPERAND_WINDOW_FIRST + PKA_OPERAND_WINDOW_SIZE)  /*!< 0x1400 */
#define PKA_FIRMWARE_OFFSET                         ((uint32)0x00004000U)  /*!< Micro-code region start */
#define PKA_FIRMWARE_SIZE                           ((uint32)0x00002000U)  /*!< 8192 bytes, 2048 words */
#define PKA_FIRMWARE_END                            (PKA_FIRMWARE_OFFSET + PKA_FIRMWARE_SIZE)  /*!< 0x6000 */
#define PKA_OPERAND_WINDOW_WORDS_MAX                (PKA_OPERAND_WINDOW_SIZE / 4U)
#define PKA_FIRMWARE_WORDS_MAX                      (PKA_FIRMWARE_SIZE / 4U)
/* Compatibility spellings used by the earlier releases of this driver. */
#define PKA_WIDE_REG_MAP_START                      PKA_OPERAND_WINDOW_FIRST
#define PKA_WIDE_REG_MAP_END                        PKA_OPERAND_WINDOW_END
/* The window guard is expressed as remaining bytes divided by the word width,
   never as the product Length * 4, so that a large Length cannot wrap the
   bound check open. */
#define PKA_WORD_BYTES                              (4U)
#define PKA_OFFSET_ALIGN_MASK                       (PKA_WORD_BYTES - 1U)
/* Operand window guard: region membership, 4-byte alignment, the total word
 * count and the room left from the requested offset.  The two length tests
 * divide the remaining bytes by the word width instead of multiplying Length
 * by 4, so a huge Length cannot wrap the comparison open. */
#define PKA_OPERAND_IN_RANGE(__ADDR__, __LEN__) \
    (((__LEN__) != 0U) && \
     (((__ADDR__) & PKA_OFFSET_ALIGN_MASK) == 0U) && \
     ((__ADDR__) >= PKA_OPERAND_WINDOW_FIRST) && \
     ((__ADDR__) <  PKA_OPERAND_WINDOW_END) && \
     ((__LEN__) <= ((PKA_OPERAND_WINDOW_END - PKA_OPERAND_WINDOW_FIRST) / PKA_WORD_BYTES)) && \
     ((__LEN__) <= ((PKA_OPERAND_WINDOW_END - (__ADDR__)) / PKA_WORD_BYTES)))
/* Same check for the micro-code region, used by HAL_PKA_LoadFirmware(). */
#define PKA_FIRMWARE_IN_RANGE(__ADDR__, __LEN__) \
    (((__LEN__) != 0U) && \
     (((__ADDR__) & PKA_OFFSET_ALIGN_MASK) == 0U) && \
     ((__ADDR__) >= PKA_FIRMWARE_OFFSET) && \
     ((__ADDR__) <  PKA_FIRMWARE_END) && \
     ((__LEN__) <= PKA_FIRMWARE_WORDS_MAX) && \
     ((__LEN__) <= ((PKA_FIRMWARE_END - (__ADDR__)) / PKA_WORD_BYTES)))
/* Compatibility spelling: the earlier releases called the operand guard
   PKA_WIDE_REG_MAP_IN_RANGE and validated Address + Length * 4. */
#define PKA_WIDE_REG_MAP_IN_RANGE(__ADDR__, __LEN__) PKA_OPERAND_IN_RANGE((__ADDR__), (__LEN__))

/**
  * @}
  */

/* Shared internal functions --------------------------------------------------*/

/**
 * @brief  Checks whether the PKA handle and its instance are valid.
 * @param  hpka: pointer to a HAL_PKA_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
uint32 PKA_HandleIsValid(HAL_PKA_HandleTypeDef *hpka);

/**
 * @brief  Checks whether the handle accepts a new operation (ARCH-CONST-09).
 * @note   A handle that is BUSY (an operation is ongoing in another context)
 *         rejects the call with HAL_BUSY, an uninitialized handle (RESET) with
 *         HAL_ERROR, while the recoverable state ERROR accepts it directly.
 * @param  hpka: pointer to a HAL_PKA_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef PKA_CheckState(HAL_PKA_HandleTypeDef *hpka);

/**
 * @brief  Validates one configuration structure against the manual's field
 *         domains.
 * @note   Beyond the per-field domains, the partial radix must not exceed
 *         the word count of the selected base radix (8, 16, 32, 64 or 128
 *         words for a 256, 512, 1024, 2048 or 4096-bit base) and the
 *         Mersenne M-521 mode accepts only its documented length of 17
 *         words.  The two metafields and the reserved words are checked by
 *         the caller, which owns the structure layout.
 * @param  Init: pointer to a PKA_InitTypeDef structure.
 * @retval uint32: 1 when every field is inside its domain, 0 otherwise.
 */
uint32 PKA_IsConfigurationValid(const PKA_InitTypeDef *Init);

/**
 * @brief  Lock the handle (RTOS mutex or single core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_PKA_MspInit()). The bare metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; the value is passed to HAL_MutexAcquire() as
 *         is (RTOS ticks; HAL_MAX_DELAY means an infinite wait).
 * @param  hpka: pointer to a HAL_PKA_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef PKA_LockHandle(HAL_PKA_HandleTypeDef *hpka, uint32 Timeout);

/**
 * @brief  Unlock the handle.
 * @param  hpka: pointer to a HAL_PKA_HandleTypeDef structure.
 * @retval None
 */
void PKA_UnlockHandle(HAL_PKA_HandleTypeDef *hpka);

/**
  * @}
  */

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_PKA_H */

/*****END OF FILE*****/
