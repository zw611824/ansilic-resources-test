/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):  	Xiamen Guoke Anxin Technology Co., LTD
 * FileName:     	as32x601_delay.c
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.0
 * Date:			2026/09/03
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/09/03     1.0     delay module for the
 *                                                       USART integration test
 * Description:     Delay functions for the AS32x601 USART integration test
 *                  project: the busy-wait loop counts the CPU cycle counter
 *                  (mcycle) instead of a peripheral timer, using exclusively
 *                  the HAL library CSR access macros (core_riscv.h, the same
 *                  source as the HAL time base).
 *                  API: delay_init() / delay_us() / delay_ms().
 */

/* Includes ------------------------------------------------------------------*/
#include "as32x601_delay.h"
#include "core_riscv.h"         /* csr_read, CSR_MCYCLE, CSR_MCYCLEH          */

/* Private variables ---------------------------------------------------------*/
static uint32 fac_us = 0U;      /*!< us delay multiplier: cycles per microsecond
                                     (= SYSCLK in MHz)                        */

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Read the CPU cycle counter (mcycle) as a 64-bit value.
 * @note   On RV32 the high and low halves are read with a consistency check
 *         (same pattern as the HAL time base in as32x601_hal.c).
 * @retval Current mcycle value.
 */
static uint64 read_cputick(void)
{
    uint32 hi;
    uint32 lo;

    do
    {
        hi = (uint32)csr_read(CSR_MCYCLEH);
        lo = (uint32)csr_read(CSR_MCYCLE);
    } while (hi != (uint32)csr_read(CSR_MCYCLEH));

    return ((uint64)hi << 32U) | (uint64)lo;
}

/* Exported functions --------------------------------------------------------*/

/**
 * @brief  Initialize the delay module.
 * @param  SYSCLK: system clock frequency, in MHz (cycles per microsecond).
 * @retval None
 */
void delay_init(uint32 SYSCLK)
{
    fac_us = SYSCLK;
}

/**
 * @brief  Microsecond delay.
 * @note   The mcycle counter is an up-counter: the elapsed cycles are
 *         accumulated from the counter deltas until the requested number of
 *         cycles is reached. The 64-bit wrap-around case is handled for
 *         completeness.
 * @param  nus: number of microseconds to delay (0..UINT32_MAX / SYSCLK).
 * @retval None
 */
void delay_us(uint32 nus)
{
    uint64 ticks;
    uint64 told;
    uint64 tnow;
    uint64 tcnt = 0U;
    uint64 reload = 0xFFFFFFFFFFFFFFFFULL;

    /* Required number of cycles */
    ticks = (uint64)nus * (uint64)fac_us;

    /* Counter value upon entry */
    told = read_cputick();

    while (1U)
    {
        tnow = read_cputick();
        if (tnow != told)
        {
            if (told < tnow)
            {
                tcnt += tnow - told;
            }
            else
            {
                /* The counter wrapped around (64-bit wrap, handled for
                 * completeness) */
                tcnt += reload - told + tnow;
            }
            told = tnow;

            /* Time reached / exceeded the requested delay: exit */
            if (tcnt >= ticks)
            {
                break;
            }
        }
    }
}

/**
 * @brief  Millisecond delay.
 * @param  nms: number of milliseconds to delay.
 * @retval None
 */
void delay_ms(uint32 nms)
{
    delay_us(nms * 1000U);
}

/*****END OF FILE*****/
