/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_i2c.c
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.5
 * Date:   2026/11/02
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.1     fix the blocking IO state
 *                                                       waiting logic: master
 *                                                       receive now accepts both
 *                                                       MREAD_DATA_ACK and
 *                                                       MREAD_DATA_NACK (the
 *                                                       last byte is NACKed, the
 *                                                       previous wait always
 *                                                       timed out on it); slave
 *                                                       transmit accepts both
 *                                                       SSEND_DATA_ACK and
 *                                                       SSEND_DATA_NACK; slave
 *                                                       receive accepts
 *                                                       SREV_STOP_MESSAGE as an
 *                                                       early master termination
 *                                                       (loop exits without
 *                                                       reading a non-existent
 *                                                       byte); add the
 *                                                       I2C_WaitStateOrUntilTimeout
 *                                                       helper for the dual-state
 *                                                       waits
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.2     add a runtime check of
 *                                                       the transfer parameters
 *                                                       (NULL data pointer or
 *                                                       zero size) to the four
 *                                                       blocking IO functions,
 *                                                       before the lock is taken;
 *                                                       remove the unused
 *                                                       I2C_STATUS_MASK constant
 *     ANSILIC APPLICATION GROUP  2026/09/17     1.3     align the resource lock and the RTOS support with
 *                                                       the architecture specification (sections 13 and
 *                                                       21): replace the public lock macro with the shared
 *                                                       helpers I2C_LockHandle (Timeout parameter and NULL
 *                                                       mutex guard, RTOS-11) / I2C_UnlockHandle and lock
 *                                                       the init / de-init as well; gate the register
 *                                                       accessing APIs with I2C_CheckState (ARCH-CONST-09,
 *                                                       the timeout / error states stay recoverable);
 *                                                       run the MSP callbacks outside the locked region
 *                                                       (LOCK-06) with the MSP init on the first
 *                                                       initialization only and before the first register
 *                                                       access (the callback enables the clock and the
 *                                                       pins); yield the CPU from the blocking wait loops
 *                                                       (RTOS-04)
 *     ANSILIC APPLICATION GROUP  2026/09/18     1.4     promote the peripheral control helpers to public
 *                                                       APIs - HAL_I2C_Cmd, HAL_I2C_ITInit,
 *                                                       HAL_I2C_GetITStatus and the interrupt safe
 *                                                       HAL_I2C_ClearITPendingBit - which removes the
 *                                                       unused static functions of the strict build and
 *                                                       makes the interrupt sources configurable and
 *                                                       acknowledgeable; add HAL_I2C_ERROR_INVALID_PARAM
 *                                                       with a runtime check of the configuration and
 *                                                       transfer parameters (the assert_param macro is
 *                                                       compiled out otherwise); defend the shared state
 *                                                       check against a NULL handle; align the
 *                                                       (BLOCKING) / (NON-BLOCKING) annotations with the
 *                                                       source file
 *     ANSILIC APPLICATION GROUP  2026/11/02     1.5     promote the atomic bus
 *                                                       step helpers to public
 *                                                       APIs - HAL_I2C_ITStructInit
 *                                                       and the interrupt safe
 *                                                       low level bus group
 *                                                       (HAL_I2C_GenerateStart /
 *                                                       HAL_I2C_GenerateStop /
 *                                                       HAL_I2C_StartClear /
 *                                                       HAL_I2C_Send7bitAddress /
 *                                                       HAL_I2C_AcknowledgeConfig /
 *                                                       HAL_I2C_SendData /
 *                                                       HAL_I2C_ReceiveData /
 *                                                       HAL_I2C_GetFlagStatus /
 *                                                       HAL_I2C_CheckStatus) - which
 *                                                       the integration suites drive
 *                                                       the bus with from the
 *                                                       interrupt service routine;
 *                                                       the group takes no lock and
 *                                                       no state gate
 *                                                       (ARCH-CONST-19 / LOCK-04)
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Inter-Integrated
 *                  Circuit (I2C) interface:
 *                  - Initialization and de-initialization: HAL_I2C_Init /
 *                    HAL_I2C_DeInit, configuration structure handling;
 *                  - IO operation functions (polling): master transmit /
 *                    receive, slave transmit / receive with timeout;
 *                  - Peripheral control: enable / disable (HAL_I2C_Cmd),
 *                    interrupt source configuration and acknowledgement
 *                    (HAL_I2C_ITInit / HAL_I2C_GetITStatus /
 *                    HAL_I2C_ClearITPendingBit);
 *                  - Interrupt safe low level bus functions: the atomic bus
 *                    steps (HAL_I2C_GenerateStart / HAL_I2C_GenerateStop /
 *                    HAL_I2C_StartClear / HAL_I2C_Send7bitAddress /
 *                    HAL_I2C_AcknowledgeConfig / HAL_I2C_SendData /
 *                    HAL_I2C_ReceiveData) and the running state queries
 *                    (HAL_I2C_GetFlagStatus / HAL_I2C_CheckStatus), so that
 *                    a user I2Cx_IRQ_Handler can drive the bus byte by byte
 *                    without taking the lock;
 *                  - State and error reporting: HAL_I2C_GetState /
 *                    HAL_I2C_GetError.
 *                  The module is layered as required by the architecture
 *                  specification: the public APIs own the resource lock and
 *                  the state gate, while the register access sequences
 *                  (Tier 3) execute with the lock already held.
 */
#include "as32x601_hal.h"          /* HAL_GetTick() / HAL_MAX_DELAY         */
#include "as32x601_hal_i2c.h"      /* I2C HAL API and register macros        */

/* The HAL_I2C_MODULE_ENABLED switch is provided by the user configuration
 * file (as32x601_hal_conf.h, included above through as32x601_hal.h): the
 * whole implementation is compiled only while the module is enabled. */
#ifdef HAL_I2C_MODULE_ENABLED

/* Private functions ---------------------------------------------------------*/

/* Private function prototypes (Tier 3 internal helpers, only used in this file) */
static void   I2C_GenerateStart(I2C_HandleTypeDef *hi2c);
static void   I2C_GenerateStop(I2C_HandleTypeDef *hi2c);
static void   I2C_StartClear(I2C_HandleTypeDef *hi2c);
static void   I2C_Send7bitAddress(I2C_HandleTypeDef *hi2c, uint8 Address, uint32 Direction);
static void   I2C_AcknowledgeConfig(I2C_HandleTypeDef *hi2c, uint32 Ackflag);
static void   I2C_SendData(I2C_HandleTypeDef *hi2c, uint8 Data);
static uint8  I2C_ReceiveData(I2C_HandleTypeDef *hi2c);
static void   I2C_ClearITPendingBit(I2C_HandleTypeDef *hi2c);
static uint8  I2C_GetFlagstatus(I2C_HandleTypeDef *hi2c);
static uint32 I2C_CheckStatus(I2C_HandleTypeDef *hi2c, uint8 Status);
static uint32 I2C_HandleIsValid(const I2C_HandleTypeDef *hi2c);

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Check the handle state before a register access.
 * @note   ARCH-CONST-09: a handle that is busy with another transfer rejects
 *         the call with HAL_BUSY, and a handle that was never initialized
 *         rejects it with HAL_ERROR (HAL_I2C_Init() is required first). The
 *         timeout / error states are recoverable and are ACCEPTED: the caller
 *         restarts the transfer, which resets the state to a busy state
 *         (STATE-06), so no DeInit / Init round trip is needed to retry.
 * @note   Not static: the helpers are part of the shared internal interface of
 *         the module (declared in as32x601_hal_i2c.h).
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef I2C_CheckState(I2C_HandleTypeDef *hi2c)
{
    /* A NULL handle cannot be inspected: report it as an uninitialized handle
     * (the outcome the caller would get from a handle in the reset state)
     * instead of dereferencing it. The public APIs check the pointer before
     * calling this helper, but it is also part of the shared internal
     * interface of the module, so it defends itself. */
    if (hi2c == NULL_PTR)
    {
        return HAL_ERROR;
    }

    if ((hi2c->State == HAL_I2C_STATE_BUSY) ||
        (hi2c->State == HAL_I2C_STATE_BUSY_TX) ||
        (hi2c->State == HAL_I2C_STATE_BUSY_RX))
    {
        return HAL_BUSY;
    }

    if (hi2c->State == HAL_I2C_STATE_RESET)
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_I2C_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the acquisition is bounded by the Timeout parameter;
 *         HAL_MAX_DELAY waits forever.
 * @note   Not static: the helpers are part of the shared internal interface of
 *         the module (declared in as32x601_hal_i2c.h).
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS, wait expired) /
 *         HAL_ERROR (RTOS, mutex not created) / HAL_BUSY (bare metal, the
 *         handle is already locked).
 */
HAL_StatusTypeDef I2C_LockHandle(I2C_HandleTypeDef *hi2c, uint32 Timeout)
{
#if (USE_RTOS == 1)
    if (hi2c->LockMutex == NULL_PTR)
    {
        /* The porting layer did not create the mutex (e.g. HAL_I2C_MspInit()
         * was not overridden): report it instead of calling the RTOS with a
         * NULL handle */
        return HAL_ERROR;
    }

    return HAL_MutexAcquire(hi2c->LockMutex, Timeout);
#else
    /* Prevent unused argument compilation warning: the bare-metal lock flag
     * either succeeds immediately or reports HAL_BUSY, it never waits */
    UNUSED(Timeout);

    if (hi2c->Lock == HAL_LOCKED)
    {
        return HAL_BUSY;
    }
    hi2c->Lock = HAL_LOCKED;
    return HAL_OK;
#endif /* USE_RTOS */
}

/**
 * @brief  Unlock the handle.
 * @note   Not static: the helpers are part of the shared internal interface of
 *         the module (declared in as32x601_hal_i2c.h).
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @retval None
 */
void I2C_UnlockHandle(I2C_HandleTypeDef *hi2c)
{
#if (USE_RTOS == 1)
    (void)HAL_MutexRelease(hi2c->LockMutex);
#else
    hi2c->Lock = HAL_UNLOCKED;
#endif /* USE_RTOS */
}

/**
 * @brief  Check the I2C handle and its peripheral instance.
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
static uint32 I2C_HandleIsValid(const I2C_HandleTypeDef *hi2c)
{
    return ((hi2c != NULL_PTR) && IS_I2C_ALL_PERIPH(hi2c->Instance));
}

/**
 * @brief  Wait for the I2C to reach a given running state, with timeout.
 * @note   Called while the caller holds the handle lock (the wait is bounded,
 *         so the lock is held on purpose); the polling loop yields the CPU in
 *         an RTOS build (RTOS-04/05, empty macro in a bare-metal build).
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  Status: the running state code to wait for (I2C_STATE_xxx).
 * @param  Timeout: maximum waiting time in ms (HAL_MAX_DELAY for infinite).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT
 */
static HAL_StatusTypeDef I2C_WaitStateUntilTimeout(I2C_HandleTypeDef *hi2c, uint8 Status, uint32 Timeout)
{
    uint32 tickstart = HAL_GetTick();

    /* Poll the running state until it reaches the expected state */
    while (I2C_CheckStatus(hi2c, Status) == 0U)
    {
        /* Check the timeout */
        if ((Timeout != HAL_MAX_DELAY) && ((HAL_GetTick() - tickstart) >= Timeout))
        {
            return HAL_TIMEOUT;
        }

#if (USE_RTOS == 1)
        /* RTOS-04: let the other tasks of the same priority run instead of
         * busy waiting (empty macro in a bare-metal build) */
        HAL_RTOS_Yield();
#endif /* USE_RTOS */
    }

    return HAL_OK;
}

/**
 * @brief  Wait for the I2C to reach one of two given running states, with
 *         timeout.
 * @note   The I2C state machine reports the acknowledge outcome (ACK or
 *         NACK) as two distinct states, and a STOP condition received from
 *         the master is reported as a dedicated state.  The blocking IO
 *         functions accept both outcomes as a valid transfer step.
 * @note   The polling loop yields the CPU in an RTOS build (RTOS-04/05, empty
 *         macro in a bare-metal build); the caller holds the handle lock.
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  Status1: first running state code to wait for (I2C_STATE_xxx).
 * @param  Status2: second running state code to wait for (I2C_STATE_xxx).
 * @param  Timeout: maximum waiting time in ms (HAL_MAX_DELAY for infinite).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT
 */
static HAL_StatusTypeDef I2C_WaitStateOrUntilTimeout(I2C_HandleTypeDef *hi2c, uint8 Status1, uint8 Status2,
                                                     uint32 Timeout)
{
    uint32 tickstart = HAL_GetTick();
    uint8  current = 0U;

    /* Poll the running state until it reaches one of the expected states */
    for (;;)
    {
        current = I2C_GetFlagstatus(hi2c);
        if ((current == Status1) || (current == Status2))
        {
            return HAL_OK;
        }

        /* Check the timeout */
        if ((Timeout != HAL_MAX_DELAY) && ((HAL_GetTick() - tickstart) >= Timeout))
        {
            return HAL_TIMEOUT;
        }

#if (USE_RTOS == 1)
        /* RTOS-04: let the other tasks of the same priority run instead of
         * busy waiting (empty macro in a bare-metal build) */
        HAL_RTOS_Yield();
#endif /* USE_RTOS */
    }
}

/* Exported functions --------------------------------------------------------*/

/** @addtogroup I2C_Exported_Functions
  * @{
  */

/** @addtogroup I2C_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Fills each I2C_InitStruct member with its default value. (NON-BLOCKING)
 * @param  I2C_InitStruct: pointer to an I2C_InitTypeDef structure which will
 *         be initialized.
 * @retval None
 */
void HAL_I2C_StructInit(I2C_InitTypeDef *I2C_InitStruct)
{
    /* Check the parameter */
    if (I2C_InitStruct == NULL_PTR)
    {
        return;
    }

    /* Reset the I2C init structure parameters values */
    I2C_InitStruct->Size            = sizeof(I2C_InitTypeDef);   /*!< sizeof struct  */
    I2C_InitStruct->Version         = I2C_INIT_VERSION;          /*!< V1             */
    I2C_InitStruct->I2C_ClockScale  = I2C_CLOCKSCALE_PCLK_256; /*!< Clock scale       */
    I2C_InitStruct->I2C_ICLKDIVL    = 0U;                      /*!< DIV low (for /8)  */
    I2C_InitStruct->I2C_ICLKDIVH    = 0U;                      /*!< DIV high (for /8) */
    I2C_InitStruct->I2C_EN          = I2C_DISABLE;             /*!< I2C enable        */
    I2C_InitStruct->I2C_SlaveAddress = 0U;                     /*!< Slave address     */
    I2C_InitStruct->I2C_Ack         = I2C_NACK;                /*!< Ack reply         */
    I2C_InitStruct->Reserved[0]     = 0U;                      /*!< Reserved          */
    I2C_InitStruct->Reserved[1]     = 0U;                      /*!< Reserved          */
}

/**
 * @brief  Initializes the I2C according to the specified parameters in the (NON-BLOCKING)
 *         I2C_InitStruct of the handle.
 * @note   The I2C clock gating and the pin multiplexing must be configured
 *         by the user in HAL_I2C_MspInit(); the callback runs on the first
 *         initialization (while the handle is in the reset state) and BEFORE
 *         the first register access, so that the peripheral clock and the
 *         pins are available when the configuration is written (MSP-04 /
 *         LOCK-06).
 * @note   Protected by the handle lock. A configuration parameter that is
 *         rejected at run time reports HAL_I2C_ERROR_INVALID_PARAM and leaves
 *         the handle state untouched, so a corrected configuration can be
 *         initialized directly afterwards (the reset state still selects the
 *         low level initialization).
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_I2C_Init(I2C_HandleTypeDef *hi2c)
{
    uint8 tmpreg = 0U;

    /* Check the I2C peripheral handle and instance */
    if (I2C_HandleIsValid(hi2c) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_I2C_CLOCKSCALE(hi2c->Init.I2C_ClockScale));
    assert_param((hi2c->Init.I2C_EN == I2C_ENABLE) || (hi2c->Init.I2C_EN == I2C_DISABLE));
    assert_param(IS_I2C_ACK_FLAG(hi2c->Init.I2C_Ack));
    assert_param(hi2c->Init.I2C_SlaveAddress <= 0x7FU);

    /* Runtime check of the configuration parameters (the assert_param macro is
     * compiled out unless USE_FULL_ASSERT is defined, so the values are
     * validated again here). The rejected call reports the invalid parameter
     * and does NOT touch the handle state: it neither takes the lock nor
     * changes State, so a corrected configuration is initialized directly. */
    if ((IS_I2C_CLOCKSCALE(hi2c->Init.I2C_ClockScale) == 0) ||
        ((hi2c->Init.I2C_EN != I2C_ENABLE) && (hi2c->Init.I2C_EN != I2C_DISABLE)) ||
        (IS_I2C_ACK_FLAG(hi2c->Init.I2C_Ack) == 0) ||
        (hi2c->Init.I2C_SlaveAddress > 0x7FU))
    {
        hi2c->ErrorCode = HAL_I2C_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* LOCK-06 / MSP-04: allocate the lock resource and run the low level
     * initialization BEFORE the handle is locked, and only on the first call
     * (avoid initializing the hardware twice). The MSP callback enables the
     * I2C clock gate and configures the pin multiplexing, so it has to run
     * before the first register access below: programming a clock gated
     * peripheral would lose the whole configuration. */
    if (hi2c->State == HAL_I2C_STATE_RESET)
    {
        hi2c->Lock = HAL_UNLOCKED;

        /* Initialize the MSP (clock enable, GPIO configuration) */
        HAL_I2C_MspInit(hi2c);
    }

    /* Process locked */
    if (I2C_LockHandle(hi2c, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state while configuring
     * (ARCH-CONST-10 / ERR-03 / STATE-03) */
    hi2c->ErrorCode = HAL_I2C_ERROR_NONE;
    hi2c->State     = HAL_I2C_STATE_BUSY;

    /* Configure the control register: clear the serial interrupt flag and
     * the clock field, set the clock scale, the enable bit and the
     * acknowledge flag in a single read-modify-write sequence */
    tmpreg = hi2c->Instance->CTLR;
    tmpreg &= ~((uint8)(I2C_CTRL_INT));
    tmpreg &= ~((uint8)(I2C_CTRL_CLK));
    tmpreg |= ((uint8)hi2c->Init.I2C_ClockScale);
    tmpreg &= ~((uint8)(I2C_CTRL_EN));
    if (hi2c->Init.I2C_EN == I2C_ENABLE)
    {
        tmpreg |= ((uint8)(I2C_CTRL_EN));
    }
    tmpreg &= ~((uint8)(I2C_CTRL_AA));
    if (hi2c->Init.I2C_Ack == I2C_ACK)
    {
        tmpreg |= ((uint8)(I2C_CTRL_AA));
    }
    hi2c->Instance->CTLR = tmpreg;

    /* When the /8 clock scale is selected, write the division factors */
    if (hi2c->Init.I2C_ClockScale == I2C_CLOCKSCALE_PCLK_8)
    {
        assert_param(hi2c->Init.I2C_ICLKDIVL <= 0xFFU);
        assert_param(hi2c->Init.I2C_ICLKDIVH <= 0xFFU);
        hi2c->Instance->DIV_L = hi2c->Init.I2C_ICLKDIVL;
        hi2c->Instance->DIV_H = hi2c->Init.I2C_ICLKDIVH;
    }

    /* Set the slave address (shifted left by one into the address field) */
    hi2c->Instance->ADDR = ((uint8)(hi2c->Init.I2C_SlaveAddress << 1U));

    hi2c->State = HAL_I2C_STATE_READY;

    /* Release Lock */
    I2C_UnlockHandle(hi2c);

    return HAL_OK;
}

/**
 * @brief  De-initializes the I2C peripheral. (NON-BLOCKING)
 * @note   The low level de-initialization callback runs after the handle lock
 *         has been released (LOCK-06), so an override may call other HAL APIs.
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_I2C_DeInit(I2C_HandleTypeDef *hi2c)
{
    /* Check the I2C peripheral handle and instance */
    if (I2C_HandleIsValid(hi2c) == 0U)
    {
        return HAL_ERROR;
    }

    /* Process locked */
    if (I2C_LockHandle(hi2c, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state while tearing the handle
     * down (ARCH-CONST-10 / ERR-03 / STATE-03) */
    hi2c->ErrorCode = HAL_I2C_ERROR_NONE;
    hi2c->State     = HAL_I2C_STATE_BUSY;

    /* Disable the I2C peripheral */
    hi2c->Instance->CTLR &= ~((uint8)(I2C_CTRL_EN));

    /* The handle goes back to the reset state so that a following
     * HAL_I2C_Init() runs the low level initialization again */
    hi2c->State = HAL_I2C_STATE_RESET;

    /* Release Lock */
    I2C_UnlockHandle(hi2c);

    /* LOCK-06 / ARCH-CONST-04: the low level de-initialization runs OUTSIDE
     * the locked region, as the architecture specification requires for the
     * MSP callbacks ("MspDeInit is called after the unlock"). The override may
     * call other HAL APIs (e.g. HAL_GPIO_DeInit()), which is only allowed
     * while the handle lock is not held. */
    HAL_I2C_MspDeInit(hi2c);

    return HAL_OK;
}

/**
 * @brief  Initializes the I2C MSP. Weak empty function; the user implements
 *         the low level hardware initialization.
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_I2C_MspInit(I2C_HandleTypeDef *hi2c)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hi2c);
}

/**
 * @brief  De-initializes the I2C MSP. Weak empty function; the user
 *         implements the low level hardware de-initialization.
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_I2C_MspDeInit(I2C_HandleTypeDef *hi2c)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hi2c);
}

/**
  * @}
  */

/** @addtogroup I2C_Exported_Functions_Group2 IO operation functions
  * @brief    Polling mode IO operations
  * @{
  */

/**
 * @brief  Transmits in master mode an amount of data in blocking mode. (BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  DevAddress: target device address (7 bits, 0x00..0x7F).
 * @param  pData: pointer to the data buffer to transmit.
 * @param  Size: amount of data to be sent, in bytes.
 * @param  Timeout: maximum waiting time in ms (HAL_MAX_DELAY for infinite).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_I2C_Master_Transmit(I2C_HandleTypeDef *hi2c, uint16 DevAddress, uint8 *pData, uint16 Size,
                                          uint32 Timeout)
{
    HAL_StatusTypeDef errorcode = HAL_OK;
    uint16 num = 0U;

    /* Check the I2C peripheral handle */
    if (hi2c == NULL_PTR)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_I2C_ALL_PERIPH(hi2c->Instance));
    assert_param(DevAddress <= 0x7FU);
    assert_param(pData != NULL_PTR);
    assert_param(Size > 0U);

    /* Runtime check of the transfer parameters (the assert_param macro is
     * compiled out unless USE_FULL_ASSERT is defined, so the values are
     * validated again here). The rejected call reports the invalid parameter
     * and does NOT touch the handle state; the check runs before the lock is
     * taken and before the state gate, so a call that is rejected here neither
     * consumes the lock resource nor disturbs an ongoing transfer. */
    if ((pData == NULL_PTR) || (Size == 0U) || (DevAddress > 0x7FU))
    {
        hi2c->ErrorCode = HAL_I2C_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another transfer is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_I2C_Init() is
     * required first). The timeout / error states are recoverable and are
     * accepted: the transfer below resets the state to a busy state
     * (STATE-06), so a retry needs no DeInit / Init round trip. */
    errorcode = I2C_CheckState(hi2c);
    if (errorcode != HAL_OK)
    {
        return errorcode;
    }

    /* Process locked */
    if (I2C_LockHandle(hi2c, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    do
    {
        /* Set the I2C state to busy TX and reset the error code */
        hi2c->State       = HAL_I2C_STATE_BUSY_TX;
        hi2c->ErrorCode   = HAL_I2C_ERROR_NONE;
        hi2c->pTxBuffPtr  = pData;
        hi2c->TxXferSize  = Size;
        hi2c->TxXferCount = Size;

        /* Enable the I2C peripheral if it is not already enabled */
        if ((hi2c->Instance->CTLR & I2C_CTRL_EN) == 0U)
        {
            hi2c->Instance->CTLR |= ((uint8)(I2C_CTRL_EN));
        }

        /* Wait for the bus to be idle (release the bus if occupied) */
        if (I2C_CheckStatus(hi2c, I2C_STATE_BUS_IDLE) == 0U)
        {
            I2C_StartClear(hi2c);
            I2C_GenerateStop(hi2c);
            I2C_ClearITPendingBit(hi2c);
            if (I2C_WaitStateUntilTimeout(hi2c, I2C_STATE_BUS_IDLE, Timeout) != HAL_OK)
            {
                errorcode = HAL_TIMEOUT;
                break;
            }
        }

        /* Generate the START condition */
        I2C_GenerateStart(hi2c);
        if (I2C_WaitStateUntilTimeout(hi2c, I2C_STATE_MASTER_START_READY, Timeout) != HAL_OK)
        {
            errorcode = HAL_TIMEOUT;
            break;
        }

        /* Send the slave address with the write direction, clear the START
         * flag and the serial interrupt flag */
        I2C_Send7bitAddress(hi2c, (uint8)DevAddress, I2C_WRITE);
        I2C_StartClear(hi2c);
        I2C_ClearITPendingBit(hi2c);

        /* Wait for the address byte to be acknowledged */
        if (I2C_WaitStateUntilTimeout(hi2c, I2C_STATE_MSEND_WADDR_ACK, Timeout) != HAL_OK)
        {
            errorcode = HAL_TIMEOUT;
            break;
        }

        /* Transmit all data bytes */
        for (num = 0U; num < Size; num++)
        {
            I2C_SendData(hi2c, pData[num]);
            I2C_ClearITPendingBit(hi2c);
            if (I2C_WaitStateUntilTimeout(hi2c, I2C_STATE_MSEND_DATA_ACK, Timeout) != HAL_OK)
            {
                errorcode = HAL_TIMEOUT;
                break;
            }
        }

        /* Generate the STOP condition and clear the serial interrupt flag */
        I2C_GenerateStop(hi2c);
        I2C_ClearITPendingBit(hi2c);
    }
    while (0);

    /* On error, set the error state and record the error code */
    if (errorcode != HAL_OK)
    {
        I2C_StartClear(hi2c);
        I2C_GenerateStop(hi2c);
        I2C_ClearITPendingBit(hi2c);
        if (hi2c->ErrorCode == HAL_I2C_ERROR_NONE)
        {
            hi2c->ErrorCode |= HAL_I2C_ERROR_TIMEOUT;
        }
        hi2c->State = HAL_I2C_STATE_ERROR;
    }
    else
    {
        hi2c->State = HAL_I2C_STATE_READY;
    }

    /* Process unlocked */
    I2C_UnlockHandle(hi2c);

    return errorcode;
}

/**
 * @brief  Receives in master mode an amount of data in blocking mode. (BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  DevAddress: target device address (7 bits, 0x00..0x7F).
 * @param  pData: pointer to the data buffer to store the received data.
 * @param  Size: amount of data to be received, in bytes.
 * @param  Timeout: maximum waiting time in ms (HAL_MAX_DELAY for infinite).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_I2C_Master_Receive(I2C_HandleTypeDef *hi2c, uint16 DevAddress, uint8 *pData, uint16 Size,
                                         uint32 Timeout)
{
    HAL_StatusTypeDef errorcode = HAL_OK;
    uint16 num = 0U;

    /* Check the I2C peripheral handle */
    if (hi2c == NULL_PTR)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_I2C_ALL_PERIPH(hi2c->Instance));
    assert_param(DevAddress <= 0x7FU);
    assert_param(pData != NULL_PTR);
    assert_param(Size > 0U);

    /* Runtime check of the transfer parameters (the assert_param macro is
     * compiled out unless USE_FULL_ASSERT is defined, so the values are
     * validated again here). The rejected call reports the invalid parameter
     * and does NOT touch the handle state; the check runs before the lock is
     * taken and before the state gate, so a call that is rejected here neither
     * consumes the lock resource nor disturbs an ongoing transfer. */
    if ((pData == NULL_PTR) || (Size == 0U) || (DevAddress > 0x7FU))
    {
        hi2c->ErrorCode = HAL_I2C_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another transfer is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_I2C_Init() is
     * required first). The timeout / error states are recoverable and are
     * accepted: the transfer below resets the state to a busy state
     * (STATE-06), so a retry needs no DeInit / Init round trip. */
    errorcode = I2C_CheckState(hi2c);
    if (errorcode != HAL_OK)
    {
        return errorcode;
    }

    /* Process locked */
    if (I2C_LockHandle(hi2c, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    do
    {
        /* Set the I2C state to busy RX and reset the error code */
        hi2c->State       = HAL_I2C_STATE_BUSY_RX;
        hi2c->ErrorCode   = HAL_I2C_ERROR_NONE;
        hi2c->pRxBuffPtr  = pData;
        hi2c->RxXferSize  = Size;
        hi2c->RxXferCount = Size;

        /* Enable the I2C peripheral if it is not already enabled */
        if ((hi2c->Instance->CTLR & I2C_CTRL_EN) == 0U)
        {
            hi2c->Instance->CTLR |= ((uint8)(I2C_CTRL_EN));
        }

        /* Wait for the bus to be idle (release the bus if occupied) */
        if (I2C_CheckStatus(hi2c, I2C_STATE_BUS_IDLE) == 0U)
        {
            I2C_StartClear(hi2c);
            I2C_GenerateStop(hi2c);
            I2C_ClearITPendingBit(hi2c);
            if (I2C_WaitStateUntilTimeout(hi2c, I2C_STATE_BUS_IDLE, Timeout) != HAL_OK)
            {
                errorcode = HAL_TIMEOUT;
                break;
            }
        }

        /* Assert ACK and generate the START condition */
        I2C_AcknowledgeConfig(hi2c, I2C_ACK);
        I2C_GenerateStart(hi2c);
        if (I2C_WaitStateUntilTimeout(hi2c, I2C_STATE_MASTER_START_READY, Timeout) != HAL_OK)
        {
            errorcode = HAL_TIMEOUT;
            break;
        }

        /* Send the slave address with the read direction, clear the serial
         * interrupt flag */
        I2C_Send7bitAddress(hi2c, (uint8)DevAddress, I2C_READ);
        I2C_ClearITPendingBit(hi2c);

        /* Wait for the address byte to be acknowledged */
        if (I2C_WaitStateUntilTimeout(hi2c, I2C_STATE_MSEND_RADDR_ACK, Timeout) != HAL_OK)
        {
            errorcode = HAL_TIMEOUT;
            break;
        }

        /* Receive all data bytes */
        for (num = 0U; num < Size; num++)
        {
            /* The last byte is acknowledged with a NACK, the others with an
             * ACK so that the slave keeps sending */
            if (num == (Size - 1U))
            {
                I2C_AcknowledgeConfig(hi2c, I2C_NACK);
            }
            else
            {
                I2C_AcknowledgeConfig(hi2c, I2C_ACK);
            }

            I2C_StartClear(hi2c);
            I2C_ClearITPendingBit(hi2c);

            /* Wait for the data byte to be received.  The last byte is
             * acknowledged with a NACK, so the state machine reports either
             * MREAD_DATA_ACK (bytes 0..N-2) or MREAD_DATA_NACK (last byte);
             * both mean the data register holds a valid received byte. */
            if (I2C_WaitStateOrUntilTimeout(hi2c, I2C_STATE_MREAD_DATA_ACK,
                                            I2C_STATE_MREAD_DATA_NACK, Timeout) != HAL_OK)
            {
                errorcode = HAL_TIMEOUT;
                break;
            }
            *pData++ = I2C_ReceiveData(hi2c);
        }

        /* Generate the STOP condition and clear the serial interrupt flag */
        I2C_StartClear(hi2c);
        I2C_GenerateStop(hi2c);
        I2C_ClearITPendingBit(hi2c);
    }
    while (0);

    /* On error, set the error state and record the error code */
    if (errorcode != HAL_OK)
    {
        I2C_StartClear(hi2c);
        I2C_GenerateStop(hi2c);
        I2C_ClearITPendingBit(hi2c);
        if (hi2c->ErrorCode == HAL_I2C_ERROR_NONE)
        {
            hi2c->ErrorCode |= HAL_I2C_ERROR_TIMEOUT;
        }
        hi2c->State = HAL_I2C_STATE_ERROR;
    }
    else
    {
        hi2c->State = HAL_I2C_STATE_READY;
    }

    /* Process unlocked */
    I2C_UnlockHandle(hi2c);

    return errorcode;
}

/**
 * @brief  Transmits in slave mode an amount of data in blocking mode. (BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  pData: pointer to the data buffer to transmit.
 * @param  Size: amount of data to be sent, in bytes.
 * @param  Timeout: maximum waiting time in ms (HAL_MAX_DELAY for infinite).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_I2C_Slave_Transmit(I2C_HandleTypeDef *hi2c, uint8 *pData, uint16 Size, uint32 Timeout)
{
    HAL_StatusTypeDef errorcode = HAL_OK;
    uint16 num = 0U;

    /* Check the I2C peripheral handle */
    if (hi2c == NULL_PTR)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_I2C_ALL_PERIPH(hi2c->Instance));
    assert_param(pData != NULL_PTR);
    assert_param(Size > 0U);

    /* Runtime check of the transfer parameters (the assert_param macro is
     * compiled out unless USE_FULL_ASSERT is defined, so the values are
     * validated again here). The rejected call reports the invalid parameter
     * and does NOT touch the handle state; the check runs before the lock is
     * taken and before the state gate, so a call that is rejected here neither
     * consumes the lock resource nor disturbs an ongoing transfer. */
    if ((pData == NULL_PTR) || (Size == 0U))
    {
        hi2c->ErrorCode = HAL_I2C_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another transfer is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_I2C_Init() is
     * required first). The timeout / error states are recoverable and are
     * accepted: the transfer below resets the state to a busy state
     * (STATE-06), so a retry needs no DeInit / Init round trip. */
    errorcode = I2C_CheckState(hi2c);
    if (errorcode != HAL_OK)
    {
        return errorcode;
    }

    /* Process locked */
    if (I2C_LockHandle(hi2c, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    do
    {
        /* Set the I2C state to busy TX and reset the error code */
        hi2c->State       = HAL_I2C_STATE_BUSY_TX;
        hi2c->ErrorCode   = HAL_I2C_ERROR_NONE;
        hi2c->pTxBuffPtr  = pData;
        hi2c->TxXferSize  = Size;
        hi2c->TxXferCount = Size;

        /* Enable the I2C peripheral if it is not already enabled */
        if ((hi2c->Instance->CTLR & I2C_CTRL_EN) == 0U)
        {
            hi2c->Instance->CTLR |= ((uint8)(I2C_CTRL_EN));
        }

        /* Wait for the bus to be idle */
        if (I2C_CheckStatus(hi2c, I2C_STATE_BUS_IDLE) == 0U)
        {
            I2C_StartClear(hi2c);
            I2C_GenerateStop(hi2c);
            I2C_ClearITPendingBit(hi2c);
            if (I2C_WaitStateUntilTimeout(hi2c, I2C_STATE_BUS_IDLE, Timeout) != HAL_OK)
            {
                errorcode = HAL_TIMEOUT;
                break;
            }
        }

        /* Assert ACK and wait for the master read request (address + R) */
        I2C_AcknowledgeConfig(hi2c, I2C_ACK);
        if (I2C_WaitStateUntilTimeout(hi2c, I2C_STATE_SREV_RADDR_ACK, Timeout) != HAL_OK)
        {
            errorcode = HAL_TIMEOUT;
            break;
        }

        /* Transmit all data bytes */
        for (num = 0U; num < Size; num++)
        {
            I2C_SendData(hi2c, pData[num]);
            if (num == (Size - 1U))
            {
                I2C_AcknowledgeConfig(hi2c, I2C_NACK);
            }
            else
            {
                I2C_AcknowledgeConfig(hi2c, I2C_ACK);
            }
            I2C_ClearITPendingBit(hi2c);

            /* Wait for the data byte to be acknowledged by the master.  The
             * master replies ACK (data accepted) or NACK (no more data wanted);
             * both outcomes complete the current byte transfer. */
            if (I2C_WaitStateOrUntilTimeout(hi2c, I2C_STATE_SSEND_DATA_ACK,
                                            I2C_STATE_SSEND_DATA_NACK, Timeout) != HAL_OK)
            {
                errorcode = HAL_TIMEOUT;
                break;
            }
        }

        I2C_ClearITPendingBit(hi2c);
    }
    while (0);

    /* On error, set the error state and record the error code */
    if (errorcode != HAL_OK)
    {
        I2C_GenerateStop(hi2c);
        I2C_ClearITPendingBit(hi2c);
        if (hi2c->ErrorCode == HAL_I2C_ERROR_NONE)
        {
            hi2c->ErrorCode |= HAL_I2C_ERROR_TIMEOUT;
        }
        hi2c->State = HAL_I2C_STATE_ERROR;
    }
    else
    {
        hi2c->State = HAL_I2C_STATE_READY;
    }

    /* Process unlocked */
    I2C_UnlockHandle(hi2c);

    return errorcode;
}

/**
 * @brief  Receives in slave mode an amount of data in blocking mode. (BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  pData: pointer to the data buffer to store the received data.
 * @param  Size: amount of data to be received, in bytes.
 * @param  Timeout: maximum waiting time in ms (HAL_MAX_DELAY for infinite).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_I2C_Slave_Receive(I2C_HandleTypeDef *hi2c, uint8 *pData, uint16 Size, uint32 Timeout)
{
    HAL_StatusTypeDef errorcode = HAL_OK;
    uint16 num = 0U;

    /* Check the I2C peripheral handle */
    if (hi2c == NULL_PTR)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_I2C_ALL_PERIPH(hi2c->Instance));
    assert_param(pData != NULL_PTR);
    assert_param(Size > 0U);

    /* Runtime check of the transfer parameters (the assert_param macro is
     * compiled out unless USE_FULL_ASSERT is defined, so the values are
     * validated again here). The rejected call reports the invalid parameter
     * and does NOT touch the handle state; the check runs before the lock is
     * taken and before the state gate, so a call that is rejected here neither
     * consumes the lock resource nor disturbs an ongoing transfer. */
    if ((pData == NULL_PTR) || (Size == 0U))
    {
        hi2c->ErrorCode = HAL_I2C_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another transfer is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_I2C_Init() is
     * required first). The timeout / error states are recoverable and are
     * accepted: the transfer below resets the state to a busy state
     * (STATE-06), so a retry needs no DeInit / Init round trip. */
    errorcode = I2C_CheckState(hi2c);
    if (errorcode != HAL_OK)
    {
        return errorcode;
    }

    /* Process locked */
    if (I2C_LockHandle(hi2c, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    do
    {
        /* Set the I2C state to busy RX and reset the error code */
        hi2c->State       = HAL_I2C_STATE_BUSY_RX;
        hi2c->ErrorCode   = HAL_I2C_ERROR_NONE;
        hi2c->pRxBuffPtr  = pData;
        hi2c->RxXferSize  = Size;
        hi2c->RxXferCount = Size;

        /* Enable the I2C peripheral if it is not already enabled */
        if ((hi2c->Instance->CTLR & I2C_CTRL_EN) == 0U)
        {
            hi2c->Instance->CTLR |= ((uint8)(I2C_CTRL_EN));
        }

        /* Wait for the bus to be idle */
        if (I2C_CheckStatus(hi2c, I2C_STATE_BUS_IDLE) == 0U)
        {
            I2C_StartClear(hi2c);
            I2C_GenerateStop(hi2c);
            I2C_ClearITPendingBit(hi2c);
            if (I2C_WaitStateUntilTimeout(hi2c, I2C_STATE_BUS_IDLE, Timeout) != HAL_OK)
            {
                errorcode = HAL_TIMEOUT;
                break;
            }
        }

        /* Wait for the master write request (address + W) */
        if (I2C_WaitStateUntilTimeout(hi2c, I2C_STATE_SREV_WADDR_ACK, Timeout) != HAL_OK)
        {
            errorcode = HAL_TIMEOUT;
            break;
        }

        /* Receive all data bytes */
        for (num = 0U; num < Size; num++)
        {
            /* Assert ACK so that the master keeps sending */
            I2C_AcknowledgeConfig(hi2c, I2C_ACK);
            I2C_ClearITPendingBit(hi2c);

            /* Wait for the data byte to be received.  The master may terminate
             * the transfer early with a STOP condition (SREV_STOP_MESSAGE);
             * in that case the transfer is considered finished and the loop
             * exits without reading a non-existent byte. */
            if (I2C_WaitStateOrUntilTimeout(hi2c, I2C_STATE_SREV_DATA_ACK,
                                            I2C_STATE_SREV_STOP_MESSAGE, Timeout) != HAL_OK)
            {
                errorcode = HAL_TIMEOUT;
                break;
            }

            /* The master terminated the transfer: stop receiving */
            if (I2C_GetFlagstatus(hi2c) == I2C_STATE_SREV_STOP_MESSAGE)
            {
                break;
            }

            *pData++ = I2C_ReceiveData(hi2c);
        }

        /* Assert NACK, generate the STOP condition and clear the serial
         * interrupt flag */
        I2C_AcknowledgeConfig(hi2c, I2C_NACK);
        I2C_GenerateStop(hi2c);
        I2C_ClearITPendingBit(hi2c);
    }
    while (0);

    /* On error, set the error state and record the error code */
    if (errorcode != HAL_OK)
    {
        I2C_GenerateStop(hi2c);
        I2C_ClearITPendingBit(hi2c);
        if (hi2c->ErrorCode == HAL_I2C_ERROR_NONE)
        {
            hi2c->ErrorCode |= HAL_I2C_ERROR_TIMEOUT;
        }
        hi2c->State = HAL_I2C_STATE_ERROR;
    }
    else
    {
        hi2c->State = HAL_I2C_STATE_READY;
    }

    /* Process unlocked */
    I2C_UnlockHandle(hi2c);

    return errorcode;
}

/**
  * @}
  */

/** @addtogroup I2C_Exported_Functions_Group3 Peripheral Control functions
  * @{
  */

/**
 * @brief  Return the I2C handle state. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @retval HAL_I2C_StateTypeDef: the current handle state.
 */
HAL_I2C_StateTypeDef HAL_I2C_GetState(I2C_HandleTypeDef *hi2c)
{
    /* Check the I2C peripheral handle */
    if (hi2c == NULL_PTR)
    {
        return HAL_I2C_STATE_RESET;
    }

    return hi2c->State;
}

/**
 * @brief  Return the I2C error code. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @retval uint32: the I2C error code (HAL_I2C_ERROR_xxx).
 */
uint32 HAL_I2C_GetError(I2C_HandleTypeDef *hi2c)
{
    /* Check the I2C peripheral handle */
    if (hi2c == NULL_PTR)
    {
        return HAL_I2C_ERROR_NONE;
    }

    return hi2c->ErrorCode;
}

/**
 * @brief  Enables or disables the specified I2C peripheral. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  NewState: ENABLE or DISABLE.
 * @note   Protected by the handle lock and gated by the handle state
 *         (ARCH-CONST-09): the call is rejected with HAL_BUSY while another
 *         transfer is ongoing (the peripheral is being driven by it) and with
 *         HAL_ERROR while the handle has not been initialized.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_I2C_Cmd(I2C_HandleTypeDef *hi2c, FunctionalState NewState)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the I2C peripheral handle */
    if (hi2c == NULL_PTR)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_I2C_ALL_PERIPH(hi2c->Instance));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* ARCH-CONST-09: reject the call while another transfer is ongoing or
     * before HAL_I2C_Init() has been called (the register write below would
     * disturb the transfer sequence or configure a clock gated peripheral) */
    status = I2C_CheckState(hi2c);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (I2C_LockHandle(hi2c, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    if (NewState != DISABLE)
    {
        /* Enable the I2C peripheral */
        hi2c->Instance->CTLR |= ((uint8)(I2C_CTRL_EN));
    }
    else
    {
        /* Disable the I2C peripheral */
        hi2c->Instance->CTLR &= ~((uint8)(I2C_CTRL_EN));
    }

    /* Process unlocked */
    I2C_UnlockHandle(hi2c);

    return HAL_OK;
}

/**
 * @brief  Initializes the I2C interrupts according to the specified
 *         parameters in the I2C_IRQStruct. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  I2C_IRQStruct: pointer to an I2C_IRQTypeDef structure.
 * @note   Protected by the handle lock and gated by the handle state
 *         (ARCH-CONST-09). A configuration value that is rejected at run time
 *         reports HAL_I2C_ERROR_INVALID_PARAM and leaves the interrupt control
 *         register untouched.
 * @note   The interrupt service routine is provided by the user (the weak
 *         I2Cx_IRQ_Handler entry point of the interrupt controller module); it
 *         can query the serial interrupt flag with HAL_I2C_GetITStatus() and
 *         clear it with HAL_I2C_ClearITPendingBit(), both of which are safe to
 *         call from an interrupt service routine. Note that the polling APIs
 *         of this driver drive the same serial interrupt flag internally.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_I2C_ITInit(I2C_HandleTypeDef *hi2c, I2C_IRQTypeDef *I2C_IRQStruct)
{
    HAL_StatusTypeDef status = HAL_OK;
    uint8 tmpreg = 0U;

    /* Check the I2C peripheral handle and the configuration structure */
    if ((hi2c == NULL_PTR) || (I2C_IRQStruct == NULL_PTR))
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_I2C_ALL_PERIPH(hi2c->Instance));
    assert_param((I2C_IRQStruct->ERRN == I2C_ENABLE) || (I2C_IRQStruct->ERRN == I2C_DISABLE));
    assert_param((I2C_IRQStruct->SIEN == I2C_ENABLE) || (I2C_IRQStruct->SIEN == I2C_DISABLE));
    assert_param((I2C_IRQStruct->TXEN == I2C_ENABLE) || (I2C_IRQStruct->TXEN == I2C_DISABLE));
    assert_param((I2C_IRQStruct->RXEN == I2C_ENABLE) || (I2C_IRQStruct->RXEN == I2C_DISABLE));

    /* Runtime check of the interrupt configuration (the assert_param macro is
     * compiled out unless USE_FULL_ASSERT is defined). The rejected call
     * reports the invalid parameter before the lock is taken, so it neither
     * consumes the lock resource nor changes the register contents. */
    if (((I2C_IRQStruct->ERRN != I2C_ENABLE) && (I2C_IRQStruct->ERRN != I2C_DISABLE)) ||
        ((I2C_IRQStruct->SIEN != I2C_ENABLE) && (I2C_IRQStruct->SIEN != I2C_DISABLE)) ||
        ((I2C_IRQStruct->TXEN != I2C_ENABLE) && (I2C_IRQStruct->TXEN != I2C_DISABLE)) ||
        ((I2C_IRQStruct->RXEN != I2C_ENABLE) && (I2C_IRQStruct->RXEN != I2C_DISABLE)))
    {
        hi2c->ErrorCode = HAL_I2C_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call while another transfer is ongoing or
     * before HAL_I2C_Init() has been called */
    status = I2C_CheckState(hi2c);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (I2C_LockHandle(hi2c, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    tmpreg = hi2c->Instance->IRQC;

    /* Transmission error interrupt enable */
    tmpreg &= ~((uint8)(I2C_IRQC_ERRN));
    if (I2C_IRQStruct->ERRN == I2C_ENABLE)
    {
        tmpreg |= ((uint8)(I2C_IRQC_ERRN));
    }

    /* Sequential operation interrupt enable */
    tmpreg &= ~((uint8)(I2C_IRQC_SIEN));
    if (I2C_IRQStruct->SIEN == I2C_ENABLE)
    {
        tmpreg |= ((uint8)(I2C_IRQC_SIEN));
    }

    /* Send idle interrupt enable */
    tmpreg &= ~((uint8)(I2C_IRQC_TXEN));
    if (I2C_IRQStruct->TXEN == I2C_ENABLE)
    {
        tmpreg |= ((uint8)(I2C_IRQC_TXEN));
    }

    /* Receive idle interrupt enable */
    tmpreg &= ~((uint8)(I2C_IRQC_RXNEN));
    if (I2C_IRQStruct->RXEN == I2C_ENABLE)
    {
        tmpreg |= ((uint8)(I2C_IRQC_RXNEN));
    }

    hi2c->Instance->IRQC = tmpreg;

    /* Process unlocked */
    I2C_UnlockHandle(hi2c);

    return HAL_OK;
}

/**
 * @brief  Returns the serial interrupt flag state. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @note   Read only access, deliberately not protected by the handle lock (see
 *         HAL_I2C_GetState()): callable from an interrupt service routine.
 * @retval uint32: 1 if the serial interrupt flag is set, 0 otherwise.
 */
uint32 HAL_I2C_GetITStatus(I2C_HandleTypeDef *hi2c)
{
    /* Check the I2C peripheral handle */
    if (hi2c == NULL_PTR)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_I2C_ALL_PERIPH(hi2c->Instance));

    if ((hi2c->Instance->CTLR & I2C_CTRL_INT) != 0U)
    {
        return 1U;
    }

    return 0U;
}

/**
 * @brief  Clears the serial interrupt flag (IICI bit). (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @note   Interrupt safe by design: no lock and no state gate (ARCH-CONST-19 /
 *         LOCK-04), so a pending serial interrupt can always be acknowledged
 *         from the user I2Cx_IRQ_Handler entry point - gating it on the handle
 *         state would leave the flag set and re-enter the interrupt forever.
 *         The transfer sequences of this module use the same helper, so the
 *         flag is acknowledged identically in polling and interrupt mode.
 * @retval None
 */
void HAL_I2C_ClearITPendingBit(I2C_HandleTypeDef *hi2c)
{
    I2C_ClearITPendingBit(hi2c);
}

/**
  * @}
  */

/** @addtogroup I2C_Exported_Functions_Group4 Interrupt safe low level bus functions
  * @brief    Atomic bus steps and running state queries of the transfer
  *           sequences, published as public APIs so that a user
  *           I2Cx_IRQ_Handler entry point can drive the bus step by step.
  * @note     Interrupt safe by design: these functions take no lock and have
  *           no state gate (ARCH-CONST-19 / LOCK-04). The polling APIs of this
  *           module execute the same helpers while the lock is already held,
  *           so the bus sequence is identical in polling and interrupt mode.
  * @{
  */

/**
 * @brief  Fills each I2C_IRQStruct member with its default value. (NON-BLOCKING)
 * @param  I2C_IRQStruct: pointer to an I2C_IRQTypeDef structure which will be
 *         initialized (all four interrupt sources disabled).
 * @note   Interrupt safe by design: no lock and no state gate (ARCH-CONST-19 /
 *         LOCK-04), so the structure can be prepared from an interrupt service
 *         routine. A NULL pointer is ignored.
 * @retval None
 */
void HAL_I2C_ITStructInit(I2C_IRQTypeDef *I2C_IRQStruct)
{
    /* Check the parameter */
    if (I2C_IRQStruct == NULL_PTR)
    {
        return;
    }

    /* Reset the I2C interrupt configuration parameters values */
    I2C_IRQStruct->ERRN = I2C_DISABLE;   /*!< Transmission error interrupt   */
    I2C_IRQStruct->SIEN = I2C_DISABLE;   /*!< Sequential operation interrupt */
    I2C_IRQStruct->TXEN = I2C_DISABLE;   /*!< Send idle interrupt            */
    I2C_IRQStruct->RXEN = I2C_DISABLE;   /*!< Receive idle interrupt         */
}

/**
 * @brief  Generates an I2C START condition. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @note   Interrupt safe by design: no lock and no state gate (ARCH-CONST-19 /
 *         LOCK-04), so the START step can be driven from an interrupt service
 *         routine. The polling APIs of this module use the same helper.
 * @retval None
 */
void HAL_I2C_GenerateStart(I2C_HandleTypeDef *hi2c)
{
    I2C_GenerateStart(hi2c);
}

/**
 * @brief  Generates an I2C STOP condition. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @note   Interrupt safe by design: no lock and no state gate (ARCH-CONST-19 /
 *         LOCK-04); used by the polling APIs and by the interrupted sequences
 *         to release the bus.
 * @retval None
 */
void HAL_I2C_GenerateStop(I2C_HandleTypeDef *hi2c)
{
    I2C_GenerateStop(hi2c);
}

/**
 * @brief  Clears the START flag of the I2C control register. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @note   Interrupt safe by design: no lock and no state gate (ARCH-CONST-19 /
 *         LOCK-04).
 * @retval None
 */
void HAL_I2C_StartClear(I2C_HandleTypeDef *hi2c)
{
    I2C_StartClear(hi2c);
}

/**
 * @brief  Sends a 7-bit slave address with the read / write direction. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  DevAddress: the 7-bit device address (0x00..0x7F).
 * @param  Direction: I2C_READ or I2C_WRITE.
 * @note   Interrupt safe by design: no lock and no state gate (ARCH-CONST-19 /
 *         LOCK-04).
 * @retval None
 */
void HAL_I2C_Send7bitAddress(I2C_HandleTypeDef *hi2c, uint8 DevAddress, uint32 Direction)
{
    I2C_Send7bitAddress(hi2c, DevAddress, Direction);
}

/**
 * @brief  Configures whether an ACK or a NACK is sent when receiving data. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  AckState: I2C_ACK or I2C_NACK.
 * @note   Interrupt safe by design: no lock and no state gate (ARCH-CONST-19 /
 *         LOCK-04), so the acknowledge policy of an interrupted receive can be
 *         changed from the interrupt service routine.
 * @retval None
 */
void HAL_I2C_AcknowledgeConfig(I2C_HandleTypeDef *hi2c, uint32 AckState)
{
    I2C_AcknowledgeConfig(hi2c, AckState);
}

/**
 * @brief  Writes a single data byte to the I2C data register. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  Data: the data byte to transmit.
 * @note   Interrupt safe by design: no lock and no state gate (ARCH-CONST-19 /
 *         LOCK-04), so the next byte of an interrupted transfer can be staged
 *         from the interrupt service routine.
 * @retval None
 */
void HAL_I2C_SendData(I2C_HandleTypeDef *hi2c, uint8 Data)
{
    I2C_SendData(hi2c, Data);
}

/**
 * @brief  Reads the data byte from the I2C data register. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @note   Interrupt safe by design: no lock and no state gate (ARCH-CONST-19 /
 *         LOCK-04), so the received byte of an interrupted transfer can be
 *         fetched from the interrupt service routine.
 * @retval uint8: the received data byte (0 when hi2c is NULL).
 */
uint8 HAL_I2C_ReceiveData(I2C_HandleTypeDef *hi2c)
{
    return I2C_ReceiveData(hi2c);
}

/**
 * @brief  Returns the running state code of the I2C state machine. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @note   Read only register access, interrupt safe by design: no lock and no
 *         state gate (ARCH-CONST-19 / LOCK-04).
 * @retval uint32: the running state code (the I2C_STATE_xxx constants), 0 when
 *         hi2c is NULL.
 */
uint32 HAL_I2C_GetFlagStatus(I2C_HandleTypeDef *hi2c)
{
    return ((uint32)I2C_GetFlagstatus(hi2c));
}

/**
 * @brief  Checks whether the I2C is in the given running state. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  Status: the running state code to check (I2C_STATE_xxx).
 * @note   Read only register access, interrupt safe by design: no lock and no
 *         state gate (ARCH-CONST-19 / LOCK-04). The polling APIs of this
 *         module use the same helper to advance the sequences.
 * @retval uint32: 1 if the I2C is in the state, 0 otherwise (0 when hi2c is
 *         NULL).
 */
uint32 HAL_I2C_CheckStatus(I2C_HandleTypeDef *hi2c, uint8 Status)
{
    return I2C_CheckStatus(hi2c, Status);
}

/**
  * @}
  */

/** @addtogroup I2C_Internal_Functions Low level register access functions (Tier 3)
  * @brief    Module internal register access sequences. They implement the
  *           atomic steps of the transfer sequences (START / STOP / address /
  *           data / acknowledge / running state) and are called by the public
  *           APIs, in most cases while the handle lock is already held
  *           (ARCH-CONST-19 / LOCK-04: no lock and no state gate inside). The
  *           Group4 wrappers publish them unchanged, which is what makes the
  *           bus sequence identical in polling and interrupt mode.
  * @{
  */

/**
 * @brief  Generates an I2C START condition. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @retval None
 */
static void I2C_GenerateStart(I2C_HandleTypeDef *hi2c)
{
    /* Check the I2C peripheral handle */
    if (hi2c == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_I2C_ALL_PERIPH(hi2c->Instance));

    hi2c->Instance->CTLR |= ((uint8)(I2C_CTRL_IICSTA));
}

/**
 * @brief  Generates an I2C STOP condition. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @retval None
 */
static void I2C_GenerateStop(I2C_HandleTypeDef *hi2c)
{
    /* Check the I2C peripheral handle */
    if (hi2c == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_I2C_ALL_PERIPH(hi2c->Instance));

    hi2c->Instance->CTLR |= ((uint8)(I2C_CTRL_STO));
}

/**
 * @brief  Clears the START flag (IICSTA bit) of the I2C control register. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @retval None
 */
static void I2C_StartClear(I2C_HandleTypeDef *hi2c)
{
    /* Check the I2C peripheral handle */
    if (hi2c == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_I2C_ALL_PERIPH(hi2c->Instance));

    hi2c->Instance->CTLR &= ~((uint8)(I2C_CTRL_IICSTA));
}

/**
 * @brief  Sends a 7-bit slave address with the read / write direction. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  Address: the 7-bit device address (0x00..0x7F).
 * @param  Direction: I2C_READ or I2C_WRITE.
 * @retval None
 */
static void I2C_Send7bitAddress(I2C_HandleTypeDef *hi2c, uint8 Address, uint32 Direction)
{
    /* Check the I2C peripheral handle */
    if (hi2c == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_I2C_ALL_PERIPH(hi2c->Instance));
    assert_param(Address <= 0x7FU);
    assert_param(IS_I2C_DIRECTION(Direction));

    /* The address byte is the 7-bit address shifted left, OR the R/W bit */
    hi2c->Instance->DATA = ((uint8)(Direction | (Address << 1U)));
}

/**
 * @brief  Configures whether an ACK or a NACK is sent when receiving data. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  Ackflag: I2C_ACK or I2C_NACK.
 * @retval None
 */
static void I2C_AcknowledgeConfig(I2C_HandleTypeDef *hi2c, uint32 Ackflag)
{
    uint8 tmpreg = 0U;

    /* Check the I2C peripheral handle */
    if (hi2c == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_I2C_ALL_PERIPH(hi2c->Instance));
    assert_param(IS_I2C_ACK_FLAG(Ackflag));

    tmpreg = hi2c->Instance->CTLR;
    tmpreg &= ~((uint8)(I2C_CTRL_AA));
    if (Ackflag == I2C_ACK)
    {
        tmpreg |= ((uint8)(I2C_CTRL_AA));
    }
    hi2c->Instance->CTLR = tmpreg;
}

/**
 * @brief  Writes a single data byte to the I2C data register. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  Data: the data byte to transmit.
 * @retval None
 */
static void I2C_SendData(I2C_HandleTypeDef *hi2c, uint8 Data)
{
    /* Check the I2C peripheral handle */
    if (hi2c == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_I2C_ALL_PERIPH(hi2c->Instance));

    hi2c->Instance->DATA = Data;
}

/**
 * @brief  Reads the data byte from the I2C data register. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @retval uint8: the received data byte.
 */
static uint8 I2C_ReceiveData(I2C_HandleTypeDef *hi2c)
{
    /* Check the I2C peripheral handle */
    if (hi2c == NULL_PTR)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_I2C_ALL_PERIPH(hi2c->Instance));

    return hi2c->Instance->DATA;
}

/**
 * @brief  Clears the serial interrupt flag (IICI bit). (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @retval None
 */
static void I2C_ClearITPendingBit(I2C_HandleTypeDef *hi2c)
{
    /* Check the I2C peripheral handle */
    if (hi2c == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_I2C_ALL_PERIPH(hi2c->Instance));

    hi2c->Instance->CTLR &= ~((uint8)(I2C_CTRL_INT));
}

/**
 * @brief  Returns the current I2C running state (STAT.STATE field). (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @retval uint8: the running state code (see the I2C_STATE_xxx constants).
 */
static uint8 I2C_GetFlagstatus(I2C_HandleTypeDef *hi2c)
{
    /* Check the I2C peripheral handle */
    if (hi2c == NULL_PTR)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_I2C_ALL_PERIPH(hi2c->Instance));

    return ((uint8)(hi2c->Instance->STAT >> I2C_STAT_STATE_Pos));
}

/**
 * @brief  Checks whether the I2C is in the given running state. (NON-BLOCKING)
 * @param  hi2c: pointer to a I2C_HandleTypeDef structure.
 * @param  Status: the running state code to check (I2C_STATE_xxx).
 * @retval 1 if the I2C is in the state, 0 otherwise.
 */
static uint32 I2C_CheckStatus(I2C_HandleTypeDef *hi2c, uint8 Status)
{
    uint32 bitstatus = 0U;

    /* Check the I2C peripheral handle */
    if (hi2c == NULL_PTR)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_I2C_ALL_PERIPH(hi2c->Instance));
    assert_param(IS_I2C_STATE(Status));

    if (I2C_GetFlagstatus(hi2c) == Status)
    {
        bitstatus = 1U;
    }

    return bitstatus;
}

/**
  * @}
  */

/**
  * @}
  */

#endif /* HAL_I2C_MODULE_ENABLED */

/*****END OF FILE*****/
