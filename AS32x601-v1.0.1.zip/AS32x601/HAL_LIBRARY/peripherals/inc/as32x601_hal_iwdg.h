/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):    Xiamen Guoke Anxin Technology Co., LTD
 * FileName:         as32x601_hal_iwdg.h
 * Author:           ANSILIC APPLICATION GROUP
 * Version:          V1.3
 * Date:             2026/09/20
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/24     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.3     bring the module up to the Medium level
 *                                                       of the architecture specification: add the
 *                                                       lock, state and error code members to the
 *                                                       handle, the state enumeration and the error
 *                                                       codes, the state and error reporting
 *                                                       interfaces, the shared lock / state helpers
 *                                                       and the run time parameter validation in
 *                                                       front of the first register access; annotate
 *                                                       the blocking property of every public
 *                                                       interface; align the version of the four
 *                                                       module files and describe the module without
 *                                                       referring to an external implementation
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Independent Watchdog
 *                  (IWDG) peripheral:
 *                  - Initialization (HAL_IWDG_Init): prescaler number
 *                    (PSC.PSCNUM), reload / timeout value (TO.BVAL) and
 *                    divider number (DIV.DIVNUM) configuration;
 *                  - IO operation functions (HAL_IWDG_Refresh /
 *                    HAL_IWDG_GetCounter).
 *                  The chip-specific enable / lock control is provided by
 *                  this driver (HAL_IWDG_Cmd / HAL_IWDG_LockCmd).
 *                  This driver depends on as32x601_hal_def.h (HAL common
 *                  types and utilities). The IWDG is clocked by the
 *                  APB_BusS domain (32.768 kHz) and has no SMU clock gate
 *                  (the clock is always on), so no MSP hook is provided.
 *                  Hardware shape of this chip: no Window feature (there is
 *                  no window register), no status register (there is no
 *                  prescaler / reload update busy flag) and no key register
 *                  write-access mechanism: the watchdog is refreshed by
 *                  writing the key value into the IWDG_CLR register, and the
 *                  register write protection is provided by the PSC / CFG
 *                  hardware lock bits (see the enable / lock definitions below).
 * @complexity  Medium
 *              Handle with lock / state / error code, polling only (no
 *              interrupt or DMA mode). The register accesses are immediate,
 *              so no operation waits on hardware; the timeout recovery state
 *              of the specification is therefore not produced by this module.
 * @note  Deliberate behaviour - no MSP callback pair is provided: the IWDG is
 *        clocked by the always-on APB_BusS domain and has no clock gate, no
 *        reset control and no pin, so there is nothing for a board support
 *        override to configure. The low level hook of the other modules is
 *        therefore absent by design rather than by omission.
 */
#ifndef __AS32X601_HAL_IWDG_H
#define __AS32X601_HAL_IWDG_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "as32x601_hal_def.h"       /* HAL common types and utilities          */
#include "as32x601.h"               /* IWDG_TypeDef, IWDG, register bits       */

/**
 * @brief IWDG HAL driver module version.
 * @note  0x0100U = V1.0. Bumped only on breaking API changes (architecture
 *        spec COMPAT-13/14/15).
 */
#define __HAL_IWDG_MODULE_VERSION  0x0100U

/* Exported types ------------------------------------------------------------*/

/** @defgroup IWDG_Exported_Types IWDG Exported Types
  * @{
  */

/**
 * @brief IWDG Init Structure definition
 * @note  The Prescaler field maps the IWDG_PSC.PSCNUM divider number (a
 *        plain value in the 2-255 range, no discrete prescaler enum). The
 *        Reload field maps the IWDG_TO.BVAL timeout value (0-65535, 16-bit
 *        wide). The Divider field is a chip-specific extension that maps
 *        the IWDG_DIV.DIVNUM divider (2-65535).
 * @note  This structure follows the Version+Size compatibility mechanism
 *        (architecture spec section 22): the user must clear the structure
 *        (__HAL_CLEAR_STRUCT / memset), set the Size and Version metafields
 *        before filling the business fields.
 */
typedef struct
{
    uint32 Size;   /*!< sizeof(IWDG_InitTypeDef), must be set by
                                                  the user after clearing the structure */
    uint32 Version;   /*!< Structure semantic version: @ref
                                                  IWDG_INIT_VERSION (IWDG_INIT_V1 = 0x0100U) */
    uint32 Prescaler;   /*!< IWDG prescaler number (PSC.PSCNUM, 2-255)
                                                     */
    uint32 Reload;   /*!< IWDG reload / timeout value (TO.BVAL,
                                                  0-65535) */
    uint32 Divider;   /*!< IWDG divider number (DIV.DIVNUM, 2-65535)
                                                     */
    uint32 Reserved[2];   /*!< Reserved for future extension (must be 0)
                                                     */
} IWDG_InitTypeDef;

/**
 * @brief IWDG / init structure version macros.
 * @note  IWDG_INIT_V1 is the current version. Future versions (e.g. V2 with
 *        new fields) must be appended after the existing fields without
 *        changing the layout (architecture spec section 22.5).
 */
#define IWDG_INIT_V1  0x0100U   /*!< IWDG Init structure version V1.0 */
#define IWDG_INIT_VERSION  IWDG_INIT_V1   /*!< Current IWDG Init structure version */

/**
 * @brief HAL IWDG state structures definition.
 * @note  The timeout recovery state of the specification is not produced by
 *        this module (no operation waits on hardware).
 */
typedef enum
{
    HAL_IWDG_STATE_RESET      = 0x00U, /*!< Peripheral not initialized           */
    HAL_IWDG_STATE_READY      = 0x01U, /*!< Peripheral initialized and ready     */
    HAL_IWDG_STATE_BUSY       = 0x02U, /*!< An internal process is ongoing       */
    HAL_IWDG_STATE_ERROR      = 0x03U  /*!< IWDG error state                     */
} HAL_IWDG_StateTypeDef;

/**
 * @brief IWDG Handle Structure definition
 * @note  The handle carries the configuration, the resource lock, the state
 *        and the error code of the module (architecture spec section 4.1,
 *        Medium level). The Lock field is allocated by HAL_IWDG_Init() and
 *        the state starts in RESET, so the handle shall be cleared
 *        (__HAL_CLEAR_STRUCT / memset) before its first use.
 */
typedef struct __IWDG_HandleTypeDef
{
    IWDG_TypeDef               *Instance;      /*!< Register base address                  */
    IWDG_InitTypeDef           Init;           /*!< IWDG required parameters                */
    HAL_LockTypeDef            Lock;           /*!< Locking object                         */
    __IO HAL_IWDG_StateTypeDef State;          /*!< IWDG state                             */
    __IO uint32                ErrorCode;      /*!< IWDG error code                        */
#if (USE_RTOS == 1)
    HAL_MutexTypeDef           LockMutex;      /*!< RTOS mutex handle (created by the user
                                                    porting layer)                          */
#endif /* USE_RTOS */
} IWDG_HandleTypeDef;
/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @defgroup IWDG_Error_Code IWDG Error Code
  * @{
  */
#define HAL_IWDG_ERROR_NONE           ((uint32)0x00000000U) /*!< No error                     */
#define HAL_IWDG_ERROR_INVALID_PARAM  ((uint32)0x00000001U) /*!< Invalid parameter or rejected
                                                                 operation                      */
/**
  * @}
  */

/* Exported macro ------------------------------------------------------------*/
/** @defgroup IWDG_Exported_Macros IWDG Exported Macros
  * @{
  */

/**
 * @brief  Reset the handle State field.
 * @note   Must be used before passing a local handle to HAL_IWDG_Init() the
 *         first time, so that the lock resource is allocated.
 */
#define __HAL_IWDG_RESET_HANDLE_STATE(__HANDLE__) ((__HANDLE__)->State = 0U)

/**
 * @brief  Start the IWDG peripheral.
 * @note   This macro sets the IWDG_CFG.CFG_EN bit. The prescaler enable
 *         (PSC.EN) is set by HAL_IWDG_Init() before it returns, so starting
 *         the watchdog after an initialization enables both blocks.
 * @param  __HANDLE__: specifies the IWDG handle.
 * @retval None
 */
#define __HAL_IWDG_START(__HANDLE__)            SET_BIT((__HANDLE__)->Instance->CFG, IWDG_CFG_EN)

/**
 * @brief  Reload IWDG counter with the refresh key value.
 * @note   The chip IWDG counter is refreshed by writing the key value
 *         0x2F3E5D8A into the IWDG_CLR register (there is no KR register).
 * @param  __HANDLE__: specifies the IWDG handle.
 * @retval None
 */
#define __HAL_IWDG_RELOAD_COUNTER(__HANDLE__)   WRITE_REG((__HANDLE__)->Instance->CLR, IWDG_CLR_KEY_RESET)

/**
 * @brief  Get the IWDG counter value.
 * @param  __HANDLE__: specifies the IWDG handle.
 * @retval The IWDG counter value (16-bit).
 */
#define __HAL_IWDG_GET_COUNTER(__HANDLE__)      ((uint16)(READ_REG((__HANDLE__)->Instance->CNT) & IWDG_CNT_CNTNUM))
/**
  * @}
  */

/* Include IWDG HAL Extension module */

/* Exported functions --------------------------------------------------------*/
/** @addtogroup IWDG_Exported_Functions
  * @{
  */

/** @addtogroup IWDG_Exported_Functions_Group1
  * @{
  */
/* Initialization functions ***************************************************/

/**
 * @brief  Initialize the IWDG: write the prescaler number, the divider and
 *         the reload / timeout values. (NON-BLOCKING)
 * @note   This function does not start the watchdog: the configuration
 *         enable bit (CFG.EN) is set afterwards by HAL_IWDG_Cmd() with
 *         IWDG_EN_CFG / ENABLE (or by the __HAL_IWDG_START() macro), so the
 *         sequence is: configure the three values, then start the watchdog.
 * @note   The configuration structure metafields (Size / Version), the
 *         reserved words and the three values are validated at run time: an
 *         invalid configuration is rejected with HAL_ERROR and
 *         HAL_IWDG_ERROR_INVALID_PARAM without taking the lock and without
 *         changing the handle state or touching a register.
 * @param  hiwdg: pointer to a IWDG_HandleTypeDef structure that contains
 *         the configuration information for IWDG.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (NULL pointer, invalid instance, invalid
 *         configuration).
 */
HAL_StatusTypeDef HAL_IWDG_Init(IWDG_HandleTypeDef *hiwdg);
/**
  * @}
  */

/** @addtogroup IWDG_Exported_Functions_Group2
  * @{
  */
/* IO operation functions *****************************************************/

/**
 * @brief  Refresh the IWDG (reload the watchdog counter). (NON-BLOCKING)
 * @note   The chip IWDG counter is refreshed by writing the key value
 *         0x2F3E5D8A into the IWDG_CLR register.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_IWDG_Init() is required first).
 * @param  hiwdg: pointer to a IWDG_HandleTypeDef structure that contains
 *         the configuration information for IWDG.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_IWDG_Refresh(IWDG_HandleTypeDef *hiwdg);

/**
 * @brief  Get the IWDG counter value. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock and applies no state gate, so
 *         it is callable from an interrupt context.
 * @param  hiwdg: pointer to a IWDG_HandleTypeDef structure that contains
 *         the configuration information for IWDG.
 * @retval The IWDG counter value (16-bit); 0 for an invalid handle or
 *         instance.
 */
uint16 HAL_IWDG_GetCounter(IWDG_HandleTypeDef *hiwdg);
/**
  * @}
  */

/** @addtogroup IWDG_Exported_Functions_Group3 State and error functions
  * @{
  */

/**
 * @brief  Return the IWDG handle state. (NON-BLOCKING)
 * @note   Read-only interface: no lock and no state gate, callable from an
 *         interrupt context.
 * @param  hiwdg: pointer to a IWDG_HandleTypeDef structure.
 * @retval HAL_IWDG_StateTypeDef: the current handle state (
 *         HAL_IWDG_STATE_RESET for an invalid handle or instance).
 */
HAL_IWDG_StateTypeDef HAL_IWDG_GetState(IWDG_HandleTypeDef *hiwdg);

/**
 * @brief  Return the IWDG error code. (NON-BLOCKING)
 * @note   Read-only interface: no lock and no state gate, callable from an
 *         interrupt context.
 * @param  hiwdg: pointer to a IWDG_HandleTypeDef structure.
 * @retval uint32: the IWDG error code (HAL_IWDG_ERROR_xxx), 0 for an invalid
 *         handle or instance.
 */
uint32 HAL_IWDG_GetError(IWDG_HandleTypeDef *hiwdg);

/**
  * @}
  */

/**
  * @}
  */

/* Exported types ------------------------------------------------------------*/

/* Exported constants --------------------------------------------------------*/

/** @defgroup IWDG_Exported_Constants IWDG Exported Constants
  * @{
  */

/** @defgroup IWDG_Enable_Definitions IWDG Enable Definitions
  * @note  The values are selector codes (they are not register bit values):
  *        they select which block (prescaler / configuration) is enabled or
  *        disabled by HAL_IWDG_Cmd().
  * @{
  */
#define IWDG_EN_PSC                     ((uint32)0x10000000)  /*!< Enable / disable the IWDG prescaler (PSC.EN) */
#define IWDG_EN_CFG                     ((uint32)0x20000000)  /*!< Enable / disable the IWDG configuration (CFG.EN) */

/* Legacy selector names kept as aliases of the current names */
#define I_PSC_EN                        IWDG_EN_PSC
#define I_CFG_EN                        IWDG_EN_CFG
/**
  * @}
  */

/** @defgroup IWDG_Lock_Definitions IWDG Lock Definitions
  * @note  The values are selector codes: they select which block (prescaler /
  *        configuration) is locked or unlocked by HAL_IWDG_LockCmd().
  * @{
  */
#define IWDG_LOCK_PSC                   ((uint32)0x80000000)  /*!< Lock / unlock the IWDG prescaler (PSC.LOCK) */
#define IWDG_LOCK_CFG                   ((uint32)0xA0000000)  /*!< Lock / unlock the IWDG configuration (CFG.LOCK) */

/* Legacy selector names kept as aliases of the current names */
#define I_PSC_LOCK                      IWDG_LOCK_PSC
#define I_CFG_LOCK                      IWDG_LOCK_CFG
/**
  * @}
  */

/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/
/** @addtogroup IWDG_Exported_Functions
  * @{
  */

/** @addtogroup IWDG_Exported_Functions_Group1
  * @{
  */
/* IWDG enable and lock functions *******************************************/

/**
 * @brief  Enable or disable the IWDG prescaler or configuration block.
 *         (NON-BLOCKING)
 * @note   The watchdog is effectively started when both the prescaler enable
 *         (PSC.EN, set by HAL_IWDG_Init) and the configuration enable (CFG.EN)
 *         are set.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not been
 *         initialized (HAL_IWDG_Init() is required first).
 * @param  hiwdg:    pointer to a IWDG_HandleTypeDef structure that contains
 *         the configuration information for IWDG.
 * @param  Enable:   specifies the IWDG block to enable / disable.
 *         This parameter can be:
 *            @arg IWDG_EN_PSC
 *            @arg IWDG_EN_CFG
 * @param  NewState: new state of the selected IWDG block (ENABLE or DISABLE).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_IWDG_Cmd(IWDG_HandleTypeDef *hiwdg, uint32 Enable,
                                 FunctionalState NewState);

/**
 * @brief  Lock or unlock the IWDG prescaler or configuration block.
 *         (NON-BLOCKING)
 * @note   A locked block rejects further writes of its registers.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not been
 *         initialized (HAL_IWDG_Init() is required first).
 * @param  hiwdg:    pointer to a IWDG_HandleTypeDef structure that contains
 *         the configuration information for IWDG.
 * @param  Lock:     specifies the IWDG block to lock / unlock.
 *         This parameter can be:
 *            @arg IWDG_LOCK_PSC
 *            @arg IWDG_LOCK_CFG
 * @param  NewState: new state of the selected IWDG lock (ENABLE or DISABLE).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_IWDG_LockCmd(IWDG_HandleTypeDef *hiwdg, uint32 Lock,
                                     FunctionalState NewState);
/**
  * @}
  */

/**
  * @}
  */

/* Private types -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private constants ---------------------------------------------------------*/
/* Private macros ------------------------------------------------------------*/
/** @addtogroup IWDG_Private_Macros IWDG Private Macros
  * @{
  */

/** @addtogroup IWDG_IS_IWDG_Definitions IWDG Private macros to check input parameters
  * @{
  */
#define IS_IWDG_EN(EN)                    (((EN) == IWDG_EN_PSC) || ((EN) == IWDG_EN_CFG))

#define IS_IWDG_LOCK(LOCK)                (((LOCK) == IWDG_LOCK_PSC) || ((LOCK) == IWDG_LOCK_CFG))

/* Legacy selector names kept as aliases of the current names */
#define IS_IWDG_CONFIG_EN                 IS_IWDG_EN
#define IS_IWDG_CONFIG_LOCK               IS_IWDG_LOCK
/**
  * @}
  */

/**
  * @}
  */

/* Private types -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private constants ---------------------------------------------------------*/
/** @defgroup IWDG_Private_Constants IWDG Private Constants
  * @{
  */
/* IWDG_CLR register refresh key value (hardware defined). */
#define IWDG_CLR_KEY_RESET              ((uint32)0x2F3E5D8A)
/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/
/** @defgroup IWDG_Private_Macros IWDG Private Macros
  * @{
  */

/** @defgroup IWDG_IS_IWDG_Definitions IWDG Private macros to check input parameters
  * @{
  */
#define IS_IWDG_ALL_INSTANCE(INSTANCE)    ((INSTANCE) == IWDG)

#define IS_IWDG_PRESCALER(PRESCALER)      (((PRESCALER) >= 0x02) && ((PRESCALER) <= 0xFF))

#define IS_IWDG_RELOAD(RELOAD)            ((RELOAD) <= IWDG_TO_BVAL)

#define IS_IWDG_DIVIDER(DIVIDER)          (((DIVIDER) >= 0x02) && ((DIVIDER) <= 0xFFFF))

/* Legacy selector name kept as an alias of the current name */
#define IS_IWDG_TOValue                   IS_IWDG_RELOAD
/**
  * @}
  */

/**
  * @}
  */

/* Shared internal functions --------------------------------------------------*/

/**
 * @brief  Check whether the IWDG handle and its instance are valid.
 * @note   Shared with the extension implementation file.
 * @param  hiwdg: pointer to a IWDG_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
uint32 IWDG_HandleIsValid(IWDG_HandleTypeDef *hiwdg);

/**
 * @brief  Check whether the handle accepts a new operation.
 * @note   ARCH-CONST-09: a handle that is BUSY rejects any other operation
 *         with HAL_BUSY, and a handle that is not initialized (RESET) requires
 *         HAL_IWDG_Init() first and is rejected with HAL_ERROR. The
 *         recoverable state ERROR accepts a new operation directly.
 * @param  hiwdg: pointer to a IWDG_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK (accepted) / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef IWDG_CheckState(IWDG_HandleTypeDef *hiwdg);

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle, which shall have been
 *         created by the user porting layer. RTOS-11: the Timeout parameter
 *         prevents a task from blocking forever; HAL_MAX_DELAY means an
 *         infinite wait.
 * @param  hiwdg: pointer to a IWDG_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef IWDG_LockHandle(IWDG_HandleTypeDef *hiwdg, uint32 Timeout);

/**
 * @brief  Unlock the handle.
 * @param  hiwdg: pointer to a IWDG_HandleTypeDef structure.
 * @retval None
 */
void IWDG_UnlockHandle(IWDG_HandleTypeDef *hiwdg);

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_IWDG_H */

/*****END OF FILE*****/
