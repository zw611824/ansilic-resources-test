/**
 * @file    CLINT_IT_DRV_006.c
 * @brief   HAL CLINT integration test case 006 (handle lock mechanism).
 *
 * One-to-one HAL library port of the original AS32x601 standard-library
 * test case CLINT_IT_DRV_006.c. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_CLINT_Init()
 *   HAL_CLINT_SoftIntCmd() (register access guarded by the handle lock)
 *   HAL_CLINT_ClearSoftInt() (interrupt safe clear used by the MSI handler)
 *   HAL_CLINT_GetState()
 *   CLINT_LockHandle() / CLINT_UnlockHandle()
 *
 * Test procedure:
 *   1. Initialize the CLINT and check the lock helper semantics
 *      (free handle -> HAL_OK, busy handle -> HAL_BUSY, release -> free);
 *   2. Hold the handle lock and request a software interrupt: the request must
 *      be discarded because the handle is locked;
 *   3. Release the lock and request the software interrupt again: the interrupt
 *      must be generated;
 *   4. Verify that the handle is usable again after the sequence;
 *   5. Repeat steps 2..4.
 *
 * Expected behaviour:
 *   - CLINT_LockHandle() (called with HAL_MAX_DELAY, as the non blocking
 *     library APIs do) returns HAL_OK on a free handle and HAL_BUSY while
 *     the handle is already locked;
 *   - With the handle locked, HAL_CLINT_SoftIntCmd() does not modify any CLINT
 *     register (no software interrupt is generated);
 *   - After CLINT_UnlockHandle(), the software interrupt request is effective
 *     and MSoftWare_IRQ_Handler() is executed (which acknowledges it with
 *     HAL_CLINT_ClearSoftInt(), the interrupt safe path).
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"
#include "core_riscv.h"          /* csr_set_bits / csr_clear_bits / CSR_MIE   */

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Observation window after each software interrupt operation */
#define TEST_WINDOW_MS              (200U)

/* Pause between two check rounds */
#define ROUND_PAUSE_MS              (1000U)

/* Private variables ---------------------------------------------------------*/
static HAL_CLINT_HandleTypeDef hclint;      /*!< CLINT handle                 */
static volatile uint32 softint_count = 0U;  /*!< software interrupt counter   */
static uint32 check_count = 0U;             /*!< executed checks              */
static uint32 fail_count  = 0U;             /*!< failed checks                */

static HAL_SMU_HandleTypeDef hsmu_clk;   /*!< SMU handle (lock / state / error) */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void test_check(const char *name, int ok);
static void clint_CheckLock(void);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    uint32 round = 0U;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== CLINT_IT_DRV_006: handle lock mechanism ===\r\n");

    /* Initialize the CLINT peripheral */
    hclint.Instance = CLINT;
    if (HAL_CLINT_Init(&hclint) != HAL_OK)
    {
        printf("HAL_CLINT_Init failed\r\n");
        while (1)
        {
        }
    }

    printf("CLINT state = %u (1 = READY)\r\n",
           PRINT_U32(HAL_CLINT_GetState(&hclint)));

    while (1)
    {
        round++;
        printf("\r\n--- round %u ---\r\n", PRINT_U32(round));

        clint_CheckLock();

        printf("checks = %u, failed = %u\r\n",
               PRINT_U32(check_count), PRINT_U32(fail_count));
        check_count = 0U;
        fail_count  = 0U;

        delay_ms(ROUND_PAUSE_MS);
    }
}

/**
 * @brief  Run the handle lock check sequence once.
 * @param  None
 * @retval None
 */
static void clint_CheckLock(void)
{
    uint32 count_before;

    /* Step 1: lock / unlock semantics */
    test_check("CLINT_LockHandle() on a free handle = HAL_OK",
               (CLINT_LockHandle(&hclint, HAL_MAX_DELAY) == HAL_OK));
    test_check("handle is locked",
               (hclint.Lock == HAL_LOCKED));
    test_check("CLINT_LockHandle() on a busy handle = HAL_BUSY",
               (CLINT_LockHandle(&hclint, HAL_MAX_DELAY) == HAL_BUSY));

    /* Step 2: a locked handle discards the software interrupt request */
    csr_set_bits(CSR_MIE, MIE_MSIE);
    count_before = softint_count;
    HAL_CLINT_SoftIntCmd(&hclint, 1U);
    delay_ms(TEST_WINDOW_MS);

    test_check("locked handle: no software interrupt generated",
               (softint_count == count_before));

    /* Step 3: release the handle and repeat the request */
    CLINT_UnlockHandle(&hclint);
    test_check("handle is unlocked",
               (hclint.Lock == HAL_UNLOCKED));
    test_check("CLINT_LockHandle() after release = HAL_OK",
               (CLINT_LockHandle(&hclint, HAL_MAX_DELAY) == HAL_OK));
    CLINT_UnlockHandle(&hclint);

    count_before = softint_count;
    HAL_CLINT_SoftIntCmd(&hclint, 1U);
    delay_ms(TEST_WINDOW_MS);

    test_check("unlocked handle: software interrupt generated",
               (softint_count == (count_before + 1U)));

    /* Step 4: the handle is still usable after the sequence */
    test_check("handle state still READY",
               (HAL_CLINT_GetState(&hclint) == HAL_CLINT_STATE_READY));
    test_check("handle error code still NONE",
               (HAL_CLINT_GetError(&hclint) == HAL_CLINT_ERROR_NONE));

    /* Leave the software interrupt source masked for the next round */
    csr_clear_bits(CSR_MIE, MIE_MSIE);
    HAL_CLINT_SoftIntCmd(&hclint, 0U);
}

/**
 * @brief  Machine software interrupt handler (weak symbol of the trap entry).
 * @param  None
 * @retval None
 */
void MSoftWare_IRQ_Handler(void)
{
    /* Clear the software interrupt pending bit and mask the source */
    /* Interrupt safe clear: takes no handle lock (LOCK-04 / RTOS-12) */
    HAL_CLINT_ClearSoftInt(&hclint);
    csr_clear_bits(CSR_MIE, MIE_MSIE);

    softint_count++;
}

/**
 * @brief  Print the result of one check and update the statistics.
 * @param  name: check description.
 * @param  ok: non-zero when the check passed.
 * @retval None
 */
static void test_check(const char *name, int ok)
{
    check_count++;

    if (ok == 0)
    {
        fail_count++;
    }

    printf("  [%s] %s\r\n", (ok != 0) ? "PASS" : "FAIL", name);
}

/**
 * @brief  Configure the system clock tree using the HAL SMU driver.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef  SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef   SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it (CLKFRQ above), so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Clock tree order: this is the order the chip requires, and the vendor
       test case uses the same one.
         1. Write the bus clock dividers while the system clock is still the
            power-on source (FIRC), so that the new divider values are already
            in place when the faster clock arrives. Writing them AFTER the
            switch instead leaves the buses at their reset dividers for a
            moment at the new core clock: at 180 MHz that is
            AXI4Bus3 = 90 MHz and APBBus0 = 45 MHz, right at their ratings, and
            the core does not survive it (measured on the board: the core
            trapped before the divider write was reached, so no output was
            produced at all).
         2. Program the EFLASH controller clock: the controller must already
            know the final frequency while the code still runs from the flash.
         3. Then configure the PLL and switch the system clock to it; this call
            also updates SystemCoreClock and re-initializes the HAL time base. */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
