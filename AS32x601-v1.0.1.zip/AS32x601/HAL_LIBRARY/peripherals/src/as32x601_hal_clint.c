/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_clint.c
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.6
 * Date:   2026/10/09
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.1     add the shared lock
 *                                                       helpers CLINT_LockHandle /
 *                                                       CLINT_UnlockHandle and
 *                                                       protect every register
 *                                                       writing function with
 *                                                       them (Init / DeInit /
 *                                                       SoftIntCmd /
 *                                                       SetTimerComparator);
 *                                                       the read-only functions
 *                                                       (ReadTimerValue /
 *                                                       GetState) stay lock-free
 *     ANSILIC APPLICATION GROUP  2026/09/07     1.2     add the ErrorCode field,
 *                                                       the HAL_CLINT_ERROR_NONE
 *                                                       constant and the
 *                                                       HAL_CLINT_GetError()
 *                                                       reporting API, aligning
 *                                                       the handle with the
 *                                                       library conventions
 *                                                       (CMU/PKA/SPACC)
 *     ANSILIC APPLICATION GROUP  2026/09/17     1.3     align the resource lock
 *                                                       and the RTOS support with
 *                                                       the architecture
 *                                                       specification (section 13
 *                                                       and section 21): take the
 *                                                       handle lock with a Timeout
 *                                                       and guard a NULL mutex
 *                                                       (RTOS-11), run the MSP
 *                                                       callbacks outside the
 *                                                       locked region (LOCK-06)
 *                                                       with the MSP init on the
 *                                                       first initialization only
 *                                                       (MSP-04), document every
 *                                                       lock failure return as a
 *                                                       path where the lock is not
 *                                                       held (LOCK-02), gate the
 *                                                       register accesses on the
 *                                                       handle state
 *                                                       (ARCH-CONST-09), use the
 *                                                       busy state while the
 *                                                       handle is being set up and
 *                                                       torn down, add
 *                                                       HAL_CLINT_ClearSoftInt()
 *                                                       as the interrupt safe way
 *                                                       to acknowledge the
 *                                                       software interrupt
 *                                                       (LOCK-04 / RTOS-12), and
 *                                                       check the software
 *                                                       interrupt command with the
 *                                                       common functional state
 *                                                       assertion
 *     ANSILIC APPLICATION GROUP  2026/09/21     1.4     add the system time base
 *                                                       (periodic tick) service:
 *                                                       HAL_CLINT_TimerIntCmd()
 *                                                       enables or disables the
 *                                                       machine timer interrupt
 *                                                       through the standard
 *                                                       mie.MTIE bit,
 *                                                       HAL_CLINT_SetTickPeriod()
 *                                                       programs the period and
 *                                                       arms the first tick,
 *                                                       HAL_CLINT_IRQHandler()
 *                                                       reloads the comparator and
 *                                                       calls the new weak
 *                                                       HAL_CLINT_TickCallback();
 *                                                       the comparator write order
 *                                                       becomes low-half before
 *                                                       high-half (aligned with the
 *                                                       device write order)
 *                                                       and is centralized in the
 *                                                       private helper
 *                                                       CLINT_ProgramComparator();
 *                                                       HAL_CLINT_DeInit() now
 *                                                       disables the machine timer
 *                                                       interrupt and parks the
 *                                                       comparator so that the
 *                                                       module is really reset; the
 *                                                       default HAL_CLINT_MspInit()
 *                                                       enables the CLINT clock gate
 *                                                       and releases its reset
 *                                                       through the SMU; and
 *                                                       HAL_CLINT_ERROR_INVALID_PARAM
 *                                                       reports a rejected tick
 *                                                       period
 *     ANSILIC APPLICATION GROUP  2026/09/21     1.5     describe the comparator write order as the device write
 *                                                       order instead of referring to an external implementation
 *     ANSILIC APPLICATION GROUP  2026/10/09     1.6     re-base the periodic tick on the planned compare
 *                                                       value instead of on the counter read inside the
 *                                                       interrupt handler, so that the effective period
 *                                                       equals the programmed period and the interrupt
 *                                                       latency no longer accumulates from tick to tick;
 *                                                       add the CompareValue software mirror to the handle
 *                                                       together with HAL_CLINT_GetTimerComparator(); advance
 *                                                       a planned instant that the counter already passed by
 *                                                       whole periods (late tick guard); forget the mirror on
 *                                                       initialization and de-initialization
 * Description:     This file provides firmware functions to manage the
 *                  functionalities of the Core-Local Interruptor (CLINT):
 *                  - Initialization and de-initialization;
 *                  - Machine software interrupt generation;
 *                  - 64-bit timer comparator programming (low-before-high);
 *                  - 64-bit real-time counter read-back (wrap-consistent);
 *                  - System time base: machine timer interrupt control, periodic
 *                    tick programming and the interrupt entry with its callback.
 */
#include "as32x601_hal.h"          /* module switch from as32x601_hal_conf.h */
#include "as32x601_hal_clint.h"    /* CLINT HAL API and register macros      */

/* The HAL_CLINT_MODULE_ENABLED switch is provided by the user configuration
 * file (as32x601_hal_conf.h, included above through as32x601_hal.h): the
 * whole implementation is compiled only while the module is enabled. */
#ifdef HAL_CLINT_MODULE_ENABLED

/* Private function prototypes -----------------------------------------------*/

static uint32 CLINT_HandleIsValid(HAL_CLINT_HandleTypeDef *hclint);
static HAL_StatusTypeDef CLINT_CheckState(HAL_CLINT_HandleTypeDef *hclint);
static uint64 CLINT_ReadTimerCounter(HAL_CLINT_HandleTypeDef *hclint);
static void CLINT_ProgramComparator(HAL_CLINT_HandleTypeDef *hclint, uint64 CompareValue);
static void CLINT_WriteTimerInt(HAL_CLINT_HandleTypeDef *hclint, FunctionalState NewState);
static void CLINT_ArmNextTick(HAL_CLINT_HandleTypeDef *hclint);

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Check whether a CLINT handle and its instance are valid.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
static uint32 CLINT_HandleIsValid(HAL_CLINT_HandleTypeDef *hclint)
{
    if ((hclint == NULL_PTR) || (hclint->Instance != CLINT))
    {
        return 0U;
    }

    return 1U;
}

/**
 * @brief  Check the handle state before a register access.
 * @note   ARCH-CONST-09: a handle that is being set up (busy) rejects the call
 *         with HAL_BUSY, and a handle that was never initialized rejects it
 *         with HAL_ERROR (HAL_CLINT_Init() is required first). The error state
 *         is recoverable, a new operation may be called directly.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
static HAL_StatusTypeDef CLINT_CheckState(HAL_CLINT_HandleTypeDef *hclint)
{
    if (hclint->State == HAL_CLINT_STATE_BUSY)
    {
        return HAL_BUSY;
    }

    if (hclint->State == HAL_CLINT_STATE_RESET)
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Program the 64-bit machine timer comparator.
 * @note   Private register primitive: it neither takes the handle lock nor
 *         checks the handle state, so it is called from the locked public
 *         functions and from the interrupt entry.
 * @note   The 64-bit value is split into two 32-bit registers.  The low half
 *         is written before the high half, which is the write order of the
 *         device; the order is confined to
 *         this single helper so that a datasheet confirmation only has to be
 *         applied here.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @param  CompareValue: 64-bit compare value.
 * @retval None
 */
static void CLINT_ProgramComparator(HAL_CLINT_HandleTypeDef *hclint, uint64 CompareValue)
{
    hclint->Instance->CMPLR = (uint32)(CompareValue & 0xFFFFFFFFU);
    hclint->Instance->CMPHR = (uint32)(CompareValue >> 32U);
}

/**
 * @brief  Enable or disable the machine timer interrupt in the mie CSR.
 * @note   Private register primitive: it neither takes the handle lock nor
 *         checks the handle state, so it may also be used from the interrupt
 *         entry and from HAL_CLINT_DeInit() while the lock is held (rules
 *         LOCK-04 / RTOS-12 and ARCH-CONST-04: no public API is called from a
 *         locked region).
 * @note   The device has no interrupt enable register: the machine timer
 *         interrupt is enabled by the standard mie.MTIE bit of the CPU, which
 *         is why the core CSR macros are used here.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @param  NewState: ENABLE = set mie.MTIE, DISABLE = clear mie.MTIE.
 * @retval None
 */
static void CLINT_WriteTimerInt(HAL_CLINT_HandleTypeDef *hclint, FunctionalState NewState)
{
    /* Prevent unused argument compilation warning: the interrupt enable bit
     * lives in the CPU CSR, not in a CLINT register */
    UNUSED(hclint);

    if (NewState != DISABLE)
    {
        csr_set_bits(CSR_MIE, MIE_MTIE);
    }
    else
    {
        csr_clear_bits(CSR_MIE, MIE_MTIE);
    }
}

/**
 * @brief  Read a wrap-consistent 64-bit snapshot of the machine timer counter.
 * @note   Private register primitive: it neither takes the handle lock nor
 *         checks the handle state.  The high half is read twice and compared
 *         to detect a wrap of the low half between the two reads (standard
 *         RISC-V CLINT reading rule on RV32), so a consistent snapshot is
 *         returned.  It is used by the public read API and by the tick arming
 *         helper, which runs with the handle lock held (rules LOCK-05 /
 *         ARCH-CONST-04: a locked region must not call a public HAL API).
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval uint64: the current machine timer counter value.
 */
static uint64 CLINT_ReadTimerCounter(HAL_CLINT_HandleTypeDef *hclint)
{
    uint32 hi1 = 0U;
    uint32 hi2 = 0U;
    uint32 low = 0U;

    /* Repeat until both high-half reads belong to the same low-half epoch. */
    do
    {
        hi1 = hclint->Instance->RDTIMEHR;
        low = hclint->Instance->RDTIMELR;
        hi2 = hclint->Instance->RDTIMEHR;
    } while (hi2 != hi1);

    return ((uint64)hi2 << 32U) | (uint64)low;
}

/**
 * @brief  Program the next machine timer comparator value and update the mirror.
 * @note   Private register primitive used by HAL_CLINT_SetTickPeriod() (first
 *         tick), by HAL_CLINT_TimerIntCmd(ENABLE) (re-arm) and by
 *         HAL_CLINT_IRQHandler() (periodic reload).
 * @note   The next instant is computed from the compare value that was planned
 *         last (the handle mirror) advanced by the tick period, and not from
 *         the counter value read here: the effective period therefore stays
 *         equal to the programmed period instead of growing by the interrupt
 *         latency of every tick.  The first arming, when no value has been
 *         planned through this handle yet, uses the counter as its base.
 * @note   A result that is not strictly in the future is advanced by whole
 *         periods until it is.  This releases the machine timer interrupt
 *         condition (counter >= compare on this device) after a handler that
 *         ran longer than one period, so that the interrupt cannot be
 *         re-asserted endlessly.
 * @note   The caller is responsible for having validated the period: with a
 *         zero period this helper does nothing, so that a handle without a
 *         programmed period never arms the comparator.
 * @note   The handle lock must be held by the caller, or this path must run in
 *         interrupt context where no task lock may be taken.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval None
 */
static void CLINT_ArmNextTick(HAL_CLINT_HandleTypeDef *hclint)
{
    uint64 period;
    uint64 base;
    uint64 now;
    uint64 next;

    if (hclint->TickPeriod == 0U)
    {
        return;
    }

    period = (uint64)hclint->TickPeriod;
    now    = CLINT_ReadTimerCounter(hclint);

    if (hclint->CompareValue == 0U)
    {
        /* First arming: nothing was planned through this handle yet, so the
         * counter is the only available base. */
        base = now;
    }
    else
    {
        /* Periodic run: advance the value planned last, so that the interrupt
         * latency does not accumulate into the period. */
        base = hclint->CompareValue;
    }

    next = base + period;

    /* Land strictly in the future so that the counter >= compare condition is
     * released: a handler that ran longer than one period would otherwise
     * leave the planned instant in the past and keep the interrupt asserted. */
    while (next <= now)
    {
        next += period;
    }

    CLINT_ProgramComparator(hclint, next);

    hclint->CompareValue = next;
}

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_CLINT_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the acquisition is bounded by the Timeout parameter;
 *         HAL_MAX_DELAY waits forever.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS, wait expired) /
 *         HAL_ERROR (RTOS, mutex not created) / HAL_BUSY (bare metal, the
 *         handle is already locked).
 */
HAL_StatusTypeDef CLINT_LockHandle(HAL_CLINT_HandleTypeDef *hclint, uint32 Timeout)
{
#if (USE_RTOS == 1)
    if (hclint->LockMutex == NULL_PTR)
    {
        /* The porting layer did not create the mutex (e.g. HAL_CLINT_MspInit()
         * was not overridden): report it instead of calling the RTOS with a
         * NULL handle */
        return HAL_ERROR;
    }

    return HAL_MutexAcquire(hclint->LockMutex, Timeout);
#else
    /* Prevent unused argument compilation warning: the bare-metal lock flag
     * either succeeds immediately or reports HAL_BUSY, it never waits */
    UNUSED(Timeout);

    if (hclint->Lock == HAL_LOCKED)
    {
        return HAL_BUSY;
    }
    hclint->Lock = HAL_LOCKED;
    return HAL_OK;
#endif /* USE_RTOS */
}

/**
 * @brief  Unlock the handle.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval None
 */
void CLINT_UnlockHandle(HAL_CLINT_HandleTypeDef *hclint)
{
#if (USE_RTOS == 1)
    (void)HAL_MutexRelease(hclint->LockMutex);
#else
    hclint->Lock = HAL_UNLOCKED;
#endif /* USE_RTOS */
}

/* Exported functions --------------------------------------------------------*/

/** @addtogroup CLINT_Exported_Functions
  * @{
  */

/** @addtogroup CLINT_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Initializes the CLINT peripheral. (NON-BLOCKING)
 * @note   The CLINT clock gating is enabled by the default HAL_CLINT_MspInit()
 *         implementation through the SMU ALB0 clock configuration register.
 * @note   The low level initialization runs only on the first call (while the
 *         handle is in the reset state) and before the handle is locked
 *         (MSP-04 / LOCK-06), so that an override may create an RTOS mutex and
 *         call other HAL APIs.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_CLINT_Init(HAL_CLINT_HandleTypeDef *hclint)
{
    /* Check the CLINT peripheral handle and instance */
    if (CLINT_HandleIsValid(hclint) == 0U)
    {
        return HAL_ERROR;
    }

    /* Allocate the lock resource and initialize the low level hardware before
     * the first use, so that a handle that was never initialized cannot report
     * HAL_BUSY from a stale Lock field. LOCK-06: the MSP callback runs before
     * the handle is locked, hence an override may call other HAL APIs and
     * create the RTOS mutex that CLINT_LockHandle() needs. MSP-04: it runs on
     * the first initialization only, so a repeated HAL_CLINT_Init() neither
     * initializes the hardware twice nor leaks a second mutex. */
    if (hclint->State == HAL_CLINT_STATE_RESET)
    {
        hclint->Lock = HAL_UNLOCKED;

        HAL_CLINT_MspInit(hclint);
    }

    /* Process locked */
    if (CLINT_LockHandle(hclint, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and mark the handle as being configured */
    hclint->ErrorCode = HAL_CLINT_ERROR_NONE;
    hclint->State     = HAL_CLINT_STATE_BUSY;

    /* Forget any compare value that an earlier run planned, so that this
     * handle starts from the documented "nothing programmed yet" condition and
     * a stale value can never become the base of a periodic reload.  The
     * programmed tick period is deliberately kept: a handle whose machine
     * timer interrupt is still enabled must keep reloading its comparator,
     * while a zero period would leave the comparator parked at the old instant
     * and hold the interrupt asserted. */
    hclint->CompareValue = 0U;

    /* The CLINT takes no initialization parameter: the comparator is NOT
     * programmed here (the free-running counter is left alone) and the machine
     * timer interrupt is NOT enabled, so a handle that is only initialized
     * never generates an interrupt. The system time base is armed explicitly
     * by HAL_CLINT_SetTickPeriod() / HAL_CLINT_TimerIntCmd() (STATE-03). */
    hclint->State = HAL_CLINT_STATE_READY;

    /* Release Lock */
    CLINT_UnlockHandle(hclint);

    return HAL_OK;
}

/**
 * @brief  De-initializes the CLINT peripheral. (NON-BLOCKING)
 * @note   The module is really reset: the machine timer interrupt is disabled
 *         in the mie CSR, the comparator is parked at its maximum value
 *         (0xFFFFFFFFFFFFFFFF, so a machine timer interrupt that the
 *         application had enabled can no longer fire on a stale period), the
 *         programmed tick period is cleared and the software interrupt pending
 *         bit is cleared.
 * @note   The low level de-initialization callback runs after the handle lock
 *         has been released (LOCK-06), so that an override may call other HAL
 *         APIs (for example HAL_GPIO_DeInit()) without risking a deadlock and
 *         without being called with the lock held.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_CLINT_DeInit(HAL_CLINT_HandleTypeDef *hclint)
{
    /* Check the CLINT peripheral handle and instance */
    if (CLINT_HandleIsValid(hclint) == 0U)
    {
        return HAL_ERROR;
    }

    /* Process locked */
    if (CLINT_LockHandle(hclint, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and mark the handle as being torn down */
    hclint->ErrorCode = HAL_CLINT_ERROR_NONE;
    hclint->State     = HAL_CLINT_STATE_BUSY;

    /* Park the comparator first, then mask the interrupt: the free-running
     * counter can no longer reach a parked comparator, so the interrupt that
     * is disabled afterwards cannot be re-asserted in between. The private
     * primitives are used because a locked region must not call a public HAL
     * API (LOCK-05 / ARCH-CONST-04). */
    CLINT_ProgramComparator(hclint, (uint64)0xFFFFFFFFFFFFFFFFULL);
    CLINT_WriteTimerInt(hclint, DISABLE);

    /* Forget the programmed period and the planned compare value, so that a
     * following HAL_CLINT_Init() / HAL_CLINT_TimerIntCmd(ENABLE) pair neither
     * arms a stale period nor continues from a stale instant */
    hclint->TickPeriod   = 0U;
    hclint->CompareValue = 0U;

    /* Clear the software interrupt pending bit */
    hclint->Instance->SOFTICR &= ~((uint32)CLINT_SOFTICR_SOFT);

    /* The handle goes back to the reset state so that a following
     * HAL_CLINT_Init() runs the low level initialization again */
    hclint->State = HAL_CLINT_STATE_RESET;

    /* Release Lock */
    CLINT_UnlockHandle(hclint);

    /* LOCK-06 / ARCH-CONST-04: the low level de-initialization runs OUTSIDE
     * the locked region, as the architecture specification requires for the
     * MSP callbacks ("MspDeInit is called after the unlock"). The override may
     * call other HAL APIs (e.g. HAL_GPIO_DeInit()), which is only allowed
     * while the handle lock is not held. */
    HAL_CLINT_MspDeInit(hclint);

    return HAL_OK;
}

/**
 * @brief  Initializes the CLINT MSP. Weak function; the default implementation
 *         enables the CLINT clock gate and releases its reset through the SMU
 *         ALB0 clock configuration register.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_CLINT_MspInit(HAL_CLINT_HandleTypeDef *hclint)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hclint);

    /* Enable the CLINT clock and release its reset: the reset bit is released
     * by SETTING it (SET = released, CLEAR = reset asserted), which is also
     * what the SMU_ALB0CFGR reset value (every RST bit set) and
     * __HAL_SMU_CLINT_RELEASE_RESET() assume. */
    SMU->ALB0CFGR |= SMU_ALB0CFGR_CLINTEN;
    SMU->ALB0CFGR |= SMU_ALB0CFGR_CLINTRST;
}

/**
 * @brief  De-initializes the CLINT MSP. Weak empty function; the user
 *         implements the low level hardware de-initialization.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_CLINT_MspDeInit(HAL_CLINT_HandleTypeDef *hclint)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hclint);
}

/**
  * @}
  */

/** @addtogroup CLINT_Exported_Functions_Group2 Peripheral Control functions
  * @{
  */

/**
 * @brief  Enables or disables the machine software interrupt pending bit. (NON-BLOCKING)
 * @note   Intended for the task / main context: the register access is
 *         protected by the handle lock and gated by the handle state. An
 *         interrupt service routine shall call HAL_CLINT_ClearSoftInt()
 *         instead (LOCK-04 / RTOS-12).
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @param  NewState: ENABLE = raise the software interrupt, DISABLE = clear it.
 * @retval None
 */
void HAL_CLINT_SoftIntCmd(HAL_CLINT_HandleTypeDef *hclint, FunctionalState NewState)
{
    /* Check the CLINT peripheral handle and instance */
    if (CLINT_HandleIsValid(hclint) == 0U)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_CLINT_Init() is
     * required first) */
    if (CLINT_CheckState(hclint) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (CLINT_LockHandle(hclint, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    if (NewState != DISABLE)
    {
        /* Set the software interrupt pending bit */
        hclint->Instance->SOFTICR |= ((uint32)CLINT_SOFTICR_SOFT);
    }
    else
    {
        /* Clear the software interrupt pending bit */
        hclint->Instance->SOFTICR &= ~((uint32)CLINT_SOFTICR_SOFT);
    }

    /* Release Lock */
    CLINT_UnlockHandle(hclint);
}

/**
 * @brief  Clears the machine software interrupt pending bit. (NON-BLOCKING)
 * @note   Interrupt safe counterpart of HAL_CLINT_SoftIntCmd(): it neither
 *         takes the handle lock nor checks the handle state, so the MSI
 *         handler of the application may acknowledge the request with it
 *         (LOCK-04 / RTOS-12 forbid taking a lock from an interrupt service
 *         routine). HAL_CLINT_SoftIntCmd() shall be used instead when the
 *         software interrupt has to be raised, or when it is cleared from the
 *         task context, so that the access stays serialized.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval None
 */
void HAL_CLINT_ClearSoftInt(HAL_CLINT_HandleTypeDef *hclint)
{
    /* Check the CLINT peripheral handle and instance. No assert_param() and no
     * state gate here: this path is deliberately lock free so that it stays
     * callable from an interrupt service routine. */
    if (CLINT_HandleIsValid(hclint) == 0U)
    {
        return;
    }

    hclint->Instance->SOFTICR &= ~((uint32)CLINT_SOFTICR_SOFT);
}

/**
 * @brief  Programs the 64-bit machine timer comparator (mtimecmp). (NON-BLOCKING)
 * @note   The comparator registers are write-only, so the hardware value can
 *         never be read back.  The handle keeps a software mirror of the value
 *         programmed here, returned by HAL_CLINT_GetTimerComparator(), and
 *         that mirror also becomes the base of the next periodic reload (see
 *         HAL_CLINT_SetTickPeriod()).  The current implementation writes the
 *         low half before the high half, which is the write order of the
 *         device; the required AS32x601 write order and commit semantics still
 *         have to be confirmed from the chip datasheet or RTL, and the order
 *         is confined to the private helper CLINT_ProgramComparator() so that
 *         the confirmation only has to be applied in that single place.
 * @note   The default HAL time base does NOT use this comparator: it is
 *         derived from the CPU mcycle counter and never accesses the CLINT
 *         (see as32x601_hal.c).  Only when the application moves the tick to
 *         the machine timer interrupt, through HAL_CLINT_SetTickPeriod() plus
 *         HAL_CLINT_TimerIntCmd(), does the comparator belong to that path and
 *         is reloaded by HAL_CLINT_IRQHandler() on every tick: it must then
 *         not be written concurrently with that handler, which is why this
 *         function must not be used while the tick is enabled.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @param  CompareValue: 64-bit compare value.
 * @retval None
 */
void HAL_CLINT_SetTimerComparator(HAL_CLINT_HandleTypeDef *hclint, uint64 CompareValue)
{
    /* Check the CLINT peripheral handle and instance */
    if (CLINT_HandleIsValid(hclint) == 0U)
    {
        return;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_CLINT_Init() is
     * required first) */
    if (CLINT_CheckState(hclint) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (CLINT_LockHandle(hclint, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    CLINT_ProgramComparator(hclint, CompareValue);

    /* Keep the mirror in step: the periodic reload advances the planned value,
     * so a value programmed here has to become the new base of that sequence
     * (the comparator registers cannot be read back to recover it). */
    hclint->CompareValue = CompareValue;

    /* Release Lock */
    CLINT_UnlockHandle(hclint);
}

/**
 * @brief  Returns the compare value that was programmed through this handle
 *         last. (NON-BLOCKING)
 * @note   Read only access, deliberately not protected by the handle lock (the
 *         mirror is a plain handle field and the tick reload may advance it
 *         from interrupt context in any case).  The comparator registers of
 *         this device are write only, so the value reported here is the
 *         software mirror maintained by HAL_CLINT_SetTimerComparator(),
 *         HAL_CLINT_SetTickPeriod() and the periodic reload of
 *         HAL_CLINT_IRQHandler(); it is not a hardware read-back and proves
 *         nothing about a hardware atomic commit.
 * @note   While the periodic tick runs the machine timer interrupt advances the
 *         mirror, so the reading is the instant planned last, not the hardware
 *         content, and on this 32-bit core the 64-bit object may be updated by
 *         interrupt context between the two halves of the read.  The API is
 *         therefore meant for diagnostics and for a stopped time base; use
 *         HAL_CLINT_ReadTimerValue() when an exact elapsed time has to be
 *         measured.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval uint64: the mirror value; 0 when nothing was programmed yet, and 0
 *         when the handle is NULL or Instance is not the accepted CLINT
 *         instance (no register is read in that case).
 */
uint64 HAL_CLINT_GetTimerComparator(HAL_CLINT_HandleTypeDef *hclint)
{
    /* Check the CLINT peripheral handle and instance */
    if (CLINT_HandleIsValid(hclint) == 0U)
    {
        return 0U;
    }

    return hclint->CompareValue;
}

/**
 * @brief  Returns the 64-bit machine timer counter (mtime) value. (NON-BLOCKING)
 * @note   On RV32 the high part is read twice and checked to detect a wrap
 *         of the low part between the two reads (standard RISC-V CLINT
 *         reading rule).
 * @note   Read only access, deliberately not protected by the handle lock
 *         (the counter is free running and the read is retried until it is
 *         consistent), so it may also be called from an interrupt service
 *         routine.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval uint64: the current mtime value.
 */
uint64 HAL_CLINT_ReadTimerValue(HAL_CLINT_HandleTypeDef *hclint)
{
    /* Check the CLINT peripheral handle and instance */
    if (CLINT_HandleIsValid(hclint) == 0U)
    {
        return 0U;
    }

    return CLINT_ReadTimerCounter(hclint);
}

/**
 * @brief  Returns the CLINT handle state. (NON-BLOCKING)
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval HAL_CLINT_StateTypeDef: the current handle state.
 */
HAL_CLINT_StateTypeDef HAL_CLINT_GetState(HAL_CLINT_HandleTypeDef *hclint)
{
    /* Check the CLINT peripheral handle */
    if (hclint == NULL_PTR)
    {
        return HAL_CLINT_STATE_RESET;
    }

    return hclint->State;
}

/**
 * @brief  Returns the CLINT error code. (NON-BLOCKING)
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval uint32: the CLINT error code (HAL_CLINT_ERROR_xxx).
 */
uint32 HAL_CLINT_GetError(HAL_CLINT_HandleTypeDef *hclint)
{
    /* Check the CLINT peripheral handle */
    if (hclint == NULL_PTR)
    {
        return HAL_CLINT_ERROR_NONE;
    }

    return hclint->ErrorCode;
}

/**
  * @}
  */

/** @addtogroup CLINT_Exported_Functions_Group3 System time base (periodic tick) functions
  * @{
  */

/**
 * @brief  Enables or disables the machine timer interrupt (MTI). (NON-BLOCKING)
 * @note   The device has no interrupt enable register of its own, so the
 *         standard mie.MTIE bit of the CPU is used (the machine timer
 *         interrupt is additionally gated by the global enable mstatus.MIE,
 *         which is configured by the startup code).
 * @note   On ENABLE, when a tick period has been programmed with
 *         HAL_CLINT_SetTickPeriod(), the comparator is re-armed before the
 *         interrupt is enabled (from the instant that was planned last, or from
 *         the current counter value when nothing was planned yet), so that a
 *         comparator left over from an earlier run cannot fire immediately: an
 *         instant the counter has already passed is advanced by whole periods
 *         until it lies in the future.  Program the period (or the comparator)
 *         BEFORE enabling: with a comparator that the free-running counter has
 *         already passed, the interrupt is asserted continuously.
 * @note   DISABLE only masks the interrupt: the comparator and the programmed
 *         period are kept, so a later ENABLE resumes the ticks.
 * @note   Intended for the task / main context: the handle lock is taken and
 *         the state gate is applied, so an interrupt service routine would
 *         violate rules LOCK-04 / RTOS-12 by calling it.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @param  NewState: ENABLE = let the comparator raise the machine timer
 *         interrupt, DISABLE = mask the machine timer interrupt.
 * @retval None
 */
void HAL_CLINT_TimerIntCmd(HAL_CLINT_HandleTypeDef *hclint, FunctionalState NewState)
{
    /* Check the CLINT peripheral handle and instance */
    if (CLINT_HandleIsValid(hclint) == 0U)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_CLINT_Init() is
     * required first) */
    if (CLINT_CheckState(hclint) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (CLINT_LockHandle(hclint, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    if (NewState != DISABLE)
    {
        /* Re-arm the next tick before letting the interrupt be taken: an
         * instant planned by an earlier run that the counter has already
         * passed is advanced by whole periods, so a stale comparator cannot
         * fire immediately. */
        CLINT_ArmNextTick(hclint);

        CLINT_WriteTimerInt(hclint, ENABLE);
    }
    else
    {
        CLINT_WriteTimerInt(hclint, DISABLE);
    }

    /* Release Lock */
    CLINT_UnlockHandle(hclint);
}

/**
 * @brief  Programs the system time base period and arms the first tick.
 *         (NON-BLOCKING)
 * @note   The period is expressed in machine timer counter ticks (a 1 ms
 *         period is "counter frequency / 1000"); the counter frequency has to
 *         be taken from the chip documentation for the configured clock tree.
 * @note   The value is validated before the lock is taken and before any
 *         register is touched: a zero period is rejected with
 *         HAL_CLINT_ERROR_INVALID_PARAM and HAL_ERROR, leaving the handle and
 *         the hardware unchanged.  A period of at least a few counter ticks is
 *         required in practice, so that the interrupt handler has left before
 *         the counter passes the newly programmed comparator.
 * @note   The period is stored in the handle and used by
 *         HAL_CLINT_IRQHandler() to reload the comparator on every tick.  The
 *         first tick is armed here, one full period ahead of the current
 *         counter value; calling this function while the tick is enabled stores
 *         the new period and re-bases the sequence, so the next tick lands one
 *         new period after the value that was planned last (or after the
 *         current counter value when nothing was planned yet).  Because the
 *         reload advances the planned instant, the effective period equals the
 *         programmed period instead of growing by the interrupt latency of
 *         every tick.
 * @note   This function only programs the period: HAL_CLINT_TimerIntCmd() is
 *         what lets the machine timer interrupt actually be taken.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @param  Period: tick period, in machine timer counter ticks (not zero).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_CLINT_SetTickPeriod(HAL_CLINT_HandleTypeDef *hclint, uint32 Period)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the CLINT peripheral handle and instance */
    if (CLINT_HandleIsValid(hclint) == 0U)
    {
        return HAL_ERROR;
    }

    /* Reject the invalid period before the lock is taken and before any
     * register is touched, so that a rejected call leaves the handle state and
     * the hardware unchanged; only the error code is reported (same pattern as
     * the other drivers of this library). */
    if (Period == 0U)
    {
        hclint->ErrorCode = HAL_CLINT_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_CLINT_Init() is
     * required first) */
    status = CLINT_CheckState(hclint);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (CLINT_LockHandle(hclint, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and store the admitted period */
    hclint->ErrorCode  = HAL_CLINT_ERROR_NONE;
    hclint->TickPeriod = Period;

    /* Arm the first tick one full period ahead of the current counter value */
    CLINT_ArmNextTick(hclint);

    /* Release Lock */
    CLINT_UnlockHandle(hclint);

    return HAL_OK;
}

/**
 * @brief  Machine timer interrupt entry of the system time base. (NON-BLOCKING)
 * @note   It is meant to be called from the machine timer interrupt handler of
 *         the trap entry (the weak MTimer_IRQ_Handler() symbol dispatched for
 *         mcause = 7):
 *         @code
 *         void MTimer_IRQ_Handler(void)
 *         {
 *             HAL_CLINT_IRQHandler(&hclint);
 *         }
 *         @endcode
 * @note   The interrupt is answered by arming the next tick first (the
 *         comparator is reloaded with the instant that was planned last
 *         advanced by the tick period, so neither the callback duration nor
 *         the interrupt latency accumulates into the period) and by calling the
 *         user HAL_CLINT_TickCallback() afterwards.  When no period has been
 *         programmed the comparator is left untouched, which keeps an
 *         application that drives the comparator manually in control.
 * @note   Deliberately lock free and state gate free (only the handle pointer
 *         and the instance are checked): an interrupt service routine must not
 *         take a lock (rules LOCK-04 / RTOS-12), and the entry has to keep
 *         working while a task holds the lock.
 * @note   The reload is based on the planned instant kept in the handle mirror
 *         rather than on the counter read here, so the interrupt latency of
 *         this tick is not accumulated into the next period.  The mirror is
 *         reported by HAL_CLINT_GetTimerComparator().
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval None
 */
void HAL_CLINT_IRQHandler(HAL_CLINT_HandleTypeDef *hclint)
{
    /* Check the CLINT peripheral handle and instance. No lock and no state
     * gate: this path is deliberately lock free so that it stays callable from
     * an interrupt service routine. */
    if (CLINT_HandleIsValid(hclint) == 0U)
    {
        return;
    }

    /* Answer the interrupt by arming the next tick, then run the user hook */
    CLINT_ArmNextTick(hclint);

    HAL_CLINT_TickCallback(hclint);
}

/**
 * @brief  System time base tick callback. Weak empty function; the user
 *         implements the work to be executed on every tick.
 * @note   It runs in interrupt context, so no blocking operation shall be
 *         executed inside it.
 * @note   SINGLE TICK OWNER (architecture rule on the time base): the HAL
 *         common layer builds its default 1 ms time base from the CPU mcycle
 *         counter by polling and never uses the CLINT, so only one of the two
 *         may feed the tick at a time (see as32x601_hal.c and the header
 *         documentation of this callback).
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_CLINT_TickCallback(HAL_CLINT_HandleTypeDef *hclint)
{
    /* Prevent unused argument compilation warning. NOTE: when this callback is
     * needed, the user implements HAL_CLINT_TickCallback() in his own file. */
    UNUSED(hclint);
}

/**
  * @}
  */

/**
  * @}
  */

#endif /* HAL_CLINT_MODULE_ENABLED */

/*****END OF FILE*****/
