/**
 * @file    TIM_IT_DRV_009.c
 * @brief   input capture on channels 1..6 with the capture interrupt
 *
 * HAL library port of the original AS32x601 standard-library test case
 * TIMER_IT_DRV_009.c, which drives TIM0. Only HAL library APIs are used; the register
 * read backs document what was programmed.
 *
 * Tested functionality:
 *   TIM_ICStructInit()      -> HAL_TIM_IC_StructInit()
 *   TIM_ICInit()            -> HAL_TIM_IC_ConfigChannel() (channels 1..6)
 *   TIM_ITConfig()          -> HAL_TIM_IC_Start_IT()
 *   TIM_GetITStatus()/TIM_ClearITPendingBit() -> HAL_TIM_IRQHandler()
 *   TIM_GetCapture1()..TIM_GetCapture6() -> HAL_TIM_ReadCapturedValue()
 *
 * Test procedure:
 *   map the six capture pins of TIM0 (PC3, PA0..PA4) as inputs;
 *   configure channels 1..6 as direct rising edge capture inputs;
 *   enable the capture interrupt of every channel and the PLIC line;
 *   feed a square wave into the pins and print the measured frequency per channel.
 *
 * Expected behaviour:
 *   every channel returns HAL_OK and CC1S..CC6S read 01 (CCMR3 for channels 5/6);
 *   DIER reads CC1IE..CC6IE set after the interrupt based start;
 *   the capture callback runs for the channels that receive edges, each channel measures the same input period, and the six captures taken in one interrupt are identical;
 *   every check prints [PASS] and "summary : failures = 0".
 *
 * Note:
 *   An external square wave is required on the pins of the channels under test; the frequency is computed from two consecutive captures.
 *
 *   The printed capture values of two channels must NOT be compared directly:
 *   each capture is a sample of the free running counter taken at the edge that
 *   channel saw, so values read at different instants differ by whole input
 *   periods (the console needs a few milliseconds per line while the input
 *   keeps producing edges). The comparable quantities are the period between
 *   two captures of the same channel, and the six values of one single
 *   interrupt, in which every channel latched the same edge.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
/* Console: USART0 on GPIOD pin 8 (TX) / pin 9 (RX), 115200 8N1 */
#define TEST_BAUDRATE                   (115200U)


#define TEST_ARR                        (100000U - 1U)
#define TEST_PSC                        (9U - 1U)


/* Private variables -------------------------------------------------------*/
static HAL_TIM_HandleTypeDef htim_dev;          /*!< timer under test        */
static HAL_SMU_HandleTypeDef hsmu_clk;          /*!< SMU handle (clock tree) */
static volatile uint32 check_failures = 0U;     /*!< failed check counter    */

static volatile uint32 capture_count[6];        /*!< captures per channel    */
static volatile uint32 capture_value[6];        /*!< last capture per channel */
static volatile uint32 capture_period[6];       /*!< counts between the last two captures of the channel */
static volatile uint32 capture_prev[6];         /*!< previous capture of the channel */
static volatile uint32 full_pass_count;         /*!< interrupts in which all six channels captured */
static volatile uint32 full_pass_value[6];      /*!< the six captures of the last such interrupt */
static SMU_ClocksTypeDef test_clocks;           /*!< clock tree read back in SystemClock_Init() */


void TIM0_IRQ_Handler(void);
void HAL_TIM_IC_CaptureCallback(HAL_TIM_HandleTypeDef *htim);


/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure one GPIO pin and, for the alternate function modes, the
 *         pin mux of that pin.
 * @param  port: GPIO port
 * @param  pin: pin mask
 * @param  source: pin source number (for the mux configuration)
 * @param  af: alternate function selector
 * @param  mode: GPIO_MODE_AF_PP / GPIO_MODE_INPUT
 * @retval None
 */
static void Gpio_Config(GPIO_TypeDef *port, uint32 pin, uint32 source, uint8 af, uint32 mode)
{
    GPIO_InitTypeDef gpio_init;

    __HAL_CLEAR_STRUCT(&gpio_init);
    gpio_init.Size         = sizeof(GPIO_InitTypeDef);
    gpio_init.Version      = GPIO_INIT_VERSION;
    gpio_init.Pin          = pin;
    gpio_init.Mode         = mode;
    gpio_init.Pull         = GPIO_NOPULL;
    gpio_init.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;
    gpio_init.Alternate    = af;
    /* The multiplex selection is independent of the pin direction: a pin that
       feeds a peripheral input (timer capture input, external clock input, ...)
       keeps MODER = input while the AFR field routes the pad to that peripheral.
       HAL_GPIO_Init() programs the AFR field only for the alternate function
       modes, so the input case must select the mux explicitly, otherwise the
       pad stays on its default function and the peripheral never sees it. */
    if (af != GPIO_AF_Pin_x)
    {
        HAL_GPIO_PinAFConfig(port, source, af);
    }
    HAL_GPIO_Init(port, &gpio_init);
}

/**
 * @brief  Configure the time base of the timer under test.
 * @note   The helper keeps the Size / Version meta fields through
 *         HAL_TIM_Base_StructInit(), which the initialization interface
 *         validates at run time.
 * @param  instance: TIM0..TIM7
 * @param  arr: auto reload value
 * @param  psc: prescaler value
 * @param  rcr: repetition counter (advanced timers only)
 * @param  ckd: clock division
 * @param  countermode: counting mode
 * @retval HAL status of HAL_TIM_Base_Init()
 */
static HAL_StatusTypeDef TimeBase_Config(TIM_TypeDef *instance, uint32 arr, uint32 psc,
                                         uint32 rcr, uint32 ckd, uint32 countermode)
{
    TIM_Base_InitTypeDef base_init;

    __HAL_CLEAR_STRUCT(&htim_dev);
    htim_dev.Instance = instance;

    HAL_TIM_Base_StructInit(&base_init);
    base_init.CounterMode       = countermode;
    base_init.ClockDivision     = ckd;
    base_init.Period            = arr;
    base_init.Prescaler         = psc;
    base_init.RepetitionCounter = rcr;
    htim_dev.Init               = base_init;

    return HAL_TIM_Base_Init(&htim_dev);
}

/**
 * @brief  Enable the clock of a timer instance and release its reset.
 * @note   The default MSP callbacks of this module are empty, so the suite
 *         performs the gate and reset handling itself; every MSP callback is
 *         routed to this helper.
 * @param  instance: TIM0..TIM7
 * @retval None
 */
static void Tim_ClockEnable(TIM_TypeDef *instance)
{
    if (instance == TIM0)
    {
        __HAL_SMU_HTIM0_CLK_ENABLE();
        __HAL_SMU_HTIM0_FORCE_RESET();
        __HAL_SMU_HTIM0_RELEASE_RESET();
    }
    else if (instance == TIM1)
    {
        __HAL_SMU_HTIM1_CLK_ENABLE();
        __HAL_SMU_HTIM1_FORCE_RESET();
        __HAL_SMU_HTIM1_RELEASE_RESET();
    }
    else if (instance == TIM2)
    {
        __HAL_SMU_HTIM2_CLK_ENABLE();
        __HAL_SMU_HTIM2_FORCE_RESET();
        __HAL_SMU_HTIM2_RELEASE_RESET();
    }
    else if (instance == TIM3)
    {
        __HAL_SMU_TIM3_CLK_ENABLE();
        __HAL_SMU_TIM3_FORCE_RESET();
        __HAL_SMU_TIM3_RELEASE_RESET();
    }
    else if (instance == TIM4)
    {
        __HAL_SMU_TIM4_CLK_ENABLE();
        __HAL_SMU_TIM4_FORCE_RESET();
        __HAL_SMU_TIM4_RELEASE_RESET();
    }
    else if (instance == TIM5)
    {
        __HAL_SMU_HTIM5_CLK_ENABLE();
        __HAL_SMU_HTIM5_FORCE_RESET();
        __HAL_SMU_HTIM5_RELEASE_RESET();
    }
    else if (instance == TIM6)
    {
        __HAL_SMU_TIM6_CLK_ENABLE();
        __HAL_SMU_TIM6_FORCE_RESET();
        __HAL_SMU_TIM6_RELEASE_RESET();
    }
    else
    {
        __HAL_SMU_TIM7_CLK_ENABLE();
        __HAL_SMU_TIM7_FORCE_RESET();
        __HAL_SMU_TIM7_RELEASE_RESET();
    }
}

/* MSP callbacks: the timer clock and reset of the instance under test */
void HAL_TIM_Base_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_OC_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_PWM_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_IC_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_OnePulse_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_Encoder_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

/**
 * @brief  Capture callback: the handle channel field identifies the source.
 * @note   The period between two consecutive captures of the same channel is
 *         the number of counter ticks of one input period; it is the quantity
 *         that can be compared between channels, because the raw capture value
 *         is a free running counter sample (each channel latches the counter at
 *         the edge it sees, so the values of two channels differ by whole
 *         periods whenever the edges are sampled at different times).
 */
void HAL_TIM_IC_CaptureCallback(HAL_TIM_HandleTypeDef *htim)
{
    uint32 idx = htim->Channel / 4U;    /* channel selector -> 0 based index */

    if (idx < 6U)
    {
        uint32 current = HAL_TIM_ReadCapturedValue(htim, htim->Channel);

        if (capture_count[idx] != 0U)
        {
            uint32 previous = capture_prev[idx];

            /* Difference over the auto reload boundary stays positive */
            capture_period[idx] = (current >= previous)
                                  ? (current - previous)
                                  : ((TEST_ARR + 1U) - previous + current);
        }

        capture_prev[idx]  = current;
        capture_value[idx] = current;
        capture_count[idx]++;
    }
}

/**
 * @brief  Interrupt handler of the TIM0 line.
 * @note   The handler counts the interrupts in which all six channels latched a
 *         capture: in such a pass every channel holds the counter value of the
 *         same edge, so the six values must be identical. That is the direct
 *         proof that the six inputs see the same waveform with the same phase.
 */
void TIM0_IRQ_Handler(void)
{
    uint32 before[6];
    uint32 idx;
    uint32 all = 1U;

    for (idx = 0U; idx < 6U; idx++)
    {
        before[idx] = capture_count[idx];
    }

    HAL_TIM_IRQHandler(&htim_dev);

    for (idx = 0U; idx < 6U; idx++)
    {
        if (capture_count[idx] == before[idx])
        {
            all = 0U;
        }
    }

    if (all != 0U)
    {
        for (idx = 0U; idx < 6U; idx++)
        {
            full_pass_value[idx] = capture_value[idx];
        }
        full_pass_count++;
    }
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the CLINT / CMU / MPU / USART integration tests:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2, CANX2 by
 *         8 -> core 180 MHz, AXILite4 Bus 1 and Bus 2 = 45 MHz (TIM0, TIM1),
 *         APBBus0 and APBBus1 = 22.5 MHz (TIM2 / TIM3 / TIM4 and TIM5 / TIM6 /
 *         TIM7 - TIM2 and TIM5 are advanced timers on the APB).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks used by this suite (GPIOH lives in the always on
       domain and has no gate macro) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Clock tree order: write the dividers while the system clock is still
       FIRC, then configure the PLL and switch to it (that call programs the
       flash controller clock before the switch and updates SystemCoreClock
       afterwards). */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&test_clocks);
}

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    TIM_IC_InitTypeDef ic_cfg;
    PLIC_InitTypeDef plic_init;
    uint32 idx;

    HAL_Init();
    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== TIM_IT_DRV_009 : input capture channels 1..6 ===\r\n");

    /* Step 1: the six capture pins */
    Gpio_Config(GPIOC, GPIO_PIN_3, GPIO_PinSource3, GPIO_AF_HTIM0_M1, GPIO_MODE_INPUT);
    Gpio_Config(GPIOA, GPIO_PIN_0, GPIO_PinSource0, GPIO_AF_HTIM0_M1, GPIO_MODE_INPUT);
    Gpio_Config(GPIOA, GPIO_PIN_1, GPIO_PinSource1, GPIO_AF_HTIM0_M1, GPIO_MODE_INPUT);
    Gpio_Config(GPIOA, GPIO_PIN_2, GPIO_PinSource2, GPIO_AF_HTIM0_M1, GPIO_MODE_INPUT);
    Gpio_Config(GPIOA, GPIO_PIN_3, GPIO_PinSource3, GPIO_AF_HTIM0_M1, GPIO_MODE_INPUT);
    Gpio_Config(GPIOA, GPIO_PIN_4, GPIO_PinSource4, GPIO_AF_HTIM0_M1, GPIO_MODE_INPUT);

    /* Step 2: the time base */
    Check("HAL_TIM_Base_Init() returns HAL_OK",
          (TimeBase_Config(TIM0, TEST_ARR, TEST_PSC, 0U, TIM_CKD_DIV1, TIM_COUNTERMODE_UP) == HAL_OK));

    /* Step 3: every channel as a direct rising edge capture input */
    __HAL_CLEAR_STRUCT(&ic_cfg);
    HAL_TIM_IC_StructInit(&ic_cfg);
    ic_cfg.ICPolarity  = TIM_ICPOLARITY_RISING;
    ic_cfg.ICSelection = TIM_ICSEL_DIRECTTI;
    ic_cfg.ICPrescaler = TIM_ICPSC_DIV1;
    ic_cfg.ICFilter    = 0U;
    for (idx = 1U; idx <= 6U; idx++)
    {
        Check("HAL_TIM_IC_ConfigChannel() returns HAL_OK",
              (HAL_TIM_IC_ConfigChannel(&htim_dev, &ic_cfg, (idx - 1U) * 4U) == HAL_OK));
    }
    Check("CCMR1.CC1S = 01", ((TIM0->CCMR1 & TIM_CCMR1_CC1S) == TIM_ICSEL_DIRECTTI));
    Check("CCMR3.CC5S = 01", ((TIM0->CCMR3 & TIM_CCMR3_CC5S) == TIM_ICSEL_DIRECTTI));
    Check("CCMR3.CC6S = 01",
          ((TIM0->CCMR3 & TIM_CCMR3_CC6S) == (TIM_ICSEL_DIRECTTI << 8U)));

    /* Step 4: capture interrupt of every channel through the PLIC */
    HAL_PLIC_StructInit(&plic_init);
    plic_init.PLIC_IRQChannel    = TIM0_IRQn;
    plic_init.PLIC_IRQPriority   = 1U;
    plic_init.PLIC_IRQChannelCmd = PLIC_ENABLE;
    (void)HAL_PLIC_Init(&plic_init);

    for (idx = 1U; idx <= 6U; idx++)
    {
        Check("HAL_TIM_IC_Start_IT() returns HAL_OK",
              (HAL_TIM_IC_Start_IT(&htim_dev, (idx - 1U) * 4U) == HAL_OK));
    }
    Check("DIER.CC1IE is set", ((TIM0->DIER & TIM_IT_CC1) != 0U));
    Check("DIER.CC6IE is set", ((TIM0->DIER & TIM_IT_CC6) != 0U));

    Summary();

    /* Measurement loop. Two quantities are printed per channel:
         - period : counter ticks between two consecutive captures of the same
                    channel, i.e. one input period. This is what has to agree
                    between the channels when they all see the same waveform.
         - freq   : counter clock divided by the period.
       The six channels are sampled at exactly the same instant (interrupts
       masked while the snapshot is copied), because the raw capture values are
       free running counter samples: printing them one after the other without
       a snapshot makes them differ by whole periods, since the UART takes
       several milliseconds per line while the input keeps producing edges. */
    for (;;)
    {
        uint32 count[6];
        uint32 value[6];
        uint32 period[6];
        uint32 delta[6];
        uint32 rate[6];
        uint32 tick_now;
        uint32 idx2;
        uint32 active = 0U;
        uint32 per_min = 0U;
        uint32 per_max = 0U;
        uint32 d_min = 0U;
        uint32 d_max = 0U;
        uint32 phase_ok = 1U;
        uint32 counter_clk;
        uint32 full_pass;

        static uint32 count_last[6];
        static uint32 tick_last;
        uint32 first_run;

        tick_now = HAL_GetTick();

        __disable_irq();
        for (idx2 = 0U; idx2 < 6U; idx2++)
        {
            count[idx2]  = capture_count[idx2];
            value[idx2]  = capture_value[idx2];
            period[idx2] = capture_period[idx2];
        }
        full_pass = full_pass_count;
        __enable_irq();

        /* Counter clock of the instance under test: TIM0..TIM2 and TIM5 live
           on AXILite4 Bus1 (AXI4Bus3), divided by the prescaler. */
        counter_clk = test_clocks.AXILite4Bus1_Frequency;
        if (counter_clk == 0U)
        {
            counter_clk = test_clocks.AXIBus3_Frequency;
        }
        counter_clk = counter_clk / (TEST_PSC + 1U);

        /* Edge rate over the wall clock interval, as an independent check of
           the period based frequency */
        first_run = (tick_last == 0U) ? 1U : 0U;
        for (idx2 = 0U; idx2 < 6U; idx2++)
        {
            uint32 span = tick_now - tick_last;

            delta[idx2] = count[idx2] - count_last[idx2];
            rate[idx2]  = ((first_run == 0U) && (span != 0U)) ? ((delta[idx2] * 1000U) / span) : 0U;
        }
        tick_last = tick_now;
        for (idx2 = 0U; idx2 < 6U; idx2++)
        {
            count_last[idx2] = count[idx2];
        }

        /* The cumulative count of a channel includes the edges counted while
           the other channels were still being started (each HAL_TIM_IC_Start_IT
           and its [PASS] print take a few input periods), so the counts are
           offset by a constant. The per second increment is the quantity that
           has to match. */
        printf("channel | captures | edges/s |  period |  freq\r\n");
        for (idx2 = 0U; idx2 < 6U; idx2++)
        {
            uint32 freq = 0U;

            if ((count[idx2] >= 2U) && (period[idx2] != 0U))
            {
                freq = counter_clk / period[idx2];
            }
            printf("   %d    | %8d | %7d | %7d | %6d\r\n",
                   (int)(idx2 + 1U), (int)count[idx2],
                   (int)rate[idx2], (int)period[idx2], (int)freq);
        }

        /* Consistency between the channels: same waveform means same period and
           a phase difference that is a whole number of periods. */
        for (idx2 = 0U; idx2 < 6U; idx2++)
        {
            if ((count[idx2] >= 3U) && (period[idx2] != 0U))
            {
                if (active == 0U)
                {
                    per_min = period[idx2];
                    per_max = period[idx2];
                }
                if (period[idx2] < per_min)
                {
                    per_min = period[idx2];
                }
                if (period[idx2] > per_max)
                {
                    per_max = period[idx2];
                }
                active++;
            }
        }

        if (active >= 2U)
        {
            uint32 ref = 0U;
            uint32 j;

            /* Reference: first channel that captured */
            for (idx2 = 0U; idx2 < 6U; idx2++)
            {
                if ((count[idx2] >= 3U) && (period[idx2] != 0U))
                {
                    ref = idx2;
                    break;
                }
            }

            for (idx2 = 0U; idx2 < 6U; idx2++)
            {
                uint32 diff;

                if ((count[idx2] < 3U) || (period[idx2] == 0U) || (idx2 == ref))
                {
                    continue;
                }

                /* The capture values are free running counter samples, so they
                   differ by whole input periods; the remainder is the phase
                   error in counter ticks. */
                diff = (value[idx2] >= value[ref]) ? (value[idx2] - value[ref])
                                                   : (value[ref] - value[idx2]);
                diff = diff % period[ref];
                if (diff > (period[ref] / 2U))
                {
                    diff = period[ref] - diff;
                }
                if (diff > 8U)
                {
                    phase_ok = 0U;
                }
            }

            /* Exact check with the six captures of one single interrupt */
            printf("full passes (all six captured in one interrupt) = %d\r\n",
                   (int)full_pass);
            if (full_pass != 0U)
            {
                __disable_irq();
                for (j = 0U; j < 6U; j++)
                {
                    value[j] = full_pass_value[j];
                }
                __enable_irq();

                printf("one interrupt, six captures : %d %d %d %d %d %d\r\n",
                       (int)value[0], (int)value[1], (int)value[2],
                       (int)value[3], (int)value[4], (int)value[5]);

                for (j = 0U; j < 6U; j++)
                {
                    if ((value[j] >= value[0]) ? ((value[j] - value[0]) > 2U)
                                               : ((value[0] - value[j]) > 2U))
                    {
                        phase_ok = 0U;
                    }
                }
            }
        }

        printf("counter clock = %d Hz (timer %d Hz / %d), channels with edges = %d\r\n",
               (int)counter_clk,
               (int)test_clocks.AXILite4Bus1_Frequency,
               (int)(TEST_PSC + 1U), (int)active);

        /* The edge rate of the channels must agree as well (the increments are
           free of the start up offset of the cumulative counts) */
        if (first_run == 0U)
        {
            for (idx2 = 0U; idx2 < 6U; idx2++)
            {
                if (delta[idx2] == 0U)
                {
                    continue;
                }
                if (d_min == 0U)
                {
                    d_min = delta[idx2];
                    d_max = delta[idx2];
                }
                if (delta[idx2] < d_min)
                {
                    d_min = delta[idx2];
                }
                if (delta[idx2] > d_max)
                {
                    d_max = delta[idx2];
                }
            }
            printf("edges per second : min %d, max %d\r\n", (int)d_min, (int)d_max);
        }

        if (active == 0U)
        {
            printf("note : no capture yet - feed a square wave to the channel pins\r\n");
        }

        /* Every iteration reports its own result (the loop runs forever) */
        check_failures = 0U;

        if (active >= 2U)
        {
            Check("every capturing channel measures the same period",
                  ((per_max - per_min) <= 2U));
            /* The increments are only available from the second iteration on
               (the first one records the baseline of the per second rate). */
            Check("every capturing channel counts the same edges",
                  (((first_run != 0U) || (d_min != 0U)) && ((d_max - d_min) <= 2U)));
            Check("captures of the channels are in phase", (phase_ok != 0U));
        }
        else
        {
            /* The square wave on the capture pins is an external stimulus: the
               cross channel comparison is only meaningful once at least two
               channels have seen an edge, so a board without a generator
               reports the observation instead of a failure. */
            printf("  [INFO] cross channel checks skipped - feed a square wave "
                   "to at least two capture pins\r\n");
        }

        Summary();

        delay_ms(1000U);
    }
}
