/**
 * @file    PKA_IT_DRV_002.c
 * @brief   HAL PKA integration test case 002 (RSA-512 modexp encryption).
 *
 * Case 002 translates the reference RSA-512 modular exponentiation
 * encryption example to the HAL API: the ciphertext is C = M^e mod n, where
 * the modulus n is 512 bits wide (16 words), the public exponent is 65537
 * and the four Montgomery precomputation values are derived by the
 * micro-code before the exponentiation.
 *
 * The case follows the operand layout of the reference material exactly:
 *   D0 = n, C0 = r^-1 mod n, D1 = n', D3 = r^2 mod n, A0 = M / C,
 *   D2 = e.
 *
 * The micro-code is loaded with HAL_PKA_LoadFirmware() and every operand is
 * transferred with HAL_PKA_WriteData() / HAL_PKA_ReadData(), so the case
 * exercises the whole HAL data path of the module.
 *
 * Tested functionality:
 *   HAL_PKA_Init() / HAL_PKA_MspInit() / HAL_PKA_ClearStack() /
 *   HAL_PKA_SetEntryPoint() / HAL_PKA_LoadFirmware() /
 *   HAL_PKA_WriteData() / HAL_PKA_ReadData() /
 *   HAL_PKA_GetStatStatus() / HAL_PKA_ClearStatus()
 *
 * Test procedure:
 *   1. Load the micro-code image and clear the operand window;
 *   2. write the modulus n to D0;
 *   3. entry 0x11 (r^-1 mod n): D0 -> C0;
 *   4. entry 0x10 (n'): C0 / D0 -> D1;
 *   5. entry 0x12 (r^2 mod n): C0 / D0 -> D3;
 *   6. write the plaintext M to A0 and the exponent e to D2;
 *   7. entry 0x16 (modular exponentiation): A0 D2 D0 D1 D3 -> A0;
 *   8. compare A0 with the expected ciphertext and print the failure count.
 *
 * Expected behaviour:
 *   - the four operations complete and the ciphertext matches the expected
 *     vector, so the summary stays at zero failures;
 *   - the case repeats the whole sequence forever, which allows the report
 *     to be read at any time.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"
#include "as32x601_pka_fw.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* One 512-bit operand is 16 words (64 bytes) */
#define TEST_WORDS                  (16U)

/* Partial radix used by the reference example: 0 selects the complete base */
#define TEST_PARTIAL_RADIX          (0U)

/* Base radix of every operation of this case */
#define TEST_BASE_RADIX             (PKA_BASE_RADIX_512)

/* Micro-code entry points used by the case */
#define TEST_EP_RINV                (0x11U)   /* r^-1 mod m                 */
#define TEST_EP_MPRIME              (0x10U)   /* m'                         */
#define TEST_EP_R2                  (0x12U)   /* r^2 mod m                  */
#define TEST_EP_MODEXP              (0x16U)   /* modular exponentiation     */

/* Bound of every polling loop, so a failure can never hang the case */
#define TEST_WAIT_GUARD             (20000000U)

/* Reporting period of the final loop (ms) */
#define TEST_POLL_MS                (1000U)

/* Private variables ---------------------------------------------------------*/
static HAL_PKA_HandleTypeDef hpka_dev;      /*!< PKA device handle            */
static PKA_InitTypeDef       pka_init;      /*!< configuration used at start  */
static HAL_SMU_HandleTypeDef hsmu_clk;      /*!< SMU handle (clock tree)      */
static uint32                failures = 0U; /*!< failed checks                */
static uint32                checks = 0U;   /*!< executed checks              */

/* Zero buffer used to clear the operand window (1024 words = the window) */
static uint32 pka_zero[PKA_OPERAND_WINDOW_WORDS_MAX];

/* Private function prototypes -----------------------------------------------*/
static void Section(const char *name);
static void Check(const char *name, uint32 condition);
static HAL_StatusTypeDef Pka_LoadFirmware(void);
static HAL_StatusTypeDef Pka_ClearMemory(void);
static HAL_StatusTypeDef Pka_Write(uint32 address, const uint32 *data, uint32 words);
static HAL_StatusTypeDef Pka_Read(uint32 address, uint32 *data, uint32 words);
static HAL_StatusTypeDef Pka_Run(uint32 entry, uint32 radix);
static uint32 Pka_Compare(const uint32 *result, const uint32 *expect, uint32 words);
static void Pka_Report(const char *name, const uint32 *result, const uint32 *expect,
                       uint32 words);
static void SystemClock_Init(void);

/* Private variables (test vectors) ------------------------------------------*/

/* RSA-512 modulus n = p * q */
static const uint32 RSA_n[TEST_WORDS] =
{
    0xf732704b, 0x5ac72429, 0x77022916, 0xfe2fa59b,
    0x01e2064e, 0x6c9b044a, 0x6406755e, 0xf2bf7a9c,
    0xe4ed3c7e, 0x86a86c56, 0x2f766e94, 0x0cf026c3,
    0x5272165c, 0x7405fa68, 0x4ee9ecdc, 0xc1004a73
};

/* RSA public exponent e = 0x10001 */
static const uint32 RSA_e[TEST_WORDS] =
{
    0x00010001, 0x00000000, 0x00000000, 0x00000000,
    0x00000000, 0x00000000, 0x00000000, 0x00000000,
    0x00000000, 0x00000000, 0x00000000, 0x00000000,
    0x00000000, 0x00000000, 0x00000000, 0x00000000
};

/* plaintext M */
static const uint32 RSA_M[TEST_WORDS] =
{
    0xb1f636f3, 0x1c5813f0, 0x0f2ec5d9, 0x5828fb3b,
    0xe6792f57, 0x52e22987, 0xebf50ad0, 0x3a84d733,
    0x65549e60, 0x620c771c, 0x86988206, 0x441179b0,
    0x2661dbac, 0x5f8c704c, 0x4db3088c, 0x0026f8bf
};

/* expected ciphertext C = M^e mod n */
static const uint32 RSA_C_Expect[TEST_WORDS] =
{
    0xAAD5C41E, 0x6225EFEA, 0x48C377ED, 0x2CC558ED,
    0x4DC784AE, 0xC98465C7, 0x78982996, 0x71F5C76B,
    0x488D6269, 0xB2386B6B, 0xD920FB92, 0x12E9FAF2,
    0xBD3EBAF5, 0xBD65BF3E, 0x2A112324, 0x9E3AE159
};

/* measured ciphertext */
static uint32 RSA_C_Result[TEST_WORDS];

/* measured Montgomery precomputation values (observability only) */
static uint32 RSA_rinv[TEST_WORDS];
static uint32 RSA_mprime[TEST_WORDS];
static uint32 RSA_r2[TEST_WORDS];


/* Private functions ---------------------------------------------------------*/
int main(void)
{
    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL, 90 MHz core clock) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);

    printf("\r\n ***** PKA RSA-512 modexp encryption test ***** \r\n");
    delay_ms(500U);

    /* Initialize the PKA handle: the low level callback enables the DSE clock
       and releases the domain reset */
    __HAL_CLEAR_STRUCT(&hpka_dev);
    hpka_dev.Instance = PKA;
    HAL_PKA_StructInit(&pka_init);
    (void)HAL_PKA_Init(&hpka_dev, &pka_init);

    Section("firmware and operand memory");
    Check("micro-code image loaded", (Pka_LoadFirmware() == HAL_OK) ? 1U : 0U);
    Check("operand window cleared", (Pka_ClearMemory() == HAL_OK) ? 1U : 0U);

    for (;;)
    {
        Section("Montgomery precomputation for the modulus n");

        /* n -> D0 */
        Check("modulus n written to D0",
              (Pka_Write(PKA_RSA_ADDR_512_D0, RSA_n, TEST_WORDS) == HAL_OK) ? 1U : 0U);

        /* r^-1 mod n: D0 -> C0 */
        Check("r^-1 mod n completed",
              (Pka_Run(TEST_EP_RINV, TEST_BASE_RADIX) == HAL_OK) ? 1U : 0U);
        (void)Pka_Read(PKA_RSA_ADDR_512_C0, RSA_rinv, TEST_WORDS);

        /* n': C0 / D0 -> D1 */
        Check("n' completed",
              (Pka_Run(TEST_EP_MPRIME, TEST_BASE_RADIX) == HAL_OK) ? 1U : 0U);
        (void)Pka_Read(PKA_RSA_ADDR_512_D1, RSA_mprime, TEST_WORDS);

        /* r^2 mod n: C0 / D0 -> D3 */
        Check("r^2 mod n completed",
              (Pka_Run(TEST_EP_R2, TEST_BASE_RADIX) == HAL_OK) ? 1U : 0U);
        (void)Pka_Read(PKA_RSA_ADDR_512_D3, RSA_r2, TEST_WORDS);

        printf("n'      = %08X %08X %08X %08X (high) \r\n",
               PRINT_U32(RSA_mprime[15]), PRINT_U32(RSA_mprime[14]),
               PRINT_U32(RSA_mprime[13]), PRINT_U32(RSA_mprime[12]));
        printf("r^2 mod n = %08X %08X %08X %08X (high) \r\n",
               PRINT_U32(RSA_r2[15]), PRINT_U32(RSA_r2[14]),
               PRINT_U32(RSA_r2[13]), PRINT_U32(RSA_r2[12]));

        Section("modular exponentiation C = M^e mod n");

        Check("plaintext M written to A0",
              (Pka_Write(PKA_RSA_ADDR_512_A0, RSA_M, TEST_WORDS) == HAL_OK) ? 1U : 0U);
        Check("exponent e written to D2",
              (Pka_Write(PKA_RSA_ADDR_512_D2, RSA_e, TEST_WORDS) == HAL_OK) ? 1U : 0U);

        Check("modexp completed",
              (Pka_Run(TEST_EP_MODEXP, TEST_BASE_RADIX) == HAL_OK) ? 1U : 0U);

        (void)Pka_Read(PKA_RSA_ADDR_512_A0, RSA_C_Result, TEST_WORDS);

        Check("ciphertext matches the expected vector",
              Pka_Compare(RSA_C_Result, RSA_C_Expect, TEST_WORDS));
        Pka_Report("ciphertext", RSA_C_Result, RSA_C_Expect, TEST_WORDS);

        printf("C = %08X %08X %08X %08X (high) \r\n",
               PRINT_U32(RSA_C_Result[15]), PRINT_U32(RSA_C_Result[14]),
               PRINT_U32(RSA_C_Result[13]), PRINT_U32(RSA_C_Result[12]));

        /* ------------------------------------------------------- summary --- */
        printf("\r\nchecks = %u | summary : failures = %u\r\n",
               PRINT_U32(checks), PRINT_U32(failures));

        delay_ms(TEST_POLL_MS);
    }
}

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Report a section title.
 * @param  name: section name.
 * @retval None
 */
static void Section(const char *name)
{
    printf("\r\n-- %s --\r\n", name);
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    checks++;

    if (condition == 0U)
    {
        failures++;
    }
    printf("%-56s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Load the PKA micro-code image through the HAL API.
 * @retval HAL status of HAL_PKA_LoadFirmware().
 */
static HAL_StatusTypeDef Pka_LoadFirmware(void)
{
    return HAL_PKA_LoadFirmware(&hpka_dev, pka_fw_addr, pka_fw_data, PKA_FW_LENGTH);
}

/**
 * @brief  Clear the whole operand window through the HAL API.
 * @retval HAL status of HAL_PKA_WriteData().
 */
static HAL_StatusTypeDef Pka_ClearMemory(void)
{
    return HAL_PKA_WriteData(&hpka_dev, PKA_OPERAND_WINDOW_FIRST, pka_zero,
                             PKA_OPERAND_WINDOW_WORDS_MAX);
}

/**
 * @brief  Write one operand through the HAL API.
 * @param  address: absolute operand address (PKA_ECC_ADDR_* / PKA_RSA_ADDR_*).
 * @param  data: source words.
 * @param  words: number of 32-bit words.
 * @retval HAL status of HAL_PKA_WriteData().
 * @note   The HAL API takes a byte offset from the instance base, while the
 *         address macros of the device header are absolute addresses, so the
 *         base is subtracted here.  The data cache is cleaned afterwards, so
 *         the accelerator observes the values that were just written.
 */
static HAL_StatusTypeDef Pka_Write(uint32 address, const uint32 *data, uint32 words)
{
    HAL_StatusTypeDef status;

    status = HAL_PKA_WriteData(&hpka_dev, address - PKA_BASE, data, words);
    CLEAR_CACHE();

    return status;
}

/**
 * @brief  Read one operand through the HAL API.
 * @param  address: absolute operand address (PKA_ECC_ADDR_* / PKA_RSA_ADDR_*).
 * @param  data: destination words.
 * @param  words: number of 32-bit words to read.
 * @retval HAL status of HAL_PKA_ReadData().
 * @note   The cache is cleaned before the read so the result that the
 *         accelerator wrote is fetched from the operand memory.
 */
static HAL_StatusTypeDef Pka_Read(uint32 address, uint32 *data, uint32 words)
{
    HAL_StatusTypeDef status;

    CLEAR_CACHE();
    status = HAL_PKA_ReadData(&hpka_dev, address - PKA_BASE, data, words);

    return status;
}

/**
 * @brief  Run one micro-code operation.
 * @param  entry: program entry point (word index of the micro-code region).
 * @param  radix: base radix encoding of the operation.
 * @retval HAL_OK when the operation completed, HAL_TIMEOUT when DONE never
 *         came within the guard, otherwise the status of the HAL call that
 *         failed.
 * @note   Sequence of the reference material, expressed with HAL calls only:
 *         clear the stack, set the entry point, start by writing CTRL.GO,
 *         poll STAT.DONE, stop by clearing CTRL.GO and acknowledge DONE.
 *         The GO bit is carried by the Init structure, so the start and the
 *         stop are two HAL_PKA_Init() calls.
 */
static HAL_StatusTypeDef Pka_Run(uint32 entry, uint32 radix)
{
    PKA_InitTypeDef   cfg;
    HAL_StatusTypeDef status;
    uint32            guard;

    (void)HAL_PKA_ClearStack(&hpka_dev);
    (void)HAL_PKA_SetEntryPoint(&hpka_dev, entry);

    /* Start: PKA_Go = PKA_GO_EN in the configuration structure */
    HAL_PKA_StructInit(&cfg);
    cfg.PKA_PartialRadix = TEST_PARTIAL_RADIX;
    cfg.PKA_BaseRadix    = radix;
    cfg.PKA_Go           = PKA_GO_EN;

    status = HAL_PKA_Init(&hpka_dev, &cfg);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Wait for the completion flag (bounded, so a failure cannot hang) */
    guard = TEST_WAIT_GUARD;
    while ((HAL_PKA_GetStatStatus(&hpka_dev, PKA_STATE_DONE) == RESET) && (guard != 0U))
    {
        guard--;
    }
    if (guard == 0U)
    {
        return HAL_TIMEOUT;
    }
    CLEAR_CACHE();

    /* The operand window is locked while the accelerator executes, so wait
       for the idle flag before the next register access */
    guard = TEST_WAIT_GUARD;
    while (((READ_REG(hpka_dev.Instance->RTN_CODE) & PKA_RTN_CODE_BUSY_Msk) != 0U) &&
           (guard != 0U))
    {
        guard--;
    }

    /* Stop: PKA_Go = PKA_GO_DIS */
    HAL_PKA_StructInit(&cfg);
    cfg.PKA_PartialRadix = TEST_PARTIAL_RADIX;
    cfg.PKA_BaseRadix    = radix;
    cfg.PKA_Go           = PKA_GO_DIS;
    (void)HAL_PKA_Init(&hpka_dev, &cfg);

    /* Acknowledge the completion so the next operation starts clean */
    HAL_PKA_ClearStatus(&hpka_dev, PKA_STATE_DONE);

    return HAL_OK;
}

/**
 * @brief  Compare a result vector against its expectation.
 * @param  result: measured words.
 * @param  expect: expected words.
 * @param  words: number of 32-bit words to compare.
 * @retval 1 when every word matches, 0 otherwise.
 */
static uint32 Pka_Compare(const uint32 *result, const uint32 *expect, uint32 words)
{
    uint32 i;

    for (i = 0U; i < words; i++)
    {
        if (result[i] != expect[i])
        {
            return 0U;
        }
    }

    return 1U;
}

/**
 * @brief  Print one result word group next to the expectation when they differ.
 * @param  name: label of the group.
 * @param  result: measured words.
 * @param  expect: expected words.
 * @param  words: number of words.
 * @retval None
 * @note   Only the first mismatching word of a failed comparison is printed,
 *         which keeps the report readable and still locates the problem.
 */
static void Pka_Report(const char *name, const uint32 *result, const uint32 *expect,
                       uint32 words)
{
    uint32 i;

    for (i = 0U; i < words; i++)
    {
        if (result[i] != expect[i])
        {
            printf("%-56s word[%u] = 0x%08X, expected 0x%08X\r\n", name, PRINT_U32(i),
                   PRINT_U32(result[i]), PRINT_U32(expect[i]));
            return;
        }
    }
}

/**
 * @brief  PKA low level initialization: instance clock gate and reset release.
 * @param  hpka: PKA handle.
 * @retval None
 * @note   The PKA is clocked by the AXILite4-Bus1 (DSE) domain, gated by the
 *         SMU, so the low level callback enables that gate and releases the
 *         reset of the domain.
 */
void HAL_PKA_MspInit(HAL_PKA_HandleTypeDef *hpka)
{
    if (hpka == NULL_PTR)
    {
        return;
    }

    __HAL_SMU_DSE_CLK_ENABLE();
    __HAL_SMU_DSE_FORCE_RESET();
    __HAL_SMU_DSE_RELEASE_RESET();
}

/**
 * @brief  Configure the system clock and the bus gates.
 * @retval None
 * @note   Same clock tree as the other HAL integration suites: the PLL is fed
 *         by the external oscillator (VCO 180 MHz) and the buses run at
 *         AXI4Bus3 / 2, APBBus0 / 2, APBBus1 / 2 and CANX2 / 8, which keeps
 *         the console USART on its usual 22.5 MHz.
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    smu_osc;
    SMU_ClockInitTypeDef  smu_clock;
    SMU_ClocksTypeDef     smu_clocks;
    HAL_PMU_HandleTypeDef hpmu;

    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Raise the core rail trim before the PLL is switched, as the other HAL
       integration suites do: the 1.2 V LDO APIs are gated on the handle state,
       so the PMU must be initialized first */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    __HAL_CLEAR_STRUCT(&smu_osc);
    smu_osc.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    smu_osc.FIRCState            = SMU_FIRC_ON;
    smu_osc.FIRCCalibrationValue = 0x00U;
    smu_osc.PLL.PLLState         = SMU_PLL_ON;
    smu_osc.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    smu_osc.PLL.PLLDivR          = 0x04U;
    smu_osc.PLL.PLLDivQ          = 0x01U;
    smu_osc.PLL.PLLDivN          = 0x14U;
    smu_osc.PLL.PLLDivF          = 0xB4U;
    smu_osc.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    (void)HAL_SMU_OscConfig(&hsmu_clk, &smu_osc, SMU_TIMEOUT_DEFAULT);

    /* Bus dividers */
    __HAL_CLEAR_STRUCT(&smu_clock);
    smu_clock.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    smu_clock.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    smu_clock.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    smu_clock.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &smu_clock);

    (void)HAL_SMU_GetClocksFreq(&smu_clocks);
}

/*****END OF FILE*****/
