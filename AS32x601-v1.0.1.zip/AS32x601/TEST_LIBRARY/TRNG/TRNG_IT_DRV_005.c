/**
 * @file    TRNG_IT_DRV_005.c
 * @brief   HAL TRNG integration test case 005 (lifecycle, metadata validation, error codes and shared helpers).
 *
 * HAL library extension case (no reference standard-library counterpart).
 * Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_TRNG_StructInit() / HAL_TRNG_Init() / HAL_TRNG_DeInit()
 *   HAL_TRNG_MspInit() / HAL_TRNG_MspDeInit()   (weak callbacks)
 *   HAL_TRNG_SendCommand() / HAL_TRNG_GenerateRandomNumber()
 *   HAL_TRNG_GenerateRandomNumber_IT() / HAL_TRNG_GetState() / GetError()
 *   TRNG_HandleIsValid() / TRNG_CheckState() / TRNG_LockHandle() / UnlockHandle()
 *
 * Test procedure:
 *   Check the default filler, then walk the refusal paths:
 *     A. HAL_TRNG_StructInit() defaults and the version macros;
 *     B. every public entry point with a null handle;
 *     C. initialization with a wrong Size / Version / Reserved word and
 *        with an instance that is not the TRNG (INVALID_PARAM recorded);
 *     D. the state gate of the three transfer interfaces before Init;
 *     E. a successful initialization plus the MSP contract (called once,
 *        before the lock, in the RESET state) and a repeated Init;
 *     F. the command value domain and the shared validation macros;
 *     G. the shared internal helpers (validity, state, bare metal lock);
 *     H. HAL_TRNG_DeInit() (registers cleared, idempotent) and a re-Init.
 *
 * Expected behaviour:
 *   every refusal returns the documented status, the refused calls never
 *   take the lock nor change the state nor reach the MSP callback, the
 *   de-initialization clears the module registers, and
 *   "summary : failures = 0" is printed.
 *
 * Note:
 *   HAL extension case. The bare metal lock is exercised through the
 *   shared helper only: the module is not RTOS enabled in this suite.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
#define TEST_BAUDRATE                  (115200U)   /*!< console baud rate     */
#define TEST_STEP_TIMEOUT_MS           (1000U)     /*!< per step wait budget  */
#define TEST_ROUND_DELAY_MS            (2000U)     /*!< delay between rounds  */

/* Private variables ---------------------------------------------------------*/
static volatile uint32 check_failures = 0U;   /*!< failed check counter        */
static HAL_SMU_HandleTypeDef hsmu_clk;        /*!< SMU handle (clock tree)     */

/**
 * @brief  TRNG handle used by every case of this suite.
 * @note   The peripheral is a single instance, so one handle is enough; the
 *         lifecycle case uses additional local handles for the refusal paths.
 */
TRNG_HandleTypeDef htrng_dev;

/* MSP callback bookkeeping (written by the shared MSP callbacks) */
uint32 Trng_MspInitCount   = 0U;              /*!< HAL_TRNG_MspInit() calls    */
uint32 Trng_MspDeInitCount = 0U;              /*!< HAL_TRNG_MspDeInit() calls  */
uint32 Trng_MspStateAtInit = 0xFFFFFFFFU;     /*!< handle state seen in the MSP */
uint32 Trng_MspLockAtInit  = 0xFFFFFFFFU;     /*!< handle lock seen in the MSP  */

/* Shared helpers of this suite (defined at the end of this file) */
void Check(const char *name, uint32 condition);
void Summary(void);
void SystemClock_Init(void);
void Trng_ClockEnable(void);
void Trng_PlicEnable(uint8 priority);
HAL_StatusTypeDef Trng_WaitFlag(uint32 flag, uint32 timeout_ms);
HAL_StatusTypeDef Trng_Seed(uint32 timeout_ms);



/* Private variables ---------------------------------------------------------*/
static uint32 random_word = 0U;                /*!< output of the generation API */

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    TRNG_InitTypeDef   trng_init;
    TRNG_HandleTypeDef hbad;                   /*!< handle of the refusal paths  */
    HAL_StatusTypeDef  status;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== TRNG_IT_DRV_005 : lifecycle, validation and shared helpers ===\r\n");

    /* ---- A. HAL_TRNG_StructInit() ----------------------------------------- */
    __HAL_CLEAR_STRUCT(&trng_init);
    HAL_TRNG_StructInit(&trng_init);
    Check("StructInit fills Size with sizeof(TRNG_InitTypeDef)",
          (trng_init.Size == (uint32)sizeof(TRNG_InitTypeDef)) ? 1U : 0U);
    Check("StructInit fills Version with TRNG_INIT_VERSION",
          (trng_init.Version == TRNG_INIT_VERSION) ? 1U : 0U);
    Check("StructInit clears both reserved words",
          ((trng_init.Reserved[0] == 0U) && (trng_init.Reserved[1] == 0U)) ? 1U : 0U);
    Check("TRNG_INIT_VERSION equals TRNG_INIT_V1", (TRNG_INIT_VERSION == TRNG_INIT_V1) ? 1U : 0U);
    Check("__HAL_TRNG_MODULE_VERSION is the 1.0 module version",
          (__HAL_TRNG_MODULE_VERSION == 0x0100U) ? 1U : 0U);

    /* ---- B. every public entry point refuses a null handle ---------------- */
    Check("HAL_TRNG_Init(NULL) is refused",
          (HAL_TRNG_Init(NULL_PTR) == HAL_ERROR) ? 1U : 0U);
    Check("HAL_TRNG_DeInit(NULL) is refused",
          (HAL_TRNG_DeInit(NULL_PTR) == HAL_ERROR) ? 1U : 0U);
    Check("HAL_TRNG_SendCommand(NULL) is refused",
          (HAL_TRNG_SendCommand(NULL_PTR, TRNG_COMMAND_NOP) == HAL_ERROR) ? 1U : 0U);
    Check("HAL_TRNG_GenerateRandomNumber(NULL) is refused",
          (HAL_TRNG_GenerateRandomNumber(NULL_PTR, &random_word) == HAL_ERROR) ? 1U : 0U);
    Check("HAL_TRNG_GenerateRandomNumber_IT(NULL) is refused",
          (HAL_TRNG_GenerateRandomNumber_IT(NULL_PTR) == HAL_ERROR) ? 1U : 0U);
    Check("HAL_TRNG_GetState(NULL) reports the RESET state",
          (HAL_TRNG_GetState(NULL_PTR) == HAL_TRNG_STATE_RESET) ? 1U : 0U);
    Check("HAL_TRNG_GetError(NULL) reports no error",
          (HAL_TRNG_GetError(NULL_PTR) == HAL_TRNG_ERROR_NONE) ? 1U : 0U);
    Check("HAL_TRNG_GetRandomNumber0(NULL) returns zero",
          (HAL_TRNG_GetRandomNumber0(NULL_PTR) == 0U) ? 1U : 0U);
    Check("HAL_TRNG_ReadLastRandomNumber(NULL) returns zero",
          (HAL_TRNG_ReadLastRandomNumber(NULL_PTR) == 0U) ? 1U : 0U);
    Check("HAL_TRNG_GetITStatus(NULL) reports RESET",
          (HAL_TRNG_GetITStatus(NULL_PTR, TRNG_FLAG_DONE) == RESET) ? 1U : 0U);

    /* The void entry points must survive a null handle as well */
    HAL_TRNG_StructInit(NULL_PTR);
    HAL_TRNG_ITConfig(NULL_PTR, TRNG_IT_DONE, ENABLE);
    HAL_TRNG_ClearITPendingBit(NULL_PTR, TRNG_FLAG_DONE);
    HAL_TRNG_IRQHandler(NULL_PTR);
    Check("the void entry points survive a null handle", 1U);

    /* ---- C. the metadata of the configuration structure is validated ------ */
    __HAL_CLEAR_STRUCT(&hbad);
    hbad.Instance = TRNG;

    trng_init.Size = 0U;
    hbad.Init = trng_init;
    Check("Init refuses a zero Size", (HAL_TRNG_Init(&hbad) == HAL_ERROR) ? 1U : 0U);
    Check("the refusal reports HAL_TRNG_ERROR_INVALID_PARAM",
          ((HAL_TRNG_GetError(&hbad) & HAL_TRNG_ERROR_INVALID_PARAM) != 0U) ? 1U : 0U);
    Check("the refused Init leaves the handle in the RESET state",
          (HAL_TRNG_GetState(&hbad) == HAL_TRNG_STATE_RESET) ? 1U : 0U);

    HAL_TRNG_StructInit(&trng_init);
    trng_init.Version = 0x0200U;
    hbad.Init = trng_init;
    Check("Init refuses an unknown structure version",
          (HAL_TRNG_Init(&hbad) == HAL_ERROR) ? 1U : 0U);

    HAL_TRNG_StructInit(&trng_init);
    trng_init.Reserved[0] = 1U;
    hbad.Init = trng_init;
    Check("Init refuses a non zero reserved word",
          (HAL_TRNG_Init(&hbad) == HAL_ERROR) ? 1U : 0U);

    hbad.Instance = (TRNG_TypeDef *)0x40000000U;
    HAL_TRNG_StructInit(&trng_init);
    hbad.Init = trng_init;
    Check("Init refuses an instance that is not the TRNG",
          (HAL_TRNG_Init(&hbad) == HAL_ERROR) ? 1U : 0U);

    /* ---- D. the state gate refuses the uninitialized handle --------------- */
    /* The handle below names the right instance but was never initialized */
    hbad.Instance = TRNG;
    HAL_TRNG_StructInit(&trng_init);
    hbad.Init = trng_init;
    Check("the refused initializations never reached the MSP callback",
          (Trng_MspInitCount == 0U) ? 1U : 0U);
    Check("SendCommand is refused on an uninitialized handle",
          (HAL_TRNG_SendCommand(&hbad, TRNG_COMMAND_NOP) == HAL_ERROR) ? 1U : 0U);
    Check("GenerateRandomNumber is refused on an uninitialized handle",
          (HAL_TRNG_GenerateRandomNumber(&hbad, &random_word) == HAL_ERROR) ? 1U : 0U);
    Check("GenerateRandomNumber_IT is refused on an uninitialized handle",
          (HAL_TRNG_GenerateRandomNumber_IT(&hbad) == HAL_ERROR) ? 1U : 0U);

    /* ---- E. a successful initialization and its MSP contract -------------- */
    __HAL_CLEAR_STRUCT(&htrng_dev);
    htrng_dev.Instance = TRNG;
    HAL_TRNG_StructInit(&trng_init);
    htrng_dev.Init = trng_init;

    Trng_MspInitCount   = 0U;
    Trng_MspDeInitCount = 0U;

    status = HAL_TRNG_Init(&htrng_dev);
    Check("Init accepts the StructInit metadata", (status == HAL_OK) ? 1U : 0U);
    Check("the handle is READY after the initialization",
          (HAL_TRNG_GetState(&htrng_dev) == HAL_TRNG_STATE_READY) ? 1U : 0U);
    Check("the error code is NONE after the initialization",
          (HAL_TRNG_GetError(&htrng_dev) == HAL_TRNG_ERROR_NONE) ? 1U : 0U);
    Check("the MSP initialization ran exactly once", (Trng_MspInitCount == 1U) ? 1U : 0U);
    Check("the MSP initialization observed the RESET state",
          (Trng_MspStateAtInit == (uint32)HAL_TRNG_STATE_RESET) ? 1U : 0U);
    Check("the MSP initialization ran before the handle was locked",
          (Trng_MspLockAtInit == (uint32)HAL_UNLOCKED) ? 1U : 0U);

    /* A second initialization of a ready handle must not repeat the MSP call */
    status = HAL_TRNG_Init(&htrng_dev);
    Check("a repeated Init returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("a repeated Init does not repeat the MSP initialization",
          (Trng_MspInitCount == 1U) ? 1U : 0U);

    /* ---- F. the command value domain is validated ------------------------- */
    random_word = 0U;
    Check("SendCommand refuses a reserved command encoding",
          (HAL_TRNG_SendCommand(&htrng_dev, 0x9U) == HAL_ERROR) ? 1U : 0U);
    Check("the refusal reports HAL_TRNG_ERROR_INVALID_PARAM",
          ((HAL_TRNG_GetError(&htrng_dev) & HAL_TRNG_ERROR_INVALID_PARAM) != 0U) ? 1U : 0U);
    Check("IS_TRNG_COMMAND accepts every documented encoding",
          ((IS_TRNG_COMMAND(TRNG_COMMAND_NOP) != 0U) &&
           (IS_TRNG_COMMAND(TRNG_COMMAND_ZEROIZE) != 0U) &&
           (IS_TRNG_COMMAND(0x9U) == 0U)) ? 1U : 0U);
    Check("IS_TRNG_ALL_INSTANCE accepts the TRNG instance",
          (IS_TRNG_ALL_INSTANCE(TRNG) != 0U) ? 1U : 0U);
    Check("IS_TRNG_ALL_INSTANCE refuses another instance",
          (IS_TRNG_ALL_INSTANCE((TRNG_TypeDef *)0x40000000U) == 0U) ? 1U : 0U);

    /* ---- G. the shared helpers of the driver ------------------------------ */
    Check("TRNG_HandleIsValid accepts the handle",
          (TRNG_HandleIsValid(&htrng_dev) == 1U) ? 1U : 0U);
    Check("TRNG_HandleIsValid refuses a null handle",
          (TRNG_HandleIsValid(NULL_PTR) == 0U) ? 1U : 0U);
    Check("TRNG_CheckState accepts a READY handle",
          (TRNG_CheckState(&htrng_dev) == HAL_OK) ? 1U : 0U);

    Check("TRNG_LockHandle acquires the bare metal lock",
          (TRNG_LockHandle(&htrng_dev, HAL_MAX_DELAY) == HAL_OK) ? 1U : 0U);
    Check("a second TRNG_LockHandle is refused with HAL_BUSY",
          (TRNG_LockHandle(&htrng_dev, HAL_MAX_DELAY) == HAL_BUSY) ? 1U : 0U);
    TRNG_UnlockHandle(&htrng_dev);
    Check("the lock can be taken again after the unlock",
          (TRNG_LockHandle(&htrng_dev, HAL_MAX_DELAY) == HAL_OK) ? 1U : 0U);
    TRNG_UnlockHandle(&htrng_dev);

    /* ---- H. de-initialization and its idempotency ------------------------- */
    status = HAL_TRNG_DeInit(&htrng_dev);
    Check("DeInit returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("DeInit publishes the RESET state",
          (HAL_TRNG_GetState(&htrng_dev) == HAL_TRNG_STATE_RESET) ? 1U : 0U);
    Check("DeInit closes every interrupt source of the module",
          ((TRNG->IE & TRNG_IT_ALL) == 0U) ? 1U : 0U);
    Check("DeInit acknowledges every event of the module",
          ((TRNG->ISTAT & TRNG_EVENT_ALL) == 0U) ? 1U : 0U);
    Check("DeInit clears the cached random word",
          (HAL_TRNG_ReadLastRandomNumber(&htrng_dev) == 0U) ? 1U : 0U);
    Check("the MSP de-initialization ran exactly once",
          (Trng_MspDeInitCount == 1U) ? 1U : 0U);
    Check("TRNG_CheckState refuses the de-initialized handle",
          (TRNG_CheckState(&htrng_dev) == HAL_ERROR) ? 1U : 0U);

    status = HAL_TRNG_DeInit(&htrng_dev);
    Check("a repeated DeInit is still accepted (idempotent)",
          (status == HAL_OK) ? 1U : 0U);
    Check("the repeated DeInit keeps the handle in the RESET state",
          (HAL_TRNG_GetState(&htrng_dev) == HAL_TRNG_STATE_RESET) ? 1U : 0U);

    /* A de-initialized handle can be initialized again */
    status = HAL_TRNG_Init(&htrng_dev);
    Check("the handle can be initialized again after DeInit",
          (status == HAL_OK) ? 1U : 0U);
    Check("the second initialization ran the MSP initialization again",
          (Trng_MspInitCount == 2U) ? 1U : 0U);

    Summary();

    for (;;)
    {
        delay_ms(1000U);
    }
}

/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the other integration tests of this library:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2 and
 *         CANX2 by 8, which gives core 180 MHz and APB 22.5 MHz (the console
 *         USART is clocked from APBBus0). The TRNG sits on the AXILite4-Bus1
 *         bus, which is not divided by this tree.
 * @note   Clock tree order: the dividers are written while the system clock
 *         is still the power on source (FIRC), then the PLL is configured and
 *         the system clock is switched to it. That last call programs the
 *         flash controller clock before the switch (the core keeps fetching
 *         from the flash) and updates SystemCoreClock afterwards.
 * @param  None
 * @retval None
 */
void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks (console pins of USART0 on GPIOD) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Open the clock gate of the security domain and release its reset.
 * @note   The TRNG has no dedicated SMU gate: it is clocked and reset through
 *         the DSE (security engine) domain bits of SMU->ALB1CFGR, exactly like
 *         the reference test case does with its DSE_CLK_ENABLE / DSE_RESET /
 *         DSE_SET sequence. The HAL TRNG driver has no default MSP body, so
 *         this helper is what HAL_TRNG_MspInit() / the cases call.
 * @note   The gate is never closed again (not even by HAL_TRNG_MspDeInit):
 *         the DSE domain is shared with the other security peripherals, and a
 *         closed gate makes any later register access stall the bus.
 * @param  None
 * @retval None
 */
void Trng_ClockEnable(void)
{
    __HAL_SMU_DSE_CLK_ENABLE();
    __HAL_SMU_DSE_FORCE_RESET();
    __HAL_SMU_DSE_RELEASE_RESET();
}

/**
 * @brief  Enable the TRNG interrupt source in the PLIC.
 * @param  priority: source priority (1..63, larger = higher priority)
 * @retval None
 */
void Trng_PlicEnable(uint8 priority)
{
    PLIC_InitTypeDef plic_init;

    __HAL_CLEAR_STRUCT(&plic_init);
    plic_init.Size               = sizeof(plic_init);
    plic_init.Version            = PLIC_INIT_VERSION;
    plic_init.PLIC_IRQChannel    = TRNG_IRQn;
    plic_init.PLIC_IRQPriority   = priority;
    plic_init.PLIC_IRQChannelCmd = PLIC_ENABLE;
    (void)HAL_PLIC_Init(&plic_init);
}

/**
 * @brief  Wait (bounded) until one ISTAT event flag of the handle is set.
 * @note   The flag is not cleared here: the caller decides who acknowledges it
 *         (the driver for the completions it owns, the application for the
 *         events it enabled itself).
 * @param  flag: event mask (TRNG_FLAG_x or a combination)
 * @param  timeout_ms: timeout in milliseconds
 * @retval HAL_StatusTypeDef: HAL_OK when the flag was observed / HAL_TIMEOUT
 */
HAL_StatusTypeDef Trng_WaitFlag(uint32 flag, uint32 timeout_ms)
{
    uint32 tickstart = HAL_GetTick();

    while (HAL_TRNG_GetITStatus(&htrng_dev, flag) == RESET)
    {
        if ((HAL_GetTick() - tickstart) > timeout_ms)
        {
            return HAL_TIMEOUT;
        }
    }

    return HAL_OK;
}

/**
 * @brief  Run the DRBG startup sequence: ZEROIZE -> GEN_NOISE -> CREATE_STATE.
 * @note   This is the sequence the reference test case runs at the beginning of
 *         every round; it is factored out here because the cases that use the
 *         HAL generation interfaces only need the DRBG to be seeded once.
 * @param  timeout_ms: per step timeout in milliseconds
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (command refused) / HAL_TIMEOUT
 */
HAL_StatusTypeDef Trng_Seed(uint32 timeout_ms)
{
    if (HAL_TRNG_SendCommand(&htrng_dev, TRNG_COMMAND_ZEROIZE) != HAL_OK)
    {
        return HAL_ERROR;
    }
    if (Trng_WaitFlag(TRNG_FLAG_ZEROIZED, timeout_ms) != HAL_OK)
    {
        return HAL_TIMEOUT;
    }
    HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_ZEROIZED);
    HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_DONE);

    if (HAL_TRNG_SendCommand(&htrng_dev, TRNG_COMMAND_GEN_NOISE) != HAL_OK)
    {
        return HAL_ERROR;
    }
    if (Trng_WaitFlag(TRNG_FLAG_DONE, timeout_ms) != HAL_OK)
    {
        return HAL_TIMEOUT;
    }
    HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_DONE);

    if (HAL_TRNG_SendCommand(&htrng_dev, TRNG_COMMAND_CREATE_STATE) != HAL_OK)
    {
        return HAL_ERROR;
    }
    if (Trng_WaitFlag(TRNG_FLAG_DONE, timeout_ms) != HAL_OK)
    {
        return HAL_TIMEOUT;
    }
    HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_DONE);

    return HAL_OK;
}

/* MSP callbacks ------------------------------------------------------------*/

/**
 * @brief  Initialize the TRNG MSP (security domain clock gate and reset).
 * @note   The default implementation of the driver is empty, so the DSE domain
 *         is opened here (the TRNG has no gate of its own).
 * @note   The call is recorded so that the lifecycle case can verify the
 *         LOCK-06 / MSP-04 contract: the callback must run outside the handle
 *         lock and only on the first initialization (state RESET).
 * @param  htrng: TRNG handle
 * @retval None
 */
void HAL_TRNG_MspInit(TRNG_HandleTypeDef *htrng)
{
    Trng_MspInitCount++;
    Trng_MspStateAtInit = (uint32)htrng->State;
    Trng_MspLockAtInit  = (uint32)htrng->Lock;

    Trng_ClockEnable();
}

/**
 * @brief  De-initialize the TRNG MSP.
 * @note   The DSE clock gate is shared with the other security peripherals and
 *         is left open on purpose, so that a case may read the TRNG registers
 *         after a de-initialization without stalling the bus.
 * @param  htrng: TRNG handle
 * @retval None
 */
void HAL_TRNG_MspDeInit(TRNG_HandleTypeDef *htrng)
{
    Trng_MspDeInitCount++;

    (void)htrng;
}

/*****END OF FILE*****/
