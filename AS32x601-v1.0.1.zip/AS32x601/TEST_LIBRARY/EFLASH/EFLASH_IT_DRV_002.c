/**
 * @file    EFLASH_IT_DRV_002.c
 * @brief   HAL EFLASH integration test case 002 (P-Flash write protection).
 *
 * HAL port of the reference test case Eflash_IT_DRV_002: only HAL APIs are used.
 *
 * Tested functionality:
 *   HAL_FLASH_Init() / HAL_FLASH_Unlock() / HAL_FLASH_Erase()
 *   HAL_FLASH_SetPFlashWriteProtection() / HAL_FLASH_ResetPFlashWriteProtection()
 *   HAL_FLASH_GetPFlashWriteProtStatus()
 *   HAL_FLASH_Program() / HAL_FLASH_Read()
 *   HAL_FLASH_GetFlagStatus() / HAL_FLASH_ClearFlagStatus() / HAL_FLASH_GetError()
 *
 * Test procedure:
 *   1. initialize the driver, unlock the controller and erase the last P-Flash
 *      sector (0x011F0000, protection area 32);
 *   2. protect area 32 and read the status back (protected);
 *   3. program the protected sector: the call must fail, the handle must
 *      record HAL_FLASH_ERROR_WRP and the hardware WPERR flag must be set;
 *   4. clear the WPERR flag, remove the protection and read the status back
 *      (unprotected);
 *   5. program the sector again: the call must succeed and the data must be
 *      read back unchanged, with the WPERR flag still clear.
 *
 * Expected behaviour:
 *   a programming request into a protected area is refused with an error and a
 *   latched WPERR flag, and the same request succeeds once the protection is
 *   removed; "summary : failures = 0" is printed.
 *
 * Note:
 *   Bit polarity of the protection register (device description, reset value
 *   0xFFFFFFFF): a 0 bit means the area is protected, a 1 bit means it is
 *   writable. Therefore HAL_FLASH_GetPFlashWriteProtStatus() returns
 *   FLASH_FLAG_RESET while the area is protected and FLASH_FLAG_SET after the
 *   protection was removed. The check names below state the meaning, not the
 *   raw flag value.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define -----------------------------------------------------------*/
#define TEST_BAUDRATE                  (115200U)      /*!< console baud rate   */
#define TEST_PROTECTED_SECTOR          (0x011F0000U)  /*!< protection area 32  */
#define TEST_PROTECT_AREA              FLASH_WP_AREA32
#define TEST_PATTERN_WORDS             (128U)         /*!< 512 bytes           */
#define TEST_ROUND_DELAY_MS            (2000U)        /*!< delay between runs  */

/* Private variables ---------------------------------------------------------*/
static volatile uint32 check_failures = 0U;   /*!< failed check counter        */
static HAL_SMU_HandleTypeDef hsmu_clk;        /*!< SMU handle (clock tree)     */
static HAL_FLASH_HandleTypeDef hflash_dev;    /*!< FLASH handle of this case   */

static uint32 program_data[TEST_PATTERN_WORDS];
static uint32 read_data[TEST_PATTERN_WORDS];

/* Shared helpers of this suite (defined at the end of this file) */
void Check(const char *name, uint32 condition);
void Summary(void);
void SystemClock_Init(void);
void Flash_InitDevice(void);
void FillPattern(void);
uint32 BufferEquals(const uint32 *a, const uint32 *b, uint32 words);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    FLASH_EraseInitTypeDef erase;
    HAL_StatusTypeDef      status;
    uint32                 addr_error;
    uint32                 i;

    HAL_Init();
    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== EFLASH_IT_DRV_002 : P-Flash write protection ===\r\n");

    /* ---- 1. initialization, unlock and erase the protected sector --------- */
    Flash_InitDevice();
    FillPattern();
    Check("HAL_FLASH_Init publishes the READY state",
          (HAL_FLASH_GetState(&hflash_dev) == HAL_FLASH_STATE_READY) ? 1U : 0U);

    status = HAL_FLASH_Unlock(&hflash_dev);
    Check("HAL_FLASH_Unlock returns HAL_OK", (status == HAL_OK) ? 1U : 0U);

    erase.TypeErase = FLASH_TYPEERASE_SECTORS;
    erase.Address   = TEST_PROTECTED_SECTOR;
    erase.Length    = PFLASH_SECTOR_SIZE;
    addr_error      = 0xFFFFFFFFU;
    status = HAL_FLASH_Erase(&hflash_dev, &erase, &addr_error);
    Check("sector erase of the area 32 sector returns HAL_OK",
          (status == HAL_OK) ? 1U : 0U);

    /* ---- 2. protect the area and verify the read back --------------------- */
    status = HAL_FLASH_SetPFlashWriteProtection(&hflash_dev, TEST_PROTECT_AREA);
    Check("HAL_FLASH_SetPFlashWriteProtection returns HAL_OK",
          (status == HAL_OK) ? 1U : 0U);
    Check("the area reads back as protected (bit = 0)",
          (HAL_FLASH_GetPFlashWriteProtStatus(&hflash_dev, TEST_PROTECT_AREA) ==
           FLASH_FLAG_RESET) ? 1U : 0U);

    /* ---- 3. programming a protected area must fail ------------------------ */
    status = HAL_FLASH_Program(&hflash_dev, TEST_PROTECTED_SECTOR, 512U, program_data);
    Check("programming a protected area is refused", (status == HAL_ERROR) ? 1U : 0U);
    Check("the handle records the write protection error",
          ((HAL_FLASH_GetError(&hflash_dev) & HAL_FLASH_ERROR_WRP) != 0U) ? 1U : 0U);
    Check("the hardware WPERR flag is latched",
          (HAL_FLASH_GetFlagStatus(&hflash_dev, FLASH_FLAG_WPERR) == FLASH_FLAG_SET) ? 1U : 0U);
    Check("the failed programming leaves the handle in the recoverable ERROR state",
          (HAL_FLASH_GetState(&hflash_dev) == HAL_FLASH_STATE_ERROR) ? 1U : 0U);

    /* ---- 4. clear the flag and remove the protection ---------------------- */
    HAL_FLASH_ClearFlagStatus(&hflash_dev, FLASH_CLEAR_WPERR);
    Check("clearing WPERR works",
          (HAL_FLASH_GetFlagStatus(&hflash_dev, FLASH_FLAG_WPERR) == FLASH_FLAG_RESET) ? 1U : 0U);

    status = HAL_FLASH_ResetPFlashWriteProtection(&hflash_dev, TEST_PROTECT_AREA);
    Check("HAL_FLASH_ResetPFlashWriteProtection returns HAL_OK",
          (status == HAL_OK) ? 1U : 0U);
    Check("the area reads back as unprotected (bit = 1)",
          (HAL_FLASH_GetPFlashWriteProtStatus(&hflash_dev, TEST_PROTECT_AREA) ==
           FLASH_FLAG_SET) ? 1U : 0U);

    /* ---- 5. the same request now succeeds -------------------------------- */
    status = HAL_FLASH_Program(&hflash_dev, TEST_PROTECTED_SECTOR, 512U, program_data);
    Check("programming the unprotected area returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("the successful programming clears the previous error code",
          (HAL_FLASH_GetError(&hflash_dev) == HAL_FLASH_ERROR_NONE) ? 1U : 0U);
    Check("no WPERR is latched by the successful programming",
          (HAL_FLASH_GetFlagStatus(&hflash_dev, FLASH_FLAG_WPERR) == FLASH_FLAG_RESET) ? 1U : 0U);

    for (i = 0U; i < TEST_PATTERN_WORDS; i++)
    {
        read_data[i] = 0U;
    }
    status = HAL_FLASH_Read(&hflash_dev, TEST_PROTECTED_SECTOR, 512U, read_data);
    Check("read back of the protected sector returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("the programmed content is read back unchanged",
          BufferEquals(read_data, program_data, TEST_PATTERN_WORDS));

    /* ---- 6. tear down ---------------------------------------------------- */
    status = HAL_FLASH_Lock(&hflash_dev);
    Check("HAL_FLASH_Lock returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    status = HAL_FLASH_DeInit(&hflash_dev);
    Check("HAL_FLASH_DeInit returns HAL_OK", (status == HAL_OK) ? 1U : 0U);

    Summary();

    for (;;)
    {
        delay_ms(TEST_ROUND_DELAY_MS);
    }
}

/* Private functions -------------------------------------------------------*/

void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

void FillPattern(void)
{
    uint32 i;

    for (i = 0U; i < TEST_PATTERN_WORDS; i++)
    {
        program_data[i] = (0x01020304U + (i * 0x01010101U)) ^ (i << 24);
    }
}

uint32 BufferEquals(const uint32 *a, const uint32 *b, uint32 words)
{
    uint32 i;

    for (i = 0U; i < words; i++)
    {
        if (a[i] != b[i])
        {
            printf("  mismatch at word %u : 0x%08X / 0x%08X\r\n",
               (unsigned)i, (unsigned)a[i], (unsigned)b[i]);
            return 0U;
        }
    }

    return 1U;
}

/**
 * @brief  Configure the system clock tree (PLL 180 MHz, APB 22.5 MHz).
 * @param  None
 * @retval None
 */
void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Initialize the FLASH driver handle of this suite.
 * @param  None
 * @retval None
 */
void Flash_InitDevice(void)
{
    __HAL_CLEAR_STRUCT(&hflash_dev);
    hflash_dev.Instance = EFLASH;
    HAL_FLASH_StructInit(&hflash_dev.Init);
    hflash_dev.Init.ClockFreq = (uint32)(SystemCoreClock / 1000000U);
    (void)HAL_FLASH_Init(&hflash_dev);
}

/*****END OF FILE*****/
