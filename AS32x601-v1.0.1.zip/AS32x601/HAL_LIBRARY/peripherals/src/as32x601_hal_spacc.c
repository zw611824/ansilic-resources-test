/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):    Xiamen Guoke Anxin Technology Co., LTD
 * FileName:         as32x601_hal_spacc.c
 * Author:           ANSILIC APPLICATION GROUP
 * Version:         V1.3
 * Date:   2026/10/09
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/09/02     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/07     1.1     align with the library
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.2     align the module with the library
 *                                                       architecture spec (resource lock and
 *                                                       RTOS chapters): give the lock helper
 *                                                       a Timeout parameter and a NULL mutex
 *                                                       guard, add the shared validity and
 *                                                       state helpers, run the MSP callbacks
 *                                                       outside the locked region, validate
 *                                                       the arguments at run time, apply the
 *                                                       state gate to the interrupt
 *                                                       configuration interface while the
 *                                                       packet and context programming
 *                                                       interfaces stay callable before the
 *                                                       initialization (the command sequence
 *                                                       programs the descriptors first),
 *                                                       report the guard path of every locked
 *                                                       entry point and yield the CPU while
 *                                                       polling
 *                                                       conventions: module
 *                                                       switch guard, shared
 *                                                       lock helpers
 *                                                       (SPACC_LockHandle /
 *                                                       SPACC_UnlockHandle,
 *                                                       RTOS branch uses the
 *                                                       LockMutex handle),
 *                                                       NULL guards on every
 *                                                       public function,
 *                                                       Version+Size init
 *                                                       structure, error code
 *                                                       field + HAL_SPACC_GetError()
 *     ANSILIC APPLICATION GROUP  2026/10/09     1.3     restore the " *" prefix of the history
 *                                                       continuation lines
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Security Processor
 *                  (SPACC) peripheral:
 *                  - Initialization and de-initialization (HAL_SPACC_Init /
 *                    HAL_SPACC_DeInit), configuration structure handling;
 *                  - Packet descriptor configuration
 *                    (HAL_SPACC_PacketInit);
 *                  - Interrupt / flag management: HAL_SPACC_ITConfig(),
 *                    HAL_SPACC_GetITStatus(),
 *                    HAL_SPACC_CommandExecResult(),
 *                    HAL_SPACC_StateFIFOFlag() and HAL_SPACC_IRQHandler();
 *                  - Context memory access: HAL_SPACC_WriteContext() /
 *                    HAL_SPACC_ReadContext();
 *                  - Status / state: HAL_SPACC_ReadStatus(),
 *                    HAL_SPACC_GetState() and HAL_SPACC_GetError().
 *
 *                  Typical usage (see the SM4 / hash examples):
 *                  (#) Call HAL_SPACC_MspInit() (clock enable through the
 *                      SMU, PLIC interrupt enable);
 *                  (#) Fill a SPACC_InitTypeDef structure with
 *                      HAL_SPACC_StructInit() or manually, then call
 *                      HAL_SPACC_Init() with the handle;
 *                  (#) Load the key / IV into the context memory with
 *                      HAL_SPACC_WriteContext();
 *                  (#) Fill a SPACC_PacketTypeDef structure and call
 *                      HAL_SPACC_PacketInit() to configure the packet
 *                      descriptor registers;
 *                  (#) Wait for the completion by polling the status FIFO
 *                      (HAL_SPACC_StateFIFOFlag / HAL_SPACC_GetITStatus) or
 *                      by the SPACC interrupt (HAL_SPACC_IRQHandler), then
 *                      read the result with HAL_SPACC_ReadStatus() and
 *                      HAL_SPACC_ReadContext().
 * @complexity  Simple
 *              Polling only (command-queue), lock + state machine,
 *              interrupt flag / handler support.
 */
#include "as32x601_hal.h"          /* HAL common types and utilities          */
#include "as32x601_hal_spacc.h"    /* SPACC HAL API and register macros       */

/* The HAL_SPACC_MODULE_ENABLED switch is provided by the user configuration
 * file (as32x601_hal_conf.h, included above through as32x601_hal.h): the
 * whole implementation is compiled only while the module is enabled. */
#ifdef HAL_SPACC_MODULE_ENABLED

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Check whether the SPACC handle and its instance are valid.
 * @param  hspacc: pointer to a HAL_SPACC_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
uint32 SPACC_HandleIsValid(HAL_SPACC_HandleTypeDef *hspacc)
{
    if (hspacc == NULL_PTR)
    {
        return 0U;
    }

    if (IS_SPACC_ALL_INSTANCE(hspacc->Instance) == 0U)
    {
        return 0U;
    }

    return 1U;
}

/**
 * @brief  Check whether the handle accepts a new operation.
 * @note   ARCH-CONST-09: a handle that is BUSY (an operation is ongoing in
 *         another context) rejects any other operation with HAL_BUSY, an
 *         uninitialized handle (RESET) requires HAL_SPACC_Init() first and
 *         is rejected with HAL_ERROR, while the recoverable state (ERROR)
 *         accepts a new operation directly.
 * @param  hspacc: pointer to a HAL_SPACC_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK (accepted) / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef SPACC_CheckState(HAL_SPACC_HandleTypeDef *hspacc)
{
    if (hspacc->State == HAL_SPACC_STATE_BUSY)
    {
        return HAL_BUSY;
    }

    if (hspacc->State == HAL_SPACC_STATE_RESET)
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Lock the handle (RTOS mutex or single core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_SPACC_MspInit()). The bare metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; the value is passed to HAL_MutexAcquire() as
 *         is (RTOS ticks; HAL_MAX_DELAY means an infinite wait).
 * @param  hspacc: pointer to a HAL_SPACC_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef SPACC_LockHandle(HAL_SPACC_HandleTypeDef *hspacc, uint32 Timeout)
{
#if (USE_RTOS == 1)
    if (hspacc->LockMutex == NULL_PTR)
    {
        /* The porting layer did not create the mutex (e.g. HAL_SPACC_MspInit()
         * was not overridden): report it instead of calling the RTOS with an
         * invalid mutex handle */
        return HAL_ERROR;
    }

    return HAL_MutexAcquire(hspacc->LockMutex, Timeout);
#else
    /* Prevent unused argument compilation warning: the bare metal lock flag
     * either succeeds immediately or reports HAL_BUSY, it never waits */
    UNUSED(Timeout);

    if (hspacc->Lock == HAL_LOCKED)
    {
        return HAL_BUSY;
    }

    hspacc->Lock = HAL_LOCKED;

    return HAL_OK;
#endif /* USE_RTOS */
}

/**
 * @brief  Unlock the handle.
 * @param  hspacc: pointer to a HAL_SPACC_HandleTypeDef structure.
 * @retval None
 */
void SPACC_UnlockHandle(HAL_SPACC_HandleTypeDef *hspacc)
{
#if (USE_RTOS == 1)
    (void)HAL_MutexRelease(hspacc->LockMutex);
#else
    hspacc->Lock = HAL_UNLOCKED;
#endif /* USE_RTOS */
}

/* Exported functions ---------------------------------------------------------*/

/** @addtogroup SPACC_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Fills a SPACC_InitTypeDef structure with the reset default values. (NON-BLOCKING)
 * @note   This is the HAL equivalent of the legacy SPACC_Struct(): it resets
 *         every field of the configuration structure to its default value
 *         and sets the Size / Version metafields. The defaults are applied
 *         by HAL_SPACC_Init() to the control registers: cipher algorithm
 *         NULL, SM4 mode ECB, hash algorithm NULL, SM3 mode RAW_SHAKE,
 *         transfer mode decrypt, key from context, AAD not copied, ICV
 *         computed over plaintext and not encrypted / appended, key not
 *         expanded, message not first / not last, key type hash.
 * @param  Init: pointer to the SPACC_InitTypeDef structure to be filled.
 * @retval None
 */
void HAL_SPACC_StructInit(SPACC_InitTypeDef *Init)
{
    /* Check the parameters */
    if (Init == NULL_PTR)
    {
        return;
    }

    /* Reset SPACC init structure parameters values */
    Init->Size                    = sizeof(SPACC_InitTypeDef); /*!< sizeof struct */
    Init->Version                 = SPACC_INIT_VERSION;        /*!< V1            */
    Init->SPACC_CipherAlgorithm   = SPACC_CIPHER_ALG_NULL;
    Init->SPACC_SM4CipherMode     = SPACC_SM4_CIPHER_MODE_ECB;
    Init->SPACC_HashAlgorithm     = SPACC_HASH_ALG_NULL;
    Init->SPACC_SM3HashMode       = SPACC_SM3_HASH_MODE_RAW_SHAKE;
    Init->SPACC_TransferMode      = SPACC_TRANS_TO_APPLY_DECRYPT;
    Init->SPACC_ContextIndex      = 0U;
    Init->SPACC_KeyFrom           = SPACC_KEY_FROM_CTX;
    Init->SPACC_AADCopy           = SPACC_APP_NOT_COPY;
    Init->SPACC_ICVCompute        = SPACC_ICV_COMPUTER_PLAIN;
    Init->SPACC_ICVEncrypt        = SPACC_ICV_NOT_ENCRYPT;
    Init->SPACC_ICVLocation       = SPACC_ICV_LOCATION_OFFSET;
    Init->SPACC_KeyExpand         = SPACC_KEY_NOT_EXPAND;
    Init->SPACC_MessageBegin      = SPACC_MSG_BEGIN_NOT_FIRST;
    Init->SPACC_MessageEnd        = SPACC_MSG_END_NOT_LAST;
    Init->SPACC_SoftwareID        = 0U;
    Init->SPACC_PriorityCommandFIFO = 0U;
    Init->SPACC_KeySize           = 0U;
    Init->SPACC_KeyIndex          = 0U;
    Init->SPACC_KeyType           = SPACC_KEY_TYPE_HASH;
    Init->Reserved[0]             = 0U;                         /*!< Reserved for future use */
    Init->Reserved[1]             = 0U;                         /*!< Reserved for future use */
}

/**
 * @brief  Initializes the SPACC peripheral. (NON-BLOCKING)
 * @note   The SPACC runs as a command-queue coprocessor: the command is
 *         submitted by configuring the SW_CTRL / KEY_SZ / CTRL registers
 *         and the packet descriptor registers. This function applies the
 *         SPACC_InitTypeDef structure to the control registers:
 *         SW_CTRL (software ID and priority command FIFO selection),
 *         KEY_SZ (key size / key index / key type) and CTRL (cipher
 *         algorithm / SM4 cipher mode / hash algorithm / SM3 hash mode /
 *         transfer mode / context index / key source / AAD copy / ICV
 *         compute / ICV encrypt / ICV location / key expand / message
 *         begin / message end).
 * @param  hspacc: pointer to a HAL_SPACC_HandleTypeDef structure that
 *         contains the configuration information for SPACC.
 * @param  Init: pointer to a SPACC_InitTypeDef structure that contains the
 *         configuration for the SPACC control registers.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_SPACC_Init(HAL_SPACC_HandleTypeDef *hspacc, const SPACC_InitTypeDef *Init)
{
    uint32 temp = 0U;

    /* Check the SPACC handle allocation */
    if (SPACC_HandleIsValid(hspacc) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_SPACC_ALL_INSTANCE(hspacc->Instance));
    assert_param(Init != NULL_PTR);
    assert_param(IS_SPACC_KEY_TYPE(Init->SPACC_KeyType));
    assert_param(IS_SPACC_CIPHER_ALG(Init->SPACC_CipherAlgorithm));
    assert_param(IS_SPACC_SM4_CIPHER_MODE(Init->SPACC_SM4CipherMode));
    assert_param(IS_SPACC_HASH_ALG(Init->SPACC_HashAlgorithm));
    assert_param(IS_SPACC_SM3_HASH_MODE(Init->SPACC_SM3HashMode));
    assert_param(IS_SPACC_TRANS_TO_APPLY(Init->SPACC_TransferMode));
    assert_param(IS_SPACC_KEY_FROM(Init->SPACC_KeyFrom));
    assert_param(IS_SPACC_APP_COPY(Init->SPACC_AADCopy));
    assert_param(IS_SPACC_ICV_COMPUTER(Init->SPACC_ICVCompute));
    assert_param(IS_SPACC_ICV_ENCRYPT(Init->SPACC_ICVEncrypt));
    assert_param(IS_SPACC_ICV_LOCATION(Init->SPACC_ICVLocation));
    assert_param(IS_SPACC_KEY_EXPAND(Init->SPACC_KeyExpand));
    assert_param(IS_SPACC_MSG_BEGIN(Init->SPACC_MessageBegin));
    assert_param(IS_SPACC_MSG_END(Init->SPACC_MessageEnd));

    /* Run time validation, so that the checks stay effective in a build with
     * the assertions disabled. The metafields of the configuration structure
     * (Size / Version, architecture spec section 22) and the two reserved words
     * are validated as well. A rejected call neither takes the lock nor changes
     * the handle state nor touches a register. */
    if ((Init == NULL_PTR) ||
        (IS_SPACC_ALL_INSTANCE(hspacc->Instance) == 0U) ||
        (IS_SPACC_KEY_TYPE(Init->SPACC_KeyType) == 0U) ||
        (IS_SPACC_CIPHER_ALG(Init->SPACC_CipherAlgorithm) == 0U) ||
        (IS_SPACC_SM4_CIPHER_MODE(Init->SPACC_SM4CipherMode) == 0U) ||
        (IS_SPACC_HASH_ALG(Init->SPACC_HashAlgorithm) == 0U) ||
        (IS_SPACC_SM3_HASH_MODE(Init->SPACC_SM3HashMode) == 0U) ||
        (IS_SPACC_TRANS_TO_APPLY(Init->SPACC_TransferMode) == 0U) ||
        (IS_SPACC_KEY_FROM(Init->SPACC_KeyFrom) == 0U) ||
        (IS_SPACC_APP_COPY(Init->SPACC_AADCopy) == 0U) ||
        (IS_SPACC_ICV_COMPUTER(Init->SPACC_ICVCompute) == 0U) ||
        (IS_SPACC_ICV_ENCRYPT(Init->SPACC_ICVEncrypt) == 0U) ||
        (IS_SPACC_ICV_LOCATION(Init->SPACC_ICVLocation) == 0U) ||
        (IS_SPACC_KEY_EXPAND(Init->SPACC_KeyExpand) == 0U) ||
        (IS_SPACC_MSG_BEGIN(Init->SPACC_MessageBegin) == 0U) ||
        (IS_SPACC_MSG_END(Init->SPACC_MessageEnd) == 0U) ||
        (Init->Size != sizeof(SPACC_InitTypeDef)) ||
        (Init->Version != SPACC_INIT_VERSION) ||
        (Init->Reserved[0] != 0U) ||
        (Init->Reserved[1] != 0U))
    {
        hspacc->ErrorCode |= HAL_SPACC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Allocate the lock resource before its first use, so that a handle that
     * was never initialized cannot report HAL_BUSY from a stale Lock field.
     * LOCK-06 / MSP-04: the low level initialization runs before the handle is
     * locked, so that an override which calls other HAL APIs cannot deadlock. */
    if (hspacc->State == HAL_SPACC_STATE_RESET)
    {
        hspacc->Lock = HAL_UNLOCKED;

        /* Init the low level hardware: clock, interrupt */
        HAL_SPACC_MspInit(hspacc);
    }

    /* Process locked */
    if (SPACC_LockHandle(hspacc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and change the SPACC peripheral state */
    hspacc->ErrorCode = HAL_SPACC_ERROR_NONE;
    hspacc->State = HAL_SPACC_STATE_BUSY;

    /* Set SPACC software ID */
    CLEAR_BIT(hspacc->Instance->SW_CTRL, (uint32)SPACC_SW_CTRL_SW_ID);
    SET_BIT(hspacc->Instance->SW_CTRL, (uint32)(Init->SPACC_SoftwareID) << SPACC_SW_CTRL_SW_ID_Pos);

    /* Set SPACC priority command FIFO */
    CLEAR_BIT(hspacc->Instance->SW_CTRL, (uint32)SPACC_SW_CTRL_PRIORITY);
    SET_BIT(hspacc->Instance->SW_CTRL,
            (uint32)(Init->SPACC_PriorityCommandFIFO) << SPACC_SW_CTRL_PRIORITY_Pos);

    /* Set SPACC key size */
    CLEAR_BIT(hspacc->Instance->KEY_SZ, (uint32)SPACC_KEY_SZ_SIZE);
    SET_BIT(hspacc->Instance->KEY_SZ, (uint32)(Init->SPACC_KeySize) << SPACC_KEY_SZ_SIZE_Pos);

    /* Set SPACC key index */
    CLEAR_BIT(hspacc->Instance->KEY_SZ, (uint32)SPACC_KEY_SZ_CTX_IDX);
    SET_BIT(hspacc->Instance->KEY_SZ, (uint32)(Init->SPACC_KeyIndex) << SPACC_KEY_SZ_CTX_IDX_Pos);

    /* Set SPACC key type */
    CLEAR_BIT(hspacc->Instance->KEY_SZ, (uint32)SPACC_KEY_SZ_CIPHER);
    SET_BIT(hspacc->Instance->KEY_SZ, (uint32)(Init->SPACC_KeyType) << SPACC_KEY_SZ_CIPHER_Pos);

    /* Update the CTRL register (read-modify-write on a local copy) */
    temp = hspacc->Instance->CTRL;

    /* Set SPACC cipher algorithm */
    CLEAR_BIT(temp, (uint32)SPACC_CTRL_SM4_CIPH_ALG);
    SET_BIT(temp, (uint32)(Init->SPACC_CipherAlgorithm) << SPACC_CTRL_SM4_CIPH_ALG_Pos);

    /* Set SPACC SM4 cipher mode */
    CLEAR_BIT(temp, (uint32)SPACC_CTRL_SM4_CIPH_MODE);
    SET_BIT(temp, (uint32)(Init->SPACC_SM4CipherMode) << SPACC_CTRL_SM4_CIPH_MODE_Pos);

    /* Set SPACC hash algorithm */
    CLEAR_BIT(temp, (uint32)SPACC_CTRL_SM_HASH_ALG);
    SET_BIT(temp, (uint32)(Init->SPACC_HashAlgorithm) << SPACC_CTRL_SM_HASH_ALG_Pos);

    /* Set SPACC SM3 hash mode */
    CLEAR_BIT(temp, (uint32)SPACC_CTRL_SM3_HASH_MODE);
    SET_BIT(temp, (uint32)(Init->SPACC_SM3HashMode) << SPACC_CTRL_SM3_HASH_MODE_Pos);

    /* Set SPACC transfer mode */
    CLEAR_BIT(temp, (uint32)SPACC_CTRL_ENCRYPT);
    SET_BIT(temp, (uint32)(Init->SPACC_TransferMode) << SPACC_CTRL_ENCRYPT_Pos);

    /* Set SPACC context index */
    CLEAR_BIT(temp, (uint32)SPACC_CTRL_CTX_IDX);
    SET_BIT(temp, (uint32)(Init->SPACC_ContextIndex) << SPACC_CTRL_CTX_IDX_Pos);

    /* Set SPACC key from */
    CLEAR_BIT(temp, (uint32)SPACC_CTRL_SEC_KEY);
    SET_BIT(temp, (uint32)(Init->SPACC_KeyFrom) << SPACC_CTRL_SEC_KEY_Pos);

    /* Set SPACC AAD copy */
    CLEAR_BIT(temp, (uint32)SPACC_CTRL_AAD_COPY);
    SET_BIT(temp, (uint32)(Init->SPACC_AADCopy) << SPACC_CTRL_AAD_COPY_Pos);

    /* Set SPACC ICV compute */
    CLEAR_BIT(temp, (uint32)SPACC_CTRL_ICV_PT);
    SET_BIT(temp, (uint32)(Init->SPACC_ICVCompute) << SPACC_CTRL_ICV_PT_Pos);

    /* Set SPACC ICV encrypt */
    CLEAR_BIT(temp, (uint32)SPACC_CTRL_ICV_ENC);
    SET_BIT(temp, (uint32)(Init->SPACC_ICVEncrypt) << SPACC_CTRL_ICV_ENC_Pos);

    /* Set SPACC ICV location */
    CLEAR_BIT(temp, (uint32)SPACC_CTRL_ICV_APPEND);
    SET_BIT(temp, (uint32)(Init->SPACC_ICVLocation) << SPACC_CTRL_ICV_APPEND_Pos);

    /* Set SPACC key expand */
    CLEAR_BIT(temp, (uint32)SPACC_CTRL_KEY_EXP);
    SET_BIT(temp, (uint32)(Init->SPACC_KeyExpand) << SPACC_CTRL_KEY_EXP_Pos);

    /* Set SPACC message begin */
    CLEAR_BIT(temp, (uint32)SPACC_CTRL_MSG_BEGIN);
    SET_BIT(temp, (uint32)(Init->SPACC_MessageBegin) << SPACC_CTRL_MSG_BEGIN_Pos);

    /* Set SPACC message end */
    CLEAR_BIT(temp, (uint32)SPACC_CTRL_MSG_END);
    SET_BIT(temp, (uint32)(Init->SPACC_MessageEnd) << SPACC_CTRL_MSG_END_Pos);

    /* Write back the CTRL register */
    hspacc->Instance->CTRL = temp;

    /* Store the applied configuration in the handle */
    hspacc->Init = *Init;

    /* Initialize the SPACC state */
    hspacc->State = HAL_SPACC_STATE_READY;

    /* Release Lock */
    SPACC_UnlockHandle(hspacc);

    return HAL_OK;
}

/**
 * @brief  De-initializes the SPACC peripheral. (NON-BLOCKING)
 * @note   The SPACC has no dedicated clock enable/disable in the driver
 *         (the DSE clock is gated at the SMU level). The de-initialization
 *         disables the interrupts (IRQ_EN) and resets the SW_CTRL / KEY_SZ
 *         / CTRL registers to zero. The interrupt status flags (IRQ_STAT)
 *         are not cleared here: as in the device-layer driver they are cleared by the
 *         corresponding FIFO/service operation (no write-to-clear register
 *         is exposed by the hardware).
 * @param  hspacc: pointer to a HAL_SPACC_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_SPACC_DeInit(HAL_SPACC_HandleTypeDef *hspacc)
{
    /* Check the SPACC handle allocation */
    if (SPACC_HandleIsValid(hspacc) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_SPACC_ALL_INSTANCE(hspacc->Instance));

    /* Process locked */
    if (SPACC_LockHandle(hspacc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Disable the SPACC interrupts */
    __HAL_SPACC_DISABLE_IT(hspacc, SPACC_IT_CMDO | SPACC_IT_CMD1 | SPACC_IT_CMD2 |
                                    SPACC_IT_STAT | SPACC_IT_RC4_DMA |
                                    SPACC_IT_STAT_WD | SPACC_IT_GLBL);

    /* Reset the software control register */
    WRITE_REG(hspacc->Instance->SW_CTRL, 0x00U);

    /* Reset the key size register */
    WRITE_REG(hspacc->Instance->KEY_SZ, 0x00U);

    /* Reset the control register */
    WRITE_REG(hspacc->Instance->CTRL, 0x00U);

    /* Set SPACC error code to none and reset the state */
    hspacc->ErrorCode = HAL_SPACC_ERROR_NONE;
    hspacc->State = HAL_SPACC_STATE_RESET;

    /* Release Lock */
    SPACC_UnlockHandle(hspacc);

    /* LOCK-06 / ARCH-CONST-04: the low level de-initialization runs OUTSIDE the
     * locked region, as the architecture specification requires for the MSP
     * callbacks ("MspDeInit is called after the unlock") */
    HAL_SPACC_MspDeInit(hspacc);

    return HAL_OK;
}

/**
 * @brief  Initializes the SPACC MSP. (NON-BLOCKING)
 * @note   The SPACC peripheral is clocked by the AXILite4-Bus1 (DSE)
 *         domain, gated by the SMU: the user must enable the DSE clock
 *         here (DSE_CLK_ENABLE() and DSE_RESET() macros of
 *         as32x601_smu.h). The SPACC also has a dedicated PLIC interrupt
 *         line (SPACC_IRQn = 0x0E): the user must enable it here and
 *         implement SPACC_IRQ_Handler() calling HAL_SPACC_IRQHandler().
 * @param  hspacc: pointer to a HAL_SPACC_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_SPACC_MspInit(HAL_SPACC_HandleTypeDef *hspacc)
{
    /* Prevent unused argument(s) compilation warning */
    (void)hspacc;

    /* NOTE : This function should not be modified. When the callback is needed,
              function HAL_SPACC_MspInit must be implemented in the user file.
     */
}

/**
 * @brief  De-initializes the SPACC MSP. (NON-BLOCKING)
 * @param  hspacc: pointer to a HAL_SPACC_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_SPACC_MspDeInit(HAL_SPACC_HandleTypeDef *hspacc)
{
    /* Prevent unused argument(s) compilation warning */
    (void)hspacc;

    /* NOTE : This function should not be modified. When the callback is needed,
              function HAL_SPACC_MspDeInit must be implemented in the user file.
     */
}

/**
  * @}
  */

/** @addtogroup SPACC_Exported_Functions_Group2 IO operation functions
  * @{
  */

/**
 * @brief  Configures the SPACC packet descriptor registers. (NON-BLOCKING)
 * @note   The SPACC processes a packet described by a data structure in
 *         system memory. This function applies the SPACC_PacketTypeDef
 *         structure to the SRC_PTR / DST_PTR / OFFSET / PRE_AAD_LEN /
 *         POST_AAD_LEN / PROC_LEN / ICV_LEN / ICV_OFFSET / IV_OFFSET
 *         registers. It must be called before the command is submitted
 *         (see the example sequence).
 * @param  hspacc: pointer to a HAL_SPACC_HandleTypeDef structure.
 * @param  Packet: pointer to a SPACC_PacketTypeDef structure that contains
 *         the packet descriptor.
 * @retval None
 */
void HAL_SPACC_PacketInit(HAL_SPACC_HandleTypeDef *hspacc, const SPACC_PacketTypeDef *Packet)
{
    /* Check the SPACC handle allocation */
    if (SPACC_HandleIsValid(hspacc) == 0U)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_SPACC_ALL_INSTANCE(hspacc->Instance));
    assert_param(Packet != NULL_PTR);

    /* Check the packet descriptor */
    /* Run time validation, so that the checks stay effective in a build
     * with the assertions disabled. */
    if (Packet == NULL_PTR)
    {
        hspacc->ErrorCode |= HAL_SPACC_ERROR_INVALID_PARAM;
        return;
    }

    /* Process locked */
    if (SPACC_LockHandle(hspacc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    /* Pointer to source packet data structure in system memory */
    CLEAR_BIT(hspacc->Instance->SRC_PTR, (uint32)SPACC_SRC_PTR_PTR);
    SET_BIT(hspacc->Instance->SRC_PTR, (uint32)(Packet->SPACC_SourcePtr));

    /* Pointer to destination packet data structure in system memory */
    CLEAR_BIT(hspacc->Instance->DST_PTR, (uint32)SPACC_DST_PTR_PTR);
    SET_BIT(hspacc->Instance->DST_PTR, (uint32)(Packet->SPACC_DestinationPtr));

    /* Source buffer offset */
    CLEAR_BIT(hspacc->Instance->OFFSET, (uint32)SPACC_OFFSET_SRC);
    SET_BIT(hspacc->Instance->OFFSET,
            (uint32)(Packet->SPACC_SouPREAADOffset) << SPACC_OFFSET_SRC_Pos);

    /* Destination buffer offset */
    CLEAR_BIT(hspacc->Instance->OFFSET, (uint32)SPACC_OFFSET_DST);
    SET_BIT(hspacc->Instance->OFFSET,
            (uint32)(Packet->SPACC_DestPREAADOffset) << SPACC_OFFSET_DST_Pos);

    /* Byte length of the prefixed AAD */
    CLEAR_BIT(hspacc->Instance->PRE_AAD_LEN, (uint32)SPACC_PRE_AAD_LEN_LEN);
    SET_BIT(hspacc->Instance->PRE_AAD_LEN,
            (uint32)(Packet->SPACC_PREAADLen) << SPACC_PRE_AAD_LEN_LEN_Pos);

    /* Byte length of the postfix AAD */
    CLEAR_BIT(hspacc->Instance->POST_AAD_LEN, (uint32)SPACC_POST_AAD_LEN_LEN);
    SET_BIT(hspacc->Instance->POST_AAD_LEN,
            (uint32)(Packet->SPACC_POSTAADLen) << SPACC_POST_AAD_LEN_LEN_Pos);

    /* Total packet byte length for processing, including PRE_AAD_LEN and payload */
    CLEAR_BIT(hspacc->Instance->PROC_LEN, (uint32)SPACC_PROC_LEN_LEN);
    SET_BIT(hspacc->Instance->PROC_LEN, (uint32)(Packet->SPACC_PROCLen) << SPACC_PROC_LEN_LEN_Pos);

    /* Byte length of the ICV */
    CLEAR_BIT(hspacc->Instance->ICV_LEN, (uint32)SPACC_ICV_LEN_LEN);
    SET_BIT(hspacc->Instance->ICV_LEN, (uint32)(Packet->SPACC_ICVLen) << SPACC_ICV_LEN_LEN_Pos);

    /* Byte offset in packet data structure to start of ICV */
    CLEAR_BIT(hspacc->Instance->ICV_OFFSET, (uint32)SPACC_ICV_OFFSET_OFFSET);
    SET_BIT(hspacc->Instance->ICV_OFFSET,
            (uint32)(Packet->SPACC_ICVOffset) << SPACC_ICV_OFFSET_OFFSET_Pos);

    /* Byte offset in source buffer to obtain the IV value */
    CLEAR_BIT(hspacc->Instance->IV_OFFSET, (uint32)SPACC_IV_OFFSET_OFFSET);
    SET_BIT(hspacc->Instance->IV_OFFSET,
            (uint32)(Packet->SPACC_IVOffset) << SPACC_IV_OFFSET_OFFSET_Pos);

    /* Controls the location of the IV value */
    CLEAR_BIT(hspacc->Instance->IV_OFFSET, (uint32)SPACC_IV_OFFSET_ENABLE);
    SET_BIT(hspacc->Instance->IV_OFFSET,
            (uint32)(Packet->SPACC_IVLocation) << SPACC_IV_OFFSET_ENABLE_Pos);

    /* Release Lock */
    SPACC_UnlockHandle(hspacc);
}

/**
 * @brief  Enables or disables the selected SPACC interrupt. (NON-BLOCKING)
 * @param  hspacc: pointer to a HAL_SPACC_HandleTypeDef structure.
 * @param  ITType: SPACC interrupt type. This parameter can be one of the
 *         following values (SPACC_IT_*):
 *           @arg SPACC_IT_CMDO
 *           @arg SPACC_IT_CMD1
 *           @arg SPACC_IT_CMD2
 *           @arg SPACC_IT_STAT
 *           @arg SPACC_IT_RC4_DMA
 *           @arg SPACC_IT_STAT_WD
 *           @arg SPACC_IT_GLBL
 * @param  NewState: ENABLE or DISABLE.
 * @retval None
 */
void HAL_SPACC_ITConfig(HAL_SPACC_HandleTypeDef *hspacc, uint32 ITType, FunctionalState NewState)
{
    /* Check the SPACC handle allocation */
    if (SPACC_HandleIsValid(hspacc) == 0U)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_SPACC_ALL_INSTANCE(hspacc->Instance));
    assert_param(IS_SPACC_IT(ITType));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Run time parameter validation, so that the checks stay effective in a
     * build with the assertions disabled. A rejected call neither takes the
     * lock nor changes the handle state nor touches a register. */
    if ((IS_SPACC_IT(ITType) == 0U) || (IS_FUNCTIONAL_STATE(NewState) == 0U))
    {
        hspacc->ErrorCode |= HAL_SPACC_ERROR_INVALID_PARAM;
        return;
    }

    /* ARCH-CONST-09: state gate. A busy handle (an operation is ongoing in
     * another context) is rejected with HAL_BUSY, an uninitialized handle with
     * HAL_ERROR, while the recoverable state ERROR accepts the operation. */
    if (SPACC_CheckState(hspacc) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (SPACC_LockHandle(hspacc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    /* Configure the SPACC interrupt */
    if (NewState != DISABLE)
    {
        __HAL_SPACC_ENABLE_IT(hspacc, ITType);
    }
    else
    {
        __HAL_SPACC_DISABLE_IT(hspacc, ITType);
    }

    /* Release Lock */
    SPACC_UnlockHandle(hspacc);
}

/**
 * @brief  Gets the SPACC interrupt status. (NON-BLOCKING)
 * @param  hspacc: pointer to a HAL_SPACC_HandleTypeDef structure.
 * @param  IT: SPACC interrupt state. This parameter can be one of the
 *         following values (SPACC_IT_STATE_*):
 *           @arg SPACC_IT_STATE_CMDO
 *           @arg SPACC_IT_STATE_CMD1
 *           @arg SPACC_IT_STATE_CMD2
 *           @arg SPACC_IT_STATE_STAT
 *           @arg SPACC_IT_STATE_RC4_DMA
 *           @arg SPACC_IT_STATE_STAT_WD
 * @retval FlagStatus: SET or RESET.
 */
FlagStatus HAL_SPACC_GetITStatus(HAL_SPACC_HandleTypeDef *hspacc, uint32 IT)
{
    /* Check the SPACC handle allocation */
    if (SPACC_HandleIsValid(hspacc) == 0U)
    {
        return RESET;
    }

    /* Check the parameters */
    assert_param(IS_SPACC_ALL_INSTANCE(hspacc->Instance));
    assert_param(IS_SPACC_IT_STATE(IT));

    /* Return the IRQ_STAT status of the selected event */
    return (FlagStatus)(READ_BIT(hspacc->Instance->IRQ_STAT, IT) != 0U);
}

/**
 * @brief  Gets the result of the command execution (ejects the status FIFO). (NON-BLOCKING)
 * @note   Writes a 1 to STAT_POP.POP to eject the current STATUS register
 *         entry, then matches the software ID. Returns SET if the ejected
 *         software ID matches the requested SoftwareID.
 * @param  hspacc: pointer to a HAL_SPACC_HandleTypeDef structure.
 * @param  SoftwareID: Software ID of the command to match.
 * @retval FlagStatus: SET or RESET.
 */
FlagStatus HAL_SPACC_CommandExecResult(HAL_SPACC_HandleTypeDef *hspacc, uint32 SoftwareID)
{
    uint32 temp = 0U;

    /* Check the SPACC handle allocation */
    if (SPACC_HandleIsValid(hspacc) == 0U)
    {
        return RESET;
    }

    /* Check the parameters */
    assert_param(IS_SPACC_ALL_INSTANCE(hspacc->Instance));

    /* Process locked (the STAT_POP write is a command-FIFO side effect) */
    if (SPACC_LockHandle(hspacc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return RESET;
    }

    /* The STATUS status is ejected by writing the STAT_POP register */
    WRITE_REG(hspacc->Instance->STAT_POP, 0x01U);

    temp = (READ_REG(hspacc->Instance->STATUS) & SPACC_STATUS_SW_ID) >> SPACC_STATUS_SW_ID_Pos;

    /* Release Lock */
    SPACC_UnlockHandle(hspacc);

    /* Return SET if the ejected software ID matches */
    if (temp == SoftwareID)
    {
        return SET;
    }
    /* Return RESET otherwise */
    return RESET;
}

/**
 * @brief  Gets the state of the SPACC state FIFO. (NON-BLOCKING)
 * @note   Returns the FIFO_STAT.STAT_EMPTY flag: SET means the status FIFO
 *         is empty (no result available), RESET means a command result is
 *         pending to be read (see the example polling loop).
 * @param  hspacc: pointer to a HAL_SPACC_HandleTypeDef structure.
 * @retval FlagStatus: SET or RESET.
 */
FlagStatus HAL_SPACC_StateFIFOFlag(HAL_SPACC_HandleTypeDef *hspacc)
{
    /* Check the SPACC handle allocation */
    if (SPACC_HandleIsValid(hspacc) == 0U)
    {
        return SET;
    }

    /* Check the parameters */
    assert_param(IS_SPACC_ALL_INSTANCE(hspacc->Instance));

    /* Return the state FIFO empty flag */
    return (FlagStatus)((READ_REG(hspacc->Instance->FIFO_STAT) &
                         SPACC_FIFO_STAT_STAT_EMPTY) >> SPACC_FIFO_STAT_STAT_EMPTY_Pos);
}

/**
 * @brief  Reads the SPACC status register value. (NON-BLOCKING)
 * @note   Returns the raw STATUS register value of the current (last
 *         ejected) result entry.
 * @param  hspacc: pointer to a HAL_SPACC_HandleTypeDef structure.
 * @retval raw STATUS register value.
 */
uint32 HAL_SPACC_ReadStatus(HAL_SPACC_HandleTypeDef *hspacc)
{
    /* Check the SPACC handle allocation */
    if (SPACC_HandleIsValid(hspacc) == 0U)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_SPACC_ALL_INSTANCE(hspacc->Instance));

    /* Return the STATUS register */
    return READ_REG(hspacc->Instance->STATUS);
}

/**
 * @brief  Writes data to the SPACC context memory area. (NON-BLOCKING)
 * @note   The context memory areas (cipher context at SPACC_BASE + 0x4000,
 *         hash context at SPACC_BASE + 0x8000) hold the key / IV /
 *         auxiliary material used by the SPACC. This function writes a
 *         buffer of Length 32-bit words at the given byte Offset relative
 *         to the selected context base. The example loads the cipher
 *         context with set_32bit_addr(DSE_SPACC_BASE, 0x4000 + cnt*4, ...).
 * @param  hspacc: pointer to a HAL_SPACC_HandleTypeDef structure.
 * @param  Base: context base address (SPACC_CIPHER_CONTEXT_BASE or
 *               SPACC_HASH_CONTEXT_BASE).
 * @param  Offset: byte offset from the context base.
 * @param  Data: pointer to the buffer to write.
 * @param  Length: number of 32-bit words to write.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_SPACC_WriteContext(HAL_SPACC_HandleTypeDef *hspacc, uint32 Base,
                                         uint32 Offset, uint32 *Data, uint32 Length)
{
    volatile uint32 *ctxaddr = (volatile uint32 *)NULL_PTR;
    uint32 idx = 0U;

    /* Check the SPACC handle allocation */
    if (SPACC_HandleIsValid(hspacc) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_SPACC_ALL_INSTANCE(hspacc->Instance));
    assert_param(IS_SPACC_CONTEXT_BASE(Base));
    assert_param(Data != NULL_PTR);

    /* Check the input buffers */
    /* Run time validation, so that the checks stay effective in a build
     * with the assertions disabled. */
    if ((Data == NULL_PTR) || (Length == 0U) || (IS_SPACC_CONTEXT_BASE(Base) == 0U))
    {
        hspacc->ErrorCode |= HAL_SPACC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Process locked */
    if (SPACC_LockHandle(hspacc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Compute the context base address (fixes the legacy pointer-arithmetic
       bug in SPACC_HASH_CONTEXT_BASE / SPACC_CIPHER_CONTEXT_BASE) */
    ctxaddr = (volatile uint32 *)(Base + Offset);

    for (idx = 0U; idx < Length; idx++)
    {
        ctxaddr[idx] = Data[idx];
    }

    /* Release Lock */
    SPACC_UnlockHandle(hspacc);

    return HAL_OK;
}

/**
 * @brief  Reads data from the SPACC context memory area. (NON-BLOCKING)
 * @note   Opposite of HAL_SPACC_WriteContext(): reads Length 32-bit words
 *         at the given byte Offset relative to the selected context base.
 * @param  hspacc: pointer to a HAL_SPACC_HandleTypeDef structure.
 * @param  Base: context base address (SPACC_CIPHER_CONTEXT_BASE or
 *               SPACC_HASH_CONTEXT_BASE).
 * @param  Offset: byte offset from the context base.
 * @param  Data: pointer to the buffer to store the read data.
 * @param  Length: number of 32-bit words to read.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_SPACC_ReadContext(HAL_SPACC_HandleTypeDef *hspacc, uint32 Base,
                                        uint32 Offset, uint32 *Data, uint32 Length)
{
    volatile uint32 *ctxaddr = (volatile uint32 *)NULL_PTR;
    uint32 idx = 0U;

    /* Check the SPACC handle allocation */
    if (SPACC_HandleIsValid(hspacc) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_SPACC_ALL_INSTANCE(hspacc->Instance));
    assert_param(IS_SPACC_CONTEXT_BASE(Base));
    assert_param(Data != NULL_PTR);

    /* Check the input buffers */
    /* Run time validation, so that the checks stay effective in a build
     * with the assertions disabled. */
    if ((Data == NULL_PTR) || (Length == 0U) || (IS_SPACC_CONTEXT_BASE(Base) == 0U))
    {
        hspacc->ErrorCode |= HAL_SPACC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Process locked */
    if (SPACC_LockHandle(hspacc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Compute the context base address */
    ctxaddr = (volatile uint32 *)(Base + Offset);

    for (idx = 0U; idx < Length; idx++)
    {
        Data[idx] = ctxaddr[idx];
    }

    /* Release Lock */
    SPACC_UnlockHandle(hspacc);

    return HAL_OK;
}

/**
 * @brief  Handles the SPACC interrupt request. (NON-BLOCKING)
 * @note   The SPACC IRQ_STAT register carries the command FIFO priority 0/1/2,
 *         status FIFO, RC4 context DMA and status watchdog interrupt status
 *         bits. The STAT_WD bit is reported through HAL_SPACC_ErrorCallback().
 *         The user must implement SPACC_IRQ_Handler() to dispatch to this
 *         handler.
 * @param  hspacc: pointer to a HAL_SPACC_HandleTypeDef structure.
 * @retval None
 */
void HAL_SPACC_IRQHandler(HAL_SPACC_HandleTypeDef *hspacc)
{
    /* Check the SPACC handle allocation */
    if (SPACC_HandleIsValid(hspacc) == 0U)
    {
        return;
    }

    /* SPACC status watchdog interrupt occurred */
    if (__HAL_SPACC_GET_IT(hspacc, SPACC_IT_STATE_STAT_WD) != RESET)
    {
        /* Change SPACC peripheral state */
        hspacc->State = HAL_SPACC_STATE_ERROR;

        HAL_SPACC_ErrorCallback(hspacc);
    }

    /* SPACC status FIFO interrupt (command result pending) */
    if (__HAL_SPACC_GET_IT(hspacc, SPACC_IT_STATE_STAT) != RESET)
    {
        /* Change SPACC peripheral state */
        if (hspacc->State != HAL_SPACC_STATE_ERROR)
        {
            hspacc->State = HAL_SPACC_STATE_READY;
        }
    }
}

/**
 * @brief  SPACC error callback. (NON-BLOCKING)
 * @param  hspacc: pointer to a HAL_SPACC_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_SPACC_ErrorCallback(HAL_SPACC_HandleTypeDef *hspacc)
{
    /* Prevent unused argument(s) compilation warning */
    (void)hspacc;

    /* NOTE : This function should not be modified. When the callback is needed,
              function HAL_SPACC_ErrorCallback must be implemented in the user file.
     */
}

/**
  * @}
  */

/** @addtogroup SPACC_Exported_Functions_Group3 Peripheral State functions
  * @{
  */

/**
 * @brief  Returns the SPACC state. (NON-BLOCKING)
 * @param  hspacc: pointer to a HAL_SPACC_HandleTypeDef structure.
 * @retval HAL_SPACC_StateTypeDef: SPACC state.
 */
HAL_SPACC_StateTypeDef HAL_SPACC_GetState(HAL_SPACC_HandleTypeDef *hspacc)
{
    /* Check the SPACC handle allocation */
    if (SPACC_HandleIsValid(hspacc) == 0U)
    {
        return HAL_SPACC_STATE_RESET;
    }

    /* Return the SPACC state */
    return hspacc->State;
}

/**
 * @brief  Returns the SPACC error code. (NON-BLOCKING)
 * @param  hspacc: pointer to a HAL_SPACC_HandleTypeDef structure.
 * @retval uint32: the SPACC error code (HAL_SPACC_ERROR_xxx).
 */
uint32 HAL_SPACC_GetError(HAL_SPACC_HandleTypeDef *hspacc)
{
    /* Check the SPACC handle allocation */
    if (SPACC_HandleIsValid(hspacc) == 0U)
    {
        return HAL_SPACC_ERROR_NONE;
    }

    /* Return the SPACC error code */
    return hspacc->ErrorCode;
}

/**
  * @}
  */

#endif /* HAL_SPACC_MODULE_ENABLED */

/*****END OF FILE*****/
