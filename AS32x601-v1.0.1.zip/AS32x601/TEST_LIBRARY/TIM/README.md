# TIM 应用与测试参考

供 skill 按需求检索 AS32x601 HAL 定时器（TIM）示例。别名/关键词：TIM、定时器、计数器、时基、PWM、输入捕获、输出比较、单脉冲、编码器、死区、刹车、主从触发、TRGO、ITR、DMA burst。共有 36 个独立用例。

HAL 依据：[头文件](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_tim.h)、[实现](../../HAL_LIBRARY/peripherals/src/as32x601_hal_tim.c)。原测试工程的 4_HAL_LIBRARY 未提供，尚不能确认原始链接版本；文中标出的源码与当前 SDK 差异须先解决再迁移。


## 实例与可选引脚

下表列出 AS32x601 LQFP144 封装的本外设信号。每根信号单独选择引脚，并核对 [GPIO AF 定义](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_gpio.h)；文档功能编号不能直接当作 HAL 编码传入。其他封装需另查引出情况。

| 信号 | 可选引脚 | 封装脚号 | 文档功能 | HAL AF |
|---|---|---|---|---|
| `HTIM0_CH0` | PB11 | 129 | 功能2 | `GPIO_AF_HTIM0_M2`（0x03） |
| `HTIM0_CH0N` | PD9 | 60 | 功能2 | `GPIO_AF_HTIM0_M2`（0x03） |
| `HTIM0_CH0N` | PA5 | 105 | 功能1 | `GPIO_AF_HTIM0_M1`（0x02） |
| `HTIM0_CH1` | PB12 | 101 | 功能2 | `GPIO_AF_HTIM0_M2`（0x03） |
| `HTIM0_CH1` | PA0 | 119 | 功能1 | `GPIO_AF_HTIM0_M1`（0x02） |
| `HTIM0_CH1N` | PD10 | 59 | 功能2 | `GPIO_AF_HTIM0_M2`（0x03） |
| `HTIM0_CH1N` | PA6 | 103 | 功能1 | `GPIO_AF_HTIM0_M1`（0x02） |
| `HTIM0_CH2` | PB13 | 110 | 功能2 | `GPIO_AF_HTIM0_M2`（0x03） |
| `HTIM0_CH2` | PA1 | 117 | 功能1 | `GPIO_AF_HTIM0_M1`（0x02） |
| `HTIM0_CH2N` | PD11 | 58 | 功能2 | `GPIO_AF_HTIM0_M2`（0x03） |
| `HTIM0_CH3` | PA2 | 115 | 功能1 | `GPIO_AF_HTIM0_M1`（0x02） |
| `HTIM0_CH3` | PB14 | 126 | 功能2 | `GPIO_AF_HTIM0_M2`（0x03） |
| `HTIM0_CH3N` | PD12 | 57 | 功能2 | `GPIO_AF_HTIM0_M2`（0x03） |
| `HTIM0_CH3N` | PC4 | 118 | 功能1 | `GPIO_AF_HTIM0_M1`（0x02） |
| `HTIM0_CH4` | PB15 | 62 | 功能2 | `GPIO_AF_HTIM0_M2`（0x03） |
| `HTIM0_CH4` | PA3 | 112 | 功能1 | `GPIO_AF_HTIM0_M1`（0x02） |
| `HTIM0_CH4N` | PD13 | 56 | 功能2 | `GPIO_AF_HTIM0_M2`（0x03） |
| `HTIM0_CH4N` | PC5 | 116 | 功能1 | `GPIO_AF_HTIM0_M1`（0x02） |
| `HTIM0_CH5` | PD8 | 61 | 功能2 | `GPIO_AF_HTIM0_M2`（0x03） |
| `HTIM0_CH5` | PA4 | 109 | 功能1 | `GPIO_AF_HTIM0_M1`（0x02） |
| `HTIM0_CH5N` | PD14 | 55 | 功能2 | `GPIO_AF_HTIM0_M2`（0x03） |
| `HTIM0_CH5N` | PB0 | 114 | 功能1 | `GPIO_AF_HTIM0_M1`（0x02） |
| `HTIM1_CH0` | PD4 | 23 | 功能1 | `GPIO_AF_HTIM1`（0x02） |
| `HTIM1_CH0N` | PG11 | 17 | 功能1 | `GPIO_AF_HTIM1`（0x02） |
| `HTIM1_CH1` | PD5 | 22 | 功能1 | `GPIO_AF_HTIM1`（0x02） |
| `HTIM1_CH1N` | PG12 | 16 | 功能1 | `GPIO_AF_HTIM1`（0x02） |
| `HTIM1_CH2` | PD6 | 21 | 功能1 | `GPIO_AF_HTIM1`（0x02） |
| `HTIM1_CH2N` | PG13 | 15 | 功能1 | `GPIO_AF_HTIM1`（0x02） |
| `HTIM1_CH3` | PD7 | 20 | 功能1 | `GPIO_AF_HTIM1`（0x02） |
| `HTIM1_CH3N` | PG14 | 14 | 功能1 | `GPIO_AF_HTIM1`（0x02） |
| `HTIM1_CH4` | PG9 | 19 | 功能1 | `GPIO_AF_HTIM1`（0x02） |
| `HTIM1_CH4N` | PG15 | 13 | 功能1 | `GPIO_AF_HTIM1`（0x02） |
| `HTIM1_CH5` | PG10 | 18 | 功能1 | `GPIO_AF_HTIM1`（0x02） |
| `HTIM1_CH5N` | PB3 | 12 | 功能1 | `GPIO_AF_HTIM1`（0x02） |
| `HTIM2_CH0` | PF13 | 2 | 功能2 | `GPIO_AF_HTIM2`（0x03） |
| `HTIM2_CH0N` | PE9 | 130 | 功能2 | `GPIO_AF_HTIM2`（0x03） |
| `HTIM2_CH1` | PF15 | 142 | 功能2 | `GPIO_AF_HTIM2`（0x03） |
| `HTIM2_CH1N` | PE10 | 1 | 功能2 | `GPIO_AF_HTIM2`（0x03） |
| `HTIM2_CH2` | PG0 | 140 | 功能2 | `GPIO_AF_HTIM2`（0x03） |
| `HTIM2_CH2N` | PE11 | 143 | 功能2 | `GPIO_AF_HTIM2`（0x03） |
| `HTIM2_CH3` | PG1 | 138 | 功能2 | `GPIO_AF_HTIM2`（0x03） |
| `HTIM2_CH3N` | PE12 | 141 | 功能2 | `GPIO_AF_HTIM2`（0x03） |
| `HTIM2_CH4` | PE7 | 136 | 功能2 | `GPIO_AF_HTIM2`（0x03） |
| `HTIM2_CH4N` | PE13 | 139 | 功能2 | `GPIO_AF_HTIM2`（0x03） |
| `HTIM2_CH5` | PE8 | 134 | 功能2 | `GPIO_AF_HTIM2`（0x03） |
| `HTIM2_CH5N` | PE14 | 137 | 功能2 | `GPIO_AF_HTIM2`（0x03） |
| `HTIM5_CH0` | PC9 | 41 | 功能2 | `GPIO_AF_HTIM5`（0x03） |
| `HTIM5_CH0` | PF2 | 92 | 功能2 | `GPIO_AF_HTIM5`（0x03） |
| `HTIM5_CH0N` | PA12 | 36 | 功能2 | `GPIO_AF_HTIM5`（0x03） |
| `HTIM5_CH0N` | PF8 | 89 | 功能2 | `GPIO_AF_HTIM5`（0x03） |
| `HTIM5_CH1` | PH9 | 67 | 功能2 | `GPIO_AF_HTIM5`（0x03） |
| `HTIM5_CH1` | PF3 | 94 | 功能2 | `GPIO_AF_HTIM5`（0x03） |
| `HTIM5_CH1N` | PA13 | 35 | 功能2 | `GPIO_AF_HTIM5`（0x03） |
| `HTIM5_CH1N` | PF9 | 91 | 功能2 | `GPIO_AF_HTIM5`（0x03） |
| `HTIM5_CH2` | PA8 | 40 | 功能2 | `GPIO_AF_HTIM5`（0x03） |
| `HTIM5_CH2` | PF4 | 96 | 功能2 | `GPIO_AF_HTIM5`（0x03） |
| `HTIM5_CH2N` | PA14 | 34 | 功能2 | `GPIO_AF_HTIM5`（0x03） |
| `HTIM5_CH2N` | PF10 | 93 | 功能2 | `GPIO_AF_HTIM5`（0x03） |
| `HTIM5_CH3` | PA9 | 39 | 功能2 | `GPIO_AF_HTIM5`（0x03） |
| `HTIM5_CH3` | PF5 | 99 | 功能2 | `GPIO_AF_HTIM5`（0x03） |
| `HTIM5_CH3N` | PA15 | 33 | 功能2 | `GPIO_AF_HTIM5`（0x03） |
| `HTIM5_CH3N` | PC0 | 95 | 功能2 | `GPIO_AF_HTIM5`（0x03） |
| `HTIM5_CH4` | PA10 | 38 | 功能2 | `GPIO_AF_HTIM5`（0x03） |
| `HTIM5_CH4` | PF6 | 84 | 功能2 | `GPIO_AF_HTIM5`（0x03） |
| `HTIM5_CH4N` | PC10 | 32 | 功能2 | `GPIO_AF_HTIM5`（0x03） |
| `HTIM5_CH4N` | PC1 | 97 | 功能2 | `GPIO_AF_HTIM5`（0x03） |
| `HTIM5_CH5` | PA11 | 37 | 功能2 | `GPIO_AF_HTIM5`（0x03） |
| `HTIM5_CH5` | PF7 | 87 | 功能2 | `GPIO_AF_HTIM5`（0x03） |
| `HTIM5_CH5N` | PC11 | 31 | 功能2 | `GPIO_AF_HTIM5`（0x03） |
| `HTIM5_CH5N` | PC2 | 100 | 功能2 | `GPIO_AF_HTIM5`（0x03） |
| `TIM3_CH0` | PF10 | 93 | 功能1 | `GPIO_AF_TIM3`（0x02） |
| `TIM3_CH1` | PC0 | 95 | 功能1 | `GPIO_AF_TIM3`（0x02） |
| `TIM3_CH2` | PC1 | 97 | 功能1 | `GPIO_AF_TIM3`（0x02） |
| `TIM3_CH3` | PC2 | 100 | 功能1 | `GPIO_AF_TIM3`（0x02） |
| `TIM4_CH0` | PC14 | 85 | 功能2 | `GPIO_AF_TIM4`（0x03） |
| `TIM4_CH1` | PC15 | 86 | 功能2 | `GPIO_AF_TIM4`（0x03） |
| `TIM4_CH2` | PF0 | 88 | 功能2 | `GPIO_AF_TIM4`（0x03） |
| `TIM4_CH3` | PF1 | 90 | 功能2 | `GPIO_AF_TIM4`（0x03） |
| `TIM6_CH0` | PE4 | 120 | 功能2 | `GPIO_AF_TIM6_M2`（0x03） |
| `TIM6_CH0` | PE11 | 143 | 功能1 | `GPIO_AF_TIM6_M1`（0x02） |
| `TIM6_CH1` | PE5 | 127 | 功能2 | `GPIO_AF_TIM6_M2`（0x03） |
| `TIM6_CH1` | PE12 | 141 | 功能1 | `GPIO_AF_TIM6_M1`（0x02） |
| `TIM6_CH2` | PE6 | 128 | 功能2 | `GPIO_AF_TIM6_M2`（0x03） |
| `TIM6_CH2` | PE13 | 139 | 功能1 | `GPIO_AF_TIM6_M1`（0x02） |
| `TIM6_CH3` | PC13 | 125 | 功能2 | `GPIO_AF_TIM6_M2`（0x03） |
| `TIM6_CH3` | PE14 | 137 | 功能1 | `GPIO_AF_TIM6_M1`（0x02） |
| `TIM7_CH0` | PG6 | 49 | 功能1 | `GPIO_AF_TIM7`（0x02） |
| `TIM7_CH1` | PG7 | 46 | 功能1 | `GPIO_AF_TIM7`（0x02） |
| `TIM7_CH2` | PG8 | 45 | 功能1 | `GPIO_AF_TIM7`（0x02） |
| `TIM7_CH3` | PC6 | 44 | 功能1 | `GPIO_AF_TIM7`（0x02） |

候选引脚不代表已验证的接线组合。实例、通道与路由约束按当前驱动和手册核对；同一引脚的其他功能须检查资源冲突。案例配置见下文。

## 生成前需确认的参数

已有工程、板级资料或用户已明确的值直接复用。仅对影响本次实现的缺失选择使用参数卡询问并等待答复；案例配置不能代替实际接线或应用参数。

| 参数 | 需要核对或确认的内容 |
|---|---|
| 实例与通道 | 时基、PWM、捕获、编码器等功能对应的定时器及通道 |
| 外部信号 | 本次需要的 CH/CHN、ETR、BKIN 引脚、AF 与极性 |
| 时序与安全状态 | 频率、占空比、分辨率、计数时钟，按需确认死区和刹车行为 |

## 按需求选择

| 用户需求 / 检索关键词 | 推荐用例 | 选择条件 / 需要补充的逻辑 |
|---|---|---|
| 最小时基：向上计数、读计数器 | [001](TIM_IT_DRV_001.c) | TIM0，ARR=100000-1、PSC=90-1；应用只留目标周期并重算 PSC/ARR |
| 向下计数 | [002](TIM_IT_DRV_002.c) | 与 001 只差 `TIM_COUNTERMODE_DOWN`；CR1.DIR=1 |
| 中心对齐计数 | [003](TIM_IT_DRV_003.c) | CMS=01，计数器到 ARR-1 后向下 |
| 更新中断、重复计数器 RCR | [004](TIM_IT_DRV_004.c) | RCR=1 时每两个计数周期一次更新；中断经 `TIM0_IRQn` → `HAL_TIM_IRQHandler()` → `PeriodElapsedCallback()` |
| 外部时钟：TI2 边沿计数 | [005](TIM_IT_DRV_005.c) | PA0 输入 1 kHz 方波；external clock mode 1 |
| 外部时钟：ETR + ADC 模拟监控 | [006](TIM_IT_DRV_006.c) | TIM0 ETR 取自 ADC0 AMO 输出；需要 ADC0 与窗口配置，不只是定时器 |
| ETR 触发/计数 + PWM + ADC | [016](TIM_IT_DRV_016.c) | external clock mode 1；用 ADC0 AMO 上升沿推进计数，同时 CH1 输出 PWM |
| 编码器接口（TI1 计数、TI2 方向） | [007](TIM_IT_DRV_007.c) | PC3=TI1、PA0=TI2；PA0 需拉低，PC3 输入方波。编码器模式下 CEN 回读不可靠 |
| 输出比较：冻结/有效/无效/翻转 6 通道 | [008](TIM_IT_DRV_008.c) | TIM0 六通道；`HAL_TIM_OC_ConfigChannel()` 会清 CCxE，必须再 Start |
| 输入捕获 6 通道 + 捕获中断 | [009](TIM_IT_DRV_009.c) | TIM0 的 PC3、PA0–PA4；需要外部方波。相同通道两次捕获的差值才可比较 |
| TIM1 输入捕获 | [025](TIM_IT_DRV_025.c) | 只覆盖板级已引出的 CH1–CH5 |
| TIM2 输入捕获 | [027](TIM_IT_DRV_027.c) | 只覆盖 CH3、CH6 |
| TIM3 输入捕获 | [029](TIM_IT_DRV_029.c) | 只覆盖 CH1、CH2、CH4 |
| TIM5 输入捕获 | [031](TIM_IT_DRV_031.c) | 只覆盖 CH1、CH2 |
| TIM6 输入捕获 | [033](TIM_IT_DRV_033.c) | 只覆盖 CH1、CH4 |
| TIM7 输入捕获 | [035](TIM_IT_DRV_035.c) | 只覆盖 CH3（PG8） |
| PWM 输入测量（周期/占空比） | [010](TIM_IT_DRV_010.c) | CH1 直接捕获上升沿、CH2 间接捕获下降沿，TI1FP1 复位从模式；PC3 输入 20 kHz |
| PWM 输出 Mode1/Mode2、六通道 | [011](TIM_IT_DRV_011.c) | TIM0 六通道，50 Hz、50% 占空；高级定时器还要 `HAL_TIM_CtrlPWMOutputs()` |
| 非对称 PWM | [012](TIM_IT_DRV_012.c) | 中心对齐 + OCxM=1110；两通道不同脉宽 |
| 组合 PWM | [013](TIM_IT_DRV_013.c) | CH1 组合 PWM1（OCxM=1100）+ CH2 PWM2 |
| 互补输出 + 死区（TIM0） | [014](TIM_IT_DRV_014.c) | 六主六补；DTG=0xF4、CKD=DIV4；死区只能在主/互补对上测 |
| 互补 + 死区（TIM1） | [024](TIM_IT_DRV_024.c) | 板上只引出 CH1–CH5 主输出，互补脚未引出，死区只能寄存器级核对 |
| 互补 + 死区（TIM2） | [026](TIM_IT_DRV_026.c) | 板上有 CH3/PG0–PE11、CH6/PE8–PE14 两对，可实测死区 |
| 互补 + 死区（TIM5） | [030](TIM_IT_DRV_030.c) | 主输出 PC9/PH9 无对应互补脚，死区不能上板实测 |
| 主输出 MOE 软件关断、空闲电平和刹车配置 | [015](TIM_IT_DRV_015.c) | 本例软件清 MOE，不代表已注入外部刹车故障并验证响应 |
| 六步 PWM、预装载 + 换相事件 | [017](TIM_IT_DRV_017.c) | OCPreload + `HAL_TIM_GenerateEvent(TIM_EVENTSOURCE_COM)` |
| 单脉冲模式（外部触发） | [018](TIM_IT_DRV_018.c) | PC3 输出、PA0 上升沿触发；SMS=110 时 CEN 回读不可用，按波形/计数器判断 |
| 三输入 XOR + 复位从模式 | [019](TIM_IT_DRV_019.c) | CR2.TI1S + TI1FP1 复位；示例用 GPIO 翻转模拟三路输入 |
| 门控从模式 | [020](TIM_IT_DRV_020.c) | CH2 作为门控，CH1 输出 PWM；需要 PA0 门控信号 |
| TIM 更新事件触发 ADC | [021](TIM_IT_DRV_021.c) | TRGO/TRGO2=update → ADC0 外部触发 2；无需外部激励 |
| 内部触发级联（TIM1 → TIM0 ITR0） | [022](TIM_IT_DRV_022.c) | TIM1 OC1REF 作 TRGO，TIM0 以 ITR0 为时钟 |
| DMA burst 更新 CCR | [023](TIM_IT_DRV_023.c) | DMA0 通道 0 写 TIM0 DMAR；CCDS + `HAL_TIM_PWM_Start_DMA()` |
| 通用定时器 PWM（TIM3/6/7） | [028](TIM_IT_DRV_028.c)、[032](TIM_IT_DRV_032.c)、[034](TIM_IT_DRV_034.c) | 通用定时器无 BDTR/MOE，不需要 `CtrlPWMOutputs`；只覆盖板级引出通道 |
| 完整 API/状态机/参数校验自检 | [036](TIM_IT_DRV_036.c) | 防御性自检，不是应用模板；覆盖十种结构助手和运行时校验 |
| 定时器 4（TIM4） | 无 | 本目录没有 TIM4 用例，不能据此断言 TIM4 能力 |
| 无外部激励的纯软件定时 | 无直接完整模板 | 001 的时基 + 004 的更新中断即可组合；但示例没有“毫秒节拍/软件定时器”封装 |

## 实现要点与案例配置

- 实例能力：TIM0、TIM1、TIM2、TIM5 具备互补输出/BDTR/刹车（高级定时器）；TIM3、TIM6、TIM7 为通用定时器（4 通道、无 MOE/死区）。TIM0/TIM1 时钟来自 AXILite4 Bus 1（示例 45 MHz）；TIM2/TIM3/TIM4 来自 APBBus0，TIM5/TIM6/TIM7 来自 APBBus1（示例 22.5 MHz）。换目标板先确认实例时钟。
- 时基公式（源码实际使用）：计数频率 = TIMx 时钟 / (PSC+1)，边沿计数溢出周期 = (ARR+1) × (PSC+1) / TIMx 时钟；中心对齐、RCR、外部时钟与从模式需另算。示例 TIM0 用 PSC=89、ARR=99999，45 MHz 下计数步长 2 µs；TIM1/TIM5 等以各自时钟重算。`Prescaler`/`Period` 字段写“原始值减一”后的值（如 PSC 90-1）。
- 初始化顺序：`HAL_Init()` → 系统时钟 → `delay_init()` / 串口 → 定时器时钟门控与复位（在覆写的 `HAL_TIM_xxx_MspInit()` 中）→ `HAL_TIM_Base_StructInit()` 后填时基 → `HAL_TIM_Base_Init()` → 按模式配置通道（OC/PWM/IC/Encoder/OnePulse）→ 需要时配置从模式、主触发、BDTR → 启动（`Base_Start` / `PWM_Start` / `IC_Start_IT` 等）→ 高级定时器再 `HAL_TIM_CtrlPWMOutputs()` 释放 MOE。
- 中断/回调链：PLIC 使能 `TIMx_IRQn` → `TIMx_IRQ_Handler()` → `HAL_TIM_IRQHandler()` → `HAL_TIM_PeriodElapsedCallback()` / `HAL_TIM_OC_DelayElapsedCallback()` / `HAL_TIM_IC_CaptureCallback()`。示例的回调都定义在案例文件内，应用应改为自己的业务处理。
- 引脚（示例，板级已引出）：

| 实例 | 通道 → 引脚 |
|---|---|
| TIM0 | CH1=PC3、CH2=PA0、CH3=PA1、CH4=PA2、CH5=PA3、CH6=PA4；CH3N=PA7、CH5N=PC5 |
| TIM1 | CH1=PD4、CH2=PD5、CH3=PD6、CH4=PD7、CH5=PG9、CH6=PG10；互补 PG11–PG15、PB3（板上未引出） |
| TIM2 | CH3=PG0/CH3N=PE11、CH6=PE8/CH6N=PE14（可实测死区） |
| TIM5 | CH1=PC9、CH2=PH9；CH3N=PA14、CH4N=PA15、CH6N=PC11（无对应主通道） |
| TIM7 | CH3=PG8 |

TIM3/TIM6 的用例只遍历板级引出通道，具体引脚见源码中的通道映射辅助函数；不要套用 TIM0 的引脚表。

- 外部条件：输入捕获、PWM 输入、外部时钟、编码器、门控、单脉冲分别需要外部方波/门控/触发信号；输出比较和 PWM 需要示波器观察电平/占空比/死区。触发 ADC 的 021 与 006/016 的 ADC 部分还需要 PC0 模拟输入。
- 证据边界：寄存器回读（PSC/ARR/CCR/CCER/BDTR/SMCR）和软件 PASS 能证明配置与状态机；真实频率、占空比、死区、相位和从模式行为需要示波器/逻辑分析仪。源码 007、018 记录的 CEN 回读异常是基于板上测量得出的结论，本次未复测。

## 验证方法与适用边界

- 高级定时器输出必须释放主输出：只调用 `HAL_TIM_PWM_Start()` 时，若 `BDTR.MOE` 未置位，引脚不会输出。TIM3/6/7 无 MOE，不要照搬 `HAL_TIM_CtrlPWMOutputs()`。
- `HAL_TIM_OC_ConfigChannel()` / `HAL_TIM_PWM_ConfigChannel()` 会清除该通道的 CCxE；配置后必须再 Start，否则引脚无输出。
- RCR 只对高级定时器有效；RCR=1 表示两个计数周期一次更新，不是“每两次中断”。
- 预装载/影子寄存器：017 需要 OCPreload + 换相事件才把新比较值生效；直接改 CCR 在运行中可能立即或延后生效，取决于 OCxPE。
- 编码器模式（007）和单脉冲模式（018）下，软件写 CEN 可能回读不到；不要用 CEN 回读判断启动，改用计数器/波形。
- 周期测量使用同一通道相邻同类边沿并处理回绕；010 的 PWM 输入配对通道可按配置计算周期/高电平。不能把任意不同通道的瞬时值直接相减，也不能把 009 的周期比较限制泛化到所有捕获模式。
- 死区只能在同一通道的主/互补输出之间测量；TIM1/TIM5 板上互补脚未引出时只能做寄存器验证，不能宣称“死区已上板验证”。
- DMA burst（023）要求先设 DCR.DBA/DBL 并置 CCDS，且该器件每个定时器只有一个 DMA 请求；不要按通用 DMA 双向模型设计。
- 007/018 的 CEN 异常是特定模式的源码历史记录，不泛化为所有从模式或 MOE 写入行为。切换模式按目标实例停通道并重新核对配置。

## 按接口与辅助宏检索

| 接口 / 宏 | 参考用例 |
|---|---|
| `HAL_TIM_Base_StructInit` / `HAL_TIM_Base_Init` | [001](TIM_IT_DRV_001.c)、[036](TIM_IT_DRV_036.c) |
| `HAL_TIM_Base_Start` / `HAL_TIM_Base_Start_IT` | [001](TIM_IT_DRV_001.c)、[004](TIM_IT_DRV_004.c) |
| `HAL_TIM_GetCounter` / `HAL_TIM_SetAutoreload` / `HAL_TIM_SetPrescaler` | [001](TIM_IT_DRV_001.c)、[036](TIM_IT_DRV_036.c) |
| `HAL_TIM_OC_ConfigChannel` / `HAL_TIM_OC_Start` | [008](TIM_IT_DRV_008.c)、[017](TIM_IT_DRV_017.c) |
| `HAL_TIM_PWM_ConfigChannel` / `HAL_TIM_PWM_Start` | [011](TIM_IT_DRV_011.c)、[028](TIM_IT_DRV_028.c) |
| `HAL_TIM_PWM_Start_DMA` / `HAL_TIM_SelectCCDMA` | [023](TIM_IT_DRV_023.c) |
| `HAL_TIM_IC_ConfigChannel` / `HAL_TIM_IC_Start_IT` | [009](TIM_IT_DRV_009.c)、[025](TIM_IT_DRV_025.c) |
| `HAL_TIM_ReadCapturedValue` | [009](TIM_IT_DRV_009.c)、[010](TIM_IT_DRV_010.c) |
| `HAL_TIM_Encoder_Init` / `HAL_TIM_Encoder_Start` | [007](TIM_IT_DRV_007.c) |
| `HAL_TIM_OnePulse_Init` / `HAL_TIM_OnePulse_Start` | [018](TIM_IT_DRV_018.c) |
| `HAL_TIM_ConfigClockSource` | [005](TIM_IT_DRV_005.c)、[006](TIM_IT_DRV_006.c)、[022](TIM_IT_DRV_022.c) |
| `HAL_TIM_SlaveConfigSynchronization` | [010](TIM_IT_DRV_010.c)、[019](TIM_IT_DRV_019.c)、[020](TIM_IT_DRV_020.c) |
| `HAL_TIM_MasterConfigSynchronization` | [021](TIM_IT_DRV_021.c)、[022](TIM_IT_DRV_022.c) |
| `HAL_TIM_ConfigBreakDeadTime` / `HAL_TIM_CtrlPWMOutputs` | [014](TIM_IT_DRV_014.c)、[015](TIM_IT_DRV_015.c)、[024](TIM_IT_DRV_024.c) |
| `HAL_TIM_GenerateEvent` | [017](TIM_IT_DRV_017.c) |
| `HAL_TIM_IRQHandler` / `HAL_TIM_PeriodElapsedCallback` / `HAL_TIM_IC_CaptureCallback` | [004](TIM_IT_DRV_004.c)、[009](TIM_IT_DRV_009.c) |


本次为源码静态整理，未重新编译、未上板；源码里的历史测试注释不代表本次验证结果。
