/**
 * @file    TRNG_IT_DRV_004.c
 * @brief   HAL TRNG integration test case 004 (interrupt generation API (ownership, busy refusal, callback)).
 *
 * HAL library extension case (no reference standard-library counterpart).
 * Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_TRNG_GenerateRandomNumber_IT()
 *   HAL_TRNG_IRQHandler() / HAL_TRNG_ReadyDataCallback()
 *   HAL_TRNG_Init() / HAL_TRNG_DeInit()   (busy refusal)
 *   HAL_TRNG_GetState() / HAL_TRNG_ReadLastRandomNumber()
 *   HAL_PLIC_EnableIRQ() / HAL_PLIC_DisableIRQ()
 *
 * Test procedure:
 *   Seed the DRBG and keep the interrupt line closed, so that the
 *   completion of the started generation stays pending:
 *     A. start an interrupt generation and read IE back (DONE and GLBL);
 *     B. verify that a second start, an Init and a DeInit are all refused
 *        with HAL_BUSY while the generation is in flight;
 *     C. consume the pending completion with an explicit call to the
 *        interrupt entry and verify the ready callback contract;
 *     D. open the interrupt line and run four real interrupt generations.
 *
 * Expected behaviour:
 *   the driver enables IE.DONE together with the global gate, publishes
 *   BUSY, refuses the lifecycle calls while busy, delivers exactly one
 *   callback per generation whose word equals the cached word, and
 *   "summary : failures = 0" is printed.
 *
 * Note:
 *   HAL extension case. A generation that is started but whose interrupt
 *   line is closed gives a deterministic window in which the BUSY state
 *   and the refusal paths can be observed without a race; the pending
 *   completion is then consumed by calling the interrupt entry directly.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
#define TEST_BAUDRATE                  (115200U)   /*!< console baud rate     */
#define TEST_STEP_TIMEOUT_MS           (1000U)     /*!< per step wait budget  */
#define TEST_ROUND_DELAY_MS            (2000U)     /*!< delay between rounds  */

/* Private variables ---------------------------------------------------------*/
static volatile uint32 check_failures = 0U;   /*!< failed check counter        */
static HAL_SMU_HandleTypeDef hsmu_clk;        /*!< SMU handle (clock tree)     */

/**
 * @brief  TRNG handle used by every case of this suite.
 * @note   The peripheral is a single instance, so one handle is enough; the
 *         lifecycle case uses additional local handles for the refusal paths.
 */
TRNG_HandleTypeDef htrng_dev;

/* MSP callback bookkeeping (written by the shared MSP callbacks) */
uint32 Trng_MspInitCount   = 0U;              /*!< HAL_TRNG_MspInit() calls    */
uint32 Trng_MspDeInitCount = 0U;              /*!< HAL_TRNG_MspDeInit() calls  */
uint32 Trng_MspStateAtInit = 0xFFFFFFFFU;     /*!< handle state seen in the MSP */
uint32 Trng_MspLockAtInit  = 0xFFFFFFFFU;     /*!< handle lock seen in the MSP  */

/* Shared helpers of this suite (defined at the end of this file) */
void Check(const char *name, uint32 condition);
void Summary(void);
void SystemClock_Init(void);
void Trng_ClockEnable(void);
void Trng_PlicEnable(uint8 priority);
HAL_StatusTypeDef Trng_WaitFlag(uint32 flag, uint32 timeout_ms);
HAL_StatusTypeDef Trng_Seed(uint32 timeout_ms);



/* Private define ------------------------------------------------------------*/
#define TEST_IT_ROUNDS                (4U)     /*!< interrupt generation rounds */

/* Private variables ---------------------------------------------------------*/
static volatile uint32 ready_callbacks = 0U;   /*!< data ready callbacks       */
static volatile uint32 ready_value     = 0U;   /*!< word delivered by callback */
static volatile uint32 done_events     = 0U;   /*!< DONE events served         */

/* Private function prototypes -----------------------------------------------*/
static HAL_StatusTypeDef Trng_WaitCounter(volatile uint32 *counter, uint32 target,
                                          uint32 timeout_ms);

/**
 * @brief  TRNG interrupt entry (overrides the weak PLIC dispatch entry).
 * @note   HAL_TRNG_GenerateRandomNumber_IT() publishes the ownership of the
 *         completion (handle BUSY plus the DONE source enabled), so the driver
 *         consumes it, reads RAND0 and calls the ready callback. The
 *         application only acknowledges an event left pending, so that the
 *         level triggered source is de-asserted before the handler returns.
 * @param  None
 * @retval None
 */
void TRNG_IRQ_Handler(void)
{
    HAL_TRNG_IRQHandler(&htrng_dev);

    if (HAL_TRNG_GetITStatus(&htrng_dev, TRNG_FLAG_DONE) != RESET)
    {
        HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_DONE);
        done_events++;
    }
}

/**
 * @brief  Weak data ready callback of the driver (overridden for the check).
 * @param  htrng: TRNG handle
 * @param  random32bit: generated random number
 * @retval None
 */
void HAL_TRNG_ReadyDataCallback(TRNG_HandleTypeDef *htrng, uint32 random32bit)
{
    (void)htrng;

    ready_value = random32bit;
    ready_callbacks++;
}

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    TRNG_InitTypeDef  trng_init;
    HAL_StatusTypeDef status;
    uint32 round = 0U;
    uint32 served = 0U;
    uint32 callbacks;
    uint32 r0;
    uint32 r1;
    uint32 r2;
    uint32 r3;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== TRNG_IT_DRV_004 : interrupt generation API ===\r\n");

    /* Handle preparation */
    __HAL_CLEAR_STRUCT(&htrng_dev);
    htrng_dev.Instance = TRNG;
    HAL_TRNG_StructInit(&trng_init);
    htrng_dev.Init = trng_init;

    status = HAL_TRNG_Init(&htrng_dev);
    Check("HAL_TRNG_Init() returns HAL_OK", (status == HAL_OK) ? 1U : 0U);

    status = Trng_Seed(TEST_STEP_TIMEOUT_MS);
    Check("the DRBG startup sequence completes", (status == HAL_OK) ? 1U : 0U);

    /* ---- A. the sources the driver enables by itself ---------------------- */
    /* The interrupt line is left closed on purpose: the completion of the
     * generation stays pending, so the ownership state of the handle can be
     * observed without a race. */
    HAL_PLIC_DisableIRQ(TRNG_IRQn);

    callbacks = ready_callbacks;
    status    = HAL_TRNG_GenerateRandomNumber_IT(&htrng_dev);
    Check("HAL_TRNG_GenerateRandomNumber_IT() returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("the driver enables IE.DONE together with the global gate IE.GLBL",
          ((TRNG->IE & (TRNG_IT_DONE | TRNG_IT_GLBL)) == (TRNG_IT_DONE | TRNG_IT_GLBL)) ? 1U : 0U);
    Check("the handle is BUSY while the completion is not consumed",
          (HAL_TRNG_GetState(&htrng_dev) == HAL_TRNG_STATE_BUSY) ? 1U : 0U);

    /* ---- B. a second start and the lifecycle calls are refused ------------ */
    Check("a second interrupt generation is refused with HAL_BUSY",
          (HAL_TRNG_GenerateRandomNumber_IT(&htrng_dev) == HAL_BUSY) ? 1U : 0U);
    Check("HAL_TRNG_Init() is refused while a generation is in flight",
          (HAL_TRNG_Init(&htrng_dev) == HAL_BUSY) ? 1U : 0U);
    Check("HAL_TRNG_DeInit() is refused while a generation is in flight",
          (HAL_TRNG_DeInit(&htrng_dev) == HAL_BUSY) ? 1U : 0U);
    Check("the refused calls leave the handle in the BUSY state",
          (HAL_TRNG_GetState(&htrng_dev) == HAL_TRNG_STATE_BUSY) ? 1U : 0U);

    /* ---- C. the pending completion is consumed by the handler ------------- */
    HAL_TRNG_IRQHandler(&htrng_dev);
    Check("the interrupt entry publishes READY for the owned completion",
          (HAL_TRNG_GetState(&htrng_dev) == HAL_TRNG_STATE_READY) ? 1U : 0U);
    Check("the ready callback ran exactly once", ((ready_callbacks - callbacks) == 1U) ? 1U : 0U);
    Check("the callback delivered the cached random word",
          ((uint32)ready_value == HAL_TRNG_ReadLastRandomNumber(&htrng_dev)) ? 1U : 0U);
    Check("ISTAT.DONE is consumed by the handler",
          (HAL_TRNG_GetITStatus(&htrng_dev, TRNG_FLAG_DONE) == RESET) ? 1U : 0U);
    Check("IE.DONE is closed after the completion has been consumed",
          ((TRNG->IE & TRNG_IT_DONE) == 0U) ? 1U : 0U);
    printf("manual entry : callback word = 0x%08X\r\n", PRINT_U32((uint32)ready_value));

    /* ---- D. interrupt driven generations with the real interrupt line ----- */
    Trng_PlicEnable(1U);

    served = 0U;
    for (round = 0U; round < TEST_IT_ROUNDS; round++)
    {
        callbacks = ready_callbacks;

        status = HAL_TRNG_GenerateRandomNumber_IT(&htrng_dev);
        if (status != HAL_OK)
        {
            break;
        }

        if (Trng_WaitCounter(&ready_callbacks, callbacks + 1U, TEST_STEP_TIMEOUT_MS) != HAL_OK)
        {
            break;
        }

        r0 = HAL_TRNG_GetRandomNumber0(&htrng_dev);
        r1 = HAL_TRNG_GetRandomNumber1(&htrng_dev);
        r2 = HAL_TRNG_GetRandomNumber2(&htrng_dev);
        r3 = HAL_TRNG_GetRandomNumber3(&htrng_dev);

        if ((uint32)ready_value != HAL_TRNG_ReadLastRandomNumber(&htrng_dev))
        {
            break;
        }

        printf("round %u : RAND0=%08X RAND1=%08X RAND2=%08X RAND3=%08X\r\n",
               PRINT_U32(round), PRINT_U32(r0), PRINT_U32(r1), PRINT_U32(r2), PRINT_U32(r3));

        served++;
        delay_ms(50U);
    }

    Check("every interrupt generation is served by the handler",
          (served == TEST_IT_ROUNDS) ? 1U : 0U);
    Check("the handle is READY after the interrupt driven rounds",
          (HAL_TRNG_GetState(&htrng_dev) == HAL_TRNG_STATE_READY) ? 1U : 0U);
    Check("the callback count matches the number of rounds",
          (ready_callbacks == (TEST_IT_ROUNDS + 1U)) ? 1U : 0U);

    /* The driver leaves the global gate enabled (it is a shared bit of the
     * interrupt line); close both sources again before leaving the case */
    HAL_TRNG_ITConfig(&htrng_dev, (uint32)(TRNG_IT_DONE | TRNG_IT_GLBL), DISABLE);

    Summary();

    for (;;)
    {
        callbacks = ready_callbacks;

        if (HAL_TRNG_GenerateRandomNumber_IT(&htrng_dev) == HAL_OK)
        {
            if (Trng_WaitCounter(&ready_callbacks, callbacks + 1U, TEST_STEP_TIMEOUT_MS) == HAL_OK)
            {
                printf("it  : 0x%08X\r\n",
                       PRINT_U32(HAL_TRNG_ReadLastRandomNumber(&htrng_dev)));
            }
            else
            {
                printf("it  : no completion\r\n");
            }
        }
        else
        {
            printf("it  : start refused\r\n");
        }

        delay_ms(TEST_ROUND_DELAY_MS);
    }
}

/**
 * @brief  Wait (bounded) until one counter reaches the target value.
 * @param  counter: address of the counter written by the interrupt handler
 * @param  target: value to reach
 * @param  timeout_ms: timeout in milliseconds
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT
 */
static HAL_StatusTypeDef Trng_WaitCounter(volatile uint32 *counter, uint32 target,
                                          uint32 timeout_ms)
{
    uint32 tickstart = HAL_GetTick();

    while (*counter < target)
    {
        if ((HAL_GetTick() - tickstart) > timeout_ms)
        {
            return HAL_TIMEOUT;
        }
    }

    return HAL_OK;
}

/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the other integration tests of this library:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2 and
 *         CANX2 by 8, which gives core 180 MHz and APB 22.5 MHz (the console
 *         USART is clocked from APBBus0). The TRNG sits on the AXILite4-Bus1
 *         bus, which is not divided by this tree.
 * @note   Clock tree order: the dividers are written while the system clock
 *         is still the power on source (FIRC), then the PLL is configured and
 *         the system clock is switched to it. That last call programs the
 *         flash controller clock before the switch (the core keeps fetching
 *         from the flash) and updates SystemCoreClock afterwards.
 * @param  None
 * @retval None
 */
void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks (console pins of USART0 on GPIOD) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Open the clock gate of the security domain and release its reset.
 * @note   The TRNG has no dedicated SMU gate: it is clocked and reset through
 *         the DSE (security engine) domain bits of SMU->ALB1CFGR, exactly like
 *         the reference test case does with its DSE_CLK_ENABLE / DSE_RESET /
 *         DSE_SET sequence. The HAL TRNG driver has no default MSP body, so
 *         this helper is what HAL_TRNG_MspInit() / the cases call.
 * @note   The gate is never closed again (not even by HAL_TRNG_MspDeInit):
 *         the DSE domain is shared with the other security peripherals, and a
 *         closed gate makes any later register access stall the bus.
 * @param  None
 * @retval None
 */
void Trng_ClockEnable(void)
{
    __HAL_SMU_DSE_CLK_ENABLE();
    __HAL_SMU_DSE_FORCE_RESET();
    __HAL_SMU_DSE_RELEASE_RESET();
}

/**
 * @brief  Enable the TRNG interrupt source in the PLIC.
 * @param  priority: source priority (1..63, larger = higher priority)
 * @retval None
 */
void Trng_PlicEnable(uint8 priority)
{
    PLIC_InitTypeDef plic_init;

    __HAL_CLEAR_STRUCT(&plic_init);
    plic_init.Size               = sizeof(plic_init);
    plic_init.Version            = PLIC_INIT_VERSION;
    plic_init.PLIC_IRQChannel    = TRNG_IRQn;
    plic_init.PLIC_IRQPriority   = priority;
    plic_init.PLIC_IRQChannelCmd = PLIC_ENABLE;
    (void)HAL_PLIC_Init(&plic_init);
}

/**
 * @brief  Wait (bounded) until one ISTAT event flag of the handle is set.
 * @note   The flag is not cleared here: the caller decides who acknowledges it
 *         (the driver for the completions it owns, the application for the
 *         events it enabled itself).
 * @param  flag: event mask (TRNG_FLAG_x or a combination)
 * @param  timeout_ms: timeout in milliseconds
 * @retval HAL_StatusTypeDef: HAL_OK when the flag was observed / HAL_TIMEOUT
 */
HAL_StatusTypeDef Trng_WaitFlag(uint32 flag, uint32 timeout_ms)
{
    uint32 tickstart = HAL_GetTick();

    while (HAL_TRNG_GetITStatus(&htrng_dev, flag) == RESET)
    {
        if ((HAL_GetTick() - tickstart) > timeout_ms)
        {
            return HAL_TIMEOUT;
        }
    }

    return HAL_OK;
}

/**
 * @brief  Run the DRBG startup sequence: ZEROIZE -> GEN_NOISE -> CREATE_STATE.
 * @note   This is the sequence the reference test case runs at the beginning of
 *         every round; it is factored out here because the cases that use the
 *         HAL generation interfaces only need the DRBG to be seeded once.
 * @param  timeout_ms: per step timeout in milliseconds
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (command refused) / HAL_TIMEOUT
 */
HAL_StatusTypeDef Trng_Seed(uint32 timeout_ms)
{
    if (HAL_TRNG_SendCommand(&htrng_dev, TRNG_COMMAND_ZEROIZE) != HAL_OK)
    {
        return HAL_ERROR;
    }
    if (Trng_WaitFlag(TRNG_FLAG_ZEROIZED, timeout_ms) != HAL_OK)
    {
        return HAL_TIMEOUT;
    }
    HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_ZEROIZED);
    HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_DONE);

    if (HAL_TRNG_SendCommand(&htrng_dev, TRNG_COMMAND_GEN_NOISE) != HAL_OK)
    {
        return HAL_ERROR;
    }
    if (Trng_WaitFlag(TRNG_FLAG_DONE, timeout_ms) != HAL_OK)
    {
        return HAL_TIMEOUT;
    }
    HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_DONE);

    if (HAL_TRNG_SendCommand(&htrng_dev, TRNG_COMMAND_CREATE_STATE) != HAL_OK)
    {
        return HAL_ERROR;
    }
    if (Trng_WaitFlag(TRNG_FLAG_DONE, timeout_ms) != HAL_OK)
    {
        return HAL_TIMEOUT;
    }
    HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_DONE);

    return HAL_OK;
}

/* MSP callbacks ------------------------------------------------------------*/

/**
 * @brief  Initialize the TRNG MSP (security domain clock gate and reset).
 * @note   The default implementation of the driver is empty, so the DSE domain
 *         is opened here (the TRNG has no gate of its own).
 * @note   The call is recorded so that the lifecycle case can verify the
 *         LOCK-06 / MSP-04 contract: the callback must run outside the handle
 *         lock and only on the first initialization (state RESET).
 * @param  htrng: TRNG handle
 * @retval None
 */
void HAL_TRNG_MspInit(TRNG_HandleTypeDef *htrng)
{
    Trng_MspInitCount++;
    Trng_MspStateAtInit = (uint32)htrng->State;
    Trng_MspLockAtInit  = (uint32)htrng->Lock;

    Trng_ClockEnable();
}

/**
 * @brief  De-initialize the TRNG MSP.
 * @note   The DSE clock gate is shared with the other security peripherals and
 *         is left open on purpose, so that a case may read the TRNG registers
 *         after a de-initialization without stalling the bus.
 * @param  htrng: TRNG handle
 * @retval None
 */
void HAL_TRNG_MspDeInit(TRNG_HandleTypeDef *htrng)
{
    Trng_MspDeInitCount++;

    (void)htrng;
}

/*****END OF FILE*****/
