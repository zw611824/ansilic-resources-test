/**
 * @file    SPACC_IT_DRV_004.c
 * @brief   HAL SPACC integration test case 004 (SM4-OFB encryption).
 *
 * SM4-OFB encryption of one 232-byte packet (230 processed bytes).
 *
 * Tested functionality:
 *   HAL_SPACC_StructInit / HAL_SPACC_Init / HAL_SPACC_PacketInit / HAL_SPACC_WriteContext / HAL_SPACC_ReadContext / HAL_SPACC_StateFIFOFlag / HAL_SPACC_CommandExecResult / HAL_SPACC_GetState.
 *
 * Expected behaviour:
 *   the SM4-OFB cipher context and the ciphertext equal the reference vectors, so the summary stays at zero failures.
 *
 * @note    The packet vectors are the ones of the reference test project
 *          (SPACC_IT_DRV_004.c) and are reproduced verbatim, so a case can be
 *          compared one to one with the reference output.
 * @note    The SPACC needs the AXILite4-Bus1 (DSE) clock gate and reset
 *          release: HAL_SPACC_MspInit() is overridden at the end of this file
 *          to do that and to count its calls.
 * @note    The DDT structures are 8-byte aligned through a union with a 64-bit
 *          member, because the driver validates the alignment of the DDT bus
 *          address (SRC_PTR.PTR starts at bit 3).
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Software identifier carried by every submitted task */
#define TEST_SOFTWARE_ID            (0x2DU)

/* Bound of every polling loop (the SPACC completes in microseconds) */
#define TEST_WAIT_GUARD             (20000000U)

/* Reporting period of the final loop (ms) */
#define TEST_POLL_MS                (1000U)

/* Unknown instance used by the handle validation checks */
#define TEST_BAD_INSTANCE           ((SPACC_TypeDef *)0x40000000UL)

/* Processed packet size, in 32-bit words, of this case */
#define TEST_PACKET_WORDS           (58U)

/* Byte-swap helper: the SPACC consumes the packet in the opposite byte order
 * of the C representation, exactly as the reference test project does. */
#define TEST_SWAP32(__VALUE__)      ((((__VALUE__) & 0x000000FFUL) << 24) | \
                                     (((__VALUE__) & 0x0000FF00UL) << 8)  | \
                                     (((__VALUE__) & 0x00FF0000UL) >> 8)  | \
                                     (((__VALUE__) & 0xFF000000UL) >> 24))

/* Private typedef -----------------------------------------------------------*/
/**
 * @brief Data descriptor table (DDT) of a packet segment list.
 * @note  The SPACC reads SRC_PTR / DST_PTR as the bus address of a DDT whose
 *        first pointer is kept on an 8-byte boundary (PTR field starts at bit
 *        3), so the two DDT instances below are wrapped in a union with a
 *        64-bit member to force that alignment on every toolchain.
 */
typedef struct
{
    uint32 *Ptr_0;
    uint32  Len_0;
    uint32 *Ptr_1;
    uint32  Len_1;
} SPACC_DDTTypeDef;

typedef union
{
    SPACC_DDTTypeDef ddt;
    uint64           force_align8;
} SPACC_DDTAlignedTypeDef;

/* Private variables ---------------------------------------------------------*/
static HAL_SPACC_HandleTypeDef hspacc_dev;          /*!< handle under test      */
static HAL_SMU_HandleTypeDef   hsmu_clk;            /*!< SMU handle (clock)     */
static SPACC_InitTypeDef       spacc_init;          /*!< configuration          */
static SPACC_PacketTypeDef     spacc_packet;        /*!< packet descriptor      */
static SPACC_DDTAlignedTypeDef spacc_ddt_src;       /*!< source DDT (8B aligned)*/
static SPACC_DDTAlignedTypeDef spacc_ddt_dst;       /*!< destination DDT        */

/* Accumulated check counters */
static uint32 failures = 0U;
static uint32 checks = 0U;

/* Low level callback instrumentation */
static uint32 msp_init_count = 0U;
static uint32 msp_deinit_count = 0U;
static uint32 error_callback_count = 0U;

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void Section(const char *name);
static void Check(const char *name, uint32 condition);
static void Summary(void);
static void Spacc_StageDdt(uint32 *src, uint32 src_bytes, uint32 *dst, uint32 dst_bytes);
static HAL_StatusTypeDef Spacc_WriteCipherContext(const uint32 *words, uint32 count);
static HAL_StatusTypeDef Spacc_ReadCipherContext(uint32 *words, uint32 count);
static uint32 Spacc_WaitResult(uint32 software_id);
static void Spacc_Drain(uint32 limit);


/* Test vectors -------------------------------------------------------------*/
/* vectors extracted verbatim from SPACC_IT_DRV_004.c (only "u32 " normalised to "uint32_t ") */
#define PACKET_LEN	58

/* spacc_sm4_ofb_context [12] */
uint32_t spacc_sm4_ofb_context[12] = {0xff451a44, 0x9b79ea7b, 0x78fdcb47, 0x88cf8a85,
                                 0x00000000, 0x00000000, 0x00000000, 0x00000000,
                                 0x6adce76d, 0xa2d76f77, 0x9a9c94bd, 0xa3639b1f};

/* spacc_sm4_ofb_plaintext [PACKET_LEN] */
uint32_t spacc_sm4_ofb_plaintext[PACKET_LEN] = {0x56f1358a, 0x24a8a358, 0xd10d02b0, 0xa6c809a0, 0xbb357e74, 0x4598d1d6, 0x648910a0, 0xbb7cc8e1,
                                           0x0edd467e, 0xc947703b, 0xea704d8d, 0xb9e642f8, 0x56622386, 0xc2fa2970, 0xc5c01b14, 0x797aa4fd,
                                           0xf11b63a0, 0x9eff66e5, 0xc3e4aa2b, 0x99158520, 0x59801b64, 0xdee9d1db, 0x9c923efa, 0xb1fece2e,
                                           0x7a8b4b15, 0x95afad32, 0xbadb9ea1, 0xbb45ae85, 0xd7bdd92b, 0x6daf6de1, 0x8fc33aee, 0x857fadf2,
                                           0x0db46c12, 0x06453414, 0x2aae8d26, 0x7e0f9708, 0xcbc72bf9, 0x24d7351f, 0xb0ea2c8b, 0x95e76e4e,
                                           0x528d84e7, 0x05163b84, 0x19b2ba22, 0x241f61b1, 0x311aca60, 0xda12227c, 0x0d5c3a68, 0x38317175,
                                           0x8f1d9ee1, 0x87618c2c, 0xaa3e1618, 0xaa03f887, 0xe4dea10b, 0xd123b800, 0x37b71c0b, 0x433072c2,
                                           0xa6fb7dde, 0x97930000};

/* spacc_sm4_ofb_ciphertext_exprct [PACKET_LEN] */
uint32_t spacc_sm4_ofb_ciphertext_exprct[PACKET_LEN] = {0xac34de3d,0xdcbdf5c6,0x5b9e79b2,0x8fe8134f,0x79014deb,0xf8c1ab8d,0xc1dbb8d5,0xe627f3a2,
                                                   0x6de0555f,0x3e3c77ea,0x0bc47b3f,0x283114ab,0xfdd25439,0xac55782c,0xfbd1692f,0xe21fd564,
                                                   0x5fcbd1a5,0x5173c40e,0x608937b7,0x89c20697,0xc3ad0579,0xe1cc0b02,0xa3f4058c,0x62b89da7,
                                                   0xd87b4000,0x4d5d9b4e,0x844c5e2a,0xf8ce6ee8,0x40ef27dd,0x0a0ace35,0x570c0ebb,0xac58ea08,
                                                   0x8addb1ea,0x238769e1,0xf47e0e69,0x0c2885a3,0xc9acf362,0x18d73a4a,0xf30f68aa,0xcd532a18,
                                                   0x87b136bc,0x3b47f8f3,0xd94cd481,0xc17a3ed3,0x28efcb71,0xb5b59277,0xbfdff46f,0x9b94c9ca,
                                                   0x5ccd1929,0x87ee4f3c,0xcafb5264,0x8a60e079,0xc1625ad2,0xf63f50af,0xaf23cde6,0x4af83373,
                                                   0x39e38669,0x109f0000};

/* spacc_sm4_ofb_context_exprct [12] */
uint32_t spacc_sm4_ofb_context_exprct[12] = {0xff451a44, 0x9b79ea7b, 0x78fdcb47, 0x88cf8a85,
                                        0x00000000, 0x00000000, 0x00000000, 0x00000000,
                                        0x9f18fbb7, 0x870c243a, 0x27537187, 0x90bff11a};

static uint32 spacc_plaintext_swp[TEST_PACKET_WORDS];
static uint32 spacc_ciphertext_result[TEST_PACKET_WORDS];
static uint32 spacc_context_read[12];

/**
 * @brief  Case 004: SM4-OFB encryption of one 232-byte packet.
 * @retval Never (the final loop keeps reporting).
 */
int main(void)
{
    uint32 i;
    uint32 context_mismatch = 0U;
    uint32 packet_mismatch = 0U;
    HAL_StatusTypeDef status;

    HAL_Init();
    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);

    printf("\r\n ***** SPACC SM4-OFB encryption test (case 004) ***** \r\n");
    printf("Data : %s\r\n", __DATE__);
    printf("Time : %s\r\n", __TIME__);
    delay_ms(500U);

    Section("preparation");

    __HAL_CLEAR_STRUCT(&hspacc_dev);
    hspacc_dev.Instance = SPACC;

    /* A warm re-run may leave results behind: drop them before the real task,
     * so the completion check of this run can only observe its own task. */
    Spacc_Drain(8U);
    Check("handle starts in the reset state",
          (HAL_SPACC_GetState(&hspacc_dev) == HAL_SPACC_STATE_RESET) ? 1U : 0U);

    for (i = 0U; i < TEST_PACKET_WORDS; i++)
    {
        spacc_plaintext_swp[i] = TEST_SWAP32(spacc_sm4_ofb_plaintext[i]);
    }
    CLEAR_CACHE();

    Spacc_StageDdt(spacc_plaintext_swp, (TEST_PACKET_WORDS * 4U),
                   spacc_ciphertext_result, (TEST_PACKET_WORDS * 4U));

    /* The reference packet declares 230 processed bytes inside a 232-byte
     * segment, which is the value the expected vectors were produced with. */
    spacc_packet.SPACC_PROCLen = 0xE6U;

    Section("context and descriptor");

    status = Spacc_WriteCipherContext(spacc_sm4_ofb_context, 12U);
    Check("cipher context written", (status == HAL_OK) ? 1U : 0U);

    HAL_SPACC_PacketInit(&hspacc_dev, &spacc_packet);
    Check("descriptor accepted", (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_NONE) ? 1U : 0U);
    Check("processing length staged",
          ((SPACC->PROC_LEN & (uint32)SPACC_PROC_LEN_LEN) == 0xE6U) ? 1U : 0U);

    Section("submit and completion");

    HAL_SPACC_StructInit(&spacc_init);
    spacc_init.SPACC_CipherAlgorithm     = SPACC_CIPHER_ALG_SM4;
    spacc_init.SPACC_SM4CipherMode       = SPACC_SM4_CIPHER_MODE_OFB;
    spacc_init.SPACC_HashAlgorithm       = SPACC_HASH_ALG_NULL;
    spacc_init.SPACC_SM3HashMode         = SPACC_SM3_HASH_MODE_RAW_SHAKE;
    spacc_init.SPACC_TransferMode        = SPACC_TRANS_TO_APPLY_ENCRYPT;
    spacc_init.SPACC_ContextIndex        = 0U;
    spacc_init.SPACC_KeyFrom             = SPACC_KEY_FROM_CTX;
    spacc_init.SPACC_AADCopy             = SPACC_APP_NOT_COPY;
    spacc_init.SPACC_ICVCompute          = SPACC_ICV_COMPUTER_PLAIN;
    spacc_init.SPACC_ICVEncrypt          = SPACC_ICV_NOT_ENCRYPT;
    spacc_init.SPACC_ICVLocation         = SPACC_ICV_LOCATION_OFFSET;
    spacc_init.SPACC_KeyExpand           = SPACC_KEY_EXPAND;
    spacc_init.SPACC_MessageBegin        = SPACC_MSG_BEGIN_FIRST;
    spacc_init.SPACC_MessageEnd          = SPACC_MSG_END_LAST;
    spacc_init.SPACC_SoftwareID          = TEST_SOFTWARE_ID;
    spacc_init.SPACC_PriorityCommandFIFO = 0U;
    spacc_init.SPACC_KeySize             = 0x10U;
    spacc_init.SPACC_KeyIndex            = 0U;
    spacc_init.SPACC_KeyType             = SPACC_KEY_TYPE_CIPHER;

    status = HAL_SPACC_Init(&hspacc_dev, &spacc_init);
    Check("Init accepted (task submitted)", (status == HAL_OK) ? 1U : 0U);
    Check("state is ready after the submission",
          (HAL_SPACC_GetState(&hspacc_dev) == HAL_SPACC_STATE_READY) ? 1U : 0U);
    Check("result available and software ID matched",
          Spacc_WaitResult(TEST_SOFTWARE_ID));
    Check("status FIFO empty after the pop",
          (HAL_SPACC_StateFIFOFlag(&hspacc_dev) == SET) ? 1U : 0U);

    Section("verification");

    status = Spacc_ReadCipherContext(spacc_context_read, 12U);
    Check("cipher context read back", (status == HAL_OK) ? 1U : 0U);

    for (i = 0U; i < 12U; i++)
    {
        if (spacc_context_read[i] != spacc_sm4_ofb_context_exprct[i])
        {
            context_mismatch++;
            printf("  context[%02u] = %08X, expected %08X\r\n", PRINT_U32(i),
                   PRINT_U32(spacc_context_read[i]),
                   PRINT_U32(spacc_sm4_ofb_context_exprct[i]));
        }
    }

    for (i = 0U; i < TEST_PACKET_WORDS; i++)
    {
        if (spacc_ciphertext_result[i] != TEST_SWAP32(spacc_sm4_ofb_ciphertext_exprct[i]))
        {
            packet_mismatch++;
            if (packet_mismatch <= 8U)
            {
                printf("  ciphertext[%03u] = %08X, expected %08X\r\n", PRINT_U32(i),
                       PRINT_U32(spacc_ciphertext_result[i]),
                       PRINT_U32(TEST_SWAP32(spacc_sm4_ofb_ciphertext_exprct[i])));
            }
        }
    }

    Check("SM4-OFB cipher context equals the expected value", (context_mismatch == 0U) ? 1U : 0U);
    Check("SM4-OFB packet equals the expected value", (packet_mismatch == 0U) ? 1U : 0U);

    printf("\r\ncontext mismatches = %u, packet mismatches = %u\r\n",
           PRINT_U32(context_mismatch), PRINT_U32(packet_mismatch));

    Section("result");
    Summary();
    printf("***** SPACC SM4-OFB encryption test %s *****\r\n",
           ((failures == 0U) ? "success" : "failed"));

    for (;;)
    {
        delay_ms(TEST_POLL_MS);
    }
}


/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Report one section of the case.
 * @param  name: section name.
 * @retval None
 */
static void Section(const char *name)
{
    printf("\r\n---- %s ----\r\n", name);
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    checks++;

    if (condition == 0U)
    {
        failures++;
    }

    printf("%-58s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Print the check summary.
 * @retval None
 */
static void Summary(void)
{
    printf("\r\nchecks = %u, failures = %u\r\n", PRINT_U32(checks), PRINT_U32(failures));
    printf("summary : failures = %s\r\n", ((failures == 0U) ? "0 (PASS)" : "NON-ZERO (FAIL)"));
}

/**
 * @brief  Fill the two DDT structures and the pointer fields of the descriptor.
 * @param  src: source buffer.
 * @param  src_bytes: source segment length, in bytes.
 * @param  dst: destination buffer.
 * @param  dst_bytes: destination segment length, in bytes.
 * @retval None
 * @note   Both DDTs describe a single segment, the second entry is the NULL
 *         terminator. The byte counts and every offset of the descriptor are
 *         cleared here; the case overrides the fields it needs afterwards.
 */
static void Spacc_StageDdt(uint32 *src, uint32 src_bytes, uint32 *dst, uint32 dst_bytes)
{
    spacc_ddt_src.ddt.Ptr_0 = src;
    spacc_ddt_src.ddt.Len_0 = src_bytes;
    spacc_ddt_src.ddt.Ptr_1 = NULL_PTR;
    spacc_ddt_src.ddt.Len_1 = 0U;

    spacc_ddt_dst.ddt.Ptr_0 = dst;
    spacc_ddt_dst.ddt.Len_0 = dst_bytes;
    spacc_ddt_dst.ddt.Ptr_1 = NULL_PTR;
    spacc_ddt_dst.ddt.Len_1 = 0U;

    spacc_packet.SPACC_SourcePtr        = (uint32)(&spacc_ddt_src.ddt);
    spacc_packet.SPACC_DestinationPtr   = (uint32)(&spacc_ddt_dst.ddt);
    spacc_packet.SPACC_SouPREAADOffset  = 0U;
    spacc_packet.SPACC_DestPREAADOffset = 0U;
    spacc_packet.SPACC_PREAADLen        = 0U;
    spacc_packet.SPACC_POSTAADLen       = 0U;
    spacc_packet.SPACC_PROCLen          = (TEST_PACKET_WORDS * 4U);
    spacc_packet.SPACC_ICVLen           = 0U;
    spacc_packet.SPACC_ICVOffset        = 0U;
    spacc_packet.SPACC_IVOffset         = 0U;
    spacc_packet.SPACC_IVLocation       = SPACC_IV_LOCATION_CONTEXT;

    CLEAR_CACHE();
}

/**
 * @brief  Write the cipher context (key / IV) through the HAL context API.
 * @param  words: context words in the C representation (big endian wording).
 * @param  count: number of words.
 * @retval HAL status of HAL_SPACC_WriteContext().
 * @note   The values are byte swapped in a local buffer before the transfer,
 *         because the SPACC context store keeps them in the opposite order
 *         (the reference test project writes them through the same swap).
 */
static HAL_StatusTypeDef Spacc_WriteCipherContext(const uint32 *words, uint32 count)
{
    uint32 swapped[16];
    uint32 i;

    for (i = 0U; (i < count) && (i < 16U); i++)
    {
        swapped[i] = TEST_SWAP32(words[i]);
    }

    return HAL_SPACC_WriteContext(&hspacc_dev, SPACC_CIPHER_CONTEXT_BASE, 0U, swapped, count);
}

/**
 * @brief  Read the cipher context and undo the byte swap.
 * @param  words: destination buffer, in the C representation.
 * @param  count: number of words.
 * @retval HAL status of HAL_SPACC_ReadContext().
 */
static HAL_StatusTypeDef Spacc_ReadCipherContext(uint32 *words, uint32 count)
{
    uint32 raw[16];
    uint32 i;
    HAL_StatusTypeDef status;

    status = HAL_SPACC_ReadContext(&hspacc_dev, SPACC_CIPHER_CONTEXT_BASE, 0U, raw, count);

    for (i = 0U; (i < count) && (i < 16U); i++)
    {
        words[i] = TEST_SWAP32(raw[i]);
    }

    return status;
}

/**
 * @brief  Wait for a result and match its software identifier.
 * @param  software_id: identifier of the submitted task.
 * @retval 1 when a result was popped and its identifier matched, 0 otherwise.
 * @note   The wait is bounded, so a silent hardware problem is reported as a
 *         failed check instead of hanging the case.
 */
static uint32 Spacc_WaitResult(uint32 software_id)
{
    uint32 guard = TEST_WAIT_GUARD;

    while ((HAL_SPACC_StateFIFOFlag(&hspacc_dev) == SET) && (guard != 0U))
    {
        guard--;
    }

    CLEAR_CACHE();

    if (guard == 0U)
    {
        return 0U;
    }

    return (HAL_SPACC_CommandExecResult(&hspacc_dev, software_id) == SET) ? 1U : 0U;
}

/**
 * @brief  Pop every pending result so that the next submission starts clean.
 * @param  limit: maximum number of results to pop.
 * @retval None
 */
static void Spacc_Drain(uint32 limit)
{
    uint32 count = 0U;

    CLEAR_CACHE();

    while ((HAL_SPACC_StateFIFOFlag(&hspacc_dev) == RESET) && (count < limit))
    {
        (void)HAL_SPACC_CommandExecResult(&hspacc_dev, 0U);
        count++;
    }
}

/**
 * @brief  SPACC low level initialization: clock gate and reset release.
 * @param  hspacc: SPACC handle.
 * @retval None
 * @note   The SPACC is clocked by the AXILite4-Bus1 (DSE) domain, gated by the
 *         SMU. The call count lets the cases verify that the callback runs
 *         once, before the handle is locked.
 */
void HAL_SPACC_MspInit(HAL_SPACC_HandleTypeDef *hspacc)
{
    if (hspacc == NULL_PTR)
    {
        return;
    }

    msp_init_count++;

    __HAL_SMU_DSE_CLK_ENABLE();
    __HAL_SMU_DSE_FORCE_RESET();
    __HAL_SMU_DSE_RELEASE_RESET();
}

/**
 * @brief  SPACC low level de-initialization, counted for the life cycle checks.
 * @param  hspacc: SPACC handle.
 * @retval None
 */
void HAL_SPACC_MspDeInit(HAL_SPACC_HandleTypeDef *hspacc)
{
    if (hspacc == NULL_PTR)
    {
        return;
    }

    msp_deinit_count++;
}

/**
 * @brief  SPACC error callback, counted for the interrupt checks.
 * @param  hspacc: SPACC handle.
 * @retval None
 */
void HAL_SPACC_ErrorCallback(HAL_SPACC_HandleTypeDef *hspacc)
{
    (void)hspacc;

    error_callback_count++;
}

/**
 * @brief  Configure the system clock and the bus gates.
 * @retval None
 * @note   Same clock tree as the other HAL integration suites: the PLL is fed
 *         by the external oscillator (VCO 180 MHz) and the buses run at
 *         AXI4Bus3 / 2, APBBus0 / 2, APBBus1 / 2 and CANX2 / 8, which keeps
 *         the console USART on its usual 22.5 MHz.
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    smu_osc;
    SMU_ClockInitTypeDef  smu_clock;
    SMU_ClocksTypeDef     smu_clocks;
    HAL_PMU_HandleTypeDef hpmu;

    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Raise the core rail trim before the PLL is switched: the 1.2 V LDO APIs
     * are gated on the handle state, so the PMU must be initialized first */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    __HAL_CLEAR_STRUCT(&smu_osc);
    smu_osc.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    smu_osc.FIRCState            = SMU_FIRC_ON;
    smu_osc.FIRCCalibrationValue = 0x00U;
    smu_osc.PLL.PLLState         = SMU_PLL_ON;
    smu_osc.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    smu_osc.PLL.PLLDivR          = 0x04U;
    smu_osc.PLL.PLLDivQ          = 0x01U;
    smu_osc.PLL.PLLDivN          = 0x14U;
    smu_osc.PLL.PLLDivF          = 0xB4U;
    smu_osc.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    (void)HAL_SMU_OscConfig(&hsmu_clk, &smu_osc, SMU_TIMEOUT_DEFAULT);

    /* Bus dividers */
    __HAL_CLEAR_STRUCT(&smu_clock);
    smu_clock.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    smu_clock.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    smu_clock.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    smu_clock.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &smu_clock);

    (void)HAL_SMU_GetClocksFreq(&smu_clocks);

    /* The packet descriptor and the context memory are programmable before the
     * first initialization, so the AXILite4-Bus1 (DSE) clock gate and its reset
     * release must already be in place: the gate is not guaranteed to be open
     * after a power-on or a hardware reset, and an access of the unclocked block
     * stalls the bus. HAL_SPACC_MspInit() repeats both operations before the
     * first submission. */
    __HAL_SMU_DSE_CLK_ENABLE();
    __HAL_SMU_DSE_FORCE_RESET();
    __HAL_SMU_DSE_RELEASE_RESET();
}

/*****END OF FILE*****/
