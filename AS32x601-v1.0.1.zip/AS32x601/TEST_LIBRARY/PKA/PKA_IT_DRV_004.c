/**
 * @file    PKA_IT_DRV_004.c
 * @brief   HAL PKA integration test case 004 (RSA-1024 CRT decryption).
 *
 * Case 004 translates the reference Chinese Remainder Theorem (CRT) RSA
 * decryption example to the HAL API. The key pair is a 1024-bit RSA key
 * whose two prime factors are 512 bits wide, so every operand of the
 * micro-code is a 512-bit value (16 words) and the plaintext is produced as
 * two 512-bit halves.
 *
 * The case follows the sequence of the reference material exactly:
 *   1. entry 0x17 (CRT key setup): p / q / d_lo / d_hi -> dp / dq / u;
 *   2. Montgomery precomputation of p (entries 0x11 / 0x10 / 0x12) -> p' and
 *      r^2 mod p;
 *   3. the same three steps for q -> q' and r^2 mod q;
 *   4. entry 0x18 (CRT modular exponentiation) with the eleven operands;
 *   5. read the low and the high half of the plaintext.
 *
 * The micro-code is loaded with HAL_PKA_LoadFirmware() and every operand is
 * transferred with HAL_PKA_WriteData() / HAL_PKA_ReadData(), so the case
 * exercises the whole HAL data path of the module.
 *
 * Tested functionality:
 *   HAL_PKA_Init() / HAL_PKA_MspInit() / HAL_PKA_ClearStack() /
 *   HAL_PKA_SetEntryPoint() / HAL_PKA_LoadFirmware() /
 *   HAL_PKA_WriteData() / HAL_PKA_ReadData() /
 *   HAL_PKA_GetStatStatus() / HAL_PKA_ClearStatus()
 *
 * Test procedure:
 *   1. Load the micro-code image and clear the operand window;
 *   2. derive u / dp / dq from p / q / d_lo / d_hi and compare them;
 *   3. derive p', r^2 mod p, q' and r^2 mod q;
 *   4. write the eleven CRT operands and run entry 0x18;
 *   5. compare both halves of the plaintext and print the failure count.
 *
 * Expected behaviour:
 *   - the derived CRT parameters u / dp / dq match the expected vectors and
 *     every micro-code operation completes;
 *   - both halves of the plaintext match the expected vectors, so the
 *     summary stays at zero failures;
 *   - the case repeats the whole sequence forever, which allows the report
 *     to be read at any time.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"
#include "as32x601_pka_fw.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* One 512-bit operand is 16 words (64 bytes) */
#define TEST_WORDS                  (16U)

/* Partial radix used by the reference example: 0 selects the complete base */
#define TEST_PARTIAL_RADIX          (0U)

/* Base radix of every operation of this case */
#define TEST_BASE_RADIX             (PKA_BASE_RADIX_512)

/* Micro-code entry points used by the case */
#define TEST_EP_RINV                (0x11U)   /* r^-1 mod m                 */
#define TEST_EP_MPRIME              (0x10U)   /* m'                         */
#define TEST_EP_R2                  (0x12U)   /* r^2 mod m                  */
#define TEST_EP_CRT_SETUP           (0x17U)   /* CRT key setup              */
#define TEST_EP_CRT_EXP             (0x18U)   /* CRT modular exponentiation */

/* Bound of every polling loop, so a failure can never hang the case */
#define TEST_WAIT_GUARD             (20000000U)

/* Reporting period of the final loop (ms) */
#define TEST_POLL_MS                (1000U)

/* Private variables ---------------------------------------------------------*/
static HAL_PKA_HandleTypeDef hpka_dev;      /*!< PKA device handle            */
static PKA_InitTypeDef       pka_init;      /*!< configuration used at start  */
static HAL_SMU_HandleTypeDef hsmu_clk;      /*!< SMU handle (clock tree)      */
static uint32                failures = 0U; /*!< failed checks                */
static uint32                checks = 0U;   /*!< executed checks              */

/* Zero buffer used to clear the operand window (1024 words = the window) */
static uint32 pka_zero[PKA_OPERAND_WINDOW_WORDS_MAX];

/* Private function prototypes -----------------------------------------------*/
static void Section(const char *name);
static void Check(const char *name, uint32 condition);
static HAL_StatusTypeDef Pka_LoadFirmware(void);
static HAL_StatusTypeDef Pka_ClearMemory(void);
static HAL_StatusTypeDef Pka_Write(uint32 address, const uint32 *data, uint32 words);
static HAL_StatusTypeDef Pka_Read(uint32 address, uint32 *data, uint32 words);
static HAL_StatusTypeDef Pka_Run(uint32 entry, uint32 radix);
static uint32 Pka_Compare(const uint32 *result, const uint32 *expect, uint32 words);
static void Pka_Report(const char *name, const uint32 *result, const uint32 *expect,
                       uint32 words);
static void Pka_PrintWords(const char *name, const uint32 *data, uint32 words);
static uint32 Pka_Montgomery(void);
static void SystemClock_Init(void);

/* Private variables (test vectors) ------------------------------------------*/

/* first prime factor p */
static const uint32 RSA_p[TEST_WORDS] =
{
    0x051fc925, 0xa40f6ee4, 0xa7924c30, 0x440d2885,
    0x1d507ad8, 0xb7825ac3, 0x1283c2e5, 0x45b665c9,
    0x192ada18, 0x94f66c5c, 0x98713a1d, 0xec00e946,
    0x99efda60, 0x20e44ba2, 0x0c87d7a5, 0x824ff4b2
};

/* second prime factor q */
static const uint32 RSA_q[TEST_WORDS] =
{
    0x3ca39755, 0xdafe55f0, 0x2543d441, 0x2fff3dc9,
    0x0c851f8a, 0xbdfa5048, 0x7aca31ea, 0xea6e265a,
    0x5bb6db65, 0x17c05414, 0x01b2f199, 0x0c5dc183,
    0xa34bce64, 0x48e7524b, 0xdda5908b, 0xf6430472
};

/* low half of the private exponent d */
static const uint32 RSA_d_lo[TEST_WORDS] =
{
    0xd7f8e591, 0x210c645e, 0x309863e4, 0xe8f8446d,
    0x19dc13e9, 0x58166336, 0xd3a0c960, 0x9371d652,
    0xdbf57b63, 0x19c32e1b, 0x55c00879, 0x89a243fe,
    0x61bfacb8, 0x143dd17e, 0x55f85666, 0x2fb3ae86
};

/* high half of the private exponent d */
static const uint32 RSA_d_hi[TEST_WORDS] =
{
    0x747182c8, 0xade6e18f, 0x9aa87bce, 0xd0ca7cb3,
    0x26fc3767, 0x2b4119be, 0x03cd91ac, 0xba1068fe,
    0x5e96a63b, 0x0d47ddbc, 0xa86ce512, 0x5bfd78bd,
    0xc1b1cba2, 0x01e3dafe, 0x05317b7b, 0x1fbafeae
};

/* expected CRT coefficient u = q^-1 mod p */
static const uint32 RSA_u_Expect[TEST_WORDS] =
{
    0x9f62e76a, 0xefc6690c, 0x4cfff624, 0x4a3497c4,
    0xe34596fd, 0x9a4a3734, 0xe19c9361, 0x69f3ad2a,
    0x30e4d5e0, 0x75146cb3, 0xe868f8f8, 0xf7602269,
    0x7129abe1, 0xb8f5ac9c, 0xee2fc550, 0x739005ad
};

/* expected dp = d mod (p - 1) */
static const uint32 RSA_dp_Expect[TEST_WORDS] =
{
    0x71136c29, 0x1e53eb32, 0x1aa8f053, 0xea98358b,
    0x01c32917, 0x81ea04e3, 0x9c86c02d, 0xd33e72f7,
    0x1617f5ca, 0xf477699a, 0xf71b4aab, 0x8f865f98,
    0x526c52bd, 0xa06433e3, 0x2deae849, 0x428b05cf
};

/* expected dq = d mod (q - 1) */
static const uint32 RSA_dq_Expect[TEST_WORDS] =
{
    0x38276595, 0x70ce3ee3, 0xc9fba496, 0x1401d532,
    0x386d1a27, 0xb0725aeb, 0xec4461d7, 0x1bd114f7,
    0x1cf75598, 0x7f9ae2cb, 0xfbec8f76, 0x22d1d624,
    0xb1a28354, 0x4777d29e, 0x38cf0e16, 0x59c3ea0e
};

/* low half of the ciphertext */
static const uint32 RSA_C_lo[TEST_WORDS] =
{
    0x098ba512, 0x7f372626, 0x2f7d2350, 0xb30a47e1,
    0x7948e370, 0xa1b82150, 0x509ff117, 0x8909db12,
    0x4fce49d7, 0x6bb75157, 0xa082e9fd, 0x9d33a400,
    0x19133276, 0xd11018c1, 0x81f08e54, 0x48f22cdc
};

/* high half of the ciphertext */
static const uint32 RSA_C_hi[TEST_WORDS] =
{
    0x28d1856c, 0xd97faa55, 0x67f6ee51, 0xa11fed7c,
    0x67dca545, 0xfab760ba, 0x836baa58, 0x2f08cebe,
    0x83ee56fd, 0xc848dec2, 0xff805834, 0xafd78437,
    0x2655914e, 0x1e8dbe57, 0x2d1135fb, 0x1e2571b6
};

/* expected low half of the plaintext */
static const uint32 RSA_M_lo_Expect[TEST_WORDS] =
{
    0xba2963ab, 0x161816a4, 0x18186a3b, 0xac1c3532,
    0xf5c1a0d8, 0x395df156, 0xc39ec382, 0x65cca13c,
    0xd7126631, 0x6e24fe8f, 0x3b351c34, 0x6c15022e,
    0x108ffe0a, 0x683bc426, 0x0b033bd3, 0x8027a8b1
};

/* expected high half of the plaintext */
static const uint32 RSA_M_hi_Expect[TEST_WORDS] =
{
    0xe578f152, 0x30c7bd57, 0xbd8e09ba, 0x9b3085d1,
    0x64b2b50f, 0x78792067, 0xb43e0c36, 0xfeb40714,
    0xfd1fb370, 0xa6aa548e, 0x226f6f1a, 0x3652ee77,
    0x8e106f5a, 0xba97e9c5, 0x9d5853cb, 0x077355ae
};

/* measured CRT parameters */
static uint32 RSA_u_Result[TEST_WORDS];
static uint32 RSA_dp_Result[TEST_WORDS];
static uint32 RSA_dq_Result[TEST_WORDS];

/* measured Montgomery precomputation values */
static uint32 RSA_p_prime[TEST_WORDS];
static uint32 RSA_r2_mod_p[TEST_WORDS];
static uint32 RSA_q_prime[TEST_WORDS];
static uint32 RSA_r2_mod_q[TEST_WORDS];

/* measured plaintext halves */
static uint32 RSA_M_lo_Result[TEST_WORDS];
static uint32 RSA_M_hi_Result[TEST_WORDS];


/* Private functions ---------------------------------------------------------*/
int main(void)
{
    uint32 written = 0U;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL, 90 MHz core clock) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);

    printf("\r\n ***** PKA RSA-1024 CRT decryption test ***** \r\n");
    delay_ms(500U);

    /* Initialize the PKA handle: the low level callback enables the DSE clock
       and releases the domain reset */
    __HAL_CLEAR_STRUCT(&hpka_dev);
    hpka_dev.Instance = PKA;
    HAL_PKA_StructInit(&pka_init);
    (void)HAL_PKA_Init(&hpka_dev, &pka_init);

    Section("firmware and operand memory");
    Check("micro-code image loaded", (Pka_LoadFirmware() == HAL_OK) ? 1U : 0U);
    Check("operand window cleared", (Pka_ClearMemory() == HAL_OK) ? 1U : 0U);

    for (;;)
    {
        /* ------------------------------------------- CRT key setup (0x17) */
        Section("CRT key setup: u / dp / dq");

        written  = (Pka_Write(PKA_RSA_ADDR_512_D0, RSA_p, TEST_WORDS) == HAL_OK) ? 1U : 0U;
        written &= (Pka_Write(PKA_RSA_ADDR_512_B1, RSA_q, TEST_WORDS) == HAL_OK) ? 1U : 0U;
        written &= (Pka_Write(PKA_RSA_ADDR_512_D1, RSA_d_lo, TEST_WORDS) == HAL_OK) ? 1U : 0U;
        written &= (Pka_Write(PKA_RSA_ADDR_512_D3, RSA_d_hi, TEST_WORDS) == HAL_OK) ? 1U : 0U;
        Check("p / q / d_lo / d_hi written", written);

        Check("CRT key setup completed",
              (Pka_Run(TEST_EP_CRT_SETUP, TEST_BASE_RADIX) == HAL_OK) ? 1U : 0U);

        (void)Pka_Read(PKA_RSA_ADDR_512_A3, RSA_u_Result, TEST_WORDS);
        (void)Pka_Read(PKA_RSA_ADDR_512_B1, RSA_dp_Result, TEST_WORDS);
        (void)Pka_Read(PKA_RSA_ADDR_512_C0, RSA_dq_Result, TEST_WORDS);

        Check("CRT coefficient u matches the expected vector",
              Pka_Compare(RSA_u_Result, RSA_u_Expect, TEST_WORDS));
        Pka_Report("u", RSA_u_Result, RSA_u_Expect, TEST_WORDS);
        Check("dp matches the expected vector",
              Pka_Compare(RSA_dp_Result, RSA_dp_Expect, TEST_WORDS));
        Pka_Report("dp", RSA_dp_Result, RSA_dp_Expect, TEST_WORDS);
        Check("dq matches the expected vector",
              Pka_Compare(RSA_dq_Result, RSA_dq_Expect, TEST_WORDS));
        Pka_Report("dq", RSA_dq_Result, RSA_dq_Expect, TEST_WORDS);

        /* ------------------------------- Montgomery precomputation of p --- */
        Section("Montgomery precomputation of the prime factors");

        (void)Pka_Write(PKA_RSA_ADDR_512_D0, RSA_p, TEST_WORDS);
        Check("p: precomputation of r^-1 / p' / r^2 mod p completed",
              Pka_Montgomery());
        (void)Pka_Read(PKA_RSA_ADDR_512_D1, RSA_p_prime, TEST_WORDS);
        (void)Pka_Read(PKA_RSA_ADDR_512_D3, RSA_r2_mod_p, TEST_WORDS);

        (void)Pka_Write(PKA_RSA_ADDR_512_D0, RSA_q, TEST_WORDS);
        Check("q: precomputation of r^-1 / q' / r^2 mod q completed",
              Pka_Montgomery());
        (void)Pka_Read(PKA_RSA_ADDR_512_D1, RSA_q_prime, TEST_WORDS);
        (void)Pka_Read(PKA_RSA_ADDR_512_D3, RSA_r2_mod_q, TEST_WORDS);

        Pka_PrintWords("p'", RSA_p_prime, TEST_WORDS);
        Pka_PrintWords("q'", RSA_q_prime, TEST_WORDS);

        /* -------------------------- CRT modular exponentiation (0x18) ----- */
        Section("CRT modular exponentiation M = C^d mod n");

        written  = (Pka_Write(PKA_RSA_ADDR_512_A2, RSA_C_lo, TEST_WORDS) == HAL_OK) ? 1U : 0U;
        written &= (Pka_Write(PKA_RSA_ADDR_512_A3, RSA_C_hi, TEST_WORDS) == HAL_OK) ? 1U : 0U;
        written &= (Pka_Write(PKA_RSA_ADDR_512_B2, RSA_p, TEST_WORDS) == HAL_OK) ? 1U : 0U;
        written &= (Pka_Write(PKA_RSA_ADDR_512_B3, RSA_q, TEST_WORDS) == HAL_OK) ? 1U : 0U;
        written &= (Pka_Write(PKA_RSA_ADDR_512_C2, RSA_u_Result, TEST_WORDS) == HAL_OK) ? 1U : 0U;
        written &= (Pka_Write(PKA_RSA_ADDR_512_C3, RSA_dp_Result, TEST_WORDS) == HAL_OK) ? 1U : 0U;
        written &= (Pka_Write(PKA_RSA_ADDR_512_D2, RSA_dq_Result, TEST_WORDS) == HAL_OK) ? 1U : 0U;
        written &= (Pka_Write(PKA_RSA_ADDR_512_D5, RSA_r2_mod_p, TEST_WORDS) == HAL_OK) ? 1U : 0U;
        written &= (Pka_Write(PKA_RSA_ADDR_512_D4, RSA_p_prime, TEST_WORDS) == HAL_OK) ? 1U : 0U;
        written &= (Pka_Write(PKA_RSA_ADDR_512_D3, RSA_r2_mod_q, TEST_WORDS) == HAL_OK) ? 1U : 0U;
        written &= (Pka_Write(PKA_RSA_ADDR_512_D6, RSA_q_prime, TEST_WORDS) == HAL_OK) ? 1U : 0U;
        Check("eleven CRT operands written", written);

        Check("CRT exponentiation completed",
              (Pka_Run(TEST_EP_CRT_EXP, TEST_BASE_RADIX) == HAL_OK) ? 1U : 0U);

        (void)Pka_Read(PKA_RSA_ADDR_512_A0, RSA_M_lo_Result, TEST_WORDS);
        (void)Pka_Read(PKA_RSA_ADDR_512_A1, RSA_M_hi_Result, TEST_WORDS);

        Check("plaintext low half matches the expected vector",
              Pka_Compare(RSA_M_lo_Result, RSA_M_lo_Expect, TEST_WORDS));
        Pka_Report("plaintext low", RSA_M_lo_Result, RSA_M_lo_Expect, TEST_WORDS);
        Check("plaintext high half matches the expected vector",
              Pka_Compare(RSA_M_hi_Result, RSA_M_hi_Expect, TEST_WORDS));
        Pka_Report("plaintext high", RSA_M_hi_Result, RSA_M_hi_Expect, TEST_WORDS);

        Pka_PrintWords("M low", RSA_M_lo_Result, TEST_WORDS);
        Pka_PrintWords("M high", RSA_M_hi_Result, TEST_WORDS);

        /* ------------------------------------------------------- summary --- */
        printf("\r\nchecks = %u | summary : failures = %u\r\n",
               PRINT_U32(checks), PRINT_U32(failures));

        delay_ms(TEST_POLL_MS);
    }
}

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Report a section title.
 * @param  name: section name.
 * @retval None
 */
static void Section(const char *name)
{
    printf("\r\n-- %s --\r\n", name);
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    checks++;

    if (condition == 0U)
    {
        failures++;
    }
    printf("%-56s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Load the PKA micro-code image through the HAL API.
 * @retval HAL status of HAL_PKA_LoadFirmware().
 */
static HAL_StatusTypeDef Pka_LoadFirmware(void)
{
    return HAL_PKA_LoadFirmware(&hpka_dev, pka_fw_addr, pka_fw_data, PKA_FW_LENGTH);
}

/**
 * @brief  Clear the whole operand window through the HAL API.
 * @retval HAL status of HAL_PKA_WriteData().
 */
static HAL_StatusTypeDef Pka_ClearMemory(void)
{
    return HAL_PKA_WriteData(&hpka_dev, PKA_OPERAND_WINDOW_FIRST, pka_zero,
                             PKA_OPERAND_WINDOW_WORDS_MAX);
}

/**
 * @brief  Write one operand through the HAL API.
 * @param  address: absolute operand address (PKA_RSA_ADDR_*).
 * @param  data: source words.
 * @param  words: number of 32-bit words.
 * @retval HAL status of HAL_PKA_WriteData().
 * @note   The HAL API takes a byte offset from the instance base, while the
 *         address macros of the device header are absolute addresses, so the
 *         base is subtracted here.  The data cache is cleaned afterwards, so
 *         the accelerator observes the values that were just written.
 */
static HAL_StatusTypeDef Pka_Write(uint32 address, const uint32 *data, uint32 words)
{
    HAL_StatusTypeDef status;

    status = HAL_PKA_WriteData(&hpka_dev, address - PKA_BASE, data, words);
    CLEAR_CACHE();

    return status;
}

/**
 * @brief  Read one operand through the HAL API.
 * @param  address: absolute operand address (PKA_RSA_ADDR_*).
 * @param  data: destination words.
 * @param  words: number of 32-bit words to read.
 * @retval HAL status of HAL_PKA_ReadData().
 * @note   The cache is cleaned before the read so the result that the
 *         accelerator wrote is fetched from the operand memory.
 */
static HAL_StatusTypeDef Pka_Read(uint32 address, uint32 *data, uint32 words)
{
    HAL_StatusTypeDef status;

    CLEAR_CACHE();
    status = HAL_PKA_ReadData(&hpka_dev, address - PKA_BASE, data, words);

    return status;
}

/**
 * @brief  Run the three Montgomery precomputation entries for one modulus.
 * @retval 1 when all three operations completed, 0 otherwise.
 * @note   The reference material repeats the very same three-entry sequence
 *         for p and for q, so it is factored out here.  Entry 0x11 reads the
 *         modulus from D0 and leaves r^-1 in C0, which the two following
 *         entries use; they leave m' in D1 and r^2 mod m in D3.
 */
static uint32 Pka_Montgomery(void)
{
    if (Pka_Run(TEST_EP_RINV, TEST_BASE_RADIX) != HAL_OK)
    {
        return 0U;
    }
    if (Pka_Run(TEST_EP_MPRIME, TEST_BASE_RADIX) != HAL_OK)
    {
        return 0U;
    }
    if (Pka_Run(TEST_EP_R2, TEST_BASE_RADIX) != HAL_OK)
    {
        return 0U;
    }

    return 1U;
}

/**
 * @brief  Run one micro-code operation.
 * @param  entry: program entry point (word index of the micro-code region).
 * @param  radix: base radix encoding of the operation.
 * @retval HAL_OK when the operation completed, HAL_TIMEOUT when DONE never
 *         came within the guard, otherwise the status of the HAL call that
 *         failed.
 * @note   Sequence of the reference material, expressed with HAL calls only:
 *         clear the stack, set the entry point, start by writing CTRL.GO,
 *         poll STAT.DONE, stop by clearing CTRL.GO and acknowledge DONE.
 *         The GO bit is carried by the Init structure, so the start and the
 *         stop are two HAL_PKA_Init() calls.
 */
static HAL_StatusTypeDef Pka_Run(uint32 entry, uint32 radix)
{
    PKA_InitTypeDef   cfg;
    HAL_StatusTypeDef status;
    uint32            guard;

    (void)HAL_PKA_ClearStack(&hpka_dev);
    (void)HAL_PKA_SetEntryPoint(&hpka_dev, entry);

    /* Start: PKA_Go = PKA_GO_EN in the configuration structure */
    HAL_PKA_StructInit(&cfg);
    cfg.PKA_PartialRadix = TEST_PARTIAL_RADIX;
    cfg.PKA_BaseRadix    = radix;
    cfg.PKA_Go           = PKA_GO_EN;

    status = HAL_PKA_Init(&hpka_dev, &cfg);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Wait for the completion flag (bounded, so a failure cannot hang) */
    guard = TEST_WAIT_GUARD;
    while ((HAL_PKA_GetStatStatus(&hpka_dev, PKA_STATE_DONE) == RESET) && (guard != 0U))
    {
        guard--;
    }
    if (guard == 0U)
    {
        return HAL_TIMEOUT;
    }
    CLEAR_CACHE();

    /* The operand window is locked while the accelerator executes, so wait
       for the idle flag before the next register access */
    guard = TEST_WAIT_GUARD;
    while (((READ_REG(hpka_dev.Instance->RTN_CODE) & PKA_RTN_CODE_BUSY_Msk) != 0U) &&
           (guard != 0U))
    {
        guard--;
    }

    /* Stop: PKA_Go = PKA_GO_DIS */
    HAL_PKA_StructInit(&cfg);
    cfg.PKA_PartialRadix = TEST_PARTIAL_RADIX;
    cfg.PKA_BaseRadix    = radix;
    cfg.PKA_Go           = PKA_GO_DIS;
    (void)HAL_PKA_Init(&hpka_dev, &cfg);

    /* Acknowledge the completion so the next operation starts clean */
    HAL_PKA_ClearStatus(&hpka_dev, PKA_STATE_DONE);

    return HAL_OK;
}

/**
 * @brief  Compare a result vector against its expectation.
 * @param  result: measured words.
 * @param  expect: expected words.
 * @param  words: number of 32-bit words to compare.
 * @retval 1 when every word matches, 0 otherwise.
 */
static uint32 Pka_Compare(const uint32 *result, const uint32 *expect, uint32 words)
{
    uint32 i;

    for (i = 0U; i < words; i++)
    {
        if (result[i] != expect[i])
        {
            return 0U;
        }
    }

    return 1U;
}

/**
 * @brief  Print one result word group next to the expectation when they differ.
 * @param  name: label of the group.
 * @param  result: measured words.
 * @param  expect: expected words.
 * @param  words: number of words.
 * @retval None
 */
static void Pka_Report(const char *name, const uint32 *result, const uint32 *expect,
                       uint32 words)
{
    uint32 i;

    for (i = 0U; i < words; i++)
    {
        if (result[i] != expect[i])
        {
            printf("%-56s word[%u] = 0x%08X, expected 0x%08X\r\n", name, PRINT_U32(i),
                   PRINT_U32(result[i]), PRINT_U32(expect[i]));
            return;
        }
    }
}

/**
 * @brief  Print the four most significant words of a vector.
 * @param  name: label of the vector.
 * @param  data: words to print.
 * @param  words: number of words in the vector.
 * @retval None
 */
static void Pka_PrintWords(const char *name, const uint32 *data, uint32 words)
{
    printf("%-8s = %08X %08X %08X %08X (high) \r\n", name,
           PRINT_U32(data[words - 1U]), PRINT_U32(data[words - 2U]),
           PRINT_U32(data[words - 3U]), PRINT_U32(data[words - 4U]));
}

/**
 * @brief  PKA low level initialization: instance clock gate and reset release.
 * @param  hpka: PKA handle.
 * @retval None
 * @note   The PKA is clocked by the AXILite4-Bus1 (DSE) domain, gated by the
 *         SMU, so the low level callback enables that gate and releases the
 *         reset of the domain.
 */
void HAL_PKA_MspInit(HAL_PKA_HandleTypeDef *hpka)
{
    if (hpka == NULL_PTR)
    {
        return;
    }

    __HAL_SMU_DSE_CLK_ENABLE();
    __HAL_SMU_DSE_FORCE_RESET();
    __HAL_SMU_DSE_RELEASE_RESET();
}

/**
 * @brief  Configure the system clock and the bus gates.
 * @retval None
 * @note   Same clock tree as the other HAL integration suites: the PLL is fed
 *         by the external oscillator (VCO 180 MHz) and the buses run at
 *         AXI4Bus3 / 2, APBBus0 / 2, APBBus1 / 2 and CANX2 / 8, which keeps
 *         the console USART on its usual 22.5 MHz.
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    smu_osc;
    SMU_ClockInitTypeDef  smu_clock;
    SMU_ClocksTypeDef     smu_clocks;
    HAL_PMU_HandleTypeDef hpmu;

    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Raise the core rail trim before the PLL is switched, as the other HAL
       integration suites do: the 1.2 V LDO APIs are gated on the handle state,
       so the PMU must be initialized first */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    __HAL_CLEAR_STRUCT(&smu_osc);
    smu_osc.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    smu_osc.FIRCState            = SMU_FIRC_ON;
    smu_osc.FIRCCalibrationValue = 0x00U;
    smu_osc.PLL.PLLState         = SMU_PLL_ON;
    smu_osc.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    smu_osc.PLL.PLLDivR          = 0x04U;
    smu_osc.PLL.PLLDivQ          = 0x01U;
    smu_osc.PLL.PLLDivN          = 0x14U;
    smu_osc.PLL.PLLDivF          = 0xB4U;
    smu_osc.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    (void)HAL_SMU_OscConfig(&hsmu_clk, &smu_osc, SMU_TIMEOUT_DEFAULT);

    /* Bus dividers */
    __HAL_CLEAR_STRUCT(&smu_clock);
    smu_clock.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    smu_clock.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    smu_clock.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    smu_clock.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &smu_clock);

    (void)HAL_SMU_GetClocksFreq(&smu_clocks);
}

/*****END OF FILE*****/
