/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):    Xiamen Guoke Anxin Technology Co., LTD
 * FileName:         as32x601_hal_pka.c
 * Author:           ANSILIC APPLICATION GROUP
 * Version:         V1.4
 * Date:   2026/11/05
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/09/04     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/07     1.1     align with the library
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.2     align the module with the library
 *                                                       architecture spec (resource lock and
 *                                                       RTOS chapters): give the lock helper
 *                                                       a Timeout parameter and a NULL mutex
 *                                                       guard, add the shared validity and
 *                                                       state helpers, run the MSP callbacks
 *                                                       outside the locked region, validate
 *                                                       the arguments at run time, apply the
 *                                                       busy / reset state gate to the
 *                                                       register writing interfaces, report
 *                                                       the guard path of every locked entry
 *                                                       point and yield the CPU while polling
 *                                                       conventions: module
 *                                                       switch guard, shared
 *                                                       lock helpers
 *                                                       (PKA_LockHandle /
 *                                                       PKA_UnlockHandle,
 *                                                       RTOS branch uses the
 *                                                       LockMutex handle),
 *                                                       NULL guards on every
 *                                                       public function,
 *                                                       Version+Size init
 *                                                       structure, error code
 *                                                       field + HAL_PKA_GetError()
 *     ANSILIC APPLICATION GROUP  2026/10/09     1.3     restore the " *" prefix of the history
 *                                                       continuation lines
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Public Key Accelerator
 *                  (PKA) peripheral:
 *                  - Initialization and de-initialization (HAL_PKA_Init /
 *                    HAL_PKA_DeInit), configuration structure handling;
 *                  - Interrupt / flag management: HAL_PKA_ITConfig(),
 *                    HAL_PKA_GetStatStatus(), HAL_PKA_GetFlagStatus(),
 *                    HAL_PKA_ClearStatus() and HAL_PKA_IRQHandler();
 *                  - Program entry point / stack: HAL_PKA_SetEntryPoint(),
 *                    HAL_PKA_SetStackPointer() and HAL_PKA_ClearStack();
 *                  - Firmware load and operand memory access:
 *                    HAL_PKA_LoadFirmware(), HAL_PKA_WriteData() and
 *                    HAL_PKA_ReadData();
 *                  - Status / state: HAL_PKA_GetStopReasonCode(),
 *                    HAL_PKA_GetState() and HAL_PKA_GetError().
 *
 *                  Typical usage (see the RSA / ECC examples):
 *                  (#) Call HAL_PKA_MspInit() (clock enable through the SMU,
 *                      PLIC interrupt enable);
 *                  (#) Fill a PKA_InitTypeDef structure with
 *                      HAL_PKA_StructInit() or manually, then call
 *                      HAL_PKA_Init() with the handle;
 *                  (#) Load the PKA micro-code with HAL_PKA_LoadFirmware()
 *                      and the operands with HAL_PKA_WriteData();
 *                  (#) Set the entry point / stack with
 *                      HAL_PKA_SetEntryPoint() / HAL_PKA_SetStackPointer(),
 *                      then fire the operation by re-running HAL_PKA_Init()
 *                      with PKA_Go = PKA_GO_EN;
 *                  (#) Wait for the completion by polling STAT.DONE
 *                      (HAL_PKA_GetStatStatus) or by the PKA interrupt
 *                      (HAL_PKA_IRQHandler), then read the result with
 *                      HAL_PKA_ReadData().
 * @complexity  Simple
 *              Polling only (command-driven), lock + state machine,
 *              interrupt flag / handler support.
 */
#include "as32x601_hal.h"          /* HAL common types and utilities          */
#include "as32x601_hal_pka.h"      /* PKA HAL API and register macros         */

/* The HAL_PKA_MODULE_ENABLED switch is provided by the user configuration
 * file (as32x601_hal_conf.h, included above through as32x601_hal.h): the
 * whole implementation is compiled only while the module is enabled. */
#ifdef HAL_PKA_MODULE_ENABLED

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Accumulates a parameter-class error without touching the state.
 * @note   The update runs in a short critical section so a concurrent reader
 *         observes the complete value.  A rejected parameter is not a
 *         hardware event, so the state is deliberately left unchanged.
 * @param  hpka: pointer to a valid HAL_PKA_HandleTypeDef structure.
 * @retval None
 */
static void PKA_ReportParamError(HAL_PKA_HandleTypeDef *hpka)
{
    uint32 irq;

    irq = __disable_irq_and_save();
    hpka->ErrorCode |= HAL_PKA_ERROR_INVALID_PARAM;
    __restore_irq(irq);
}

/**
 * @brief  Check whether the PKA handle and its instance are valid.
 * @param  hpka: pointer to a HAL_PKA_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
uint32 PKA_HandleIsValid(HAL_PKA_HandleTypeDef *hpka)
{
    if (hpka == NULL_PTR)
    {
        return 0U;
    }

    if (IS_PKA_ALL_INSTANCE(hpka->Instance) == 0U)
    {
        return 0U;
    }

    return 1U;
}

/**
 * @brief  Check whether the handle accepts a new operation.
 * @note   ARCH-CONST-09: a handle that is BUSY (an operation is ongoing in
 *         another context) rejects any other operation with HAL_BUSY, an
 *         uninitialized handle (RESET) requires HAL_PKA_Init() first and
 *         is rejected with HAL_ERROR, while the recoverable state (ERROR)
 *         accepts a new operation directly.
 * @param  hpka: pointer to a HAL_PKA_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK (accepted) / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef PKA_CheckState(HAL_PKA_HandleTypeDef *hpka)
{
    if (hpka->State == HAL_PKA_STATE_BUSY)
    {
        return HAL_BUSY;
    }

    if (hpka->State == HAL_PKA_STATE_RESET)
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Validates one configuration structure against the manual's domains.
 * @note   The partial radix must not exceed the word count of the selected
 *         base (8 / 16 / 32 / 64 / 128 words for a 256 / 512 / 1024 / 2048 /
 *         4096-bit base) and the Mersenne M-521 mode accepts only its
 *         documented 17-word length.  This is the reason a 17-word default
 *         paired with a 256-bit base is rejected instead of silently
 *         producing a truncated operand.
 * @param  Init: pointer to a PKA_InitTypeDef structure.
 * @retval uint32: 1 when every field is inside its domain, 0 otherwise.
 */
uint32 PKA_IsConfigurationValid(const PKA_InitTypeDef *Init)
{
    uint32 radix_words;

    if ((Init == NULL_PTR) ||
        (IS_PKA_PARTIAL_RADIX(Init->PKA_PartialRadix) == 0U) ||
        (IS_PKA_BASE_RADIX(Init->PKA_BaseRadix) == 0U) ||
        (IS_PKA_M521_MODE(Init->PKA_M521Mode) == 0U) ||
        (IS_PKA_STOP_RQST(Init->PKA_StopRqst) == 0U) ||
        (IS_PKA_GO(Init->PKA_Go) == 0U) ||
        (IS_PKA_ALT_ACCESS(Init->PKA_AltAccess) == 0U) ||
        (IS_PKA_ENDIAN_SWAP(Init->PKA_EndianSwap) == 0U))
    {
        return 0U;
    }

    /* 256 / 512 / 1024 / 2048 / 4096-bit base with 32-bit words gives
     * 8 / 16 / 32 / 64 / 128 words (encoding 2..6 -> exponent 3..7). */
    radix_words = (uint32)1U << ((uint32)Init->PKA_BaseRadix + 1U);
    if (Init->PKA_PartialRadix > radix_words)
    {
        return 0U;
    }

    /* The M-521 mode has a single legal length. */
    if ((Init->PKA_M521Mode == PKA_M521_MODE_M521) &&
        (Init->PKA_PartialRadix != PKA_PARTIAL_RADIX_M521))
    {
        return 0U;
    }

    return 1U;
}

/**
 * @brief  Lock the handle (RTOS mutex or single core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_PKA_MspInit()). The bare metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; the value is passed to HAL_MutexAcquire() as
 *         is (RTOS ticks; HAL_MAX_DELAY means an infinite wait).
 * @param  hpka: pointer to a HAL_PKA_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef PKA_LockHandle(HAL_PKA_HandleTypeDef *hpka, uint32 Timeout)
{
#if (USE_RTOS == 1)
    if (hpka->LockMutex == NULL_PTR)
    {
        /* The porting layer did not create the mutex (e.g. HAL_PKA_MspInit()
         * was not overridden): report it instead of calling the RTOS with an
         * invalid mutex handle */
        return HAL_ERROR;
    }

    return HAL_MutexAcquire(hpka->LockMutex, Timeout);
#else
    /* Prevent unused argument compilation warning: the bare metal lock flag
     * either succeeds immediately or reports HAL_BUSY, it never waits */
    UNUSED(Timeout);

    if (hpka->Lock == HAL_LOCKED)
    {
        return HAL_BUSY;
    }

    hpka->Lock = HAL_LOCKED;

    return HAL_OK;
#endif /* USE_RTOS */
}

/**
 * @brief  Unlock the handle.
 * @param  hpka: pointer to a HAL_PKA_HandleTypeDef structure.
 * @retval None
 */
void PKA_UnlockHandle(HAL_PKA_HandleTypeDef *hpka)
{
#if (USE_RTOS == 1)
    (void)HAL_MutexRelease(hpka->LockMutex);
#else
    hpka->Lock = HAL_UNLOCKED;
#endif /* USE_RTOS */
}

/* Exported functions ---------------------------------------------------------*/

/** @addtogroup PKA_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Fills a PKA_InitTypeDef structure with the reset default values. (NON-BLOCKING)
 * @note   This is the HAL equivalent of the legacy PKA_Struct(): it resets
 *         every field of the configuration structure to its default value
 *         and sets the Size / Version metafields.
 * @param  Init: pointer to the PKA_InitTypeDef structure to be filled.
 * @retval None
 */
void HAL_PKA_StructInit(PKA_InitTypeDef *Init)
{
    /* Check the parameters */
    if (Init == NULL_PTR)
    {
        return;
    }

    Init->Size           = sizeof(PKA_InitTypeDef);   /*!< sizeof struct */
    Init->Version        = PKA_INIT_VERSION;          /*!< V1            */
    /* Eight words are the complete effective length of the 256-bit base
     * selected just below, so the default is a valid, untruncated
     * configuration.  17 is the M-521 length, not a 256-bit one. */
    Init->PKA_PartialRadix = 8U;
    Init->PKA_BaseRadix  = PKA_BASE_RADIX_256;
    Init->PKA_M521Mode   = 0U;
    Init->PKA_StopRqst   = PKA_STOP_RQST_DIS;
    Init->PKA_Go         = PKA_GO_DIS;
    Init->PKA_AltAccess  = PKA_ALT_ACCESS_NORMAL;
    Init->PKA_EndianSwap = PKA_ENDIAN_SWAP_LITTLE;
    Init->Reserved[0]    = 0U;                         /*!< Reserved for future use */
    Init->Reserved[1]    = 0U;                         /*!< Reserved for future use */
}

/**
 * @brief  Initializes the PKA peripheral. (NON-BLOCKING)
 * @note   The PKA runs as a command-driven coprocessor: the operation is
 *         started by the CTRL.GO bit. This function applies the
 *         PKA_InitTypeDef structure to the CONFIG register (alternate
 *         access / endian swap) and to the CTRL register (partial radix /
 *         base radix / M521 mode / stop request / GO). The GO field is a
 *         start trigger: the example fires an operation by re-running
 *         the init with PKA_Go = PKA_GO_EN and stops it with GO_DIS.
 * @param  hpka: pointer to a HAL_PKA_HandleTypeDef structure that contains
 *         the configuration information for PKA.
 * @param  Init: pointer to a PKA_InitTypeDef structure that contains the
 *         configuration for the PKA control registers.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_PKA_Init(HAL_PKA_HandleTypeDef *hpka, const PKA_InitTypeDef *Init)
{
    uint32 temp = 0U;
    uint32 first_init = 0U;

    /* Check the PKA handle allocation */
    if (PKA_HandleIsValid(hpka) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_PKA_ALL_INSTANCE(hpka->Instance));
    assert_param(Init != NULL_PTR);
    assert_param(IS_PKA_BASE_RADIX(Init->PKA_BaseRadix));
    assert_param(IS_PKA_STOP_RQST(Init->PKA_StopRqst));
    assert_param(IS_PKA_GO(Init->PKA_Go));
    assert_param(IS_PKA_ALT_ACCESS(Init->PKA_AltAccess));
    assert_param(IS_PKA_ENDIAN_SWAP(Init->PKA_EndianSwap));

    /* Run time validation, so that the checks stay effective in a build with
     * the assertions disabled. The metafields of the configuration structure
     * (Size / Version, architecture spec section 22) and the two reserved words
     * are validated as well. A rejected call neither takes the lock nor changes
     * the handle state nor touches a register. */
    if ((Init == NULL_PTR) ||
        (IS_PKA_ALL_INSTANCE(hpka->Instance) == 0U) ||
        (Init->Size != sizeof(PKA_InitTypeDef)) ||
        (Init->Version != PKA_INIT_VERSION) ||
        (Init->Reserved[0] != 0U) ||
        (Init->Reserved[1] != 0U) ||
        (PKA_IsConfigurationValid(Init) == 0U))
    {
        PKA_ReportParamError(hpka);
        return HAL_ERROR;
    }

    /* Allocate the lock resource before its first use, so that a handle that
     * was never initialized cannot report HAL_BUSY from a stale Lock field.
     * LOCK-06 / MSP-04: the low level initialization runs before the handle is
     * locked, so that an override which calls other HAL APIs cannot deadlock. */
    if (hpka->State == HAL_PKA_STATE_RESET)
    {
        hpka->Lock = HAL_UNLOCKED;

        /* Init the low level hardware: clock, interrupt */
        HAL_PKA_MspInit(hpka);
    }

    /* Remember whether this call starts the module, so a failed lock
     * acquisition can roll the preparation back (P1-8). */
    first_init = (hpka->State == HAL_PKA_STATE_RESET) ? 1U : 0U;
    (void)first_init;

    /* Process locked */
    if (PKA_LockHandle(hpka, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        if (first_init != 0U)
        {
            /* Pair the preparation this call already performed. */
            HAL_PKA_MspDeInit(hpka);
            hpka->State = HAL_PKA_STATE_RESET;
        }
        return HAL_BUSY;
    }

    /* Hardware gate: the manual locks the operand window while the
     * accelerator executes, so a running program rejects a reconfiguration
     * of the control registers as well. */
    if ((READ_REG(hpka->Instance->RTN_CODE) & PKA_RTN_CODE_BUSY_Msk) != 0U)
    {
        PKA_UnlockHandle(hpka);
        return HAL_BUSY;
    }

    /* Clear the error code and change the PKA peripheral state */
    hpka->ErrorCode = HAL_PKA_ERROR_NONE;
    hpka->State = HAL_PKA_STATE_BUSY;

    /* Update the CONFIG register (read-modify-write on a local copy) */
    temp = hpka->Instance->CONFIG;

    /* Set PKA alternate access mode */
    CLEAR_BIT(temp, (uint32)PKA_CONFIG_ALT_ACCESS);
    SET_BIT(temp, (uint32)(Init->PKA_AltAccess) << PKA_CONFIG_ALT_ACCESS_Pos);

    /* Set PKA endian swap mode */
    CLEAR_BIT(temp, (uint32)PKA_CONFIG_ENDIAN_SWAP);
    SET_BIT(temp, (uint32)(Init->PKA_EndianSwap) << PKA_CONFIG_ENDIAN_SWAP_Pos);

    hpka->Instance->CONFIG = temp;

    /* Update the CTRL register (read-modify-write on a local copy) */
    temp = hpka->Instance->CTRL;

    /* Set PKA partial radix */
    CLEAR_BIT(temp, (uint32)PKA_CTRL_PARTIAL_RADIX);
    SET_BIT(temp, (uint32)(Init->PKA_PartialRadix) << PKA_CTRL_PARTIAL_RADIX_Pos);

    /* Set PKA base radix */
    CLEAR_BIT(temp, (uint32)PKA_CTRL_BASE_RADIX);
    SET_BIT(temp, (uint32)(Init->PKA_BaseRadix) << PKA_CTRL_BASE_RADIX_Pos);

    /* Set PKA M521 mode */
    CLEAR_BIT(temp, (uint32)PKA_CTRL_M521_MODE);
    SET_BIT(temp, (uint32)(Init->PKA_M521Mode) << PKA_CTRL_M521_MODE_Pos);

    /* Set PKA stop request */
    CLEAR_BIT(temp, (uint32)PKA_CTRL_STOP_RQST);
    SET_BIT(temp, (uint32)(Init->PKA_StopRqst) << PKA_CTRL_STOP_RQST_Pos);

    /* Set PKA GO */
    CLEAR_BIT(temp, (uint32)PKA_CTRL_GO);
    SET_BIT(temp, (uint32)(Init->PKA_Go) << PKA_CTRL_GO_Pos);

    hpka->Instance->CTRL = temp;

    /* Store the applied configuration in the handle */
    hpka->Init = *Init;

    /* Initialize the PKA state */
    hpka->State = HAL_PKA_STATE_READY;

    /* Release Lock */
    PKA_UnlockHandle(hpka);

    return HAL_OK;
}

/**
 * @brief  De-initializes the PKA peripheral. (NON-BLOCKING)
 * @note   The PKA has no dedicated clock enable/disable in the driver (the
 *         DSE clock is gated at the SMU level). The de-initialization
 *         disables the interrupts (IRQ_EN), resets the CONFIG / CTRL /
 *         STACK_PNTR registers and then HAL_PKA_MspDeInit() is called. The
 *         STAT / FLAGS registers are not cleared here (the STAT flags are
 *         write-0-clear by HAL_PKA_ClearStatus()).
 * @param  hpka: pointer to a HAL_PKA_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_PKA_DeInit(HAL_PKA_HandleTypeDef *hpka)
{
    /* Check the PKA handle allocation */
    if (PKA_HandleIsValid(hpka) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_PKA_ALL_INSTANCE(hpka->Instance));

    /* Process locked */
    if (PKA_LockHandle(hpka, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* An already de-initialized handle is a no-op: nothing is written and the
     * MSP teardown is not repeated. */
    if (hpka->State == HAL_PKA_STATE_RESET)
    {
        PKA_UnlockHandle(hpka);
        return HAL_OK;
    }

    /* Hardware gate: the accelerator must be stopped before its register set
     * is reset, as the manual requires for a new operation. */
    if ((READ_REG(hpka->Instance->RTN_CODE) & PKA_RTN_CODE_BUSY_Msk) != 0U)
    {
        PKA_UnlockHandle(hpka);
        return HAL_BUSY;
    }

    /* Disable the PKA interrupts */
    __HAL_PKA_DISABLE_IT(hpka, PKA_IT_SIF_ERR | PKA_IT_SIF_SBE | PKA_IT_DONE | PKA_IT_GLB);

    /* Reset the config register */
    WRITE_REG(hpka->Instance->CONFIG, 0x00U);

    /* Reset the control and entry-point registers */
    WRITE_REG(hpka->Instance->CTRL, 0x00U);
    WRITE_REG(hpka->Instance->ENTRY_PNT, 0x00U);

    /* Reset the stack pointer register */
    WRITE_REG(hpka->Instance->STACK_PNTR, 0x00U);

    /* Acknowledge a pending completion so the next round cannot look
     * finished before it started (STAT is write-one-to-clear). */
    WRITE_REG(hpka->Instance->STAT, PKA_STATE_DONE);

    /* Set PKA error code to none and reset the state */
    hpka->ErrorCode = HAL_PKA_ERROR_NONE;
    hpka->State = HAL_PKA_STATE_RESET;

    /* Release Lock */
    PKA_UnlockHandle(hpka);

    /* LOCK-06 / ARCH-CONST-04: the low level de-initialization runs OUTSIDE the
     * locked region, as the architecture specification requires for the MSP
     * callbacks ("MspDeInit is called after the unlock") */
    HAL_PKA_MspDeInit(hpka);

    return HAL_OK;
}

/**
 * @brief  Initializes the PKA MSP. (NON-BLOCKING)
 * @note   The PKA peripheral is clocked by the AXILite4-Bus1 (DSE)
 *         domain, gated by the SMU: the user must enable the DSE clock
 *         here (DSE_CLK_ENABLE() and DSE_RESET() macros of
 *         as32x601_smu.h). The PKA also has a dedicated PLIC interrupt
 *         line (PKA_IRQn = 0x0D): the user must enable it here and
 *         implement PKA_IRQ_Handler() calling HAL_PKA_IRQHandler().
 * @param  hpka: pointer to a HAL_PKA_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_PKA_MspInit(HAL_PKA_HandleTypeDef *hpka)
{
    /* Prevent unused argument(s) compilation warning */
    (void)hpka;

    /* NOTE : This function should not be modified. When the callback is needed,
              function HAL_PKA_MspInit must be implemented in the user file.
     */
}

/**
 * @brief  De-initializes the PKA MSP. (NON-BLOCKING)
 * @param  hpka: pointer to a HAL_PKA_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_PKA_MspDeInit(HAL_PKA_HandleTypeDef *hpka)
{
    /* Prevent unused argument(s) compilation warning */
    (void)hpka;

    /* NOTE : This function should not be modified. When the callback is needed,
              function HAL_PKA_MspDeInit must be implemented in the user file.
     */
}

/**
  * @}
  */

/** @addtogroup PKA_Exported_Functions_Group2 IO operation functions
  * @{
  */

/**
 * @brief  Enables or disables the selected PKA interrupt. (NON-BLOCKING)
 * @param  hpka: pointer to a HAL_PKA_HandleTypeDef structure.
 * @param  ITType: PKA interrupt type. This parameter can be one of the
 *         following values (PKA_IT_*):
 *           @arg PKA_IT_SIF_ERR
 *           @arg PKA_IT_SIF_SBE
 *           @arg PKA_IT_DONE
 *           @arg PKA_IT_GLB
 * @param  NewState: ENABLE or DISABLE.
 * @retval None
 */
void HAL_PKA_ITConfig(HAL_PKA_HandleTypeDef *hpka, uint32 ITType, FunctionalState NewState)
{
    /* Check the PKA handle allocation */
    if (PKA_HandleIsValid(hpka) == 0U)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_PKA_ALL_INSTANCE(hpka->Instance));
    assert_param(IS_PKA_IT(ITType));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Run time parameter validation, so that the checks stay effective in a
     * build with the assertions disabled. A rejected call neither takes the
     * lock nor changes the handle state nor touches a register. */
    if ((IS_PKA_IT(ITType) == 0U) || (IS_FUNCTIONAL_STATE(NewState) == 0U))
    {
        PKA_ReportParamError(hpka);
        return;
    }

    /* ARCH-CONST-09: state gate. A busy handle (an operation is ongoing in
     * another context) is rejected with HAL_BUSY, an uninitialized handle with
     * HAL_ERROR, while the recoverable state ERROR accepts the operation. */
    if (PKA_CheckState(hpka) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (PKA_LockHandle(hpka, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    /* Configure the PKA interrupt */
    if (NewState != DISABLE)
    {
        __HAL_PKA_ENABLE_IT(hpka, ITType);
    }
    else
    {
        __HAL_PKA_DISABLE_IT(hpka, ITType);
    }

    /* Release Lock */
    PKA_UnlockHandle(hpka);
}

/**
 * @brief  Gets the PKA stat status. (NON-BLOCKING)
 * @param  hpka: pointer to a HAL_PKA_HandleTypeDef structure.
 * @param  Stat: PKA stat. This parameter can be one of the following
 *         values (PKA_STATE_*):
 *           @arg PKA_STATE_SIF_ERR
 *           @arg PKA_STATE_SIF_SBE
 *           @arg PKA_STATE_DONE
 * @retval FlagStatus: SET or RESET.
 */
FlagStatus HAL_PKA_GetStatStatus(HAL_PKA_HandleTypeDef *hpka, uint32 Stat)
{
    /* Check the PKA handle allocation */
    if (PKA_HandleIsValid(hpka) == 0U)
    {
        return RESET;
    }

    /* Check the parameters */
    assert_param(IS_PKA_ALL_INSTANCE(hpka->Instance));
    assert_param(IS_PKA_IT_STATE(Stat));

    /* Return the STAT status of the selected event */
    return (FlagStatus)(READ_BIT(hpka->Instance->STAT, Stat) != 0U);
}

/**
 * @brief  Gets the PKA flag status. (NON-BLOCKING)
 * @param  hpka: pointer to a HAL_PKA_HandleTypeDef structure.
 * @param  Flag: PKA flag. This parameter can be one of the following
 *         values (PKA_FLAG_*):
 *           @arg PKA_FLAG_ZERO
 *           @arg PKA_FLAG_MEMORYTEST
 *           @arg PKA_FLAG_BORROW
 *           @arg PKA_FLAG_CARRY
 *           @arg PKA_FLAG_USERFLAG0
 *           @arg PKA_FLAG_USERFLAG1
 *           @arg PKA_FLAG_USERFLAG2
 *           @arg PKA_FLAG_USERFLAG3
 * @retval FlagStatus: SET or RESET.
 */
FlagStatus HAL_PKA_GetFlagStatus(HAL_PKA_HandleTypeDef *hpka, uint32 Flag)
{
    /* Check the PKA handle allocation */
    if (PKA_HandleIsValid(hpka) == 0U)
    {
        return RESET;
    }

    /* Check the parameters */
    assert_param(IS_PKA_ALL_INSTANCE(hpka->Instance));
    assert_param(IS_PKA_FLAG(Flag));

    /* Return the FLAGS status of the selected flag */
    return (FlagStatus)(READ_BIT(hpka->Instance->FLAGS, Flag) != 0U);
}

/**
 * @brief  Clears the PKA stat status. (NON-BLOCKING)
 * @note   The STAT flags are write-0-clear (W0C): a 0 is written to the
 *         selected bit to clear it (STAT &= ~flag). This matches the legacy
 *         PKA_ClearStatus and is opposite to the write-1-clear status
 *         registers of some other chip peripherals.
 * @param  hpka: pointer to a HAL_PKA_HandleTypeDef structure.
 * @param  Stat: PKA stat. This parameter can be one of the following
 *         values (PKA_STATE_*):
 *           @arg PKA_STATE_SIF_ERR
 *           @arg PKA_STATE_SIF_SBE
 *           @arg PKA_STATE_DONE
 * @retval None
 */
void HAL_PKA_ClearStatus(HAL_PKA_HandleTypeDef *hpka, uint32 Stat)
{
    /* Check the PKA handle allocation */
    if (PKA_HandleIsValid(hpka) == 0U)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_PKA_ALL_INSTANCE(hpka->Instance));
    assert_param(IS_PKA_IT_STATE(Stat));

    /* Run time parameter validation, so that the checks stay effective in a
     * build with the assertions disabled. A rejected call neither takes the
     * lock nor changes the handle state nor touches a register. */
    if ((IS_PKA_IT_STATE(Stat) == 0U))
    {
        PKA_ReportParamError(hpka);
        return;
    }

    /* ARCH-CONST-09: state gate. A busy handle (an operation is ongoing in
     * another context) is rejected with HAL_BUSY, an uninitialized handle with
     * HAL_ERROR, while the recoverable state ERROR accepts the operation. */
    if (PKA_CheckState(hpka) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (PKA_LockHandle(hpka, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    /* Acknowledge the selected status bits.  STAT is write-one-to-clear: the
     * selected mask is written directly, never read-modified-written, so an
     * unselected pending event is not acknowledged by accident. */
    WRITE_REG(hpka->Instance->STAT, Stat);

    /* Release Lock */
    PKA_UnlockHandle(hpka);
}

/**
 * @brief  Sets the PKA program entry point. (NON-BLOCKING)
 * @note   This is the HAL equivalent of the legacy PKA_SetStack(): that
 *         function wrote the ENTRY_PNT (program entry point) register but
 *         was named SetStack (a naming / register mismatch bug). Here the
 *         register is set through a correctly-named function; the stack
 *         pointer register (STACK_PNTR) is left to HAL_PKA_ClearStack() /
 *         HAL_PKA_SetStackPointer().
 * @param  hpka: pointer to a HAL_PKA_HandleTypeDef structure.
 * @param  EntryPoint: program entry point (ENTRY_PNT.ADDR).
 * @retval None
 */
void HAL_PKA_SetEntryPoint(HAL_PKA_HandleTypeDef *hpka, uint32 EntryPoint)
{
    uint32 temp;

    /* Check the PKA handle allocation */
    if (PKA_HandleIsValid(hpka) == 0U)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_PKA_ALL_INSTANCE(hpka->Instance));

    /* Run time field-width validation (the manual defines a 12-bit index). */
    if (IS_PKA_ENTRY_POINT(EntryPoint) == 0U)
    {
        PKA_ReportParamError(hpka);
        return;
    }

    /* ARCH-CONST-09: state gate. A busy handle (an operation is ongoing in
     * another context) is rejected with HAL_BUSY, an uninitialized handle with
     * HAL_ERROR, while the recoverable state ERROR accepts the operation. */
    if (PKA_CheckState(hpka) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (PKA_LockHandle(hpka, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    /* Only the ADDR field is written; the reserved bits keep their value. */
    temp = READ_REG(hpka->Instance->ENTRY_PNT);
    temp &= ~((uint32)PKA_ENTRY_PNT_ADDR_Msk);
    temp |= (((uint32)EntryPoint << PKA_ENTRY_PNT_ADDR_Pos) & (uint32)PKA_ENTRY_PNT_ADDR_Msk);
    WRITE_REG(hpka->Instance->ENTRY_PNT, temp);

    /* Release Lock */
    PKA_UnlockHandle(hpka);
}

/**
 * @brief  Sets the PKA stack pointer. (NON-BLOCKING)
 * @param  hpka: pointer to a HAL_PKA_HandleTypeDef structure.
 * @param  StackPointer: stack pointer (STACK_PNTR.PNTR).
 * @retval None
 */
void HAL_PKA_SetStackPointer(HAL_PKA_HandleTypeDef *hpka, uint32 StackPointer)
{
    uint32 temp;

    /* Check the PKA handle allocation */
    if (PKA_HandleIsValid(hpka) == 0U)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_PKA_ALL_INSTANCE(hpka->Instance));

    /* Run time field-width validation (the manual defines a 12-bit field). */
    if (IS_PKA_STACK_POINTER(StackPointer) == 0U)
    {
        PKA_ReportParamError(hpka);
        return;
    }

    /* ARCH-CONST-09: state gate. A busy handle (an operation is ongoing in
     * another context) is rejected with HAL_BUSY, an uninitialized handle with
     * HAL_ERROR, while the recoverable state ERROR accepts the operation. */
    if (PKA_CheckState(hpka) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (PKA_LockHandle(hpka, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    /* Only the PNTR field is written; the reserved bits keep their value. */
    temp = READ_REG(hpka->Instance->STACK_PNTR);
    temp &= ~((uint32)PKA_STACK_PNTR_PNTR_Msk);
    temp |= (((uint32)StackPointer << PKA_STACK_PNTR_PNTR_Pos) & (uint32)PKA_STACK_PNTR_PNTR_Msk);
    WRITE_REG(hpka->Instance->STACK_PNTR, temp);

    /* Release Lock */
    PKA_UnlockHandle(hpka);
}

/**
 * @brief  Clears the PKA stack pointer. (NON-BLOCKING)
 * @param  hpka: pointer to a HAL_PKA_HandleTypeDef structure.
 * @retval None
 */
void HAL_PKA_ClearStack(HAL_PKA_HandleTypeDef *hpka)
{
    /* Check the PKA handle allocation */
    if (PKA_HandleIsValid(hpka) == 0U)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_PKA_ALL_INSTANCE(hpka->Instance));

    /* ARCH-CONST-09: state gate. A busy handle (an operation is ongoing in
     * another context) is rejected with HAL_BUSY, an uninitialized handle with
     * HAL_ERROR, while the recoverable state ERROR accepts the operation. */
    if (PKA_CheckState(hpka) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (PKA_LockHandle(hpka, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    /* Clear the stack pointer */
    WRITE_REG(hpka->Instance->STACK_PNTR, 0x00U);

    /* Release Lock */
    PKA_UnlockHandle(hpka);
}

/**
 * @brief  Gets the PKA stop reason code. (NON-BLOCKING)
 * @param  hpka: pointer to a HAL_PKA_HandleTypeDef structure.
 * @retval PKA_StopReasonEnum: the RTN_CODE.STOP_REASON field value.
 */
PKA_StopReasonEnum HAL_PKA_GetStopReasonCode(HAL_PKA_HandleTypeDef *hpka)
{
    uint32 code;

    /* Check the PKA handle allocation */
    if (PKA_HandleIsValid(hpka) == 0U)
    {
        return NORMAL_STOP;
    }

    /* Check the parameters */
    assert_param(IS_PKA_ALL_INSTANCE(hpka->Instance));

    /* Decode the field; a reserved or undocumented code is reported as the
     * out-of-enumeration value instead of being folded into a known reason. */
    code = (uint32)((READ_REG(hpka->Instance->RTN_CODE) &
                     PKA_RTN_CODE_STOP_REASON) >> PKA_RTN_CODE_STOP_REASON_Pos);

    switch (code)
    {
        case PKA_STOP_REASON_NORMAL_STOP:
            return NORMAL_STOP;

        case PKA_STOP_REASON_INVALID_OP_CODE:
            return INVALID_OP_CODE;

        case PKA_STOP_REASON_STACK_UNDERFLOW:
            return STACK_UNDERFLOW;

        case PKA_STOP_REASON_STACK_OVERFLOW:
            return STACK_OVERFLOW;

        case PKA_STOP_REASON_WATCHDOG:
            return WATCHDOG;

        case PKA_STOP_REASON_HOST_REQUEST:
            return HOST_REQUEST;

        case PKA_STOP_REASON_MEMORY_COLLISION:
            return MEMORY_PORT_COLLISION;

        default:
            return (PKA_StopReasonEnum)PKA_STOP_REASON_UNKNOWN;
    }
}

/**
 * @brief  Loads the PKA micro-code firmware. (NON-BLOCKING)
 * @note   The PKA executes an internal micro-code (firmware) that is
 *         written to the firmware region of the PKA before the operation
 *         starts. The example writes the firmware with
 *         set_32bit_addr(DSE_PKA_BASE, g_pka_fw[cnt].addr,
 *         g_pka_fw[cnt].data). This function writes Length adjacent
 *         (Address, Data) pairs to the PKA memory at offset Address. The
 *         two arrays are the firmware table split in column-major
 *         form: FirmwareAddr[] holds the per-entry offset, FirmwareData[]
 *         the per-entry value.
 * @param  hpka: pointer to a HAL_PKA_HandleTypeDef structure.
 * @param  FirmwareAddr: pointer to the array of byte offsets (relative to
 *                       PKA_BASE) of each firmware entry.
 * @param  FirmwareData: pointer to the array of data values to write.
 * @param  Length: number of firmware entries to write.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_PKA_LoadFirmware(HAL_PKA_HandleTypeDef *hpka,
                                       const uint32 *FirmwareAddr,
                                       const uint32 *FirmwareData, uint32 Length)
{
    volatile uint32 *fwaddr = (volatile uint32 *)NULL_PTR;
    uint32 idx = 0U;

    /* Check the PKA handle allocation */
    if (PKA_HandleIsValid(hpka) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_PKA_ALL_INSTANCE(hpka->Instance));
    assert_param(FirmwareAddr != NULL_PTR);
    assert_param(FirmwareData != NULL_PTR);

    /* Check the input buffers */
    /* Run time validation, so that the checks stay effective in a build
     * with the assertions disabled. */
    if ((FirmwareAddr == NULL_PTR) || (FirmwareData == NULL_PTR) ||
        (Length == 0U) || (Length > PKA_FIRMWARE_WORDS_MAX))
    {
        PKA_ReportParamError(hpka);
        return HAL_ERROR;
    }

    /* Preflight every entry against the micro-code region before the first
     * write, so one bad entry rejects the whole call and the firmware region
     * (or any other address) cannot be overwritten by a stray offset. */
    for (idx = 0U; idx < Length; idx++)
    {
        if (PKA_FIRMWARE_IN_RANGE(FirmwareAddr[idx], 1U) == 0U)
        {
            PKA_ReportParamError(hpka);
            return HAL_ERROR;
        }
    }

    /* ARCH-CONST-09: state gate. A busy handle (an operation is ongoing in
     * another context) is rejected with HAL_BUSY, an uninitialized handle with
     * HAL_ERROR, while the recoverable state ERROR accepts the operation. */
    if (PKA_CheckState(hpka) != HAL_OK)
    {
        return PKA_CheckState(hpka);
    }

    /* Process locked */
    if (PKA_LockHandle(hpka, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* The micro-code region is not writable while a program executes. */
    if ((READ_REG(hpka->Instance->RTN_CODE) & PKA_RTN_CODE_BUSY_Msk) != 0U)
    {
        PKA_UnlockHandle(hpka);
        return HAL_BUSY;
    }

    for (idx = 0U; idx < Length; idx++)
    {
        /* Compute the absolute firmware address from the validated offset */
        fwaddr = (volatile uint32 *)(PKA_BASE + FirmwareAddr[idx]);
        *fwaddr = FirmwareData[idx];
    }

    /* Release Lock */
    PKA_UnlockHandle(hpka);

    return HAL_OK;
}

/**
 * @brief  Writes data to the PKA wide data register map (operand memory). (NON-BLOCKING)
 * @note   The PKA operand memory (A / B / C / D regions, from the wide data
 *         register map base macros PKA_ECC_ADDR_* / PKA_RSA_ADDR_*) holds
 *         the big-number operands processed by the RSA / ECC micro-code.
 *         This function writes a buffer of Length 32-bit words at the given
 *         byte Address relative to PKA_BASE. The example accesses the same
 *         memory with memcpy((uint32 *)(PKA_RSA_ADDR_512_D0), ...).
 * @param  hpka: pointer to a HAL_PKA_HandleTypeDef structure.
 * @param  Address: byte offset from PKA_BASE (PKA_BASE + Address).
 * @param  Data: pointer to the buffer to write.
 * @param  Length: number of 32-bit words to write.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_PKA_WriteData(HAL_PKA_HandleTypeDef *hpka, uint32 Address,
                                    const uint32 *Data, uint32 Length)
{
    volatile uint32 *addr = (volatile uint32 *)NULL_PTR;
    uint32 idx = 0U;

    /* Check the PKA handle allocation */
    if (PKA_HandleIsValid(hpka) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_PKA_ALL_INSTANCE(hpka->Instance));
    assert_param(Data != NULL_PTR);
    assert_param(Address >= PKA_OPERAND_WINDOW_FIRST);
    assert_param(Address < PKA_OPERAND_WINDOW_END);
    assert_param(((uint32)Data & PKA_OFFSET_ALIGN_MASK) == 0U);

    /* Check the input buffers */
    /* Run time validation, so that the checks stay effective in a build
     * with the assertions disabled: the operand window is validated as
     * well, so that an out of range access stays impossible. */
    /* The window guard divides the remaining bytes by the word width, so a
     * huge Length cannot wrap the comparison open, and it also requires both
     * the offset and the caller buffer to be 4-byte aligned. */
    if ((Data == NULL_PTR) ||
        (((uint32)Data & PKA_OFFSET_ALIGN_MASK) != 0U) ||
        (PKA_OPERAND_IN_RANGE(Address, Length) == 0U))
    {
        PKA_ReportParamError(hpka);
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: state gate. A busy handle (an operation is ongoing in
     * another context) is rejected with HAL_BUSY, an uninitialized handle with
     * HAL_ERROR, while the recoverable state ERROR accepts the operation. */
    if (PKA_CheckState(hpka) != HAL_OK)
    {
        return PKA_CheckState(hpka);
    }

    /* Process locked */
    if (PKA_LockHandle(hpka, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* The manual locks the operand window while the accelerator executes a
     * program, so a running operation rejects a window access. */
    if ((READ_REG(hpka->Instance->RTN_CODE) & PKA_RTN_CODE_BUSY_Msk) != 0U)
    {
        PKA_UnlockHandle(hpka);
        return HAL_BUSY;
    }

    /* Compute the operand address */
    addr = (volatile uint32 *)(PKA_BASE + Address);

    for (idx = 0U; idx < Length; idx++)
    {
        addr[idx] = Data[idx];
    }

    /* Release Lock */
    PKA_UnlockHandle(hpka);

    return HAL_OK;
}

/**
 * @brief  Reads data from the PKA wide data register map (operand memory). (NON-BLOCKING)
 * @note   Opposite of HAL_PKA_WriteData(): reads Length 32-bit words at the
 *         given byte Address relative to PKA_BASE. The example reads the
 *         result with memcpy(RSA_u_Result, (uint32 *)(PKA_RSA_ADDR_512_A3),
 *         ...).
 * @param  hpka: pointer to a HAL_PKA_HandleTypeDef structure.
 * @param  Address: byte offset from PKA_BASE (PKA_BASE + Address).
 * @param  Data: pointer to the buffer to store the read data.
 * @param  Length: number of 32-bit words to read.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_PKA_ReadData(HAL_PKA_HandleTypeDef *hpka, uint32 Address,
                                   uint32 *Data, uint32 Length)
{
    volatile uint32 *addr = (volatile uint32 *)NULL_PTR;
    uint32 idx = 0U;

    /* Check the PKA handle allocation */
    if (PKA_HandleIsValid(hpka) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_PKA_ALL_INSTANCE(hpka->Instance));
    assert_param(Data != NULL_PTR);
    assert_param(Address >= PKA_OPERAND_WINDOW_FIRST);
    assert_param(Address < PKA_OPERAND_WINDOW_END);
    assert_param(((uint32)Data & PKA_OFFSET_ALIGN_MASK) == 0U);

    /* Check the input buffers */
    /* Run time validation, so that the checks stay effective in a build
     * with the assertions disabled: the operand window is validated as
     * well, so that an out of range access stays impossible. */
    /* The window guard divides the remaining bytes by the word width, so a
     * huge Length cannot wrap the comparison open, and it also requires both
     * the offset and the caller buffer to be 4-byte aligned. */
    if ((Data == NULL_PTR) ||
        (((uint32)Data & PKA_OFFSET_ALIGN_MASK) != 0U) ||
        (PKA_OPERAND_IN_RANGE(Address, Length) == 0U))
    {
        PKA_ReportParamError(hpka);
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: state gate. A busy handle (an operation is ongoing in
     * another context) is rejected with HAL_BUSY, an uninitialized handle with
     * HAL_ERROR, while the recoverable state ERROR accepts the operation. */
    if (PKA_CheckState(hpka) != HAL_OK)
    {
        return PKA_CheckState(hpka);
    }

    /* Process locked */
    if (PKA_LockHandle(hpka, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* The manual locks the operand window while the accelerator executes a
     * program, so a running operation rejects a window access. */
    if ((READ_REG(hpka->Instance->RTN_CODE) & PKA_RTN_CODE_BUSY_Msk) != 0U)
    {
        PKA_UnlockHandle(hpka);
        return HAL_BUSY;
    }

    /* Compute the operand address */
    addr = (volatile uint32 *)(PKA_BASE + Address);

    for (idx = 0U; idx < Length; idx++)
    {
        Data[idx] = addr[idx];
    }

    /* Release Lock */
    PKA_UnlockHandle(hpka);

    return HAL_OK;
}

/**
 * @brief  Handles the PKA interrupt request. (NON-BLOCKING)
 * @note   The PKA IRQ_EN register carries the SIF error / SIF single bit
 *         error / DONE / global interrupt enable bits, and the STAT
 *         register carries the corresponding status flags. An SIF error
 *         (SIF_ERR / SIF_SBE) or the global error is reported through
 *         HAL_PKA_ErrorCallback(); a successful DONE transitions the state
 *         to READY. The user must implement PKA_IRQ_Handler() to dispatch
 *         to this handler.
 * @param  hpka: pointer to a HAL_PKA_HandleTypeDef structure.
 * @retval None
 */
void HAL_PKA_IRQHandler(HAL_PKA_HandleTypeDef *hpka)
{
    uint32 owned;

    /* Check the PKA handle allocation */
    if (PKA_HandleIsValid(hpka) == 0U)
    {
        return;
    }

    /* Only status bits that are both asserted and enabled belong to this
     * entry; a source the application left disabled stays its own.  The
     * peripheral implements STAT.DONE / IRQ_EN.IE only, so the SIF and
     * global masks can never be owned here. */
    owned = (READ_REG(hpka->Instance->STAT) & READ_REG(hpka->Instance->IRQ_EN));
    if ((owned & (uint32)PKA_STATE_DONE) == 0U)
    {
        return;
    }

    /* Acknowledge the completion.  STAT is write-one-to-clear, so the
     * documented clearable bit is written directly.  The task-side state is
     * deliberately not touched: a READY published here would overwrite the
     * BUSY snapshot of a call that is still running in another context, and
     * the driver has no completion callback to publish success through. */
    WRITE_REG(hpka->Instance->STAT, PKA_STATE_DONE);
}

/**
 * @brief  PKA error callback. (NON-BLOCKING)
 * @param  hpka: pointer to a HAL_PKA_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_PKA_ErrorCallback(HAL_PKA_HandleTypeDef *hpka)
{
    /* Prevent unused argument(s) compilation warning */
    (void)hpka;

    /* NOTE : This function should not be modified. When the callback is needed,
              function HAL_PKA_ErrorCallback must be implemented in the user file.
     */
}

/**
  * @}
  */

/** @addtogroup PKA_Exported_Functions_Group3 Peripheral State functions
  * @{
  */

/**
 * @brief  Returns the PKA state. (NON-BLOCKING)
 * @param  hpka: pointer to a HAL_PKA_HandleTypeDef structure.
 * @retval HAL_PKA_StateTypeDef: PKA state.
 */
HAL_PKA_StateTypeDef HAL_PKA_GetState(HAL_PKA_HandleTypeDef *hpka)
{
    /* Check the PKA handle allocation */
    if (PKA_HandleIsValid(hpka) == 0U)
    {
        return HAL_PKA_STATE_RESET;
    }

    /* Return the PKA state */
    return hpka->State;
}

/**
 * @brief  Returns the PKA error code. (NON-BLOCKING)
 * @param  hpka: pointer to a HAL_PKA_HandleTypeDef structure.
 * @retval uint32: the PKA error code (HAL_PKA_ERROR_xxx).
 */
uint32 HAL_PKA_GetError(HAL_PKA_HandleTypeDef *hpka)
{
    /* Check the PKA handle allocation */
    if (PKA_HandleIsValid(hpka) == 0U)
    {
        return HAL_PKA_ERROR_NONE;
    }

    /* Return the PKA error code */
    return hpka->ErrorCode;
}

/**
  * @}
  */

#endif /* HAL_PKA_MODULE_ENABLED */

/*****END OF FILE*****/
