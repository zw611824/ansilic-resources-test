/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_smu.c
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V2.3
 * Date:   2026/10/14
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/13     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.1     add the module guard (HAL_SMU_MODULE_ENABLED) around the whole implementation
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.2     put the as32x601_hal.h include first (module switch from the conf) before the module headers
 *     ANSILIC APPLICATION GROUP  2026/09/07     1.3     align with the SMU
 *                                                       configuration structure
 *                                                       Size / Version metafields
 *                                                       (header V1.1)
 *     ANSILIC APPLICATION GROUP  2026/09/15     1.4     fix a silent PLL
 *                                                       configuration skip: an
 *                                                       FIRC power-down request
 *                                                       issued while the FIRC is
 *                                                       the system clock source
 *                                                       is now ignored instead of
 *                                                       aborting HAL_SMU_OscConfig
 *                                                       (the PLL configuration
 *                                                       must still be applied);
 *                                                       HAL_SMU_ClockConfig now
 *                                                       refuses to select a PLL
 *                                                       whose PLLEN / PLLN / PLLQ
 *                                                       were never programmed
 *     ANSILIC APPLICATION GROUP  2026/09/16     1.5     move the system clock
 *                                                       source selection into
 *                                                       HAL_SMU_OscConfig (the
 *                                                       SYSCLKSelect field is
 *                                                       moved from the clock
 *                                                       configuration structure
 *                                                       to the oscillator one, so
 *                                                       that it is defined only
 *                                                       once); HAL_SMU_ClockConfig
 *                                                       now only programs the bus
 *                                                       dividers; drive the FIRC
 *                                                       power state from FIRCState
 *                                                       alone; add the handle
 *                                                       (lock / state / error
 *                                                       code) and make all the
 *                                                       public functions handle
 *                                                       based (RTOS support); add
 *                                                       HAL_SMU_GetState /
 *                                                       HAL_SMU_GetError and the
 *                                                       MSP callbacks; factor the
 *                                                       clock source ready waits
 *                                                       into private helpers
 *     ANSILIC APPLICATION GROUP  2026/09/16     1.6     align the driver with
 *                                                       the Medium class of the
 *                                                       architecture
 *                                                       specification: add a
 *                                                       Timeout parameter to
 *                                                       HAL_SMU_OscConfig /
 *                                                       HAL_SMU_DeInit and use
 *                                                       HAL_GetTick() for the
 *                                                       waits (POLL-01/02),
 *                                                       yield the CPU from the
 *                                                       polling loops through
 *                                                       HAL_RTOS_Yield()
 *                                                       (RTOS-04), give the
 *                                                       handle lock a timeout
 *                                                       (RTOS-11), add the
 *                                                       HAL_SMU_STATE_TIMEOUT
 *                                                       state and the
 *                                                       ARCH-CONST-09 state gate
 *                                                       (BUSY -> HAL_BUSY,
 *                                                       RESET -> HAL_ERROR),
 *                                                       move the HAL_InitTick()
 *                                                       / SystemCoreClock
 *                                                       refresh after the
 *                                                       unlock (LOCK-05), store
 *                                                       the applied
 *                                                       configuration in the
 *                                                       handle and tag the
 *                                                       blocking functions as
 *                                                       (BLOCKING) (POLL-04)
 *     ANSILIC APPLICATION GROUP  2026/09/16     1.7     fix the lock
 *                                                       compliance of
 *                                                       HAL_SMU_DeInit: the
 *                                                       low level
 *                                                       de-initialization
 *                                                       callback and the
 *                                                       time base refresh
 *                                                       now run after the
 *                                                       handle lock has been
 *                                                       released (LOCK-06
 *                                                       forbids calling the
 *                                                       MSP callback while
 *                                                       the lock is held, and
 *                                                       the weak
 *                                                       HAL_InitTick() may
 *                                                       take an RTOS lock);
 *                                                       document every lock
 *                                                       failure return as a
 *                                                       path where the lock
 *                                                       is not held (LOCK-02);
 *                                                       tag HAL_SMU_OscConfig
 *                                                       as (BLOCKING) in the
 *                                                       source too and return
 *                                                       the operation status
 *                                                       from
 *                                                       HAL_SMU_ClockConfig
 *     ANSILIC APPLICATION GROUP  2026/09/17     1.8     change the NewState parameter of
                                                         HAL_SMU_SetSRAMLowPower / HAL_SMU_DCLSCmd /
                                                         HAL_SMU_ECCCmd / HAL_SMU_BUSTimeOutCmd from
                                                         uint32 to FunctionalState (ENABLE / DISABLE, as
                                                         in the other drivers of the library), check it
                                                         with IS_FUNCTIONAL_STATE and compare it
                                                         against DISABLE (matching the header V1.6)
 *     ANSILIC APPLICATION GROUP  2026/10/08     1.9     merge the capabilities of the System
 *                                                       Management release of 2026/09/29 (header
 *                                                       V1.7):
 *                                                       - add the PLL electrical range check
 *                                                       (SMU_CheckPllFreqDomain): the
 *                                                       frequencies produced by the requested
 *                                                       divider set (input, phase detector, VCO,
 *                                                       CLK_Q, CLK_R) are verified against the
 *                                                       documented limits before the PLL
 *                                                       registers are written, because the
 *                                                       IS_SMU_PLLDIV*_VALUE checks only bound
 *                                                       each divider on its own;
 *                                                       - move the PLL source protections
 *                                                       (reconfiguring the running PLL,
 *                                                       enabling it from a powered down FIRC,
 *                                                       disabling the running PLL) into
 *                                                       SMU_CheckOscRequest(), evaluated before
 *                                                       the first register write, so that a
 *                                                       refused request no longer leaves the
 *                                                       FIRC part applied;
 *                                                       - update a bus divider with the clock of
 *                                                       that bus switched off (SMU_SetBusDivider)
 *                                                       and close both AxiLite buses while the
 *                                                       CAN divider changes, as the release
 *                                                       documents;
 *                                                       - add HAL_SMU_GetBusState() and
 *                                                       HAL_SMU_GetWorkMode() (read only, no
 *                                                       handle) and HAL_SMU_TIMBreakCmd()
 *                                                       (per timer brake enable / disable)
 *     ANSILIC APPLICATION GROUP  2026/10/09     2.0     validate the four PLL divider encodings at
 *                                                       run time as well (not only through
 *                                                       assert_param): in a release build a
 *                                                       divider that does not fit its PLLCFGR
 *                                                       field used to be shifted into the
 *                                                       neighbouring field, now the set is
 *                                                       rejected
 *     ANSILIC APPLICATION GROUP  2026/10/14     2.1     first attempt at the PLL lock
 *                                                       defect (superseded by 2.2):
 *                                                       stop the PLL and hold it in
 *                                                       reset before rewriting its
 *                                                       dividers, then restart it and
 *                                                       wait for the lock flag to go low
 *                                                       and high again. The stop/start
 *                                                       turned out to be unnecessary and
 *                                                       risky (the lock flag does not
 *                                                       have to follow a stopped PLL, and
 *                                                       restarting it shortly before the
 *                                                       system clock switch can feed the
 *                                                       core an unlocked clock), so the
 *                                                       approach was replaced by 2.2
 *     ANSILIC APPLICATION GROUP  2026/10/14     2.2     latch the PLL after the source is
 *                                                       selected: HAL_SMU_OscConfig now
 *                                                       programs the dividers, releases
 *                                                       the reset, enables the PLL and
 *                                                       selects the input source in
 *                                                       separate accesses, and writes the
 *                                                       PLLUF update request LAST. The
 *                                                       request is the access that latches
 *                                                       the divider values and the source
 *                                                       into the PLL, and this device does
 *                                                       not re-latch by itself when only
 *                                                       the source changes: writing PLLUF
 *                                                       together with the dividers (i.e.
 *                                                       before the source was selected)
 *                                                       latched the PLL onto its previous
 *                                                       input source. The PLL therefore
 *                                                       kept running from the 16 MHz FIRC
 *                                                       instead of locking to the 20 MHz
 *                                                       OSC, and the core ran at
 *                                                       180 MHz x 16/20 = 144 MHz (every
 *                                                       delay 25 % long: a 500 ms delay
 *                                                       measured 625 ms) while the driver,
 *                                                       reading PLLSEL = OSC, reported the
 *                                                       expected 180 MHz. The PLL is not
 *                                                       stopped any more: it is running
 *                                                       from reset on (PLLCFGR reset value
 *                                                       0x00E15A10 has PLLEN = PLLRST = 1)
 *                                                       and is only re-latched, which also
 *                                                       keeps the lock wait meaningful
 *     ANSILIC APPLICATION GROUP  2026/10/14     2.3     make the clock request independent
 *                                                       of how the device was started: a
 *                                                       download that does not reset the
 *                                                       device leaves SYSSEL at the PLL of
 *                                                       the previous run, and the old rule
 *                                                       ("refuse PLL_ON while the PLL clocks
 *                                                       the system") then refused the whole
 *                                                       request. SystemCoreClock was updated
 *                                                       only on success, so it stayed at the
 *                                                       16 MHz reset value while the core kept
 *                                                       running at the previous frequency:
 *                                                       measured on the board, a 500 ms delay
 *                                                       took about 50 ms. HAL_SMU_OscConfig
 *                                                       now hands the system clock over to the
 *                                                       FIRC (power on, wait for ready, select)
 *                                                       before reprogramming the PLL, which is
 *                                                       the sequence HAL_SMU_DeInit already
 *                                                       used, and the two over-broad refusals
 *                                                       ("PLL running while the PLL is
 *                                                       reconfigured", for both PLL_ON and
 *                                                       PLL_OFF) are gone: only a request that
 *                                                       would leave the device without a usable
 *                                                       clock is refused. SystemCoreClock and
 *                                                       HAL_InitTick() are now refreshed on
 *                                                       EVERY exit path, so the HAL time base
 *                                                       always describes the hardware even when
 *                                                       a request is refused. A failed
 *                                                       hand-over leaves the clock tree as it
 *                                                       was and is reported as a timeout
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the System Management Unit
 *                  (SMU), following the structure of a conventional clock-controller HAL driver:
 *                  - Initialization and de-initialization: HAL_SMU_Init,
 *                    HAL_SMU_DeInit, HAL_SMU_OscConfig, HAL_SMU_ClockConfig,
 *                    HAL_SMU_MspInit, HAL_SMU_MspDeInit;
 *                  - Peripheral control: system / bus clock frequency
 *                    retrieval, oscillator and clock configuration read-back,
 *                    status flags, clock output, state and error reporting;
 *                  - Extended control: high-timer brake, SRAM low power,
 *                    dual-core lock-step, ECC, bus timeout monitoring.
 *
 *                  The driver uses one handle (HAL_SMU_HandleTypeDef) that
 *                  carries the synchronization state only: it is locked by
 *                  every modifying function (RTOS mutex or bare-metal lock
 *                  flag) and it reports the driver state and error code.
 */
#include "as32x601_hal.h"                /* module switch from as32x601_hal_conf.h */
#include "as32x601_hal_smu.h"            /* SMU HAL API and register macros        */

/* The HAL_SMU_MODULE_ENABLED switch is provided by the user configuration
 * file (as32x601_hal_conf.h, included above through as32x601_hal.h): the
 * whole implementation is compiled only while the module is enabled. */
#ifdef HAL_SMU_MODULE_ENABLED

/* Private define ------------------------------------------------------------*/
#ifndef FIRC_VALUE
    /**
     * @brief Fast internal RC oscillator frequency in Hz (fallback).
     * @note  Normally provided by the as32x601_hal_conf.h file.
     */
    #define FIRC_VALUE   16000000U
#endif /* FIRC_VALUE */

#ifndef OSC_VALUE
    /**
     * @brief External oscillator frequency in Hz (fallback).
     * @note  Normally provided by the as32x601_hal_conf.h file.
     */
    #define OSC_VALUE    20000000U
#endif /* OSC_VALUE */

/* PLL electrical limits in Hz. The divider encoding checks (IS_SMU_PLLDIV*_VALUE)
 * only bound each divider on its own: the same encoding is legal at any divider
 * combination, so the frequencies it produces must be checked as well before the
 * PLL registers are written. The limits below are the ones documented for the
 * PLL (input, phase frequency detector, VCO and the two outputs).
 *
 * Source: they are taken from the vendor release of this driver; they have NOT
 * been re-confirmed against the AS32x601 chip manual on this machine (the manual
 * is not available locally), so treat the values as "vendor derived, manual
 * confirmation pending".
 */
#define SMU_PLL_IN_MIN        11592000U     /*!< Minimum PLL input clock (Hz)         */
#define SMU_PLL_IN_MAX        25000000U     /*!< Maximum PLL input clock (Hz)         */
#define SMU_PLL_PFD_MIN         950000U     /*!< Minimum phase detector frequency (Hz)*/
#define SMU_PLL_PFD_MAX        2100000U     /*!< Maximum phase detector frequency (Hz)*/
#define SMU_PLL_VCO_MIN      100000000U     /*!< Minimum VCO frequency (Hz)           */
#define SMU_PLL_VCO_MAX      480000000U     /*!< Maximum VCO frequency (Hz)           */
#define SMU_PLL_CLKQ_MIN      16000000U     /*!< Minimum CLK_Q output frequency (Hz)  */
#define SMU_PLL_CLKQ_MAX     480000000U     /*!< Maximum CLK_Q output frequency (Hz)  */
#define SMU_PLL_CLKR_MIN      30000000U     /*!< Minimum CLK_R output frequency (Hz)  */
#define SMU_PLL_CLKR_MAX     240000000U     /*!< Maximum CLK_R output frequency (Hz)  */

HAL_FLASH_HandleTypeDef hflash;

/* Private function prototypes -----------------------------------------------*/
static uint32 SMU_HandleIsValid(HAL_SMU_HandleTypeDef *hsmu);
static HAL_StatusTypeDef SMU_CheckState(HAL_SMU_HandleTypeDef *hsmu);
static HAL_StatusTypeDef SMU_WaitFIRCReady(uint32 Timeout);
static HAL_StatusTypeDef SMU_WaitPLLLocked(uint32 Timeout);
static uint32 SMU_IsPLLConfigured(void);
static uint32 SMU_GetPLLQCLK(void);
static uint32 SMU_GetPLLRCLK(void);
static uint32 SMU_GetValidDivider(uint32 Divider, uint32 MaxDiv);
static uint32 SMU_GetPllInputFreq(uint32 PllSource);
static HAL_StatusTypeDef SMU_CheckPllFreqDomain(const SMU_PLLConfigTypeDef *pPll);
static HAL_StatusTypeDef SMU_CheckOscRequest(const SMU_OscInitTypeDef *pOscInit);
static void SMU_SetBusDivider(uint32 FieldMask, uint32 FieldPos, uint32 Div,
                              __IO uint32 *pBusCfg, uint32 ClkEnBit);

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Check whether a SMU handle and its instance are valid.
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
static uint32 SMU_HandleIsValid(HAL_SMU_HandleTypeDef *hsmu)
{
    if ((hsmu == NULL_PTR) || (hsmu->Instance != SMU))
    {
        return 0U;
    }

    return 1U;
}

/**
 * @brief  Check whether the handle accepts a new operation.
 * @note   Architecture constraint ARCH-CONST-09: a handle that is BUSY (an
 *         operation is ongoing in another context) rejects any other operation
 *         with HAL_BUSY, and a handle that is not initialized (RESET) requires
 *         HAL_SMU_Init() first and is rejected with HAL_ERROR. The recoverable
 *         states ERROR and TIMEOUT accept a new operation directly (the entry
 *         point of the operation resets the state to BUSY, so that no DeInit /
 *         Init round trip is required).
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK (accepted) / HAL_BUSY / HAL_ERROR.
 */
static HAL_StatusTypeDef SMU_CheckState(HAL_SMU_HandleTypeDef *hsmu)
{
    if (hsmu->State == HAL_SMU_STATE_BUSY)
    {
        return HAL_BUSY;
    }

    if (hsmu->State == HAL_SMU_STATE_RESET)
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Wait until the FIRC oscillator is ready.
 * @note   The wait is bounded by the caller supplied Timeout, measured with
 *         the HAL 1 ms time base (HAL_GetTick()), so that a missing oscillator
 *         cannot hang the MCU. HAL_MAX_DELAY waits forever; 0 gives the
 *         hardware a single chance (no waiting).
 * @param  Timeout: maximum wait time in ms.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT.
 */
static HAL_StatusTypeDef SMU_WaitFIRCReady(uint32 Timeout)
{
    uint32 tickstart = HAL_GetTick();

    while (__HAL_SMU_GET_FIRC_READY() == 0U)
    {
        if (Timeout != HAL_MAX_DELAY)
        {
            if ((HAL_GetTick() - tickstart) > Timeout)
            {
                return HAL_TIMEOUT;
            }
        }

#if (USE_RTOS == 1)
        /* ARCH/RTOS-04: let the other tasks of the same priority run instead of
         * busy waiting (empty macro in a bare-metal build) */
        HAL_RTOS_Yield();
#endif /* USE_RTOS */
    }

    return HAL_OK;
}

/**
 * @brief  Wait until the PLL lock flag is set.
 * @note   The wait is bounded by the caller supplied Timeout, measured with
 *         the HAL 1 ms time base (HAL_GetTick()), so that a misconfigured PLL
 *         cannot hang the MCU. HAL_MAX_DELAY waits forever; 0 gives the
 *         hardware a single chance (no waiting).
 * @param  Timeout: maximum wait time in ms.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT.
 */
static HAL_StatusTypeDef SMU_WaitPLLLocked(uint32 Timeout)
{
    uint32 tickstart = HAL_GetTick();

    while (__HAL_SMU_GET_FLAG(SMU_FLAG_PLLLOCK) == 0U)
    {
        if (Timeout != HAL_MAX_DELAY)
        {
            if ((HAL_GetTick() - tickstart) > Timeout)
            {
                return HAL_TIMEOUT;
            }
        }

#if (USE_RTOS == 1)
        /* ARCH/RTOS-04: let the other tasks of the same priority run instead of
         * busy waiting (empty macro in a bare-metal build) */
        HAL_RTOS_Yield();
#endif /* USE_RTOS */
    }

    return HAL_OK;
}

/**
 * @brief  Check whether the PLL may clock the system clock, i.e. whether it is
 *         enabled and its PLLN / PLLQ dividers have been programmed.
 * @note   The PLL reset value (PLLCFGR = 0x00E15A10) is enabled but divides
 *         the 16 MHz FIRC by 16 before multiplying it by 360, i.e. far above
 *         the maximum core frequency: selecting such a PLL would over-clock
 *         the device, so it must be rejected.
 * @retval uint32: 1 if the PLL is configured, 0 otherwise.
 */
static uint32 SMU_IsPLLConfigured(void)
{
    uint32 pllcfgr = SMU->PLLCFGR;

    if ((HAL_IS_BIT_SET(pllcfgr, SMU_PLLCFGR_PLLEN) == 0U) ||
        (((pllcfgr & SMU_PLLCFGR_PLLN) >> SMU_PLLCFGR_PLLN_Pos) == 0U) ||
        (((pllcfgr & SMU_PLLCFGR_PLLF) >> SMU_PLLCFGR_PLLF_Pos) == 0U) ||
        (((pllcfgr & SMU_PLLCFGR_PLLQ) >> SMU_PLLCFGR_PLLQ_Pos) == 0U))
    {
        return 0U;
    }

    return 1U;
}

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_SMU_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; when the mutex is not acquired before the
 *         Timeout expires, HAL_TIMEOUT is returned. The value is passed to
 *         HAL_MutexAcquire() as is (RTOS ticks; with the usual 1 ms tick it is
 *         the same quantity as the millisecond Timeout of the public API, and
 *         HAL_MAX_DELAY means an infinite wait).
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef SMU_LockHandle(HAL_SMU_HandleTypeDef *hsmu, uint32 Timeout)
{
#if (USE_RTOS == 1)
    if (hsmu->LockMutex == NULL_PTR)
    {
        /* The porting layer did not create the mutex (e.g. HAL_SMU_MspInit()
         * was not overridden): report it instead of calling the RTOS with a
         * NULL handle */
        return HAL_ERROR;
    }

    return HAL_MutexAcquire(hsmu->LockMutex, Timeout);
#else
    /* Prevent unused argument compilation warning: the bare-metal lock flag
     * either succeeds immediately or reports HAL_BUSY, it never waits */
    UNUSED(Timeout);

    if (hsmu->Lock == HAL_LOCKED)
    {
        return HAL_BUSY;
    }

    hsmu->Lock = HAL_LOCKED;

    return HAL_OK;
#endif /* USE_RTOS */
}

/**
 * @brief  Unlock the handle.
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @retval None
 */
void SMU_UnlockHandle(HAL_SMU_HandleTypeDef *hsmu)
{
#if (USE_RTOS == 1)
    (void)HAL_MutexRelease(hsmu->LockMutex);
#else
    hsmu->Lock = HAL_UNLOCKED;
#endif /* USE_RTOS */
}

/**
 * @brief  Compute the PLL CLK_Q output frequency in Hz.
 * @note   FCLK_VCO = FCLKIN * PLLDivF / PLLDivN, FCLK_Q = FCLK_VCO / PLLDivQ.
 *         The PLL input clock FCLKIN depends on the SMU_BUSCFGR.PLLSEL bit
 *         (0: FIRC, 1: OSC).
 * @retval uint32: CLK_Q frequency in Hz, or 0 if the PLL is disabled or
 *         not yet configured (PLLN = 0) to avoid a divide-by-zero.
 */
static uint32 SMU_GetPLLQCLK(void)
{
    uint32 pllclk_sel = 0U;
    uint32 pllcfgr = 0U;
    uint32 plln = 0U;
    uint32 pllf = 0U;
    uint32 pllq = 0U;

    pllcfgr = SMU->PLLCFGR;
    plln = (pllcfgr & SMU_PLLCFGR_PLLN) >> SMU_PLLCFGR_PLLN_Pos;
    pllf = (pllcfgr & SMU_PLLCFGR_PLLF) >> SMU_PLLCFGR_PLLF_Pos;
    pllq = (pllcfgr & SMU_PLLCFGR_PLLQ) >> SMU_PLLCFGR_PLLQ_Pos;

    /* PLL not enabled or divider value not written yet: no valid output */
    if ((plln == 0U) || (pllq == 0U) || (HAL_IS_BIT_SET(pllcfgr, SMU_PLLCFGR_PLLEN) == 0U))
    {
        return 0U;
    }

    if (READ_BIT(SMU->BUSCFGR, SMU_BUSCFGR_PLLSEL) == SMU_PLLSOURCE_OSC)
    {
        pllclk_sel = OSC_VALUE;
    }
    else
    {
        pllclk_sel = FIRC_VALUE;
    }

    return (uint32)(((uint64)pllclk_sel * (uint64)pllf) /
                    ((uint64)plln * (uint64)pllq));
}

/**
 * @brief  Compute the PLL CLK_R output frequency in Hz.
 * @note   FCLK_R = FCLK_VCO / PLLDivR. Used as the CANCLKx2 clock source.
 * @retval uint32: CLK_R frequency in Hz, or 0 if the PLL is disabled or
 *         not yet configured (PLLN = 0) to avoid a divide-by-zero.
 */
static uint32 SMU_GetPLLRCLK(void)
{
    uint32 pllclk_sel = 0U;
    uint32 pllcfgr = 0U;
    uint32 plln = 0U;
    uint32 pllf = 0U;
    uint32 pllr = 0U;

    pllcfgr = SMU->PLLCFGR;
    plln = (pllcfgr & SMU_PLLCFGR_PLLN) >> SMU_PLLCFGR_PLLN_Pos;
    pllf = (pllcfgr & SMU_PLLCFGR_PLLF) >> SMU_PLLCFGR_PLLF_Pos;
    pllr = (pllcfgr & SMU_PLLCFGR_PLLR) >> SMU_PLLCFGR_PLLR_Pos;

    /* PLL not enabled or divider value not written yet: no valid output */
    if ((plln == 0U) || (pllr == 0U) || (HAL_IS_BIT_SET(pllcfgr, SMU_PLLCFGR_PLLEN) == 0U))
    {
        return 0U;
    }

    if (READ_BIT(SMU->BUSCFGR, SMU_BUSCFGR_PLLSEL) == SMU_PLLSOURCE_OSC)
    {
        pllclk_sel = OSC_VALUE;
    }
    else
    {
        pllclk_sel = FIRC_VALUE;
    }

    return (uint32)(((uint64)pllclk_sel * (uint64)pllf) /
                    ((uint64)plln * (uint64)pllr));
}

/**
 * @brief  Check whether a divider field holds a valid power-of-two value
 *         (1, 2, 4 or 8).
 * @param  Divider: divider field read from the SMU_BUSCFGR register.
 * @param  MaxDiv:  maximum accepted divider value (2 for AXI4BUS3DIV, 8 for
 *                  the APB / CAN dividers).
 * @retval uint32: the divider value if valid, MaxDiv otherwise.
 */
static uint32 SMU_GetValidDivider(uint32 Divider, uint32 MaxDiv)
{
    if (((Divider & (Divider - 1U)) == 0U) && (Divider <= MaxDiv) && (Divider != 0U))
    {
        return Divider;
    }

    return MaxDiv;
}

/**
 * @brief  Return the PLL input clock frequency in Hz.
 * @param  PllSource: SMU_PLLSOURCE_FIRC or SMU_PLLSOURCE_OSC.
 * @retval uint32: input clock frequency in Hz.
 */
static uint32 SMU_GetPllInputFreq(uint32 PllSource)
{
    return (PllSource == SMU_PLLSOURCE_OSC) ? OSC_VALUE : FIRC_VALUE;
}

/**
 * @brief  Check the frequencies produced by a PLL divider set.
 * @note   The IS_SMU_PLLDIV*_VALUE parameter checks bound every divider on its
 *         own, but one encoding is available at any divider combination: with a
 *         20 MHz oscillator, PLLDivN = 22 still passes IS_SMU_PLLDIVN_VALUE and
 *         yet produces a 0.909 MHz phase detector frequency, below the
 *         FCLK_PFD minimum. The frequencies of the requested set are therefore
 *         evaluated before the PLL registers are written:
 *         - FCLKIN   = FIRC (16 MHz) or OSC (20 MHz), from PLLSource
 *         - FCLK_PFD = FCLKIN / PLLDivN
 *         - FCLK_VCO = FCLKIN * PLLDivF / PLLDivN
 *         - FCLK_Q   = FCLK_VCO / PLLDivQ, FCLK_R = FCLK_VCO / PLLDivR
 * @param  pPll: pointer to the PLL configuration to be checked.
 * @retval HAL_StatusTypeDef: HAL_OK when every frequency is inside its range,
 *         HAL_ERROR otherwise.
 */
static HAL_StatusTypeDef SMU_CheckPllFreqDomain(const SMU_PLLConfigTypeDef *pPll)
{
    uint32 fclkin = 0U;
    uint32 vco = 0U;
    uint32 clkq = 0U;
    uint32 clkr = 0U;

    /* The divider encodings are validated at run time and not only through
     * assert_param: in a build with the assertions compiled out, a value that
     * does not fit its PLLCFGR field would be shifted into the neighbouring
     * field when the register is assembled (a PLLDivQ above 4 bits would
     * corrupt PLLDivR), and a zero divider cannot produce a clock at all.
     * Both cases are rejected here, before any register is written. */
    if ((IS_SMU_PLLDIVN_VALUE(pPll->PLLDivN) == 0U) ||
        (IS_SMU_PLLDIVF_VALUE(pPll->PLLDivF) == 0U) ||
        (IS_SMU_PLLDIVQ_VALUE(pPll->PLLDivQ) == 0U) ||
        (IS_SMU_PLLDIVR_VALUE(pPll->PLLDivR) == 0U))
    {
        return HAL_ERROR;
    }

    fclkin = SMU_GetPllInputFreq(pPll->PLLSource);
    if ((fclkin < SMU_PLL_IN_MIN) || (fclkin > SMU_PLL_IN_MAX))
    {
        return HAL_ERROR;
    }

    if (((fclkin / pPll->PLLDivN) < SMU_PLL_PFD_MIN) ||
        ((fclkin / pPll->PLLDivN) > SMU_PLL_PFD_MAX))
    {
        return HAL_ERROR;
    }

    /* 64 bit intermediate: FCLKIN * PLLDivF overflows a 32 bit product over the
     * upper half of the PLLDivF range */
    vco = (uint32)(((uint64)fclkin * (uint64)pPll->PLLDivF) / (uint64)pPll->PLLDivN);
    if ((vco < SMU_PLL_VCO_MIN) || (vco > SMU_PLL_VCO_MAX))
    {
        return HAL_ERROR;
    }

    clkq = vco / pPll->PLLDivQ;
    clkr = vco / pPll->PLLDivR;

    if ((clkq < SMU_PLL_CLKQ_MIN) || (clkq > SMU_PLL_CLKQ_MAX))
    {
        return HAL_ERROR;
    }

    if ((clkr < SMU_PLL_CLKR_MIN) || (clkr > SMU_PLL_CLKR_MAX))
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Reject the source changes that would leave the system without a clock.
 * @note   The condition is evaluated before the first register write, so that a
 *         rejected request leaves the SMU untouched instead of applying the
 *         oscillator part and then aborting on the PLL part.
 *         The request is refused when the PLL is enabled from an FIRC that is
 *         (or becomes) powered down.
 * @note   The two other protections of an earlier revision - "the PLL is
 *         reconfigured while it is the current system clock source" and "the
 *         running PLL is disabled while it is the current system clock source"
 *         - are gone on purpose: those requests are now made safe instead of
 *         being refused. HAL_SMU_OscConfig() hands the system clock over to the
 *         FIRC before it reprograms or disables the PLL that currently clocks
 *         the core, so the request is accepted whatever the state the device was
 *         started in. Refusing it instead made the outcome depend on whether the
 *         device had really been reset (the system clock source register keeps
 *         the PLL selected across a download that does not reset it).
 * @note   The FIRC power-down request itself is still handled in the FIRC
 *         section of HAL_SMU_OscConfig: it is checked there before the FIRC
 *         register is written, so it never leaves a partial configuration.
 * @param  pOscInit: pointer to the requested oscillator configuration.
 * @retval HAL_StatusTypeDef: HAL_OK when the request is acceptable, HAL_ERROR
 *         when it must be refused.
 */
static HAL_StatusTypeDef SMU_CheckOscRequest(const SMU_OscInitTypeDef *pOscInit)
{
    uint32 firc_powered_down = 0U;

    /* Effective FIRC power state once the request has been applied: the request
     * decides when it drives the FIRC, otherwise the current state is kept */
    if ((pOscInit->OscillatorType & SMU_OSCILLATORTYPE_FIRC) == SMU_OSCILLATORTYPE_FIRC)
    {
        firc_powered_down = (pOscInit->FIRCState == SMU_FIRC_OFF) ? 1U : 0U;
    }
    else
    {
        firc_powered_down = (HAL_IS_BIT_SET(SMU->FIRCCFGR, SMU_FIRCCFGR_FIRCON) != 0U) ? 1U : 0U;
    }

    /* The PLL may be reprogrammed even while it clocks the system: the caller
     * (HAL_SMU_OscConfig) moves the system clock back to the FIRC first, so the
     * following request is only refused when the result would leave the device
     * without a usable clock - i.e. when the FIRC would be powered down while
     * it is the system clock or while it feeds a running PLL.
     * Refusing "the PLL is running while the PLL is reconfigured" instead (the
     * previous rule) made the request outcome depend on how the device was
     * started, because SYSSEL survives a download that does not reset it. */
    if ((pOscInit->PLL.PLLState == SMU_PLL_ON) &&
        (pOscInit->PLL.PLLSource == SMU_PLLSOURCE_FIRC) && (firc_powered_down != 0U))
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Update one bus divider with the bus clock closed during the update.
 * @note   Changing the clock frequency of a bus requires the clock enable of
 *         that bus to be switched off first and switched back to its previous
 *         value afterwards. The divided clock of the device has no stable
 *         indicator, so no wait is inserted.
 * @param  FieldMask: mask of the divider field inside SMU_BUSCFGR.
 * @param  FieldPos: position of the divider field inside SMU_BUSCFGR.
 * @param  Div: requested divider encoding.
 * @param  pBusCfg: pointer to the bus configuration register that owns the
 *         clock enable bit of the bus.
 * @param  ClkEnBit: clock enable bit of that bus.
 * @retval None
 */
static void SMU_SetBusDivider(uint32 FieldMask, uint32 FieldPos, uint32 Div,
                              __IO uint32 *pBusCfg, uint32 ClkEnBit)
{
    uint32 was_enabled = 0U;

    if (((SMU->BUSCFGR & FieldMask) >> FieldPos) == Div)
    {
        /* The divider already holds the requested value */
        return;
    }

    was_enabled = *pBusCfg & ClkEnBit;

    CLEAR_BIT(*pBusCfg, ClkEnBit);

    MODIFY_REG(SMU->BUSCFGR, FieldMask, (Div << FieldPos));

    if (was_enabled != 0U)
    {
        SET_BIT(*pBusCfg, ClkEnBit);
    }
}

/* Exported functions ---------------------------------------------------------*/

/** @addtogroup SMU_Exported_Functions_Group1
  * @{
  */

/**
 * @brief  Initialize the SMU handle. (NON-BLOCKING)
 * @note   The handle carries the synchronization state of the driver (lock /
 *         state / error code) and the last applied clock tree configuration
 *         (Init / ClockInit); the clock tree itself is programmed by
 *         HAL_SMU_OscConfig() and HAL_SMU_ClockConfig().
 * @note   The low level initialization is performed by HAL_SMU_MspInit(), which
 *         is empty by default (the SMU is always clocked and has no interrupt).
 *         It is executed only once, when the handle state is HAL_SMU_STATE_RESET
 *         (MSP-04).
 * @note   This function does not wait for any hardware event: the lock is
 *         acquired with an infinite wait, as in the rest of the library.
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (NULL pointer, invalid instance
 *         or the handle lock could not be taken).
 */
HAL_StatusTypeDef HAL_SMU_Init(HAL_SMU_HandleTypeDef *hsmu)
{
    /* Check the SMU peripheral handle and instance */
    if (SMU_HandleIsValid(hsmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Allocate the lock resource before the first use, so that a handle that
     * was never initialized cannot report HAL_BUSY from a stale Lock field */
    if (hsmu->State == HAL_SMU_STATE_RESET)
    {
        hsmu->Lock = HAL_UNLOCKED;

        /* Initialize the low level hardware (empty by default). LOCK-06: the
         * MSP callback runs before the handle is locked */
        HAL_SMU_MspInit(hsmu);
    }

    /* Process locked */
    if (SMU_LockHandle(hsmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_ERROR;
    }

    /* Reset the error code and mark the handle as ready */
    hsmu->ErrorCode = HAL_SMU_ERROR_NONE;
    hsmu->State     = HAL_SMU_STATE_READY;

    /* Release Lock */
    SMU_UnlockHandle(hsmu);

    return HAL_OK;
}

/**
 * @brief  De-initialize the SMU to its default reset state. (BLOCKING)
 * @note   Implementation details:
 *         - If the PLL is currently the system clock source, the system clock
 *           is first switched back to the FIRC (the FIRC is powered on and its
 *           ready flag is polled until the Timeout expires);
 *         - The PLL is disabled and held in reset, the FIRC calibration is
 *           cleared, and the bus dividers are restored to /1;
 *         - The bus peripheral clock gates and reset bits (AB0CFGR ... APB1CFGR)
 *           are NOT touched, so that the already enabled peripheral clocks are
 *           kept.
 * @note   The handle state is set back to HAL_SMU_STATE_RESET and the low level
 *         de-initialization is performed by HAL_SMU_MspDeInit(), so that a
 *         following HAL_SMU_Init() re-runs HAL_SMU_MspInit().
 * @note   This function is callable from any handle state (ARCH-CONST-09).
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the FIRC to become ready, in ms
 *         (HAL_MAX_DELAY waits forever, 0 does not wait). The FIRC start-up
 *         only takes a few microseconds in practice, so a small value (for
 *         example 100 ms) is sufficient.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (NULL pointer or invalid
 *         instance) / HAL_BUSY / HAL_TIMEOUT if the FIRC does not become ready
 *         before the Timeout expires (the state is then HAL_SMU_STATE_TIMEOUT
 *         and the error code HAL_SMU_ERROR_TIMEOUT).
 */
HAL_StatusTypeDef HAL_SMU_DeInit(HAL_SMU_HandleTypeDef *hsmu, uint32 Timeout)
{
    uint32 tmpreg = 0U;
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the SMU peripheral handle and instance */
    if (SMU_HandleIsValid(hsmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Process locked */
    status = SMU_LockHandle(hsmu, Timeout);
    if (status != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return status;
    }

    /* Clear the error code and enter the busy state */
    hsmu->ErrorCode = HAL_SMU_ERROR_NONE;
    hsmu->State     = HAL_SMU_STATE_BUSY;

    /* If the PLL is the current system clock source, switch back to FIRC */
    if (__HAL_SMU_GET_SYSCLK_SOURCE() == SMU_SYSCLKSOURCE_PLL)
    {
        /* Power on the FIRC and wait until it is ready */
        __HAL_SMU_FIRC_ENABLE();

        status = SMU_WaitFIRCReady(Timeout);
        if (status != HAL_OK)
        {
            hsmu->ErrorCode |= HAL_SMU_ERROR_TIMEOUT;
        }
        else
        {
            __HAL_CLEAR_STRUCT(&hflash);
            hflash.Instance = EFLASH;
            hflash.Init.ClockFreq = FIRC_VALUE / 1000000U;

            (void)HAL_FLASH_SetClockFrequency(&hflash, (uint16)hflash.Init.ClockFreq);
            /* Switch the system clock source to the FIRC */
            __HAL_SMU_SYSCLK_CONFIG(SMU_SYSCLKSOURCE_FIRC);

            __HAL_SMU_EFLASH_CLK_UPDATE_ENABLE();
            __HAL_SMU_EFLASH_CLK_UPDATE_DISABLE();
        }
    }

    if (status == HAL_OK)
    {
        /* Disable the PLL and hold it in reset */
        __HAL_SMU_PLL_DISABLE();
        __HAL_SMU_PLL_RESET_ASSERT();

        /* Clear the FIRC calibration value */
        __HAL_SMU_FIRC_CALIBRATION_CONFIG(0U);

        /* Restore the default system clock selection and the /1 bus dividers
         * (PLL source = FIRC, system clock = FIRC) */
        tmpreg = (SMU_AXI4BUS3CLK_DIV1 << SMU_BUSCFGR_AXI4BUS3DIV_Pos) |
                 (SMU_APBBUS0CLK_DIV1   << SMU_BUSCFGR_APBBUS0DIV_Pos)  |
                 (SMU_APBBUS1CLK_DIV1   << SMU_BUSCFGR_APBBUS1DIV_Pos)  |
                 (SMU_CANX2CLK_DIV1     << SMU_BUSCFGR_CANX2DIV_Pos);
        SMU->BUSCFGR = tmpreg;

        /* The handle goes back to the reset state so that a following
         * HAL_SMU_Init() runs the low level initialization again */
        hsmu->State = HAL_SMU_STATE_RESET;
    }
    else
    {
        /* ARCH-CONST-09: the timeout / error state is recoverable, a new
         * operation may be called directly */
        hsmu->State = (status == HAL_TIMEOUT) ? HAL_SMU_STATE_TIMEOUT : HAL_SMU_STATE_ERROR;
    }

    /* Release Lock */
    SMU_UnlockHandle(hsmu);

    /* LOCK-06 / ARCH-CONST-04: the low level de-initialization and the time
     * base refresh run OUTSIDE the locked region, as the architecture
     * specification requires for the MSP callbacks ("MspDeInit is called
     * after the unlock") and for the weak HAL_InitTick() callback (a user
     * override may take an RTOS lock, which would deadlock while
     * hsmu->LockMutex is held). HAL_SMU_MspDeInit() may call other HAL APIs
     * (e.g. HAL_GPIO_DeInit()), which is only allowed outside the lock. */
    if (status == HAL_OK)
    {
        HAL_SMU_MspDeInit(hsmu);

        SystemCoreClock = HAL_SMU_GetSysClockFreq();
        (void)HAL_InitTick();
    }

    return status;
}

/**
 * @brief  Initialize the oscillator (FIRC / OSC), the PLL and the system clock
 *         source according to the specified parameters in the
 *         SMU_OscInitStruct. (BLOCKING)
 * @note   The OSC is managed by the hardware and needs no software
 *         configuration: it is not touched even when OscillatorType includes
 *         SMU_OSCILLATORTYPE_OSC (the PLL source selection alone decides
 *         whether the PLL is clocked by the OSC or the FIRC).
 * @note   The FIRC (calibration value and power state) is configured only when
 *         OscillatorType includes SMU_OSCILLATORTYPE_FIRC, and its power state
 *         is then driven by the FIRCState field alone: the FIRC is powered on
 *         and waited for when FIRCState is SMU_FIRC_ON, and powered down when
 *         FIRCState is SMU_FIRC_OFF (with the protection that the FIRC cannot
 *         be powered down while it powers the CPU or the running PLL).
 * @note   SYSCLKSelect is applied at the end of this function: the selected
 *         source is always brought up and confirmed ready before the system
 *         clock is switched to it (the FIRC ready flag and the PLL lock flag
 *         are polled until the Timeout expires), and a PLL that was never
 *         programmed is rejected with HAL_ERROR instead of being selected.
 *         SystemCoreClock is refreshed and the HAL time base is re-initialized
 *         with HAL_InitTick() at the end of EVERY call, whether the request was
 *         applied or refused, so that the frequency base always describes the
 *         hardware. The bus dividers are NOT
 *         programmed here: they are programmed by HAL_SMU_ClockConfig().
 * @note   Protection: a clock source (FIRC / PLL) that is currently used as the
 *         system clock source cannot be disabled or reconfigured in place. When
 *         the request must reprogram the PLL that currently clocks the system,
 *         the system clock is first handed over to the FIRC (which always runs
 *         in that configuration) and the PLL is reprogrammed afterwards; the
 *         request is only refused when the result would leave the device
 *         without a usable clock, i.e. when the FIRC would be powered down
 *         while it is the system clock or while it feeds a running PLL.
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @param  SMU_OscInitStruct: pointer to a SMU_OscInitTypeDef structure that
 *         contains the configuration information for the oscillators, the PLL
 *         and the system clock source.
 * @param  Timeout: maximum wait time, in ms, applied to EACH hardware wait of
 *         this call (the FIRC ready flag and the PLL lock flag; the value is
 *         also used as the mutex acquisition timeout in an RTOS build). The
 *         worst case of a full oscillator + PLL + system clock configuration is
 *         therefore about three times the Timeout. HAL_MAX_DELAY waits forever,
 *         0 does not wait (the hardware gets a single chance).
 *         @ref SMU_TIMEOUT_DEFAULT is a value that covers a PLL lock
 *         comfortably.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (NULL pointer, invalid
 *         parameter, source protection or the handle is not initialized) /
 *         HAL_BUSY / HAL_TIMEOUT (the operation timed out; the state is then
 *         HAL_SMU_STATE_TIMEOUT and the error code HAL_SMU_ERROR_TIMEOUT).
 */
HAL_StatusTypeDef HAL_SMU_OscConfig(HAL_SMU_HandleTypeDef *hsmu, SMU_OscInitTypeDef *SMU_OscInitStruct,
                                    uint32 Timeout)
{
    uint32 sysclk_source = 0U;
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the SMU peripheral handle and instance */
    if (SMU_HandleIsValid(hsmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check Null pointer */
    if (SMU_OscInitStruct == NULL_PTR)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_SMU_Init() is
     * required first) */
    status = SMU_CheckState(hsmu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Check the parameters */
    assert_param(IS_SMU_OSCILLATORTYPE(SMU_OscInitStruct->OscillatorType));
    assert_param(IS_SMU_SYSCLKSOURCE(SMU_OscInitStruct->SYSCLKSelect));
    if ((SMU_OscInitStruct->OscillatorType & SMU_OSCILLATORTYPE_FIRC) == SMU_OSCILLATORTYPE_FIRC)
    {
        assert_param(IS_SMU_FIRC_STATE(SMU_OscInitStruct->FIRCState));
    }
    if (SMU_OscInitStruct->PLL.PLLState != SMU_PLL_NONE)
    {
        assert_param(IS_SMU_PLL_STATE(SMU_OscInitStruct->PLL.PLLState));
        assert_param(IS_SMU_PLLSOURCE(SMU_OscInitStruct->PLL.PLLSource));
        assert_param(IS_SMU_PLLDIVR_VALUE(SMU_OscInitStruct->PLL.PLLDivR));
        assert_param(IS_SMU_PLLDIVQ_VALUE(SMU_OscInitStruct->PLL.PLLDivQ));
        assert_param(IS_SMU_PLLDIVN_VALUE(SMU_OscInitStruct->PLL.PLLDivN));
        assert_param(IS_SMU_PLLDIVF_VALUE(SMU_OscInitStruct->PLL.PLLDivF));
    }

    /* Process locked */
    status = SMU_LockHandle(hsmu, Timeout);
    if (status != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return status;
    }

    /* Clear the error code and enter the busy state */
    hsmu->ErrorCode = HAL_SMU_ERROR_NONE;
    hsmu->State = HAL_SMU_STATE_BUSY;

    /* Get the current system clock source. A source that is about to be
     * reprogrammed is handed over first (see below), so this variable is kept
     * up to date as the hand-over happens. */
    sysclk_source = __HAL_SMU_GET_SYSCLK_SOURCE();

    /* --------------------- Safe hand-over from the PLL --------------------- */
    /* When the system clock is currently the PLL (SYSSEL = PLL) it must be
     * moved back to the 16 MHz FIRC before the PLL is reprogrammed: the PLL is
     * re-latched by this call, and re-latching it while it clocks the core
     * would leave the core without a stable clock.
     * The FIRC always runs here - it is the PLL input in this configuration and
     * its power-down is refused below while it feeds a running PLL - so the
     * source is safe to select, and no readiness wait is needed (the same
     * sequence is used by HAL_SMU_DeInit). */
    if (((SMU_OscInitStruct->PLL.PLLState == SMU_PLL_ON) ||
         (SMU_OscInitStruct->PLL.PLLState == SMU_PLL_OFF)) &&
        (sysclk_source == SMU_SYSCLKSOURCE_PLL))
    {
        /* Power on the FIRC and wait until it is ready before selecting it as
         * the system clock (the same sequence as HAL_SMU_DeInit). The FIRC is
         * normally already running - it is the PLL input whenever PLLSEL = FIRC
         * and its power-down is refused below while it feeds a running PLL - so
         * the ready flag is already set and the wait returns immediately. */
        __HAL_SMU_FIRC_ENABLE();

        if (SMU_WaitFIRCReady(Timeout) != HAL_OK)
        {
            hsmu->ErrorCode |= HAL_SMU_ERROR_TIMEOUT;
            status = HAL_ERROR;
        }
        else
        {
            __HAL_CLEAR_STRUCT(&hflash);
            hflash.Instance = EFLASH;
            hflash.Init.ClockFreq = FIRC_VALUE / 1000000U;

            (void)HAL_FLASH_SetClockFrequency(&hflash, (uint16)hflash.Init.ClockFreq);

            __HAL_SMU_SYSCLK_CONFIG(SMU_SYSCLKSOURCE_FIRC);
            sysclk_source = SMU_SYSCLKSOURCE_FIRC;

            __HAL_SMU_EFLASH_CLK_UPDATE_ENABLE();
            __HAL_SMU_EFLASH_CLK_UPDATE_DISABLE();
        }
    }

    /* ------------------ Pre-write validation and rejection ----------------- */
    /* Every rejection condition is evaluated before the first register write,
     * so that a refused request leaves the clock tree untouched instead of
     * applying the oscillator part and aborting on the PLL part. The outcome is
     * carried by status: LOCK-02 requires the lock held region to hold a single
     * exit point, so no return statement is used here. */
    if (status != HAL_OK)
    {
        /* The hand-over could not be completed, so the clock tree is left the
         * way it was (the system clock may still be the PLL) and nothing else is
         * programmed. status already carries the reason. */
    }
    else if (SMU_CheckOscRequest(SMU_OscInitStruct) != HAL_OK)
    {
        hsmu->ErrorCode |= HAL_SMU_ERROR_CLOCK_SOURCE;
        status = HAL_ERROR;
    }
    /* Reject a divider set whose resulting frequencies leave the PLL electrical
     * range: the encoding checks of the parameter block cannot catch it. The
     * divider chain is only used when the PLL is requested on, so the check is
     * skipped for SMU_PLL_OFF / SMU_PLL_NONE (a caller that only disables the
     * PLL may leave the divider fields cleared). */
    else if ((SMU_OscInitStruct->PLL.PLLState == SMU_PLL_ON) &&
             (SMU_CheckPllFreqDomain(&SMU_OscInitStruct->PLL) != HAL_OK))
    {
        hsmu->ErrorCode |= HAL_SMU_ERROR_INVALID_PARAM;
        status = HAL_ERROR;
    }
    else
    {
        /* The request passed the pre-write validation */
    }

    /* ------------------------- FIRC configuration ------------------------- */
    if ((status == HAL_OK) &&
        ((SMU_OscInitStruct->OscillatorType & SMU_OSCILLATORTYPE_FIRC) == SMU_OSCILLATORTYPE_FIRC))
    {
        if (SMU_OscInitStruct->FIRCState == SMU_FIRC_ON)
        {
            /* Adjust the FIRC calibration value, power on the FIRC and wait
             * until it is ready */
            __HAL_SMU_FIRC_CALIBRATION_CONFIG(SMU_OscInitStruct->FIRCCalibrationValue);
            __HAL_SMU_FIRC_ENABLE();

            status = SMU_WaitFIRCReady(Timeout);
        }
        else
        {
            /* Protection: the FIRC cannot be powered down while it powers the
             * CPU or the running PLL */
            if ((sysclk_source == SMU_SYSCLKSOURCE_FIRC) ||
                ((__HAL_SMU_GET_PLL_SOURCE() == SMU_PLLSOURCE_FIRC) &&
                 (HAL_IS_BIT_SET(SMU->PLLCFGR, SMU_PLLCFGR_PLLEN) != 0U)))
            {
                hsmu->ErrorCode |= HAL_SMU_ERROR_CLOCK_SOURCE;
                status = HAL_ERROR;
            }
            else
            {
                __HAL_SMU_FIRC_DISABLE();
            }
        }
    }

    /* ------------------------- PLL configuration -------------------------- */
    /* The PLL source protections (reconfiguring the PLL while it clocks the
     * system, enabling it from a powered down FIRC, disabling the running PLL)
     * are evaluated by the pre-write guard above, so that a refused request
     * does not leave the FIRC part applied */
    if (status == HAL_OK)
    {
        if (SMU_OscInitStruct->PLL.PLLState == SMU_PLL_ON)
        {
            /* Program the PLL with separate accesses, in this order, and write
             * the update request LAST - after the input source is selected:
             *   1. the N / F / Q / R dividers,
             *   2. the reset release (PLLRST) and the enable (PLLEN),
             *   3. the input source (PLLSEL),
             *   4. the update request (PLLUF): this is the access that latches
             *      the divider values and the source into the PLL,
             *   5. the lock wait.
             * The update request must NOT be written together with the dividers.
             * Doing so latched the PLL while its input source was still the
             * 16 MHz FIRC, and this device does not re-latch by itself when only
             * the source changes afterwards: the PLL kept running from the FIRC
             * instead of locking to the 20 MHz OSC. Measured on the board, the
             * core ran at 180 MHz x 16/20 = 144 MHz (every delay 25 % long)
             * while the driver, reading PLLSEL = OSC, reported the expected
             * 180 MHz, so the error was invisible in SystemCoreClock.
             * The PLL is deliberately NOT stopped and NOT held in reset first:
             * the power-on value of PLLCFGR (0x00E15A10) already carries
             * PLLEN = 1 and PLLRST = 1, i.e. the PLL runs from the FIRC as soon
             * as the device leaves reset, and stopping it only risks feeding the
             * core an unlocked clock. The core is guaranteed not to run from the
             * PLL here: the hand-over at the top of this function moves the
             * system clock back to the FIRC when the request is about to
             * reprogram the PLL that currently clocks it. */
            MODIFY_REG(SMU->PLLCFGR,
                       (SMU_PLLCFGR_PLLN | SMU_PLLCFGR_PLLF |
                        SMU_PLLCFGR_PLLQ | SMU_PLLCFGR_PLLR),
                       ((SMU_OscInitStruct->PLL.PLLDivN << SMU_PLLCFGR_PLLN_Pos) |
                        (SMU_OscInitStruct->PLL.PLLDivF << SMU_PLLCFGR_PLLF_Pos) |
                        (SMU_OscInitStruct->PLL.PLLDivQ << SMU_PLLCFGR_PLLQ_Pos) |
                        (SMU_OscInitStruct->PLL.PLLDivR << SMU_PLLCFGR_PLLR_Pos)));

            /* Release the reset and enable the PLL (the reset is released
             * explicitly: the request must not depend on an undocumented
             * power-on value) */
            __HAL_SMU_PLL_RESET_RELEASE();
            __HAL_SMU_PLL_ENABLE();

            /* Select the PLL clock source BEFORE the update request, so that the
             * values latched by the request are clocked by the new source */
            __HAL_SMU_PLLSOURCE_CONFIG(SMU_OscInitStruct->PLL.PLLSource);

            /* Update request: latch the dividers and the source into the PLL,
             * then wait until it is locked from the new source */
            SET_BIT(SMU->PLLCFGR, SMU_PLLCFGR_PLLUF);

            status = SMU_WaitPLLLocked(Timeout);
        }
        else if (SMU_OscInitStruct->PLL.PLLState == SMU_PLL_OFF)
        {
            /* Disable the PLL and hold it in reset */
            __HAL_SMU_PLL_DISABLE();
            __HAL_SMU_PLL_RESET_ASSERT();
        }
        else /* SMU_PLL_NONE */
        {
            /* No PLL configuration requested */
        }
    }

    /* --------------------- System clock source selection ------------------ */
    if (status == HAL_OK)
    {
        switch (SMU_OscInitStruct->SYSCLKSelect)
        {
            case SMU_SYSCLKSOURCE_FIRC:
                /* Power on the FIRC when it is not ready yet, then wait until
                 * it is ready before switching the system clock to it */
                if (__HAL_SMU_GET_FIRC_READY() == 0U)
                {
                    __HAL_SMU_FIRC_ENABLE();
                }

                status = SMU_WaitFIRCReady(Timeout);
                break;

            case SMU_SYSCLKSOURCE_PLL:
                /* The PLL may only be selected once it is enabled and its
                 * dividers have been programmed (see SMU_IsPLLConfigured()) */
                if (SMU_IsPLLConfigured() == 0U)
                {
                    hsmu->ErrorCode |= HAL_SMU_ERROR_CLOCK_SOURCE;
                    status = HAL_ERROR;
                }
                else
                {
                    status = SMU_WaitPLLLocked(Timeout);
                }
                break;

            case SMU_SYSCLKSOURCE_OSC:
                /* The OSC is hardware managed and is assumed to be stable */
                break;

            default:
                /* Unsupported clock source */
                hsmu->ErrorCode |= HAL_SMU_ERROR_INVALID_PARAM;
                status = HAL_ERROR;
                break;
        }
    }

    /* ------------------------ Clock tree update --------------------------- */
    if (status == HAL_OK)
    {
        __HAL_CLEAR_STRUCT(&hflash);
        hflash.Instance = EFLASH;
        if (SMU_OscInitStruct->SYSCLKSelect == SMU_SYSCLKSOURCE_FIRC)
        {
            hflash.Init.ClockFreq = FIRC_VALUE / 1000000U;
        }
        else if (SMU_OscInitStruct->SYSCLKSelect == SMU_SYSCLKSOURCE_PLL)
        {
            hflash.Init.ClockFreq = (uint32)(((uint64)SMU_GetPllInputFreq(SMU_OscInitStruct->PLL.PLLSource) * (uint64)SMU_OscInitStruct->PLL.PLLDivF) / (uint64)SMU_OscInitStruct->PLL.PLLDivN) / SMU_OscInitStruct->PLL.PLLDivQ / 1000000U;
        }
        else if (SMU_OscInitStruct->SYSCLKSelect == SMU_SYSCLKSOURCE_OSC)
        {
            hflash.Init.ClockFreq = OSC_VALUE / 1000000U;
        }
        else {
            return HAL_ERROR;
        }
        (void)HAL_FLASH_SetClockFrequency(&hflash, (uint16)hflash.Init.ClockFreq);

        /* Switch the system clock source to the selected source */
        __HAL_SMU_SYSCLK_CONFIG(SMU_OscInitStruct->SYSCLKSelect);

        __HAL_SMU_EFLASH_CLK_UPDATE_ENABLE();
        __HAL_SMU_EFLASH_CLK_UPDATE_DISABLE();

        /* Keep the applied configuration in the handle (the meta fields are
         * normalized so that the stored copy stays well formed even when the
         * caller did not fill them) */
        hsmu->Init = *SMU_OscInitStruct;
        hsmu->Init.Size    = sizeof(SMU_OscInitTypeDef);
        hsmu->Init.Version = SMU_OSC_INIT_VERSION;

        hsmu->State = HAL_SMU_STATE_READY;
    }
    else
    {
        if (status == HAL_TIMEOUT)
        {
            /* ARCH-CONST-09: the timeout state is recoverable */
            hsmu->ErrorCode |= HAL_SMU_ERROR_TIMEOUT;
            hsmu->State = HAL_SMU_STATE_TIMEOUT;
        }
        else
        {
            hsmu->State = HAL_SMU_STATE_ERROR;
        }
    }

    /* Release Lock */
    SMU_UnlockHandle(hsmu);

    /* Refresh the frequency base in EVERY case, not only on success.
     * SystemCoreClock must always describe the hardware: it is the scale of the
     * HAL time base, of HAL_Delay() and of every driver timeout. A refused or
     * partially applied request still leaves a running clock tree (the
     * hand-over above may already have moved the system clock back to the
     * FIRC), and a request that is applied must publish the new frequency.
     * This used to run only when status == HAL_OK, so a refused request left
     * SystemCoreClock at its reset value; measured on the board after a
     * download that does not reset the device, that turned a 500 ms delay into
     * roughly 50 ms (16 MHz assumed against the 180 MHz actually running).
     * ARCH-CONST-04 / LOCK-05: both calls stay outside the locked region;
     * HAL_InitTick() is a weak callback a user override may take a lock in.
     * The new SystemCoreClock value is in place before the tick is re-anchored. */
    SystemCoreClock = HAL_SMU_GetSysClockFreq();
    (void)HAL_InitTick();

    return status;
}

/**
 * @brief  Initialize the bus clock dividers according to the specified
 *         parameters in the SMU_ClockInitStruct. (NON-BLOCKING)
 * @note   Only the bus clock dividers (AXI4Bus3 / APBBus0 / APBBus1 /
 *         CANCLKx2) are programmed here: the system clock source is selected by
 *         HAL_SMU_OscConfig(), which also waits for it to be ready. Programming
 *         the dividers never changes the core clock, so SystemCoreClock does
 *         not need to be updated by this function.
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @param  SMU_ClockInitStruct: pointer to a SMU_ClockInitTypeDef structure that
 *         contains the bus clock divider configuration.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (NULL pointer, invalid
 *         parameter or the handle is not initialized) / HAL_BUSY.
 */
HAL_StatusTypeDef HAL_SMU_ClockConfig(HAL_SMU_HandleTypeDef *hsmu, SMU_ClockInitTypeDef *SMU_ClockInitStruct)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the SMU peripheral handle and instance */
    if (SMU_HandleIsValid(hsmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check Null pointer */
    if (SMU_ClockInitStruct == NULL_PTR)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_SMU_Init() is
     * required first) */
    status = SMU_CheckState(hsmu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Check the parameters */
    assert_param(IS_SMU_AXI4BUS3CLKDIV(SMU_ClockInitStruct->AXI4Bus3CLKDiv));
    assert_param(IS_SMU_APBBUS0CLKDIV(SMU_ClockInitStruct->APBBus0CLKDiv));
    assert_param(IS_SMU_APBBUS1CLKDIV(SMU_ClockInitStruct->APBBus1CLKDiv));
    assert_param(IS_SMU_CANX2CLKDIV(SMU_ClockInitStruct->CANX2CLKDiv));

    /* Process locked (no hardware wait: the lock is taken with an infinite
     * wait, as in the rest of the library) */
    status = SMU_LockHandle(hsmu, HAL_MAX_DELAY);
    if (status != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return status;
    }

    /* Clear the error code and enter the busy state */
    hsmu->ErrorCode = HAL_SMU_ERROR_NONE;
    hsmu->State = HAL_SMU_STATE_BUSY;

    /* Configure the bus clock dividers (the system clock selection field
     * SYSSEL and the PLL source field PLLSEL are preserved). The clock of the
     * bus that owns a divider is switched off while that divider is updated and
     * restored to its previous state afterwards. */
    SMU_SetBusDivider(SMU_BUSCFGR_AXI4BUS3DIV_Msk, SMU_BUSCFGR_AXI4BUS3DIV_Pos,
                      SMU_ClockInitStruct->AXI4Bus3CLKDiv,
                      &SMU->AB3CFGR, SMU_AB3CFGR_AXIBUS3EN);
    SMU_SetBusDivider(SMU_BUSCFGR_APBBUS0DIV_Msk, SMU_BUSCFGR_APBBUS0DIV_Pos,
                      SMU_ClockInitStruct->APBBus0CLKDiv,
                      &SMU->APB0CFGR, SMU_APB0CFGR_APBBUS0EN);
    SMU_SetBusDivider(SMU_BUSCFGR_APBBUS1DIV_Msk, SMU_BUSCFGR_APBBUS1DIV_Pos,
                      SMU_ClockInitStruct->APBBus1CLKDiv,
                      &SMU->APB1CFGR, SMU_APB1CFGR_APBBUS1EN);

    /* The CAN clock divider belongs to the AxiLite bus domain, so both AxiLite
     * buses are closed while it changes */
    if (((SMU->BUSCFGR & SMU_BUSCFGR_CANX2DIV_Msk) >> SMU_BUSCFGR_CANX2DIV_Pos) !=
        SMU_ClockInitStruct->CANX2CLKDiv)
    {
        uint32 alb1_enabled = SMU->ALB1CFGR & SMU_ALB1CFGR_AXILITEBUS1EN;
        uint32 alb2_enabled = SMU->ALB2CFGR & SMU_ALB2CFGR_AXILITEBUS2EN;

        CLEAR_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_AXILITEBUS1EN);
        CLEAR_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_AXILITEBUS2EN);

        MODIFY_REG(SMU->BUSCFGR, SMU_BUSCFGR_CANX2DIV_Msk,
                   (SMU_ClockInitStruct->CANX2CLKDiv << SMU_BUSCFGR_CANX2DIV_Pos));

        if (alb1_enabled != 0U)
        {
            SET_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_AXILITEBUS1EN);
        }

        if (alb2_enabled != 0U)
        {
            SET_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_AXILITEBUS2EN);
        }
    }

    /* Keep the applied configuration in the handle (the meta fields are
     * normalized so that the stored copy stays well formed even when the
     * caller did not fill them) */
    hsmu->ClockInit = *SMU_ClockInitStruct;
    hsmu->ClockInit.Size    = sizeof(SMU_ClockInitTypeDef);
    hsmu->ClockInit.Version = SMU_CLOCK_INIT_VERSION;

    hsmu->State = HAL_SMU_STATE_READY;

    /* Release Lock */
    SMU_UnlockHandle(hsmu);

    return status;
}

/**
 * @brief  Initialize the SMU low level resources. (NON-BLOCKING)
 * @note   Weak function: the default implementation is empty because the SMU
 *         is the clock / reset controller itself: it has no peripheral clock
 *         gate and no interrupt to set up. The user porting layer may override
 *         it, for example to create the RTOS mutex handle (HAL_MutexCreate())
 *         used through hsmu->LockMutex.
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_SMU_MspInit(HAL_SMU_HandleTypeDef *hsmu)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hsmu);
}

/**
 * @brief  De-initialize the SMU low level resources. (NON-BLOCKING)
 * @note   Weak function: the default implementation is empty (see
 *         HAL_SMU_MspInit()).
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_SMU_MspDeInit(HAL_SMU_HandleTypeDef *hsmu)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hsmu);
}

/**
  * @}
  */

/** @addtogroup SMU_Exported_Functions_Group2
  * @{
  */

/**
 * @brief  Return the current system (core) clock frequency in Hz. (NON-BLOCKING)
 * @note   The frequency is computed from the current SMU_BUSCFGR.SYSSEL
 *         selection: FIRC_VALUE for the FIRC, OSC_VALUE for the OSC, and the
 *         PLL CLK_Q output for the PLL.
 * @retval uint32: system clock frequency in Hz.
 */
uint32 HAL_SMU_GetSysClockFreq(void)
{
    uint32 sysclk = 0U;

    switch (__HAL_SMU_GET_SYSCLK_SOURCE())
    {
        case SMU_SYSCLKSOURCE_FIRC:
            sysclk = FIRC_VALUE;
            break;
        case SMU_SYSCLKSOURCE_OSC:
            sysclk = OSC_VALUE;
            break;
        case SMU_SYSCLKSOURCE_PLL:
            sysclk = SMU_GetPLLQCLK();
            break;
        default:
            /* Unsupported clock source: fall back to FIRC */
            sysclk = FIRC_VALUE;
            break;
    }

    return sysclk;
}

/**
 * @brief  Return the current core (AXIBus0) clock frequency used by the HAL
 *         time base, i.e. the SystemCoreClock variable. (NON-BLOCKING)
 * @retval uint32: core clock frequency in Hz.
 */
uint32 HAL_SMU_GetHCLKFreq(void)
{
    return SystemCoreClock;
}

/**
 * @brief  Return the APBBus0 clock frequency in Hz. (NON-BLOCKING)
 * @note   APBBus0 = AXIBus3 / APBBus0Div, with AXIBus3 = AXIBus1 / AXI4Bus3Div
 *         and AXIBus1 = AXIBus0 (system clock) / 2.
 * @retval uint32: APBBus0 clock frequency in Hz.
 */
uint32 HAL_SMU_GetPCLK0Freq(void)
{
    uint32 axi3div = 0U;
    uint32 apbdiv = 0U;

    axi3div = (uint32)(READ_BIT(SMU->BUSCFGR, SMU_BUSCFGR_AXI4BUS3DIV) >> SMU_BUSCFGR_AXI4BUS3DIV_Pos);
    apbdiv = (uint32)(READ_BIT(SMU->BUSCFGR, SMU_BUSCFGR_APBBUS0DIV) >> SMU_BUSCFGR_APBBUS0DIV_Pos);

    return ((HAL_SMU_GetSysClockFreq() / 2U) / SMU_GetValidDivider(axi3div, 2U)) /
           SMU_GetValidDivider(apbdiv, 8U);
}

/**
 * @brief  Return the APBBus1 clock frequency in Hz. (NON-BLOCKING)
 * @note   APBBus1 = AXIBus3 / APBBus1Div, with AXIBus3 = AXIBus1 / AXI4Bus3Div
 *         and AXIBus1 = AXIBus0 (system clock) / 2.
 * @retval uint32: APBBus1 clock frequency in Hz.
 */
uint32 HAL_SMU_GetPCLK1Freq(void)
{
    uint32 axi3div = 0U;
    uint32 apbdiv = 0U;

    axi3div = (uint32)(READ_BIT(SMU->BUSCFGR, SMU_BUSCFGR_AXI4BUS3DIV) >> SMU_BUSCFGR_AXI4BUS3DIV_Pos);
    apbdiv = (uint32)(READ_BIT(SMU->BUSCFGR, SMU_BUSCFGR_APBBUS1DIV) >> SMU_BUSCFGR_APBBUS1DIV_Pos);

    return ((HAL_SMU_GetSysClockFreq() / 2U) / SMU_GetValidDivider(axi3div, 2U)) /
           SMU_GetValidDivider(apbdiv, 8U);
}

/**
 * @brief  Fill the SMU_Clocks structure with the current frequencies of all
 *         the AXI / AXI-Lite / APB / CAN clock domains. (NON-BLOCKING)
 * @note   The frequency chain follows the chip clock tree:
 *         AXIBus0 (core) = system clock; AXIBus1 = AXIBus0 / 2;
 *         AXIBus3 = AXIBus1 / AXI4Bus3Div; APBBus0/1 = AXIBus3 / APBxDiv;
 *         CANCLKx2 = PLL CLK_R / CANX2Div.
 * @param  SMU_Clocks: pointer to a SMU_ClocksTypeDef structure that will hold
 *         the clocks frequencies.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR if the system clock source is
 *         not recognized.
 */
HAL_StatusTypeDef HAL_SMU_GetClocksFreq(SMU_ClocksTypeDef *SMU_Clocks)
{
    uint32 tmpclk = 0U;
    uint32 tmpreg = 0U;

    /* Check Null pointer */
    if (SMU_Clocks == NULL_PTR)
    {
        return HAL_ERROR;
    }

    /* Compute the system (AXIBus0) clock frequency from the clock source */
    switch (__HAL_SMU_GET_SYSCLK_SOURCE())
    {
        case SMU_SYSCLKSOURCE_FIRC:
            tmpclk = FIRC_VALUE;
            break;
        case SMU_SYSCLKSOURCE_OSC:
            tmpclk = OSC_VALUE;
            break;
        case SMU_SYSCLKSOURCE_PLL:
            tmpclk = SMU_GetPLLQCLK();
            break;
        default:
            /* Unsupported clock source: error */
            return HAL_ERROR;
    }

    /* AXIBus0 clock */
    SMU_Clocks->AXIBus0_Frequency = tmpclk;

    /* AXIBus1 clock = AXIBus0 / 2 */
    SMU_Clocks->AXIBus1_Frequency = tmpclk / 2U;

    /* AXIBus2 clock = AXIBus1 */
    SMU_Clocks->AXIBus2_Frequency = SMU_Clocks->AXIBus1_Frequency;

    /* AXIBus3 clock = AXIBus1 / AXI4Bus3Div */
    tmpreg = (uint32)(READ_BIT(SMU->BUSCFGR, SMU_BUSCFGR_AXI4BUS3DIV) >> SMU_BUSCFGR_AXI4BUS3DIV_Pos);
    SMU_Clocks->AXIBus3_Frequency = SMU_Clocks->AXIBus1_Frequency / SMU_GetValidDivider(tmpreg, 2U);

    /* AXILite4Bus0 clock = AXIBus0 */
    SMU_Clocks->AXILite4Bus0_Frequency = SMU_Clocks->AXIBus0_Frequency;

    /* AXILite4Bus1 / AXILite4Bus2 clock = AXIBus3 */
    SMU_Clocks->AXILite4Bus1_Frequency = SMU_Clocks->AXIBus3_Frequency;
    SMU_Clocks->AXILite4Bus2_Frequency = SMU_Clocks->AXIBus3_Frequency;

    /* APBBus0 clock = AXIBus3 / APBBus0Div */
    tmpreg = (uint32)(READ_BIT(SMU->BUSCFGR, SMU_BUSCFGR_APBBUS0DIV) >> SMU_BUSCFGR_APBBUS0DIV_Pos);
    SMU_Clocks->APBBus0_Frequency = SMU_Clocks->AXIBus3_Frequency / SMU_GetValidDivider(tmpreg, 8U);

    /* APBBus1 clock = AXIBus3 / APBBus1Div */
    tmpreg = (uint32)(READ_BIT(SMU->BUSCFGR, SMU_BUSCFGR_APBBUS1DIV) >> SMU_BUSCFGR_APBBUS1DIV_Pos);
    SMU_Clocks->APBBus1_Frequency = SMU_Clocks->AXIBus3_Frequency / SMU_GetValidDivider(tmpreg, 8U);

    /* CANCLKx2 clock = PLL CLK_R / CANX2Div / 2 */
    tmpreg = (uint32)(READ_BIT(SMU->BUSCFGR, SMU_BUSCFGR_CANX2DIV) >> SMU_BUSCFGR_CANX2DIV_Pos);
    SMU_Clocks->CANCLKx2_Frequency = SMU_GetPLLRCLK() / SMU_GetValidDivider(tmpreg, 8U) / 2;

    return HAL_OK;
}

/**
 * @brief  Get the current oscillator, PLL and system clock source
 *         configuration into the SMU_OscInitStruct. (NON-BLOCKING)
 * @param  SMU_OscInitStruct: pointer to a SMU_OscInitTypeDef structure that
 *         will hold the read-back configuration.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (NULL pointer).
 */
HAL_StatusTypeDef HAL_SMU_GetOscConfig(SMU_OscInitTypeDef *SMU_OscInitStruct)
{
    uint32 pllcfgr = 0U;
    uint32 firccfgr = 0U;

    /* Check Null pointer */
    if (SMU_OscInitStruct == NULL_PTR)
    {
        return HAL_ERROR;
    }

    /* Read the PLLCFGR and FIRCCFGR register values */
    pllcfgr = SMU->PLLCFGR;
    firccfgr = SMU->FIRCCFGR;

    /* Oscillator type: the OSC is hardware managed and is therefore always
     * reported as available; the FIRC is reported only when it is powered on */
    SMU_OscInitStruct->OscillatorType = SMU_OSCILLATORTYPE_OSC;
    if (HAL_IS_BIT_SET(firccfgr, SMU_FIRCCFGR_FIRCON) == 0U)
    {
        SMU_OscInitStruct->OscillatorType |= SMU_OSCILLATORTYPE_FIRC;
    }

    /* FIRC state and calibration */
    if (HAL_IS_BIT_SET(firccfgr, SMU_FIRCCFGR_FIRCON))
    {
        SMU_OscInitStruct->FIRCState = SMU_FIRC_OFF;    /* FIRCON set: powered down */
    }
    else
    {
        SMU_OscInitStruct->FIRCState = SMU_FIRC_ON;
    }
    SMU_OscInitStruct->FIRCCalibrationValue = (firccfgr & SMU_FIRCCFGR_FIRCTF) >> SMU_FIRCCFGR_FIRCTF_Pos;

    /* PLL state */
    if (HAL_IS_BIT_SET(pllcfgr, SMU_PLLCFGR_PLLEN))
    {
        SMU_OscInitStruct->PLL.PLLState = SMU_PLL_ON;
    }
    else
    {
        SMU_OscInitStruct->PLL.PLLState = SMU_PLL_OFF;
    }

    /* PLL source, divide values and the system clock source */
    SMU_OscInitStruct->PLL.PLLSource = __HAL_SMU_GET_PLL_SOURCE();
    SMU_OscInitStruct->PLL.PLLDivN  = (pllcfgr & SMU_PLLCFGR_PLLN) >> SMU_PLLCFGR_PLLN_Pos;
    SMU_OscInitStruct->PLL.PLLDivF  = (pllcfgr & SMU_PLLCFGR_PLLF) >> SMU_PLLCFGR_PLLF_Pos;
    SMU_OscInitStruct->PLL.PLLDivQ  = (pllcfgr & SMU_PLLCFGR_PLLQ) >> SMU_PLLCFGR_PLLQ_Pos;
    SMU_OscInitStruct->PLL.PLLDivR  = (pllcfgr & SMU_PLLCFGR_PLLR) >> SMU_PLLCFGR_PLLR_Pos;
    SMU_OscInitStruct->SYSCLKSelect = __HAL_SMU_GET_SYSCLK_SOURCE();

    return HAL_OK;
}

/**
 * @brief  Get the current bus divider configuration into the
 *         SMU_ClockInitStruct. (NON-BLOCKING)
 * @note   The system clock source is not part of SMU_ClockInitTypeDef: it is
 *         reported by HAL_SMU_GetOscConfig().
 * @param  SMU_ClockInitStruct: pointer to a SMU_ClockInitTypeDef structure
 *         that will hold the read-back configuration.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (NULL pointer).
 */
HAL_StatusTypeDef HAL_SMU_GetClockConfig(SMU_ClockInitTypeDef *SMU_ClockInitStruct)
{
    uint32 buscfgr = 0U;

    /* Check Null pointer */
    if (SMU_ClockInitStruct == NULL_PTR)
    {
        return HAL_ERROR;
    }

    /* Read the BUSCFGR register value */
    buscfgr = SMU->BUSCFGR;

    SMU_ClockInitStruct->AXI4Bus3CLKDiv = (buscfgr & SMU_BUSCFGR_AXI4BUS3DIV) >> SMU_BUSCFGR_AXI4BUS3DIV_Pos;
    SMU_ClockInitStruct->APBBus0CLKDiv  = (buscfgr & SMU_BUSCFGR_APBBUS0DIV) >> SMU_BUSCFGR_APBBUS0DIV_Pos;
    SMU_ClockInitStruct->APBBus1CLKDiv  = (buscfgr & SMU_BUSCFGR_APBBUS1DIV) >> SMU_BUSCFGR_APBBUS1DIV_Pos;
    SMU_ClockInitStruct->CANX2CLKDiv    = (buscfgr & SMU_BUSCFGR_CANX2DIV) >> SMU_BUSCFGR_CANX2DIV_Pos;

    return HAL_OK;
}

/**
 * @brief  Check whether the specified SMU status flag is set. (NON-BLOCKING)
 * @param  SMU_FLAG: SMU_FLAG_PLLLOCK or any other SMU_FLAG_xxx value.
 * @retval 1 if the flag is set, 0 otherwise.
 */
uint32 HAL_SMU_GetFlagStatus(uint32 SMU_FLAG)
{
    /* Check the parameters */
    assert_param(IS_SMU_FLAG(SMU_FLAG));

    /* The power-on state corresponds to MCUSM[1:0] == 0b00, i.e. both MCUSM
     * bits cleared. It cannot be expressed as a single-bit mask (SMU_FLAG_PWNSTART
     * is defined as 0x0000), so it is detected specially. */
    if (SMU_FLAG == SMU_FLAG_PWNSTART)
    {
        return (READ_BIT(SMU->SR, SMU_SR_MCUSM) == 0U) ? 1U : 0U;
    }

    return __HAL_SMU_GET_FLAG(SMU_FLAG);
}

/**
 * @brief  Return the current AXI bus state of the SMU. (NON-BLOCKING)
 * @note   Read only query (SMU-REQ-041): no handle and no lock. The BUSS[2:0]
 *         field lets a low power entry sequence check that the bus is idle
 *         before a clock is switched off.
 * @retval uint32: BUSS[2:0] bus state field of the SMU status register.
 */
uint32 HAL_SMU_GetBusState(void)
{
    return ((SMU->SR & SMU_SR_BUSS_Msk) >> SMU_SR_BUSS_Pos);
}

/**
 * @brief  Return the start-up mode recorded for the current run. (NON-BLOCKING)
 * @note   Read only query (SMU-REQ-041): no handle and no lock. The remaining
 *         MCUSM[1:0] encoding is reserved and is reported as a power-on
 *         start-up.
 * @retval HAL_SMU_WorkModeTypeDef: HAL_SMU_WORKMODE_POWER_ON /
 *         HAL_SMU_WORKMODE_DEEP_SLEEP / HAL_SMU_WORKMODE_SLEEP.
 */
HAL_SMU_WorkModeTypeDef HAL_SMU_GetWorkMode(void)
{
    uint32 work_mode = 0U;

    work_mode = ((SMU->SR & SMU_SR_MCUSM_Msk) >> SMU_SR_MCUSM_Pos);

    if (work_mode == 0x00000001U)
    {
        return HAL_SMU_WORKMODE_DEEP_SLEEP;
    }

    if (work_mode == 0x00000002U)
    {
        return HAL_SMU_WORKMODE_SLEEP;
    }

    return HAL_SMU_WORKMODE_POWER_ON;
}

/**
 * @brief  Return the current SMU state of the specified handle. (NON-BLOCKING)
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @retval HAL_SMU_StateTypeDef: HAL_SMU_STATE_RESET / READY / BUSY / ERROR
 *         (HAL_SMU_STATE_RESET if hsmu is NULL).
 */
HAL_SMU_StateTypeDef HAL_SMU_GetState(HAL_SMU_HandleTypeDef *hsmu)
{
    if (hsmu == NULL_PTR)
    {
        return HAL_SMU_STATE_RESET;
    }

    return hsmu->State;
}

/**
 * @brief  Return the SMU error code of the specified handle. (NON-BLOCKING)
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @retval uint32: HAL_SMU_ERROR_NONE / INVALID_PARAM / CLOCK_SOURCE / TIMEOUT
 *         (HAL_SMU_ERROR_NONE if hsmu is NULL).
 */
uint32 HAL_SMU_GetError(HAL_SMU_HandleTypeDef *hsmu)
{
    if (hsmu == NULL_PTR)
    {
        return HAL_SMU_ERROR_NONE;
    }

    return hsmu->ErrorCode;
}

/**
  * @}
  */

/** @addtogroup SMU_Exported_Functions_Group3
  * @{
  */

/**
 * @brief  Output the selected internal clock through the SMU clock output pad
 *         (divided-by-8 variants or the SIRC clock). (NON-BLOCKING)
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @param  CLKSelect: SMU_CLKOUTMUX_xxx clock selection.
 * @retval None
 */
void HAL_SMU_MCOConfig(HAL_SMU_HandleTypeDef *hsmu, uint32 CLKSelect)
{
    uint32 tmpreg = 0U;

    /* Check the SMU peripheral handle and instance */
    if (SMU_HandleIsValid(hsmu) == 0U)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_SMU_CLKOUTMUX(CLKSelect));

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_SMU_Init() is
     * required first) */
    if (SMU_CheckState(hsmu) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (SMU_LockHandle(hsmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    /* Select the clock output mux */
    tmpreg = SMU->OTHCFGR;
    tmpreg &= ~(uint32)SMU_OTHCFGR_CLKOUTMUX;
    tmpreg |= (uint32)(CLKSelect << SMU_OTHCFGR_CLKOUTMUX_Pos);
    SMU->OTHCFGR = tmpreg;

    /* Release Lock */
    SMU_UnlockHandle(hsmu);
}

/**
 * @brief  Select the high-timer brake output signal. (NON-BLOCKING)
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @param  TimerSelect: SMU_TIMBREAK_TIM0 / SMU_TIMBREAK_TIM1 / SMU_TIMBREAK_TIM2 /
 *         SMU_TIMBREAK_TIM5.
 * @retval None
 */
void HAL_SMU_TimerBreak(HAL_SMU_HandleTypeDef *hsmu, uint32 TimerSelect)
{
    uint32 tmpreg = 0U;

    /* Check the SMU peripheral handle and instance */
    if (SMU_HandleIsValid(hsmu) == 0U)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_SMU_TIMBREAK(TimerSelect));

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_SMU_Init() is
     * required first) */
    if (SMU_CheckState(hsmu) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (SMU_LockHandle(hsmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    /* Select the timer to be break outputted */
    tmpreg = SMU->OTHCFGR;
    tmpreg &= ~(uint32)SMU_OTHCFGR_TIMBKEN;
    tmpreg |= (uint32)(TimerSelect << SMU_OTHCFGR_TIMBKEN_Pos);
    SMU->OTHCFGR = tmpreg;

    /* Release Lock */
    SMU_UnlockHandle(hsmu);
}

/**
 * @brief  Enable or disable the brake output of the selected high timers. (NON-BLOCKING)
 * @note   HAL_SMU_TimerBreak() writes the whole selection field (it selects
 *         which timers drive the brake output); this function changes only the
 *         bits of the timers given in TimerSelect, so the other timers keep
 *         their state.
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @param  TimerSelect: bit mask built from SMU_TIMBREAK_TIM0 / SMU_TIMBREAK_TIM1 /
 *         SMU_TIMBREAK_TIM2 / SMU_TIMBREAK_TIM5.
 * @param  NewState: ENABLE or DISABLE.
 * @retval None
 */
void HAL_SMU_TIMBreakCmd(HAL_SMU_HandleTypeDef *hsmu, uint32 TimerSelect, FunctionalState NewState)
{
    uint32 mask = 0U;

    /* Check the SMU peripheral handle and instance */
    if (SMU_HandleIsValid(hsmu) == 0U)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_SMU_TIMBREAK_MASK(TimerSelect));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_SMU_Init() is
     * required first) */
    if (SMU_CheckState(hsmu) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (SMU_LockHandle(hsmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    /* Enable or disable the selected timers without touching the others */
    mask = (uint32)(TimerSelect << SMU_OTHCFGR_TIMBKEN_Pos);

    if (NewState != DISABLE)
    {
        MODIFY_REG(SMU->OTHCFGR, mask, mask);
    }
    else
    {
        MODIFY_REG(SMU->OTHCFGR, mask, 0U);
    }

    /* Release Lock */
    SMU_UnlockHandle(hsmu);
}

/**
 * @brief  Enable or disable the SRAM low power mode. (NON-BLOCKING)
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @param  SRAMSelect: SMU_SRAMLOWPOWER_SRAM0 ... SMU_SRAMLOWPOWER_SRAM3.
 * @param  NewState: ENABLE or DISABLE.
 * @retval None
 */
void HAL_SMU_SetSRAMLowPower(HAL_SMU_HandleTypeDef *hsmu, uint32 SRAMSelect, FunctionalState NewState)
{
    /* Check the SMU peripheral handle and instance */
    if (SMU_HandleIsValid(hsmu) == 0U)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_FUNCTIONAL_STATE(NewState));
    assert_param(IS_SMU_SRAMLOWPOWER(SRAMSelect));

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_SMU_Init() is
     * required first) */
    if (SMU_CheckState(hsmu) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (SMU_LockHandle(hsmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    if (NewState != DISABLE)
    {
        SET_BIT(SMU->OTHCFGR, (SRAMSelect << SMU_OTHCFGR_SRAMLPEN_Pos));
    }
    else
    {
        CLEAR_BIT(SMU->OTHCFGR, (SRAMSelect << SMU_OTHCFGR_SRAMLPEN_Pos));
    }

    /* Release Lock */
    SMU_UnlockHandle(hsmu);
}

/**
 * @brief  Enable or disable the dual-core lock-step mode. (NON-BLOCKING)
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @param  NewState: ENABLE or DISABLE.
 * @retval None
 */
void HAL_SMU_DCLSCmd(HAL_SMU_HandleTypeDef *hsmu, FunctionalState NewState)
{
    /* Check the SMU peripheral handle and instance */
    if (SMU_HandleIsValid(hsmu) == 0U)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_SMU_Init() is
     * required first) */
    if (SMU_CheckState(hsmu) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (SMU_LockHandle(hsmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    if (NewState != DISABLE)
    {
        SET_BIT(SMU->OTHCFGR, SMU_OTHCFGR_DCLSEN);
    }
    else
    {
        CLEAR_BIT(SMU->OTHCFGR, SMU_OTHCFGR_DCLSEN);
    }

    /* Release Lock */
    SMU_UnlockHandle(hsmu);
}

/**
 * @brief  Enable or disable the ECC. (NON-BLOCKING)
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @param  NewState: ENABLE or DISABLE.
 * @retval None
 */
void HAL_SMU_ECCCmd(HAL_SMU_HandleTypeDef *hsmu, FunctionalState NewState)
{
    /* Check the SMU peripheral handle and instance */
    if (SMU_HandleIsValid(hsmu) == 0U)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_SMU_Init() is
     * required first) */
    if (SMU_CheckState(hsmu) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (SMU_LockHandle(hsmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    if (NewState != DISABLE)
    {
        SET_BIT(SMU->OTHCFGR, SMU_OTHCFGR_ECCEN);
    }
    else
    {
        CLEAR_BIT(SMU->OTHCFGR, SMU_OTHCFGR_ECCEN);
    }

    /* Release Lock */
    SMU_UnlockHandle(hsmu);
}

/**
 * @brief  Enable or disable the bus timeout monitoring. (NON-BLOCKING)
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @param  NewState: ENABLE or DISABLE.
 * @retval None
 */
void HAL_SMU_BUSTimeOutCmd(HAL_SMU_HandleTypeDef *hsmu, FunctionalState NewState)
{
    /* Check the SMU peripheral handle and instance */
    if (SMU_HandleIsValid(hsmu) == 0U)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_SMU_Init() is
     * required first) */
    if (SMU_CheckState(hsmu) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (SMU_LockHandle(hsmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    if (NewState != DISABLE)
    {
        SET_BIT(SMU->BUSTCFGR, SMU_BUSTCFGR_BUSTIMEOUTEN);
    }
    else
    {
        CLEAR_BIT(SMU->BUSTCFGR, SMU_BUSTCFGR_BUSTIMEOUTEN);
    }

    /* Release Lock */
    SMU_UnlockHandle(hsmu);
}

/**
 * @brief  Set the bus timeout counter value. (NON-BLOCKING)
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @param  TimeOutValue: bus timeout counter value, from SMU_BUSTIMEOUT_VALUE_MIN
 *         to SMU_BUSTIMEOUT_VALUE_MAX.
 * @retval None
 */
void HAL_SMU_SetBUSTimeOutValue(HAL_SMU_HandleTypeDef *hsmu, uint32 TimeOutValue)
{
    /* Check the SMU peripheral handle and instance */
    if (SMU_HandleIsValid(hsmu) == 0U)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_SMU_BUSTIMEOUTVALUE(TimeOutValue));

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_SMU_Init() is
     * required first) */
    if (SMU_CheckState(hsmu) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (SMU_LockHandle(hsmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    MODIFY_REG(SMU->BUSTCFGR, SMU_BUSTCFGR_BUSTIMEOUTNUM, TimeOutValue);

    /* Release Lock */
    SMU_UnlockHandle(hsmu);
}

/**
 * @brief  Clear the bus timeout flag. (NON-BLOCKING)
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @retval None
 */
void HAL_SMU_ClearTimeOutFlag(HAL_SMU_HandleTypeDef *hsmu)
{
    /* Check the SMU peripheral handle and instance */
    if (SMU_HandleIsValid(hsmu) == 0U)
    {
        return;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_SMU_Init() is
     * required first) */
    if (SMU_CheckState(hsmu) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (SMU_LockHandle(hsmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    SET_BIT(SMU->OTHCFGR, SMU_OTHCFGR_TIMEOUTCF);

    /* Release Lock */
    SMU_UnlockHandle(hsmu);
}

/**
  * @}
  */

#endif /* HAL_SMU_MODULE_ENABLED */

/*****END OF FILE*****/
