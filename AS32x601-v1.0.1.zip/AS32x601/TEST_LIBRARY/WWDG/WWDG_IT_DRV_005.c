/**
 * @file    WWDG_IT_DRV_005.c
 * @brief   HAL WWDG integration test case 005 (prescaler enable / disable).
 *
 * One-to-one HAL library port of the reference AS32x601 standard-library
 * test case WWDG_IT_DRV_005.c. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_WWDG_Init()          (programs PSC.EN and WD.WDEN)
 *   HAL_WWDG_Cmd()           (WWDG_EN_PSC / WWDG_EN_CFG)
 *   HAL_WWDG_Refresh()
 *   HAL_WWDG_GetCounter()
 *   HAL_WWDG_GetBKStatus()
 *   HAL_WWDG_GetState() / HAL_WWDG_GetError()
 *
 * Test procedure:
 *   Channel 0 of WWDG0 is programmed with a prescaler of 10, a divider of 2
 *   and a timeout value of 1000 (0.98 ms in this clock tree). The case then
 *   runs the three phases of the reference test case:
 *     Phase 1: with the configuration block started and the prescaler block
 *              disabled, the counter has to stay at 0 (the prescaler is what
 *              clocks the counter);
 *     Phase 2: enabling the prescaler block starts the counter, so the counter
 *              has to be non zero after 100 ms;
 *     Phase 3: the bark arrives and is reported through the FCU.
 *
 * Expected behaviour:
 *   PSC.EN reads back as commanded, the counter is frozen at 0 while the
 *   prescaler block is disabled, it runs once the block is enabled, the bark
 *   is reported on channel 0 and every check prints [PASS] with
 *   "summary : failures = 0".
 *
 * Note:
 *   The reference test case measures PD4 with a scope. This port keeps the
 *   PD4 marker (high while armed, low at the bark) but decides the phases from
 *   the counter value and the bark flag, so the result is automatic.
 */

/* Includes ------------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
#define TEST_BAUDRATE                 (115200U)
#define TEST_PD4_PORT                 GPIOD
#define TEST_PD4_PIN                  GPIO_PIN_4
#define TEST_WAIT_SLACK_MS            (500U)
#define TEST_PD4_ON                   GPIO_PIN_SET
#define TEST_PD4_OFF                  GPIO_PIN_RESET

#define TEST_PRESCALER                (10U)       /*!< PSC.PSCNUM (fixed)       */
#define TEST_DIVIDER                  (2U)        /*!< DIV.DIVNUM (fixed)       */
#define TEST_COUNTER                  (1000U)     /*!< TO.BVAL (fixed)          */
#define TEST_PHASE_DELAY_MS           (100U)      /*!< observation window       */

/* Private variables ---------------------------------------------------------*/
static volatile uint32        check_failures = 0U;
static HAL_SMU_HandleTypeDef  hsmu_clk;
static HAL_PMU_HandleTypeDef  hpmu_dev;

WWDG_HandleTypeDef     hwwdg_dev;
HAL_FCU_HandleTypeDef  hfcu_dev;

volatile uint32 test_bark_count   = 0U;
volatile uint32 test_bark_mask    = 0U;
volatile uint32 test_bark_counter = 0U;
volatile uint32 test_bark_mcycle  = 0U;

void Check(const char *name, uint32 condition);
void Summary(void);
void SystemClock_Init(void);
void Test_Pd4Init(void);
void Test_Pd4Set(GPIO_PinState state);
uint32 Test_McycleNow(void);
uint32 Test_McycleToUs(uint32 cycles);
void Test_BarkReset(void);
HAL_StatusTypeDef Test_WaitBark(uint32 timeout_ms);
HAL_StatusTypeDef Test_WwdgApply(uint32 prescaler, uint32 divider, uint32 counter,
                                 uint32 window, WWDG_Channel_TypeDef *instance);
void Test_FcuConfig(HAL_FCU_ChannelTypeDef channel,
                    HAL_FCU_FaultActionTypeDef fault_action,
                    HAL_FCU_AlarmActionTypeDef alarm_action,
                    HAL_FCU_FaultLevelTypeDef level);
void Test_PlicEnable(uint32 priority);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    HAL_StatusTypeDef status;
    uint32 apb_hz;
    uint32 rounds = 0U;
    uint32 counter;

    HAL_Init();
    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);

    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== WWDG_IT_DRV_005 : prescaler enable / disable ===\r\n");

    apb_hz = HAL_SMU_GetPCLK0Freq();
    printf("APBBus0 = %u Hz, prescaler = %u, divider = %u, timeout value = %u\r\n",
           PRINT_U32(apb_hz), PRINT_U32(TEST_PRESCALER),
           PRINT_U32(TEST_DIVIDER), PRINT_U32(TEST_COUNTER));
    printf("expected period = %u us\r\n",
           PRINT_U32((uint32)(((uint64)(TEST_PRESCALER + 1U) * (uint64)TEST_DIVIDER *
                               (uint64)TEST_COUNTER * 1000000ULL) / (uint64)apb_hz)));

    Test_Pd4Init();
    Test_Pd4Set(TEST_PD4_ON);
    Test_FcuConfig(HAL_FCU_CHANNEL_WWDG0, HAL_FCU_FAULT_INTERRUPT,
                   HAL_FCU_ALARM_INTERRUPT, HAL_FCU_FAULT_LEVEL_ALARM);
    Test_PlicEnable(1U);

    for (;;)
    {
        printf("-- round %u --\r\n", PRINT_U32(rounds));

        if (hwwdg_dev.State == HAL_WWDG_STATE_READY)
        {
            (void)HAL_WWDG_Cmd(&hwwdg_dev, WWDG_EN_CFG, DISABLE);
        }

        Test_BarkReset();
        Test_Pd4Set(TEST_PD4_ON);

        status = Test_WwdgApply(TEST_PRESCALER, TEST_DIVIDER, TEST_COUNTER, 0U, WWDG0_Channel0);
        Check("PSC : HAL_WWDG_Init() returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
        Check("PSC : PSC.EN is set by the initialization",
              ((READ_REG(WWDG0->PSC) & WWDG_PSC_EN) != 0U) ? 1U : 0U);
        (void)HAL_WWDG_Refresh(&hwwdg_dev);

        /* Phase 1: configuration block running, prescaler block disabled */
        printf("Phase 1 : CFG enabled, PSC disabled\r\n");
        status = HAL_WWDG_Cmd(&hwwdg_dev, WWDG_EN_PSC, DISABLE);
        Check("PSC : HAL_WWDG_Cmd(PSC, DISABLE) returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
        Check("PSC : PSC.EN reads 0 after the disable",
              ((READ_REG(WWDG0->PSC) & WWDG_PSC_EN) == 0U) ? 1U : 0U);

        status = HAL_WWDG_Cmd(&hwwdg_dev, WWDG_EN_CFG, ENABLE);
        Check("PSC : HAL_WWDG_Cmd(CFG, ENABLE) returns HAL_OK", (status == HAL_OK) ? 1U : 0U);

        delay_ms(TEST_PHASE_DELAY_MS);
        counter = (uint32)HAL_WWDG_GetCounter(&hwwdg_dev);
        Check("PSC : the counter stays at 0 while the prescaler is disabled",
              (counter == 0U) ? 1U : 0U);
        Check("PSC : no bark while the prescaler is disabled",
              (test_bark_count == 0U) ? 1U : 0U);

        /* Phase 2: re-enable the prescaler block, the counter starts running */
        printf("Phase 2 : PSC enabled\r\n");
        status = HAL_WWDG_Cmd(&hwwdg_dev, WWDG_EN_PSC, ENABLE);
        Check("PSC : HAL_WWDG_Cmd(PSC, ENABLE) returns HAL_OK", (status == HAL_OK) ? 1U : 0U);

        delay_ms(TEST_PHASE_DELAY_MS);
        counter = (uint32)HAL_WWDG_GetCounter(&hwwdg_dev);
        Check("PSC : the counter runs once the prescaler is enabled",
              (counter > 0U) ? 1U : 0U);

        /* Phase 3: the bark has to arrive */
        printf("Phase 3 : bark\r\n");
        status = Test_WaitBark(TEST_WAIT_SLACK_MS);
        Check("PSC : the bark arrives after the prescaler is enabled",
              (status == HAL_OK) ? 1U : 0U);
        Check("PSC : the bark is reported on channel 0",
              ((test_bark_mask & WWDG_FLAG_BK0) != 0U) ? 1U : 0U);

        printf("   counter after 100 ms with PSC enabled = %u, DSTA = 0x%X\r\n",
               PRINT_U32(test_bark_counter), PRINT_U32(test_bark_mask));

        Summary();
        rounds++;
        delay_ms(2000U);
    }
}

/* ==========================================================================*/
/*  Shared helpers of the suite (identical in every case of this suite)       */
/* ==========================================================================*/

/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the other integration tests of this library:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2 and
 *         CANX2 by 8, which gives core 180 MHz and APB 22.5 MHz. WWDG0 is
 *         clocked from APBBus0 and WWDG1 from APBBus1, so both watchdog
 *         instances run from the same 22.5 MHz in this tree.
 * @note   Clock tree order: the dividers are written while the system clock
 *         is still the power on source (FIRC), then the PLL is configured and
 *         the system clock is switched to it. That last call programs the
 *         flash controller clock before the switch (the core keeps fetching
 *         from the flash) and updates SystemCoreClock afterwards.
 * @param  None
 * @retval None
 */
void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks (console pins of USART0 and the PD4 marker pin) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu_dev);
    hpmu_dev.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu_dev);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu_dev, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu_dev, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Configure the PD4 marker pin as a push-pull output.
 * @note   The reference test case drives PD4 to be able to measure the bark
 *         time on a scope: the pin is set before the watchdog is started and
 *         cleared inside the FCU interrupt handler.
 * @param  None
 * @retval None
 */
void Test_Pd4Init(void)
{
    GPIO_InitTypeDef gpio_init;

    __HAL_CLEAR_STRUCT(&gpio_init);
    HAL_GPIO_StructInit(&gpio_init);
    gpio_init.Pin          = TEST_PD4_PIN;
    gpio_init.Mode         = GPIO_MODE_OUTPUT_PP;
    gpio_init.Pull         = GPIO_NOPULL;
    gpio_init.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    gpio_init.Alternate    = 0U;

    HAL_GPIO_Init(TEST_PD4_PORT, &gpio_init);
}

/**
 * @brief  Drive the PD4 marker pin.
 * @param  state: GPIO_PIN_SET (watchdog armed, waiting) / GPIO_PIN_RESET (bark)
 * @retval None
 */
void Test_Pd4Set(GPIO_PinState state)
{
    HAL_GPIO_WritePin(TEST_PD4_PORT, TEST_PD4_PIN, state);
}

/**
 * @brief  Read the cycle counter (low 32 bits).
 * @note   The core runs at 180 MHz in this test, so the 32-bit counter wraps
 *         after about 23.8 s: every measurement of the suite is far shorter,
 *         and an unsigned difference stays correct across a wrap.
 * @param  None
 * @retval The mcycle value
 */
uint32 Test_McycleNow(void)
{
    return (uint32)csr_read(CSR_MCYCLE);
}

/**
 * @brief  Convert a cycle count into microseconds.
 * @param  cycles: number of core cycles
 * @retval The equivalent number of microseconds
 */
uint32 Test_McycleToUs(uint32 cycles)
{
    uint32 per_us = SystemCoreClock / 1000000U;

    if (per_us == 0U)
    {
        per_us = 1U;
    }

    return cycles / per_us;
}

/**
 * @brief  Clear the bark observation of the previous round.
 * @param  None
 * @retval None
 */
void Test_BarkReset(void)
{
    test_bark_count   = 0U;
    test_bark_mask    = 0U;
    test_bark_counter = 0U;
    test_bark_mcycle  = 0U;
}

/**
 * @brief  Wait (bounded) until the FCU handler observed a bark.
 * @param  timeout_ms: budget in milliseconds
 * @retval HAL_StatusTypeDef: HAL_OK when a bark arrived / HAL_TIMEOUT
 */
HAL_StatusTypeDef Test_WaitBark(uint32 timeout_ms)
{
    uint32 tickstart = HAL_GetTick();

    while (test_bark_count == 0U)
    {
        if ((HAL_GetTick() - tickstart) > timeout_ms)
        {
            return HAL_TIMEOUT;
        }
    }

    return HAL_OK;
}

/**
 * @brief  Program one watchdog channel through HAL_WWDG_Init().
 * @note   The driver has no HAL_WWDG_StructInit(): the configuration
 *         structure follows the Version+Size mechanism, so the metafields are
 *         filled here (the business fields are overwritten on every call).
 * @param  prescaler: PSC.PSCNUM value (0..255)
 * @param  divider:   DIV.DIVNUM value (2..65535)
 * @param  counter:   TO.BVAL timeout value (1..65535)
 * @param  window:    WD.WDCNT window value (0..65534, 0 = plain watchdog)
 * @param  instance:  channel register base (WWDG0_Channel0 .. WWDG1_Channel3)
 * @retval HAL_StatusTypeDef of HAL_WWDG_Init()
 */
HAL_StatusTypeDef Test_WwdgApply(uint32 prescaler, uint32 divider, uint32 counter,
                                 uint32 window, WWDG_Channel_TypeDef *instance)
{
    hwwdg_dev.Instance        = instance;
    hwwdg_dev.Init.Size       = (uint32)sizeof(WWDG_InitTypeDef);
    hwwdg_dev.Init.Version    = WWDG_INIT_VERSION;
    hwwdg_dev.Init.Prescaler  = prescaler;
    hwwdg_dev.Init.Divider    = divider;
    hwwdg_dev.Init.Counter    = counter;
    hwwdg_dev.Init.Window     = window;
    hwwdg_dev.Init.Reserved[0] = 0U;
    hwwdg_dev.Init.Reserved[1] = 0U;

    return HAL_WWDG_Init(&hwwdg_dev);
}

/**
 * @brief  Configure one FCU channel for the watchdog bark.
 * @note   MaskEnable = FCU_DISABLE unmasks the channel (an enabled mask keeps
 *         the channel silent), which is the configuration of the reference
 *         test case.
 * @param  channel:      FCU channel of the watchdog (WWDG0 / WWDG1)
 * @param  fault_action: action at fault level
 * @param  alarm_action: action at alarm level
 * @param  level:        fault level of the channel
 * @retval None
 */
void Test_FcuConfig(HAL_FCU_ChannelTypeDef channel,
                    HAL_FCU_FaultActionTypeDef fault_action,
                    HAL_FCU_AlarmActionTypeDef alarm_action,
                    HAL_FCU_FaultLevelTypeDef level)
{
    FCU_InitTypeDef fcu_init;

    __HAL_CLEAR_STRUCT(&hfcu_dev);
    hfcu_dev.Instance = FCU;

    HAL_FCU_StructInit(&fcu_init);
    fcu_init.Channel           = channel;
    fcu_init.FaultToResetCount = 0U;
    fcu_init.AlarmToFaultCount = 0U;
    fcu_init.FaultAction       = fault_action;
    fcu_init.AlarmAction       = alarm_action;
    fcu_init.FaultLevel        = level;
    fcu_init.MaskEnable        = FCU_DISABLE;

    hfcu_dev.Init = fcu_init;

    (void)HAL_FCU_Init(&hfcu_dev);
    (void)HAL_FCU_Cmd(&hfcu_dev, channel, FCU_ENABLE);
}

/**
 * @brief  Enable the FCU interrupt source in the PLIC.
 * @param  priority: source priority (1..63, larger = higher priority)
 * @retval None
 */
void Test_PlicEnable(uint32 priority)
{
    PLIC_InitTypeDef plic_init;

    __HAL_CLEAR_STRUCT(&plic_init);
    plic_init.Size               = (uint32)sizeof(PLIC_InitTypeDef);
    plic_init.Version            = PLIC_INIT_VERSION;
    plic_init.PLIC_IRQChannel    = FCU_IRQn;
    plic_init.PLIC_IRQPriority   = priority;
    plic_init.PLIC_IRQChannelCmd = PLIC_ENABLE;
    (void)HAL_PLIC_Init(&plic_init);
}

/**
 * @brief  Return the instance level register block of a channel.
 * @param  instance: channel register base
 * @retval WWDG0 or WWDG1
 */
static WWDG_TypeDef *Test_Periph(WWDG_Channel_TypeDef *instance)
{
    if ((instance == WWDG0_Channel0) || (instance == WWDG0_Channel1) ||
        (instance == WWDG0_Channel2) || (instance == WWDG0_Channel3))
    {
        return WWDG0;
    }

    return WWDG1;
}

/**
 * @brief  FCU interrupt handler: record the bark, then acknowledge the source.
 * @note   The reference test case uses this handler to drive PD4 low and to
 *         read the bark flags. The handler runs outside the driver locks: the
 *         read-only queries (HAL_FCU_GetAlarmStatus / HAL_FCU_GetFaultStatus /
 *         HAL_WWDG_GetCounter / HAL_WWDG_GetBKStatus) and the clear family
 *         (HAL_FCU_ClearFcuStatus) are interrupt safe by design.
 * @note   The bark instant is stamped with the cycle counter, so the case can
 *         compare the measured timeout with the programmed one.
 * @param  None
 * @retval None
 */
void FCU_IRQ_Handler(void)
{
    uint32 status0;
    uint32 status1;

    status0 = HAL_FCU_GetAlarmStatus(&hfcu_dev, HAL_FCU_CHANNEL_WWDG0) |
              HAL_FCU_GetFaultStatus(&hfcu_dev, HAL_FCU_CHANNEL_WWDG0);
    status1 = HAL_FCU_GetAlarmStatus(&hfcu_dev, HAL_FCU_CHANNEL_WWDG1) |
              HAL_FCU_GetFaultStatus(&hfcu_dev, HAL_FCU_CHANNEL_WWDG1);

    if ((status0 != 0U) || (status1 != 0U))
    {
        test_bark_mcycle  = Test_McycleNow();
        test_bark_counter = (uint32)HAL_WWDG_GetCounter(&hwwdg_dev);
        test_bark_mask    = (uint32)(READ_REG(Test_Periph(hwwdg_dev.Instance)->DSTA) &
                                     (WWDG_DSTA_BK0 | WWDG_DSTA_BK1 |
                                      WWDG_DSTA_BK2 | WWDG_DSTA_BK3));
        test_bark_count++;

        /* Marker pin: the bark pulls PD4 low (the scope reference) */
        Test_Pd4Set(TEST_PD4_OFF);
    }

    if (status0 != 0U)
    {
        (void)HAL_FCU_ClearFcuStatus(&hfcu_dev, HAL_FCU_CHANNEL_WWDG0);
    }
    if (status1 != 0U)
    {
        (void)HAL_FCU_ClearFcuStatus(&hfcu_dev, HAL_FCU_CHANNEL_WWDG1);
    }
}

/*****END OF FILE*****/
