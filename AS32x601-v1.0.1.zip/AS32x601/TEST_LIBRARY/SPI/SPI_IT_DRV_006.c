/**
 * @file    SPI_IT_DRV_006.c
 * @brief   HAL SPI integration test case 006 (slave mode full duplex).
 *
 * HAL library port of the original AS32x601 standard-library test case
 * SPI_IT_DRV_006.c, which drives SPI3 in slave mode and exchanges 64 frames
 * with an external master. Only HAL library APIs are used; the register read
 * backs are there to document what was programmed.
 *
 * Tested functionality:
 *   HAL_SPI_StructInit()
 *   HAL_SPI_Init()
 *   HAL_SPI_TransmitReceive()   (blocking, slave, 64 frames of 8 bit)
 *   HAL_SPI_GetState() / HAL_SPI_GetError()
 *   HAL_SPI_MspInit()           (overridden: clock gate, reset pulse, pins)
 *
 * Test procedure:
 *   1. map and configure the pins of the device under test (the data output
 *      MISO is open drain in slave mode);
 *   2. initialize SPI3 in slave mode (8 bit, Motorola mode 0, normal
 *      transmission);
 *   3. exchange 64 frames with the external master: the case transmits
 *      0xA0 .. 0xDF and expects 0x00 .. 0x3F back;
 *   4. compare the received buffer with the expected buffer.
 *
 * Expected behaviour:
 *   - HAL_SPI_TransmitReceive() returns HAL_OK and the handle returns to READY
 *     with the error code NONE;
 *   - the received buffer holds 0x00 .. 0x3F, so every comparison prints
 *     [PASS] and "summary : failures = 0".
 *
 * Note:
 *   - External stimulus is required: an SPI master must clock the 64 frames
 *     (same Motorola mode, 8 bit) and send 0x00 .. 0x3F. Without a master
 *     there is no clock, so the transfer ends in HAL_TIMEOUT and the data
 *     comparison fails - that is the expected behaviour of a slave.
 *   - The reference test case polled IRSR.RXNE by hand and was therefore
 *     blocking forever without a master; the HAL entry point has a timeout,
 *     so the case reports the situation instead of hanging.
 *   - The reference case printed the expected value under the label "Sent";
 *     the wording here distinguishes the transmitted pattern from the expected
 *     received pattern.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console: USART0 on GPIOD pin 8 (TX) / pin 9 (RX), 115200 8N1 */
#define TEST_BAUDRATE                   (115200U)

/* Device under test: SPI3 in slave mode (as in the reference test case)
 *   CS0  = PC10   SCK  = PD3   MOSI = PD1   MISO = PD2 (open drain)
 */
#define TEST_SPI                        SPI3
#define TEST_CS_PORT                    GPIOC
#define TEST_CS_PIN                     GPIO_PIN_10
#define TEST_CS_SOURCE                  GPIO_PinSource10
#define TEST_SCK_PORT                   GPIOD
#define TEST_SCK_PIN                    GPIO_PIN_3
#define TEST_SCK_SOURCE                 GPIO_PinSource3
#define TEST_MOSI_PORT                  GPIOD
#define TEST_MOSI_PIN                   GPIO_PIN_1
#define TEST_MOSI_SOURCE                GPIO_PinSource1
#define TEST_MISO_PORT                  GPIOD
#define TEST_MISO_PIN                   GPIO_PIN_2
#define TEST_MISO_SOURCE                GPIO_PinSource2
#define TEST_PIN_AF                     GPIO_AF_SPI3

/* Frame geometry and timeouts */
#define FRAME_COUNT                     (64U)
#define TRANSFER_TIMEOUT_MS             (2000U)
#define TX_PATTERN_BASE                 (0xA0U)

/* Private variables ---------------------------------------------------------*/
static SPI_HandleTypeDef hspi_dev;              /*!< device under test      */
static HAL_SMU_HandleTypeDef hsmu_clk;          /*!< SMU handle (clock tree) */
static uint8 tx_data[FRAME_COUNT];              /*!< transmit pattern        */
static uint8 rx_data[FRAME_COUNT];              /*!< received frames         */
static uint8 rx_expected[FRAME_COUNT];          /*!< expected frames         */
static volatile uint32 check_failures = 0U;     /*!< failed check counter    */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void BufferInit(void);
static void Check(const char *name, uint32 condition);
static void Summary(void);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    SPI_InitTypeDef spi_init;
    HAL_StatusTypeDef status;
    uint32 index;
    uint32 mismatches;
    uint32 first_bad;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock tree */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART (USART0 on GPIOD pin 8 / pin 9) */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== SPI_IT_DRV_006 : slave mode full duplex (SPI3) ===\r\n");

    /* Transmit pattern 0xA0 .. 0xDF, expected pattern 0x00 .. 0x3F */
    BufferInit();

    /* Step 2: initialize the device under test in slave mode. The divider has
     * no meaning for a slave (the master provides the clock); the reference
     * test case programmed /2 as well. */
    __HAL_CLEAR_STRUCT(&hspi_dev);
    HAL_SPI_StructInit(&spi_init);
    spi_init.SPI_CLKDiv       = SPI_CLKDiv2;
    spi_init.SPI_Mode         = SPI_Mode_Slave;
    spi_init.SPI_FrameSize    = SPI_FrameSize_8b;
    spi_init.SPI_MotorolaMode = SPI_Motorola_Mode0;
    spi_init.SPI_TransMode    = SPI_TransNor;

    hspi_dev.Instance = TEST_SPI;
    hspi_dev.Init     = spi_init;

    status = HAL_SPI_Init(&hspi_dev);
    Check("HAL_SPI_Init returns HAL_OK", (uint32)((status == HAL_OK) ? 1U : 0U));
    Check("state after init is READY",
          (uint32)((HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_READY) ? 1U : 0U));
    Check("error code after init is NONE",
          (uint32)((HAL_SPI_GetError(&hspi_dev) == HAL_SPI_ERROR_NONE) ? 1U : 0U));
    Check("CR0.MSTR is cleared (slave mode)",
          (uint32)((((uint32)TEST_SPI->CR0 & SPI_CR0_MSTR) == 0U) ? 1U : 0U));

    printf("mode         : slave\r\n");
    printf("pattern      : transmit 0x%02X..0x%02X, expect 0x00..0x3F\r\n",
           PRINT_U32(TX_PATTERN_BASE), PRINT_U32(TX_PATTERN_BASE + FRAME_COUNT - 1U));

    /* Step 3: exchange the frames. The master has to clock them; without a
     * master the call ends in HAL_TIMEOUT (the slave cannot generate the
     * clock). */
    status = HAL_SPI_TransmitReceive(&hspi_dev, tx_data, rx_data, FRAME_COUNT,
                                     TRANSFER_TIMEOUT_MS);
    Check("HAL_SPI_TransmitReceive returns HAL_OK",
          (uint32)((status == HAL_OK) ? 1U : 0U));
    if (status != HAL_OK)
    {
        printf("transfer status: %u (2 = HAL_ERROR, 3 = HAL_BUSY, "
               "4 = HAL_TIMEOUT; a slave needs an external master)\r\n",
               PRINT_U32((uint32)status));
        printf("error code     : 0x%08X\r\n", PRINT_U32(HAL_SPI_GetError(&hspi_dev)));
        printf("state          : %u (7 = TIMEOUT)\r\n",
               PRINT_U32((uint32)HAL_SPI_GetState(&hspi_dev)));
    }

    /* Step 4: compare the received buffer with the expectation */
    mismatches = 0U;
    first_bad  = FRAME_COUNT;
    for (index = 0U; index < FRAME_COUNT; index++)
    {
        if (rx_data[index] != rx_expected[index])
        {
            if (mismatches == 0U)
            {
                first_bad = index;
            }
            mismatches++;
        }
    }

    printf("rx[%u..%u]    : ", PRINT_U32(0U), PRINT_U32(FRAME_COUNT - 1U));
    for (index = 0U; index < 8U; index++)
    {
        printf("0x%02X ", PRINT_U32(rx_data[index]));
    }
    printf("...\r\n");

    if (mismatches != 0U)
    {
        printf("first mismatch at index %u : expected 0x%02X, received 0x%02X\r\n",
               PRINT_U32(first_bad), PRINT_U32(rx_expected[first_bad]),
               PRINT_U32(rx_data[first_bad]));
    }

    Check("received pattern matches the expectation",
          (uint32)((mismatches == 0U) ? 1U : 0U));

    Summary();

    while (1)
    {
        delay_ms(1000U);
    }
}

/**
 * @brief  Fill the transmit and the expected receive buffer.
 * @param  None
 * @retval None
 */
static void BufferInit(void)
{
    uint32 index;

    for (index = 0U; index < FRAME_COUNT; index++)
    {
        tx_data[index]     = (uint8)(TX_PATTERN_BASE + index);
        rx_expected[index] = (uint8)index;
        rx_data[index]     = 0x00U;
    }
}

/**
 * @brief  Report the result of one check.
 * @param  name: short description of the check.
 * @param  condition: 0 = FAIL, non zero = PASS.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("%-46s : [PASS]\r\n", name);
    }
    else
    {
        check_failures++;
        printf("%-46s : [FAIL]\r\n", name);
    }
}

/**
 * @brief  Print the accumulated failure counter.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(check_failures));
}

/**
 * @brief  MSP initialization of the device under test.
 * @note   Strong override of the weak driver callback. The data output line
 *         (MISO) is open drain in slave mode, as the reference test case
 *         configured it.
 * @param  hspi: SPI handle of the device under test.
 * @retval None
 */
void HAL_SPI_MspInit(SPI_HandleTypeDef *hspi)
{
    GPIO_InitTypeDef gpio;

    if (hspi->Instance != TEST_SPI)
    {
        return;
    }

    /* Peripheral clock gate and reset pulse */
    __HAL_SMU_SPI3_CLK_ENABLE();
    __HAL_SMU_SPI3_FORCE_RESET();
    __HAL_SMU_SPI3_RELEASE_RESET();

    /* Port clock gates used by this case */
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&gpio);
    gpio.Size         = sizeof(gpio);
    gpio.Version      = GPIO_INIT_VERSION;
    gpio.Pull         = GPIO_NOPULL;
    gpio.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    gpio.Alternate    = TEST_PIN_AF;

    /* CS0: the master drives it, the pin stays mapped to the SPI function */
    HAL_GPIO_PinAFConfig(TEST_CS_PORT, TEST_CS_SOURCE, TEST_PIN_AF);
    gpio.Pin  = TEST_CS_PIN;
    gpio.Mode = GPIO_MODE_AF_PP;
    HAL_GPIO_Init(TEST_CS_PORT, &gpio);

    /* SCK: input in slave mode, driven by the master */
    HAL_GPIO_PinAFConfig(TEST_SCK_PORT, TEST_SCK_SOURCE, TEST_PIN_AF);
    gpio.Pin  = TEST_SCK_PIN;
    gpio.Mode = GPIO_MODE_INPUT;
    HAL_GPIO_Init(TEST_SCK_PORT, &gpio);

    /* MOSI: input in slave mode, driven by the master */
    HAL_GPIO_PinAFConfig(TEST_MOSI_PORT, TEST_MOSI_SOURCE, TEST_PIN_AF);
    gpio.Pin  = TEST_MOSI_PIN;
    gpio.Mode = GPIO_MODE_INPUT;
    HAL_GPIO_Init(TEST_MOSI_PORT, &gpio);

    /* MISO: data output of the slave, open drain as in the reference case */
    HAL_GPIO_PinAFConfig(TEST_MISO_PORT, TEST_MISO_SOURCE, TEST_PIN_AF);
    gpio.Pin  = TEST_MISO_PIN;
    gpio.Mode = GPIO_MODE_AF_OD;
    HAL_GPIO_Init(TEST_MISO_PORT, &gpio);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the CLINT / CMU / MPU / USART integration tests.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef    SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the same set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls (PMU_CheckState) */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
