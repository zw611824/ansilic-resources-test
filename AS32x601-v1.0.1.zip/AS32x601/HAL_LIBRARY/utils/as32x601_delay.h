/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):  	Xiamen Guoke Anxin Technology Co., LTD
 * FileName:     	as32x601_delay.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.0
 * Date:			2026/09/03
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/09/03     1.0     delay module for the
 *                                                       USART integration test
 * Description:     Delay functions for the AS32x601 USART integration test
 *                  project: the busy-wait loop counts the CPU cycle counter
 *                  (mcycle) through the HAL library CSR access macros
 *                  (core_riscv.h), so only HAL library functions are used.
 *                  API: delay_init() / delay_us() / delay_ms().
 */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __AS32X601_DELAY_H
#define __AS32X601_DELAY_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "core_riscv.h"         /* uint32 / uint64, csr_read, CSR_MCYCLE      */

/* Exported functions --------------------------------------------------------*/

/**
 * @brief  Initialize the delay module.
 * @param  SYSCLK: system clock frequency, in MHz (cycles per microsecond).
 * @retval None
 */
void delay_init(uint32 SYSCLK);

/**
 * @brief  Microsecond delay.
 * @param  nus: number of microseconds to delay (0..UINT32_MAX / SYSCLK).
 * @retval None
 */
void delay_us(uint32 nus);

/**
 * @brief  Millisecond delay.
 * @param  nms: number of milliseconds to delay.
 * @retval None
 */
void delay_ms(uint32 nms);

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_DELAY_H */

/*****END OF FILE*****/
