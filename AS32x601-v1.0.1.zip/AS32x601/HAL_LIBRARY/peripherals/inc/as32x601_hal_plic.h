/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_plic.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.6
 * Date:   2026/10/10
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/10     1.1     keep handler declarations only, the weak stubs moved to as32x601_hal_plic.c
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.4     unify the two file versions, add the
 *                                                       doxygen block and the blocking marker
 *                                                       of every public prototype, and state
 *                                                       the RTOS non-applicability of a
 *                                                       handle-less Simple module
 *     ANSILIC APPLICATION GROUP  2026/09/21     1.5     correct the description of the two
 *                                                       core interrupt handlers: the machine
 *                                                       timer interrupt is NOT the source of
 *                                                       the default HAL time base (that one is
 *                                                       derived from the CPU mcycle counter by
 *                                                       polling), it is the trampoline of the
 *                                                       CLINT system time base whose entry is
 *                                                       HAL_CLINT_IRQHandler()
 *     ANSILIC APPLICATION GROUP  2026/10/10     1.6     state that both branches of the
 *                                                       initialisation guarantee the PLIC clock,
 *                                                       and add the read-back and priority notes
 *                                                       (the enable status is the hardware bit,
 *                                                       not a software cache; writing a priority
 *                                                       never changes the enable bit)
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Platform-Level
 *                  Interrupt Controller (PLIC), following the structure of
 *                  a conventional NVIC-style HAL driver:
 *                  - Initialization: per-source priority / enable
 *                    configuration through the PLIC_InitTypeDef structure;
 *                  - Peripheral control: per-source interrupt enable /
 *                    disable, priority get / set and enable status
 *                    read-back.
 *                  The trap dispatch (mcause decode, PLIC claim / complete
 *                  handshake and the weak handler table) is implemented by
 *                  the as32x601_trapentry assembly module; this driver only
 *                  declares the handler symbols referenced by that module so
 *                  that the user can provide strong definitions (the weak
 *                  default stubs live at the end of as32x601_hal_plic.c).
 * @complexity  Simple
 *              Channel configuration + enable/priority control, no handle /
 *              state machine, no lock.
 * @note  RTOS configuration - this module needs no RTOS specific code and
 *        therefore compiles and behaves identically in the bare-metal and in
 *        the RTOS configuration. The rules of the RTOS chapter are mapped as
 *        follows:
 *          - "a blocking API shall yield the CPU in every polling iteration":
 *            not applicable, the module contains no polling loop and calls
 *            neither HAL_GetTick() nor HAL_Delay() (every function drives the
 *            registers once and returns);
 *          - "the handle may carry a MutexHandle field instead of the
 *            bare-metal Lock field": not applicable, the module has no handle
 *            structure at all;
 *          - "an RTOS lock shall support the Timeout parameter": not
 *            applicable, the module takes no lock, hence there is no waiting
 *            point that could time out;
 *          - "no lock operation from an interrupt context": satisfied, the
 *            weak interrupt handler stubs perform no lock operation and no
 *            blocking wait;
 *          - the remaining rules of that chapter (tick source, HAL_Delay()
 *            remapping, notification from the weak callbacks, calling the
 *            FromISR variants) concern the common layer and the application,
 *            not this module.
 *        The only concurrency constraint that remains concerns the register
 *        read-modify-write sequences that share the enable registers with
 *        another context: serialising them is the responsibility of the
 *        application.
 */
#ifndef __AS32X601_HAL_PLIC_H
#define __AS32X601_HAL_PLIC_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "as32x601.h"               /* IRQn_Type, PLIC_TypeDef, PLIC macros   */

/**
 * @brief PLIC HAL driver module version.
 * @note  0x0101U = V1.1. Bumped only on breaking API changes (architecture
 *        spec COMPAT-13/14/15).
 */
#define __HAL_PLIC_MODULE_VERSION  0x0101U

/* Exported types ------------------------------------------------------------*/

/** @defgroup PLIC_Exported_Types PLIC Exported Types
  * @{
  */

/**
 * @brief PLIC interrupt channel init structure definition.
 * @note  PLIC_IRQChannel must be a valid IRQn_Type value (1..50), the value
 *        None (0) is ignored by the configuration functions.
 *        PLIC_IRQPriority is the PLIC gatekeeper priority: 0 disables the
 *        source, 1..63 enable it.  Unlike a conventional priority controller, a LARGER priority
 *        value means a HIGHER priority on this PLIC.
 * @note  This structure follows the Version+Size compatibility mechanism
 *        (architecture spec section 22): the user must clear the structure
 *        (__HAL_CLEAR_STRUCT / memset), set the Size and Version metafields
 *        before filling the business fields (see HAL_PLIC_StructInit()).
 */
typedef struct
{
    uint32 Size;                    /*!< sizeof(PLIC_InitTypeDef), must be set by the user
                                         after clearing the structure           */
    uint32 Version;                 /*!< Structure semantic version: @ref PLIC_INIT_VERSION
                                         (PLIC_INIT_V1 = 0x0100U)                */
    IRQn_Type PLIC_IRQChannel;      /*!< Interrupt source selection: IRQn_Type */
    uint8   PLIC_IRQPriority;       /*!< Source priority 0x00-0x3F (0=disabled,
                                         larger = higher priority)            */
    uint8   PLIC_IRQChannelCmd;     /*!< PLIC_ENABLE or PLIC_DISABLE          */
    uint32  Reserved[2];            /*!< Reserved for future extension (must be 0)     */
} PLIC_InitTypeDef;

/**
 * @brief PLIC / init structure version macros.
 * @note  PLIC_INIT_V1 is the current version. Future versions (e.g. V2 with
 *        new fields) must be appended after the existing fields without
 *        changing the layout (architecture spec section 22.5).
 */
#define PLIC_INIT_V1  0x0100U   /*!< PLIC Init structure version V1.0 */
#define PLIC_INIT_VERSION  PLIC_INIT_V1   /*!< Current PLIC Init structure version */

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @defgroup PLIC_Exported_Constants PLIC Exported Constants
  * @{
  */

/** @defgroup PLIC_Channel_Enable PLIC Channel Enable
  * @{
  */
#define PLIC_DISABLE   0U            /*!< Disable the interrupt channel        */
#define PLIC_ENABLE    1U            /*!< Enable the interrupt channel         */
/**
  * @}
  */

/** @defgroup PLIC_Interrupt_Priority PLIC Interrupt Priority
  * @{
  */
#define PLIC_PRIORITY_MIN           ((uint32)0x00U)  /*!< Lowest priority; also disables the source */
#define PLIC_PRIORITY_MAX           ((uint32)0x3FU)  /*!< Highest priority                           */
/**
  * @}
  */

/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/

/** @addtogroup PLIC_Exported_Functions
  * @{
  */

/** @addtogroup PLIC_Exported_Functions_Group1 Initialization functions
  * @note  This group drives the shared PLIC clock gate
  *        (SMU_ALB0CFGR.PLICEN / PLICRST) and the shared enable word; their
  *        read-modify-write must be serialized by the caller or by a selected
  *        cross-module critical section.  This matches the "configure the PLIC
  *        only when it is actually used" policy: the startup file does not
  *        enable the PLIC clock.
  * @{
  */

/**
 * @brief  Fills each PLIC_InitStruct member with its default value. (NON-BLOCKING)
 * @param  PLIC_InitStruct: pointer to a PLIC_InitTypeDef structure which
 *         will be initialized (IRQChannel = None, priority = 0,
 *         ChannelCmd = PLIC_DISABLE).
 * @retval None
 */
void HAL_PLIC_StructInit(PLIC_InitTypeDef *PLIC_InitStruct);

/**
 * @brief  Initializes the PLIC interrupt channel according to the specified (NON-BLOCKING)
 *         parameters in the PLIC_InitStruct.
 * @note   Both branches of a valid source guarantee the PLIC clock
 *         (SMU_ALB0CFGR.PLICEN) before the first register access: the enable
 *         branch writes the priority record and then the enable bit, the
 *         disable branch only clears the enable bit but still writes a PLIC
 *         register and therefore needs the clock as well.  The machine
 *         external interrupt (mie.MEIE) is enabled by the startup file.
 * @note   Writing a priority does not change the enable bit, does not perform a
 *         pending clear or a complete, and does not gate off the source
 *         hardware.
 * @param  PLIC_InitStruct: pointer to a PLIC_InitTypeDef structure that
 *         contains the configuration information for the specified PLIC
 *         interrupt channel.
 * @retval None
 */
void HAL_PLIC_Init(PLIC_InitTypeDef *PLIC_InitStruct);

/**
  * @}
  */

/** @addtogroup PLIC_Exported_Functions_Group2 Peripheral Control functions
  * @note  Every function of this group drives the shared PLIC clock gate
  *        (SMU_ALB0CFGR.PLICEN / PLICRST) before touching a PLIC register.  The
  *        read-modify-write of that gate register and of the shared enable word
  *        must be serialized by the caller or by a selected cross-module
  *        critical section.
  * @{
  */

/**
 * @brief  Enables a device specific interrupt source in the PLIC. (NON-BLOCKING)
 * @note   The PLIC clock (SMU_ALB0CFGR.PLICEN) is enabled automatically before
 *         the enable bit is written.  Only the enable bit of the target source
 *         is set; its priority is not changed.  IRQn = None (0) is ignored.
 * @param  IRQn: IRQn_Type interrupt source number (1..50).
 * @retval None
 */
void HAL_PLIC_EnableIRQ(IRQn_Type IRQn);

/**
 * @brief  Disables a device specific interrupt source in the PLIC. (NON-BLOCKING)
 * @note   The PLIC clock (SMU_ALB0CFGR.PLICEN) is enabled automatically before
 *         the enable bit is cleared.  Only the enable bit of the target source
 *         is cleared; its priority is not changed.  Once disabled, the source
 *         no longer requests an interrupt as long as the remaining
 *         configuration is unchanged.  IRQn = None (0) is ignored.
 * @param  IRQn: IRQn_Type interrupt source number (1..50).
 * @retval None
 */
void HAL_PLIC_DisableIRQ(IRQn_Type IRQn);

/**
 * @brief  Sets the priority of an interrupt source in the PLIC. (NON-BLOCKING)
 * @note   PLIC priority semantics: 0 disables the source, 1..63 enable it,
 *         a larger value has a higher priority (opposite to conventional priority ordering).
 * @note   Writing a priority does not change the enable bit, does not perform a
 *         pending clear or a complete, and does not gate off the source
 *         hardware; it is not a substitute for HAL_PLIC_DisableIRQ().
 * @param  IRQn: IRQn_Type interrupt source number (1..50).
 * @param  Priority: PLIC_PRIORITY_MIN..PLIC_PRIORITY_MAX (0x00..0x3F).
 * @retval None
 */
void HAL_PLIC_SetPriority(IRQn_Type IRQn, uint32 Priority);

/**
 * @brief  Gets the priority of an interrupt source in the PLIC. (NON-BLOCKING)
 * @note   The value returned is the hardware priority field of the source
 *         (masked to the implemented 0x00..0x3F field), not a cached or
 *         derived value.
 * @note   Because 0 is also a valid priority value, a caller that must
 *         distinguish an invalid source from a valid zero priority has to
 *         validate the source first (IS_PLIC_IRQn()).
 * @param  IRQn: IRQn_Type interrupt source number (1..50).
 * @retval uint32: current priority value (0x00..0x3F); 0 for IRQn = None.
 */
uint32 HAL_PLIC_GetPriority(IRQn_Type IRQn);

/**
 * @brief  Reads the enable status of an interrupt source in the PLIC. (NON-BLOCKING)
 * @note   The value returned is defined as the read-back of the hardware enable
 *         bit, not a software cache and not a claim that the source can
 *         currently deliver an interrupt: actual delivery also depends on the
 *         priority of the source and on the machine external interrupt being
 *         enabled.
 * @param  IRQn: IRQn_Type interrupt source number (1..50).
 * @retval uint32: 1 if the source is enabled, 0 otherwise (also for
 *         IRQn = None).
 */
uint32 HAL_PLIC_GetEnabledIRQ(IRQn_Type IRQn);

/**
  * @}
  */

/**
  * @}
  */

/* Interrupt handler declarations --------------------------------------------*/
/*
 * The following handlers are dispatched by the as32x601_trapentry assembly
 * module (dispatch tables).  The user provides strong definitions (e.g.
 * void RTC_IRQ_Handler(void) { ... }) in his own module to serve the
 * corresponding interrupt source; a handler that is not overridden falls
 * back to the weak stub in as32x601_hal_plic.c, which defaults to
 * Default_Int_Handler (fatal loop).
 *
 * NOTE: this header must only DECLARE the handlers.  A __weak definition
 * placed here would be emitted into every module that includes it, and would
 * then make it impossible for any of those modules to supply its own strong
 * definition (IAR: Error[Pe247] "has already been defined").
 */

/**
 * @brief Default hook for unregistered / unhandled interrupt sources.
 * @note  The weak stub in as32x601_hal_plic.c spins forever; the user may
 *        provide a strong override implementing e.g. an ignore policy.
 */
void Default_Int_Handler(void);

/** @defgroup PLIC_Exported_IRQHandlers PLIC Interrupt Handlers
  * @{
  */
void EFLASH_IRQ_Handler(void);
void FCU_IRQ_Handler(void);
void DMA0_IRQ_Handler(void);
void DMA1_IRQ_Handler(void);
void TIM0_IRQ_Handler(void);
void CANFD0_IRQ_Handler(void);
void CANFD1_IRQ_Handler(void);
void ADC0_IRQ_Handler(void);
void ADC1_IRQ_Handler(void);
void GPIOA_IRQ_Handler(void);
void GPIOB_IRQ_Handler(void);
void GPIOC_IRQ_Handler(void);
void PKA_IRQ_Handler(void);
void SPACC_IRQ_Handler(void);
void TRNG_IRQ_Handler(void);
void TIM1_IRQ_Handler(void);
void CANFD2_IRQ_Handler(void);
void CANFD3_IRQ_Handler(void);
void GPIOD_IRQ_Handler(void);
void GPIOE_IRQ_Handler(void);
void GPIOF_IRQ_Handler(void);
void GPIOG_IRQ_Handler(void);
void MAC_IRQ_Handler(void);
void SPI0_IRQ_Handler(void);
void SPI1_IRQ_Handler(void);
void SPI2_IRQ_Handler(void);
void I2C0_IRQ_Handler(void);
void I2C1_IRQ_Handler(void);
void USART0_IRQ_Handler(void);
void USART1_IRQ_Handler(void);
void USART2_IRQ_Handler(void);
void USART3_IRQ_Handler(void);
void TIM2_IRQ_Handler(void);
void TIM3_IRQ_Handler(void);
void TIM4_IRQ_Handler(void);
void SPI3_IRQ_Handler(void);
void SPI4_IRQ_Handler(void);
void SPI5_IRQ_Handler(void);
void I2C2_IRQ_Handler(void);
void I2C3_IRQ_Handler(void);
void USART4_IRQ_Handler(void);
void USART5_IRQ_Handler(void);
void USART6_IRQ_Handler(void);
void USART7_IRQ_Handler(void);
void TIM5_IRQ_Handler(void);
void TIM6_IRQ_Handler(void);
void TIM7_IRQ_Handler(void);
void GPIOH_IRQ_Handler(void);
void RTC_IRQ_Handler(void);
/**
  * @}
  */

/** @defgroup PLIC_Exported_CoreHandlers Core Interrupt / Exception Handlers
  * @{
  */

/**
 * @brief  Machine software interrupt handler (CLINT MSIP).
 * @note   Dispatched by the trap entry for mcause = 3 (MSI).  The strong
 *         override of the application typically acknowledges the request with
 *         HAL_CLINT_ClearSoftInt(), which is the interrupt safe clear of the
 *         CLINT driver.
 */
void MSoftWare_IRQ_Handler(void);

/**
 * @brief  Machine timer interrupt handler (CLINT MTIMECMP).
 * @note   Dispatched by the trap entry for mcause = 7 (MTI).  It is the
 *         trampoline of the CLINT system time base: the strong override of the
 *         application forwards it to HAL_CLINT_IRQHandler(), which reloads the
 *         comparator and runs HAL_CLINT_TickCallback().  The default HAL time
 *         base does NOT use this interrupt: it is derived from the CPU mcycle
 *         counter by polling and never accesses the CLINT (see
 *         as32x601_hal.c).
 */
void MTimer_IRQ_Handler(void);

/** @defgroup PLIC_Exported_ExceptionHandlers Exception Handlers
  * @{
  */
void InstAddrMisalign_Handler(void);
void InstAccessFault_Handler(void);
void IllegalInst_Handler(void);
void Breakpoint_Handler(void);
void LoadAddrMisalign_Handler(void);
void LoadAccessFault_Handler(void);
void StoreAMOAddrMisalign_Handler(void);
void StoreAMOAccessFault_Handler(void);
void ECall_Handler(void);
void InstPageFault_Handler(void);
void LoadPageFault_Handler(void);
void StoreAMOPageFault_Handler(void);
/**
  * @}
  */

/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/

/** @defgroup PLIC_Private_Macros PLIC Private Macros
  * @{
  */

/**
 * @brief  Check that IRQn is a valid PLIC interrupt source.
 * @note   The ADC2 source (0x13) is reserved on AS32x601 (no ADC2
 *         peripheral) and is not part of the enumeration.
 */
#define IS_PLIC_IRQn(IRQN)   (((IRQN) == None        ) || ((IRQN) == EFLASH_IRQn ) || \
                              ((IRQN) == FCU_IRQn    ) || ((IRQN) == DMA0_IRQn   ) || \
                              ((IRQN) == DMA1_IRQn   ) || ((IRQN) == TIM0_IRQn   ) || \
                              ((IRQN) == CANFD0_IRQn ) || ((IRQN) == CANFD1_IRQn ) || \
                              ((IRQN) == ADC0_IRQn   ) || ((IRQN) == ADC1_IRQn   ) || \
                              ((IRQN) == GPIOA_IRQn  ) || ((IRQN) == GPIOB_IRQn  ) || \
                              ((IRQN) == GPIOC_IRQn  ) || ((IRQN) == PKA_IRQn    ) || \
                              ((IRQN) == SPACC_IRQn  ) || ((IRQN) == TRNG_IRQn   ) || \
                              ((IRQN) == TIM1_IRQn   ) || ((IRQN) == CANFD2_IRQn ) || \
                              ((IRQN) == CANFD3_IRQn ) || ((IRQN) == GPIOD_IRQn  ) || \
                              ((IRQN) == GPIOE_IRQn  ) || ((IRQN) == GPIOF_IRQn  ) || \
                              ((IRQN) == GPIOG_IRQn  ) || ((IRQN) == MAC_IRQn    ) || \
                              ((IRQN) == SPI0_IRQn   ) || ((IRQN) == SPI1_IRQn   ) || \
                              ((IRQN) == SPI2_IRQn   ) || ((IRQN) == I2C0_IRQn   ) || \
                              ((IRQN) == I2C1_IRQn   ) || ((IRQN) == USART0_IRQn ) || \
                              ((IRQN) == USART1_IRQn ) || ((IRQN) == USART2_IRQn ) || \
                              ((IRQN) == USART3_IRQn ) || ((IRQN) == TIM2_IRQn   ) || \
                              ((IRQN) == TIM3_IRQn   ) || ((IRQN) == TIM4_IRQn   ) || \
                              ((IRQN) == SPI3_IRQn   ) || ((IRQN) == SPI4_IRQn   ) || \
                              ((IRQN) == SPI5_IRQn   ) || ((IRQN) == I2C2_IRQn   ) || \
                              ((IRQN) == I2C3_IRQn   ) || ((IRQN) == USART4_IRQn ) || \
                              ((IRQN) == USART5_IRQn ) || ((IRQN) == USART6_IRQn ) || \
                              ((IRQN) == USART7_IRQn ) || ((IRQN) == TIM5_IRQn   ) || \
                              ((IRQN) == TIM6_IRQn   ) || ((IRQN) == TIM7_IRQn   ) || \
                              ((IRQN) == GPIOH_IRQn  ) || ((IRQN) == RTC_IRQn    ))

#define IS_PLIC_PRIORITY(PRIORITY) (((PRIORITY) <= PLIC_PRIORITY_MAX))

/**
  * @}
  */

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_PLIC_H */

/*****END OF FILE*****/
