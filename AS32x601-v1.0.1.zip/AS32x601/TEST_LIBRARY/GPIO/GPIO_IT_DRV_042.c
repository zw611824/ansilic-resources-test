/**
 * @file    GPIO_IT_DRV_042.c
 * @brief   HAL GPIO integration test case 042 (GPIOH, interrupt, software forced).
 *
 * One-to-one HAL library port of the original AS32x601 standard-library
 * test case GPIO_IT_DRV_042.c. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_PLIC_Init()           (enable the port interrupt line in the PLIC)
 *   HAL_GPIO_Init()           (input, floating)
 *   HAL_GPIO_ITConfig()     (both edges, line unmasked)
 *   HAL_GPIO_ForceINT()     (raise the interrupt in software)
 *   HAL_GPIO_IRQHandler()     (called from GPIOH_IRQ_Handler)
 *   HAL_GPIOH_EXTI_Callback()  (strong override, accumulates the fired pins)
 *
 * Test configuration:
 *   GPIOH test pins : GPIO_Pin_2 .. GPIO_Pin_9 (mask 0x03FC)
 *   GPIO_Pin_0 | GPIO_Pin_1 are the BOOT0 / BOOT1 pins: they are reserved and are
 *   not part of the test. The GPIOH port has ten channels (Pin0..Pin9) and no MI1SR
 *   register, so its channels 10..15 do not exist.
 *
 * Test procedure:
 *   1. enable the GPIOH interrupt line in the PLIC
 *   2. initialize the GPIOH test pins as floating inputs
 *   3. configure the interrupt of every test pin (both edges)
 *   4. raise the interrupt of every test pin in software (HAL_GPIO_ForceINT())
 *   5. the port interrupt handler accumulates the fired pins in Interrupt_State; watch it
 *   6. loop over step 5
 *
 * Expected behaviour:
 *   Interrupt_State = 0x03FC : every configured pin fired exactly once.
 *   HAL_GPIO_IRQHandler() clears the pending bit of every fired line before it
 *   calls HAL_GPIOH_EXTI_Callback(), so the interrupt is not re-entered.
 *
 * Note: this case prints nothing. The observation variables below and the
 * register values are meant to be watched with the debugger, and the pin
 * waveform with a logic analyser.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"

/* Private define -----------------------------------------------------------*/
/* GPIOH test pins */
#define TEST_PIN        (GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_5 | \
                         GPIO_PIN_6 | GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9)

/* Test pin mask, kept in a 32 bit type for the accumulated observations */
#define TEST_PIN_MASK   ((uint32)0x03FCU)

/* Private variables ---------------------------------------------------------*/
static HAL_SMU_HandleTypeDef hsmu_clk;   /*!< SMU handle (lock / state / error) */
static volatile uint32 Interrupt_State = 0U;  /*!< fired pins (bit mask) */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void gpioh_Config(void);
static void plic_Config(void);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Enable the port interrupt in the PLIC */
    plic_Config();

    /* Configure the GPIOH test pins */
    gpioh_Config();

    /* Step 2: configure the interrupt of every test pin. The trigger is the same as
       in the original test case (GPIO_ITType_EDGE: both edges). */
    HAL_GPIO_ITConfig(GPIOH, TEST_PIN, GPIO_ITType_EDGE, ENABLE);

    /* Step 3: raise the interrupt of every test pin in software */
    HAL_GPIO_ForceINT(GPIOH, TEST_PIN);

    while (1)
    {
        /* Steps 5..6: the port interrupt handler clears the pending bits and
           accumulates the fired pins in Interrupt_State (watch it with the
           debugger: it shall be TEST_PIN_MASK after the first interrupt) */
        delay_ms(100U);
    }
}

/**
 * @brief  Configure the system clock tree. Every case of this suite uses the
 *         same clock tree as the original standard-library test (PLL 180 MHz).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef  SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef   SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it (CLKFRQ above), so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Clock tree order: this is the order the chip requires, and the vendor
       test case uses the same one.
         1. Write the bus clock dividers while the system clock is still the
            power-on source (FIRC), so that the new divider values are already
            in place when the faster clock arrives. Writing them AFTER the
            switch instead leaves the buses at their reset dividers for a
            moment at the new core clock: at 180 MHz that is
            AXI4Bus3 = 90 MHz and APBBus0 = 45 MHz, right at their ratings, and
            the core does not survive it (measured on the board: the core
            trapped before the divider write was reached, so no output was
            produced at all).
         2. Program the EFLASH controller clock: the controller must already
            know the final frequency while the code still runs from the flash.
         3. Then configure the PLL and switch the system clock to it; this call
            also updates SystemCoreClock and re-initializes the HAL time base. */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Configure the GPIOH test pins.
 * @param  None
 * @retval None
 */
static void gpioh_Config(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    /* The GPIOH port belongs to the always-on APB-BusS domain: that port has no
       clock gate, so there is nothing to enable here */

    /* Clear the structure and set the Size / Version metafields */
    __HAL_CLEAR_STRUCT(&GPIO_InitStruct);
    GPIO_InitStruct.Size    = sizeof(GPIO_InitStruct);
    GPIO_InitStruct.Version = GPIO_INIT_VERSION;

    /* Configure the test pins */
    GPIO_InitStruct.Pin          = TEST_PIN;
    GPIO_InitStruct.Mode         = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull         = GPIO_NOPULL;
    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    GPIO_InitStruct.Alternate    = GPIO_AF_Pin_x;

    HAL_GPIO_Init(GPIOH, &GPIO_InitStruct);
}

/**
 * @brief  Enable the GPIOH interrupt line in the PLIC (priority 1 = enabled).
 * @param  None
 * @retval None
 */
static void plic_Config(void)
{
    PLIC_InitTypeDef plic_init;

    __HAL_CLEAR_STRUCT(&plic_init);
    HAL_PLIC_StructInit(&plic_init);

    plic_init.PLIC_IRQChannel    = GPIOH_IRQn;
    plic_init.PLIC_IRQPriority   = 1U;
    plic_init.PLIC_IRQChannelCmd = PLIC_ENABLE;

    HAL_PLIC_Init(&plic_init);
}

/**
 * @brief  GPIOH port interrupt handler: strong override of the weak handler
 *         provided by the PLIC module.
 * @param  None
 * @retval None
 */
void GPIOH_IRQ_Handler(void)
{
    HAL_GPIO_IRQHandler(GPIOH);
}

/**
 * @brief  GPIO interrupt line callback: accumulate the pins that fired.
 * @param  GPIO_Pin: pin mask of the interrupted port line.
 * @retval None
 */
void HAL_GPIOH_EXTI_Callback(uint16 GPIO_Pin)
{
    Interrupt_State |= (uint32)GPIO_Pin;
}

/*****END OF FILE*****/
