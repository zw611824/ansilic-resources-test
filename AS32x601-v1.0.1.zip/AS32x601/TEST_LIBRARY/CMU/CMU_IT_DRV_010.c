/**
 * @file    CMU_IT_DRV_010.c
 * @brief   HAL CMU integration test case 010 (SIRC monitoring, no threshold triggered).
 *
 * One-to-one HAL library port of the original AS32x601 standard-library test
 * case CMU_IT_DRV_010.c. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_CMU_StructInit()
 *   HAL_CMU_Init()
 *   HAL_CMU_SetWindowLength()
 *   HAL_CMU_SetReferenceThreshold()
 *   HAL_CMU_Cmd()
 *   HAL_CMU_GetFlagStatus()
 *   HAL_CMU_ClearFlag()
 *   HAL_CMU_GetState() / HAL_CMU_GetError()
 *
 * Test procedure:
 *   1. Initialize the HAL library and configure the system clock tree with the
 *      HAL SMU / PMU drivers (core clock 180 MHz, PLLQ and PLLR enabled);
 *   2. No clock source has to be enabled: the monitored clock is the OSC /
 *      PLL output already produced by the system clock tree;
 *   3. Initialize the CMU_OSC instance with HAL_CMU_Init() (the MSP hook
 *      enables the CMU clock gate and releases the CMU reset; the zero
 *      monitoring mode keeps the monitoring off);
 *   4. Program the reference count window length with
 *      HAL_CMU_SetWindowLength() (equivalent of the original CMU_SetWinLen());
 *   5. Program the high / low frequency reference thresholds with
 *      HAL_CMU_SetReferenceThreshold() (equivalent of the original
 *      CMU_SetReferenceThreshold());
 *   6. Enable the monitoring with HAL_CMU_Cmd(CMU_ENABLE) (equivalent of the
 *      original CMU_Cmd(ENABLE)), then read and clear the status flags with
 *      HAL_CMU_GetFlagStatus() / HAL_CMU_ClearFlag().
 *
 * Test configuration (same values as the original test case):
 *   monitored clock = 32.768 kHz SIRC (RC32K), window length = 37,
 *   high threshold = 24000, low threshold = 16000.
 *
 * Expected behaviour:
 *   - The configuration read-back matches the requested values (CCR / HTCR /
 *     LTCR and the CR.MODE field are non-zero only after HAL_CMU_Cmd());
 *   - neither the high threshold flag (FHH) nor the low threshold flag
 *     (FLL) is triggered (both flags stay 0).
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* CMU configuration (same values as the original test case) */
#define TEST_WINDOW_LENGTH          (37U)
#define TEST_HIGH_THRESHOLD         (24000U)
#define TEST_LOW_THRESHOLD          (16000U)

/* Expected monitoring result: 1 = the threshold must be triggered */
#define TEST_EXPECT_FHH             (0U)
#define TEST_EXPECT_FLL             (0U)

/* Monitored clock source */
#define TEST_CMU_INSTANCE           (CMU_OSC)

/* Observation window after the monitoring is enabled (ms) */
#define TEST_SETTLE_MS              (100U)

/* Status flag polling period (ms) */
#define TEST_POLL_MS                (50U)

/* Private variables ---------------------------------------------------------*/
static HAL_CMU_HandleTypeDef hcmu_dev;                /*!< CMU device handle          */
static CMU_InitTypeDef       cmu_init;                /*!< CMU configuration structure */
static volatile uint32       cmu_high_fhh_flag = 0U;  /*!< high threshold flag        */
static volatile uint32       cmu_high_fll_flag = 0U;  /*!< low threshold flag         */
static uint32                failures = 0U;           /*!< failed checks              */

static HAL_SMU_HandleTypeDef hsmu_clk;   /*!< SMU handle (lock / state / error) */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void Check(const char *name, uint32 condition);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    uint32 mode;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL, 180 MHz core / PLLQ) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== CMU_IT_DRV_010: SIRC monitoring, no threshold triggered ===\r\n");

    /* Initialize the CMU instance with the monitoring disabled */
    __HAL_CLEAR_STRUCT(&hcmu_dev);
    hcmu_dev.Instance = TEST_CMU_INSTANCE;
    HAL_CMU_StructInit(&cmu_init);
    hcmu_dev.Init = cmu_init;

    if (HAL_CMU_Init(&hcmu_dev) != HAL_OK)
    {
        printf("HAL_CMU_Init failed\r\n");
        while (1)
        {
        }
    }

    printf("CMU state = %u (1 = READY), error = %u\r\n",
           PRINT_U32(HAL_CMU_GetState(&hcmu_dev)),
           PRINT_U32(HAL_CMU_GetError(&hcmu_dev)));

    /* Reference count window length */
    Check("SetWindowLength accepted",
          (HAL_CMU_SetWindowLength(&hcmu_dev, TEST_WINDOW_LENGTH) == HAL_OK));

    /* High / low frequency reference thresholds */
    Check("SetReferenceThreshold accepted",
          (HAL_CMU_SetReferenceThreshold(&hcmu_dev, TEST_HIGH_THRESHOLD,
                                         TEST_LOW_THRESHOLD) == HAL_OK));

    /* Enable the monitoring */
    Check("Cmd(CMU_ENABLE) accepted",
          (HAL_CMU_Cmd(&hcmu_dev, CMU_ENABLE) == HAL_OK));

    /* Read back the configuration: a CMU that is still held in reset would
     * read back zeros here */
    printf("CCR  = 0x%X (expected 0x%X)\r\n",
           PRINT_U32(hcmu_dev.Instance->CCR), PRINT_U32(TEST_WINDOW_LENGTH));
    printf("HTCR = 0x%X (expected 0x%X)\r\n",
           PRINT_U32(hcmu_dev.Instance->HTCR), PRINT_U32(TEST_HIGH_THRESHOLD));
    printf("LTCR = 0x%X (expected 0x%X)\r\n",
           PRINT_U32(hcmu_dev.Instance->LTCR), PRINT_U32(TEST_LOW_THRESHOLD));

    Check("window length programmed",
          (hcmu_dev.Instance->CCR == TEST_WINDOW_LENGTH));
    Check("high threshold programmed",
          (hcmu_dev.Instance->HTCR == TEST_HIGH_THRESHOLD));
    Check("low threshold programmed",
          (hcmu_dev.Instance->LTCR == TEST_LOW_THRESHOLD));

    mode = hcmu_dev.Instance->CR & CMU_CR_MODE_Msk;
    Check("monitoring enabled (CR.MODE != 0)", (mode != 0U));
    printf("CR   = 0x%X (MODE field = 0x%X)\r\n",
           PRINT_U32(hcmu_dev.Instance->CR), PRINT_U32(mode));

    /* Let the monitoring run before the flags are polled */
    delay_ms(TEST_SETTLE_MS);

    while (1)
    {
        /* Flag polling and clearing (the original test loop) */
        if (HAL_CMU_GetFlagStatus(&hcmu_dev, CMU_FLAG_FHH) != 0U)
        {
            (void)HAL_CMU_ClearFlag(&hcmu_dev, CMU_CLEAR_FHH);
            cmu_high_fhh_flag = 1U;
        }

        if (HAL_CMU_GetFlagStatus(&hcmu_dev, CMU_FLAG_FLL) != 0U)
        {
            (void)HAL_CMU_ClearFlag(&hcmu_dev, CMU_CLEAR_FLL);
            cmu_high_fll_flag = 1U;
        }

        printf("SR = 0x%X | FHH = %u (expected %u) [%s] | FLL = %u (expected %u) [%s]\r\n",
               PRINT_U32(hcmu_dev.Instance->SR),
               PRINT_U32(cmu_high_fhh_flag), PRINT_U32(TEST_EXPECT_FHH),
               ((cmu_high_fhh_flag == TEST_EXPECT_FHH) ? "PASS" : "FAIL"),
               PRINT_U32(cmu_high_fll_flag), PRINT_U32(TEST_EXPECT_FLL),
               ((cmu_high_fll_flag == TEST_EXPECT_FLL) ? "PASS" : "FAIL"));
        printf("summary : configuration failures = %u\r\n",
               PRINT_U32(failures));

        delay_ms(TEST_POLL_MS);
    }
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition == 0U)
    {
        failures++;
    }
    printf("%-38s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Initialize the CMU MSP: enable the CMU clock gate and release the
 *         CMU reset.
 * @note   Strong override of the weak HAL_CMU_MspInit() of the driver: it
 *         reproduces the sequence of the original test case
 *         (CMU3_CLK_ENABLE(); CMU3_RESET(); CMU3_SET();), i.e. it
 *         enables the clock, asserts the reset and releases it again, so that
 *         the monitoring registers start from a known state. The driver
 *         default implementation enables the clock and releases the reset by
 *         setting the CMU0-3RST bits (setting = released, clearing = reset
 *         asserted).
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @retval None
 */
void HAL_CMU_MspInit(HAL_CMU_HandleTypeDef *hcmu)
{
    if (hcmu->Instance == CMU_FIRC)
    {
        __HAL_SMU_CMU0_CLK_ENABLE();
        __HAL_SMU_CMU0_FORCE_RESET();
        __HAL_SMU_CMU0_RELEASE_RESET();
    }
    else if (hcmu->Instance == CMU_PLLQ)
    {
        __HAL_SMU_CMU1_CLK_ENABLE();
        __HAL_SMU_CMU1_FORCE_RESET();
        __HAL_SMU_CMU1_RELEASE_RESET();
    }
    else if (hcmu->Instance == CMU_PLLR)
    {
        __HAL_SMU_CMU2_CLK_ENABLE();
        __HAL_SMU_CMU2_FORCE_RESET();
        __HAL_SMU_CMU2_RELEASE_RESET();
    }
    else
    {
        __HAL_SMU_CMU3_CLK_ENABLE();
        __HAL_SMU_CMU3_FORCE_RESET();
        __HAL_SMU_CMU3_RELEASE_RESET();
    }
}

/**
 * @brief  Configure the system clock tree using the HAL SMU / PMU drivers.
 * @note   Same clock tree as the original test case: OSC 20 MHz as PLL source,
 *         PLLDivN = 20 / PLLDivF = 180 / PLLDivQ = 1 -> 180 MHz core clock,
 *         AXI4Bus3 = /1, APBBus0 = /4, APBBus1 = /8, CANX2 = /1; the 1.2V LDO
 *         is scaled to 1.24 V like the original test does.
 * @note   Clock tree order (the order the chip requires): the bus clock
 *         dividers are written while the system clock is still the power-on
 *         source (FIRC), then HAL_SMU_OscConfig() programs the EFLASH
 *         controller clock, switches the system clock to the PLL and lets the
 *         flash clock follow. HAL_SMU_OscConfig() performs the EFLASH
 *         synchronization internally (CLKFRQ + EFLASH_CLK_UPDATE), so no
 *         explicit HAL_FLASH_SetClockFrequency() is needed here; writing the
 *         dividers after the switch instead would leave the buses at their
 *         reset dividers at the new core clock.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef  SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef   SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it (CLKFRQ above), so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Clock tree order: this is the order the chip requires, and the vendor
       test case uses the same one.
         1. Write the bus clock dividers while the system clock is still the
            power-on source (FIRC), so that the new divider values are already
            in place when the faster clock arrives. Writing them AFTER the
            switch instead leaves the buses at their reset dividers for a
            moment at the new core clock: at 180 MHz that is
            AXI4Bus3 = 90 MHz and APBBus0 = 45 MHz, right at their ratings, and
            the core does not survive it (measured on the board: the core
            trapped before the divider write was reached, so no output was
            produced at all).
         2. Program the EFLASH controller clock: the controller must already
            know the final frequency while the code still runs from the flash.
         3. Then configure the PLL and switch the system clock to it; this call
            also updates SystemCoreClock and re-initializes the HAL time base. */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
