/**
 * @file    USART_IT_DRV_014.c
 * @brief   HAL USART integration test case 014 (asynchronous transmit with CTS flow control).
 *
 * HAL library port of the original AS32x601 standard-library test case
 * USART_IT_DRV_014.c, which drives USART7. Only HAL library APIs are
 * used; the register read backs are there to document what was programmed.
 *
 * Tested functionality:
 *   HAL_USART_DeInit()
 *   HAL_USART_StructInit()
 *   HAL_USART_Init()
 *   HAL_USART_EnableFIFO()
 *   HAL_USART_GetState()
 *   HAL_USART_GetError()
 *   HAL_USART_Transmit()
 *   __HAL_USART_GET_FLAG(USART_FLAG_CTS)
 *
 * Test procedure:
 *   1. map and configure the pins of the device under test;
 *   2. program the frame parameters and initialize the USART;
 *   3. enable the receive FIFO mode;
 *   4. read the CTS flag of the instance;
 *   5. transmit the 8 byte frame only when CTS reports an active line;
 *   6. repeat.
 *
 * Expected behaviour:
 *   - CR3.CTSE is set by HAL_USART_Init();
 *   - the frame is transmitted when the CTS line is active and refused (timeout) otherwise;
 *   - the checks compare the CTS flag with the result of the transmit call, so the case passes while both agree;
 *   - every check prints [PASS] and "summary : failures = 0".
 *
 * Note:
 *   - Frame parameters: baud rate 115200, word length USART_WORDLENGTH_8B, stop bits USART_STOPBITS_1, parity USART_PARITY_NONE, hardware flow control USART_HWCONTROL_CTS, CPOL USART_POLARITY_LOW, CPHA USART_PHASE_1EDGE.
 *   - CTS is the PC4 alternate function of USART7; drive it from the host to observe both branches.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
/* Console: USART0 on GPIOD pin 8 (TX) / pin 9 (RX), 115200 8N1 */
#define TEST_BAUDRATE                   (115200U)

/* Device under test: the pins are the ones the original test case uses */
#define TEST_USART                      USART7
#define TEST_USART_IRQn                 USART7_IRQn
#define TEST_USART_IRQ_HANDLER          USART7_IRQ_Handler
#define TEST_TX_PORT                    GPIOA
#define TEST_TX_PIN                     GPIO_PIN_6
#define TEST_TX_SOURCE                  GPIO_PinSource6
#define TEST_TX_AF                      GPIO_AF_USART7
#define TEST_RX_PORT                    GPIOA
#define TEST_RX_PIN                     GPIO_PIN_7
#define TEST_RX_SOURCE                  GPIO_PinSource7
#define TEST_RX_AF                      GPIO_AF_USART7
#define TEST_CTS_PORT                   GPIOC
#define TEST_CTS_PIN                    GPIO_PIN_4
#define TEST_CTS_SOURCE                 GPIO_PinSource4
#define TEST_CTS_AF                     GPIO_AF_USART7

/* Frame parameters of this case */
#define TEST_BAUD_RATE                  (115200U)
#define TEST_WORD_LENGTH                USART_WORDLENGTH_8B
#define TEST_STOP_BITS                  USART_STOPBITS_1
#define TEST_PARITY                     USART_PARITY_NONE
#define TEST_MODE                       (USART_MODE_TX_RX)
#define TEST_OVERSAMPLING               USART_OVERSAMPLING_16
#define TEST_FLOW_CONTROL               USART_HWCONTROL_CTS
#define TEST_CLK_POLARITY               USART_POLARITY_LOW
#define TEST_CLK_PHASE                  USART_PHASE_1EDGE
#define TEST_CLK_LASTBIT                USART_LASTBIT_DISABLE
#define TEST_SYNC_MODE                  (0U)
#define TEST_SLAVE_MODE                 (0U)

/* Frame geometry, pacing and timeouts */
#define TX_FRAME_SIZE                   (8U)
#define RX_BURST_SIZE                   (64U)
#define TX_FRAME_PERIOD_MS              (500U)
#define TRANSFER_TIMEOUT_MS             (2000U)
#define WAIT_SPINS                      (20000000U)
#define RX_WAIT_MS                      (1000U)

/* Private variables --------------------------------------------------------*/
static USART_HandleTypeDef husart_dev;          /*!< device under test       */
static HAL_SMU_HandleTypeDef hsmu_clk;          /*!< SMU handle (clock tree) */
static const uint8 tx_data[TX_FRAME_SIZE] = {0x11U, 0x22U, 0x33U, 0x44U,
                                              0x55U, 0x66U, 0x77U, 0x88U};

static volatile uint32 check_failures = 0U;     /*!< failed check counter    */


/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void USART_GPIO_Init(void);
static void Check(const char *name, uint32 condition);
static void Summary(void);


/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    USART_InitTypeDef usart_init;
    uint32 expected_brr;
    uint32 frame;
    uint32 cts_active;
    HAL_StatusTypeDef status;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock tree */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART (USART0 on GPIOD pin 8 / pin 9) */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== USART_IT_DRV_014 : asynchronous transmit with CTS flow control ===\r\n");

    /* Step 1: map and configure the pins of the device under test */
    USART_GPIO_Init();

    /* Step 2: program the frame parameters and initialize the USART */
    (void)HAL_USART_DeInit(&husart_dev);

    HAL_USART_StructInit(&usart_init);
    usart_init.BaudRate            = TEST_BAUD_RATE;
    usart_init.WordLength          = TEST_WORD_LENGTH;
    usart_init.StopBits            = TEST_STOP_BITS;
    usart_init.Parity              = TEST_PARITY;
    usart_init.Mode                = TEST_MODE;
    usart_init.OverSampling        = TEST_OVERSAMPLING;
    usart_init.HardwareFlowControl = TEST_FLOW_CONTROL;
    usart_init.CLKPolarity         = TEST_CLK_POLARITY;
    usart_init.CLKPhase            = TEST_CLK_PHASE;
    usart_init.CLKLastBit          = TEST_CLK_LASTBIT;

    husart_dev.Instance = TEST_USART;
    husart_dev.Init     = usart_init;

    Check("HAL_USART_Init", (uint32)((HAL_USART_Init(&husart_dev) == HAL_OK) ? 1U : 0U));
    Check("state after init is READY",
          (uint32)((HAL_USART_GetState(&husart_dev) == HAL_USART_STATE_READY) ? 1U : 0U));
    Check("error code after init is NONE",
          (uint32)((HAL_USART_GetError(&husart_dev) == HAL_USART_ERROR_NONE) ? 1U : 0U));

    /* Cross check the baud rate divider: the driver computes the divider as
     * BRR = bus clock / baud rate. USART0..USART3 are clocked by APBBus0 and
     * USART4..USART7 by APBBus1. */
    expected_brr = HAL_SMU_GetPCLK1Freq() / TEST_BAUD_RATE;

    printf("bus clock       : %u Hz\r\n", PRINT_U32(HAL_SMU_GetPCLK1Freq()));
    printf("divider         : BRR = %u (expected %u) %s\r\n",
           PRINT_U32((uint32)TEST_USART->BRR), PRINT_U32(expected_brr),
           (((uint32)TEST_USART->BRR == expected_brr) ? "[PASS]" : "[FAIL]"));
    if ((uint32)TEST_USART->BRR != expected_brr)
    {
        check_failures++;
    }

    /* Step 3: enable the FIFO mode, as the original test case does */
    Check("HAL_USART_EnableFIFO",
          (uint32)((HAL_USART_EnableFIFO(&husart_dev) == HAL_OK) ? 1U : 0U));

    /* Step 4: the CTS input gates the transmission: the frame is only sent
     * when the CTS flag reports an active (low) CTS line. The check compares
     * what the flag says with what the blocking transmit did, so the case
     * passes whether the CTS line is asserted or not, as long as the two
     * agree (the original test case does the same test by hand). */
    frame = 0U;
    while (1)
    {
        cts_active = (uint32)((__HAL_USART_GET_FLAG(&husart_dev, USART_FLAG_CTS) != RESET) ? 1U : 0U);
        frame++;

        status = HAL_USART_Transmit(&husart_dev, (uint8 *)tx_data, TX_FRAME_SIZE,
                                    (cts_active != 0U) ? TRANSFER_TIMEOUT_MS : 50U);

        if (cts_active != 0U)
        {
            Check("CTS active : frame transmitted",
                  (uint32)((status == HAL_OK) ? 1U : 0U));
        }
        else
        {
            Check("CTS inactive : frame NOT transmitted",
                  (uint32)((status != HAL_OK) ? 1U : 0U));
        }

        printf("frame %u : CTS flag = %u, HAL_USART_Transmit = %u\r\n",
               PRINT_U32(frame), PRINT_U32(cts_active), PRINT_U32((uint32)status));
        printf("CR3 = 0x%08X (CTSE = 0x%08X) %s\r\n",
               PRINT_U32((uint32)TEST_USART->CR3), PRINT_U32((uint32)USART_CR3_CTSE),
               ((((uint32)TEST_USART->CR3 & (uint32)USART_CR3_CTSE) != 0U) ? "[PASS]" : "[FAIL]"));
        if (((uint32)TEST_USART->CR3 & (uint32)USART_CR3_CTSE) == 0U)
        {
            check_failures++;
        }

        Summary();
        delay_ms(TX_FRAME_PERIOD_MS);
    }
}

/**
 * @brief  Report the result of one check.
 * @param  name: short description of the check.
 * @param  condition: 0 = FAIL, non zero = PASS.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("%-44s : [PASS]\r\n", name);
    }
    else
    {
        check_failures++;
        printf("%-44s : [FAIL]\r\n", name);
    }
}

/**
 * @brief  Print the accumulated failure counter.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("summary : failures = %u\r\n", PRINT_U32(check_failures));
}

/**
 * @brief  Map and configure the pins of the device under test.
 * @note   The ports are the ones the original test case uses. GPIOH lives in
 *         the always on domain, so the library provides no clock gate for it.
 * @param  None
 * @retval None
 */
static void USART_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    /* Port clock gates used by this case */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    /* GPIOH (when used) lives in the always on domain: no clock gate */

    /* TX pin: alternate function push pull */
    HAL_GPIO_PinAFConfig(TEST_TX_PORT, TEST_TX_SOURCE, TEST_TX_AF);
    __HAL_CLEAR_STRUCT(&GPIO_InitStruct);
    GPIO_InitStruct.Size         = sizeof(GPIO_InitStruct);
    GPIO_InitStruct.Version      = GPIO_INIT_VERSION;
    GPIO_InitStruct.Pin          = TEST_TX_PIN;
    GPIO_InitStruct.Mode         = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull         = GPIO_NOPULL;
    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;
    GPIO_InitStruct.Alternate    = TEST_TX_AF;
    HAL_GPIO_Init(TEST_TX_PORT, &GPIO_InitStruct);

    /* RX pin: alternate function input (floating) */
    HAL_GPIO_PinAFConfig(TEST_RX_PORT, TEST_RX_SOURCE, TEST_RX_AF);
    GPIO_InitStruct.Pin       = TEST_RX_PIN;
    GPIO_InitStruct.Mode      = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull      = GPIO_NOPULL;
    GPIO_InitStruct.Alternate = TEST_RX_AF;
    HAL_GPIO_Init(TEST_RX_PORT, &GPIO_InitStruct);
    /* CTS input of the hardware flow control */
    HAL_GPIO_PinAFConfig(TEST_CTS_PORT, TEST_CTS_SOURCE, TEST_CTS_AF);
    GPIO_InitStruct.Pin       = TEST_CTS_PIN;
    GPIO_InitStruct.Mode      = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull      = GPIO_NOPULL;
    GPIO_InitStruct.Alternate = TEST_CTS_AF;
    HAL_GPIO_Init(TEST_CTS_PORT, &GPIO_InitStruct);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the CLINT / CMU / MPU integration tests: PLL
 *         VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2, CANX2 by 8.
 *         With this tree the APB bus clock is 22.5 MHz, which is the reference
 *         the baud rate divider check of every case is computed from.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef    SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the same set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_USART7_CLK_ENABLE();
    __HAL_SMU_USART7_FORCE_RESET();
    __HAL_SMU_USART7_RELEASE_RESET();

    /* Clock gate and reset pulse of the USART under test */
    /* Initialize the PMU before the voltage scaling calls: the LDO API is
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Clock tree order: this is the order the chip requires (and the one the
       reference test case uses):
         1. write the bus dividers while the system clock is still the power on
            source (FIRC), so that the new divider values are already in place
            when the faster clock arrives. Writing them after the switch leaves
            the buses at their reset dividers for a moment at the new core
            clock, which the core does not survive at 180 MHz.
         2. configure the PLL and switch the system clock to it. This call also
            programs the flash controller clock before the switch and update
            SystemCoreClock afterwards. */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
