/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):  	Xiamen Guoke Anxin Technology Co., LTD
 * FileName:     	as32x601_startup_iar.S
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.2
 * Date:			2026/10/08
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/05     1.0     port to HAL library
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.1     RTOS support: initialize mscratch to the
 *                                                       dedicated interrupt stack top before
 *                                                       enabling global interrupts
 *                                                       (HAL_INTERRUPT_STACK_SIZE > 0)
 *     ANSILIC APPLICATION GROUP  2026/10/08     1.2     harden the memory-initialization
 *                                                       loops with byte tails, clear
 *                                                       mstatus.MIE explicitly at
 *                                                       reset, pass argc/argv
 *                                                       explicitly to main, compose
 *                                                       mstatus from named fields
 *                                                       and reject a configuration
 *                                                       that enables RTOS without
 *                                                       deriving a dedicated
 *                                                       interrupt stack size
 * Description:     This file implements the startup operation for the AS32x601
 *                  (IAR toolchain), such as pointer configuration, data segment
 *                  initialization, and interrupt configuration.
 */

    SECTION `.init`:CODE
    PUBLIC  _start

    EXTERN   main

    EXTERN RW_DATA$$Limit
    EXTERN CSTACK$$Limit
    EXTERN CSTACK$$Base
    EXTERN RW_DATA$$Base
    EXTERN RW_DATA_INIT$$Base
    EXTERN RW_BSS$$Base
    EXTERN RW_BSS$$Limit
    EXTERN SystemInit
    EXTERN TrapEntry
    EXTERN  __iar_static_base$$GPREL

/* The HAL configuration file is auto-included when found on the include path
 * (it provides HAL_INTERRUPT_STACK_SIZE derived from USE_RTOS).
 * NOTE: written without the __has_include operator token to stay safe under
 * preprocessors where a semicolon is not a comment (IAR assembly comments). */
#if defined(__has_include)
    #if __has_include("as32x601_hal_conf.h")
        #include "as32x601_hal_conf.h"
    #endif
#endif /* defined(__has_include) */

#ifndef HAL_INTERRUPT_STACK_SIZE
    #define HAL_INTERRUPT_STACK_SIZE 0
#endif /* HAL_INTERRUPT_STACK_SIZE */

; Configuration consistency: a build that selects RTOS must derive a positive
; dedicated interrupt-stack size.  Without this check the interrupt stack stays
; silently disabled while the trap entry still expects it, which is only
; visible at run time.
#if defined(USE_RTOS) && (USE_RTOS == 1U) && (HAL_INTERRUPT_STACK_SIZE == 0)
    #error "USE_RTOS is enabled but HAL_INTERRUPT_STACK_SIZE is zero - put as32x601_hal_conf.h on the include path"
#endif

; CSR field operands, composed by field name instead of a bare literal.  The
; STARTUP_ prefix keeps these assembler constants in a name space of their own:
; the core header declares bit masks with the same field names (MSTATUS_MIE,
; MIE_MEIE, ...).  That header is skipped during assembly because the project
; defines __ASSEMBLER__, but the prefix makes the separation structural rather
; than dependent on that define.
STARTUP_STACK_FILL_PATTERN    EQU  0xAAAAAAAA   ; stack paint for depth/overflow checks
STARTUP_MSTATUS_MIE           EQU  0x00000008   ; mstatus[3]     global machine interrupt enable
STARTUP_MSTATUS_MPIE          EQU  0x00000080   ; mstatus[7]     previous interrupt enable
STARTUP_MSTATUS_MPP_MACHINE   EQU  0x00001800   ; mstatus[12:11] previous privilege = Machine
STARTUP_MSTATUS_FS_DIRTY      EQU  0x00006000   ; mstatus[14:13] floating-point state = Dirty
STARTUP_MIE_MEIE              EQU  0x00000800   ; mie[11]        machine external interrupt enable

#if (HAL_INTERRUPT_STACK_SIZE > 0)
    ; RTOS support: dedicated interrupt stack top (defined in
    ; as32x601_trapentry_iar.S).  Must be defined before global interrupts
    ; are enabled below.
    EXTERN  _isr_stack_top
#endif /* (HAL_INTERRUPT_STACK_SIZE > 0) */

    ALIGN  2

_start:
    .option   norvc;

    ; Reset-time interrupt state: clear the global machine interrupt enable
    ; explicitly instead of trusting an undocumented reset default, so no
    ; interrupt can be granted while the runtime is still being built.  This is
    ; the only place the bit is cleared; the final enable is near the end.
    li      t0, STARTUP_MSTATUS_MIE
    csrc    mstatus, t0

    la gp, __iar_static_base$$GPREL
    la sp, CSTACK$$Limit

    /* Fill stack region with pattern for overflow detection.  The range is the
     * half-open interval [CSTACK$$Base, CSTACK$$Limit): the word loop runs only
     * while a full word fits and the byte tail covers a residual of 1 to 3
     * bytes, so no byte outside the interval is touched even when the reserved
     * size is not a multiple of four. */
    la a0, CSTACK$$Base
    la a1, CSTACK$$Limit
    li t0, STARTUP_STACK_FILL_PATTERN
stack_fill:
    bgeu a0, a1, stack_fill_done
    addi t1, a0, 4
    bgtu t1, a1, stack_fill_tail
    sw t0, 0(a0)
    addi a0, a0, 4
    j stack_fill
stack_fill_tail:
    bgeu a0, a1, stack_fill_done
    sb t0, 0(a0)
    addi a0, a0, 1
    j stack_fill_tail
stack_fill_done:

    /* Load the initialized-data sections from their ROM image into the RAM run
     * area, RW_DATA$$Base..RW_DATA$$Limit from RW_DATA_INIT$$Base.  Same word
     * loop plus byte tail as the stack paint above, so a run range that is not
     * a multiple of four is copied completely and exactly. */
    la a0, RW_DATA_INIT$$Base
    la a1, RW_DATA$$Base
    la a2, RW_DATA$$Limit
copy_data:
    bgeu a1, a2, copy_data_done
    addi t1, a1, 4
    bgtu t1, a2, copy_data_tail
    lw t0, 0(a0)
    sw t0, 0(a1)
    addi a0, a0, 4
    addi a1, a1, 4
    j copy_data
copy_data_tail:
    bgeu a1, a2, copy_data_done
    lbu t0, 0(a0)
    sb t0, 0(a1)
    addi a0, a0, 1
    addi a1, a1, 1
    j copy_data_tail
copy_data_done:

    /* Clear the zero-initialized range RW_BSS$$Base..RW_BSS$$Limit.  Same word
     * loop plus byte tail.  Storage outside this range (a .noinit section) is
     * deliberately left untouched. */
    la a0, RW_BSS$$Base
    la a1, RW_BSS$$Limit
zero_bss:
    bgeu a0, a1, zero_bss_done
    addi t1, a0, 4
    bgtu t1, a1, zero_bss_tail
    sw zero, 0(a0)
    addi a0, a0, 4
    j zero_bss
zero_bss_tail:
    bgeu a0, a1, zero_bss_done
    sb zero, 0(a0)
    addi a0, a0, 1
    j zero_bss_tail
zero_bss_done:
#if (HAL_INTERRUPT_STACK_SIZE > 0)
    ; RTOS support: point mscratch at the dedicated interrupt stack top so
    ; that the trap entry can swap to it (csrrw sp, mscratch, sp).  Must be
    ; done BEFORE global interrupts are enabled below (an early interrupt
    ; would otherwise swap with an undefined mscratch).
    la      t0, _isr_stack_top
    csrw    mscratch, t0
#endif /* (HAL_INTERRUPT_STACK_SIZE > 0) */

    /* Configure the CPU status without enabling global interrupts.  The value is
     * composed from named fields rather than written as a bare literal:
     *   mstatus[3]     MIE  = 0  global interrupts remain disabled
     *   mstatus[7]     MPIE = 1  previous interrupt enable
     *   mstatus[12:11] MPP  = 11 Machine mode
     *   mstatus[14:13] FS   = 11 Dirty (FPU enabled, adapts None/F/D,
     *                          unimplemented bits ignored by hardware)
     * which yields 0x00007880. */
    li      t0, STARTUP_MSTATUS_FS_DIRTY
    ori     t0, t0, STARTUP_MSTATUS_MPIE
    li      t1, STARTUP_MSTATUS_MPP_MACHINE
    or      t0, t0, t1
    csrw    mstatus, t0

    ; Initialize floating-point control/status register to zero.  Deliberately
    ; kept before mtvec and mie are programmed: once an interrupt can be granted,
    ; an intervening FP context would have its flags erased by this clear.
    csrw    fcsr, zero

    /* Set the trap/exception entry function before enabling interrupts */
    la      t0, TrapEntry
    csrw    mtvec, t0

    /* Enable machine external interrupt (PLIC): mie[11] MEIE = 1 */
    li      t0, STARTUP_MIE_MEIE
    csrw    mie, t0

    /* Enable CPU global interrupts only after mtvec and mie are configured */
    csrrsi  zero, mstatus, STARTUP_MSTATUS_MIE

    ; Call the system initialization function if needed
    ; call SystemInit

    ; Jump to the application with an explicit empty argument list: argc = 0 in
    ; a0 and argv = NULL in a1, instead of whatever the reset state left there.
    ; _start does not return: reaching the loop below is a fatal condition.
    li      a0, 0
    li      a1, 0
    call    main

loop:
    j loop

    END
