/**
 * @file    PKA_IT_DRV_001.c
 * @brief   HAL PKA integration test case 001 (ECC key exchange).
 *
 * Case 001 translates the reference ECC key exchange example (P-256) to the
 * HAL API: both peers derive their public key with a point multiplication and
 * then their shared secret from the other peer's public key, and every value
 * is compared with the expected vector of the reference material.  The
 * micro-code is loaded with HAL_PKA_LoadFirmware() and every operand is
 * transferred with HAL_PKA_WriteData() / HAL_PKA_ReadData(), so the case
 * exercises the whole HAL data path of the module.
 *
 * The operand addresses, the entry point (0x19, point multiplication) and the
 * base radix (256-bit) are the ones of the reference case.  The partial radix
 * stays 0, which selects the complete base.
 *
 * Tested functionality:
 *   HAL_PKA_Init() / HAL_PKA_MspInit() / HAL_PKA_ClearStack() /
 *   HAL_PKA_SetEntryPoint() / HAL_PKA_LoadFirmware() /
 *   HAL_PKA_WriteData() / HAL_PKA_ReadData() /
 *   HAL_PKA_GetStatStatus() / HAL_PKA_ClearStatus()
 *
 * Test procedure:
 *   1. Load the micro-code image and clear the operand window;
 *   2. Alice public key: operand setup, point multiplication, read back and
 *      compare Ax / Ay with the expected vector;
 *   3. Bob public key: the same with Bob's private key, compare Bx / By;
 *   4. Alice shared secret: point multiplication of Bob's public key with
 *      Alice's private key, compare Sx / Sy;
 *   5. Bob shared secret: the same with Alice's public key, compare Sx / Sy;
 *   6. Print the check counter and the number of failures.
 *
 * Expected behaviour:
 *   - every comparison matches the expected vector, so the summary stays at
 *     zero failures;
 *   - the case repeats the four operations forever, which allows the report
 *     to be read at any time.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"
#include "as32x601_pka_fw.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Operand sizes: one 256-bit operand is 8 words, one 512-bit operand 16 */
#define PKA_ECC_WORDS               (8U)
#define PKA_ECC_BYTES               (32U)
#define PKA_RSA_WORDS               (16U)
#define PKA_RSA_BYTES               (64U)

/* Partial radix used by the reference examples: 0 selects the complete base */
#define TEST_PARTIAL_RADIX          (0U)

/* Bound of every polling loop, so a failure can never hang the case */
#define TEST_WAIT_GUARD             (20000000U)

/* Micro-code entry points of the operations used by the case */
#define TEST_EP_PMULT               (0x19U)   /* point multiplication      */

/* Reporting period of the final loop (ms) */
#define TEST_POLL_MS                (1000U)

/* Private variables ---------------------------------------------------------*/
static HAL_PKA_HandleTypeDef hpka_dev;      /*!< PKA device handle            */
static PKA_InitTypeDef       pka_init;      /*!< configuration used at start  */
static HAL_SMU_HandleTypeDef hsmu_clk;      /*!< SMU handle (clock tree)      */
static uint32                failures = 0U; /*!< failed checks                */
static uint32                checks = 0U;   /*!< executed checks              */

/* Zero buffer used to clear the operand window (1024 words = the window) */
static uint32 pka_zero[PKA_OPERAND_WINDOW_WORDS_MAX];

/* Private function prototypes -----------------------------------------------*/
static void Section(const char *name);
static void Check(const char *name, uint32 condition);
static HAL_StatusTypeDef Pka_LoadFirmware(void);
static HAL_StatusTypeDef Pka_ClearMemory(void);
static HAL_StatusTypeDef Pka_Write(uint32 address, const uint32 *data, uint32 words);
static HAL_StatusTypeDef Pka_Read(uint32 address, uint32 *data, uint32 words);
static HAL_StatusTypeDef Pka_Run(uint32 entry, uint32 radix);
static uint32 Pka_Compare(const uint32 *result, const uint32 *expect, uint32 words);
static void Pka_Report(const char *name, const uint32 *result, const uint32 *expect, uint32 words);
static void SystemClock_Init(void);

/* Private variables (test vectors) ------------------------------------------*/

/* base point Gx of P-256 (little endian words) */
static const uint32 ECC_KEYExchange_Gx[PKA_ECC_WORDS] =
{
    0xd898c296, 0xf4a13945, 0x2deb33a0, 0x77037d81,
    0x63a440f2, 0xf8bce6e5, 0xe12c4247, 0x6b17d1f2
};

/* base point Gy of P-256 */
static const uint32 ECC_KEYExchange_Gy[PKA_ECC_WORDS] =
{
    0x37bf51f5, 0xcbb64068, 0x6b315ece, 0x2bce3357,
    0x7c0f9e16, 0x8ee7eb4a, 0xfe1a7f9b, 0x4fe342e2
};

/* field prime p */
static const uint32 ECC_KEYExchange_p[PKA_ECC_WORDS] =
{
    0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0x00000000,
    0x00000000, 0x00000000, 0x00000001, 0xFFFFFFFF
};

/* Montgomery precomputation p' */
static const uint32 ECC_KEYExchange_p_[PKA_ECC_WORDS] =
{
    0x00000001, 0x00000000, 0x00000000, 0x00000001,
    0x00000000, 0x00000000, 0x00000002, 0xffffffff
};

/* Montgomery precomputation r^2 mod p */
static const uint32 ECC_KEYExchange_r2_mod_p[PKA_ECC_WORDS] =
{
    0x00000003, 0x00000000, 0xFFFFFFFF, 0xFFFFFFFB,
    0xFFFFFFFE, 0xFFFFFFFF, 0xFFFFFFFD, 0x00000004
};

/* curve parameter a */
static const uint32 ECC_KEYExchange_a[PKA_ECC_WORDS] =
{
    0xfffffffc, 0xffffffff, 0xffffffff, 0x00000000,
    0x00000000, 0x00000000, 0x00000001, 0xffffffff
};

/* The curve parameter b and the order n of the base point are not carried
   here: the point multiplication of this case does not read them, so they
   would only be dead data (and a compilation warning).  Their documented
   values are b = 0x5AC635D8AA3A93E7B3EBBD55769886BC651D06B0CC53B0F63BCE3C3E27D2604B
   and n = 0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551. */
/* Alice private key k */
static const uint32 ECC_KEYExchange_Alice_Private_k[PKA_ECC_WORDS] =
{
    0x32C10CE6, 0x2CCDC5C2, 0x380318AD, 0xF7C9547A,
    0xED8FEF03, 0xC715F966, 0x0F80B3DF, 0x50CFF1A1
};

/* Alice public key Ax, expected */
static const uint32 ECC_KEYExchange_Alice_Public_Ax_Expect[PKA_ECC_WORDS] =
{
    0x48111c1c, 0x07c5d6b7, 0x0e2dbcf8, 0xe39cc6c1,
    0x534480ba, 0x5f7e43ac, 0xd93e17ac, 0x9ad8f0ce
};

/* Alice public key Ay, expected */
static const uint32 ECC_KEYExchange_Alice_Public_Ay_Expect[PKA_ECC_WORDS] =
{
    0x1c716157, 0x4014f211, 0xb738320d, 0x2b60c375,
    0x0e9e3597, 0xe3c62779, 0xcc85d7da, 0xde308602
};

/* Bob private key k */
static const uint32 ECC_KEYExchange_Bob_Private_k[PKA_ECC_WORDS] =
{
    0x9666a9e7, 0x822ff545, 0xfbe8bf54, 0x82a4b7a0,
    0xf052beb9, 0x15800d4f, 0xa737ad2d, 0xfc872ae3
};

/* Bob public key Bx, expected */
static const uint32 ECC_KEYExchange_Bob_Public_Bx_Expect[PKA_ECC_WORDS] =
{
    0x23480ca4, 0x4e2f6dc8, 0x1c41bb7e, 0x908be748,
    0xa6cfdb06, 0x9865908c, 0x9e4009c8, 0x54aeb5d0
};

/* Bob public key By, expected */
static const uint32 ECC_KEYExchange_Bob_Public_By_Expect[PKA_ECC_WORDS] =
{
    0x95c5b395, 0x8d0ad829, 0xa94a1569, 0x56d3e524,
    0x074873cc, 0x56de63e2, 0x98c09a07, 0xfcb12646
};

/* shared secret Sx, expected */
static const uint32 ECC_KEYExchange_ShareKey_Sx_Expect[PKA_ECC_WORDS] =
{
    0x63ebab42, 0x9c373012, 0x7acc7111, 0xc9b885cc,
    0x8a5c0d42, 0x5037ac7a, 0x660724d9, 0x4cc197d3
};

/* shared secret Sy, expected */
static const uint32 ECC_KEYExchange_ShareKey_Sy_Expect[PKA_ECC_WORDS] =
{
    0x4314675e, 0x90c7d5e0, 0xf9defe5f, 0xee1b5862,
    0x87a12bd3, 0x7f11138b, 0x554533b4, 0xa328049f
};

/* Measured results of the four operations */
static uint32 ECC_KEYExchange_Alice_Public_Ax_Result[PKA_ECC_WORDS];
static uint32 ECC_KEYExchange_Alice_Public_Ay_Result[PKA_ECC_WORDS];
static uint32 ECC_KEYExchange_Bob_Public_Bx_Result[PKA_ECC_WORDS];
static uint32 ECC_KEYExchange_Bob_Public_By_Result[PKA_ECC_WORDS];
static uint32 ECC_KEYExchange_Alice_ShareKey_Sx_Result[PKA_ECC_WORDS];
static uint32 ECC_KEYExchange_Alice_ShareKey_Sy_Result[PKA_ECC_WORDS];
static uint32 ECC_KEYExchange_Bob_ShareKey_Sx_Result[PKA_ECC_WORDS];
static uint32 ECC_KEYExchange_Bob_ShareKey_Sy_Result[PKA_ECC_WORDS];


/* Private functions ---------------------------------------------------------*/
int main(void)
{
    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL, 90 MHz core clock) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);

    printf("\r\n ***** PKA ECC Key Exchange test ***** \r\n");
    delay_ms(500U);

    /* Initialize the PKA handle: the low level callback enables the DSE clock
       and releases the domain reset */
    __HAL_CLEAR_STRUCT(&hpka_dev);
    hpka_dev.Instance = PKA;
    HAL_PKA_StructInit(&pka_init);
    (void)HAL_PKA_Init(&hpka_dev, &pka_init);

    Section("firmware and operand memory");
    Check("micro-code image loaded", (Pka_LoadFirmware() == HAL_OK) ? 1U : 0U);
    Check("operand window cleared", (Pka_ClearMemory() == HAL_OK) ? 1U : 0U);

    for (;;)
    {
        /* ------------------------------------------------ Alice public key */
        Section("Alice public key (k * G)");

        (void)Pka_Write(PKA_ECC_ADDR_256_A2, ECC_KEYExchange_Gx, PKA_ECC_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_B2, ECC_KEYExchange_Gy, PKA_ECC_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_A6, ECC_KEYExchange_a, PKA_ECC_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D7, ECC_KEYExchange_Alice_Private_k, PKA_ECC_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D0, ECC_KEYExchange_p, PKA_ECC_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D1, ECC_KEYExchange_p_, PKA_ECC_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D3, ECC_KEYExchange_r2_mod_p, PKA_ECC_WORDS);

        Check("Alice: point multiplication completed",
              (Pka_Run(TEST_EP_PMULT, PKA_BASE_RADIX_256) == HAL_OK) ? 1U : 0U);

        (void)Pka_Read(PKA_ECC_ADDR_256_A2, ECC_KEYExchange_Alice_Public_Ax_Result, PKA_ECC_WORDS);
        (void)Pka_Read(PKA_ECC_ADDR_256_B2, ECC_KEYExchange_Alice_Public_Ay_Result, PKA_ECC_WORDS);

        Check("Alice public Ax matches the expected vector",
              Pka_Compare(ECC_KEYExchange_Alice_Public_Ax_Result,
                          ECC_KEYExchange_Alice_Public_Ax_Expect, PKA_ECC_WORDS));
        Pka_Report("Alice public Ax", ECC_KEYExchange_Alice_Public_Ax_Result,
                   ECC_KEYExchange_Alice_Public_Ax_Expect, PKA_ECC_WORDS);
        Check("Alice public Ay matches the expected vector",
              Pka_Compare(ECC_KEYExchange_Alice_Public_Ay_Result,
                          ECC_KEYExchange_Alice_Public_Ay_Expect, PKA_ECC_WORDS));
        Pka_Report("Alice public Ay", ECC_KEYExchange_Alice_Public_Ay_Result,
                   ECC_KEYExchange_Alice_Public_Ay_Expect, PKA_ECC_WORDS);

        /* -------------------------------------------------- Bob public key */
        Section("Bob public key (k * G)");

        (void)Pka_Write(PKA_ECC_ADDR_256_A2, ECC_KEYExchange_Gx, PKA_ECC_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_B2, ECC_KEYExchange_Gy, PKA_ECC_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_A6, ECC_KEYExchange_a, PKA_ECC_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D7, ECC_KEYExchange_Bob_Private_k, PKA_ECC_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D0, ECC_KEYExchange_p, PKA_ECC_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D1, ECC_KEYExchange_p_, PKA_ECC_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D3, ECC_KEYExchange_r2_mod_p, PKA_ECC_WORDS);

        Check("Bob: point multiplication completed",
              (Pka_Run(TEST_EP_PMULT, PKA_BASE_RADIX_256) == HAL_OK) ? 1U : 0U);

        (void)Pka_Read(PKA_ECC_ADDR_256_A2, ECC_KEYExchange_Bob_Public_Bx_Result, PKA_ECC_WORDS);
        (void)Pka_Read(PKA_ECC_ADDR_256_B2, ECC_KEYExchange_Bob_Public_By_Result, PKA_ECC_WORDS);

        Check("Bob public Bx matches the expected vector",
              Pka_Compare(ECC_KEYExchange_Bob_Public_Bx_Result,
                          ECC_KEYExchange_Bob_Public_Bx_Expect, PKA_ECC_WORDS));
        Pka_Report("Bob public Bx", ECC_KEYExchange_Bob_Public_Bx_Result,
                   ECC_KEYExchange_Bob_Public_Bx_Expect, PKA_ECC_WORDS);
        Check("Bob public By matches the expected vector",
              Pka_Compare(ECC_KEYExchange_Bob_Public_By_Result,
                          ECC_KEYExchange_Bob_Public_By_Expect, PKA_ECC_WORDS));
        Pka_Report("Bob public By", ECC_KEYExchange_Bob_Public_By_Result,
                   ECC_KEYExchange_Bob_Public_By_Expect, PKA_ECC_WORDS);

        /* ------------------------------------------------ Alice shared key */
        Section("shared secret, Alice side (kA * B)");

        (void)Pka_Write(PKA_ECC_ADDR_256_A2, ECC_KEYExchange_Bob_Public_Bx_Result, PKA_ECC_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_B2, ECC_KEYExchange_Bob_Public_By_Result, PKA_ECC_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_A6, ECC_KEYExchange_a, PKA_ECC_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D7, ECC_KEYExchange_Alice_Private_k, PKA_ECC_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D0, ECC_KEYExchange_p, PKA_ECC_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D1, ECC_KEYExchange_p_, PKA_ECC_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D3, ECC_KEYExchange_r2_mod_p, PKA_ECC_WORDS);

        Check("Alice: shared secret operation completed",
              (Pka_Run(TEST_EP_PMULT, PKA_BASE_RADIX_256) == HAL_OK) ? 1U : 0U);

        (void)Pka_Read(PKA_ECC_ADDR_256_A2, ECC_KEYExchange_Alice_ShareKey_Sx_Result, PKA_ECC_WORDS);
        (void)Pka_Read(PKA_ECC_ADDR_256_B2, ECC_KEYExchange_Alice_ShareKey_Sy_Result, PKA_ECC_WORDS);

        Check("Alice shared Sx matches the expected vector",
              Pka_Compare(ECC_KEYExchange_Alice_ShareKey_Sx_Result,
                          ECC_KEYExchange_ShareKey_Sx_Expect, PKA_ECC_WORDS));
        Pka_Report("Alice shared Sx", ECC_KEYExchange_Alice_ShareKey_Sx_Result,
                   ECC_KEYExchange_ShareKey_Sx_Expect, PKA_ECC_WORDS);
        Check("Alice shared Sy matches the expected vector",
              Pka_Compare(ECC_KEYExchange_Alice_ShareKey_Sy_Result,
                          ECC_KEYExchange_ShareKey_Sy_Expect, PKA_ECC_WORDS));
        Pka_Report("Alice shared Sy", ECC_KEYExchange_Alice_ShareKey_Sy_Result,
                   ECC_KEYExchange_ShareKey_Sy_Expect, PKA_ECC_WORDS);

        /* -------------------------------------------------- Bob shared key */
        Section("shared secret, Bob side (kB * A)");

        (void)Pka_Write(PKA_ECC_ADDR_256_A2, ECC_KEYExchange_Alice_Public_Ax_Result, PKA_ECC_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_B2, ECC_KEYExchange_Alice_Public_Ay_Result, PKA_ECC_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_A6, ECC_KEYExchange_a, PKA_ECC_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D7, ECC_KEYExchange_Bob_Private_k, PKA_ECC_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D0, ECC_KEYExchange_p, PKA_ECC_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D1, ECC_KEYExchange_p_, PKA_ECC_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D3, ECC_KEYExchange_r2_mod_p, PKA_ECC_WORDS);

        Check("Bob: shared secret operation completed",
              (Pka_Run(TEST_EP_PMULT, PKA_BASE_RADIX_256) == HAL_OK) ? 1U : 0U);

        (void)Pka_Read(PKA_ECC_ADDR_256_A2, ECC_KEYExchange_Bob_ShareKey_Sx_Result, PKA_ECC_WORDS);
        (void)Pka_Read(PKA_ECC_ADDR_256_B2, ECC_KEYExchange_Bob_ShareKey_Sy_Result, PKA_ECC_WORDS);

        Check("Bob shared Sx matches the expected vector",
              Pka_Compare(ECC_KEYExchange_Bob_ShareKey_Sx_Result,
                          ECC_KEYExchange_ShareKey_Sx_Expect, PKA_ECC_WORDS));
        Pka_Report("Bob shared Sx", ECC_KEYExchange_Bob_ShareKey_Sx_Result,
                   ECC_KEYExchange_ShareKey_Sx_Expect, PKA_ECC_WORDS);
        Check("Bob shared Sy matches the expected vector",
              Pka_Compare(ECC_KEYExchange_Bob_ShareKey_Sy_Result,
                          ECC_KEYExchange_ShareKey_Sy_Expect, PKA_ECC_WORDS));
        Pka_Report("Bob shared Sy", ECC_KEYExchange_Bob_ShareKey_Sy_Result,
                   ECC_KEYExchange_ShareKey_Sy_Expect, PKA_ECC_WORDS);

        /* ------------------------------------------------------- summary --- */
        printf("\r\nchecks = %u | summary : failures = %u\r\n",
               PRINT_U32(checks), PRINT_U32(failures));

        delay_ms(TEST_POLL_MS);
    }
}

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Report a section title.
 * @param  name: section name.
 * @retval None
 */
static void Section(const char *name)
{
    printf("\r\n-- %s --\r\n", name);
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    checks++;

    if (condition == 0U)
    {
        failures++;
    }
    printf("%-56s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Load the PKA micro-code image through the HAL API.
 * @retval HAL status of HAL_PKA_LoadFirmware().
 */
static HAL_StatusTypeDef Pka_LoadFirmware(void)
{
    return HAL_PKA_LoadFirmware(&hpka_dev, pka_fw_addr, pka_fw_data, PKA_FW_LENGTH);
}

/**
 * @brief  Clear the whole operand window through the HAL API.
 * @retval HAL status of HAL_PKA_WriteData().
 */
static HAL_StatusTypeDef Pka_ClearMemory(void)
{
    return HAL_PKA_WriteData(&hpka_dev, PKA_OPERAND_WINDOW_FIRST, pka_zero,
                             PKA_OPERAND_WINDOW_WORDS_MAX);
}

/**
 * @brief  Write one operand through the HAL API.
 * @param  address: absolute operand address (PKA_ECC_ADDR_* / PKA_RSA_ADDR_*).
 * @param  data: source words.
 * @param  words: number of 32-bit words (one 8-word group per 256 bits).
 * @retval HAL status of HAL_PKA_WriteData().
 * @note   The HAL API takes a byte offset from the instance base, while the
 *         address macros of the device header are absolute addresses, so the
 *         base is subtracted here.  The data cache is cleaned afterwards, so
 *         the accelerator observes the values that were just written.
 */
static HAL_StatusTypeDef Pka_Write(uint32 address, const uint32 *data, uint32 words)
{
    HAL_StatusTypeDef status;

    status = HAL_PKA_WriteData(&hpka_dev, address - PKA_BASE, data, words);
    CLEAR_CACHE();

    return status;
}

/**
 * @brief  Read one operand through the HAL API.
 * @param  address: absolute operand address (PKA_ECC_ADDR_* / PKA_RSA_ADDR_*).
 * @param  data: destination words.
 * @param  words: number of 32-bit words to read.
 * @retval HAL status of HAL_PKA_ReadData().
 * @note   The cache is cleaned before the read so the result that the
 *         accelerator wrote is fetched from the operand memory.
 */
static HAL_StatusTypeDef Pka_Read(uint32 address, uint32 *data, uint32 words)
{
    HAL_StatusTypeDef status;

    CLEAR_CACHE();
    status = HAL_PKA_ReadData(&hpka_dev, address - PKA_BASE, data, words);

    return status;
}

/**
 * @brief  Run one micro-code operation.
 * @param  entry: program entry point (word index of the micro-code region).
 * @param  radix: base radix encoding of the operation.
 * @retval HAL_OK when the operation completed, HAL_TIMEOUT when DONE never
 *         came within the guard, otherwise the status of the HAL call that
 *         failed.
 * @note   Sequence of the reference material, expressed with HAL calls only:
 *         clear the stack, set the entry point, start by writing CTRL.GO,
 *         poll STAT.DONE, stop by clearing CTRL.GO and acknowledge DONE.
 *         The GO bit is carried by the Init structure, so the start and the
 *         stop are two HAL_PKA_Init() calls.
 */
static HAL_StatusTypeDef Pka_Run(uint32 entry, uint32 radix)
{
    PKA_InitTypeDef   cfg;
    HAL_StatusTypeDef status;
    uint32            guard;

    (void)HAL_PKA_ClearStack(&hpka_dev);
    (void)HAL_PKA_SetEntryPoint(&hpka_dev, entry);

    /* Start: PKA_Go = PKA_GO_EN in the configuration structure */
    HAL_PKA_StructInit(&cfg);
    cfg.PKA_PartialRadix = TEST_PARTIAL_RADIX;
    cfg.PKA_BaseRadix    = radix;
    cfg.PKA_Go           = PKA_GO_EN;

    status = HAL_PKA_Init(&hpka_dev, &cfg);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Wait for the completion flag (bounded, so a failure cannot hang) */
    guard = TEST_WAIT_GUARD;
    while ((HAL_PKA_GetStatStatus(&hpka_dev, PKA_STATE_DONE) == RESET) && (guard != 0U))
    {
        guard--;
    }
    if (guard == 0U)
    {
        return HAL_TIMEOUT;
    }
    CLEAR_CACHE();

    /* The operand window is locked while the accelerator executes, so wait
       for the idle flag before the next register access */
    guard = TEST_WAIT_GUARD;
    while (((READ_REG(hpka_dev.Instance->RTN_CODE) & PKA_RTN_CODE_BUSY_Msk) != 0U) &&
           (guard != 0U))
    {
        guard--;
    }

    /* Stop: PKA_Go = PKA_GO_DIS */
    HAL_PKA_StructInit(&cfg);
    cfg.PKA_PartialRadix = TEST_PARTIAL_RADIX;
    cfg.PKA_BaseRadix    = radix;
    cfg.PKA_Go           = PKA_GO_DIS;
    (void)HAL_PKA_Init(&hpka_dev, &cfg);

    /* Acknowledge the completion so the next operation starts clean */
    HAL_PKA_ClearStatus(&hpka_dev, PKA_STATE_DONE);

    return HAL_OK;
}

/**
 * @brief  Compare a result vector against its expectation.
 * @param  result: measured words.
 * @param  expect: expected words.
 * @param  words: number of 32-bit words to compare.
 * @retval 1 when every word matches, 0 otherwise.
 */
static uint32 Pka_Compare(const uint32 *result, const uint32 *expect, uint32 words)
{
    uint32 i;

    for (i = 0U; i < words; i++)
    {
        if (result[i] != expect[i])
        {
            return 0U;
        }
    }

    return 1U;
}

/**
 * @brief  Print one result word group next to the expectation when they differ.
 * @param  name: label of the group.
 * @param  result: measured words.
 * @param  expect: expected words.
 * @param  words: number of words.
 * @retval None
 * @note   Only the first mismatching word of a failed comparison is printed,
 *         which keeps the report readable and still locates the problem.
 */
static void Pka_Report(const char *name, const uint32 *result, const uint32 *expect,
                       uint32 words)
{
    uint32 i;

    for (i = 0U; i < words; i++)
    {
        if (result[i] != expect[i])
        {
            printf("%-56s word[%u] = 0x%08X, expected 0x%08X\r\n", name, PRINT_U32(i),
                   PRINT_U32(result[i]), PRINT_U32(expect[i]));
            return;
        }
    }
}

/**
 * @brief  PKA low level initialization: instance clock gate and reset release.
 * @param  hpka: PKA handle.
 * @retval None
 * @note   The PKA is clocked by the AXILite4-Bus1 (DSE) domain, gated by the
 *         SMU, so the low level callback enables that gate and releases the
 *         reset of the domain, exactly as the reference example does with its
 *         DSE clock / reset sequence.
 */
void HAL_PKA_MspInit(HAL_PKA_HandleTypeDef *hpka)
{
    if (hpka == NULL_PTR)
    {
        return;
    }

    __HAL_SMU_DSE_CLK_ENABLE();
    __HAL_SMU_DSE_FORCE_RESET();
    __HAL_SMU_DSE_RELEASE_RESET();
}

/**
 * @brief  Configure the system clock and the bus gates.
 * @retval None
 * @note   Same clock tree as the other HAL integration suites: the PLL is fed
 *         by the external oscillator (VCO 180 MHz) and the buses run at
 *         AXI4Bus3 / 2, APBBus0 / 2, APBBus1 / 2 and CANX2 / 8, which keeps
 *         the console USART on its usual 22.5 MHz.
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    smu_osc;
    SMU_ClockInitTypeDef  smu_clock;
    SMU_ClocksTypeDef     smu_clocks;
    HAL_PMU_HandleTypeDef hpmu;

    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Raise the core rail trim before the PLL is switched, as the other HAL
       integration suites do: the 1.2 V LDO APIs are gated on the handle state,
       so the PMU must be initialized first */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    __HAL_CLEAR_STRUCT(&smu_osc);
    smu_osc.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    smu_osc.FIRCState            = SMU_FIRC_ON;
    smu_osc.FIRCCalibrationValue = 0x00U;
    smu_osc.PLL.PLLState         = SMU_PLL_ON;
    smu_osc.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    smu_osc.PLL.PLLDivR          = 0x04U;
    smu_osc.PLL.PLLDivQ          = 0x01U;
    smu_osc.PLL.PLLDivN          = 0x14U;
    smu_osc.PLL.PLLDivF          = 0xB4U;
    smu_osc.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    (void)HAL_SMU_OscConfig(&hsmu_clk, &smu_osc, SMU_TIMEOUT_DEFAULT);

    /* Bus dividers */
    __HAL_CLEAR_STRUCT(&smu_clock);
    smu_clock.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    smu_clock.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    smu_clock.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    smu_clock.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &smu_clock);

    (void)HAL_SMU_GetClocksFreq(&smu_clocks);
}

/*****END OF FILE*****/
