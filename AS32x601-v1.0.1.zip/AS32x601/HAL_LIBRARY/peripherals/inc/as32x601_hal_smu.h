/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_smu.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.8
 * Date:   2026/10/09
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/13     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/07     1.1     add the Size / Version
 *                                                       metafields and the
 *                                                       Reserved arrays to the
 *                                                       SMU_ClockInitTypeDef /
 *                                                       SMU_PLLConfigTypeDef /
 *                                                       SMU_OscInitTypeDef
 *                                                       structures (Version+Size
 *                                                       compatibility mechanism,
 *                                                       architecture spec
 *                                                       section 22); add the
 *                                                       SMU_*_INIT_V1 /
 *                                                       SMU_*_INIT_VERSION macros
 *     ANSILIC APPLICATION GROUP  2026/09/15     1.2     document the source
 *                                                       protection rules of
 *                                                       HAL_SMU_OscConfig /
 *                                                       HAL_SMU_ClockConfig in
 *                                                       the function comments
 *                                                       (matching the .c V1.4):
 *                                                       an FIRC power-down request
 *                                                       is ignored while the FIRC
 *                                                       clocks the system, and the
 *                                                       PLL is only selected when
 *                                                       it was actually programmed
 *     ANSILIC APPLICATION GROUP  2026/09/16     1.3     move the system clock
 *                                                       source selection into
 *                                                       HAL_SMU_OscConfig (the
 *                                                       SYSCLKSelect field is moved
 *                                                       from SMU_ClockInitTypeDef to
 *                                                       SMU_OscInitTypeDef so that
 *                                                       it is defined only once);
 *                                                       HAL_SMU_ClockConfig only
 *                                                       programs the bus dividers;
 *                                                       add the handle structure
 *                                                       (lock / state / error code)
 *                                                       and make all the public
 *                                                       functions handle based
 *                                                       (RTOS support); drive the
 *                                                       FIRC power state from
 *                                                       FIRCState alone
 *     ANSILIC APPLICATION GROUP  2026/09/16     1.4     classify the module as
 *                                                       Medium (the clock
 *                                                       configuration waits
 *                                                       for the oscillator /
 *                                                       PLL): add a Timeout
 *                                                       parameter to the
 *                                                       blocking functions, use
 *                                                       HAL_GetTick() for the
 *                                                       waits and HAL_RTOS_Yield()
 *                                                       in the polling loops,
 *                                                       add the HAL_SMU_STATE_TIMEOUT
 *                                                       state and the ARCH-CONST-09
 *                                                       state gate, give the lock
 *                                                       an acquisition Timeout,
 *                                                       store the applied
 *                                                       configuration in the
 *                                                       handle (Init / ClockInit)
 *     ANSILIC APPLICATION GROUP  2026/09/16     1.5     document the lock
 *                                                       order of
 *                                                       HAL_SMU_DeInit: the
 *                                                       low level
 *                                                       de-initialization
 *                                                       callback runs after
 *                                                       the handle lock is
 *                                                       released (LOCK-06),
 *                                                       so a MspDeInit
 *                                                       override may call
 *                                                       other HAL APIs
 *     ANSILIC APPLICATION GROUP  2026/09/17     1.6     change the NewState parameter of
                                                         HAL_SMU_SetSRAMLowPower / HAL_SMU_DCLSCmd /
                                                         HAL_SMU_ECCCmd / HAL_SMU_BUSTimeOutCmd from
                                                         uint32 to FunctionalState (ENABLE / DISABLE, as
                                                         in the other drivers of the library) and drop
                                                         the local IS_SMU_NEWSTATE macro (the
                                                         functional state check is now
                                                         IS_FUNCTIONAL_STATE from as32x601_hal_def.h)
 *     ANSILIC APPLICATION GROUP  2026/10/08     1.7     merge the capabilities of the
 *                                                       System Management release of
 *                                                       2026/09/29 into this driver:
 *                                                       add HAL_SMU_GetBusState()
 *                                                       (AXI bus state) and
 *                                                       HAL_SMU_GetWorkMode() (start-up
 *                                                       mode) as read only queries
 *                                                       without handle (SMU-REQ-041),
 *                                                       add HAL_SMU_TIMBreakCmd() to
 *                                                       enable / disable the brake
 *                                                       output of individual high
 *                                                       timers (the existing
 *                                                       HAL_SMU_TimerBreak() selects
 *                                                       the whole field) with the
 *                                                       IS_SMU_TIMBREAK_MASK macro,
 *                                                       add the
 *                                                       HAL_SMU_WorkModeTypeDef
 *                                                       enumeration, and rename the
 *                                                       I2Cx clock / reset macros
 *                                                       to IICx so that they match
 *                                                       the SMU_APBxCFGR_IICyEN
 *                                                       register fields. The
 *                                                       delivery-release I2Cx names
 *                                                       are kept as aliases of the
 *                                                       IICx macros, so that the
 *                                                       macro surface of the earlier
 *                                                       release keeps compiling. The
 *                                                       ADC2 clock / reset macros of
 *                                                       that release are dropped and
 *                                                       not aliased: the ALB2CFGR
 *                                                       bit6 / bit7 pair they
 *                                                       reference is not defined by
 *                                                       the device header (reserved
 *                                                       bits, no ADC2 on the device),
 *                                                       so they never compiled
 *     ANSILIC APPLICATION GROUP  2026/10/09     1.8     document the division of labour between
 *                                                       HAL_SMU_GetWorkMode() and the
 *                                                       SMU_FLAG_*START status bits of
 *                                                       HAL_SMU_GetFlagStatus(), and annotate the
 *                                                       source of the ten PLL domain constants
 *                                                       (they come from the vendor release and
 *                                                       are still to be confirmed against the
 *                                                       chip manual)
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the System Management Unit
 *                  (SMU), following the structure of a conventional clock-controller HAL driver:
 *                  - Initialization and de-initialization (oscillator / PLL
 *                    configuration, system clock tree configuration);
 *                  - Peripheral control (system / bus clock frequency
 *                    retrieval, oscillator and clock configuration read-back,
 *                    status flags, clock output);
 *                  - Bus peripheral clock enable / disable and reset /
 *                    release macros (all AXI / AXI-Lite / APB peripherals).
 *
 *                  Typical usage of the SMU:
 *                  (#) Clear the handle (__HAL_CLEAR_STRUCT), set its Instance
 *                      to SMU and call HAL_SMU_Init();
 *                  (#) Fill the SMU_OscInitTypeDef (oscillators, PLL and the
 *                      system clock source), then call HAL_SMU_OscConfig()
 *                      with the handle and a Timeout: the oscillators and the
 *                      PLL are programmed, the selected clock source is
 *                      waited for and the system clock is switched to it;
 *                  (#) Call HAL_SMU_ClockConfig() with the handle to program
 *                      the AXI / APB / CAN bus dividers;
 *                  (#) Query the clock tree with HAL_SMU_GetSysClockFreq() /
 *                      HAL_SMU_GetPCLK0Freq() / HAL_SMU_GetClocksFreq();
 *                  (#) Query and configure the monitoring / low power
 *                      features with HAL_SMU_GetFlagStatus() /
 *                      HAL_SMU_MCOConfig() / HAL_SMU_SetSRAMLowPower() /
 *                      HAL_SMU_BUSTimeOutCmd().
 * @complexity  Medium
 *              Clock / oscillator / PLL configuration + macros and one handle
 *              (lock / state / error code). The configuration functions are
 *              blocking: they wait for the FIRC to start up and for the PLL to
 *              lock, bounded by a caller supplied Timeout. No interrupt and no
 *              DMA.
 */
#ifndef __AS32X601_HAL_SMU_H
#define __AS32X601_HAL_SMU_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "as32x601_hal_def.h"       /* HAL common types and utilities          */
#include "as32x601.h"               /* SMU_TypeDef, SMU register bits          */

/**
 * @brief SMU HAL driver module version.
 * @note  0x0100U = V1.0. Bumped only on breaking API changes (architecture
 *        spec COMPAT-13/14/15).
 */
#define __HAL_SMU_MODULE_VERSION  0x0100U

/* Exported types ------------------------------------------------------------*/

/** @defgroup SMU_Exported_Types SMU Exported Types
  * @{
  */

/**
 * @brief SMU bus clock configuration structures definition.
 * @note  The fields of SMU_ClockInitTypeDef reflect the bus clock divider
 *        fields of the SMU_BUSCFGR register (AXI4BUS3DIV / APBBUS0DIV /
 *        APBBUS1DIV / CANX2DIV).
 * @note  The system clock source selection (SMU_BUSCFGR.SYSSEL) is part of
 *        SMU_OscInitTypeDef and is programmed by HAL_SMU_OscConfig(), so that
 *        the selection is defined in a single place and a clock source is
 *        always configured before it is selected.
 * @note  This structure follows the Version+Size compatibility mechanism
 *        (architecture spec section 22): the user must clear the structure
 *        (__HAL_CLEAR_STRUCT / memset), set the Size and Version metafields
 *        before filling the business fields.
 */
typedef struct
{
    uint32 Size;          /*!< sizeof(SMU_ClockInitTypeDef), must be set by the user
                               after clearing the structure              */
    uint32 Version;       /*!< Structure semantic version: @ref SMU_CLOCK_INIT_VERSION
                               (SMU_CLOCK_INIT_V1 = 0x0100U)            */
    uint32 AXI4Bus3CLKDiv;    /*!< AXI4Bus3 clock divider: SMU_AXI4BUS3CLK_DIVx  */
    uint32 APBBus0CLKDiv;     /*!< APBBus0 clock divider: SMU_APBBUS0CLK_DIVx    */
    uint32 APBBus1CLKDiv;     /*!< APBBus1 clock divider: SMU_APBBUS1CLK_DIVx    */
    uint32 CANX2CLKDiv;       /*!< CANCLKx2 clock divider: SMU_CANX2CLK_DIVx     */
    uint32 Reserved[2];       /*!< Reserved for future extension (must be 0) */
} SMU_ClockInitTypeDef;

/**
 * @brief SMU PLL configuration structure definition.
 * @note  The fields map the SMU_PLLCFGR register (PLLN / PLLF / PLLQ / PLLR)
 *        and the SMU_BUSCFGR.PLLSEL bit (clock source of the PLL).
 *        PLL output frequencies: FCLK_VCO = FCLKIN x PLLDivF / PLLDivN,
 *        FCLK_Q = FCLK_VCO / PLLDivQ, FCLK_R = FCLK_VCO / PLLDivR.
 * @note  This structure follows the Version+Size compatibility mechanism
 *        (architecture spec section 22): the user must clear the structure
 *        (__HAL_CLEAR_STRUCT / memset), set the Size and Version metafields
 *        before filling the business fields.
 */
typedef struct
{
    uint32 Size;          /*!< sizeof(SMU_PLLConfigTypeDef), must be set by the user
                               after clearing the structure              */
    uint32 Version;       /*!< Structure semantic version: @ref SMU_PLL_INIT_VERSION
                               (SMU_PLL_INIT_V1 = 0x0100U)              */
    uint32 PLLState;          /*!< PLL state: SMU_PLL_NONE / SMU_PLL_OFF / SMU_PLL_ON */
    uint32 PLLSource;         /*!< PLL clock source: SMU_PLLSOURCE_FIRC / SMU_PLLSOURCE_OSC */
    uint32 PLLDivR;           /*!< CLK_R output divider: 1 to 7                        */
    uint32 PLLDivQ;           /*!< CLK_Q output divider: 1 to 15                       */
    uint32 PLLDivN;           /*!< Input frequency divider: 1 to 63                   */
    uint32 PLLDivF;           /*!< Feedback frequency multiplier: 50 to 511           */
    uint32 Reserved[2];       /*!< Reserved for future extension (must be 0) */
} SMU_PLLConfigTypeDef;

/**
 * @brief SMU oscillator, PLL and system clock configuration structure definition.
 * @note  The FIRC calibration value is a 6-bit field (0x00 to 0x3F).
 * @note  The FIRC (calibration value and power state) is configured only when
 *        OscillatorType contains SMU_OSCILLATORTYPE_FIRC; the OSC needs no
 *        software configuration (hardware managed), its bit in
 *        OscillatorType is declarative.
 * @note  SYSCLKSelect is the system clock source that the device runs on
 *        after HAL_SMU_OscConfig() returns, i.e. it is applied by
 *        HAL_SMU_OscConfig() and NOT by HAL_SMU_ClockConfig() (which only
 *        programs the bus dividers).
 * @note  This structure follows the Version+Size compatibility mechanism
 *        (architecture spec section 22): the user must clear the structure
 *        (__HAL_CLEAR_STRUCT / memset), set the Size and Version metafields
 *        before filling the business fields.
 */
typedef struct
{
    uint32                  Size;   /*!< sizeof(SMU_OscInitTypeDef), must be set by the user after
                                    clearing the structure */
    uint32                  Version;   /*!< Structure semantic version: @ref SMU_OSC_INIT_VERSION
                                       (SMU_OSC_INIT_V1 = 0x0100U) */
    uint32                  OscillatorType;       /*!< SMU_OSCILLATORTYPE_xxx: FIRC and/or OSC */
    uint32                  FIRCState;            /*!< FIRC state: SMU_FIRC_OFF / SMU_FIRC_ON  */
    uint32                  FIRCCalibrationValue; /*!< FIRC frequency adjustment (0x00-0x3F)    */
    SMU_PLLConfigTypeDef      PLL;                  /*!< PLL configuration structure              */
    uint32                  SYSCLKSelect;          /*!< System clock source: SMU_SYSCLKSOURCE_xxx */
    uint32                  Reserved[1];          /*!< Reserved for future extension (must be 0) */
} SMU_OscInitTypeDef;

/**
 * @brief SMU configuration structure version macros.
 * @note  SMU_*_INIT_V1 is the current version. Future versions (e.g. V2 with
 *        new fields) must be appended after the existing fields without
 *        changing the layout (architecture spec section 22.5).
 */
#define SMU_CLOCK_INIT_V1  0x0100U   /*!< SMU_ClockInitTypeDef version V1.0 */
#define SMU_CLOCK_INIT_VERSION  SMU_CLOCK_INIT_V1   /*!< Current version */
#define SMU_PLL_INIT_V1    0x0100U   /*!< SMU_PLLConfigTypeDef version V1.0 */
#define SMU_PLL_INIT_VERSION  SMU_PLL_INIT_V1       /*!< Current version */
#define SMU_OSC_INIT_V1    0x0100U   /*!< SMU_OscInitTypeDef version V1.0 */
#define SMU_OSC_INIT_VERSION  SMU_OSC_INIT_V1       /*!< Current version */

/**
 * @brief HAL SMU state enumeration definition.
 */
typedef enum
{
    HAL_SMU_STATE_RESET = 0x00U,   /*!< SMU not initialized yet (or de-initialized) */
    HAL_SMU_STATE_READY = 0x01U,   /*!< SMU initialized and ready                    */
    HAL_SMU_STATE_BUSY  = 0x02U,   /*!< A clock configuration is ongoing             */
    HAL_SMU_STATE_ERROR = 0x03U,   /*!< SMU error state (recoverable)                */
    HAL_SMU_STATE_TIMEOUT = 0x04U  /*!< SMU operation timed out (recoverable)        */
} HAL_SMU_StateTypeDef;

/**
 * @brief HAL SMU start-up mode enumeration definition.
 * @note  The value is the MCUSM[1:0] field of the SMU status register, i.e. the
 *        same information that the SMU_FLAG_PWNSTART / SMU_FLAG_DSSTART /
 *        SMU_FLAG_SLEEPSTART status flags report bit by bit, in value form.
 */
typedef enum
{
    HAL_SMU_WORKMODE_POWER_ON   = 0x00U,   /*!< Power-on start-up           */
    HAL_SMU_WORKMODE_DEEP_SLEEP = 0x01U,   /*!< Deep sleep wake-up start-up */
    HAL_SMU_WORKMODE_SLEEP      = 0x02U    /*!< Sleep wake-up start-up      */
} HAL_SMU_WorkModeTypeDef;

/**
 * @brief SMU handle structure definition.
 * @note  The handle carries the synchronization state of the driver (lock /
 *        state / error code) and the last clock tree configuration applied
 *        through the handle. The SMU is a single instance clock / reset
 *        controller, so the configuration is passed to the configuration
 *        functions as SMU_OscInitTypeDef / SMU_ClockInitTypeDef parameters and
 *        kept in the handle for read-back.
 * @note  The handle must be cleared (__HAL_CLEAR_STRUCT) and its Instance set
 *        to SMU before the first HAL_SMU_Init() call (ARCH-CONST-16).
 */
typedef struct __HAL_SMU_HandleTypeDef
{
    SMU_TypeDef               *Instance;      /*!< SMU registers base address                  */
    SMU_OscInitTypeDef         Init;          /*!< Last oscillator / PLL / system clock source
                                                   configuration applied by HAL_SMU_OscConfig() */
    HAL_LockTypeDef            Lock;          /*!< Locking object                              */
    __IO HAL_SMU_StateTypeDef  State;         /*!< SMU state                                   */
    __IO uint32                ErrorCode;     /*!< SMU error code                              */
    SMU_ClockInitTypeDef       ClockInit;     /*!< Last bus clock divider configuration applied
                                                   by HAL_SMU_ClockConfig()                    */
#if (USE_RTOS == 1)
    HAL_MutexTypeDef           LockMutex;     /*!< RTOS mutex handle (created by the user
                                                   porting layer, e.g. in HAL_SMU_MspInit)      */
#endif /* USE_RTOS */
} HAL_SMU_HandleTypeDef;

/**
 * @brief SMU clocks frequencies structure definition.
 */
typedef struct
{
    uint32 AXIBus0_Frequency;      /*!< AXIBus0 (core) clock frequency in Hz */
    uint32 AXIBus1_Frequency;      /*!< AXIBus1 clock frequency in Hz        */
    uint32 AXIBus2_Frequency;      /*!< AXIBus2 clock frequency in Hz        */
    uint32 AXIBus3_Frequency;      /*!< AXIBus3 clock frequency in Hz        */
    uint32 AXILite4Bus0_Frequency; /*!< AXILite4Bus0 clock frequency in Hz   */
    uint32 AXILite4Bus1_Frequency; /*!< AXILite4Bus1 clock frequency in Hz   */
    uint32 AXILite4Bus2_Frequency; /*!< AXILite4Bus2 clock frequency in Hz   */
    uint32 APBBus0_Frequency;      /*!< APBBus0 clock frequency in Hz        */
    uint32 APBBus1_Frequency;      /*!< APBBus1 clock frequency in Hz        */
    uint32 CANCLKx2_Frequency;     /*!< CANCLKx2 clock frequency in Hz       */
} SMU_ClocksTypeDef;

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @defgroup SMU_Exported_Constants SMU Exported Constants
  * @{
  */

/** @defgroup SMU_Error_Code SMU Error Code
  * @{
  */
#define HAL_SMU_ERROR_NONE          ((uint32)0x00000000U) /*!< No error                            */
#define HAL_SMU_ERROR_INVALID_PARAM ((uint32)0x00000001U) /*!< Invalid parameter                   */
#define HAL_SMU_ERROR_CLOCK_SOURCE  ((uint32)0x00000002U) /*!< Clock source protected by another
                                                               running source (or a clock source
                                                               that was never programmed)        */
#define HAL_SMU_ERROR_TIMEOUT       ((uint32)0x00000004U) /*!< Clock source ready timeout           */
/**
  * @}
  */

/** @defgroup SMU_Timeout_Value SMU Timeout Values
  * @note  Values suggested for the Timeout parameter of the blocking functions
  *        (HAL_SMU_OscConfig / HAL_SMU_DeInit). The Timeout is expressed in ms
  *        and applies to each hardware wait of the call.
  * @{
  */
#define SMU_TIMEOUT_OSC     ((uint32)100U)    /*!< FIRC / OSC start-up: a few microseconds in
                                                   practice, 100 ms is a safe bound          */
#define SMU_TIMEOUT_PLL     ((uint32)1000U)   /*!< PLL lock: 1000 ms covers the PLL start-up
                                                   and lock comfortably                      */
#define SMU_TIMEOUT_DEFAULT SMU_TIMEOUT_PLL   /*!< Default Timeout for a full clock tree
                                                   configuration                              */
/**
  * @}
  */

/** @defgroup SMU_Oscillator_Type Oscillator Type
  * @{
  */
#define SMU_OSCILLATORTYPE_NONE   0x00000000U   /*!< No oscillator configuration requested  */
#define SMU_OSCILLATORTYPE_FIRC   0x00000001U   /*!< Fast internal RC oscillator (16 MHz)   */
#define SMU_OSCILLATORTYPE_OSC    0x00000002U   /*!< External crystal oscillator (20 MHz)   */
/**
  * @}
  */

/** @defgroup SMU_FIRC_State FIRC State
  * @{
  */
#define SMU_FIRC_OFF  0x00000000U               /*!< FIRC powered down                      */
#define SMU_FIRC_ON   0x00000001U               /*!< FIRC powered on                        */
/**
  * @}
  */

/** @defgroup SMU_PLL_State PLL State
  * @{
  */
#define SMU_PLL_NONE  0x00000000U               /*!< PLL configuration not requested        */
#define SMU_PLL_OFF   0x00000001U               /*!< PLL disabled                           */
#define SMU_PLL_ON    0x00000002U               /*!< PLL enabled                            */
/**
  * @}
  */

/** @defgroup SMU_PLL_Source PLL Source
  * @{
  */
#define SMU_PLLSOURCE_FIRC  0x00000000U         /*!< FIRC selected as PLL clock source      */
#define SMU_PLLSOURCE_OSC   0x00000001U         /*!< OSC selected as PLL clock source       */
/**
  * @}
  */

/** @defgroup SMU_SYSCLK_Source System Clock Source
  * @note  Values are the SMU_BUSCFGR.SYSSEL field encodings.
  * @{
  */
#define SMU_SYSCLKSOURCE_FIRC  0x00000000U      /*!< FIRC used as system clock source       */
#define SMU_SYSCLKSOURCE_PLL   0x00000001U      /*!< PLL used as system clock source        */
#define SMU_SYSCLKSOURCE_OSC   0x00000002U      /*!< OSC used as system clock source        */
/**
  * @}
  */

/** @defgroup SMU_AXI4Bus3_Clock_Divider AXI4Bus3 Clock Divider
  * @note  Values are the SMU_BUSCFGR.AXI4BUS3DIV field encodings.
  * @{
  */
#define SMU_AXI4BUS3CLK_DIV1  0x00000001U       /*!< AXI4Bus3 clock = AXI4Bus1 clock / 1    */
#define SMU_AXI4BUS3CLK_DIV2  0x00000002U       /*!< AXI4Bus3 clock = AXI4Bus1 clock / 2    */
/**
  * @}
  */

/** @defgroup SMU_APBBus0_Clock_Divider APBBus0 Clock Divider
  * @note  Values are the SMU_BUSCFGR.APBBUS0DIV field encodings.
  * @{
  */
#define SMU_APBBUS0CLK_DIV1  0x00000001U        /*!< APBBus0 clock = AXI4Bus3 clock / 1     */
#define SMU_APBBUS0CLK_DIV2  0x00000002U        /*!< APBBus0 clock = AXI4Bus3 clock / 2     */
#define SMU_APBBUS0CLK_DIV4  0x00000004U        /*!< APBBus0 clock = AXI4Bus3 clock / 4     */
#define SMU_APBBUS0CLK_DIV8  0x00000008U        /*!< APBBus0 clock = AXI4Bus3 clock / 8     */
/**
  * @}
  */

/** @defgroup SMU_APBBus1_Clock_Divider APBBus1 Clock Divider
  * @note  Values are the SMU_BUSCFGR.APBBUS1DIV field encodings.
  * @{
  */
#define SMU_APBBUS1CLK_DIV1  0x00000001U        /*!< APBBus1 clock = AXI4Bus3 clock / 1     */
#define SMU_APBBUS1CLK_DIV2  0x00000002U        /*!< APBBus1 clock = AXI4Bus3 clock / 2     */
#define SMU_APBBUS1CLK_DIV4  0x00000004U        /*!< APBBus1 clock = AXI4Bus3 clock / 4     */
#define SMU_APBBUS1CLK_DIV8  0x00000008U        /*!< APBBus1 clock = AXI4Bus3 clock / 8     */
/**
  * @}
  */

/** @defgroup SMU_CANX2_Clock_Divider CANCLKx2 Clock Divider
  * @note  Values are the SMU_BUSCFGR.CANX2DIV field encodings.
  * @{
  */
#define SMU_CANX2CLK_DIV1  0x00000001U          /*!< CANCLKx2 clock = PLLR clock / 1        */
#define SMU_CANX2CLK_DIV2  0x00000002U          /*!< CANCLKx2 clock = PLLR clock / 2        */
#define SMU_CANX2CLK_DIV4  0x00000004U          /*!< CANCLKx2 clock = PLLR clock / 4        */
#define SMU_CANX2CLK_DIV8  0x00000008U          /*!< CANCLKx2 clock = PLLR clock / 8        */
/**
  * @}
  */

/** @defgroup SMU_Clock_Output_Mux System Clock Output Mux
  * @note  Values are the SMU_OTHCFGR.CLKOUTMUX field encodings.
  * @{
  */
#define SMU_CLKOUTMUX_CORECLK_DIV8    0x00000000U  /*!< CoreClk 8-division clock output  */
#define SMU_CLKOUTMUX_AXIBUS1_DIV8    0x00000001U  /*!< AxiBus1Clk 8-division output     */
#define SMU_CLKOUTMUX_AXIBUS3_DIV8    0x00000002U  /*!< AxiBus3Clk 8-division output     */
#define SMU_CLKOUTMUX_APBBUS0_DIV8    0x00000003U  /*!< ApbBus0Clk 8-division output     */
#define SMU_CLKOUTMUX_APBBUS1_DIV8    0x00000004U  /*!< ApbBus1Clk 8-division output     */
#define SMU_CLKOUTMUX_FIRC_DIV8       0x00000005U  /*!< FircClk 8-division output        */
#define SMU_CLKOUTMUX_OSC_DIV8        0x00000006U  /*!< Osc 8-division clock output      */
#define SMU_CLKOUTMUX_SIRC            0x00000007U  /*!< SircClk clock output             */
/**
  * @}
  */

/** @defgroup SMU_Timer_Break Timer Break Select
  * @note  Values are the SMU_OTHCFGR.TIMBKEN field encodings.
  * @{
  */
#define SMU_TIMBREAK_TIM0  0x00000001U          /*!< Timer 0 break output   */
#define SMU_TIMBREAK_TIM1  0x00000002U          /*!< Timer 1 break output   */
#define SMU_TIMBREAK_TIM2  0x00000004U          /*!< Timer 2 break output   */
#define SMU_TIMBREAK_TIM5  0x00000008U          /*!< Timer 5 break output   */
/**
  * @}
  */

/** @defgroup SMU_SRAM_Low_Power SRAM Low Power Select
  * @note  Values are the SMU_OTHCFGR.SRAMLPEN field encodings.
  * @{
  */
#define SMU_SRAMLOWPOWER_SRAM0  0x00000001U     /*!< SRAM0 low power enable bit */
#define SMU_SRAMLOWPOWER_SRAM1  0x00000002U     /*!< SRAM1 low power enable bit */
#define SMU_SRAMLOWPOWER_SRAM2  0x00000004U     /*!< SRAM2 low power enable bit */
#define SMU_SRAMLOWPOWER_SRAM3  0x00000008U     /*!< SRAM3 low power enable bit */
/**
  * @}
  */

/** @defgroup SMU_FLAG SMU Status Flags
  * @note  Flags are read from the SMU_SR register (read only).
  * @{
  */
#define SMU_FLAG_PLLLOCK    ((uint32)0x0001)  /*!< PLL clock lock flag                  */
#define SMU_FLAG_EFLASHICS  ((uint32)0x0002)  /*!< EFLASH initialization completion flag */
#define SMU_FLAG_PWNSTART   ((uint32)0x0000)  /*!< Power-on start state (MCUSM[1:0]=0b00).
                                                 *   The mask is 0 because this state is
                                                 *   "both MCUSM bits cleared"; it is detected
                                                 *   specially by HAL_SMU_GetFlagStatus().    */
#define SMU_FLAG_DSSTART    ((uint32)0x0004)  /*!< Deep sleep activation flag (MCUSM[1:0]=01) */
#define SMU_FLAG_SLEEPSTART ((uint32)0x0008)  /*!< Sleep start flag (MCUSM[1:0]=10)      */
#define SMU_FLAG_LPWR       ((uint32)0x0010)  /*!< Low power mode flag                   */
#define SMU_FLAG_AXI4Bus0   ((uint32)0x0020)  /*!< AXI4Bus0 bus status flag              */
#define SMU_FLAG_AXI4Bus1   ((uint32)0x0040)  /*!< AXI4Bus1 bus status flag              */
#define SMU_FLAG_AXI4Bus2   ((uint32)0x0080)  /*!< AXI4Bus2 bus status flag              */
#define SMU_FLAG_SRAM0RDY   ((uint32)0x0100)  /*!< SRAM0 readiness flag                  */
#define SMU_FLAG_SRAM1RDY   ((uint32)0x0200)  /*!< SRAM1 readiness flag                  */
#define SMU_FLAG_SRAM2RDY   ((uint32)0x0400)  /*!< SRAM2 readiness flag                  */
#define SMU_FLAG_SRAM3RDY   ((uint32)0x0800)  /*!< SRAM3 readiness flag                  */
/**
  * @}
  */

/** @defgroup SMU_BUS_Timeout Bus Timeout
  * @{
  */
#define SMU_BUSTIMEOUT_VALUE_MIN  30000U        /*!< Bus timeout counter minimum value     */
#define SMU_BUSTIMEOUT_VALUE_MAX  0xFFFFU       /*!< Bus timeout counter maximum value     */
/**
  * @}
  */

/**
  * @}
  */

/* Exported macros -----------------------------------------------------------*/

/** @defgroup SMU_Exported_Macros SMU Exported Macros
  * @{
  */

/** @defgroup SMU_FIRC_Control FIRC Control
  * @{
  */

/**
 * @brief  Power on the FIRC oscillator (clears the FIRCON bit).
 */
#define __HAL_SMU_FIRC_ENABLE()    (CLEAR_BIT(SMU->FIRCCFGR, SMU_FIRCCFGR_FIRCON))

/**
 * @brief  Power down the FIRC oscillator (sets the FIRCON bit).
 */
#define __HAL_SMU_FIRC_DISABLE()   (SET_BIT(SMU->FIRCCFGR, SMU_FIRCCFGR_FIRCON))

/**
 * @brief  Adjust the FIRC oscillator frequency.
 * @param  __VALUE__: 6-bit calibration value (0x00 to 0x3F).
 */
#define __HAL_SMU_FIRC_CALIBRATION_CONFIG(__VALUE__)                    \
                    (MODIFY_REG(SMU->FIRCCFGR, SMU_FIRCCFGR_FIRCTF,     \
                                ((uint32)(__VALUE__) << SMU_FIRCCFGR_FIRCTF_Pos)))

/**
 * @brief  Check whether the FIRC oscillator is ready.
 * @retval 1 if ready, 0 otherwise.
 */
#define __HAL_SMU_GET_FIRC_READY()  (HAL_IS_BIT_SET(SMU->FIRCCFGR, SMU_FIRCCFGR_FIRCRDY) ? 1U : 0U)
/**
  * @}
  */

/** @defgroup SMU_PLL_Control PLL Control
  * @{
  */

/**
 * @brief  Enable the PLL clock.
 */
#define __HAL_SMU_PLL_ENABLE()   (SET_BIT(SMU->PLLCFGR, SMU_PLLCFGR_PLLEN))

/**
 * @brief  Disable the PLL clock.
 */
#define __HAL_SMU_PLL_DISABLE()  (CLEAR_BIT(SMU->PLLCFGR, SMU_PLLCFGR_PLLEN))

/**
 * @brief  Enable the PLL frequency update (any configuration change is
 *         latched only when the PLLUF bit is set).
 */
#define __HAL_SMU_PLL_UPDATE_ENABLE()  (SET_BIT(SMU->PLLCFGR, SMU_PLLCFGR_PLLUF))

/**
 * @brief  Disable the PLL frequency update.
 */
#define __HAL_SMU_PLL_UPDATE_DISABLE() (CLEAR_BIT(SMU->PLLCFGR, SMU_PLLCFGR_PLLUF))

/**
 * @brief  Put the PLL into reset state (clear the PLLRST bit).
 * @note   The PLLRST bit is an active-low reset: 0 = PLL held in reset,
 *         1 = PLL running. Holding the PLL in reset after it has been
 *         disabled leaves it in its stopped state, as used by
 *         HAL_SMU_DeInit() and by HAL_SMU_OscConfig() with SMU_PLL_OFF.
 */
#define __HAL_SMU_PLL_RESET_ASSERT()   (CLEAR_BIT(SMU->PLLCFGR, SMU_PLLCFGR_PLLRST))

/**
 * @brief  Release the PLL reset (set the PLLRST bit) so that the PLL runs.
 * @note   The PLL is started by writing PLLEN | PLLRST | PLLUF in a single
 *         access (PLLRST = 1 releases the reset, PLLUF latches the configured
 *         N / F / Q / R values) before the PLL lock flag is polled; see
 *         HAL_SMU_OscConfig().
 */
#define __HAL_SMU_PLL_RESET_RELEASE()  (SET_BIT(SMU->PLLCFGR, SMU_PLLCFGR_PLLRST))
/**
  * @}
  */

/** @defgroup SMU_Clock_Config System Clock Configuration
  * @{
  */

/**
 * @brief  Configure the system clock source.
 * @param  __SOURCE__: SMU_SYSCLKSOURCE_FIRC / SMU_SYSCLKSOURCE_PLL / SMU_SYSCLKSOURCE_OSC.
 */
#define __HAL_SMU_SYSCLK_CONFIG(__SOURCE__)                              \
                    (MODIFY_REG(SMU->BUSCFGR, SMU_BUSCFGR_SYSSEL,       \
                                ((uint32)(__SOURCE__) << SMU_BUSCFGR_SYSSEL_Pos)))

/**
 * @brief  Get the system clock source.
 * @retval SMU_SYSCLKSOURCE_FIRC / SMU_SYSCLKSOURCE_PLL / SMU_SYSCLKSOURCE_OSC.
 */
#define __HAL_SMU_GET_SYSCLK_SOURCE()    (READ_BIT(SMU->BUSCFGR, SMU_BUSCFGR_SYSSEL) >> SMU_BUSCFGR_SYSSEL_Pos)

/**
 * @brief  Configure the PLL clock source.
 * @param  __SOURCE__: SMU_PLLSOURCE_FIRC / SMU_PLLSOURCE_OSC.
 */
#define __HAL_SMU_PLLSOURCE_CONFIG(__SOURCE__)                           \
                    (MODIFY_REG(SMU->BUSCFGR, SMU_BUSCFGR_PLLSEL,       \
                                ((uint32)(__SOURCE__) << SMU_BUSCFGR_PLLSEL_Pos)))

/**
 * @brief  Get the PLL clock source.
 * @retval SMU_PLLSOURCE_FIRC / SMU_PLLSOURCE_OSC.
 */
#define __HAL_SMU_GET_PLL_SOURCE()       (READ_BIT(SMU->BUSCFGR, SMU_BUSCFGR_PLLSEL) >> SMU_BUSCFGR_PLLSEL_Pos)
/**
  * @}
  */

/** @defgroup SMU_Flag_Management Flag Management
  * @{
  */

/**
 * @brief  Get the specified SMU status flag.
 * @param  __FLAG__: SMU_FLAG_PLLLOCK or other SMU_FLAG_xxx values.
 * @retval 1 if the flag is set, 0 otherwise.
 */
#define __HAL_SMU_GET_FLAG(__FLAG__)     (HAL_IS_BIT_SET(SMU->SR, (__FLAG__)) ? 1U : 0U)
/**
  * @}
  */

/** @defgroup SMU_Peripheral_Clock_Enable_Disable Peripheral Clock Enable / Disable
  * @note  Each enable macro uses a "set then read-back" sequence in the same
  *        way as a conventional HAL library, to work around the 2-cycle access
  *        delay of the AXI / APB clock gates after the clock is switched on.
  * @{
  */

/* ------------------------ AxiBus0 (AB0CFGR) ------------------------ */
#define __HAL_SMU_QSPI_CLK_ENABLE()       do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->AB0CFGR, SMU_AB0CFGR_QSPIEN);    tmpreg = READ_BIT(SMU->AB0CFGR, SMU_AB0CFGR_QSPIEN);    UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_QSPI_CLK_DISABLE()      (CLEAR_BIT(SMU->AB0CFGR, SMU_AB0CFGR_QSPIEN))
#define __HAL_SMU_EFLASH_CLK_ENABLE()     do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->AB0CFGR, SMU_AB0CFGR_EFLASHEN);  tmpreg = READ_BIT(SMU->AB0CFGR, SMU_AB0CFGR_EFLASHEN);  UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_EFLASH_CLK_DISABLE()    (CLEAR_BIT(SMU->AB0CFGR, SMU_AB0CFGR_EFLASHEN))
#define __HAL_SMU_QSPI_CLK_UPDATE_ENABLE()      do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->AB0CFGR, SMU_AB0CFGR_QSPIUEN);    tmpreg = READ_BIT(SMU->AB0CFGR, SMU_AB0CFGR_QSPIUEN);    UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_QSPI_CLK_UPDATE_DISABLE()     (CLEAR_BIT(SMU->AB0CFGR, SMU_AB0CFGR_QSPIUEN))
#define __HAL_SMU_EFLASH_CLK_UPDATE_ENABLE()    do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->AB0CFGR, SMU_AB0CFGR_EFLASHUEN);  tmpreg = READ_BIT(SMU->AB0CFGR, SMU_AB0CFGR_EFLASHUEN);  UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_EFLASH_CLK_UPDATE_DISABLE()   (CLEAR_BIT(SMU->AB0CFGR, SMU_AB0CFGR_EFLASHUEN))

/* ------------------------ AxiBus1 (AB1CFGR) ------------------------ */
#define __HAL_SMU_DMA0_CLK_ENABLE()       do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->AB1CFGR, SMU_AB1CFGR_DMA0EN);   tmpreg = READ_BIT(SMU->AB1CFGR, SMU_AB1CFGR_DMA0EN);   UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_DMA0_CLK_DISABLE()      (CLEAR_BIT(SMU->AB1CFGR, SMU_AB1CFGR_DMA0EN))
#define __HAL_SMU_DMA1_CLK_ENABLE()       do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->AB1CFGR, SMU_AB1CFGR_DMA1EN);   tmpreg = READ_BIT(SMU->AB1CFGR, SMU_AB1CFGR_DMA1EN);   UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_DMA1_CLK_DISABLE()      (CLEAR_BIT(SMU->AB1CFGR, SMU_AB1CFGR_DMA1EN))
#define __HAL_SMU_SRAM0_CLK_ENABLE()      do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->AB1CFGR, SMU_AB1CFGR_SRAM0EN);  tmpreg = READ_BIT(SMU->AB1CFGR, SMU_AB1CFGR_SRAM0EN);  UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_SRAM0_CLK_DISABLE()     (CLEAR_BIT(SMU->AB1CFGR, SMU_AB1CFGR_SRAM0EN))
#define __HAL_SMU_SRAM1_CLK_ENABLE()      do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->AB1CFGR, SMU_AB1CFGR_SRAM1EN);  tmpreg = READ_BIT(SMU->AB1CFGR, SMU_AB1CFGR_SRAM1EN);  UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_SRAM1_CLK_DISABLE()     (CLEAR_BIT(SMU->AB1CFGR, SMU_AB1CFGR_SRAM1EN))
#define __HAL_SMU_SRAM2_CLK_ENABLE()      do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->AB1CFGR, SMU_AB1CFGR_SRAM2EN);  tmpreg = READ_BIT(SMU->AB1CFGR, SMU_AB1CFGR_SRAM2EN);  UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_SRAM2_CLK_DISABLE()     (CLEAR_BIT(SMU->AB1CFGR, SMU_AB1CFGR_SRAM2EN))
#define __HAL_SMU_SRAM3_CLK_ENABLE()      do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->AB1CFGR, SMU_AB1CFGR_SRAM3EN);  tmpreg = READ_BIT(SMU->AB1CFGR, SMU_AB1CFGR_SRAM3EN);  UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_SRAM3_CLK_DISABLE()     (CLEAR_BIT(SMU->AB1CFGR, SMU_AB1CFGR_SRAM3EN))

/* ------------------------ AxiBus3 (AB3CFGR) ------------------------ */
#define __HAL_SMU_AXI4TOAPB0_CLK_ENABLE() do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->AB3CFGR, SMU_AB3CFGR_AXI4TOAPB0EN); tmpreg = READ_BIT(SMU->AB3CFGR, SMU_AB3CFGR_AXI4TOAPB0EN); UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_AXI4TOAPB0_CLK_DISABLE() (CLEAR_BIT(SMU->AB3CFGR, SMU_AB3CFGR_AXI4TOAPB0EN))
#define __HAL_SMU_AXI4TOAPB1_CLK_ENABLE() do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->AB3CFGR, SMU_AB3CFGR_AXI4TOAPB1EN); tmpreg = READ_BIT(SMU->AB3CFGR, SMU_AB3CFGR_AXI4TOAPB1EN); UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_AXI4TOAPB1_CLK_DISABLE() (CLEAR_BIT(SMU->AB3CFGR, SMU_AB3CFGR_AXI4TOAPB1EN))
#define __HAL_SMU_AXIBUS3_CLK_ENABLE()    do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->AB3CFGR, SMU_AB3CFGR_AXIBUS3EN);   tmpreg = READ_BIT(SMU->AB3CFGR, SMU_AB3CFGR_AXIBUS3EN);   UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_AXIBUS3_CLK_DISABLE()   (CLEAR_BIT(SMU->AB3CFGR, SMU_AB3CFGR_AXIBUS3EN))

/* ------------------------ AxiLiteBus0 (ALB0CFGR) ------------------------ */
#define __HAL_SMU_FCU_CLK_ENABLE()        do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_FCUEN);    tmpreg = READ_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_FCUEN);    UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_FCU_CLK_DISABLE()       (CLEAR_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_FCUEN))
#define __HAL_SMU_CMU0_CLK_ENABLE()       do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_CMU0EN);   tmpreg = READ_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_CMU0EN);   UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_CMU0_CLK_DISABLE()      (CLEAR_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_CMU0EN))
#define __HAL_SMU_CMU1_CLK_ENABLE()       do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_CMU1EN);   tmpreg = READ_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_CMU1EN);   UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_CMU1_CLK_DISABLE()      (CLEAR_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_CMU1EN))
#define __HAL_SMU_CMU2_CLK_ENABLE()       do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_CMU2EN);   tmpreg = READ_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_CMU2EN);   UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_CMU2_CLK_DISABLE()      (CLEAR_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_CMU2EN))
#define __HAL_SMU_CMU3_CLK_ENABLE()       do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_CMU3EN);   tmpreg = READ_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_CMU3EN);   UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_CMU3_CLK_DISABLE()      (CLEAR_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_CMU3EN))
#define __HAL_SMU_PLIC_CLK_ENABLE()       do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_PLICEN);   tmpreg = READ_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_PLICEN);   UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_PLIC_CLK_DISABLE()      (CLEAR_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_PLICEN))
#define __HAL_SMU_CLINT_CLK_ENABLE()      do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_CLINTEN);  tmpreg = READ_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_CLINTEN);  UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_CLINT_CLK_DISABLE()     (CLEAR_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_CLINTEN))

/* ------------------------ AxiLiteBus1 (ALB1CFGR) ------------------------ */
#define __HAL_SMU_HTIM0_CLK_ENABLE()      do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_HTIM0EN);      tmpreg = READ_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_HTIM0EN);      UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_HTIM0_CLK_DISABLE()     (CLEAR_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_HTIM0EN))
#define __HAL_SMU_CANFD0_CLK_ENABLE()     do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_CANFD0EN);     tmpreg = READ_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_CANFD0EN);     UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_CANFD0_CLK_DISABLE()    (CLEAR_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_CANFD0EN))
#define __HAL_SMU_CANFD1_CLK_ENABLE()     do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_CANFD1EN);     tmpreg = READ_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_CANFD1EN);     UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_CANFD1_CLK_DISABLE()    (CLEAR_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_CANFD1EN))
#define __HAL_SMU_ADC0_CLK_ENABLE()       do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_ADC0EN);       tmpreg = READ_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_ADC0EN);       UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_ADC0_CLK_DISABLE()      (CLEAR_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_ADC0EN))
#define __HAL_SMU_ADC1_CLK_ENABLE()       do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_ADC1EN);       tmpreg = READ_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_ADC1EN);       UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_ADC1_CLK_DISABLE()      (CLEAR_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_ADC1EN))
#define __HAL_SMU_DAC0_CLK_ENABLE()       do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_DAC0EN);       tmpreg = READ_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_DAC0EN);       UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_DAC0_CLK_DISABLE()      (CLEAR_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_DAC0EN))
#define __HAL_SMU_GPIOA_CLK_ENABLE()      do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_GPIOAEN);      tmpreg = READ_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_GPIOAEN);      UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_GPIOA_CLK_DISABLE()     (CLEAR_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_GPIOAEN))
#define __HAL_SMU_GPIOB_CLK_ENABLE()      do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_GPIOBEN);      tmpreg = READ_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_GPIOBEN);      UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_GPIOB_CLK_DISABLE()     (CLEAR_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_GPIOBEN))
#define __HAL_SMU_GPIOC_CLK_ENABLE()      do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_GPIOCEN);      tmpreg = READ_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_GPIOCEN);      UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_GPIOC_CLK_DISABLE()     (CLEAR_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_GPIOCEN))
#define __HAL_SMU_DSE_CLK_ENABLE()        do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_DSEEN);        tmpreg = READ_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_DSEEN);        UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_DSE_CLK_DISABLE()       (CLEAR_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_DSEEN))
#define __HAL_SMU_AXILITEBUS1_CLK_ENABLE() do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_AXILITEBUS1EN); tmpreg = READ_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_AXILITEBUS1EN); UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_AXILITEBUS1_CLK_DISABLE() (CLEAR_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_AXILITEBUS1EN))

/* ------------------------ AxiLiteBus2 (ALB2CFGR) ------------------------ */
#define __HAL_SMU_HTIM1_CLK_ENABLE()      do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_HTIM1EN);      tmpreg = READ_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_HTIM1EN);      UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_HTIM1_CLK_DISABLE()     (CLEAR_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_HTIM1EN))
#define __HAL_SMU_CANFD2_CLK_ENABLE()     do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_CANFD2EN);     tmpreg = READ_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_CANFD2EN);     UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_CANFD2_CLK_DISABLE()    (CLEAR_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_CANFD2EN))
#define __HAL_SMU_CANFD3_CLK_ENABLE()     do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_CANFD3EN);     tmpreg = READ_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_CANFD3EN);     UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_CANFD3_CLK_DISABLE()    (CLEAR_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_CANFD3EN))
/* No ADC2 clock macro. The delivery release declared __HAL_SMU_ADC2_CLK_ENABLE
 * and __HAL_SMU_ADC2_CLK_DISABLE, but they referenced the ALB2CFGR bit6 / bit7
 * pair, which the device header does not define at all (bits 6 and 7 are
 * skipped: the register jumps from CANFD3 at bit5 to DAC1 at bit8). Those bits
 * are reserved and the device has no ADC2 peripheral, so the two macros could
 * never compile and dropping them loses no usable functionality. */
#define __HAL_SMU_DAC1_CLK_ENABLE()       do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_DAC1EN);       tmpreg = READ_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_DAC1EN);       UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_DAC1_CLK_DISABLE()      (CLEAR_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_DAC1EN))
#define __HAL_SMU_GPIOD_CLK_ENABLE()      do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_GPIODEN);      tmpreg = READ_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_GPIODEN);      UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_GPIOD_CLK_DISABLE()     (CLEAR_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_GPIODEN))
#define __HAL_SMU_GPIOE_CLK_ENABLE()      do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_GPIOEEN);      tmpreg = READ_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_GPIOEEN);      UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_GPIOE_CLK_DISABLE()     (CLEAR_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_GPIOEEN))
#define __HAL_SMU_GPIOF_CLK_ENABLE()      do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_GPIOFEN);      tmpreg = READ_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_GPIOFEN);      UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_GPIOF_CLK_DISABLE()     (CLEAR_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_GPIOFEN))
#define __HAL_SMU_GPIOG_CLK_ENABLE()      do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_GPIOGEN);      tmpreg = READ_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_GPIOGEN);      UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_GPIOG_CLK_DISABLE()     (CLEAR_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_GPIOGEN))
#define __HAL_SMU_AXILITEBUS2_CLK_ENABLE() do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_AXILITEBUS2EN); tmpreg = READ_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_AXILITEBUS2EN); UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_AXILITEBUS2_CLK_DISABLE() (CLEAR_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_AXILITEBUS2EN))

/* ------------------------ ApbBus0 (APB0CFGR) ------------------------ */
#define __HAL_SMU_MAC_CLK_ENABLE()        do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_MACEN);      tmpreg = READ_BIT(SMU->APB0CFGR, SMU_APB0CFGR_MACEN);      UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_MAC_CLK_DISABLE()       (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_MACEN))
#define __HAL_SMU_SPI0_CLK_ENABLE()       do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_SPI0EN);     tmpreg = READ_BIT(SMU->APB0CFGR, SMU_APB0CFGR_SPI0EN);     UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_SPI0_CLK_DISABLE()      (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_SPI0EN))
#define __HAL_SMU_SPI1_CLK_ENABLE()       do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_SPI1EN);     tmpreg = READ_BIT(SMU->APB0CFGR, SMU_APB0CFGR_SPI1EN);     UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_SPI1_CLK_DISABLE()      (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_SPI1EN))
#define __HAL_SMU_SPI2_CLK_ENABLE()       do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_SPI2EN);     tmpreg = READ_BIT(SMU->APB0CFGR, SMU_APB0CFGR_SPI2EN);     UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_SPI2_CLK_DISABLE()      (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_SPI2EN))
#define __HAL_SMU_IIC0_CLK_ENABLE()       do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_IIC0EN);     tmpreg = READ_BIT(SMU->APB0CFGR, SMU_APB0CFGR_IIC0EN);     UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_IIC0_CLK_DISABLE()      (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_IIC0EN))
#define __HAL_SMU_IIC1_CLK_ENABLE()       do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_IIC1EN);     tmpreg = READ_BIT(SMU->APB0CFGR, SMU_APB0CFGR_IIC1EN);     UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_IIC1_CLK_DISABLE()      (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_IIC1EN))
/* I2Cx: delivery-release spelling of the two APB0 IIC clocks, retained so that
 * code written against the earlier release keeps compiling. */
#define __HAL_SMU_I2C0_CLK_ENABLE()       __HAL_SMU_IIC0_CLK_ENABLE()
#define __HAL_SMU_I2C0_CLK_DISABLE()      __HAL_SMU_IIC0_CLK_DISABLE()
#define __HAL_SMU_I2C1_CLK_ENABLE()       __HAL_SMU_IIC1_CLK_ENABLE()
#define __HAL_SMU_I2C1_CLK_DISABLE()      __HAL_SMU_IIC1_CLK_DISABLE()
#define __HAL_SMU_USART0_CLK_ENABLE()     do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_USART0EN);   tmpreg = READ_BIT(SMU->APB0CFGR, SMU_APB0CFGR_USART0EN);   UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_USART0_CLK_DISABLE()    (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_USART0EN))
#define __HAL_SMU_USART1_CLK_ENABLE()     do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_USART1EN);   tmpreg = READ_BIT(SMU->APB0CFGR, SMU_APB0CFGR_USART1EN);   UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_USART1_CLK_DISABLE()    (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_USART1EN))
#define __HAL_SMU_USART2_CLK_ENABLE()     do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_USART2EN);   tmpreg = READ_BIT(SMU->APB0CFGR, SMU_APB0CFGR_USART2EN);   UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_USART2_CLK_DISABLE()    (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_USART2EN))
#define __HAL_SMU_USART3_CLK_ENABLE()     do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_USART3EN);   tmpreg = READ_BIT(SMU->APB0CFGR, SMU_APB0CFGR_USART3EN);   UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_USART3_CLK_DISABLE()    (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_USART3EN))
#define __HAL_SMU_HTIM2_CLK_ENABLE()      do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_HTIM2EN);    tmpreg = READ_BIT(SMU->APB0CFGR, SMU_APB0CFGR_HTIM2EN);    UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_HTIM2_CLK_DISABLE()     (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_HTIM2EN))
#define __HAL_SMU_TIM3_CLK_ENABLE()       do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_TIM3EN);     tmpreg = READ_BIT(SMU->APB0CFGR, SMU_APB0CFGR_TIM3EN);     UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_TIM3_CLK_DISABLE()      (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_TIM3EN))
#define __HAL_SMU_TIM4_CLK_ENABLE()       do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_TIM4EN);     tmpreg = READ_BIT(SMU->APB0CFGR, SMU_APB0CFGR_TIM4EN);     UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_TIM4_CLK_DISABLE()      (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_TIM4EN))
#define __HAL_SMU_WWDG0_CLK_ENABLE()      do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_WWDG0EN);    tmpreg = READ_BIT(SMU->APB0CFGR, SMU_APB0CFGR_WWDG0EN);    UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_WWDG0_CLK_DISABLE()     (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_WWDG0EN))
#define __HAL_SMU_APBBUS0_CLK_ENABLE()    do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_APBBUS0EN);  tmpreg = READ_BIT(SMU->APB0CFGR, SMU_APB0CFGR_APBBUS0EN);  UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_APBBUS0_CLK_DISABLE()   (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_APBBUS0EN))

/* ------------------------ ApbBus1 (APB1CFGR) ------------------------ */
#define __HAL_SMU_SPI3_CLK_ENABLE()       do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_SPI3EN);     tmpreg = READ_BIT(SMU->APB1CFGR, SMU_APB1CFGR_SPI3EN);     UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_SPI3_CLK_DISABLE()      (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_SPI3EN))
#define __HAL_SMU_SPI4_CLK_ENABLE()       do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_SPI4EN);     tmpreg = READ_BIT(SMU->APB1CFGR, SMU_APB1CFGR_SPI4EN);     UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_SPI4_CLK_DISABLE()      (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_SPI4EN))
#define __HAL_SMU_SPI5_CLK_ENABLE()       do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_SPI5EN);     tmpreg = READ_BIT(SMU->APB1CFGR, SMU_APB1CFGR_SPI5EN);     UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_SPI5_CLK_DISABLE()      (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_SPI5EN))
#define __HAL_SMU_IIC2_CLK_ENABLE()       do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_IIC2EN);     tmpreg = READ_BIT(SMU->APB1CFGR, SMU_APB1CFGR_IIC2EN);     UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_IIC2_CLK_DISABLE()      (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_IIC2EN))
#define __HAL_SMU_IIC3_CLK_ENABLE()       do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_IIC3EN);     tmpreg = READ_BIT(SMU->APB1CFGR, SMU_APB1CFGR_IIC3EN);     UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_IIC3_CLK_DISABLE()      (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_IIC3EN))
/* I2Cx: delivery-release spelling of the two APB1 IIC clocks, retained so that
 * code written against the earlier release keeps compiling. */
#define __HAL_SMU_I2C2_CLK_ENABLE()       __HAL_SMU_IIC2_CLK_ENABLE()
#define __HAL_SMU_I2C2_CLK_DISABLE()      __HAL_SMU_IIC2_CLK_DISABLE()
#define __HAL_SMU_I2C3_CLK_ENABLE()       __HAL_SMU_IIC3_CLK_ENABLE()
#define __HAL_SMU_I2C3_CLK_DISABLE()      __HAL_SMU_IIC3_CLK_DISABLE()
#define __HAL_SMU_USART4_CLK_ENABLE()     do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_USART4EN);   tmpreg = READ_BIT(SMU->APB1CFGR, SMU_APB1CFGR_USART4EN);   UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_USART4_CLK_DISABLE()    (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_USART4EN))
#define __HAL_SMU_USART5_CLK_ENABLE()     do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_USART5EN);   tmpreg = READ_BIT(SMU->APB1CFGR, SMU_APB1CFGR_USART5EN);   UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_USART5_CLK_DISABLE()    (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_USART5EN))
#define __HAL_SMU_USART6_CLK_ENABLE()     do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_USART6EN);   tmpreg = READ_BIT(SMU->APB1CFGR, SMU_APB1CFGR_USART6EN);   UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_USART6_CLK_DISABLE()    (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_USART6EN))
#define __HAL_SMU_USART7_CLK_ENABLE()     do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_USART7EN);   tmpreg = READ_BIT(SMU->APB1CFGR, SMU_APB1CFGR_USART7EN);   UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_USART7_CLK_DISABLE()    (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_USART7EN))
#define __HAL_SMU_HTIM5_CLK_ENABLE()      do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_HTIM5EN);    tmpreg = READ_BIT(SMU->APB1CFGR, SMU_APB1CFGR_HTIM5EN);    UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_HTIM5_CLK_DISABLE()     (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_HTIM5EN))
#define __HAL_SMU_TIM6_CLK_ENABLE()       do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_TIM6EN);     tmpreg = READ_BIT(SMU->APB1CFGR, SMU_APB1CFGR_TIM6EN);     UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_TIM6_CLK_DISABLE()      (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_TIM6EN))
#define __HAL_SMU_TIM7_CLK_ENABLE()       do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_TIM7EN);     tmpreg = READ_BIT(SMU->APB1CFGR, SMU_APB1CFGR_TIM7EN);     UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_TIM7_CLK_DISABLE()      (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_TIM7EN))
#define __HAL_SMU_WWDG1_CLK_ENABLE()      do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_WWDG1EN);    tmpreg = READ_BIT(SMU->APB1CFGR, SMU_APB1CFGR_WWDG1EN);    UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_WWDG1_CLK_DISABLE()     (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_WWDG1EN))
#define __HAL_SMU_CRC_CLK_ENABLE()        do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_CRCEN);      tmpreg = READ_BIT(SMU->APB1CFGR, SMU_APB1CFGR_CRCEN);      UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_CRC_CLK_DISABLE()       (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_CRCEN))
#define __HAL_SMU_APBBUS1_CLK_ENABLE()    do { __IO uint32 tmpreg = 0x00U; SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_APBBUS1EN);  tmpreg = READ_BIT(SMU->APB1CFGR, SMU_APB1CFGR_APBBUS1EN);  UNUSED(tmpreg); } while (0U)
#define __HAL_SMU_APBBUS1_CLK_DISABLE()   (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_APBBUS1EN))

/**
  * @}
  */

/** @defgroup SMU_Force_Release_Peripheral_Reset Peripheral Reset / Release
  * @{
  */

/* ------------------------ AxiBus0 (AB0CFGR) ------------------------ */
#define __HAL_SMU_QSPI_FORCE_RESET()    (CLEAR_BIT(SMU->AB0CFGR, SMU_AB0CFGR_QSPIRST))
#define __HAL_SMU_QSPI_RELEASE_RESET()  (SET_BIT(SMU->AB0CFGR, SMU_AB0CFGR_QSPIRST))
#define __HAL_SMU_EFLASH_FORCE_RESET()  (CLEAR_BIT(SMU->AB0CFGR, SMU_AB0CFGR_EFLASHRST))
#define __HAL_SMU_EFLASH_RELEASE_RESET()(SET_BIT(SMU->AB0CFGR, SMU_AB0CFGR_EFLASHRST))

/* ------------------------ AxiBus1 (AB1CFGR) ------------------------ */
#define __HAL_SMU_DMA0_FORCE_RESET()    (CLEAR_BIT(SMU->AB1CFGR, SMU_AB1CFGR_DMA0RST))
#define __HAL_SMU_DMA0_RELEASE_RESET()  (SET_BIT(SMU->AB1CFGR, SMU_AB1CFGR_DMA0RST))
#define __HAL_SMU_DMA1_FORCE_RESET()    (CLEAR_BIT(SMU->AB1CFGR, SMU_AB1CFGR_DMA1RST))
#define __HAL_SMU_DMA1_RELEASE_RESET()  (SET_BIT(SMU->AB1CFGR, SMU_AB1CFGR_DMA1RST))
#define __HAL_SMU_SRAM0_FORCE_RESET()   (CLEAR_BIT(SMU->AB1CFGR, SMU_AB1CFGR_SRAM0RST))
#define __HAL_SMU_SRAM0_RELEASE_RESET() (SET_BIT(SMU->AB1CFGR, SMU_AB1CFGR_SRAM0RST))
#define __HAL_SMU_SRAM1_FORCE_RESET()   (CLEAR_BIT(SMU->AB1CFGR, SMU_AB1CFGR_SRAM1RST))
#define __HAL_SMU_SRAM1_RELEASE_RESET() (SET_BIT(SMU->AB1CFGR, SMU_AB1CFGR_SRAM1RST))
#define __HAL_SMU_SRAM2_FORCE_RESET()   (CLEAR_BIT(SMU->AB1CFGR, SMU_AB1CFGR_SRAM2RST))
#define __HAL_SMU_SRAM2_RELEASE_RESET() (SET_BIT(SMU->AB1CFGR, SMU_AB1CFGR_SRAM2RST))
#define __HAL_SMU_SRAM3_FORCE_RESET()   (CLEAR_BIT(SMU->AB1CFGR, SMU_AB1CFGR_SRAM3RST))
#define __HAL_SMU_SRAM3_RELEASE_RESET() (SET_BIT(SMU->AB1CFGR, SMU_AB1CFGR_SRAM3RST))

/* ------------------------ AxiBus3 (AB3CFGR) ------------------------ */
#define __HAL_SMU_AXI4TOAPB0_FORCE_RESET()   (CLEAR_BIT(SMU->AB3CFGR, SMU_AB3CFGR_AXI4TOAPB0RST))
#define __HAL_SMU_AXI4TOAPB0_RELEASE_RESET() (SET_BIT(SMU->AB3CFGR, SMU_AB3CFGR_AXI4TOAPB0RST))
#define __HAL_SMU_AXI4TOAPB1_FORCE_RESET()   (CLEAR_BIT(SMU->AB3CFGR, SMU_AB3CFGR_AXI4TOAPB1RST))
#define __HAL_SMU_AXI4TOAPB1_RELEASE_RESET() (SET_BIT(SMU->AB3CFGR, SMU_AB3CFGR_AXI4TOAPB1RST))
#define __HAL_SMU_AXIBUS3_FORCE_RESET()      (CLEAR_BIT(SMU->AB3CFGR, SMU_AB3CFGR_AXIBUS3RST))
#define __HAL_SMU_AXIBUS3_RELEASE_RESET()    (SET_BIT(SMU->AB3CFGR, SMU_AB3CFGR_AXIBUS3RST))

/* ------------------------ AxiLiteBus0 (ALB0CFGR) ------------------------ */
#define __HAL_SMU_FCU_FORCE_RESET()     (CLEAR_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_FCURST))
#define __HAL_SMU_FCU_RELEASE_RESET()   (SET_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_FCURST))
#define __HAL_SMU_CMU0_FORCE_RESET()    (CLEAR_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_CMU0RST))
#define __HAL_SMU_CMU0_RELEASE_RESET()  (SET_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_CMU0RST))
#define __HAL_SMU_CMU1_FORCE_RESET()    (CLEAR_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_CMU1RST))
#define __HAL_SMU_CMU1_RELEASE_RESET()  (SET_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_CMU1RST))
#define __HAL_SMU_CMU2_FORCE_RESET()    (CLEAR_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_CMU2RST))
#define __HAL_SMU_CMU2_RELEASE_RESET()  (SET_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_CMU2RST))
#define __HAL_SMU_CMU3_FORCE_RESET()    (CLEAR_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_CMU3RST))
#define __HAL_SMU_CMU3_RELEASE_RESET()  (SET_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_CMU3RST))
#define __HAL_SMU_PLIC_FORCE_RESET()    (CLEAR_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_PLICRST))
#define __HAL_SMU_PLIC_RELEASE_RESET()  (SET_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_PLICRST))
#define __HAL_SMU_CLINT_FORCE_RESET()   (CLEAR_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_CLINTRST))
#define __HAL_SMU_CLINT_RELEASE_RESET() (SET_BIT(SMU->ALB0CFGR, SMU_ALB0CFGR_CLINTRST))

/* ------------------------ AxiLiteBus1 (ALB1CFGR) ------------------------ */
#define __HAL_SMU_HTIM0_FORCE_RESET()      (CLEAR_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_HTIM0RST))
#define __HAL_SMU_HTIM0_RELEASE_RESET()    (SET_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_HTIM0RST))
#define __HAL_SMU_CANFD0_FORCE_RESET()     (CLEAR_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_CANFD0RST))
#define __HAL_SMU_CANFD0_RELEASE_RESET()   (SET_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_CANFD0RST))
#define __HAL_SMU_CANFD1_FORCE_RESET()     (CLEAR_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_CANFD1RST))
#define __HAL_SMU_CANFD1_RELEASE_RESET()   (SET_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_CANFD1RST))
#define __HAL_SMU_ADC0_FORCE_RESET()       (CLEAR_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_ADC0RST))
#define __HAL_SMU_ADC0_RELEASE_RESET()     (SET_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_ADC0RST))
#define __HAL_SMU_ADC1_FORCE_RESET()       (CLEAR_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_ADC1RST))
#define __HAL_SMU_ADC1_RELEASE_RESET()     (SET_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_ADC1RST))
#define __HAL_SMU_DAC0_FORCE_RESET()       (CLEAR_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_DAC0RST))
#define __HAL_SMU_DAC0_RELEASE_RESET()     (SET_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_DAC0RST))
#define __HAL_SMU_GPIOA_FORCE_RESET()      (CLEAR_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_GPIOARST))
#define __HAL_SMU_GPIOA_RELEASE_RESET()    (SET_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_GPIOARST))
#define __HAL_SMU_GPIOB_FORCE_RESET()      (CLEAR_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_GPIOBRST))
#define __HAL_SMU_GPIOB_RELEASE_RESET()    (SET_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_GPIOBRST))
#define __HAL_SMU_GPIOC_FORCE_RESET()      (CLEAR_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_GPIOCRST))
#define __HAL_SMU_GPIOC_RELEASE_RESET()    (SET_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_GPIOCRST))
#define __HAL_SMU_DSE_FORCE_RESET()        (CLEAR_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_DSERST))
#define __HAL_SMU_DSE_RELEASE_RESET()      (SET_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_DSERST))
#define __HAL_SMU_AXILITEBUS1_FORCE_RESET()    (CLEAR_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_AXILITEBUS1RST))
#define __HAL_SMU_AXILITEBUS1_RELEASE_RESET()  (SET_BIT(SMU->ALB1CFGR, SMU_ALB1CFGR_AXILITEBUS1RST))

/* ------------------------ AxiLiteBus2 (ALB2CFGR) ------------------------ */
#define __HAL_SMU_HTIM1_FORCE_RESET()      (CLEAR_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_HTIM1RST))
#define __HAL_SMU_HTIM1_RELEASE_RESET()    (SET_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_HTIM1RST))
#define __HAL_SMU_CANFD2_FORCE_RESET()     (CLEAR_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_CANFD2RST))
#define __HAL_SMU_CANFD2_RELEASE_RESET()   (SET_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_CANFD2RST))
#define __HAL_SMU_CANFD3_FORCE_RESET()     (CLEAR_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_CANFD3RST))
#define __HAL_SMU_CANFD3_RELEASE_RESET()   (SET_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_CANFD3RST))
/* No ADC2 reset macro: the delivery release pair
 * __HAL_SMU_ADC2_FORCE_RESET / __HAL_SMU_ADC2_RELEASE_RESET referenced the same
 * undefined ALB2CFGR bit6 / bit7 pair, see the note on the clock macros above. */
#define __HAL_SMU_DAC1_FORCE_RESET()       (CLEAR_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_DAC1RST))
#define __HAL_SMU_DAC1_RELEASE_RESET()     (SET_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_DAC1RST))
#define __HAL_SMU_GPIOD_FORCE_RESET()      (CLEAR_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_GPIODRST))
#define __HAL_SMU_GPIOD_RELEASE_RESET()    (SET_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_GPIODRST))
#define __HAL_SMU_GPIOE_FORCE_RESET()      (CLEAR_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_GPIOERST))
#define __HAL_SMU_GPIOE_RELEASE_RESET()    (SET_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_GPIOERST))
#define __HAL_SMU_GPIOF_FORCE_RESET()      (CLEAR_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_GPIOFRST))
#define __HAL_SMU_GPIOF_RELEASE_RESET()    (SET_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_GPIOFRST))
#define __HAL_SMU_GPIOG_FORCE_RESET()      (CLEAR_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_GPIOGRST))
#define __HAL_SMU_GPIOG_RELEASE_RESET()    (SET_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_GPIOGRST))
#define __HAL_SMU_AXILITEBUS2_FORCE_RESET()    (CLEAR_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_AXILITEBUS2RST))
#define __HAL_SMU_AXILITEBUS2_RELEASE_RESET()  (SET_BIT(SMU->ALB2CFGR, SMU_ALB2CFGR_AXILITEBUS2RST))

/* ------------------------ ApbBus0 (APB0CFGR) ------------------------ */
#define __HAL_SMU_MAC_FORCE_RESET()       (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_MACRST))
#define __HAL_SMU_MAC_RELEASE_RESET()     (SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_MACRST))
#define __HAL_SMU_SPI0_FORCE_RESET()      (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_SPI0RST))
#define __HAL_SMU_SPI0_RELEASE_RESET()    (SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_SPI0RST))
#define __HAL_SMU_SPI1_FORCE_RESET()      (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_SPI1RST))
#define __HAL_SMU_SPI1_RELEASE_RESET()    (SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_SPI1RST))
#define __HAL_SMU_SPI2_FORCE_RESET()      (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_SPI2RST))
#define __HAL_SMU_SPI2_RELEASE_RESET()    (SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_SPI2RST))
#define __HAL_SMU_IIC0_FORCE_RESET()      (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_IIC0RST))
#define __HAL_SMU_IIC0_RELEASE_RESET()    (SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_IIC0RST))
#define __HAL_SMU_IIC1_FORCE_RESET()      (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_IIC1RST))
#define __HAL_SMU_IIC1_RELEASE_RESET()    (SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_IIC1RST))
/* I2Cx: delivery-release spelling of the two APB0 IIC resets, retained so that
 * code written against the earlier release keeps compiling. */
#define __HAL_SMU_I2C0_FORCE_RESET()      __HAL_SMU_IIC0_FORCE_RESET()
#define __HAL_SMU_I2C0_RELEASE_RESET()    __HAL_SMU_IIC0_RELEASE_RESET()
#define __HAL_SMU_I2C1_FORCE_RESET()      __HAL_SMU_IIC1_FORCE_RESET()
#define __HAL_SMU_I2C1_RELEASE_RESET()    __HAL_SMU_IIC1_RELEASE_RESET()
#define __HAL_SMU_USART0_FORCE_RESET()    (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_USART0RST))
#define __HAL_SMU_USART0_RELEASE_RESET()  (SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_USART0RST))
#define __HAL_SMU_USART1_FORCE_RESET()    (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_USART1RST))
#define __HAL_SMU_USART1_RELEASE_RESET()  (SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_USART1RST))
#define __HAL_SMU_USART2_FORCE_RESET()    (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_USART2RST))
#define __HAL_SMU_USART2_RELEASE_RESET()  (SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_USART2RST))
#define __HAL_SMU_USART3_FORCE_RESET()    (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_USART3RST))
#define __HAL_SMU_USART3_RELEASE_RESET()  (SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_USART3RST))
#define __HAL_SMU_HTIM2_FORCE_RESET()     (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_HTIM2RST))
#define __HAL_SMU_HTIM2_RELEASE_RESET()   (SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_HTIM2RST))
#define __HAL_SMU_TIM3_FORCE_RESET()      (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_TIM3RST))
#define __HAL_SMU_TIM3_RELEASE_RESET()    (SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_TIM3RST))
#define __HAL_SMU_TIM4_FORCE_RESET()      (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_TIM4RST))
#define __HAL_SMU_TIM4_RELEASE_RESET()    (SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_TIM4RST))
#define __HAL_SMU_WWDG0_FORCE_RESET()     (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_WWDG0RST))
#define __HAL_SMU_WWDG0_RELEASE_RESET()   (SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_WWDG0RST))
#define __HAL_SMU_APBBUS0_FORCE_RESET()   (CLEAR_BIT(SMU->APB0CFGR, SMU_APB0CFGR_APBBUS0RST))
#define __HAL_SMU_APBBUS0_RELEASE_RESET() (SET_BIT(SMU->APB0CFGR, SMU_APB0CFGR_APBBUS0RST))

/* ------------------------ ApbBus1 (APB1CFGR) ------------------------ */
#define __HAL_SMU_SPI3_FORCE_RESET()      (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_SPI3RST))
#define __HAL_SMU_SPI3_RELEASE_RESET()    (SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_SPI3RST))
#define __HAL_SMU_SPI4_FORCE_RESET()      (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_SPI4RST))
#define __HAL_SMU_SPI4_RELEASE_RESET()    (SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_SPI4RST))
#define __HAL_SMU_SPI5_FORCE_RESET()      (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_SPI5RST))
#define __HAL_SMU_SPI5_RELEASE_RESET()    (SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_SPI5RST))
#define __HAL_SMU_IIC2_FORCE_RESET()      (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_IIC2RST))
#define __HAL_SMU_IIC2_RELEASE_RESET()    (SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_IIC2RST))
#define __HAL_SMU_IIC3_FORCE_RESET()      (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_IIC3RST))
#define __HAL_SMU_IIC3_RELEASE_RESET()    (SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_IIC3RST))
/* I2Cx: delivery-release spelling of the two APB1 IIC resets, retained so that
 * code written against the earlier release keeps compiling. */
#define __HAL_SMU_I2C2_FORCE_RESET()      __HAL_SMU_IIC2_FORCE_RESET()
#define __HAL_SMU_I2C2_RELEASE_RESET()    __HAL_SMU_IIC2_RELEASE_RESET()
#define __HAL_SMU_I2C3_FORCE_RESET()      __HAL_SMU_IIC3_FORCE_RESET()
#define __HAL_SMU_I2C3_RELEASE_RESET()    __HAL_SMU_IIC3_RELEASE_RESET()
#define __HAL_SMU_USART4_FORCE_RESET()    (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_USART4RST))
#define __HAL_SMU_USART4_RELEASE_RESET()  (SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_USART4RST))
#define __HAL_SMU_USART5_FORCE_RESET()    (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_USART5RST))
#define __HAL_SMU_USART5_RELEASE_RESET()  (SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_USART5RST))
#define __HAL_SMU_USART6_FORCE_RESET()    (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_USART6RST))
#define __HAL_SMU_USART6_RELEASE_RESET()  (SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_USART6RST))
#define __HAL_SMU_USART7_FORCE_RESET()    (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_USART7RST))
#define __HAL_SMU_USART7_RELEASE_RESET()  (SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_USART7RST))
#define __HAL_SMU_HTIM5_FORCE_RESET()     (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_HTIM5RST))
#define __HAL_SMU_HTIM5_RELEASE_RESET()   (SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_HTIM5RST))
#define __HAL_SMU_TIM6_FORCE_RESET()      (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_TIM6RST))
#define __HAL_SMU_TIM6_RELEASE_RESET()    (SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_TIM6RST))
#define __HAL_SMU_TIM7_FORCE_RESET()      (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_TIM7RST))
#define __HAL_SMU_TIM7_RELEASE_RESET()    (SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_TIM7RST))
#define __HAL_SMU_WWDG1_FORCE_RESET()     (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_WWDG1RST))
#define __HAL_SMU_WWDG1_RELEASE_RESET()   (SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_WWDG1RST))
#define __HAL_SMU_CRC_FORCE_RESET()       (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_CRCRST))
#define __HAL_SMU_CRC_RELEASE_RESET()     (SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_CRCRST))
#define __HAL_SMU_APBBUS1_FORCE_RESET()   (CLEAR_BIT(SMU->APB1CFGR, SMU_APB1CFGR_APBBUS1RST))
#define __HAL_SMU_APBBUS1_RELEASE_RESET() (SET_BIT(SMU->APB1CFGR, SMU_APB1CFGR_APBBUS1RST))

/**
  * @}
  */

/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/

/** @defgroup SMU_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Initialize the SMU handle: check the handle and the instance,
 *         allocate the lock resource, initialize the low level hardware
 *         through HAL_SMU_MspInit() and set the state to ready. (NON-BLOCKING)
 * @note   Every other function of this driver expects an initialized handle:
 *         calling a configuration function on a handle that is still in the
 *         HAL_SMU_STATE_RESET state returns HAL_ERROR.
 *         The SMU configuration itself (oscillators, PLL, system clock source
 *         and bus dividers) is not programmed here: it is passed to
 *         HAL_SMU_OscConfig() / HAL_SMU_ClockConfig().
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (NULL pointer, invalid instance
 *         or the handle lock could not be taken).
 */
HAL_StatusTypeDef HAL_SMU_Init(HAL_SMU_HandleTypeDef *hsmu);

/**
 * @brief  De-initialize the SMU to its default reset state. (BLOCKING)
 * @note   The system clock source is switched back to the FIRC (and the PLL
 *         is stopped), all the bus dividers are restored to /1, the FIRC
 *         calibration is cleared, and SystemCoreClock is updated. The bus
 *         peripheral clock gates and reset bits (AB0CFGR ... APB1CFGR) are
 *         NOT touched by this function.
 * @note   The handle state is set back to HAL_SMU_STATE_RESET, so that a
 *         following HAL_SMU_Init() runs the low level initialization again.
 * @note   The low level de-initialization callback HAL_SMU_MspDeInit() is
 *         called AFTER the handle lock has been released, and the time base is
 *         refreshed after it: a HAL_SMU_MspDeInit() override may therefore
 *         call other HAL APIs (e.g. HAL_GPIO_DeInit()), and a HAL_InitTick()
 *         override may take an RTOS lock, without deadlocking (LOCK-06 /
 *         ARCH-CONST-04).
 * @note   This function is callable from any handle state (ARCH-CONST-09).
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @param  Timeout: maximum wait time for the FIRC start-up, in ms (the value is
 *         also used as the mutex acquisition timeout in an RTOS build).
 *         HAL_MAX_DELAY waits forever, 0 does not wait; @ref SMU_TIMEOUT_OSC is
 *         sufficient in practice.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (NULL pointer or invalid
 *         instance) / HAL_BUSY / HAL_TIMEOUT if the FIRC does not become ready
 *         before the Timeout expires (the state is then HAL_SMU_STATE_TIMEOUT
 *         and the error code HAL_SMU_ERROR_TIMEOUT).
 */
HAL_StatusTypeDef HAL_SMU_DeInit(HAL_SMU_HandleTypeDef *hsmu, uint32 Timeout);

/**
 * @brief  Initialize the oscillator (FIRC / OSC), the PLL and the system
 *         clock source according to the specified parameters in the
 *         SMU_OscInitStruct. (BLOCKING)
 * @note   The FIRC (calibration value and power state) is configured only when
 *         OscillatorType contains SMU_OSCILLATORTYPE_FIRC, and its power state
 *         is then driven by FIRCState alone; the OSC needs no software
 *         configuration (hardware managed). The PLL configuration is latched
 *         only when the PLL update bit is set.
 * @note   SYSCLKSelect is programmed at the end of this function, so that the
 *         target clock source is always configured and confirmed ready before
 *         the system clock is switched to it: the FIRC is powered on and
 *         polled until ready when it is selected, and the PLL lock flag is
 *         polled when the PLL is selected (a PLL that was never programmed is
 *         rejected with HAL_ERROR instead of being selected). After the
 *         switch, SystemCoreClock is updated and the HAL time base is
 *         re-initialized with HAL_InitTick(). The bus dividers are NOT
 *         programmed here (see HAL_SMU_ClockConfig()).
 * @note   The waits use the HAL 1 ms time base (HAL_GetTick()); in an RTOS
 *         build the polling loops yield the CPU (HAL_RTOS_Yield(), rule
 *         RTOS-04).
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @param  SMU_OscInitStruct: pointer to a SMU_OscInitTypeDef structure that
 *         contains the configuration information for the oscillators, the PLL
 *         and the system clock source.
 * @param  Timeout: maximum wait time, in ms, applied to EACH hardware wait of
 *         this call (the FIRC ready flag and the PLL lock flag; the value is
 *         also used as the mutex acquisition timeout in an RTOS build).
 *         HAL_MAX_DELAY waits forever, 0 does not wait; @ref
 *         SMU_TIMEOUT_DEFAULT covers a PLL lock comfortably.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (NULL pointer, invalid
 *         parameters, source protection or the handle is not initialized) /
 *         HAL_BUSY / HAL_TIMEOUT (the operation timed out; the state is then
 *         HAL_SMU_STATE_TIMEOUT and the error code HAL_SMU_ERROR_TIMEOUT).
 */
HAL_StatusTypeDef HAL_SMU_OscConfig(HAL_SMU_HandleTypeDef *hsmu, SMU_OscInitTypeDef *SMU_OscInitStruct,
                                    uint32 Timeout);

/**
 * @brief  Initialize the bus clock dividers according to the specified
 *         parameters in the SMU_ClockInitStruct. (NON-BLOCKING)
 * @note   Only the bus clock dividers (AXI4Bus3 / APBBus0 / APBBus1 /
 *         CANCLKx2) are programmed: the system clock source is not touched
 *         here, it is selected by HAL_SMU_OscConfig(). Programming the
 *         dividers does not change the core clock, hence no Timeout parameter
 *         and no SystemCoreClock update are needed.
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @param  SMU_ClockInitStruct: pointer to a SMU_ClockInitTypeDef structure
 *         that contains the bus clock divider configuration.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (NULL pointer, invalid
 *         parameters or the handle is not initialized) / HAL_BUSY.
 */
HAL_StatusTypeDef HAL_SMU_ClockConfig(HAL_SMU_HandleTypeDef *hsmu, SMU_ClockInitTypeDef *SMU_ClockInitStruct);

/**
 * @brief  Initialize the SMU low level resources. Weak function; the default
 *         implementation is empty because the SMU has no peripheral clock gate
 *         (it is always clocked) and no interrupt.
 * @note   The user porting layer may override it, for example to create the
 *         RTOS mutex handle (HAL_MutexCreate()) used through
 *         hsmu->LockMutex.
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @retval None
 */
void HAL_SMU_MspInit(HAL_SMU_HandleTypeDef *hsmu);

/**
 * @brief  De-initialize the SMU low level resources. Weak function; the
 *         default implementation is empty.
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @retval None
 */
void HAL_SMU_MspDeInit(HAL_SMU_HandleTypeDef *hsmu);

/**
  * @}
  */

/** @defgroup SMU_Exported_Functions_Group2 Peripheral Control functions
  * @brief    Clock tree read-back and monitoring functions.
  * @note     The functions of this group only read the SMU registers (or the
  *           cached SystemCoreClock value): they take no handle and are not
  *           locked, so that they can be called from any context, including
  *           from another driver (the USART driver reads the APB clock
  *           frequencies to compute its BRR value) or from an interrupt
  *           service routine.
  * @{
  */

/**
 * @brief  Return the current system (core) clock frequency in Hz, computed
 *         from the SMU_BUSCFGR.SYSSEL selection and the PLL registers.
 * @retval uint32: system clock frequency in Hz.
 */
uint32 HAL_SMU_GetSysClockFreq(void);

/**
 * @brief  Return the current core (AXIBus0) clock frequency used by the HAL
 *         time base, i.e. the SystemCoreClock variable.
 * @retval uint32: core clock frequency in Hz.
 */
uint32 HAL_SMU_GetHCLKFreq(void);

/**
 * @brief  Return the APBBus0 clock frequency in Hz.
 * @retval uint32: APBBus0 clock frequency in Hz.
 */
uint32 HAL_SMU_GetPCLK0Freq(void);

/**
 * @brief  Return the APBBus1 clock frequency in Hz.
 * @retval uint32: APBBus1 clock frequency in Hz.
 */
uint32 HAL_SMU_GetPCLK1Freq(void);

/**
 * @brief  Fill the SMU_Clocks structure with the current frequencies of all
 *         the AXI / AXI-Lite / APB / CAN clock domains.
 * @param  SMU_Clocks: pointer to a SMU_ClocksTypeDef structure that will hold
 *         the clocks frequencies.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (NULL pointer or system clock
 *         source not recognized).
 */
HAL_StatusTypeDef HAL_SMU_GetClocksFreq(SMU_ClocksTypeDef *SMU_Clocks);

/**
 * @brief  Get the current oscillator, PLL and system clock source
 *         configuration into the SMU_OscInitStruct.
 * @param  SMU_OscInitStruct: pointer to a SMU_OscInitTypeDef structure that
 *         will hold the read-back configuration.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (NULL pointer).
 */
HAL_StatusTypeDef HAL_SMU_GetOscConfig(SMU_OscInitTypeDef *SMU_OscInitStruct);

/**
 * @brief  Get the current bus divider configuration into the
 *         SMU_ClockInitStruct.
 * @note   The system clock source is not part of SMU_ClockInitTypeDef: it is
 *         reported by HAL_SMU_GetOscConfig().
 * @param  SMU_ClockInitStruct: pointer to a SMU_ClockInitTypeDef structure
 *         that will hold the read-back configuration.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (NULL pointer).
 */
HAL_StatusTypeDef HAL_SMU_GetClockConfig(SMU_ClockInitTypeDef *SMU_ClockInitStruct);

/**
 * @brief  Check whether the specified SMU status flag is set.
 * @param  SMU_FLAG: SMU_FLAG_PLLLOCK or any other SMU_FLAG_xxx value.
 * @retval 1 if the flag is set, 0 otherwise.
 */
uint32 HAL_SMU_GetFlagStatus(uint32 SMU_FLAG);

/**
 * @brief  Return the current AXI bus state of the SMU.
 * @note   Read only query: no handle is required and the lock is not taken
 *         (SMU-REQ-041). The value is the BUSS[2:0] field of the SMU status
 *         register, which lets a low power entry sequence check that the bus is
 *         idle before the clock is switched off.
 * @retval uint32: BUSS[2:0] bus state field.
 */
uint32 HAL_SMU_GetBusState(void);

/**
 * @brief  Return the start-up mode of the current run.
 * @note   Read only query: no handle is required and the lock is not taken
 *         (SMU-REQ-041).
 * @note   Division of labour with the SMU_FLAG_*START status bits: this
 *         function decodes the latched start-up source into the
 *         HAL_SMU_WorkModeTypeDef enumeration (power on / deep sleep /
 *         sleep), which is the form an application branches on;
 *         HAL_SMU_GetFlagStatus(SMU_FLAG_*START) reports the raw register
 *         flag of one start-up source. Both are read-only views of the same
 *         information at different levels (decoded mode vs single flag) and
 *         neither replaces the other: use the mode for control flow, the
 *         flag for a bit-level check of a specific source.
 * @retval HAL_SMU_WorkModeTypeDef: HAL_SMU_WORKMODE_POWER_ON /
 *         DEEP_SLEEP / SLEEP.
 */
HAL_SMU_WorkModeTypeDef HAL_SMU_GetWorkMode(void);

/**
 * @brief  Return the current SMU state of the specified handle.
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @retval HAL_SMU_StateTypeDef: HAL_SMU_STATE_RESET / READY / BUSY / ERROR
 *         (HAL_SMU_STATE_RESET if hsmu is NULL).
 */
HAL_SMU_StateTypeDef HAL_SMU_GetState(HAL_SMU_HandleTypeDef *hsmu);

/**
 * @brief  Return the SMU error code of the specified handle.
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @retval uint32: HAL_SMU_ERROR_NONE / INVALID_PARAM / CLOCK_SOURCE / TIMEOUT
 *         (HAL_SMU_ERROR_NONE if hsmu is NULL).
 */
uint32 HAL_SMU_GetError(HAL_SMU_HandleTypeDef *hsmu);

/**
  * @}
  */

/** @defgroup SMU_Exported_Functions_Group3 Extended Control functions
  * @brief    Extended control functions (clock output, low power, monitoring)
  * @{
  */

/**
 * @brief  Output the selected internal clock through the SMU clock output
 *         pad (divided-by-8 variants or the SIRC clock).
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @param  CLKSelect: SMU_CLKOUTMUX_xxx clock selection.
 * @retval None
 */
void HAL_SMU_MCOConfig(HAL_SMU_HandleTypeDef *hsmu, uint32 CLKSelect);

/**
 * @brief  Select the high-timer brake output signal.
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @param  TimerSelect: SMU_TIMBREAK_TIM0 / SMU_TIMBREAK_TIM1 / SMU_TIMBREAK_TIM2 /
 *         SMU_TIMBREAK_TIM5.
 * @retval None
 */
void HAL_SMU_TimerBreak(HAL_SMU_HandleTypeDef *hsmu, uint32 TimerSelect);

/**
 * @brief  Enable or disable the brake output of the selected high timers.
 * @note   HAL_SMU_TimerBreak() selects which timers drive the brake output by
 *         writing the field, this function enables or disables the selected
 *         timers inside that field without touching the others.
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @param  TimerSelect: bit mask built from SMU_TIMBREAK_TIM0 / TIM1 / TIM2 /
 *         TIM5.
 * @param  NewState: ENABLE or DISABLE.
 * @retval None
 */
void HAL_SMU_TIMBreakCmd(HAL_SMU_HandleTypeDef *hsmu, uint32 TimerSelect, FunctionalState NewState);

/**
 * @brief  Enable or disable the SRAM low power mode.
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @param  SRAMSelect: SMU_SRAMLOWPOWER_SRAM0 ... SMU_SRAMLOWPOWER_SRAM3.
 * @param  NewState: ENABLE or DISABLE.
 * @retval None
 */
void HAL_SMU_SetSRAMLowPower(HAL_SMU_HandleTypeDef *hsmu, uint32 SRAMSelect, FunctionalState NewState);

/**
 * @brief  Enable or disable the dual-core lock-step mode.
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @param  NewState: ENABLE or DISABLE.
 * @retval None
 */
void HAL_SMU_DCLSCmd(HAL_SMU_HandleTypeDef *hsmu, FunctionalState NewState);

/**
 * @brief  Enable or disable the ECC.
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @param  NewState: ENABLE or DISABLE.
 * @retval None
 */
void HAL_SMU_ECCCmd(HAL_SMU_HandleTypeDef *hsmu, FunctionalState NewState);

/**
 * @brief  Enable or disable the bus timeout monitoring.
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @param  NewState: ENABLE or DISABLE.
 * @retval None
 */
void HAL_SMU_BUSTimeOutCmd(HAL_SMU_HandleTypeDef *hsmu, FunctionalState NewState);

/**
 * @brief  Set the bus timeout counter value.
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @param  TimeOutValue: bus timeout counter value, from SMU_BUSTIMEOUT_VALUE_MIN
 *         to SMU_BUSTIMEOUT_VALUE_MAX.
 * @retval None
 */
void HAL_SMU_SetBUSTimeOutValue(HAL_SMU_HandleTypeDef *hsmu, uint32 TimeOutValue);

/**
 * @brief  Clear the bus timeout flag.
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @retval None
 */
void HAL_SMU_ClearTimeOutFlag(HAL_SMU_HandleTypeDef *hsmu);

/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/

/** @defgroup SMU_Private_Macros SMU Private Macros
  * @{
  */

#define IS_SMU_INSTANCE(INSTANCE)   ((INSTANCE) == SMU)
#define IS_SMU_OSCILLATORTYPE(TYPE) ((((TYPE) & ~(SMU_OSCILLATORTYPE_FIRC | SMU_OSCILLATORTYPE_OSC)) == 0U) && ((TYPE) != SMU_OSCILLATORTYPE_NONE))
#define IS_SMU_FIRC_STATE(STATE)    (((STATE) == SMU_FIRC_OFF) || ((STATE) == SMU_FIRC_ON))
#define IS_SMU_PLL_STATE(STATE)     (((STATE) == SMU_PLL_NONE) || ((STATE) == SMU_PLL_OFF) || ((STATE) == SMU_PLL_ON))
#define IS_SMU_PLLSOURCE(SOURCE)    (((SOURCE) == SMU_PLLSOURCE_FIRC) || ((SOURCE) == SMU_PLLSOURCE_OSC))
#define IS_SMU_SYSCLKSOURCE(SOURCE) (((SOURCE) == SMU_SYSCLKSOURCE_FIRC) || ((SOURCE) == SMU_SYSCLKSOURCE_PLL) || ((SOURCE) == SMU_SYSCLKSOURCE_OSC))
#define IS_SMU_PLLDIVR_VALUE(VALUE) ((1U <= (VALUE)) && ((VALUE) <= 7U))
#define IS_SMU_PLLDIVQ_VALUE(VALUE) ((1U <= (VALUE)) && ((VALUE) <= 15U))
#define IS_SMU_PLLDIVN_VALUE(VALUE) ((1U <= (VALUE)) && ((VALUE) <= 63U))
#define IS_SMU_PLLDIVF_VALUE(VALUE) ((50U <= (VALUE)) && ((VALUE) <= 511U))
#define IS_SMU_AXI4BUS3CLKDIV(DIV)  (((DIV) == SMU_AXI4BUS3CLK_DIV1) || ((DIV) == SMU_AXI4BUS3CLK_DIV2))
#define IS_SMU_APBBUS0CLKDIV(DIV)   (((DIV) == SMU_APBBUS0CLK_DIV1) || ((DIV) == SMU_APBBUS0CLK_DIV2) || \
                                     ((DIV) == SMU_APBBUS0CLK_DIV4) || ((DIV) == SMU_APBBUS0CLK_DIV8))
#define IS_SMU_APBBUS1CLKDIV(DIV)   (((DIV) == SMU_APBBUS1CLK_DIV1) || ((DIV) == SMU_APBBUS1CLK_DIV2) || \
                                     ((DIV) == SMU_APBBUS1CLK_DIV4) || ((DIV) == SMU_APBBUS1CLK_DIV8))
#define IS_SMU_CANX2CLKDIV(DIV)     (((DIV) == SMU_CANX2CLK_DIV1) || ((DIV) == SMU_CANX2CLK_DIV2) || \
                                     ((DIV) == SMU_CANX2CLK_DIV4) || ((DIV) == SMU_CANX2CLK_DIV8))
#define IS_SMU_CLKOUTMUX(MUX)       (((MUX) == SMU_CLKOUTMUX_CORECLK_DIV8) || ((MUX) == SMU_CLKOUTMUX_AXIBUS1_DIV8) || \
                                     ((MUX) == SMU_CLKOUTMUX_AXIBUS3_DIV8) || ((MUX) == SMU_CLKOUTMUX_APBBUS0_DIV8) || \
                                     ((MUX) == SMU_CLKOUTMUX_APBBUS1_DIV8) || ((MUX) == SMU_CLKOUTMUX_FIRC_DIV8) || \
                                     ((MUX) == SMU_CLKOUTMUX_OSC_DIV8) || ((MUX) == SMU_CLKOUTMUX_SIRC))
#define IS_SMU_TIMBREAK(SELECT)     (((SELECT) == SMU_TIMBREAK_TIM0) || ((SELECT) == SMU_TIMBREAK_TIM1) || \
                                     ((SELECT) == SMU_TIMBREAK_TIM2) || ((SELECT) == SMU_TIMBREAK_TIM5))
#define IS_SMU_TIMBREAK_MASK(MASK)  (((MASK) != 0U) && (((MASK) & ~(SMU_TIMBREAK_TIM0 | SMU_TIMBREAK_TIM1 | \
                                                                    SMU_TIMBREAK_TIM2 | SMU_TIMBREAK_TIM5)) == 0U))
#define IS_SMU_SRAMLOWPOWER(SELECT) (((SELECT) == SMU_SRAMLOWPOWER_SRAM0) || ((SELECT) == SMU_SRAMLOWPOWER_SRAM1) || \
                                     ((SELECT) == SMU_SRAMLOWPOWER_SRAM2) || ((SELECT) == SMU_SRAMLOWPOWER_SRAM3))
#define IS_SMU_FLAG(FLAG)           (((FLAG) == SMU_FLAG_PLLLOCK) || ((FLAG) == SMU_FLAG_EFLASHICS) || \
                                     ((FLAG) == SMU_FLAG_PWNSTART) || ((FLAG) == SMU_FLAG_DSSTART) || \
                                     ((FLAG) == SMU_FLAG_SLEEPSTART) || ((FLAG) == SMU_FLAG_LPWR) || \
                                     ((FLAG) == SMU_FLAG_AXI4Bus0) || ((FLAG) == SMU_FLAG_AXI4Bus1) || \
                                     ((FLAG) == SMU_FLAG_AXI4Bus2) || ((FLAG) == SMU_FLAG_SRAM0RDY) || \
                                     ((FLAG) == SMU_FLAG_SRAM1RDY) || ((FLAG) == SMU_FLAG_SRAM2RDY) || \
                                     ((FLAG) == SMU_FLAG_SRAM3RDY))
#define IS_SMU_BUSTIMEOUTVALUE(VALUE) (((VALUE) >= SMU_BUSTIMEOUT_VALUE_MIN) && ((VALUE) <= SMU_BUSTIMEOUT_VALUE_MAX))

/**
  * @}
  */

/* Shared internal functions --------------------------------------------------*/

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_SMU_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the acquisition is bounded by the Timeout parameter (RTOS
 *         ticks, which with the usual 1 ms tick is the same quantity as the
 *         millisecond Timeout of the public API); HAL_MAX_DELAY waits forever.
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS, wait expired) /
 *         HAL_ERROR (RTOS, mutex not created) / HAL_BUSY (bare metal, the
 *         handle is already locked).
 */
HAL_StatusTypeDef SMU_LockHandle(HAL_SMU_HandleTypeDef *hsmu, uint32 Timeout);

/**
 * @brief  Unlock the handle.
 * @param  hsmu: pointer to a HAL_SMU_HandleTypeDef structure.
 * @retval None
 */
void SMU_UnlockHandle(HAL_SMU_HandleTypeDef *hsmu);

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_SMU_H */

/*****END OF FILE*****/
