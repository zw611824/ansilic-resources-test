/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_gpio.c
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.13
 * Date:            2026/10/20
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/19     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.1     add the module guard (HAL_GPIO_MODULE_ENABLED) around the whole implementation
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.2     put the as32x601_hal.h include first (module switch from the conf) before the module headers
 *     ANSILIC APPLICATION GROUP  2026/09/07     1.3     align with the GPIO_InitTypeDef
 *                                                       Size / Version metafields
 *                                                       (header V1.1)
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.4     add the run time parameter validation
 *                                                       (instance, pin mask / availability,
 *                                                       mode, pull, drive strength, alternate
 *                                                       function and the Size / Version
 *                                                       metafields of the configuration
 *                                                       structure) in front of the first
 *                                                       register access, so that the checks
 *                                                       stay effective with the assertions
 *                                                       disabled; use NULL_PTR; align the
 *                                                       version number with the other three
 *                                                       module files; describe the module
 *                                                       without referring to an external
 *                                                       implementation
 *     ANSILIC APPLICATION GROUP  2026/10/10     1.7     reject a pin mask that names a pin which does not
 *                                                       exist on the port: the GPIOH port exposes ten
 *                                                       channels (Pin0..Pin9) only, so its channels 10..15
 *                                                       are refused by the pin availability check that is
 *                                                       now applied to the IO entry points as well; filter
 *                                                       the interrupt status snapshot with the per-port
 *                                                       available mask; align the version number and the
 *                                                       date of the four module files
 *     ANSILIC APPLICATION GROUP  2026/10/12     1.8     follow the rename of the drive current constants, the check macro
 *                                                       and the GPIO_InitTypeDef member (DriveCurrent)
 *     ANSILIC APPLICATION GROUP  2026/10/12     1.9     add GPIO_GetDefaultFuncMask() and make HAL_GPIO_DeInit() skip the pins
 *                                                       whose reset default function is multiplexed (GPIOx_PIN_DEFAULT_FUNC, the
 *                                                       QSPI / JTAG / BOOT / FlexBus pins), controlled by
 *                                                       HAL_GPIO_DEINIT_PROTECT_DEFAULT_FUNC; document the behaviour on the
 *                                                       function itself
 *     ANSILIC APPLICATION GROUP  2026/10/12     1.12    drop the pin mask parameter of HAL_GPIO_DeInit(): the function restores the whole
 *                                                       port (every channel that exists on the port, the protected pins excepted) instead
 *                                                       of a caller selection, so its prototype is HAL_GPIO_DeInit(GPIOx)
 *     ANSILIC APPLICATION GROUP  2026/10/20     1.13    split the GPIO interrupt callback per port: HAL_GPIO_IRQHandler() now forwards every pending pin
 *                                                       to the weak callback of the port it was called for (HAL_GPIOA_EXTI_Callback() ...
 *                                                       HAL_GPIOH_EXTI_Callback()) instead of the single aggregated HAL_GPIO_EXTI_Callback(), because
 *                                                       the same bit position exists on every port and the aggregated callback could not tell
 *                                                       GPIOA Pin1 from GPIOC Pin1
 * Description:     This file provides firmware functions to manage the functionalities of the GPIO HAL peripheral.
 *                  It declares the initialization / de-initialization, the basic IO operations
 *                  (read / write / toggle) and the port interrupt handling for the GPIO peripheral.
 *                  Usage: configure the GPIO_InitTypeDef structure (Pin, Mode, Pull, DriveCurrent, Alternate)
 *                  and call HAL_GPIO_Init(). To use the port interrupts, configure the corresponding
 *                  GPIO_MODE_IT_* mode, enable the NVIC/PLIC line (GPIOA_IRQn ... GPIOH_IRQn) in the
 *                  application and call HAL_GPIO_IRQHandler() from the port IRQ handler
 *                  (GPIOA_IRQ_Handler() ... GPIOH_IRQ_Handler()); the weak callback of that
 *                  port (HAL_GPIOA_EXTI_Callback() ... HAL_GPIOH_EXTI_Callback()) is invoked
 *                  for each pending pin, so the callback knows the port and the pin.
 *                  Note: the GPIOH port (10 channels, Pin0..Pin9) is mapped at a dedicated address
 *                  (GPIOHMAP) whose register layout has no MI1SR field; every register access in this
 *                  driver is routed through the GPIO_READ_REG / GPIO_WRITE_REG / GPIO_SET_REG /
 *                  GPIO_CLEAR_REG helper macros.
 */

/* Includes ------------------------------------------------------------------*/
#include "as32x601_hal.h"           /* module switch from as32x601_hal_conf.h */
#include "as32x601_hal_gpio.h"

/* The HAL_GPIO_MODULE_ENABLED switch is provided by the user configuration
 * file (as32x601_hal_conf.h, included above through as32x601_hal.h): the
 * whole implementation is compiled only while the module is enabled. */
#ifdef HAL_GPIO_MODULE_ENABLED

/** @addtogroup AS32X601_HAL_Driver
  * @{
  */

/** @defgroup GPIO GPIO
  * @brief GPIO HAL module driver
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/** @addtogroup GPIO_Private_Constants GPIO Private Constants
  * @{
  */
/**
  * @}
  */
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
static uint32 GPIO_GetAvailableMask(GPIO_TypeDef *GPIOx);
#if (HAL_GPIO_DEINIT_PROTECT_DEFAULT_FUNC == 1U)
static uint32 GPIO_GetDefaultFuncMask(GPIO_TypeDef *GPIOx);
#endif /* (HAL_GPIO_DEINIT_PROTECT_DEFAULT_FUNC == 1U) */
static void GPIO_DispatchPortCallback(GPIO_TypeDef *GPIOx, uint16 GPIO_Pin);
/* Private functions ---------------------------------------------------------*/

/**
  * @brief  Return the per-port available pin mask.
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @retval Available pin mask of the port, or 0 for an unknown instance.
  * @note   The GPIOH port exposes ten channels (Pin0..Pin9) only and its
  *         RWM0CR / IM0CR registers implement ten 2-bit fields, so its channels
  *         10..15 do not exist and must be filtered out of a pin mask or of an
  *         interrupt-status snapshot. Ports A..G expose all sixteen channels.
  *         The value mirrors the GPIOx_PIN_AVAILABLE constant of the extension
  *         header, which is the single source for the pin availability rule.
  */
static uint32 GPIO_GetAvailableMask(GPIO_TypeDef *GPIOx)
{
    if (GPIOx == GPIOH)
    {
        return (uint32)GPIOH_PIN_AVAILABLE;
    }

    if (IS_GPIO_ALL_INSTANCE(GPIOx) == 0)
    {
        return 0U;
    }

    return (uint32)GPIO_PIN_MASK;
}

#if (HAL_GPIO_DEINIT_PROTECT_DEFAULT_FUNC == 1U)
/**
  * @brief  Return the mask of the pins whose reset default function is not GPIO.
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @retval Mask of the pins that carry a multiplexed function out of reset, or
  *         0 for an unknown instance.
  * @note   The value mirrors the GPIOx_PIN_DEFAULT_FUNC constant of the extension
  *         header, which is the single source for this rule. Those pins (QSPI /
  *         JTAG / BOOT / FlexBus) are left untouched by HAL_GPIO_DeInit().
  */
static uint32 GPIO_GetDefaultFuncMask(GPIO_TypeDef *GPIOx)
{
    if (GPIOx == GPIOA)
    {
        return (uint32)GPIOA_PIN_DEFAULT_FUNC;
    }

    if (GPIOx == GPIOB)
    {
        return (uint32)GPIOB_PIN_DEFAULT_FUNC;
    }

    if (GPIOx == GPIOC)
    {
        return (uint32)GPIOC_PIN_DEFAULT_FUNC;
    }

    if (GPIOx == GPIOD)
    {
        return (uint32)GPIOD_PIN_DEFAULT_FUNC;
    }

    if (GPIOx == GPIOE)
    {
        return (uint32)GPIOE_PIN_DEFAULT_FUNC;
    }

    if (GPIOx == GPIOF)
    {
        return (uint32)GPIOF_PIN_DEFAULT_FUNC;
    }

    if (GPIOx == GPIOG)
    {
        return (uint32)GPIOG_PIN_DEFAULT_FUNC;
    }

    if (GPIOx == GPIOH)
    {
        return (uint32)GPIOH_PIN_DEFAULT_FUNC;
    }

    return 0U;
}
#endif /* (HAL_GPIO_DEINIT_PROTECT_DEFAULT_FUNC == 1U) */

/**
  * @brief  Forward one pending pin of a port to the callback dedicated to that
  *         port.
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @param  GPIO_Pin: bit mask of the pending pin (a single GPIO_PIN_x bit).
  * @retval None
  * @note   The AS32X601 has one interrupt line per port (GPIOA_IRQn ... GPIOH_IRQn)
  *         and every port carries the same sixteen bit positions, so the pin mask
  *         alone does not identify an event: bit 1 of GPIOA and bit 1 of GPIOC
  *         are both 0x0002. Forwarding only the mask would therefore leave the
  *         callback unable to tell those two events apart. Each port has its own
  *         weak callback (HAL_GPIOA_EXTI_Callback() ... HAL_GPIOH_EXTI_Callback())
  *         and this helper selects it, so the callback that is entered already
  *         knows the port, while its parameter carries the pin.
  *         An instance that is not a GPIO port is ignored: HAL_GPIO_IRQHandler()
  *         rejects such an argument before it reaches this helper.
  */
static void GPIO_DispatchPortCallback(GPIO_TypeDef *GPIOx, uint16 GPIO_Pin)
{
    if (GPIOx == GPIOA)
    {
        HAL_GPIOA_EXTI_Callback(GPIO_Pin);
    }
    else if (GPIOx == GPIOB)
    {
        HAL_GPIOB_EXTI_Callback(GPIO_Pin);
    }
    else if (GPIOx == GPIOC)
    {
        HAL_GPIOC_EXTI_Callback(GPIO_Pin);
    }
    else if (GPIOx == GPIOD)
    {
        HAL_GPIOD_EXTI_Callback(GPIO_Pin);
    }
    else if (GPIOx == GPIOE)
    {
        HAL_GPIOE_EXTI_Callback(GPIO_Pin);
    }
    else if (GPIOx == GPIOF)
    {
        HAL_GPIOF_EXTI_Callback(GPIO_Pin);
    }
    else if (GPIOx == GPIOG)
    {
        HAL_GPIOG_EXTI_Callback(GPIO_Pin);
    }
    else if (GPIOx == GPIOH)
    {
        HAL_GPIOH_EXTI_Callback(GPIO_Pin);
    }
    else
    {
        /* Not a GPIO port instance: nothing to do */
    }
}

/* Exported functions --------------------------------------------------------*/
/** @defgroup GPIO_Exported_Functions GPIO Exported Functions
  * @{
  */

/** @defgroup GPIO_Exported_Functions_Group1 Initialization and de-initialization functions
 *  @brief    Initialization and Configuration functions
 *
@verbatim
 ===============================================================================
              ##### Initialization and de-initialization functions #####
 ===============================================================================
  [..]
    This section provides functions allowing to initialize and de-initialize the GPIOs
    to be ready for use.

@endverbatim
  * @{
  */

/**
  * @brief  Initializes the GPIOx peripheral according to the specified parameters in the GPIO_Init. (NON-BLOCKING)
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  *         The GPIOH port has 10 channels (Pin0..Pin9).
  * @param  GPIO_Init: pointer to a GPIO_InitTypeDef structure that contains
  *         the configuration information for the specified GPIO peripheral.
  * @retval None
  */
void HAL_GPIO_Init(GPIO_TypeDef *GPIOx, GPIO_InitTypeDef *GPIO_Init)
{
    uint32 position = 0x00;
    uint32 ioposition = 0x00;
    uint32 iocurrent = 0x00;
    uint32 temp = 0x00;
    uint32 mode_value = 0x00;

    /* Check the parameters: the NULL test comes first (the instance test that
       follows only compares the pointer, it never dereferences it) */
    if ((GPIOx == NULL_PTR) || (GPIO_Init == NULL_PTR))
    {
        return;
    }

    assert_param(IS_GPIO_ALL_INSTANCE(GPIOx));
    assert_param(IS_GPIO_PIN(GPIO_Init->Pin));
    assert_param(IS_GPIO_PIN_AVAILABLE(GPIOx, GPIO_Init->Pin));
    assert_param(IS_GPIO_MODE(GPIO_Init->Mode));
    assert_param(IS_GPIO_PULL(GPIO_Init->Pull));
    assert_param(IS_GPIO_DRIVE_CURRENT(GPIO_Init->DriveCurrent));

    /* Run time parameter validation, so that the checks stay effective in a
       build with the assertions disabled. The Size / Version metafields of the
       configuration structure are validated as well (architecture spec section
       22: the structure is cleared and its metafields filled in before the
       business fields), and the reserved words must be zero. The alternate
       function is only relevant in the alternate function modes, so it is
       validated in those modes only, exactly like the assertion above. A
       rejected call performs no register access at all, which leaves the port
       unchanged; the reason is reported through assert_param() in a
       USE_FULL_ASSERT build. */
    if ((IS_GPIO_ALL_INSTANCE(GPIOx) == 0U) ||
        (GPIO_Init->Size != sizeof(GPIO_InitTypeDef)) ||
        (GPIO_Init->Version != GPIO_INIT_VERSION) ||
        (IS_GPIO_PIN(GPIO_Init->Pin) == 0U) ||
        (IS_GPIO_PIN_AVAILABLE(GPIOx, GPIO_Init->Pin) == 0U) ||
        (IS_GPIO_MODE(GPIO_Init->Mode) == 0U) ||
        (IS_GPIO_PULL(GPIO_Init->Pull) == 0U) ||
        (IS_GPIO_DRIVE_CURRENT(GPIO_Init->DriveCurrent) == 0U) ||
        ((((GPIO_Init->Mode) == GPIO_MODE_AF_PP) || ((GPIO_Init->Mode) == GPIO_MODE_AF_OD)) &&
         (IS_GPIO_AF(GPIO_Init->Alternate) == 0U)) ||
        (GPIO_Init->Reserved[0] != 0U) ||
        (GPIO_Init->Reserved[1] != 0U))
    {
        return;
    }

    /* Configure the port pins */
    for(position = 0; position < GPIO_NUMBER; position++)
    {
        /* Get the IO position */
        ioposition = ((uint32)0x01) << position;
        /* Get the current IO position */
        iocurrent = (uint32)(GPIO_Init->Pin) & ioposition;

        if(iocurrent == ioposition)
        {
            /*--------------------- GPIO Mode Configuration ------------------------*/
            /* In case of Alternate function mode selection */
            if((GPIO_Init->Mode == GPIO_MODE_AF_PP) || (GPIO_Init->Mode == GPIO_MODE_AF_OD))
            {
                /* Check the Alternate function parameter */
                assert_param(IS_GPIO_AF(GPIO_Init->Alternate));

                /* Configure Alternate function mapped with the current IO.
                   The AS32X601 multiplex interface is a 3-bit per pin encoding:
                   pins 0..9  -> MI0SR register (all ports, GPIOH included)
                   pins 10..15-> MI1SR register (GPIOH has no MI1SR: nothing to do) */
                if(position < 10U)
                {
                    temp = GPIO_READ_REG(GPIOx, MI0SR);
                    temp &= ~((uint32)GPIO_MI0SR_AFR0 << (position * 3));
                    temp |= ((uint32)(GPIO_Init->Alternate) << (position * 3));
                    GPIO_WRITE_REG(GPIOx, MI0SR, temp);
                }
                else
                {
                    if(GPIOx != GPIOH)
                    {
                        temp = GPIOx->MI1SR;
                        temp &= ~((uint32)GPIO_MI1SR_AFR10 << ((position - 10U) * 3));
                        temp |= ((uint32)(GPIO_Init->Alternate) << ((position - 10U) * 3));
                        GPIOx->MI1SR = temp;
                    }
                }
            }

            /* Configure IO Direction mode (Input, Output, Alternate or Analog).
               The AS32X601 RWM0CR MODER field encodes: 00=Input, 01=Output, 10=Analog, 11=IDDQ.
               The Alternate mode requires the MODER set to Output (01) plus the MI0SR/MI1SR
               multiplex selection configured above; the IDDQ mode is chip specific and is
               defined in the extension module. */
            if((GPIO_Init->Mode == GPIO_MODE_AF_PP) || (GPIO_Init->Mode == GPIO_MODE_AF_OD) ||
               (GPIO_Init->Mode == GPIO_MODE_OUTPUT_PP) || (GPIO_Init->Mode == GPIO_MODE_OUTPUT_OD))
            {
                mode_value = GPIO_MODE_VALUE_OUTPUT;
            }
            else if(GPIO_Init->Mode == GPIO_MODE_ANALOG)
            {
                mode_value = GPIO_MODE_VALUE_ANALOG;
            }
            else if(GPIO_Init->Mode == GPIO_MODE_IDDQ)
            {
                mode_value = GPIO_MODE_VALUE_IDDQ;
            }
            else
            {
                /* GPIO_MODE_INPUT or GPIO_MODE_IT_* */
                mode_value = GPIO_MODE_VALUE_INPUT;
            }

            temp = GPIO_READ_REG(GPIOx, RWM0CR);
            temp &= ~(GPIO_RWM0CR_MODER0 << (position * 2));
            temp |= (mode_value << (position * 2));
            GPIO_WRITE_REG(GPIOx, RWM0CR, temp);

            /* Configure the IO output drive current (OICR field).
               The output intensity register is programmed for every mode; its value
               is only meaningful in the output and alternate function modes. */
            temp = GPIO_READ_REG(GPIOx, OICR);
            temp &= ~(GPIO_OICR_OSTRENGTH0 << (position * 2));
            temp |= (GPIO_Init->DriveCurrent << (position * 2));
            GPIO_WRITE_REG(GPIOx, OICR, temp);

            /* In case of Output or Alternate function mode selection */
            if((GPIO_Init->Mode == GPIO_MODE_OUTPUT_PP) || (GPIO_Init->Mode == GPIO_MODE_AF_PP) ||
               (GPIO_Init->Mode == GPIO_MODE_OUTPUT_OD) || (GPIO_Init->Mode == GPIO_MODE_AF_OD))
            {
                /* Configure the IO Output Type.
                   Note: the OMCR bit encoding is inverted vs the GPIO_OUTPUT_TYPE bit 4
                   of the Mode value (the Mode bit 4 encodes 0 = Push-Pull, 1 = Open-Drain
                   while the OMCR register encodes 0 = Open-Drain, 1 = Push-Pull). */
                temp = GPIO_READ_REG(GPIOx, OMCR);
                temp &= ~(GPIO_OMCR_OT0 << position);
                if((GPIO_Init->Mode & GPIO_OUTPUT_TYPE) != GPIO_OUTPUT_TYPE)
                {
                    /* Push-Pull output: OMCR bit = 1 */
                    temp |= (GPIO_OMCR_OT0 << position);
                }
                GPIO_WRITE_REG(GPIOx, OMCR, temp);
            }

            /* In case of Input or External Interrupt mode selection, activate the
               Pull-up or Pull-down resistor for the current IO (IM0CR field) */
            if((GPIO_Init->Mode == GPIO_MODE_INPUT) || ((GPIO_Init->Mode & EXTI_MODE) == EXTI_MODE))
            {
                temp = GPIO_READ_REG(GPIOx, IM0CR);
                temp &= ~(GPIO_IM0CR_PUPDR0 << (position * 2));
                temp |= ((GPIO_Init->Pull) << (position * 2));
                GPIO_WRITE_REG(GPIOx, IM0CR, temp);
            }

            /*--------------------- EXTI Mode Configuration ------------------------*/
            /* Configure the External Interrupt for the current IO.
               The AS32X601 integrates the interrupt controller inside the GPIO port:
               the trigger type is programmed in the ITYPE0R register and the line
               interrupt is enabled by clearing the corresponding IMR mask bit. */
            if((GPIO_Init->Mode & EXTI_MODE) == EXTI_MODE)
            {
                uint32 ittype = 0x00;

                /* Compute the ITYPE0R 2-bit trigger encoding:
                   00 = disabled, 01 = rising edge, 10 = falling edge, 11 = both edges */
                if((GPIO_Init->Mode & RISING_EDGE) == RISING_EDGE)
                {
                    ittype |= 0x01U;
                }
                if((GPIO_Init->Mode & FALLING_EDGE) == FALLING_EDGE)
                {
                    ittype |= 0x02U;
                }

                /* Configure the interrupt trigger type */
                temp = GPIO_READ_REG(GPIOx, ITYPE0R);
                temp &= ~(GPIO_ITYPE0R_ITEN0 << (position * 2));
                temp |= (ittype << (position * 2));
                GPIO_WRITE_REG(GPIOx, ITYPE0R, temp);

                /* Enable the interrupt line (clear the IMR mask bit) */
                GPIO_CLEAR_REG(GPIOx, IMR, iocurrent);
            }
        }
    }
}

/**
  * @brief  De-initializes the GPIOx port: restores every channel of the port
  *         to its reset state. (NON-BLOCKING)
  * @note   The function takes no pin mask: the whole port is restored. The
  *         channels that do not exist on the port are skipped, so a port with
  *         ten channels (GPIOH, Pin0..Pin9) is restored over those ten channels
  *         only.
  * @note   The pins whose reset default function is a multiplexed function
  *         (GPIOx_PIN_DEFAULT_FUNC: QSPI / JTAG / BOOT / FlexBus) are left
  *         untouched, so that the function they carry is not dropped. Set
  *         HAL_GPIO_DEINIT_PROTECT_DEFAULT_FUNC to 0 to reset them as well;
  *         when every channel of the port carries such a function, the call
  *         leaves the port unchanged.
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @retval None
  */
void HAL_GPIO_DeInit(GPIO_TypeDef *GPIOx)
{
    uint32 position;
    uint32 ioposition = 0x00;
    uint32 iocurrent = 0x00;
    uint32 pins;

    /* Check the parameters. The run time check mirrors the assertion below,
       so that a rejected call leaves the port unchanged in every build. */
    if (GPIOx == NULL_PTR)
    {
        return;
    }

    assert_param(IS_GPIO_ALL_INSTANCE(GPIOx));

    if (IS_GPIO_ALL_INSTANCE(GPIOx) == 0U)
    {
        return;
    }

    /* Restore every channel that exists on this port: the port availability
       mask also keeps the channels 10..15 of the GPIOH port out, as they do
       not exist there. */
    pins = GPIO_GetAvailableMask(GPIOx);

#if (HAL_GPIO_DEINIT_PROTECT_DEFAULT_FUNC == 1U)
    /* Leave the pins whose reset default function is not GPIO untouched
       (GPIOx_PIN_DEFAULT_FUNC: QSPI / JTAG / BOOT / FlexBus). Their reset state
       is not the plain GPIO default, so clearing it would drop the function they
       carry and could break, for example, the QSPI boot path or the debug port.
       The filter can be disabled with
       HAL_GPIO_DEINIT_PROTECT_DEFAULT_FUNC = 0. */
    pins &= ~GPIO_GetDefaultFuncMask(GPIOx);

    if (pins == 0U)
    {
        /* Every channel of this port carries a default function */
        return;
    }
#endif /* (HAL_GPIO_DEINIT_PROTECT_DEFAULT_FUNC == 1U) */

    /* Configure the port pins */
    for(position = 0; position < GPIO_NUMBER; position++)
    {
        /* Get the IO position */
        ioposition = ((uint32)0x01) << position;
        /* Get the current IO position */
        iocurrent = pins & ioposition;

        if(iocurrent == ioposition)
        {
            /*------------------------- GPIO Mode Configuration --------------------*/
            /* Configure IO Direction in Input Floating Mode */
            GPIO_CLEAR_REG(GPIOx, RWM0CR, GPIO_RWM0CR_MODER0 << (position * 2));

            /* Configure the default input type (floating) */
            GPIO_CLEAR_REG(GPIOx, IM0CR, GPIO_IM0CR_PUPDR0 << (position * 2));

            /* Configure the default value for IO Output Type */
            GPIO_CLEAR_REG(GPIOx, OMCR, GPIO_OMCR_OT0 << position);

            /* Configure the default value for IO output drive strength */
            GPIO_CLEAR_REG(GPIOx, OICR, GPIO_OICR_OSTRENGTH0 << (position * 2));

            /* Configure the default Alternate Function in current IO */
            if(position < 10U)
            {
                GPIO_CLEAR_REG(GPIOx, MI0SR, GPIO_MI0SR_AFR0 << (position * 3));
            }
            else
            {
                if(GPIOx != GPIOH)
                {
                    GPIOx->MI1SR &= ~((uint32)GPIO_MI1SR_AFR10 << ((position - 10U) * 3));
                }
            }

            /*------------------------- EXTI Mode Configuration --------------------*/
            /* Reset the interrupt trigger type (interrupt disabled) */
            GPIO_CLEAR_REG(GPIOx, ITYPE0R, GPIO_ITYPE0R_ITEN0 << (position * 2));

            /* Mask the interrupt line (IMR bit = 1) */
            GPIO_SET_REG(GPIOx, IMR, iocurrent);
        }
    }
}

/**
  * @}
  */

/** @defgroup GPIO_Exported_Functions_Group2 IO operation functions
 *  @brief   GPIO Read and Write
 *
@verbatim
 ===============================================================================
                       ##### IO operation functions #####
 ===============================================================================

@endverbatim
  * @{
  */

/**
  * @brief  Reads the specified input port pin. (NON-BLOCKING)
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @param  GPIO_Pin: specifies the port bit to read.
  *         This parameter can be GPIO_PIN_x where x can be (0..15).
  * @retval The input port pin value.
  */
GPIO_PinState HAL_GPIO_ReadPin(GPIO_TypeDef *GPIOx, uint16 GPIO_Pin)
{
    GPIO_PinState bitstatus;

    /* Check the parameters. The run time checks mirror the assertions below,
       so that a rejected call performs no register access in every build. */
    if (GPIOx == NULL_PTR)
    {
        return GPIO_PIN_RESET;
    }

    assert_param(IS_GPIO_ALL_INSTANCE(GPIOx));
    assert_param(IS_GPIO_PIN(GPIO_Pin));
    assert_param(IS_GPIO_PIN_AVAILABLE(GPIOx, GPIO_Pin));

    if ((IS_GPIO_ALL_INSTANCE(GPIOx) == 0U) || (IS_GPIO_PIN(GPIO_Pin) == 0U) ||
        (IS_GPIO_PIN_AVAILABLE(GPIOx, GPIO_Pin) == 0U))
    {
        return GPIO_PIN_RESET;
    }

    if((GPIO_READ_REG(GPIOx, IRR) & GPIO_Pin) != (uint32)GPIO_PIN_RESET)
    {
        bitstatus = GPIO_PIN_SET;
    }
    else
    {
        bitstatus = GPIO_PIN_RESET;
    }
    return bitstatus;
}

/**
  * @brief  Sets or clears the selected data port bit. (NON-BLOCKING)
  * @note   This function uses the GPIOx OPBR/OBCR registers to allow atomic
  *         read/modify accesses. In this way, there is no risk of an IRQ
  *         occurring between the read and the modify access.
  *
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @param  GPIO_Pin: specifies the port bit to be written.
  *          This parameter can be one of GPIO_PIN_x where x can be (0..15).
  * @param  PinState: specifies the value to be written to the selected bit.
  *          This parameter can be one of the GPIO_PinState enum values:
  *            @arg GPIO_PIN_RESET: to clear the port pin
  *            @arg GPIO_PIN_SET: to set the port pin
  * @retval None
  */
void HAL_GPIO_WritePin(GPIO_TypeDef *GPIOx, uint16 GPIO_Pin, GPIO_PinState PinState)
{
    /* Check the parameters. The run time checks mirror the assertions below,
       so that a rejected call performs no register access in every build. */
    if (GPIOx == NULL_PTR)
    {
        return;
    }

    assert_param(IS_GPIO_ALL_INSTANCE(GPIOx));
    assert_param(IS_GPIO_PIN(GPIO_Pin));
    assert_param(IS_GPIO_PIN_AVAILABLE(GPIOx, GPIO_Pin));
    assert_param(IS_GPIO_PIN_ACTION(PinState));

    if ((IS_GPIO_ALL_INSTANCE(GPIOx) == 0U) ||
        (IS_GPIO_PIN(GPIO_Pin) == 0U) ||
        (IS_GPIO_PIN_AVAILABLE(GPIOx, GPIO_Pin) == 0U) ||
        (IS_GPIO_PIN_ACTION(PinState) == 0U))
    {
        return;
    }

    if(PinState != GPIO_PIN_RESET)
    {
        /* OPBR is a write-only set register: writing 1 sets the pin, 0 has no effect */
        GPIO_WRITE_REG(GPIOx, OPBR, GPIO_Pin);
    }
    else
    {
        /* OBCR is a write-only clear register: writing 1 clears the pin, 0 has no effect */
        GPIO_WRITE_REG(GPIOx, OBCR, GPIO_Pin);
    }
}

/**
  * @brief  Toggles the specified GPIO pins. (NON-BLOCKING)
  * @param  GPIOx: Where x can be (A..H) to select the GPIO peripheral.
  * @param  GPIO_Pin: Specifies the pins to be toggled.
  * @retval None
  */
void HAL_GPIO_TogglePin(GPIO_TypeDef *GPIOx, uint16 GPIO_Pin)
{
    /* Check the parameters. The run time checks mirror the assertions below,
       so that a rejected call performs no register access in every build. */
    if (GPIOx == NULL_PTR)
    {
        return;
    }

    assert_param(IS_GPIO_ALL_INSTANCE(GPIOx));
    assert_param(IS_GPIO_PIN(GPIO_Pin));
    assert_param(IS_GPIO_PIN_AVAILABLE(GPIOx, GPIO_Pin));

    if ((IS_GPIO_ALL_INSTANCE(GPIOx) == 0U) || (IS_GPIO_PIN(GPIO_Pin) == 0U) ||
        (IS_GPIO_PIN_AVAILABLE(GPIOx, GPIO_Pin) == 0U))
    {
        return;
    }

    /* OBTR is a write-only toggle register: writing 1 toggles the pin, 0 has no effect */
    GPIO_WRITE_REG(GPIOx, OBTR, GPIO_Pin);
}

/**
  * @brief  This function handles GPIO port interrupt requests.
  * @note   The AS32X601 GPIO port has a single interrupt line per port
  *         (GPIOA_IRQn ... GPIOH_IRQn): this function shall be called from the
  *         port IRQ handler (e.g. GPIOA_IRQ_Handler()). It scans the pending
  *         (unmasked) interrupt status bits and, for each pending pin, invokes
  *         the callback of the port the function was called for
  *         (HAL_GPIOA_EXTI_Callback() ... HAL_GPIOH_EXTI_Callback()).
  * @note   The callback is selected by port, so an event on GPIOA Pin1 and an
  *         event on GPIOC Pin1 reach different callbacks even though both pins
  *         carry the same mask (0x0002). A single aggregated callback would not
  *         be able to tell them apart.
  * @note   The status snapshot is filtered with the per-port available pin mask
  *         first, so a callback is never raised for a channel that does not
  *         exist on the port (the GPIOH port exposes Pin0..Pin9 only).
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @retval None
  */
void HAL_GPIO_IRQHandler(GPIO_TypeDef *GPIOx)
{
    uint32 position = 0x00;
    uint32 ioposition = 0x00;
    uint32 iocurrent = 0x00;
    uint32 isr = 0x00;

    /* Check the parameters. Interrupt context: the run time check mirrors the
       assertion below; nothing is locked and nothing is waited for. */
    if (GPIOx == NULL_PTR)
    {
        return;
    }

    assert_param(IS_GPIO_ALL_INSTANCE(GPIOx));

    if (IS_GPIO_ALL_INSTANCE(GPIOx) == 0U)
    {
        return;
    }

    /* Read the interrupt status register (raw status AND NOT mask) once and keep
       only the channels that exist on this port. */
    isr  = GPIO_READ_REG(GPIOx, ISR);
    isr &= GPIO_GetAvailableMask(GPIOx);

    for(position = 0; position < GPIO_NUMBER; position++)
    {
        ioposition = ((uint32)0x01) << position;
        iocurrent = isr & ioposition;

        if(iocurrent == ioposition)
        {
            /* Clear the pending bit (IRSR is a write-1-to-clear register) */
            GPIO_WRITE_REG(GPIOx, IRSR, ioposition);
            /* Invoke the callback of this port, so that the callback knows both
               the port and the pin of the event */
            GPIO_DispatchPortCallback(GPIOx, (uint16)ioposition);
        }
    }
}

/**
  * @brief  GPIOA port interrupt line detection callback: called for every
  *         pending pin of the GPIOA port.
  * @param  GPIO_Pin: bit mask of the pending pin (a single GPIO_PIN_x bit).
  * @retval None
  */
__weak void HAL_GPIOA_EXTI_Callback(uint16 GPIO_Pin)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(GPIO_Pin);

    /* NOTE: This function should not be modified, when the callback is needed,
             the HAL_GPIOA_EXTI_Callback could be implemented in the user file
     */
}

/**
  * @brief  GPIOB port interrupt line detection callback: called for every
  *         pending pin of the GPIOB port.
  * @param  GPIO_Pin: bit mask of the pending pin (a single GPIO_PIN_x bit).
  * @retval None
  */
__weak void HAL_GPIOB_EXTI_Callback(uint16 GPIO_Pin)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(GPIO_Pin);

    /* NOTE: This function should not be modified, when the callback is needed,
             the HAL_GPIOB_EXTI_Callback could be implemented in the user file
     */
}

/**
  * @brief  GPIOC port interrupt line detection callback: called for every
  *         pending pin of the GPIOC port.
  * @param  GPIO_Pin: bit mask of the pending pin (a single GPIO_PIN_x bit).
  * @retval None
  */
__weak void HAL_GPIOC_EXTI_Callback(uint16 GPIO_Pin)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(GPIO_Pin);

    /* NOTE: This function should not be modified, when the callback is needed,
             the HAL_GPIOC_EXTI_Callback could be implemented in the user file
     */
}

/**
  * @brief  GPIOD port interrupt line detection callback: called for every
  *         pending pin of the GPIOD port.
  * @param  GPIO_Pin: bit mask of the pending pin (a single GPIO_PIN_x bit).
  * @retval None
  */
__weak void HAL_GPIOD_EXTI_Callback(uint16 GPIO_Pin)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(GPIO_Pin);

    /* NOTE: This function should not be modified, when the callback is needed,
             the HAL_GPIOD_EXTI_Callback could be implemented in the user file
     */
}

/**
  * @brief  GPIOE port interrupt line detection callback: called for every
  *         pending pin of the GPIOE port.
  * @param  GPIO_Pin: bit mask of the pending pin (a single GPIO_PIN_x bit).
  * @retval None
  */
__weak void HAL_GPIOE_EXTI_Callback(uint16 GPIO_Pin)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(GPIO_Pin);

    /* NOTE: This function should not be modified, when the callback is needed,
             the HAL_GPIOE_EXTI_Callback could be implemented in the user file
     */
}

/**
  * @brief  GPIOF port interrupt line detection callback: called for every
  *         pending pin of the GPIOF port.
  * @param  GPIO_Pin: bit mask of the pending pin (a single GPIO_PIN_x bit).
  * @retval None
  */
__weak void HAL_GPIOF_EXTI_Callback(uint16 GPIO_Pin)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(GPIO_Pin);

    /* NOTE: This function should not be modified, when the callback is needed,
             the HAL_GPIOF_EXTI_Callback could be implemented in the user file
     */
}

/**
  * @brief  GPIOG port interrupt line detection callback: called for every
  *         pending pin of the GPIOG port.
  * @param  GPIO_Pin: bit mask of the pending pin (a single GPIO_PIN_x bit).
  * @retval None
  */
__weak void HAL_GPIOG_EXTI_Callback(uint16 GPIO_Pin)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(GPIO_Pin);

    /* NOTE: This function should not be modified, when the callback is needed,
             the HAL_GPIOG_EXTI_Callback could be implemented in the user file
     */
}

/**
  * @brief  GPIOH port interrupt line detection callback: called for every
  *         pending pin of the GPIOH port.
  * @param  GPIO_Pin: bit mask of the pending pin (a single GPIO_PIN_x bit).
  * @retval None
  */
__weak void HAL_GPIOH_EXTI_Callback(uint16 GPIO_Pin)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(GPIO_Pin);

    /* NOTE: This function should not be modified, when the callback is needed,
             the HAL_GPIOH_EXTI_Callback could be implemented in the user file
     */
}

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/** @addtogroup AS32X601_HAL_Driver
  * @{
  */

/** @defgroup GPIO GPIO
  * @brief GPIO Extended HAL module driver
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/* Exported functions --------------------------------------------------------*/
/** @defgroup GPIO_Exported_Functions GPIO Exported Functions
  * @{
  */

/**
  * @brief  Fills each GPIO_InitStruct member with its default value. (NON-BLOCKING)
  * @param  GPIO_InitStruct: pointer to a GPIO_InitTypeDef structure which will be initialized.
  * @retval None
  */
void HAL_GPIO_StructInit(GPIO_InitTypeDef *GPIO_InitStruct)
{
    /* Check the parameters */
    if (GPIO_InitStruct == NULL_PTR)
    {
        return;
    }

    /* Reset GPIO init structure parameters values. The Size / Version
       metafields belong to the defaults (architecture spec section 22):
       filling them here means that a structure prepared with this function is
       accepted by HAL_GPIO_Init() without any further assignment. */
    GPIO_InitStruct->Size      = sizeof(GPIO_InitTypeDef);
    GPIO_InitStruct->Version   = GPIO_INIT_VERSION;
    GPIO_InitStruct->Pin       = GPIO_PIN_All;
    GPIO_InitStruct->Mode      = GPIO_MODE_INPUT;               /* Specifies the operating mode for the selected pins */
    GPIO_InitStruct->Pull      = GPIO_NOPULL;                   /* Specifies the Pull-up or Pull-Down activation for the selected pins */
    GPIO_InitStruct->DriveCurrent = GPIO_DRIVE_CURRENT_LOW;        /* Specifies the maximum output drive current for the selected pins */
    GPIO_InitStruct->Alternate = GPIO_AF_Pin_x;                 /* Specifies the peripheral to be connected to the selected pins */
    /* The V1 reserved words belong to the same contract: HAL_GPIO_Init()
       rejects a structure whose reserved words are not zero, so they are part
       of the defaults produced here (a caller that has not cleared the
       structure still obtains a request the driver accepts). */
    GPIO_InitStruct->Reserved[0] = 0U;
    GPIO_InitStruct->Reserved[1] = 0U;
}

/**
  * @brief  Set the specified GPIO pin multiplex function. (NON-BLOCKING)
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @param  GPIO_PinSource: selects the GPIO pin source to be used as multiplex interface.
  *          This parameter can be one of GPIO_PinSourcex where x can be (0..15).
  * @param  GPIO_AF: select the function of the port to be multiplexed.
  *          This parameter can be one of @ref GPIO_Alternate_function_selection.
  * @note   The GPIOH port has 10 channels (Pin0..Pin9) and no MI1SR register:
  *         the multiplex function of its channels 10..15 cannot be configured
  *         (such a request is rejected by the pin availability check).
  * @retval None
  */
void HAL_GPIO_PinAFConfig(GPIO_TypeDef *GPIOx, uint32 GPIO_PinSource, uint8 GPIO_AF)
{
    uint32 temp = 0x00;

    /* Check the parameters. The run time checks mirror the assertions below,
       so that a rejected call performs no register access in every build. The
       pin source and the alternate function are both encoded in three bits, so
       an out of range value must not reach the shift below. */
    if (GPIOx == NULL_PTR)
    {
        return;
    }

    assert_param(IS_GPIO_ALL_INSTANCE(GPIOx));
    assert_param(IS_GPIO_PIN_SOURCE(GPIO_PinSource));
    assert_param(IS_GPIO_PIN_AVAILABLE(GPIOx, ((uint32)0x01) << GPIO_PinSource));
    assert_param(IS_GPIO_AF(GPIO_AF));

    if ((IS_GPIO_ALL_INSTANCE(GPIOx) == 0U) ||
        (IS_GPIO_PIN_SOURCE(GPIO_PinSource) == 0U) ||
        (IS_GPIO_PIN_AVAILABLE(GPIOx, ((uint32)0x01) << GPIO_PinSource) == 0U) ||
        (IS_GPIO_AF(GPIO_AF) == 0U))
    {
        return;
    }

    /* Select different registers according to the size of the pin number value */
    if (GPIO_PinSource < 10U)
    {
        temp = GPIO_READ_REG(GPIOx, MI0SR);
        temp &= ~((uint32)GPIO_MI0SR_AFR0 << (GPIO_PinSource * 3));
        temp |= (uint32)GPIO_AF << (GPIO_PinSource * 3);
        GPIO_WRITE_REG(GPIOx, MI0SR, temp);
    }
    else
    {
        if(GPIOx != GPIOH)
        {
            temp = GPIOx->MI1SR;
            temp &= ~((uint32)GPIO_MI1SR_AFR10 << ((GPIO_PinSource - 10U) * 3));
            temp |= (uint32)GPIO_AF << ((GPIO_PinSource - 10U) * 3);
            GPIOx->MI1SR = temp;
        }
        else
        {
            /* The GPIOH port has no MI1SR register: nothing to do */
        }
    }
}

/**
  * @brief  Configures the GPIO pin interrupt trigger type. (NON-BLOCKING)
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @param  GPIO_Pin: specifies the port bit to be configured.
  *          This parameter can be one of GPIO_PIN_x where x can be (0..15).
  * @param  ITType: GPIO pin interrupt trigger type.
  *          This parameter can be one of @ref GPIO_ITType_TypeDef.
  * @param  NewState: new state of the GPIO interrupt configuration.
  *          This parameter can be: ENABLE or DISABLE.
  * @note   When NewState is DISABLE the interrupt trigger type is cleared and the
  *         interrupt line is masked; when ENABLE the trigger type is programmed and
  *         the interrupt line is unmasked (enabled).
  * @retval None
  */
void HAL_GPIO_ITConfig(GPIO_TypeDef *GPIOx, uint32 GPIO_Pin, GPIO_ITType_TypeDef ITType, FunctionalState NewState)
{
    uint32 pinpos = 0x00;
    uint32 pos = 0x00;
    uint32 currentpin = 0x00;
    uint32 temp = 0x00;

    /* Check the parameters. The run time checks mirror the assertions below,
       so that a rejected call performs no register access in every build. */
    if (GPIOx == NULL_PTR)
    {
        return;
    }

    assert_param(IS_GPIO_ALL_INSTANCE(GPIOx));
    assert_param(IS_GPIO_PIN(GPIO_Pin));
    assert_param(IS_GPIO_PIN_AVAILABLE(GPIOx, GPIO_Pin));
    assert_param(IS_GPIO_ITTYPE(ITType));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    if ((IS_GPIO_ALL_INSTANCE(GPIOx) == 0U) ||
        (IS_GPIO_PIN(GPIO_Pin) == 0U) ||
        (IS_GPIO_PIN_AVAILABLE(GPIOx, GPIO_Pin) == 0U) ||
        (IS_GPIO_ITTYPE(ITType) == 0U) ||
        (IS_FUNCTIONAL_STATE(NewState) == 0U))
    {
        return;
    }

    for (pinpos = 0x00; pinpos < 16U; pinpos++)
    {
        pos = ((uint32)0x01) << pinpos;
        currentpin = GPIO_Pin & pos;

        if (currentpin == pos)
        {
            if (NewState != DISABLE)
            {
                /* Program the trigger type (ITYPE0R) and enable the line (clear IMR mask) */
                temp = GPIO_READ_REG(GPIOx, ITYPE0R);
                temp &= ~(GPIO_ITYPE0R_ITEN0 << (pinpos * 2));
                temp |= (uint32)ITType << (pinpos * 2);
                GPIO_WRITE_REG(GPIOx, ITYPE0R, temp);

                GPIO_CLEAR_REG(GPIOx, IMR, (uint32)0x01 << pinpos);
            }
            else
            {
                /* Clear the trigger type (ITYPE0R) and mask the line (set IMR) */
                temp = GPIO_READ_REG(GPIOx, ITYPE0R);
                temp &= ~((uint32)GPIO_ITYPE0R_ITEN0 << (pinpos * 2));
                GPIO_WRITE_REG(GPIOx, ITYPE0R, temp);

                GPIO_SET_REG(GPIOx, IMR, (uint32)0x01 << pinpos);
            }
        }
        else
        {
            /* Nothing to do */
        }
    }
}

/**
  * @brief  Gets the specified GPIO interrupt status. (NON-BLOCKING)
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @param  GPIO_Pin: specifies the port bit to be checked.
  *          This parameter can be one of GPIO_PIN_x where x can be (0..15).
  * @retval GPIO interrupt status value.
  * @note   The interrupt status register reflects the raw status AND NOT mask:
  *         status = raw && (!mask).
  */
ITStatus HAL_GPIO_GetITStatus(GPIO_TypeDef *GPIOx, uint32 GPIO_Pin)
{
    ITStatus bitstatus = RESET;

    /* Check the parameters. The run time checks mirror the assertions below,
       so that a rejected call performs no register access in every build. */
    if (GPIOx == NULL_PTR)
    {
        return RESET;
    }

    assert_param(IS_GPIO_ALL_INSTANCE(GPIOx));
    assert_param(IS_GPIO_PIN(GPIO_Pin));
    assert_param(IS_GPIO_PIN_AVAILABLE(GPIOx, GPIO_Pin));

    if ((IS_GPIO_ALL_INSTANCE(GPIOx) == 0U) || (IS_GPIO_PIN(GPIO_Pin) == 0U) ||
        (IS_GPIO_PIN_AVAILABLE(GPIOx, GPIO_Pin) == 0U))
    {
        return RESET;
    }

    if ((GPIO_READ_REG(GPIOx, ISR) & GPIO_Pin) != (uint32)RESET)
    {
        bitstatus = SET;
    }
    else
    {
        bitstatus = RESET;
    }

    return bitstatus;
}

/**
  * @brief  Forces the interrupt of the specified GPIO pins. (NON-BLOCKING)
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @param  GPIO_Pin: specifies the port bit to be forced.
  *          This parameter can be one of GPIO_PIN_x where x can be (0..15).
  * @retval None
  */
void HAL_GPIO_ForceINT(GPIO_TypeDef *GPIOx, uint32 GPIO_Pin)
{
    /* Check the parameters. The run time checks mirror the assertions below,
       so that a rejected call performs no register access in every build. */
    if (GPIOx == NULL_PTR)
    {
        return;
    }

    assert_param(IS_GPIO_ALL_INSTANCE(GPIOx));
    assert_param(IS_GPIO_PIN(GPIO_Pin));
    assert_param(IS_GPIO_PIN_AVAILABLE(GPIOx, GPIO_Pin));

    if ((IS_GPIO_ALL_INSTANCE(GPIOx) == 0U) || (IS_GPIO_PIN(GPIO_Pin) == 0U) ||
        (IS_GPIO_PIN_AVAILABLE(GPIOx, GPIO_Pin) == 0U))
    {
        return;
    }

    /* IFR is the interrupt force register: write 1 to raise the request of the
       selected lines and 0 to the others. It is written in a single access
       (no read-modify-write), so a line that was forced earlier is not forced
       again by this call. */
    GPIO_WRITE_REG(GPIOx, IFR, GPIO_Pin);
}

/**
  * @brief  Configures the interrupt mask of the specified GPIO pins. (NON-BLOCKING)
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @param  GPIO_Pin: specifies the port bit to be configured.
  *          This parameter can be one of GPIO_PIN_x where x can be (0..15).
  * @param  NewState: new state of the GPIO interrupt mask.
  *          This parameter can be: ENABLE (unmask the line) or DISABLE (mask the line).
  * @retval None
  */
void HAL_GPIO_ITMaskConfig(GPIO_TypeDef *GPIOx, uint32 GPIO_Pin, FunctionalState NewState)
{
    /* Check the parameters. The run time checks mirror the assertions below,
       so that a rejected call performs no register access in every build. */
    if (GPIOx == NULL_PTR)
    {
        return;
    }

    assert_param(IS_GPIO_ALL_INSTANCE(GPIOx));
    assert_param(IS_GPIO_PIN(GPIO_Pin));
    assert_param(IS_GPIO_PIN_AVAILABLE(GPIOx, GPIO_Pin));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    if ((IS_GPIO_ALL_INSTANCE(GPIOx) == 0U) ||
        (IS_GPIO_PIN(GPIO_Pin) == 0U) ||
        (IS_GPIO_PIN_AVAILABLE(GPIOx, GPIO_Pin) == 0U) ||
        (IS_FUNCTIONAL_STATE(NewState) == 0U))
    {
        return;
    }

    if (NewState == DISABLE)
    {
        /* Mask the interrupt line: IMR bit = 1 */
        GPIO_SET_REG(GPIOx, IMR, GPIO_Pin);
    }
    else
    {
        /* Unmask (enable) the interrupt line: IMR bit = 0 */
        GPIO_CLEAR_REG(GPIOx, IMR, GPIO_Pin);
    }
}

/**
  * @brief  Clears the interrupt pending bits of the specified GPIO pins. (NON-BLOCKING)
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @param  GPIO_Pin: specifies the port bit to be cleared.
  *          This parameter can be one of GPIO_PIN_x where x can be (0..15).
  * @retval None
  */
void HAL_GPIO_ClearITPendingBit(GPIO_TypeDef *GPIOx, uint32 GPIO_Pin)
{
    /* Check the parameters. The run time checks mirror the assertions below,
       so that a rejected call performs no register access in every build. This
       function is interrupt safe: nothing is locked and nothing is awaited. */
    if (GPIOx == NULL_PTR)
    {
        return;
    }

    assert_param(IS_GPIO_ALL_INSTANCE(GPIOx));
    assert_param(IS_GPIO_PIN(GPIO_Pin));
    assert_param(IS_GPIO_PIN_AVAILABLE(GPIOx, GPIO_Pin));

    if ((IS_GPIO_ALL_INSTANCE(GPIOx) == 0U) || (IS_GPIO_PIN(GPIO_Pin) == 0U) ||
        (IS_GPIO_PIN_AVAILABLE(GPIOx, GPIO_Pin) == 0U))
    {
        return;
    }

    /* IRSR is a write-1-to-clear raw status register */
    GPIO_WRITE_REG(GPIOx, IRSR, GPIO_Pin);
}

/**
  * @brief  Writes the whole GPIO port output data value. (NON-BLOCKING)
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @param  PortVal: the value to be written to the output control register (OCR).
  * @retval None
  */
void HAL_GPIO_WritePort(GPIO_TypeDef *GPIOx, uint16 PortVal)
{
    /* Check the parameters. The run time check mirrors the assertion below, so
       that a rejected call performs no register access in every build. */
    if (GPIOx == NULL_PTR)
    {
        return;
    }

    assert_param(IS_GPIO_ALL_INSTANCE(GPIOx));

    if (IS_GPIO_ALL_INSTANCE(GPIOx) == 0U)
    {
        return;
    }

    GPIO_WRITE_REG(GPIOx, OCR, PortVal);
}

/**
  * @brief  Reads the specified GPIO port output data bit. (NON-BLOCKING)
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @param  GPIO_Pin: specifies the port bit to be read.
  *          This parameter can be one of GPIO_PIN_x where x can be (0..15).
  * @retval The output port pin value (GPIO_PIN_SET or GPIO_PIN_RESET).
  */
GPIO_PinState HAL_GPIO_ReadOutputPin(GPIO_TypeDef *GPIOx, uint32 GPIO_Pin)
{
    GPIO_PinState bitstatus = GPIO_PIN_RESET;

    /* Check the parameters. The run time checks mirror the assertions below,
       so that a rejected call performs no register access in every build. */
    if (GPIOx == NULL_PTR)
    {
        return GPIO_PIN_RESET;
    }

    assert_param(IS_GPIO_ALL_INSTANCE(GPIOx));
    assert_param(IS_GPIO_PIN(GPIO_Pin));
    assert_param(IS_GPIO_PIN_AVAILABLE(GPIOx, GPIO_Pin));

    if ((IS_GPIO_ALL_INSTANCE(GPIOx) == 0U) || (IS_GPIO_PIN(GPIO_Pin) == 0U) ||
        (IS_GPIO_PIN_AVAILABLE(GPIOx, GPIO_Pin) == 0U))
    {
        return GPIO_PIN_RESET;
    }

    if ((GPIO_READ_REG(GPIOx, OCR) & GPIO_Pin) != (uint32)GPIO_PIN_RESET)
    {
        bitstatus = GPIO_PIN_SET;
    }
    else
    {
        bitstatus = GPIO_PIN_RESET;
    }

    return bitstatus;
}

/**
  * @brief  Reads the specified GPIO port output data value. (NON-BLOCKING)
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @retval The output data port value.
  */
uint32 HAL_GPIO_ReadOutputPort(GPIO_TypeDef *GPIOx)
{
    /* Check the parameters. The run time check mirrors the assertion below, so
       that a rejected call performs no register access in every build. */
    if (GPIOx == NULL_PTR)
    {
        return 0U;
    }

    assert_param(IS_GPIO_ALL_INSTANCE(GPIOx));

    if (IS_GPIO_ALL_INSTANCE(GPIOx) == 0U)
    {
        return 0U;
    }

    return (uint32)GPIO_READ_REG(GPIOx, OCR);
}

/**
  * @brief  Reads the specified GPIO port input data value. (NON-BLOCKING)
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @retval The input data port value.
  */
uint32 HAL_GPIO_ReadInputPort(GPIO_TypeDef *GPIOx)
{
    /* Check the parameters. The run time check mirrors the assertion below, so
       that a rejected call performs no register access in every build. */
    if (GPIOx == NULL_PTR)
    {
        return 0U;
    }

    assert_param(IS_GPIO_ALL_INSTANCE(GPIOx));

    if (IS_GPIO_ALL_INSTANCE(GPIOx) == 0U)
    {
        return 0U;
    }

    return (uint32)GPIO_READ_REG(GPIOx, IRR);
}

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

#endif /* HAL_GPIO_MODULE_ENABLED */

/*****END OF FILE*****/
