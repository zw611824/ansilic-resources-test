/**
 * @file    CANFD_IT_DRV_012.c
 * @brief   HAL CANFD integration test case 012 (API contract self-check (no partner needed)).
 *
 * HAL library extension case: the reference test plan has no case
 * that exercises the driver contract itself.  This case walks the
 * whole public interface of the CAN FD driver and never needs an
 * external node (the frames of the length checks stay on the
 * internal loopback path).
 *
 * Tested functionality:
 *   HAL_CANFD_StructInit() / HAL_CANFD_Init() / HAL_CANFD_DeInit()
 *   HAL_CANFD_FilterInit()
 *   HAL_CANFD_MspInit() (driver hook, overridden by the case)
 *   HAL_CANFD_GetState() / HAL_CANFD_GetError()
 *   HAL_CANFD_FrameStructInit() / HAL_CANFD_FrameInit()
 *   HAL_CANFD_FilterInit() / HAL_CANFD_ReceiveAll()
 *   HAL_CANFD_Transmit() / HAL_CANFD_LoopbackTransmit()
 *   HAL_CANFD_SetLoopback() / HAL_CANFD_CloseLoopback()
 *   HAL_CANFD_SetSendChannel() / HAL_CANFD_CancelTransmit()
 *   HAL_CANFD_GetReceiveBytes() / HAL_CANFD_GetReceiveData()
 *   HAL_CANFD_GetReceiveInfo() / HAL_CANFD_GetRxFillLevel()
 *   HAL_CANFD_GetRxReadIndex() / HAL_CANFD_SetRxIncReadIndex()
 *   HAL_CANFD_ITConfig() / HAL_CANFD_SetBufferReadyIT() /
 *   HAL_CANFD_TxBufferCancelIT() / HAL_CANFD_GetITStatus() /
 *   HAL_CANFD_ClearITPendingBit()
 *   HAL_CANFD_Sleep() / HAL_CANFD_WakeUp() / HAL_CANFD_SetSnoop() /
 *   HAL_CANFD_CloseSnoop() / HAL_CANFD_SetBusOff()
 *   HAL_CANFD_NormalStatus() / HAL_CANFD_AutoRetransConfig() /
 *   HAL_CANFD_AutoBusOffRecoConfig() / HAL_CANFD_ProtExcConfig() /
 *   HAL_CANFD_BitRateConfig() / HAL_CANFD_TDCConfig()
 *   HAL_CANFD_GetStatus() / HAL_CANFD_GetErrorStatus() /
 *   HAL_CANFD_GetRXErrorCount() / HAL_CANFD_GetTXErrorCount() /
 *   HAL_CANFD_GetTimestampValue() / HAL_CANFD_ClearTimestamp()
 *   HAL_CANFD_GetState() / HAL_CANFD_GetError()
 *   CANFD_LockHandle() / CANFD_UnlockHandle() (shared helpers)
 *   __HAL_CANFD_MODULE_VERSION / IS_CANFD_xxx() macros
 *
 * Test procedure:
 *   ten groups of checks:
 *   1. structure defaults of StructInit / FrameStructInit (plus NULL);
 *   2. run-time rejection of the meta fields of the configuration
 *      (Size / Version / Reserved) and of an unknown instance;
 *   3. successful initialization, register read back and repeated Init;
 *   4. acceptance filter interface: activate / deactivate / illegal command /
 *      NULL configuration / ReceiveAll;
 *   5. frame configuration: identifier range and the BRS / EIDE bits;
 *   6. transmit parameter protection and the discrete CAN FD length set on the
 *      loopback path;
 *   7. NULL handle protection of the whole API surface;
 *   8. shared lock helpers (double lock reports BUSY);
 *   9. de-initialization is idempotent, re-initialization works;
 *  10. exported version and validation macros.
 *
 * Expected behaviour:
 *   - every contract check prints [PASS] and the summary reports
 *     "failures = 0";
 *   - a rejected configuration leaves the handle in RESET and never touches a
 *     register;
 *   - a rejected call of a void interface is visible through the error code or
 *     through the unchanged registers;
 *   - the case can be executed repeatedly (it does not rely on the bus).
 *
 * @note Clock tree: the CAN FD controller is clocked by
 *       CANCLK = PLLR / CANX2DIV / 2 (SMU formula).  This suite keeps the
 *       vendor configuration of the CAN FD reference cases: VCO 160 MHz,
 *       PLLR = 1 -> CANCLK = 80 MHz, so the bit timing of the reference cases
 *       (10 tq prescaler, 16 tq per arbitration bit = 500 kbit/s and 2 tq
 *       prescaler, 8 tq per data bit = 5 Mbit/s) is reproduced unchanged.
 *       The core therefore runs at 160 MHz in this suite (AXI4Bus3 80 MHz,
 *       APBBus0/APBBus1 40 MHz); the other HAL suites use 180 MHz and cannot
 *       reach a CANCLK inside the 8..80 MHz window with a 500 kbit/s timing.
 *
 * @note Only HAL library APIs are used.  The one exception is the source of
 *       case 011, whose whole purpose is to reproduce the reference scenario
 *       "configure the GPIO first, then enable the peripheral clock".
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* CAN FD instance under test */
#define TEST_CANFD                  CANFD3
#define TEST_CANFD_IRQn             CANFD3_IRQn
#define TEST_CANFD_CLK_ENABLE()     __HAL_SMU_CANFD3_CLK_ENABLE()
#define TEST_CANFD_FORCE_RESET()    __HAL_SMU_CANFD3_FORCE_RESET()
#define TEST_CANFD_RELEASE_RESET()  __HAL_SMU_CANFD3_RELEASE_RESET()

/* Port / pins of the instance (from the chip IO map) */
#define TEST_CAN_TX_GPIO            GPIOC
#define TEST_CAN_TX_PIN             GPIO_PIN_7
#define TEST_CAN_TX_SOURCE          GPIO_PinSource7
#define TEST_CAN_RX_PIN             GPIO_PIN_8
#define TEST_CAN_RX_SOURCE          GPIO_PinSource8
#define TEST_CAN_AF                 GPIO_AF_CAN3
#define TEST_CAN_GPIO_CLK_ENABLE()  __HAL_SMU_GPIOC_CLK_ENABLE()

/* Bit timing of the reference cases: 500 kbit/s arbitration,
 * 5 Mbit/s data phase, CANCLK = 80 MHz */
#define TEST_APBRPR_VALUE           (10U)   /* 80 MHz / 10 = 8 MHz tq clock     */
#define TEST_APTS1_VALUE            (11U)   /* + 1 sync = 16 tq -> 500 kbit/s   */
#define TEST_APTS2_VALUE            (4U)
#define TEST_APSJW_VALUE            (2U)
#define TEST_DPBRPR_VALUE           (2U)    /* 80 MHz / 2 = 40 MHz tq clock     */
#define TEST_DPTS1_VALUE            (5U)    /* + 1 sync = 8 tq -> 5 Mbit/s      */
#define TEST_DPTS2_VALUE            (2U)
#define TEST_DPSJW_VALUE            (2U)

/* Number of bytes used to exercise the discrete CAN FD length set */
#define TEST_DATA_BYTES_CLASSIC     (8U)
#define TEST_DATA_BYTES_FD          (64U)

/* Frame identifiers used by the reference cases (the acceptance filters
 * accept 0x147 standard, 0x147 extended and 0x258 / 0x269) */
#define TEST_STD_ID                 (0x147U)
#define TEST_EXT_ID                 (0x147U)
#define TEST_FILTER_ID_1            (0x28E00000U)   /* standard 0x147 */
#define TEST_FILTER_ID_2            (0x4B000000U)   /* standard 0x258 */
#define TEST_FILTER_ID_3            (0x6D200000U)   /* standard 0x269 */
#define TEST_FILTER_ID_4            (0x0008028EU)   /* extended 0x0000147 */
#define TEST_FILTER_MASK_STD        (0xFFE00000U)
#define TEST_FILTER_MASK_EXT        (0xFFEFFFFEU)

/* Bounded waits: the cases must never hang when the external CAN partner is
 * absent, they report the timeout instead */
#define TEST_WAIT_FRAME_MS          (2000U)   /* one frame on the bus         */
#define TEST_WAIT_BUSOFF_MS         (5000U)   /* bus-off recovery             */
#define TEST_WAIT_WAKEUP_MS         (10000U)  /* wait for the partner frame   */
#define TEST_TX_TIMEOUT_MS          (100U)    /* wait for normal mode         */

/* Private variables ---------------------------------------------------------*/
static CANFD_HandleTypeDef hcanfd_dev;      /*!< CAN FD handle                */
static HAL_SMU_HandleTypeDef   hsmu_clk;    /*!< SMU handle (lock / state)    */
static SMU_ClocksTypeDef       g_clocks;    /*!< clock tree snapshot          */

static uint32 failures = 0U;                /*!< failed check counter         */

static volatile uint32 tx_ok_count   = 0U;  /*!< TXOK interrupt counter       */
static volatile uint32 rx_ok_count   = 0U;  /*!< RXOK interrupt counter       */
static volatile uint32 busoff_count  = 0U;  /*!< BSOFF interrupt counter      */
static volatile uint32 wakeup_count  = 0U;  /*!< WKUP  interrupt counter      */
static volatile uint32 error_count   = 0U;  /*!< EERROR interrupt counter     */

static uint8 tx_data[TEST_DATA_BYTES_FD];   /*!< transmit payload             */
static uint8 rx_data[TEST_DATA_BYTES_FD];   /*!< receive payload              */

static volatile uint32 rx_len = 0U;         /*!< length of the last rx frame  */

/* Payload pattern of the reference cases */
static const uint8 test_pattern[TEST_DATA_BYTES_FD] =
{
    0x11U, 0x12U, 0x13U, 0x14U, 0x15U, 0x16U, 0x17U, 0x18U,
    0x21U, 0x22U, 0x23U, 0x24U, 0x25U, 0x26U, 0x27U, 0x28U,
    0x31U, 0x32U, 0x33U, 0x34U, 0x35U, 0x36U, 0x37U, 0x38U,
    0x41U, 0x42U, 0x43U, 0x44U, 0x45U, 0x46U, 0x47U, 0x48U,
    0x51U, 0x52U, 0x53U, 0x54U, 0x55U, 0x56U, 0x57U, 0x58U,
    0x61U, 0x62U, 0x63U, 0x64U, 0x65U, 0x66U, 0x67U, 0x68U,
    0x71U, 0x72U, 0x73U, 0x74U, 0x75U, 0x76U, 0x77U, 0x78U,
    0x81U, 0x82U, 0x83U, 0x84U, 0x85U, 0x86U, 0x87U, 0x88U
};

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void Can_ClockEnable(void);
static void Can_GpioInit(void);
static void Can_InitStruct_Default(CANFD_InitTypeDef *init);
static void Can_SetAcceptanceFilters(void);
static HAL_StatusTypeDef Can_Setup(void);
static void Can_FrameInit(uint32 TxBuffer, uint32 Protocol, uint32 Format, uint32 Id);
static void Can_CopyPattern(uint32 Length);
static uint32 Can_WaitRxFlag(uint32 TimeoutMs);
static void Can_CheckPayload(const char *what, uint32 Length);
static void Check(const char *name, int ok);
static void Summary(void);

/**
 * @brief  Accumulate one check result.
 * @param  name: name of the checked item.
 * @param  ok:   non zero when the check passed.
 * @retval None
 */
static void Check(const char *name, int ok)
{
    printf("  %-52s [%s]\r\n", name, (ok != 0) ? "PASS" : "FAIL");

    if (ok == 0)
    {
        failures++;
    }
}

/**
 * @brief  Print the summary line of the case.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("summary : failures = %u\r\n", PRINT_U32(failures));
}


/**
 * @brief  Copy the reference pattern into the transmit buffer.
 * @param  Length: number of bytes to copy (0..64).
 * @retval None
 */
static void Can_CopyPattern(uint32 Length)
{
    uint32 i;

    for (i = 0U; i < Length; i++)
    {
        tx_data[i] = test_pattern[i];
    }
}

/**
 * @brief  Compare the received payload with the reference pattern.
 * @param  what:   text printed in front of the check name.
 * @param  Length: number of bytes that must match.
 * @retval None
 */
static void Can_CheckPayload(const char *what, uint32 Length)
{
    uint32 i;
    int equal = 1;
    char name[96];

    for (i = 0U; i < Length; i++)
    {
        if (rx_data[i] != test_pattern[i])
        {
            equal = 0;
            break;
        }
    }

    (void)snprintf(name, sizeof(name), "%s : payload matches the reference", what);
    Check(name, equal);

    printf("  %s : received", what);
    for (i = 0U; i < Length; i++)
    {
        printf(" %x", (unsigned int)rx_data[i]);
    }
    printf("\r\n");
}

/**
 * @brief  Configure a transmit buffer frame (identifier, format, type and
 *         protocol of the reference cases).
 * @param  TxBuffer: transmit buffer index, 0..31.
 * @param  Protocol: CANFD_PROTOCOL_CAN / CANFD_PROTOCOL_CANFD /
 *                   CANFD_PROTOCOL_CANFD_BRS.
 * @param  Format:   CANFD_FORMAT_STANDARD / CANFD_FORMAT_EXTENDED.
 * @param  Id:       frame identifier.
 * @retval None
 */
static void Can_FrameInit(uint32 TxBuffer, uint32 Protocol, uint32 Format, uint32 Id)
{
    CANFD_TXFrameTypeDef frame;

    HAL_CANFD_FrameStructInit(&frame);
    frame.CANFD_TX_PROTOCOL = Protocol;
    frame.CANFD_TX_FORMAT   = Format;
    frame.CANFD_TX_TYPE     = CANFD_TYPE_DATA;
    frame.CANFD_Frame_ID    = Id;

    HAL_CANFD_FrameInit(&hcanfd_dev, TxBuffer, &frame);
}


/**
 * @brief  Poll the receive FIFO until a message arrives.
 * @param  TimeoutMs: bounded wait in milliseconds.
 * @retval 1 when a message is pending, 0 on timeout.
 */
static uint32 Can_WaitRxFlag(uint32 TimeoutMs)
{
    uint32 tickstart = HAL_GetTick();

    while (HAL_CANFD_GetRxFillLevel(&hcanfd_dev) == 0U)
    {
        if ((HAL_GetTick() - tickstart) > TimeoutMs)
        {
            return 0U;
        }
    }

    return 1U;
}

/**
 * @brief  Enable the clock gate of the CAN FD instance under test and release
 *         its reset.
 * @note   HAL_CANFD_MspInit() is a weak empty function in the driver, so the
 *         low level bring-up (clock gate, reset, pin multiplexing) is done by
 *         the test case.  The reset bit is SET = released / CLEAR = reset
 *         asserted, as for every other instance of the SMU block.
 * @param  None
 * @retval None
 */
static void Can_ClockEnable(void)
{
    TEST_CAN_GPIO_CLK_ENABLE();
    TEST_CANFD_CLK_ENABLE();

    TEST_CANFD_FORCE_RESET();
    TEST_CANFD_RELEASE_RESET();
    TEST_CAN_GPIO_CLK_ENABLE();
}

/**
 * @brief  Configure the CAN TX / RX pins.
 * @note   Both pins are configured as alternate function push-pull: the
 *         transmit pin is driven by the controller and the receive pin is an
 *         input of the controller, and the direction is selected by the
 *         peripheral, not by the GPIO mode.  The receive pin keeps an internal
 *         pull-up so that a floating bus does not produce a permanent dominant
 *         level.
 * @param  None
 * @retval None
 */
static void Can_GpioInit(void)
{
    GPIO_InitTypeDef gpio;

    __HAL_CLEAR_STRUCT(&gpio);
    gpio.Size         = sizeof(gpio);
    gpio.Version      = GPIO_INIT_VERSION;
    gpio.Mode         = GPIO_MODE_AF_PP;
    gpio.Pull         = GPIO_NOPULL;
    gpio.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    gpio.Alternate    = TEST_CAN_AF;

    gpio.Pin = TEST_CAN_TX_PIN;
    HAL_GPIO_Init(TEST_CAN_TX_GPIO, &gpio);

    /* The transceiver drives RXD, so the RX pin must stay an input with a
     * pull-up; only the AF number selects the CAN function
     * (a push-pull output here would fight the transceiver and the
     * controller would never see a frame). */
    gpio.Mode = GPIO_MODE_INPUT;
    gpio.Pull = GPIO_PULLUP;
    gpio.Pin  = TEST_CAN_RX_PIN;
    HAL_GPIO_Init(TEST_CAN_TX_GPIO, &gpio);

    HAL_GPIO_PinAFConfig(TEST_CAN_TX_GPIO, TEST_CAN_TX_SOURCE, TEST_CAN_AF);
    HAL_GPIO_PinAFConfig(TEST_CAN_TX_GPIO, TEST_CAN_RX_SOURCE, TEST_CAN_AF);
}

/**
 * @brief  Fill the CAN FD init structure with the bit timing of the reference
 *         cases (500 kbit/s arbitration, 5 Mbit/s data phase).
 * @note   The driver takes register encodings, and the encoding of every
 *         prescaler / time segment is "value - 1"; the CANFD_xxx_VALUE()
 *         helpers apply that rule, so the numbers below are the physical
 *         time quantum counts of the reference cases.
 * @param  init: pointer to the structure to fill.
 * @retval None
 */
static void Can_InitStruct_Default(CANFD_InitTypeDef *init)
{
    HAL_CANFD_StructInit(init);

    init->CANFD_SRR         = CANFD_SRR_ENABLE;
    init->CANFD_APBRPR      = CANFD_APBRPR_PRESCALER(TEST_APBRPR_VALUE);
    init->CANFD_APBTR_APTS1 = CANFD_APBTR_TS1_VALUE(TEST_APTS1_VALUE);
    init->CANFD_APBTR_APTS2 = CANFD_APBTR_TS2_VALUE(TEST_APTS2_VALUE);
    init->CANFD_APBTR_APSJW = CANFD_APBTR_SJW_VALUE(TEST_APSJW_VALUE);
    init->CANFD_DPBRPR      = CANFD_DPBRPR_PRESCALER(TEST_DPBRPR_VALUE);
    init->CANFD_DPBTR_DPTS1 = CANFD_DPBTR_TS1_VALUE(TEST_DPTS1_VALUE);
    init->CANFD_DPBTR_DPTS2 = CANFD_DPBTR_TS2_VALUE(TEST_DPTS2_VALUE);
    init->CANFD_DPBTR_DPSJW = CANFD_DPBTR_SJW_VALUE(TEST_DPSJW_VALUE);
}

/**
 * @brief  Install the four acceptance filters of the reference cases.
 * @param  None
 * @retval None
 */
static void Can_SetAcceptanceFilters(void)
{
    CANFD_FilterConfigTypeDef filter;

    __HAL_CLEAR_STRUCT(&filter);
    filter.CANFD_FilterCmd = CANFD_ENABLE;

    filter.CANFD_FilterNumber = 0U;
    filter.CANFD_FilterMask   = TEST_FILTER_MASK_STD;
    filter.CANFD_FilterID     = TEST_FILTER_ID_1;
    (void)HAL_CANFD_FilterInit(&hcanfd_dev, &filter);

    filter.CANFD_FilterNumber = 1U;
    filter.CANFD_FilterMask   = TEST_FILTER_MASK_STD;
    filter.CANFD_FilterID     = TEST_FILTER_ID_2;
    (void)HAL_CANFD_FilterInit(&hcanfd_dev, &filter);

    filter.CANFD_FilterNumber = 2U;
    filter.CANFD_FilterMask   = TEST_FILTER_MASK_STD;
    filter.CANFD_FilterID     = TEST_FILTER_ID_3;
    (void)HAL_CANFD_FilterInit(&hcanfd_dev, &filter);

    filter.CANFD_FilterNumber = 3U;
    filter.CANFD_FilterMask   = TEST_FILTER_MASK_EXT;
    filter.CANFD_FilterID     = TEST_FILTER_ID_4;
    (void)HAL_CANFD_FilterInit(&hcanfd_dev, &filter);
}

/**
 * @brief  Initialize the CAN FD instance with the reference bit timing and
 *         install the acceptance filters.
 * @param  None
 * @retval HAL_OK on success, the driver status otherwise.
 */
static HAL_StatusTypeDef Can_Setup(void)
{
    CANFD_InitTypeDef init;
    HAL_StatusTypeDef status;

    __HAL_CLEAR_STRUCT(&hcanfd_dev);
    hcanfd_dev.Instance = TEST_CANFD;

    Can_InitStruct_Default(&init);
    hcanfd_dev.Init = init;

    status = HAL_CANFD_Init(&hcanfd_dev);
    if (status == HAL_OK)
    {
        Can_SetAcceptanceFilters();
    }

    return status;
}


/**
 * @brief  Override of the weak driver hook: bring the CAN FD instance up
 *         (clock gate, reset, pin multiplexing) once the configuration is
 *         known.
 * @note   LOCK-06: the driver calls this hook BEFORE it takes the handle lock,
 *         so calling HAL_GPIO_Init() from here is safe.
 * @param  hcanfd: CAN FD handle.
 * @retval None
 */
void HAL_CANFD_MspInit(CANFD_HandleTypeDef *hcanfd)
{
    if (hcanfd != &hcanfd_dev)
    {
        return;
    }

    Can_ClockEnable();
    Can_GpioInit();
}

/**
 * @brief  Configure the system clock tree using the HAL SMU driver.
 * @note   The CAN FD bit timing needs a CANCLK inside 8..80 MHz; with the
 *         vendor PLLR = 1 and CANX2DIV = 1 the controller runs at 80 MHz,
 *         which is exactly the frequency of the CAN FD reference cases.
 *         The core therefore runs at 160 MHz (VCO 160 MHz).
 * @note   Order: the bus dividers are written while the system clock is still
 *         the power-on source (FIRC), then the flash controller is programmed
 *         and the clock is switched by HAL_SMU_OscConfig().  Writing the
 *         dividers after the switch would leave the buses at their reset
 *         dividers for a moment at the new core clock.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   osc;
    SMU_ClockInitTypeDef clk;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the console USART needs AXI4Bus3 / APBBus0) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* 1.2 V / 2.5 V LDO trimming (the PMU API is gated on the handle state,
     * so the handle must be initialized first) */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Bus dividers first: the system clock is still FIRC here */
    clk.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV1;   /* 80 MHz */
    clk.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;    /* 40 MHz */
    clk.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;    /* 40 MHz */
    clk.CANX2CLKDiv    = SMU_CANX2CLK_DIV1;      /* CANCLK = PLLR / 2 = 80 MHz */
    (void)HAL_SMU_ClockConfig(&hsmu_clk, &clk);

    /* PLL: VCO 160 MHz, PLLR = 1 -> CANCLKx2 source 160 MHz */
    osc.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    osc.FIRCState            = SMU_FIRC_ON;
    osc.FIRCCalibrationValue = 0x00U;
    osc.PLL.PLLState         = SMU_PLL_ON;
    osc.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    osc.PLL.PLLDivR          = 0x01U;
    osc.PLL.PLLDivQ          = 0x01U;
    osc.PLL.PLLDivN          = 0x14U;
    osc.PLL.PLLDivF          = 0xA0U;
    osc.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    (void)HAL_SMU_OscConfig(&hsmu_clk, &osc, SMU_TIMEOUT_DEFAULT);
    (void)HAL_SMU_GetClocksFreq(&g_clocks);
}

/**
 * @brief  CAN FD interrupt handler of the instance under test.
 * @note   The driver has no interrupt dispatcher and no callbacks, so the
 *         application owns the interrupt service routine: it reads the pending
 *         sources, services them and clears them through the interrupt safe
 *         HAL_CANFD_ClearITPendingBit() (that interface takes no handle lock
 *         and applies no state gate, so it is usable from the ISR even while a
 *         task owns the handle).
 * @note   The receive FIFO is drained here, which is the intended use of the
 *         lock free read path HAL_CANFD_GetReceiveData().
 * @param  None
 * @retval None
 */
void CANFD3_IRQ_Handler(void)
{
    if (HAL_CANFD_GetITStatus(&hcanfd_dev, CANFD_IT_ERXOK) != 0U)
    {
        rx_ok_count++;
        rx_len = HAL_CANFD_GetReceiveData(&hcanfd_dev, rx_data);
        HAL_CANFD_ClearITPendingBit(&hcanfd_dev, CANFD_IT_ERXOK);
    }

    if (HAL_CANFD_GetITStatus(&hcanfd_dev, CANFD_IT_ETXOK) != 0U)
    {
        tx_ok_count++;
        HAL_CANFD_ClearITPendingBit(&hcanfd_dev, CANFD_IT_ETXOK);
    }

    if (HAL_CANFD_GetITStatus(&hcanfd_dev, CANFD_IT_EBSOFF) != 0U)
    {
        busoff_count++;
        HAL_CANFD_ClearITPendingBit(&hcanfd_dev, CANFD_IT_EBSOFF);
    }

    if (HAL_CANFD_GetITStatus(&hcanfd_dev, CANFD_IT_EWKUP) != 0U)
    {
        wakeup_count++;
        HAL_CANFD_ClearITPendingBit(&hcanfd_dev, CANFD_IT_EWKUP);
    }

    if (HAL_CANFD_GetITStatus(&hcanfd_dev, CANFD_IT_EERROR) != 0U)
    {
        error_count++;
        HAL_CANFD_ClearITPendingBit(&hcanfd_dev, CANFD_IT_EERROR);
    }

    /* An event that is not serviced above would keep the line asserted: clear
     * every remaining source of the enable register as a safety net */
    HAL_CANFD_ClearITPendingBit(&hcanfd_dev, CANFD_IT_ALL);
}

/*****END OF FILE*****/

int main(void)
{
    CANFD_InitTypeDef init;
    CANFD_TXFrameTypeDef frame;
    CANFD_FilterConfigTypeDef filter;
    CANFD_HandleTypeDef bad;
    CANFD_RXInfoTypeDef info;
    CANFD_InitTypeDef init_saved;
    uint32 afr_before;
    uint32 id_before;
    uint32 len;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (VCO 160 MHz, CANCLK 80 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);

    printf("\r\n=== CANFD_IT_DRV_012 : API contract self-check (no partner needed) ===\r\n");
    printf("clock    : core %u Hz, CANCLK %u Hz\r\n",
           PRINT_U32(SystemCoreClock), PRINT_U32(g_clocks.CANCLKx2_Frequency));
    printf("NOTE     : no external partner is needed; the bus traffic of this\r\n");
    printf("           case stays inside the loopback path\r\n");

    /* =====================================================================
     * Group 1: structure defaults
     * ===================================================================== */
    printf("-- Group 1: structure defaults\r\n");

    __HAL_CLEAR_STRUCT(&init);
    HAL_CANFD_StructInit(&init);
    Check("StructInit : Size = sizeof(CANFD_InitTypeDef)",
          (init.Size == sizeof(CANFD_InitTypeDef)));
    Check("StructInit : Version = CANFD_INIT_VERSION",
          (init.Version == CANFD_INIT_VERSION));
    Check("StructInit : CANFD_SRR = software reset request",
          (init.CANFD_SRR == CANFD_SRR_RESET));
    Check("StructInit : every prescaler / segment encodes 1 tq",
          ((init.CANFD_APBRPR == 0U) && (init.CANFD_APBTR_APTS1 == 0U) &&
           (init.CANFD_APBTR_APTS2 == 0U) && (init.CANFD_APBTR_APSJW == 0U) &&
           (init.CANFD_DPBRPR == 0U) && (init.CANFD_DPBTR_DPTS1 == 0U) &&
           (init.CANFD_DPBTR_DPTS2 == 0U) && (init.CANFD_DPBTR_DPSJW == 0U)));
    Check("StructInit : Reserved[] cleared",
          ((init.Reserved[0] == 0U) && (init.Reserved[1] == 0U)));

    __HAL_CLEAR_STRUCT(&frame);
    HAL_CANFD_FrameStructInit(&frame);
    Check("FrameStructInit : classic CAN, standard, data, id 0",
          ((frame.CANFD_TX_PROTOCOL == CANFD_PROTOCOL_CAN) &&
           (frame.CANFD_TX_FORMAT == CANFD_FORMAT_STANDARD) &&
           (frame.CANFD_TX_TYPE == CANFD_TYPE_DATA) &&
           (frame.CANFD_Frame_ID == 0U)));

    HAL_CANFD_StructInit(NULL_PTR);
    HAL_CANFD_FrameStructInit(NULL_PTR);
    Check("StructInit / FrameStructInit : NULL tolerated", 1);

    /* =====================================================================
     * Group 2: the meta fields of the configuration are validated before the
     *          first register access (the value ranges themselves are guarded
     *          by assert_param, they are not exercised here so that the case
     *          also runs in a USE_FULL_ASSERT build)
     * ===================================================================== */
    printf("-- Group 2: run-time validation of the meta fields\r\n");

    __HAL_CLEAR_STRUCT(&hcanfd_dev);
    hcanfd_dev.Instance = TEST_CANFD;

    Can_InitStruct_Default(&init_saved);

    init = init_saved;
    init.Size = 0U;
    hcanfd_dev.Init = init;
    Check("Init : Size = 0 rejected, state stays RESET",
          ((HAL_CANFD_Init(&hcanfd_dev) == HAL_ERROR) &&
           (HAL_CANFD_GetState(&hcanfd_dev) == HAL_CANFD_STATE_RESET)));

    init = init_saved;
    init.Version = 0U;
    hcanfd_dev.Init = init;
    Check("Init : Version = 0 rejected, state stays RESET",
          ((HAL_CANFD_Init(&hcanfd_dev) == HAL_ERROR) &&
           (HAL_CANFD_GetState(&hcanfd_dev) == HAL_CANFD_STATE_RESET)));

    init = init_saved;
    init.Reserved[0] = 1U;
    hcanfd_dev.Init = init;
    Check("Init : Reserved[0] not zero rejected",
          (HAL_CANFD_Init(&hcanfd_dev) == HAL_ERROR));

    init = init_saved;
    init.Reserved[1] = 0x80U;
    hcanfd_dev.Init = init;
    Check("Init : Reserved[1] not zero rejected",
          (HAL_CANFD_Init(&hcanfd_dev) == HAL_ERROR));

    Check("Init : NULL handle rejected", (HAL_CANFD_Init(NULL_PTR) == HAL_ERROR));

    __HAL_CLEAR_STRUCT(&bad);
    bad.Instance = (CANFD_TypeDef *)0x40000000U;
    bad.Init     = init_saved;
    Check("Init : unknown instance rejected", (HAL_CANFD_Init(&bad) == HAL_ERROR));

    hcanfd_dev.Init = init_saved;

    /* =====================================================================
     * Group 3: successful initialization, state machine and register read back
     * ===================================================================== */
    printf("-- Group 3: initialization and state machine\r\n");

    if (Can_Setup() != HAL_OK)
    {
        printf("HAL_CANFD_Init failed, error = 0x%08X\r\n",
               PRINT_U32(HAL_CANFD_GetError(&hcanfd_dev)));
        Summary();
        while (1)
        {
        }
    }

    Check("Init : state = READY",
          (HAL_CANFD_GetState(&hcanfd_dev) == HAL_CANFD_STATE_READY));
    Check("Init : error code = NONE",
          (HAL_CANFD_GetError(&hcanfd_dev) == HAL_CANFD_ERROR_NONE));
    Check("Init : APBRPR register matches the configuration",
          (TEST_CANFD->APBRPR == CANFD_APBRPR_PRESCALER(TEST_APBRPR_VALUE)));
    Check("Init : APBTR register carries TS1 / TS2 / SJW",
          (TEST_CANFD->APBTR ==
           (uint32)((CANFD_APBTR_TS1_VALUE(TEST_APTS1_VALUE) << CANFD_APBTR_TS1_Pos) |
                    (CANFD_APBTR_TS2_VALUE(TEST_APTS2_VALUE) << CANFD_APBTR_TS2_Pos) |
                    (CANFD_APBTR_SJW_VALUE(TEST_APSJW_VALUE) << CANFD_APBTR_SJW_Pos))));
    Check("Init : DPBTR register carries TS1 / TS2 / SJW",
          (TEST_CANFD->DPBTR ==
           (uint32)((CANFD_DPBTR_TS1_VALUE(TEST_DPTS1_VALUE) << CANFD_DPBTR_DP_TS1_Pos) |
                    (CANFD_DPBTR_TS2_VALUE(TEST_DPTS2_VALUE) << CANFD_DPBTR_DP_TS2_Pos) |
                    (CANFD_DPBTR_SJW_VALUE(TEST_DPSJW_VALUE) << CANFD_DPBTR_DP_SJW_Pos))));
    Check("Init : controller enabled (SRR.CEN)",
          ((TEST_CANFD->SRR & CANFD_SRR_CEN) != 0U));
    Check("Init : the prescaler field is only replaced in DPBRPR (TDC kept)",
          ((TEST_CANFD->DPBRPR & ~((uint32)CANFD_DPBRPR_DP_BRP)) ==
           (TEST_CANFD->DPBRPR & ~((uint32)CANFD_DPBRPR_DP_BRP))));

    Check("Init : a second initialization is accepted",
          (HAL_CANFD_Init(&hcanfd_dev) == HAL_OK));
    Check("Init : state still READY after the second initialization",
          (HAL_CANFD_GetState(&hcanfd_dev) == HAL_CANFD_STATE_READY));

    /* =====================================================================
     * Group 4: acceptance filter interface
     * ===================================================================== */
    printf("-- Group 4: acceptance filters\r\n");

    Check("FilterInit : filters 0..3 active after the setup",
          ((TEST_CANFD->AFR & 0x0FU) == 0x0FU));

    __HAL_CLEAR_STRUCT(&filter);
    filter.CANFD_FilterNumber = 5U;
    filter.CANFD_FilterMask   = TEST_FILTER_MASK_STD;
    filter.CANFD_FilterID     = TEST_FILTER_ID_1;
    filter.CANFD_FilterCmd    = CANFD_ENABLE;
    afr_before = TEST_CANFD->AFR;
    Check("FilterInit : filter 5 accepted",
          ((HAL_CANFD_FilterInit(&hcanfd_dev, &filter) == HAL_OK) &&
           ((TEST_CANFD->AFR & (1UL << 5U)) != 0U)));
    Check("FilterInit : the previously active filters are untouched",
          ((TEST_CANFD->AFR & 0x0FU) == (afr_before & 0x0FU)));
    Check("FilterInit : the mask / ID pair was written",
          ((TEST_CANFD->Rxfiltering[5].AFMR == TEST_FILTER_MASK_STD) &&
           (TEST_CANFD->Rxfiltering[5].AFIR == TEST_FILTER_ID_1)));

    filter.CANFD_FilterCmd = CANFD_DISABLE;
    Check("FilterInit : filter 5 can be deactivated",
          ((HAL_CANFD_FilterInit(&hcanfd_dev, &filter) == HAL_OK) &&
           ((TEST_CANFD->AFR & (1UL << 5U)) == 0U)));

    filter.CANFD_FilterNumber = 6U;
    filter.CANFD_FilterCmd    = 2U;
    afr_before = TEST_CANFD->AFR;
    Check("FilterInit : illegal command rejected, AFR unchanged",
          ((HAL_CANFD_FilterInit(&hcanfd_dev, &filter) == HAL_ERROR) &&
           (TEST_CANFD->AFR == afr_before)));

    Check("FilterInit : NULL configuration rejected",
          (HAL_CANFD_FilterInit(&hcanfd_dev, NULL_PTR) == HAL_ERROR));

    HAL_CANFD_ReceiveAll(&hcanfd_dev, CANFD_ENABLE);
    Check("ReceiveAll ENABLE : every filter active",
          (TEST_CANFD->AFR == 0xFFFFFFFFU));
    HAL_CANFD_ReceiveAll(&hcanfd_dev, CANFD_DISABLE);
    Check("ReceiveAll DISABLE : every filter inactive",
          (TEST_CANFD->AFR == 0U));

    Can_SetAcceptanceFilters();
    Check("filters restored for the following groups",
          ((TEST_CANFD->AFR & 0x0FU) == 0x0FU));

    /* =====================================================================
     * Group 5: frame configuration
     * ===================================================================== */
    printf("-- Group 5: frame configuration\r\n");

    Can_FrameInit(0U, CANFD_PROTOCOL_CAN, CANFD_FORMAT_STANDARD, TEST_STD_ID);
    Check("FrameInit : standard identifier written",
          (((TEST_CANFD->TxMessage[0].TB_ID >> CANFD_TB_ID_ID_Pos) & 0x7FFU) == TEST_STD_ID));

    Can_FrameInit(1U, CANFD_PROTOCOL_CANFD, CANFD_FORMAT_EXTENDED, TEST_EXT_ID);
    Check("FrameInit : extended frame sets the IDE bit",
          ((TEST_CANFD->TxMessage[1].TB_ID & CANFD_TB_ID_IDE) != 0U));

    Can_FrameInit(2U, CANFD_PROTOCOL_CANFD_BRS, CANFD_FORMAT_EXTENDED, TEST_EXT_ID);
    Check("FrameInit : bit rate switch flag set in the length word",
          ((TEST_CANFD->TxMessage[2].TB_DLC & CANFD_TB_DLC_BRS) != 0U));

    /* An identifier wider than the format allows is refused without touching
     * the buffer (the interface has no return value) */
    id_before = TEST_CANFD->TxMessage[0].TB_ID;
    Can_FrameInit(0U, CANFD_PROTOCOL_CAN, CANFD_FORMAT_STANDARD, 0x800U);
    Check("FrameInit : standard identifier > 0x7FF leaves the buffer unchanged",
          (TEST_CANFD->TxMessage[0].TB_ID == id_before));

    Can_FrameInit(3U, CANFD_PROTOCOL_CAN, CANFD_FORMAT_EXTENDED, TEST_EXT_ID);
    id_before = TEST_CANFD->TxMessage[3].TB_ID;
    Can_FrameInit(3U, CANFD_PROTOCOL_CAN, CANFD_FORMAT_EXTENDED, 0x20000000U);
    Check("FrameInit : extended identifier > 29 bit leaves the buffer unchanged",
          (TEST_CANFD->TxMessage[3].TB_ID == id_before));

    /* =====================================================================
     * Group 6: transmit parameter protection and the discrete length set.
     *          The frames are sent through the loopback path, so the case
     *          produces no bus traffic and needs no acknowledge.
     * ===================================================================== */
    printf("-- Group 6: transmit parameters (loopback path)\r\n");

    HAL_CANFD_SetLoopback(&hcanfd_dev);
    delay_ms(10U);
    Check("loopback mode entered", (HAL_CANFD_GetStatus(&hcanfd_dev, CANFD_STATUS_LBACK) != 0U));

    Can_CopyPattern(TEST_DATA_BYTES_FD);

    Check("Transmit : NULL payload with a non-zero length rejected",
          (HAL_CANFD_LoopbackTransmit(&hcanfd_dev, 0U, NULL_PTR, CANFD_BYTES_8,
                                      TEST_TX_TIMEOUT_MS) == HAL_ERROR));
    Check("Transmit : NULL handle rejected",
          (HAL_CANFD_LoopbackTransmit(NULL_PTR, 0U, tx_data, CANFD_BYTES_8,
                                      TEST_TX_TIMEOUT_MS) == HAL_ERROR));

    /* 12 bytes and 64 bytes belong to the discrete CAN FD length set */
    Can_FrameInit(0U, CANFD_PROTOCOL_CANFD, CANFD_FORMAT_EXTENDED, TEST_EXT_ID);
    Check("Transmit : CAN FD frame with 12 bytes accepted",
          (HAL_CANFD_LoopbackTransmit(&hcanfd_dev, 0U, tx_data, CANFD_BYTES_12,
                                      TEST_TX_TIMEOUT_MS) == HAL_OK));
    Check("loopback : the 12 byte frame came back",
          Can_WaitRxFlag(TEST_WAIT_FRAME_MS));
    len = HAL_CANFD_GetReceiveData(&hcanfd_dev, rx_data);
    Check("loopback : the 12 byte frame reports 12 bytes", (len == CANFD_BYTES_12));

    Can_FrameInit(1U, CANFD_PROTOCOL_CANFD_BRS, CANFD_FORMAT_EXTENDED, TEST_EXT_ID);
    Check("Transmit : CAN FD + BRS frame with 64 bytes accepted",
          (HAL_CANFD_LoopbackTransmit(&hcanfd_dev, 1U, tx_data, CANFD_BYTES_64,
                                      TEST_TX_TIMEOUT_MS) == HAL_OK));
    Check("loopback : the 64 byte frame came back",
          Can_WaitRxFlag(TEST_WAIT_FRAME_MS));
    len = HAL_CANFD_GetReceiveData(&hcanfd_dev, rx_data);
    Check("loopback : the 64 byte frame reports 64 bytes", (len == CANFD_BYTES_64));
    Can_CheckPayload("loopback frame", CANFD_BYTES_64);

    HAL_CANFD_CloseLoopback(&hcanfd_dev);
    delay_ms(10U);
    Check("loopback mode left", (HAL_CANFD_GetStatus(&hcanfd_dev, CANFD_STATUS_LBACK) == 0U));

    /* =====================================================================
     * Group 7: NULL handle protection of the whole API surface
     * ===================================================================== */
    printf("-- Group 7: NULL handle protection\r\n");

    Check("DeInit(NULL) rejected", (HAL_CANFD_DeInit(NULL_PTR) == HAL_ERROR));
    Check("GetState(NULL) = RESET", (HAL_CANFD_GetState(NULL_PTR) == HAL_CANFD_STATE_RESET));
    Check("GetError(NULL) = NONE", (HAL_CANFD_GetError(NULL_PTR) == HAL_CANFD_ERROR_NONE));
    Check("GetSendCmpStatus(NULL) = 0", (HAL_CANFD_GetSendCmpStatus(NULL_PTR, 1U) == 0U));
    Check("GetRxFillLevel(NULL) = 0", (HAL_CANFD_GetRxFillLevel(NULL_PTR) == 0U));
    Check("GetRxReadIndex(NULL) = 0", (HAL_CANFD_GetRxReadIndex(NULL_PTR) == 0U));
    Check("GetReceiveBytes(NULL) = 0", (HAL_CANFD_GetReceiveBytes(NULL_PTR) == 0U));
    Check("GetReceiveData(NULL) = 0", (HAL_CANFD_GetReceiveData(NULL_PTR, rx_data) == 0U));
    Check("GetITStatus(NULL) = 0", (HAL_CANFD_GetITStatus(NULL_PTR, CANFD_IT_ERXOK) == 0U));
    Check("GetStatus(NULL) = 0", (HAL_CANFD_GetStatus(NULL_PTR, CANFD_STATUS_NORMAL) == 0U));
    Check("GetRXErrorCount(NULL) = 0", (HAL_CANFD_GetRXErrorCount(NULL_PTR) == 0U));
    Check("GetTXErrorCount(NULL) = 0", (HAL_CANFD_GetTXErrorCount(NULL_PTR) == 0U));
    Check("GetTimestampValue(NULL) = 0", (HAL_CANFD_GetTimestampValue(NULL_PTR) == 0U));
    Check("NormalStatus(NULL) rejected", (HAL_CANFD_NormalStatus(NULL_PTR, 0U) == HAL_ERROR));

    HAL_CANFD_Sleep(NULL_PTR);
    HAL_CANFD_WakeUp(NULL_PTR);
    HAL_CANFD_SetLoopback(NULL_PTR);
    HAL_CANFD_CloseLoopback(NULL_PTR);
    HAL_CANFD_SetSnoop(NULL_PTR);
    HAL_CANFD_CloseSnoop(NULL_PTR);
    HAL_CANFD_SetBusOff(NULL_PTR);
    HAL_CANFD_SetSendChannel(NULL_PTR, 1U);
    HAL_CANFD_CancelTransmit(NULL_PTR, 1U);
    HAL_CANFD_SetRxIncReadIndex(NULL_PTR);
    HAL_CANFD_ClearTimestamp(NULL_PTR);
    HAL_CANFD_ITConfig(NULL_PTR, CANFD_IT_ALL, CANFD_ENABLE);
    HAL_CANFD_SetBufferReadyIT(NULL_PTR, 1U, CANFD_ENABLE);
    HAL_CANFD_TxBufferCancelIT(NULL_PTR, 1U, CANFD_ENABLE);
    HAL_CANFD_ClearITPendingBit(NULL_PTR, CANFD_IT_ALL);
    HAL_CANFD_ReceiveAll(NULL_PTR, CANFD_ENABLE);
    HAL_CANFD_AutoRetransConfig(NULL_PTR, CANFD_ENABLE);
    HAL_CANFD_AutoBusOffRecoConfig(NULL_PTR, CANFD_ENABLE);
    HAL_CANFD_ProtExcConfig(NULL_PTR, CANFD_ENABLE);
    HAL_CANFD_BitRateConfig(NULL_PTR, CANFD_ENABLE);
    HAL_CANFD_TDCConfig(NULL_PTR, CANFD_ENABLE, 0U);
    HAL_CANFD_GetReceiveInfo(NULL_PTR, &info);
    Check("void interfaces tolerate a NULL handle", 1);

    /* =====================================================================
     * Group 8: shared lock helpers
     * ===================================================================== */
    printf("-- Group 8: shared lock helpers\r\n");

    Check("CANFD_LockHandle : idle handle accepted",
          (CANFD_LockHandle(&hcanfd_dev, 10U) == HAL_OK));
    Check("CANFD_LockHandle : a second lock reports BUSY",
          (CANFD_LockHandle(&hcanfd_dev, 10U) == HAL_BUSY));
    CANFD_UnlockHandle(&hcanfd_dev);
    Check("CANFD_UnlockHandle : the handle can be taken again",
          (CANFD_LockHandle(&hcanfd_dev, 10U) == HAL_OK));
    CANFD_UnlockHandle(&hcanfd_dev);
    Check("lock / unlock : the handle is free again",
          (CANFD_LockHandle(&hcanfd_dev, 0U) == HAL_OK));
    CANFD_UnlockHandle(&hcanfd_dev);

    /* =====================================================================
     * Group 9: de-initialization is idempotent and re-initialization works
     * ===================================================================== */
    printf("-- Group 9: de-initialization and re-initialization\r\n");

    Check("DeInit : accepted", (HAL_CANFD_DeInit(&hcanfd_dev) == HAL_OK));
    Check("DeInit : state = RESET",
          (HAL_CANFD_GetState(&hcanfd_dev) == HAL_CANFD_STATE_RESET));
    Check("DeInit : mode register cleared", (TEST_CANFD->MSR == 0U));
    Check("DeInit : every interrupt source disabled", (TEST_CANFD->IER == 0U));
    Check("DeInit : acceptance filter control cleared", (TEST_CANFD->AFR == 0U));
    Check("DeInit : a second DeInit is harmless",
          (HAL_CANFD_DeInit(&hcanfd_dev) == HAL_OK));

    if (Can_Setup() != HAL_OK)
    {
        printf("re-initialization failed, error = 0x%08X\r\n",
               PRINT_U32(HAL_CANFD_GetError(&hcanfd_dev)));
    }
    Check("re-initialization after DeInit : state = READY",
          (HAL_CANFD_GetState(&hcanfd_dev) == HAL_CANFD_STATE_READY));

    /* =====================================================================
     * Group 10: exported version and validation macros
     * ===================================================================== */
    printf("-- Group 10: macros\r\n");

    Check("__HAL_CANFD_MODULE_VERSION = 0x0100",
          (__HAL_CANFD_MODULE_VERSION == 0x0100U));
    Check("CANFD_INIT_VERSION = 0x0100", (CANFD_INIT_VERSION == 0x0100U));
    Check("CANFD_IT_ALL covers the defined sources only (0x7F7F)",
          (CANFD_IT_ALL == 0x00007F7FU));
    Check("IS_CANFD_ALL_PERIPH : CANFD0..CANFD3 accepted",
          ((IS_CANFD_ALL_PERIPH(CANFD0) != 0) && (IS_CANFD_ALL_PERIPH(CANFD1) != 0) &&
           (IS_CANFD_ALL_PERIPH(CANFD2) != 0) && (IS_CANFD_ALL_PERIPH(CANFD3) != 0)));
    Check("IS_CANFD_TB_NUMBER : 31 accepted / 32 rejected",
          ((IS_CANFD_TB_NUMBER(31U) != 0) && (IS_CANFD_TB_NUMBER(32U) == 0)));
    Check("IS_CANFD_FILTER_SPACE : 31 accepted / 32 rejected",
          ((IS_CANFD_FILTER_SPACE(31U) != 0) && (IS_CANFD_FILTER_SPACE(32U) == 0)));
    Check("IS_CANFD_DATA_LENGTH : the discrete FD set is accepted",
          ((IS_CANFD_DATA_LENGTH(0U) != 0) && (IS_CANFD_DATA_LENGTH(8U) != 0) &&
           (IS_CANFD_DATA_LENGTH(12U) != 0) && (IS_CANFD_DATA_LENGTH(64U) != 0)));
    Check("IS_CANFD_SRR : the four legal combinations are accepted",
          ((IS_CANFD_SRR(0U) != 0) && (IS_CANFD_SRR(CANFD_SRR_RESET) != 0) &&
           (IS_CANFD_SRR(CANFD_SRR_ENABLE) != 0) &&
           (IS_CANFD_SRR(CANFD_SRR_RESET | CANFD_SRR_ENABLE) != 0)));
    Check("IS_CANFD_PROTOCOL : CAN / CANFD / CANFD_BRS accepted",
          ((IS_CANFD_PROTOCOL(CANFD_PROTOCOL_CAN) != 0) &&
           (IS_CANFD_PROTOCOL(CANFD_PROTOCOL_CANFD) != 0) &&
           (IS_CANFD_PROTOCOL(CANFD_PROTOCOL_CANFD_BRS) != 0)));

    Summary();

    printf("-- idle (reset the board to run the checks again)\r\n");
    while (1)
    {
        if (HAL_CANFD_GetRxFillLevel(&hcanfd_dev) != 0U)
        {
            (void)HAL_CANFD_GetReceiveData(&hcanfd_dev, rx_data);
        }
    }
}

