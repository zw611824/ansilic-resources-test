# AS32x601 HAL 库编译参数配置指南

> 适用版本：as32x601.ld V1.4（2026/10/08）、as32x601.icf V1.2、HAL 库全部 34 个源文件
> 验证环境：xPack RISC-V GCC 15.2.0，裸机与 RTOS（USE_RTOS=1）双模式均 ExitCode=0、零警告
> 配套链接脚本：`4_HAL_LIBRARY\sys\gcc\as32x601.ld`

---

## 1. 工具链与目录约定

本文以下列变量指代常用路径（按你的实际环境替换）：

| 变量 | 路径 |
|------|------|
| `GCC` | `E:\001_work\002_umc\002_vscode_workspace\AS32x601_LED\.eide\xpack-riscv-none-elf-gcc-15.2.0-1-win32-x64\xpack-riscv-none-elf-gcc-15.2.0-1\bin\riscv-none-elf-gcc.exe` |
| `HAL` | `E:\001_work\002_umc\004_AS32x601_HAL\as32x601_hal_develop\4_HAL_LIBRARY` |
| `LDSCRIPT` | `%HAL%\sys\gcc\as32x601.ld` |
| `CONF_DIR` | 存放 `as32x601_hal_conf.h` 的目录（见 §4） |

> 提示：同目录下还有 `riscv-none-elf-nm.exe`、`riscv-none-elf-readelf.exe`、`riscv-none-elf-objcopy.exe` 等工具，用于验证产物。

---

## 2. 架构 / ABI 参数（必选）

AS32x601 为 RISC-V 32 位内核，以下两个参数**必须**同时使用：

```
-march=rv32imafdc_zicsr_zaamo_zalrsc
-mabi=ilp32d
```

| 参数 | 含义 |
|------|------|
| `rv32imafdc` | RV32I 基础整数 + M 乘法/除法 + A 原子 + F/D 单双精度浮点 + C 压缩指令 |
| `_zicsr` | CSR 指令（读/写控制状态寄存器） |
| `_zaamo` | A 扩展的原子内存操作 |
| `_zalrsc` | 加载保留/存储条件（LR/SC） |
| `ilp32d` | 32 位指针 + 双精度浮点调用约定 |

> 若编译选项与链接脚本 / libgcc 的架构不匹配，会出现 `relocation truncated to fit` 或 undefined instruction 问题。

---

## 3. 编译选项（C 源文件）

### 3.1 优化级别

| 选项 | 用途 |
|------|------|
| `-O0` | 不优化，调试最友好（推荐调试阶段） |
| `-O1` / `-O2` | 常规优化（推荐发布阶段） |
| `-Os` | 侧重代码体积（Flash 紧张时） |

### 3.2 调试信息

| 选项 | 用途 |
|------|------|
| `-g` | 标准 DWARF 调试信息 |
| `-g3` | 最大调试信息（含宏展开，配合 `-O0` 可单步宏） |

> 调试信息放在 ELF 的 `.debug_*` 段，不占芯片 Flash（`objcopy -O binary` 时被剥离）。

### 3.3 警告选项（推荐全开）

```
-Wall -Wextra -Wshadow
```

| 选项 | 含义 |
|------|------|
| `-Wall` | 常用警告集合 |
| `-Wextra` | 额外警告（未使用参数、隐式转换等） |
| `-Wshadow` | 局部变量遮蔽外层变量警告 |

> 更严格可追加：`-Werror`（警告视为错误）、`-Wconversion`、`-Wpointer-arith`。
> 语法检查可用：`-fsyntax-only`（只检查不产出目标文件）。

### 3.4 展开栈回溯表（Unwind Table）

消除 Flash 中的孤立 `.eh_frame` 段（约 40 字节），**编译阶段**：

```
-fno-asynchronous-unwind-tables -fno-unwind-tables
```

| 选项 | 作用 |
|------|------|
| `-fno-asynchronous-unwind-tables` | 不生成异步异常展开表（`.eh_frame`） |
| `-fno-unwind-tables` | 不生成同步展开表 |

> **为什么还要在链接脚本 /DISCARD/ 加一条？**
> `-fno-*` 只作用于本工程 C 源码；链接 `-lgcc` 时预编译的 `libgcc.a`（如 `_udivdi3.o`）自带 40 字节 `.eh_frame`，编译选项无法消除。
> 因此 as32x601.ld V1.2 起在 `/DISCARD/` 中追加了 `*(.eh_frame) *(.eh_frame.*)` 兜底删除（V1.4 沿用）。
> 两层配合后 readelf 检查结果为：`.eh_frame` 完全消失。

---

## 4. 头文件包含路径（-I）

```
-I"%CONF_DIR%"  -I"%HAL%\peripherals\inc"  -I"%HAL%\sys"  -I"%HAL%\riscv"
```

| 路径 | 内容 |
|------|------|
| `%CONF_DIR%` | **你的工程目录**，放 `as32x601_hal_conf.h`（从模板复制，见下）。必须放在最前面 |
| `%HAL%\peripherals\inc` | 全部外设驱动头文件（`as32x601_hal_*.h`） |
| `%HAL%\sys` | `as32x601.h`、`as32x601_addrmap.h` 等设备层头文件 |
| `%HAL%\riscv` | `core_riscv.h`（RISC-V 内核寄存器定义） |

### 4.1 配置文件 `as32x601_hal_conf.h`

- 模板位置：`%HAL%\peripherals\inc\as32x601_hal_conf_template.h`
- 使用方式：复制到你的工程目录并改名 `as32x601_hal_conf.h`，再按需修改：
  - **模块开关**：`#define HAL_XXX_MODULE_ENABLED`（如 `HAL_SPI_MODULE_ENABLED`、`HAL_DMA_MODULE_ENABLED` 等），启用需要的驱动；未启用的驱动编译时被排除
  - **RTOS 模式**：`#define USE_RTOS 1`（见 §7）

> 启动汇编（`as32x601_startup_gcc.S` / `as32x601_trapentry_gcc.S`）通过 `__has_include` 自动探测 `as32x601_hal_conf.h`，因此 `%CONF_DIR%` 必须在 `-I` 首位。

---

## 5. 链接选项

### 5.1 基本链接命令

```
"%GCC%" -march=rv32imafdc_zicsr_zaamo_zalrsc -mabi=ilp32d ^
    -nostartfiles -nostdlib ^
    -Wl,--no-warn-rwx-segments -Wl,-Map,"out.map" ^
    -T "%LDSCRIPT%" -o "out.elf" <目标文件...> -lgcc
```

| 参数 | 含义 |
|------|------|
| `-nostartfiles` | 不用编译器自带启动文件（使用 `as32x601_startup_gcc.S`） |
| `-nostdlib` | 不链接标准 C 库（裸机无 libc） |
| `-T %LDSCRIPT%` | 指定链接脚本 `as32x601.ld` |
| `-Wl,-Map,"out.map"` | 生成内存映射文件（排查段布局用） |
| `-Wl,--no-warn-rwx-segments` | 屏蔽 RISC-V 上 RWX 段警告（Flash 只读+RAM 可读写，正常） |
| `-lgcc` | **必加**：RV32 的 64 位除法 `__udivdi3` 等由 libgcc 软实现提供 |

### 5.2 用 `--defsym` 覆盖链接脚本参数

`as32x601.ld` 支持通过 `-Wl,--defsym=` 覆盖区域与栈/堆大小，无需改脚本：

#### 内存区域（Flash / RAM）

```
-Wl,--defsym=__FLASH_ORIGIN=0x01000000
-Wl,--defsym=__FLASH_LENGTH=0x00200000
-Wl,--defsym=__RAM_ORIGIN=0x20000000
-Wl,--defsym=__RAM_LENGTH=0x00080000
```

| 符号 | 默认值 | 含义 |
|------|--------|------|
| `__FLASH_ORIGIN` | `0x01000000` | P-Flash 起始地址 |
| `__FLASH_LENGTH` | `0x00200000` | P-Flash 大小（2 MB） |
| `__RAM_ORIGIN` | `0x20000000` | SRAM 起始地址 |
| `__RAM_LENGTH` | `0x00080000` | SRAM 大小（512 KB） |

> 注意符号名是小写下划线前缀（`__FLASH_ORIGIN` 等），不是 `-D` 宏，必须用 `-Wl,--defsym=` 传入。

#### 栈 / 堆大小

```
-Wl,--defsym=__stack_size=0x4000
-Wl,--defsym=__heap_size=0x1000
```

| 符号 | 默认值 | 含义 |
|------|--------|------|
| `__stack_size` | `0x00004000`（16 KB） | 任务栈大小，栈从 RAM 顶向下生长 |
| `__heap_size` | `0x00000000`（0 = 禁用） | 堆大小，堆从 `.bss` 末尾向上生长 |

> 约束：`heap_end` 不得超过 `stack_bottom`（`__ram_end - __stack_size`）；脚本已用 `ASSERT` 自动检查，重叠时直接链接失败。
> 符号用小写以匹配工具链约定与 IDE builder 的 LD_FLAGS。

---

## 6. 链接脚本布局约定（as32x601.ld）

| 段 | 区域 | 说明 |
|----|------|------|
| `.text` | Flash | 代码（`KEEP(*(.init))` 复位入口、`KEEP(*(.text.entry))` 陷阱入口） |
| `.rodata` | Flash | 只读常量 |
| `.data` | Flash 装载 → RAM 运行 | LMA/VMA 分离，启动代码拷贝 `_data_load.._data_end`；开头收小数据类 `.sdata`/`.srodata`（gp 窗口内） |
| `.RamFunc` | Flash 装载 → RAM 运行（代码） | `__RAM_FUNC`（`as32x601_hal_def.h`）标记的函数段：与 `.data` 同属一个 Flash 装载块，随启动拷贝进入 RAM，因此确实从 RAM 执行；当前库内无使用者，段为空 |
| `.bss` | RAM | 零初始化（含 `.sbss`、`.bss.isr_stack`） |
| `.noinit` | RAM（清零区之外） | 保留数据：放在 `_bss_end` 之后，启动清零循环不会清除 |
| `.heap` | RAM | 可选堆（`__heap_size`） |
| `.stack` | RAM 顶 | 栈（`__stack_size`） |
| `/DISCARD/` | — | 丢弃 `.comment`/`.note`/`.riscv.attributes`/`.eh_frame` |

> 区域与栈/堆大小由 `PROVIDE()` 给出默认值，因此 `-Wl,--defsym=` 覆盖生效（见 5.2）。
> 脚本末尾有一组链接期不变量（`ASSERT`）：复位入口地址、被拷贝区间长度与字长、栈边界对齐与 RAM 越界、
> `.noinit` 是否落在清零区间之外；任一违反即链接失败（例如栈/堆放不下会直接报 `stack leaves the RAM region`）。

关键导出符号（供启动/中断汇编使用）：

| 符号 | 含义 |
|------|------|
| `_stack_top` / `_stack_bottom` | 栈顶（初始 sp）/ 栈底（防护） |
| `_data_load` / `_data_start` / `_data_end` | `.data` 装载地址 / 运行地址范围 |
| `_bss_start` / `_bss_end` | 零初始化区范围 |
| `__global_pointer$` | GP 指针（`.sdata + 0x800`，小数据寻址） |
| `_isr_stack_top` / `_isr_stack_bottom` | RTOS 模式中断栈（位于 `.bss.isr_stack`） |
| `__ram_end` | RAM 末尾（`ORIGIN(RAM)+LENGTH(RAM)`，堆/栈边界检查） |

---

## 7. RTOS 模式配置

### 7.1 使能 RTOS

在 `as32x601_hal_conf.h` 中：

```c
#define USE_RTOS 1
```

### 7.2 提供互斥锁实现

HAL 库只声明不实现以下三个函数，**用户必须提供实现**（真实 RTOS 或测试 stub）：

```c
HAL_MutexTypeDef HAL_MutexCreate(void);
HAL_StatusTypeDef HAL_MutexAcquire(HAL_MutexTypeDef Mutex, uint32 Timeout);
HAL_StatusTypeDef HAL_MutexRelease(HAL_MutexTypeDef Mutex);
```

测试用最小实现（`mutex_stub.c`）：

```c
#include "as32x601_hal.h"

HAL_MutexTypeDef HAL_MutexCreate(void)
{
    static uint32 dummy = 0U;
    return (HAL_MutexTypeDef)(&dummy);
}

HAL_StatusTypeDef HAL_MutexAcquire(HAL_MutexTypeDef Mutex, uint32 Timeout)
{
    (void)Mutex; (void)Timeout;
    return HAL_OK;
}

HAL_StatusTypeDef HAL_MutexRelease(HAL_MutexTypeDef Mutex)
{
    (void)Mutex;
    return HAL_OK;
}
```

### 7.3 RTOS 模式下的段布局差异

- 中断栈 `.bss.isr_stack`（2 KB）被 `*(.bss.*)` 正确归集到 `.bss`
- `_isr_stack_top` = `_bss_end` = `_stack_bottom`（栈紧接中断栈）
- 链接时仍需要 `-lgcc` 与完整 `as32x601_startup_gcc.S` / `as32x601_trapentry_gcc.S`

---

## 8. 完整命令示例

### 8.1 编译单个源文件（示例：SPI 驱动）

```
"%GCC%" -march=rv32imafdc_zicsr_zaamo_zalrsc -mabi=ilp32d -O0 -g3 ^
    -Wall -Wextra -Wshadow -fno-asynchronous-unwind-tables -fno-unwind-tables ^
    -I"%CONF_DIR%" -I"%HAL%\peripherals\inc" -I"%HAL%\sys" -I"%HAL%\riscv" ^
    -c "%HAL%\peripherals\src\as32x601_hal_spi.c" -o "as32x601_hal_spi.o"
```

### 8.2 编译汇编文件（startup / trapentry）

```
"%GCC%" -march=rv32imafdc_zicsr_zaamo_zalrsc -mabi=ilp32d -O0 -g3 ^
    -I"%CONF_DIR%" -I"%HAL%\peripherals\inc" -I"%HAL%\sys" -I"%HAL%\riscv" ^
    -c "%HAL%\sys\gcc\as32x601_startup_gcc.S" -o "as32x601_startup_gcc.o"
```

> 汇编文件无需 unwind 选项（不含 C 栈帧展开信息）。

### 8.3 链接（裸机，默认区域/栈）

```
"%GCC%" -march=rv32imafdc_zicsr_zaamo_zalrsc -mabi=ilp32d -nostartfiles -nostdlib ^
    -Wl,--no-warn-rwx-segments -Wl,-Map,"out.map" ^
    -T "%LDSCRIPT%" -o "out.elf" <全部 .o 文件> -lgcc
```

### 8.4 链接（带自定义区域与栈/堆覆盖）

```
"%GCC%" -march=rv32imafdc_zicsr_zaamo_zalrsc -mabi=ilp32d -nostartfiles -nostdlib ^
    -Wl,--no-warn-rwx-segments -Wl,-Map,"out.map" ^
    -Wl,--defsym=__FLASH_ORIGIN=0x01000000 -Wl,--defsym=__FLASH_LENGTH=0x00200000 ^
    -Wl,--defsym=__RAM_ORIGIN=0x20000000   -Wl,--defsym=__RAM_LENGTH=0x00080000 ^
    -Wl,--defsym=__stack_size=0x8000       -Wl,--defsym=__heap_size=0x1000 ^
    -T "%LDSCRIPT%" -o "out.elf" <全部 .o 文件> -lgcc
```

### 8.5 链接（RTOS 模式，追加 mutex 实现）

在上面的 `<全部 .o 文件>` 中追加编译好的 `mutex_stub.o`（或你的真实 RTOS 互斥锁实现），其余不变。

---

## 9. 产物验证方法

### 9.1 段布局（确认无孤立段、无 .eh_frame）

```
"%GCC_DIR%\riscv-none-elf-readelf.exe" -S out.elf
```

期望结果（V1.2 起无 `.eh_frame`）：

```
[ 1] .text      PROGBITS 01000000 ... AX   <- Flash
[ 2] .rodata    PROGBITS 01017cec ... A    <- Flash
[ 3] .data      PROGBITS 20000000 ... WA   <- RAM（LMA 在 Flash）
[ 4] .bss       NOBITS   20000008 ... WA   <- RAM
[ 5] .stack     NOBITS   ...         WA   <- RAM 顶
```

### 9.2 关键符号（布局正确性）

```
"%GCC_DIR%\riscv-none-elf-nm.exe" -n out.elf
```

核对：`_data_load`（Flash 地址）< `_data_start`（RAM 地址）表示 LMA/VMA 分离正确；
`_stack_top` 必须 ≤ `__ram_end`（0x20080000），且 `_stack_top` 与 `_bss_end` 之间无重叠。
（说明：`__RAM_FUNC` 需链接脚本同时具备"RAM 放置 + Flash 装载镜像 + 启动拷贝"三要素；as32x601.ld V1.4 与 as32x601.icf V1.2 均已落实，缺任一要素则该宏静默失效——函数留在 Flash 继续执行。）

### 9.3 转出烧录文件（可选）

```
"%GCC_DIR%\riscv-none-elf-objcopy.exe" -O binary out.elf out.bin
```

---

## 10. 常见问题排查

| 现象 | 原因 / 处理 |
|------|------------|
| `undefined symbol '__HEAP_SIZE'` | 链接脚本引用了未定义的大写符号。V1.2 已改用小写 `__heap_size`/`__stack_size` |
| `undefined reference to __udivdi3` | 缺少 `-lgcc`（64 位除法软实现） |
| `relocation truncated to fit` | `-march`/`-mabi` 与链接脚本/libgcc 不匹配，或 Flash/RAM 区域定义过小 |
| RTOS 链接报 `undefined HAL_MutexCreate` | 未提供互斥锁实现（见 §7.2） |
| ELF 出现孤立 `.eh_frame` 段 | 未加 `-fno-asynchronous-unwind-tables -fno-unwind-tables`，且旧版脚本未在 `/DISCARD/` 丢弃；升级 as32x601.ld 至 V1.2 即可 |
| 汇编找不到 `as32x601_hal_conf.h` | `%CONF_DIR%` 未放在 `-I` 首位（启动汇编用 `__has_include` 探测） |
| RWX segment 警告 | 正常，用 `-Wl,--no-warn-rwx-segments` 屏蔽 |

---

## 11. 验证环境参考

本指南中的命令已在以下环境全量验证：

- 编译器：xPack RISC-V GCC 15.2.0
- 覆盖：全部 33 个 HAL 源文件 + `as32x601_startup_gcc.S` + `as32x601_trapentry_gcc.S` + `main.c`
- 模式：裸机（`USE_RTOS=0`）与 RTOS（`USE_RTOS=1` + mutex_stub）
- 编译：`-Wall -Wextra -Wshadow -fno-asynchronous-unwind-tables -fno-unwind-tables`，零警告
- 链接：`-nostartfiles -nostdlib -lgcc`，ExitCode=0
- 布局：`.eh_frame` 完全消失；`_data_load`(Flash)→`_data_start`(RAM) LMA/VMA 正确；
  `__global_pointer$`=`.sdata+0x800`；栈/堆无重叠，`_stack_top` 未溢出 RAM
