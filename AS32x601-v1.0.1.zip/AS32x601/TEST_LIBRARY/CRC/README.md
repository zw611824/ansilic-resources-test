# CRC 应用与测试参考

供 skill 按需求检索 AS32x601 HAL CRC 示例。关键词：循环冗余校验、校验和、多项式、输入/输出反转、分块计算、分段累加、ID 寄存器、句柄锁。共有 6 个独立用例。

HAL 依据：[头文件](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_crc.h)、[实现](../../HAL_LIBRARY/peripherals/src/as32x601_hal_crc.c)。原测试工程的 4_HAL_LIBRARY 未提供，尚不能确认原始链接版本；文中标出的源码与当前 SDK 差异须先解决再迁移。


## 实例与相关资源

本模块不单独列出外部通信引脚组。按实际功能核对实例、时钟、中断、内存或数据通路；关联 GPIO、定时器或其他外设时，再读取对应分支的引脚资料。具体资源与案例配置见下文。

## 生成前需确认的参数

已有工程、板级资料或用户已明确的值直接复用。仅对影响本次实现的缺失选择使用参数卡询问并等待答复；案例配置不能代替实际接线或应用参数。

| 参数 | 需要核对或确认的内容 |
|---|---|
| 算法参数 | 多项式、初始值、反射、最终异或及位宽 |
| 输入约定 | 数据范围、字节序、喂入宽度和对照结果 |

## 按需求选择

| 用户需求 / 检索关键词 | 推荐用例 | 选择条件 / 需要补充的逻辑 |
|---|---|---|
| 对单个字求 CRC；验证一组多项式与反转参数 | [001](CRC_IT_DRV_001.c) | 最小单字模板。示例扫 8 种多项式 × 4 种输入反转；应用只保留目标配置即可 |
| 一次性计算内存块（字 / 半字 / 字节） | [002](CRC_IT_DRV_002.c) | 有 `HAL_CRC_CalcWordBlockCRC()`、`HAL_CRC_CalcHalfBlockCRC()`、`HAL_CRC_CalcByteBlockCRC()`；长度按元素个数传入 |
| 分多段累积同一报文；流式校验 | [003](CRC_IT_DRV_003.c) | 用 `HAL_CRC_Reset()` + 多次 `HAL_CRC_Accumulate()`；示例证明分段结果等于整块 `HAL_CRC_Calculate()` |
| 复位累加器、读写 8 位 ID 寄存器、读取当前结果 | [004](CRC_IT_DRV_004.c) | `HAL_CRC_Reset()` 只重装初值，不预装 `CRC_DR`；ID 寄存器需要自己的读写流程 |
| 核对配置是否被接受、错误码、非法句柄拒绝路径 | [005](CRC_IT_DRV_005.c) | 防御性自检，不是应用模板。可用来确认 `HAL_CRC_ERROR_INVALID_PARAM` 与状态门控 |
| 句柄生命周期、MSP 回调、锁助手、三种数据宽度 | [006](CRC_IT_DRV_006.c) | 生命周期/并发契约自检；应用侧只借初始化顺序和宽度设置 |
| 与某通信标准（如 CRC-32/ISO-HDLC）逐项对齐 | 无直接完整模板 | 参照 001 的配置原语，按标准核对 `CRC_PolySize`、`CRC_INIT`、`CRC_XOR`、输入/输出反转和喂数宽度；示例只做内部一致性检查，未与外部标准向量比对 |

## 实现要点与案例配置

- CRC 为单实例、无中断、无 DMA、无引脚；只有 APBBus1 时钟门控与复位，控制过程是阻塞式同步计算。
- 初始化顺序：`HAL_Init()` → 系统时钟（示例 PLL 180 MHz，APBBus1 22.5 MHz）→ `delay_init()` / 串口 → `__HAL_CLEAR_STRUCT(&hcrc_dev)`、`Instance = CRC` → `HAL_CRC_StructInit()` 填默认值后改字段 → 设置句柄字段 `InputDataFormat`（`HAL_CRC_INPUTDATA_FORMAT_BYTES/HALFWORDS/WORDS`，不是 `CRC_InitTypeDef` 字段）→ `HAL_CRC_Init()`。时钟与复位在弱函数 `HAL_CRC_MspInit()` 中完成（示例经 `__HAL_SMU_APBBUS1_CLK_ENABLE()`、`__HAL_SMU_CRC_CLK_ENABLE()`、`__HAL_SMU_CRC_FORCE_RESET/RELEASE_RESET()`）。
- 长度单位：块接口的 `BufferLength` 是“该接口宽度下的元素个数”（字块按 32 位字、半字块按 16 位半字、字节块按字节）；`HAL_CRC_Accumulate()` / `HAL_CRC_Calculate()` 按句柄已配置的 `InputDataFormat` 解释长度。
- 复位语义：`HAL_CRC_Reset()` 只置 `CRC_CR` 的 RESET 位，配置字段保持不变；`CRC_DR` 保留上次结果，需再喂一个元素才能观察到从初值重算。
- 证据边界：这些用例的 PASS/FAIL 均由软件比较和寄存器回读产生；能证明当前驱动在目标配置下的内部一致性、配置读写与状态门控，不能证明与外部协议标准或具体对端设备的 CRC 一致。无需示波器等外部测量。

## 验证方法与适用边界

- 各用例独立准备句柄；多段计算共享硬件累加状态。Init 重写配置，Reset 重装累加初值，按目标操作选择，不合并不同测试 main。
- 取值接口的错误哨兵可能与合法结果 0 重合，须结合状态/错误码判断，不能仅凭结果为 0 判失败。锁助手测试不等于 RTOS 并发验证。
- `HAL_CRC_SetIDRegister()` 只写 8 位；`MspInit()` 中的复位脉冲会把它清回 0，重新初始化后要重写。
- 输入反转模式会随喂数宽度改变结果；块接口必须与相同宽度的 `HAL_CRC_Accumulate()` 对照，不能跨宽度直接比较。
- CRC 只有一个实例，驱动内部按锁串行化；多任务共享时仍需自行保证调用顺序，本组用例未在 RTOS 下验证。

## 按接口与辅助宏检索

| 接口 / 宏 | 参考用例 |
|---|---|
| `HAL_CRC_StructInit` | [001](CRC_IT_DRV_001.c)、[005](CRC_IT_DRV_005.c) |
| `HAL_CRC_Init` / `HAL_CRC_DeInit` | [001](CRC_IT_DRV_001.c)、[004](CRC_IT_DRV_004.c)、[006](CRC_IT_DRV_006.c) |
| `HAL_CRC_CalcCRC` | [001](CRC_IT_DRV_001.c)、[002](CRC_IT_DRV_002.c)、[004](CRC_IT_DRV_004.c) |
| `HAL_CRC_CalcWordBlockCRC` / `HAL_CRC_CalcHalfBlockCRC` / `HAL_CRC_CalcByteBlockCRC` | [002](CRC_IT_DRV_002.c)、[005](CRC_IT_DRV_005.c) |
| `HAL_CRC_Accumulate` / `HAL_CRC_Calculate` | [002](CRC_IT_DRV_002.c)、[003](CRC_IT_DRV_003.c) |
| `HAL_CRC_Reset` | [001](CRC_IT_DRV_001.c)、[003](CRC_IT_DRV_003.c)、[004](CRC_IT_DRV_004.c) |
| `HAL_CRC_GetCRC` | [001](CRC_IT_DRV_001.c)、[004](CRC_IT_DRV_004.c) |
| `HAL_CRC_SetIDRegister` / `HAL_CRC_GetIDRegister` | [004](CRC_IT_DRV_004.c)、[005](CRC_IT_DRV_005.c) |
| `HAL_CRC_GetState` / `HAL_CRC_GetError` | [001](CRC_IT_DRV_001.c)、[005](CRC_IT_DRV_005.c) |
| `CRC_LockHandle` / `CRC_UnlockHandle` | [006](CRC_IT_DRV_006.c) |

本次为源码静态整理，未重新编译、未上板；源码里的历史测试注释不代表本次验证结果。
