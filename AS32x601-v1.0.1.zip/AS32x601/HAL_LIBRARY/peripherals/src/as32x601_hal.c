/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal.c
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.5
 * Date:   2026/10/08
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/12     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.4     take the initial value of SystemCoreClock
 *                                                       from the power-on clock source (FIRC)
 *                                                       instead of the external oscillator; derive
 *                                                       the time base from the HAL_TICK_FREQ_HZ
 *                                                       system parameter so that HAL_GetTickFreq()
 *                                                       reports the frequency the time base is
 *                                                       built with; convert HAL_Delay with a
 *                                                       multiply-then-divide so that a frequency
 *                                                       that is not an integer multiple of 1000 Hz
 *                                                       is no longer a precondition, and report the
 *                                                       remaining precondition through the
 *                                                       assertion instead of returning silently;
 *                                                       annotate the blocking property of the
 *                                                       public services and align the version
 *                                                       number with the rest of the common layer
 *     ANSILIC APPLICATION GROUP  2026/10/08     1.5     document the tick counter (its unit is the
 *                                                       configured tick frequency and it stays
 *                                                       private to this file) and the
 *                                                       multiply-then-divide conversion of
 *                                                       HAL_Delay with the missing result value of
 *                                                       its public signature
 * Description:     This file is the common part of the AS32x601 HAL
 *                  initialization. It provides the generic and common APIs
 *                  used by the peripheral drivers and by the application:
 *                  - Initialization and de-initialization of the common HAL;
 *                  - Time base services based on the CPU mcycle counter
 *                    (1 ms tick derived by polling, without interrupts);
 *                  - Tick services (increment, get, delay, suspend, resume);
 *                  - HAL library version identification.
 */
#include "as32x601_hal.h"       /* HAL master header: configuration + common */
#include "core_riscv.h"         /* Project CSR access macros and definitions */

/* Private variables ---------------------------------------------------------*/

/**
 * @brief Tick counter maintained by the HAL time base.
 * @note  The value counts ticks at HAL_GetTickFreq() Hz, so it equals the
 *        elapsed milliseconds only while the configured tick frequency is
 *        1000 Hz.
 * @note  It stays private to this file on purpose: a definition in a header or
 *        in another module would be a second definition in the image, and
 *        HAL_GetTick() is the supported way to read the value.
 */
__IO uint32 uwTick;

/* Power-on system clock frequency (HAL-REQ-025). The reset value of
 * SMU_BUSCFGR is 0x00091308, whose SYSSEL field selects the fast internal
 * RC oscillator (SMU_SYSCLKSOURCE_FIRC = 0x0), therefore the core leaves
 * reset running on FIRC and the mcycle counter is clocked at FIRC_VALUE.
 * A wrong value here would scale every tick and every delay, so the initial
 * value follows the power-on clock source and not the external oscillator.
 * The application updates it (and calls HAL_InitTick()) once it has
 * programmed another clock tree. */
__IO uint32 SystemCoreClock = FIRC_VALUE;
static uint64 uwTickCycleStart;
static uint32 uwTickStart;
static uint32 uwTickSuspended;

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Read mcycle consistently on RV32 using the project CSR macro.
 * @retval Current machine cycle counter value.
 */
static uint64 ReadMcycle(void)
{
#if __riscv_xlen == 64
    return (uint64)csr_read(CSR_MCYCLE);
#else
    uint32 hi;
    uint32 lo;

    do
    {
        hi = (uint32)csr_read(CSR_MCYCLEH);
        lo = (uint32)csr_read(CSR_MCYCLE);
    } while (hi != (uint32)csr_read(CSR_MCYCLEH));

    return ((uint64)hi << 32U) | (uint64)lo;
#endif
}

static void DelayCycles(uint64 cycles)
{
    uint64 start = ReadMcycle();

    while ((ReadMcycle() - start) < cycles)
    {
    }
}

static uint32 UpdateTick(void)
{
    uint32 cyclesPerTick = SystemCoreClock / HAL_TICK_FREQ_HZ;

    if ((uwTickSuspended != 0U) || (cyclesPerTick == 0U))
    {
        return uwTick;
    }

    uwTick = uwTickStart + (uint32)((ReadMcycle() - uwTickCycleStart) /
                                    (uint64)cyclesPerTick);
    return uwTick;
}

/**
 * @brief  Initialize the HAL library; it must be the first instruction to be
 *         executed in the main program, before calling any other HAL function. (NON-BLOCKING)
 * @note   Resets the tick state, records the current mcycle value through the
 *         project csr_read() macro, and calls the HAL_MspInit() callback.
 *         No interrupt or CLINT resource is configured by this function.
 * @note   SystemCoreClock shall already match the mcycle frequency. Before a
 *         later frequency change, call HAL_GetTick() to settle elapsed time;
 *         after the change, update SystemCoreClock and call HAL_InitTick().
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR
 */
HAL_StatusTypeDef HAL_Init(void)
{
    uwTick = 0U;
    uwTickStart = 0U;
    uwTickSuspended = 0U;

    {
        HAL_StatusTypeDef status = HAL_InitTick();
        if (status != HAL_OK)
        {
            return status;
        }
    }

    HAL_MspInit();
    return HAL_OK;
}

/**
 * @brief  De-initialize the common part of the HAL and stop the time base
 *         source. This function is optional. (NON-BLOCKING)
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR
 */
HAL_StatusTypeDef HAL_DeInit(void)
{
    HAL_SuspendTick();
    HAL_MspDeInit();
    return HAL_OK;
}

/**
 * @brief  Initializes the MSP (MCU Support Package). Weak empty function,
 *         implemented by the user when the global low level hardware
 *         initialization is needed.
 * @note   This function should not be modified; when a callback is needed,
 *         the HAL_MspInit could be implemented in the user file.
 * @retval None
 */
__weak void HAL_MspInit(void)
{
    /* NOTE : This function should not be modified; when the callback is
              needed, the HAL_MspInit could be implemented in the user file */
}

/**
 * @brief  De-initializes the MSP. Weak empty function, implemented by the
 *         user when the global low level hardware de-initialization is
 *         needed.
 * @note   This function should not be modified; when a callback is needed,
 *         the HAL_MspDeInit could be implemented in the user file.
 * @retval None
 */
__weak void HAL_MspDeInit(void)
{
    /* NOTE : This function should not be modified; when the callback is
              needed, the HAL_MspDeInit could be implemented in the user file */
}

/**
 * @brief  Configure the source of the time base to have a 1 ms time base. (NON-BLOCKING)
 * @note   The default implementation records the current CPU mcycle value.
 *         SystemCoreClock shall match the mcycle frequency and shall be at
 *         least equal to, and an integer multiple of, the configured time
 *         base frequency HAL_TICK_FREQ_HZ (1000 Hz for the default 1 ms
 *         time base). No interrupt or CLINT register is used.
 * @note   This function is declared as __weak to be overridden when another
 *         time base source (e.g. a general purpose timer) is required.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR
 */
__weak HAL_StatusTypeDef HAL_InitTick(void)
{
    if ((SystemCoreClock < HAL_TICK_FREQ_HZ) ||
        ((SystemCoreClock % HAL_TICK_FREQ_HZ) != 0U))
    {
        return HAL_ERROR;
    }

    uwTickCycleStart = ReadMcycle();
    uwTickStart = uwTick;
    uwTickSuspended = 0U;
    return HAL_OK;
}

/**
 * @brief  Increment the global tick variable "uwTick" used as the application
 *         time base. (NON-BLOCKING)
 * @note   This compatibility hook first settles the elapsed mcycle time, then
 *         adds one millisecond and records a new cycle baseline. It does
 *         nothing while the tick is suspended.
 * @retval None
 */
__weak void HAL_IncTick(void)
{
    if (uwTickSuspended == 0U)
    {
        uwTick = UpdateTick() + 1U;
        uwTickStart = uwTick;
        uwTickCycleStart = ReadMcycle();
    }
}

/**
 * @brief  Provide a tick value in milliseconds. (NON-BLOCKING)
 * @note   Declared as __weak to be overridden in case of another
 *         implementation in the user file.
 * @retval uint32: tick value
 */
__weak uint32 HAL_GetTick(void)
{
    return UpdateTick();
}

/**
 * @brief  Provide a blocking delay based directly on the CPU cycle counter. (BLOCKING)
 * @note   The conversion to cycles multiplies before it divides
 *         (Delay * SystemCoreClock / 1000, widened to 64 bits), so it stays
 *         exact for every SystemCoreClock value and a frequency that is not an
 *         integer multiple of 1000 Hz is not a precondition.
 * @note   Precondition: SystemCoreClock shall be >= 1000 Hz and equal to the
 *         mcycle frequency. When it is not met the requested time cannot be
 *         converted into cycles; the call then reports that through
 *         assert_param() and returns without delaying, instead of delaying a
 *         silently wrong amount of time (HAL-REQ-029). The public signature
 *         carries no result value, so the assertion and this documented
 *         precondition are the only channels through which the violation can
 *         be reported.
 * @param  Delay: delay time in milliseconds.
 * @retval None
 */
__weak void HAL_Delay(uint32 Delay)
{
    /* HAL-REQ-029: a frequency that cannot resolve a millisecond is a
       configuration error, and the interface must not swallow it silently.
       It is reported through the assertion (the precondition is documented
       on the prototype as well) and the call returns without pretending to
       have delayed. */
    assert_param(SystemCoreClock >= 1000U);

    if (SystemCoreClock < 1000U)
    {
        return;
    }

    /* Multiply before dividing: the conversion stays exact for every
       SystemCoreClock value, so a frequency that is not an integer multiple
       of 1000 Hz is no longer a precondition. The divisor is the number of
       milliseconds per second: Delay is expressed in milliseconds,
       independently of the configured tick frequency. */
    DelayCycles(((uint64)Delay * (uint64)SystemCoreClock) / 1000U);
}

/**
 * @brief  Freeze the cycle-derived tick without changing interrupt state. (NON-BLOCKING)
 * @retval None
 */
__weak void HAL_SuspendTick(void)
{
    if (uwTickSuspended == 0U)
    {
        uwTick = UpdateTick();
        uwTickSuspended = 1U;
    }
}

/**
 * @brief  Resume the cycle-derived tick from the current cycle counter. (NON-BLOCKING)
 * @retval None
 */
__weak void HAL_ResumeTick(void)
{
    if (uwTickSuspended != 0U)
    {
        uwTickCycleStart = ReadMcycle();
        uwTickStart = uwTick;
        uwTickSuspended = 0U;
    }
}

/**
 * @brief  Return the HAL library revision. (NON-BLOCKING)
 * @retval uint32: version, 0xXYZR (8 bits for each decimal, R for RC)
 */
uint32 HAL_GetHalVersion(void)
{
    return (uint32)__AS32X601_HAL_VERSION;
}

/**
 * @brief  Return the time base frequency of the HAL tick. (NON-BLOCKING)
 * @note   The configured HAL_TICK_FREQ_HZ value is returned, so the reported
 *         frequency always matches the frequency HAL_InitTick() built the
 *         time base with (HAL-REQ-028).
 * @retval uint32: tick frequency, in Hz
 */
uint32 HAL_GetTickFreq(void)
{
    return (uint32)HAL_TICK_FREQ_HZ;
}

/*****END OF FILE*****/
