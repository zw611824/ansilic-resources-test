/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_dma.c
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.4
 * Date:   2026/09/21
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/21     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.1     add the module guard (HAL_DMA_MODULE_ENABLED) around the whole implementation
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.2     put the as32x601_hal.h include first (module switch from the conf) before the module headers
 *     ANSILIC APPLICATION GROUP  2026/09/21     1.4     align the resource lock and the RTOS support with the
 *                                                       architecture specification (section 13 LOCK-01..06 and
 *                                                       section 21 RTOS-04/11): the public lock macros are
 *                                                       replaced by the shared lock helpers with a Timeout
 *                                                       parameter and a NULL mutex guard (RTOS-11), the
 *                                                       de-initialization no longer releases a lock it never
 *                                                       acquired, the MSP callbacks run outside the locked
 *                                                       region (LOCK-06) with the MSP init on the first
 *                                                       initialization only (MSP-04), every lock failure return
 *                                                       is documented as a path where the lock is not held
 *                                                       (LOCK-02), a state gate is applied to the start and the
 *                                                       callback interfaces while the abort and the polling
 *                                                       interfaces use a gate that accepts the busy state, the
 *                                                       handle and the instance are checked through one shared
 *                                                       helper, the polling loop yields the CPU (RTOS-04), the
 *                                                       configuration structure is validated at run time, the
 *                                                       handle keeps the RTOS mutex at the end of the structure
 *                                                       and the external implementation references are dropped
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Direct Memory Access
 *                  (DMA) peripheral:
 *                  - Initialization and de-initialization functions
 *                    (HAL_DMA_Init / HAL_DMA_DeInit + weak MSP hooks);
 *                  - IO operation functions (HAL_DMA_Start / HAL_DMA_Start_IT /
 *                    HAL_DMA_Abort / HAL_DMA_Abort_IT /
 *                    HAL_DMA_PollForTransfer / HAL_DMA_IRQHandler);
 *                  - Peripheral Control and Flag functions (HAL_DMA_ITConfig /
 *                    HAL_DMA_StructInit / HAL_DMA_SetCurrDataCounter /
 *                    HAL_DMA_GetCurrDataCounter / HAL_DMA_GetFlagStatus /
 *                    HAL_DMA_ClearFlag / HAL_DMA_GetITStatus /
 *                    HAL_DMA_ClearITPendingBit);
 *                  - Callback registration functions (HAL_DMA_RegisterCallback /
 *                    HAL_DMA_UnRegisterCallback / HAL_DMA_CleanCallbacks);
 *                  - Peripheral State and Errors functions (HAL_DMA_GetState /
 *                    HAL_DMA_GetError).
 *                  The chip-specific extended features (watchdog, dual-core
 *                  lock step, peripheral interface mapping) are provided by
 *                  this driver.
 *                  HAL_DMA_MspInit() must be overridden by the user to enable
 *                  the DMA peripheral clock and release its bus reset through
 *                  the SMU HAL macros, e.g. for DMA0:
 *                    __HAL_SMU_DMA0_CLK_ENABLE();
 *                    __HAL_SMU_DMA0_RELEASE_RESET();
 *                  (DMA0/DMA1 clock gates are in SMU->AB1CFGR, bits
 *                  SMU_AB1CFGR_DMA0EN/DMA0RST and DMA1EN/DMA1RST).
 */
#include "as32x601_hal.h"           /* module switch from as32x601_hal_conf.h */
#include "as32x601_hal_dma.h"       /* DMA HAL API and register macros         */

/* The HAL_DMA_MODULE_ENABLED switch is provided by the user configuration
 * file (as32x601_hal_conf.h, included above through as32x601_hal.h): the
 * whole implementation is compiled only while the module is enabled. */
#ifdef HAL_DMA_MODULE_ENABLED

/* Private functions prototypes ---------------------------------------------*/
static void DMA_SetConfig(DMA_HandleTypeDef *hdma, uint32 SrcAddress, uint32 DstAddress, uint32 DataLength);
static uint32 DMA_CalcChannelIndex(DMA_HandleTypeDef *hdma);
static void DMA_SetChannelEnable(DMA_TypeDef *DMAy, uint32 index, uint32 enable);
static uint32 DMA_IsChannelActive(DMA_TypeDef *DMAy, uint32 index);
static void DMA_MaskChannelSources(DMA_TypeDef *DMAy, uint32 index);
static void DMA_UnmaskChannelSources(DMA_TypeDef *DMAy, uint32 index, uint32 unmask_htf);
static void DMA_ClearChannelPending(DMA_TypeDef *DMAy, uint32 index);

/* Shared internal functions --------------------------------------------------*/

/**
 * @brief  Check whether the DMA handle and its channel instance are valid.
 * @note   Shared with the extension implementation file: every public entry
 *         point of both files performs its handle check through it, so the
 *         NULL pointer and the instance validity are verified in one place.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
uint32 DMA_HandleIsValid(DMA_HandleTypeDef *hdma)
{
    if (hdma == NULL_PTR)
    {
        return 0U;
    }

    if (IS_DMA_ALL_INSTANCE(hdma->Instance) == 0U)
    {
        return 0U;
    }

    return 1U;
}

/**
 * @brief  Check whether the handle accepts a new operation.
 * @note   ARCH-CONST-09: a handle that is BUSY (a transfer is ongoing) rejects
 *         a new operation with HAL_BUSY, and a handle that is not initialized
 *         (RESET) requires HAL_DMA_Init() first and is rejected with
 *         HAL_ERROR. The recoverable states TIMEOUT, ERROR and ABORT accept a
 *         new operation directly, so a failed transfer can be restarted
 *         without a re-initialization.
 * @note   This gate is applied to the start and the callback registration
 *         interfaces. The abort and the polling interfaces deliberately do NOT
 *         use it: they operate on a BUSY channel by definition, so they apply
 *         their own busy check (DMA_CheckInitState).
 * @param  hdma: pointer to a DMA_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK (accepted) / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef DMA_CheckState(DMA_HandleTypeDef *hdma)
{
    if (hdma->State == HAL_DMA_STATE_BUSY)
    {
        return HAL_BUSY;
    }

    if (hdma->State == HAL_DMA_STATE_RESET)
    {
        return HAL_ERROR;
    }

    /* A recoverable state (TIMEOUT / ERROR / ABORT) is accepted only once the
     * channel has really stopped: re-programming the counters and the
     * addresses of a still active channel would make the ongoing transfer
     * undefined. The enable bit is re-checked here because the state alone
     * does not prove that the hardware stopped. */
    if ((hdma->State == HAL_DMA_STATE_TIMEOUT) || (hdma->State == HAL_DMA_STATE_ERROR))
    {
        if (DMA_IsChannelActive(DMA_GET_DMAy(hdma), hdma->ChannelIndex) != 0U)
        {
            return HAL_BUSY;
        }
    }

    return HAL_OK;
}

/**
 * @brief  Check whether the handle has been initialized (no busy check).
 * @note   Variant of DMA_CheckState() used by the abort and the polling
 *         interfaces, which are meant to run while a transfer is ongoing and
 *         therefore accept the busy state; only a handle that was never
 *         initialized (RESET) is rejected with HAL_ERROR.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK (accepted) / HAL_ERROR (not initialized).
 */
HAL_StatusTypeDef DMA_CheckInitState(DMA_HandleTypeDef *hdma)
{
    if (hdma->State == HAL_DMA_STATE_RESET)
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_DMA_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared channel; the value is passed to HAL_MutexAcquire() as is
 *         (RTOS ticks; HAL_MAX_DELAY means an infinite wait).
 * @param  hdma: pointer to a DMA_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS, wait expired) /
 *         HAL_ERROR (RTOS, mutex not created) / HAL_BUSY (bare metal, the
 *         handle is already locked).
 */
HAL_StatusTypeDef DMA_LockHandle(DMA_HandleTypeDef *hdma, uint32 Timeout)
{
#if (USE_RTOS == 1)
    if (hdma->LockMutex == NULL_PTR)
    {
        /* The porting layer did not create the mutex: report it instead of
         * calling the RTOS with a NULL handle */
        return HAL_ERROR;
    }

    return HAL_MutexAcquire(hdma->LockMutex, Timeout);
#else
    /* Prevent unused argument compilation warning: the bare-metal lock flag
     * either succeeds immediately or reports HAL_BUSY, it never waits */
    UNUSED(Timeout);

    if (hdma->Lock == HAL_LOCKED)
    {
        return HAL_BUSY;
    }
    hdma->Lock = HAL_LOCKED;
    return HAL_OK;
#endif /* USE_RTOS */
}

/**
 * @brief  Unlock the handle.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure.
 * @retval None
 */
void DMA_UnlockHandle(DMA_HandleTypeDef *hdma)
{
#if (USE_RTOS == 1)
    (void)HAL_MutexRelease(hdma->LockMutex);
#else
    hdma->Lock = HAL_UNLOCKED;
#endif /* USE_RTOS */
}

/**
 * @brief  Enter a short critical section protecting a controller register that
 *         the 16 channels of that controller share.
 * @note   Shared with the extension implementation file. The interrupt mask is
 *         saved and restored, so the pair nests, and it is usable from an
 *         interrupt context: it deliberately does not take the handle lock,
 *         which the ISR must not take.
 * @retval uint32: the interrupt mask state to restore.
 */
uint32 DMA_EnterCritical(void)
{
    return __disable_irq_and_save();
}

/**
 * @brief  Leave the critical section entered by DMA_EnterCritical().
 * @param  state: the value returned by the matching DMA_EnterCritical().
 * @retval None
 */
void DMA_ExitCritical(uint32 state)
{
    __restore_irq(state);
}

/**
 * @brief  Enable or disable one channel of a controller.
 * @note   The CHEN register is shared by the 16 channels of the controller, so
 *         the enable bit is updated inside a short critical section: an
 *         interrupt handler enabling or disabling another channel of the same
 *         controller at the same time must not lose this update.
 * @param  DMAy:   where y can be 0 or 1 to select the DMA controller.
 * @param  index:  channel index (0..15).
 * @param  enable: 1 to enable the channel, 0 to disable it.
 * @retval None
 */
static void DMA_SetChannelEnable(DMA_TypeDef *DMAy, uint32 index, uint32 enable)
{
    uint32 chbit = (uint32)(1UL << index);
    uint32 primask = DMA_EnterCritical();

    if (enable != 0U)
    {
        DMAy->CHEN |= chbit;
    }
    else
    {
        DMAy->CHEN &= (uint32)(~chbit);
    }

    DMA_ExitCritical(primask);
}

/**
 * @brief  Report whether one channel is enabled in the CHEN register.
 * @param  DMAy:  where y can be 0 or 1 to select the DMA controller.
 * @param  index: channel index (0..15).
 * @retval uint32: 1 if the channel is active, 0 otherwise.
 */
static uint32 DMA_IsChannelActive(DMA_TypeDef *DMAy, uint32 index)
{
    return ((DMAy->CHEN & (uint32)(1UL << index)) != 0U) ? 1U : 0U;
}

/**
 * @brief  Mask (disable) the ERR, HTF and FTF interrupt sources of one channel.
 * @note   The three mask registers are shared by the 16 channels of the
 *         controller, hence the short critical section; only the bit of the
 *         addressed channel is touched.
 * @param  DMAy:  where y can be 0 or 1 to select the DMA controller.
 * @param  index: channel index (0..15).
 * @retval None
 */
static void DMA_MaskChannelSources(DMA_TypeDef *DMAy, uint32 index)
{
    uint32 chbit = (uint32)(1UL << index);
    uint32 primask = DMA_EnterCritical();

    DMAy->ERR_INT_MASK |= chbit;
    DMAy->HTF_INT_MASK |= chbit;
    DMAy->FTF_INT_MASK |= chbit;

    DMA_ExitCritical(primask);
}

/**
 * @brief  Unmask (enable) the ERR and FTF interrupt sources of one channel and,
 *         on request, the HTF source as well.
 * @note   The mask registers are shared by the 16 channels of the controller,
 *         hence the short critical section. The HTF source is enabled only
 *         when a half transfer callback is registered, so that a channel
 *         without one does not raise an interrupt it cannot service.
 * @param  DMAy:       where y can be 0 or 1 to select the DMA controller.
 * @param  index:      channel index (0..15).
 * @param  unmask_htf: non-zero to unmask the half transfer source as well.
 * @retval None
 */
static void DMA_UnmaskChannelSources(DMA_TypeDef *DMAy, uint32 index, uint32 unmask_htf)
{
    uint32 chbit = (uint32)(1UL << index);
    uint32 primask = DMA_EnterCritical();

    DMAy->ERR_INT_MASK &= (uint32)(~chbit);
    DMAy->FTF_INT_MASK &= (uint32)(~chbit);
    if (unmask_htf != 0U)
    {
        DMAy->HTF_INT_MASK &= (uint32)(~chbit);
    }

    DMA_ExitCritical(primask);
}

/**
 * @brief  Clear the ERR, HTF and FTF pending raw flags of one channel.
 * @note   The raw registers are cleared by writing one, so the bit of the
 *         addressed channel is written directly inside a short critical
 *         section: a read-modify-write would clear the pending violations of
 *         the other channels of the controller as well.
 * @param  DMAy:  where y can be 0 or 1 to select the DMA controller.
 * @param  index: channel index (0..15).
 * @retval None
 */
static void DMA_ClearChannelPending(DMA_TypeDef *DMAy, uint32 index)
{
    uint32 chbit = (uint32)(1UL << index);
    uint32 primask = DMA_EnterCritical();

    DMAy->ERR_INT_RAW = chbit;
    DMAy->HTF_INT_RAW = chbit;
    DMAy->FTF_INT_RAW = chbit;

    DMA_ExitCritical(primask);
}

/* Exported functions ---------------------------------------------------------*/

/** @defgroup DMA_Exported_Functions DMA Exported Functions
  * @{
  */

/** @defgroup DMA_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Initialize the DMA channel according to the specified parameters in (NON-BLOCKING)
 *         the hdma->Init structure and initialize the low level hardware. (NON-BLOCKING)
 * @note   Programs the channel with the conventional register write sequence
 *         (CHCTL configuration bits OR-ed together, then CHCNT / CHPADDR /
 *         CHMADDR). The channel index is computed and stored in the handle,
 *         the pending interrupt raw flags of the channel are cleared and the
 *         channel is left disabled: it is enabled by HAL_DMA_Start() /
 *         HAL_DMA_Start_IT().
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_DMA_Init(DMA_HandleTypeDef *hdma)
{
    uint32 tmpreg;

    /* Check the DMA handle and the channel instance */
    if (DMA_HandleIsValid(hdma) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_DMA_ALL_INSTANCE(hdma->Instance));
    assert_param(IS_DMA_DIRECTION(hdma->Init.DMA_DIR));
    assert_param(IS_DMA_BUFFER_SIZE(hdma->Init.DMA_BufferSize));
    assert_param(IS_DMA_PERIPHERAL_INC_STATE(hdma->Init.DMA_PeripheralInc));
    assert_param(IS_DMA_MEMORY_INC_STATE(hdma->Init.DMA_MemoryInc));
    assert_param(IS_DMA_PERIPHERAL_DATA_SIZE(hdma->Init.DMA_PeripheralDataSize));
    assert_param(IS_DMA_MEMORY_DATA_SIZE(hdma->Init.DMA_MemoryDataSize));
    assert_param(IS_DMA_PRIORITY(hdma->Init.DMA_Priority));
    assert_param(IS_DMA_M2M_STATE(hdma->Init.DMA_M2M));
    assert_param(IS_DMA_MODE(hdma->Init.DMA_Mode));

    /* Run time validation of the configuration, so that the checks stay
     * effective in a build with the assertions disabled. The metafields
     * (Size / Version, architecture spec section 22) and the reserved words
     * are validated as well. A rejected call neither takes the lock nor
     * changes the handle state nor touches a register. */
    if ((hdma->Init.Size != sizeof(DMA_InitTypeDef)) ||
        (hdma->Init.Version != DMA_INIT_VERSION) ||
        (IS_DMA_DIRECTION(hdma->Init.DMA_DIR) == 0U) ||
        (IS_DMA_BUFFER_SIZE(hdma->Init.DMA_BufferSize) == 0U) ||
        (IS_DMA_PERIPHERAL_INC_STATE(hdma->Init.DMA_PeripheralInc) == 0U) ||
        (IS_DMA_MEMORY_INC_STATE(hdma->Init.DMA_MemoryInc) == 0U) ||
        (IS_DMA_PERIPHERAL_DATA_SIZE(hdma->Init.DMA_PeripheralDataSize) == 0U) ||
        (IS_DMA_MEMORY_DATA_SIZE(hdma->Init.DMA_MemoryDataSize) == 0U) ||
        (IS_DMA_PRIORITY(hdma->Init.DMA_Priority) == 0U) ||
        (IS_DMA_M2M_STATE(hdma->Init.DMA_M2M) == 0U) ||
        (IS_DMA_MODE(hdma->Init.DMA_Mode) == 0U) ||
        (hdma->Init.Reserved[0] != 0U) ||
        (hdma->Init.Reserved[1] != 0U))
    {
        hdma->ErrorCode |= HAL_DMA_ERROR_PARAM;
        return HAL_ERROR;
    }

    /* Allocate the lock resource and initialize the low level hardware before
     * the first use (architecture rules MSP-04 and LOCK-06): the MSP callback
     * runs before the handle is locked, so an override may create the RTOS
     * mutex that DMA_LockHandle() needs and call other HAL APIs, and it runs
     * only while the handle is in the reset state, so a repeated
     * initialization does not initialize the hardware twice. */
    if (hdma->State == HAL_DMA_STATE_RESET)
    {
        hdma->Lock = HAL_UNLOCKED;

        /* Init the low level hardware (peripheral clock / reset release) */
        HAL_DMA_MspInit(hdma);
    }

    /* Process locked */
    if (DMA_LockHandle(hdma, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and mark the handle as being configured */
    hdma->ErrorCode = HAL_DMA_ERROR_NONE;
    hdma->State = HAL_DMA_STATE_BUSY;

    /* Derive the channel index BEFORE the first register access of the
     * configuration sequence: the disable below and the pending flag clear
     * further down address the channel through it, so a handle whose index is
     * stale (it was bound to another channel by a previous configuration) or
     * still zero would disable the wrong channel of the controller and leave
     * the channel being programmed active. */
    hdma->ChannelIndex = DMA_CalcChannelIndex(hdma);

    /* Disable the selected DMA channel (the CHEN register is shared by the 16
       channels of one controller: the enable bit is updated in a short
       critical section) */
    DMA_SetChannelEnable(DMA_GET_DMAy(hdma), hdma->ChannelIndex, 0U);

    /*--------------------------- DMA channel CHCTL configuration ------------*/
    /* Get the DMA channel CHCTL value */
    tmpreg = hdma->Instance->CHCTL;
    /* Clear M2M, DIR, CIRC, PINC, MINC, PSIZE, MSIZE and PRIO bits */
    tmpreg &= DMA_CHCTL_CLEAR_Mask;
    /* Configure the data transfer direction, the address increment, the data
       sizes, the priority level, the memory-to-memory mode and the circular
       mode (all values are CHCTL bit values) */
    tmpreg |= hdma->Init.DMA_DIR        | hdma->Init.DMA_PeripheralInc |
              hdma->Init.DMA_MemoryInc  | hdma->Init.DMA_PeripheralDataSize |
              hdma->Init.DMA_MemoryDataSize | hdma->Init.DMA_Priority |
              hdma->Init.DMA_M2M        | hdma->Init.DMA_Mode;
    /* Write to the DMA channel CHCTL register */
    hdma->Instance->CHCTL = tmpreg;

    /*--------------------------- DMA channel CHCNT configuration ------------*/
    hdma->Instance->CHCNT = hdma->Init.DMA_BufferSize;

    /*--------------------------- DMA channel CHPADDR configuration ----------*/
    hdma->Instance->CHPADDR = hdma->Init.DMA_PeripheralBaseAddr;

    /*--------------------------- DMA channel CHMADDR configuration ----------*/
    hdma->Instance->CHMADDR = hdma->Init.DMA_MemoryBaseAddr;

    /* Clear the pending interrupt raw flags of the channel (write one clears,
       so only the bits of this channel are written, in a short critical
       section, instead of clearing every channel of the controller) */
    DMA_ClearChannelPending(DMA_GET_DMAy(hdma), hdma->ChannelIndex);

    hdma->State = HAL_DMA_STATE_READY;

    /* Release Lock */
    DMA_UnlockHandle(hdma);

    CLEAR_CACHE();

    return HAL_OK;
}

/**
 * @brief  De-initialize the DMA channel registers to their default reset (NON-BLOCKING)
 *         values and de-initialize the low level hardware. (NON-BLOCKING)
 * @note   The channel is disabled, its interrupts
 *         are masked, the pending raw flags are cleared and the four channel
 *         registers (CHCTL/CHCNT/CHPADDR/CHMADDR) are reset to zero. The WDG
 *         interrupt of the controller is masked and cleared as well.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY.
 */
HAL_StatusTypeDef HAL_DMA_DeInit(DMA_HandleTypeDef *hdma)
{
    DMA_TypeDef *DMAy;

    /* Check the DMA handle and the channel instance */
    if (DMA_HandleIsValid(hdma) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_DMA_ALL_INSTANCE(hdma->Instance));

    /* Check the DMA peripheral state before the lock is taken: a
     * de-initialization is refused while a transfer is ongoing. The reset
     * state is accepted, so that a handle that was never initialized can be
     * de-initialized as well (see the channel index recomputation below). */
    if (hdma->State == HAL_DMA_STATE_BUSY)
    {
        /* Return error status */
        return HAL_BUSY;
    }

    /* Process locked */
    if (DMA_LockHandle(hdma, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and mark the handle as being torn down */
    hdma->ErrorCode = HAL_DMA_ERROR_NONE;
    hdma->State = HAL_DMA_STATE_BUSY;

    /* Recompute the channel index: covers the case where the handle was not
       initialized before the de-initialization */
    hdma->ChannelIndex = DMA_CalcChannelIndex(hdma);

    DMAy = DMA_GET_DMAy(hdma);

    /* Disable the selected DMA channel (the CHEN register is shared by the 16
       channels of the controller) */
    DMA_SetChannelEnable(DMAy, hdma->ChannelIndex, 0U);

    /* Mask the ERR / HTF / FTF sources of this channel and clear its pending
       raw flags: the mask and the raw registers are shared by the 16 channels
       of the controller, so both updates run in a short critical section and
       touch the bits of this channel only. */
    DMA_MaskChannelSources(DMAy, hdma->ChannelIndex);
    DMA_ClearChannelPending(DMAy, hdma->ChannelIndex);

    /* Mask and clear the controller level watchdog source as well: it is not
       channel specific, so it is not covered by the helpers above. */
    {
        uint32 primask = DMA_EnterCritical();

        DMAy->WDG_INT_MASK |= DMA_WDG_INT_MASK_MASK;
        DMAy->WDG_INT_RAW = DMA_WDG_INT_RAW_RAW;

        DMA_ExitCritical(primask);
    }

    /* Reset the DMA channel configuration register */
    hdma->Instance->CHCTL = 0;

    /* Reset the DMA channel number of data register */
    hdma->Instance->CHCNT = 0;

    /* Reset the DMA channel peripheral address register */
    hdma->Instance->CHPADDR = 0;

    /* Reset the DMA channel memory address register */
    hdma->Instance->CHMADDR = 0;

    /* The handle goes back to the reset state */
    hdma->State = HAL_DMA_STATE_RESET;

    /* Release Lock */
    DMA_UnlockHandle(hdma);

    /* LOCK-06 / ARCH-CONST-04: the low level de-initialization runs OUTSIDE
     * the locked region, as the architecture specification requires for the
     * MSP callbacks ("MspDeInit is called after the unlock"). An override may
     * call other HAL APIs, which is only allowed while the handle lock is not
     * held. */
    HAL_DMA_MspDeInit(hdma);

    CLEAR_CACHE();

    return HAL_OK;
}

/**
 * @brief  Initialize the DMA MSP (peripheral clock enable, reset release).
 * @note   This function should not be modified: when the MSP initialization
 *         is needed, HAL_DMA_MspInit() should be implemented in the user file
 *         (e.g. call __HAL_SMU_DMA0_CLK_ENABLE() / __HAL_SMU_DMA0_RELEASE_RESET()
 *         for DMA0, or the DMA1 counterparts for DMA1).
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @retval None
 */
__weak void HAL_DMA_MspInit(DMA_HandleTypeDef *hdma)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(hdma);

    /* NOTE : This function should not be modified, when the callback is needed,
              the HAL_DMA_MspInit could be implemented in the user file
    */
}

/**
 * @brief  De-initialize the DMA MSP (peripheral clock disable, reset assert).
 * @note   This function should not be modified: when the MSP de-initialization
 *         is needed, HAL_DMA_MspDeInit() should be implemented in the user file
 *         (e.g. call __HAL_SMU_DMA0_FORCE_RESET() / __HAL_SMU_DMA0_CLK_DISABLE()
 *         for DMA0, or the DMA1 counterparts for DMA1).
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @retval None
 */
__weak void HAL_DMA_MspDeInit(DMA_HandleTypeDef *hdma)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(hdma);

    /* NOTE : This function should not be modified, when the callback is needed,
              the HAL_DMA_MspDeInit could be implemented in the user file
    */
}

/**
  * @}
  */

/** @defgroup DMA_Exported_Functions_Group2 IO operation functions
  * @{
  */

/**
 * @brief  Start the DMA transfer. (NON-BLOCKING)
 * @note   No interrupt source is enabled by this flavour: the three channel
 *         sources are masked (a mask left enabled by an earlier interrupt
 *         transfer cannot raise an interrupt that has no owner) and the
 *         pending flags of the channel are cleared before the channel is
 *         enabled.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains
 *         the configuration information for the specified DMA channel.
 * @param  SrcAddress: the source memory buffer address
 * @param  DstAddress: the destination memory buffer address
 * @param  DataLength: the length of data to be transferred from source to destination
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (invalid length) / HAL_BUSY.
 */
HAL_StatusTypeDef HAL_DMA_Start(DMA_HandleTypeDef *hdma, uint32 SrcAddress, uint32 DstAddress, uint32 DataLength)
{
    HAL_StatusTypeDef status = HAL_OK;
    DMA_TypeDef *DMAy;

    /* Check the DMA handle and the channel instance */
    if (DMA_HandleIsValid(hdma) == 0U)
    {
        return HAL_ERROR;
    }
    assert_param(IS_DMA_BUFFER_SIZE(DataLength));

    /* Run time validation of the transfer length, so that the check stays
     * effective in a build with the assertions disabled (the macro and the
     * branch share one definition of the domain): the counter is 16 bits
     * wide, so a length of zero or beyond 0xFFFF units cannot be
     * programmed. A rejected call touches no register and leaves the handle
     * state unchanged. */
    if (IS_DMA_BUFFER_SIZE(DataLength) == 0U)
    {
        hdma->ErrorCode |= HAL_DMA_ERROR_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when a transfer is ongoing (BUSY) or when
     * the handle has not been initialized (RESET, HAL_DMA_Init() is required
     * first). The recoverable states TIMEOUT / ERROR / ABORT accept a new
     * operation directly, once the channel has really stopped (see
     * DMA_CheckState()). */
    status = DMA_CheckState(hdma);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (DMA_LockHandle(hdma, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Change DMA peripheral state */
    hdma->State = HAL_DMA_STATE_BUSY;

    /* Initialize the error code */
    hdma->ErrorCode = HAL_DMA_ERROR_NONE;

    /* Stop the channel before reprogramming it: this controller does NOT clear
       the channel enable bit when a normal (non circular) transfer ends, so a
       channel re-armed after a completed transfer is still enabled. A data
       counter (CHCNT) written while the channel is enabled is not loaded, the
       running counter wraps instead (measured on silicon: CHEN = 1 and
       CHCNT = 0xFFFF after programming 8 units) and the transfer then never
       reports its completion. The reference standard-library driver disables
       the channel before programming it as well. */
    DMA_SetChannelEnable(DMA_GET_DMAy(hdma), hdma->ChannelIndex, 0U);

    /* Configure the source, destination address and the data length */
    DMA_SetConfig(hdma, SrcAddress, DstAddress, DataLength);

    DMAy = DMA_GET_DMAy(hdma);

    /* A transfer started without interrupts enables no source: mask the three
       channel sources, so that a mask left enabled by an earlier interrupt
       transfer cannot raise an interrupt that has no owner, and clear the
       pending flags of the channel. Both register groups are shared by the 16
       channels of the controller. */
    DMA_MaskChannelSources(DMAy, hdma->ChannelIndex);
    DMA_ClearChannelPending(DMAy, hdma->ChannelIndex);

    CLEAR_CACHE();

    /* Enable the channel */
    DMA_SetChannelEnable(DMAy, hdma->ChannelIndex, 1U);

    /* Release Lock */
    DMA_UnlockHandle(hdma);

    return HAL_OK;
}

/**
 * @brief  Start the DMA transfer with interrupt enabled. (NON-BLOCKING / IT)
 * @note   The full transfer (FTF) and the transfer error (ERR) interrupts are
 *         always unmasked; the half transfer (HTF) interrupt is unmasked only
 *         when the XferHalfCpltCallback is registered. The WDG interrupt is
 *         not touched (it is a global interrupt configured with
 *         HAL_DMA_ConfigWatchDog()).
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains
 *         the configuration information for the specified DMA channel.
 * @param  SrcAddress: the source memory buffer address
 * @param  DstAddress: the destination memory buffer address
 * @param  DataLength: the length of data to be transferred from source to destination
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (invalid length) / HAL_BUSY.
 */
HAL_StatusTypeDef HAL_DMA_Start_IT(DMA_HandleTypeDef *hdma, uint32 SrcAddress, uint32 DstAddress, uint32 DataLength)
{
    HAL_StatusTypeDef status = HAL_OK;
    DMA_TypeDef *DMAy;

    /* Check the DMA handle and the channel instance (first entry check) */
    if (DMA_HandleIsValid(hdma) == 0U)
    {
        return HAL_ERROR;
    }
    assert_param(IS_DMA_BUFFER_SIZE(DataLength));

    /* Run time validation of the transfer length, so that the check stays
     * effective in a build with the assertions disabled (the macro and the
     * branch share one definition of the domain): the counter is 16 bits
     * wide, so a length of zero or beyond 0xFFFF units cannot be
     * programmed. A rejected call touches no register and leaves the handle
     * state unchanged. Both start flavours enforce the same domain. */
    if (IS_DMA_BUFFER_SIZE(DataLength) == 0U)
    {
        hdma->ErrorCode |= HAL_DMA_ERROR_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when a transfer is ongoing (BUSY) or when
     * the handle has not been initialized (RESET, HAL_DMA_Init() is required
     * first). The recoverable states TIMEOUT / ERROR / ABORT accept a new
     * operation directly, once the channel has really stopped (see
     * DMA_CheckState()). */
    status = DMA_CheckState(hdma);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (DMA_LockHandle(hdma, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Change DMA peripheral state */
    hdma->State = HAL_DMA_STATE_BUSY;

    /* Initialize the error code */
    hdma->ErrorCode = HAL_DMA_ERROR_NONE;

    /* Stop the channel before reprogramming it: this controller does NOT clear
       the channel enable bit when a normal (non circular) transfer ends, so a
       channel re-armed after a completed transfer is still enabled. A data
       counter (CHCNT) written while the channel is enabled is not loaded, the
       running counter wraps instead (measured on silicon: CHEN = 1 and
       CHCNT = 0xFFFF after programming 8 units) and the transfer then never
       reports its completion. The reference standard-library driver disables
       the channel before programming it as well. */
    DMA_SetChannelEnable(DMA_GET_DMAy(hdma), hdma->ChannelIndex, 0U);

    /* Configure the source, destination address and the data length */
    DMA_SetConfig(hdma, SrcAddress, DstAddress, DataLength);

    DMAy = DMA_GET_DMAy(hdma);

    /* Clear the pending interrupt raw flags of the channel, then unmask the
       common sources (mask bit set to 1 disables): the ERR and FTF sources
       are always unmasked, the HTF source only when a half transfer callback
       is registered. The mask and the raw registers are shared by the 16
       channels of the controller, so each update is a short critical
       section. */
    DMA_ClearChannelPending(DMAy, hdma->ChannelIndex);
    DMA_UnmaskChannelSources(DMAy, hdma->ChannelIndex,
                             (hdma->XferHalfCpltCallback != NULL) ? 1U : 0U);

    /* Enable the channel */
    DMA_SetChannelEnable(DMAy, hdma->ChannelIndex, 1U);

    /* Release Lock */
    DMA_UnlockHandle(hdma);

    return HAL_OK;
}

/**
 * @brief  Abort the DMA transfer. (NON-BLOCKING)
 * @note   The channel is disabled immediately (no wait loop: the channel
 *         enable bit stops the transfer right away on this chip), all the
 *         channel interrupts are masked and the pending raw flags are cleared.
 * @note   The stop is confirmed by reading the enable bit back before success
 *         is reported: a channel that is still active keeps its state and
 *         reports HAL_ERROR, so the caller is never told to reuse a buffer the
 *         hardware is still writing.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (handle or instance invalid,
 *         no transfer ongoing, or the stop could not be confirmed) / HAL_BUSY
 *         (the handle lock is held by another context).
 */
HAL_StatusTypeDef HAL_DMA_Abort(DMA_HandleTypeDef *hdma)
{
    DMA_TypeDef *DMAy;
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the DMA handle and the channel instance (first entry check) */
    if (DMA_HandleIsValid(hdma) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_DMA_ALL_INSTANCE(hdma->Instance));

    /* This interface runs while a transfer is ongoing, so it only requires an
     * initialized handle (DMA_CheckInitState): the busy state is expected and
     * accepted here. */
    status = DMA_CheckInitState(hdma);
    if (status != HAL_OK)
    {
        return status;
    }

    DMAy = DMA_GET_DMAy(hdma);

    /* Process locked */
    if (DMA_LockHandle(hdma, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    if (hdma->State != HAL_DMA_STATE_BUSY)
    {
        hdma->ErrorCode = HAL_DMA_ERROR_NO_XFER;

        /* Release Lock */
        DMA_UnlockHandle(hdma);

        return HAL_ERROR;
    }

    /* Mask every transfer source of the channel, disable the channel and clear
       its pending flags. The three register groups are shared by the 16
       channels of the controller, so each update is a short critical
       section. */
    DMA_MaskChannelSources(DMAy, hdma->ChannelIndex);
    DMA_SetChannelEnable(DMAy, hdma->ChannelIndex, 0U);
    DMA_ClearChannelPending(DMAy, hdma->ChannelIndex);

    /* Confirm that the channel has really stopped before reporting success:
       the enable bit is read back after the write and the state is kept while
       the channel is still active, so that a later abort (or the interrupt
       path) can finish the transaction. */
    if (DMA_IsChannelActive(DMAy, hdma->ChannelIndex) != 0U)
    {
        /* Release Lock */
        DMA_UnlockHandle(hdma);

        return HAL_ERROR;
    }

    /* Finalize the data cache of a receive transfer before the caller reads
       the buffer: the DMA writes memory behind the cache, so the delivered
       lines must not be read stale. A transmit transfer delivers no data. */
    if (hdma->Init.DMA_DIR == DMA_PERIPH_TO_MEMORY)
    {
        CLEAR_CACHE();
    }

    /* Change the DMA state (inside the locked region, so that the state
       transition cannot interleave with another context) */
    hdma->State = HAL_DMA_STATE_READY;

    /* Release Lock */
    DMA_UnlockHandle(hdma);

    return HAL_OK;
}

/**
 * @brief  Abort the DMA transfer in interrupt mode. (NON-BLOCKING / IT)
 * @note   The channel is disabled and the abort completion is reported by the
 *         XferAbortCallback, invoked from HAL_DMA_IRQHandler() when the full
 *         transfer interrupt of the disabled channel is serviced. If the
 *         channel stops without any pending full transfer flag, the user
 *         should call HAL_DMA_Abort() instead (blocking completion).
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_DMA_Abort_IT(DMA_HandleTypeDef *hdma)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the DMA handle and the channel instance */
    if (DMA_HandleIsValid(hdma) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_DMA_ALL_INSTANCE(hdma->Instance));

    /* This interface runs while a transfer is ongoing, so it only requires an
     * initialized handle (DMA_CheckInitState): the busy state is expected and
     * accepted here. */
    status = DMA_CheckInitState(hdma);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (DMA_LockHandle(hdma, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    if (hdma->State != HAL_DMA_STATE_BUSY)
    {
        hdma->ErrorCode = HAL_DMA_ERROR_NO_XFER;

        /* Release Lock */
        DMA_UnlockHandle(hdma);

        return HAL_ERROR;
    }

    /* Set Abort State */
    hdma->State = HAL_DMA_STATE_ABORT;

    /* Disable the channel (the CHEN register is shared by the 16 channels of
       one controller, so its update is a short critical section). The transfer
       sources are deliberately left enabled: on this device the abort
       completion is reported by the interrupt path, which services the full
       transfer flag of the disabled channel and invokes the abort callback, so
       masking them here would silence that completion. */
    DMA_SetChannelEnable(DMA_GET_DMAy(hdma), hdma->ChannelIndex, 0U);

    /* Release Lock */
    DMA_UnlockHandle(hdma);

    return HAL_OK;
}

/**
 * @brief  Poll for transfer complete. (BLOCKING)
 * @note   The polling mode is not supported in circular mode.
 * @note   The wait does not hold the handle lock (architecture rule section
 *         12): the lock is taken for a short verification of this transfer at
 *         each iteration and released before the yield hook, so another user
 *         of this channel (and a task of the same priority) can run while the
 *         transfer completes. A context that finalizes the transfer during the
 *         wait ends this poll with its final state.
 * @param  hdma:          pointer to a DMA_HandleTypeDef structure that contains
 *         the configuration information for the specified DMA channel.
 * @param  CompleteLevel: specifies the DMA level complete (HAL_DMA_FULL_TRANSFER /
 *         HAL_DMA_HALF_TRANSFER).
 * @param  Timeout:       timeout duration.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (handle, instance or level
 *         invalid, no transfer ongoing, transfer error, or circular mode) /
 *         HAL_TIMEOUT (the wait expired, the transfer itself is not stopped) /
 *         HAL_BUSY (the handle lock could not be acquired).
 */
HAL_StatusTypeDef HAL_DMA_PollForTransfer(DMA_HandleTypeDef *hdma, HAL_DMA_LevelCompleteTypeDef CompleteLevel,
                                          uint32 Timeout)
{
    HAL_StatusTypeDef status = HAL_OK;
    uint32 tickstart;
    DMA_TypeDef *DMAy;
    uint32 chbit;

    /* Check the DMA handle and the channel instance (first entry check) */
    if (DMA_HandleIsValid(hdma) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_DMA_ALL_INSTANCE(hdma->Instance));
    assert_param((CompleteLevel == HAL_DMA_FULL_TRANSFER) || (CompleteLevel == HAL_DMA_HALF_TRANSFER));

    /* Run time validation of the completion level, so that the check stays
     * effective in a build with the assertions disabled: an unknown level
     * would select a different flag register and silently wait for the wrong
     * event. */
    if ((CompleteLevel != HAL_DMA_FULL_TRANSFER) && (CompleteLevel != HAL_DMA_HALF_TRANSFER))
    {
        hdma->ErrorCode |= HAL_DMA_ERROR_PARAM;
        return HAL_ERROR;
    }

    /* This interface runs while a transfer is ongoing, so it only requires an
     * initialized handle (DMA_CheckInitState): the busy state is expected and
     * accepted here. */
    status = DMA_CheckInitState(hdma);
    if (status != HAL_OK)
    {
        return status;
    }

    tickstart = HAL_GetTick();

    /* Wait for the completion flag of the requested level, unless a transfer
     * error has been detected. The handle lock is taken for a short
     * verification of this transfer only and released before the wait
     * (architecture rule section 12: a long wait does not hold the handle
     * mutex, and the yield hook runs outside the locked region), so that
     * another user of this channel and a task of the same priority can run
     * while the transfer completes. */
    for (;;)
    {
        /* Process locked: short critical section around the transfer
           verification and the flag handling */
        if (DMA_LockHandle(hdma, HAL_MAX_DELAY) != HAL_OK)
        {
            /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
            return HAL_BUSY;
        }

        if (hdma->State != HAL_DMA_STATE_BUSY)
        {
            /* Another context changed this transfer while the lock was
               released: report its final state instead of waiting for an event
               that no longer belongs to this transfer (a stale waiter must not
               consume the event of a following transfer). */
            HAL_DMA_StateTypeDef final_state = hdma->State;

            DMA_UnlockHandle(hdma);

            return (final_state == HAL_DMA_STATE_READY) ? HAL_OK : HAL_ERROR;
        }

        /* Polling mode not supported in circular mode */
        if ((hdma->Instance->CHCTL & DMA_CHCTL_CIRC) != RESET)
        {
            hdma->ErrorCode = HAL_DMA_ERROR_NOT_SUPPORTED;

            /* Release Lock */
            DMA_UnlockHandle(hdma);

            return HAL_ERROR;
        }

        DMAy = DMA_GET_DMAy(hdma);
        chbit = (uint32)(1UL << hdma->ChannelIndex);

        if ((DMAy->ERR_INT_RAW & chbit) != RESET)
        {
            /* Update error code */
            hdma->ErrorCode |= HAL_DMA_ERROR_TE;

            /* Release the handle lock so HAL_DMA_Abort() can re-acquire it
             * and perform the abort transaction for the transfer error */
            DMA_UnlockHandle(hdma);

            (void)HAL_DMA_Abort(hdma);

            /* Clear the pending flags of the channel */
            DMA_ClearChannelPending(DMAy, hdma->ChannelIndex);

            /* Change the DMA state */
            hdma->State = HAL_DMA_STATE_READY;

            return HAL_ERROR;
        }

        if (CompleteLevel == HAL_DMA_FULL_TRANSFER)
        {
            if ((DMAy->FTF_INT_RAW & chbit) != RESET)
            {
                /* Clear the pending flags of the channel */
                DMA_ClearChannelPending(DMAy, hdma->ChannelIndex);

                /* Change the DMA state */
                hdma->State = HAL_DMA_STATE_READY;

                /* Release Lock. The lock is released for both completion
                 * levels: the half-transfer level keeps the handle busy (the
                 * caller polls again), but holding the lock would deadlock the
                 * second call of the same task on a non-recursive RTOS
                 * mutex. */
                DMA_UnlockHandle(hdma);

                /* For a peripheral-to-memory (receive) transfer, flush and
                   invalidate the data cache so the caller reads the freshly
                   DMA-written buffer */
                if (hdma->Init.DMA_DIR == DMA_PERIPH_TO_MEMORY)
                {
                    CLEAR_CACHE();
                }

                return HAL_OK;
            }
        }
        else
        {
            if ((DMAy->HTF_INT_RAW & chbit) != RESET)
            {
                /* Clear the half transfer flag only: the full transfer is
                   still pending, the state stays BUSY */
                DMAy->HTF_INT_RAW = chbit;

                /* Release Lock */
                DMA_UnlockHandle(hdma);

                /* Finalize the data cache of the half that has been delivered
                   to a receive buffer */
                if (hdma->Init.DMA_DIR == DMA_PERIPH_TO_MEMORY)
                {
                    CLEAR_CACHE();
                }

                return HAL_OK;
            }
        }

        /* Check for the Timeout */
        if (Timeout != HAL_MAX_DELAY)
        {
            if ((Timeout == 0U) || ((HAL_GetTick() - tickstart) > Timeout))
            {
                /* Update error code */
                hdma->ErrorCode = HAL_DMA_ERROR_TIMEOUT;

                /* Change the DMA state */
                hdma->State = HAL_DMA_STATE_READY;

                /* Release Lock */
                DMA_UnlockHandle(hdma);

                return HAL_TIMEOUT;
            }
        }

        /* Release the lock before yielding: the wait does not hold the handle
           mutex (architecture rule section 12), and a yield taken while
           holding it would starve every other user of this channel */
        DMA_UnlockHandle(hdma);

        /* Yield the CPU so that a task of the same priority is not starved
         * while the transfer completes (architecture rules RTOS-04/05; the
         * hook is an empty macro in a bare-metal build) */
        HAL_RTOS_Yield();
    }
}

/**
 * @brief  Handle the DMA interrupt request of one channel.
 * @note   One IRQ line is shared by the 16 channels of a controller: the user
 *         DMA0_IRQ_Handler() / DMA1_IRQ_Handler() (PLIC entries, see
 *         as32x601_plic.h) must call HAL_DMA_IRQHandler() for every active
 *         channel handle of the controller. The masked status registers are
 *         polled, so only the unmasked (enabled) interrupts are serviced.
 *         The WDG interrupt is global and not channel related: it must be
 *         polled by the user with HAL_DMA_GetITStatus(DMAy, DMA_IT_WDG) and
 *         cleared with HAL_DMA_ClearITPendingBit(DMAy, DMA_IT_WDG).
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @retval None
 */
void HAL_DMA_IRQHandler(DMA_HandleTypeDef *hdma)
{
    uint32 tmpisr;
    DMA_TypeDef *DMAy;
    uint32 chbit;

    /* Check the hdma handle allocation (first entry check, before any use
     * of the handle) */
    if (hdma == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_DMA_ALL_INSTANCE(hdma->Instance));

    DMAy = DMA_GET_DMAy(hdma);
    chbit = (uint32)(1UL << hdma->ChannelIndex);

    /* Transfer Error Interrupt management ***********************************/
    tmpisr = DMAy->ERR_INT_STATUS;
    if ((tmpisr & chbit) != RESET)
    {
        uint32 primask = DMA_EnterCritical();

        /* Clear the transfer error flag (write one clears, so the bit of this
           channel is written directly and the pending flags of the other
           channels of the controller are preserved) */
        DMAy->ERR_INT_RAW = chbit;

        /* Mask the transfer error interrupt */
        DMAy->ERR_INT_MASK |= chbit;

        DMA_ExitCritical(primask);

        /* Update error code */
        hdma->ErrorCode |= HAL_DMA_ERROR_TE;
    }

    /* Half Transfer Complete Interrupt management ***************************/
    tmpisr = DMAy->HTF_INT_STATUS;
    if ((tmpisr & chbit) != RESET)
    {
        uint32 primask = DMA_EnterCritical();

        /* Clear the half transfer flag (write one clears, this channel only) */
        DMAy->HTF_INT_RAW = chbit;

        /* Mask the half transfer interrupt if the DMA mode is not CIRCULAR */
        if ((hdma->Instance->CHCTL & DMA_CHCTL_CIRC) == RESET)
        {
            DMAy->HTF_INT_MASK |= chbit;
        }

        DMA_ExitCritical(primask);

        /* Finalize the data cache of the half that has been delivered: a
           receive transfer wrote memory behind the cache and the callback
           below reads it */
        if (hdma->Init.DMA_DIR == DMA_PERIPH_TO_MEMORY)
        {
            CLEAR_CACHE();
        }

        if (hdma->XferHalfCpltCallback != NULL)
        {
            /* Half transfer callback */
            hdma->XferHalfCpltCallback(hdma);
        }
    }

    /* Full Transfer Complete Interrupt management ***************************/
    tmpisr = DMAy->FTF_INT_STATUS;
    if ((tmpisr & chbit) != RESET)
    {
        /* Clear the full transfer flag */
        DMAy->FTF_INT_RAW = chbit;

        if (HAL_DMA_STATE_ABORT == hdma->State)
        {
            /* Mask all the transfer interrupts of the channel (the three mask
               registers are shared by the 16 channels of the controller) */
            DMA_MaskChannelSources(DMAy, hdma->ChannelIndex);

            /* Change the DMA state */
            hdma->State = HAL_DMA_STATE_READY;

            /* Finalize the data cache of what a receive transfer delivered
               before the callback reads it */
            if (hdma->Init.DMA_DIR == DMA_PERIPH_TO_MEMORY)
            {
                CLEAR_CACHE();
            }

            if (hdma->XferAbortCallback != NULL)
            {
                hdma->XferAbortCallback(hdma);
            }
            return;
        }

        /* Mask the full transfer interrupt if the DMA mode is not CIRCULAR */
        if ((hdma->Instance->CHCTL & DMA_CHCTL_CIRC) == RESET)
        {
            DMAy->FTF_INT_MASK |= chbit;

            /* The one shot transfer is over: stop the channel. This controller
               does not clear the channel enable bit at the end of a normal
               transfer, and a counter written while the channel is enabled is
               not loaded (it wraps), so the channel has to be left disabled to
               be re-armed by the next HAL_DMA_Start()/HAL_DMA_Start_IT(). */
            DMA_SetChannelEnable(DMAy, hdma->ChannelIndex, 0U);

            /* Change the DMA state */
            hdma->State = HAL_DMA_STATE_READY;
        }

        /* For a peripheral-to-memory (receive) transfer, flush and invalidate
           the data cache so the callback reads the freshly DMA-written buffer */
        if (hdma->Init.DMA_DIR == DMA_PERIPH_TO_MEMORY)
        {
            CLEAR_CACHE();
        }

        if (hdma->XferCpltCallback != NULL)
        {
            /* Full transfer callback */
            hdma->XferCpltCallback(hdma);
        }
    }

    /* Manage error case */
    if (hdma->ErrorCode != HAL_DMA_ERROR_NONE)
    {
        hdma->State = HAL_DMA_STATE_ABORT;

        /* Disable the channel (the CHEN register is shared by the 16 channels
           of the controller) */
        DMA_SetChannelEnable(DMAy, hdma->ChannelIndex, 0U);

        /* Change the DMA state */
        hdma->State = HAL_DMA_STATE_READY;

        /* Finalize the data cache of what a receive transfer delivered before
           the error callback reads it */
        if (hdma->Init.DMA_DIR == DMA_PERIPH_TO_MEMORY)
        {
            CLEAR_CACHE();
        }

        if (hdma->XferErrorCallback != NULL)
        {
            /* Transfer error callback */
            hdma->XferErrorCallback(hdma);
        }
    }
}

/**
  * @}
  */

/** @defgroup DMA_Exported_Functions_Group3 Peripheral Control and Flag functions
  * @{
  */

/**
 * @brief  Enable or disable the specified DMA channel interrupt sources. (NON-BLOCKING)
 * @note   The interrupt mask registers are
 *         inverted on this chip: a mask bit set to 1 disables the interrupt.
 * @param  hdma:    pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @param  DMA_IT:  specifies the DMA interrupt source to be enabled or disabled.
 *         This parameter can be DMA_ERR_IT / DMA_FTF_IT / DMA_HTF_IT
 *         / DMA_WDG_IT.
 * @param  NewState: new state of the DMA interrupt. This parameter can be
 *         ENABLE or DISABLE.
 * @retval None
 */
void HAL_DMA_ITConfig(DMA_HandleTypeDef *hdma, uint32 DMA_IT, FunctionalState NewState)
{
    DMA_TypeDef *DMAy;
    uint32 chbit;
    uint32 primask;

    /* Check the hdma handle allocation (first entry check, before any use
     * of the handle) */
    if (hdma == NULL_PTR)
    {
        return;
    }
    assert_param(IS_DMA_ALL_INSTANCE(hdma->Instance));
    assert_param(IS_DMA_CONFIG_IT(DMA_IT));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Run time validation, so that an invalid source or an invalid state does
     * not write a register in a build with the assertions disabled. The
     * refusal is not observable by the caller (the interface returns void),
     * which its documentation states. */
    if ((IS_DMA_CONFIG_IT(DMA_IT) == 0U) || (IS_FUNCTIONAL_STATE(NewState) == 0U))
    {
        return;
    }

    DMAy = DMA_GET_DMAy(hdma);
    chbit = (uint32)(1UL << hdma->ChannelIndex);

    /* The mask registers are shared by the 16 channels of the controller, so
       the read-modify-write of one source bit runs in a short critical
       section. */
    primask = DMA_EnterCritical();

    switch (DMA_IT)
    {
        case DMA_ERR_IT:
            if (NewState != DISABLE)
            {
                DMAy->ERR_INT_MASK &= (uint32)(~chbit);
            }
            else
            {
                DMAy->ERR_INT_MASK |= chbit;
            }
            break;

        case DMA_FTF_IT:
            if (NewState != DISABLE)
            {
                DMAy->FTF_INT_MASK &= (uint32)(~chbit);
            }
            else
            {
                DMAy->FTF_INT_MASK |= chbit;
            }
            break;

        case DMA_HTF_IT:
            if (NewState != DISABLE)
            {
                DMAy->HTF_INT_MASK &= (uint32)(~chbit);
            }
            else
            {
                DMAy->HTF_INT_MASK |= chbit;
            }
            break;

        default:   /* DMA_WDG_IT: controller level, single bit 0 */
            if (NewState != DISABLE)
            {
                DMAy->WDG_INT_MASK &= (uint32)(~DMA_WDG_INT_MASK_MASK);
            }
            else
            {
                DMAy->WDG_INT_MASK |= DMA_WDG_INT_MASK_MASK;
            }
            break;
    }

    DMA_ExitCritical(primask);
}

/**
 * @brief  Fill each DMA_InitStruct member with its default value. (NON-BLOCKING)
 * @param  DMA_InitStruct: pointer to a DMA_InitTypeDef structure which will
 *         be initialized.
 * @retval None
 */
void HAL_DMA_StructInit(DMA_InitTypeDef *DMA_InitStruct)
{
    /* Check the DMA init structure allocation */
    if (DMA_InitStruct == NULL_PTR)
    {
        return;
    }

    /* Initialize the Size / Version metafields */
    DMA_InitStruct->Size = sizeof(DMA_InitTypeDef);
    DMA_InitStruct->Version = DMA_INIT_VERSION;

    /* Initialize the DMA_PeripheralBaseAddr member */
    DMA_InitStruct->DMA_PeripheralBaseAddr = 0;
    /* Initialize the DMA_MemoryBaseAddr member */
    DMA_InitStruct->DMA_MemoryBaseAddr = 0;
    /* Initialize the DMA_DIR member */
    DMA_InitStruct->DMA_DIR = DMA_PERIPH_TO_MEMORY;
    /* Initialize the DMA_BufferSize member */
    DMA_InitStruct->DMA_BufferSize = 0;
    /* Initialize the DMA_PeripheralInc member */
    DMA_InitStruct->DMA_PeripheralInc = DMA_PINC_DISABLE;
    /* Initialize the DMA_MemoryInc member */
    DMA_InitStruct->DMA_MemoryInc = DMA_MINC_DISABLE;
    /* Initialize the DMA_PeripheralDataSize member */
    DMA_InitStruct->DMA_PeripheralDataSize = DMA_PDATAALIGN_BYTE;
    /* Initialize the DMA_MemoryDataSize member */
    DMA_InitStruct->DMA_MemoryDataSize = DMA_MDATAALIGN_BYTE;
    /* Initialize the DMA_Priority member */
    DMA_InitStruct->DMA_Priority = DMA_PRIORITY_LOW;
    /* Initialize the DMA_M2M member */
    DMA_InitStruct->DMA_M2M = DMA_M2M_Disable;
    /* Initialize the DMA_Mode member */
    DMA_InitStruct->DMA_Mode = DMA_NORMAL;
    /* Initialize the Reserved member */
    DMA_InitStruct->Reserved[0] = 0U;
    DMA_InitStruct->Reserved[1] = 0U;
}

/**
 * @brief  Set the number of data units in the current DMA channel transfer. (NON-BLOCKING)
 * @param  hdma:       pointer to a DMA_HandleTypeDef structure that contains
 *         the configuration information for the specified DMA channel.
 * @param  DataNumber: the number of data units in the current DMA channel transfer.
 * @retval None
 */
void HAL_DMA_SetCurrDataCounter(DMA_HandleTypeDef *hdma, uint16 DataNumber)
{
    /* Check the hdma handle allocation and the channel instance binding: a
       handle whose instance is not an approved channel has no register to
       write */
    if (DMA_HandleIsValid(hdma) == 0U)
    {
        return;
    }
    assert_param(IS_DMA_ALL_INSTANCE(hdma->Instance));

    /* The counter domain needs no run time check: the parameter type (uint16)
     * already bounds it to 0..0xFFFF, and a comparison against those bounds
     * would be tautological. The interface returns void, so a refused value is
     * not observable by the caller (its documentation states it). */

    /* Write to the DMA channel CHCNT register */
    hdma->Instance->CHCNT = DataNumber;
}

/**
 * @brief  Return the number of remaining data units in the current DMA channel transfer. (NON-BLOCKING)
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @retval The number of remaining data units in the current transfer.
 */
uint16 HAL_DMA_GetCurrDataCounter(DMA_HandleTypeDef *hdma)
{
    /* Check the hdma handle allocation and the channel instance binding: a
       handle whose instance is not an approved channel has no register to
       read */
    if (DMA_HandleIsValid(hdma) == 0U)
    {
        return 0U;
    }
    assert_param(IS_DMA_ALL_INSTANCE(hdma->Instance));

    /* Return the number of remaining data units */
    return (uint16)(hdma->Instance->CHCNT);
}

/**
 * @brief  Check whether the specified DMA flag is set or not. (NON-BLOCKING)
 * @param  DMAy:     where y can be 0 or 1 to select the DMA controller.
 * @param  DMA_FLAG: DMA_FLAG_ERRx / DMA_FLAG_FTFx / DMA_FLAG_HTFx / DMA_FLAG_WDG
 *         where x can be 0 to 15 to select the DMA channel.
 * @retval The new state of DMA_FLAG (SET or RESET).
 */
FlagStatus HAL_DMA_GetFlagStatus(DMA_TypeDef *DMAy, uint32 DMA_FLAG)
{
    /* Check the DMAy handle allocation */
    if (DMAy == NULL_PTR)
    {
        return RESET;
    }
    FlagStatus bitstatus = RESET;
    uint32 tmpreg = 0;

    /* Check the parameters */
    assert_param(IS_DMA_FLAG(DMA_FLAG));
    assert_param(IS_DMA_TypeDef(DMAy));

    /* Check if the flag is in ERR_INT_RAW, FTF_INT_RAW, HTF_INT_RAW or
       WDG_INT_RAW */
    if ((DMA_FLAG & DMA_MASK_ERR) == DMA_MASK_ERR)
    {
        /* Get DMAy ERR_INT_RAW register value */
        tmpreg = DMAy->ERR_INT_RAW;
    }
    else if ((DMA_FLAG & DMA_MASK_FTF) == DMA_MASK_FTF)
    {
        /* Get DMAy FTF_INT_RAW register value */
        tmpreg = DMAy->FTF_INT_RAW;
    }
    else if ((DMA_FLAG & DMA_MASK_HTF) == DMA_MASK_HTF)
    {
        /* Get DMAy HTF_INT_RAW register value */
        tmpreg = DMAy->HTF_INT_RAW;
    }
    else
    {
        if ((DMA_FLAG & DMA_MASK_WDG) == DMA_MASK_WDG)
        {
            /* Get DMAy WDG_INT_RAW register value */
            tmpreg = DMAy->WDG_INT_RAW;
        }
    }

    /* Check the status of the specified DMA flag */
    if ((tmpreg & DMA_FLAG) != (uint32)RESET)
    {
        /* DMAy_FLAG is set */
        bitstatus = SET;
    }
    else
    {
        /* DMAy_FLAG is reset */
        bitstatus = RESET;
    }

    /* Return the DMAy_FLAG status */
    return bitstatus;
}

/**
 * @brief  Clear the specified DMA flag (write 1 to the raw register). (NON-BLOCKING)
 * @param  DMAy:     where y can be 0 or 1 to select the DMA controller.
 * @param  DMA_FLAG: DMA_FLAG_ERRx / DMA_FLAG_FTFx / DMA_FLAG_HTFx / DMA_FLAG_WDG
 *         where x can be 0 to 15 to select the DMA channel.
 * @retval None
 */
void HAL_DMA_ClearFlag(DMA_TypeDef *DMAy, uint32 DMA_FLAG)
{
    /* Check the parameters */
    /* Check the DMAy handle allocation */
    if (DMAy == NULL_PTR)
    {
        return;
    }
    assert_param(IS_DMA_CLEAR_FLAG(DMA_FLAG));
    assert_param(IS_DMA_TypeDef(DMAy));

    /* Check if the flag is in ERR_INT_RAW, FTF_INT_RAW, HTF_INT_RAW or
       WDG_INT_RAW */
    if ((DMA_FLAG & DMA_MASK_ERR) == DMA_MASK_ERR)
    {
        /* Clear DMA ERR_INT_RAW register value (write 1, channel bits only:
           the type field of the encoding is not a register bit) */
        DMAy->ERR_INT_RAW = (DMA_FLAG & DMA_FLAG_CHANNEL_MASK);
    }
    else if ((DMA_FLAG & DMA_MASK_FTF) == DMA_MASK_FTF)
    {
        /* Clear DMA FTF_INT_RAW register value (write 1, channel bits only) */
        DMAy->FTF_INT_RAW = (DMA_FLAG & DMA_FLAG_CHANNEL_MASK);
    }
    else if ((DMA_FLAG & DMA_MASK_HTF) == DMA_MASK_HTF)
    {
        /* Clear DMA HTF_INT_RAW register value (write 1, channel bits only) */
        DMAy->HTF_INT_RAW = (DMA_FLAG & DMA_FLAG_CHANNEL_MASK);
    }
    else
    {
        if ((DMA_FLAG & DMA_MASK_WDG) == DMA_MASK_WDG)
        {
            /* Clear DMA WDG_INT_RAW register value (write 1, the controller
               level source keeps its single status bit) */
            DMAy->WDG_INT_RAW = (DMA_FLAG & DMA_FLAG_CHANNEL_MASK);
        }
    }
}

/**
 * @brief  Check whether the specified DMA interrupt is set or not (masked (NON-BLOCKING)
 *         status). (NON-BLOCKING)
 * @param  DMAy:   where y can be 0 or 1 to select the DMA controller.
 * @param  DMAy_IT: DMA_IT_ERRx / DMA_IT_FTFx / DMA_IT_HTFx / DMA_IT_WDG
 *         where x can be 0 to 15 to select the DMA channel.
 * @retval The new state of DMAy_IT (SET or RESET).
 */
ITStatus HAL_DMA_GetITStatus(DMA_TypeDef *DMAy, uint32 DMAy_IT)
{
    /* Check the DMAy handle allocation */
    if (DMAy == NULL_PTR)
    {
        return RESET;
    }
    ITStatus bitstatus = RESET;
    uint32 tmpreg = 0;

    /* Check the parameters */
    assert_param(IS_DMA_IT(DMAy_IT));
    assert_param(IS_DMA_TypeDef(DMAy));

    /* Check if the flag is in ERR_INT_STATUS, FTF_INT_STATUS, HTF_INT_STATUS
       or WDG_INT_STATUS */
    if ((DMAy_IT & DMA_MASK_ERR) == DMA_MASK_ERR)
    {
        /* Get DMAy ERR_INT_STATUS register value */
        tmpreg = DMAy->ERR_INT_STATUS;
    }
    else if ((DMAy_IT & DMA_MASK_FTF) == DMA_MASK_FTF)
    {
        /* Get DMAy FTF_INT_STATUS register value */
        tmpreg = DMAy->FTF_INT_STATUS;
    }
    else if ((DMAy_IT & DMA_MASK_HTF) == DMA_MASK_HTF)
    {
        /* Get DMAy HTF_INT_STATUS register value */
        tmpreg = DMAy->HTF_INT_STATUS;
    }
    else
    {
        if ((DMAy_IT & DMA_MASK_WDG) == DMA_MASK_WDG)
        {
            /* Get DMAy WDG_INT_STATUS register value */
            tmpreg = DMAy->WDG_INT_STATUS;
        }
    }

    /* Check the status of the specified DMA interrupt */
    if ((tmpreg & DMAy_IT) != (uint32)RESET)
    {
        /* DMAy_IT is set */
        bitstatus = SET;
    }
    else
    {
        /* DMAy_IT is reset */
        bitstatus = RESET;
    }

    /* Return the DMAy_IT status */
    return bitstatus;
}

/**
 * @brief  Clear the specified DMA interrupt pending bit (write 1 to the raw (NON-BLOCKING)
 *         register; the masked status register is read-only). (NON-BLOCKING)
 * @param  DMAy:   where y can be 0 or 1 to select the DMA controller.
 * @param  DMAy_IT: DMA_IT_ERRx / DMA_IT_FTFx / DMA_IT_HTFx / DMA_IT_WDG
 *         where x can be 0 to 15 to select the DMA channel.
 * @retval None
 */
void HAL_DMA_ClearITPendingBit(DMA_TypeDef *DMAy, uint32 DMAy_IT)
{
    /* Check the parameters */
    /* Check the DMAy handle allocation */
    if (DMAy == NULL_PTR)
    {
        return;
    }
    assert_param(IS_DMA_CLEAR_IT(DMAy_IT));
    assert_param(IS_DMA_TypeDef(DMAy));

    /* Check if the flag is in ERR_INT_STATUS, FTF_INT_STATUS, HTF_INT_STATUS
       or WDG_INT_STATUS */
    if ((DMAy_IT & DMA_MASK_ERR) == DMA_MASK_ERR)
    {
        /* Clear DMA ERR_INT_RAW register value (write 1, channel bits only:
           the type field of the encoding is not a register bit) */
        DMAy->ERR_INT_RAW = (DMAy_IT & DMA_FLAG_CHANNEL_MASK);
    }
    else if ((DMAy_IT & DMA_MASK_FTF) == DMA_MASK_FTF)
    {
        /* Clear DMA FTF_INT_RAW register value (write 1, channel bits only) */
        DMAy->FTF_INT_RAW = (DMAy_IT & DMA_FLAG_CHANNEL_MASK);
    }
    else if ((DMAy_IT & DMA_MASK_HTF) == DMA_MASK_HTF)
    {
        /* Clear DMA HTF_INT_RAW register value (write 1, channel bits only) */
        DMAy->HTF_INT_RAW = (DMAy_IT & DMA_FLAG_CHANNEL_MASK);
    }
    else
    {
        if ((DMAy_IT & DMA_MASK_WDG) == DMA_MASK_WDG)
        {
            /* Clear DMA WDG_INT_RAW register value (write 1, the controller
               level source keeps its single status bit) */
            DMAy->WDG_INT_RAW = (DMAy_IT & DMA_FLAG_CHANNEL_MASK);
        }
    }
}

/**
  * @}
  */

/** @defgroup DMA_Exported_Functions_Group4 Callback registration functions
  * @{
  */

/**
 * @brief  Clean all the callbacks of the DMA handle. (NON-BLOCKING)
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @retval HAL_StatusTypeDef: HAL_OK.
 */
HAL_StatusTypeDef HAL_DMA_CleanCallbacks(DMA_HandleTypeDef *hdma)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the DMA handle and the channel instance */
    if (DMA_HandleIsValid(hdma) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when a transfer is ongoing (BUSY) or when
     * the handle has not been initialized (RESET, HAL_DMA_Init() is required
     * first). The recoverable states TIMEOUT / ERROR / ABORT accept a new
     * operation directly, once the channel has really stopped. */
    status = DMA_CheckState(hdma);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (DMA_LockHandle(hdma, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* The interrupt handler reads the callback pointers without taking the
       handle lock, so they are cleared inside a short interrupt masked
       critical section: the ISR must never service a half cleared set. */
    {
        uint32 primask = DMA_EnterCritical();

        hdma->XferCpltCallback = NULL;
        hdma->XferHalfCpltCallback = NULL;
        hdma->XferErrorCallback = NULL;
        hdma->XferAbortCallback = NULL;

        DMA_ExitCritical(primask);
    }

    /* Release Lock */
    DMA_UnlockHandle(hdma);

    return HAL_OK;
}

/**
 * @brief  Register the callbacks of the DMA handle. (NON-BLOCKING)
 * @param  hdma:       pointer to a DMA_HandleTypeDef structure that contains
 *         the configuration information for the specified DMA channel.
 * @param  CallbackID: user callback identifier (HAL_DMA_XFER_CPLT_CB_ID /
 *         HAL_DMA_XFER_HALFCPLT_CB_ID / HAL_DMA_XFER_ERROR_CB_ID /
 *         HAL_DMA_XFER_ABORT_CB_ID / HAL_DMA_XFER_ALL_CB_ID).
 * @param  pCallback:  pointer to the private callback function which takes a
 *         DMA_HandleTypeDef structure as parameter.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_DMA_RegisterCallback(DMA_HandleTypeDef *hdma, HAL_DMA_CallbackIDTypeDef CallbackID,
                                           void (*pCallback)(DMA_HandleTypeDef *_hdma))
{
    HAL_StatusTypeDef status = HAL_OK;
    uint32 CallbackValid = 1U;
    uint32 primask;

    /* Check the DMA handle and the channel instance */
    if (DMA_HandleIsValid(hdma) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_DMA_ALL_INSTANCE(hdma->Instance));

    /* ARCH-CONST-09: reject the call when a transfer is ongoing (BUSY) or when
     * the handle has not been initialized (RESET, HAL_DMA_Init() is required
     * first). The recoverable states TIMEOUT / ERROR / ABORT accept a new
     * operation directly, once the channel has really stopped. */
    status = DMA_CheckState(hdma);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (DMA_LockHandle(hdma, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* The interrupt handler reads the callback pointers without taking the
       handle lock, so they are published inside a short interrupt masked
       critical section: the ISR must never service a half updated set. */
    primask = DMA_EnterCritical();

    switch (CallbackID)
    {
        case HAL_DMA_XFER_CPLT_CB_ID:
            hdma->XferCpltCallback = pCallback;
            break;

        case HAL_DMA_XFER_HALFCPLT_CB_ID:
            hdma->XferHalfCpltCallback = pCallback;
            break;

        case HAL_DMA_XFER_ERROR_CB_ID:
            hdma->XferErrorCallback = pCallback;
            break;

        case HAL_DMA_XFER_ABORT_CB_ID:
            hdma->XferAbortCallback = pCallback;
            break;

        case HAL_DMA_XFER_ALL_CB_ID:
            hdma->XferCpltCallback = pCallback;
            hdma->XferHalfCpltCallback = pCallback;
            hdma->XferErrorCallback = pCallback;
            hdma->XferAbortCallback = pCallback;
            break;

        default:
            /* Report the invalid identifier without touching the callbacks */
            CallbackValid = 0U;
            break;
    }

    DMA_ExitCritical(primask);

    if (CallbackValid == 0U)
    {
        hdma->ErrorCode |= HAL_DMA_ERROR_PARAM;
        status = HAL_ERROR;
    }

    /* Release Lock */
    DMA_UnlockHandle(hdma);

    return status;
}

/**
 * @brief  Un-register the callbacks of the DMA handle. (NON-BLOCKING)
 * @param  hdma:       pointer to a DMA_HandleTypeDef structure that contains
 *         the configuration information for the specified DMA channel.
 * @param  CallbackID: user callback identifier (HAL_DMA_XFER_CPLT_CB_ID /
 *         HAL_DMA_XFER_HALFCPLT_CB_ID / HAL_DMA_XFER_ERROR_CB_ID /
 *         HAL_DMA_XFER_ABORT_CB_ID / HAL_DMA_XFER_ALL_CB_ID).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_DMA_UnRegisterCallback(DMA_HandleTypeDef *hdma, HAL_DMA_CallbackIDTypeDef CallbackID)
{
    HAL_StatusTypeDef status = HAL_OK;
    uint32 CallbackValid = 1U;
    uint32 primask;

    /* Check the DMA handle and the channel instance */
    if (DMA_HandleIsValid(hdma) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_DMA_ALL_INSTANCE(hdma->Instance));

    /* ARCH-CONST-09: reject the call when a transfer is ongoing (BUSY) or when
     * the handle has not been initialized (RESET, HAL_DMA_Init() is required
     * first). The recoverable states TIMEOUT / ERROR / ABORT accept a new
     * operation directly, once the channel has really stopped. */
    status = DMA_CheckState(hdma);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (DMA_LockHandle(hdma, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* The interrupt handler reads the callback pointers without taking the
       handle lock, so they are cleared inside a short interrupt masked
       critical section: the ISR must never service a half cleared set. */
    primask = DMA_EnterCritical();

    switch (CallbackID)
    {
        case HAL_DMA_XFER_CPLT_CB_ID:
            hdma->XferCpltCallback = NULL;
            break;

        case HAL_DMA_XFER_HALFCPLT_CB_ID:
            hdma->XferHalfCpltCallback = NULL;
            break;

        case HAL_DMA_XFER_ERROR_CB_ID:
            hdma->XferErrorCallback = NULL;
            break;

        case HAL_DMA_XFER_ABORT_CB_ID:
            hdma->XferAbortCallback = NULL;
            break;

        case HAL_DMA_XFER_ALL_CB_ID:
            hdma->XferCpltCallback = NULL;
            hdma->XferHalfCpltCallback = NULL;
            hdma->XferErrorCallback = NULL;
            hdma->XferAbortCallback = NULL;
            break;

        default:
            /* Report the invalid identifier without touching the callbacks */
            CallbackValid = 0U;
            break;
    }

    DMA_ExitCritical(primask);

    if (CallbackValid == 0U)
    {
        hdma->ErrorCode |= HAL_DMA_ERROR_PARAM;
        status = HAL_ERROR;
    }

    /* Release Lock */
    DMA_UnlockHandle(hdma);

    return status;
}

/**
  * @}
  */

/** @defgroup DMA_Exported_Functions_Group5 Peripheral State and Errors functions
  * @{
  */

/**
 * @brief  Return the DMA handle state. (NON-BLOCKING)
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @retval HAL_DMA_StateTypeDef: HAL_DMA_STATE_RESET / READY / BUSY / TIMEOUT
 *         / ERROR / ABORT.
 */
HAL_DMA_StateTypeDef HAL_DMA_GetState(DMA_HandleTypeDef *hdma)
{
    /* Return the DMA handle state */
    /* Check the hdma handle allocation and the channel instance binding: a
       handle that is not bound to an approved channel has no state to report
       (the same answer as an uninitialized handle) */
    if (DMA_HandleIsValid(hdma) == 0U)
    {
        return HAL_DMA_STATE_RESET;
    }
    return hdma->State;
}

/**
 * @brief  Return the DMA error code. (NON-BLOCKING)
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @retval DMA Error Code: HAL_DMA_ERROR_NONE / TE / TIMEOUT / PARAM / NO_XFER
 *         / NOT_SUPPORTED.
 */
uint32 HAL_DMA_GetError(DMA_HandleTypeDef *hdma)
{
    /* Return the DMA error code */
    /* Check the hdma handle allocation and the channel instance binding: a
       handle that is not bound to an approved channel reports no error (the
       same answer as an uninitialized handle) */
    if (DMA_HandleIsValid(hdma) == 0U)
    {
        return 0U;
    }
    return hdma->ErrorCode;
}

/**
  * @}
  */

/**
  * @}
  */

/* Exported functions ---------------------------------------------------------*/

/** @defgroup DMA_Exported_Functions DMA Exported Functions
  * @{
  */

/** @defgroup DMA_Exported_Functions_Group1 Extended features functions
  * @{
  */

/**
 * @brief  Configure the DMA watchdog of a controller. (NON-BLOCKING)
 * @note   The watchdog is a controller level
 *         feature: it generates the global WDG interrupt (DMA_IT_WDG) when
 *         the configured counter elapses without any transfer progress. The
 *         WDG interrupt enable is handled separately by HAL_DMA_ITConfig()
 *         or __HAL_DMA_ENABLE_IT() with DMA_WDG_IT, and the WDG flag is
 *         polled with HAL_DMA_GetITStatus(DMAy, DMA_IT_WDG).
 * @param  DMAy:     where y can be 0 or 1 to select the DMA controller.
 * @param  Counter:  specifies the watchdog counter value (0x0000..0xFFFF).
 * @param  NewState: new state of the DMA watchdog. This parameter can be
 *         ENABLE or DISABLE.
 * @retval None
 */
void HAL_DMA_ConfigWatchDog(DMA_TypeDef *DMAy, uint16 Counter, FunctionalState NewState)
{
    uint32 primask;

    /* Check the parameters */
    /* Check the DMAy handle allocation */
    if (DMAy == NULL_PTR)
    {
        return;
    }
    assert_param(IS_DMA_TypeDef(DMAy));
    /* The counter parameter is uint16 and the WDCNT field is 16 bits wide, so
       every value of the parameter is in range: a counter check here would be
       vacuously true (and used to raise -Wtype-limits at this call site).  The
       check macro is kept in the header for uint32 callers. */
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Run time parameter validation, so that the check stays effective in a
       build with the assertions disabled. The interface returns void, so the
       refusal is not observable by the caller. */
    if (IS_FUNCTIONAL_STATE(NewState) == 0U)
    {
        return;
    }

    /* The CCR register is shared by the 16 channels of the controller (and by
       the dual-core lock step), so the read-modify-write below runs inside a
       short interrupt masked critical section: an interrupt handler updating
       another field of the same register must not lose this update. */
    primask = DMA_EnterCritical();

    /* The threshold is taken over only while the watchdog is disabled: WDEN is
       cleared first, the counter is written next and the requested state is
       restored last, so that a threshold update cannot produce a spurious
       global timeout. */
    DMAy->CCR &= (uint32)(~DMA_CCR_WDEN);

    DMAy->CCR &= (uint32)(~DMA_CCR_WDCNT_Msk);
    DMAy->CCR |= ((uint32)Counter << DMA_CCR_WDCNT_Pos);

    if (NewState != DISABLE)
    {
        /* Enable the DMA watchdog */
        DMAy->CCR |= DMA_CCR_WDEN;
    }

    DMA_ExitCritical(primask);
}

/**
 * @brief  Enable or disable the dual-core lock step of a controller. (NON-BLOCKING)
 * @note   The dual-core lock step duplicates
 *         the DMA controller (DEN bit of the CCR register); the ready and
 *         error statuses are reported by the DRDY and DERR bits.
 * @param  DMAy:     where y can be 0 or 1 to select the DMA controller.
 * @param  NewState: new state of the dual-core lock step. This parameter can
 *         be ENABLE or DISABLE.
 * @retval None
 */
void HAL_DMA_DualCoreCmd(DMA_TypeDef *DMAy, FunctionalState NewState)
{
    uint32 primask;

    /* Check the parameters */
    /* Check the DMAy handle allocation */
    if (DMAy == NULL_PTR)
    {
        return;
    }
    assert_param(IS_DMA_TypeDef(DMAy));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Run time parameter validation, so that the check stays effective in a
       build with the assertions disabled. The interface returns void, so the
       refusal is not observable by the caller. */
    if (IS_FUNCTIONAL_STATE(NewState) == 0U)
    {
        return;
    }

    /* The CCR register is shared by the 16 channels of the controller, so the
       read-modify-write below runs inside a short interrupt masked critical
       section */
    primask = DMA_EnterCritical();

    if (NewState != DISABLE)
    {
        /* Enable the dual-core lock step */
        DMAy->CCR |= DMA_CCR_DEN;
    }
    else
    {
        /* Disable the dual-core lock step */
        DMAy->CCR &= (uint32)(~DMA_CCR_DEN);
    }

    DMA_ExitCritical(primask);
}

/**
 * @brief  Configure the peripheral interface number of a DMA channel. (NON-BLOCKING)
 * @note   Channels 0..7 are mapped in the PTCH0
 *         register (4 bits per channel), channels 8..15 in the PTCH1
 *         register. The interface numbers are controller dependent: the
 *         first group is wired to DMA0, the second group to DMA1.
 * @param  hdma:      pointer to a DMA_HandleTypeDef structure that contains
 *         the configuration information for the specified DMA channel.
 * @param  IF_Number: DMA channel peripheral interface number (TIM0_IF /
 *         ADC0_IF / ... / TIM7_IF, see the DMA interface groups).
 * @retval None
 */
void HAL_DMA_ConfigPeriphIF(DMA_HandleTypeDef *hdma, uint32 IF_Number)
{
    DMA_TypeDef *DMAy;
    uint32 Channelx;
    uint32 fieldshift;
    uint32 primask;
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the DMA handle and the channel instance */
    if (DMA_HandleIsValid(hdma) == 0U)
    {
        return;
    }
    assert_param(IS_DMA_ALL_INSTANCE(hdma->Instance));
    assert_param(IS_PeriphInterface_Number(IF_Number));

    DMAy = DMA_GET_DMAy(hdma);
    Channelx = hdma->ChannelIndex;

    /* Run time parameter validation, so that the checks stay effective in a
     * build with the assertions disabled. The request number must belong to
     * the connection table of the controller that owns the channel: the
     * numbers of DMA0 and DMA1 overlap (0x00 names TIM0 on DMA0 and TIM1 on
     * DMA1, ...), so a number taken from the other controller would silently
     * map an unrelated peripheral. The interface returns void, so the refusal
     * is not observable by the caller. */
    if (DMAy == DMA0)
    {
        if (IS_DMA0_PERIPH_IF(IF_Number) == 0U)
        {
            return;
        }
    }
    else
    {
        if (IS_DMA1_PERIPH_IF(IF_Number) == 0U)
        {
            return;
        }
    }

    /* ARCH-CONST-09: reject the call when a transfer is ongoing (BUSY) or when
     * the handle has not been initialized (RESET, HAL_DMA_Init() is required
     * first); the interface mapping is a configuration of an idle channel */
    status = DMA_CheckState(hdma);
    if (status != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (DMA_LockHandle(hdma, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    /* The PTCH0 / PTCH1 registers are shared by the channels of the
     * controller, so the read-modify-write runs inside a short interrupt
     * masked critical section. Channels 0..7 are mapped in PTCH0, channels
     * 8..15 in PTCH1, one four bit field per channel. */
    fieldshift = ((Channelx % DMA_PTCH_CHANNELS) * DMA_PTCH_FIELD_SHIFT);

    primask = DMA_EnterCritical();

    if (Channelx < DMA_PTCH_CHANNELS)
    {
        /* Configure the peripheral interface in the PTCH0 register */
        DMAy->PTCH0 &= (uint32)(~((uint32)DMA_PTCH_FIELD_MASK << fieldshift));
        DMAy->PTCH0 |= (IF_Number << fieldshift);
    }
    else
    {
        /* Configure the peripheral interface in the PTCH1 register */
        DMAy->PTCH1 &= (uint32)(~((uint32)DMA_PTCH_FIELD_MASK << fieldshift));
        DMAy->PTCH1 |= (IF_Number << fieldshift);
    }

    DMA_ExitCritical(primask);

    /* Release Lock */
    DMA_UnlockHandle(hdma);
}

/**
  * @}
  */

/**
  * @}
  */

/* Private functions ---------------------------------------------------------*/

/** @defgroup DMA_Private_Functions DMA Private Functions
  * @{
  */

/**
 * @brief  Set the DMA transfer parameters (addresses and data length).
 * @param  hdma:       pointer to a DMA_HandleTypeDef structure that contains
 *         the configuration information for the specified DMA channel.
 * @param  SrcAddress: the source memory buffer address
 * @param  DstAddress: the destination memory buffer address
 * @param  DataLength: the length of data to be transferred from source to destination
 * @retval None
 */
static void DMA_SetConfig(DMA_HandleTypeDef *hdma, uint32 SrcAddress, uint32 DstAddress, uint32 DataLength)
{
    /* Peripheral to Memory */
    if ((hdma->Init.DMA_DIR) == DMA_MEMORY_TO_PERIPH)
    {
        /* Configure the DMA channel destination address (peripheral) */
        hdma->Instance->CHPADDR = DstAddress;

        /* Configure the DMA channel source address (memory) */
        hdma->Instance->CHMADDR = SrcAddress;
    }
    /* Memory to Peripheral */
    else
    {
        /* Configure the DMA channel source address (peripheral) */
        hdma->Instance->CHPADDR = SrcAddress;

        /* Configure the DMA channel destination address (memory) */
        hdma->Instance->CHMADDR = DstAddress;
    }

    /* Configure the DMA channel data length */
    hdma->Instance->CHCNT = DataLength;
}

/**
 * @brief  Compute the channel index (0..15) of the handle from the channel
 *         base address (channels are spaced by 0x10 bytes).
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @retval The channel index (0..15).
 */
static uint32 DMA_CalcChannelIndex(DMA_HandleTypeDef *hdma)
{
    DMA_TypeDef *DMAy = DMA_GET_DMAy(hdma);

    return (((uint32)hdma->Instance - (uint32)DMAy) >> 4U);
}

/**
  * @}
  */

#endif /* HAL_DMA_MODULE_ENABLED */

/*****END OF FILE*****/

