/**
 * @file    TIM_IT_DRV_022.c
 * @brief   internal trigger: TIM1 TRGO (OC1REF) clocks TIM0 through ITR0
 *
 * HAL library port of the original AS32x601 standard-library test case
 * TIMER_IT_DRV_023.c, which drives TIM0 + TIM1. Only HAL library APIs are used; the register
 * read backs document what was programmed.
 *
 * Tested functionality:
 *   TIM_SelectOutputTrigger() -> HAL_TIM_MasterConfigSynchronization(TIM_TRGO_OC1REF)
 *   TIM_ITRxExternalClockConfig() -> HAL_TIM_ConfigClockSource(TIM_CLOCKSOURCE_ITR0)
 *   TIM_OC1Init()          -> HAL_TIM_PWM_ConfigChannel()
 *   TIM_Cmd(ENABLE)        -> HAL_TIM_PWM_Start() / HAL_TIM_Base_Start()
 *
 * Test procedure:
 *   configure TIM1 channel 1 (PD4) with a 450 Hz PWM and route its OC1REF to TRGO;
 *   configure TIM0 channel 1 (PC3) with ARR = 1000-1 and a 50 percent pulse;
 *   clock TIM0 from the ITR0 internal trigger and start both timers.
 *
 * Expected behaviour:
 *   TIM1 SMCR reads OC1REF as the TRGO source (CR2.MMS = 100);
 *   TIM0 SMCR reads SMS = 111 (external clock mode 1) and TS = ITR0;
 *   the TIM0 counter advances with the TIM1 trigger events and its PWM output follows;
 *   every check prints [PASS] and "summary : failures = 0".
 *
 * Note:
 *   TRGO of TIM1 must be wired to ITR0 of TIM0 in the device; the 450 Hz trigger of TIM1 comes
 *   from ARR = 10000-1 and PSC = 9-1 on the advanced timer clock (45 MHz / 10 / 10000 = 450 Hz).
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
/* Console: USART0 on GPIOD pin 8 (TX) / pin 9 (RX), 115200 8N1 */
#define TEST_BAUDRATE                   (115200U)


#define TEST_ARR_MASTER                 (10000U - 1U)
#define TEST_PSC_MASTER                 (9U - 1U)
#define TEST_ARR_SLAVE                  (1000U - 1U)
#define TEST_PULSE_SLAVE                (500U)


/* Private variables -------------------------------------------------------*/
static HAL_TIM_HandleTypeDef htim_dev;          /*!< timer under test        */
static HAL_SMU_HandleTypeDef hsmu_clk;          /*!< SMU handle (clock tree) */
static volatile uint32 check_failures = 0U;     /*!< failed check counter    */

static HAL_TIM_HandleTypeDef htim_master;       /*!< TIM1, the trigger source */



/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure one GPIO pin and, for the alternate function modes, the
 *         pin mux of that pin.
 * @param  port: GPIO port
 * @param  pin: pin mask
 * @param  source: pin source number (for the mux configuration)
 * @param  af: alternate function selector
 * @param  mode: GPIO_MODE_AF_PP / GPIO_MODE_INPUT
 * @retval None
 */
static void Gpio_Config(GPIO_TypeDef *port, uint32 pin, uint32 source, uint8 af, uint32 mode)
{
    GPIO_InitTypeDef gpio_init;

    __HAL_CLEAR_STRUCT(&gpio_init);
    gpio_init.Size         = sizeof(GPIO_InitTypeDef);
    gpio_init.Version      = GPIO_INIT_VERSION;
    gpio_init.Pin          = pin;
    gpio_init.Mode         = mode;
    gpio_init.Pull         = GPIO_NOPULL;
    gpio_init.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;
    gpio_init.Alternate    = af;
    if (mode == GPIO_MODE_AF_PP)
    {
        HAL_GPIO_PinAFConfig(port, source, af);
    }
    HAL_GPIO_Init(port, &gpio_init);
}

/**
 * @brief  Configure the time base of the timer under test.
 * @note   The helper keeps the Size / Version meta fields through
 *         HAL_TIM_Base_StructInit(), which the initialization interface
 *         validates at run time.
 * @param  instance: TIM0..TIM7
 * @param  arr: auto reload value
 * @param  psc: prescaler value
 * @param  rcr: repetition counter (advanced timers only)
 * @param  ckd: clock division
 * @param  countermode: counting mode
 * @retval HAL status of HAL_TIM_Base_Init()
 */
static HAL_StatusTypeDef TimeBase_Config(TIM_TypeDef *instance, uint32 arr, uint32 psc,
                                         uint32 rcr, uint32 ckd, uint32 countermode)
{
    TIM_Base_InitTypeDef base_init;

    __HAL_CLEAR_STRUCT(&htim_dev);
    htim_dev.Instance = instance;

    HAL_TIM_Base_StructInit(&base_init);
    base_init.CounterMode       = countermode;
    base_init.ClockDivision     = ckd;
    base_init.Period            = arr;
    base_init.Prescaler         = psc;
    base_init.RepetitionCounter = rcr;
    htim_dev.Init               = base_init;

    return HAL_TIM_Base_Init(&htim_dev);
}

/**
 * @brief  Enable the clock of a timer instance and release its reset.
 * @note   The default MSP callbacks of this module are empty, so the suite
 *         performs the gate and reset handling itself; every MSP callback is
 *         routed to this helper.
 * @param  instance: TIM0..TIM7
 * @retval None
 */
static void Tim_ClockEnable(TIM_TypeDef *instance)
{
    if (instance == TIM0)
    {
        __HAL_SMU_HTIM0_CLK_ENABLE();
        __HAL_SMU_HTIM0_FORCE_RESET();
        __HAL_SMU_HTIM0_RELEASE_RESET();
    }
    else if (instance == TIM1)
    {
        __HAL_SMU_HTIM1_CLK_ENABLE();
        __HAL_SMU_HTIM1_FORCE_RESET();
        __HAL_SMU_HTIM1_RELEASE_RESET();
    }
    else if (instance == TIM2)
    {
        __HAL_SMU_HTIM2_CLK_ENABLE();
        __HAL_SMU_HTIM2_FORCE_RESET();
        __HAL_SMU_HTIM2_RELEASE_RESET();
    }
    else if (instance == TIM3)
    {
        __HAL_SMU_TIM3_CLK_ENABLE();
        __HAL_SMU_TIM3_FORCE_RESET();
        __HAL_SMU_TIM3_RELEASE_RESET();
    }
    else if (instance == TIM4)
    {
        __HAL_SMU_TIM4_CLK_ENABLE();
        __HAL_SMU_TIM4_FORCE_RESET();
        __HAL_SMU_TIM4_RELEASE_RESET();
    }
    else if (instance == TIM5)
    {
        __HAL_SMU_HTIM5_CLK_ENABLE();
        __HAL_SMU_HTIM5_FORCE_RESET();
        __HAL_SMU_HTIM5_RELEASE_RESET();
    }
    else if (instance == TIM6)
    {
        __HAL_SMU_TIM6_CLK_ENABLE();
        __HAL_SMU_TIM6_FORCE_RESET();
        __HAL_SMU_TIM6_RELEASE_RESET();
    }
    else
    {
        __HAL_SMU_TIM7_CLK_ENABLE();
        __HAL_SMU_TIM7_FORCE_RESET();
        __HAL_SMU_TIM7_RELEASE_RESET();
    }
}

/* MSP callbacks: the timer clock and reset of the instance under test */
void HAL_TIM_Base_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_OC_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_PWM_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_IC_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_OnePulse_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_Encoder_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the CLINT / CMU / MPU / USART integration tests:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2, CANX2 by
 *         8 -> core 180 MHz, AXILite4 Bus 1 and Bus 2 = 45 MHz (TIM0, TIM1),
 *         APBBus0 and APBBus1 = 22.5 MHz (TIM2 / TIM3 / TIM4 and TIM5 / TIM6 /
 *         TIM7 - TIM2 and TIM5 are advanced timers on the APB).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef    SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks used by this suite (GPIOH lives in the always on
       domain and has no gate macro) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Clock tree order: write the dividers while the system clock is still
       FIRC, then configure the PLL and switch to it (that call programs the
       flash controller clock before the switch and updates SystemCoreClock
       afterwards). */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    TIM_OC_InitTypeDef oc_cfg;
    TIM_ClockConfigTypeDef clock_cfg;
    TIM_MasterConfigTypeDef master_cfg;
    TIM_Base_InitTypeDef base_init;

    HAL_Init();
    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== TIM_IT_DRV_022 : internal trigger (TIM1 -> TIM0) ===\r\n");

    /* the TIM1 output pin (PD4 = HTIM1 channel 1) and the TIM0 output pin (PC3) */
    Gpio_Config(GPIOD, GPIO_PIN_4, GPIO_PinSource4, GPIO_AF_HTIM1, GPIO_MODE_AF_PP);
    Gpio_Config(GPIOC, GPIO_PIN_3, GPIO_PinSource3, GPIO_AF_HTIM0_M1, GPIO_MODE_AF_PP);

    /* ---- TIM1: 450 Hz PWM on channel 1, OC1REF as TRGO ---- */
    __HAL_CLEAR_STRUCT(&htim_master);
    htim_master.Instance = TIM1;
    HAL_TIM_Base_StructInit(&base_init);
    base_init.CounterMode   = TIM_COUNTERMODE_UP;
    base_init.ClockDivision = TIM_CKD_DIV1;
    base_init.Period        = TEST_ARR_MASTER;
    base_init.Prescaler     = TEST_PSC_MASTER;
    htim_master.Init        = base_init;
    Check("TIM1 HAL_TIM_Base_Init() returns HAL_OK", (HAL_TIM_Base_Init(&htim_master) == HAL_OK));

    __HAL_CLEAR_STRUCT(&oc_cfg);
    HAL_TIM_OC_StructInit(&oc_cfg);
    oc_cfg.OCMode     = TIM_OCMODE_PWM2;
    oc_cfg.Pulse      = 5000U;
    oc_cfg.OCPolarity = TIM_OCPOLARITY_HIGH;
    Check("TIM1 HAL_TIM_PWM_ConfigChannel() returns HAL_OK",
          (HAL_TIM_PWM_ConfigChannel(&htim_master, &oc_cfg, TIM_CHANNEL_1) == HAL_OK));

    __HAL_CLEAR_STRUCT(&master_cfg);
    HAL_TIM_MasterConfig_StructInit(&master_cfg);
    master_cfg.MasterOutputTrigger = TIM_TRGO_OC1REF;
    master_cfg.MasterSlaveMode     = TIM_MASTERSLAVEMODE_DISABLE;
    Check("HAL_TIM_MasterConfigSynchronization() returns HAL_OK",
          (HAL_TIM_MasterConfigSynchronization(&htim_master, &master_cfg) == HAL_OK));
    Check("TIM1 CR2.MMS = 100 (OC1REF)", ((TIM1->CR2 & TIM_CR2_MMS) == TIM_TRGO_OC1REF));
    Check("TIM1 HAL_TIM_PWM_Start() returns HAL_OK",
          (HAL_TIM_PWM_Start(&htim_master, TIM_CHANNEL_1) == HAL_OK));

    /* ---- TIM0: clocked by the ITR0 internal trigger ---- */
    Check("TIM0 HAL_TIM_Base_Init() returns HAL_OK",
          (TimeBase_Config(TIM0, TEST_ARR_SLAVE, 0U, 0U, TIM_CKD_DIV1, TIM_COUNTERMODE_UP) == HAL_OK));

    __HAL_CLEAR_STRUCT(&clock_cfg);
    clock_cfg.ClockSource    = TIM_CLOCKSOURCE_ITR0;
    clock_cfg.ClockPolarity  = TIM_TRIGGERPOLARITY_RISING;
    clock_cfg.ClockPrescaler = TIM_CLOCKPRESCALER_DIV1;
    clock_cfg.ClockFilter    = 0U;
    Check("TIM0 HAL_TIM_ConfigClockSource(ITR0) returns HAL_OK",
          (HAL_TIM_ConfigClockSource(&htim_dev, &clock_cfg) == HAL_OK));
    Check("TIM0 SMCR.SMS = 111 (external clock mode 1)",
          ((TIM0->SMCR & TIM_SMCR_SMS) == TIM_SLAVEMODE_EXTERNAL1));
    Check("TIM0 SMCR.TS = ITR0", ((TIM0->SMCR & TIM_SMCR_TS) == TIM_TS_ITR0));

    __HAL_CLEAR_STRUCT(&oc_cfg);
    HAL_TIM_OC_StructInit(&oc_cfg);
    oc_cfg.OCMode     = TIM_OCMODE_PWM2;
    oc_cfg.Pulse      = TEST_PULSE_SLAVE;
    oc_cfg.OCPolarity = TIM_OCPOLARITY_HIGH;
    Check("TIM0 HAL_TIM_PWM_ConfigChannel() returns HAL_OK",
          (HAL_TIM_PWM_ConfigChannel(&htim_dev, &oc_cfg, TIM_CHANNEL_1) == HAL_OK));
    Check("TIM0 HAL_TIM_PWM_Start() returns HAL_OK",
          (HAL_TIM_PWM_Start(&htim_dev, TIM_CHANNEL_1) == HAL_OK));
    HAL_TIM_CtrlPWMOutputs(&htim_dev, TIM_ENABLE);

    Summary();

    for (;;)
    {
    }
}
