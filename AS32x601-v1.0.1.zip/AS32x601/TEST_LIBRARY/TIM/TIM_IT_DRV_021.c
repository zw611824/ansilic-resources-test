/**
 * @file    TIM_IT_DRV_021.c
 * @brief   TIM0 TRGO2 (update) triggers the ADC0 regular group on the external trigger 2
 *
 * HAL library port of the original AS32x601 standard-library test case
 * TIMER_IT_DRV_022.c, which drives TIM0 + ADC0. Only HAL library APIs are used; the register
 * read backs document what was programmed.
 *
 * Tested functionality:
 *   TIM_TimeBaseInit()          -> HAL_TIM_Base_StructInit() / HAL_TIM_Base_Init()
 *   TIM_SelectOutputTrigger()   -> HAL_TIM_MasterConfigSynchronization(TIM_TRGO_UPDATE)
 *   TIM_Cmd(ENABLE)             -> HAL_TIM_Base_Start()
 *   ADC_Init()                  -> HAL_ADC_Init()
 *   ADC_ConfigChannel()         -> HAL_ADC_ConfigChannel() (rank interrupt enabled)
 *   PLIC_Init()                 -> HAL_PLIC_StructInit() / HAL_PLIC_Init()
 *   ADC_IRQ_Handler()           -> HAL_ADC_IRQHandler()
 *   ADC_GetSeqResult()          -> HAL_ADC_GetValue() inside HAL_ADC_ConvCpltCallback()
 *
 * Test procedure:
 *   configure the time base of TIM0 (ARR = 100000-1, PSC = 90-1) and select the update event as
 *   the master output trigger;
 *   configure the ADC0 regular group on channel 14 (PC0) with the external trigger 2 as its
 *   trigger source and enable the rank end of conversion interrupt through the PLIC;
 *   start the ADC interrupt mode conversion and the timer, then let the timer trigger the group.
 *
 * Expected behaviour:
 *   CR2.MMS reads 010 (TRGO = update) and CR2.MMS2 reads 0010 (TRGO2 = update);
 *   CTRL0.TRIGSRC reads the external trigger 2 and the rank interrupt is enabled;
 *   the update events of the timer trigger the ADC: the conversion complete callback is called
 *   about five times within the 1 s observation window (4..6 are accepted) and every value is
 *   inside the 12-bit range;
 *   every check prints [PASS] and "summary : failures = 0".
 *
 * Note:
 *   This case needs no external stimulus: the ADC trigger comes from the timer itself. TIM0 is an
 *   advanced timer clocked from AXILite4 Bus 1 = 45 MHz (not from APBBus0), so the update period
 *   is (ARR+1) x (PSC+1) / 45 MHz = 100000 x 90 / 45 MHz = 0.2 s and the 1 s observation window
 *   sees about five triggers.
 *
 *   The master output trigger 2 (TRGO2, CR2.MMS2) of the advanced timers is programmed through
 *   the driver (MasterOutputTrigger2 / HAL_TIM_SetMasterOutputTrigger2()), so no register level
 *   access is needed here.
 *
 *   The timer and the ADC keep running after the summary: the conversion complete callback
 *   prints the value of every trigger (the reference case does the same) and the main loop
 *   prints the free running counter, so the console trace stays alive instead of showing frozen
 *   numbers.
 *
 *   Difference to the reference case (TIMER_IT_DRV_022.c): that one programs TRGO2 alone through
 *   TIM_SelectOutputTrigger(), which clears MMS and therefore leaves TRGO off. This port also
 *   sets TRGO to the update event (MMS = 010), an extra output the ADC does not use but which is
 *   routed to the HTIM1 ITR0 line; it is asserted here on purpose and documented for that reason.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
/* Console: USART0 on GPIOD pin 8 (TX) / pin 9 (RX), 115200 8N1 */
#define TEST_BAUDRATE                   (115200U)

#define TEST_ARR                        (100000U - 1U)
#define TEST_PSC                        (90U - 1U)

#define TEST_ADC_CHANNEL                (ADC_CH_14)
#define TEST_ADC_SAMPLE_TIME            (ADC_SPT_CLK_640)
#define TEST_OBSERVE_MS                 (1000U)
#define TEST_TRIG_MIN                   (4U)    /* 1 s / 0.2 s = 5 triggers, +-1 margin */
#define TEST_TRIG_MAX                   (6U)

/* TRGO2 = update is TIM_TRGO2_UPDATE, the CR2.MMS2 value of the update event */


/* Private variables -------------------------------------------------------*/
static HAL_TIM_HandleTypeDef htim_dev;          /*!< timer under test          */
static HAL_SMU_HandleTypeDef hsmu_clk;          /*!< SMU handle (clock tree)   */
static ADC_HandleTypeDef     hadc_dev;          /*!< ADC under test            */
static volatile uint32 check_failures = 0U;     /*!< failed check counter      */

static volatile uint32 adc_cplt_count = 0U;     /*!< conversion complete calls */
static volatile uint32 adc_last_value = 0U;     /*!< last converted sample     */
static volatile uint32 adc_out_of_range = 0U;   /*!< samples above 0xFFF       */


/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure one GPIO pin as an analog input.
 * @note   An analog input does not use the alternate function mux, so the pin is
 *         left in its reset function (AFR = 0) and only the mode is programmed;
 *         this matches the reference case (GPIO_Mode_An only) and the helper of
 *         TIM_IT_DRV_006.
 * @param  port: GPIO port
 * @param  pin: pin mask
 * @retval None
 */
static void Gpio_AnalogConfig(GPIO_TypeDef *port, uint32 pin)
{
    GPIO_InitTypeDef gpio_init;

    __HAL_CLEAR_STRUCT(&gpio_init);
    gpio_init.Size         = sizeof(GPIO_InitTypeDef);
    gpio_init.Version      = GPIO_INIT_VERSION;
    gpio_init.Pin          = pin;
    gpio_init.Mode         = GPIO_MODE_ANALOG;
    gpio_init.Pull         = GPIO_NOPULL;
    gpio_init.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;
    gpio_init.Alternate    = GPIO_AF_Pin_x;
    HAL_GPIO_Init(port, &gpio_init);
}

/**
 * @brief  Configure the time base of the timer under test.
 * @note   The helper keeps the Size / Version meta fields through
 *         HAL_TIM_Base_StructInit(), which the initialization interface
 *         validates at run time.
 * @param  instance: TIM0..TIM7
 * @param  arr: auto reload value
 * @param  psc: prescaler value
 * @param  rcr: repetition counter (advanced timers only)
 * @retval HAL status of HAL_TIM_Base_Init()
 */
static HAL_StatusTypeDef TimeBase_Config(TIM_TypeDef *instance, uint32 arr, uint32 psc, uint32 rcr)
{
    TIM_Base_InitTypeDef base_init;

    __HAL_CLEAR_STRUCT(&htim_dev);
    htim_dev.Instance = instance;

    HAL_TIM_Base_StructInit(&base_init);
    base_init.CounterMode       = TIM_COUNTERMODE_UP;
    base_init.ClockDivision     = TIM_CKD_DIV1;
    base_init.Period            = arr;
    base_init.Prescaler         = psc;
    base_init.RepetitionCounter = rcr;
    htim_dev.Init               = base_init;

    return HAL_TIM_Base_Init(&htim_dev);
}

/**
 * @brief  Enable the clock of a timer instance and release its reset.
 * @note   The default MSP callbacks of this module are empty, so the suite
 *         performs the gate and reset handling itself; every MSP callback is
 *         routed to this helper.
 * @param  instance: TIM0..TIM7
 * @retval None
 */
static void Tim_ClockEnable(TIM_TypeDef *instance)
{
    if (instance == TIM0)
    {
        __HAL_SMU_HTIM0_CLK_ENABLE();
        __HAL_SMU_HTIM0_FORCE_RESET();
        __HAL_SMU_HTIM0_RELEASE_RESET();
    }
    else if (instance == TIM1)
    {
        __HAL_SMU_HTIM1_CLK_ENABLE();
        __HAL_SMU_HTIM1_FORCE_RESET();
        __HAL_SMU_HTIM1_RELEASE_RESET();
    }
    else if (instance == TIM2)
    {
        __HAL_SMU_HTIM2_CLK_ENABLE();
        __HAL_SMU_HTIM2_FORCE_RESET();
        __HAL_SMU_HTIM2_RELEASE_RESET();
    }
    else if (instance == TIM3)
    {
        __HAL_SMU_TIM3_CLK_ENABLE();
        __HAL_SMU_TIM3_FORCE_RESET();
        __HAL_SMU_TIM3_RELEASE_RESET();
    }
    else if (instance == TIM4)
    {
        __HAL_SMU_TIM4_CLK_ENABLE();
        __HAL_SMU_TIM4_FORCE_RESET();
        __HAL_SMU_TIM4_RELEASE_RESET();
    }
    else if (instance == TIM5)
    {
        __HAL_SMU_HTIM5_CLK_ENABLE();
        __HAL_SMU_HTIM5_FORCE_RESET();
        __HAL_SMU_HTIM5_RELEASE_RESET();
    }
    else if (instance == TIM6)
    {
        __HAL_SMU_TIM6_CLK_ENABLE();
        __HAL_SMU_TIM6_FORCE_RESET();
        __HAL_SMU_TIM6_RELEASE_RESET();
    }
    else
    {
        __HAL_SMU_TIM7_CLK_ENABLE();
        __HAL_SMU_TIM7_FORCE_RESET();
        __HAL_SMU_TIM7_RELEASE_RESET();
    }
}

/* MSP callbacks: the timer clock and reset of the instance under test */
void HAL_TIM_Base_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_OC_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_PWM_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_IC_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_OnePulse_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_Encoder_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

/**
 * @brief  Enable the clock of the ADC instance and release its reset.
 * @note   The default MSP callback of the ADC module is empty, so this case
 *         provides it (the ADC0 gate and reset live in SMU->ALB1CFGR).
 * @param  hadc: ADC handle
 * @retval None
 */
void HAL_ADC_MspInit(ADC_HandleTypeDef *hadc)
{
    if (hadc->Instance == ADC0)
    {
        __HAL_SMU_ADC0_CLK_ENABLE();
        __HAL_SMU_ADC0_FORCE_RESET();
        __HAL_SMU_ADC0_RELEASE_RESET();
    }
}

/**
 * @brief  De-initialize the ADC MSP (clock gate off, reset held).
 * @param  hadc: ADC handle
 * @retval None
 */
void HAL_ADC_MspDeInit(ADC_HandleTypeDef *hadc)
{
    if (hadc->Instance == ADC0)
    {
        __HAL_SMU_ADC0_FORCE_RESET();
        __HAL_SMU_ADC0_CLK_DISABLE();
    }
}

/**
 * @brief  Regular group conversion complete callback.
 * @note   Called from the interrupt context through HAL_ADC_IRQHandler(): the
 *         result of the rank is read and the number of triggers is counted, so
 *         the test can prove that the timer really triggered the group.
 * @param  hadc: ADC handle
 * @retval None
 */
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
    uint32 value;

    value = HAL_ADC_GetValue(hadc);
    if (value > 0x0FFFU)
    {
        adc_out_of_range++;
    }
    adc_last_value = value;
    adc_cplt_count++;

    /* The reference case prints every conversion from its interrupt handler.
       The handler runs once per timer update (0.2 s here), which is far longer
       than the ~3 ms this line needs at 115200 baud, so printing is safe. */
    printf("TIM0 trigger ADC0 value: %d\r\n", (int)value);
}

/**
 * @brief  ADC0 interrupt entry (weak symbol of the PLIC driver table).
 * @param  None
 * @retval None
 */
void ADC0_IRQ_Handler(void)
{
    HAL_ADC_IRQHandler(&hadc_dev);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the other TIM integration tests: PLL VCO 180 MHz,
 *         AXI4Bus3 / APBBus0 / APBBus1 divided by 2, CANX2 by 8 -> core 180 MHz,
 *         AXILite4 Bus 1 and Bus 2 = 45 MHz (TIM0, TIM1), APBBus0 and APBBus1 =
 *         22.5 MHz (TIM2 / TIM3 / TIM4 and TIM5 / TIM6 / TIM7 - TIM2 and TIM5
 *         are advanced timers on the APB).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef    SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks used by this suite (GPIOC carries the ADC input on PC0) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Clock tree order: write the dividers while the system clock is still
       FIRC, then configure the PLL and switch to it (that call programs the
       flash controller clock before the switch and updates SystemCoreClock
       afterwards). */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Configure the ADC0 regular group with the external trigger 2.
 * @note   Mirrors the reference case: channel 1 on PC14, 12-bit right aligned
 *         unsigned data, input clock divided by 4, regular group of one rank
 *         triggered by the external trigger 2 (TRGO2 of the timer) with the
 *         rank end of conversion interrupt enabled.
 * @param  None
 * @retval HAL status of HAL_ADC_Init()
 */
static HAL_StatusTypeDef Adc_Config(void)
{
    ADC_InitTypeDef        adc_init;
    ADC_ChannelConfTypeDef adc_channel;


    __HAL_CLEAR_STRUCT(&hadc_dev);
    hadc_dev.Instance = ADC0;

    HAL_ADC_StructInit(&adc_init);
    adc_init.ADC_ClockDivide              = ADC_CLK_DIVIDE_4;
    adc_init.ADC_Resolution               = ADC_RESOLUTION_12BIT;
    adc_init.ADC_Alignment                = ADC_DATA_ALIGN_RIGHT;
    adc_init.ADC_Symbol                   = ADC_DATA_SELDO_UNSIGNED;
    adc_init.ADC_RegularTrigger           = ADC_TRIGGER_EXTERNAL_2;
    adc_init.ADC_InjectTrigger            = ADC_TRIGGER_INTERNAL;
    adc_init.ADC_RegularEnable            = ENABLE;
    adc_init.ADC_InjectEnable             = DISABLE;
    adc_init.ADC_DmaEnable                = DISABLE;
    adc_init.ADC_ScanModeEn               = ENABLE;
    adc_init.ADC_ContinuousModeEn         = DISABLE;
    adc_init.ADC_RegularDiscontinuousModeEn = DISABLE;
    adc_init.ADC_InjectDiscontinuousModeEn  = DISABLE;
    adc_init.ADC_IntervalModeEn           = DISABLE;
    adc_init.ADC_InjectAutoModeEn         = DISABLE;
    adc_init.ADC_RegularSequenceLength    = 1U;
    adc_init.ADC_InjectSequenceLength     = 1U;
    adc_init.ADC_PowerEn                  = ENABLE;
    adc_init.ADC_PowerRegain              = ENABLE;
    hadc_dev.Init                         = adc_init;

    if (HAL_ADC_Init(&hadc_dev) != HAL_OK)
    {
        return HAL_ERROR;
    }

    HAL_ADC_ChannelStructInit(&adc_channel);
    adc_channel.ADC_Channel      = TEST_ADC_CHANNEL;
    adc_channel.ADC_SampleTime   = TEST_ADC_SAMPLE_TIME;
    adc_channel.ADC_InterruptEn  = ENABLE;
    adc_channel.Rank             = ADC_RSEQ_0;
    (void)HAL_ADC_ConfigChannel(&hadc_dev, &adc_channel);

    return HAL_OK;
}

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    TIM_MasterConfigTypeDef master_cfg;
    PLIC_InitTypeDef        plic_init;
    HAL_StatusTypeDef       status;
    uint32                  before;
    uint32                  after;

    HAL_Init();
    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== TIM_IT_DRV_021 : TIM0 TRGO2 triggers the ADC0 regular group ===\r\n");
    Gpio_AnalogConfig(GPIOC, GPIO_PIN_0);

    /* Step 1: the time base of TIM0 */
    status = TimeBase_Config(TIM0, TEST_ARR, TEST_PSC, 0U);
    Check("HAL_TIM_Base_Init() returns HAL_OK", (status == HAL_OK));

    /* Step 2: the update event as both master output triggers (TRGO and TRGO2
     * are programmed by the same call of the driver) */
    __HAL_CLEAR_STRUCT(&master_cfg);
    HAL_TIM_MasterConfig_StructInit(&master_cfg);
    master_cfg.MasterOutputTrigger  = TIM_TRGO_UPDATE;
    master_cfg.MasterSlaveMode      = TIM_MASTERSLAVEMODE_DISABLE;
    master_cfg.MasterOutputTrigger2 = TIM_TRGO2_UPDATE;
    status = HAL_TIM_MasterConfigSynchronization(&htim_dev, &master_cfg);
    Check("HAL_TIM_MasterConfigSynchronization() returns HAL_OK", (status == HAL_OK));
    Check("CR2.MMS = 010 (TRGO = update)", ((TIM0->CR2 & TIM_CR2_MMS) == TIM_TRGO_UPDATE));
    Check("CR2.MMS2 = 0010 (TRGO2 = update)",
          ((TIM0->CR2 & TIM_CR2_MMS2) == TIM_TRGO2_UPDATE));

    /* Step 3: TRGO2 can also be changed on its own (only MMS2 is written) */
    Check("HAL_TIM_SetMasterOutputTrigger2() returns HAL_OK",
          (HAL_TIM_SetMasterOutputTrigger2(&htim_dev, TIM_TRGO2_OC1REF) == HAL_OK));
    Check("CR2.MMS2 = 0100 (TRGO2 = OC1REF) after the single change",
          ((TIM0->CR2 & TIM_CR2_MMS2) == TIM_TRGO2_OC1REF));
    Check("CR2.MMS is preserved by the single change",
          ((TIM0->CR2 & TIM_CR2_MMS) == TIM_TRGO_UPDATE));
    Check("HAL_TIM_SetMasterOutputTrigger2() restores the update event",
          (HAL_TIM_SetMasterOutputTrigger2(&htim_dev, TIM_TRGO2_UPDATE) == HAL_OK));
    Check("CR2.MMS2 = 0010 (TRGO2 = update) again",
          ((TIM0->CR2 & TIM_CR2_MMS2) == TIM_TRGO2_UPDATE));

    /* Step 4: the ADC0 regular group triggered by the external trigger 2 */
    Check("HAL_ADC_Init() returns HAL_OK", (Adc_Config() == HAL_OK));
    Check("CTRL0.TRIGSRC reads the external trigger 2",
          (((ADC0->CTRL0 & ADC_CTRL0_TRIGSRC) >> ADC_CTRL0_TRIGSRC_Pos) == ADC_TRIGGER_EXTERNAL_2));
    Check("HAL_ADC_GetConfig() returns HAL_OK", (HAL_ADC_GetConfig(&hadc_dev) == HAL_OK));
    Check("the group trigger reads the external trigger 2 back",
          (hadc_dev.Init.ADC_RegularTrigger == ADC_TRIGGER_EXTERNAL_2));
    Check("the regular group is enabled", (hadc_dev.Init.ADC_RegularEnable == ENABLE));

    /* Step 5: the ADC0 interrupt through the PLIC */
    HAL_PLIC_StructInit(&plic_init);
    plic_init.PLIC_IRQChannel    = ADC0_IRQn;
    plic_init.PLIC_IRQPriority   = 1U;
    plic_init.PLIC_IRQChannelCmd = PLIC_ENABLE;
    (void)HAL_PLIC_Init(&plic_init);

    /* Step 6: start the interrupt mode conversion and the timer */
    Check("HAL_ADC_Start_IT() returns HAL_OK", (HAL_ADC_Start_IT(&hadc_dev) == HAL_OK));
    Check("HAL_TIM_Base_Start() returns HAL_OK", (HAL_TIM_Base_Start(&htim_dev) == HAL_OK));
    Check("CR1.CEN is set", ((TIM0->CR1 & TIM_CR1_CEN) != 0U));

    /* Step 7: the timer must trigger the group about five times per second
     * (0.2 s update period over a 1 s window). The accepted range keeps a
     * margin of one trigger for the window boundaries and the UART latency. */
    before = adc_cplt_count;
    delay_ms(TEST_OBSERVE_MS);
    after = adc_cplt_count;
    printf("conversions triggered by TIM0 in %d ms: %d\r\n", (int)TEST_OBSERVE_MS, (int)(after - before));
    Check("the timer triggered the regular group 4..6 times in 1 s",
          (((after - before) >= TEST_TRIG_MIN) && ((after - before) <= TEST_TRIG_MAX)));
    Check("every sample is inside the 12-bit range", (adc_out_of_range == 0U));

    /* Step 8: the stop interfaces, then restart. A stopped timer and a stopped
     * ADC would freeze every printed number and look like a hang on the
     * console, so the trace below is kept alive on purpose. */
    Check("HAL_ADC_Stop_IT() returns HAL_OK", (HAL_ADC_Stop_IT(&hadc_dev) == HAL_OK));
    Check("HAL_TIM_Base_Stop() returns HAL_OK", (HAL_TIM_Base_Stop(&htim_dev) == HAL_OK));
    Check("CR1.CEN is cleared after the stop", ((TIM0->CR1 & TIM_CR1_CEN) == 0U));

    Check("HAL_ADC_Start_IT() restarts the conversion", (HAL_ADC_Start_IT(&hadc_dev) == HAL_OK));
    Check("HAL_TIM_Base_Start() restarts the timer", (HAL_TIM_Base_Start(&htim_dev) == HAL_OK));

    Summary();
    printf("note: timer and ADC keep running, the values below increase\r\n");

    for (;;)
    {
        printf("tim0 cnt: %d  last adc0 value: %d  total conversions: %d\r\n",
               (int)HAL_TIM_GetCounter(&htim_dev), (int)adc_last_value, (int)adc_cplt_count);
        delay_ms(100U);
    }
}
