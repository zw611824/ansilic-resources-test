/**
 * @file    SPACC_IT_DRV_002.c
 * @brief   HAL SPACC integration test case 002 (AES-CBC decryption).
 *
 * AES-CBC decryption of one 448-byte packet.
 *
 * Tested functionality:
 *   HAL_SPACC_StructInit / HAL_SPACC_Init / HAL_SPACC_PacketInit / HAL_SPACC_WriteContext / HAL_SPACC_StateFIFOFlag / HAL_SPACC_CommandExecResult / HAL_SPACC_GetState.
 *
 * Expected behaviour:
 *   the decrypted 448-byte plaintext equals the reference vectors, so the summary stays at zero failures.
 *
 * @note    The packet vectors are the ones of the reference test project
 *          (SPACC_IT_DRV_002.c) and are reproduced verbatim, so a case can be
 *          compared one to one with the reference output.
 * @note    The SPACC needs the AXILite4-Bus1 (DSE) clock gate and reset
 *          release: HAL_SPACC_MspInit() is overridden at the end of this file
 *          to do that and to count its calls.
 * @note    The DDT structures are 8-byte aligned through a union with a 64-bit
 *          member, because the driver validates the alignment of the DDT bus
 *          address (SRC_PTR.PTR starts at bit 3).
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Software identifier carried by every submitted task */
#define TEST_SOFTWARE_ID            (0x2DU)

/* Bound of every polling loop (the SPACC completes in microseconds) */
#define TEST_WAIT_GUARD             (20000000U)

/* Reporting period of the final loop (ms) */
#define TEST_POLL_MS                (1000U)

/* Unknown instance used by the handle validation checks */
#define TEST_BAD_INSTANCE           ((SPACC_TypeDef *)0x40000000UL)

/* Processed packet size, in 32-bit words, of this case */
#define TEST_PACKET_WORDS           (112U)

/* Byte-swap helper: the SPACC consumes the packet in the opposite byte order
 * of the C representation, exactly as the reference test project does. */
#define TEST_SWAP32(__VALUE__)      ((((__VALUE__) & 0x000000FFUL) << 24) | \
                                     (((__VALUE__) & 0x0000FF00UL) << 8)  | \
                                     (((__VALUE__) & 0x00FF0000UL) >> 8)  | \
                                     (((__VALUE__) & 0xFF000000UL) >> 24))

/* Private typedef -----------------------------------------------------------*/
/**
 * @brief Data descriptor table (DDT) of a packet segment list.
 * @note  The SPACC reads SRC_PTR / DST_PTR as the bus address of a DDT whose
 *        first pointer is kept on an 8-byte boundary (PTR field starts at bit
 *        3), so the two DDT instances below are wrapped in a union with a
 *        64-bit member to force that alignment on every toolchain.
 */
typedef struct
{
    uint32 *Ptr_0;
    uint32  Len_0;
    uint32 *Ptr_1;
    uint32  Len_1;
} SPACC_DDTTypeDef;

typedef union
{
    SPACC_DDTTypeDef ddt;
    uint64           force_align8;
} SPACC_DDTAlignedTypeDef;

/* Private variables ---------------------------------------------------------*/
static HAL_SPACC_HandleTypeDef hspacc_dev;          /*!< handle under test      */
static HAL_SMU_HandleTypeDef   hsmu_clk;            /*!< SMU handle (clock)     */
static SPACC_InitTypeDef       spacc_init;          /*!< configuration          */
static SPACC_PacketTypeDef     spacc_packet;        /*!< packet descriptor      */
static SPACC_DDTAlignedTypeDef spacc_ddt_src;       /*!< source DDT (8B aligned)*/
static SPACC_DDTAlignedTypeDef spacc_ddt_dst;       /*!< destination DDT        */

/* Accumulated check counters */
static uint32 failures = 0U;
static uint32 checks = 0U;

/* Low level callback instrumentation */
static uint32 msp_init_count = 0U;
static uint32 msp_deinit_count = 0U;
static uint32 error_callback_count = 0U;

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void Section(const char *name);
static void Check(const char *name, uint32 condition);
static void Summary(void);
static void Spacc_StageDdt(uint32 *src, uint32 src_bytes, uint32 *dst, uint32 dst_bytes);
static HAL_StatusTypeDef Spacc_WriteCipherContext(const uint32 *words, uint32 count);
static HAL_StatusTypeDef Spacc_ReadCipherContext(uint32 *words, uint32 count);
static uint32 Spacc_WaitResult(uint32 software_id);
static void Spacc_Drain(uint32 limit);


/* Test vectors -------------------------------------------------------------*/
/* vectors extracted verbatim from SPACC_IT_DRV_002.c (only "u32 " normalised to "uint32_t ") */
#define PACKET_LEN	112

/* spacc_aes_cbc_context [12] */
uint32_t spacc_aes_cbc_context[12] = {0xae781dad, 0x18efd7f1, 0x4acc012a, 0x75dbeb3a,     //KEY
                                      0x00000000, 0x00000000, 0x00000000, 0x00000000,     //KEY
                                      0x6fac1192, 0xeb4540ff, 0xcb5afd0f, 0xb408d5c5};    //IV

/* spacc_aes_cbc_ciphertext [PACKET_LEN] */
uint32_t spacc_aes_cbc_ciphertext[PACKET_LEN] = {0x541a99f8, 0x54f4e67b, 0x40b4a23a, 0x71f71374, 0xc70398a4, 0x910cd151, 0x25d33587, 0xa6e87369,
                                                 0x407c2d3c, 0x9d0fd2a1, 0xc50187f2, 0xa9593ad2, 0x7fddd060, 0xbf1e2f19, 0x7bdcb198, 0x99885e38,
                                                 0x9f5d7c0f, 0xe9223022, 0x4b12a13f, 0x81cebf12, 0xd9c67506, 0x321eb155, 0xd4c8ec3c, 0xe8281926,
                                                 0x0d58a056, 0x469a0ba0, 0x7da0d421, 0xd90fdd77, 0xa02720ee, 0xe55da7bd, 0xe1190d0a, 0x2d2001e3,
                                                 0x61daffc0, 0x432c4bda, 0xb19db26d, 0x7efeabcf, 0xea29bb5f, 0xa74e974d, 0x66d2cd3c, 0x89925436,
                                                 0x912a6828, 0xcd8d538b, 0x6862af92, 0x49e9d9f3, 0x2d6c881b, 0x203b0f8e, 0x8afff0c2, 0x9b457bb8,
                                                 0xd08aa760, 0xa8a425c8, 0x4d1fb363, 0x2013a54e, 0x6e121168, 0x7d755358, 0xd023eab2, 0xdbaab738,
                                                 0xf12d8de3, 0xb032d610, 0x560e7d77, 0x327cf8ea, 0xc7d80a73, 0xd8cf599c, 0x499fd6e7, 0x3f698c5c,
                                                 0x2251cdf2, 0x6d071441, 0x1bbbcd57, 0xaa4ae7b9, 0xab3f2f2a, 0x4e33c77d, 0xa9bcd430, 0x8f4504d6,
                                                 0xc863c8f3, 0xbbcc70d5, 0x45304e91, 0xcb237eaa, 0xab47460c, 0x7c19a11e, 0xd2bddc66, 0xd448528f,
                                                 0x6c3eab6d, 0x5853f6a3, 0xfbd45fef, 0x33ab4b16, 0x64ca8b40, 0x3d1833a4, 0x48ef2156, 0xca17749f,
                                                 0x6ad98415, 0xbad5a3c1, 0x0f0ca087, 0x4da78302, 0x5b65a601, 0x44fe2ec3, 0x275b5afd, 0x5670f3fc,
                                                 0xa23c781b, 0x930df676, 0x0e42394a, 0xafd464a7, 0x60fd1eef, 0x0fc3cf5d, 0x44312a15, 0xa7e723d1,
                                                 0x52b4e144, 0x77b73436, 0xaf2ff864, 0x1beff6d2, 0xbe5a05e6, 0x1b3ef42e, 0x20e53356, 0xe313d93b};

/* spacc_aes_cbc_plaintext_expect [PACKET_LEN] */
uint32_t spacc_aes_cbc_plaintext_expect[PACKET_LEN] = {0x5d1d5a36, 0xa86380db, 0x7905a5b2, 0x6afaccd3, 0x44e77625, 0xa4a61e36, 0x4fcb9ebc, 0x84448cff,  /* row 1 */
                                                       0xdc0131fc, 0x8a248223, 0x87211ff7, 0x11b71f4b, 0x73c7cfba, 0xc0831484, 0x6a6a2775, 0x07ec6258,
                                                       0x805177f1, 0x7d30dd83, 0x6597bb2a, 0x58171693, 0xd9e01310, 0x4df4a881, 0xff3449cf, 0x56b96f68,
                                                       0xf0b03e14, 0x6b00166d, 0x4cabd2e0, 0xdb503a9a, 0xf107c7c1, 0x8ba69d3d, 0xb3c625f3, 0x6f451d59,
                                                       0x77387ec3, 0x4574d32b, 0x57eccc74, 0xa4dc34da, 0x1f851b64, 0xe6756fbf, 0x03aae328, 0x1f3a5d0c,
                                                       0x8f4b5ba3, 0xd22becb0, 0x6373f25e, 0xb780a155, 0xbf4612be, 0x37e306d4, 0x9d3fce52, 0xe2d6d119,
                                                       0xaa6e38c7, 0xd95d787a, 0x45a93b9d, 0x73349bbb, 0x02f97736, 0xfbd177e7, 0x31ef0eaa, 0x39d5ac2a,
                                                       0x5a76772e, 0x80d66393, 0xde4898b8, 0xe97f737c, 0x1b933b90, 0x2aea509b, 0xcf5d0da2, 0x11c947f4,
                                                       0x6ee88a43, 0x5d7f66e0, 0x45f500fe, 0x957d1230, 0xc03f20dd, 0x5013ae59, 0xc469f3e0, 0x544fab22,
                                                       0xb30727eb, 0xf8d6b1fe, 0xc3accdd8, 0xfd35d9c1, 0x99725373, 0xf400954e, 0x6893975b, 0xdf2f2519,
                                                       0x8b8c647b, 0xe385139b, 0xb5c2df66, 0x27cc13ab, 0x34fa2d24, 0xd8c75c58, 0xb01907b7, 0xdf0068b7,
                                                       0x76c657d6, 0x97d32c6f, 0x6c8b8272, 0x6104cc5d, 0x47fbf646, 0x0be89f56, 0xc9d61437, 0x2c02b81d,
                                                       0x19febe78, 0x71b15ae4, 0x2a4835df, 0x40fe6c36, 0x94656a60, 0xf6d434c4, 0x605c862d, 0x19d3affc,
                                                       0x3554118f, 0xedd0fcfa, 0xf1c3aa94, 0x3d1c7135, 0x4a8a568a, 0xf0c4f0a6, 0x32c114c8, 0x091cfb95};  /* row 14 */

static uint32 spacc_ciphertext_swp[TEST_PACKET_WORDS];
static uint32 spacc_plaintext_result[TEST_PACKET_WORDS];
static uint32 spacc_context_read[12];

/**
 * @brief  Case 002: AES-CBC decryption of one 448-byte packet.
 * @retval Never (the final loop keeps reporting).
 */
int main(void)
{
    uint32 i;
    uint32 packet_mismatch = 0U;
    HAL_StatusTypeDef status;

    HAL_Init();
    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);

    printf("\r\n ***** SPACC AES-CBC decryption test (case 002) ***** \r\n");
    printf("Data : %s\r\n", __DATE__);
    printf("Time : %s\r\n", __TIME__);
    delay_ms(500U);

    Section("preparation");

    __HAL_CLEAR_STRUCT(&hspacc_dev);
    hspacc_dev.Instance = SPACC;

    /* A warm re-run may leave results behind: drop them before the real task,
     * so the completion check of this run can only observe its own task. */
    Spacc_Drain(8U);
    Check("handle starts in the reset state",
          (HAL_SPACC_GetState(&hspacc_dev) == HAL_SPACC_STATE_RESET) ? 1U : 0U);

    for (i = 0U; i < TEST_PACKET_WORDS; i++)
    {
        spacc_ciphertext_swp[i] = TEST_SWAP32(spacc_aes_cbc_ciphertext[i]);
    }
    CLEAR_CACHE();

    Spacc_StageDdt(spacc_ciphertext_swp, (TEST_PACKET_WORDS * 4U),
                   spacc_plaintext_result, (TEST_PACKET_WORDS * 4U));

    Section("context and descriptor");

    status = Spacc_WriteCipherContext(spacc_aes_cbc_context, 12U);
    Check("cipher context written", (status == HAL_OK) ? 1U : 0U);

    HAL_SPACC_PacketInit(&hspacc_dev, &spacc_packet);
    Check("descriptor accepted", (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_NONE) ? 1U : 0U);

    Section("submit and completion");

    HAL_SPACC_StructInit(&spacc_init);
    spacc_init.SPACC_CipherAlgorithm     = SPACC_CIPHER_ALG_AES;
    spacc_init.SPACC_SM4CipherMode       = SPACC_SM4_CIPHER_MODE_CBC;
    spacc_init.SPACC_HashAlgorithm       = SPACC_HASH_ALG_NULL;
    spacc_init.SPACC_SM3HashMode         = SPACC_SM3_HASH_MODE_RAW_SHAKE;
    spacc_init.SPACC_TransferMode        = SPACC_TRANS_TO_APPLY_DECRYPT;
    spacc_init.SPACC_ContextIndex        = 0U;
    spacc_init.SPACC_KeyFrom             = SPACC_KEY_FROM_CTX;
    spacc_init.SPACC_AADCopy             = SPACC_APP_NOT_COPY;
    spacc_init.SPACC_ICVCompute          = SPACC_ICV_COMPUTER_PLAIN;
    spacc_init.SPACC_ICVEncrypt          = SPACC_ICV_NOT_ENCRYPT;
    spacc_init.SPACC_ICVLocation         = SPACC_ICV_LOCATION_OFFSET;
    spacc_init.SPACC_KeyExpand           = SPACC_KEY_EXPAND;
    spacc_init.SPACC_MessageBegin        = SPACC_MSG_BEGIN_FIRST;
    spacc_init.SPACC_MessageEnd          = SPACC_MSG_END_LAST;
    spacc_init.SPACC_SoftwareID          = TEST_SOFTWARE_ID;
    spacc_init.SPACC_PriorityCommandFIFO = 0U;
    spacc_init.SPACC_KeySize             = 0x10U;
    spacc_init.SPACC_KeyIndex            = 0U;
    spacc_init.SPACC_KeyType             = SPACC_KEY_TYPE_CIPHER;

    status = HAL_SPACC_Init(&hspacc_dev, &spacc_init);
    Check("Init accepted (task submitted)", (status == HAL_OK) ? 1U : 0U);
    Check("state is ready after the submission",
          (HAL_SPACC_GetState(&hspacc_dev) == HAL_SPACC_STATE_READY) ? 1U : 0U);
    Check("result available and software ID matched",
          Spacc_WaitResult(TEST_SOFTWARE_ID));
    Check("status FIFO empty after the pop",
          (HAL_SPACC_StateFIFOFlag(&hspacc_dev) == SET) ? 1U : 0U);

    Section("verification");

    for (i = 0U; i < TEST_PACKET_WORDS; i++)
    {
        if (spacc_plaintext_result[i] != TEST_SWAP32(spacc_aes_cbc_plaintext_expect[i]))
        {
            packet_mismatch++;
            if (packet_mismatch <= 8U)
            {
                printf("  plaintext[%03u] = %08X, expected %08X\r\n", PRINT_U32(i),
                       PRINT_U32(spacc_plaintext_result[i]),
                       PRINT_U32(TEST_SWAP32(spacc_aes_cbc_plaintext_expect[i])));
            }
        }
    }

    Check("decrypted packet equals the expected value", (packet_mismatch == 0U) ? 1U : 0U);

    /* The reference case of a CBC decryption does not publish an expected
     * chaining value, so the context is only read back as an observability
     * check (a failed read is reported, the value is printed for comparison). */
    Section("cipher context after the decryption");

    status = Spacc_ReadCipherContext(spacc_context_read, 12U);
    Check("cipher context readable after the task", (status == HAL_OK) ? 1U : 0U);
    printf("\r\ncontext: ");
    for (i = 0U; i < 12U; i++)
    {
        printf("%08X", PRINT_U32(spacc_context_read[i]));
    }
    printf("\r\n");

    printf("\r\npacket mismatches = %u\r\n", PRINT_U32(packet_mismatch));

    Section("result");
    Summary();
    printf("***** SPACC AES-CBC decryption test %s *****\r\n",
           ((failures == 0U) ? "success" : "failed"));

    for (;;)
    {
        delay_ms(TEST_POLL_MS);
    }
}


/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Report one section of the case.
 * @param  name: section name.
 * @retval None
 */
static void Section(const char *name)
{
    printf("\r\n---- %s ----\r\n", name);
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    checks++;

    if (condition == 0U)
    {
        failures++;
    }

    printf("%-58s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Print the check summary.
 * @retval None
 */
static void Summary(void)
{
    printf("\r\nchecks = %u, failures = %u\r\n", PRINT_U32(checks), PRINT_U32(failures));
    printf("summary : failures = %s\r\n", ((failures == 0U) ? "0 (PASS)" : "NON-ZERO (FAIL)"));
}

/**
 * @brief  Fill the two DDT structures and the pointer fields of the descriptor.
 * @param  src: source buffer.
 * @param  src_bytes: source segment length, in bytes.
 * @param  dst: destination buffer.
 * @param  dst_bytes: destination segment length, in bytes.
 * @retval None
 * @note   Both DDTs describe a single segment, the second entry is the NULL
 *         terminator. The byte counts and every offset of the descriptor are
 *         cleared here; the case overrides the fields it needs afterwards.
 */
static void Spacc_StageDdt(uint32 *src, uint32 src_bytes, uint32 *dst, uint32 dst_bytes)
{
    spacc_ddt_src.ddt.Ptr_0 = src;
    spacc_ddt_src.ddt.Len_0 = src_bytes;
    spacc_ddt_src.ddt.Ptr_1 = NULL_PTR;
    spacc_ddt_src.ddt.Len_1 = 0U;

    spacc_ddt_dst.ddt.Ptr_0 = dst;
    spacc_ddt_dst.ddt.Len_0 = dst_bytes;
    spacc_ddt_dst.ddt.Ptr_1 = NULL_PTR;
    spacc_ddt_dst.ddt.Len_1 = 0U;

    spacc_packet.SPACC_SourcePtr        = (uint32)(&spacc_ddt_src.ddt);
    spacc_packet.SPACC_DestinationPtr   = (uint32)(&spacc_ddt_dst.ddt);
    spacc_packet.SPACC_SouPREAADOffset  = 0U;
    spacc_packet.SPACC_DestPREAADOffset = 0U;
    spacc_packet.SPACC_PREAADLen        = 0U;
    spacc_packet.SPACC_POSTAADLen       = 0U;
    spacc_packet.SPACC_PROCLen          = (TEST_PACKET_WORDS * 4U);
    spacc_packet.SPACC_ICVLen           = 0U;
    spacc_packet.SPACC_ICVOffset        = 0U;
    spacc_packet.SPACC_IVOffset         = 0U;
    spacc_packet.SPACC_IVLocation       = SPACC_IV_LOCATION_CONTEXT;

    CLEAR_CACHE();
}

/**
 * @brief  Write the cipher context (key / IV) through the HAL context API.
 * @param  words: context words in the C representation (big endian wording).
 * @param  count: number of words.
 * @retval HAL status of HAL_SPACC_WriteContext().
 * @note   The values are byte swapped in a local buffer before the transfer,
 *         because the SPACC context store keeps them in the opposite order
 *         (the reference test project writes them through the same swap).
 */
static HAL_StatusTypeDef Spacc_WriteCipherContext(const uint32 *words, uint32 count)
{
    uint32 swapped[16];
    uint32 i;

    for (i = 0U; (i < count) && (i < 16U); i++)
    {
        swapped[i] = TEST_SWAP32(words[i]);
    }

    return HAL_SPACC_WriteContext(&hspacc_dev, SPACC_CIPHER_CONTEXT_BASE, 0U, swapped, count);
}

/**
 * @brief  Read the cipher context and undo the byte swap.
 * @param  words: destination buffer, in the C representation.
 * @param  count: number of words.
 * @retval HAL status of HAL_SPACC_ReadContext().
 */
static HAL_StatusTypeDef Spacc_ReadCipherContext(uint32 *words, uint32 count)
{
    uint32 raw[16];
    uint32 i;
    HAL_StatusTypeDef status;

    status = HAL_SPACC_ReadContext(&hspacc_dev, SPACC_CIPHER_CONTEXT_BASE, 0U, raw, count);

    for (i = 0U; (i < count) && (i < 16U); i++)
    {
        words[i] = TEST_SWAP32(raw[i]);
    }

    return status;
}

/**
 * @brief  Wait for a result and match its software identifier.
 * @param  software_id: identifier of the submitted task.
 * @retval 1 when a result was popped and its identifier matched, 0 otherwise.
 * @note   The wait is bounded, so a silent hardware problem is reported as a
 *         failed check instead of hanging the case.
 */
static uint32 Spacc_WaitResult(uint32 software_id)
{
    uint32 guard = TEST_WAIT_GUARD;

    while ((HAL_SPACC_StateFIFOFlag(&hspacc_dev) == SET) && (guard != 0U))
    {
        guard--;
    }

    CLEAR_CACHE();

    if (guard == 0U)
    {
        return 0U;
    }

    return (HAL_SPACC_CommandExecResult(&hspacc_dev, software_id) == SET) ? 1U : 0U;
}

/**
 * @brief  Pop every pending result so that the next submission starts clean.
 * @param  limit: maximum number of results to pop.
 * @retval None
 */
static void Spacc_Drain(uint32 limit)
{
    uint32 count = 0U;

    CLEAR_CACHE();

    while ((HAL_SPACC_StateFIFOFlag(&hspacc_dev) == RESET) && (count < limit))
    {
        (void)HAL_SPACC_CommandExecResult(&hspacc_dev, 0U);
        count++;
    }
}

/**
 * @brief  SPACC low level initialization: clock gate and reset release.
 * @param  hspacc: SPACC handle.
 * @retval None
 * @note   The SPACC is clocked by the AXILite4-Bus1 (DSE) domain, gated by the
 *         SMU. The call count lets the cases verify that the callback runs
 *         once, before the handle is locked.
 */
void HAL_SPACC_MspInit(HAL_SPACC_HandleTypeDef *hspacc)
{
    if (hspacc == NULL_PTR)
    {
        return;
    }

    msp_init_count++;

    __HAL_SMU_DSE_CLK_ENABLE();
    __HAL_SMU_DSE_FORCE_RESET();
    __HAL_SMU_DSE_RELEASE_RESET();
}

/**
 * @brief  SPACC low level de-initialization, counted for the life cycle checks.
 * @param  hspacc: SPACC handle.
 * @retval None
 */
void HAL_SPACC_MspDeInit(HAL_SPACC_HandleTypeDef *hspacc)
{
    if (hspacc == NULL_PTR)
    {
        return;
    }

    msp_deinit_count++;
}

/**
 * @brief  SPACC error callback, counted for the interrupt checks.
 * @param  hspacc: SPACC handle.
 * @retval None
 */
void HAL_SPACC_ErrorCallback(HAL_SPACC_HandleTypeDef *hspacc)
{
    (void)hspacc;

    error_callback_count++;
}

/**
 * @brief  Configure the system clock and the bus gates.
 * @retval None
 * @note   Same clock tree as the other HAL integration suites: the PLL is fed
 *         by the external oscillator (VCO 180 MHz) and the buses run at
 *         AXI4Bus3 / 2, APBBus0 / 2, APBBus1 / 2 and CANX2 / 8, which keeps
 *         the console USART on its usual 22.5 MHz.
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    smu_osc;
    SMU_ClockInitTypeDef  smu_clock;
    SMU_ClocksTypeDef     smu_clocks;
    HAL_PMU_HandleTypeDef hpmu;

    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Raise the core rail trim before the PLL is switched: the 1.2 V LDO APIs
     * are gated on the handle state, so the PMU must be initialized first */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    __HAL_CLEAR_STRUCT(&smu_osc);
    smu_osc.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    smu_osc.FIRCState            = SMU_FIRC_ON;
    smu_osc.FIRCCalibrationValue = 0x00U;
    smu_osc.PLL.PLLState         = SMU_PLL_ON;
    smu_osc.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    smu_osc.PLL.PLLDivR          = 0x04U;
    smu_osc.PLL.PLLDivQ          = 0x01U;
    smu_osc.PLL.PLLDivN          = 0x14U;
    smu_osc.PLL.PLLDivF          = 0xB4U;
    smu_osc.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    (void)HAL_SMU_OscConfig(&hsmu_clk, &smu_osc, SMU_TIMEOUT_DEFAULT);

    /* Bus dividers */
    __HAL_CLEAR_STRUCT(&smu_clock);
    smu_clock.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    smu_clock.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    smu_clock.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    smu_clock.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &smu_clock);

    (void)HAL_SMU_GetClocksFreq(&smu_clocks);

    /* The packet descriptor and the context memory are programmable before the
     * first initialization, so the AXILite4-Bus1 (DSE) clock gate and its reset
     * release must already be in place: the gate is not guaranteed to be open
     * after a power-on or a hardware reset, and an access of the unclocked block
     * stalls the bus. HAL_SPACC_MspInit() repeats both operations before the
     * first submission. */
    __HAL_SMU_DSE_CLK_ENABLE();
    __HAL_SMU_DSE_FORCE_RESET();
    __HAL_SMU_DSE_RELEASE_RESET();
}

/*****END OF FILE*****/
