/**
 * @file    MPU_IT_DRV_011.c
 * @brief   HAL MPU integration test case 011 (API coverage, constants,
 *          parameter validation, register programming and null handle
 *          protection).
 *
 * Extension test case of the HAL MPU driver: it covers the API surface that the
 * ten original standard-library cases do not exercise.
 *
 * Tested functionality:
 *   __HAL_MPU_MODULE_VERSION / MPU_INIT_V1 / MPU_INIT_VERSION
 *   MPU_ENABLE / MPU_DISABLE / HAL_MPU_ERROR_NONE / HAL_MPU_ERROR_INVALID_PARAM
 *   HAL_MPU_InstanceTypeDef / HAL_MPU_StateTypeDef
 *   IS_MPU_INSTANCE / IS_MPU_CHANNEL / IS_MPU_WP_INSTANCE / IS_MPU_ENABLE_STATE
 *   HAL_MPU_StructInit() / HAL_MPU_Init() / HAL_MPU_DeInit()
 *   HAL_MPU_SetAddressRange() / HAL_MPU_Cmd() / HAL_MPU_WriteProtectCmd() /
 *   HAL_MPU_ReadProtectCmd()
 *   HAL_MPU_GetWriteProtectStatus() / HAL_MPU_GetReadProtectStatus() /
 *   HAL_MPU_ClearStatus()
 *   HAL_MPU_GetState() / HAL_MPU_GetError()
 *   HAL_MPU_GetRegBlock() / HAL_MPU_GetIPortBlock()
 *   MPU_LockHandle() / MPU_UnlockHandle() / __HAL_MPU_RESET_HANDLE_STATE()
 *   HAL_MPU_MspInit() / HAL_MPU_MspDeInit()
 *
 * API surface note (no case can exercise what the driver does not provide):
 *   - the MPU has no clock gate of its own (it is clocked by the AXILite bus
 *     clock), so the MSP hooks are empty by default;
 *   - there is no interrupt mode, no IRQ handler and no callback: a violation is
 *     reported through the status registers and forwarded to the FCU;
 *   - MPU0 (I-Bus) has no write-protection hardware: IS_MPU_WP_INSTANCE(0) is
 *     false and its register block uses the three-register I-Port layout, which
 *     is why the driver exposes HAL_MPU_GetIPortBlock().
 *
 * Test procedure:
 *   1. Check the version, error, enable and instance constants;
 *   2. Check the boundary behaviour of every parameter validation macro;
 *   3. Check the defaults of HAL_MPU_StructInit() and its NULL protection;
 *   4. Initialize MPU1 channel 3 through HAL_MPU_Init() and verify the register
 *      programming, the handle state and the error code;
 *   5. Trigger a write and a read violation on that channel and check the
 *      status reporting and clearing;
 *   6. Check __HAL_MPU_RESET_HANDLE_STATE() and the lock / unlock functions;
 *   7. Check the register block mapping of the five instances;
 *   8. Exercise the channel control functions on MPU2, MPU3 and MPU4;
 *   9. De-initialize the channel and check that all bits are cleared;
 *  10. Check the state gate (a control function called before
 *      HAL_MPU_Init() is rejected), the run-time parameter validation (out of
 *      range channel and address values are rejected with
 *      HAL_MPU_ERROR_INVALID_PARAM) and the write protection request addressing
 *      MPU0 (it must not touch the I-Port registers);
 *  11. Check the null handle protection of every public function.
 *
 * Expected behaviour:
 *   - Every constant and validation macro behaves as documented;
 *   - HAL_MPU_Init() programs SADDR / EADDR and sets only the protection and
 *     enable bits that were requested;
 *   - a protected access is recorded by the status of the channel and can be
 *     cleared again;
 *   - DeInit() disables the channel and clears its range and protection bits;
 *   - the control functions return HAL_ERROR when the handle is NULL or when
 *     the handle has not been initialized (RESET), and HAL_BUSY while another
 *     operation is ongoing (no hard fault);
 *   - a write protection request addressing MPU0 is rejected with HAL_ERROR
 *     and HAL_MPU_ERROR_NOT_SUPPORTED (MPU0 has no such register), leaves the
 *     I-Port registers untouched and still reads back as 0.
 * NOTE: The case programmes every instance with benign addresses and disables
 *       every channel at the end of each iteration, so it can run repeatedly
 *       without disturbing the rest of the system.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Report period (ms) */
#define TEST_PERIOD_MS              (1000U)

/* Channel and address used by the register-programming checks (MPU1) */
#define TEST_INSTANCE               (HAL_MPU_INSTANCE_1_DBUS)
#define TEST_CHANNEL                (3U)
#define TEST_WINDOW_LENGTH          (4U)

/* Value written into the protected word */
#define TEST_WRITE_VALUE            (0x11111111U)

/* Value the refused store of the violation test tries to write */
#define TEST_WRITE_REFUSED          (0x22222222U)

/* Invalid values used by the validation macro checks */
#define TEST_BAD_INSTANCE           (5U)
#define TEST_BAD_CHANNEL            (16U)
#define TEST_BAD_CHANNEL_DMA        (8U)
#define TEST_BAD_STATE              (2U)

/* Private variables ---------------------------------------------------------*/
static HAL_MPU_HandleTypeDef hmpu_dev;        /*!< MPU device handle           */
static uint32          failures = 0U;         /*!< failed checks               */

static MPU_InitTypeDef mpu_init;              /*!< MPU configuration structure */

/* The protected word lives in a 64-byte cache line of its own.  A D-Port access
   is compared against the whole cache line it belongs to, so a window that
   shared its line with other variables would protect them as well; and a store
   that was refused on that line could be forwarded to the next load of the
   protected word, which would hide the violation.  The sink of the protected
   reads is kept outside the line for the same reason. */
static volatile uint32 protected_line[16] __attribute__((aligned(64)));
static volatile uint32 read_sink;             /*!< sink of the protected reads */

/* The protected word is the first word of that line */
#define protected_word              (protected_line[0])

static HAL_SMU_HandleTypeDef hsmu_clk;   /*!< SMU handle (lock / state / error) */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void Check(const char *name, uint32 condition);

static void Instance_ControlCheck(uint32 instance, uint32 channel);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    uint32 ok;
    uint32 bit;
    uint32 start;
    uint32 ch;
    uint32 rd_start;
    uint32 rd_end;
    MPU_InitTypeDef rd_cfg;
    MPU_Channel_TypeDef *channel3 = MPU1_Channel3;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n\r\n ***** MPU Test ***** \r\n");
    printf("case : MPU_IT_DRV_011 (API coverage)\r\n");
    delay_ms(500U);

    __HAL_CLEAR_STRUCT(&hmpu_dev);
    protected_word = TEST_WRITE_VALUE;

    while (1)
    {
        /* ---- Step 1: version, error and instance constants ------------ */
        printf("\r\n-----------------constants----------------- \r\n");
        Check("__HAL_MPU_MODULE_VERSION = 0x0100",
              ((__HAL_MPU_MODULE_VERSION == 0x0100U) ? 1U : 0U));
        Check("MPU_INIT_V1 = 0x0100", ((MPU_INIT_V1 == 0x0100U) ? 1U : 0U));
        Check("MPU_INIT_VERSION = MPU_INIT_V1",
              ((MPU_INIT_VERSION == MPU_INIT_V1) ? 1U : 0U));
        Check("MPU_ENABLE / MPU_DISABLE",
              (((MPU_ENABLE == 1U) && (MPU_DISABLE == 0U)) ? 1U : 0U));
        Check("HAL_MPU_ERROR_NONE / INVALID_PARAM",
              (((HAL_MPU_ERROR_NONE == 0U) && (HAL_MPU_ERROR_INVALID_PARAM == 1U)) ? 1U : 0U));
        Check("instance enum values 0..4",
              (((HAL_MPU_INSTANCE_0_IBUS == 0U) && (HAL_MPU_INSTANCE_1_DBUS == 1U) &&
                (HAL_MPU_INSTANCE_2_PBUS == 2U) && (HAL_MPU_INSTANCE_3_DMA0 == 3U) &&
                (HAL_MPU_INSTANCE_4_DMA1 == 4U)) ? 1U : 0U));
        Check("state enum RESET / READY / BUSY / ERROR",
              (((HAL_MPU_STATE_RESET == 0U) && (HAL_MPU_STATE_READY == 1U) &&
                (HAL_MPU_STATE_BUSY == 2U) && (HAL_MPU_STATE_ERROR == 3U)) ? 1U : 0U));

        /* ---- Step 2: parameter validation macros ---------------------- */
        printf("\r\n-----------------parameter validation macros----------------- \r\n");
        ok = (((IS_MPU_INSTANCE(0U) != 0) && (IS_MPU_INSTANCE(4U) != 0) &&
               (IS_MPU_INSTANCE(TEST_BAD_INSTANCE) == 0)) ? 1U : 0U);
        Check("IS_MPU_INSTANCE accepts 0..4 only", ok);

        ok = (((IS_MPU_CHANNEL(0U, 0U) != 0) && (IS_MPU_CHANNEL(2U, 15U) != 0) &&
               (IS_MPU_CHANNEL(0U, TEST_BAD_CHANNEL) == 0)) ? 1U : 0U);
        Check("IS_MPU_CHANNEL accepts 0..15 for MPU0..2", ok);

        ok = (((IS_MPU_CHANNEL(3U, 7U) != 0) && (IS_MPU_CHANNEL(4U, 7U) != 0) &&
               (IS_MPU_CHANNEL(3U, TEST_BAD_CHANNEL_DMA) == 0) &&
               (IS_MPU_CHANNEL(4U, TEST_BAD_CHANNEL_DMA) == 0)) ? 1U : 0U);
        Check("IS_MPU_CHANNEL accepts 0..7 for MPU3 / MPU4", ok);

        ok = (((IS_MPU_WP_INSTANCE(0U) == 0) && (IS_MPU_WP_INSTANCE(1U) != 0) &&
               (IS_MPU_WP_INSTANCE(4U) != 0) &&
               (IS_MPU_WP_INSTANCE(TEST_BAD_INSTANCE) == 0)) ? 1U : 0U);
        Check("IS_MPU_WP_INSTANCE accepts 1..4 only (MPU0 has no write protection)", ok);

        ok = (((IS_MPU_ENABLE_STATE(MPU_ENABLE) != 0) &&
               (IS_MPU_ENABLE_STATE(MPU_DISABLE) != 0) &&
               (IS_MPU_ENABLE_STATE(TEST_BAD_STATE) == 0)) ? 1U : 0U);
        Check("IS_MPU_ENABLE_STATE", ok);

        /* ---- Step 3: StructInit defaults ----------------------------- */
        printf("\r\n-----------------HAL_MPU_StructInit----------------- \r\n");
        (void)memset(&mpu_init, 0xA5, sizeof(mpu_init));
        HAL_MPU_StructInit(&mpu_init);
        Check("StructInit Size", ((mpu_init.Size == sizeof(MPU_InitTypeDef)) ? 1U : 0U));
        Check("StructInit Version", ((mpu_init.Version == MPU_INIT_VERSION) ? 1U : 0U));
        Check("StructInit Instance = MPU0",
              ((mpu_init.Instance == HAL_MPU_INSTANCE_0_IBUS) ? 1U : 0U));
        ok = (((mpu_init.Channel == 0U) && (mpu_init.StartAddr == 0U) &&
               (mpu_init.EndAddr == 0U) && (mpu_init.WriteProtectEnable == 0U) &&
               (mpu_init.ReadProtectEnable == 0U) && (mpu_init.ChannelEnable == 0U) &&
               (mpu_init.Reserved[0] == 0U) && (mpu_init.Reserved[1] == 0U)) ? 1U : 0U);
        Check("StructInit clears channel, range, protections and reserved", ok);

        HAL_MPU_StructInit(NULL_PTR);
        Check("StructInit(NULL) safe", 1U);

        /* ---- Step 4: HAL_MPU_Init register programming ---------------- */
        printf("\r\n-----------------HAL_MPU_Init----------------- \r\n");
        __HAL_CLEAR_STRUCT(&hmpu_dev);
        hmpu_dev.Instance = TEST_INSTANCE;
        HAL_MPU_StructInit(&mpu_init);
        mpu_init.Instance           = TEST_INSTANCE;
        mpu_init.Channel            = TEST_CHANNEL;
        mpu_init.StartAddr          = (uint32)(unsigned long)&protected_word;
        mpu_init.EndAddr            = (uint32)(unsigned long)&protected_word + TEST_WINDOW_LENGTH;
        mpu_init.WriteProtectEnable = 1U;
        mpu_init.ReadProtectEnable  = 1U;
        mpu_init.ChannelEnable      = 1U;
        hmpu_dev.Init = mpu_init;

        start = mpu_init.StartAddr;
        bit   = (uint32)(1UL << TEST_CHANNEL);

        Check("Init returns HAL_OK", ((HAL_MPU_Init(&hmpu_dev) == HAL_OK) ? 1U : 0U));
        Check("SADDR programmed", ((channel3->SADDR == start) ? 1U : 0U));
        Check("EADDR programmed",
              ((channel3->EADDR == (start + TEST_WINDOW_LENGTH)) ? 1U : 0U));
        Check("WPTEN bit set", (((MPU1_DBUS->WPTEN & bit) != 0U) ? 1U : 0U));
        Check("RPTEN bit set", (((MPU1_DBUS->RPTEN & bit) != 0U) ? 1U : 0U));
        Check("PTEN bit set", (((MPU1_DBUS->PTEN & bit) != 0U) ? 1U : 0U));
        Check("handle instance synchronized",
              ((hmpu_dev.Instance == TEST_INSTANCE) ? 1U : 0U));
        Check("state READY",
              ((HAL_MPU_GetState(&hmpu_dev) == HAL_MPU_STATE_READY) ? 1U : 0U));
        Check("error code NONE",
              ((HAL_MPU_GetError(&hmpu_dev) == HAL_MPU_ERROR_NONE) ? 1U : 0U));

        /* ---- Step 5: violation reporting and clearing ------------------ */
        printf("\r\n-----------------violation reporting----------------- \r\n");

        /* Write protection: the store is taken by the cache first and refused
           when it is written back, so the cache has to be flushed AGAIN after
           the store - a store that is still pending has not reached the D-Port
           yet and nothing would be recorded */
        CLEAR_CACHE();
        protected_word = TEST_WRITE_REFUSED;             /* write protected */
        CLEAR_CACHE();
        Check("write protection status set",
              ((HAL_MPU_GetWriteProtectStatus(&hmpu_dev, TEST_CHANNEL) != 0U) ? 1U : 0U));
        HAL_MPU_ClearStatus(&hmpu_dev, TEST_CHANNEL);
        Check("write protection status cleared",
              ((HAL_MPU_GetWriteProtectStatus(&hmpu_dev, TEST_CHANNEL) == 0U) ? 1U : 0U));

        /* Read protection: the cache is flushed before the load so that it
           really goes to the D-Port, and the sink lies outside the protected
           cache line so that no pending store of that line can serve the load */
        CLEAR_CACHE();
        read_sink = protected_word;               /* read protected */
        Check("read protection status set",
              ((HAL_MPU_GetReadProtectStatus(&hmpu_dev, TEST_CHANNEL) != 0U) ? 1U : 0U));
        HAL_MPU_ClearStatus(&hmpu_dev, TEST_CHANNEL);
        Check("read protection status cleared",
              ((HAL_MPU_GetReadProtectStatus(&hmpu_dev, TEST_CHANNEL) == 0U) ? 1U : 0U));

        /* ---- Step 6: handle state reset and lock ----------------------- */
        printf("\r\n-----------------handle state / lock----------------- \r\n");
        __HAL_MPU_RESET_HANDLE_STATE(&hmpu_dev);
        Check("__HAL_MPU_RESET_HANDLE_STATE resets the state",
              ((hmpu_dev.State == 0U) ? 1U : 0U));

        Check("MPU_LockHandle takes the lock",
              ((MPU_LockHandle(&hmpu_dev, HAL_MAX_DELAY) == HAL_OK) ? 1U : 0U));
        Check("second MPU_LockHandle returns HAL_BUSY",
              ((MPU_LockHandle(&hmpu_dev, HAL_MAX_DELAY) == HAL_BUSY) ? 1U : 0U));
        MPU_UnlockHandle(&hmpu_dev);
        Check("lock available after MPU_UnlockHandle",
              ((MPU_LockHandle(&hmpu_dev, HAL_MAX_DELAY) == HAL_OK) ? 1U : 0U));
        MPU_UnlockHandle(&hmpu_dev);

        /* ---- Step 7: register block mapping --------------------------- */
        printf("\r\n-----------------register block mapping----------------- \r\n");
        ok = (((HAL_MPU_GetRegBlock(HAL_MPU_INSTANCE_1_DBUS) == MPU1_DBUS) &&
               (HAL_MPU_GetRegBlock(HAL_MPU_INSTANCE_2_PBUS) == MPU2_PBUS) &&
               (HAL_MPU_GetRegBlock(HAL_MPU_INSTANCE_3_DMA0) == MPU3_DMA0) &&
               (HAL_MPU_GetRegBlock(HAL_MPU_INSTANCE_4_DMA1) == MPU4_DMA1)) ? 1U : 0U);
        Check("HAL_MPU_GetRegBlock maps MPU1..MPU4", ok);
        Check("HAL_MPU_GetRegBlock(MPU0) addresses the MPU0 block",
              ((((uint32)(unsigned long)HAL_MPU_GetRegBlock(HAL_MPU_INSTANCE_0_IBUS) ==
                 MPU0_IBUS_BASE) ? 1U : 0U)));
        Check("HAL_MPU_GetIPortBlock(MPU0) = MPU0_IBUS",
              ((HAL_MPU_GetIPortBlock(HAL_MPU_INSTANCE_0_IBUS) == MPU0_IBUS) ? 1U : 0U));

        /* ---- Step 8: channel control of MPU2, MPU3 and MPU4 ----------- */
        printf("\r\n-----------------channel control of MPU2 / MPU3 / MPU4----------------- \r\n");
        Instance_ControlCheck(HAL_MPU_INSTANCE_2_PBUS, 0U);
        Instance_ControlCheck(HAL_MPU_INSTANCE_2_PBUS, 15U);
        Instance_ControlCheck(HAL_MPU_INSTANCE_3_DMA0, 0U);
        Instance_ControlCheck(HAL_MPU_INSTANCE_3_DMA0, 7U);
        Instance_ControlCheck(HAL_MPU_INSTANCE_4_DMA1, 0U);
        Instance_ControlCheck(HAL_MPU_INSTANCE_4_DMA1, 7U);

        /* ---- Step 9: DeInit ----------------------------------------- */
        printf("\r\n-----------------HAL_MPU_DeInit----------------- \r\n");
        Check("DeInit returns HAL_OK", ((HAL_MPU_DeInit(&hmpu_dev) == HAL_OK) ? 1U : 0U));
        Check("protection bits cleared",
              ((((MPU1_DBUS->WPTEN | MPU1_DBUS->RPTEN | MPU1_DBUS->PTEN) & bit) == 0U) ? 1U : 0U));
        Check("address range cleared", ((channel3->SADDR == 0U) ? 1U : 0U));
        Check("state RESET",
              ((HAL_MPU_GetState(&hmpu_dev) == HAL_MPU_STATE_RESET) ? 1U : 0U));

        /* With the channel de-initialized the word is reachable again.  The
           content of the word is NOT checked here: a refused read leaves the
           cache line of the protected window holding zeros, and a plain load
           cannot tell that state apart from a word that was overwritten by the
           refused store.  The question "does a refused store reach the memory"
           is answered by case 004, which exercises write protection with the
           read protection switched off and can therefore read the word back. */
        CLEAR_CACHE();
        read_sink = protected_word;

        /* re-initialization after the de-initialization */
        hmpu_dev.Init = mpu_init;
        Check("re-Init after DeInit", ((HAL_MPU_Init(&hmpu_dev) == HAL_OK) ? 1U : 0U));
        Check("state READY after the re-Init",
              ((HAL_MPU_GetState(&hmpu_dev) == HAL_MPU_STATE_READY) ? 1U : 0U));
        (void)HAL_MPU_DeInit(&hmpu_dev);

        /* ---- Step 10: state gate, parameter validation --------------- */
        printf("\r\n-----------------state gate / parameter validation----------------- \r\n");

        /* the handle is in the RESET state here (the re-initialization above
         * was de-initialized): every control function is rejected */
        Check("state gate: SetAddressRange before Init = HAL_ERROR",
              ((HAL_MPU_SetAddressRange(&hmpu_dev, TEST_CHANNEL, 0x20000000U,
                                        0x20000004U) == HAL_ERROR) ? 1U : 0U));
        Check("state gate: Cmd before Init = HAL_ERROR",
              ((HAL_MPU_Cmd(&hmpu_dev, TEST_CHANNEL, MPU_ENABLE) == HAL_ERROR) ? 1U : 0U));
        Check("state gate: ReadProtectCmd before Init = HAL_ERROR",
              ((HAL_MPU_ReadProtectCmd(&hmpu_dev, TEST_CHANNEL, MPU_ENABLE) == HAL_ERROR) ? 1U : 0U));
        Check("state gate: WriteProtectCmd before Init = HAL_ERROR",
              ((HAL_MPU_WriteProtectCmd(&hmpu_dev, TEST_CHANNEL, MPU_ENABLE) == HAL_ERROR) ? 1U : 0U));
        Check("state gate: ClearStatus before Init = HAL_ERROR",
              ((HAL_MPU_ClearStatus(&hmpu_dev, TEST_CHANNEL) == HAL_ERROR) ? 1U : 0U));

        /* the handle becomes READY again: the invalid parameters are now
         * rejected at run time and reported through INVALID_PARAM */
        hmpu_dev.Init = mpu_init;
        Check("re-Init for the parameter checks", ((HAL_MPU_Init(&hmpu_dev) == HAL_OK) ? 1U : 0U));
        Check("SetAddressRange(channel 16) rejected + INVALID_PARAM",
              (((HAL_MPU_SetAddressRange(&hmpu_dev, 16U, 0x20000000U, 0x20000004U) == HAL_ERROR) &&
                ((HAL_MPU_GetError(&hmpu_dev) & HAL_MPU_ERROR_INVALID_PARAM) != 0U)) ? 1U : 0U));

        /* the handle instance is changed directly for the channel range checks
         * above (the range depends on the instance) */
        hmpu_dev.Instance = HAL_MPU_INSTANCE_3_DMA0;
        Check("SetAddressRange(channel 8 on MPU3) rejected",
              ((HAL_MPU_SetAddressRange(&hmpu_dev, 8U, 0x20000000U, 0x20000004U) == HAL_ERROR) ? 1U : 0U));
        Check("Cmd(channel 8 on MPU3) rejected",
              ((HAL_MPU_Cmd(&hmpu_dev, 8U, MPU_ENABLE) == HAL_ERROR) ? 1U : 0U));
        Check("ClearStatus(channel 8 on MPU3) rejected",
              ((HAL_MPU_ClearStatus(&hmpu_dev, 8U) == HAL_ERROR) ? 1U : 0U));

        /* MPU0 has no write protection hardware: a write protection request is
         * rejected with HAL_ERROR and HAL_MPU_ERROR_NOT_SUPPORTED and must
         * leave the read protection register of the I-Port untouched, while
         * the read protection itself still works */
        mpu_init.Instance           = HAL_MPU_INSTANCE_0_IBUS;
        mpu_init.WriteProtectEnable = 1U;     /* rejected: MPU0 has no such register */
        mpu_init.ReadProtectEnable  = 1U;
        mpu_init.ChannelEnable      = 1U;
        hmpu_dev.Init = mpu_init;
        Check("Init on MPU0 with a write protection request = HAL_ERROR",
              ((HAL_MPU_Init(&hmpu_dev) == HAL_ERROR) ? 1U : 0U));
        Check("... reports HAL_MPU_ERROR_NOT_SUPPORTED",
              (((HAL_MPU_GetError(&hmpu_dev) & HAL_MPU_ERROR_NOT_SUPPORTED) != 0U) ? 1U : 0U));
        mpu_init.WriteProtectEnable = 0U;     /* MPU0 accepts the read protection only */
        hmpu_dev.Init = mpu_init;
        (void)HAL_MPU_Init(&hmpu_dev);
        HAL_MPU_ReadProtectCmd(&hmpu_dev, TEST_CHANNEL, MPU_DISABLE);
        Check("WriteProtectCmd on MPU0 = HAL_ERROR",
              ((HAL_MPU_WriteProtectCmd(&hmpu_dev, TEST_CHANNEL, MPU_ENABLE) == HAL_ERROR) ? 1U : 0U));
        Check("... reports HAL_MPU_ERROR_NOT_SUPPORTED",
              (((HAL_MPU_GetError(&hmpu_dev) & HAL_MPU_ERROR_NOT_SUPPORTED) != 0U) ? 1U : 0U));
        Check("WriteProtectCmd on MPU0 leaves RPTEN untouched",
              (((HAL_MPU_GetIPortBlock(HAL_MPU_INSTANCE_0_IBUS)->RPTEN & bit) == 0U) ? 1U : 0U));
        Check("GetWriteProtectStatus on MPU0 = 0",
              ((HAL_MPU_GetWriteProtectStatus(&hmpu_dev, TEST_CHANNEL) == 0U) ? 1U : 0U));
        HAL_MPU_ReadProtectCmd(&hmpu_dev, TEST_CHANNEL, MPU_DISABLE);
        HAL_MPU_Cmd(&hmpu_dev, TEST_CHANNEL, MPU_DISABLE);
        (void)HAL_MPU_DeInit(&hmpu_dev);
        mpu_init.Instance = TEST_INSTANCE;    /* restore for the next loop */

        /* ---- Step 11: null handle protection ------------------------- */
        printf("\r\n-----------------null handle protection----------------- \r\n");
        Check("Init(NULL) = HAL_ERROR", ((HAL_MPU_Init(NULL_PTR) == HAL_ERROR) ? 1U : 0U));
        Check("DeInit(NULL) = HAL_ERROR", ((HAL_MPU_DeInit(NULL_PTR) == HAL_ERROR) ? 1U : 0U));
        Check("GetState(NULL) = RESET",
              ((HAL_MPU_GetState(NULL_PTR) == HAL_MPU_STATE_RESET) ? 1U : 0U));
        Check("GetError(NULL) = NONE",
              ((HAL_MPU_GetError(NULL_PTR) == HAL_MPU_ERROR_NONE) ? 1U : 0U));
        Check("GetWriteProtectStatus(NULL) = 0",
              ((HAL_MPU_GetWriteProtectStatus(NULL_PTR, 1U) == 0U) ? 1U : 0U));
        Check("GetReadProtectStatus(NULL) = 0",
              ((HAL_MPU_GetReadProtectStatus(NULL_PTR, 1U) == 0U) ? 1U : 0U));

        /* the control functions report the rejected null handle with HAL_ERROR */
        Check("SetAddressRange(NULL) = HAL_ERROR",
              ((HAL_MPU_SetAddressRange(NULL_PTR, 0U, 0U, 4U) == HAL_ERROR) ? 1U : 0U));
        Check("Cmd(NULL) = HAL_ERROR",
              ((HAL_MPU_Cmd(NULL_PTR, 0U, MPU_ENABLE) == HAL_ERROR) ? 1U : 0U));
        Check("WriteProtectCmd(NULL) = HAL_ERROR",
              ((HAL_MPU_WriteProtectCmd(NULL_PTR, 0U, MPU_ENABLE) == HAL_ERROR) ? 1U : 0U));
        Check("ReadProtectCmd(NULL) = HAL_ERROR",
              ((HAL_MPU_ReadProtectCmd(NULL_PTR, 0U, MPU_ENABLE) == HAL_ERROR) ? 1U : 0U));
        Check("ClearStatus(NULL) = HAL_ERROR",
              ((HAL_MPU_ClearStatus(NULL_PTR, 0U) == HAL_ERROR) ? 1U : 0U));

        HAL_MPU_MspInit(NULL_PTR);
        HAL_MPU_MspDeInit(NULL_PTR);
        Check("MPU Msp hooks accept NULL safely", 1U);

        HAL_MPU_MspInit(&hmpu_dev);
        HAL_MPU_MspDeInit(&hmpu_dev);
        Check("MPU Msp hooks callable", 1U);

        /* ---- Step 12: configuration read-back / instance reset ------- */
        printf("\r\n-----------------configuration read-back / instance reset----------------- \r\n");

        /* program channel 2 of MPU1 (write protection on) and read it back */
        mpu_init.Instance           = HAL_MPU_INSTANCE_1_DBUS;
        mpu_init.Channel            = 2U;
        mpu_init.StartAddr          = 0x20000000U;
        mpu_init.EndAddr            = 0x20000008U;
        mpu_init.WriteProtectEnable = 1U;
        mpu_init.ReadProtectEnable  = 0U;
        mpu_init.ChannelEnable      = 1U;
        hmpu_dev.Instance           = HAL_MPU_INSTANCE_1_DBUS;
        hmpu_dev.Init               = mpu_init;
        Check("re-Init MPU1 channel 2", ((HAL_MPU_Init(&hmpu_dev) == HAL_OK) ? 1U : 0U));

        rd_start = 0U;
        rd_end   = 0U;
        Check("GetAddressRange returns HAL_OK",
              ((HAL_MPU_GetAddressRange(&hmpu_dev, 2U, &rd_start, &rd_end) == HAL_OK) ? 1U : 0U));
        Check("address range read back through the HAL API",
              (((rd_start == 0x20000000U) && (rd_end == 0x20000008U)) ? 1U : 0U));
        Check("GetAddressRange(NULL output) = HAL_ERROR",
              ((HAL_MPU_GetAddressRange(&hmpu_dev, 2U, NULL_PTR, &rd_end) == HAL_ERROR) ? 1U : 0U));
        Check("GetAddressRange(NULL handle) = HAL_ERROR",
              ((HAL_MPU_GetAddressRange(NULL_PTR, 2U, &rd_start, &rd_end) == HAL_ERROR) ? 1U : 0U));
        Check("GetAddressRange(channel 16 on MPU1) = HAL_ERROR",
              ((HAL_MPU_GetAddressRange(&hmpu_dev, 16U, &rd_start, &rd_end) == HAL_ERROR) ? 1U : 0U));

        __HAL_CLEAR_STRUCT(&rd_cfg);
        Check("GetChannelConfig returns HAL_OK",
              ((HAL_MPU_GetChannelConfig(&hmpu_dev, 2U, &rd_cfg) == HAL_OK) ? 1U : 0U));
        Check("channel config read back (metafields / range / enables)",
              (((rd_cfg.Size == (uint32)sizeof(MPU_InitTypeDef)) &&
                (rd_cfg.Version == MPU_INIT_VERSION) &&
                (rd_cfg.Instance == HAL_MPU_INSTANCE_1_DBUS) &&
                (rd_cfg.Channel == 2U) &&
                (rd_cfg.StartAddr == 0x20000000U) &&
                (rd_cfg.EndAddr == 0x20000008U) &&
                (rd_cfg.WriteProtectEnable == 1U) &&
                (rd_cfg.ReadProtectEnable == 0U) &&
                (rd_cfg.ChannelEnable == 1U) &&
                (rd_cfg.Reserved[0] == 0U) && (rd_cfg.Reserved[1] == 0U)) ? 1U : 0U));
        Check("GetChannelConfig(NULL output) = HAL_ERROR",
              ((HAL_MPU_GetChannelConfig(&hmpu_dev, 2U, NULL_PTR) == HAL_ERROR) ? 1U : 0U));
        Check("GetChannelConfig(NULL handle) = HAL_ERROR",
              ((HAL_MPU_GetChannelConfig(NULL_PTR, 2U, &rd_cfg) == HAL_ERROR) ? 1U : 0U));
        Check("GetChannelConfig(channel 16 on MPU1) = HAL_ERROR",
              ((HAL_MPU_GetChannelConfig(&hmpu_dev, 16U, &rd_cfg) == HAL_ERROR) ? 1U : 0U));

        /* MPU0 has no write protection: it accepts a read protection request
         * only (a write protection request would be rejected), so its read-back
         * reports 0 for the write protection */
        mpu_init.Instance           = HAL_MPU_INSTANCE_0_IBUS;
        mpu_init.Channel            = 0U;
        mpu_init.WriteProtectEnable = 0U;
        mpu_init.ReadProtectEnable  = 1U;
        mpu_init.ChannelEnable      = 1U;
        hmpu_dev.Instance           = HAL_MPU_INSTANCE_0_IBUS;
        hmpu_dev.Init               = mpu_init;
        (void)HAL_MPU_Init(&hmpu_dev);
        __HAL_CLEAR_STRUCT(&rd_cfg);
        (void)HAL_MPU_GetChannelConfig(&hmpu_dev, 0U, &rd_cfg);
        Check("MPU0 read-back reports no write protection enable",
              ((rd_cfg.WriteProtectEnable == 0U) ? 1U : 0U));
        Check("MPU0 read-back reports the read / channel enables",
              (((rd_cfg.ReadProtectEnable == 1U) && (rd_cfg.ChannelEnable == 1U)) ? 1U : 0U));
        (void)HAL_MPU_ResetInstance(&hmpu_dev);
        (void)HAL_MPU_DeInit(&hmpu_dev);

        /* configure two channels of MPU1 and clear the whole instance */
        mpu_init.Instance           = HAL_MPU_INSTANCE_1_DBUS;
        mpu_init.Channel            = 2U;
        mpu_init.WriteProtectEnable = 1U;
        mpu_init.ReadProtectEnable  = 0U;
        hmpu_dev.Instance           = HAL_MPU_INSTANCE_1_DBUS;
        hmpu_dev.Init               = mpu_init;
        Check("channel 2 configured", ((HAL_MPU_Init(&hmpu_dev) == HAL_OK) ? 1U : 0U));
        mpu_init.Channel           = 3U;
        mpu_init.ReadProtectEnable = 1U;
        hmpu_dev.Init              = mpu_init;
        Check("channel 3 configured", ((HAL_MPU_Init(&hmpu_dev) == HAL_OK) ? 1U : 0U));

        Check("ResetInstance returns HAL_OK",
              ((HAL_MPU_ResetInstance(&hmpu_dev) == HAL_OK) ? 1U : 0U));
        Check("state READY after ResetInstance",
              ((HAL_MPU_GetState(&hmpu_dev) == HAL_MPU_STATE_READY) ? 1U : 0U));
        Check("ResetInstance(NULL) = HAL_ERROR",
              ((HAL_MPU_ResetInstance(NULL_PTR) == HAL_ERROR) ? 1U : 0U));

        ok = 1U;
        for (ch = 0U; ch < 16U; ch++)
        {
            __HAL_CLEAR_STRUCT(&rd_cfg);
            (void)HAL_MPU_GetChannelConfig(&hmpu_dev, ch, &rd_cfg);

            if ((rd_cfg.ChannelEnable != 0U) || (rd_cfg.ReadProtectEnable != 0U) ||
                (rd_cfg.WriteProtectEnable != 0U) || (rd_cfg.StartAddr != 0U) ||
                (rd_cfg.EndAddr != 0U))
            {
                ok = 0U;
            }
        }
        Check("every channel of MPU1 cleared by ResetInstance", ok);

        /* the handle stays READY, so the instance can be used again at once */
        mpu_init.Channel = 3U;
        hmpu_dev.Init    = mpu_init;
        Check("re-Init after ResetInstance", ((HAL_MPU_Init(&hmpu_dev) == HAL_OK) ? 1U : 0U));
        (void)HAL_MPU_ResetInstance(&hmpu_dev);
        (void)HAL_MPU_DeInit(&hmpu_dev);
        Check("ResetInstance on a RESET handle = HAL_ERROR",
              ((HAL_MPU_ResetInstance(&hmpu_dev) == HAL_ERROR) ? 1U : 0U));
        mpu_init.Instance = TEST_INSTANCE;    /* restore for the next loop */

        printf("\r\nsummary : failures = %u\r\n", PRINT_U32(failures));
        delay_ms(TEST_PERIOD_MS);
    }
}

/**
 * @brief  Exercise the channel control functions of one MPU instance.
 * @note   The address range is benign (a RAM word); only the register
 *         programming of the functions is checked, and the channel is disabled
 *         again before returning.
 * @param  instance: MPU instance (HAL_MPU_INSTANCE_2..4).
 * @param  channel: channel index (0..7).
 * @retval None
 */
static void Instance_ControlCheck(uint32 instance, uint32 channel)
{
    HAL_MPU_HandleTypeDef hmpu;
    uint32 bit = (uint32)(1UL << channel);
    uint32 start = (uint32)(unsigned long)&protected_word;

    __HAL_CLEAR_STRUCT(&hmpu);
    hmpu.Instance = instance;
    /* The channel control functions require an initialized handle: this helper
       drives them directly, so the READY state is set up explicitly (no
       channel is programmed by HAL_MPU_Init() here) */
    hmpu.State = HAL_MPU_STATE_READY;

    HAL_MPU_SetAddressRange(&hmpu, channel, start, start + TEST_WINDOW_LENGTH);

    HAL_MPU_ReadProtectCmd(&hmpu, channel, MPU_ENABLE);
    Check("ReadProtectCmd set RPTEN",
          (((HAL_MPU_GetRegBlock(instance)->RPTEN & bit) != 0U) ? 1U : 0U));

    HAL_MPU_WriteProtectCmd(&hmpu, channel, MPU_ENABLE);
    Check("WriteProtectCmd set WPTEN",
          (((HAL_MPU_GetRegBlock(instance)->WPTEN & bit) != 0U) ? 1U : 0U));

    HAL_MPU_Cmd(&hmpu, channel, MPU_ENABLE);
    Check("Cmd set PTEN", ((((HAL_MPU_GetRegBlock(instance)->PTEN & bit) != 0U)) ? 1U : 0U));

    HAL_MPU_Cmd(&hmpu, channel, MPU_DISABLE);
    HAL_MPU_ReadProtectCmd(&hmpu, channel, MPU_DISABLE);
    HAL_MPU_WriteProtectCmd(&hmpu, channel, MPU_DISABLE);
    Check("control bits cleared again",
          ((((HAL_MPU_GetRegBlock(instance)->PTEN |
              HAL_MPU_GetRegBlock(instance)->RPTEN |
              HAL_MPU_GetRegBlock(instance)->WPTEN) & bit) == 0U) ? 1U : 0U));

    HAL_MPU_ClearStatus(&hmpu, channel);
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition == 0U)
    {
        failures++;
    }
    printf("%-46s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Configure the system clock tree using the HAL SMU / PMU drivers.
 * @note   Same clock tree as the CLINT / CMU reference suites: OSC 20 MHz as
 *         the PLL source, PLLDivN = 20 / PLLDivF = 180 / PLLDivQ = 1 /
 *         PLLDivR = 4 -> 180 MHz VCO, AXI4Bus3 = /2, APBBus0 = /2,
 *         APBBus1 = /2, CANX2 = /8; the 2.5V LDO is scaled to 2.78 V and the
 *         1.2V LDO to 1.34 V as in the reference suites.
 * @note   Clock tree order (the order the chip requires, and the order the
 *         vendor test case uses): configure the oscillators and the PLL and
 *         switch the system clock to it, then write the bus clock dividers.
 *         HAL_SMU_OscConfig() programs the EFLASH controller clock (CLKFRQ)
 *         before the switch and lets it follow the new system clock afterwards
 *         (EFLASH_CLK_UPDATE), so no explicit HAL_FLASH_SetClockFrequency() is
 *         needed here; it also updates SystemCoreClock together with the HAL
 *         time base.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef  SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef   SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it (CLKFRQ above), so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Set the bus clock dividers (the system clock source is already set by
       HAL_SMU_OscConfig() above) */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/

