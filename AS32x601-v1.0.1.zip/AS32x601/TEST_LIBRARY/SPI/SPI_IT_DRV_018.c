/**
 * @file    SPI_IT_DRV_018.c
 * @brief   HAL SPI integration test case 018 (API self check).
 *
 * Extension case of this suite: it checks the whole public interface of the HAL
 * SPI driver that the ported reference cases do not touch - the configuration
 * structure defaults, the run time argument checks of the driver, the state
 * machine, the low level register level interface, the validation macros and
 * the handle life cycle (including the MSP callbacks). Only HAL library APIs
 * are used.
 *
 * Tested functionality:
 *   __HAL_SPI_MODULE_VERSION
 *   HAL_SPI_StructInit()
 *   HAL_SPI_Init() / HAL_SPI_DeInit()
 *   HAL_SPI_MspInit() / HAL_SPI_MspDeInit()   (call counters)
 *   HAL_SPI_GetState() / HAL_SPI_GetError()
 *   HAL_SPI_Cmd() / HAL_SPI_ResetFIFO() / HAL_SPI_NSSConfig()
 *   HAL_SPI_SendData() / HAL_SPI_SendDataLast() / HAL_SPI_ReceiveData()
 *   HAL_SPI_ITConfig() / HAL_SPI_GetITStatus() / HAL_SPI_GetITRawStatus()
 *   HAL_SPI_ClearITPendingBit() / HAL_SPI_GetFlagStatus()
 *   HAL_SPI_Transmit() / HAL_SPI_Transmit_IT()
 *   IS_SPI_* validation macros
 *
 * Test procedure:
 *   1. module version and structure defaults;
 *   2. rejected initialization: every invalid field must be refused before any
 *      register access, with HAL_SPI_ERROR_INVALID_PARAM and without changing
 *      the handle state or the registers;
 *   3. accepted initialization and the register read back;
 *   4. rejected transfer requests (null pointer, zero length);
 *   5. low level register interface: enable / disable, FIFO reset, slave select
 *      selection, data registers, interrupt sources and flags;
 *   6. validation macros;
 *   7. invalid handle protection;
 *   8. busy handle protection (a running interrupt transfer rejects a new one);
 *   9. de-initialization, MSP call back counters and the re-initialization.
 *
 * Expected behaviour:
 *   - every rejected request returns HAL_ERROR (or HAL_BUSY for a busy handle)
 *     and reports HAL_SPI_ERROR_INVALID_PARAM, without touching the registers;
 *   - the accepted requests return HAL_OK and the state machine follows the
 *     documented sequence RESET -> BUSY -> READY -> RESET;
 *   - the MSP callbacks run once per RESET -> READY transition and the
 *     de-initialization callback runs after the lock has been released;
 *   - every check prints [PASS] and "summary : failures = 0".
 *
 * Note:
 *   - The case does not need an external peer: it only checks the driver
 *     contract, the register programming and one interrupt driven transfer that
 *     is started and then aborted by a de-initialization.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console: USART0 on GPIOD pin 8 (TX) / pin 9 (RX), 115200 8N1 */
#define TEST_BAUDRATE                   (115200U)

/* Device under test: SPI3
 *   CS0  = PC10   SCK  = PD3   MOSI = PD1   MISO = PD2
 */
#define TEST_SPI                        SPI3
#define TEST_CS_PORT                    GPIOC
#define TEST_CS_PIN                     GPIO_PIN_10
#define TEST_CS_SOURCE                  GPIO_PinSource10
#define TEST_SCK_PORT                   GPIOD
#define TEST_SCK_PIN                    GPIO_PIN_3
#define TEST_SCK_SOURCE                 GPIO_PinSource3
#define TEST_MOSI_PORT                  GPIOD
#define TEST_MOSI_PIN                   GPIO_PIN_1
#define TEST_MOSI_SOURCE                GPIO_PinSource1
#define TEST_MISO_PORT                  GPIOD
#define TEST_MISO_PIN                   GPIO_PIN_2
#define TEST_MISO_SOURCE                GPIO_PinSource2
#define TEST_PIN_AF                     GPIO_AF_SPI3

/* Frame geometry and timeouts */
#define FRAME_COUNT                     (64U)
#define TRANSFER_TIMEOUT_MS             (100U)
#define BUSY_TIMEOUT_MS                 (10U)

/* Private variables ---------------------------------------------------------*/
static SPI_HandleTypeDef hspi_dev;              /*!< device under test      */
static HAL_SMU_HandleTypeDef hsmu_clk;          /*!< SMU handle (clock tree) */
static uint8 tx_data[FRAME_COUNT];              /*!< transmit pattern        */
static uint8 rx_data[FRAME_COUNT];              /*!< receive buffer          */
static volatile uint32 check_failures = 0U;     /*!< failed check counter    */
static volatile uint32 msp_init_count = 0U;     /*!< MspInit calls           */
static volatile uint32 msp_deinit_count = 0U;   /*!< MspDeInit calls         */
static volatile uint32 msp_init_state_reset = 0U; /*!< MspInit saw RESET     */
static volatile uint32 msp_init_lock_free = 0U;   /*!< MspInit saw no lock   */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void BufferInit(void);
static void Check(const char *name, uint32 condition);
static void Summary(void);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    SPI_InitTypeDef spi_init;
    SPI_InitTypeDef bad_init;
    HAL_StatusTypeDef status;
    uint32 index;
    uint32 snapshot;
    uint32 saved_cfg;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock tree */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART (USART0 on GPIOD pin 8 / pin 9) */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== SPI_IT_DRV_018 : API self check (SPI3) ===\r\n");

    BufferInit();

    /* ---- Step 1: module version and structure defaults ------------------- */
    printf("\r\n-- step 1 : module version and structure defaults --\r\n");
    printf("module version : 0x%08X\r\n", PRINT_U32(__HAL_SPI_MODULE_VERSION));
    Check("module version is 0x0100",
          (uint32)((__HAL_SPI_MODULE_VERSION == 0x0100U) ? 1U : 0U));
    Check("SPI_INIT_VERSION is 0x0100",
          (uint32)((SPI_INIT_VERSION == 0x0100U) ? 1U : 0U));

    __HAL_CLEAR_STRUCT(&spi_init);
    HAL_SPI_StructInit(&spi_init);

    Check("StructInit : Size = sizeof(SPI_InitTypeDef)",
          (uint32)((spi_init.Size == sizeof(SPI_InitTypeDef)) ? 1U : 0U));
    Check("StructInit : Version = SPI_INIT_VERSION",
          (uint32)((spi_init.Version == SPI_INIT_VERSION) ? 1U : 0U));
    Check("StructInit : clock divider = SPI_CLKDiv2",
          (uint32)((spi_init.SPI_CLKDiv == SPI_CLKDiv2) ? 1U : 0U));
    Check("StructInit : mode = SPI_Mode_Master",
          (uint32)((spi_init.SPI_Mode == SPI_Mode_Master) ? 1U : 0U));
    Check("StructInit : frame size = SPI_FrameSize_8b",
          (uint32)((spi_init.SPI_FrameSize == SPI_FrameSize_8b) ? 1U : 0U));
    Check("StructInit : Motorola mode = Mode0",
          (uint32)((spi_init.SPI_MotorolaMode == SPI_Motorola_Mode0) ? 1U : 0U));
    Check("StructInit : transfer mode = SPI_TransNor",
          (uint32)((spi_init.SPI_TransMode == SPI_TransNor) ? 1U : 0U));
    Check("StructInit : reserved words are zero",
          (uint32)(((spi_init.Reserved[0] == 0U) &&
                    (spi_init.Reserved[1] == 0U)) ? 1U : 0U));

    /* ---- Step 2: rejected initialization -------------------------------- */
    printf("\r\n-- step 2 : rejected initialization --\r\n");

    __HAL_CLEAR_STRUCT(&hspi_dev);
    hspi_dev.Instance = TEST_SPI;
    hspi_dev.Init     = spi_init;

    /* The registers must not change on a rejected request: keep a snapshot of
     * the mode register, which is written by an accepted initialization */
    saved_cfg = (uint32)TEST_SPI->CFG;

    bad_init = spi_init;
    bad_init.SPI_CLKDiv = 0x00000002U;             /* not a divider code */
    hspi_dev.Init = bad_init;
    status = HAL_SPI_Init(&hspi_dev);
    Check("invalid clock divider is rejected",
          (uint32)((status == HAL_ERROR) ? 1U : 0U));
    Check("invalid clock divider sets INVALID_PARAM",
          (uint32)(((HAL_SPI_GetError(&hspi_dev) &
                     HAL_SPI_ERROR_INVALID_PARAM) != 0U) ? 1U : 0U));
    Check("state stays RESET after the rejection",
          (uint32)((HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_RESET) ? 1U : 0U));

    bad_init = spi_init;
    bad_init.SPI_Mode = 0x00000005U;               /* neither master nor slave */
    hspi_dev.Init = bad_init;
    status = HAL_SPI_Init(&hspi_dev);
    Check("invalid mode is rejected", (uint32)((status == HAL_ERROR) ? 1U : 0U));

    bad_init = spi_init;
    bad_init.SPI_FrameSize = 0x00002200U;          /* not a frame size code */
    hspi_dev.Init = bad_init;
    status = HAL_SPI_Init(&hspi_dev);
    Check("invalid frame size is rejected", (uint32)((status == HAL_ERROR) ? 1U : 0U));

    bad_init = spi_init;
    bad_init.SPI_MotorolaMode = 0x00000001U;       /* not a Motorola mode code */
    hspi_dev.Init = bad_init;
    status = HAL_SPI_Init(&hspi_dev);
    Check("invalid Motorola mode is rejected", (uint32)((status == HAL_ERROR) ? 1U : 0U));

    bad_init = spi_init;
    bad_init.SPI_TransMode = 0x00000020U;          /* not a transfer mode code */
    hspi_dev.Init = bad_init;
    status = HAL_SPI_Init(&hspi_dev);
    Check("invalid transfer mode is rejected", (uint32)((status == HAL_ERROR) ? 1U : 0U));

    Check("the mode register was not touched by the rejected calls",
          (uint32)((((uint32)TEST_SPI->CFG) == saved_cfg) ? 1U : 0U));
    Check("the MSP callback was not called by the rejected calls",
          (uint32)((msp_init_count == 0U) ? 1U : 0U));

    /* ---- Step 3: accepted initialization -------------------------------- */
    printf("\r\n-- step 3 : accepted initialization --\r\n");

    hspi_dev.Init = spi_init;
    status = HAL_SPI_Init(&hspi_dev);
    Check("HAL_SPI_Init returns HAL_OK", (uint32)((status == HAL_OK) ? 1U : 0U));
    Check("state after init is READY",
          (uint32)((HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_READY) ? 1U : 0U));
    Check("error code after init is NONE",
          (uint32)((HAL_SPI_GetError(&hspi_dev) == HAL_SPI_ERROR_NONE) ? 1U : 0U));
    Check("MspInit was called once", (uint32)((msp_init_count == 1U) ? 1U : 0U));
    Check("MspInit ran while the handle was in RESET",
          (uint32)((msp_init_state_reset != 0U) ? 1U : 0U));
    Check("MspInit ran before the lock was taken",
          (uint32)((msp_init_lock_free != 0U) ? 1U : 0U));

    printf("CLKCR          : 0x%08X\r\n", PRINT_U32((uint32)TEST_SPI->CLKCR));
    printf("CR0            : 0x%08X\r\n", PRINT_U32((uint32)TEST_SPI->CR0));
    printf("CFG            : 0x%08X\r\n", PRINT_U32((uint32)TEST_SPI->CFG));
    Check("clock divider field carries /2",
          (uint32)((((uint32)TEST_SPI->CLKCR & SPI_CLKCR_CLKCR_Msk) ==
                    (SPI_CLKDiv2 & SPI_CLKCR_CLKCR_Msk)) ? 1U : 0U));
    Check("CR0.MSTR is set (master mode)",
          (uint32)((((uint32)TEST_SPI->CR0 & SPI_CR0_MSTR) != 0U) ? 1U : 0U));
    Check("CFG carries the 8 bit frame size",
          (uint32)((((uint32)TEST_SPI->CFG & SPI_CFG_FS_Msk) ==
                    (SPI_FrameSize_8b & SPI_CFG_FS_Msk)) ? 1U : 0U));

    /* A second initialization of a READY handle must not re-run the MSP
     * callback (MSP-04) */
    status = HAL_SPI_Init(&hspi_dev);
    Check("re-init of a READY handle returns HAL_OK",
          (uint32)((status == HAL_OK) ? 1U : 0U));
    Check("re-init does not call MspInit again",
          (uint32)((msp_init_count == 1U) ? 1U : 0U));

    /* ---- Step 4: rejected transfer requests ----------------------------- */
    printf("\r\n-- step 4 : rejected transfer requests --\r\n");

    status = HAL_SPI_Transmit(&hspi_dev, NULL_PTR, FRAME_COUNT,
                              TRANSFER_TIMEOUT_MS);
    Check("a null data pointer is rejected", (uint32)((status == HAL_ERROR) ? 1U : 0U));
    Check("a null data pointer sets INVALID_PARAM",
          (uint32)(((HAL_SPI_GetError(&hspi_dev) &
                     HAL_SPI_ERROR_INVALID_PARAM) != 0U) ? 1U : 0U));

    status = HAL_SPI_Transmit(&hspi_dev, tx_data, 0U, TRANSFER_TIMEOUT_MS);
    Check("a zero length transfer is rejected",
          (uint32)((status == HAL_ERROR) ? 1U : 0U));

    status = HAL_SPI_Receive(&hspi_dev, NULL_PTR, FRAME_COUNT,
                             TRANSFER_TIMEOUT_MS);
    Check("a null receive buffer is rejected",
          (uint32)((status == HAL_ERROR) ? 1U : 0U));

    status = HAL_SPI_TransmitReceive(&hspi_dev, NULL_PTR, rx_data, FRAME_COUNT,
                                     TRANSFER_TIMEOUT_MS);
    Check("a null full duplex buffer is rejected",
          (uint32)((status == HAL_ERROR) ? 1U : 0U));

    Check("the rejected requests left the handle in READY",
          (uint32)((HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_READY) ? 1U : 0U));

    /* ---- Step 5: low level register interface --------------------------- */
    printf("\r\n-- step 5 : low level register interface --\r\n");

    /* Master with /512, so that the shifter stays slow enough to observe the
     * FIFO flags */
    hspi_dev.Init.SPI_CLKDiv = SPI_CLKDiv512;
    status = HAL_SPI_Init(&hspi_dev);
    Check("re-init with /512 returns HAL_OK", (uint32)((status == HAL_OK) ? 1U : 0U));

    HAL_SPI_Cmd(&hspi_dev, SPI_ENABLE);
    Check("HAL_SPI_Cmd(ENABLE) sets CR0.SPE",
          (uint32)((((uint32)TEST_SPI->CR0 & SPI_CR0_SPE) != 0U) ? 1U : 0U));
    HAL_SPI_Cmd(&hspi_dev, SPI_DISABLE);
    Check("HAL_SPI_Cmd(DISABLE) clears CR0.SPE",
          (uint32)((((uint32)TEST_SPI->CR0 & SPI_CR0_SPE) == 0U) ? 1U : 0U));
    HAL_SPI_Cmd(&hspi_dev, SPI_ENABLE);

    HAL_SPI_ResetFIFO(&hspi_dev, SPI_RESETFIFO_TXANDRX);
    Check("FIFO reset request is self clearing",
          (uint32)((((uint32)TEST_SPI->CR1 &
                     (SPI_CR1_RXRE | SPI_CR1_TXRE)) == 0U) ? 1U : 0U));

    /* Slave select selection */
    HAL_SPI_NSSConfig(&hspi_dev, SPI_Slave0, SPI_ENABLE);
    Check("slave 0 selected",
          (uint32)((((uint32)TEST_SPI->SSR & SPI_SSR_SSR_Msk) == SPI_Slave0) ?
                   1U : 0U));
    /* The API selects exactly the requested line: the register carries the
     * current selection, so a second call replaces the first one instead of
     * adding to it (the same equality also proves slave 0 was dropped) */
    HAL_SPI_NSSConfig(&hspi_dev, SPI_Slave3, SPI_ENABLE);
    Check("slave 3 replaces the selection",
          (uint32)((((uint32)TEST_SPI->SSR & SPI_SSR_SSR_Msk) ==
                    SPI_Slave3) ? 1U : 0U));
    HAL_SPI_NSSConfig(&hspi_dev, SPI_Slave0, SPI_DISABLE);
    HAL_SPI_NSSConfig(&hspi_dev, SPI_Slave3, SPI_DISABLE);
    Check("selection cleared again",
          (uint32)((((uint32)TEST_SPI->SSR & SPI_SSR_SSR_Msk) == 0U) ? 1U : 0U));

    /* Data registers: a write into the transmit register shifts one frame out
     * and fills the receive FIFO with the frame the shifter captured */
    HAL_SPI_ResetFIFO(&hspi_dev, SPI_RESETFIFO_TXANDRX);
    Check("the receive FIFO starts empty",
          (uint32)((HAL_SPI_GetFlagStatus(&hspi_dev, SPI_Flag_RXE) != 0U) ? 1U : 0U));

    HAL_SPI_SendData(&hspi_dev, 0x5AU);
    for (index = 0U; index < 200000U; index++)
    {
        if (HAL_SPI_GetFlagStatus(&hspi_dev, SPI_Flag_RXE) == 0U)
        {
            break;
        }
    }
    Check("a frame arrived in the receive FIFO after the write",
          (uint32)((HAL_SPI_GetFlagStatus(&hspi_dev, SPI_Flag_RXE) == 0U) ? 1U : 0U));

    snapshot = HAL_SPI_ReceiveData(&hspi_dev);
    printf("RXDR read      : 0x%08X\r\n", PRINT_U32(snapshot));
    Check("the receive FIFO is empty again after the read",
          (uint32)((HAL_SPI_GetFlagStatus(&hspi_dev, SPI_Flag_RXE) != 0U) ? 1U : 0U));

    /* The end of send register carries the last frame of a transfer: after it
     * the shifter reports DONE (no request pending) */
    HAL_SPI_SendDataLast(&hspi_dev, 0xA5U);
    for (index = 0U; index < 200000U; index++)
    {
        if (HAL_SPI_GetFlagStatus(&hspi_dev, SPI_Flag_DONE) != 0U)
        {
            break;
        }
    }
    Check("SR.DONE is set after the last frame",
          (uint32)((HAL_SPI_GetFlagStatus(&hspi_dev, SPI_Flag_DONE) != 0U) ? 1U : 0U));
    (void)HAL_SPI_ReceiveData(&hspi_dev);
    HAL_SPI_ResetFIFO(&hspi_dev, SPI_RESETFIFO_TXANDRX);

    /* Interrupt sources: each source owns one enable bit. The transmit done,
     * receive overflow and transmit empty sources live in CR0, the slave
     * select, receive not empty and transmit not full sources in IER. */
    HAL_SPI_ITConfig(&hspi_dev, SPI_IT_RXNE, SPI_ENABLE);
    Check("IER receive not empty enable bit is set",
          (uint32)((((uint32)TEST_SPI->IER & (1UL << 6)) != 0U) ? 1U : 0U));
    HAL_SPI_ITConfig(&hspi_dev, SPI_IT_RXNE, SPI_DISABLE);
    Check("IER receive not empty enable bit is cleared",
          (uint32)((((uint32)TEST_SPI->IER & (1UL << 6)) == 0U) ? 1U : 0U));

    HAL_SPI_ITConfig(&hspi_dev, SPI_IT_TXNE, SPI_ENABLE);
    Check("IER transmit not full enable bit is set",
          (uint32)((((uint32)TEST_SPI->IER & (1UL << 7)) != 0U) ? 1U : 0U));
    HAL_SPI_ITConfig(&hspi_dev, SPI_IT_TXNE, SPI_DISABLE);

    HAL_SPI_ITConfig(&hspi_dev, SPI_IT_NSSV, SPI_ENABLE);
    Check("IER slave select enable bit is set",
          (uint32)((((uint32)TEST_SPI->IER & (1UL << 5)) != 0U) ? 1U : 0U));
    HAL_SPI_ITConfig(&hspi_dev, SPI_IT_NSSV, SPI_DISABLE);

    HAL_SPI_ITConfig(&hspi_dev, SPI_IT_RXO, SPI_ENABLE);
    Check("CR0 receive overflow enable bit is set",
          (uint32)((((uint32)TEST_SPI->CR0 & (1UL << 4)) != 0U) ? 1U : 0U));
    HAL_SPI_ITConfig(&hspi_dev, SPI_IT_RXO, SPI_DISABLE);

    HAL_SPI_ITConfig(&hspi_dev, SPI_IT_TXE, SPI_ENABLE);
    Check("CR0 transmit empty enable bit is set",
          (uint32)((((uint32)TEST_SPI->CR0 & (1UL << 5)) != 0U) ? 1U : 0U));
    HAL_SPI_ITConfig(&hspi_dev, SPI_IT_TXE, SPI_DISABLE);

    HAL_SPI_ITConfig(&hspi_dev, SPI_IT_TD, SPI_ENABLE);
    Check("CR0 transmit done enable bit is set",
          (uint32)((((uint32)TEST_SPI->CR0 & (1UL << 3)) != 0U) ? 1U : 0U));
    HAL_SPI_ITConfig(&hspi_dev, SPI_IT_TD, SPI_DISABLE);
    Check("every interrupt enable bit is masked again",
          (uint32)(((((uint32)TEST_SPI->CR0 &
                       (SPI_CR0_TDIE | SPI_CR0_RXOIE | SPI_CR0_TXEIE)) |
                     ((uint32)TEST_SPI->IER & 0xE0U)) == 0U) ? 1U : 0U));

    /* Pending bits: write one and clear it again */
    HAL_SPI_ClearITPendingBit(&hspi_dev, SPI_CLEAR_TD);
    Check("the transmit done pending bit is clear",
          (uint32)((HAL_SPI_GetITStatus(&hspi_dev, SPI_ITStatus_TD) == 0U) ? 1U : 0U));
    HAL_SPI_ClearITPendingBit(&hspi_dev, SPI_CLEAR_RXNE);
    Check("the receive pending bit is clear",
          (uint32)((HAL_SPI_GetITStatus(&hspi_dev, SPI_ITStatus_RXNE) == 0U) ? 1U : 0U));

    /* Raw status read (no mask of the enable bits) */
    snapshot = HAL_SPI_GetITRawStatus(&hspi_dev, SPI_ITRaw_TXNF);
    printf("raw TXNF       : %u\r\n", PRINT_U32(snapshot));
    Check("the raw status can be read back",
          (uint32)(((snapshot == 0U) || (snapshot == 1U)) ? 1U : 0U));

    /* Flags */
    Check("SPI_Flag_RXE is readable",
          (uint32)(((HAL_SPI_GetFlagStatus(&hspi_dev, SPI_Flag_RXE) == 0U) ||
                    (HAL_SPI_GetFlagStatus(&hspi_dev, SPI_Flag_RXE) == 1U)) ?
                   1U : 0U));
    Check("SPI_Flag_TXF is readable",
          (uint32)(((HAL_SPI_GetFlagStatus(&hspi_dev, SPI_Flag_TXF) == 0U) ||
                    (HAL_SPI_GetFlagStatus(&hspi_dev, SPI_Flag_TXF) == 1U)) ?
                   1U : 0U));
    Check("SPI_Flag_BUSS is readable",
          (uint32)(((HAL_SPI_GetFlagStatus(&hspi_dev, SPI_Flag_BUSS) == 0U) ||
                    (HAL_SPI_GetFlagStatus(&hspi_dev, SPI_Flag_BUSS) == 1U)) ?
                   1U : 0U));

    /* ---- Step 6: validation macros -------------------------------------- */
    printf("\r\n-- step 6 : validation macros --\r\n");

    Check("IS_SPI_ALL_PERIPH accepts SPI3", (uint32)((IS_SPI_ALL_PERIPH(SPI3) != 0U) ? 1U : 0U));
    Check("IS_SPI_MODE accepts both modes",
          (uint32)(((IS_SPI_MODE(SPI_Mode_Master) != 0U) &&
                    (IS_SPI_MODE(SPI_Mode_Slave) != 0U)) ? 1U : 0U));
    Check("IS_SPI_MODE rejects a foreign value",
          (uint32)((IS_SPI_MODE(0x00000005U) == 0U) ? 1U : 0U));
    Check("IS_SPI_CLKDIV accepts the nine codes",
          (uint32)(((IS_SPI_CLKDIV(SPI_CLKDiv2) != 0U) &&
                    (IS_SPI_CLKDIV(SPI_CLKDiv512) != 0U) &&
                    (IS_SPI_CLKDIV(SPI_CLKDiv8) != 0U)) ? 1U : 0U));
    Check("IS_SPI_CLKDIV rejects a foreign value",
          (uint32)((IS_SPI_CLKDIV(0x00000002U) == 0U) ? 1U : 0U));
    Check("IS_SPI_FRAMESIZE accepts the ends of the range",
          (uint32)(((IS_SPI_FRAMESIZE(SPI_FrameSize_4b) != 0U) &&
                    (IS_SPI_FRAMESIZE(SPI_FrameSize_32b) != 0U)) ? 1U : 0U));
    Check("IS_SPI_MOTOROLAMODE accepts all four modes",
          (uint32)(((IS_SPI_MOTOROLAMODE(SPI_Motorola_Mode0) != 0U) &&
                    (IS_SPI_MOTOROLAMODE(SPI_Motorola_Mode3) != 0U)) ? 1U : 0U));
    Check("IS_SPI_TRANSMODE accepts both modes",
          (uint32)(((IS_SPI_TRANSMODE(SPI_TransNor) != 0U) &&
                    (IS_SPI_TRANSMODE(SPI_TransBToB) != 0U)) ? 1U : 0U));
    Check("IS_SPI_SLAVESEL accepts the four lines",
          (uint32)(((IS_SPI_SLAVESEL(SPI_Slave0) != 0U) &&
                    (IS_SPI_SLAVESEL(SPI_Slave3) != 0U)) ? 1U : 0U));

    /* ---- Step 7: invalid handle protection ------------------------------ */
    printf("\r\n-- step 7 : invalid handle protection --\r\n");

    status = HAL_SPI_Init(NULL_PTR);
    Check("HAL_SPI_Init(NULL) returns HAL_ERROR", (uint32)((status == HAL_ERROR) ? 1U : 0U));
    status = HAL_SPI_DeInit(NULL_PTR);
    Check("HAL_SPI_DeInit(NULL) returns HAL_ERROR", (uint32)((status == HAL_ERROR) ? 1U : 0U));
    status = HAL_SPI_Transmit(NULL_PTR, tx_data, FRAME_COUNT, TRANSFER_TIMEOUT_MS);
    Check("HAL_SPI_Transmit(NULL) returns HAL_ERROR",
          (uint32)((status == HAL_ERROR) ? 1U : 0U));
    status = HAL_SPI_Transmit_IT(NULL_PTR, tx_data, FRAME_COUNT);
    Check("HAL_SPI_Transmit_IT(NULL) returns HAL_ERROR",
          (uint32)((status == HAL_ERROR) ? 1U : 0U));
    Check("HAL_SPI_GetState(NULL) does not crash",
          (uint32)((HAL_SPI_GetState(NULL_PTR) == HAL_SPI_STATE_RESET) ? 1U : 0U));
    Check("HAL_SPI_GetError(NULL) returns NONE",
          (uint32)((HAL_SPI_GetError(NULL_PTR) == HAL_SPI_ERROR_NONE) ? 1U : 0U));

    /* ---- Step 8: busy handle protection --------------------------------- */
    printf("\r\n-- step 8 : busy handle protection --\r\n");

    status = HAL_SPI_Transmit_IT(&hspi_dev, tx_data, FRAME_COUNT);
    Check("an interrupt transfer can be started",
          (uint32)((status == HAL_OK) ? 1U : 0U));
    status = HAL_SPI_Transmit(&hspi_dev, tx_data, FRAME_COUNT, BUSY_TIMEOUT_MS);
    Check("a new blocking transfer is refused with HAL_BUSY",
          (uint32)((status == HAL_BUSY) ? 1U : 0U));
    Check("the handle is still busy with the running transfer",
          (uint32)(((HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_BUSY_TX) ||
                    (HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_READY)) ?
                   1U : 0U));

    /* Stop the running transfer: the driver has no abort entry point, a
     * de-initialization disables the peripheral and resets the handle */
    HAL_SPI_ITConfig(&hspi_dev, SPI_IT_TXNE, SPI_DISABLE);
    HAL_SPI_ITConfig(&hspi_dev, SPI_IT_RXNE, SPI_DISABLE);
    HAL_SPI_ITConfig(&hspi_dev, SPI_IT_RXO, SPI_DISABLE);

    /* ---- Step 9: de-initialization and MSP callbacks -------------------- */
    printf("\r\n-- step 9 : de-initialization --\r\n");

    status = HAL_SPI_DeInit(&hspi_dev);
    Check("HAL_SPI_DeInit returns HAL_OK", (uint32)((status == HAL_OK) ? 1U : 0U));
    Check("state after de-init is RESET",
          (uint32)((HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_RESET) ? 1U : 0U));
    Check("CR0.SPE is cleared after de-init",
          (uint32)((((uint32)TEST_SPI->CR0 & SPI_CR0_SPE) == 0U) ? 1U : 0U));
    Check("MspDeInit was called once",
          (uint32)((msp_deinit_count == 1U) ? 1U : 0U));

    /* A fresh initialization after the de-initialization runs the MSP callback
     * again */
    status = HAL_SPI_Init(&hspi_dev);
    Check("re-init after de-init returns HAL_OK",
          (uint32)((status == HAL_OK) ? 1U : 0U));
    Check("re-init after de-init calls MspInit again",
          (uint32)((msp_init_count == 2U) ? 1U : 0U));
    Check("state is READY again",
          (uint32)((HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_READY) ? 1U : 0U));

    printf("\r\nMSP callbacks : init %u, deinit %u\r\n",
           PRINT_U32(msp_init_count), PRINT_U32(msp_deinit_count));

    Summary();

    while (1)
    {
        delay_ms(1000U);
    }
}

/**
 * @brief  Fill the transmit buffer with 0x00 .. 0x3F.
 * @param  None
 * @retval None
 */
static void BufferInit(void)
{
    uint32 index;

    for (index = 0U; index < FRAME_COUNT; index++)
    {
        tx_data[index] = (uint8)index;
        rx_data[index] = 0x00U;
    }
}

/**
 * @brief  Report the result of one check.
 * @param  name: short description of the check.
 * @param  condition: 0 = FAIL, non zero = PASS.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("%-52s : [PASS]\r\n", name);
    }
    else
    {
        check_failures++;
        printf("%-52s : [FAIL]\r\n", name);
    }
}

/**
 * @brief  Print the accumulated failure counter.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(check_failures));
}

/**
 * @brief  MSP initialization of the device under test.
 * @note   Strong override of the weak driver callback. It records the state and
 *         the lock of the handle at the time it runs, which documents the
 *         MSP-04 / LOCK-06 contract of the driver.
 * @param  hspi: SPI handle of the device under test.
 * @retval None
 */
void HAL_SPI_MspInit(SPI_HandleTypeDef *hspi)
{
    GPIO_InitTypeDef gpio;

    if (hspi->Instance != TEST_SPI)
    {
        return;
    }

    msp_init_count++;

    if (hspi->State == HAL_SPI_STATE_RESET)
    {
        msp_init_state_reset = 1U;
    }

    if (hspi->Lock != HAL_LOCKED)
    {
        msp_init_lock_free = 1U;
    }

    /* Peripheral clock gate and reset pulse */
    __HAL_SMU_SPI3_CLK_ENABLE();
    __HAL_SMU_SPI3_FORCE_RESET();
    __HAL_SMU_SPI3_RELEASE_RESET();

    /* Port clock gates used by this case */
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&gpio);
    gpio.Size         = sizeof(gpio);
    gpio.Version      = GPIO_INIT_VERSION;
    gpio.Pull         = GPIO_NOPULL;
    gpio.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    gpio.Alternate    = TEST_PIN_AF;

    /* CS0 (driven by the SSR register) */
    HAL_GPIO_PinAFConfig(TEST_CS_PORT, TEST_CS_SOURCE, TEST_PIN_AF);
    gpio.Pin  = TEST_CS_PIN;
    gpio.Mode = GPIO_MODE_AF_PP;
    HAL_GPIO_Init(TEST_CS_PORT, &gpio);

    /* SCK */
    HAL_GPIO_PinAFConfig(TEST_SCK_PORT, TEST_SCK_SOURCE, TEST_PIN_AF);
    gpio.Pin = TEST_SCK_PIN;
    HAL_GPIO_Init(TEST_SCK_PORT, &gpio);

    /* MOSI */
    HAL_GPIO_PinAFConfig(TEST_MOSI_PORT, TEST_MOSI_SOURCE, TEST_PIN_AF);
    gpio.Pin = TEST_MOSI_PIN;
    HAL_GPIO_Init(TEST_MOSI_PORT, &gpio);

    /* MISO: alternate function input, floating */
    HAL_GPIO_PinAFConfig(TEST_MISO_PORT, TEST_MISO_SOURCE, TEST_PIN_AF);
    gpio.Pin  = TEST_MISO_PIN;
    gpio.Mode = GPIO_MODE_INPUT;
    HAL_GPIO_Init(TEST_MISO_PORT, &gpio);
}

/**
 * @brief  MSP de-initialization of the device under test.
 * @note   Strong override of the weak driver callback: it only counts the call,
 *         the pins and the clock gate stay as they are (the other cases of this
 *         suite reuse them).
 * @param  hspi: SPI handle of the device under test.
 * @retval None
 */
void HAL_SPI_MspDeInit(SPI_HandleTypeDef *hspi)
{
    if (hspi->Instance == TEST_SPI)
    {
        msp_deinit_count++;
    }
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the CLINT / CMU / MPU / USART integration tests.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef    SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the same set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls (PMU_CheckState) */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
