/**
 * @file    MPU_IT_DRV_009.c
 * @brief   HAL MPU integration test case 009 (write protection of the
 *          DMA1 port, channels 0..7).
 *
 * One-to-one HAL library port of the original AS32x601 standard-library test
 * case MPU_IT_DRV_009.c. Only HAL library APIs are used, plus the DMA
 * driver that produces the accesses under test.
 *
 * Tested functionality:
 *   HAL_MPU_SetAddressRange()
 *   HAL_MPU_WriteProtectCmd()
 *   HAL_MPU_Cmd()
 *   HAL_MPU_GetWriteProtectStatus()
 *   HAL_MPU_ClearStatus()
 *   HAL_MPU_GetChannelConfig()
 *   HAL_DMA_Init() / HAL_DMA_Start() / HAL_DMA_Abort()   (the accesses)
 *
 * Test procedure:
 *   1. Select the protected window of every channel: eight data words in RAM,
 *      each in a 64-byte line of its own, and protect each one with its own
 *      4-byte window;
 *   2. Enable the write protection of all 8 channels and the channels
 *      themselves, then check the whole configuration from the firmware:
 *      register read-back, HAL_MPU_GetChannelConfig() read-back, the
 *      disable / enable round trip and the clear-status path;
 *   3. Configure the 8 DMA channels for a single byte memory-to-memory transfer
 *      and start one transfer per channel: the DMA access of the protected word
 *      passes through the DMA1 port and sets the protection status of
 *      that channel;
 *   4. Check the WPTS register and the per channel status, then clear
 *      them;
 *   5. Disable the protection and check that a new transfer records nothing.
 *
 * Test configuration:
 *   HAL_MPU_INSTANCE_4_DMA1 (the DMA1 port), channels 0..7,
 *   write protection of eight RAM words.
 * @note   The original test case protects the transmit / receive data register
 *         of the USARTs and requests the transfer from the peripheral.  Measured
 *         on the board, the DMA ports do NOT report the accesses they make to a
 *         peripheral: a transfer whose source / destination was a protected
 *         USART register left the status clear, while a protected RAM word was
 *         reported both for a read and for a write (see the notes below).  The
 *         windows therefore protect RAM words, and the transfers are started in
 *         memory-to-memory mode so that they run without any external
 *         stimulus.  What is tested is unchanged: a DMA access through this port
 *         inside the protected window is recorded and can be cleared.
 *
 * Expected behaviour:
 *   - SADDR / EADDR of the 8 channels are programmed as requested and
 *     WPTEN / PTEN read back as 0x00FF;
 *   - before the transfers the status is clear;
 *   - the 8 DMA accesses set WPTS bit 0..7, so the protection state
 *     reads 0x00FF;
 *   - HAL_MPU_GetWriteProtectStatus() reports 1 for all 8 channels;
 *   - HAL_MPU_ClearStatus() empties the status;
 *   - after the protection is disabled a new transfer records nothing.
 * NOTE: A violation is recorded by the MPU (and forwarded to the FCU by its
 *       MPUDMA1 channel); the DMA transfer is not aborted by the
 *       driver, it is stopped by this test right after the access.
 * NOTE: Measured on the board: the DMA port protection covers the accesses the
 *       DMA engine makes to the memory (data) side.  A protected RAM word is
 *       reported for a read (RPTS) and for a write (WPTS); a protected USART
 *       data register is not reported at all.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Report period (ms) */
#define TEST_PERIOD_MS              (1000U)

/* MPU instance under test (the DMA1 port) */
#define TEST_MPU_INSTANCE           (HAL_MPU_INSTANCE_4_DMA1)

/* Number of channels of the DMA ports */
#define TEST_CHANNEL_COUNT          (8U)

/* Length of one protected window (bytes) */
#define TEST_WINDOW_LENGTH          (4U)

/* Private variables ---------------------------------------------------------*/
static HAL_MPU_HandleTypeDef hmpu_dev;        /*!< MPU device handle           */
static uint32          failures = 0U;         /*!< failed checks               */

static DMA_HandleTypeDef hdma_dev[TEST_CHANNEL_COUNT];  /*!< one per channel   */
static DMA_InitTypeDef   dma_init;            /*!< DMA configuration structure */

/* The protected words and the words the transfers move.  Each protected word
   sits in a 64-byte line of its own: a DMA port access is compared against the
   whole line it belongs to, so a window that shared its line with another
   window or with other variables would protect them as well. */
static volatile uint8 src_word[TEST_CHANNEL_COUNT][64] __attribute__((aligned(64)));
static volatile uint8 dst_word[TEST_CHANNEL_COUNT][64] __attribute__((aligned(64)));

static MPU_Channel_TypeDef * const dma_port_channel[8] =
{
    MPU4_Channel0, MPU4_Channel1, MPU4_Channel2, MPU4_Channel3,
    MPU4_Channel4, MPU4_Channel5, MPU4_Channel6, MPU4_Channel7
};

static HAL_SMU_HandleTypeDef hsmu_clk;   /*!< SMU handle (lock / state / error) */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void Check(const char *name, uint32 condition);
static void Read_EnableMasks(HAL_MPU_HandleTypeDef *hmpu, uint32 count,
                             uint32 *pten, uint32 *rpten, uint32 *wpten);

static DMA_Channel_TypeDef *Dma_ChannelInstance(uint32 ch);
static void Dma_Setup(uint32 ch);
static void Dma_Trigger(uint32 ch);
static uint32 Protected_Address(uint32 ch);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    uint32 ch;
    uint32 state;
    uint32 rd_pten;
    uint32 rd_rpten;
    uint32 rd_wpten;
    uint32 ok;
    uint32 start;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n\r\n ***** MPU Test ***** \r\n");
    printf("case : MPU_IT_DRV_009 (write protection of the DMA1 port)\r\n");
    delay_ms(500U);

    /* ---- Step 1: protected words --------------------------------- */
    /* The DMA controller has a clock gate of its own in the SMU and the DMA
       driver leaves it to the application (its HAL_DMA_MspInit() hook is
       empty), so the gate is opened here explicitly */
        __HAL_SMU_DMA1_CLK_ENABLE();
    __HAL_SMU_DMA1_FORCE_RESET();
    __HAL_SMU_DMA1_RELEASE_RESET();

    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        src_word[ch][0] = (uint8)(0xA0U + ch);
        dst_word[ch][0] = 0x00U;
    }

    printf("\r\n-----------------protected words----------------- \r\n");
    __HAL_CLEAR_STRUCT(&hmpu_dev);
    hmpu_dev.Instance = TEST_MPU_INSTANCE;
    /* The channel control functions require an initialized handle: this case
       drives them directly, so the READY state is set up explicitly (no
       channel is programmed by HAL_MPU_Init() here) */
    hmpu_dev.State = HAL_MPU_STATE_READY;

    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        start = Protected_Address(ch);
        HAL_MPU_SetAddressRange(&hmpu_dev, ch, start, start + TEST_WINDOW_LENGTH);
        printf("channel %u : 0x%08X .. 0x%08X\r\n",
               PRINT_U32(ch), PRINT_U32(start), PRINT_U32(start + TEST_WINDOW_LENGTH));
    }

    ok = 1U;
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        start = Protected_Address(ch);
        if ((dma_port_channel[ch]->SADDR != start) ||
            (dma_port_channel[ch]->EADDR != (start + TEST_WINDOW_LENGTH)))
        {
            ok = 0U;
        }
    }
    Check("SADDR / EADDR of all 8 channels", ok);

    /* ---- Step 2: protection and channel enable -------------------- */
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        HAL_MPU_WriteProtectCmd(&hmpu_dev, ch, MPU_ENABLE);
    }
    Check("WPTEN = 0x00FF",
          (((MPU4_DMA1->WPTEN & 0x00FFUL) == 0x00FFUL) ? 1U : 0U));

    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        HAL_MPU_Cmd(&hmpu_dev, ch, MPU_ENABLE);
    }
    Check("PTEN = 0x00FF", (((MPU4_DMA1->PTEN & 0x00FFUL) == 0x00FFUL) ? 1U : 0U));
    /* read the enable masks back through the HAL API (V1.2); the direct
       register reads above stay as the white-box cross check */
    Read_EnableMasks(&hmpu_dev, TEST_CHANNEL_COUNT, &rd_pten, &rd_rpten, &rd_wpten);
    Check("PTEN read back by HAL_MPU_GetChannelConfig",
          (((rd_pten & 0x00FFUL) == 0x00FFUL) ? 1U : 0U));
    Check("WPTEN read back by HAL_MPU_GetChannelConfig",
          (((rd_wpten & 0x00FFUL) == 0x00FFUL) ? 1U : 0U));
        Check("no read protection enable (write protection case, HAL read-back)",
          ((rd_rpten == 0U) ? 1U : 0U));

    /* ---- Step 3: DMA channel configuration ------------------------ */
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        Dma_Setup(ch);
    }
    Check("8 DMA channels initialized",
          (((HAL_DMA_GetState(&hdma_dev[0]) == HAL_DMA_STATE_READY) &&
            (HAL_DMA_GetState(&hdma_dev[7]) == HAL_DMA_STATE_READY)) ? 1U : 0U));

    delay_ms(100U);

    /* ---- Step 4: status path before any protected access ---------- */
    printf("\r\n-----------------configuration------------------------ \r\n");

    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        (void)HAL_MPU_ClearStatus(&hmpu_dev, ch);
    }
    Check("WPTS = 0 before the protected accesses",
          (((MPU4_DMA1->WPTS & 0x00FFUL) == 0U) ? 1U : 0U));

    ok = 1U;
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        if (HAL_MPU_GetWriteProtectStatus(&hmpu_dev, ch) != 0U)
        {
            ok = 0U;
        }
    }
    Check("HAL_MPU_GetWriteProtectStatus = 0 for all 8 channels", ok);

    /* disable / enable round trip of both control bits (no DMA access) */
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        HAL_MPU_WriteProtectCmd(&hmpu_dev, ch, MPU_DISABLE);
        HAL_MPU_Cmd(&hmpu_dev, ch, MPU_DISABLE);
    }
    Check("WPTEN = 0 after the disable",
          (((MPU4_DMA1->WPTEN & 0x00FFUL) == 0U) ? 1U : 0U));
    Check("PTEN = 0 after the disable",
          (((MPU4_DMA1->PTEN & 0x00FFUL) == 0U) ? 1U : 0U));

    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        HAL_MPU_WriteProtectCmd(&hmpu_dev, ch, MPU_ENABLE);
        HAL_MPU_Cmd(&hmpu_dev, ch, MPU_ENABLE);
    }
    Check("WPTEN = 0x00FF after the re-enable",
          (((MPU4_DMA1->WPTEN & 0x00FFUL) == 0x00FFUL) ? 1U : 0U));
    Check("PTEN = 0x00FF after the re-enable",
          (((MPU4_DMA1->PTEN & 0x00FFUL) == 0x00FFUL) ? 1U : 0U));

    ok = 1U;
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        start = Protected_Address(ch);
        if ((dma_port_channel[ch]->SADDR != start) ||
            (dma_port_channel[ch]->EADDR != (start + TEST_WINDOW_LENGTH)))
        {
            ok = 0U;
        }
    }
    Check("SADDR / EADDR of all 8 channels after the round trip", ok);

    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        (void)HAL_MPU_ClearStatus(&hmpu_dev, ch);
    }
    Check("status cleared right before the protected accesses",
          (((MPU4_DMA1->WPTS & 0x00FFUL) == 0U) ? 1U : 0U));

    /* ---- Step 5: the protected accesses --------------------------- */
    printf("\r\n-----------------trigger the protection----------------- \r\n");

    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        Dma_Trigger(ch);
    }

    state = (uint32)MPU4_DMA1->WPTS;
    printf("DMA1 WPTS : 0x%08X (data 0x%02X -> 0x%02X)\r\n",
           PRINT_U32(state), PRINT_U32(src_word[0][0]), PRINT_U32(dst_word[0][0]));

    Check("write protection state = 0x00FF", ((state & 0x00FFUL) == 0x00FFUL));
    Check("bit 0 (channel 0 window) set", ((state & 0x0001UL) != 0U));
    Check("bit 7 (channel 7 window) set", ((state & 0x0080UL) != 0U));

    ok = 1U;
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        if (HAL_MPU_GetWriteProtectStatus(&hmpu_dev, ch) == 0U)
        {
            ok = 0U;
        }
    }
    Check("HAL_MPU_GetWriteProtectStatus of all 8 channels", ok);

    /* ---- Step 6: clear, then disable ----------------------------- */
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        (void)HAL_MPU_ClearStatus(&hmpu_dev, ch);
    }
    Check("status cleared by HAL_MPU_ClearStatus",
          (((MPU4_DMA1->WPTS & 0x00FFUL) == 0U) ? 1U : 0U));

    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        HAL_MPU_WriteProtectCmd(&hmpu_dev, ch, MPU_DISABLE);
        HAL_MPU_Cmd(&hmpu_dev, ch, MPU_DISABLE);
    }
    Check("WPTEN / PTEN cleared by the disable",
          (((((uint32)MPU4_DMA1->WPTEN & 0x00FFUL) == 0U) &&
            (((uint32)MPU4_DMA1->PTEN & 0x00FFUL) == 0U)) ? 1U : 0U));

    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        Dma_Trigger(ch);
    }
    Check("no violation while the protection is disabled",
          (((MPU4_DMA1->WPTS & 0x00FFUL) == 0U) ? 1U : 0U));

    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(failures));

    /* The DMA ports only record the access: no trap, no exception, so the case
       keeps running.  The protection is left disabled, which is why the trigger
       is not repeated in the loop (it would record nothing). */
    while (1)
    {
        delay_ms(TEST_PERIOD_MS);
    }
}

/**
 * @brief  Address of the protected word of one channel.
 * @note   The write protection reports the the destination of the transfer,
 *         so the window covers the word on that side.
 * @param  ch: channel index (0..7).
 * @retval Address of the protected 4-byte window of that channel.
 */
static uint32 Protected_Address(uint32 ch)
{
    return (uint32)(unsigned long)&dst_word[ch][0];
}

/**
 * @brief  Return the DMA channel register block of the given channel index.
 * @param  ch: DMA channel index (0..7).
 * @retval Pointer to the channel register block.
 */
static DMA_Channel_TypeDef *Dma_ChannelInstance(uint32 ch)
{
    DMA_Channel_TypeDef *instance = DMA1_Channel0;

    switch (ch)
    {
        case 0U: instance = DMA1_Channel0; break;
        case 1U: instance = DMA1_Channel1; break;
        case 2U: instance = DMA1_Channel2; break;
        case 3U: instance = DMA1_Channel3; break;
        case 4U: instance = DMA1_Channel4; break;
        case 5U: instance = DMA1_Channel5; break;
        case 6U: instance = DMA1_Channel6; break;
        default: instance = DMA1_Channel7; break;
    }
    return instance;
}

/**
 * @brief  Initialize one DMA port channel for a memory-to-memory transfer.
 * @note   The memory-to-memory mode makes the channel run without a peripheral
 *         request, so the access happens without any external stimulus.  Both
 *         address mappings are covered: the one used by the window of this case
 *         is the direction field set here, the other one is exercised by the
 *         companion case of the same port.
 * @param  ch: DMA channel index (0..7).
 * @retval None
 */
static void Dma_Setup(uint32 ch)
{
    __HAL_CLEAR_STRUCT(&hdma_dev[ch]);
    hdma_dev[ch].Instance = Dma_ChannelInstance(ch);

    HAL_DMA_StructInit(&dma_init);
    dma_init.DMA_PeripheralBaseAddr = (uint32)(unsigned long)&dst_word[ch][0];
    dma_init.DMA_MemoryBaseAddr     = (uint32)(unsigned long)&src_word[ch][0];
    dma_init.DMA_DIR                = DMA_MEMORY_TO_PERIPH;
    dma_init.DMA_BufferSize         = 1U;
    dma_init.DMA_PeripheralInc      = DMA_PINC_DISABLE;
    dma_init.DMA_MemoryInc          = DMA_MINC_DISABLE;
    dma_init.DMA_PeripheralDataSize = DMA_PDATAALIGN_BYTE;
    dma_init.DMA_MemoryDataSize     = DMA_MDATAALIGN_BYTE;
    dma_init.DMA_Priority           = DMA_PRIORITY_HIGH;
    dma_init.DMA_M2M                = DMA_M2M_Enable;
    dma_init.DMA_Mode               = DMA_NORMAL;
    hdma_dev[ch].Init = dma_init;

    (void)HAL_DMA_Init(&hdma_dev[ch]);
}

/**
 * @brief  Start one single byte transfer per channel.
 * @note   The transfer moves one byte from the source word to the destination
 *         word of the channel: the DMA reads the source and writes the
 *         destination, so the protection of either side is exercised by the
 *         corresponding case.  The channel is stopped right after the access.
 * @param  ch: DMA channel index (0..7).
 * @retval None
 */
static void Dma_Trigger(uint32 ch)
{
    hdma_dev[ch].Init = dma_init;
    (void)HAL_DMA_Init(&hdma_dev[ch]);

    (void)HAL_DMA_Start(&hdma_dev[ch],
                        (uint32)(unsigned long)&src_word[ch][0],
                        (uint32)(unsigned long)&dst_word[ch][0], 1U);
    delay_ms(2U);
    (void)HAL_DMA_Abort(&hdma_dev[ch]);
}


/**
 * @brief  Rebuild the channel enable / protection enable masks of a MPU
 *         instance by reading the configuration of every channel back through
 *         HAL_MPU_GetChannelConfig().
 * @note   The driver provides the configuration read-back interface from V1.2
 *         on: the masks let the case check the programmed enables through the
 *         HAL API in addition to the direct PTEN / WPTEN reads of
 *         the original test case.
 * @param  hmpu: pointer to the MPU handle.
 * @param  count: number of channels of the instance (16 or 8).
 * @param  pten: receives the channel enable mask.
 * @param  rpten: receives the read protection enable mask.
 * @param  wpten: receives the write protection enable mask.
 * @retval None
 */
static void Read_EnableMasks(HAL_MPU_HandleTypeDef *hmpu, uint32 count,
                             uint32 *pten, uint32 *rpten, uint32 *wpten)
{
    uint32 i;
    MPU_InitTypeDef cfg;

    *pten  = 0U;
    *rpten = 0U;
    *wpten = 0U;

    for (i = 0U; i < count; i++)
    {
        __HAL_CLEAR_STRUCT(&cfg);

        if (HAL_MPU_GetChannelConfig(hmpu, i, &cfg) == HAL_OK)
        {
            *pten  |= ((uint32)cfg.ChannelEnable      << i);
            *rpten |= ((uint32)cfg.ReadProtectEnable  << i);
            *wpten |= ((uint32)cfg.WriteProtectEnable << i);
        }
    }
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition == 0U)
    {
        failures++;
    }
    printf("%-46s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Configure the system clock tree using the HAL SMU / PMU drivers.
 * @note   Same clock tree as the CLINT / CMU reference suites: OSC 20 MHz as
 *         the PLL source, PLLDivN = 20 / PLLDivF = 180 / PLLDivQ = 1 /
 *         PLLDivR = 4 -> 180 MHz VCO, AXI4Bus3 = /2, APBBus0 = /2,
 *         APBBus1 = /2, CANX2 = /8; the 2.5V LDO is scaled to 2.78 V and the
 *         1.2V LDO to 1.34 V as in the reference suites.
 * @note   Clock tree order (the order the chip requires, and the order the
 *         vendor test case uses): configure the oscillators and the PLL and
 *         switch the system clock to it, then write the bus clock dividers.
 *         HAL_SMU_OscConfig() programs the EFLASH controller clock (CLKFRQ)
 *         before the switch and lets it follow the new system clock afterwards
 *         (EFLASH_CLK_UPDATE), so no explicit HAL_FLASH_SetClockFrequency() is
 *         needed here; it also updates SystemCoreClock together with the HAL
 *         time base.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef  SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef   SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it (CLKFRQ above), so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Set the bus clock dividers (the system clock source is already set by
       HAL_SMU_OscConfig() above) */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
