# QSPI 引脚参考

此处仅整理 AS32x601 LQFP144 引脚资料，当前未收录该外设的独立测试用例。接口以 [HAL 头文件](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_qspi.h) 为准。

## 实例与可选引脚

| 信号 | 引脚 | LQFP144 脚号 | 功能 | HAL 配置 |
| --- | --- | --- | --- | --- |
| QSPI_CSN | PA8 | 40 | 功能0 | GPIO_AF_QSPI（0x01） |
| QSPI_DIO0 | PA10 | 38 | 功能0 | GPIO_AF_QSPI（0x01） |
| QSPI_DIO1 | PA11 | 37 | 功能0 | GPIO_AF_QSPI（0x01） |
| QSPI_DIO2 | PA12 | 36 | 功能0 | GPIO_AF_QSPI（0x01） |
| QSPI_DIO3 | PA13 | 35 | 功能0 | GPIO_AF_QSPI（0x01） |
| QSPI_SCK | PA9 | 39 | 功能0 | GPIO_AF_QSPI（0x01） |

PA8～PA13 具备 QSPI 默认功能，重新复用前需核对启动方式和现有占用。
