/**
 * @file    TIM_IT_DRV_006.c
 * @brief   external clock mode 2 (ETR as the counter clock) with the ADC0 regular group polled
 *
 * HAL library port of the original AS32x601 standard-library test case
 * TIMER_IT_DRV_006.c, which drives TIM0 + ADC0. Only HAL library APIs are used; the register
 * read backs document what was programmed.
 *
 * Tested functionality:
 *   TIM_TimeBaseInit()          -> HAL_TIM_Base_StructInit() / HAL_TIM_Base_Init()
 *   TIM_ETRClockMode2Config()   -> HAL_TIM_ConfigClockSource(TIM_CLOCKSOURCE_ETRMODE2)
 *   TIM_Cmd(ENABLE)             -> HAL_TIM_Base_Start()
 *   TIM_GetCounter()            -> HAL_TIM_GetCounter()
 *   ADC_Init()                  -> HAL_ADC_Init()
 *   ADC_ConfigAMO()             -> HAL_ADC_AMOStructInit() / HAL_ADC_ConfigAnalogMonitor()
 *   ADC_ConfigChannel()         -> HAL_ADC_ConfigChannel()
 *   ADC_SoftRegularConvert()    -> HAL_ADC_Start()
 *   ADC_GetFlagStatus()         -> HAL_ADC_GetFlagStatus()
 *   ADC_ClearFlag()             -> HAL_ADC_ClearFlag()
 *   ADC_GetSeqResult()          -> HAL_ADC_GetValue()
 *
 * Test procedure:
 *   configure the time base of TIM0 (ARR = 100000-1, PSC = 0) and select the ETR input as the
 *   counter clock with the external clock mode 2 (the ETR input stage is programmed by the same
 *   call);
 *   start the counter and configure the ADC0 regular group on channel 14 (PC0) with the analog
 *   monitor enabled between 1500 and 3500 counts;
 *   trigger the regular group from software and read the result in the main loop while printing
 *   the TIM0 counter;
 *   move the monitor window out of range and back four times so that ADC_AMO_OUT produces four
 *   rising edges, then check that the counter advanced by exactly four counts and restore the
 *   documented window.
 *
 * Expected behaviour:
 *   SMCR.ECE is set (external clock mode 2) and the ETR input stage reads ETPS = DIV1 with ETF = 0;
 *   TIMx_AF1.ETRSEL reads 0, i.e. the ETR0 source is the analog monitor output of ADC0;
 *   the ADC0 regular group reads its programmed trigger (internal) and channel configuration back;
 *   the analog monitor reads its programmed window (upper 3500 / lower 1500) back;
 *   one software triggered conversion finishes, its result is inside the 12-bit range and the
 *   analog monitor flag can be cleared;
 *   every ADC0.AMO rising edge advances the counter by exactly one count (step 7), and the window
 *   reads 1500..3500 again afterwards;
 *   every check prints [PASS] and "summary : failures = 0".
 *
 * Note:
 *   The ETR inputs of the advanced timers are internal signals on this device, not pins:
 *   TIMx_AF1.ETRSEL (offset 0x5C, reset value 0) selects 0 = ETR0 = ADC0.AMO and
 *   1 = ETR1 = ADC1.AMO (chip manual table 24.1), so the counter of TIM0 is clocked by the
 *   analog monitor output of ADC0. ADC_AMO_OUT rises to 1 while the monitored result is outside
 *   the window (above AMOHR or below AMOLR) and falls back to 0 as soon as a monitored result is
 *   inside it again, so one out-of-window conversion produces one rising edge on the ETR path.
 *
 *   The window of this case is 1500..3500 while the PC0 input of this board reads about
 *   0.57..0.66 V (roughly 710..815 counts), i.e. always below the lower threshold. The monitor
 *   output therefore stays at 1 after the first conversion and, with no second rising edge, the
 *   counter stops at 1 instead of counting. That is the correct result for this configuration
 *   and not a defect of the driver: step 7 below moves the window out of and back into range to
 *   generate rising edges and proves that every edge advances the counter, and the main loop
 *   keeps doing the same so that the printed counter keeps increasing.
 *
 *   The ADC0 input of this case is PC0 (ADC0 channel 14); PC14 / PC15 (ADC0 channel 1 / 2) are
 *   not routed on this board.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
/* Console: USART0 on GPIOD pin 8 (TX) / pin 9 (RX), 115200 8N1 */
#define TEST_BAUDRATE                   (115200U)

#define TEST_ARR                        (100000U - 1U)

#define TEST_ADC_CHANNEL                (ADC_CH_14)
#define TEST_ADC_SAMPLE_TIME            (ADC_SPT_CLK_640)
#define TEST_ADC_AMO_HIGH               (3500U)
#define TEST_ADC_AMO_LOW                (1500U)
#define TEST_ADC_TIMEOUT_MS             (10U)

/* Number of ADC0.AMO rising edges generated in step 7; PSC = 0, so every edge
   has to advance the counter by exactly one count. */
#define TEST_ETR_EDGES                  (4U)

/* Thresholds that force the monitor out of / back into its window: the sample
   of PC0 is a small positive count, so 0..0 is always exceeded and 0..4095 is
   always inside. */
#define TEST_AMO_FORCE_OUT_HIGH         (0U)
#define TEST_AMO_FORCE_OUT_LOW          (0U)
#define TEST_AMO_FORCE_IN_HIGH          (4095U)
#define TEST_AMO_FORCE_IN_LOW           (0U)


/* Private variables -------------------------------------------------------*/
static HAL_TIM_HandleTypeDef htim_dev;          /*!< timer under test          */
static HAL_SMU_HandleTypeDef hsmu_clk;          /*!< SMU handle (clock tree)   */
static ADC_HandleTypeDef     hadc_dev;          /*!< ADC under test            */
static volatile uint32 check_failures = 0U;     /*!< failed check counter      */

static uint32 last_adc_value = 0U;              /*!< last converted sample     */


/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure one GPIO pin as an analog input.
 * @param  port: GPIO port
 * @param  pin: pin mask
 * @retval None
 */
static void Gpio_AnalogConfig(GPIO_TypeDef *port, uint32 pin)
{
    GPIO_InitTypeDef gpio_init;

    __HAL_CLEAR_STRUCT(&gpio_init);
    gpio_init.Size         = sizeof(GPIO_InitTypeDef);
    gpio_init.Version      = GPIO_INIT_VERSION;
    gpio_init.Pin          = pin;
    gpio_init.Mode         = GPIO_MODE_ANALOG;
    gpio_init.Pull         = GPIO_NOPULL;
    gpio_init.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;
    gpio_init.Alternate    = GPIO_AF_Pin_x;
    HAL_GPIO_Init(port, &gpio_init);
}

/**
 * @brief  Configure the time base of the timer under test.
 * @note   The helper keeps the Size / Version meta fields through
 *         HAL_TIM_Base_StructInit(), which the initialization interface
 *         validates at run time.
 * @param  instance: TIM0..TIM7
 * @param  arr: auto reload value
 * @param  psc: prescaler value
 * @param  rcr: repetition counter (advanced timers only)
 * @retval HAL status of HAL_TIM_Base_Init()
 */
static HAL_StatusTypeDef TimeBase_Config(TIM_TypeDef *instance, uint32 arr, uint32 psc, uint32 rcr)
{
    TIM_Base_InitTypeDef base_init;

    __HAL_CLEAR_STRUCT(&htim_dev);
    htim_dev.Instance = instance;

    HAL_TIM_Base_StructInit(&base_init);
    base_init.CounterMode       = TIM_COUNTERMODE_UP;
    base_init.ClockDivision     = TIM_CKD_DIV1;
    base_init.Period            = arr;
    base_init.Prescaler         = psc;
    base_init.RepetitionCounter = rcr;
    htim_dev.Init               = base_init;

    return HAL_TIM_Base_Init(&htim_dev);
}

/**
 * @brief  Enable the clock of a timer instance and release its reset.
 * @note   The default MSP callbacks of this module are empty, so the suite
 *         performs the gate and reset handling itself; every MSP callback is
 *         routed to this helper.
 * @param  instance: TIM0..TIM7
 * @retval None
 */
static void Tim_ClockEnable(TIM_TypeDef *instance)
{
    if (instance == TIM0)
    {
        __HAL_SMU_HTIM0_CLK_ENABLE();
        __HAL_SMU_HTIM0_FORCE_RESET();
        __HAL_SMU_HTIM0_RELEASE_RESET();
    }
    else if (instance == TIM1)
    {
        __HAL_SMU_HTIM1_CLK_ENABLE();
        __HAL_SMU_HTIM1_FORCE_RESET();
        __HAL_SMU_HTIM1_RELEASE_RESET();
    }
    else if (instance == TIM2)
    {
        __HAL_SMU_HTIM2_CLK_ENABLE();
        __HAL_SMU_HTIM2_FORCE_RESET();
        __HAL_SMU_HTIM2_RELEASE_RESET();
    }
    else if (instance == TIM3)
    {
        __HAL_SMU_TIM3_CLK_ENABLE();
        __HAL_SMU_TIM3_FORCE_RESET();
        __HAL_SMU_TIM3_RELEASE_RESET();
    }
    else if (instance == TIM4)
    {
        __HAL_SMU_TIM4_CLK_ENABLE();
        __HAL_SMU_TIM4_FORCE_RESET();
        __HAL_SMU_TIM4_RELEASE_RESET();
    }
    else if (instance == TIM5)
    {
        __HAL_SMU_HTIM5_CLK_ENABLE();
        __HAL_SMU_HTIM5_FORCE_RESET();
        __HAL_SMU_HTIM5_RELEASE_RESET();
    }
    else if (instance == TIM6)
    {
        __HAL_SMU_TIM6_CLK_ENABLE();
        __HAL_SMU_TIM6_FORCE_RESET();
        __HAL_SMU_TIM6_RELEASE_RESET();
    }
    else
    {
        __HAL_SMU_TIM7_CLK_ENABLE();
        __HAL_SMU_TIM7_FORCE_RESET();
        __HAL_SMU_TIM7_RELEASE_RESET();
    }
}

/* MSP callbacks: the timer clock and reset of the instance under test */
void HAL_TIM_Base_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_OC_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_PWM_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_IC_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_OnePulse_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_Encoder_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

/**
 * @brief  Enable the clock of the ADC instance and release its reset.
 * @note   The default MSP callback of the ADC module is empty, so this case
 *         provides it (the ADC0 gate and reset live in SMU->ALB1CFGR).
 * @param  hadc: ADC handle
 * @retval None
 */
void HAL_ADC_MspInit(ADC_HandleTypeDef *hadc)
{
    if (hadc->Instance == ADC0)
    {
        __HAL_SMU_ADC0_CLK_ENABLE();
        __HAL_SMU_ADC0_FORCE_RESET();
        __HAL_SMU_ADC0_RELEASE_RESET();
    }
}

/**
 * @brief  De-initialize the ADC MSP (clock gate off, reset held).
 * @param  hadc: ADC handle
 * @retval None
 */
void HAL_ADC_MspDeInit(ADC_HandleTypeDef *hadc)
{
    if (hadc->Instance == ADC0)
    {
        __HAL_SMU_ADC0_FORCE_RESET();
        __HAL_SMU_ADC0_CLK_DISABLE();
    }
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the other TIM integration tests: PLL VCO 180 MHz,
 *         AXI4Bus3 / APBBus0 / APBBus1 divided by 2, CANX2 by 8 -> core 180 MHz,
 *         AXILite4 Bus 1 and Bus 2 = 45 MHz (TIM0, TIM1), APBBus0 and APBBus1 =
 *         22.5 MHz (TIM2 / TIM3 / TIM4 and TIM5 / TIM6 / TIM7 - TIM2 and TIM5
 *         are advanced timers on the APB).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef    SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks used by this suite (GPIOC carries the ADC input on PC0) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Clock tree order: write the dividers while the system clock is still
       FIRC, then configure the PLL and switch to it (that call programs the
       flash controller clock before the switch and updates SystemCoreClock
       afterwards). */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Configure the ADC0 regular group and its analog monitor.
 * @note   Mirrors the reference case: channel 1 on PC14, 12-bit right aligned
 *         unsigned data, input clock divided by 4, software triggered regular
 *         group of one rank, analog monitor window 1500..3500 on the same
 *         channel without the monitor interrupt (the flag is polled).
 * @param  None
 * @retval HAL status of HAL_ADC_Init()
 */
static HAL_StatusTypeDef Adc_Config(void)
{
    ADC_InitTypeDef        adc_init;
    ADC_ChannelConfTypeDef adc_channel;
    ADC_AmoConfTypeDef     adc_amo;


    __HAL_CLEAR_STRUCT(&hadc_dev);
    hadc_dev.Instance = ADC0;

    HAL_ADC_StructInit(&adc_init);
    adc_init.ADC_ClockDivide              = ADC_CLK_DIVIDE_4;
    adc_init.ADC_Resolution               = ADC_RESOLUTION_12BIT;
    adc_init.ADC_Alignment                = ADC_DATA_ALIGN_RIGHT;
    adc_init.ADC_Symbol                   = ADC_DATA_SELDO_UNSIGNED;
    adc_init.ADC_RegularTrigger           = ADC_TRIGGER_INTERNAL;
    adc_init.ADC_InjectTrigger            = ADC_TRIGGER_INTERNAL;
    adc_init.ADC_RegularEnable            = ENABLE;
    adc_init.ADC_InjectEnable             = DISABLE;
    adc_init.ADC_DmaEnable                = DISABLE;
    adc_init.ADC_ScanModeEn               = ENABLE;
    adc_init.ADC_ContinuousModeEn         = DISABLE;
    adc_init.ADC_RegularDiscontinuousModeEn = DISABLE;
    adc_init.ADC_InjectDiscontinuousModeEn  = DISABLE;
    adc_init.ADC_IntervalModeEn           = DISABLE;
    adc_init.ADC_InjectAutoModeEn         = DISABLE;
    adc_init.ADC_RegularSequenceLength    = 1U;
    adc_init.ADC_InjectSequenceLength     = 1U;
    adc_init.ADC_PowerEn                  = ENABLE;
    adc_init.ADC_PowerRegain              = ENABLE;
    hadc_dev.Init                         = adc_init;

    if (HAL_ADC_Init(&hadc_dev) != HAL_OK)
    {
        return HAL_ERROR;
    }

    HAL_ADC_AMOStructInit(&adc_amo);
    adc_amo.ADC_AmoInterruptEn    = DISABLE;
    adc_amo.ADC_AmoRegularEn      = ENABLE;
    adc_amo.ADC_AmoInjectEn       = DISABLE;
    adc_amo.ADC_AmoSingleModeEn   = ENABLE;
    adc_amo.ADC_AmoSingleChannel  = TEST_ADC_CHANNEL;
    adc_amo.ADC_AmoUpThreshold    = (uint16)TEST_ADC_AMO_HIGH;
    adc_amo.ADC_AmoLowThreshold   = (uint16)TEST_ADC_AMO_LOW;
    (void)HAL_ADC_ConfigAnalogMonitor(&hadc_dev, &adc_amo);

    HAL_ADC_ChannelStructInit(&adc_channel);
    adc_channel.ADC_Channel      = TEST_ADC_CHANNEL;
    adc_channel.ADC_SampleTime   = TEST_ADC_SAMPLE_TIME;
    adc_channel.ADC_InterruptEn  = DISABLE;
    adc_channel.Rank             = ADC_RSEQ_0;
    (void)HAL_ADC_ConfigChannel(&hadc_dev, &adc_channel);

    return HAL_OK;
}

/**
 * @brief  Program the analog monitor window and run one conversion.
 * @note   Used by the ETR edge generation: the monitor output follows the
 *         window, so moving the window out of and back into range makes the
 *         ETR input of TIM0 rise and fall.
 * @param  high: upper threshold
 * @param  low: lower threshold
 * @retval the converted sample
 */
static uint32 Adc_AmoConvert(uint16 high, uint16 low)
{
    ADC_AmoConfTypeDef amo;

    (void)HAL_ADC_GetAnalogMonitorConfig(&hadc_dev, &amo);
    amo.ADC_AmoUpThreshold  = high;
    amo.ADC_AmoLowThreshold = low;
    (void)HAL_ADC_ConfigAnalogMonitor(&hadc_dev, &amo);

    (void)HAL_ADC_Start(&hadc_dev);
    (void)HAL_ADC_PollForConversion(&hadc_dev, TEST_ADC_TIMEOUT_MS);

    return HAL_ADC_GetValue(&hadc_dev);
}

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    TIM_ClockConfigTypeDef clock_cfg;
    ADC_AmoConfTypeDef     adc_amo;
    ADC_ChannelConfTypeDef adc_channel;
    HAL_StatusTypeDef      status;
    uint32                 before;
    uint32                 after;
    uint32                 i;
    uint32                 amo_flag;

    HAL_Init();
    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== TIM_IT_DRV_006 : external clock mode 2 (ETR) + ADC0 polling ===\r\n");
    Gpio_AnalogConfig(GPIOC, GPIO_PIN_0);

    /* Step 1: the time base of TIM0 */
    status = TimeBase_Config(TIM0, TEST_ARR, 0U, 0U);
    Check("HAL_TIM_Base_Init() returns HAL_OK", (status == HAL_OK));
    Check("ARR holds 100000-1", (TIM0->ARR == TEST_ARR));

    /* Step 2: the ETR input as the counter clock (external clock mode 2) */
    __HAL_CLEAR_STRUCT(&clock_cfg);
    clock_cfg.ClockSource    = TIM_CLOCKSOURCE_ETRMODE2;
    clock_cfg.ClockPolarity  = TIM_ETRPOLARITY_NONINVERTED;
    clock_cfg.ClockPrescaler = TIM_CLOCKPRESCALER_DIV1;
    clock_cfg.ClockFilter    = 0U;
    status = HAL_TIM_ConfigClockSource(&htim_dev, &clock_cfg);
    Check("HAL_TIM_ConfigClockSource(ETRMODE2) returns HAL_OK", (status == HAL_OK));
    Check("SMCR.ECE is set (external clock mode 2)", ((TIM0->SMCR & TIM_SMCR_ECE) != 0U));
    Check("SMCR.ETPS = DIV1", ((TIM0->SMCR & TIM_SMCR_ETPS) == TIM_CLOCKPRESCALER_DIV1));
    Check("SMCR.ETF = 0", ((TIM0->SMCR & TIM_SMCR_ETF) == 0U));
    Check("SMCR.ETP = non inverted", ((TIM0->SMCR & TIM_SMCR_ETP) == TIM_ETRPOLARITY_NONINVERTED));
    /* The ETR source is not a pin: ETRSEL picks the internal trigger and the
       reset value 0 (ETR0 = ADC0.AMO) is what this case relies on, so it is
       asserted instead of being assumed. */
    Check("TIM0->AF1.ETRSEL = 0 (ETR0 = ADC0.AMO)",
          ((TIM0->AF1 & TIM_AF1_ETRSEL_Msk) == 0U));

    /* Step 3: start the counter */
    Check("HAL_TIM_Base_Start() returns HAL_OK", (HAL_TIM_Base_Start(&htim_dev) == HAL_OK));
    Check("CR1.CEN is set", ((TIM0->CR1 & TIM_CR1_CEN) != 0U));

    /* Step 4: the ADC0 regular group */
    Check("HAL_ADC_Init() returns HAL_OK", (Adc_Config() == HAL_OK));
    Check("CTRL0.TRIGSRC reads the internal trigger",
          (((ADC0->CTRL0 & ADC_CTRL0_TRIGSRC) >> ADC_CTRL0_TRIGSRC_Pos) == ADC_TRIGGER_INTERNAL));
    /* The read-back interface takes the rank from the Rank field of the
       structure, so the rank has to be preset before the call; the structure
       used inside Adc_Config() is a local copy and is not visible here. */
    __HAL_CLEAR_STRUCT(&adc_channel);
    adc_channel.Rank = ADC_RSEQ_0;
    Check("HAL_ADC_GetChannelConfig() returns HAL_OK",
          (HAL_ADC_GetChannelConfig(&hadc_dev, &adc_channel) == HAL_OK));
    Check("the channel reads channel 14 back", (adc_channel.ADC_Channel == TEST_ADC_CHANNEL));
    Check("the sample time reads 640 clocks back", (adc_channel.ADC_SampleTime == TEST_ADC_SAMPLE_TIME));

    /* Step 5: the analog monitor window */
    Check("HAL_ADC_GetAnalogMonitorConfig() returns HAL_OK",
          (HAL_ADC_GetAnalogMonitorConfig(&hadc_dev, &adc_amo) == HAL_OK));
    Check("the monitor upper threshold reads 3500 back", (adc_amo.ADC_AmoUpThreshold == TEST_ADC_AMO_HIGH));
    Check("the monitor lower threshold reads 1500 back", (adc_amo.ADC_AmoLowThreshold == TEST_ADC_AMO_LOW));
    Check("the monitor is enabled for the regular group", (adc_amo.ADC_AmoRegularEn == ENABLE));

    /* Step 6: one software triggered conversion */
    Check("HAL_ADC_Start() returns HAL_OK", (HAL_ADC_Start(&hadc_dev) == HAL_OK));
    status = HAL_ADC_PollForConversion(&hadc_dev, TEST_ADC_TIMEOUT_MS);
    Check("HAL_ADC_PollForConversion() returns HAL_OK", (status == HAL_OK));
    last_adc_value = HAL_ADC_GetValue(&hadc_dev);
    Check("the sample is inside the 12-bit range", (last_adc_value <= 0x0FFFU));
    Check("HAL_ADC_ClearFlag(AMO) returns HAL_OK",
          (HAL_ADC_ClearFlag(&hadc_dev, ADC_FLAG_AMO, ADC_RSEQ_0) == HAL_OK));
    Check("the analog monitor flag reads RESET after the clear",
          (HAL_ADC_GetFlagStatus(&hadc_dev, ADC_FLAG_AMO, ADC_RSEQ_0) == RESET));

    /* Step 7: the analog monitor output really is the clock of the counter.
     * Moving the window out of range makes ADC_AMO_OUT rise, moving it back
     * makes it fall again, so every loop of the for statement produces exactly
     * one rising edge; with PSC = 0 the counter has to advance by one count per
     * edge. This is the check that the ETR path itself works, which the pure
     * register read backs above cannot show. */
    before = HAL_TIM_GetCounter(&htim_dev);
    for (i = 0U; i < TEST_ETR_EDGES; i++)
    {
        (void)Adc_AmoConvert((uint16)TEST_AMO_FORCE_OUT_HIGH, (uint16)TEST_AMO_FORCE_OUT_LOW);
        (void)HAL_ADC_ClearFlag(&hadc_dev, ADC_FLAG_AMO, ADC_RSEQ_0);
        (void)Adc_AmoConvert((uint16)TEST_AMO_FORCE_IN_HIGH, (uint16)TEST_AMO_FORCE_IN_LOW);
    }
    after = HAL_TIM_GetCounter(&htim_dev);
    printf("ADC0.AMO rising edges generated: %d, tim0 counter %d -> %d\r\n",
           (int)TEST_ETR_EDGES, (int)before, (int)after);
    Check("every ADC0.AMO rising edge advances the counter by one",
          ((after - before) == TEST_ETR_EDGES));

    /* Restore the documented window so that the trace below matches step 5 */
    adc_amo.ADC_AmoUpThreshold  = (uint16)TEST_ADC_AMO_HIGH;
    adc_amo.ADC_AmoLowThreshold = (uint16)TEST_ADC_AMO_LOW;
    Check("the monitor window is restored to 1500..3500",
          ((HAL_ADC_ConfigAnalogMonitor(&hadc_dev, &adc_amo) == HAL_OK) &&
           (HAL_ADC_GetAnalogMonitorConfig(&hadc_dev, &adc_amo) == HAL_OK) &&
           (adc_amo.ADC_AmoUpThreshold == TEST_ADC_AMO_HIGH) &&
           (adc_amo.ADC_AmoLowThreshold == TEST_ADC_AMO_LOW)));

    Summary();
    printf("note: the window is moved out of and back into range once per loop,\r\n");
    printf("      every ADC0.AMO rising edge advances the counter by one\r\n");

    for (;;)
    {
        /* out of window: the monitor flag sets and ADC_AMO_OUT rises */
        last_adc_value = Adc_AmoConvert((uint16)TEST_AMO_FORCE_OUT_HIGH,
                                        (uint16)TEST_AMO_FORCE_OUT_LOW);
        amo_flag = (uint32)HAL_ADC_GetFlagStatus(&hadc_dev, ADC_FLAG_AMO, ADC_RSEQ_0);
        (void)HAL_ADC_ClearFlag(&hadc_dev, ADC_FLAG_AMO, ADC_RSEQ_0);

        /* back inside the window: the monitor output falls again */
        (void)Adc_AmoConvert((uint16)TEST_AMO_FORCE_IN_HIGH, (uint16)TEST_AMO_FORCE_IN_LOW);

        printf("adc0 value: %d  amo flag: %d  tim0 cnt: %d\r\n",
               (int)last_adc_value, (int)amo_flag, (int)HAL_TIM_GetCounter(&htim_dev));
        delay_ms(200U);
    }
}
