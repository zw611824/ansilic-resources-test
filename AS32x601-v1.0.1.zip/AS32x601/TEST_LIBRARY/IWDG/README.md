# IWDG 应用与测试参考

供 skill 按需求检索 AS32x601 HAL 独立看门狗（IWDG）示例。别名/关键词：看门狗、独立看门狗、喂狗、刷新、超时复位、PSC/DIV/BVAL、预分频、分频、写保护、FCU 告警。共有 11 个独立用例。

HAL 依据：[头文件](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_iwdg.h)、[实现](../../HAL_LIBRARY/peripherals/src/as32x601_hal_iwdg.c)。原测试工程的 4_HAL_LIBRARY 未提供，尚不能确认原始链接版本；文中标出的源码与当前 SDK 差异须先解决再迁移。

IWDG 自身没有中断线；本组用例把 FCU 的 IWDG 通道配成告警/复位源来观察超时，因此涉及 IWDG 的“中断告警”必须同时配置 FCU，不能只看 IWDG 接口。


## 实例与相关资源

本模块不单独列出外部通信引脚组。按实际功能核对实例、时钟、中断、内存或数据通路；关联 GPIO、定时器或其他外设时，再读取对应分支的引脚资料。具体资源与案例配置见下文。

## 生成前需确认的参数

已有工程、板级资料或用户已明确的值直接复用。仅对影响本次实现的缺失选择使用参数卡询问并等待答复；案例配置不能代替实际接线或应用参数。

| 参数 | 需要核对或确认的内容 |
|---|---|
| 看门狗参数 | 实际时钟源、超时范围及启动时机 |
| 喂狗与复位 | 喂狗条件、故障注入与复位后记录需求 |

## 按需求选择

| 用户需求 / 检索关键词 | 推荐用例 | 选择条件 / 需要补充的逻辑 |
|---|---|---|
| 最短路径：初始化、启动、喂狗 | [001](IWDG_IT_DRV_001.c) | 先看 001 的主流程即可；它同时扫 4 个预分频值。应用删除扫描，只保留目标 `Prescaler/Divider/Reload` |
| 选择分频值 / 计算超时时间 | [002](IWDG_IT_DRV_002.c) | 分频扫描 2/100/500/1000。超时公式见下节，不能按“计数值=毫秒”理解 |
| 选择超时重装值 BVAL | [003](IWDG_IT_DRV_003.c) | 扫描 100/5000/30000/65535；BVAL 为 0–65535 |
| 观察计数器递增、刷新后重装 | [004](IWDG_IT_DRV_004.c) | 计数器从 0 向上计到 BVAL；`HAL_IWDG_Refresh()` 使其回落。最适合调试喂狗节奏 |
| 停止/启动看门狗（PSC / CFG 块使能） | [005](IWDG_IT_DRV_005.c)、[006](IWDG_IT_DRV_006.c) | 005 操作 `IWDG_EN_PSC` 预分频块，006 操作 `IWDG_EN_CFG` 配置块；只有两个块都使能计数器才运行 |
| 锁定预分频块，防止误改 | [007](IWDG_IT_DRV_007.c)、[011](IWDG_IT_DRV_011.c) | `HAL_IWDG_LockCmd(IWDG_LOCK_PSC, ...)`；锁定后写入被硬件忽略，但驱动可能仍返回 `HAL_OK` |
| 锁定配置块，防止误启动/误改 | [008](IWDG_IT_DRV_008.c) | `IWDG_LOCK_CFG`；同样存在“写入被忽略但总线接受”的语义 |
| 超时后复位整个系统 | [009](IWDG_IT_DRV_009.c) | 需要 FCU 的 `HAL_FCU_FAULT_GLOBAL_SOFTWARE_RESET`；示例用备份 RAM 标记跨复位识别，勿在调试器暂停下照搬 |
| 配置/句柄/参数合法性自检 | [010](IWDG_IT_DRV_010.c) | 防御性自检，不是应用模板；可查参数范围、状态门控和锁助手 |
| 超时告警经 FCU 上报 | [001](IWDG_IT_DRV_001.c)、[004](IWDG_IT_DRV_004.c) | 这是超时后的 FCU 告警，不等于超时前提前预警；IWDG 无独立 IRQ |
| 窗口约束、刷新过早告警 | [WWDG](../WWDG/README.md) | WWDG 是独立硬件外设，按其计数与 FCU 语义配置 |

## 实现要点与案例配置

- 时钟：IWDG 由常开域 `APB_BusS` 的 32768 Hz（RC32K 派生）计数，不依赖系统主时钟门控；RC32K 本身有偏差，示例的超时比较窗口留有余量。
- 超时公式（源码实际使用）：`T = (PSCNUM + 1) × DIVNUM × BVAL / 32768` 秒。参数范围为 `Prescaler` 2–255、`Divider` 2–65535、`Reload` 0–65535。配置字段直接写原始数值，不是“寄存器编码 − 1”。
- 初始化顺序：`HAL_Init()` → 系统时钟 → `delay_init()` / 串口 →（需要告警时）配置 FCU 通道 → `__HAL_CLEAR_STRUCT`、`Instance = IWDG`、填 `IWDG_InitTypeDef` → `HAL_IWDG_Init()`。`HAL_IWDG_Init()` 返回时预分频块 `PSC.EN` 已置位，但配置块 `CFG.EN` 仍未使能，计数器不动；再调用 `HAL_IWDG_Cmd(&hiwdg, IWDG_EN_CFG, ENABLE)` 才真正启动。
- 运行与喂狗：计数器从 0 向上计到 BVAL；`HAL_IWDG_Refresh()` 重装计数器。示例用 `HAL_IWDG_GetCounter()` 观察递增和刷新回落。本组 001～008 显式配置 FCU 告警，009 配置全局软件复位，不能据此推断芯片复位默认动作。
- 中断/复位链：IWDG 无自身 ISR。001–008 靠 FCU 告警中断并统计到达时间；009 靠 FCU 全局软件复位，复位后在备份 RAM 中检查标记，证明“确实复位过”而非仅超时。
- 证据边界：计数器回读、配置回读和 FCU 到达时间能证明计时链路与启动/停止语义；PD4 翻转可用示波器观察超时时刻；009 的系统复位只能通过复位后现场（备份 RAM 标记、启动日志）确认。RC32K 精度、真实复位波形和长期稳定性需要上板测量，本次未做。

## 验证方法与适用边界

- `HAL_IWDG_Init()` 会**总是使能预分频块**，即使应用之前用 `HAL_IWDG_Cmd(IWDG_EN_PSC, DISABLE)` 关过；011 明确验证了这一点。不要把它当成“只写配置不启动”。
- 写保护块被锁定时，硬件会忽略修改，但总线写入仍被接受，`HAL_IWDG_Cmd/LockCmd` 可能返回 `HAL_OK`；必须回读 `PSC/CFG` 才能判断是否生效。011 还显示：在锁定状态下写入不同值会导致驱动回读不匹配并返回 `HAL_ERROR`。
- 句柄状态门控：`RESET` 状态拒绝刷新/命令/锁定；`BUSY` 状态拒绝新操作并保持状态；`ERROR` 状态可接受下一次合法操作并恢复。错误恢复后要重新确认配置。
- 009 会真实复位系统，且用备份 RAM 标记跨复位；普通 RAM 变量不能承担该标记。调试器暂停会停止内核但看门狗通常继续计数，调试时需先放宽超时或停狗。
- 超时值不要贴着喂狗周期设置；RC32K 偏差、中断延迟和 Flash 操作都会吃掉余量。
- 源码 010 的头注释把 `PSC 255 / DIV 65535 / BVAL 65535` 的超时写成“约 33500 s”，按代码公式实际约为 `3.35 × 10^7 s`（约一年）。该用例的意图只是“足够长、不会触发”，引用数值时以公式为准。
- 不要把 IWDG 与 WWDG 的窗口/早期唤醒行为混用；两者时钟源、复位条件和寄存器都不同。

## 按接口与辅助宏检索

| 接口 / 宏 | 参考用例 |
|---|---|
| `HAL_IWDG_Init` | [001](IWDG_IT_DRV_001.c)、[004](IWDG_IT_DRV_004.c)、[010](IWDG_IT_DRV_010.c) |
| `HAL_IWDG_Cmd` | [005](IWDG_IT_DRV_005.c)、[006](IWDG_IT_DRV_006.c)、[009](IWDG_IT_DRV_009.c) |
| `HAL_IWDG_LockCmd` | [007](IWDG_IT_DRV_007.c)、[008](IWDG_IT_DRV_008.c)、[011](IWDG_IT_DRV_011.c) |
| `HAL_IWDG_Refresh` | [001](IWDG_IT_DRV_001.c)、[004](IWDG_IT_DRV_004.c)、[009](IWDG_IT_DRV_009.c) |
| `HAL_IWDG_GetCounter` | [004](IWDG_IT_DRV_004.c)、[005](IWDG_IT_DRV_005.c)、[006](IWDG_IT_DRV_006.c) |
| `HAL_IWDG_GetState` / `HAL_IWDG_GetError` | [010](IWDG_IT_DRV_010.c)、[011](IWDG_IT_DRV_011.c) |
| `IWDG_EN_PSC` / `IWDG_EN_CFG` | [005](IWDG_IT_DRV_005.c)、[006](IWDG_IT_DRV_006.c) |
| `IWDG_LOCK_PSC` / `IWDG_LOCK_CFG` | [007](IWDG_IT_DRV_007.c)、[008](IWDG_IT_DRV_008.c) |
| `HAL_FCU_Init` / `HAL_FCU_FAULT_GLOBAL_SOFTWARE_RESET` | [009](IWDG_IT_DRV_009.c) |


本次为源码静态整理，未重新编译、未上板；源码里的历史测试注释不代表本次验证结果。
