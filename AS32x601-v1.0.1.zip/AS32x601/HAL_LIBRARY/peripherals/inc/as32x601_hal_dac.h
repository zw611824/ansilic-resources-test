/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_dac.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.1
 * Date:   2026/09/20
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/19     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.1     apply the resource lock / RTOS rules:
 *                                                       document the state gate, add the
 *                                                       shared internal functions (handle /
 *                                                       state check and lock helper) for the
 *                                                       extended driver, add the invalid
 *                                                       parameter error code and mark the
 *                                                       blocking behaviour of every
 *                                                       interface
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Digital to Analog
 *                  Converter (DAC) peripheral:
 *                  - Initialization and de-initialization (HAL_DAC_Init /
 *                    HAL_DAC_DeInit + weak MSP hooks);
 *                  - IO operation (HAL_DAC_Start / HAL_DAC_Stop /
 *                    HAL_DAC_GetValue);
 *                  - Peripheral control (HAL_DAC_SetValue);
 *                  - Peripheral state and errors (HAL_DAC_GetState /
 *                    HAL_DAC_GetError).
 *                  The chip-specific features (comparator, DAC reset
 *                  control) are provided by this driver.
 *                  This driver depends on as32x601_hal_def.h (HAL common
 *                  types and utilities) and on the SMU HAL module for the
 *                  peripheral clock enable / reset release in HAL_DAC_MspInit
 *                  (see the weak implementations in as32x601_hal_dac.c).
 * @complexity  Medium
 *              Blocking (polling) only, state machine, no IT/DMA.
 */
#ifndef __AS32X601_HAL_DAC_H
#define __AS32X601_HAL_DAC_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "as32x601_hal_def.h"       /* HAL common types and utilities          */
#include "as32x601.h"               /* DAC_TypeDef, DAC0/DAC1, register bits   */

/* Exported constants --------------------------------------------------------*/

/**
 * @brief DAC HAL driver module version.
 * @note  0x0100U = V1.0. Bumped only on breaking API changes (architecture
 *        spec COMPAT-13/14/15).
 */
#define __HAL_DAC_MODULE_VERSION  0x0100U

/* Exported types ------------------------------------------------------------*/

/** @defgroup DAC_Exported_Types DAC Exported Types
  * @{
  */

/**
 * @brief HAL State structures definition
 */
typedef enum
{
    HAL_DAC_STATE_RESET             = 0x00U,  /*!< DAC not yet initialized or disabled */
    HAL_DAC_STATE_READY             = 0x01U,  /*!< DAC initialized and ready for use    */
    HAL_DAC_STATE_BUSY              = 0x02U,  /*!< DAC internal processing is ongoing   */
    HAL_DAC_STATE_TIMEOUT           = 0x03U,  /*!< DAC timeout state                    */
    HAL_DAC_STATE_ERROR             = 0x04U   /*!< DAC error state                      */
} HAL_DAC_StateTypeDef;

/**
 * @brief DAC Init Structure definition
 * @note  The fields map the DAC_CTRL register (MD / VREF_MD / EN) and the
 *        DAC_CLK_DIV register (CLK_DIV_NU). The DAC_Enable field is applied
 *        by HAL_DAC_Init(); the enable state
 *        can be changed at run time with HAL_DAC_Start() / HAL_DAC_Stop().
 *        A DAC_ClockDivider value of 0 is interpreted as 1 by HAL_DAC_Init()
 *        so that the DAC conversion clock is never stopped.
 */
typedef struct
{
    uint32 Size;               /*!< sizeof(DAC_InitTypeDef), set by the user
                                    after clearing the structure */
    uint32 Version;            /*!< Structure semantic version: @ref DAC_INIT_VERSION
                                    (DAC_INIT_V1 = 0x0100U) */
    FunctionalState DAC_Enable;        /*!< Enable/disable DAC function (ENABLE/DISABLE) */
    uint32          DAC_Mode;          /*!< DAC output mode: DAC_OUTPUTBUFFER_ENABLE /
                                            DAC_OUTPUTBUFFER_DISABLE (device layer aliases
                                            DAC_MD_BUFFER_OUT / DAC_MD_BYPASS_OUT)       */
    uint32          DAC_VrefMode;      /*!< DAC reference voltage: DAC_VREF_MD_VREFP /
                                            DAC_VREF_MD_AVD                              */
    uint32          DAC_ClockDivider;  /*!< DAC clock divide ratio (0x01 to 0xFF)        */
    uint32 Reserved[2];         /*!< Reserved for future extension (must be 0) */
} DAC_InitTypeDef;

/**
 * @brief DAC init structure version macros.
 * @note  DAC_INIT_V1 is the current version. Future versions must be
 *        appended after the existing fields (architecture spec section 22.5).
 */
#define DAC_INIT_V1  0x0100U   /*!< DAC Init structure version V1.0 */
#define DAC_INIT_VERSION  DAC_INIT_V1   /*!< Current DAC Init structure version */

/**
 * @brief DAC handle Structure definition
 * @note  Field order follows the architecture spec HANDLE-02:
 *        Instance -> Init -> Lock -> State -> ErrorCode.
 */
typedef struct __DAC_HandleTypeDef
{
    DAC_TypeDef               *Instance;  /*!< Register base address                     */
    DAC_InitTypeDef           Init;       /*!< DAC required parameters                   */
    HAL_LockTypeDef           Lock;       /*!< DAC locking object                        */
#if (USE_RTOS == 1)
    HAL_MutexTypeDef          LockMutex;  /*!< RTOS mutex handle                         */
#endif
    __IO HAL_DAC_StateTypeDef State;      /*!< DAC peripheral state                       */
    __IO uint32               ErrorCode;  /*!< DAC Error code                            */
} DAC_HandleTypeDef;

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @defgroup DAC_Exported_Constants DAC Exported Constants
  * @{
  */

/** @defgroup DAC_Error_Code DAC Error Code
  * @{
  */
#define HAL_DAC_ERROR_NONE              0x00000000U  /*!< No error                          */
#define HAL_DAC_ERROR_INVALID_PARAM     0x00000001U  /*!< Invalid parameter, invalid
                                                          configuration structure or a
                                                          rejected operation                  */
/**
  * @}
  */

/** @defgroup DAC_Output_Buffer DAC Output Buffer
  * @note  Same encodings as the device layer DAC_MD_BUFFER_OUT / DAC_MD_BYPASS_OUT
  *        (DAC_CTRL.MD: 0 = buffer output, 1 = bypass output). The generic
  *        names are provided first, the device layer names are kept as aliases so
  *        that migrated code keeps compiling.
  * @{
  */
#define DAC_OUTPUTBUFFER_ENABLE         0x00000000U  /*!< DAC output buffer mode (device layer: DAC_MD_BUFFER_OUT)  */
#define DAC_OUTPUTBUFFER_DISABLE        0x00000001U  /*!< DAC bypass output mode  (device layer: DAC_MD_BYPASS_OUT) */

#define DAC_MD_BUFFER_OUT               DAC_OUTPUTBUFFER_ENABLE   /*!< Device layer alias */
#define DAC_MD_BYPASS_OUT               DAC_OUTPUTBUFFER_DISABLE  /*!< Device layer alias */
/**
  * @}
  */

/** @defgroup DAC_Enable DAC Enable Selection
  * @note  Values match the FunctionalState ENABLE / DISABLE (1 / 0), i.e. the
  *        DAC_CTRL.EN bit value written by the initialization routine.
  * @{
  */
#define DAC_ENABLE                      0x00000001U   /*!< DAC enable  */
#define DAC_DISABLE                     0x00000000U   /*!< DAC disable */
/**
  * @}
  */

/** @defgroup DAC_Reference_Voltage DAC Reference Voltage
  * @note  Values are the DAC_CTRL.VREF_MD field encodings (device layer names kept).
  * @{
  */
#define DAC_VREF_MD_VREFP               0x00000000U   /*!< DAC reference VREFP selection */
#define DAC_VREF_MD_AVD                 0x00000001U   /*!< DAC reference AVD selection   */
/**
  * @}
  */

/**
  * @}
  */

/* Exported macros -----------------------------------------------------------*/

/** @defgroup DAC_Exported_Macros DAC Exported Macros
  * @{
  */

/** @defgroup DAC_Handle_Management DAC Handle Management
  * @{
  */

/**
 * @brief  Reset the DAC handle state.
 * @param  __HANDLE__: specifies the DAC handle.
 * @retval None
 */
#define __HAL_DAC_RESET_HANDLE_STATE(__HANDLE__) ((__HANDLE__)->State = HAL_DAC_STATE_RESET)
/**
  * @}
  */

/** @defgroup DAC_Enable_Disable DAC Enable / Disable
  * @{
  */

/**
 * @brief  Enable the DAC (set the DAC_CTRL.EN bit).
 * @param  __HANDLE__: specifies the DAC handle.
 * @retval None
 */
#define __HAL_DAC_ENABLE(__HANDLE__)    (SET_BIT((__HANDLE__)->Instance->CTRL, DAC_CTRL_EN))

/**
 * @brief  Disable the DAC (clear the DAC_CTRL.EN bit).
 * @param  __HANDLE__: specifies the DAC handle.
 * @retval None
 */
#define __HAL_DAC_DISABLE(__HANDLE__)   (CLEAR_BIT((__HANDLE__)->Instance->CTRL, DAC_CTRL_EN))
/**
  * @}
  */

/** @defgroup DAC_Reset_Control DAC Reset Control
  * @{
  */

/**
 * @brief  Release the DAC reset (set the DAC_CTRL.RESETN bit, DAC running).
 * @param  __HANDLE__: specifies the DAC handle.
 * @retval None
 */
#define __HAL_DAC_RESET_RELEASE(__HANDLE__) (SET_BIT((__HANDLE__)->Instance->CTRL, DAC_CTRL_RESETN))

/**
 * @brief  Assert the DAC reset (clear the DAC_CTRL.RESETN bit, DAC held in
 *         reset).
 * @param  __HANDLE__: specifies the DAC handle.
 * @retval None
 */
#define __HAL_DAC_RESET_ASSERT(__HANDLE__)  (CLEAR_BIT((__HANDLE__)->Instance->CTRL, DAC_CTRL_RESETN))
/**
  * @}
  */

/**
  * @}
  */

/* Include DAC HAL Extension module */

/* Exported functions --------------------------------------------------------*/

/** @defgroup DAC_Exported_Functions DAC Exported Functions
  * @{
  */

/** @defgroup DAC_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Initialize the DAC_InitTypeDef structure with default values. (NON-BLOCKING)
 * @note   Sets the Size / Version compatibility metafields and fills the
 *         configuration fields with the DAC default values.
 * @param  DAC_InitStruct: pointer to a DAC_InitTypeDef structure.
 * @retval None
 */
void HAL_DAC_StructInit(DAC_InitTypeDef *DAC_InitStruct);

/**
 * @brief  Initialize the DAC peripheral according to the specified parameters (NON-BLOCKING)
 *         in the hdac->Init structure (output mode, reference voltage, clock
 *         divider, enable state) and initialize the low level hardware.
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
 *         configuration information for the specified DAC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_DAC_Init(DAC_HandleTypeDef *hdac);

/**
 * @brief  De-initialize the DAC peripheral registers to their default reset (NON-BLOCKING)
 *         values.
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
 *         configuration information for the specified DAC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_DAC_DeInit(DAC_HandleTypeDef *hdac);

/**
 * @brief  Initialize the DAC MSP (peripheral clock enable, reset release).
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
 *         configuration information for the specified DAC.
 * @retval None
 */
void HAL_DAC_MspInit(DAC_HandleTypeDef *hdac);

/**
 * @brief  De-initialize the DAC MSP (peripheral clock disable, reset assert).
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
 *         configuration information for the specified DAC.
 * @retval None
 */
void HAL_DAC_MspDeInit(DAC_HandleTypeDef *hdac);
/**
  * @}
  */

/** @defgroup DAC_Exported_Functions_Group2 IO operation functions
  * @{
  */

/**
 * @brief  Enable the DAC (starts the conversion of the 8-bit data written to (NON-BLOCKING)
 *         the DAC_DOUT register).
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
 *         configuration information for the specified DAC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_DAC_Start(DAC_HandleTypeDef *hdac);

/**
 * @brief  Disable the DAC (stops the conversion). (NON-BLOCKING)
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
 *         configuration information for the specified DAC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_DAC_Stop(DAC_HandleTypeDef *hdac);

/**
 * @brief  Return the last data value written to the DAC data register. (NON-BLOCKING)
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
 *         configuration information for the specified DAC.
 * @retval uint32: the DAC data register value (8-bit).
 */
uint32 HAL_DAC_GetValue(DAC_HandleTypeDef *hdac);
/**
  * @}
  */

/** @defgroup DAC_Exported_Functions_Group3 Peripheral Control functions
  * @{
  */

/**
 * @brief  Set the 8-bit data holding register value of the DAC. (NON-BLOCKING)
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
 *         configuration information for the specified DAC.
 * @param  Data: 8-bit data to be loaded in the DAC data register (0x00 to 0xFF).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_DAC_SetValue(DAC_HandleTypeDef *hdac, uint32 Data);
/**
  * @}
  */

/** @defgroup DAC_Exported_Functions_Group4 Peripheral State and Errors functions
  * @{
  */

/**
 * @brief  Return the DAC state. (NON-BLOCKING)
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
 *         configuration information for the specified DAC.
 * @retval HAL_DAC_StateTypeDef: HAL_DAC_STATE_xxx.
 */
HAL_DAC_StateTypeDef HAL_DAC_GetState(DAC_HandleTypeDef *hdac);

/**
 * @brief  Return the DAC error code. (NON-BLOCKING)
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
 *         configuration information for the specified DAC.
 * @retval uint32: DAC error code (HAL_DAC_ERROR_NONE).
 */
uint32 HAL_DAC_GetError(DAC_HandleTypeDef *hdac);
/**
  * @}
  */

/**
  * @}
  */

/* Shared internal functions --------------------------------------------------*/

/** @defgroup DAC_Shared_Internal_Functions DAC Shared Internal Functions
  * @{
  */

/**
 * @brief  Check whether the handle and its instance are valid (shared by every
 *         entry point of this driver).
 * @param  hdac: pointer to a DAC_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
uint32 DAC_HandleIsValid(DAC_HandleTypeDef *hdac);

/**
 * @brief  Check whether the handle accepts a new operation (ARCH-CONST-09).
 * @note   A busy handle reports HAL_BUSY, a handle that has not been
 *         initialized (RESET) reports HAL_ERROR; the remaining states
 *         (READY and the recoverable TIMEOUT / ERROR) accept the call.
 * @param  hdac: pointer to a DAC_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef DAC_CheckState(DAC_HandleTypeDef *hdac);

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_DAC_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; when the mutex is not acquired before the
 *         Timeout expires, HAL_TIMEOUT is returned. The value is passed to
 *         HAL_MutexAcquire() as is (RTOS ticks; with the usual 1 ms tick it is
 *         the same quantity as the millisecond Timeout of the public API, and
 *         HAL_MAX_DELAY means an infinite wait).
 * @param  hdac: pointer to a DAC_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef DAC_LockHandle(DAC_HandleTypeDef *hdac, uint32 Timeout);

/**
 * @brief  Unlock the handle.
 * @param  hdac: pointer to a DAC_HandleTypeDef structure.
 * @retval None
 */
void DAC_UnlockHandle(DAC_HandleTypeDef *hdac);

/**
  * @}
  */

/* Exported types ------------------------------------------------------------*/

/** @addtogroup DAC_Exported_Types DAC Exported Types
  * @{
  */

/**
 * @brief DAC Comparator Configuration Structure definition
 * @note  The fields map the DAC_CMP_CTRL register (EN / MD / HYS). The
 *        structure corresponds to the device layer DAC_CMPTypedef (renamed to follow
 *        the xxxConfTypeDef naming convention).
 */
typedef struct
{
    uint32 CMP_Enable;        /*!< Enable/disable comparator: DAC_CMP_ENABLE / DAC_CMP_DISABLE */
    uint32 CMP_Mode;          /*!< Comparator mode: DAC_CMP_MD_DACO / DAC_CMP_MD_CMP_P          */
    uint32 CMP_Hysteresis;    /*!< Comparator hysteresis: DAC_CMP_HYS_xxx (unit: mV)            */
} DAC_CMPConfTypeDef;

/* Device layer compatible alias: the device layer structure was DAC_CMPTypedef */
typedef DAC_CMPConfTypeDef DAC_CMPTypedef;

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @addtogroup DAC_Exported_Constants DAC Exported Constants
  * @{
  */

/** @defgroup DAC_Comparator_Enable DAC Comparator Enable Selection
  * @note  Values match the DAC_CMP_CTRL.EN bit value (device layer names kept).
  * @{
  */
#define DAC_CMP_ENABLE                      0x00000001U  /*!< DAC comparator enable  */
#define DAC_CMP_DISABLE                     0x00000000U  /*!< DAC comparator disable */
/**
  * @}
  */

/** @defgroup DAC_Comparator_Mode DAC Comparator Mode Selection
  * @note  Values are the DAC_CMP_CTRL.MD field encodings (device layer names kept).
  * @{
  */
#define DAC_CMP_MD_DACO                     0x00000000U  /*!< Comparator input from DAC0 output */
#define DAC_CMP_MD_CMP_P                    0x00000001U  /*!< Comparator input from CMP_P pin   */
/**
  * @}
  */

/** @defgroup DAC_Comparator_Hysteresis DAC Comparator Hysteresis Selection
  * @note  Values are the DAC_CMP_CTRL.HYS field encodings (3 bit field, eight
  *        steps). Unit: mV.
  * @{
  */
#define DAC_CMP_HYS_0MV                     0x00000000U  /*!< Comparator hysteresis 0 mV    */
#define DAC_CMP_HYS_3P30MV                  0x00000001U  /*!< Comparator hysteresis 3.3 mV  */
#define DAC_CMP_HYS_16P50MV                 0x00000002U  /*!< Comparator hysteresis 16.5 mV */
#define DAC_CMP_HYS_33MV                    0x00000003U  /*!< Comparator hysteresis 33 mV   */
#define DAC_CMP_HYS_66MV                    0x00000004U  /*!< Comparator hysteresis 66 mV   */
#define DAC_CMP_HYS_165MV                   0x00000005U  /*!< Comparator hysteresis 165 mV  */
#define DAC_CMP_HYS_264MV                   0x00000006U  /*!< Comparator hysteresis 264 mV  */
#define DAC_CMP_HYS_330MV                   0x00000007U  /*!< Comparator hysteresis 330 mV  */

/* Device layer compatible aliases (short names) */
#define DAC_CMP_HYS_0                       DAC_CMP_HYS_0MV
#define DAC_CMP_HYS_3MV3                    DAC_CMP_HYS_3P30MV
#define DAC_CMP_HYS_16MV5                   DAC_CMP_HYS_16P50MV
#define DAC_CMP_HYS_33                      DAC_CMP_HYS_33MV
#define DAC_CMP_HYS_66                      DAC_CMP_HYS_66MV
#define DAC_CMP_HYS_165                     DAC_CMP_HYS_165MV
#define DAC_CMP_HYS_264                     DAC_CMP_HYS_264MV
#define DAC_CMP_HYS_330                     DAC_CMP_HYS_330MV
/**
  * @}
  */

/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/

/** @addtogroup DAC_Exported_Functions DAC Exported Functions
  * @{
  */

/** @addtogroup DAC_Exported_Functions_Group1 Extended features functions
  * @{
  */

/**
 * @brief  Assert or release the DAC reset (DAC_CTRL.RESETN bit). (NON-BLOCKING)
 * @note   NewState = 1 releases the reset (DAC running), NewState = 0 asserts
 *         the reset (DAC held in reset).
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_DAC_Init() is required first).
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
 *         configuration information for the specified DAC.
 * @param  NewState: 1 = release the DAC reset, 0 = assert the DAC reset.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_DAC_ResetCmd(DAC_HandleTypeDef *hdac, uint32 NewState);

/**
 * @brief  Initialize the DAC comparator configuration structure with default (NON-BLOCKING)
 *         values.
 * @param  pCMPConf: pointer to a DAC_CMPConfTypeDef structure that will be
 *         filled with the default configuration.
 * @retval None
 */
void HAL_DAC_CMPStructInit(DAC_CMPConfTypeDef *pCMPConf);

/**
 * @brief  Configure the DAC comparator according to the specified parameters (NON-BLOCKING)
 *         in the pCMPConf structure (enable, mode, hysteresis).
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
 *         configuration information for the specified DAC.
 * @param  pCMPConf: pointer to a DAC_CMPConfTypeDef structure that contains
 *         the configuration information for the comparator.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_DAC_ConfigComparator(DAC_HandleTypeDef *hdac, DAC_CMPConfTypeDef *pCMPConf);

/**
 * @brief  Enable or disable the DAC comparator (DAC_CMP_CTRL.EN bit). (NON-BLOCKING)
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
 *         configuration information for the specified DAC.
 * @param  NewState: 1 = enable the comparator, 0 = disable the comparator.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_DAC_ComparatorCmd(DAC_HandleTypeDef *hdac, uint32 NewState);

/**
 * @brief  Return the DAC comparator result value (DAC_CMP_CTRL.CMPO bit). (NON-BLOCKING)
 * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains the
         configuration information for the specified DAC.
 * @retval uint32: 1 if the comparator output is high, 0 otherwise (also 0 for
 *         an invalid handle or instance).
 */
uint32 HAL_DAC_GetComparatorResult(DAC_HandleTypeDef *hdac);
/**
  * @}
  */

/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/

/** @addtogroup DAC_Private_Macros DAC Private Macros
  * @{
  */

#define IS_DAC_CMP_EN(EN)                 (((EN) == DAC_CMP_ENABLE) || ((EN) == DAC_CMP_DISABLE))
#define IS_DAC_CMP_MD(MD)                 (((MD) == DAC_CMP_MD_DACO) || ((MD) == DAC_CMP_MD_CMP_P))
#define IS_DAC_CMP_HYS(HYS)               (((HYS) == DAC_CMP_HYS_0MV) || \
                                           ((HYS) == DAC_CMP_HYS_3P30MV) || \
                                           ((HYS) == DAC_CMP_HYS_16P50MV) || \
                                           ((HYS) == DAC_CMP_HYS_33MV) || \
                                           ((HYS) == DAC_CMP_HYS_66MV) || \
                                           ((HYS) == DAC_CMP_HYS_165MV) || \
                                           ((HYS) == DAC_CMP_HYS_264MV) || \
                                           ((HYS) == DAC_CMP_HYS_330MV))

/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/

/** @defgroup DAC_Private_Macros DAC Private Macros
  * @{
  */

#define IS_DAC_ALL_INSTANCE(INSTANCE)     (((INSTANCE) == DAC0) || \
                                           ((INSTANCE) == DAC1))
/* Device layer compatible aliases (assert macros, kept for migrated code) */
#define IS_DAC_ALL_PERIPH                 IS_DAC_ALL_INSTANCE
#define IS_DAC_MD                         IS_DAC_OUTPUT_BUFFER_STATE
#define IS_DAC_EN(EN)                     (((EN) == DAC_ENABLE) || ((EN) == DAC_DISABLE))
#define IS_DAC_OUTPUT_BUFFER_STATE(STATE) (((STATE) == DAC_OUTPUTBUFFER_ENABLE) || \
                                           ((STATE) == DAC_OUTPUTBUFFER_DISABLE))
#define IS_DAC_VREF_MD(MD)                (((MD) == DAC_VREF_MD_VREFP) || ((MD) == DAC_VREF_MD_AVD))
#define IS_DAC_CLK_DIV(CLKDIV)            ((CLKDIV) <= 0xFFU)
#define IS_DAC_DATA(DATA)                 ((DATA) <= 0xFFU)
#define IS_DAC_NEWSTATE(STATE)            (((STATE) == 0U) || ((STATE) == 1U))

/**
  * @}
  */

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_DAC_H */

/*****END OF FILE*****/
