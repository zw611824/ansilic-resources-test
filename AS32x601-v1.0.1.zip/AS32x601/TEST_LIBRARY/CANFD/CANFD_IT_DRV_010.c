/**
 * @file    CANFD_IT_DRV_010.c
 * @brief   HAL CANFD integration test case 010 (transmit length encoding sweep (DLC codes)).
 *
 * HAL port of the AS32x601 standard-library test case
 * CANFD_IT_DRV_010.c.  The subject is the encoding of every
 * discrete CAN FD length into its DLC code, so this case does not
 * repeat the frame matrix of case 001 nor the mode sweep of 013.
 *
 * Tested functionality:
 *   HAL_CANFD_StructInit() / HAL_CANFD_Init() / HAL_CANFD_DeInit()
 *   HAL_CANFD_FilterInit()
 *   HAL_CANFD_MspInit() (driver hook, overridden by the case)
 *   HAL_CANFD_GetState() / HAL_CANFD_GetError()
 *   HAL_CANFD_FrameStructInit() / HAL_CANFD_FrameInit()
 *   HAL_CANFD_Transmit() / HAL_CANFD_GetSendCmpStatus()
 *   HAL_CANFD_GetRXErrorCount() / HAL_CANFD_GetTXErrorCount() /
 *
 * Test procedure:
 *   1. initialize the controller;
 *   2. for every length of the discrete set (0, 1, 8, 12, 16, 32, 48, 64 bytes)
 *      clear the DLC field of its buffer, transmit, and verify that the length
 *      word of that buffer carries the matching DLC code (0..8, 9, 10, 13, 14,
 *      15) and that the request is served;
 *   3. verify that lengths outside the set (9, 10, 63, 65 bytes) are refused
 *      instead of being rounded up;
 *   4. verify that a classic frame accepts 8 bytes and refuses 12 bytes;
 *   5. verify that a rejected length leaves the DLC field of the buffer as it
 *      was;
 *   6. verify that a classic remote frame is accepted with a NULL payload.
 *
 * Expected behaviour:
 *   - every length of the discrete set is accepted and its DLC code is the
 *     expected one (0/1/8/12/16/32/48/64 bytes -> 0/1/8/9/10/13/14/15);
 *   - 9, 10, 63 and 65 bytes are refused with HAL_ERROR;
 *   - a classic frame accepts 0..8 bytes and refuses 12 bytes;
 *   - a refused call does not modify the DLC field of the buffer;
 *   - the summary reports "failures = 0".
 *
 * PARTNER: an external node is required only to acknowledge the frames; the
 * case does not need a matching answer.
 *
 * @note Clock tree: the CAN FD controller is clocked by
 *       CANCLK = PLLR / CANX2DIV / 2 (SMU formula).  This suite keeps the
 *       vendor configuration of the CAN FD reference cases: VCO 160 MHz,
 *       PLLR = 1 -> CANCLK = 80 MHz, so the bit timing of the reference cases
 *       (10 tq prescaler, 16 tq per arbitration bit = 500 kbit/s and 2 tq
 *       prescaler, 8 tq per data bit = 5 Mbit/s) is reproduced unchanged.
 *       The core therefore runs at 160 MHz in this suite (AXI4Bus3 80 MHz,
 *       APBBus0/APBBus1 40 MHz); the other HAL suites use 180 MHz and cannot
 *       reach a CANCLK inside the 8..80 MHz window with a 500 kbit/s timing.
 *
 * @note Only HAL library APIs are used.  The one exception is the source of
 *       case 011, whose whole purpose is to reproduce the reference scenario
 *       "configure the GPIO first, then enable the peripheral clock".
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* CAN FD instance under test */
#define TEST_CANFD                  CANFD3
#define TEST_CANFD_IRQn             CANFD3_IRQn
#define TEST_CANFD_CLK_ENABLE()     __HAL_SMU_CANFD3_CLK_ENABLE()
#define TEST_CANFD_FORCE_RESET()    __HAL_SMU_CANFD3_FORCE_RESET()
#define TEST_CANFD_RELEASE_RESET()  __HAL_SMU_CANFD3_RELEASE_RESET()

/* Port / pins of the instance (from the chip IO map) */
#define TEST_CAN_TX_GPIO            GPIOC
#define TEST_CAN_TX_PIN             GPIO_PIN_7
#define TEST_CAN_TX_SOURCE          GPIO_PinSource7
#define TEST_CAN_RX_PIN             GPIO_PIN_8
#define TEST_CAN_RX_SOURCE          GPIO_PinSource8
#define TEST_CAN_AF                 GPIO_AF_CAN3
#define TEST_CAN_GPIO_CLK_ENABLE()  __HAL_SMU_GPIOC_CLK_ENABLE()

/* Bit timing of the reference cases: 500 kbit/s arbitration,
 * 5 Mbit/s data phase, CANCLK = 80 MHz */
#define TEST_APBRPR_VALUE           (10U)   /* 80 MHz / 10 = 8 MHz tq clock     */
#define TEST_APTS1_VALUE            (11U)   /* + 1 sync = 16 tq -> 500 kbit/s   */
#define TEST_APTS2_VALUE            (4U)
#define TEST_APSJW_VALUE            (2U)
#define TEST_DPBRPR_VALUE           (2U)    /* 80 MHz / 2 = 40 MHz tq clock     */
#define TEST_DPTS1_VALUE            (5U)    /* + 1 sync = 8 tq -> 5 Mbit/s      */
#define TEST_DPTS2_VALUE            (2U)
#define TEST_DPSJW_VALUE            (2U)

/* Number of bytes used to exercise the discrete CAN FD length set */
#define TEST_DATA_BYTES_CLASSIC     (8U)
#define TEST_DATA_BYTES_FD          (64U)

/* Frame identifiers used by the reference cases (the acceptance filters
 * accept 0x147 standard, 0x147 extended and 0x258 / 0x269) */
#define TEST_STD_ID                 (0x147U)
#define TEST_EXT_ID                 (0x147U)
#define TEST_FILTER_ID_1            (0x28E00000U)   /* standard 0x147 */
#define TEST_FILTER_ID_2            (0x4B000000U)   /* standard 0x258 */
#define TEST_FILTER_ID_3            (0x6D200000U)   /* standard 0x269 */
#define TEST_FILTER_ID_4            (0x0008028EU)   /* extended 0x0000147 */
#define TEST_FILTER_MASK_STD        (0xFFE00000U)
#define TEST_FILTER_MASK_EXT        (0xFFEFFFFEU)

/* Bounded waits: the cases must never hang when the external CAN partner is
 * absent, they report the timeout instead */
#define TEST_WAIT_FRAME_MS          (2000U)   /* one frame on the bus         */
#define TEST_WAIT_BUSOFF_MS         (5000U)   /* bus-off recovery             */
#define TEST_WAIT_WAKEUP_MS         (10000U)  /* wait for the partner frame   */
#define TEST_TX_TIMEOUT_MS          (100U)    /* wait for normal mode         */

/* Private variables ---------------------------------------------------------*/
static CANFD_HandleTypeDef hcanfd_dev;      /*!< CAN FD handle                */
static HAL_SMU_HandleTypeDef   hsmu_clk;    /*!< SMU handle (lock / state)    */
static SMU_ClocksTypeDef       g_clocks;    /*!< clock tree snapshot          */

static uint32 failures = 0U;                /*!< failed check counter         */

static volatile uint32 tx_ok_count   = 0U;  /*!< TXOK interrupt counter       */
static volatile uint32 rx_ok_count   = 0U;  /*!< RXOK interrupt counter       */
static volatile uint32 busoff_count  = 0U;  /*!< BSOFF interrupt counter      */
static volatile uint32 wakeup_count  = 0U;  /*!< WKUP  interrupt counter      */
static volatile uint32 error_count   = 0U;  /*!< EERROR interrupt counter     */

static uint8 tx_data[TEST_DATA_BYTES_FD];   /*!< transmit payload             */
static uint8 rx_data[TEST_DATA_BYTES_FD];   /*!< receive payload              */

static volatile uint32 rx_len = 0U;         /*!< length of the last rx frame  */

/* Payload pattern of the reference cases */
static const uint8 test_pattern[TEST_DATA_BYTES_FD] =
{
    0x11U, 0x12U, 0x13U, 0x14U, 0x15U, 0x16U, 0x17U, 0x18U,
    0x21U, 0x22U, 0x23U, 0x24U, 0x25U, 0x26U, 0x27U, 0x28U,
    0x31U, 0x32U, 0x33U, 0x34U, 0x35U, 0x36U, 0x37U, 0x38U,
    0x41U, 0x42U, 0x43U, 0x44U, 0x45U, 0x46U, 0x47U, 0x48U,
    0x51U, 0x52U, 0x53U, 0x54U, 0x55U, 0x56U, 0x57U, 0x58U,
    0x61U, 0x62U, 0x63U, 0x64U, 0x65U, 0x66U, 0x67U, 0x68U,
    0x71U, 0x72U, 0x73U, 0x74U, 0x75U, 0x76U, 0x77U, 0x78U,
    0x81U, 0x82U, 0x83U, 0x84U, 0x85U, 0x86U, 0x87U, 0x88U
};

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void Can_ClockEnable(void);
static void Can_GpioInit(void);
static void Can_InitStruct_Default(CANFD_InitTypeDef *init);
static void Can_SetAcceptanceFilters(void);
static HAL_StatusTypeDef Can_Setup(void);
static void Can_FrameInit(uint32 TxBuffer, uint32 Protocol, uint32 Format, uint32 Id);
static void Can_CopyPattern(uint32 Length);
static uint32 Can_WaitSendComplete(uint32 TxBuffer, uint32 TimeoutMs);
static void Check(const char *name, int ok);
static void Summary(void);
static void Print_ErrorCounters(void);

/**
 * @brief  Accumulate one check result.
 * @param  name: name of the checked item.
 * @param  ok:   non zero when the check passed.
 * @retval None
 */
static void Check(const char *name, int ok)
{
    printf("  %-52s [%s]\r\n", name, (ok != 0) ? "PASS" : "FAIL");

    if (ok == 0)
    {
        failures++;
    }
}

/**
 * @brief  Print the summary line of the case.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("summary : failures = %u\r\n", PRINT_U32(failures));
}

/**
 * @brief  Print the CAN FD error counters.
 * @param  None
 * @retval None
 */
static void Print_ErrorCounters(void)
{
    printf("RXErrorCount: 0x%X\r\n", PRINT_U32(HAL_CANFD_GetRXErrorCount(&hcanfd_dev)));
    printf("TXErrorCount: 0x%X\r\n", PRINT_U32(HAL_CANFD_GetTXErrorCount(&hcanfd_dev)));
}

/**
 * @brief  Copy the reference pattern into the transmit buffer.
 * @param  Length: number of bytes to copy (0..64).
 * @retval None
 */
static void Can_CopyPattern(uint32 Length)
{
    uint32 i;

    for (i = 0U; i < Length; i++)
    {
        tx_data[i] = test_pattern[i];
    }
}


/**
 * @brief  Configure a transmit buffer frame (identifier, format, type and
 *         protocol of the reference cases).
 * @param  TxBuffer: transmit buffer index, 0..31.
 * @param  Protocol: CANFD_PROTOCOL_CAN / CANFD_PROTOCOL_CANFD /
 *                   CANFD_PROTOCOL_CANFD_BRS.
 * @param  Format:   CANFD_FORMAT_STANDARD / CANFD_FORMAT_EXTENDED.
 * @param  Id:       frame identifier.
 * @retval None
 */
static void Can_FrameInit(uint32 TxBuffer, uint32 Protocol, uint32 Format, uint32 Id)
{
    CANFD_TXFrameTypeDef frame;

    HAL_CANFD_FrameStructInit(&frame);
    frame.CANFD_TX_PROTOCOL = Protocol;
    frame.CANFD_TX_FORMAT   = Format;
    frame.CANFD_TX_TYPE     = CANFD_TYPE_DATA;
    frame.CANFD_Frame_ID    = Id;

    HAL_CANFD_FrameInit(&hcanfd_dev, TxBuffer, &frame);
}

/**
 * @brief  Poll the transmit request bit until the frame has been sent.
 * @note   HAL_CANFD_GetSendCmpStatus() returns 1 when the request has been
 *         served (the controller clears the request bit), 0 while it is still
 *         pending, so the wait condition is "0 -> 1".
 * @param  TxBuffer:  transmit buffer index, 0..31.
 * @param  TimeoutMs: bounded wait in milliseconds.
 * @retval 1 when the frame was sent, 0 on timeout.
 */
static uint32 Can_WaitSendComplete(uint32 TxBuffer, uint32 TimeoutMs)
{
    uint32 tickstart = HAL_GetTick();

    while (HAL_CANFD_GetSendCmpStatus(&hcanfd_dev, ((uint32)1U << TxBuffer)) == 0U)
    {
        if ((HAL_GetTick() - tickstart) > TimeoutMs)
        {
            return 0U;
        }
    }

    return 1U;
}


/**
 * @brief  Enable the clock gate of the CAN FD instance under test and release
 *         its reset.
 * @note   HAL_CANFD_MspInit() is a weak empty function in the driver, so the
 *         low level bring-up (clock gate, reset, pin multiplexing) is done by
 *         the test case.  The reset bit is SET = released / CLEAR = reset
 *         asserted, as for every other instance of the SMU block.
 * @param  None
 * @retval None
 */
static void Can_ClockEnable(void)
{
    TEST_CAN_GPIO_CLK_ENABLE();
    TEST_CANFD_CLK_ENABLE();

    TEST_CANFD_FORCE_RESET();
    TEST_CANFD_RELEASE_RESET();
    TEST_CAN_GPIO_CLK_ENABLE();
}

/**
 * @brief  Configure the CAN TX / RX pins.
 * @note   Both pins are configured as alternate function push-pull: the
 *         transmit pin is driven by the controller and the receive pin is an
 *         input of the controller, and the direction is selected by the
 *         peripheral, not by the GPIO mode.  The receive pin keeps an internal
 *         pull-up so that a floating bus does not produce a permanent dominant
 *         level.
 * @param  None
 * @retval None
 */
static void Can_GpioInit(void)
{
    GPIO_InitTypeDef gpio;

    __HAL_CLEAR_STRUCT(&gpio);
    gpio.Size         = sizeof(gpio);
    gpio.Version      = GPIO_INIT_VERSION;
    gpio.Mode         = GPIO_MODE_AF_PP;
    gpio.Pull         = GPIO_NOPULL;
    gpio.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    gpio.Alternate    = TEST_CAN_AF;

    gpio.Pin = TEST_CAN_TX_PIN;
    HAL_GPIO_Init(TEST_CAN_TX_GPIO, &gpio);

    /* The transceiver drives RXD, so the RX pin must stay an input with a
     * pull-up; only the AF number selects the CAN function
     * (a push-pull output here would fight the transceiver and the
     * controller would never see a frame). */
    gpio.Mode = GPIO_MODE_INPUT;
    gpio.Pull = GPIO_PULLUP;
    gpio.Pin  = TEST_CAN_RX_PIN;
    HAL_GPIO_Init(TEST_CAN_TX_GPIO, &gpio);

    HAL_GPIO_PinAFConfig(TEST_CAN_TX_GPIO, TEST_CAN_TX_SOURCE, TEST_CAN_AF);
    HAL_GPIO_PinAFConfig(TEST_CAN_TX_GPIO, TEST_CAN_RX_SOURCE, TEST_CAN_AF);
}

/**
 * @brief  Fill the CAN FD init structure with the bit timing of the reference
 *         cases (500 kbit/s arbitration, 5 Mbit/s data phase).
 * @note   The driver takes register encodings, and the encoding of every
 *         prescaler / time segment is "value - 1"; the CANFD_xxx_VALUE()
 *         helpers apply that rule, so the numbers below are the physical
 *         time quantum counts of the reference cases.
 * @param  init: pointer to the structure to fill.
 * @retval None
 */
static void Can_InitStruct_Default(CANFD_InitTypeDef *init)
{
    HAL_CANFD_StructInit(init);

    init->CANFD_SRR         = CANFD_SRR_ENABLE;
    init->CANFD_APBRPR      = CANFD_APBRPR_PRESCALER(TEST_APBRPR_VALUE);
    init->CANFD_APBTR_APTS1 = CANFD_APBTR_TS1_VALUE(TEST_APTS1_VALUE);
    init->CANFD_APBTR_APTS2 = CANFD_APBTR_TS2_VALUE(TEST_APTS2_VALUE);
    init->CANFD_APBTR_APSJW = CANFD_APBTR_SJW_VALUE(TEST_APSJW_VALUE);
    init->CANFD_DPBRPR      = CANFD_DPBRPR_PRESCALER(TEST_DPBRPR_VALUE);
    init->CANFD_DPBTR_DPTS1 = CANFD_DPBTR_TS1_VALUE(TEST_DPTS1_VALUE);
    init->CANFD_DPBTR_DPTS2 = CANFD_DPBTR_TS2_VALUE(TEST_DPTS2_VALUE);
    init->CANFD_DPBTR_DPSJW = CANFD_DPBTR_SJW_VALUE(TEST_DPSJW_VALUE);
}

/**
 * @brief  Install the four acceptance filters of the reference cases.
 * @param  None
 * @retval None
 */
static void Can_SetAcceptanceFilters(void)
{
    CANFD_FilterConfigTypeDef filter;

    __HAL_CLEAR_STRUCT(&filter);
    filter.CANFD_FilterCmd = CANFD_ENABLE;

    filter.CANFD_FilterNumber = 0U;
    filter.CANFD_FilterMask   = TEST_FILTER_MASK_STD;
    filter.CANFD_FilterID     = TEST_FILTER_ID_1;
    (void)HAL_CANFD_FilterInit(&hcanfd_dev, &filter);

    filter.CANFD_FilterNumber = 1U;
    filter.CANFD_FilterMask   = TEST_FILTER_MASK_STD;
    filter.CANFD_FilterID     = TEST_FILTER_ID_2;
    (void)HAL_CANFD_FilterInit(&hcanfd_dev, &filter);

    filter.CANFD_FilterNumber = 2U;
    filter.CANFD_FilterMask   = TEST_FILTER_MASK_STD;
    filter.CANFD_FilterID     = TEST_FILTER_ID_3;
    (void)HAL_CANFD_FilterInit(&hcanfd_dev, &filter);

    filter.CANFD_FilterNumber = 3U;
    filter.CANFD_FilterMask   = TEST_FILTER_MASK_EXT;
    filter.CANFD_FilterID     = TEST_FILTER_ID_4;
    (void)HAL_CANFD_FilterInit(&hcanfd_dev, &filter);
}

/**
 * @brief  Initialize the CAN FD instance with the reference bit timing and
 *         install the acceptance filters.
 * @param  None
 * @retval HAL_OK on success, the driver status otherwise.
 */
static HAL_StatusTypeDef Can_Setup(void)
{
    CANFD_InitTypeDef init;
    HAL_StatusTypeDef status;

    __HAL_CLEAR_STRUCT(&hcanfd_dev);
    hcanfd_dev.Instance = TEST_CANFD;

    Can_InitStruct_Default(&init);
    hcanfd_dev.Init = init;

    status = HAL_CANFD_Init(&hcanfd_dev);
    if (status == HAL_OK)
    {
        Can_SetAcceptanceFilters();
    }

    return status;
}


/**
 * @brief  Override of the weak driver hook: bring the CAN FD instance up
 *         (clock gate, reset, pin multiplexing) once the configuration is
 *         known.
 * @note   LOCK-06: the driver calls this hook BEFORE it takes the handle lock,
 *         so calling HAL_GPIO_Init() from here is safe.
 * @param  hcanfd: CAN FD handle.
 * @retval None
 */
void HAL_CANFD_MspInit(CANFD_HandleTypeDef *hcanfd)
{
    if (hcanfd != &hcanfd_dev)
    {
        return;
    }

    Can_ClockEnable();
    Can_GpioInit();
}

/**
 * @brief  Configure the system clock tree using the HAL SMU driver.
 * @note   The CAN FD bit timing needs a CANCLK inside 8..80 MHz; with the
 *         vendor PLLR = 1 and CANX2DIV = 1 the controller runs at 80 MHz,
 *         which is exactly the frequency of the CAN FD reference cases.
 *         The core therefore runs at 160 MHz (VCO 160 MHz).
 * @note   Order: the bus dividers are written while the system clock is still
 *         the power-on source (FIRC), then the flash controller is programmed
 *         and the clock is switched by HAL_SMU_OscConfig().  Writing the
 *         dividers after the switch would leave the buses at their reset
 *         dividers for a moment at the new core clock.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   osc;
    SMU_ClockInitTypeDef clk;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the console USART needs AXI4Bus3 / APBBus0) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* 1.2 V / 2.5 V LDO trimming (the PMU API is gated on the handle state,
     * so the handle must be initialized first) */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Bus dividers first: the system clock is still FIRC here */
    clk.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV1;   /* 80 MHz */
    clk.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;    /* 40 MHz */
    clk.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;    /* 40 MHz */
    clk.CANX2CLKDiv    = SMU_CANX2CLK_DIV1;      /* CANCLK = PLLR / 2 = 80 MHz */
    (void)HAL_SMU_ClockConfig(&hsmu_clk, &clk);

    /* PLL: VCO 160 MHz, PLLR = 1 -> CANCLKx2 source 160 MHz */
    osc.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    osc.FIRCState            = SMU_FIRC_ON;
    osc.FIRCCalibrationValue = 0x00U;
    osc.PLL.PLLState         = SMU_PLL_ON;
    osc.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    osc.PLL.PLLDivR          = 0x01U;
    osc.PLL.PLLDivQ          = 0x01U;
    osc.PLL.PLLDivN          = 0x14U;
    osc.PLL.PLLDivF          = 0xA0U;
    osc.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    (void)HAL_SMU_OscConfig(&hsmu_clk, &osc, SMU_TIMEOUT_DEFAULT);
    (void)HAL_SMU_GetClocksFreq(&g_clocks);
}

/**
 * @brief  CAN FD interrupt handler of the instance under test.
 * @note   The driver has no interrupt dispatcher and no callbacks, so the
 *         application owns the interrupt service routine: it reads the pending
 *         sources, services them and clears them through the interrupt safe
 *         HAL_CANFD_ClearITPendingBit() (that interface takes no handle lock
 *         and applies no state gate, so it is usable from the ISR even while a
 *         task owns the handle).
 * @note   The receive FIFO is drained here, which is the intended use of the
 *         lock free read path HAL_CANFD_GetReceiveData().
 * @param  None
 * @retval None
 */
void CANFD3_IRQ_Handler(void)
{
    if (HAL_CANFD_GetITStatus(&hcanfd_dev, CANFD_IT_ERXOK) != 0U)
    {
        rx_ok_count++;
        rx_len = HAL_CANFD_GetReceiveData(&hcanfd_dev, rx_data);
        HAL_CANFD_ClearITPendingBit(&hcanfd_dev, CANFD_IT_ERXOK);
    }

    if (HAL_CANFD_GetITStatus(&hcanfd_dev, CANFD_IT_ETXOK) != 0U)
    {
        tx_ok_count++;
        HAL_CANFD_ClearITPendingBit(&hcanfd_dev, CANFD_IT_ETXOK);
    }

    if (HAL_CANFD_GetITStatus(&hcanfd_dev, CANFD_IT_EBSOFF) != 0U)
    {
        busoff_count++;
        HAL_CANFD_ClearITPendingBit(&hcanfd_dev, CANFD_IT_EBSOFF);
    }

    if (HAL_CANFD_GetITStatus(&hcanfd_dev, CANFD_IT_EWKUP) != 0U)
    {
        wakeup_count++;
        HAL_CANFD_ClearITPendingBit(&hcanfd_dev, CANFD_IT_EWKUP);
    }

    if (HAL_CANFD_GetITStatus(&hcanfd_dev, CANFD_IT_EERROR) != 0U)
    {
        error_count++;
        HAL_CANFD_ClearITPendingBit(&hcanfd_dev, CANFD_IT_EERROR);
    }

    /* An event that is not serviced above would keep the line asserted: clear
     * every remaining source of the enable register as a safety net */
    HAL_CANFD_ClearITPendingBit(&hcanfd_dev, CANFD_IT_ALL);
}

/*****END OF FILE*****/

int main(void)
{
    uint32 index;
    uint32 ok;
    uint32 dlc_read;
    uint32 dlc_want;

    /* The whole discrete CAN FD length set, one buffer per length.  The DLC
     * code of each length is the one the controller has to publish in the
     * length word of the transmit buffer. */
    static const uint32 length_table[8] = { CANFD_BYTES_0,  CANFD_BYTES_1,
                                            CANFD_BYTES_8,  CANFD_BYTES_12,
                                            CANFD_BYTES_16, CANFD_BYTES_32,
                                            CANFD_BYTES_48, CANFD_BYTES_64 };
    static const uint32 dlc_table[8]    = { CANFD_DLC_0B, CANFD_DLC_1B,
                                            CANFD_DLC_8B, CANFD_DLC_12B,
                                            CANFD_DLC_16B, CANFD_DLC_32B,
                                            CANFD_DLC_48B, CANFD_DLC_64B };

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (VCO 160 MHz, CANCLK 80 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);

    printf("\r\n=== CANFD_IT_DRV_010 : transmit length encoding sweep (DLC codes) ===\r\n");
    printf("clock    : core %u Hz, CANCLK %u Hz\r\n",
           PRINT_U32(SystemCoreClock), PRINT_U32(g_clocks.CANCLKx2_Frequency));
    printf("bit time : arbitration 500 kbit/s, data phase 5 Mbit/s\r\n");
    printf("PARTNER  : an external node is required (it acknowledges every frame\r\n");
    printf("           of the sweep); the subject of the case is the transmit\r\n");
    printf("           side, so no matching answer is needed\r\n");

    /* Step 1: initialize the controller */
    if (Can_Setup() != HAL_OK)
    {
        printf("HAL_CANFD_Init failed, error = 0x%08X\r\n",
               PRINT_U32(HAL_CANFD_GetError(&hcanfd_dev)));
        Summary();
        while (1)
        {
        }
    }

    Check("HAL_CANFD_Init : state = READY",
          (HAL_CANFD_GetState(&hcanfd_dev) == HAL_CANFD_STATE_READY));
    Check("HAL_CANFD_GetStatus : normal mode",
          (HAL_CANFD_GetStatus(&hcanfd_dev, CANFD_STATUS_NORMAL) != 0U));

    /* Step 2: every length of the discrete set is written into its own buffer,
     * and the length word of that buffer has to carry the matching DLC code.
     * This is the register level proof that the driver never rounds a length
     * up to the next legal code. */
    Can_CopyPattern(TEST_DATA_BYTES_FD);
    ok = 1U;

    for (index = 0U; index < 8U; index++)
    {
        Can_FrameInit(index, CANFD_PROTOCOL_CANFD, CANFD_FORMAT_STANDARD, TEST_STD_ID);

        /* clear the DLC field so that the value below can only come from the
         * transmit call (the frame configuration keeps the DLC intact) */
        TEST_CANFD->TxMessage[index].TB_DLC &= ~((uint32)CANFD_TB_DLC_DLC);

        if (HAL_CANFD_Transmit(&hcanfd_dev, index, tx_data, length_table[index],
                               TEST_TX_TIMEOUT_MS) != HAL_OK)
        {
            printf("  %u bytes : transmit refused\r\n", PRINT_U32(length_table[index]));
            ok = 0U;
            continue;
        }

        dlc_read = (TEST_CANFD->TxMessage[index].TB_DLC & CANFD_TB_DLC_DLC)
                   >> CANFD_TB_DLC_DLC_Pos;
        dlc_want = dlc_table[index];
        printf("  %2u bytes -> DLC = %u (expected %u)\r\n",
               PRINT_U32(length_table[index]), PRINT_U32(dlc_read), PRINT_U32(dlc_want));
        if (dlc_read != dlc_want)
        {
            ok = 0U;
        }

        if (Can_WaitSendComplete(index, TEST_WAIT_FRAME_MS) == 0U)
        {
            printf("  %u bytes : request not served\r\n", PRINT_U32(length_table[index]));
            ok = 0U;
        }
    }

    Check("transmit sweep : every discrete CAN FD length accepted", (ok != 0U));
    Check("transmit sweep : the DLC code matches the length", (ok != 0U));
    Print_ErrorCounters();

    /* Step 3: lengths outside the discrete set must be refused and must not be
     * rounded up (9, 10, 63 and 65 bytes are not legal CAN FD lengths) */
    Check("transmit : 9 bytes refused",
          (HAL_CANFD_Transmit(&hcanfd_dev, 0U, tx_data, 9U, TEST_TX_TIMEOUT_MS) == HAL_ERROR));
    Check("transmit : 10 bytes refused",
          (HAL_CANFD_Transmit(&hcanfd_dev, 0U, tx_data, 10U, TEST_TX_TIMEOUT_MS) == HAL_ERROR));
    Check("transmit : 63 bytes refused",
          (HAL_CANFD_Transmit(&hcanfd_dev, 0U, tx_data, 63U, TEST_TX_TIMEOUT_MS) == HAL_ERROR));
    Check("transmit : 65 bytes refused",
          (HAL_CANFD_Transmit(&hcanfd_dev, 0U, tx_data, 65U, TEST_TX_TIMEOUT_MS) == HAL_ERROR));

    /* Step 4: a classic CAN frame accepts 0..8 bytes only, so a 12 byte classic
     * frame must be refused while the same buffer accepts 8 bytes */
    Can_FrameInit(0U, CANFD_PROTOCOL_CAN, CANFD_FORMAT_STANDARD, TEST_STD_ID);
    Check("transmit : a classic frame with 12 bytes refused",
          (HAL_CANFD_Transmit(&hcanfd_dev, 0U, tx_data, CANFD_BYTES_12,
                              TEST_TX_TIMEOUT_MS) == HAL_ERROR));
    Check("transmit : a classic frame with 8 bytes accepted",
          (HAL_CANFD_Transmit(&hcanfd_dev, 0U, tx_data, CANFD_BYTES_8,
                              TEST_TX_TIMEOUT_MS) == HAL_OK));
    (void)Can_WaitSendComplete(0U, TEST_WAIT_FRAME_MS);

    /* Step 5: a rejected length must leave the DLC field of the buffer as it
     * was, so that the frame of that buffer cannot be sent with a wrong code */
    Can_FrameInit(1U, CANFD_PROTOCOL_CANFD, CANFD_FORMAT_STANDARD, TEST_STD_ID);
    TEST_CANFD->TxMessage[1].TB_DLC &= ~((uint32)CANFD_TB_DLC_DLC);
    TEST_CANFD->TxMessage[1].TB_DLC |= ((uint32)CANFD_DLC_16B << CANFD_TB_DLC_DLC_Pos);
    (void)HAL_CANFD_Transmit(&hcanfd_dev, 1U, tx_data, 33U, TEST_TX_TIMEOUT_MS);
    Check("transmit : a rejected length leaves the DLC field untouched",
          (((TEST_CANFD->TxMessage[1].TB_DLC & CANFD_TB_DLC_DLC) >> CANFD_TB_DLC_DLC_Pos)
           == CANFD_DLC_16B));

    /* Step 6: a remote frame carries no payload, so the length rules of the
     * data frames do not apply to it (configured as a classic remote frame) */
    Can_FrameInit(2U, CANFD_PROTOCOL_CAN, CANFD_FORMAT_STANDARD, TEST_STD_ID);
    {
        CANFD_TXFrameTypeDef frame;

        HAL_CANFD_FrameStructInit(&frame);
        frame.CANFD_TX_PROTOCOL = CANFD_PROTOCOL_CAN;
        frame.CANFD_TX_FORMAT   = CANFD_FORMAT_STANDARD;
        frame.CANFD_TX_TYPE     = CANFD_TYPE_REMOTE;
        frame.CANFD_Frame_ID    = TEST_STD_ID;
        HAL_CANFD_FrameInit(&hcanfd_dev, 2U, &frame);
    }
    Check("transmit : a classic remote frame is accepted with a NULL payload",
          (HAL_CANFD_Transmit(&hcanfd_dev, 2U, NULL_PTR, CANFD_BYTES_0,
                              TEST_TX_TIMEOUT_MS) == HAL_OK));
    (void)Can_WaitSendComplete(2U, TEST_WAIT_FRAME_MS);

    Print_ErrorCounters();
    Summary();

    printf("-- monitoring (reset the board to run the checks again)\r\n");
    while (1)
    {
        if (HAL_CANFD_GetRxFillLevel(&hcanfd_dev) != 0U)
        {
            (void)HAL_CANFD_GetReceiveData(&hcanfd_dev, rx_data);
        }
    }
}

