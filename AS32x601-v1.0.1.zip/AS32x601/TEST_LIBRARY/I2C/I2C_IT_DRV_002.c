/**
 * @file    I2C_IT_DRV_002.c
 * @brief   HAL I2C integration test case 002 (master receive at 100 kHz and 400 kHz).
 *
 * One-to-one HAL library port of the original AS32x601 standard-library test
 * case I2C_IT_DRV_002.c. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_I2C_StructInit()
 *   HAL_I2C_Init()              (I2C1, SCL = GPIOF pin 15,
 *                                SDA = GPIOF pin 13,
 *                                alternate function IIC1)
 *   HAL_I2C_Master_Receive()    (blocking, 1000 ms budget per transfer)
 *   HAL_I2C_DeInit() / HAL_I2C_GetState() / HAL_I2C_GetError()
 *
 * Test procedure:
 *   1. Apply the standard clock tree (PLL 180 MHz, AXI4Bus3 /2, APBBus0 /2,
 *      APBBus1 /2, CANCLKx2 /8, so APBBus0 = 22.5 MHz) and initialize the
 *      console at 115200 Bd;
 *   2. Run the transfer twice in one pass, first with the 100 kHz divider and
 *      then with the 400 kHz divider;
 *   3. Each round re-initializes I2C1 (de-initialize first, so the low
 *      level initialization runs again) and receives 64 bytes from slave
 *      address 0x55, printing them as 16 bytes per line;
 *   4. Report the result of each round and the register read back.
 *
 * Expected behaviour:
 *   - SCL on GPIOF pin 15: about 100 kHz in round 1 and
 *     about 400 kHz in round 2 (scope or logic analyzer);
 *   - with a slave at 0x55 the console prints "I2C Master Receive Success!"
 *     followed by the 64 received bytes, otherwise "I2C Master Receive
 *     Failed!";
 *   - the divider registers read back the programmed value and the last line
 *     reads "summary : failures = N" (N counts the configuration checks only).
 *
 * Notes (deliberate adaptations of this port):
 *   - the divider values are recomputed for this library's clock tree.  With
 *     no documented divider formula the value follows
 *     I2C clock = PCLK / 8 / DIV, i.e. 2.8125 MHz / 28 = 100.4 kHz and
 *     2.8125 MHz / 7 = 401.8 kHz; the firmware prints the estimate it derives
 *     from the divider it programmed and the real frequency is measured on the
 *     pin;
 *   - the original test case asked the operator to type the rate on the
 *     console and waited for ever; this port scans the rates in one run, which
 *     covers more and needs no terminal.
 *
 * Note: slave must be present on the bus for the transfer to complete; with
 * no slave the call reports an error after its timeout instead of hanging.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Budget of one blocking transfer */
#define TEST_TIMEOUT_MS             (1000U)

/* Standard clock tree (the same tree the other HAL integration suites use) */
#define STD_PLL_DIV_R               (0x04U)
#define STD_PLL_DIV_Q               (0x01U)
#define STD_PLL_DIV_N               (0x14U)
#define STD_PLL_DIV_F               (0xB4U)
#define STD_AXI4BUS3_DIV            SMU_AXI4BUS3CLK_DIV2
#define STD_APBBUS0_DIV             SMU_APBBUS0CLK_DIV2
#define STD_APBBUS1_DIV             SMU_APBBUS1CLK_DIV2
#define STD_CANX2_DIV               SMU_CANX2CLK_DIV8

/* ---------------------- parameters of this test case --------------------- */
#define TEST_I2C                    I2C1
#define TEST_SCL_PORT               GPIOF
#define TEST_SCL_PIN                GPIO_PIN_15
#define TEST_SCL_SOURCE             GPIO_PinSource15
#define TEST_SDA_PORT               GPIOF
#define TEST_SDA_PIN                GPIO_PIN_13
#define TEST_SDA_SOURCE             GPIO_PinSource13
#define TEST_AF                     GPIO_AF_IIC1

/* Own slave address and peer (slave) address of the original test case */
#define TEST_OWN_ADDRESS            (0x5AU)
#define TEST_PEER_ADDRESS           (0x55U)

/* Transfer size of the original test case */
#define TEST_SIZE                   (64U)

/* Divider values for a 22.5 MHz APB clock: I2C clock = APB / 8 = 2.8125 MHz,
 * DIV 28 -> 100.4 kHz, DIV 7 -> 401.8 kHz */
#define TEST_DIV_100K               (0x1CU)
#define TEST_DIV_400K               (0x07U)
#define TEST_DIV_H                  (0x00U)

/* Number of rate rounds */
#define TEST_ROUNDS                 (2U)

/* Private variables -------------------------------------------------------*/
static I2C_HandleTypeDef hi2c_dev;          /*!< I2C handle                   */
static HAL_PMU_HandleTypeDef hpmu_dev;      /*!< PMU handle (LDO scaler)      */
static uint8  I2C_BufferTx[TEST_SIZE];      /*!< transmit buffer              */
static uint8  I2C_BufferRx[TEST_SIZE];      /*!< receive buffer               */
static uint32 g_failures;                   /*!< collected failures           */

/* Divider of each round, and the label printed for it */
static const uint32 g_div[TEST_ROUNDS]   = { TEST_DIV_100K, TEST_DIV_400K };
static const char  *g_rate[TEST_ROUNDS]  = { "100K", "400K" };

/* Private function prototypes ---------------------------------------------*/
static void   SystemClock_Init(void);
static void   I2C_Config(uint32 Divider);
static void   Buffer_Init(void);
static uint32 RunRound(uint32 Divider, const char *Rate);
static uint32 Chk(const char *name, uint32 expect, uint32 actual);
static void   Info(const char *name, uint32 value);

static void   Print_RxBuffer(void);
/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    uint32 i;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Clock tree and console */
    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);

    printf("\r\n=== I2C_IT_DRV_002: master receive at 100 kHz and 400 kHz ===\r\n");
    printf("APBBus0 = %u Hz\r\n", PRINT_U32(HAL_SMU_GetPCLK0Freq()));

    /* Transmit buffer contents 0x00..0x3F */
    Buffer_Init();

    /* The two rate rounds */
    for (i = 0U; i < TEST_ROUNDS; i++)
    {
        printf("\r\n--- round %u: %s (divider 0x%02X) ---\r\n",
               PRINT_U32(i + 1U), g_rate[i], PRINT_U32(g_div[i]));
        g_failures += RunRound(g_div[i], g_rate[i]);
    }

    /* RunRound() leaves the controller initialized and enabled, so it has to be
     * de-initialized here before the reset state of the configuration
     * registers can be checked */
    (void)HAL_I2C_DeInit(&hi2c_dev);
    g_failures += Chk("controller disabled after HAL_I2C_DeInit()", 0U,
                      (uint32)((TEST_I2C->CTLR & I2C_CTRL_EN) ? 1U : 0U));
    g_failures += Chk("handle state is RESET after HAL_I2C_DeInit()",
                      (uint32)HAL_I2C_STATE_RESET,
                      (uint32)HAL_I2C_GetState(&hi2c_dev));

    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(g_failures));

    while (1)
    {
    }
}

/**
 * @brief  Initialize the clock tree, the SMU / PMU handles and the bus gates.
 * @note   Dividers first (the system clock is still the FIRC), then
 *         HAL_SMU_OscConfig(), which programs the flash controller clock,
 *         switches the system clock and performs the flash clock update.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    osc;
    SMU_ClockInitTypeDef  clk;
    HAL_SMU_HandleTypeDef hsmu;
    SMU_ClocksTypeDef     clocks;

    /* Bus clock gates used by this case */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();

    /* PMU: the LDO APIs are gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu_dev);
    hpmu_dev.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu_dev);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu_dev, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu_dev, PMU_VO12_1V34);

    /* SMU handle */
    __HAL_CLEAR_STRUCT(&hsmu);
    hsmu.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu);

    /* Bus dividers of the standard tree */
    __HAL_CLEAR_STRUCT(&clk);
    clk.Size           = sizeof(clk);
    clk.Version        = SMU_CLOCK_INIT_VERSION;
    clk.AXI4Bus3CLKDiv = STD_AXI4BUS3_DIV;
    clk.APBBus0CLKDiv  = STD_APBBUS0_DIV;
    clk.APBBus1CLKDiv  = STD_APBBUS1_DIV;
    clk.CANX2CLKDiv    = STD_CANX2_DIV;
    (void)HAL_SMU_ClockConfig(&hsmu, &clk);

    /* PLL from the OSC, then switch the system clock to it */
    __HAL_CLEAR_STRUCT(&osc);
    osc.Size                 = sizeof(osc);
    osc.Version              = SMU_OSC_INIT_VERSION;
    osc.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    osc.FIRCState            = SMU_FIRC_ON;
    osc.FIRCCalibrationValue = 0x00U;
    osc.PLL.Size             = sizeof(osc.PLL);
    osc.PLL.Version          = SMU_PLL_INIT_VERSION;
    osc.PLL.PLLState         = SMU_PLL_ON;
    osc.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    osc.PLL.PLLDivR          = STD_PLL_DIV_R;
    osc.PLL.PLLDivQ          = STD_PLL_DIV_Q;
    osc.PLL.PLLDivN          = STD_PLL_DIV_N;
    osc.PLL.PLLDivF          = STD_PLL_DIV_F;
    osc.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;
    (void)HAL_SMU_OscConfig(&hsmu, &osc, SMU_TIMEOUT_DEFAULT);

    (void)HAL_SMU_GetClocksFreq(&clocks);
}

/**
 * @brief  Low level initialization of the I2C peripheral (weak override).
 * @note   The driver calls this from HAL_I2C_Init() before the first register
 *         access and only while the handle is in the RESET state (MSP-04 /
 *         LOCK-06), so the clock gate and the pin multiplexing are in place in
 *         time.  Every round de-initializes the handle first, which is what
 *         makes the callback run again for the second rate.
 * @param  hi2c: I2C handle.
 * @retval None
 */
void HAL_I2C_MspInit(I2C_HandleTypeDef *hi2c)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    if (hi2c->Instance != TEST_I2C)
    {
        return;
    }

    /* Peripheral clock gate and a reset pulse */
    __HAL_SMU_IIC1_CLK_ENABLE();
    __HAL_SMU_IIC1_FORCE_RESET();
    __HAL_SMU_IIC1_RELEASE_RESET();

    /* GPIO port clock of the two pins */
    __HAL_SMU_GPIOF_CLK_ENABLE();

    /* Alternate function mapping */
    HAL_GPIO_PinAFConfig(TEST_SCL_PORT, TEST_SCL_SOURCE, TEST_AF);
    HAL_GPIO_PinAFConfig(TEST_SDA_PORT, TEST_SDA_SOURCE, TEST_AF);

    /* SCL and SDA: alternate function, open drain (pulled up on the bus) */
    __HAL_CLEAR_STRUCT(&GPIO_InitStruct);
    GPIO_InitStruct.Size         = sizeof(GPIO_InitStruct);
    GPIO_InitStruct.Version      = GPIO_INIT_VERSION;
    GPIO_InitStruct.Pin          = TEST_SCL_PIN;
    GPIO_InitStruct.Mode         = GPIO_MODE_AF_OD;
    GPIO_InitStruct.Pull         = GPIO_PULLUP;
    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;
    GPIO_InitStruct.Alternate    = TEST_AF;
    HAL_GPIO_Init(TEST_SCL_PORT, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = TEST_SDA_PIN;
    HAL_GPIO_Init(TEST_SDA_PORT, &GPIO_InitStruct);
}

/**
 * @brief  Low level de-initialization of the I2C peripheral (weak override).
 * @param  hi2c: I2C handle.
 * @retval None
 */
void HAL_I2C_MspDeInit(I2C_HandleTypeDef *hi2c)
{
    if (hi2c->Instance != TEST_I2C)
    {
        return;
    }

    __HAL_SMU_IIC1_CLK_DISABLE();
}

/**
 * @brief  Initialize the I2C peripheral with the selected divider.
 * @param  Divider: value written to the low divider register.
 * @retval None
 */
static void I2C_Config(uint32 Divider)
{
    I2C_InitTypeDef I2C_InitStruct;

    __HAL_CLEAR_STRUCT(&I2C_InitStruct);
    I2C_InitStruct.Size             = sizeof(I2C_InitStruct);
    I2C_InitStruct.Version          = I2C_INIT_VERSION;
    I2C_InitStruct.I2C_ClockScale   = I2C_CLOCKSCALE_PCLK_8;
    I2C_InitStruct.I2C_ICLKDIVL     = (uint8)Divider;
    I2C_InitStruct.I2C_ICLKDIVH     = (uint8)TEST_DIV_H;
    I2C_InitStruct.I2C_EN           = I2C_ENABLE;
    I2C_InitStruct.I2C_SlaveAddress = TEST_OWN_ADDRESS;
    I2C_InitStruct.I2C_Ack          = I2C_ACK;

    hi2c_dev.Instance = TEST_I2C;
    hi2c_dev.Init     = I2C_InitStruct;
    (void)HAL_I2C_Init(&hi2c_dev);
}

/**
 * @brief  Fill the transmit buffer with 0x00..0x3F.
 * @param  None
 * @retval None
 */
static void Buffer_Init(void)
{
    uint16 index;

    for (index = 0U; index < TEST_SIZE; index++)
    {
        I2C_BufferTx[index] = (uint8)index;
    }
}

/**
 * @brief  Print the receive buffer, 16 bytes per line.
 * @param  None
 * @retval None
 */
static void Print_RxBuffer(void)
{
    uint16 index;

    for (index = 0U; index < TEST_SIZE; index++)
    {
        printf("0x%02X ", PRINT_U32(I2C_BufferRx[index]));

        if (((index + 1U) % 16U) == 0U)
        {
            printf("\r\n");
        }
    }
    printf("\r\n");
}

/**
 * @brief  Run one rate round: re-initialize, transfer, check, de-initialize.
 * @param  Divider: value written to the low divider register.
 * @param  Rate: label of the round ("100K" / "400K"), used for the report.
 * @retval uint32: number of failed configuration checks of this round.
 */
static uint32 RunRound(uint32 Divider, const char *Rate)
{
    uint32 failures = 0U;
    HAL_StatusTypeDef status;

    (void)Rate;

    /* Back to RESET so that the low level initialization runs again */
    if (HAL_I2C_GetState(&hi2c_dev) != HAL_I2C_STATE_RESET)
    {
        (void)HAL_I2C_DeInit(&hi2c_dev);
    }

    I2C_Config(Divider);

    status = HAL_I2C_Master_Receive(&hi2c_dev, TEST_PEER_ADDRESS,
                                    I2C_BufferRx, TEST_SIZE, TEST_TIMEOUT_MS);
    if (status == HAL_OK)
    {
        printf("I2C Master Receive Success!\r\n");
        printf("Received Data:\r\n");
        Print_RxBuffer();
    }
    else
    {
        printf("I2C Master Receive Failed! (status = %u)\r\n",
               PRINT_U32((uint32)status));
    }

    /* Configuration read back (independent of the peer) */
    failures += Chk("DIV_L holds the selected divider", Divider, (uint32)TEST_I2C->DIV_L);
    failures += Chk("DIV_H holds the high divider byte", (uint32)TEST_DIV_H,
                    (uint32)TEST_I2C->DIV_H);
    failures += Chk("own slave address programmed",
                    (uint32)(TEST_OWN_ADDRESS << 1U), (uint32)TEST_I2C->ADDR);
    failures += Chk("controller enabled", 1U,
                    (uint32)((TEST_I2C->CTLR & I2C_CTRL_EN) ? 1U : 0U));

    /* I2C-REQ-018: the receive sequence asserts NACK for the last byte, so a
     * completed transfer deliberately leaves the acknowledge flag cleared.
     * That is why this is not a configuration read back of the value
     * HAL_I2C_Init() programmed: it checks the end of the transfer sequence.
     * A transfer that reported an error stopped at an arbitrary point of the
     * sequence, so there the flag is only reported, not judged. */
    if (status == HAL_OK)
    {
        failures += Chk("last byte answered with NACK (AA cleared by the sequence)",
                        0U, (uint32)((TEST_I2C->CTLR & I2C_CTRL_AA) ? 1U : 0U));
    }
    else
    {
        Info("AA flag left by the failed transfer =",
             (uint32)((TEST_I2C->CTLR & I2C_CTRL_AA) ? 1U : 0U));
    }

    failures += Chk("handle state is READY", (uint32)HAL_I2C_STATE_READY,
                    (uint32)HAL_I2C_GetState(&hi2c_dev));
    Info("SCL estimate (Hz) =", HAL_SMU_GetPCLK0Freq() / 8U / Divider);
    Info("error code =", HAL_I2C_GetError(&hi2c_dev));

    return failures;
}
/**
 * @brief  Print one check and return the number of failures it contributes.
 * @param  name: check description.
 * @param  expect: expected value.
 * @param  actual: value read back.
 * @retval uint32: 0 when the check passed, 1 otherwise.
 */
static uint32 Chk(const char *name, uint32 expect, uint32 actual)
{
    uint32 fail = 0U;

    if (expect == actual)
    {
        printf("  [PASS] %s : expect %u, read %u\r\n",
               name, PRINT_U32(expect), PRINT_U32(actual));
    }
    else
    {
        printf("  [FAIL] %s : expect %u, read %u\r\n",
               name, PRINT_U32(expect), PRINT_U32(actual));
        fail = 1U;
    }

    return fail;
}

/**
 * @brief  Print a value without judging it.
 * @param  name: label.
 * @param  value: value to print.
 * @retval None
 */
static void Info(const char *name, uint32 value)
{
    printf("  [info] %s %u\r\n", name, PRINT_U32(value));
}

/*****END OF FILE*****/
