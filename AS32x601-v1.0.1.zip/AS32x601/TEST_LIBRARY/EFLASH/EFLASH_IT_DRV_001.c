/**
 * @file    EFLASH_IT_DRV_001.c
 * @brief   HAL EFLASH integration test case 001 (sector erase, program and read back).
 *
 * HAL port of the reference test case Eflash_IT_DRV_001: only HAL APIs are used.
 *
 * Tested functionality:
 *   HAL_FLASH_StructInit() / HAL_FLASH_Init() / HAL_FLASH_DeInit()
 *   HAL_FLASH_Unlock() / HAL_FLASH_Lock()
 *   HAL_FLASH_Erase() / HAL_FLASH_Program() / HAL_FLASH_Read()
 *   HAL_FLASH_GetFlagStatus() / HAL_FLASH_GetState() / HAL_FLASH_GetError()
 *
 * Test procedure:
 *   1. initialize the driver (metadata filled by HAL_FLASH_StructInit) and
 *      unlock the controller registers;
 *   2. erase one P-Flash sector at 0x01100000 and one D-Flash sector at
 *      0x02000000 (both far from the running image);
 *   3. read 512 bytes of each erased sector and require 0xFFFFFFFF everywhere
 *      (the erased value), with no error code recorded;
 *   4. program 512 bytes (64 program rows of 8 bytes) into both sectors;
 *   5. read the 512 bytes back and compare them against the source buffer;
 *   6. lock the controller (the LOCK flag must read back set) and de-initialize.
 *
 * Expected behaviour:
 *   every HAL call returns HAL_OK, the erased sectors read back as 0xFFFFFFFF,
 *   the programmed data is read back unchanged and
 *   "summary : failures = 0" is printed.
 *
 * Note:
 *   The two test addresses are 1 MB (P-Flash) and 0 (D-Flash) away from the
 *   running image, so the case never erases the code that is executing. Both
 *   sectors are only used by this suite.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define -----------------------------------------------------------*/
#define TEST_BAUDRATE                  (115200U)      /*!< console baud rate   */
#define TEST_PFLASH_SECTOR             (0x01100000U)  /*!< P-Flash test sector */
#define TEST_DFLASH_SECTOR             (0x02000000U)  /*!< D-Flash test sector */
#define TEST_PATTERN_WORDS             (128U)         /*!< 512 bytes           */
#define TEST_ROUND_DELAY_MS            (2000U)        /*!< delay between runs  */

/* Private variables ---------------------------------------------------------*/
static volatile uint32 check_failures = 0U;   /*!< failed check counter        */
static HAL_SMU_HandleTypeDef hsmu_clk;        /*!< SMU handle (clock tree)     */
static HAL_FLASH_HandleTypeDef hflash_dev;    /*!< FLASH handle of this case   */

/**
 * @brief  Source pattern: 128 words built from a simple formula so that the
 *         comparison also proves the word order (no duplicated value).
 */
static uint32 program_data[TEST_PATTERN_WORDS];

/**
 * @brief  Read back buffer.
 */
static uint32 read_data[TEST_PATTERN_WORDS];

/* Shared helpers of this suite (defined at the end of this file) */
void Check(const char *name, uint32 condition);
void Summary(void);
void SystemClock_Init(void);
void Flash_InitDevice(void);
void FillPattern(void);
uint32 BufferEquals(const uint32 *a, const uint32 *b, uint32 words);
uint32 BufferIsErased(const uint32 *buf, uint32 words);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    FLASH_EraseInitTypeDef erase;
    HAL_StatusTypeDef      status;
    uint32                 addr_error;
    uint32                 i;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz, APB 22.5 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== EFLASH_IT_DRV_001 : sector erase, program and read back ===\r\n");

    /* ---- 1. driver initialization and controller unlock ------------------- */
    Flash_InitDevice();
    Check("HAL_FLASH_Init publishes the READY state",
          (HAL_FLASH_GetState(&hflash_dev) == HAL_FLASH_STATE_READY) ? 1U : 0U);
    Check("HAL_FLASH_Init leaves no error behind",
          (HAL_FLASH_GetError(&hflash_dev) == HAL_FLASH_ERROR_NONE) ? 1U : 0U);

    status = HAL_FLASH_Unlock(&hflash_dev);
    Check("HAL_FLASH_Unlock returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("the controller LOCK flag is cleared after the unlock",
          (HAL_FLASH_GetFlagStatus(&hflash_dev, FLASH_FLAG_LOCK) == FLASH_FLAG_RESET) ? 1U : 0U);

    /* ---- 2. erase one sector of each main region -------------------------- */
    FillPattern();

    erase.TypeErase = FLASH_TYPEERASE_SECTORS;
    erase.Address   = TEST_PFLASH_SECTOR;
    erase.Length    = PFLASH_SECTOR_SIZE;
    addr_error      = 0xFFFFFFFFU;
    status = HAL_FLASH_Erase(&hflash_dev, &erase, &addr_error);
    Check("P-Flash sector erase returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("P-Flash sector erase reports no failing unit",
          (addr_error == 0xFFFFFFFFU) ? 1U : 0U);
    Check("P-Flash erase leaves the handle READY",
          (HAL_FLASH_GetState(&hflash_dev) == HAL_FLASH_STATE_READY) ? 1U : 0U);

    erase.TypeErase = FLASH_TYPEERASE_SECTORS;
    erase.Address   = TEST_DFLASH_SECTOR;
    erase.Length    = DFLASH_SECTOR_SIZE;
    addr_error      = 0xFFFFFFFFU;
    status = HAL_FLASH_Erase(&hflash_dev, &erase, &addr_error);
    Check("D-Flash sector erase returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("D-Flash sector erase reports no failing unit",
          (addr_error == 0xFFFFFFFFU) ? 1U : 0U);

    /* ---- 3. the erased sectors must read back as 0xFFFFFFFF ---------------- */
    status = HAL_FLASH_Read(&hflash_dev, TEST_PFLASH_SECTOR, 512U, read_data);
    Check("P-Flash read after the erase returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("P-Flash erased sector reads back as 0xFFFFFFFF",
          BufferIsErased(read_data, TEST_PATTERN_WORDS));

    status = HAL_FLASH_Read(&hflash_dev, TEST_DFLASH_SECTOR, 512U, read_data);
    Check("D-Flash read after the erase returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("D-Flash erased sector reads back as 0xFFFFFFFF",
          BufferIsErased(read_data, TEST_PATTERN_WORDS));

    /* ---- 4. program 512 bytes into both sectors --------------------------- */
    status = HAL_FLASH_Program(&hflash_dev, TEST_PFLASH_SECTOR, 512U, program_data);
    Check("P-Flash program returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("P-Flash program leaves no error code",
          (HAL_FLASH_GetError(&hflash_dev) == HAL_FLASH_ERROR_NONE) ? 1U : 0U);

    status = HAL_FLASH_Program(&hflash_dev, TEST_DFLASH_SECTOR, 512U, program_data);
    Check("D-Flash program returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("D-Flash program leaves no error code",
          (HAL_FLASH_GetError(&hflash_dev) == HAL_FLASH_ERROR_NONE) ? 1U : 0U);

    /* ---- 5. read back and compare ----------------------------------------- */
    for (i = 0U; i < TEST_PATTERN_WORDS; i++)
    {
        read_data[i] = 0U;
    }
    status = HAL_FLASH_Read(&hflash_dev, TEST_PFLASH_SECTOR, 512U, read_data);
    Check("P-Flash read back returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("P-Flash content equals the programmed pattern",
          BufferEquals(read_data, program_data, TEST_PATTERN_WORDS));

    for (i = 0U; i < TEST_PATTERN_WORDS; i++)
    {
        read_data[i] = 0U;
    }
    status = HAL_FLASH_Read(&hflash_dev, TEST_DFLASH_SECTOR, 512U, read_data);
    Check("D-Flash read back returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("D-Flash content equals the programmed pattern",
          BufferEquals(read_data, program_data, TEST_PATTERN_WORDS));

    /* ---- 6. lock the controller and tear the driver down ------------------ */
    status = HAL_FLASH_Lock(&hflash_dev);
    Check("HAL_FLASH_Lock returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("the controller LOCK flag is set after the lock",
          (HAL_FLASH_GetFlagStatus(&hflash_dev, FLASH_FLAG_LOCK) == FLASH_FLAG_SET) ? 1U : 0U);

    status = HAL_FLASH_DeInit(&hflash_dev);
    Check("HAL_FLASH_DeInit returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("HAL_FLASH_DeInit publishes the RESET state",
          (HAL_FLASH_GetState(&hflash_dev) == HAL_FLASH_STATE_RESET) ? 1U : 0U);

    Summary();

    for (;;)
    {
        delay_ms(TEST_ROUND_DELAY_MS);
    }
}

/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Fill the source pattern with a position dependent value.
 * @note   A formula is used instead of a constant table so that a word that
 *         was programmed at a wrong offset cannot coincide with the source.
 * @param  None
 * @retval None
 */
void FillPattern(void)
{
    uint32 i;

    for (i = 0U; i < TEST_PATTERN_WORDS; i++)
    {
        program_data[i] = (0x01020304U + (i * 0x01010101U)) ^ (i << 24);
    }
}

/**
 * @brief  Compare two word buffers.
 * @param  a: first buffer
 * @param  b: second buffer
 * @param  words: number of words to compare
 * @retval uint32: 1 when equal, 0 otherwise
 */
uint32 BufferEquals(const uint32 *a, const uint32 *b, uint32 words)
{
    uint32 i;

    for (i = 0U; i < words; i++)
    {
        if (a[i] != b[i])
        {
            printf("  mismatch at word %u : 0x%08X / 0x%08X\r\n",
               (unsigned)i, (unsigned)a[i], (unsigned)b[i]);
            return 0U;
        }
    }

    return 1U;
}

/**
 * @brief  Check that a buffer only holds the erased value.
 * @param  buf: buffer to check
 * @param  words: number of words to check
 * @retval uint32: 1 when every word is 0xFFFFFFFF, 0 otherwise
 */
uint32 BufferIsErased(const uint32 *buf, uint32 words)
{
    uint32 i;

    for (i = 0U; i < words; i++)
    {
        if (buf[i] != 0xFFFFFFFFU)
        {
            printf("  word %u is 0x%08X instead of 0xFFFFFFFF\r\n",
               (unsigned)i, (unsigned)buf[i]);
            return 0U;
        }
    }

    return 1U;
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the other integration tests of this library:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2 and
 *         CANX2 by 8, which gives core 180 MHz and APB 22.5 MHz (the console
 *         USART is clocked from APBBus0).
 * @note   Clock tree order: the dividers are written while the system clock
 *         is still the power on source (FIRC), then the PLL is configured and
 *         the system clock is switched to it. That last call programs the
 *         flash controller clock (CR.CLKFRQ) before the switch, which is what
 *         the EFLASH controller needs to keep fetching the running image.
 * @param  None
 * @retval None
 */
void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks (console pins of USART0 on GPIOD) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Initialize the FLASH driver handle of this suite.
 * @note   The metadata (Size / Version / Reserved) is filled by
 *         HAL_FLASH_StructInit(): HAL_FLASH_Init() validates it before it
 *         touches the controller, so a structure that was not filled this way
 *         is rejected with HAL_FLASH_ERROR_PARAM.
 * @note   ClockFreq is the AXI_Bus0 frequency in MHz. The system clock setup
 *         already programmed CR.CLKFRQ, so the value matches the current one
 *         and the driver skips the switch (the read back below proves it).
 * @param  None
 * @retval None
 */
void Flash_InitDevice(void)
{
    __HAL_CLEAR_STRUCT(&hflash_dev);
    hflash_dev.Instance = EFLASH;
    HAL_FLASH_StructInit(&hflash_dev.Init);
    hflash_dev.Init.ClockFreq = (uint32)(SystemCoreClock / 1000000U);
    (void)HAL_FLASH_Init(&hflash_dev);
}

/*****END OF FILE*****/
