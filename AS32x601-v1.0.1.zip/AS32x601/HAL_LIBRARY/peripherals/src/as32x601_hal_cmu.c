/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_cmu.c
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.4
 * Date:   2026/10/09
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.1     expose the shared lock
 *                                                       helpers CMU_LockHandle /
 *                                                       CMU_UnlockHandle (the
 *                                                       RTOS branch uses the
 *                                                       LockMutex handle) and
 *                                                       protect every register
 *                                                       writing function with
 *                                                       them (Init / DeInit /
 *                                                       Cmd / SetMode /
 *                                                       SetWindowLength /
 *                                                       SetReferenceThreshold /
 *                                                       ClearFlag); the read-only
 *                                                       functions stay lock-free
 *     ANSILIC APPLICATION GROUP  2026/09/11     1.2     fix the polarity of the CMU reset bit
 *                                                       in HAL_CMU_MspInit (the reset is
 *                                                       released by setting the bit, not by
 *                                                       clearing it)
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.3     apply the resource lock / RTOS rules:
 *                                                       run the MSP callbacks outside the
 *                                                       locked region, add a Timeout and a
 *                                                       NULL-mutex guard to the lock helper,
 *                                                       add the busy / reset state gate,
 *                                                       return HAL_StatusTypeDef from the
 *                                                       control setters with run-time
 *                                                       parameter validation, drop the unused
 *                                                       timeout error code
 *     ANSILIC APPLICATION GROUP  2026/10/09     1.4     merge the capabilities of the System
 *                                                       Management release of 2026/09/29 into
 *                                                       this driver: add the window length
 *                                                       lower bound CMU_WINLEN_MIN (the
 *                                                       reference counter minimum value
 *                                                       documented for the hardware) and make
 *                                                       HAL_CMU_StructInit() default to it,
 *                                                       accept a mask of flags in
 *                                                       HAL_CMU_GetFlagStatus() and a mask of
 *                                                       latched events in HAL_CMU_ClearFlag()
 *                                                       with the new CMU_FLAG_ALL constant,
 *                                                       make HAL_CMU_Cmd() enable the
 *                                                       monitoring with the mode recorded in
 *                                                       the handle (a handle without a
 *                                                       recorded non-zero mode keeps the
 *                                                       earlier all ones enable value)
 *                                                       and record the
 *                                                       values programmed by the setters, add
 *                                                       the instance binding check to the
 *                                                       read-only interfaces and to
 *                                                       HAL_CMU_MspInit() /
 *                                                       HAL_CMU_MspDeInit() (their
 *                                                       default no longer falls
 *                                                       back to the CMU3 clock
 *                                                       gate), record the values
 *                                                       programmed by every
 *                                                       setter (mode, window
 *                                                       length and both
 *                                                       thresholds) in the handle
 *                                                       Init structure, and align
 *                                                       HAL_CMU_ERROR_INVALID_PARAM with the
 *                                                       SMU / PMU siblings (0x1)
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Clock Monitoring Unit
 *                  (CMU) of the AS32x601:
 *                  - Initialization and de-initialization;
 *                  - Peripheral control: enable / disable the monitoring,
 *                    monitoring mode, reference count window length, high /
 *                    low frequency reference thresholds;
 *                  - Flag management: query and clear the monitoring
 *                    status flags;
 *                  - State and error reporting.
 *
 *                  Typical usage of the CMU:
 *                  (#) Fill the CMU_InitTypeDef with HAL_CMU_StructInit(),
 *                      set the MonitoringMode, WindowLength and the high /
 *                      low thresholds, then call HAL_CMU_Init() with the
 *                      handle;
 *                  (#) Optionally re-configure the monitoring at runtime
 *                      with HAL_CMU_Cmd() / HAL_CMU_SetMode() /
 *                      HAL_CMU_SetWindowLength() /
 *                      HAL_CMU_SetReferenceThreshold();
 *                  (#) Poll the status flags with HAL_CMU_GetFlagStatus()
 *                      (WORK, CHCDONE, LOSSCLK, FHH, FLL) and clear the
 *                      latched FHH / FLL flags with HAL_CMU_ClearFlag().
 *
 *                  All the register writing interfaces take the handle lock
 *                  and reject a call when the handle is busy (an operation is
 *                  ongoing in another context) or not initialized; the
 *                  read-only interfaces are lock-free.
 */
#include "as32x601_hal.h"          /* HAL_StatusTypeDef / HAL_MAX_DELAY / UNUSED */
#include "as32x601_hal_cmu.h"            /* CMU HAL API and register macros     */

/* The HAL_CMU_MODULE_ENABLED switch is provided by the user configuration
 * file (as32x601_hal_conf.h, included above through as32x601_hal.h): the
 * whole implementation is compiled only while the module is enabled. */
#ifdef HAL_CMU_MODULE_ENABLED

/* Private function prototypes -----------------------------------------------*/
static uint32 CMU_HandleIsValid(HAL_CMU_HandleTypeDef *hcmu);
static HAL_StatusTypeDef CMU_CheckState(HAL_CMU_HandleTypeDef *hcmu);

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Check whether a CMU handle and its instance are valid.
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
static uint32 CMU_HandleIsValid(HAL_CMU_HandleTypeDef *hcmu)
{
    if (hcmu == NULL_PTR)
    {
        return 0U;
    }

    if (IS_CMU_ALL_INSTANCE(hcmu->Instance) == 0U)
    {
        return 0U;
    }

    return 1U;
}

/**
 * @brief  Check whether the handle accepts a new operation.
 * @note   Architecture constraint ARCH-CONST-09: a handle that is BUSY (an
 *         operation is ongoing in another context) rejects any other operation
 *         with HAL_BUSY, and a handle that is not initialized (RESET) requires
 *         HAL_CMU_Init() first and is rejected with HAL_ERROR. The recoverable
 *         state ERROR accepts a new operation directly (the entry point of the
 *         operation programs the registers again, so that no DeInit / Init
 *         round trip is required).
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK (accepted) / HAL_BUSY / HAL_ERROR.
 */
static HAL_StatusTypeDef CMU_CheckState(HAL_CMU_HandleTypeDef *hcmu)
{
    if (hcmu->State == HAL_CMU_STATE_BUSY)
    {
        return HAL_BUSY;
    }

    if (hcmu->State == HAL_CMU_STATE_RESET)
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_CMU_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; when the mutex is not acquired before the
 *         Timeout expires, HAL_TIMEOUT is returned. The value is passed to
 *         HAL_MutexAcquire() as is (RTOS ticks; with the usual 1 ms tick it is
 *         the same quantity as the millisecond Timeout of the public API, and
 *         HAL_MAX_DELAY means an infinite wait).
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef CMU_LockHandle(HAL_CMU_HandleTypeDef *hcmu, uint32 Timeout)
{
#if (USE_RTOS == 1)
    if (hcmu->LockMutex == NULL_PTR)
    {
        /* The porting layer did not create the mutex (e.g. HAL_CMU_MspInit()
         * was not overridden): report it instead of calling the RTOS with a
         * NULL handle */
        return HAL_ERROR;
    }

    return HAL_MutexAcquire(hcmu->LockMutex, Timeout);
#else
    /* Prevent unused argument compilation warning: the bare-metal lock flag
     * either succeeds immediately or reports HAL_BUSY, it never waits */
    UNUSED(Timeout);

    if (hcmu->Lock == HAL_LOCKED)
    {
        return HAL_BUSY;
    }

    hcmu->Lock = HAL_LOCKED;

    return HAL_OK;
#endif /* USE_RTOS */
}

/**
 * @brief  Unlock the handle.
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @retval None
 */
void CMU_UnlockHandle(HAL_CMU_HandleTypeDef *hcmu)
{
#if (USE_RTOS == 1)
    (void)HAL_MutexRelease(hcmu->LockMutex);
#else
    hcmu->Lock = HAL_UNLOCKED;
#endif /* USE_RTOS */
}

/* Exported functions ---------------------------------------------------------*/

/** @addtogroup CMU_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Fills each CMU_InitStruct member with its default value
 *         (monitoring disabled, window length = CMU_WINLEN_MIN, thresholds =
 *         0). (NON-BLOCKING)
 * @param  CMU_InitStruct: pointer to a CMU_InitTypeDef structure which
 *         will be initialized.
 * @retval None
 * @note   The window length default is the minimum legal value, so that the
 *         filled structure is accepted by HAL_CMU_Init() as is.
 */
void HAL_CMU_StructInit(CMU_InitTypeDef *CMU_InitStruct)
{
    if (CMU_InitStruct == NULL_PTR)
    {
        return;
    }

    CMU_InitStruct->Size           = sizeof(CMU_InitTypeDef);  /*!< sizeof struct */
    CMU_InitStruct->Version        = CMU_INIT_VERSION;         /*!< V1            */
    CMU_InitStruct->MonitoringMode = CMU_MODE_0;   /*!< Monitoring disabled by default */
    CMU_InitStruct->WindowLength   = CMU_WINLEN_MIN; /*!< Reference count window length,
                                                          the minimum legal value      */
    CMU_InitStruct->HighThreshold  = 0U;           /*!< High frequency reference threshold */
    CMU_InitStruct->LowThreshold   = 0U;           /*!< Low frequency reference threshold  */
    CMU_InitStruct->Reserved[0]    = 0U;           /*!< Reserved for future use       */
    CMU_InitStruct->Reserved[1]    = 0U;           /*!< Reserved for future use       */
}

/**
 * @brief  Initializes the CMU according to the specified parameters in the
 *         CMU_InitStruct of the handle. (NON-BLOCKING)
 * @note   The CMU clock gating is enabled by the default HAL_CMU_MspInit()
 *         through the SMU_ALB0CFGR register; the user may override it.
 * @note   After the initialization the monitoring state depends on the
 *         MonitoringMode field: 0 keeps the monitoring disabled, a non-zero
 *         value enables it with the selected mode.
 * @note   LOCK-06: the low level initialization (HAL_CMU_MspInit()) runs
 *         before the handle is locked, so that an override which calls other
 *         HAL APIs (e.g. HAL_GPIO_Init()) cannot deadlock.
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (NULL pointer, invalid instance or invalid
 *         configuration)
 */
HAL_StatusTypeDef HAL_CMU_Init(HAL_CMU_HandleTypeDef *hcmu)
{
    /* Check the CMU peripheral handle and instance */
    if (CMU_HandleIsValid(hcmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_CMU_MODE(hcmu->Init.MonitoringMode));
    assert_param(IS_CMU_WINDOW_LENGTH(hcmu->Init.WindowLength));
    assert_param(IS_CMU_THRESHOLD(hcmu->Init.HighThreshold));
    assert_param(IS_CMU_THRESHOLD(hcmu->Init.LowThreshold));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((hcmu->Init.Size != sizeof(CMU_InitTypeDef)) ||
        (hcmu->Init.Version != CMU_INIT_VERSION) ||
        (IS_CMU_MODE(hcmu->Init.MonitoringMode) == 0U) ||
        (IS_CMU_WINDOW_LENGTH(hcmu->Init.WindowLength) == 0U) ||
        (IS_CMU_THRESHOLD(hcmu->Init.HighThreshold) == 0U) ||
        (IS_CMU_THRESHOLD(hcmu->Init.LowThreshold) == 0U))
    {
        hcmu->ErrorCode |= HAL_CMU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Allocate the lock resource before the first use, so that a handle that
     * was never initialized cannot report HAL_BUSY from a stale Lock field */
    if (hcmu->State == HAL_CMU_STATE_RESET)
    {
        hcmu->Lock = HAL_UNLOCKED;

        /* Init the low level hardware: clock, reset. LOCK-06: the MSP callback
         * runs before the handle is locked */
        HAL_CMU_MspInit(hcmu);
    }

    /* Process locked */
    if (CMU_LockHandle(hcmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hcmu->ErrorCode = HAL_CMU_ERROR_NONE;
    hcmu->State = HAL_CMU_STATE_BUSY;

    /* Program the monitoring configuration: window length, thresholds and
       monitoring mode (a zero mode keeps the monitoring disabled) */
    hcmu->Instance->CCR = hcmu->Init.WindowLength;
    hcmu->Instance->HTCR = hcmu->Init.HighThreshold;
    hcmu->Instance->LTCR = hcmu->Init.LowThreshold;
    hcmu->Instance->CR = hcmu->Init.MonitoringMode;

    hcmu->State = HAL_CMU_STATE_READY;

    /* Release Lock */
    CMU_UnlockHandle(hcmu);

    return HAL_OK;
}

/**
 * @brief  De-initializes the CMU peripheral. (NON-BLOCKING)
 * @note   The monitoring is disabled and the configuration registers
 *         (CR / CCR / HTCR / LTCR) are cleared, the handle goes back to the
 *         RESET state so that a following HAL_CMU_Init() re-runs
 *         HAL_CMU_MspInit().
 * @note   The state transition is READY -> BUSY -> RESET, so that a concurrent
 *         caller sees the handle as busy while the registers are cleared.
 * @note   LOCK-06: the low level de-initialization (HAL_CMU_MspDeInit()) runs
 *         after the unlock, so that an override which calls other HAL APIs
 *         (e.g. HAL_GPIO_DeInit()) cannot deadlock.
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (NULL pointer or invalid instance)
 */
HAL_StatusTypeDef HAL_CMU_DeInit(HAL_CMU_HandleTypeDef *hcmu)
{
    /* Check the CMU peripheral handle and instance */
    if (CMU_HandleIsValid(hcmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Process locked. ARCH-CONST-09: the de-initialization is callable from
     * any handle state, so that a failed initialization can always be undone */
    if (CMU_LockHandle(hcmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hcmu->ErrorCode = HAL_CMU_ERROR_NONE;
    hcmu->State = HAL_CMU_STATE_BUSY;

    /* Disable the monitoring and reset the configuration registers */
    hcmu->Instance->CR = 0U;
    hcmu->Instance->CCR = 0U;
    hcmu->Instance->HTCR = 0U;
    hcmu->Instance->LTCR = 0U;

    /* Set CMU error code to none and reset the state */
    hcmu->State = HAL_CMU_STATE_RESET;

    /* Release Lock */
    CMU_UnlockHandle(hcmu);

    /* LOCK-06 / ARCH-CONST-04: the low level de-initialization runs OUTSIDE
     * the locked region, as the architecture specification requires for the
     * MSP callbacks ("MspDeInit is called after the unlock") */
    HAL_CMU_MspDeInit(hcmu);

    return HAL_OK;
}

/**
 * @brief  Initializes the CMU MSP. Weak function; the default implementation
 *         enables the selected CMU clock and releases its reset through the
 *         SMU_ALB0CFGR register.
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @retval None
 * @note   The instance binding is validated before the first register access:
 *         a NULL handle or an instance outside the four CMU register blocks
 *         returns without touching any register.
 */
__weak void HAL_CMU_MspInit(HAL_CMU_HandleTypeDef *hcmu)
{
    uint32 clockenable = 0U;
    uint32 clockreset = 0U;

    /* The instance is validated before any register is touched, so that an
     * invalid binding can never gate a clock the caller did not ask for */
    if (CMU_HandleIsValid(hcmu) == 0U)
    {
        return;
    }

    /* Map the CMU instance to its clock gating bits in the SMU_ALB0CFGR
       register */
    if (hcmu->Instance == CMU_FIRC)
    {
        clockenable = SMU_ALB0CFGR_CMU0EN;
        clockreset  = SMU_ALB0CFGR_CMU0RST;
    }
    else if (hcmu->Instance == CMU_PLLQ)
    {
        clockenable = SMU_ALB0CFGR_CMU1EN;
        clockreset  = SMU_ALB0CFGR_CMU1RST;
    }
    else if (hcmu->Instance == CMU_PLLR)
    {
        clockenable = SMU_ALB0CFGR_CMU2EN;
        clockreset  = SMU_ALB0CFGR_CMU2RST;
    }
    else
    {
        /* CMU_OSC, the only remaining valid instance (see the check above) */
        clockenable = SMU_ALB0CFGR_CMU3EN;
        clockreset  = SMU_ALB0CFGR_CMU3RST;
    }

    /* Enable the selected CMU clock and release its reset: the reset bit is
     * released by SETTING it (SET = released, CLEAR = reset asserted), which
     * is also what the SMU_ALB0CFGR reset value (every RST bit set) and the
     * __HAL_SMU_CMUx_RELEASE_RESET() macros assume. */
    SMU->ALB0CFGR |= clockenable;
    SMU->ALB0CFGR |= clockreset;
}

/**
 * @brief  De-initializes the CMU MSP. Weak function; the default
 *         implementation disables the selected CMU clock.
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_CMU_MspDeInit(HAL_CMU_HandleTypeDef *hcmu)
{
    uint32 clockenable = 0U;

    /* The instance is validated before any register is touched, so that an
     * invalid binding can never gate a clock the caller did not ask for */
    if (CMU_HandleIsValid(hcmu) == 0U)
    {
        return;
    }

    /* Map the CMU instance to its clock gating bit in the SMU_ALB0CFGR
       register */
    if (hcmu->Instance == CMU_FIRC)
    {
        clockenable = SMU_ALB0CFGR_CMU0EN;
    }
    else if (hcmu->Instance == CMU_PLLQ)
    {
        clockenable = SMU_ALB0CFGR_CMU1EN;
    }
    else if (hcmu->Instance == CMU_PLLR)
    {
        clockenable = SMU_ALB0CFGR_CMU2EN;
    }
    else
    {
        /* CMU_OSC, the only remaining valid instance (see the check above) */
        clockenable = SMU_ALB0CFGR_CMU3EN;
    }

    /* Disable the selected CMU clock */
    SMU->ALB0CFGR &= ~clockenable;
}

/**
  * @}
  */

/** @addtogroup CMU_Exported_Functions_Group2 Peripheral Control functions
  * @{
  */

/**
 * @brief  Enables or disables the CMU clock monitoring. (NON-BLOCKING)
 * @note   The enable writes the non-zero monitoring mode recorded in the
 *         handle (the value programmed by HAL_CMU_Init() or the last
 *         HAL_CMU_SetMode()), so that a mode already selected by the caller
 *         is not overwritten; a handle that has no recorded non-zero mode
 *         keeps the enable value used by the earlier releases (every bit of
 *         the CR.MODE field set), which the documentation accepts as a
 *         non-zero mode. The disable writes the disabled mode (CMU_MODE_0).
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_CMU_Init() is required first).
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @param  NewState: ENABLE or DISABLE (CMU_ENABLE / CMU_DISABLE).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_CMU_Cmd(HAL_CMU_HandleTypeDef *hcmu, FunctionalState NewState)
{
    uint32 reg = 0U;
    uint32 mode = CMU_MODE_0;
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the CMU peripheral handle and instance */
    if (CMU_HandleIsValid(hcmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Runtime parameter validation (see HAL_CMU_Init()) */
    if (IS_FUNCTIONAL_STATE(NewState) == 0U)
    {
        hcmu->ErrorCode |= HAL_CMU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* The enable restarts the monitoring with the non-zero mode recorded in
     * the handle, so that a mode already selected by the caller is not
     * overwritten. A handle that has no recorded non-zero mode still enables
     * the monitoring, with every bit of the CR.MODE field set: the enable is
     * never refused and the register write happens on the same path as
     * before. */
    if (NewState != DISABLE)
    {
        mode = hcmu->Init.MonitoringMode;
        if (mode == CMU_MODE_0)
        {
            /* No non-zero mode was recorded: fall back to the enable value of
             * the earlier releases (the whole CR.MODE field), so that the
             * enable keeps working on a handle that was initialized with the
             * monitoring disabled */
            mode = (uint32)(CMU_CR_MODE_Msk >> CMU_CR_MODE_Pos);
        }
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_CMU_Init() is
     * required first) */
    status = CMU_CheckState(hcmu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (CMU_LockHandle(hcmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Update the MODE field (zero stops the monitoring, a non-zero recorded
     * mode starts it), keep the other CR bits */
    reg = hcmu->Instance->CR;
    reg &= ~(uint32)(CMU_CR_MODE_Msk);
    reg |= (uint32)((mode << CMU_CR_MODE_Pos) & CMU_CR_MODE_Msk);
    hcmu->Instance->CR = reg;

    /* Release Lock */
    CMU_UnlockHandle(hcmu);

    return HAL_OK;
}

/**
 * @brief  Sets the CMU monitoring mode (CR.MODE field). (NON-BLOCKING)
 * @note   The accepted value is recorded in the MonitoringMode field of the
 *         handle Init structure, so that a following HAL_CMU_Cmd(CMU_ENABLE)
 *         restarts the monitoring with this mode.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_CMU_Init() is required first).
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @param  Mode: CMU_MODE_0..CMU_MODE_7 (0 disables the monitoring).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_CMU_SetMode(HAL_CMU_HandleTypeDef *hcmu, uint32 Mode)
{
    uint32 reg = 0U;
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the CMU peripheral handle and instance */
    if (CMU_HandleIsValid(hcmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_CMU_MODE(Mode));

    /* Runtime parameter validation (see HAL_CMU_Init()) */
    if (IS_CMU_MODE(Mode) == 0U)
    {
        hcmu->ErrorCode |= HAL_CMU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_CMU_Init() is
     * required first) */
    status = CMU_CheckState(hcmu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (CMU_LockHandle(hcmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Update the MODE field, keep the other CR bits */
    reg = hcmu->Instance->CR;
    reg &= ~(uint32)(CMU_CR_MODE_Msk);
    reg |= (uint32)((Mode << CMU_CR_MODE_Pos) & CMU_CR_MODE_Msk);
    hcmu->Instance->CR = reg;

    /* Record the programmed mode, so that a following
     * HAL_CMU_Cmd(CMU_ENABLE) restarts the monitoring with it */
    hcmu->Init.MonitoringMode = Mode;

    /* Release Lock */
    CMU_UnlockHandle(hcmu);

    return HAL_OK;
}

/**
 * @brief  Sets the reference count window length (CCR.WINLEN field). (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_CMU_Init() is required first).
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @param  WindowLength: window length in reference clock cycles
 *         (CMU_WINLEN_MIN..CMU_WINLEN_MAX).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_CMU_SetWindowLength(HAL_CMU_HandleTypeDef *hcmu, uint32 WindowLength)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the CMU peripheral handle and instance */
    if (CMU_HandleIsValid(hcmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_CMU_WINDOW_LENGTH(WindowLength));

    /* Runtime parameter validation (see HAL_CMU_Init()) */
    if (IS_CMU_WINDOW_LENGTH(WindowLength) == 0U)
    {
        hcmu->ErrorCode |= HAL_CMU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_CMU_Init() is
     * required first) */
    status = CMU_CheckState(hcmu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (CMU_LockHandle(hcmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    hcmu->Instance->CCR = WindowLength;

    /* Record the programmed value, so that the handle configuration stays in
     * step with the register (a following HAL_CMU_Init() reproduces it) */
    hcmu->Init.WindowLength = WindowLength;

    /* Release Lock */
    CMU_UnlockHandle(hcmu);

    return HAL_OK;
}

/**
 * @brief  Sets the high and low frequency reference thresholds
 *         (HTCR.HFREF / LTCR.LFREF fields). (NON-BLOCKING)
 * @note   The accepted values are recorded in the HighThreshold / LowThreshold
 *         fields of the handle Init structure, so that the handle
 *         configuration stays in step with the registers (a following
 *         HAL_CMU_Init() reproduces them).
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_CMU_Init() is required first).
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @param  HighThreshold: high frequency reference threshold (0..0xFFFFFF).
 * @param  LowThreshold: low frequency reference threshold (0..0xFFFFFF).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_CMU_SetReferenceThreshold(HAL_CMU_HandleTypeDef *hcmu, uint32 HighThreshold,
                                                uint32 LowThreshold)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the CMU peripheral handle and instance */
    if (CMU_HandleIsValid(hcmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_CMU_THRESHOLD(HighThreshold));
    assert_param(IS_CMU_THRESHOLD(LowThreshold));

    /* Runtime parameter validation (see HAL_CMU_Init()) */
    if ((IS_CMU_THRESHOLD(HighThreshold) == 0U) || (IS_CMU_THRESHOLD(LowThreshold) == 0U))
    {
        hcmu->ErrorCode |= HAL_CMU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_CMU_Init() is
     * required first) */
    status = CMU_CheckState(hcmu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (CMU_LockHandle(hcmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    hcmu->Instance->HTCR = HighThreshold;
    hcmu->Instance->LTCR = LowThreshold;

    /* Record the programmed values, so that the handle configuration stays in
     * step with the registers (a following HAL_CMU_Init() reproduces them) */
    hcmu->Init.HighThreshold = HighThreshold;
    hcmu->Init.LowThreshold = LowThreshold;

    /* Release Lock */
    CMU_UnlockHandle(hcmu);

    return HAL_OK;
}

/**
  * @}
  */

/** @addtogroup CMU_Exported_Functions_Group3 Flag and State functions
  * @{
  */

/**
 * @brief  Checks whether one or more CMU status flags are set. (NON-BLOCKING)
 * @note   The instance binding is validated before the status register is
 *         read; an invalid request performs no register access.
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @param  CMU_FLAG: the flag or the mask of flags to check (a non-zero
 *         combination of the CMU_FLAG_xxx values, e.g. CMU_FLAG_ALL).
 * @retval 1 if at least one of the selected flags is set, 0 otherwise (also
 *         when the handle, the instance binding or the mask is invalid).
 */
uint32 HAL_CMU_GetFlagStatus(HAL_CMU_HandleTypeDef *hcmu, uint32 CMU_FLAG)
{
    /* Check the CMU handle allocation first: the assertions below dereference
     * the handle, so a NULL pointer must be rejected before them */
    if (hcmu == NULL_PTR)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_CMU_ALL_INSTANCE(hcmu->Instance));
    assert_param(IS_CMU_FLAG(CMU_FLAG));

    /* Runtime validation of the same two conditions, so that the guard stays
     * effective in a build with the assertions disabled (ERR-03) */
    if ((IS_CMU_ALL_INSTANCE(hcmu->Instance) == 0U) || (IS_CMU_FLAG(CMU_FLAG) == 0U))
    {
        return 0U;
    }

    return ((hcmu->Instance->SR & CMU_FLAG) != 0U) ? 1U : 0U;
}

/**
 * @brief  Clears one or more latched CMU status flags. (NON-BLOCKING)
 * @note   The selected mask is written directly to the status register
 *         (write 1 to clear) without a read-modify-write cycle, so that a
 *         latched event that appears at the same time is not lost. The mask
 *         accepts a single event or the combination of both latched events
 *         (CMU_CLEAR_FLL | CMU_CLEAR_FHH).
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_CMU_Init() is required first).
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @param  CMU_FLAG: the mask to clear (CMU_CLEAR_FLL, CMU_CLEAR_FHH or their
 *         combination; SR write value).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_CMU_ClearFlag(HAL_CMU_HandleTypeDef *hcmu, uint32 CMU_FLAG)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the CMU peripheral handle and instance */
    if (CMU_HandleIsValid(hcmu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_CMU_CLEAR(CMU_FLAG));

    /* Runtime parameter validation (see HAL_CMU_Init()) */
    if (IS_CMU_CLEAR(CMU_FLAG) == 0U)
    {
        hcmu->ErrorCode |= HAL_CMU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (BUSY)
     * or when the handle has not been initialized (RESET, HAL_CMU_Init() is
     * required first) */
    status = CMU_CheckState(hcmu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (CMU_LockHandle(hcmu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    hcmu->Instance->SR = CMU_FLAG;

    /* Release Lock */
    CMU_UnlockHandle(hcmu);

    return HAL_OK;
}

/**
 * @brief  Returns the CMU handle state. (NON-BLOCKING)
 * @note   The instance binding is validated before the handle state is read.
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @retval HAL_CMU_StateTypeDef: the current handle state; HAL_CMU_STATE_RESET
 *         when the handle is NULL or bound to an address outside the four CMU
 *         register blocks.
 */
HAL_CMU_StateTypeDef HAL_CMU_GetState(HAL_CMU_HandleTypeDef *hcmu)
{
    /* Check the CMU peripheral handle and instance */
    if (CMU_HandleIsValid(hcmu) == 0U)
    {
        return HAL_CMU_STATE_RESET;
    }

    return hcmu->State;
}

/**
 * @brief  Returns the CMU error code. (NON-BLOCKING)
 * @note   The instance binding is validated before the handle error code is
 *         read.
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @retval uint32: the CMU error code (HAL_CMU_ERROR_xxx); HAL_CMU_ERROR_NONE
 *         when the handle is NULL and HAL_CMU_ERROR_INVALID_PARAM when the
 *         handle is bound to an address outside the four CMU register blocks.
 */
uint32 HAL_CMU_GetError(HAL_CMU_HandleTypeDef *hcmu)
{
    /* Check the CMU handle allocation */
    if (hcmu == NULL_PTR)
    {
        return HAL_CMU_ERROR_NONE;
    }

    /* Check the CMU instance binding */
    if (IS_CMU_ALL_INSTANCE(hcmu->Instance) == 0U)
    {
        return HAL_CMU_ERROR_INVALID_PARAM;
    }

    return hcmu->ErrorCode;
}

/**
  * @}
  */

/**
  * @}
  */

#endif /* HAL_CMU_MODULE_ENABLED */

/*****END OF FILE*****/
