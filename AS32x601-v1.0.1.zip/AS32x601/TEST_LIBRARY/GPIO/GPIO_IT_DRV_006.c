/**
 * @file    GPIO_IT_DRV_006.c
 * @brief   HAL GPIO integration test case 006 (GPIOA, input read).
 *
 * One-to-one HAL library port of the original AS32x601 standard-library
 * test case GPIO_IT_DRV_006.c. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_GPIO_Init()           (input, floating)
 *   HAL_GPIO_ReadPin()        (input level of one pin)
 *   HAL_GPIO_ReadInputPort()(whole input register)
 *
 * Test configuration:
 *   GPIOA test pins : GPIO_Pin_0 .. GPIO_Pin_7, GPIO_Pin_14, GPIO_Pin_15 (mask 0xC0FF)
 *   GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13
 *   are the QSPI pins of the chip: they are driven by the QSPI interface out of
 *   reset, so they are not part of the test.
 *
 * Test procedure:
 *   1. initialize the GPIOA test pins as floating inputs
 *   2. drive every test pin high from the outside
 *   3. read the level of every test pin and the whole input register into the observation variables
 *   4. drive every test pin low from the outside
 *   5. read the level of every test pin and the whole input register again
 *   6. loop over steps 2..5
 *
 * Expected behaviour:
 *   After step 3  (external high level):
 *     Read_Input_Data_Bit = 0xC0FF   (every test pin reads high)
 *     Read_Input_Data     = 0xC0FFU   (whole input register, vendor board)
 *   After step 5  (external low level):
 *     Read_Input_Data_Bit = 0x0000
 *     Read_Input_Data     = 0x0000U   (whole input register, vendor board)
 *   Read_Result is 0 whenever the accumulated test pin mask matches the phase,
 *   1 otherwise. The input path has no internal stimulus, so the pins have to be
 *   driven from the outside (a signal generator at about 1 Hz fits the 500 ms
 *   delay of the loop).
 *
 * Note: this case prints nothing. The observation variables below and the
 * register values are meant to be watched with the debugger, and the pin
 * waveform with a logic analyser.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"

/* Private define -----------------------------------------------------------*/
/* GPIOA test pins */
#define TEST_PIN        (GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | \
                         GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7 | \
                         GPIO_PIN_14 | GPIO_PIN_15)

/* Test pin mask, kept in a 32 bit type for the accumulated observations */
#define TEST_PIN_MASK   ((uint32)0xC0FFU)

/* Private variables ---------------------------------------------------------*/
static HAL_SMU_HandleTypeDef hsmu_clk;   /*!< SMU handle (lock / state / error) */
static volatile uint32 Read_Input_Data_Bit = 0U;  /*!< test pins read (bit mask)   */
static volatile uint32 Read_Input_Data     = 0U;  /*!< whole input register        */
static volatile uint32 Read_Result         = 1U;  /*!< 0: matched, 1: not matched  */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void gpioa_Config(void);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    uint32 position;
    uint32 pin;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Configure the GPIOA test pins */
    gpioa_Config();

    while (1)
    {
        /* Step 2: the test pins are driven high from the outside (there is no
           internal stimulus for the input path) */

        /* Step 3: read every test pin and check the observation */
        Read_Input_Data_Bit = 0U;
        for (position = 0U; position < 16U; position++)
        {
            pin = ((uint32)0x01U) << position;
            if ((TEST_PIN_MASK & pin) != 0U)
            {
                if (HAL_GPIO_ReadPin(GPIOA, (uint16)pin) != GPIO_PIN_RESET)
                {
                    Read_Input_Data_Bit |= pin;
                }
            }
        }
        Read_Input_Data = HAL_GPIO_ReadInputPort(GPIOA);
        Read_Result = ((Read_Input_Data_Bit == TEST_PIN_MASK) ? 0U : 1U);
        delay_ms(500U);

        /* Step 4: the test pins are driven low from the outside */

        /* Step 5: read every test pin again, they shall all read low */
        Read_Input_Data_Bit = 0U;
        for (position = 0U; position < 16U; position++)
        {
            pin = ((uint32)0x01U) << position;
            if ((TEST_PIN_MASK & pin) != 0U)
            {
                if (HAL_GPIO_ReadPin(GPIOA, (uint16)pin) != GPIO_PIN_RESET)
                {
                    Read_Input_Data_Bit |= pin;
                }
            }
        }
        Read_Input_Data = HAL_GPIO_ReadInputPort(GPIOA);
        Read_Result = ((Read_Input_Data_Bit == 0U) ? 0U : 1U);
        delay_ms(500U);
    }
}

/**
 * @brief  Configure the system clock tree. Every case of this suite uses the
 *         same clock tree as the original standard-library test (PLL 180 MHz).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef  SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef   SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it (CLKFRQ above), so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Clock tree order: this is the order the chip requires, and the vendor
       test case uses the same one.
         1. Write the bus clock dividers while the system clock is still the
            power-on source (FIRC), so that the new divider values are already
            in place when the faster clock arrives. Writing them AFTER the
            switch instead leaves the buses at their reset dividers for a
            moment at the new core clock: at 180 MHz that is
            AXI4Bus3 = 90 MHz and APBBus0 = 45 MHz, right at their ratings, and
            the core does not survive it (measured on the board: the core
            trapped before the divider write was reached, so no output was
            produced at all).
         2. Program the EFLASH controller clock: the controller must already
            know the final frequency while the code still runs from the flash.
         3. Then configure the PLL and switch the system clock to it; this call
            also updates SystemCoreClock and re-initializes the HAL time base. */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Configure the GPIOA test pins.
 * @param  None
 * @retval None
 */
static void gpioa_Config(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    /* Enable the GPIOA clock gate */
    __HAL_SMU_GPIOA_CLK_ENABLE();

    /* Clear the structure and set the Size / Version metafields */
    __HAL_CLEAR_STRUCT(&GPIO_InitStruct);
    GPIO_InitStruct.Size    = sizeof(GPIO_InitStruct);
    GPIO_InitStruct.Version = GPIO_INIT_VERSION;

    /* Configure the test pins */
    GPIO_InitStruct.Pin          = TEST_PIN;
    GPIO_InitStruct.Mode         = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull         = GPIO_NOPULL;
    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    GPIO_InitStruct.Alternate    = GPIO_AF_Pin_x;

    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

/*****END OF FILE*****/
