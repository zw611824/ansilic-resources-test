/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_fcu.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.5
 * Date:   2026/11/02
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/11     1.1     fix the polarity of the FCU reset bit
 *                                                       in HAL_FCU_MspInit (the reset is
 *                                                       released by setting the bit, not by
 *                                                       clearing it)
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.2     apply the resource lock / RTOS rules:
 *                                                       run the MSP callbacks outside the
 *                                                       locked region, add a Timeout and a
 *                                                       NULL-mutex guard to the lock helper,
 *                                                       add the busy / reset state gate,
 *                                                       return HAL_StatusTypeDef from the
 *                                                       seven register writing interfaces
 *                                                       with run-time parameter validation,
 *                                                       and keep the four status clear
 *                                                       interfaces lock free so that they
 *                                                       stay callable from the FCU interrupt
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.3     document the entry error code clear of
 *                                                       the three register writing interfaces
 *                                                       (matching source file V1.3)
 *     ANSILIC APPLICATION GROUP  2026/10/09     1.4     merge the capabilities of the Error
 *                                                       Handling release of 2026/09/30 into
 *                                                       this driver: add the per channel
 *                                                       run-time setters HAL_FCU_SetLevel /
 *                                                       SetFaultAction / SetAlarmAction, add
 *                                                       the interrupt dispatch entry
 *                                                       HAL_FCU_IRQHandler() with the weak
 *                                                       HAL_FCU_FaultCallback() /
 *                                                       HAL_FCU_AlarmCallback(), add the
 *                                                       HAL_FCU_CHANNEL_COUNT constant,
 *                                                       reset all the 42 channels in
 *                                                       HAL_FCU_DeInit() and clear the
 *                                                       channel status latch together
 *                                                       with the software fault in
 *                                                       HAL_FCU_ClearSoftwareFault().
 *                                                       HAL_FCU_Cmd() keeps the channel
 *                                                       mask untouched, so a channel
 *                                                       configured as masked stays silent
 *                                                       while it is enabled
 *     ANSILIC APPLICATION GROUP  2026/11/02     1.5     absorb the Error Handling release of
 *                                                       2026/10/10: the channel mask now
 *                                                       drives the enable bit as well (an
 *                                                       unmasked channel is enabled by
 *                                                       HAL_FCU_Init()), the software fault
 *                                                       trigger threshold of the configured
 *                                                       channel is programmed from
 *                                                       Init.SoftwareTriggerCount, the clear
 *                                                       registers are written directly
 *                                                       instead of read back and rewritten,
 *                                                       the clear family masks the channel
 *                                                       around the clear and reports a latch
 *                                                       that survives it through the new
 *                                                       HAL_FCU_ERROR_CLEAR_FAILED code, and
 *                                                       a whole fault source category can be
 *                                                       cleared with the new
 *                                                       HAL_FCU_ClearCategoryFaultStatus()
 *                                                       and the published category masks.
 *                                                       The structure size and the offsets
 *                                                       are unchanged (the first reserved
 *                                                       word of 1.0 carries the software
 *                                                       trigger threshold)
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Fault Collection Unit
 *                  (FCU) of the AS32x601:
 *                  - Initialization and de-initialization: HAL_FCU_Init /
 *                    HAL_FCU_DeInit, configuration structure handling;
 *                  - Peripheral control: channel enable / disable,
 *                    software fault trigger / count / clear;
 *                  - Fault and alarm management: software fault status,
 *                    channel alarm / fault status query and clear, bus
 *                    timeout / ECC fault clear;
 *                  - State and error reporting.
 *
 *                  The FCU collects the fault signals of the chip (ECC,
 *                  bus timeouts, watchdog, voltage detectors, ...) on 42
 *                  channels and raises an alarm or a fault level depending
 *                  on the channel configuration. The FCU interrupt
 *                  (FCU_IRQn) is enabled through the PLIC by the user; the
 *                  interrupt service routine shall read the alarm / fault
 *                  status with HAL_FCU_GetAlarmStatus() /
 *                  HAL_FCU_GetFaultStatus() and clear them with
 *                  HAL_FCU_ClearFcuStatus().
 *
 * @complexity  Medium
 *              State machine (State/ErrorCode) and blocking lock operations.
 */
#ifndef __AS32X601_HAL_FCU_H
#define __AS32X601_HAL_FCU_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "as32x601.h"               /* FCU_TypeDef, FCU register bits          */
#include "as32x601_hal_def.h"       /* HAL_StatusTypeDef, HAL_LockTypeDef      */

/* Exported constants --------------------------------------------------------*/

/**
 * @brief  FCU HAL driver module version.
 * @note   0x0100U = V1.0. Bumped only on breaking API changes (architecture
 *         spec COMPAT-13/14/15).
 */
#define __HAL_FCU_MODULE_VERSION  0x0100U

/* Exported types ------------------------------------------------------------*/

/** @defgroup FCU_Exported_Types FCU Exported Types
  * @{
  */

/**
 * @brief FCU channel type enumeration (42 channels).
 * @note  The values are the FCU channel indices used to index the CFG
 *        register array and the ALARM / FAULT bit positions.
 */
typedef enum
{
    HAL_FCU_CHANNEL_CPUDCLS        = 0x00U, /*!< Channel 0  CPUDCLS        */
    HAL_FCU_CHANNEL_MPU0           = 0x01U, /*!< Channel 1  MPU0           */
    HAL_FCU_CHANNEL_MPU1           = 0x02U, /*!< Channel 2  MPU1           */
    HAL_FCU_CHANNEL_MPU2           = 0x03U, /*!< Channel 3  MPU2           */
    HAL_FCU_CHANNEL_CACHEECC       = 0x04U, /*!< Channel 4  CACHEECC       */
    HAL_FCU_CHANNEL_CPUPORTECC     = 0x05U, /*!< Channel 5  CPUPORTECC     */
    HAL_FCU_CHANNEL_FLASHPORTECC   = 0x06U, /*!< Channel 6  FLASHPORTECC   */
    HAL_FCU_CHANNEL_EFLASHECC      = 0x07U, /*!< Channel 7  EFLASHECC      */
    HAL_FCU_CHANNEL_CPUIBUSTIMEOUT = 0x08U, /*!< Channel 8  CPUIBUSTIMEOUT */
    HAL_FCU_CHANNEL_DMA0DCLS       = 0x09U, /*!< Channel 9  DMA0DCLS       */
    HAL_FCU_CHANNEL_DMA1DCLS       = 0x0AU, /*!< Channel 10 DMA1DCLS       */
    HAL_FCU_CHANNEL_MPUDMA0        = 0x0BU, /*!< Channel 11 MPUDMA0        */
    HAL_FCU_CHANNEL_MPUDMA1        = 0x0CU, /*!< Channel 12 MPUDMA1        */
    HAL_FCU_CHANNEL_DMA0ECC        = 0x0DU, /*!< Channel 13 DMA0ECC        */
    HAL_FCU_CHANNEL_DMA1ECC        = 0x0EU, /*!< Channel 14 DMA1ECC        */
    HAL_FCU_CHANNEL_SRAMECC        = 0x0FU, /*!< Channel 15 SRAMECC        */
    HAL_FCU_CHANNEL_CPUDBUSTIMEOUT = 0x10U, /*!< Channel 16 CPUDBUSTIMEOUT */
    HAL_FCU_CHANNEL_MACBUSTIMEOUT  = 0x11U, /*!< Channel 17 MACBUSTIMEOUT  */
    HAL_FCU_CHANNEL_DMA0BUSTIMEOUT = 0x12U, /*!< Channel 18 DMA0BUSTIMEOUT */
    HAL_FCU_CHANNEL_DMA1BUSTIMEOUT = 0x13U, /*!< Channel 19 DMA1BUSTIMEOUT */
    HAL_FCU_CHANNEL_DSEBUSTIMEOUT  = 0x14U, /*!< Channel 20 DSEBUSTIMEOUT  */
    HAL_FCU_CHANNEL_CPUPBUSTIMEOUT = 0x15U, /*!< Channel 21 CPUPBUSTIMEOUT */
    HAL_FCU_CHANNEL_APB0ECC        = 0x16U, /*!< Channel 22 APB0ECC        */
    HAL_FCU_CHANNEL_APB1ECC        = 0x17U, /*!< Channel 23 APB1ECC        */
    HAL_FCU_CHANNEL_AXILITE0ECC    = 0x18U, /*!< Channel 24 AXILITE0ECC    */
    HAL_FCU_CHANNEL_CMU0           = 0x19U, /*!< Channel 25 CMU0           */
    HAL_FCU_CHANNEL_CMU1           = 0x1AU, /*!< Channel 26 CMU1           */
    HAL_FCU_CHANNEL_CMU2           = 0x1BU, /*!< Channel 27 CMU2           */
    HAL_FCU_CHANNEL_CMU3           = 0x1CU, /*!< Channel 28 CMU3           */
    HAL_FCU_CHANNEL_AXILITE1ECC    = 0x1DU, /*!< Channel 29 AXILITE1ECC    */
    HAL_FCU_CHANNEL_AXILITE2ECC    = 0x1EU, /*!< Channel 30 AXILITE2ECC    */
    HAL_FCU_CHANNEL_WWDG0          = 0x1FU, /*!< Channel 31 WWDG0          */
    HAL_FCU_CHANNEL_WWDG1          = 0x20U, /*!< Channel 32 WWDG1          */
    HAL_FCU_CHANNEL_LVD            = 0x21U, /*!< Channel 33 LVD            */
    HAL_FCU_CHANNEL_HVD            = 0x22U, /*!< Channel 34 HVD            */
    HAL_FCU_CHANNEL_IWDG           = 0x23U, /*!< Channel 35 IWDG           */
    HAL_FCU_CHANNEL_SOFTWARE0      = 0x24U, /*!< Channel 36 SOFTWARE0      */
    HAL_FCU_CHANNEL_SOFTWARE1      = 0x25U, /*!< Channel 37 SOFTWARE1      */
    HAL_FCU_CHANNEL_SOFTWARE2      = 0x26U, /*!< Channel 38 SOFTWARE2      */
    HAL_FCU_CHANNEL_SOFTWARE3      = 0x27U, /*!< Channel 39 SOFTWARE3      */
    HAL_FCU_CHANNEL_EXTENDFAULT0   = 0x28U, /*!< Channel 40 EXTENDFAULT0   */
    HAL_FCU_CHANNEL_EXTENDFAULT1   = 0x29U  /*!< Channel 41 EXTENDFAULT1   */
} HAL_FCU_ChannelTypeDef;

/**
 * @brief FCU fault action type enumeration.
 * @note  The values are the CFG.FACT field values.
 */
typedef enum
{
    HAL_FCU_FAULT_INTERRUPT       = 0x00U,  /*!< Fault action: interrupt       */
    HAL_FCU_FAULT_GLOBAL_SOFTWARE_RESET = 0x02U /*!< Fault action: global software reset */
} HAL_FCU_FaultActionTypeDef;

/**
 * @brief FCU alarm action type enumeration.
 * @note  The values are the CFG.AACT field values.
 */
typedef enum
{
    HAL_FCU_ALARM_NONE            = 0x00U,  /*!< Alarm action: none            */
    HAL_FCU_ALARM_INTERRUPT       = 0x01U   /*!< Alarm action: interrupt       */
} HAL_FCU_AlarmActionTypeDef;

/**
 * @brief FCU fault level type enumeration.
 * @note  The values are the CFG.LEVEL field values.
 */
typedef enum
{
    HAL_FCU_FAULT_LEVEL_INVALID   = 0x00U,  /*!< Fault level: invalid          */
    HAL_FCU_FAULT_LEVEL_ALARM     = 0x01U,  /*!< Fault level: alarm            */
    HAL_FCU_FAULT_LEVEL_FAULT     = 0x02U   /*!< Fault level: fault            */
} HAL_FCU_FaultLevelTypeDef;

/**
 * @brief FCU configuration structure definition.
 * @note  The channel configuration fields directly map to the FCU_CFGx
 *        register fields; SoftwareTriggerCount maps to the SFCNT field of the
 *        configured software channel.
 * @note  The structure size and the offsets of the members that existed in
 *        version 1.0 are unchanged: the first reserved word of that revision
 *        carries the software fault trigger threshold, so a structure which
 *        was cleared and filled by an older revision (writing 0 into it) keeps
 *        its meaning (0 = one trigger reports).
 */
typedef struct
{
    uint32                       Size;   /*!< sizeof(FCU_InitTypeDef), set by the user after
                                         clearing the structure */
    uint32                       Version;   /*!< Structure semantic version: @ref FCU_INIT_VERSION
                                            (FCU_INIT_V1 = 0x0100U) */
    HAL_FCU_ChannelTypeDef       Channel;            /*!< Channel to configure         */
    uint8                        FaultToResetCount;  /*!< Count to reset under FOCU (0..0xFF) */
    uint8                        AlarmToFaultCount;   /*!< Count to change alarm to fault
                                                     (0..0xFF) */
    HAL_FCU_FaultActionTypeDef   FaultAction;        /*!< Fault action (interrupt / reset) */
    HAL_FCU_AlarmActionTypeDef   AlarmAction;        /*!< Alarm action (none / interrupt) */
    HAL_FCU_FaultLevelTypeDef    FaultLevel;         /*!< Fault level                  */
    uint32                       MaskEnable;         /*!< Channel mask enable (0/1)    */
    uint32                       SoftwareTriggerCount;   /*!< Software fault channel trigger
                                                            threshold (0..0xFF, 0 = one
                                                            trigger reports); it is written
                                                            to SFCNT when the configured
                                                            channel is a software one
                                                            (SOFTWARE0..SOFTWARE3)         */
    uint32                       Reserved;       /*!< Reserved for future extension (must be
                                                     0) */
} FCU_InitTypeDef;

#define FCU_INIT_V1      0x0100U                        /*!< Init structure version 1 */
#define FCU_INIT_VERSION FCU_INIT_V1                    /*!< Init structure semantic version */

/**
 * @brief HAL FCU state structures definition.
 */
typedef enum
{
    HAL_FCU_STATE_RESET      = 0x00U, /*!< Peripheral not initialized          */
    HAL_FCU_STATE_READY      = 0x01U, /*!< Peripheral initialized and ready    */
    HAL_FCU_STATE_BUSY       = 0x02U, /*!< An internal process is ongoing      */
    HAL_FCU_STATE_ERROR      = 0x03U  /*!< FCU error state                     */
} HAL_FCU_StateTypeDef;

/**
 * @brief FCU handle structure definition.
 */
typedef struct __HAL_FCU_HandleTypeDef
{
    FCU_TypeDef               *Instance;      /*!< FCU registers base address    */
    FCU_InitTypeDef           Init;           /*!< FCU configuration parameters  */
    HAL_LockTypeDef           Lock;           /*!< Locking object                */
    __IO HAL_FCU_StateTypeDef State;          /*!< FCU communication state       */
    __IO uint32               ErrorCode;      /*!< FCU error code                */
#if (USE_RTOS == 1)
    HAL_MutexTypeDef          LockMutex;      /*!< RTOS mutex handle (created by the
                                                   user porting layer, e.g. in
                                                   HAL_FCU_MspInit)             */
#endif /* USE_RTOS */
} HAL_FCU_HandleTypeDef;

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @defgroup FCU_Exported_Constants FCU Exported Constants
  * @{
  */

/** @defgroup FCU_Error_Code FCU Error Code
  * @{
  */
#define HAL_FCU_ERROR_NONE           ((uint32)0x00000000U) /*!< No error                             */
#define HAL_FCU_ERROR_INVALID_PARAM  ((uint32)0x00000001U) /*!< Invalid parameter, invalid
                                                                configuration structure or a
                                                                rejected operation                      */
#define HAL_FCU_ERROR_CLEAR_FAILED   ((uint32)0x00000004U) /*!< A status latch is still asserted
                                                                after the clear request: the
                                                                underlying fault source is still
                                                                active                                  */
/**
  * @}
  */

/** @defgroup FCU_Channel_Count FCU Channel Count
  * @{
  */
#define HAL_FCU_CHANNEL_COUNT        42U   /*!< Number of fault source channels of the fault
                                                collection unit (CPUDCLS .. EXTENDFAULT1) */
/**
  * @}
  */

/** @defgroup FCU_Software_Channel FCU Software Fault Channel
  * @note  The values are the SFTR / SFSTA / SFCLR register bit masks.
  * @{
  */
#define FCU_SOFTWARE_CHANNEL_0       ((uint32)0x00000001U) /*!< Software fault channel 0 */
#define FCU_SOFTWARE_CHANNEL_1       ((uint32)0x00000002U) /*!< Software fault channel 1 */
#define FCU_SOFTWARE_CHANNEL_2       ((uint32)0x00000004U) /*!< Software fault channel 2 */
#define FCU_SOFTWARE_CHANNEL_3       ((uint32)0x00000008U) /*!< Software fault channel 3 */
/**
  * @}
  */

/** @defgroup FCU_Category_Clear_Mask FCU Fault Source Category Clear Mask
  * @note  Each fault source category owns a mask pair which selects its
  *        channels in the CLEAR0 (channels 0..31) and CLEAR1 (channels 32..41)
  *        clear registers. The pairs are consumed by
  *        HAL_FCU_ClearCategoryFaultStatus() and are published so that the
  *        category of a channel can also be derived by the application.
  * @note  A category whose channels do not live in a bank carries 0 in that
  *        member of the pair (writing 0 to a clear register has no effect).
  * @note  The software fault category owns the SFSTA latch as well: clearing
  *        software channels with the published pair clears their fault / alarm
  *        latch only. Use HAL_FCU_ClearSoftwareFault() for them, which also
  *        writes SFCLR and therefore does not leave the trigger latch set.
  * @{
  */
#define FCU_CATEGORY_CLEAR_CORE_MASK0        ((uint32)0x00001E0FUL) /*!< CLEAR0: CPUDCLS, MPU0..2,
                                                                         DMA0/DMA1DCLS, MPUDMA0/1 */
#define FCU_CATEGORY_CLEAR_CORE_MASK1        ((uint32)0x00000000U)  /*!< CLEAR1: none            */
#define FCU_CATEGORY_CLEAR_STORAGE_MASK0     ((uint32)0x61C0E0F0UL) /*!< CLEAR0: CACHE/CPUPORT/
                                                                         FLASH/EFLASH/APB0/APB1/
                                                                         AXILITE0..2/DMA0/DMA1/
                                                                         SRAM ECC               */
#define FCU_CATEGORY_CLEAR_STORAGE_MASK1     ((uint32)0x00000000U)  /*!< CLEAR1: none            */
#define FCU_CATEGORY_CLEAR_BUS_MASK0         ((uint32)0x003F0100UL) /*!< CLEAR0: CPUIBUS/CPUDBUS/
                                                                         MAC/DMA0/DMA1/DSE/CPUP
                                                                         bus timeout            */
#define FCU_CATEGORY_CLEAR_BUS_MASK1         ((uint32)0x00000000U)  /*!< CLEAR1: none            */
#define FCU_CATEGORY_CLEAR_CLOCK_MASK0       ((uint32)0x1E000000UL) /*!< CLEAR0: CMU0..CMU3      */
#define FCU_CATEGORY_CLEAR_CLOCK_MASK1       ((uint32)0x00000000U)  /*!< CLEAR1: none            */
#define FCU_CATEGORY_CLEAR_WATCHDOG_MASK0    ((uint32)0x80000000UL) /*!< CLEAR0: WWDG0           */
#define FCU_CATEGORY_CLEAR_WATCHDOG_MASK1    ((uint32)0x00000009UL) /*!< CLEAR1: WWDG1, IWDG     */
#define FCU_CATEGORY_CLEAR_VOLTAGE_MASK0     ((uint32)0x00000000U)  /*!< CLEAR0: none            */
#define FCU_CATEGORY_CLEAR_VOLTAGE_MASK1     ((uint32)0x00000006UL) /*!< CLEAR1: LVD, HVD        */
#define FCU_CATEGORY_CLEAR_SOFTWARE_MASK0    ((uint32)0x00000000U)  /*!< CLEAR0: none            */
#define FCU_CATEGORY_CLEAR_SOFTWARE_MASK1    ((uint32)0x000000F0UL) /*!< CLEAR1: SOFTWARE0..3
                                                                         (see the group note)   */
#define FCU_CATEGORY_CLEAR_EXTENSION_MASK0   ((uint32)0x00000000U)  /*!< CLEAR0: none            */
#define FCU_CATEGORY_CLEAR_EXTENSION_MASK1   ((uint32)0x00000300UL) /*!< CLEAR1: EXTENDFAULT0/1  */
/**
  * @}
  */

/** @defgroup FCU_Enable_Value FCU Enable Value
  * @note  The two values serve two purposes: as the NewState of
  *        HAL_FCU_Cmd() they drive the CFG.EN bit of the channel, while as the
  *        MaskEnable field of FCU_InitTypeDef they drive the CFG.MASK bit
  *        (FCU_ENABLE = the channel is masked, so it stays silent even while it
  *        is enabled).
  * @{
  */
#define FCU_ENABLE                   1U       /*!< Enable the FCU channel / request the channel
                                                   mask                            */
#define FCU_DISABLE                  0U       /*!< Disable the FCU channel / leave the channel
                                                   unmasked (HAL_FCU_Init() enables it) */
/**
  * @}
  */

/**
  * @}
  */

/* Exported macros ------------------------------------------------------------*/

/** @defgroup FCU_Exported_Macros FCU Exported Macros
  * @{
  */

/**
 * @brief  Reset the handle State field.
 * @note   Must be used before passing a local handle to HAL_FCU_Init() the
 *         first time, so that the low level initialization (MspInit) is
 *         always executed.
 */
#define __HAL_FCU_RESET_HANDLE_STATE(__HANDLE__) ((__HANDLE__)->State = 0U)

/**
 * @brief  Enable the FCU peripheral clock.
 * @note   The macros below directly access the peripheral registers and do
 *         not check the handle: the caller must guarantee a valid handle.
 */
#define __HAL_FCU_CLK_ENABLE(__HANDLE__)        (SMU->ALB0CFGR |= (SMU_ALB0CFGR_FCUEN))

/**
 * @brief  Disable the FCU peripheral clock.
 */
#define __HAL_FCU_CLK_DISABLE(__HANDLE__)       (SMU->ALB0CFGR &= ~(SMU_ALB0CFGR_FCUEN))

/**
 * @brief  Check whether a FCU software fault status is set.
 * @param  __CHANNEL__: FCU_SOFTWARE_CHANNEL_x bit mask.
 * @retval 1 if the flag is set, 0 otherwise.
 */
#define __HAL_FCU_GET_SOFTWARE_FAULT(__HANDLE__, __CHANNEL__) (((__HANDLE__)->Instance->SFSTA & (__CHANNEL__)) != 0U)

/**
 * @brief  Check whether a FCU alarm status is set.
 * @param  __CHANNEL__: HAL_FCU_ChannelTypeDef channel index.
 * @retval 1 if the flag is set, 0 otherwise.
 */
#define __HAL_FCU_GET_ALARM(__HANDLE__, __CHANNEL__) \
    (((__CHANNEL__) < 32U) ? (((__HANDLE__)->Instance->ALARM0 & (1UL << (__CHANNEL__))) != 0U) : \
                             (((__HANDLE__)->Instance->ALARM1 & (1UL << ((__CHANNEL__) - 32U))) != 0U))

/**
 * @brief  Check whether a FCU fault status is set.
 * @param  __CHANNEL__: HAL_FCU_ChannelTypeDef channel index.
 * @retval 1 if the flag is set, 0 otherwise.
 */
#define __HAL_FCU_GET_FAULT(__HANDLE__, __CHANNEL__) \
    (((__CHANNEL__) < 32U) ? (((__HANDLE__)->Instance->FAULT0 & (1UL << (__CHANNEL__))) != 0U) : \
                             (((__HANDLE__)->Instance->FAULT1 & (1UL << ((__CHANNEL__) - 32U))) != 0U))

/**
 * @brief  Clear a FCU alarm / fault status.
 * @note   The clear registers are write-one-to-clear: the target mask is
 *         written directly and the register is never read back and rewritten,
 *         so a status that is not selected by the mask cannot be cleared by
 *         accident.
 * @param  __CHANNEL__: HAL_FCU_ChannelTypeDef channel index.
 */
#define __HAL_FCU_CLEAR_FCU_STATUS(__HANDLE__, __CHANNEL__) \
    (((__CHANNEL__) < 32U) ? ((__HANDLE__)->Instance->CLEAR0 = (1UL << (__CHANNEL__))) : \
                             ((__HANDLE__)->Instance->CLEAR1 = (1UL << ((__CHANNEL__) - 32U))))

/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/

/** @addtogroup FCU_Exported_Functions
  * @{
  */

/** @addtogroup FCU_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Fills each FCU_InitStruct member with its default value. (NON-BLOCKING)
 * @note   The default channel is EXTENDFAULT1, the fault action is the
 *         global software reset, the alarm action is none, the fault level
 *         is invalid, the mask is requested (the default channel is therefore
 *         masked, so it stays silent until MaskEnable is set to FCU_DISABLE)
 *         and the software trigger threshold is 0 (one trigger reports).
 * @param  FCU_InitStruct: pointer to a FCU_InitTypeDef structure which
 *         will be initialized.
 * @retval None
 */
void HAL_FCU_StructInit(FCU_InitTypeDef *FCU_InitStruct);

/**
 * @brief  Initializes the FCU channel according to the specified parameters (NON-BLOCKING)
 *         in the FCU_InitStruct of the handle.
 * @note   The FCU clock gating is enabled by the default HAL_FCU_MspInit()
 *         through the SMU_ALB0CFGR register; the user may override it.
 * @note   The mask field drives the enable bit as well: with
 *         MaskEnable = FCU_ENABLE the channel is masked and its enable bit is
 *         left untouched (a channel that was enabled before stays enabled but
 *         silent), while with MaskEnable = FCU_DISABLE the channel is
 *         unmasked and enabled by this call, so that HAL_FCU_Cmd() is only
 *         needed for the channels that are initialized as masked.
 * @note   When the configured channel is a software fault channel
 *         (SOFTWARE0..SOFTWARE3), Init.SoftwareTriggerCount is programmed into
 *         the matching field of SFCNT before the channel is configured.
 * @note   The parameters and the configuration structure metafields (Size /
 *         Version) are validated at run time: an invalid configuration is
 *         rejected with HAL_ERROR and HAL_FCU_ERROR_INVALID_PARAM without
 *         changing the handle state.
 * @note   LOCK-06: the low level initialization (HAL_FCU_MspInit()) runs
 *         before the handle is locked.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (NULL pointer, invalid instance or invalid
 *         configuration)
 */
HAL_StatusTypeDef HAL_FCU_Init(HAL_FCU_HandleTypeDef *hfcu);

/**
 * @brief  De-initializes the FCU peripheral. (NON-BLOCKING)
 * @note   The configuration of every FCU channel is reset (the enable bit is
 *         cleared first, then the whole configuration register is written to
 *         0) and the FCU clock is disabled, so that no channel of a previous
 *         configuration keeps driving an alarm or a fault.
 * @note   The call is accepted from any handle state, so that a failed
 *         initialization can always be undone.
 * @note   LOCK-06: the low level de-initialization (HAL_FCU_MspDeInit()) runs
 *         after the unlock.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (NULL pointer or invalid instance)
 */
HAL_StatusTypeDef HAL_FCU_DeInit(HAL_FCU_HandleTypeDef *hfcu);

/**
 * @brief  Initializes the FCU MSP. Weak function; the default implementation
 *         enables the FCU clock and releases its reset through the
 *         SMU_ALB0CFGR register.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @retval None
 */
void HAL_FCU_MspInit(HAL_FCU_HandleTypeDef *hfcu);

/**
 * @brief  De-initializes the FCU MSP. Weak function; the default
 *         implementation disables the FCU clock.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @retval None
 */
void HAL_FCU_MspDeInit(HAL_FCU_HandleTypeDef *hfcu);

/**
  * @}
  */

/** @addtogroup FCU_Exported_Functions_Group2 Peripheral Control functions
  * @{
  */

/**
 * @brief  Enables or disables the specified FCU channel. (NON-BLOCKING)
 * @note   The enable / disable only drives the CFG.EN bit of the channel; the
 *         mask configuration written by HAL_FCU_Init() (Init.MaskEnable) is
 *         left untouched, so a channel that was configured as masked stays
 *         silent even while it is enabled.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_FCU_Init() is required first).
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  Channel: the FCU channel (HAL_FCU_CHANNEL_xxx).
 * @param  NewState: ENABLE or DISABLE (FCU_ENABLE / FCU_DISABLE).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid channel, invalid parameter or the handle
 *         is not initialized)
 */
HAL_StatusTypeDef HAL_FCU_Cmd(HAL_FCU_HandleTypeDef *hfcu, HAL_FCU_ChannelTypeDef Channel,
                              FunctionalState NewState);

/**
 * @brief  Updates the fault level of the specified FCU channel. (NON-BLOCKING)
 * @note   Only the CFG.LEVEL field of the channel is written; its enable,
 *         mask, action and counter fields are preserved. When the channel is
 *         the one configured by HAL_FCU_Init(), the adjusted value is also
 *         written back to the handle Init structure, so that a following
 *         HAL_FCU_Init() keeps it.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_FCU_Init() is required first).
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  Channel: the FCU channel (HAL_FCU_CHANNEL_xxx).
 * @param  Level: the new fault level (HAL_FCU_FAULT_LEVEL_xxx).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid channel, invalid parameter or the handle
 *         is not initialized)
 */
HAL_StatusTypeDef HAL_FCU_SetLevel(HAL_FCU_HandleTypeDef *hfcu, HAL_FCU_ChannelTypeDef Channel,
                                   HAL_FCU_FaultLevelTypeDef Level);

/**
 * @brief  Updates the fault action of the specified FCU channel. (NON-BLOCKING)
 * @note   Only the CFG.FACT field of the channel is written; its alarm action
 *         is preserved.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_FCU_Init() is required first).
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  Channel: the FCU channel (HAL_FCU_CHANNEL_xxx).
 * @param  Action: the new fault action (HAL_FCU_FAULT_INTERRUPT /
 *         HAL_FCU_FAULT_GLOBAL_SOFTWARE_RESET).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid channel, invalid parameter or the handle
 *         is not initialized)
 */
HAL_StatusTypeDef HAL_FCU_SetFaultAction(HAL_FCU_HandleTypeDef *hfcu, HAL_FCU_ChannelTypeDef Channel,
                                         HAL_FCU_FaultActionTypeDef Action);

/**
 * @brief  Updates the alarm action of the specified FCU channel. (NON-BLOCKING)
 * @note   Only the CFG.AACT field of the channel is written; its fault action
 *         is preserved.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_FCU_Init() is required first).
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  Channel: the FCU channel (HAL_FCU_CHANNEL_xxx).
 * @param  Action: the new alarm action (HAL_FCU_ALARM_NONE /
 *         HAL_FCU_ALARM_INTERRUPT).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid channel, invalid parameter or the handle
 *         is not initialized)
 */
HAL_StatusTypeDef HAL_FCU_SetAlarmAction(HAL_FCU_HandleTypeDef *hfcu, HAL_FCU_ChannelTypeDef Channel,
                                         HAL_FCU_AlarmActionTypeDef Action);

/**
 * @brief  Triggers the specified software fault channel(s). (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_FCU_Init() is required first).
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  SoftwareChannel: FCU_SOFTWARE_CHANNEL_0..3 combination.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_FCU_SetSoftwareTrigger(HAL_FCU_HandleTypeDef *hfcu, uint32 SoftwareChannel);

/**
 * @brief  Returns the software fault status of the specified channel(s). (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  SoftwareChannel: FCU_SOFTWARE_CHANNEL_0..3 combination.
 * @retval 1 if the fault status is set, 0 otherwise (also 0 for an invalid
 *         handle, instance or parameter).
 */
uint32 HAL_FCU_GetSoftwareFaultStatus(HAL_FCU_HandleTypeDef *hfcu, uint32 SoftwareChannel);

/**
 * @brief  Sets the software fault count of the specified channel(s). (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_FCU_Init() is required first).
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  SoftwareChannel: FCU_SOFTWARE_CHANNEL_0..3 combination.
 * @param  Count: fault count (0..0xFF).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_FCU_SetSoftwareFaultCount(HAL_FCU_HandleTypeDef *hfcu, uint32 SoftwareChannel,
                                                uint8 Count);

/**
 * @brief  Returns the software fault count of the specified channel. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  SoftwareChannel: FCU_SOFTWARE_CHANNEL_0..3 combination.
 * @retval uint8: the software fault count of the highest selected channel (0
 *         for an invalid handle, instance or parameter).
 */
uint8 HAL_FCU_GetSoftwareFaultCount(HAL_FCU_HandleTypeDef *hfcu, uint32 SoftwareChannel);

/**
 * @brief  Clears the software fault of the specified channel(s). (NON-BLOCKING)
 * @note   Interrupt safe by design: the interface takes no lock and changes no
 *         handle state (it is a status latch clear), so it is callable from an
 *         interrupt service routine (LOCK-04 / RTOS-12).
 * @note   Each selected software channel is handled as a whole: the channel is
 *         temporarily masked (so that the clear cannot re-latch it), the
 *         software fault is cleared through SFCLR, the corresponding fault /
 *         alarm latch of the FCU channel (software channel n is FCU channel
 *         36 + n, whose latch lives in CLEAR1) is cleared, and the previous
 *         mask configuration is restored. Clearing only SFCLR would leave the
 *         latch of the FCU channel set and retrigger the interrupt.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  SoftwareChannel: FCU_SOFTWARE_CHANNEL_0..3 combination.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (NULL pointer, invalid
 *         instance, invalid parameter)
 */
HAL_StatusTypeDef HAL_FCU_ClearSoftwareFault(HAL_FCU_HandleTypeDef *hfcu, uint32 SoftwareChannel);

/**
  * @}
  */

/** @addtogroup FCU_Exported_Functions_Group3 Fault and Alarm functions
  * @{
  */

/**
 * @brief  Returns the alarm status of the specified FCU channel. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  Channel: the FCU channel (HAL_FCU_CHANNEL_xxx).
 * @retval 1 if the alarm is set, 0 otherwise (also 0 for an invalid handle,
 *         instance or channel).
 */
uint32 HAL_FCU_GetAlarmStatus(HAL_FCU_HandleTypeDef *hfcu, HAL_FCU_ChannelTypeDef Channel);

/**
 * @brief  Returns the fault status of the specified FCU channel. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  Channel: the FCU channel (HAL_FCU_CHANNEL_xxx).
 * @retval 1 if the fault is set, 0 otherwise (also 0 for an invalid handle,
 *         instance or channel).
 */
uint32 HAL_FCU_GetFaultStatus(HAL_FCU_HandleTypeDef *hfcu, HAL_FCU_ChannelTypeDef Channel);

/**
 * @brief  Clears the alarm / fault status of the specified FCU channel. (NON-BLOCKING)
 * @note   Interrupt safe by design: the interface takes no lock (LOCK-04 /
 *         RTOS-12), so it is callable from the FCU interrupt service routine.
 *         Taking the lock here would make the routine fail to clear the latched
 *         status whenever a task holds the handle, which would retrigger the
 *         interrupt continuously. It serializes the mask change against an
 *         interrupt with a short critical section instead.
 * @note   The channel is masked for the duration of the clear (so that the
 *         source cannot latch the status again in between), the status is
 *         cleared by writing the target mask directly into the write-one-to-
 *         clear register, and the previous mask configuration is restored.
 * @note   The latch is read back after the clear: when it is still asserted
 *         the underlying fault source is still active, HAL_FCU_ERROR_CLEAR_FAILED
 *         is reported and the handle moves to HAL_FCU_STATE_ERROR (a
 *         recoverable state: the next operation is accepted and clears the
 *         error code again).
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  Channel: the FCU channel (HAL_FCU_CHANNEL_xxx).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (NULL pointer, invalid
 *         instance, invalid parameter or a latch that survived the clear)
 */
HAL_StatusTypeDef HAL_FCU_ClearFcuStatus(HAL_FCU_HandleTypeDef *hfcu, HAL_FCU_ChannelTypeDef Channel);

/**
 * @brief  Clears the alarm / fault latches of a fault source category. (NON-BLOCKING)
 * @note   The category is selected with a mask pair that addresses the CLEAR0
 *         (channels 0..31) and CLEAR1 (channels 32..41) registers; the
 *         published FCU_CATEGORY_CLEAR_xxx_MASK0 / MASK1 pairs can be used
 *         directly, and any other pair of channel masks is accepted as well.
 * @note   Interrupt safe by design: same locking and serialization contract as
 *         HAL_FCU_ClearFcuStatus(). The selected channels are masked for the
 *         duration of the clear and their previous mask configuration is
 *         restored afterwards.
 * @note   The latches are read back after the clear: any selected channel
 *         whose status survives it reports HAL_FCU_ERROR_CLEAR_FAILED and
 *         moves the handle to HAL_FCU_STATE_ERROR.
 * @note   The software fault category additionally owns the SFSTA latch; use
 *         HAL_FCU_ClearSoftwareFault() for software channels, see the group
 *         note of the published masks.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  Mask0: channels 0..31 of the category (bit n selects channel n).
 * @param  Mask1: channels 32..41 of the category (bit n selects channel 32+n).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (NULL pointer, invalid
 *         instance, both masks zero or a latch that survived the clear)
 */
HAL_StatusTypeDef HAL_FCU_ClearCategoryFaultStatus(HAL_FCU_HandleTypeDef *hfcu, uint32 Mask0,
                                                   uint32 Mask1);

/**
 * @brief  Clears the bus timeout fault status. (NON-BLOCKING)
 * @note   Interrupt safe by design: the interface takes no lock and changes no
 *         handle state (it is a write-one-to-clear signal latch), so it is
 *         callable from an interrupt service routine (LOCK-04 / RTOS-12).
 * @note   The clear register is written directly: the bit is written one-to-
 *         clear and the register is never read back and rewritten.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (NULL pointer or invalid
 *         instance)
 */
HAL_StatusTypeDef HAL_FCU_ClearBusTimeoutFaultStatus(HAL_FCU_HandleTypeDef *hfcu);

/**
 * @brief  Clears the ECC fault status. (NON-BLOCKING)
 * @note   Interrupt safe by design: the interface takes no lock and changes no
 *         handle state (it is a write-one-to-clear signal latch), so it is
 *         callable from an interrupt service routine (LOCK-04 / RTOS-12).
 * @note   The clear register is written directly: the bit is written one-to-
 *         clear and the register is never read back and rewritten.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (NULL pointer or invalid
 *         instance)
 */
HAL_StatusTypeDef HAL_FCU_ClearECCFaultStatus(HAL_FCU_HandleTypeDef *hfcu);

/**
  * @}
  */

/** @addtogroup FCU_Exported_Functions_Group4 State functions
  * @{
  */

/**
 * @brief  Returns the FCU handle state. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @retval HAL_FCU_StateTypeDef: the current handle state (HAL_FCU_STATE_RESET
 *         for an invalid handle or instance).
 */
HAL_FCU_StateTypeDef HAL_FCU_GetState(HAL_FCU_HandleTypeDef *hfcu);

/**
 * @brief  Returns the FCU error code. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @retval uint32: the FCU error code (HAL_FCU_ERROR_xxx), 0 for an invalid
 *         handle or instance.
 */
uint32 HAL_FCU_GetError(HAL_FCU_HandleTypeDef *hfcu);

/**
  * @}
  */

/** @addtogroup FCU_Exported_Functions_Group5 Interrupt handling and callbacks
  * @{
  */

/**
 * @brief  Interrupt dispatch entry of the FCU. (NON-BLOCKING)
 * @note   Call this from the user FCU interrupt service routine (FCU_IRQn,
 *         enabled through the PLIC). It takes one snapshot of the four latch
 *         registers, invokes HAL_FCU_FaultCallback() when any fault latch is
 *         set and then HAL_FCU_AlarmCallback() when any alarm latch is set.
 *         Both callbacks run in the interrupt context, so they shall only use
 *         the read-only query interfaces and the interrupt safe clear family
 *         (LOCK-04 / RTOS-12).
 * @note   Read-only with respect to the handle: it takes no lock and changes
 *         no handle state.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @retval None
 */
void HAL_FCU_IRQHandler(HAL_FCU_HandleTypeDef *hfcu);

/**
 * @brief  Fault callback. Weak function; called by HAL_FCU_IRQHandler() when at
 *         least one fault latch is set.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @retval None
 */
void HAL_FCU_FaultCallback(HAL_FCU_HandleTypeDef *hfcu);

/**
 * @brief  Alarm callback. Weak function; called by HAL_FCU_IRQHandler() when at
 *         least one alarm latch is set.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @retval None
 */
void HAL_FCU_AlarmCallback(HAL_FCU_HandleTypeDef *hfcu);

/**
  * @}
  */

/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/

/** @defgroup FCU_Private_Macros FCU Private Macros
  * @{
  */

/**
 * @brief  Check that the FCU peripheral instance is valid.
 */
#define IS_FCU_ALL_INSTANCE(INSTANCE) ((INSTANCE) == FCU)

/**
 * @brief  Check that the FCU channel is a valid value (0..41).
 */
#define IS_FCU_CHANNEL(CHANNEL) ((CHANNEL) <= 0x29U)

/**
 * @brief  Check that the software fault channel is a valid value.
 */
#define IS_FCU_SOFTWARE_CHANNEL(CHANNEL) (((CHANNEL) >= 1U) && ((CHANNEL) <= 0xFU))

/**
 * @brief  Check that the fault count is a valid value (0..0xFF).
 */
#define IS_FCU_FAULT_COUNT(COUNT) ((COUNT) <= 0xFFU)

/**
 * @brief  Check that the fault action is a valid value.
 */
#define IS_FCU_FAULT_ACTION(ACTION) (((ACTION) == HAL_FCU_FAULT_INTERRUPT) || \
                                     ((ACTION) == HAL_FCU_FAULT_GLOBAL_SOFTWARE_RESET))

/**
 * @brief  Check that the alarm action is a valid value.
 */
#define IS_FCU_ALARM_ACTION(ACTION) (((ACTION) == HAL_FCU_ALARM_NONE) || \
                                     ((ACTION) == HAL_FCU_ALARM_INTERRUPT))

/**
 * @brief  Check that the fault level is a valid value.
 */
#define IS_FCU_FAULT_LEVEL(LEVEL) (((LEVEL) == HAL_FCU_FAULT_LEVEL_INVALID) || \
                                   ((LEVEL) == HAL_FCU_FAULT_LEVEL_ALARM)   || \
                                   ((LEVEL) == HAL_FCU_FAULT_LEVEL_FAULT))

/**
 * @brief  Check that the enable value is valid.
 */
#define IS_FCU_ENABLE_STATE(NEWSTATE) (((NEWSTATE) == FCU_ENABLE) || ((NEWSTATE) == FCU_DISABLE))

/**
  * @}
  */

/* Shared internal functions --------------------------------------------------*/

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_FCU_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; when the mutex is not acquired before the
 *         Timeout expires, HAL_TIMEOUT is returned. The value is passed to
 *         HAL_MutexAcquire() as is (RTOS ticks; with the usual 1 ms tick it is
 *         the same quantity as the millisecond Timeout of the public API, and
 *         HAL_MAX_DELAY means an infinite wait).
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef FCU_LockHandle(HAL_FCU_HandleTypeDef *hfcu, uint32 Timeout);

/**
 * @brief  Unlock the handle.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @retval None
 */
void FCU_UnlockHandle(HAL_FCU_HandleTypeDef *hfcu);

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_FCU_H */

/*****END OF FILE*****/
