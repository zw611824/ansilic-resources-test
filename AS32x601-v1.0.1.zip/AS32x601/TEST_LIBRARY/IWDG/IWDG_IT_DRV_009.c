/**
 * @file    IWDG_IT_DRV_009.c
 * @brief   HAL IWDG integration test case 009 (watchdog system reset).
 *
 * One-to-one HAL library port of the reference AS32x601 standard-library
 * test case IWDG_IT_DRV_009.c. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_IWDG_Init() / HAL_IWDG_Cmd() / HAL_IWDG_Refresh()
 *   HAL_IWDG_GetCounter() / HAL_IWDG_GetState()
 *   HAL_FCU_Init() with HAL_FCU_FAULT_GLOBAL_SOFTWARE_RESET
 *
 * Test procedure:
 *   The IWDG channel of the FCU is configured with the global software reset
 *   fault action, so a watchdog timeout restarts the whole system instead of
 *   raising an interrupt. The marker value is written into the backup RAM
 *   (APB_BusS domain, kept across a soft reset) and the watchdog is armed with
 *   PSC 2 / DIV 2 / BVAL 10000 (1.831 s) without any refresh:
 *     1. first pass  : the marker is written, the watchdog is armed and the
 *        core spins until the reset hits;
 *     2. second pass : the marker is still present, the post reset register
 *        state is printed, a very long timeout is programmed first (so a block
 *        that survived the reset cannot reset the system again), the
 *        configuration block is stopped and the reference configuration is
 *        restored;
 *     3. the marker is cleared and the watchdog is armed again, so every round
 *        of the case ends with exactly one system reset.
 *
 * Expected behaviour:
 *   the system restarts after the programmed timeout, the backup RAM marker
 *   survives the reset, the watchdog can be reconfigured and stopped after the
 *   reset and every check prints [PASS] with "summary : failures = 0".
 *
 * Note:
 *   The reference test case uses a variable in the normal RAM as the marker.
 *   This port moves the marker into the backup RAM of the always-on domain,
 *   which is the storage the chip provides for exactly this purpose. The FCU
 *   is configured only in the first pass: after the reset the channel keeps
 *   its reset (no action) value, so the recovery steps can never reset the
 *   system a second time.
 */

/* Includes ------------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
#define TEST_BAUDRATE                 (115200U)   /*!< console baud rate         */
#define TEST_PD4_PORT                 GPIOD       /*!< marker pin port (PD4)     */
#define TEST_PD4_PIN                  GPIO_PIN_4  /*!< marker pin of the case    */
#define TEST_PD4_ON                   GPIO_PIN_SET
#define TEST_PD4_OFF                  GPIO_PIN_RESET
#define TEST_WAIT_SLACK_MS            (500U)      /*!< extra budget on top of the
                                                       expected alarm time       */
#define TEST_CLOCK_HZ                 (32768U)    /*!< IWDG clock (APB_BusS)    */
#define TEST_STALL_WINDOW_MS          (100U)      /*!< observation window of the
                                                       counter movement checks   */
#define TEST_PRESCALER                (2U)        /*!< PSC.PSCNUM               */
#define TEST_DIVIDER                  (2U)        /*!< DIV.DIVNUM               */
#define TEST_TIMEOUT                  (10000U)    /*!< TO.BVAL (1.831 s)        */
#define TEST_FLAG_ADDR                ((uint32)BACKUP_RAM_BASE)
#define TEST_MAGIC                    ((uint32)0x49574447U) /*!< "IWDG"          */
#define TEST_LONG_PRESCALER           (0xFFU)     /*!< recovery PSC.PSCNUM      */
#define TEST_LONG_DIVIDER             (0xFFFFU)   /*!< recovery DIV.DIVNUM      */
#define TEST_LONG_TIMEOUT             (0xFFFFU)   /*!< recovery TO.BVAL         */

/* Private variables ---------------------------------------------------------*/
static volatile uint32        check_failures = 0U;  /*!< failed check counter */
static HAL_SMU_HandleTypeDef  hsmu_clk;             /*!< SMU handle           */
static HAL_PMU_HandleTypeDef  hpmu_dev;             /*!< PMU handle           */

IWDG_HandleTypeDef     hiwdg_dev;                   /*!< device under test     */
HAL_FCU_HandleTypeDef  hfcu_dev;                    /*!< alarm / reset source  */

/* Shared helpers of this suite (defined at the end of this file) */
void Check(const char *name, uint32 condition);
void Test_WatchdogQuiesce(void);
void Summary(void);
void SystemClock_Init(void);
void Test_Pd4Init(void);
void Test_Pd4Set(GPIO_PinState state);
HAL_StatusTypeDef Test_IwdgApply(uint32 prescaler, uint32 divider,
                                 uint32 timeout_value);
uint32 Test_CounterStalled(uint32 window_ms);
void Test_FcuConfig(HAL_FCU_FaultActionTypeDef fault_action,
                    HAL_FCU_AlarmActionTypeDef alarm_action,
                    HAL_FCU_FaultLevelTypeDef level);

/**
 * @brief  Arm the watchdog so that its fault request resets the system.
 * @note   The FCU channel of the IWDG is configured (by the caller) with
 *         HAL_FCU_FAULT_GLOBAL_SOFTWARE_RESET, so the timeout of the watchdog
 *         resets the whole system instead of raising an interrupt. The
 *         configuration is programmed again from a cleared handle, because the
 *         peripheral state of the previous run is meaningless after a reset.
 * @param  None
 * @retval None
 */
void Test_ArmReset(void)
{
    /* The SMU lives in the always-on domain: the clock gate of the FCU can be
     * left closed by whatever image ran before (it survives `reg pc` restarts
     * and ndmreset). With the gate closed the alarm is still latched by the FCU
     * but its interrupt line never reaches the PLIC, so the wait below could
     * never succeed. The vendor library does the same explicitly. */
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_FCU_CLK_ENABLE();
    __HAL_SMU_FCU_RELEASE_RESET();
    HAL_StatusTypeDef status;
    uint32            expected_us;

    __HAL_CLEAR_STRUCT(&hiwdg_dev);

    status = Test_IwdgApply(TEST_PRESCALER, TEST_DIVIDER, TEST_TIMEOUT);
    if (status != HAL_OK)
    {
        printf("   [FAIL] the watchdog could not be programmed before the reset\r\n");
    }

    expected_us = (uint32)(((uint64)(TEST_PRESCALER + 1U) * (uint64)TEST_DIVIDER *
                            (uint64)TEST_TIMEOUT * 1000000ULL) /
                           (uint64)TEST_CLOCK_HZ);
    printf("   arming the watchdog, expected reset after %u us (%.3f s)\r\n",
           PRINT_U32(expected_us), (double)expected_us / 1000000.0);

    Test_Pd4Set(TEST_PD4_ON);
    (void)HAL_IWDG_Refresh(&hiwdg_dev);
    (void)HAL_IWDG_Cmd(&hiwdg_dev, IWDG_EN_CFG, ENABLE);
}

/**
 * @brief  Put the watchdog into a known stopped state.
 * @note   The IWDG lives in the always-on domain: CFG.EN survives ndmreset and
 *         a restart from the reset vector, so an image that was armed when the
 *         previous run ended keeps the block running (and would keep resetting
 *         the chip). The cases assert the stopped state right after their own
 *         initialization, so the block is quiesced once at start up.
 * @note   The register is written directly: the handle is not initialized yet,
 *         so HAL_IWDG_Cmd() would be refused by the state gate.
 * @param  None
 * @retval None
 */
void Test_WatchdogQuiesce(void)
{
    WRITE_REG(IWDG->CFG, 0U);
    WRITE_REG(IWDG->PSC, 0U);
    WRITE_REG(IWDG->DIV, 0U);
    WRITE_REG(IWDG->TO, 0U);
}

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    /* A running watchdog left behind by the previous run would reset the chip
     * here and would make the "block is stopped" checks below fail */
    Test_WatchdogQuiesce();
    volatile uint32  *flag = (volatile uint32 *)TEST_FLAG_ADDR;
    HAL_StatusTypeDef status;
    uint32            rounds = 0U;
    uint32            psc_read;
    uint32            div_read;
    uint32            to_read;
    uint32            cfg_read;

    HAL_Init();
    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);

    printf("\r\n=== IWDG_IT_DRV_009 : watchdog system reset ===\r\n");
    printf("IWDG clock = %u Hz, reset marker at 0x%08X\r\n",
           PRINT_U32(TEST_CLOCK_HZ), PRINT_U32(TEST_FLAG_ADDR));

    if (*flag != TEST_MAGIC)
    {
        /* ---------------- first pass: arm the watchdog ---------------- */
        printf("-- first pass : no refresh, waiting for the system reset --\r\n");

        /* Marker first: it is what proves the restart after the reset */
        *flag = TEST_MAGIC;

        Test_Pd4Init();
        Test_Pd4Set(TEST_PD4_ON);

        /* The fault action of the channel is a global software reset, so the
         * timeout restarts the whole system instead of raising an interrupt */
        Test_FcuConfig(HAL_FCU_FAULT_GLOBAL_SOFTWARE_RESET, HAL_FCU_ALARM_NONE,
                       HAL_FCU_FAULT_LEVEL_FAULT);

        Test_ArmReset();

        for (;;)
        {
            /* Wait for the watchdog to reset the system. PD4 stays high, so a
             * scope shows the whole interval between the arm and the reset. */
        }
    }

    /* ---------------- second pass: the system restarted ---------------- */
    printf("-- second pass : the system restarted (round %u) --\r\n", PRINT_U32(rounds));
    printf("   marker read back = 0x%08X\r\n", PRINT_U32(*flag));

    /* Observation of the post reset register state (not asserted: whether the
     * always-on domain keeps its value across the reset is a silicon detail) */
    psc_read = READ_REG(IWDG->PSC);
    div_read = READ_REG(IWDG->DIV);
    to_read  = READ_REG(IWDG->TO);
    cfg_read = READ_REG(IWDG->CFG);
    printf("   PSC=0x%08X DIV=0x%08X TO=0x%08X CFG=0x%08X\r\n",
           PRINT_U32(psc_read), PRINT_U32(div_read), PRINT_U32(to_read),
           PRINT_U32(cfg_read));

    /* Recover a known state. A very long timeout is programmed first, so that
     * a configuration block that is still enabled cannot reset the system
     * again before it is stopped. */
    __HAL_CLEAR_STRUCT(&hiwdg_dev);
    status = Test_IwdgApply(TEST_LONG_PRESCALER, TEST_LONG_DIVIDER, TEST_LONG_TIMEOUT);
    Check("reset     : HAL_IWDG_Init() accepts a configuration after the reset",
          (status == HAL_OK) ? 1U : 0U);

    status = HAL_IWDG_Cmd(&hiwdg_dev, IWDG_EN_CFG, DISABLE);
    Check("reset     : the configuration block can be stopped after the reset",
          (status == HAL_OK) ? 1U : 0U);
    Check("reset     : CFG.EN is cleared after the recovery",
          ((READ_REG(IWDG->CFG) & IWDG_CFG_EN) == 0U) ? 1U : 0U);

    status = Test_IwdgApply(TEST_PRESCALER, TEST_DIVIDER, TEST_TIMEOUT);
    Check("reset     : the reference configuration is accepted after the reset",
          (status == HAL_OK) ? 1U : 0U);
    Check("reset     : the handle is READY after the recovery",
          (HAL_IWDG_GetState(&hiwdg_dev) == HAL_IWDG_STATE_READY) ? 1U : 0U);
    Check("reset     : the watchdog does not count while CFG.EN = 0",
          Test_CounterStalled(TEST_STALL_WINDOW_MS) ? 1U : 0U);

    /* The marker is cleared, so the next pass arms the watchdog again */
    *flag = 0U;
    Check("reset     : the marker is cleared for the next pass",
          (*flag == 0U) ? 1U : 0U);

    Summary();

    /* Arm the watchdog again: the whole sequence then repeats, which keeps the
     * case observable round after round (every round ends with one reset) */
    Test_Pd4Set(TEST_PD4_ON);
    Test_FcuConfig(HAL_FCU_FAULT_GLOBAL_SOFTWARE_RESET, HAL_FCU_ALARM_NONE,
                   HAL_FCU_FAULT_LEVEL_FAULT);
    *flag = TEST_MAGIC;
    Test_ArmReset();

    for (;;)
    {
    }
}

/* ==========================================================================*/
/*  Shared helpers of the suite (identical in every case of this suite)       */
/* ==========================================================================*/

/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the other integration tests of this library:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2 and
 *         CANX2 by 8, which gives core 180 MHz and APB 22.5 MHz. The IWDG is
 *         clocked from the always-on APB_BusS domain (32768 Hz), so this tree
 *         only supplies the console, the delay module and the marker pin.
 * @note   Clock tree order: the dividers are written while the system clock
 *         is still the power on source (FIRC), then the PLL is configured and
 *         the system clock is switched to it. That last call programs the
 *         flash controller clock before the switch (the core keeps fetching
 *         from the flash) and updates SystemCoreClock afterwards.
 * @param  None
 * @retval None
 */
void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks (console pins of USART0 and the PD4 marker pin) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu_dev);
    hpmu_dev.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu_dev);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu_dev, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu_dev, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* The SMU is in the always-on domain: the clock tree of the previous image
     * (or of the flash programmer) survives ndmreset and a restart from the
     * reset vector. Put it back into its power-on shape first, so that the
     * configuration below is applied to a known state - otherwise the PLL is
     * found enabled, the feedback divider of this configuration is ignored, and
     * the console ends up at the wrong baud rate. HAL_SMU_DeInit() is the
     * driver's own sequence for that: it switches the core to the FIRC,
     * reprograms the flash wait states with the CLK_UPDATE handshake and holds
     * the PLL in reset. */
    (void)HAL_SMU_DeInit(&hsmu_clk, SMU_TIMEOUT_DEFAULT);
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Metafields of the two configuration structures (Version+Size contract,
     * same discipline as the IWDG configuration below). The business fields are
     * overwritten one by one, everything else must start at zero. */
    __HAL_CLEAR_STRUCT(&SMU_OscInitStruct);
    SMU_OscInitStruct.Size    = (uint32)sizeof(SMU_OscInitTypeDef);
    SMU_OscInitStruct.Version = SMU_OSC_INIT_VERSION;
    __HAL_CLEAR_STRUCT(&SMU_ClockInitStruct);
    SMU_ClockInitStruct.Size    = (uint32)sizeof(SMU_ClockInitTypeDef);
    SMU_ClockInitStruct.Version = SMU_CLOCK_INIT_VERSION;

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.Size             = (uint32)sizeof(SMU_PLLConfigTypeDef);
    SMU_OscInitStruct.PLL.Version          = SMU_PLL_INIT_VERSION;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Configure the PD4 marker pin as a push-pull output.
 * @note   The reference test case drives PD4 to be able to measure the alarm
 *         or the reset on a scope: the pin is set before the watchdog is
 *         started and released by the event.
 * @param  None
 * @retval None
 */
void Test_Pd4Init(void)
{
    GPIO_InitTypeDef gpio_init;

    __HAL_CLEAR_STRUCT(&gpio_init);
    HAL_GPIO_StructInit(&gpio_init);
    gpio_init.Pin          = TEST_PD4_PIN;
    gpio_init.Mode         = GPIO_MODE_OUTPUT_PP;
    gpio_init.Pull         = GPIO_NOPULL;
    gpio_init.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    gpio_init.Alternate    = 0U;

    HAL_GPIO_Init(TEST_PD4_PORT, &gpio_init);
}

/**
 * @brief  Drive the PD4 marker pin.
 * @param  state: GPIO_PIN_SET (watchdog armed, waiting) / GPIO_PIN_RESET (event)
 * @retval None
 */
void Test_Pd4Set(GPIO_PinState state)
{
    HAL_GPIO_WritePin(TEST_PD4_PORT, TEST_PD4_PIN, state);
}

/**
 * @brief  Program the watchdog through HAL_IWDG_Init().
 * @note   The driver has no HAL_IWDG_StructInit(): the configuration
 *         structure follows the Version+Size mechanism, so the metafields are
 *         filled here (the business fields are overwritten on every call).
 *         HAL_IWDG_Init() enables the prescaler block (PSC.EN) and never
 *         starts the watchdog (CFG.EN stays untouched).
 * @param  prescaler:     PSC.PSCNUM value (2..255)
 * @param  divider:       DIV.DIVNUM value (2..65535)
 * @param  timeout_value: TO.BVAL value (0..65535)
 * @retval HAL_StatusTypeDef of HAL_IWDG_Init()
 */
HAL_StatusTypeDef Test_IwdgApply(uint32 prescaler, uint32 divider,
                                 uint32 timeout_value)
{
    hiwdg_dev.Instance         = IWDG;
    hiwdg_dev.Init.Size        = (uint32)sizeof(IWDG_InitTypeDef);
    hiwdg_dev.Init.Version     = IWDG_INIT_VERSION;
    hiwdg_dev.Init.Prescaler   = prescaler;
    hiwdg_dev.Init.Reload      = timeout_value;
    hiwdg_dev.Init.Divider     = divider;
    hiwdg_dev.Init.Reserved[0] = 0U;
    hiwdg_dev.Init.Reserved[1] = 0U;

    return HAL_IWDG_Init(&hiwdg_dev);
}

/**
 * @brief  Check that the watchdog counter does not advance.
 * @note   The counter runs from the always-on 32768 Hz clock divided by
 *         (PSCNUM + 1) * DIVNUM, so a 100 ms window covers several counts and
 *         a stalled counter is unambiguous. The comparison is on the movement
 *         rather than on the absolute value, so the check does not depend on
 *         whether the hardware clears the counter when a block is disabled.
 * @param  window_ms: observation window in milliseconds
 * @retval uint32: 1 when the counter did not move, 0 otherwise
 */
uint32 Test_CounterStalled(uint32 window_ms)
{
    uint32 first = (uint32)HAL_IWDG_GetCounter(&hiwdg_dev);

    delay_ms(window_ms);

    return ((uint32)HAL_IWDG_GetCounter(&hiwdg_dev) == first) ? 1U : 0U;
}

/**
 * @brief  Configure the IWDG channel of the FCU.
 * @note   MaskEnable = FCU_DISABLE unmasks the channel (an enabled mask keeps
 *         the channel silent), which is the configuration of the reference
 *         test case.
 * @param  fault_action: action at fault level
 * @param  alarm_action: action at alarm level
 * @param  level:        fault level of the channel
 * @retval None
 */
void Test_FcuConfig(HAL_FCU_FaultActionTypeDef fault_action,
                    HAL_FCU_AlarmActionTypeDef alarm_action,
                    HAL_FCU_FaultLevelTypeDef level)
{
    FCU_InitTypeDef fcu_init;

    __HAL_CLEAR_STRUCT(&hfcu_dev);
    hfcu_dev.Instance = FCU;

    HAL_FCU_StructInit(&fcu_init);
    fcu_init.Channel           = HAL_FCU_CHANNEL_IWDG;
    fcu_init.FaultToResetCount = 0U;
    fcu_init.AlarmToFaultCount = 0U;
    fcu_init.FaultAction       = fault_action;
    fcu_init.AlarmAction       = alarm_action;
    fcu_init.FaultLevel        = level;
    fcu_init.MaskEnable        = FCU_DISABLE;

    hfcu_dev.Init = fcu_init;

    (void)HAL_FCU_Init(&hfcu_dev);
    (void)HAL_FCU_Cmd(&hfcu_dev, HAL_FCU_CHANNEL_IWDG, FCU_ENABLE);
}

/*****END OF FILE*****/
