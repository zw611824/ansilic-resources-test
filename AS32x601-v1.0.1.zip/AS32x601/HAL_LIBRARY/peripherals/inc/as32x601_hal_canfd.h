/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_canfd.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.4
 * Date:   2026/09/17
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.1     align with the source file
 *                                                       V1.1 (transmit data-word
 *                                                       packing fix: uint32 widening
 *                                                       and zero-padded tail)
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.2     fix the CANFD_STATUS_* bit
 *                                                       positions: PEE_CONFIG bit 9,
 *                                                       BSFR_CONFIG bit 10, SNOOP
 *                                                       bit 12 (were bit 8/9/10),
 *                                                       matching the device-layer
 *                                                       status register layout
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.3     add the handle lock
 *                                                       mechanism: the shared
 *                                                       CANFD_LockHandle /
 *                                                       CANFD_UnlockHandle
 *                                                       functions are declared in
 *                                                       the shared internal
 *                                                       section, every register
 *                                                       writing function takes the
 *                                                       lock, the read only
 *                                                       functions stay unlocked,
 *                                                       and the handle gains the
 *                                                       RTOS LockMutex member
 *     ANSILIC APPLICATION GROUP  2026/09/17     1.4     architecture compliance
 *                                                       rework of the resource
 *                                                       lock and RTOS chapters
 *                                                       (matching the source file
 *                                                       V1.4): the MSP callbacks
 *                                                       run outside the locked
 *                                                       region (LOCK-06 /
 *                                                       ARCH-CONST-04),
 *                                                       CANFD_LockHandle() takes a
 *                                                       Timeout parameter and
 *                                                       reports a missing RTOS
 *                                                       mutex (RTOS-11),
 *                                                       HAL_CANFD_NormalStatus()
 *                                                       and the transmit functions
 *                                                       take a Timeout parameter
 *                                                       and return
 *                                                       HAL_TIMEOUT on expiry
 *                                                       (POLL-01/02/03, RTOS-04),
 *                                                       the state enumeration
 *                                                       gains BUSY and TIMEOUT and
 *                                                       the ARCH-CONST-09 state
 *                                                       gate was added, and the
 *                                                       blocking functions are
 *                                                       tagged (BLOCKING)
 *                                                       (POLL-04)
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Controller Area
 *                  Network Flexible Data-rate (CAN FD) interface, as a
 *                  HAL peripheral driver of this library:
 *                  - Initialization and de-initialization: HAL_CANFD_Init /
 *                    HAL_CANFD_DeInit, configuration structure handling;
 *                  - Mode control: normal / sleep / loopback / snoop and
 *                    the associated configuration switches (bit rate
 *                    switch, auto retransmission, protocol exception,
 *                    bus-off recovery);
 *                  - Filtering: per-filter acceptance mask / ID pair
 *                    configuration and receive-all mode;
 *                  - Frame handling: transmit (single / loopback), receive
 *                    data / info retrieval;
 *                  - Interrupt control: source enable / disable, status
 *                    query and pending clear;
 *                  - Status and error reporting.
 *                  The CAN FD controller of the AS32x601 exposes an
 *                  arbitration-phase (nominal) and a data-phase timing
 *                  configuration, 32 transmit buffers, 32 acceptance filter
 *                  pairs and a 64-message RX FIFO.
 * @complexity  Medium
 *              Blocking (polling) only, state machine (BUSY / TIMEOUT states
 *              and the ARCH-CONST-09 state gate), handle lock (bare metal
 *              flag or RTOS mutex with Timeout), no IT/DMA.
 */
#ifndef __AS32X601_HAL_CANFD_H
#define __AS32X601_HAL_CANFD_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "as32x601.h"               /* CANFD_TypeDef, CANFD register bits     */
#include "as32x601_hal_def.h"       /* HAL_StatusTypeDef, HAL_LockTypeDef     */

/* Exported constants --------------------------------------------------------*/

/**
 * @brief CANFD HAL driver module version.
 * @note  0x0100U = V1.0. Bumped only on breaking API changes (architecture
 *        spec COMPAT-13/14/15).
 */
#define __HAL_CANFD_MODULE_VERSION  0x0100U

/* Exported types ------------------------------------------------------------*/

/** @defgroup CANFD_Exported_Types CANFD Exported Types
  * @{
  */

/**
 * @brief CAN FD configuration structure definition.
 * @note  The arbitration phase (nominal) and the data phase each carry a
 *        prescaler and a bit timing (time segment 1/2 and synchronization
 *        jump width).  All values are register encodings: the prescaler
 *        encoding equals the divider minus one (1..256 -> 0x00..0xFF).
 */
typedef struct
{
    uint32 Size;            /*!< sizeof(CANFD_InitTypeDef), set by the user
                                 after clearing the structure */
    uint32 Version;         /*!< Structure semantic version: @ref CANFD_INIT_VERSION
                                 (CANFD_INIT_V1 = 0x0100U) */
    uint32 CANFD_SRR;            /*!< Software reset / enable: CANFD_SRR_xxx     */
    uint32 CANFD_APBRPR;         /*!< Arbitration phase prescaler encoding       */
    uint32 CANFD_APBTR_APTS1;    /*!< Arbitration phase time segment 1 encoding  */
    uint32 CANFD_APBTR_APTS2;    /*!< Arbitration phase time segment 2 encoding  */
    uint32 CANFD_APBTR_APSJW;    /*!< Arbitration phase sync jump width encoding */
    uint32 CANFD_DPBRPR;         /*!< Data phase prescaler encoding              */
    uint32 CANFD_DPBTR_DPTS1;    /*!< Data phase time segment 1 encoding         */
    uint32 CANFD_DPBTR_DPTS2;    /*!< Data phase time segment 2 encoding         */
    uint32 CANFD_DPBTR_DPSJW;    /*!< Data phase sync jump width encoding        */
    uint32 Reserved[2];          /*!< Reserved for future extension (must be 0) */
} CANFD_InitTypeDef;

/**
 * @brief CANFD init structure version macros.
 * @note  CANFD_INIT_V1 is the current version. Future versions must be
 *        appended after the existing fields (architecture spec section 22.5).
 */
#define CANFD_INIT_V1  0x0100U   /*!< CANFD Init structure version V1.0 */
#define CANFD_INIT_VERSION  CANFD_INIT_V1   /*!< Current CANFD Init structure version */

/**
 * @brief CAN FD transmit frame structure definition.
 */
typedef struct
{
    uint32 CANFD_TX_PROTOCOL;    /*!< Frame protocol: CANFD_PROTOCOL_CAN / CANFD / CANFD_BRS */
    uint32 CANFD_TX_FORMAT;      /*!< Frame format: CANFD_FORMAT_STANDARD / EXTENDED         */
    uint32 CANFD_TX_TYPE;        /*!< Frame type: CANFD_TYPE_DATA / REMOTE                    */
    uint32 CANFD_Frame_ID;       /*!< Frame identifier (standard 11-bit / extended 29-bit)     */
} CANFD_TXFrameTypeDef;

/**
 * @brief CAN FD receive info structure definition.
 */
typedef struct
{
    uint8  CANFD_Message_Count;              /*!< Number of messages pending in the RX FIFO  */
    uint32 CANFD_CurrentMessage_PROTOCOL;    /*!< Protocol of the current message            */
    uint32 CANFD_CurrentMessage_FORMAT;      /*!< Format of the current message              */
    uint32 CANFD_CurrentMessage_TYPE;        /*!< Type of the current message                */
    uint32 CANFD_CurrentFrame_ID;            /*!< Identifier of the current message          */
    uint32 CANFD_CurrentMessage_DLC;         /*!< Data length code of the current message    */
} CANFD_RXInfoTypeDef;

/**
 * @brief CAN FD filter configuration structure definition.
 */
typedef struct
{
    uint32 CANFD_FilterNumber;   /*!< Filter index, 0..31                              */
    uint32 CANFD_FilterMask;     /*!< Acceptance filter mask register value (AFMR)    */
    uint32 CANFD_FilterID;       /*!< Acceptance filter ID register value (AFIR)      */
    uint32 CANFD_FilterCmd;      /*!< CANFD_ENABLE / CANFD_DISABLE                    */
} CANFD_FilterConfigTypeDef;

/**
 * @brief HAL CAN FD state structures definition.
 */
typedef enum
{
    HAL_CANFD_STATE_RESET     = 0x00U, /*!< Peripheral not initialized              */
    HAL_CANFD_STATE_READY     = 0x01U, /*!< Peripheral initialized and ready        */
    HAL_CANFD_STATE_SLEEP     = 0x02U, /*!< Peripheral in sleep mode                */
    HAL_CANFD_STATE_LISTEN    = 0x03U, /*!< Peripheral in listen / snoop mode       */
    HAL_CANFD_STATE_ERROR     = 0x04U, /*!< Peripheral in error state (recoverable) */
    HAL_CANFD_STATE_BUSY      = 0x05U, /*!< A transmit operation is in progress     */
    HAL_CANFD_STATE_TIMEOUT   = 0x06U  /*!< An operation timed out (recoverable)    */
} HAL_CANFD_StateTypeDef;

/**
 * @brief CAN FD handle structure definition.
 */
typedef struct __CANFD_HandleTypeDef
{
    CANFD_TypeDef            *Instance;      /*!< CAN FD registers base address     */
    CANFD_InitTypeDef        Init;           /*!< CAN FD communication parameters   */
    HAL_LockTypeDef          Lock;           /*!< Locking object                    */
    __IO HAL_CANFD_StateTypeDef State;       /*!< CAN FD communication state        */
    __IO uint32              ErrorCode;      /*!< CAN FD error code                 */
#if (USE_RTOS == 1)
    HAL_MutexTypeDef         LockMutex;      /*!< RTOS mutex handle (created by the
                                                  user porting layer, e.g. in
                                                  HAL_CANFD_MspInit)              */
#endif /* USE_RTOS */
} CANFD_HandleTypeDef;

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @defgroup CANFD_Exported_Constants CANFD Exported Constants
  * @{
  */

/** @defgroup CANFD_Error_Code CANFD Error Code
  * @{
  */
#define HAL_CANFD_ERROR_NONE     ((uint32)0x00000000U)  /*!< No error                       */
#define HAL_CANFD_ERROR_TX       ((uint32)0x00000001U)  /*!< Transmit error                 */
#define HAL_CANFD_ERROR_RX       ((uint32)0x00000002U)  /*!< Receive error                  */
#define HAL_CANFD_ERROR_ARBLST   ((uint32)0x00000004U)  /*!< Arbitration lost               */
#define HAL_CANFD_ERROR_BUSOFF   ((uint32)0x00000008U)  /*!< Bus-off error                  */
#define HAL_CANFD_ERROR_TIMEOUT  ((uint32)0x00000010U)  /*!< Timeout error                  */
/**
  * @}
  */

/** @defgroup CANFD_Enable_Value CANFD Enable Value
  * @{
  */
#define CANFD_ENABLE     1U        /*!< Enable the CAN FD peripheral / function  */
#define CANFD_DISABLE    0U        /*!< Disable the CAN FD peripheral / function */
/**
  * @}
  */

/** @defgroup CANFD_Software_Reset CANFD Software Reset
  * @{
  */
#define CANFD_SRR_RESET   ((uint32)0x00000001U)  /*!< CAN FD software reset  */
#define CANFD_SRR_ENABLE  ((uint32)0x00000002U)  /*!< CAN FD enable          */
/**
  * @}
  */

/** @defgroup CANFD_Value_Encoding CANFD Value Encoding Helpers
  * @note  The timing fields store the register encoding (divider minus one);
  *        these helpers convert a natural value (1-based) into the encoding.
  * @{
  */
#define CANFD_APBRPR_PRESCALER(VALUE)   ((uint32)(VALUE) - 1U)   /*!< 1..256 -> 0x00..0xFF */
#define CANFD_APBTR_TS1_VALUE(VALUE)    ((uint32)(VALUE) - 1U)   /*!< 1..256 -> 0x00..0xFF */
#define CANFD_APBTR_TS2_VALUE(VALUE)    ((uint32)(VALUE) - 1U)   /*!< 1..128 -> 0x00..0x7F */
#define CANFD_APBTR_SJW_VALUE(VALUE)    ((uint32)(VALUE) - 1U)   /*!< 1..128 -> 0x00..0x7F */
#define CANFD_DPBRPR_PRESCALER(VALUE)   ((uint32)(VALUE) - 1U)   /*!< 1..256 -> 0x00..0xFF */
#define CANFD_DPBTR_TS1_VALUE(VALUE)    ((uint32)(VALUE) - 1U)   /*!< 1..32  -> 0x00..0x1F */
#define CANFD_DPBTR_TS2_VALUE(VALUE)    ((uint32)(VALUE) - 1U)   /*!< 1..16  -> 0x00..0x0F */
#define CANFD_DPBTR_SJW_VALUE(VALUE)    ((uint32)(VALUE) - 1U)   /*!< 1..16  -> 0x00..0x0F */
/**
  * @}
  */

/** @defgroup CANFD_Frame_Protocol CANFD Frame Protocol
  * @{
  */
#define CANFD_PROTOCOL_CAN       ((uint32)0x00000000U)  /*!< Classic CAN frame            */
#define CANFD_PROTOCOL_CANFD     ((uint32)0x00000002U)  /*!< CAN FD frame (no BRS)        */
#define CANFD_PROTOCOL_CANFD_BRS ((uint32)0x00000003U)  /*!< CAN FD frame with BRS         */
/**
  * @}
  */

/** @defgroup CANFD_Frame_Format CANFD Frame Format
  * @{
  */
#define CANFD_FORMAT_STANDARD    ((uint32)0x00000000U)  /*!< Standard (11-bit) identifier  */
#define CANFD_FORMAT_EXTENDED    ((uint32)0x00000001U)  /*!< Extended (29-bit) identifier  */
/**
  * @}
  */

/** @defgroup CANFD_Frame_Type CANFD Frame Type
  * @{
  */
#define CANFD_TYPE_DATA          ((uint32)0x00000000U)  /*!< Data frame                    */
#define CANFD_TYPE_REMOTE        ((uint32)0x00000001U)  /*!< Remote frame                  */
/**
  * @}
  */

/** @defgroup CANFD_Data_Length_Code CANFD Data Length Code
  * @{
  */
#define CANFD_DLC_0B   ((uint32)0x00000000U)  /*!< Data length code 0  (0 bytes)   */
#define CANFD_DLC_1B   ((uint32)0x00000001U)  /*!< Data length code 1  (1 byte)    */
#define CANFD_DLC_2B   ((uint32)0x00000002U)  /*!< Data length code 2  (2 bytes)   */
#define CANFD_DLC_3B   ((uint32)0x00000003U)  /*!< Data length code 3  (3 bytes)   */
#define CANFD_DLC_4B   ((uint32)0x00000004U)  /*!< Data length code 4  (4 bytes)   */
#define CANFD_DLC_5B   ((uint32)0x00000005U)  /*!< Data length code 5  (5 bytes)   */
#define CANFD_DLC_6B   ((uint32)0x00000006U)  /*!< Data length code 6  (6 bytes)   */
#define CANFD_DLC_7B   ((uint32)0x00000007U)  /*!< Data length code 7  (7 bytes)   */
#define CANFD_DLC_8B   ((uint32)0x00000008U)  /*!< Data length code 8  (8 bytes)   */
#define CANFD_DLC_12B  ((uint32)0x00000009U)  /*!< Data length code 9  (12 bytes)  */
#define CANFD_DLC_16B  ((uint32)0x0000000AU)  /*!< Data length code 10 (16 bytes)  */
#define CANFD_DLC_20B  ((uint32)0x0000000BU)  /*!< Data length code 11 (20 bytes)  */
#define CANFD_DLC_24B  ((uint32)0x0000000CU)  /*!< Data length code 12 (24 bytes)  */
#define CANFD_DLC_32B  ((uint32)0x0000000DU)  /*!< Data length code 13 (32 bytes)  */
#define CANFD_DLC_48B  ((uint32)0x0000000EU)  /*!< Data length code 14 (48 bytes)  */
#define CANFD_DLC_64B  ((uint32)0x0000000FU)  /*!< Data length code 15 (64 bytes)  */
/**
  * @}
  */

/** @defgroup CANFD_Byte_Count CANFD Byte Count
  * @{
  */
#define CANFD_BYTES_0   0U   /*!< 0 bytes  */
#define CANFD_BYTES_1   1U   /*!< 1 byte   */
#define CANFD_BYTES_2   2U   /*!< 2 bytes  */
#define CANFD_BYTES_3   3U   /*!< 3 bytes  */
#define CANFD_BYTES_4   4U   /*!< 4 bytes  */
#define CANFD_BYTES_5   5U   /*!< 5 bytes  */
#define CANFD_BYTES_6   6U   /*!< 6 bytes  */
#define CANFD_BYTES_7   7U   /*!< 7 bytes  */
#define CANFD_BYTES_8   8U   /*!< 8 bytes  */
#define CANFD_BYTES_12  12U  /*!< 12 bytes */
#define CANFD_BYTES_16  16U  /*!< 16 bytes */
#define CANFD_BYTES_20  20U  /*!< 20 bytes */
#define CANFD_BYTES_24  24U  /*!< 24 bytes */
#define CANFD_BYTES_32  32U  /*!< 32 bytes */
#define CANFD_BYTES_48  48U  /*!< 48 bytes */
#define CANFD_BYTES_64  64U  /*!< 64 bytes */
/**
  * @}
  */

/** @defgroup CANFD_Transmit_Buffer_Bitmask CANFD Transmit Buffer Bitmask
  * @{
  */
#define CANFD_SEND_ALL   ((uint32)0xFFFFFFFFU)  /*!< Select all transmit buffers */
/**
  * @}
  */

/** @defgroup CANFD_Status CANFD Status Flags
  * @{
  */
#define CANFD_STATUS_CONFIG      ((uint32)0x00000001U)  /*!< Configuration mode indicator   */
#define CANFD_STATUS_LBACK       ((uint32)0x00000002U)  /*!< Loopback mode                  */
#define CANFD_STATUS_SLEEP       ((uint32)0x00000004U)  /*!< Sleep mode                     */
#define CANFD_STATUS_NORMAL      ((uint32)0x00000008U)  /*!< Normal mode                    */
#define CANFD_STATUS_BIDLE       ((uint32)0x00000010U)  /*!< Bus idle                       */
#define CANFD_STATUS_BBSY        ((uint32)0x00000020U)  /*!< Bus busy                       */
#define CANFD_STATUS_ERRWRN      ((uint32)0x00000040U)  /*!< Error warning                  */
#define CANFD_STATUS_ESTAT       ((uint32)0x00000080U)  /*!< Error status (2 bits)          */
#define CANFD_STATUS_PEE_CONFIG  ((uint32)0x00000200U)  /*!< PEE mode indicator (bit 9)     */
#define CANFD_STATUS_BSFR_CONFIG ((uint32)0x00000400U)  /*!< Bus-off recovery mode indicator (bit 10) */
#define CANFD_STATUS_SNOOP       ((uint32)0x00001000U)  /*!< Snoop mode (bit 12)            */
#define CANFD_STATUS_TDCV        ((uint32)0x00010000U)  /*!< TDC value (7 bits, bit 16)     */
/**
  * @}
  */

/** @defgroup CANFD_Error_Status CANFD Error Status Flags
  * @note  Values match the CANFD_ESR register bits.
  * @{
  */
#define CANFD_ERRSTAT_CRCERR        ((uint32)0x00000001U)  /*!< CRC error                      */
#define CANFD_ERRSTAT_FORMERR       ((uint32)0x00000002U)  /*!< Form error                     */
#define CANFD_ERRSTAT_STUFFERR      ((uint32)0x00000004U)  /*!< Stuff error                    */
#define CANFD_ERRSTAT_BITERR        ((uint32)0x00000008U)  /*!< Bit error                      */
#define CANFD_ERRSTAT_ACKERR        ((uint32)0x00000010U)  /*!< Acknowledge error              */
#define CANFD_ERRSTAT_CRCERR_FD     ((uint32)0x00000100U)  /*!< CRC error in FD data phase     */
#define CANFD_ERRSTAT_FORMERR_FD    ((uint32)0x00000200U)  /*!< Form error in FD data phase    */
#define CANFD_ERRSTAT_STUFFERR_FD   ((uint32)0x00000400U)  /*!< Stuff error in FD data phase   */
#define CANFD_ERRSTAT_BITERR_FD     ((uint32)0x00000800U)  /*!< Bit error in FD data phase     */
/**
  * @}
  */

/** @defgroup CANFD_Interrupts CANFD Interrupt Sources
  * @{
  */
#define CANFD_IT_EARBLST   ((uint32)0x00000001U)  /*!< Arbitration lost interrupt          */
#define CANFD_IT_ETXOK     ((uint32)0x00000002U)  /*!< Transmission successful interrupt  */
#define CANFD_IT_EPEE      ((uint32)0x00000004U)  /*!< Protocol exception event interrupt */
#define CANFD_IT_EBSFRD    ((uint32)0x00000008U)  /*!< Bus-off recovery done interrupt    */
#define CANFD_IT_ERXOK     ((uint32)0x00000010U)  /*!< New message received interrupt     */
#define CANFD_IT_ETSCNT_OFLW ((uint32)0x00000020U) /*!< Timestamp overflow interrupt       */
#define CANFD_IT_ERXFOFLW  ((uint32)0x00000040U)  /*!< RX FIFO overflow interrupt         */
#define CANFD_IT_EERROR    ((uint32)0x00000100U)  /*!< Error interrupt                    */
#define CANFD_IT_EBSOFF    ((uint32)0x00000200U)  /*!< Bus-off interrupt                  */
#define CANFD_IT_ESLP      ((uint32)0x00000400U)  /*!< Sleep interrupt                    */
#define CANFD_IT_EWKUP     ((uint32)0x00000800U)  /*!< Wake-up interrupt                  */
#define CANFD_IT_ETXRRS    ((uint32)0x00002000U)  /*!< TX buffer ready request served     */
#define CANFD_IT_ETXCRS    ((uint32)0x00004000U)  /*!< TX cancellation request served     */
#define CANFD_IT_ALL       ((uint32)0x00007FFF)   /*!< All interrupt sources              */
/**
  * @}
  */

/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/

/** @addtogroup CANFD_Exported_Functions
  * @{
  */

/** @addtogroup CANFD_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Fills each CANFD_InitStruct member with its default value.
 * @param  CANFD_InitStruct: pointer to a CANFD_InitTypeDef structure which
 *         will be initialized.
 * @retval None
 */
void HAL_CANFD_StructInit(CANFD_InitTypeDef *CANFD_InitStruct);

/**
 * @brief  Initializes the CAN FD according to the specified parameters in
 *         the CANFD_InitStruct of the handle.
 * @note   The CAN FD clock gating and the pin multiplexing must be
 *         configured by the user in HAL_CANFD_MspInit().
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR
 */
HAL_StatusTypeDef HAL_CANFD_Init(CANFD_HandleTypeDef *hcanfd);

/**
 * @brief  De-initializes the CAN FD peripheral.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR
 */
HAL_StatusTypeDef HAL_CANFD_DeInit(CANFD_HandleTypeDef *hcanfd);

/**
 * @brief  Initializes the CAN FD MSP. Weak empty function; the user
 *         implements the low level hardware initialization (CAN FD clock
 *         enable through the SMU bus clock configuration, GPIO pin
 *         configuration).
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval None
 */
void HAL_CANFD_MspInit(CANFD_HandleTypeDef *hcanfd);

/**
 * @brief  De-initializes the CAN FD MSP. Weak empty function; the user
 *         implements the low level hardware de-initialization.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval None
 */
void HAL_CANFD_MspDeInit(CANFD_HandleTypeDef *hcanfd);

/**
  * @}
  */

/** @addtogroup CANFD_Exported_Functions_Group2 Mode control functions
  * @{
  */

/**
 * @brief  Requests the CAN FD core to enter sleep mode.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval None
 */
void HAL_CANFD_Sleep(CANFD_HandleTypeDef *hcanfd);

/**
 * @brief  Wakes up the CAN FD core from sleep mode.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval None
 */
void HAL_CANFD_WakeUp(CANFD_HandleTypeDef *hcanfd);

/**
 * @brief  Requests the CAN FD core to enter loopback mode.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval None
 */
void HAL_CANFD_SetLoopback(CANFD_HandleTypeDef *hcanfd);

/**
 * @brief  Requests the CAN FD core to leave loopback mode.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval None
 */
void HAL_CANFD_CloseLoopback(CANFD_HandleTypeDef *hcanfd);

/**
 * @brief  Requests the CAN FD core to enter snoop mode.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval None
 */
void HAL_CANFD_SetSnoop(CANFD_HandleTypeDef *hcanfd);

/**
 * @brief  Requests the CAN FD core to leave snoop mode.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval None
 */
void HAL_CANFD_CloseSnoop(CANFD_HandleTypeDef *hcanfd);

/**
 * @brief  Waits until the CAN FD core is in normal mode. (BLOCKING)
 * @note   The wait is bounded by the Timeout parameter and yields the CPU to
 *         the other tasks while polling (RTOS-04). On expiry HAL_TIMEOUT is
 *         returned, HAL_CANFD_ERROR_TIMEOUT is accumulated into the error
 *         code and the state becomes HAL_CANFD_STATE_TIMEOUT (POLL-03).
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  Timeout: maximum wait time in ms (HAL_MAX_DELAY waits forever,
 *         0 does not wait).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY / HAL_TIMEOUT.
 */
HAL_StatusTypeDef HAL_CANFD_NormalStatus(CANFD_HandleTypeDef *hcanfd, uint32 Timeout);

/**
  * @}
  */

/** @addtogroup CANFD_Exported_Functions_Group3 Configuration functions
  * @{
  */

/**
 * @brief  Enables or disables the CAN FD bit rate switch (BRSD override).
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  NewState: CANFD_ENABLE or CANFD_DISABLE.
 * @retval None
 */
void HAL_CANFD_BitRateConfig(CANFD_HandleTypeDef *hcanfd, uint32 NewState);

/**
 * @brief  Enables or disables the CAN FD auto retransmission.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  NewState: CANFD_ENABLE or CANFD_DISABLE.
 * @retval None
 */
void HAL_CANFD_AutoRetransConfig(CANFD_HandleTypeDef *hcanfd, uint32 NewState);

/**
 * @brief  Enables or disables the CAN FD protocol exception event detection.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  NewState: CANFD_ENABLE or CANFD_DISABLE.
 * @retval None
 */
void HAL_CANFD_ProtExcConfig(CANFD_HandleTypeDef *hcanfd, uint32 NewState);

/**
 * @brief  Starts the CAN FD bus-off recovery request.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval None
 */
void HAL_CANFD_SetBusOff(CANFD_HandleTypeDef *hcanfd);

/**
 * @brief  Enables or disables the CAN FD auto bus-off recovery.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  NewState: CANFD_ENABLE or CANFD_DISABLE.
 * @retval None
 */
void HAL_CANFD_AutoBusOffRecoConfig(CANFD_HandleTypeDef *hcanfd, uint32 NewState);

/**
 * @brief  Configures the CAN FD transmitter delay compensation.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  NewState: CANFD_ENABLE or CANFD_DISABLE.
 * @param  TDC_OFFSET: TDC offset value (0..63).
 * @retval None
 */
void HAL_CANFD_TDCConfig(CANFD_HandleTypeDef *hcanfd, uint32 NewState, uint8 TDC_OFFSET);

/**
  * @}
  */

/** @addtogroup CANFD_Exported_Functions_Group4 Filtering functions
  * @{
  */

/**
 * @brief  Configures a CAN FD acceptance filter (mask / ID pair) and
 *         activates it.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  CANFD_FilterConfig: pointer to a CANFD_FilterConfigTypeDef
 *         structure containing the filter configuration.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR
 */
HAL_StatusTypeDef HAL_CANFD_FilterInit(CANFD_HandleTypeDef *hcanfd,
                                       CANFD_FilterConfigTypeDef *CANFD_FilterConfig);

/**
 * @brief  Configures the CAN FD to receive all messages (mask / ID filters
 *         cleared and the acceptance filter control set to all-pass).
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  NewState: CANFD_ENABLE (receive all) or CANFD_DISABLE.
 * @retval None
 */
void HAL_CANFD_ReceiveAll(CANFD_HandleTypeDef *hcanfd, uint32 NewState);

/**
  * @}
  */

/** @addtogroup CANFD_Exported_Functions_Group5 Frame and transmit functions
  * @{
  */

/**
 * @brief  Fills each CANFD_TXFrameStruct member with its default value.
 * @param  CANFD_TXFrameStruct: pointer to a CANFD_TXFrameTypeDef structure
 *         which will be initialized (CAN protocol, standard format, data
 *         frame).
 * @retval None
 */
void HAL_CANFD_FrameStructInit(CANFD_TXFrameTypeDef *CANFD_TXFrameStruct);

/**
 * @brief  Configures a transmit buffer frame settings (identifier, format,
 *         type and protocol).
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  TxBuffer: transmit buffer index, 0..31.
 * @param  CANFD_TXFrameStruct: pointer to a CANFD_TXFrameTypeDef structure.
 * @retval None
 */
void HAL_CANFD_FrameInit(CANFD_HandleTypeDef *hcanfd, uint32 TxBuffer,
                         CANFD_TXFrameTypeDef *CANFD_TXFrameStruct);

/**
 * @brief  Writes the transmit data into a transmit buffer and requests the
 *         transmission (normal mode). (BLOCKING)
 * @note   The function waits until the core reports normal mode before it
 *         requests the transmission; the wait is bounded by the Timeout
 *         parameter and yields the CPU while polling (RTOS-04).
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  TxBuffer: transmit buffer index, 0..31.
 * @param  pData: pointer to the data buffer (0..64 bytes, length must be a
 *         valid CAN FD length: 0-8, 12, 16, 20, 24, 32, 48 or 64).
 * @param  Length: number of bytes in the data buffer.
 * @param  Timeout: maximum time to wait for the normal mode, in ms
 *         (HAL_MAX_DELAY waits forever, 0 does not wait).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY / HAL_TIMEOUT.
 */
HAL_StatusTypeDef HAL_CANFD_Transmit(CANFD_HandleTypeDef *hcanfd, uint32 TxBuffer, uint8 *pData,
                                     uint32 Length, uint32 Timeout);

/**
 * @brief  Writes the transmit data into a transmit buffer and requests the
 *         transmission (loopback mode). (NON-BLOCKING)
 * @note   The loopback transmission does not wait for the core mode; the
 *         Timeout parameter only bounds the wait for the handle lock in RTOS
 *         builds.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  TxBuffer: transmit buffer index, 0..31.
 * @param  pData: pointer to the data buffer.
 * @param  Length: number of bytes in the data buffer.
 * @param  Timeout: maximum time to wait for the handle lock, in ms
 *         (HAL_MAX_DELAY waits forever).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY / HAL_TIMEOUT.
 */
HAL_StatusTypeDef HAL_CANFD_LoopbackTransmit(CANFD_HandleTypeDef *hcanfd, uint32 TxBuffer,
                                             uint8 *pData,
                                             uint32 Length, uint32 Timeout);

/**
 * @brief  Requests the transmission of the selected transmit buffers.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  SendTb: transmit buffer bitmask (bit N selects buffer N, or
 *         CANFD_SEND_ALL).
 * @retval None
 */
void HAL_CANFD_SetSendChannel(CANFD_HandleTypeDef *hcanfd, uint32 SendTb);

/**
 * @brief  Checks whether the selected transmit buffer(s) have completed
 *         the transmission.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  SendTb: transmit buffer bitmask.
 * @retval 1 if the selected buffers are ready (transmission complete),
 *         0 otherwise.
 */
uint32 HAL_CANFD_GetSendCmpStatus(CANFD_HandleTypeDef *hcanfd, uint32 SendTb);

/**
 * @brief  Cancels the transmission of the selected transmit buffers.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  TcrTb: transmit buffer bitmask to cancel.
 * @retval None
 */
void HAL_CANFD_CancelTransmit(CANFD_HandleTypeDef *hcanfd, uint32 TcrTb);

/**
  * @}
  */

/** @addtogroup CANFD_Exported_Functions_Group6 Receive functions
  * @{
  */

/**
 * @brief  Returns the number of messages pending in the RX FIFO.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval uint32: RX FIFO fill level.
 */
uint32 HAL_CANFD_GetRxFillLevel(CANFD_HandleTypeDef *hcanfd);

/**
 * @brief  Returns the read index of the RX FIFO.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval uint32: RX FIFO read index.
 */
uint32 HAL_CANFD_GetRxReadIndex(CANFD_HandleTypeDef *hcanfd);

/**
 * @brief  Increments the RX FIFO read index (release the current message).
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval None
 */
void HAL_CANFD_SetRxIncReadIndex(CANFD_HandleTypeDef *hcanfd);

/**
 * @brief  Returns the data length (in bytes) of the current RX message.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval uint32: data length in bytes (0,1,...,8,12,16,...,64).
 */
uint32 HAL_CANFD_GetReceiveBytes(CANFD_HandleTypeDef *hcanfd);

/**
 * @brief  Reads the current RX message data into the given buffer and
 *         releases the message (increments the read index).
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  pData: pointer to the data buffer (up to 64 bytes).
 * @retval uint32: number of bytes read.
 */
uint32 HAL_CANFD_GetReceiveData(CANFD_HandleTypeDef *hcanfd, uint8 *pData);

/**
 * @brief  Returns the info of the current RX message (identifier, format,
 *         type, protocol, DLC and pending count).
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  CANFD_RXInfoStruct: pointer to the structure that will hold the
 *         message info.
 * @retval None
 */
void HAL_CANFD_GetReceiveInfo(CANFD_HandleTypeDef *hcanfd,
                              CANFD_RXInfoTypeDef *CANFD_RXInfoStruct);

/**
  * @}
  */

/** @addtogroup CANFD_Exported_Functions_Group7 Interrupt functions
  * @{
  */

/**
 * @brief  Enables or disables the specified CAN FD interrupt source(s).
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  ITType: interrupt source bitmask (CANFD_IT_xxx).
 * @param  NewState: CANFD_ENABLE or CANFD_DISABLE.
 * @retval None
 */
void HAL_CANFD_ITConfig(CANFD_HandleTypeDef *hcanfd, uint32 ITType, uint32 NewState);

/**
 * @brief  Enables or disables the TX buffer ready request served interrupt.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  Cleartb: transmit buffer bitmask.
 * @param  NewState: CANFD_ENABLE or CANFD_DISABLE.
 * @retval None
 */
void HAL_CANFD_SetBufferReadyIT(CANFD_HandleTypeDef *hcanfd, uint32 Cleartb, uint32 NewState);

/**
 * @brief  Enables or disables the TX buffer cancellation served interrupt.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  EcrsTb: transmit buffer bitmask.
 * @param  NewState: CANFD_ENABLE or CANFD_DISABLE.
 * @retval None
 */
void HAL_CANFD_TxBufferCancelIT(CANFD_HandleTypeDef *hcanfd, uint32 EcrsTb, uint32 NewState);

/**
 * @brief  Checks whether the specified CAN FD interrupt flag is set.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  Flag: interrupt flag bitmask (CANFD_IT_xxx).
 * @retval 1 if the flag is set, 0 otherwise.
 */
uint32 HAL_CANFD_GetITStatus(CANFD_HandleTypeDef *hcanfd, uint32 Flag);

/**
 * @brief  Clears the specified CAN FD interrupt pending bit(s).
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  ClearIT: interrupt flag bitmask to clear.
 * @retval None
 */
void HAL_CANFD_ClearITPendingBit(CANFD_HandleTypeDef *hcanfd, uint32 ClearIT);

/**
  * @}
  */

/** @addtogroup CANFD_Exported_Functions_Group8 Status and error functions
  * @{
  */

/**
 * @brief  Returns the value of the given CAN FD status flag.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  Status: the status flag to check (CANFD_STATUS_xxx).
 * @retval 1 if the flag is set, 0 otherwise; for the ESTAT (2 bits) and
 *         TDCV (7 bits) flags the raw field value is returned.
 */
uint32 HAL_CANFD_GetStatus(CANFD_HandleTypeDef *hcanfd, uint32 Status);

/**
 * @brief  Checks whether the given CAN FD error status flag is set.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  ErrorState: the error flag to check (CANFD_ERRSTAT_xxx).
 * @retval 1 if the error flag is set, 0 otherwise.
 */
uint32 HAL_CANFD_GetErrorStatus(CANFD_HandleTypeDef *hcanfd, uint32 ErrorState);

/**
 * @brief  Returns the CAN FD receive error counter.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval uint32: receive error count.
 */
uint32 HAL_CANFD_GetRXErrorCount(CANFD_HandleTypeDef *hcanfd);

/**
 * @brief  Returns the CAN FD transmit error counter.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval uint32: transmit error count.
 */
uint32 HAL_CANFD_GetTXErrorCount(CANFD_HandleTypeDef *hcanfd);

/**
 * @brief  Returns the CAN FD timestamp counter value.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval uint32: timestamp counter value.
 */
uint32 HAL_CANFD_GetTimestampValue(CANFD_HandleTypeDef *hcanfd);

/**
 * @brief  Clears the CAN FD timestamp counter.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval None
 */
void HAL_CANFD_ClearTimestamp(CANFD_HandleTypeDef *hcanfd);

/**
 * @brief  Returns the CAN FD handle state.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval HAL_CANFD_StateTypeDef: the current handle state.
 */
HAL_CANFD_StateTypeDef HAL_CANFD_GetState(CANFD_HandleTypeDef *hcanfd);

/**
 * @brief  Returns the CAN FD error code.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval uint32: the CAN FD error code (HAL_CANFD_ERROR_xxx).
 */
uint32 HAL_CANFD_GetError(CANFD_HandleTypeDef *hcanfd);

/**
  * @}
  */

/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/

/** @defgroup CANFD_Private_Macros CANFD Private Macros
  * @{
  */

/**
 * @brief  Check that the CAN FD peripheral instance is one of CANFD0..CANFD3.
 */
#define IS_CANFD_ALL_PERIPH(PERIPH) (((PERIPH) == CANFD0) || \
                                     ((PERIPH) == CANFD1) || \
                                     ((PERIPH) == CANFD2) || \
                                     ((PERIPH) == CANFD3))

/**
 * @brief  Check that the software reset / enable value is valid.
 */
#define IS_CANFD_SRR(SRR) (((SRR) == CANFD_SRR_RESET) || ((SRR) == CANFD_SRR_ENABLE))

/**
 * @brief  Check that the arbitration phase prescaler encoding is valid
 *         (0x00..0xFF, i.e. a divider of 1..256).
 */
#define IS_CANFD_APBRPR(APBRPR) ((APBRPR) <= 0xFFU)

/**
 * @brief  Check that the arbitration phase TS1 encoding is valid.
 */
#define IS_CANFD_APBTR_TS1(TS1) ((TS1) <= 0xFFU)

/**
 * @brief  Check that the arbitration phase TS2 encoding is valid.
 */
#define IS_CANFD_APBTR_TS2(TS2) ((TS2) <= 0x7FU)

/**
 * @brief  Check that the arbitration phase SJW encoding is valid.
 */
#define IS_CANFD_APBTR_SJW(SJW) ((SJW) <= 0x7FU)

/**
 * @brief  Check that the data phase prescaler encoding is valid.
 */
#define IS_CANFD_DPBRPR(DPBRPR) ((DPBRPR) <= 0xFFU)

/**
 * @brief  Check that the data phase TS1 encoding is valid.
 */
#define IS_CANFD_DPBTR_TS1(TS1) ((TS1) <= 0x1FU)

/**
 * @brief  Check that the data phase TS2 encoding is valid.
 */
#define IS_CANFD_DPBTR_TS2(TS2) ((TS2) <= 0x0FU)

/**
 * @brief  Check that the data phase SJW encoding is valid.
 */
#define IS_CANFD_DPBTR_SJW(SJW) ((SJW) <= 0x0FU)

/**
 * @brief  Check that the frame protocol is valid.
 */
#define IS_CANFD_PROTOCOL(PROTOCOL) (((PROTOCOL) == CANFD_PROTOCOL_CAN) || \
                                     ((PROTOCOL) == CANFD_PROTOCOL_CANFD) || \
                                     ((PROTOCOL) == CANFD_PROTOCOL_CANFD_BRS))

/**
 * @brief  Check that the frame format is valid.
 */
#define IS_CANFD_FORMAT(FORMAT) (((FORMAT) == CANFD_FORMAT_STANDARD) || \
                                 ((FORMAT) == CANFD_FORMAT_EXTENDED))

/**
 * @brief  Check that the frame type is valid.
 */
#define IS_CANFD_TYPE(TYPE) (((TYPE) == CANFD_TYPE_DATA) || ((TYPE) == CANFD_TYPE_REMOTE))

/**
 * @brief  Check that the transmit buffer index is valid (0..31).
 */
#define IS_CANFD_TB_NUMBER(NUMBER) ((NUMBER) <= 31U)

/**
 * @brief  Check that the filter index is valid (0..31).
 */
#define IS_CANFD_FILTER_SPACE(NUMBER) ((NUMBER) <= 31U)

/**
 * @brief  Check that the data length is a valid CAN FD length
 *         (0-8, 12, 16, 20, 24, 32, 48, 64).
 */
#define IS_CANFD_DATA_LENGTH(LENGTH) (((LENGTH) == 0U)  || ((LENGTH) == 1U)  || \
                                      ((LENGTH) == 2U)  || ((LENGTH) == 3U)  || \
                                      ((LENGTH) == 4U)  || ((LENGTH) == 5U)  || \
                                      ((LENGTH) == 6U)  || ((LENGTH) == 7U)  || \
                                      ((LENGTH) == 8U)  || ((LENGTH) == 12U) || \
                                      ((LENGTH) == 16U) || ((LENGTH) == 20U) || \
                                      ((LENGTH) == 24U) || ((LENGTH) == 32U) || \
                                      ((LENGTH) == 48U) || ((LENGTH) == 64U))

/**
 * @brief  Check that the TDC offset is valid (0..63).
 */
#define IS_CANFD_TDC_OFFSET(OFFSET) ((OFFSET) <= 0x3FU)

/**
  * @}
  */

/* Shared internal functions --------------------------------------------------*/

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_CANFD_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; when the mutex is not acquired before the
 *         Timeout expires, HAL_TIMEOUT is returned. The value is passed to
 *         HAL_MutexAcquire() as is (RTOS ticks; with the usual 1 ms tick it is
 *         the same quantity as the millisecond Timeout of the public API, and
 *         HAL_MAX_DELAY means an infinite wait).
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef CANFD_LockHandle(CANFD_HandleTypeDef *hcanfd, uint32 Timeout);

/**
 * @brief  Unlock the handle.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval None
 */
void CANFD_UnlockHandle(CANFD_HandleTypeDef *hcanfd);

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_CANFD_H */

/*****END OF FILE*****/
