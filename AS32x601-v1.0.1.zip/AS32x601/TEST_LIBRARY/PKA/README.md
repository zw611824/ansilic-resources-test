# PKA 应用与测试参考

供 skill 按需求检索 AS32x601 HAL 公钥加速器（PKA）示例。别名/关键词：PKA、公钥加速、ECC、ECDSA、P-256、点乘、密钥交换、RSA、模幂、CRT、Montgomery、微码、操作数窗口。共有 6 个独立用例。

HAL 依据：[头文件](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_pka.h)、[实现](../../HAL_LIBRARY/peripherals/src/as32x601_hal_pka.c)。原测试工程的 4_HAL_LIBRARY 未提供，尚不能确认原始链接版本；文中标出的源码与当前 SDK 差异须先解决再迁移。

PKA 用例还需要配套微码头 as32x601_pka_fw.h，微码保存在原测试工程的模板/生成工程 Stub 中，本目录只打包测试 .c 和 README，不包含微码头。当前目录不是独立可编译包；微码缺失或与 entry/操作数布局不匹配时，不能执行这些运算。


## 实例与相关资源

本模块不单独列出外部通信引脚组。按实际功能核对实例、时钟、中断、内存或数据通路；关联 GPIO、定时器或其他外设时，再读取对应分支的引脚资料。具体资源与案例配置见下文。

## 生成前需确认的参数

已有工程、板级资料或用户已明确的值直接复用。仅对影响本次实现的缺失选择使用参数卡询问并等待答复；案例配置不能代替实际接线或应用参数。

| 参数 | 需要核对或确认的内容 |
|---|---|
| 算法与输入 | 目标运算、密钥/操作数格式、长度和字节序 |
| 输出与验证 | 结果格式、已知向量及错误处理 |

## 按需求选择

| 用户需求 / 检索关键词 | 推荐用例 | 选择条件 / 需要补充的逻辑 |
|---|---|---|
| ECC P-256 点乘、双方公钥、共享密钥 | [001](PKA_IT_DRV_001.c) | 最完整的 ECC 数据通路模板。操作数布局、基址和 entry 0x19 都按微码约定；应用需替换私钥并做密钥保护 |
| RSA-512 公钥模幂演示 | [002](PKA_IT_DRV_002.c) | 已知 n/e 的运算向量，含 Montgomery 预计算与 entry 0x16；不包含完整加密协议 |
| RSA-512 私钥模幂演示 | [003](PKA_IT_DRV_003.c) | 指数为 d 的向量；密钥管理、填充与完整协议不在本例范围 |
| RSA-1024 CRT 解密 | [004](PKA_IT_DRV_004.c) | 先由 p/q/d_lo/d_hi 推导 dp/dq/u，再对 p、q 各做 Montgomery 预计算，最后 entry 0x18；操作数多达 11 个 |
| ECDSA P-256 签名与验签 | [005](PKA_IT_DRV_005.c) | 覆盖公钥、R、r、k⁻¹、w、X、v 的完整链。**注意**：源码记载 entry 0x0A、0x0B 的结果只作为观察值、不计失败，并用文档中间值继续；不要据此认为这两条指令已在硅片上验证可用 |
| 结构/参数/生命周期/中断回调自检 | [006](PKA_IT_DRV_006.c) | 防御性自检，不是应用模板；可查操作数窗口边界、4 字节对齐、entry point、状态和回调契约 |
| RSA 密钥生成、素数检测 | 无直接模板 | 微码用例只覆盖“已知密钥”的运算；密钥生成需另找微码入口或软件实现并自行验证 |
| 其他曲线（P-384/P-521）、其他密钥长度 | 无现成向量 | 可参考 001/005 的数据流，但曲线参数、基址和 entry 需按微码手册重新确认，不能照抄 P-256 常量 |

## 实现要点与案例配置

- PKA 由 CTRL.GO 启动：先以 GO_DIS 调用 Init 准备句柄/时钟，再加载微码、清栈、写操作数。SetEntryPoint 只设置入口；后续携带 PKA_Go=PKA_GO_EN 的 HAL_PKA_Init 才启动，结束后示例再写 GO_DIS。
- HAL_PKA_WriteData / ReadData 的 Address 为相对 PKA_BASE 的字节偏移，Length 为 32 位字数；偏移和缓冲需 4 字节对齐。不要传入绝对 PKA_OPERAND_x_ADDR，示例封装会减去 PKA_BASE。
- 基数、PartialRadix 和 entry 必须与微码匹配。001 使用 PartialRadix=0 的旧约定，已安装 SDK 默认填写完整字数（256 位为 8），不能断言 0 始终表示完整基数。点乘 0x19、模幂 0x16、CRT 0x18 是本组镜像入口，不是通用枚举。
- 完成判定：轮询 `HAL_PKA_GetStatStatus()` 的 DONE/错误位，再 `HAL_PKA_ClearStatus()` 确认；随后 `HAL_PKA_ReadData()` 取结果。中断模式由 `HAL_PKA_IRQHandler()` 分发并调用 `HAL_PKA_ErrorCallback()`，示例 006 覆盖该路径。
- 证据边界：与参考向量逐字比较能证明当前微码/驱动的运算结果与数据通路正确；不能证明侧信道安全、密钥存储安全或长时间稳定性。PKA 没有可直接测量的模拟输出，验证以读回向量为主。

测试用固定密钥及 RSA-512/1024 向量仅作硬件运算验证，不包含完整填充、密钥管理或业务密码协议。

## 验证方法与适用边界

- 操作数布局完全由微码约定：D0/C0/D1/D3/A0/D2 等位置不能凭函数名推断；迁移时先对照微码手册和 002/003/004 的实际写入顺序。
- `HAL_PKA_LoadFirmware()` 会检查镜像地址/长度；微码镜像来自应用提供的头文件，不能用其他芯片的镜像替代。
- 操作数窗口在多次运算间不会自动清零；涉及密钥的缓冲应在使用后主动清零，避免残留。
- 状态门控与锁参考 006；不将 API 调用期间的句柄 BUSY 与硬件运算状态等同，故障恢复后重新核对入口和操作数。
- 005 的 0x0A/0x0B 未计入失败是源码的有意行为（参考材料也标注其不工作），应用若依赖这两条指令必须自行补验证。
- 轮询循环都要有超时上限（示例 `TEST_WAIT_GUARD`），不要写死等；PKA 异常时无超时会卡死。

## 按接口与辅助宏检索

| 接口 / 宏 | 参考用例 |
|---|---|
| `HAL_PKA_Init` / `HAL_PKA_DeInit` | [001](PKA_IT_DRV_001.c)、[006](PKA_IT_DRV_006.c) |
| `HAL_PKA_LoadFirmware` | [001](PKA_IT_DRV_001.c)、[003](PKA_IT_DRV_003.c) |
| `HAL_PKA_ClearStack` / `HAL_PKA_SetEntryPoint` | [001](PKA_IT_DRV_001.c)、[002](PKA_IT_DRV_002.c) |
| `HAL_PKA_WriteData` / `HAL_PKA_ReadData` | [001](PKA_IT_DRV_001.c)、[004](PKA_IT_DRV_004.c) |
| `HAL_PKA_GetStatStatus` / `HAL_PKA_ClearStatus` | [002](PKA_IT_DRV_002.c)、[006](PKA_IT_DRV_006.c) |
| `HAL_PKA_ITConfig` / `HAL_PKA_IRQHandler` / `HAL_PKA_ErrorCallback` | [006](PKA_IT_DRV_006.c) |
| `HAL_PKA_GetState` / `HAL_PKA_GetError` | [005](PKA_IT_DRV_005.c)、[006](PKA_IT_DRV_006.c) |
| `PKA_BASE_RADIX_256` / `PKA_BASE_RADIX_512` | [001](PKA_IT_DRV_001.c)、[002](PKA_IT_DRV_002.c) |


本次为源码静态整理，未重新编译、未上板；源码里的历史测试注释不代表本次验证结果。
