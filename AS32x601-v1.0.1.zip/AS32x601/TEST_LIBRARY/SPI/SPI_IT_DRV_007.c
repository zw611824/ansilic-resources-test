/**
 * @file    SPI_IT_DRV_007.c
 * @brief   HAL SPI integration test case 007 (receive not empty interrupt).
 *
 * HAL library port of the original AS32x601 standard-library test case
 * SPI_IT_DRV_007.c, which drives SPI3 in master mode with the receive buffer
 * not empty interrupt enabled and lets the interrupt service routine clock the
 * next frame. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_SPI_StructInit()
 *   HAL_SPI_Init()
 *   HAL_SPI_ResetFIFO()
 *   HAL_SPI_NSSConfig()         (asserts SPI_Slave0 around every transfer)
 *   HAL_SPI_TransmitReceive_IT()   (interrupt driven, 64 frames of 8 bit)
 *   HAL_SPI_IRQHandler()           (RXNE / TXNE service)
 *   HAL_SPI_TxRxCpltCallback()
 *   HAL_PLIC_Init()                (SPI3 interrupt line)
 *   HAL_SPI_GetState() / HAL_SPI_GetError()
 *   HAL_SPI_MspInit()              (overridden: clock gate, reset pulse, pins)
 *
 * Test procedure:
 *   1. map the pins and initialize SPI3 in master mode (8 bit, Motorola mode 0,
 *      back-to-back transmission, divider /512);
 *   2. route the SPI3 interrupt line through the PLIC;
 *   3. start an interrupt driven full duplex transfer of 64 frames: the
 *      transmit buffer holds 0x00 .. 0x3F, so the received buffer is expected
 *      to carry the same pattern from the peer;
 *   4. wait for the completion callback and compare the received buffer.
 *
 * Expected behaviour:
 *   - HAL_SPI_TransmitReceive_IT() returns HAL_OK and the handle enters
 *     BUSY_TX_RX;
 *   - the interrupt service routine clocks frame by frame; the completion
 *     callback fires exactly once and the handle returns to READY;
 *   - the received buffer holds 0x00 .. 0x3F, so every comparison prints
 *     [PASS] and "summary : failures = 0".
 *
 * Note:
 *   - External stimulus is required: an SPI slave (or a MOSI to MISO loop)
 *     must return the 64 frames. Without it the transfer never completes; the
 *     case waits for a bounded number of polls and then reports the situation
 *     instead of hanging.
 *   - The reference test case masked the interrupt by hand inside its own
 *     service routine and had an off by one write (it stored the received
 *     frame into rx[64] before testing the index). The driver owns the indices
 *     now, so both problems are gone.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console: USART0 on GPIOD pin 8 (TX) / pin 9 (RX), 115200 8N1 */
#define TEST_BAUDRATE                   (115200U)

/* Device under test: SPI3 (as in the reference test case)
 *   CS0  = PC10   SCK  = PD3   MOSI = PD1   MISO = PD2
 */
#define TEST_SPI                        SPI3
#define TEST_SPI_IRQn                   SPI3_IRQn
#define TEST_CS_PORT                    GPIOC
#define TEST_CS_PIN                     GPIO_PIN_10
#define TEST_CS_SOURCE                  GPIO_PinSource10
#define TEST_SCK_PORT                   GPIOD
#define TEST_SCK_PIN                    GPIO_PIN_3
#define TEST_SCK_SOURCE                 GPIO_PinSource3
#define TEST_MOSI_PORT                  GPIOD
#define TEST_MOSI_PIN                   GPIO_PIN_1
#define TEST_MOSI_SOURCE                GPIO_PinSource1
#define TEST_MISO_PORT                  GPIOD
#define TEST_MISO_PIN                   GPIO_PIN_2
#define TEST_MISO_SOURCE                GPIO_PinSource2
#define TEST_PIN_AF                     GPIO_AF_SPI3

/* Frame geometry, pacing and the poll bound of the wait loop */
#define FRAME_COUNT                     (64U)
#define WAIT_POLLS                      (20000000U)
#define RETRY_PERIOD_MS                 (2000U)
#define ROUNDS                          (3U)

/* Private variables ---------------------------------------------------------*/
static SPI_HandleTypeDef hspi_dev;              /*!< device under test      */
static HAL_SMU_HandleTypeDef hsmu_clk;          /*!< SMU handle (clock tree) */
static uint8 tx_data[FRAME_COUNT];              /*!< transmit pattern        */
static uint8 rx_data[FRAME_COUNT];              /*!< received frames         */
static uint8 rx_expected[FRAME_COUNT];          /*!< expected frames         */
static volatile uint32 check_failures = 0U;     /*!< failed check counter    */
static volatile uint32 rxrx_cplt_count = 0U;    /*!< completion callbacks    */
static volatile uint32 irq_count = 0U;          /*!< SPI interrupt entries   */
static volatile uint32 transfer_done = 0U;      /*!< completion flag         */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void SPI_PLIC_Init(void);
static void BufferInit(void);
static void Check(const char *name, uint32 condition);
static void Summary(void);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    SPI_InitTypeDef spi_init;
    HAL_StatusTypeDef status;
    uint32 index;
    uint32 round;
    uint32 polls;
    uint32 mismatches;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock tree */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART (USART0 on GPIOD pin 8 / pin 9) */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== SPI_IT_DRV_007 : receive not empty interrupt (SPI3) ===\r\n");

    /* Transmit pattern 0x00 .. 0x3F, same expected pattern from the peer */
    BufferInit();

    /* Step 1: initialize the device under test (back-to-back transmission, as
     * the reference test case did) */
    __HAL_CLEAR_STRUCT(&hspi_dev);
    HAL_SPI_StructInit(&spi_init);
    spi_init.SPI_CLKDiv       = SPI_CLKDiv512;
    spi_init.SPI_Mode         = SPI_Mode_Master;
    spi_init.SPI_FrameSize    = SPI_FrameSize_8b;
    spi_init.SPI_MotorolaMode = SPI_Motorola_Mode0;
    spi_init.SPI_TransMode    = SPI_TransBToB;

    hspi_dev.Instance = TEST_SPI;
    hspi_dev.Init     = spi_init;

    status = HAL_SPI_Init(&hspi_dev);
    /* The slave select is not part of the initialization: SSR
     * resets to 0 (no slave selected) and HAL_SPI_Init() does not
     * touch it, so the selection has to be programmed here. */
    HAL_SPI_ResetFIFO(&hspi_dev, SPI_RESETFIFO_TXANDRX);
    HAL_SPI_NSSConfig(&hspi_dev, SPI_Slave0, SPI_ENABLE);
    Check("HAL_SPI_Init returns HAL_OK", (uint32)((status == HAL_OK) ? 1U : 0U));
    Check("state after init is READY",
          (uint32)((HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_READY) ? 1U : 0U));

    /* Step 2: route the SPI3 interrupt line */
    SPI_PLIC_Init();

    for (round = 1U; round <= ROUNDS; round++)
    {
        printf("\r\n-- round %u --\r\n", PRINT_U32(round));

        for (index = 0U; index < FRAME_COUNT; index++)
        {
            rx_data[index] = 0x00U;
        }
        rxrx_cplt_count = 0U;
        irq_count       = 0U;
        transfer_done   = 0U;

        /* Step 3: start the interrupt driven full duplex transfer */
        status = HAL_SPI_TransmitReceive_IT(&hspi_dev, tx_data, rx_data,
                                            FRAME_COUNT);
        Check("HAL_SPI_TransmitReceive_IT returns HAL_OK",
              (uint32)((status == HAL_OK) ? 1U : 0U));
        Check("state is BUSY_TX_RX while the transfer runs",
              (uint32)((HAL_SPI_GetState(&hspi_dev) ==
                        HAL_SPI_STATE_BUSY_TX_RX) ? 1U : 0U));

        /* Step 4: wait for the completion callback (bounded, a missing peer
         * must not hang the case) */
        polls = 0U;
        while ((transfer_done == 0U) && (polls < WAIT_POLLS))
        {
            polls++;
        }

        printf("interrupts   : %u entries while clocking %u frames\r\n",
               PRINT_U32(irq_count), PRINT_U32(FRAME_COUNT));
        Check("the interrupt line was taken", (uint32)((irq_count != 0U) ? 1U : 0U));
        Check("completion callback fired exactly once",
              (uint32)((rxrx_cplt_count == 1U) ? 1U : 0U));
        Check("state is READY after the transfer",
              (uint32)((HAL_SPI_GetState(&hspi_dev) ==
                        HAL_SPI_STATE_READY) ? 1U : 0U));
        Check("error code after the transfer is NONE",
              (uint32)((HAL_SPI_GetError(&hspi_dev) == HAL_SPI_ERROR_NONE) ? 1U : 0U));

        /* Compare the received buffer with the expectation */
        mismatches = 0U;
        for (index = 0U; index < FRAME_COUNT; index++)
        {
            if (rx_data[index] != rx_expected[index])
            {
                mismatches++;
            }
        }

        printf("rx[0..7]     : ");
        for (index = 0U; index < 8U; index++)
        {
            printf("0x%02X ", PRINT_U32(rx_data[index]));
        }
        printf("... (mismatches %u)\r\n", PRINT_U32(mismatches));

        Check("received pattern matches the expectation",
              (uint32)(((mismatches == 0U) && (transfer_done != 0U)) ? 1U : 0U));

        if (transfer_done == 0U)
        {
            printf("note         : no completion - an SPI slave (or a MOSI to\n");
            printf("               MISO loop) is required to return the frames\n");
            /* Recover the handle so that the next round can start again */
            (void)HAL_SPI_DeInit(&hspi_dev);
            status = HAL_SPI_Init(&hspi_dev);
            /* The slave select is not part of the initialization: SSR
             * resets to 0 (no slave selected) and HAL_SPI_Init() does not
             * touch it, so the selection has to be programmed here. */
            HAL_SPI_ResetFIFO(&hspi_dev, SPI_RESETFIFO_TXANDRX);
            HAL_SPI_NSSConfig(&hspi_dev, SPI_Slave0, SPI_ENABLE);
            if (status != HAL_OK)
            {
                printf("re-init after the missing peer failed\r\n");
                break;
            }
        }

        delay_ms(RETRY_PERIOD_MS);
    }

    /* Release the slave select, so the lines are not left asserted */
    HAL_SPI_NSSConfig(&hspi_dev, SPI_Slave0, SPI_DISABLE);

    Summary();

    while (1)
    {
        delay_ms(1000U);
    }
}

/**
 * @brief  Fill the transmit and the expected receive buffer.
 * @param  None
 * @retval None
 */
static void BufferInit(void)
{
    uint32 index;

    for (index = 0U; index < FRAME_COUNT; index++)
    {
        tx_data[index]     = (uint8)index;
        rx_expected[index] = (uint8)index;
        rx_data[index]     = 0x00U;
    }
}

/**
 * @brief  Route the SPI3 interrupt line through the PLIC.
 * @param  None
 * @retval None
 */
static void SPI_PLIC_Init(void)
{
    PLIC_InitTypeDef plic;

    __HAL_SMU_PLIC_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&plic);
    plic.Size               = sizeof(plic);
    plic.Version            = PLIC_INIT_VERSION;
    plic.PLIC_IRQPriority   = 1U;
    plic.PLIC_IRQChannelCmd = ENABLE;
    plic.PLIC_IRQChannel    = TEST_SPI_IRQn;

    HAL_PLIC_Init(&plic);
}

/**
 * @brief  Report the result of one check.
 * @param  name: short description of the check.
 * @param  condition: 0 = FAIL, non zero = PASS.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("%-46s : [PASS]\r\n", name);
    }
    else
    {
        check_failures++;
        printf("%-46s : [FAIL]\r\n", name);
    }
}

/**
 * @brief  Print the accumulated failure counter.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(check_failures));
}

/**
 * @brief  SPI3 interrupt handler (weak symbol of the trap entry).
 * @note   A trampoline only: HAL_SPI_IRQHandler() serves the RXNE / TXNE / RXO
 *         events, refills the transmit FIFO and calls the completion callback
 *         when the last frame has been exchanged. No lock is taken here
 *         (LOCK-04 / RTOS-12).
 * @param  None
 * @retval None
 */
void SPI3_IRQ_Handler(void)
{
    irq_count++;
    HAL_SPI_IRQHandler(&hspi_dev);
}

/**
 * @brief  Full duplex completion callback of the device under test.
 * @param  hspi: SPI handle.
 * @retval None
 */
void HAL_SPI_TxRxCpltCallback(SPI_HandleTypeDef *hspi)
{
    if (hspi == &hspi_dev)
    {
        rxrx_cplt_count++;
        transfer_done = 1U;
    }
}

/**
 * @brief  Error callback of the device under test (documented for reference).
 * @param  hspi: SPI handle.
 * @retval None
 */
void HAL_SPI_ErrorCallback(SPI_HandleTypeDef *hspi)
{
    if (hspi == &hspi_dev)
    {
        printf("[irq] SPI error, error code 0x%08X\r\n",
               PRINT_U32(HAL_SPI_GetError(&hspi_dev)));
    }
}

/**
 * @brief  MSP initialization of the device under test.
 * @note   Strong override of the weak driver callback.
 * @param  hspi: SPI handle of the device under test.
 * @retval None
 */
void HAL_SPI_MspInit(SPI_HandleTypeDef *hspi)
{
    GPIO_InitTypeDef gpio;

    if (hspi->Instance != TEST_SPI)
    {
        return;
    }

    /* Peripheral clock gate and reset pulse */
    __HAL_SMU_SPI3_CLK_ENABLE();
    __HAL_SMU_SPI3_FORCE_RESET();
    __HAL_SMU_SPI3_RELEASE_RESET();

    /* Port clock gates used by this case */
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&gpio);
    gpio.Size         = sizeof(gpio);
    gpio.Version      = GPIO_INIT_VERSION;
    gpio.Pull         = GPIO_NOPULL;
    gpio.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    gpio.Alternate    = TEST_PIN_AF;

    /* CS0 (driven by the SSR register) */
    HAL_GPIO_PinAFConfig(TEST_CS_PORT, TEST_CS_SOURCE, TEST_PIN_AF);
    gpio.Pin  = TEST_CS_PIN;
    gpio.Mode = GPIO_MODE_AF_PP;
    HAL_GPIO_Init(TEST_CS_PORT, &gpio);

    /* SCK */
    HAL_GPIO_PinAFConfig(TEST_SCK_PORT, TEST_SCK_SOURCE, TEST_PIN_AF);
    gpio.Pin = TEST_SCK_PIN;
    HAL_GPIO_Init(TEST_SCK_PORT, &gpio);

    /* MOSI */
    HAL_GPIO_PinAFConfig(TEST_MOSI_PORT, TEST_MOSI_SOURCE, TEST_PIN_AF);
    gpio.Pin = TEST_MOSI_PIN;
    HAL_GPIO_Init(TEST_MOSI_PORT, &gpio);

    /* MISO: alternate function input, floating */
    HAL_GPIO_PinAFConfig(TEST_MISO_PORT, TEST_MISO_SOURCE, TEST_PIN_AF);
    gpio.Pin  = TEST_MISO_PIN;
    gpio.Mode = GPIO_MODE_INPUT;
    HAL_GPIO_Init(TEST_MISO_PORT, &gpio);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the CLINT / CMU / MPU / USART integration tests.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef    SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the same set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls (PMU_CheckState) */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
