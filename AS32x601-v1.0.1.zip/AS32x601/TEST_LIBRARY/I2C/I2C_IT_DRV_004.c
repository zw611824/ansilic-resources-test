/**
 * @file    I2C_IT_DRV_004.c
 * @brief   HAL I2C integration test case 004 (slave receive at 100 kHz).
 *
 * One-to-one HAL library port of the original AS32x601 standard-library test
 * case I2C_IT_DRV_004.c. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_I2C_StructInit()
 *   HAL_I2C_Init()              (I2C1 as a slave at 100 kHz, SCL =
 *                                GPIOF pin 15, SDA =
 *                                GPIOF pin 13)
 *   HAL_I2C_Slave_Receive()     (blocking)
 *   HAL_I2C_DeInit() / HAL_I2C_GetState() / HAL_I2C_GetError()
 *
 * Test procedure:
 *   1. Apply the standard clock tree (PLL 180 MHz) and initialize the console;
 *   2. Configure I2C1 as a slave at 100 kHz with the own address 0x5A and
 *      wait for the host to write 64 bytes;
 *   3. Print the received bytes (16 per line);
 *   4. Report the result and the register read back.
 *
 * Expected behaviour:
 *   - when the host writes to address 0x5A the console prints "I2C Slave
 *     Receive Success!" followed by the 64 received bytes;
 *   - with no host write request the call returns after TEST_SLAVE_TIMEOUT_MS
 *     and the console prints "I2C Slave Receive Failed!";
 *   - the last line reads "summary : failures = N".
 *
 * Notes (deliberate adaptations of this port):
 *   - the divider values are recomputed for this library's clock tree.  With no
 *     documented divider formula the value follows
 *     I2C clock = PCLK / 8 / DIV, i.e. 2.8125 MHz / 28 = 100.4 kHz;
 *   - the original slave test case waited up to 1000000 ms for the host.  This
 *     port uses TEST_SLAVE_TIMEOUT_MS so that the case returns an error instead
 *     of blocking for ever when no host is present.
 *
 * Note: host must be present on the bus for the transfer to complete; with
 * no host the call reports an error after its timeout instead of hanging.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Budget of one blocking transfer */
#define TEST_TIMEOUT_MS             (1000U)

/* Standard clock tree (the same tree the other HAL integration suites use) */
#define STD_PLL_DIV_R               (0x04U)
#define STD_PLL_DIV_Q               (0x01U)
#define STD_PLL_DIV_N               (0x14U)
#define STD_PLL_DIV_F               (0xB4U)
#define STD_AXI4BUS3_DIV            SMU_AXI4BUS3CLK_DIV2
#define STD_APBBUS0_DIV             SMU_APBBUS0CLK_DIV2
#define STD_APBBUS1_DIV             SMU_APBBUS1CLK_DIV2
#define STD_CANX2_DIV               SMU_CANX2CLK_DIV8

/* ---------------------- parameters of this test case --------------------- */
#define TEST_I2C                    I2C1
#define TEST_SCL_PORT               GPIOF
#define TEST_SCL_PIN                GPIO_PIN_15
#define TEST_SCL_SOURCE             GPIO_PinSource15
#define TEST_SDA_PORT               GPIOF
#define TEST_SDA_PIN                GPIO_PIN_13
#define TEST_SDA_SOURCE             GPIO_PinSource13
#define TEST_AF                     GPIO_AF_IIC1

/* Own slave address and peer (slave) address of the original test case */
#define TEST_OWN_ADDRESS            (0x5AU)
#define TEST_PEER_ADDRESS           (0x55U)

/* Transfer size of the original test case */
#define TEST_SIZE                   (64U)

/* Divider values for a 22.5 MHz APB clock: I2C clock = APB / 8 = 2.8125 MHz,
 * DIV 28 -> 100.4 kHz, DIV 7 -> 401.8 kHz */
#define TEST_DIV_100K               (0x1CU)
#define TEST_DIV_400K               (0x07U)
#define TEST_DIV_H                  (0x00U)

/* Number of rate rounds */
#define TEST_ROUNDS                 (2U)


/* Budget of the slave call: the original waited up to 1000000 ms for the host;
 * this port bounds the wait so that a case without a host returns an error
 * instead of blocking the console for ever */
#define TEST_SLAVE_TIMEOUT_MS       (30000U)
/* Private variables -------------------------------------------------------*/
static I2C_HandleTypeDef hi2c_dev;          /*!< I2C handle                   */
static HAL_PMU_HandleTypeDef hpmu_dev;      /*!< PMU handle (LDO scaler)      */
static uint8  I2C_BufferTx[TEST_SIZE];      /*!< transmit buffer              */
static uint8  I2C_BufferRx[TEST_SIZE];      /*!< receive buffer               */
static uint32 g_failures;                   /*!< collected failures           */


/* Private function prototypes ---------------------------------------------*/
static void   SystemClock_Init(void);
static void   I2C_Config(uint32 Divider);
static void   Buffer_Init(void);
static uint32 Chk(const char *name, uint32 expect, uint32 actual);
static void   Info(const char *name, uint32 value);

static void   Print_RxBuffer(void);
/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    HAL_StatusTypeDef status;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);

    printf("\r\n=== I2C_IT_DRV_004: slave receive at 100 kHz ===\r\n");

    /* Transmit buffer contents 0x00..0x3F */
    Buffer_Init();

    /* Configure the peripheral as a slave at 100 kHz */
    I2C_Config(TEST_DIV_100K);
    printf("I2C1 Slave configured at 100K (divider: 0x%02X), Slave Address: 0x%02X\r\n",
           PRINT_U32(TEST_DIV_100K), PRINT_U32(TEST_OWN_ADDRESS));
    printf("Waiting for master to send data...\r\n");

    /* The transfer: the call returns when the host has read the bytes, when the
     * host stops early, or after the timeout */
    status = HAL_I2C_Slave_Receive(&hi2c_dev, I2C_BufferRx, TEST_SIZE,
                                   TEST_SLAVE_TIMEOUT_MS);
    if (status == HAL_OK)
    {
        printf("I2C Slave Receive Success!\r\n");
        printf("Received Data:\r\n");
        Print_RxBuffer();
    }
    else
    {
        printf("I2C Slave Receive Failed! (status = %u)\r\n",
               PRINT_U32((uint32)status));
    }

    /* Configuration read back */
    g_failures += Chk("DIV_L holds the selected divider", (uint32)TEST_DIV_100K,
                      (uint32)TEST_I2C->DIV_L);
    g_failures += Chk("own slave address programmed",
                      (uint32)(TEST_OWN_ADDRESS << 1U), (uint32)TEST_I2C->ADDR);

    /* I2C-REQ-020: the slave receive sequence asserts NACK when the transfer
     * ends, so a completed transfer deliberately leaves the acknowledge flag
     * cleared. That is why this is not a configuration read back of the value
     * HAL_I2C_Init() programmed: it checks the end of the transfer sequence.
     * A transfer that reported an error stopped before that point, so there the
     * flag is only reported, not judged. */
    if (status == HAL_OK)
    {
        g_failures += Chk("last byte answered with NACK (AA cleared by the sequence)",
                          0U, (uint32)((TEST_I2C->CTLR & I2C_CTRL_AA) ? 1U : 0U));
    }
    else
    {
        Info("AA flag left by the failed transfer =",
             (uint32)((TEST_I2C->CTLR & I2C_CTRL_AA) ? 1U : 0U));
    }

    g_failures += Chk("handle state is READY", (uint32)HAL_I2C_STATE_READY,
                      (uint32)HAL_I2C_GetState(&hi2c_dev));
    Info("error code =", HAL_I2C_GetError(&hi2c_dev));

    /* De-initialize and check the reset values */
    g_failures += Chk("HAL_I2C_DeInit returns HAL_OK",
                      (uint32)HAL_OK, (uint32)HAL_I2C_DeInit(&hi2c_dev));
    g_failures += Chk("controller disabled after HAL_I2C_DeInit()", 0U,
                      (uint32)((TEST_I2C->CTLR & I2C_CTRL_EN) ? 1U : 0U));

    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(g_failures));

    while (1)
    {
    }
}

/**
 * @brief  Initialize the clock tree, the SMU / PMU handles and the bus gates.
 * @note   Dividers first (the system clock is still the FIRC), then
 *         HAL_SMU_OscConfig(), which programs the flash controller clock,
 *         switches the system clock and performs the flash clock update.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    osc;
    SMU_ClockInitTypeDef  clk;
    HAL_SMU_HandleTypeDef hsmu;
    SMU_ClocksTypeDef     clocks;

    /* Bus clock gates used by this case */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();

    /* PMU: the LDO APIs are gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu_dev);
    hpmu_dev.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu_dev);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu_dev, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu_dev, PMU_VO12_1V34);

    /* SMU handle */
    __HAL_CLEAR_STRUCT(&hsmu);
    hsmu.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu);

    /* Bus dividers of the standard tree */
    __HAL_CLEAR_STRUCT(&clk);
    clk.Size           = sizeof(clk);
    clk.Version        = SMU_CLOCK_INIT_VERSION;
    clk.AXI4Bus3CLKDiv = STD_AXI4BUS3_DIV;
    clk.APBBus0CLKDiv  = STD_APBBUS0_DIV;
    clk.APBBus1CLKDiv  = STD_APBBUS1_DIV;
    clk.CANX2CLKDiv    = STD_CANX2_DIV;
    (void)HAL_SMU_ClockConfig(&hsmu, &clk);

    /* PLL from the OSC, then switch the system clock to it */
    __HAL_CLEAR_STRUCT(&osc);
    osc.Size                 = sizeof(osc);
    osc.Version              = SMU_OSC_INIT_VERSION;
    osc.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    osc.FIRCState            = SMU_FIRC_ON;
    osc.FIRCCalibrationValue = 0x00U;
    osc.PLL.Size             = sizeof(osc.PLL);
    osc.PLL.Version          = SMU_PLL_INIT_VERSION;
    osc.PLL.PLLState         = SMU_PLL_ON;
    osc.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    osc.PLL.PLLDivR          = STD_PLL_DIV_R;
    osc.PLL.PLLDivQ          = STD_PLL_DIV_Q;
    osc.PLL.PLLDivN          = STD_PLL_DIV_N;
    osc.PLL.PLLDivF          = STD_PLL_DIV_F;
    osc.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;
    (void)HAL_SMU_OscConfig(&hsmu, &osc, SMU_TIMEOUT_DEFAULT);

    (void)HAL_SMU_GetClocksFreq(&clocks);
}

/**
 * @brief  Low level initialization of the I2C peripheral (weak override).
 * @note   The driver calls this from HAL_I2C_Init() before the first register
 *         access and only while the handle is in the RESET state (MSP-04 /
 *         LOCK-06), so the clock gate and the pin multiplexing are in place in
 *         time.  Every round de-initializes the handle first, which is what
 *         makes the callback run again for the second rate.
 * @param  hi2c: I2C handle.
 * @retval None
 */
void HAL_I2C_MspInit(I2C_HandleTypeDef *hi2c)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    if (hi2c->Instance != TEST_I2C)
    {
        return;
    }

    /* Peripheral clock gate and a reset pulse */
    __HAL_SMU_IIC1_CLK_ENABLE();
    __HAL_SMU_IIC1_FORCE_RESET();
    __HAL_SMU_IIC1_RELEASE_RESET();

    /* GPIO port clock of the two pins */
    __HAL_SMU_GPIOF_CLK_ENABLE();

    /* Alternate function mapping */
    HAL_GPIO_PinAFConfig(TEST_SCL_PORT, TEST_SCL_SOURCE, TEST_AF);
    HAL_GPIO_PinAFConfig(TEST_SDA_PORT, TEST_SDA_SOURCE, TEST_AF);

    /* SCL and SDA: alternate function, open drain (pulled up on the bus) */
    __HAL_CLEAR_STRUCT(&GPIO_InitStruct);
    GPIO_InitStruct.Size         = sizeof(GPIO_InitStruct);
    GPIO_InitStruct.Version      = GPIO_INIT_VERSION;
    GPIO_InitStruct.Pin          = TEST_SCL_PIN;
    GPIO_InitStruct.Mode         = GPIO_MODE_AF_OD;
    GPIO_InitStruct.Pull         = GPIO_PULLUP;
    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;
    GPIO_InitStruct.Alternate    = TEST_AF;
    HAL_GPIO_Init(TEST_SCL_PORT, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = TEST_SDA_PIN;
    HAL_GPIO_Init(TEST_SDA_PORT, &GPIO_InitStruct);
}

/**
 * @brief  Low level de-initialization of the I2C peripheral (weak override).
 * @param  hi2c: I2C handle.
 * @retval None
 */
void HAL_I2C_MspDeInit(I2C_HandleTypeDef *hi2c)
{
    if (hi2c->Instance != TEST_I2C)
    {
        return;
    }

    __HAL_SMU_IIC1_CLK_DISABLE();
}

/**
 * @brief  Initialize the I2C peripheral with the selected divider.
 * @param  Divider: value written to the low divider register.
 * @retval None
 */
static void I2C_Config(uint32 Divider)
{
    I2C_InitTypeDef I2C_InitStruct;

    __HAL_CLEAR_STRUCT(&I2C_InitStruct);
    I2C_InitStruct.Size             = sizeof(I2C_InitStruct);
    I2C_InitStruct.Version          = I2C_INIT_VERSION;
    I2C_InitStruct.I2C_ClockScale   = I2C_CLOCKSCALE_PCLK_8;
    I2C_InitStruct.I2C_ICLKDIVL     = (uint8)Divider;
    I2C_InitStruct.I2C_ICLKDIVH     = (uint8)TEST_DIV_H;
    I2C_InitStruct.I2C_EN           = I2C_ENABLE;
    I2C_InitStruct.I2C_SlaveAddress = TEST_OWN_ADDRESS;
    I2C_InitStruct.I2C_Ack          = I2C_ACK;

    hi2c_dev.Instance = TEST_I2C;
    hi2c_dev.Init     = I2C_InitStruct;
    (void)HAL_I2C_Init(&hi2c_dev);
}

/**
 * @brief  Fill the transmit buffer with 0x00..0x3F.
 * @param  None
 * @retval None
 */
static void Buffer_Init(void)
{
    uint16 index;

    for (index = 0U; index < TEST_SIZE; index++)
    {
        I2C_BufferTx[index] = (uint8)index;
    }
}

/**
 * @brief  Print the receive buffer, 16 bytes per line.
 * @param  None
 * @retval None
 */
static void Print_RxBuffer(void)
{
    uint16 index;

    for (index = 0U; index < TEST_SIZE; index++)
    {
        printf("0x%02X ", PRINT_U32(I2C_BufferRx[index]));

        if (((index + 1U) % 16U) == 0U)
        {
            printf("\r\n");
        }
    }
    printf("\r\n");
}

/**
 * @brief  Print one check and return the number of failures it contributes.
 * @param  name: check description.
 * @param  expect: expected value.
 * @param  actual: value read back.
 * @retval uint32: 0 when the check passed, 1 otherwise.
 */
static uint32 Chk(const char *name, uint32 expect, uint32 actual)
{
    uint32 fail = 0U;

    if (expect == actual)
    {
        printf("  [PASS] %s : expect %u, read %u\r\n",
               name, PRINT_U32(expect), PRINT_U32(actual));
    }
    else
    {
        printf("  [FAIL] %s : expect %u, read %u\r\n",
               name, PRINT_U32(expect), PRINT_U32(actual));
        fail = 1U;
    }

    return fail;
}

/**
 * @brief  Print a value without judging it.
 * @param  name: label.
 * @param  value: value to print.
 * @retval None
 */
static void Info(const char *name, uint32 value)
{
    printf("  [info] %s %u\r\n", name, PRINT_U32(value));
}

/*****END OF FILE*****/
