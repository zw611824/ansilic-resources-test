/**
 * @file    PMU_IT_DRV_015.c
 * @brief   HAL PMU integration test case 015 (deep sleep mode, PH2 edge wake-up).
 *
 * One-to-one HAL library port of the original AS32x601 standard-library
 * test case PMU_IT_DRV_015.c. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_PMU_Init()
 *   HAL_PMU_WakeUpSourceCmd()
 *   HAL_PMU_PowerModeConfig() / HAL_PMU_GetPowerModeStatus()
 *   HAL_PMU_GetFlagStatus() / HAL_PMU_GetWakeUpFlag() / HAL_PMU_ClearFlag()
 *   HAL_PMU_GetState() / HAL_PMU_GetError()
 *   HAL_GPIO_Init() / HAL_GPIO_ITConfig() / HAL_GPIO_ClearITPendingBit()
 *   (the PH2 wake-up input)
 *   GPIO wake-up pin read-back (MI0SR multiplex = 0, IMR not masked)
 *
 * Test procedure (same as the original test case):
 *   - report (and clear) the wake-up flag left over by a previous run;
 *   1. Configure PH2 as a pull-up input with both-edge interrupt;
 *   2. Enable the PH2 wake-up source in the PMU (WKEN);
 *   3. Enter deep sleep mode (PMCR.POWMC);
 *   4. The wake-up resets the system, so the program restarts from the
 *      beginning and reports the wake-up flag at its start.
 *
 * Test configuration (same values as the original test case):
 *   power mode     = deep sleep (HAL_PMU_POWERMODE_DEEPSLEEP)
 *   wake-up source = PH2 (HAL_PMU_WKSOURCE_PH2)
 *   wake-up pin    = PH2 (GPIOH pin 2, pull-up input, both edges)
 *
 * Expected behaviour:
 *   - The WKEN read-back shows the enabled wake-up source and the PMCR read-back
 *     shows the selected power mode before the mode is entered (a missing WKEN
 *     bit would leave the chip asleep forever);
 *   - The wake-up resets the system: the program restarts, the wake-up flag of
 *     the PH2 source is still set and is reported (then cleared) at start-up.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Power mode entered by this case */
#define TEST_POWER_MODE             (HAL_PMU_POWERMODE_DEEPSLEEP)

/* Name of the power mode (for the report) */
#define TEST_POWER_NAME             "deep sleep"

/* Wake-up source enabled by this case */
#define TEST_WAKEUP_SOURCE          (HAL_PMU_WKSOURCE_PH2)

/* Wake-up flag expected after the wake-up */
#define TEST_WAKEUP_FLAG            (PMU_FLAG_PH2WK)

/* Wake-up clear value (WKFR write one to clear) of the expected source */
#define TEST_WAKEUP_CLEAR           (PMU_CLEAR_PH2WKF)

/* Human readable name of the wake-up source (for the report) */
#define TEST_WAKEUP_NAME            "PH2"

/* Wake-up pin of this case (GPIOH pin 2..9, pull-up input, both edges) */
#define TEST_PH_GPIO                GPIOH
#define TEST_PH_PIN                 (GPIO_PIN_2)
#define TEST_PH_PIN_SOURCE          (GPIO_PinSource2)
#define TEST_PH_NAME                "PH2"

/* Settling time granted to the wake-up path after PMCR is written (ms) */
#define TEST_WAKE_SETTLE_MS         (100U)

/* Reporting period of the final loop (ms) */
#define TEST_POLL_MS                (500U)

/* Private variables ---------------------------------------------------------*/
static HAL_PMU_HandleTypeDef hpmu_dev;      /*!< PMU device handle            */
static uint32                failures = 0U; /*!< failed checks                */
static volatile uint32       source_flag_seen = 0U; /*!< wake-up flag seen     */

static HAL_SMU_HandleTypeDef hsmu_clk;   /*!< SMU handle (lock / state / error) */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void PMU_Init(void);
static void ReportWakeUpFlags(void);
static void Check(const char *name, uint32 condition);

/**
 * @brief PMU wake-up flag table: flag selector, clear value and source name.
 * @note  Every wake-up flag of the PMU is listed, so any unexpected wake-up
 *        source is reported instead of being silently ignored.
 */
typedef struct
{
    uint32      Flag;                       /*!< PMU_FLAG_xxx selector        */
    uint32      Clear;                      /*!< PMU_CLEAR_xxx write value    */
    const char *Name;                       /*!< wake-up source name          */
} WakeUpFlagTypeDef;

static const WakeUpFlagTypeDef wakeup_flags[] =
{
    { PMU_FLAG_IWDGWK, PMU_CLEAR_IWDGWKF, "IWDG" },
    { PMU_FLAG_RTCWK,  PMU_CLEAR_RTCWKF,  "RTC"  },
    { PMU_FLAG_PH0WK,  PMU_CLEAR_PH0WKF,  "PH0"  },
    { PMU_FLAG_PH1WK,  PMU_CLEAR_PH1WKF,  "PH1"  },
    { PMU_FLAG_PH2WK,  PMU_CLEAR_PH2WKF,  "PH2"  },
    { PMU_FLAG_PH3WK,  PMU_CLEAR_PH3WKF,  "PH3"  },
    { PMU_FLAG_PH4WK,  PMU_CLEAR_PH4WKF,  "PH4"  },
    { PMU_FLAG_PH5WK,  PMU_CLEAR_PH5WKF,  "PH5"  },
    { PMU_FLAG_PH6WK,  PMU_CLEAR_PH6WKF,  "PH6"  },
    { PMU_FLAG_PH7WK,  PMU_CLEAR_PH7WKF,  "PH7"  },
    { PMU_FLAG_PH8WK,  PMU_CLEAR_PH8WKF,  "PH8"  },
    { PMU_FLAG_PH9WK,  PMU_CLEAR_PH9WKF,  "PH9"  },
    { PMU_FLAG_FOCUR,  PMU_CLEAR_FOCURF,  "FOCU" },
};

/**
 * @brief  Read every PMU wake-up flag; print and clear the ones that are set.
 * @note   Mirrors the flag polling of the original test case. The flag of the
 *         expected source additionally arms the "expected wake-up source
 *         reported" check, and the clear operation is verified afterwards
 *         (the wake-up flags are cleared by writing one to the WKFR register).
 * @param  None
 * @retval None
 */
static void ReportWakeUpFlags(void)
{
    uint32 i;
    uint32 count;

    count = (uint32)(sizeof(wakeup_flags) / sizeof(wakeup_flags[0]));

    for (i = 0U; i < count; i++)
    {
        if (HAL_PMU_GetFlagStatus(&hpmu_dev, wakeup_flags[i].Flag) != 0U)
        {
            printf("%s wake up!\r\n", wakeup_flags[i].Name);
            HAL_PMU_ClearFlag(&hpmu_dev, wakeup_flags[i].Clear);

            if (wakeup_flags[i].Flag == (uint32)TEST_WAKEUP_FLAG)
            {
                source_flag_seen = 1U;
            }
        }
    }

    /* acknowledge the expected flag as well and verify the clear operation */
    HAL_PMU_ClearFlag(&hpmu_dev, TEST_WAKEUP_CLEAR);
    printf("WKFR = 0x%X after clearing the reported flags\r\n",
           PRINT_U32(hpmu_dev.Instance->WKFR));
    Check("wake-up flag acknowledged (WKFR cleared)",
          (HAL_PMU_GetFlagStatus(&hpmu_dev, TEST_WAKEUP_FLAG) == 0U));
}

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    GPIO_InitTypeDef gpio_init;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL, 45 MHz core clock) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n\r\n==== PMU_IT_DRV_015: deep sleep mode, PH2 edge wake-up ====\r\n");
    printf("Data : %s\r\n", __DATE__);
    printf("Time : %s\r\n", __TIME__);
    printf("PH2 wake up deep sleep\r\n");

    /* ---- Step 1a: PMU initialization ----------------------------------- */
    PMU_Init();

    /* ---- Step 1b: report a wake-up left over from the previous run ------ *
     * In deep sleep mode the wake-up resets the system, so this program
     * restarts from the beginning and the wake-up flag raised by the power
     * mode hardware is still set: reporting it here is what makes the
     * deep sleep cases observable on the console (the section after the
     * power mode request below is never reached in that mode). On a cold
     * start no flag is set and nothing is printed. */
    ReportWakeUpFlags();
    if (source_flag_seen != 0U)
    {
        Check("previous wake-up reported (deep sleep restarts the program)",
              source_flag_seen);
        source_flag_seen = 0U;
    }
    printf("WKFR before entering the mode = 0x%X\r\n",
           PRINT_U32(hpmu_dev.Instance->WKFR));

    /* ---- Step 1c: configure the wake-up source -------------------------- */

    /* GPIOH pin as the wake-up input (the original test case uses GPIO_IPU and
     * reconfigures the pin with a 9 mA drive strength). GPIOH is always
     * clocked (APB-BusS domain), it has no clock gate macro, and the wake-up
     * does not go through the PLIC: the pin is a PMU wake-up source. */
    __HAL_CLEAR_STRUCT(&gpio_init);
    HAL_GPIO_StructInit(&gpio_init);
    gpio_init.Pin          = TEST_PH_PIN;
    gpio_init.Mode         = GPIO_MODE_INPUT;
    gpio_init.Pull         = GPIO_PULLUP;                  /* original: GPIO_IPU  */
    gpio_init.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;    /* original: 9 mA      */
    HAL_GPIO_Init(TEST_PH_GPIO, &gpio_init);

    /* clear the pending interrupt state, then program the trigger type */
    HAL_GPIO_ClearITPendingBit(TEST_PH_GPIO, TEST_PH_PIN);
    HAL_GPIO_ITConfig(TEST_PH_GPIO, TEST_PH_PIN, GPIO_ITType_EDGE, ENABLE);

    printf("ITYPE0R = 0x%X (trigger field of %s = %u, expected %u)\r\n",
           PRINT_U32(TEST_PH_GPIO->ITYPE0R),
           TEST_PH_NAME,
           PRINT_U32((TEST_PH_GPIO->ITYPE0R >> (TEST_PH_PIN_SOURCE * 2U)) & 0x3U),
           PRINT_U32((uint32)GPIO_ITType_EDGE));
    Check("wake-up pin armed for both edges",
          (((TEST_PH_GPIO->ITYPE0R >> (TEST_PH_PIN_SOURCE * 2U)) & 0x3U) ==
           (uint32)GPIO_ITType_EDGE));
    /* ---- Step 1d: pin configuration read-back --------------------------- *
     * The wake-up input has to be a plain GPIO (the multiplex field of MI0SR
     * reads 0, GPIOH pins 0..9 are encoded in MI0SR) and its interrupt line
     * has to be unmasked (IMR bit = 0 means enabled), otherwise the edge
     * cannot reach the PMU wake-up logic. */
    printf("MI0SR = 0x%X (AF field of %s = %u, expected 0), IMR = 0x%X (mask bit = %u, expected 0)\r\n",
           PRINT_U32(TEST_PH_GPIO->MI0SR),
           TEST_PH_NAME,
           PRINT_U32((TEST_PH_GPIO->MI0SR >> ((uint32)TEST_PH_PIN_SOURCE * 3U)) & 0x7U),
           PRINT_U32(TEST_PH_GPIO->IMR),
           PRINT_U32(((TEST_PH_GPIO->IMR & (uint32)TEST_PH_PIN) != 0U) ? 1U : 0U));
    Check("wake-up pin is a plain GPIO (no alternate function)",
          (((TEST_PH_GPIO->MI0SR >> ((uint32)TEST_PH_PIN_SOURCE * 3U)) & 0x7U) == 0U));
    Check("wake-up pin interrupt line not masked (IMR bit cleared)",
          ((TEST_PH_GPIO->IMR & (uint32)TEST_PH_PIN) == 0U));

    /* ---- Step 2: enable the wake-up source ----------------------------- */
    Check("wake-up source enabled",
          (HAL_PMU_WakeUpSourceCmd(&hpmu_dev, TEST_WAKEUP_SOURCE, ENABLE) == HAL_OK));
    printf("WKEN = 0x%X (requested 0x%X)\r\n",
           PRINT_U32(hpmu_dev.Instance->WKEN), PRINT_U32(TEST_WAKEUP_SOURCE));
    Check("wake-up source bit set in WKEN",
          ((hpmu_dev.Instance->WKEN & (uint32)TEST_WAKEUP_SOURCE) != 0U));

    /* ---- Step 3: enter the power mode ---------------------------------- */
    if (TEST_POWER_MODE == HAL_PMU_POWERMODE_DEEPSLEEP)
    {
        printf("entering deep sleep mode, the wake-up resets the system\r\n");
    }
    else
    {
        printf("entering sleep mode, the wake-up resumes the program\r\n");
    }

    Check("power mode requested",
          (HAL_PMU_PowerModeConfig(&hpmu_dev, TEST_POWER_MODE) == HAL_OK));

    /* The chip is awake again from here on: in sleep mode the core resumes
     * with the peripherals still running, in deep sleep mode the system is
     * reset and this program restarts from the beginning. */
    delay_ms(TEST_WAKE_SETTLE_MS);

    /* the console has to be brought back after the wake-up */
    User_Print_Init(TEST_BAUDRATE);
    delay_init(SystemCoreClock / 1000000U);

    /* ---- Step 4: report and clear the wake-up source -------------------- */
    printf("PMCR = 0x%X (power mode status, 3 = normal)\r\n",
           PRINT_U32(HAL_PMU_GetPowerModeStatus(&hpmu_dev)));
    source_flag_seen = 0U;
    ReportWakeUpFlags();
    Check("expected wake-up source reported", source_flag_seen);

    while (1)
    {
        printf("power mode = %u | mode = %s | WKFR = 0x%X | source = %s | expected = %s | summary : failures = %u\r\n",
               PRINT_U32(HAL_PMU_GetPowerModeStatus(&hpmu_dev)),
               TEST_POWER_NAME,
               PRINT_U32(hpmu_dev.Instance->WKFR),
               TEST_WAKEUP_NAME,
               "wake-up + system reset",
               PRINT_U32(failures));
        delay_ms(TEST_POLL_MS);
    }
}

/**
 * @brief  Configure the system clock tree using the HAL SMU driver.
 * @note   Clock tree shared by every integration test suite of this library:
 *         OSC 20 MHz as the PLL source, PLLDivR = 0x04 / PLLDivN = 0x14 /
 *         PLLDivF = 0xB4 / PLLDivQ = 0x01 -> 45 MHz core clock, then
 *         AXI4Bus3 = /2, APBBus0 = /2, APBBus1 = /2 and CANX2 = /8. The
 *         dividers are programmed while the system clock is still the
 *         power-on source and the PLL is switched in afterwards, which is
 *         the order the chip requires (see HAL_SMU_OscConfig()).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it, so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Clock tree order: the bus dividers are written while the system clock is
       still the power-on source (FIRC), so that the new divider values are
       already in place when the faster clock arrives; the previous call has
       already programmed the EFLASH controller clock and switched the system
       clock. */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition == 0U)
    {
        failures++;
    }
    printf("%-44s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Initialize the PMU handle and report its state.
 * @note   HAL_PMU_Init() must run before any other PMU API of this project:
 *         the configuration APIs are gated on the handle state and refuse to
 *         work on a handle that is still in the RESET state.
 * @param  None
 * @retval None
 */
static void PMU_Init(void)
{
    __HAL_CLEAR_STRUCT(&hpmu_dev);
    hpmu_dev.Instance = PMU;

    Check("PMU init", (HAL_PMU_Init(&hpmu_dev) == HAL_OK));
    printf("PMU state = %u (1 = READY), error = %u\r\n",
           PRINT_U32(HAL_PMU_GetState(&hpmu_dev)),
           PRINT_U32(HAL_PMU_GetError(&hpmu_dev)));
}

/*****END OF FILE*****/
