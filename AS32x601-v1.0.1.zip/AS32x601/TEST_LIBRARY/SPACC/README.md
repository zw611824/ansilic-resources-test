# SPACC 应用与测试参考

供 skill 按需求检索 AS32x601 HAL 安全包加速器（SPACC）示例。别名/关键词：SPACC、DSE、AES-CBC、SM4-OFB、SM3、哈希、加解密、上下文、DDT、软件 ID、状态 FIFO、命令 FIFO。共有 6 个独立用例。

HAL 依据：[头文件](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_spacc.h)、[实现](../../HAL_LIBRARY/peripherals/src/as32x601_hal_spacc.c)。原测试工程的 4_HAL_LIBRARY 未提供，尚不能确认原始链接版本；文中标出的源码与当前 SDK 差异须先解决再迁移。


## 实例与相关资源

本模块不单独列出外部通信引脚组。按实际功能核对实例、时钟、中断、内存或数据通路；关联 GPIO、定时器或其他外设时，再读取对应分支的引脚资料。具体资源与案例配置见下文。

## 生成前需确认的参数

已有工程、板级资料或用户已明确的值直接复用。仅对影响本次实现的缺失选择使用参数卡询问并等待答复；案例配置不能代替实际接线或应用参数。

| 参数 | 需要核对或确认的内容 |
|---|---|
| 算法配置 | 算法、模式、密钥长度、IV/nonce 与填充 |
| 数据通路 | 输入输出格式、字节序、缓冲和对照向量 |

## 按需求选择

| 用户需求 / 检索关键词 | 推荐用例 | 选择条件 / 需要补充的逻辑 |
|---|---|---|
| AES-CBC 加密一个数据包 | [001](SPACC_IT_DRV_001.c) | 最完整的提交模板：写上下文 → `HAL_SPACC_PacketInit()` 暂存描述符 → 填 `SPACC_InitTypeDef` → `HAL_SPACC_Init()` 提交 → 等结果。448 字节、AES-128（KeySize 0x10） |
| AES-CBC 解密 | [002](SPACC_IT_DRV_002.c) | 与 001 相同的数据流，传输模式为解密；向量与 001 对应 |
| SM3 哈希（无上下文） | [003](SPACC_IT_DRV_003.c) | 摘要直接从目的缓冲读取，不需要 `ReadContext`；335 字节消息走 PRE-AAD 字段 |
| SM4-OFB 加密 | [004](SPACC_IT_DRV_004.c) | 算法切到 `SPACC_CIPHER_ALG_SM4`、模式 `SPACC_SM4_CIPHER_MODE_OFB`；232 字节包、处理长度 230 字节，注意“包长 ≠ 处理长度” |
| 完整 API/参数/生命周期自检 | [005](SPACC_IT_DRV_005.c) | 防御性自检，不是应用模板；可查结构默认值、校验、上下文访问和中断配置 |
| 提交队列、结果归属、中断检查 | [006](SPACC_IT_DRV_006.c) | 软件 ID 与 FIFO 出队可作参考；源码 W1C 断言与 SDK 不一致，须先解决版本差异 |
| AES-GCM/CCM、SHA 系列、密钥来自 OTP | 无现成用例 | 驱动有对应字段，但本目录没有参考向量；需按芯片手册确认算法枚举、ICV/AAD 长度和密钥源后再验证 |
| 多包连续处理、DMA 链式搬运 | 无直接模板 | 001 只提交单段 DDT（第二项为 NULL）；多段需自行构造 DDT 链并保证缓存一致性 |

## 实现要点与案例配置

- 时钟与实例：单实例 `SPACC`，位于 AXILite4-Bus1（DSE）域，`HAL_SPACC_MspInit()` 中通过 `__HAL_SMU_DSE_CLK_ENABLE()`、`__HAL_SMU_DSE_FORCE_RESET/RELEASE_RESET()` 打开时钟并释放复位。
- 001 在 SystemClock_Init 中先打开并释放 DSE，再写上下文、配置 DDT/PacketInit，最后填结构调用 Init 提交。不能遗漏首次寄存器访问前的硬件准备。PacketInit 配置硬件描述符寄存器，不是仅缓存于软件，也不等于提交。
- 描述符与缓冲：`SRC_PTR/DST_PTR` 指向 DDT，DDT 首指针必须 8 字节对齐（示例用含 64 位成员的 union 保证），一段链的下一项为 NULL。包缓冲需对 SPACC 可见：示例在填充后、暂存后和读取结果前后调用 `CLEAR_CACHE()`（RISC-V 自定义缓存指令）。
- 示例将 uint32 向量经 TEST_SWAP32 转换后装载或比较；不是所有输入都应反转。已有字节流需分别核对数据、密钥/IV、摘要布局，避免重复交换。
- StateFIFOFlag()==SET 表示状态 FIFO 空，取结果前先判非空。CommandExecResult 弹出一个结果再匹配软件 ID，不是无副作用的按 ID 查询；不匹配也可能消费结果，应用应集中接收、分发并检查执行结果码。
- 证据边界：密文/明文/摘要与参考向量逐字比较，能证明算法数据通路与上下文读写正确；软件 ID 匹配能证明结果归属。不能证明密钥存储安全、侧信道抗性或多任务并发正确性。

SDK 的 HAL_SPACC_IRQHandler 读 IRQ_STAT、更新状态并报告错误，没有写 1 清除路径；中断来源通过相应 FIFO/服务操作处理。006 的“写 1 清除”断言不能作为本版行为，不能向假定的 ISTAT 写清除值。

## 验证方法与适用边界

- `HAL_SPACC_Init()` 是“提交任务”，不是纯外设初始化；重复调用会再次提交。不要按其他外设的习惯在初始化阶段调用两次。
- DDT/缓冲需满足设备可访问性、对齐和缓存一致性，按芯片实际规定维护缓存，不凭其他平台经验追加 invalidate。
- DDT、上下文及数据缓冲在完成前需有效且不被提前改写；局部缓冲只有在退出作用域前确认硬件不再使用时才可采用。示例使用静态存储。
- 队列可保存多个任务，句柄 READY 只表示提交 API 已返回，不表示硬件完成。多任务需同步描述符、上下文和提交，按软件 ID 分发结果；006 不是完整并发模板。
- `HAL_SPACC_DeInit()` 不写 CTRL、不重置 FIFO（006 验证）；重新初始化前应自行清空遗留结果，否则会读到上一次的完成事件。
- KeySize/KeyIndex/KeyFrom 与上下文索引必须匹配实际密钥装载方式；示例从上下文取密钥（`SPACC_KEY_FROM_CTX`），不是直接写密钥寄存器。
- 003 的 SM3 摘要从目的缓冲读取，不需要上下文；不要不必要地调用 `ReadContext` 并把它当成摘要来源。

## 按接口与辅助宏检索

| 接口 / 宏 | 参考用例 |
|---|---|
| `HAL_SPACC_StructInit` / `HAL_SPACC_Init` / `HAL_SPACC_DeInit` | [001](SPACC_IT_DRV_001.c)、[005](SPACC_IT_DRV_005.c) |
| `HAL_SPACC_PacketInit` | [001](SPACC_IT_DRV_001.c)、[003](SPACC_IT_DRV_003.c) |
| `HAL_SPACC_WriteContext` / `HAL_SPACC_ReadContext` | [001](SPACC_IT_DRV_001.c)、[004](SPACC_IT_DRV_004.c) |
| `HAL_SPACC_StateFIFOFlag` / `HAL_SPACC_CommandExecResult` | [001](SPACC_IT_DRV_001.c)、[006](SPACC_IT_DRV_006.c) |
| `HAL_SPACC_ITConfig` / `HAL_SPACC_GetITStatus` / `HAL_SPACC_IRQHandler` | [005](SPACC_IT_DRV_005.c)、[006](SPACC_IT_DRV_006.c) |
| `HAL_SPACC_ReadStatus` / `HAL_SPACC_GetState` / `HAL_SPACC_GetError` | [005](SPACC_IT_DRV_005.c)、[006](SPACC_IT_DRV_006.c) |
| `SPACC_CIPHER_ALG_AES` / `SPACC_CIPHER_ALG_SM4` | [001](SPACC_IT_DRV_001.c)、[004](SPACC_IT_DRV_004.c) |
| `SPACC_HASH_ALG_SM3` / `SPACC_SM3_HASH_MODE_*` | [003](SPACC_IT_DRV_003.c) |


本次为源码静态整理，未重新编译、未上板；源码里的历史测试注释不代表本次验证结果。
