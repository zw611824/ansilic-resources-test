/**
 * @file    EFLASH_IT_DRV_004.c
 * @brief   HAL EFLASH integration test case 004 (block erase, completion interrupt, security).
 *
 * HAL port of the reference test case Eflash_IT_DRV_004.
 *
 * Tested functionality:
 *   HAL_FLASH_Init() / HAL_FLASH_Unlock() / HAL_FLASH_Erase() (block erase)
 *   HAL_FLASH_Program() / HAL_FLASH_Read()
 *   HAL_FLASH_ITConfig() / HAL_FLASH_ClearITPendingBit() / HAL_FLASH_GetFlagStatus()
 *   HAL_FLASH_GetSECFlagStatus() / HAL_FLASH_GetECCErrorAddress()
 *   HAL_FLASH_ClearECCErrorAddress() / HAL_FLASH_InputSECKEY()
 *   HAL_PLIC_Init() + the EFLASH completion interrupt path
 *
 * Test procedure (default, safe mode):
 *   1. initialize the driver, unlock the controller and raise the EFLASH
 *      completion interrupt in the PLIC (priority 1);
 *   2. erase one D-Flash BLOCK (0x02000000, 512 KB) with the completion
 *      interrupt enabled: the interrupt must be serviced, and the handler
 *      disables the source again;
 *   3. read the erased block start back as 0xFFFFFFFF, program 512 bytes and
 *      read them back unchanged;
 *   4. query the security register (read protection / security key enable) and
 *      prove that the query is side effect free (two reads agree);
 *   5. read the ECC error address register and clear it (no ECC event is
 *      expected, so it must read back as 0 after the clear).
 *
 * Full read protection flow (opt-in):
 *   Setting TEST_RUN_FULL_READ_PROTECTION to 1 runs the reference sequence as
 *   well: program the read protection pattern into the P-Flash information
 *   sector, reset the controller through the FCU software channel, read the
 *   protected P-Flash (the access is refused), unlock it with
 *   HAL_FLASH_InputSECKEY() and erase the whole chip at the end.
 *
 *   WARNING: the full flow is DESTRUCTIVE and cannot run from the P-Flash:
 *     - it erases the P-Flash block 0 which holds the running image, and
 *     - once the read protection is active the core cannot fetch from the
 *       P-Flash any more.
 *   Run it only from an image placed in the QSPI flash (or another memory that
 *   is not erased by this case), and expect one controller reset on the first
 *   run. A guard word in the backup RAM keeps the sequence from looping.
 *
 * Expected behaviour:
 *   the block erase, the programming and the read back all succeed, the
 *   completion interrupt is delivered exactly as configured, the security
 *   query has no side effect and "summary : failures = 0" is printed.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define -----------------------------------------------------------*/
#define TEST_BAUDRATE                  (115200U)      /*!< console baud rate   */
#define TEST_DFLASH_BLOCK              (0x02000000U)  /*!< D-Flash block base  */
#define TEST_PFLASH_BLOCK              (0x01000000U)  /*!< P-Flash block base  */
#define TEST_RP_INFO_ADDR              (0x01201000U)  /*!< P-Flash info sector */
#define TEST_PATTERN_WORDS             (128U)         /*!< 512 bytes           */
#define TEST_ROUND_DELAY_MS            (2000U)        /*!< delay between runs  */
#define TEST_ISR_TIMEOUT_MS            (1000U)        /*!< interrupt wait      */

/**
 * @brief Opt-in of the destructive read protection flow.
 * @note  0 (default) keeps the case repeatable: the read protection is only
 *        queried, never enabled. 1 runs the reference sequence documented in
 *        the file header; run it from the QSPI flash only.
 * @note  The value can be overridden from the build command line with
 *        -DTEST_RUN_FULL_READ_PROTECTION=1.
 */
#ifndef TEST_RUN_FULL_READ_PROTECTION
#define TEST_RUN_FULL_READ_PROTECTION  (0U)
#endif

/* Backup RAM guard of the full flow (survives a controller reset) */
#define TEST_GUARD_ADDR                (BACKUP_RAM_BASE)
#define TEST_GUARD_MAGIC               (0x574C4634U)  /*!< "WLF4"              */
#define TEST_RP_KEY0                   (0x01020304U)
#define TEST_RP_KEY1                   (0x05060708U)

/* Private variables ---------------------------------------------------------*/
static volatile uint32 check_failures = 0U;   /*!< failed check counter        */
static volatile uint32 irq_count      = 0U;   /*!< completion ISR entries      */
static HAL_SMU_HandleTypeDef hsmu_clk;        /*!< SMU handle (clock tree)     */
static HAL_FLASH_HandleTypeDef hflash_dev;    /*!< FLASH handle of this case   */
#if (TEST_RUN_FULL_READ_PROTECTION != 0U)
static HAL_FCU_HandleTypeDef hfcu_dev;        /*!< FCU handle (full flow only) */
#endif

static uint32 program_data[TEST_PATTERN_WORDS];
static uint32 read_data[TEST_PATTERN_WORDS];

/* Shared helpers of this suite (defined at the end of this file) */
void Check(const char *name, uint32 condition);
void Summary(void);
void SystemClock_Init(void);
void Flash_InitDevice(void);
void FillPattern(void);
uint32 BufferEquals(const uint32 *a, const uint32 *b, uint32 words);
uint32 BufferIsErased(const uint32 *buf, uint32 words);
void Flash_PlicEnable(void);

/**
 * @brief  EFLASH interrupt handler.
 * @note   The HAL FLASH driver is polling only and provides no interrupt
 *         handler of its own, so the application owns this entry. It is
 *         written over the weak EFLASH_IRQ_Handler() of the PLIC module
 *         (which would otherwise park the core in the default handler).
 * @note   The completion source is acknowledged here, so the level triggered
 *         PLIC line is released before the handler returns. Enabling and
 *         disabling the source needs no handle lock (the driver declares
 *         those two calls interrupt safe).
 * @param  None
 * @retval None
 */
void EFLASH_IRQ_Handler(void)
{
    irq_count++;

    /* Acknowledge the event when it is still latched here: the polled driver
     * may already have cleared FINISH before the core took this interrupt. */
    if (HAL_FLASH_GetFlagStatus(&hflash_dev, FLASH_FLAG_FINISH) == FLASH_FLAG_SET)
    {
        HAL_FLASH_ClearITPendingBit(&hflash_dev, FLASH_CLEAR_IT_FINISH);
    }

    /* The source is disabled unconditionally: this case arms it for one
     * erase on purpose, and leaving it enabled with a level triggered line
     * would keep the core in the handler. */
    HAL_FLASH_ITConfig(&hflash_dev, FLASH_IT_FINIE, FLASH_IT_DISABLE);
}

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    FLASH_EraseInitTypeDef erase;
    HAL_StatusTypeDef      status;
    uint32                 addr_error;
    uint32                 tickstart;
    uint32                 sec_flag_first;
    uint32                 sec_flag_second;
    uint32                 ecc_addr;
    uint32                 i;

    HAL_Init();
    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== EFLASH_IT_DRV_004 : block erase, completion interrupt, security ===\r\n");
    printf("mode : %s\r\n", (TEST_RUN_FULL_READ_PROTECTION != 0U) ?
           "FULL read protection flow (destructive)" : "safe (read protection queried only)");

    /* ---- 1. driver initialization, unlock and interrupt routing ----------- */
    Flash_InitDevice();
    Check("HAL_FLASH_Init publishes the READY state",
          (HAL_FLASH_GetState(&hflash_dev) == HAL_FLASH_STATE_READY) ? 1U : 0U);
    status = HAL_FLASH_Unlock(&hflash_dev);
    Check("HAL_FLASH_Unlock returns HAL_OK", (status == HAL_OK) ? 1U : 0U);

    Flash_PlicEnable();
    FillPattern();

    /* ---- 2. block erase with the completion interrupt enabled ------------- */
    HAL_FLASH_ClearFlagStatus(&hflash_dev, FLASH_CLEAR_FINISH);
    HAL_FLASH_ITConfig(&hflash_dev, FLASH_IT_FINIE, FLASH_IT_ENABLE);

    erase.TypeErase = FLASH_TYPEERASE_BLOCKS;
    erase.Address   = TEST_DFLASH_BLOCK;
    erase.Length    = DFLASH_BLOCK_SIZE;
    addr_error      = 0xFFFFFFFFU;
    status = HAL_FLASH_Erase(&hflash_dev, &erase, &addr_error);
    Check("D-Flash block erase returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("D-Flash block erase reports no failing unit",
          (addr_error == 0xFFFFFFFFU) ? 1U : 0U);

    /* The handler disables the source; wait (bounded) for at least one entry */
    tickstart = HAL_GetTick();
    while ((irq_count == 0U) && ((HAL_GetTick() - tickstart) < TEST_ISR_TIMEOUT_MS))
    {
    }
    Check("the completion interrupt was serviced at least once", (irq_count > 0U) ? 1U : 0U);
    Check("the interrupt handler cleared the completion flag",
          (HAL_FLASH_GetFlagStatus(&hflash_dev, FLASH_FLAG_FINISH) == FLASH_FLAG_RESET) ? 1U : 0U);
    Check("the interrupt handler disabled the completion source again",
          ((EFLASH->CR & FLASH_IT_FINIE) == 0U) ? 1U : 0U);

    /* ---- 3. erased block reads back as 0xFFFFFFFF, then program it -------- */
    status = HAL_FLASH_Read(&hflash_dev, TEST_DFLASH_BLOCK, 512U, read_data);
    Check("read after the block erase returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("the erased block reads back as 0xFFFFFFFF",
          BufferIsErased(read_data, TEST_PATTERN_WORDS));

    status = HAL_FLASH_Program(&hflash_dev, TEST_DFLASH_BLOCK, 512U, program_data);
    Check("programming the erased block returns HAL_OK", (status == HAL_OK) ? 1U : 0U);

    for (i = 0U; i < TEST_PATTERN_WORDS; i++)
    {
        read_data[i] = 0U;
    }
    status = HAL_FLASH_Read(&hflash_dev, TEST_DFLASH_BLOCK, 512U, read_data);
    Check("read back of the block returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("the programmed content is read back unchanged",
          BufferEquals(read_data, program_data, TEST_PATTERN_WORDS));

    /* ---- 4. security register: query only, no side effect ----------------- */
    sec_flag_first  = (uint32)HAL_FLASH_GetSECFlagStatus(&hflash_dev, FLASH_SECFLAG_RP);
    sec_flag_second = (uint32)HAL_FLASH_GetSECFlagStatus(&hflash_dev, FLASH_SECFLAG_RP);
    printf("  read protection flag : %s\r\n",
           (sec_flag_first == (uint32)FLASH_FLAG_SET) ? "active (field not all ones)" : "not active");
    Check("the read protection query is side effect free",
          (sec_flag_first == sec_flag_second) ? 1U : 0U);

    sec_flag_first  = (uint32)HAL_FLASH_GetSECFlagStatus(&hflash_dev, FLASH_SECFLAG_KEY);
    sec_flag_second = (uint32)HAL_FLASH_GetSECFlagStatus(&hflash_dev, FLASH_SECFLAG_KEY);
    printf("  security key enable  : %s\r\n",
           (sec_flag_first == (uint32)FLASH_FLAG_SET) ? "active (field not all ones)" : "not active");
    Check("the security key query is side effect free",
          (sec_flag_first == sec_flag_second) ? 1U : 0U);

    /* ---- 5. ECC error address register ----------------------------------- */
    ecc_addr = HAL_FLASH_GetECCErrorAddress(&hflash_dev);
    printf("  ECC error address    : 0x%08X\r\n", (unsigned)ecc_addr);
    HAL_FLASH_ClearECCErrorAddress(&hflash_dev);
    Check("clearing the ECC error address works",
          (HAL_FLASH_GetECCErrorAddress(&hflash_dev) == 0U) ? 1U : 0U);

#if (TEST_RUN_FULL_READ_PROTECTION != 0U)
    /* ================= full read protection flow (opt-in) ================= */
    printf("  full flow : guard 0x%08X\r\n", (unsigned)(*(volatile uint32 *)TEST_GUARD_ADDR));

    if (*(volatile uint32 *)TEST_GUARD_ADDR == TEST_GUARD_MAGIC)
    {
        /* Second run after the controller reset: the protection is active, so
         * the P-Flash read is expected to be refused until the key is given. */
        status = HAL_FLASH_Read(&hflash_dev, TEST_PFLASH_BLOCK, 8U, read_data);
        printf("  protected read  : status=%d data=0x%08X 0x%08X\r\n",
               (int)status, (unsigned)read_data[0], (unsigned)read_data[1]);
        Check("the P-Flash read is refused while the protection is active",
              (status != HAL_OK) ? 1U : 0U);

        status = HAL_FLASH_InputSECKEY(&hflash_dev, TEST_RP_KEY0, TEST_RP_KEY1);
        Check("HAL_FLASH_InputSECKEY returns HAL_OK", (status == HAL_OK) ? 1U : 0U);

        status = HAL_FLASH_Read(&hflash_dev, TEST_PFLASH_BLOCK, 8U, read_data);
        Check("the P-Flash read succeeds again after the key", (status == HAL_OK) ? 1U : 0U);

        /* Whole chip erase releases the protection for good */
        erase.TypeErase = FLASH_TYPEERASE_MASSERASE;
        erase.Address   = 0U;
        erase.Length    = 0U;
        status = HAL_FLASH_Erase(&hflash_dev, &erase, &addr_error);
        Check("mass erase returns HAL_OK", (status == HAL_OK) ? 1U : 0U);

        *(volatile uint32 *)TEST_GUARD_ADDR = 0U;
    }
    else
    {
        FLASH_EraseInitTypeDef rp_erase;

        /* First run: write the protection pattern, arm the guard and reset */
        rp_erase.TypeErase = FLASH_TYPEERASE_BLOCKS;
        rp_erase.Address   = TEST_PFLASH_BLOCK;
        rp_erase.Length    = PFLASH_BLOCK_SIZE;
        status = HAL_FLASH_Erase(&hflash_dev, &rp_erase, &addr_error);
        Check("P-Flash block 0 erase returns HAL_OK", (status == HAL_OK) ? 1U : 0U);

        program_data[0] = 0x00000000U;   /* read protection enable pattern */
        program_data[1] = 0x00000000U;
        program_data[2] = TEST_RP_KEY0;  /* unlock key                     */
        program_data[3] = TEST_RP_KEY1;
        status = HAL_FLASH_Program(&hflash_dev, TEST_RP_INFO_ADDR, 16U, program_data);
        Check("programming the read protection pattern returns HAL_OK",
              (status == HAL_OK) ? 1U : 0U);

        *(volatile uint32 *)TEST_GUARD_ADDR = TEST_GUARD_MAGIC;
        printf("  requesting a controller reset through the FCU...\r\n");

        /* FCU software channel 0 with a global software reset action */
        __HAL_CLEAR_STRUCT(&hfcu_dev);
        hfcu_dev.Instance = FCU;
        (void)HAL_FCU_Init(&hfcu_dev);
        (void)HAL_FCU_Cmd(&hfcu_dev, HAL_FCU_CHANNEL_SOFTWARE0, ENABLE);
        (void)HAL_FCU_SetFaultAction(&hfcu_dev, HAL_FCU_CHANNEL_SOFTWARE0,
                                     HAL_FCU_FAULT_GLOBAL_SOFTWARE_RESET);
        (void)HAL_FCU_SetLevel(&hfcu_dev, HAL_FCU_CHANNEL_SOFTWARE0, HAL_FCU_FAULT_LEVEL_FAULT);
        (void)HAL_FCU_SetSoftwareTrigger(&hfcu_dev, 0U);

        /* The reset happens here; the guard keeps the second run on the
         * branch above. */
        Check("the FCU software reset was requested", 1U);
    }
#endif /* TEST_RUN_FULL_READ_PROTECTION */

    /* ---- 6. tear down ---------------------------------------------------- */
    status = HAL_FLASH_Lock(&hflash_dev);
    Check("HAL_FLASH_Lock returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    status = HAL_FLASH_DeInit(&hflash_dev);
    Check("HAL_FLASH_DeInit returns HAL_OK", (status == HAL_OK) ? 1U : 0U);

    Summary();

    for (;;)
    {
        delay_ms(TEST_ROUND_DELAY_MS);
    }
}

/* Private functions -------------------------------------------------------*/

void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

void FillPattern(void)
{
    uint32 i;

    for (i = 0U; i < TEST_PATTERN_WORDS; i++)
    {
        program_data[i] = (0x01020304U + (i * 0x01010101U)) ^ (i << 24);
    }
}

uint32 BufferEquals(const uint32 *a, const uint32 *b, uint32 words)
{
    uint32 i;

    for (i = 0U; i < words; i++)
    {
        if (a[i] != b[i])
        {
            printf("  mismatch at word %u : 0x%08X / 0x%08X\r\n",
               (unsigned)i, (unsigned)a[i], (unsigned)b[i]);
            return 0U;
        }
    }

    return 1U;
}

uint32 BufferIsErased(const uint32 *buf, uint32 words)
{
    uint32 i;

    for (i = 0U; i < words; i++)
    {
        if (buf[i] != 0xFFFFFFFFU)
        {
            printf("  word %u is 0x%08X instead of 0xFFFFFFFF\r\n",
               (unsigned)i, (unsigned)buf[i]);
            return 0U;
        }
    }

    return 1U;
}

/**
 * @brief  Route the EFLASH completion interrupt through the PLIC.
 * @note   The PLIC channel has to be enabled for the completion event to reach
 *         the core; the machine external interrupt itself is enabled by the
 *         startup file.
 * @param  None
 * @retval None
 */
void Flash_PlicEnable(void)
{
    PLIC_InitTypeDef plic_init;

    __HAL_CLEAR_STRUCT(&plic_init);
    plic_init.Size               = sizeof(plic_init);
    plic_init.Version            = PLIC_INIT_VERSION;
    plic_init.PLIC_IRQChannel    = EFLASH_IRQn;
    plic_init.PLIC_IRQPriority   = 1U;
    plic_init.PLIC_IRQChannelCmd = PLIC_ENABLE;
    HAL_PLIC_Init(&plic_init);
}

/**
 * @brief  Configure the system clock tree (PLL 180 MHz, APB 22.5 MHz).
 * @param  None
 * @retval None
 */
void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Initialize the FLASH driver handle of this suite.
 * @param  None
 * @retval None
 */
void Flash_InitDevice(void)
{
    __HAL_CLEAR_STRUCT(&hflash_dev);
    hflash_dev.Instance = EFLASH;
    HAL_FLASH_StructInit(&hflash_dev.Init);
    hflash_dev.Init.ClockFreq = (uint32)(SystemCoreClock / 1000000U);
    (void)HAL_FLASH_Init(&hflash_dev);
}

/*****END OF FILE*****/
