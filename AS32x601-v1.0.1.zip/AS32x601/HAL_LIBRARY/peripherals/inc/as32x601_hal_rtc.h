/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):    Xiamen Guoke Anxin Technology Co., LTD
 * FileName:         as32x601_hal_rtc.h
 * Author:           ANSILIC APPLICATION GROUP
 * Version:          V1.6
 * Date:             2026/11/04
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/11/04     1.6     state the device prerequisite of the
 *                                                       de-initialization in the register reset
 *                                                       interface: the control register is
 *                                                       cleared before TR / DR, because the
 *                                                       device ignores writes to the time and
 *                                                       date registers while the calendar is
 *                                                       enabled
 *     ANSILIC APPLICATION GROUP  2026/11/02     1.5     align with the implementation file
 *                                                       (V1.4) and make the header
 *                                                       self-contained, then close the
 *                                                       comparison findings: include
 *                                                       as32x601_hal.h so that USE_RTOS is
 *                                                       visible to a direct includer (the
 *                                                       RTOS handle layout was divergent),
 *                                                       export RTC_HandleIsValid() next to
 *                                                       the other shared internal
 *                                                       processes so that every register
 *                                                       accessing interface runs the same
 *                                                       handle check, state check and lock
 *                                                       sequence, document the run time
 *                                                       parameter validation, the metafield
 *                                                       check of the Init structure, the
 *                                                       alarm flag clearing prerequisite and
 *                                                       the interrupt entry that no longer
 *                                                       changes the task side state, and
 *                                                       drop the extension include note left
 *                                                       over from the merged Ex file
 *     ANSILIC APPLICATION GROUP  2026/09/21     1.2     drop the six remaining external
 *                                                       implementation references of the
 *                                                       documentation (the Division field
 *                                                       note, the Time and Alarm structure
 *                                                       notes, the Alarm constant note, the
 *                                                       HAL_RTC_Cmd() note and the register
 *                                                       mask origin note), each rewritten
 *                                                       from the device itself
 *     ANSILIC APPLICATION GROUP  2026/09/17     1.1     align the resource lock and the RTOS support with
 *                                                       the architecture specification (sections 13 and
 *                                                       21): export the shared lock helpers
 *                                                       (RTC_LockHandle / RTC_UnlockHandle, with a
 *                                                       Timeout parameter and a NULL mutex guard -
 *                                                       RTOS-11) and the shared state check
 *                                                       (RTC_CheckState, ARCH-CONST-09) in the private
 *                                                       section so that the extended driver
 *                                                       (as32x601_hal_rtc_ex.c) shares them; document
 *                                                       the LOCK-06 MSP callback ordering and the
 *                                                       state gate of the register accessing APIs
 *     ANSILIC APPLICATION GROUP  2026/08/24     1.0     build this module
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Real Time Clock (RTC)
 *                  peripheral:
 *                  - Initialization and de-initialization (HAL_RTC_Init /
 *                    HAL_RTC_DeInit + weak MSP hooks);
 *                  - Time and date (HAL_RTC_SetTime / HAL_RTC_GetTime /
 *                    HAL_RTC_SetDate / HAL_RTC_GetDate + *StructInit);
 *                  - Alarm (HAL_RTC_SetAlarm / HAL_RTC_SetAlarm_IT /
 *                    HAL_RTC_GetAlarm, interrupt mode with
 *                    HAL_RTC_AlarmIRQHandler and weak
 *                    HAL_RTC_AlarmEventCallback callback);
 *                  - Peripheral control (HAL_RTC_Cmd / HAL_RTC_GetState).
 *                  The chip-specific wake-up feature is provided by
 *                  this driver (HAL_RTC_WakeUpCmd).
 *                  This driver depends on as32x601_hal.h (user
 *                  configuration: USE_RTOS and the module switch, plus
 *                  as32x601_hal_def.h), on as32x601_hal_def.h (HAL common
 *                  types and utilities) and on as32x601.h (RTC_TypeDef,
 *                  register bits). The RTC has no SMU clock gate (the clock
 *                  is always on), so the weak MSP hooks are empty by
 *                  default: the user may override them to configure the
 *                  RTC_IRQn PLIC line when interrupt mode is used.
 *                  Every interface that touches a register runs the same
 *                  three shared internal processes in the same order:
 *                  RTC_HandleIsValid() (null pointer and instance),
 *                  RTC_CheckState() (the ARCH-CONST-09 state gate) and
 *                  RTC_LockHandle() / RTC_UnlockHandle() (the resource
 *                  lock). HAL_RTC_Init() and HAL_RTC_DeInit() are the two
 *                  documented exceptions to the state gate, and
 *                  HAL_RTC_AlarmIRQHandler() is the documented exception to
 *                  the lock (an interrupt service routine must not take the
 *                  task lock).
 * @complexity  Complex
 *              Time/date/alarm + state machine + lock, polling + interrupt
 *              (alarm) mode.
 */
#ifndef __AS32X601_HAL_RTC_H
#define __AS32X601_HAL_RTC_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "as32x601_hal.h"           /* user configuration (USE_RTOS) + def.h   */
#include "as32x601_hal_def.h"       /* HAL common types and utilities          */
#include "as32x601.h"               /* RTC_TypeDef, RTC, register bits         */

/**
 * @brief RTC HAL driver module version.
 * @note  0x0100U = V1.0. Bumped only on breaking API changes (architecture
 *        spec COMPAT-13/14/15).
 */
#define __HAL_RTC_MODULE_VERSION  0x0100U

/* Exported types ------------------------------------------------------------*/

/** @defgroup RTC_Exported_Types RTC Exported Types
  * @{
  */

/**
 * @brief  HAL RTC State structures definition
 * @note   The State field of the handle is a plain state machine value
 *         (HAL_RTC_STATE_x).
 * @{
 */
#define HAL_RTC_STATE_RESET             0x00000000U  /*!< RTC not yet initialized or disabled */
#define HAL_RTC_STATE_READY             0x00000001U  /*!< RTC initialized and ready for use   */
#define HAL_RTC_STATE_BUSY              0x00000002U  /*!< RTC process is ongoing              */
#define HAL_RTC_STATE_TIMEOUT           0x00000003U  /*!< RTC timeout state                   */
#define HAL_RTC_STATE_ERROR             0x00000004U  /*!< RTC error state                     */
typedef uint32 HAL_RTCStateTypeDef;
/**
  * @}
  */

/**
 * @brief RTC Init Structure definition
 * @note  The Division field maps the RTC_CR.DIV divider coefficient (the
 *        value recommended for a 1 Hz time base is 1638, which is the
 *        32768 Hz clock divided to 1 Hz).
 * @note  This structure follows the Version+Size compatibility mechanism
 *        (architecture spec section 22): the user must clear the structure
 *        (__HAL_CLEAR_STRUCT / memset), set the Size and Version metafields
 *        before filling the business fields.
 */
typedef struct
{
    uint32 Size;   /*!< sizeof(RTC_InitTypeDef), must be set by
                                                  the user after clearing the structure */
    uint32 Version;   /*!< Structure semantic version: @ref
                                                  RTC_INIT_VERSION (RTC_INIT_V1 = 0x0100U) */
    uint32 Division;   /*!< RTC clock divider coefficient (0 ..
                                                  0x7FFFFFF) */
    uint32 Reserved[2];   /*!< Reserved for future extension (must be 0)
                                                     */
} RTC_InitTypeDef;

/**
 * @brief RTC / init structure version macros.
 * @note  RTC_INIT_V1 is the current version. Future versions (e.g. V2 with
 *        new fields) must be appended after the existing fields without
 *        changing the layout (architecture spec section 22.5).
 */
#define RTC_INIT_V1  0x0100U   /*!< RTC Init structure version V1.0 */
#define RTC_INIT_VERSION  RTC_INIT_V1   /*!< Current RTC Init structure version */

/**
 * @brief RTC Time structure definition
 * @note  The fields keep the field names and their decimal semantics
 *        (converted to/from BCD internally by the driver). The
 *        RTC_TenthOfSecond field is a chip-specific resolution (0-9).
 */
typedef struct
{
    uint8 RTC_Hours;   /*!< Specifies the RTC Time Hour (0-23 range)
                                                    */
    uint8 RTC_Minutes;   /*!< Specifies the RTC Time Minutes (0-59
                                                  range)  */
    uint8 RTC_Seconds;   /*!< Specifies the RTC Time Seconds (0-59
                                                  range)  */
    uint8 RTC_TenthOfSecond;   /*!< Specifies one tenth of second (0-9 range)
                                                    */
} RTC_TimeTypeDef;

/**
 * @brief RTC Date structure definition
 * @note  The RTC_Century field is a chip-specific extension (0-99) stored in
 *        the RTC_DR.CT/CU bits.
 */
typedef struct
{
    uint8 RTC_WeekDay;   /*!< Specifies the RTC Date WeekDay
                                                  (RTC_Weekday_x) */
    uint8 RTC_Century;   /*!< Specifies the RTC Date Century (0-99
                                                  range)    */
    uint8 RTC_Year;   /*!< Specifies the RTC Date Year (0-99 range)
                                                      */
    uint8 RTC_Month;   /*!< Specifies the RTC Date Month (RTC_Month_x)
                                                      */
    uint8 RTC_Date;   /*!< Specifies the RTC Date (1-31 range)
                                                      */
} RTC_DateTypeDef;

/**
 * @brief RTC Alarm structure definition
 * @note  The comparison enable fields select which time / date fields are
 *        compared (RTC_AlarmTime_x / RTC_AlarmDate_x bit masks): a bit set
 *        to 1 means the corresponding field is compared. The chip has a
 *        single alarm (no Alarm A/B).
 */
typedef struct
{
    RTC_TimeTypeDef RTC_AlarmTime;                /*!< Specifies the RTC Alarm Time members   */
    RTC_DateTypeDef RTC_AlarmDate;                /*!< Specifies the RTC Alarm Date members   */
    uint32 RTC_AlarmTimeCompEn;                   /*!< RTC Alarm Time Comparison Enable       */
    uint32 RTC_AlarmDataCompEn;                   /*!< RTC Alarm Date Comparison Enable       */
} RTC_AlarmTypeDef;

/**
 * @brief  RTC handle Structure definition
 */
typedef struct __HAL_RTC_HandleTypeDef
{
    RTC_TypeDef               *Instance;          /*!< Register base address                     */
    RTC_InitTypeDef           Init;               /*!< RTC required parameters                   */
    HAL_LockTypeDef           Lock;               /*!< RTC locking object                        */
    __IO HAL_RTCStateTypeDef  State;              /*!< Time communication state                  */
    __IO uint32               ErrorCode;          /*!< RTC error code                            */
#if (USE_RTOS == 1)
    HAL_MutexTypeDef          LockMutex;          /*!< RTOS mutex handle                         */
#endif
} RTC_HandleTypeDef;

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @defgroup RTC_Exported_Constants RTC Exported Constants
  * @{
  */

/** @defgroup RTC_Error_Code RTC Error Code
  * @{
  */
/**
  * @brief  RTC error codes.
  * @note   HAL_RTC_ERROR_NONE is written by every start operation
  *         (ARCH-CONST-10 / ERR-03). HAL_RTC_ERROR_INVALID_PARAM is raised by
  *         the run time validation of every interface that accepts a value
  *         (the Init metafields, the divider, the format, the time / date /
  *         alarm fields including the per digit BCD check, the comparison
  *         enable masks and the functional state); the validation runs before
  *         the lock is taken, so a rejected call changes neither the state nor
  *         a register. HAL_RTC_ERROR_TIMEOUT is part of the common error code
  *         set of the library but is NOT produced by this driver: the RTC has
  *         no blocking wait (only the lock can wait, and its result is reported
  *         through the return value). A call that is refused because of the
  *         handle state also reports the reason through the return value
  *         (HAL_BUSY / HAL_ERROR) and leaves the state visible through
  *         HAL_RTC_GetState().
  */
#define HAL_RTC_ERROR_NONE              ((uint32)0x00000000U)  /*!< No error            */
#define HAL_RTC_ERROR_INVALID_PARAM     ((uint32)0x00000001U)  /*!< Invalid parameter
                                                                    or capability
                                                                    (run time
                                                                    validation)      */
#define HAL_RTC_ERROR_TIMEOUT           ((uint32)0x00000002U)  /*!< Flag wait timeout
                                                                    (reserved, not
                                                                    produced: this
                                                                    driver has no
                                                                    blocking wait)   */
/**
  * @}
  */

/** @defgroup RTC_Input_parameter_format_definitions RTC Input Parameter Format Definitions
  * @{
  */
#define RTC_FORMAT_BIN                  0x00000000U  /*!< Binary data format */
#define RTC_FORMAT_BCD                  0x00000001U  /*!< BCD data format    */
/**
  * @}
  */

/** @defgroup RTC_Month_Date_Definitions RTC Month Date Definitions
  * @note  Values are the plain decimal month numbers (1-12): the driver
  *        converts them to BCD before writing the RTC_DR register in
  *        RTC_FORMAT_BIN mode. BCD-coded month values are not accepted.
  * @{
  */
#define RTC_Month_January               ((uint8)0x01)
#define RTC_Month_February              ((uint8)0x02)
#define RTC_Month_March                 ((uint8)0x03)
#define RTC_Month_April                 ((uint8)0x04)
#define RTC_Month_May                   ((uint8)0x05)
#define RTC_Month_June                  ((uint8)0x06)
#define RTC_Month_July                  ((uint8)0x07)
#define RTC_Month_August                ((uint8)0x08)
#define RTC_Month_September             ((uint8)0x09)
#define RTC_Month_October               ((uint8)0x0A)
#define RTC_Month_November              ((uint8)0x0B)
#define RTC_Month_December              ((uint8)0x0C)
/**
  * @}
  */

/** @defgroup RTC_WeekDay_Definitions RTC WeekDay Definitions
  * @note  Values are the chip RTC_TR.WDU encodings (Monday = 0x02, Sunday =
  *        0x01). The weekday is written into the RTC_TR register (not BCD
  *        encoded).
  * @{
  */
#define RTC_Weekday_Monday              ((uint8)0x02)
#define RTC_Weekday_Tuesday             ((uint8)0x03)
#define RTC_Weekday_Wednesday           ((uint8)0x04)
#define RTC_Weekday_Thursday            ((uint8)0x05)
#define RTC_Weekday_Friday              ((uint8)0x06)
#define RTC_Weekday_Saturday            ((uint8)0x07)
#define RTC_Weekday_Sunday              ((uint8)0x01)
/**
  * @}
  */

/** @defgroup RTC_Alarm_Definitions RTC Alarm Definitions
  * @note  Values are the RTC_ALRMTR / RTC_ALRMDR comparison enable bits
  *        (a bit set to 1 means the field is compared). The legacy
  *        RTC_AlarmTime_Minutes constant (0x20008000) has been fixed to
  *        0x20000000: the stray 0x8000 bit would be written into the
  *        ALRMTR.MNT field and fails the IS_RTC_ALARMTIME() check.
  * @{
  */
#define RTC_Alarm_None                  ((uint32)0x00000000)
#define RTC_AlarmTime_WeekDay           RTC_ALRMTR_WDCE
#define RTC_AlarmTime_Hours             RTC_ALRMTR_HCE
#define RTC_AlarmTime_Minutes           RTC_ALRMTR_MCE
#define RTC_AlarmTime_Seconds           RTC_ALRMTR_SCE
#define RTC_AlarmTime_TenOfSecond       RTC_ALRMTR_TOSCE
#define RTC_AlarmDate_Century           RTC_ALRMDR_CCE
#define RTC_AlarmDate_Year              RTC_ALRMDR_YCE
#define RTC_AlarmDate_Month             RTC_ALRMDR_MCE
#define RTC_AlarmDate_Date              RTC_ALRMDR_DCE
/**
  * @}
  */

/** @defgroup RTC_Interrupts_Definitions RTC Interrupts Definitions
  * @{
  */
#define RTC_IT_ALARM                    RTC_CR_IE    /*!< RTC alarm interrupt enable (CR.IE) */
/**
  * @}
  */

/** @defgroup RTC_Flags_Definitions RTC Flags Definitions
  * @{
  */
#define RTC_FLAG_ALARM                  RTC_CR_ALRMT /*!< RTC alarm trigger flag (CR.ALRMT) */
/**
  * @}
  */

/**
  * @}
  */

/* Exported macro ------------------------------------------------------------*/
/** @defgroup RTC_Exported_Macros RTC Exported Macros
  * @{
  */

/** @brief Reset RTC handle state
  * @param  __HANDLE__: specifies the RTC handle.
  * @retval None
  */
#define __HAL_RTC_RESET_HANDLE_STATE(__HANDLE__) ((__HANDLE__)->State = HAL_RTC_STATE_RESET)

/**
  * @brief  Enable the RTC peripheral.
  * @param  __HANDLE__: specifies the RTC handle.
  * @retval None
  */
#define __HAL_RTC_ENABLE(__HANDLE__)                ((__HANDLE__)->Instance->CR |= RTC_CR_EN)

/**
  * @brief  Disable the RTC peripheral.
  * @param  __HANDLE__: specifies the RTC handle.
  * @retval None
  */
#define __HAL_RTC_DISABLE(__HANDLE__)               ((__HANDLE__)->Instance->CR &= ~RTC_CR_EN)

/**
  * @brief  Enable the RTC interrupt.
  * @param  __HANDLE__: specifies the RTC handle.
  * @param  __INTERRUPT__: specifies the RTC interrupt source to be enabled.
  *         This parameter can be:
  *            @arg RTC_IT_ALARM
  * @retval None
  */
#define __HAL_RTC_ENABLE_IT(__HANDLE__, __INTERRUPT__)      ((__HANDLE__)->Instance->CR |= (__INTERRUPT__))

/**
  * @brief  Disable the RTC interrupt.
  * @param  __HANDLE__: specifies the RTC handle.
  * @param  __INTERRUPT__: specifies the RTC interrupt source to be disabled.
  *         This parameter can be:
  *            @arg RTC_IT_ALARM
  * @retval None
  */
#define __HAL_RTC_DISABLE_IT(__HANDLE__, __INTERRUPT__)     ((__HANDLE__)->Instance->CR &= ~(__INTERRUPT__))

/**
  * @brief  Check whether the specified RTC interrupt has been enabled or not.
  * @param  __HANDLE__: specifies the RTC handle.
  * @param  __INTERRUPT__: specifies the RTC interrupt source to check.
  *         This parameter can be:
  *            @arg RTC_IT_ALARM
  * @retval The new state of __INTERRUPT__ (SET or RESET).
  */
#define __HAL_RTC_GET_IT_SOURCE(__HANDLE__, __INTERRUPT__)  (((((__HANDLE__)->Instance->CR) & (__INTERRUPT__)) != RESET) ? SET : RESET)

/**
  * @brief  Get the selected RTC flag status.
  * @param  __HANDLE__: specifies the RTC handle.
  * @param  __FLAG__: specifies the RTC flag to check.
  *         This parameter can be:
  *            @arg RTC_FLAG_ALARM
  * @retval The new state of __FLAG__ (SET or RESET).
  */
#define __HAL_RTC_GET_FLAG(__HANDLE__, __FLAG__)            (((((__HANDLE__)->Instance->CR) & (__FLAG__)) != RESET) ? SET : RESET)

/**
  * @brief  Clear the RTC pending flags.
  * @note   The chip RTC flags are plain read/write bits of the CR register:
  *         they are cleared by writing 0 (a write-1-to-clear flag mechanism
  *         is not provided by this chip).
  * @param  __HANDLE__: specifies the RTC handle.
  * @param  __FLAG__: specifies the RTC flag to clear.
  *         This parameter can be:
  *            @arg RTC_FLAG_ALARM
  * @retval None
  */
#define __HAL_RTC_CLEAR_FLAG(__HANDLE__, __FLAG__)          ((__HANDLE__)->Instance->CR &= ~(__FLAG__))
/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/
/** @addtogroup RTC_Exported_Functions
  * @{
  */

/** @addtogroup RTC_Exported_Functions_Group1
  * @{
  */
/* Initialization and de-initialization functions  ****************************/

/**
 * @brief  Initialize the RTC peripheral (clock divider coefficient).
 * @note   The RTC is not enabled by this function: call HAL_RTC_Cmd() with
 *         ENABLE to start the calendar (the behavior of the device is kept).
 * @note   Run time validation before the lock, the MSP callback and any
 *         register access: the configuration structure metafields
 *         (IS_RTC_INIT_STRUCT_OK: Size, Version and both reserved words) and the
 *         divider width are checked, and a rejected structure is reported with
 *         HAL_ERROR and HAL_RTC_ERROR_INVALID_PARAM while the handle and the
 *         peripheral stay untouched. assert_param() keeps reporting the same
 *         conditions in a full assertion build.
 * @note   The low level initialization callback runs only on the first call
 *         (while the handle is in the reset state) and before the handle is
 *         locked (architecture rules MSP-04 and LOCK-06), so an override may
 *         create an RTOS mutex and call other HAL APIs.
 * @param  hrtc: pointer to a RTC_HandleTypeDef structure that contains the
 *         configuration information for RTC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY.
 */
HAL_StatusTypeDef HAL_RTC_Init(RTC_HandleTypeDef *hrtc);

/**
 * @brief  De-initialize the RTC peripheral.
 * @note   This function resets all RTC registers (TR / DR / ALRMTR /
 *         ALRMDR / CR / WUCR), including the divider coefficient: the
 *         HAL_RTC_Init() must be called again before reusing the RTC.
 * @note   The low level de-initialization callback runs after the handle lock
 *         has been released (architecture rule LOCK-06), so an override may
 *         call other HAL APIs.
 * @param  hrtc: pointer to a RTC_HandleTypeDef structure that contains the
 *         configuration information for RTC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY.
 */
HAL_StatusTypeDef HAL_RTC_DeInit(RTC_HandleTypeDef *hrtc);

/**
 * @brief  Initialize the RTC MSP.
 * @note   This function should not be modified: when the MSP initialization
 *         is needed, HAL_RTC_MspInit() should be implemented in the user file
 *         (e.g. enable the RTC_IRQn PLIC line for interrupt mode). The RTC
 *         has no SMU clock gate, so no clock enable is required.
 * @param  hrtc: pointer to a RTC_HandleTypeDef structure that contains the
 *         configuration information for RTC.
 * @retval None
 */
void HAL_RTC_MspInit(RTC_HandleTypeDef *hrtc);

/**
 * @brief  De-initialize the RTC MSP.
 * @note   This function should not be modified: when the MSP de-initialization
 *         is needed, HAL_RTC_MspDeInit() should be implemented in the user file
 *         (e.g. disable the RTC_IRQn PLIC line).
 * @param  hrtc: pointer to a RTC_HandleTypeDef structure that contains the
 *         configuration information for RTC.
 * @retval None
 */
void HAL_RTC_MspDeInit(RTC_HandleTypeDef *hrtc);
/**
  * @}
  */

/** @addtogroup RTC_Exported_Functions_Group2
  * @{
  */
/* RTC Time and Date functions ************************************************/

/**
 * @brief  Set the RTC current time.
 * @note   The chip RTC is 24-hour only: the RTC_Hours field must stay in the
 *         0-23 range whatever the Format.
 * @note   Protected by the handle lock and gated by the handle state
 *         (ARCH-CONST-09): the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR while the handle has not
 *         been initialized; the error code is cleared on entry.
 * @note   Run time validation before the lock: the format, the tenth of a
 *         second field and the hour / minute / second fields are checked
 *         (in RTC_FORMAT_BCD every decimal digit is checked to be 0..9 before
 *         the value is converted), and a rejected value is reported with
 *         HAL_ERROR and HAL_RTC_ERROR_INVALID_PARAM without touching the
 *         register or the state.
 * @param  hrtc:   pointer to a RTC_HandleTypeDef structure that contains the
 *         configuration information for RTC.
 * @param  sTime:  pointer to a RTC_TimeTypeDef structure that contains the
 *         time configuration information for the RTC.
 * @param  Format: specifies the format of the entered parameters
 *         (RTC_FORMAT_BIN / RTC_FORMAT_BCD).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_RTC_SetTime(RTC_HandleTypeDef *hrtc, RTC_TimeTypeDef *sTime, uint32 Format);

/**
 * @brief  Get the RTC current time.
 * @note   Read access that returns one register snapshot converted to the
 *         requested representation. It runs the shared handle check, the state
 *         gate and the handle lock, so a read cannot interleave with the
 *         read-modify-write of HAL_RTC_SetTime() / HAL_RTC_SetDate(); the
 *         call is therefore NOT callable from an interrupt service routine
 *         (LOCK-04 / RTOS-12: an interrupt must not take the task lock).
 * @param  hrtc:   pointer to a RTC_HandleTypeDef structure that contains the
 *         configuration information for RTC.
 * @param  sTime:  pointer to a RTC_TimeTypeDef structure that will contain
 *         the returned current time configuration.
 * @param  Format: specifies the format of the returned parameters
 *         (RTC_FORMAT_BIN / RTC_FORMAT_BCD).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_RTC_GetTime(RTC_HandleTypeDef *hrtc, RTC_TimeTypeDef *sTime, uint32 Format);

/**
 * @brief  Set the RTC current date.
 * @note   The weekday is written into the RTC_TR.WDU field (not BCD encoded).
 * @note   Protected by the handle lock and gated by the handle state
 *         (ARCH-CONST-09): the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR while the handle has not
 *         been initialized; the error code is cleared on entry.
 * @note   Run time validation before the lock: the format, the weekday and the
 *         century / year / month / day fields are checked (in RTC_FORMAT_BCD
 *         every decimal digit is checked to be 0..9 before the value is
 *         converted), and a rejected value is reported with HAL_ERROR and
 *         HAL_RTC_ERROR_INVALID_PARAM without touching the register or the
 *         state.
 * @param  hrtc:   pointer to a RTC_HandleTypeDef structure that contains the
 *         configuration information for RTC.
 * @param  sDate:  pointer to a RTC_DateTypeDef structure that contains the
 *         date configuration information for the RTC.
 * @param  Format: specifies the format of the entered parameters
 *         (RTC_FORMAT_BIN / RTC_FORMAT_BCD).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_RTC_SetDate(RTC_HandleTypeDef *hrtc, RTC_DateTypeDef *sDate, uint32 Format);

/**
 * @brief  Get the RTC current date.
 * @note   Read access that returns one register snapshot converted to the
 *         requested representation (see HAL_RTC_GetTime()): it runs the shared
 *         handle check, the state gate and the handle lock, so it is NOT
 *         callable from an interrupt service routine. The weekday and the date
 *         live in different registers, so the two reads are not one atomic
 *         snapshot of the calendar.
 * @param  hrtc:   pointer to a RTC_HandleTypeDef structure that contains the
 *         configuration information for RTC.
 * @param  sDate:  pointer to a RTC_DateTypeDef structure that will contain
 *         the returned current date configuration.
 * @param  Format: specifies the format of the returned parameters
 *         (RTC_FORMAT_BIN / RTC_FORMAT_BCD).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_RTC_GetDate(RTC_HandleTypeDef *hrtc, RTC_DateTypeDef *sDate, uint32 Format);

/**
 * @brief  Fill each RTC_TimeTypeDef member with its default value
 *         (Time = 00h:00min:00sec:00ms).
 * @param  sTime: pointer to a RTC_TimeTypeDef structure which will be
 *         initialized.
 * @retval None
 */
void HAL_RTC_TimeStructInit(RTC_TimeTypeDef *sTime);

/**
 * @brief  Fill each RTC_DateTypeDef member with its default value
 *         (Monday, January 01 0000).
 * @param  sDate: pointer to a RTC_DateTypeDef structure which will be
 *         initialized.
 * @retval None
 */
void HAL_RTC_DateStructInit(RTC_DateTypeDef *sDate);
/**
  * @}
  */

/** @addtogroup RTC_Exported_Functions_Group3
  * @{
  */
/* RTC Alarm functions ********************************************************/

/**
 * @brief  Set the RTC alarm.
 * @note   The chip has a single alarm: the comparison enable fields
 *         (RTC_AlarmTimeCompEn / RTC_AlarmDataCompEn) select which time /
 *         date fields are compared (a bit set to 1 means compared).
 * @note   This call configures the match condition without enabling the
 *         interrupt and without consuming the historical alarm flag. The
 *         interrupt is masked for the whole reconfiguration and the comparison
 *         enables are cleared while the match fields are written (see
 *         HAL_RTC_SetAlarm_IT() for the device clearing order).
 * @note   Run time validation: an out-of-range field, an illegal BCD digit, an
 *         out-of-range comparison enable mask or an invalid format is rejected
 *         with HAL_ERROR and HAL_RTC_ERROR_INVALID_PARAM before the lock is
 *         taken; nothing is written in that case.
 * @param  hrtc:   pointer to a RTC_HandleTypeDef structure that contains the
 *         configuration information for RTC.
 * @param  sAlarm: pointer to a RTC_AlarmTypeDef structure that contains the
 *         alarm configuration parameters.
 * @param  Format: specifies the format of the entered parameters
 *         (RTC_FORMAT_BIN / RTC_FORMAT_BCD).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_RTC_SetAlarm(RTC_HandleTypeDef *hrtc, RTC_AlarmTypeDef *sAlarm,
                                   uint32 Format);

/**
 * @brief  Set the RTC alarm with interrupt enabled.
 * @note   The alarm interrupt (CR.IE) is enabled and the alarm flag
 *         (CR.ALRMT) is cleared by this function. The interrupt must be
 *         routed to the CPU through the PLIC (see HAL_RTC_MspInit()).
 * @note   Clearing order (device prerequisite): CR.ALRMT is a flag that the
 *         hardware sets when the enabled comparison fields match and that the
 *         software clears by writing 0. While a comparison enable is still set
 *         the still true match condition re-asserts the flag, so the flag is
 *         cleared only after the comparison enables have been cleared; the
 *         interrupt is masked for the whole reconfiguration and the previous
 *         interrupt enable is restored afterwards. The historical flag is
 *         therefore consumed by this call.
 * @note   Run time validation: an out-of-range field, an illegal BCD digit, an
 *         out-of-range comparison enable mask or an invalid format is rejected
 *         with HAL_ERROR and HAL_RTC_ERROR_INVALID_PARAM before the lock is
 *         taken; nothing is written in that case.
 * @param  hrtc:   pointer to a RTC_HandleTypeDef structure that contains the
 *         configuration information for RTC.
 * @param  sAlarm: pointer to a RTC_AlarmTypeDef structure that contains the
 *         alarm configuration parameters.
 * @param  Format: specifies the format of the entered parameters
 *         (RTC_FORMAT_BIN / RTC_FORMAT_BCD).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_RTC_SetAlarm_IT(RTC_HandleTypeDef *hrtc, RTC_AlarmTypeDef *sAlarm,
                                      uint32 Format);

/**
 * @brief  Get the RTC alarm value and comparison enables.
 * @note   Read access that runs the shared handle check, the state gate and the
 *         handle lock (see HAL_RTC_GetTime()), so it is NOT callable from an
 *         interrupt service routine. Two registers are read, so the result is
 *         not one atomic snapshot of the alarm configuration.
 * @param  hrtc:   pointer to a RTC_HandleTypeDef structure that contains the
 *         configuration information for RTC.
 * @param  sAlarm: pointer to a RTC_AlarmTypeDef structure that will contain
 *         the returned alarm configuration values.
 * @param  Format: specifies the format of the returned parameters
 *         (RTC_FORMAT_BIN / RTC_FORMAT_BCD).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_RTC_GetAlarm(RTC_HandleTypeDef *hrtc, RTC_AlarmTypeDef *sAlarm,
                                   uint32 Format);

/**
 * @brief  Handle the RTC alarm interrupt request.
 * @note   This function must be called from the RTC_IRQ_Handler() PLIC
 *         callback when the alarm interrupt is used.
 * @note   LOCK-FREE and GATE-FREE by design (LOCK-04 / RTOS-12: an interrupt
 *         service routine must not take the task lock). The shared register
 *         sequence runs inside a short critical section that is closed before
 *         the user callback, so the callback may call any non-blocking code.
 * @note   Clearing order (device prerequisite): the comparison enables are
 *         cleared first, then CR.ALRMT is written 0, then the comparison
 *         enables are restored - otherwise the still true match condition
 *         re-asserts the flag and the interrupt becomes a storm.
 * @note   This function never writes the task side State or ErrorCode: a busy
 *         or uninitialized handle is not turned into READY by an interrupt.
 * @param  hrtc: pointer to a RTC_HandleTypeDef structure that contains the
 *         configuration information for RTC.
 * @retval None
 */
void HAL_RTC_AlarmIRQHandler(RTC_HandleTypeDef *hrtc);

/**
 * @brief  Alarm event callback.
 * @note   This function should not be modified: when the callback is needed,
 *         the HAL_RTC_AlarmEventCallback could be implemented in the user file.
 * @param  hrtc: pointer to a RTC_HandleTypeDef structure that contains the
 *         configuration information for RTC.
 * @retval None
 */
void HAL_RTC_AlarmEventCallback(RTC_HandleTypeDef *hrtc);

/**
 * @brief  Fill each RTC_AlarmTypeDef member with its default value
 *         (Time = 00h:00mn:00sec:00ms / Date = Monday, January 01 0000 /
 *         Comparison = all fields are not compared).
 * @param  sAlarm: pointer to a RTC_AlarmTypeDef structure which will be
 *         initialized.
 * @retval None
 */
void HAL_RTC_AlarmStructInit(RTC_AlarmTypeDef *sAlarm);
/**
  * @}
  */

/** @addtogroup RTC_Exported_Functions_Group4
  * @{
  */
/* Peripheral Control functions ***********************************************/

/**
 * @brief  Enable or disable the RTC peripheral.
 * @note   Only the calendar enable bit of the module owned fields is changed.
 *         The control register is assembled and written once, and the alarm
 *         flag is written with its neutral value (writing 1 leaves a flag set
 *         by the hardware unchanged, writing 0 would clear it), so a flag that
 *         the hardware asserts around the update cannot be lost.
 * @note   Serialized by the handle lock and gated by the handle state
 *         (ARCH-CONST-09); the shared RTC_HandleIsValid() check runs first.
 * @param  hrtc:     pointer to a RTC_HandleTypeDef structure that contains the
 *         configuration information for RTC.
 * @param  NewState: new state of the RTC peripheral (ENABLE or DISABLE).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY.
 */
HAL_StatusTypeDef HAL_RTC_Cmd(RTC_HandleTypeDef *hrtc, FunctionalState NewState);
/**
  * @}
  */

/** @addtogroup RTC_Exported_Functions_Group5
  * @{
  */
/* Peripheral State functions *************************************************/

/**
 * @brief  Return the RTC state.
 * @note   Reads a handle field only: no register access, no lock and no state
 *         gate, so it stays callable from an interrupt service routine. The
 *         shared RTC_HandleIsValid() check is still applied, and an invalid
 *         handle reports HAL_RTC_STATE_RESET.
 * @param  hrtc: pointer to a RTC_HandleTypeDef structure that contains the
 *         configuration information for RTC.
 * @retval HAL_RTCStateTypeDef: HAL_RTC_STATE_RESET / READY / BUSY / TIMEOUT
 *         / ERROR.
 */
HAL_RTCStateTypeDef HAL_RTC_GetState(RTC_HandleTypeDef *hrtc);

/**
 * @brief  Returns the RTC error code.
 * @note   Reads a handle field only: no register access, no lock and no state
 *         gate, so it stays callable from an interrupt service routine. The
 *         shared RTC_HandleIsValid() check is still applied, and an invalid
 *         handle reports HAL_RTC_ERROR_NONE.
 * @param  hrtc: pointer to a RTC_HandleTypeDef structure.
 * @retval uint32: the RTC error code (HAL_RTC_ERROR_xxx).
 */
uint32 HAL_RTC_GetError(RTC_HandleTypeDef *hrtc);
/**
  * @}
  */

/**
  * @}
  */

/* Exported types ------------------------------------------------------------*/

/* Exported constants --------------------------------------------------------*/

/** @addtogroup RTC_Exported_Constants RTC Exported Constants
  * @{
  */

/** @defgroup RTC_Wakeup_Timer_Definitions RTC Wake-up Timer Definitions
  * @note  The chip wake-up timer has no counter register: only the wake-up
  *        enable bit (RTC_WUCR.WUTE) is available. A programmable wake-up
  *        counter and clock selection are therefore not provided.
  * @{
  */
#define RTC_WAKEUP_ENABLE               RTC_WUCR_WUTE /*!< Wake-up timer enable bit value */
/**
  * @}
  */

/**
  * @}
  */

/* Exported macro ------------------------------------------------------------*/
/** @addtogroup RTC_Exported_Macros RTC Exported Macros
  * @{
  */

/**
  * @brief  Enable the RTC wake-up timer.
  * @param  __HANDLE__: specifies the RTC handle.
  * @retval None
  */
#define __HAL_RTC_WAKEUPTIMER_ENABLE(__HANDLE__)            ((__HANDLE__)->Instance->WUCR |= RTC_WUCR_WUTE)

/**
  * @brief  Disable the RTC wake-up timer.
  * @param  __HANDLE__: specifies the RTC handle.
  * @retval None
  */
#define __HAL_RTC_WAKEUPTIMER_DISABLE(__HANDLE__)           ((__HANDLE__)->Instance->WUCR &= ~RTC_WUCR_WUTE)
/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/
/** @addtogroup RTC_Exported_Functions
  * @{
  */

/** @addtogroup RTC_Exported_Functions_Group1
  * @{
  */
/* RTC Wake-up timer functions **********************************************/

/**
 * @brief  Enable or disable the RTC wake-up timer.
 * @note   The chip wake-up timer has no counter register: only the wake-up
 *         enable bit (RTC_WUCR.WUTE) is available. The wake-up period is
 *         defined by the hardware (the RTC divider coefficient), it cannot
 *         be programmed by software.
 * @note   The register access is protected by the handle lock (the shared
 *         RTC_LockHandle / RTC_UnlockHandle helpers exported by the main
 *         header) and gated by the handle state (RTC_CheckState, architecture
 *         rule ARCH-CONST-09) after the shared RTC_HandleIsValid() check: a
 *         handle that is busy with another operation or that has not been
 *         initialized is left untouched. The void signature
 *         is kept, so a rejected call simply does not touch the peripheral;
 *         the outcome can be checked with HAL_RTC_GetState() /
 *         HAL_RTC_GetError() of the core driver.
 * @param  hrtc:     pointer to a RTC_HandleTypeDef structure that contains
 *         the configuration information for RTC.
 * @param  NewState: new state of the RTC wake-up timer (ENABLE or DISABLE).
 * @retval None
 */
void HAL_RTC_WakeUpCmd(RTC_HandleTypeDef *hrtc, FunctionalState NewState);
/**
  * @}
  */

/**
  * @}
  */

/* Private types -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private constants ---------------------------------------------------------*/
/** @defgroup RTC_Private_Constants RTC Private Constants
  * @{
  */
/* Register field masks of this device, defined here because the device level
    header carries the bit fields only. */
#define RTC_TR_RESERVED_MASK            ((uint32)0x00FFFFFF)
#define RTC_DR_RESERVED_MASK            ((uint32)0x07FFFFFF)
#define RTC_ALRMTR_RESERVED_MASK        ((uint32)0xF8000000)
#define RTC_ALRMDR_RESERVED_MASK        ((uint32)0x78000000)
/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/
/** @defgroup RTC_Private_Macros RTC Private Macros
  * @{
  */

/** @defgroup RTC_IS_RTC_Definitions RTC Private macros to check input parameters
  * @{
  */
#define IS_RTC_ALL_INSTANCE(INSTANCE)     ((INSTANCE) == RTC)

#define IS_RTC_DIVISION(DIVISION)         ((DIVISION) <= 0x7FFFFFF)

#define IS_RTC_FORMAT(FORMAT)             (((FORMAT) == RTC_FORMAT_BIN) || \
                                           ((FORMAT) == RTC_FORMAT_BCD))

#define IS_RTC_HOURS(HOURS)               ((HOURS) <= 23)

#define IS_RTC_MINUTES(MINUTES)           ((MINUTES) <= 59)

#define IS_RTC_SECONDS(SECONDS)           ((SECONDS) <= 59)

#define IS_RTC_TENOFSECOND(TENOFSECOND)   ((TENOFSECOND) <= 9)

#define IS_RTC_CENTURY(CENTURY)           ((CENTURY) <= 99)

#define IS_RTC_YEAR(YEAR)                 ((YEAR) <= 99)

#define IS_RTC_MONTH(MONTH)               (((MONTH) >= 1) && ((MONTH) <= 12))

#define IS_RTC_DATE(DATE)                 (((DATE) >= 1) && ((DATE) <= 31))

#define IS_RTC_WEEKDAY(WEEKDAY)           (((WEEKDAY) == RTC_Weekday_Monday)    || \
                                           ((WEEKDAY) == RTC_Weekday_Tuesday)   || \
                                           ((WEEKDAY) == RTC_Weekday_Wednesday) || \
                                           ((WEEKDAY) == RTC_Weekday_Thursday)  || \
                                           ((WEEKDAY) == RTC_Weekday_Friday)    || \
                                           ((WEEKDAY) == RTC_Weekday_Saturday)  || \
                                           ((WEEKDAY) == RTC_Weekday_Sunday))

#define IS_RTC_ALARMTIME(ALARMTIME)       (((ALARMTIME) & 0x07FFFFFF) == (uint32)RESET)

#define IS_RTC_ALARMDATE(ALARMDATE)       (((ALARMDATE) & 0x87FFFFFF) == (uint32)RESET)

/* Metafield check of the configuration structure (architecture spec section 22):
   the size, the semantic version and both reserved words must hold the values
   written by the caller after clearing the structure. The check runs before the
   lock is taken, before the MSP callback and before any register access, so a
   rejected structure leaves the handle and the peripheral untouched. */
#define IS_RTC_INIT_STRUCT_OK(INIT)       (((INIT)->Size == (uint32)sizeof(RTC_InitTypeDef)) && \
                                           ((INIT)->Version == RTC_INIT_VERSION) &&           \
                                           ((INIT)->Reserved[0] == 0U) &&                     \
                                           ((INIT)->Reserved[1] == 0U))
/**
  * @}
  */

/**
  * @}
  */

/* Shared internal functions --------------------------------------------------*/

/** @defgroup RTC_Shared_Internal_Functions RTC Shared Internal Functions
  * @brief  The four processes that every interface touching a register runs in
  *         the same order: RTC_HandleIsValid() (null pointer and instance),
  *         RTC_CheckState() (the ARCH-CONST-09 state gate) and
  *         RTC_LockHandle() / RTC_UnlockHandle() (the resource lock). They are
  *         exported (not static) so that the application, a test bench and any
  *         other translation unit of this module reuse exactly the same
  *         validation, gate and lock semantics instead of re-implementing
  *         them; the same pattern is used by the other peripheral drivers of
  *         this library (for example ADC_HandleIsValid / ADC_CheckState /
  *         ADC_LockHandle / ADC_UnlockHandle).
  * @{
  */

/**
 * @brief  Check whether the handle and its peripheral instance are valid
 *         (shared by every entry point of this driver).
 * @note   A null pointer or an instance outside the model instance set is
 *         invalid. This is the first check of every interface, so the
 *         validation strength cannot differ between interfaces.
 * @param  hrtc: pointer to a RTC_HandleTypeDef structure.
 * @retval uint32: 1 if the handle and the instance are usable, 0 otherwise.
 */
uint32 RTC_HandleIsValid(RTC_HandleTypeDef *hrtc);

/**
 * @brief  Check the handle state before a register access (ARCH-CONST-09).
 * @note   Returns HAL_BUSY while the handle is busy with another operation and
 *         HAL_ERROR while it has not been initialized (HAL_RTC_Init() is
 *         required first). The timeout / error states are recoverable and are
 *         accepted, so no DeInit / Init round trip is required to retry.
 * @note   HAL_RTC_Init() and HAL_RTC_DeInit() are the two documented exceptions
 *         that skip this gate (the architecture specification exempts them, and
 *         DeInit must be able to undo a failed initialization).
 * @note   Not static: declared in the shared internal functions section of this
 *         header, so the application may reuse the same check.
 * @param  hrtc: pointer to a RTC_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef RTC_CheckState(RTC_HandleTypeDef *hrtc);

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_RTC_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the acquisition is bounded by the Timeout parameter (RTOS
 *         ticks, which with the usual 1 ms tick is the same quantity as the
 *         millisecond Timeout of the public API); HAL_MAX_DELAY waits forever.
 *         A mutex that was never created is reported as HAL_ERROR instead of
 *         being passed to the porting layer as a NULL handle.
 * @note   Never called from HAL_RTC_AlarmIRQHandler() or from any other
 *         interrupt context (LOCK-04 / RTOS-12: an interrupt service routine
 *         must not take the task lock).
 * @note   Not static: declared in the shared internal functions section of this
 *         header, so the application may reuse the same helper.
 * @param  hrtc: pointer to a RTC_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS, wait expired) /
 *         HAL_ERROR (RTOS, mutex not created) / HAL_BUSY (bare metal, the
 *         handle is already locked).
 */
HAL_StatusTypeDef RTC_LockHandle(RTC_HandleTypeDef *hrtc, uint32 Timeout);

/**
 * @brief  Unlock the handle.
 * @note   Every successful RTC_LockHandle() call has exactly one matching
 *         RTC_UnlockHandle() call on every return path of the interface.
 * @param  hrtc: pointer to a RTC_HandleTypeDef structure.
 * @retval None
 */
void RTC_UnlockHandle(RTC_HandleTypeDef *hrtc);

/**
  * @}
  */

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_RTC_H */

/*****END OF FILE*****/
