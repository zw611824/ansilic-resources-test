/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_trng.c
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.4
 * Date:   2026/10/09
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/10/09     1.4     restore the " *" prefix of the history
 *                                                       continuation lines
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.3     align the module with the library
 *                                                       architecture spec (resource lock and
 *                                                       RTOS chapters): give the lock helper
 *                                                       a Timeout parameter and a NULL mutex
 *                                                       guard, add the shared validity and
 *                                                       state helpers, run the MSP callbacks
 *                                                       outside the locked region, validate
 *                                                       the configuration metafields at run
 *                                                       time, apply the busy / reset state
 *                                                       gate to the transfer interfaces,
 *                                                       report the guard path of every locked
 *                                                       entry point and yield the CPU while
 *                                                       polling
 *     ANSILIC APPLICATION GROUP  2026/09/03     1.2     second compliance review:
 *                                                       source file header synced
 *                                                       with the header file V1.2
 *                                                       (handle struct tag, header
 *                                                       declarations, constants and
 *                                                       line-width cleanups); no
 *                                                       functional change
 *     ANSILIC APPLICATION GROUP  2026/09/02     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/03     1.1     align with the library
 *                                                       conventions: include the
 *                                                       device layer through
 *                                                       as32x601_hal.h and guard
 *                                                       the whole implementation
 *                                                       with HAL_TRNG_MODULE_ENABLED;
 *                                                       guard every public
 *                                                       function against a NULL
 *                                                       handle (NULL_PTR);
 *                                                       reset the ErrorCode at
 *                                                       the operation start and
 *                                                       record the timeout /
 *                                                       alarmed error sources;
 *                                                       reorder
 *                                                       GenerateRandomNumber_IT
 *                                                       (enable the DONE
 *                                                       interrupt before
 *                                                       unlocking) and
 *                                                       IRQHandler (clear the
 *                                                       event flag before the
 *                                                       callback); add
 *                                                       HAL_TRNG_StructInit()
 *                                                       and HAL_TRNG_GetError()
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the True Random Number
 *                  Generator (TRNG) peripheral.
 */

/* Includes ------------------------------------------------------------------*/
#include "as32x601_hal.h"           /* HAL_GetTick() / HAL_MAX_DELAY        */
#include "as32x601_hal_trng.h"      /* TRNG HAL API and register macros      */

/* The HAL_TRNG_MODULE_ENABLED switch is provided by the user configuration
 * file (as32x601_hal_conf.h, included above through as32x601_hal.h): the
 * whole implementation is compiled only while the module is enabled. */
#ifdef HAL_TRNG_MODULE_ENABLED

/* Private defines -----------------------------------------------------------*/
/** @addtogroup TRNG_Private_Defines
  * @{
  */
#define TRNG_TIMEOUT_VALUE      1000U     /*!< Timeout value (in ms) for the    */
                                          /*   DONE flag polling loop. The DRBG */
                                          /*   state machine may take some time */
                                          /*   to complete a command.          */
/**
  * @}
  */

/* Shared internal functions --------------------------------------------------*/
/** @defgroup TRNG_Shared_Internal_Functions TRNG Shared Internal Functions
  * @brief    Helpers shared by the TRNG driver (Tier 3). They are not part of
  *           the public API and shall not be called by the application.
  * @{
  */

/**
 * @brief  Check whether the TRNG handle and its instance are valid.
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
uint32 TRNG_HandleIsValid(TRNG_HandleTypeDef *htrng)
{
    if (htrng == NULL_PTR)
    {
        return 0U;
    }

    if (IS_TRNG_ALL_INSTANCE(htrng->Instance) == 0U)
    {
        return 0U;
    }

    return 1U;
}

/**
 * @brief  Check whether the handle accepts a new operation.
 * @note   ARCH-CONST-09: a handle that is BUSY (an operation is ongoing in
 *         another context) rejects any other operation with HAL_BUSY, an
 *         uninitialized handle (RESET) requires HAL_TRNG_Init() first and is
 *         rejected with HAL_ERROR, while the recoverable states (TIMEOUT and
 *         ERROR) accept a new operation directly.
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK (accepted) / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef TRNG_CheckState(TRNG_HandleTypeDef *htrng)
{
    if (htrng->State == HAL_TRNG_STATE_BUSY)
    {
        return HAL_BUSY;
    }

    if (htrng->State == HAL_TRNG_STATE_RESET)
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Lock the handle (RTOS mutex or single core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_TRNG_MspInit()). The bare metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; the value is passed to HAL_MutexAcquire() as
 *         is (RTOS ticks; HAL_MAX_DELAY means an infinite wait).
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef TRNG_LockHandle(TRNG_HandleTypeDef *htrng, uint32 Timeout)
{
#if (USE_RTOS == 1)
    if (htrng->LockMutex == NULL_PTR)
    {
        /* The porting layer did not create the mutex (e.g. HAL_TRNG_MspInit()
         * was not overridden): report it instead of calling the RTOS with an
         * invalid mutex handle */
        return HAL_ERROR;
    }

    return HAL_MutexAcquire(htrng->LockMutex, Timeout);
#else
    /* Prevent unused argument compilation warning: the bare metal lock flag
     * either succeeds immediately or reports HAL_BUSY, it never waits */
    UNUSED(Timeout);

    if (htrng->Lock == HAL_LOCKED)
    {
        return HAL_BUSY;
    }

    htrng->Lock = HAL_LOCKED;

    return HAL_OK;
#endif /* USE_RTOS */
}

/**
 * @brief  Unlock the handle.
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @retval None
 */
void TRNG_UnlockHandle(TRNG_HandleTypeDef *htrng)
{
#if (USE_RTOS == 1)
    (void)HAL_MutexRelease(htrng->LockMutex);
#else
    htrng->Lock = HAL_UNLOCKED;
#endif /* USE_RTOS */
}

/**
  * @}
  */


/** @addtogroup TRNG_Exported_Functions
  * @{
  */

/** @addtogroup TRNG_Exported_Functions_Group1
  *  @brief   Initialization and de-initialization functions.
  * @{
  */

/**
 * @brief  Fills each TRNG_InitStruct member with its default value. (NON-BLOCKING)
 * @param  TRNG_InitStruct: pointer to a TRNG_InitTypeDef structure which
 *         will be initialized.
 * @retval None
 */
void HAL_TRNG_StructInit(TRNG_InitTypeDef *TRNG_InitStruct)
{
    /* Check the parameter */
    if (TRNG_InitStruct == NULL_PTR)
    {
        return;
    }

    /* Reset the TRNG init structure parameters values */
    TRNG_InitStruct->Size        = sizeof(TRNG_InitTypeDef);  /*!< sizeof struct */
    TRNG_InitStruct->Version     = TRNG_INIT_VERSION;         /*!< V1            */
    TRNG_InitStruct->Reserved[0] = 0U;                        /*!< Reserved for future use */
    TRNG_InitStruct->Reserved[1] = 0U;                        /*!< Reserved for future use */
}

/**
 * @brief  Initializes the TRNG peripheral. (NON-BLOCKING)
 * @note   The TRNG is command-driven: unlike a conventional RNG there is
 *         no enable bit. HAL_TRNG_Init() clears the CTRL.CMD command
 *         field (equivalent to issuing the NOP command) so that the DRBG
 *         state machine starts from an idle state. The DRBG state machine
 *         must then be initialized by sending the
 *         ZEROIZE -> GEN_NOISE -> CREATE_STATE command sequence before any
 *         random number can be generated (see HAL_TRNG_SendCommand()).
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure that contains
 *                the configuration information for TRNG.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_TRNG_Init(TRNG_HandleTypeDef *htrng)
{
    /* Check the TRNG handle and instance */
    if (TRNG_HandleIsValid(htrng) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_TRNG_ALL_INSTANCE(htrng->Instance));

    /* Run time validation, so that the checks stay effective in a build with
     * the assertions disabled. The metafields of the configuration structure
     * (Size / Version, architecture spec section 22) and the two reserved words
     * are validated as well. A rejected call neither takes the lock nor changes
     * the handle state nor touches a register. */
    if ((IS_TRNG_ALL_INSTANCE(htrng->Instance) == 0U) ||
        (htrng->Init.Size != sizeof(TRNG_InitTypeDef)) ||
        (htrng->Init.Version != TRNG_INIT_VERSION) ||
        (htrng->Init.Reserved[0] != 0U) ||
        (htrng->Init.Reserved[1] != 0U))
    {
        htrng->ErrorCode |= HAL_TRNG_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Allocate the lock resource before its first use, so that a handle that
     * was never initialized cannot report HAL_BUSY from a stale Lock field.
     * LOCK-06 / MSP-04: the low level initialization runs before the handle is
     * locked, so that an override which calls other HAL APIs cannot deadlock.
     * In the RTOS configuration this is also what makes the very first call
     * work: HAL_TRNG_MspInit() is where the porting layer creates the mutex. */
    if (htrng->State == HAL_TRNG_STATE_RESET)
    {
        htrng->Lock = HAL_UNLOCKED;

        /* Init the low level hardware */
        HAL_TRNG_MspInit(htrng);
    }

    /* Process locked */
    if (TRNG_LockHandle(htrng, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Change TRNG peripheral state */
    htrng->State = HAL_TRNG_STATE_BUSY;

    /* Clear the command field of the CTRL register (NOP command) */
    CLEAR_BIT(htrng->Instance->CTRL, TRNG_CTRL_CMD);

    /* Reset the error code and initialize the TRNG state */
    htrng->ErrorCode = HAL_TRNG_ERROR_NONE;
    htrng->State = HAL_TRNG_STATE_READY;

    /* Process Unlocked */
    TRNG_UnlockHandle(htrng);

    /* Return function status */
    return HAL_OK;
}

/**
 * @brief  DeInitializes the TRNG peripheral. (NON-BLOCKING)
 * @note   The TRNG has no clock gating to disable: the de-initialization
 *         clears the interrupt enables and the interrupt status flags.
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure that contains
 *                the configuration information for TRNG.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_TRNG_DeInit(TRNG_HandleTypeDef *htrng)
{
    /* Check the TRNG handle and instance */
    if (TRNG_HandleIsValid(htrng) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_TRNG_ALL_INSTANCE(htrng->Instance));

    /* Process locked. ARCH-CONST-09: the de-initialization is callable from any
     * handle state, so that a failed initialization can always be undone */
    if (TRNG_LockHandle(htrng, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Disable the TRNG interrupts */
    __HAL_TRNG_DISABLE_IT(htrng, TRNG_IT_ZEROIZED  | TRNG_IT_KAT_COMPLETE |
                                 TRNG_IT_NOISE_RDY | TRNG_IT_ALARMED   |
                                 TRNG_IT_DONE      | TRNG_IT_GLBL);

    /* Clear the TRNG interrupt status flags */
    __HAL_TRNG_CLEAR_IT(htrng, TRNG_FLAG_ZEROIZED  | TRNG_FLAG_KAT_COMPLETE |
                                TRNG_FLAG_NOISE_RDY | TRNG_FLAG_ALARMED   |
                                TRNG_FLAG_DONE);

    /* Update the TRNG state and error code */
    htrng->State     = HAL_TRNG_STATE_RESET;
    htrng->ErrorCode = HAL_TRNG_ERROR_NONE;

    /* Process Unlocked */
    TRNG_UnlockHandle(htrng);

    /* LOCK-06 / ARCH-CONST-04: the low level de-initialization runs OUTSIDE the
     * locked region, as the architecture specification requires for the MSP
     * callbacks ("MspDeInit is called after the unlock") */
    HAL_TRNG_MspDeInit(htrng);

    /* Return the function status */
    return HAL_OK;
}

/**
 * @brief  Initializes the TRNG MSP. Weak empty function; the user implements
 *         the low level hardware initialization.
 * @note   The TRNG peripheral is clocked by the AXILite4-Bus1 domain
 *         without any SMU clock gating, so no clock enable is required.
 *         However the TRNG has a dedicated PLIC interrupt line
 *         (TRNG_IRQn = 0x0F): the user must enable it here and implement
 *         TRNG_IRQ_Handler() calling HAL_TRNG_IRQHandler().
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure that contains
 *                the configuration information for TRNG.
 * @retval None
 */
__weak void HAL_TRNG_MspInit(TRNG_HandleTypeDef *htrng)
{
    /* Prevent unused argument compilation warning */
    UNUSED(htrng);

    /* NOTE : This function should not be modified. When the callback is needed,
              function HAL_TRNG_MspInit must be implemented in the user file.
     */
}

/**
 * @brief  De-initializes the TRNG MSP. Weak empty function; the user
 *         implements the low level hardware de-initialization.
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure that contains
 *                the configuration information for TRNG.
 * @retval None
 */
__weak void HAL_TRNG_MspDeInit(TRNG_HandleTypeDef *htrng)
{
    /* Prevent unused argument compilation warning */
    UNUSED(htrng);

    /* NOTE : This function should not be modified. When the callback is needed,
              function HAL_TRNG_MspDeInit must be implemented in the user file.
     */
}

/**
  * @}
  */

/** @addtogroup TRNG_Exported_Functions_Group2
  *  @brief   Control functions.
  * @{
  */

/**
 * @brief  Sends a command to the command-driven DRBG state machine. (NON-BLOCKING)
 * @note   The TRNG runs as a command-driven DRBG: the CTRL.CMD 4-bit field
 *         selects the command. This function writes the command only; the
 *         completion is observed in the ISTAT register (DONE or ZEROIZED
 *         event bit). The DRBG state machine must be initialized with the
 *         ZEROIZE -> GEN_NOISE -> CREATE_STATE sequence before any random
 *         number can be generated.
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @param  Command: TRNG command to send. This parameter can be one of the
 *                  following values:
 *                    @arg TRNG_COMMAND_NOP
 *                    @arg TRNG_COMMAND_GEN_NOISE
 *                    @arg TRNG_COMMAND_GEN_NONCE
 *                    @arg TRNG_COMMAND_CREATE_STATE
 *                    @arg TRNG_COMMAND_RENEW_STATE
 *                    @arg TRNG_COMMAND_REFRESH_ADDIN
 *                    @arg TRNG_COMMAND_GEN_RANDOM
 *                    @arg TRNG_COMMAND_ADVANCE_STATE
 *                    @arg TRNG_COMMAND_RUN_KAT
 *                    @arg TRNG_COMMAND_ZEROIZE
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_TRNG_SendCommand(TRNG_HandleTypeDef *htrng, uint32 Command)
{
    /* Check the TRNG handle and instance */
    if (TRNG_HandleIsValid(htrng) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_TRNG_ALL_INSTANCE(htrng->Instance));
    assert_param(IS_TRNG_COMMAND(Command));

    /* Run time parameter validation, so that the checks stay effective in a
     * build with the assertions disabled. A rejected call neither takes the
     * lock nor changes the handle state nor touches a register. */
    if (IS_TRNG_COMMAND(Command) == 0U)
    {
        htrng->ErrorCode |= HAL_TRNG_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: state gate. A busy handle (an operation is ongoing in
     * another context) is rejected with HAL_BUSY, an uninitialized handle with
     * HAL_ERROR, while the recoverable states (timeout / error) are accepted. */
    if (TRNG_CheckState(htrng) != HAL_OK)
    {
        return TRNG_CheckState(htrng);
    }

    /* Process Locked */
    if (TRNG_LockHandle(htrng, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Set the command field of the CTRL register */
    CLEAR_BIT(htrng->Instance->CTRL, TRNG_CTRL_CMD);
    SET_BIT(htrng->Instance->CTRL, (uint32)(Command) << TRNG_CTRL_CMD_Pos);

    /* Process Unlocked */
    TRNG_UnlockHandle(htrng);

    /* Return function status */
    return HAL_OK;
}

/**
 * @brief  Generates a 32-bit random number in polling mode. (BLOCKING)
 * @note   The DRBG state machine must be initialized first. This function
 *         issues the GEN_RANDOM command, waits for the DONE event flag,
 *         clears it and reads the RAND0 register. Each read of the RAND0
 *         register is not automatically cleared; flag clearing is done
 *         explicitly.
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @param  random32bit: pointer to generated random number variable if
 *                      successful.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_TIMEOUT.
 */
HAL_StatusTypeDef HAL_TRNG_GenerateRandomNumber(TRNG_HandleTypeDef *htrng, uint32 *random32bit)
{
    uint32 tickstart = 0U;

    /* Check the TRNG handle and instance */
    if (TRNG_HandleIsValid(htrng) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_TRNG_ALL_INSTANCE(htrng->Instance));

    /* Run time parameter validation, so that the checks stay effective in a
     * build with the assertions disabled. A rejected call neither takes the
     * lock nor changes the handle state nor touches a register. */
    if (random32bit == NULL_PTR)
    {
        htrng->ErrorCode |= HAL_TRNG_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: state gate. A busy handle (an operation is ongoing in
     * another context) is rejected with HAL_BUSY, an uninitialized handle with
     * HAL_ERROR, while the recoverable states (timeout / error) are accepted. */
    if (TRNG_CheckState(htrng) != HAL_OK)
    {
        return TRNG_CheckState(htrng);
    }

    /* Process Locked */
    if (TRNG_LockHandle(htrng, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Change TRNG peripheral state and reset the error code */
    htrng->State     = HAL_TRNG_STATE_BUSY;
    htrng->ErrorCode = HAL_TRNG_ERROR_NONE;

    /* Issue the GEN_RANDOM command */
    CLEAR_BIT(htrng->Instance->CTRL, TRNG_CTRL_CMD);
    SET_BIT(htrng->Instance->CTRL, (uint32)(TRNG_COMMAND_GEN_RANDOM) << TRNG_CTRL_CMD_Pos);

    /* Get tick */
    tickstart = HAL_GetTick();

    /* Check if the DONE event flag is set */
    while (__HAL_TRNG_GET_FLAG(htrng, TRNG_FLAG_DONE) == RESET)
    {
        /* RTOS-04/05: yield the CPU so that a task polling the peripheral does
           not starve the other tasks (empty macro in a bare-metal build) */
        HAL_RTOS_Yield();

        if ((HAL_GetTick() - tickstart) > TRNG_TIMEOUT_VALUE)
        {
            /* Report the timeout through the handle state and the error code */
            htrng->ErrorCode |= HAL_TRNG_ERROR_TIMEOUT;
            htrng->State = HAL_TRNG_STATE_TIMEOUT;

            /* Process Unlocked */
            TRNG_UnlockHandle(htrng);

            return HAL_TIMEOUT;
        }
    }

    /* Clear the DONE event flag */
    __HAL_TRNG_CLEAR_FLAG(htrng, TRNG_FLAG_DONE);

    /* Get a 32-bit random number from the RAND0 register */
    htrng->RandomNumber = htrng->Instance->RAND0;
    *random32bit = htrng->RandomNumber;

    htrng->State = HAL_TRNG_STATE_READY;

    /* Process Unlocked */
    TRNG_UnlockHandle(htrng);

    return HAL_OK;
}

/**
 * @brief  Generates a 32-bit random number in interrupt mode. (NON-BLOCKING / IT)
 * @note   The DRBG state machine must be initialized first. This function
 *         issues the GEN_RANDOM command and enables the DONE interrupt;
 *         the random number is read in HAL_TRNG_IRQHandler() and returned
 *         through the HAL_TRNG_ReadyDataCallback().
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_TRNG_GenerateRandomNumber_IT(TRNG_HandleTypeDef *htrng)
{
    /* Check the TRNG handle and instance */
    if (TRNG_HandleIsValid(htrng) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_TRNG_ALL_INSTANCE(htrng->Instance));

    /* ARCH-CONST-09: state gate. A busy handle (an operation is ongoing in
     * another context) is rejected with HAL_BUSY, an uninitialized handle with
     * HAL_ERROR, while the recoverable states (timeout / error) are accepted. */
    if (TRNG_CheckState(htrng) != HAL_OK)
    {
        return TRNG_CheckState(htrng);
    }

    /* Process Locked */
    if (TRNG_LockHandle(htrng, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Change TRNG peripheral state and reset the error code */
    htrng->State     = HAL_TRNG_STATE_BUSY;
    htrng->ErrorCode = HAL_TRNG_ERROR_NONE;

    /* Issue the GEN_RANDOM command */
    CLEAR_BIT(htrng->Instance->CTRL, TRNG_CTRL_CMD);
    SET_BIT(htrng->Instance->CTRL, (uint32)(TRNG_COMMAND_GEN_RANDOM) << TRNG_CTRL_CMD_Pos);

    /* Enable the DONE interrupt before unlocking, so that the interrupt
     * cannot fire while the lock is still held by this context */
    __HAL_TRNG_ENABLE_IT(htrng, TRNG_IT_DONE);

    /* Process Unlocked */
    TRNG_UnlockHandle(htrng);

    return HAL_OK;
}

/**
 * @brief  Reads the RAND0 random number register. (NON-BLOCKING)
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @retval 32-bit random number.
 */
uint32 HAL_TRNG_GetRandomNumber0(TRNG_HandleTypeDef *htrng)
{
    /* Check the TRNG handle allocation */
    if (TRNG_HandleIsValid(htrng) == 0U)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_TRNG_ALL_INSTANCE(htrng->Instance));

    /* Return the RAND0 random number */
    return htrng->Instance->RAND0;
}

/**
 * @brief  Reads the RAND1 random number register. (NON-BLOCKING)
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @retval 32-bit random number.
 */
uint32 HAL_TRNG_GetRandomNumber1(TRNG_HandleTypeDef *htrng)
{
    /* Check the TRNG handle allocation */
    if (TRNG_HandleIsValid(htrng) == 0U)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_TRNG_ALL_INSTANCE(htrng->Instance));

    /* Return the RAND1 random number */
    return htrng->Instance->RAND1;
}

/**
 * @brief  Reads the RAND2 random number register. (NON-BLOCKING)
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @retval 32-bit random number.
 */
uint32 HAL_TRNG_GetRandomNumber2(TRNG_HandleTypeDef *htrng)
{
    /* Check the TRNG handle allocation */
    if (TRNG_HandleIsValid(htrng) == 0U)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_TRNG_ALL_INSTANCE(htrng->Instance));

    /* Return the RAND2 random number */
    return htrng->Instance->RAND2;
}

/**
 * @brief  Reads the RAND3 random number register. (NON-BLOCKING)
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @retval 32-bit random number.
 */
uint32 HAL_TRNG_GetRandomNumber3(TRNG_HandleTypeDef *htrng)
{
    /* Check the TRNG handle allocation */
    if (TRNG_HandleIsValid(htrng) == 0U)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_TRNG_ALL_INSTANCE(htrng->Instance));

    /* Return the RAND3 random number */
    return htrng->Instance->RAND3;
}

/**
 * @brief  Reads the last generated random number. (NON-BLOCKING)
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @retval random value.
 */
uint32 HAL_TRNG_ReadLastRandomNumber(TRNG_HandleTypeDef *htrng)
{
    /* Check the TRNG handle allocation */
    if (TRNG_HandleIsValid(htrng) == 0U)
    {
        return 0U;
    }

    /* Return the last generated random number */
    return htrng->RandomNumber;
}

/**
 * @brief  Enables or disables the selected TRNG interrupt. (NON-BLOCKING)
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @param  ITType: TRNG interrupt type. This parameter can be one of the
 *                 following values (TRNG_IT_*):
 *                    @arg TRNG_IT_ZEROIZED
 *                    @arg TRNG_IT_KAT_COMPLETE
 *                    @arg TRNG_IT_NOISE_RDY
 *                    @arg TRNG_IT_ALARMED
 *                    @arg TRNG_IT_DONE
 *                    @arg TRNG_IT_GLBL
 * @param  NewState: ENABLE or DISABLE.
 * @retval None
 */
void HAL_TRNG_ITConfig(TRNG_HandleTypeDef *htrng, uint32 ITType, FunctionalState NewState)
{
    /* Check the TRNG handle allocation */
    if (TRNG_HandleIsValid(htrng) == 0U)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_TRNG_ALL_INSTANCE(htrng->Instance));
    assert_param(IS_TRNG_IT(ITType));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Configure the TRNG interrupt */
    if (NewState != DISABLE)
    {
        __HAL_TRNG_ENABLE_IT(htrng, ITType);
    }
    else
    {
        __HAL_TRNG_DISABLE_IT(htrng, ITType);
    }
}

/**
 * @brief  Gets the TRNG interrupt status. (NON-BLOCKING)
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @param  IT: TRNG interrupt state. This parameter can be one of the
 *             following values (TRNG_FLAG_*):
 *               @arg TRNG_FLAG_ZEROIZED
 *               @arg TRNG_FLAG_KAT_COMPLETE
 *               @arg TRNG_FLAG_NOISE_RDY
 *               @arg TRNG_FLAG_ALARMED
 *               @arg TRNG_FLAG_DONE
 * @retval FlagStatus: SET or RESET.
 */
FlagStatus HAL_TRNG_GetITStatus(TRNG_HandleTypeDef *htrng, uint32 IT)
{
    /* Check the TRNG handle allocation */
    if (TRNG_HandleIsValid(htrng) == 0U)
    {
        return RESET;
    }

    /* Check the parameters */
    assert_param(IS_TRNG_ALL_INSTANCE(htrng->Instance));
    assert_param(IS_TRNG_FLAG(IT));

    /* Return the ISTAT status of the selected event */
    return (FlagStatus)(READ_BIT(htrng->Instance->ISTAT, IT));
}

/**
 * @brief  Clears the TRNG interrupt pending bit. (NON-BLOCKING)
 * @note   The ISTAT flags are cleared by writing a 1.
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @param  ClearIT: TRNG interrupt pending bit. This parameter can be one
 *                  of the following values (TRNG_FLAG_*):
 *                    @arg TRNG_FLAG_ZEROIZED
 *                    @arg TRNG_FLAG_KAT_COMPLETE
 *                    @arg TRNG_FLAG_NOISE_RDY
 *                    @arg TRNG_FLAG_ALARMED
 *                    @arg TRNG_FLAG_DONE
 * @retval None
 */
void HAL_TRNG_ClearITPendingBit(TRNG_HandleTypeDef *htrng, uint32 ClearIT)
{
    /* Check the TRNG handle allocation */
    if (TRNG_HandleIsValid(htrng) == 0U)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_TRNG_ALL_INSTANCE(htrng->Instance));
    assert_param(IS_TRNG_FLAG(ClearIT));

    /* Clear the ISTAT flag (write 1) */
    __HAL_TRNG_CLEAR_IT(htrng, ClearIT);
}

/**
 * @brief  Handles the TRNG interrupt request. (NON-BLOCKING / IT)
 * @note   The TRNG interrupt status register ISTAT carries five event bits.
 *         The DONE bit is the completion flag of the issued command: the
 *         HAL_TRNG_GenerateRandomNumber_IT() flow uses it as "data ready".
 *         The ALARMED bit is reported through HAL_TRNG_ErrorCallback()
 *         and recorded in the error code field. The ZEROIZED /
 *         KAT_COMPLETE / NOISE_RDY event bits are simply cleared (they are
 *         normally polled in blocking flows). The user must implement
 *         TRNG_IRQ_Handler() to dispatch to this handler.
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @retval None
 */
void HAL_TRNG_IRQHandler(TRNG_HandleTypeDef *htrng)
{
    /* Check the TRNG handle allocation */
    if (TRNG_HandleIsValid(htrng) == 0U)
    {
        return;
    }

    /* TRNG alarmed interrupt occurred */
    if (__HAL_TRNG_GET_IT(htrng, TRNG_FLAG_ALARMED) != RESET)
    {
        /* Clear the alarmed event flag */
        __HAL_TRNG_CLEAR_IT(htrng, TRNG_FLAG_ALARMED);

        /* Record the error source and change the peripheral state */
        htrng->ErrorCode |= HAL_TRNG_ERROR_ALARMED;
        htrng->State = HAL_TRNG_STATE_ERROR;

        HAL_TRNG_ErrorCallback(htrng);
    }

    /* Check TRNG DONE interrupt occurred */
    if (__HAL_TRNG_GET_IT(htrng, TRNG_FLAG_DONE) != RESET)
    {
        /* Generate random number once, so disable the DONE interrupt */
        __HAL_TRNG_DISABLE_IT(htrng, TRNG_IT_DONE);

        /* Clear the DONE event flag */
        __HAL_TRNG_CLEAR_IT(htrng, TRNG_FLAG_DONE);

        /* Read the 32-bit random number from the RAND0 register */
        htrng->RandomNumber = htrng->Instance->RAND0;

        if (htrng->State != HAL_TRNG_STATE_ERROR)
        {
            /* Change TRNG peripheral state */
            htrng->State = HAL_TRNG_STATE_READY;

            /* Data ready callback */
            HAL_TRNG_ReadyDataCallback(htrng, htrng->RandomNumber);
        }
    }

    /* Clear the other event flags (ZEROIZED / KAT_COMPLETE / NOISE_RDY) */
    if (__HAL_TRNG_GET_IT(htrng, TRNG_FLAG_ZEROIZED) != RESET)
    {
        __HAL_TRNG_CLEAR_IT(htrng, TRNG_FLAG_ZEROIZED);
    }
    if (__HAL_TRNG_GET_IT(htrng, TRNG_FLAG_KAT_COMPLETE) != RESET)
    {
        __HAL_TRNG_CLEAR_IT(htrng, TRNG_FLAG_KAT_COMPLETE);
    }
    if (__HAL_TRNG_GET_IT(htrng, TRNG_FLAG_NOISE_RDY) != RESET)
    {
        __HAL_TRNG_CLEAR_IT(htrng, TRNG_FLAG_NOISE_RDY);
    }
}

/**
 * @brief  Data Ready callback in non-blocking mode (WEAK).
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @param  random32bit: generated random number.
 * @retval None
 */
__weak void HAL_TRNG_ReadyDataCallback(TRNG_HandleTypeDef *htrng, uint32 random32bit)
{
    /* Prevent unused argument compilation warning */
    UNUSED(htrng);
    UNUSED(random32bit);

    /* NOTE : This function should not be modified. When the callback is needed,
              function HAL_TRNG_ReadyDataCallback must be implemented in the user file.
     */
}

/**
 * @brief  TRNG error callback (WEAK).
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_TRNG_ErrorCallback(TRNG_HandleTypeDef *htrng)
{
    /* Prevent unused argument compilation warning */
    UNUSED(htrng);

    /* NOTE : This function should not be modified. When the callback is needed,
              function HAL_TRNG_ErrorCallback must be implemented in the user file.
     */
}

/**
  * @}
  */

/** @addtogroup TRNG_Exported_Functions_Group3
  *  @brief   Peripheral State functions.
  * @{
  */

/**
 * @brief  Returns the TRNG state. (NON-BLOCKING)
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @retval HAL_TRNG_StateTypeDef: TRNG state.
 */
HAL_TRNG_StateTypeDef HAL_TRNG_GetState(TRNG_HandleTypeDef *htrng)
{
    /* Check the TRNG handle allocation */
    if (TRNG_HandleIsValid(htrng) == 0U)
    {
        return HAL_TRNG_STATE_RESET;
    }

    /* Return the TRNG state */
    return htrng->State;
}

/**
 * @brief  Returns the TRNG error code. (NON-BLOCKING)
 * @param  htrng: pointer to a TRNG_HandleTypeDef structure.
 * @retval uint32: the TRNG error code (HAL_TRNG_ERROR_xxx).
 */
uint32 HAL_TRNG_GetError(TRNG_HandleTypeDef *htrng)
{
    /* Check the TRNG handle allocation */
    if (TRNG_HandleIsValid(htrng) == 0U)
    {
        return HAL_TRNG_ERROR_NONE;
    }

    /* Return the TRNG error code */
    return htrng->ErrorCode;
}

/**
  * @}
  */

/**
  * @}
  */

#endif /* HAL_TRNG_MODULE_ENABLED */

/*****END OF FILE*****/
