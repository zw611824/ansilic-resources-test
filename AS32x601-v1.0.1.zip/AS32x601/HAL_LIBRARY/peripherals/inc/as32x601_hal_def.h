/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_def.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.6
 * Date:   2026/10/08
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/11     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/16     1.1     add the HAL_RTOS_Yield()
 *                                                       CPU yield hook used by
 *                                                       the blocking polling
 *                                                       loops of the drivers
 *                                                       (empty macro in a
 *                                                       bare-metal build,
 *                                                       user implemented in an
 *                                                       RTOS build)
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.4     define __packed as an alias of the
 *                                                       kernel layer PACKED macro so that
 *                                                       the packed attribute has a single
 *                                                       definition in the library, document
 *                                                       the abstraction ownership split,
 *                                                       and align the version number with
 *                                                       the rest of the common layer
 *     ANSILIC APPLICATION GROUP  2026/10/08     1.5     move the alignment attribute to
 *                                                       __ALIGN_BEGIN so that an aligned object
 *                                                       reads __ALIGN_BEGIN TYPE x __ALIGN_END
 *                                                       (mainstream convention, and the same
 *                                                       split the IAR branch already used), and
 *                                                       state the compiler scope of the
 *                                                       abstraction section: only GCC and IAR
 *                                                       are covered, other toolchains keep the
 *                                                       empty fallbacks instead of an #error
 *     ANSILIC APPLICATION GROUP  2026/10/08     1.6     correct the two IAR compiler abstractions:
 *                                                       __RAM_FUNC was __ramfunc, a keyword the IAR
 *                                                       RISC-V compiler does not have (the token is
 *                                                       absent from iccriscv.exe while __weak /
 *                                                       __root / __no_init / __task are all present),
 *                                                       so it is expressed with the location pragma;
 *                                                       __NOINLINE used the optimize pragma family and
 *                                                       now uses inline = never, the spelling the
 *                                                       toolchain itself uses for _NOINLINE. The
 *                                                       section name is honoured end to end now:
 *                                                       as32x601.ld V1.4 / as32x601.icf V1.2 place
 *                                                       .RamFunc in RAM with its load image in Flash,
 *                                                       inside the block the startup copies
 * Description:     This file contains the HAL common type definitions,
 *                  lock mechanism, utility macros and the compiler
 *                  abstraction for the AS32x601 HAL library.
 */
#ifndef __AS32X601_HAL_DEF_H
#define __AS32X601_HAL_DEF_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include <string.h>                 /* memset: __HAL_CLEAR_STRUCT dependency    */
#include "as32x601.h"               /* device layer: __I/__O/__IO, IRQn, regs   */

/* Exported types ------------------------------------------------------------*/

/**
 * @brief HAL status return codes.
 */
typedef enum
{
    HAL_OK      = 0x00U,            /*!< Operation succeeded                       */
    HAL_ERROR   = 0x01U,            /*!< Operation failed                          */
    HAL_BUSY    = 0x02U,            /*!< Operation blocked by a busy resource      */
    HAL_TIMEOUT = 0x03U             /*!< Operation timed out                       */
} HAL_StatusTypeDef;

/**
 * @brief HAL resource lock state.
 */
typedef enum
{
    HAL_UNLOCKED = 0x00U,           /*!< Resource not locked                       */
    HAL_LOCKED   = 0x01U            /*!< Resource locked                           */
} HAL_LockTypeDef;

/**
 * @brief Abstract mutex handle type.
 * @note  The HAL library itself does not depend on any concrete RTOS. The
 *        real mutex object is created and owned by the user's RTOS porting
 *        layer; HAL only stores and passes this opaque handle around.
 *        A NULL value means "no mutex has been created yet".
 */
typedef void *HAL_MutexTypeDef;

typedef enum
{
    DISABLE = 0U,
    ENABLE  = 1U
} FunctionalState;
#define IS_FUNCTIONAL_STATE(STATE) (((STATE) == DISABLE) || ((STATE) == ENABLE))

typedef enum
{
    RESET = 0U,
    SET   = 1U
} ITStatus;

typedef ITStatus FlagStatus;

/* Exported constants --------------------------------------------------------*/

/**
 * @brief Infinite timeout value used by the blocking API Timeout parameter.
 */
#define HAL_MAX_DELAY        0xFFFFFFFFU

/**
 * @brief Default timeout value (same as HAL_MAX_DELAY: wait forever).
 */
#define HAL_DEFAULT_TIMEOUT  0xFFFFFFFFU

/* Exported macros -----------------------------------------------------------*/

/**
 * @brief Check whether a bit in a register is set.
 */
#define HAL_IS_BIT_SET(REG, BIT)  (((REG) & (BIT)) != 0U)

/**
 * @brief Check whether a bit in a register is cleared.
 */
#define HAL_IS_BIT_CLR(REG, BIT)  (((REG) & (BIT)) == 0U)

/**
 * @brief Link a DMA handle to a peripheral handle and vice versa.
 * @note  The DMA handle must provide a "Parent" field that points back
 *        to the owning peripheral handle.
 */
#define __HAL_LINKDMA(__HANDLE__, __PPP_DMA_FIELD__, __DMA_HANDLE__)            \
                        do{                                                     \
                              (__HANDLE__)->__PPP_DMA_FIELD__ = &(__DMA_HANDLE__); \
                              (__DMA_HANDLE__).Parent = (__HANDLE__);           \
                          } while(0)

/**
 * @brief Avoid compiler warnings for unused variables/parameters.
 * @note  Already provided by core_riscv.h; only defined here as a fallback.
 */
#ifndef UNUSED
    #define UNUSED(x) ((void)(x))
#endif /* UNUSED */

/**
 * @brief Reset the Handle's State field.
 * @note  Must be used before passing a local Handle to HAL_PPP_Init() the
 *        first time, so that the low level initialization (MspInit) is
 *        always executed.
 */
#define __HAL_RESET_HANDLE_STATE(__HANDLE__) ((__HANDLE__)->State = 0U)

#if (USE_RTOS == 1)
    /**
     * @brief Lock a Handle with an RTOS mutex.
     * @note  Requires the peripheral handle to contain a "LockMutex" member
     *        of type HAL_MutexTypeDef, created beforehand by HAL_MutexCreate()
     *        (e.g. inside HAL_PPP_MspInit()). Blocks until the mutex is
     *        acquired or the wait expires.
     */
    #define __HAL_LOCK(__HANDLE__)                                           \
                                do{                                          \
                                    if((__HANDLE__)->LockMutex == NULL)      \
                                    {                                        \
                                       return HAL_ERROR;                     \
                                    }                                        \
                                    if(HAL_MutexAcquire((__HANDLE__)->LockMutex, \
                                                        HAL_MAX_DELAY) != HAL_OK) \
                                    {                                        \
                                       return HAL_BUSY;                      \
                                    }                                        \
                                  }while (0)

    /**
     * @brief Unlock a Handle.
     */
    #define __HAL_UNLOCK(__HANDLE__)                                         \
                                do{                                          \
                                    if((__HANDLE__)->LockMutex != NULL)      \
                                    {                                        \
                                        (void)HAL_MutexRelease((__HANDLE__)->LockMutex); \
                                    }                                        \
                                  }while (0)
#else
    /**
     * @brief Lock a Handle; returns HAL_BUSY immediately if already locked.
     */
    #define __HAL_LOCK(__HANDLE__)                                           \
                                do{                                          \
                                    if((__HANDLE__)->Lock == HAL_LOCKED)     \
                                    {                                        \
                                       return HAL_BUSY;                      \
                                    }                                        \
                                    else                                     \
                                    {                                        \
                                       (__HANDLE__)->Lock = HAL_LOCKED;      \
                                    }                                        \
                                  }while (0)

    /**
     * @brief Unlock a Handle.
     */
    #define __HAL_UNLOCK(__HANDLE__)                                         \
                                do{                                          \
                                    (__HANDLE__)->Lock = HAL_UNLOCKED;       \
                                  }while (0)
#endif /* USE_RTOS */

/**
 * @brief Yield the CPU from a blocking polling loop (architecture rules
 *        RTOS-04 / RTOS-05).
 * @note  In a bare-metal build this is an empty macro, so that the drivers
 *        keep a single code path. In an RTOS build the user RTOS porting layer
 *        shall implement the function (for example taskYIELD() / vTaskDelay(1)
 *        for FreeRTOS, rt_thread_yield() for RT-Thread) so that a task
 *        polling a peripheral does not starve the other tasks of the same
 *        priority.
 * @note  HAL_RTOS_Yield() shall never be called from an interrupt service
 *        routine nor from within a critical section (rule RTOS-06).
 */
#if (USE_RTOS == 1)
void HAL_RTOS_Yield(void);
#else
#define HAL_RTOS_Yield()   do { } while (0U)
#endif /* USE_RTOS */

/**
 * @brief Clear a handle structure (must be done before its first use).
 */
#define __HAL_CLEAR_STRUCT(__STRUCT__) memset((__STRUCT__), 0, sizeof(*(__STRUCT__)))

/******************************************************************************
 *  COMPILER ABSTRACTION DEFINITIONS
 *****************************************************************************/
/* The abstraction is split by layer (HAL-REQ-016): the kernel layer
 * (core_riscv.h) owns the register qualifiers (__I / __O / __IO), INLINE,
 * PACKED and UNUSED; this header only adds the abstractions the kernel layer
 * does not provide (__weak, the alignment pair, __RAM_FUNC, __NOINLINE) and
 * never re-defines a kernel one.
 *
 * Scope of the two branches below: only GCC and IAR RISC-V are covered. A
 * compiler that matches neither keeps the kernel layer abstractions (which
 * cover further toolchains) but receives no HAL owned one. That case is
 * deliberately not rejected with an #error: __weak and __packed stay
 * undefined and __RAM_FUNC / __NOINLINE fall back to empty definitions, so
 * the header stays usable and the missing behaviour surfaces at the point of
 * use instead of being refused here.
 */

/*------------------------------------ GCC -----------------------------------*/
#if defined(__GNUC__)
    #ifndef __weak
        #define __weak   __attribute__((weak))
    #endif /* __weak */
    #ifndef __packed
        /* Reuse the kernel layer definition instead of writing the attribute
         * a second time (HAL-REQ-016: one packed attribute, one definition) */
        #define __packed PACKED
    #endif /* __packed */
    /* The alignment attribute opens the declaration, so that an aligned object
     * is written as:
     *   __ALIGN_BEGIN uint8_t buffer[N] __ALIGN_END;
     * This is the mainstream HAL convention and the same split the IAR branch
     * below uses, therefore one declaration is portable between the two
     * toolchains. Note that it is the opposite split from the definition this
     * library used before V1.5, which carried the attribute on __ALIGN_END:
     * the two forms are not interchangeable, so a declaration copied from an
     * older file must be adapted rather than mixed. (No object in the library
     * uses the pair today, so this change is free of behavioural risk.) */
    #ifndef __ALIGN_BEGIN
        #define __ALIGN_BEGIN  __attribute__((aligned(4)))
    #endif /* __ALIGN_BEGIN */
    #ifndef __ALIGN_END
        #define __ALIGN_END
    #endif /* __ALIGN_END */
#endif /* __GNUC__ */

/*----------------------------------- IAR ------------------------------------*/
#if defined(__ICCRISCV__)
    /* __weak / __packed are native keywords of the IAR RISC-V compiler. */
    /* The alignment is expressed as a pragma, which must precede the
     * declaration it applies to; that is why it belongs to __ALIGN_BEGIN, the
     * same split as the GCC branch above:
     *   __ALIGN_BEGIN uint8_t buffer[N] __ALIGN_END; */
    #ifndef __ALIGN_BEGIN
        #define __ALIGN_BEGIN  _Pragma("data_alignment=4")
    #endif /* __ALIGN_BEGIN */
    #ifndef __ALIGN_END
        #define __ALIGN_END
    #endif /* __ALIGN_END */
#endif /* __ICCRISCV__ */

/**
 * @brief Function placed in RAM (for code executed from SRAM).
 * @note  Both branches name the same section, ".RamFunc": GCC selects it with
 *        the section attribute and IAR RISC-V with the location pragma. The
 *        linker configuration must place that section in RAM and keep its load
 *        image inside the block the startup routine copies (as32x601.ld V1.4 /
 *        as32x601.icf V1.2 do), otherwise the function silently keeps running
 *        from Flash.
 */
#if defined(__GNUC__)
    #define __RAM_FUNC   __attribute__((section(".RamFunc")))
#elif defined(__ICCRISCV__)
    /* IAR RISC-V has no __ramfunc keyword: the token is absent from the IAR
     * RISC-V compiler while the keywords it does provide (__weak, __root,
     * __no_init, __task) are all present, so the earlier spelling would have
     * failed to compile the moment the macro was used.  Section placement is
     * expressed with the location pragma instead, which the same compiler
     * accepts (its pragma table contains "location", next to "alignment" and
     * "optimize").
     * The section name must match the linker configuration on both toolchains:
     * as32x601.ld / as32x601.icf place .RamFunc in RAM with its load image in
     * Flash, inside the block the startup routine copies, so a function tagged
     * with this macro really executes from RAM. */
    #define __RAM_FUNC   _Pragma("location = \".RamFunc\"")
#else
    /* Another toolchain: no RAM execution attribute is invented here, so the
     * function keeps its default placement (see the scope note at the head of
     * this section). */
    #define __RAM_FUNC
#endif /* __GNUC__ */

/**
 * @brief Prevent the compiler from inlining a function.
 */
#if defined(__GNUC__)
    #define __NOINLINE   __attribute__((noinline))
#elif defined(__ICCRISCV__)
    /* IAR spells the "do not inline" pragma as "inline = never": the token is
     * present in the IAR RISC-V compiler and it is the spelling the toolchain's
     * own standard header uses to define its _NOINLINE macro.  The previous
     * spelling (the optimize pragma) is a different pragma family and was not
     * verified against the toolchain. */
    #define __NOINLINE   _Pragma("inline = never")
#else
    /* Another toolchain: the function may be inlined (see the scope note at the
     * head of this section). */
    #define __NOINLINE
#endif /* __GNUC__ */

/* Exported functions --------------------------------------------------------*/
#if (USE_RTOS == 1)
/**
 * @brief Create a mutex object.
 * @note  Implemented by the user's RTOS porting layer. The HAL library itself
 *        does not include any RTOS dependency.
 * @retval HAL_MutexTypeDef: opaque mutex handle, NULL on failure.
 */
HAL_MutexTypeDef HAL_MutexCreate(void);

/**
 * @brief Acquire a mutex.
 * @note  Implemented by the user's RTOS porting layer.
 * @param  Mutex:   mutex handle returned by HAL_MutexCreate()
 * @param  Timeout: maximum wait time in RTOS ticks; HAL_MAX_DELAY for an
 *                  infinite wait.
 * @retval HAL_StatusTypeDef: HAL_OK on success, HAL_TIMEOUT on timeout,
 *         HAL_ERROR on error (e.g. NULL mutex handle).
 */
HAL_StatusTypeDef HAL_MutexAcquire(HAL_MutexTypeDef Mutex, uint32 Timeout);

/**
 * @brief Release a mutex.
 * @note  Implemented by the user's RTOS porting layer.
 * @param  Mutex: mutex handle returned by HAL_MutexCreate()
 * @retval HAL_StatusTypeDef: HAL_OK on success, HAL_ERROR on error.
 */
HAL_StatusTypeDef HAL_MutexRelease(HAL_MutexTypeDef Mutex);
#endif /* USE_RTOS */

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_DEF_H */

/*****END OF FILE*****/
