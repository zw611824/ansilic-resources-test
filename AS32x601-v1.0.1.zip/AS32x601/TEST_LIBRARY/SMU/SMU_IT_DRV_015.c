/**
 * @file    SMU_IT_DRV_015.c
 * @brief   HAL SMU integration test case 015 (full API coverage).
 *
 * Extension case (no one-to-one vendor counterpart): it exercises the whole
 * HAL SMU API surface with only HAL library calls.
 *
 * Tested functionality:
 *   Group 1  HAL_SMU_Init() + HAL_SMU_GetState() / HAL_SMU_GetError()
 *            (+ HAL_SMU_MspInit() call counting)
 *   Group 2  HAL_SMU_GetSysClockFreq() / GetHCLKFreq() / GetPCLK0Freq() /
 *            GetPCLK1Freq() / GetClocksFreq() and their consistency
 *   Group 3  HAL_SMU_GetOscConfig() / HAL_SMU_GetClockConfig() read back
 *   Group 4  HAL_SMU_MCOConfig() over all eight clock output selections
 *   Group 5  HAL_SMU_GetFlagStatus() / GetBusState() / GetWorkMode()
 *   Group 6  HAL_SMU_TimerBreak() / TIMBreakCmd() / SetSRAMLowPower() /
 *            DCLSCmd() / ECCCmd() / BUSTimeOutCmd() /
 *            SetBUSTimeOutValue() / ClearTimeOutFlag()
 *   Group 7  check macros and constants
 *   Group 8  SMU_LockHandle() / SMU_UnlockHandle()
 *   Group 9  HAL_SMU_DeInit() (+ HAL_SMU_MspDeInit() call counting)
 *   Group 10 state gate: configuration calls on a de-initialized handle
 *
 * Test procedure:
 *   The standard clock tree (PLL 180 MHz) is applied and the groups are
 *   checked and printed in place.  Group 1 runs before the console can be
 *   initialized (the console is derived from the clock tree), so its results
 *   are collected first and judged once the console is up.  The groups that
 *   de-initialize the SMU come last: HAL_SMU_DeInit() moves the system clock
 *   back to the FIRC, so every result of groups 9 and 10 is collected first
 *   and printed after the standard tree and the console have been restored.
 *
 * Expected behaviour:
 *   "summary : failures = 0".  The lines marked "info" are recorded but not
 *   judged: they depend on the start-up source (power on / deep sleep /
 *   sleep) or are write-1-to-clear register bits.
 *
 * Safety notes (calls deliberately restricted):
 *   - HAL_SMU_DCLSCmd(ENABLE) is NOT issued: the dual core lock step needs the
 *     second core to run in lock step, so enabling it from a single core test
 *     would hang the device.  Only the disable direction is exercised.
 *   - HAL_SMU_SetSRAMLowPower() is NOT used to enable: switching a SRAM bank
 *     to low power while the stack lives in it would fault.  Only the disable
 *     direction is exercised.
 *   - HAL_SMU_ECCCmd(ENABLE) and HAL_SMU_BUSTimeOutCmd(ENABLE) are followed
 *     immediately by the matching disable call.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
#define TEST_BAUDRATE               (115200U)

/* Standard clock tree (the same tree the other HAL integration suites use) */
#define STD_PLL_DIV_R               (0x04U)
#define STD_PLL_DIV_Q               (0x01U)
#define STD_PLL_DIV_N               (0x14U)
#define STD_PLL_DIV_F               (0xB4U)
#define STD_AXI4BUS3_DIV            SMU_AXI4BUS3CLK_DIV2
#define STD_APBBUS0_DIV             SMU_APBBUS0CLK_DIV2
#define STD_APBBUS1_DIV             SMU_APBBUS1CLK_DIV2
#define STD_CANX2_DIV               SMU_CANX2CLK_DIV8

/* Expected system clock of the standard tree: 180 MHz PLLCLK_Q */
#define STD_SYSCLK_HZ               (180000000U)

/* Number of clock output selections of the MCO test */
#define MCO_SELECTIONS              (8U)

/* Private variables -------------------------------------------------------*/
static HAL_SMU_HandleTypeDef hsmu_dev;      /*!< SMU handle                   */
static HAL_PMU_HandleTypeDef hpmu_dev;      /*!< PMU handle (LDO scaler)      */
static uint32 g_failures;                   /*!< collected failures           */

/* MSP callback instrumentation (the weak symbols are overridden below) */
static uint32 g_msp_init_cnt;
static uint32 g_msp_deinit_cnt;
static uint32 g_msp_init_state;
static uint32 g_msp_init_lock;
static uint32 g_msp_deinit_state;

/* Clock output selections, in the order of the register field */
static const uint32 g_mco[MCO_SELECTIONS] =
{
    SMU_CLKOUTMUX_CORECLK_DIV8,
    SMU_CLKOUTMUX_AXIBUS1_DIV8,
    SMU_CLKOUTMUX_AXIBUS3_DIV8,
    SMU_CLKOUTMUX_APBBUS0_DIV8,
    SMU_CLKOUTMUX_APBBUS1_DIV8,
    SMU_CLKOUTMUX_FIRC_DIV8,
    SMU_CLKOUTMUX_OSC_DIV8,
    SMU_CLKOUTMUX_SIRC
};

/* Group 1 collected results */
static uint32 g1_state_before;
static uint32 g1_init_ret;
static uint32 g1_state_after;
static uint32 g1_error_after;
static uint32 g1_init_again_ret;
static uint32 g1_init_null_ret;
static uint32 g1_init_bad_ret;
static uint32 g1_state_null;
static uint32 g1_error_null;

/* Group 9 / 10 collected results */
static uint32 g9_deinit_ret;
static uint32 g9_state_after;
static uint32 g9_clock_ret;
static uint32 g9_osc_ret;
static uint32 g9_mco_before;
static uint32 g9_mco_after;
static uint32 g9_sysclk_after_deinit;
static uint32 g9_init_null_ret;
static uint32 g9_deinit_null_ret;
static uint32 g9_reinit_ret;

/* Private function prototypes ---------------------------------------------*/
static void   SystemClock_Standard(void);
static uint32 Chk(const char *name, uint32 expect, uint32 actual);
static void   Info(const char *name, uint32 value);
static uint32 ChkRange(const char *name, uint32 value, uint32 low, uint32 high);
static void   Group1_Execute(void);
static void   Group1_Report(void);
static void   Group9_Execute(void);
static void   Group9_Report(void);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    SMU_OscInitTypeDef   osc_rb;
    SMU_ClockInitTypeDef clk_rb;
    SMU_ClocksTypeDef    clocks;
    uint32 i;
    uint32 othcfgr;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Group 1 runs before the console exists: collect, judge it later */
    Group1_Execute();

    /* Buses and the flash controller must be clocked before the clock tree
       is programmed (HAL_SMU_OscConfig touches the flash controller) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();

    /* PMU in a known state, then the standard clock tree and the console */
    __HAL_CLEAR_STRUCT(&hpmu_dev);
    hpmu_dev.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu_dev);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu_dev, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu_dev, PMU_VO12_1V34);

    SystemClock_Standard();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);

    printf("\r\n=== SMU_IT_DRV_015: full API coverage ===\r\n");

    /* ---------------- Group 1: handle initialization ------------------ */
    Group1_Report();

    /* ---------------- Group 2: frequency queries ---------------------- */
    printf("--- group 2: frequency queries ---\r\n");
    g_failures += Chk("HAL_SMU_GetClocksFreq returns HAL_OK",
                      (uint32)HAL_OK, (uint32)HAL_SMU_GetClocksFreq(&clocks));
    g_failures += Chk("HAL_SMU_GetClocksFreq(NULL) returns HAL_ERROR",
                      (uint32)HAL_ERROR, (uint32)HAL_SMU_GetClocksFreq(NULL_PTR));
    g_failures += Chk("GetSysClockFreq agrees with GetClocksFreq",
                      HAL_SMU_GetSysClockFreq(), clocks.AXIBus0_Frequency);
    g_failures += Chk("GetHCLKFreq agrees with SystemCoreClock",
                      HAL_SMU_GetHCLKFreq(), (uint32)SystemCoreClock);
    g_failures += Chk("GetPCLK0Freq agrees with GetClocksFreq",
                      HAL_SMU_GetPCLK0Freq(), clocks.APBBus0_Frequency);
    g_failures += Chk("GetPCLK1Freq agrees with GetClocksFreq",
                      HAL_SMU_GetPCLK1Freq(), clocks.APBBus1_Frequency);
    g_failures += Chk("AXIBus1 is AXIBus0 / 2",
                      clocks.AXIBus0_Frequency / 2U, clocks.AXIBus1_Frequency);
    g_failures += Chk("AXIBus2 equals AXIBus1",
                      clocks.AXIBus1_Frequency, clocks.AXIBus2_Frequency);
    g_failures += Chk("AXIBus3 is AXIBus1 / AXI4Bus3Div",
                      clocks.AXIBus1_Frequency / (uint32)STD_AXI4BUS3_DIV,
                      clocks.AXIBus3_Frequency);
    g_failures += Chk("AXILite4Bus0 equals AXIBus0",
                      clocks.AXIBus0_Frequency, clocks.AXILite4Bus0_Frequency);
    g_failures += Chk("AXILite4Bus1 equals AXIBus3",
                      clocks.AXIBus3_Frequency, clocks.AXILite4Bus1_Frequency);
    g_failures += Chk("AXILite4Bus2 equals AXIBus3",
                      clocks.AXIBus3_Frequency, clocks.AXILite4Bus2_Frequency);
    g_failures += Chk("SYSCLK is the expected 180 MHz PLLCLK_Q",
                      (uint32)STD_SYSCLK_HZ, clocks.AXIBus0_Frequency);
    Info("CANCLKx2 =", clocks.CANCLKx2_Frequency);

    /* ---------------- Group 3: configuration read back ---------------- */
    printf("--- group 3: GetOscConfig / GetClockConfig ---\r\n");
    g_failures += Chk("HAL_SMU_GetOscConfig returns HAL_OK",
                      (uint32)HAL_OK, (uint32)HAL_SMU_GetOscConfig(&osc_rb));
    g_failures += Chk("HAL_SMU_GetOscConfig(NULL) returns HAL_ERROR",
                      (uint32)HAL_ERROR, (uint32)HAL_SMU_GetOscConfig(NULL_PTR));
    g_failures += Chk("HAL_SMU_GetClockConfig returns HAL_OK",
                      (uint32)HAL_OK, (uint32)HAL_SMU_GetClockConfig(&clk_rb));
    g_failures += Chk("HAL_SMU_GetClockConfig(NULL) returns HAL_ERROR",
                      (uint32)HAL_ERROR, (uint32)HAL_SMU_GetClockConfig(NULL_PTR));
    g_failures += Chk("read back SYSCLKSelect is PLL",
                      (uint32)SMU_SYSCLKSOURCE_PLL, osc_rb.SYSCLKSelect);
    g_failures += Chk("read back PLLState is ON",
                      (uint32)SMU_PLL_ON, osc_rb.PLL.PLLState);
    g_failures += Chk("read back PLLSource is OSC",
                      (uint32)SMU_PLLSOURCE_OSC, osc_rb.PLL.PLLSource);
    g_failures += Chk("read back PLL N", (uint32)STD_PLL_DIV_N, osc_rb.PLL.PLLDivN);
    g_failures += Chk("read back PLL F", (uint32)STD_PLL_DIV_F, osc_rb.PLL.PLLDivF);
    g_failures += Chk("read back PLL Q", (uint32)STD_PLL_DIV_Q, osc_rb.PLL.PLLDivQ);
    g_failures += Chk("read back PLL R", (uint32)STD_PLL_DIV_R, osc_rb.PLL.PLLDivR);
    g_failures += Chk("read back AXI4Bus3 divider",
                      (uint32)STD_AXI4BUS3_DIV, clk_rb.AXI4Bus3CLKDiv);
    g_failures += Chk("read back APBBus0 divider",
                      (uint32)STD_APBBUS0_DIV, clk_rb.APBBus0CLKDiv);
    g_failures += Chk("read back APBBus1 divider",
                      (uint32)STD_APBBUS1_DIV, clk_rb.APBBus1CLKDiv);
    g_failures += Chk("read back CANCLKx2 divider",
                      (uint32)STD_CANX2_DIV, clk_rb.CANX2CLKDiv);

    /* ---------------- Group 4: clock output selections ---------------- */
    printf("--- group 4: MCOConfig over all %u selections ---\r\n",
           PRINT_U32(MCO_SELECTIONS));
    for (i = 0U; i < MCO_SELECTIONS; i++)
    {
        HAL_SMU_MCOConfig(&hsmu_dev, g_mco[i]);
        othcfgr = (SMU->OTHCFGR & SMU_OTHCFGR_CLKOUTMUX) >> SMU_OTHCFGR_CLKOUTMUX_Pos;
        g_failures += Chk("clock output selection read back", g_mco[i], othcfgr);
    }
    /* Leave the output on the core clock, as the other cases do */
    HAL_SMU_MCOConfig(&hsmu_dev, SMU_CLKOUTMUX_CORECLK_DIV8);

    /* ---------------- Group 5: flags, bus state, work mode ------------ */
    printf("--- group 5: GetFlagStatus / GetBusState / GetWorkMode ---\r\n");
    g_failures += Chk("PLL lock flag is set", 1U,
                      HAL_SMU_GetFlagStatus(SMU_FLAG_PLLLOCK));
    g_failures += Chk("flash init flag is set", 1U,
                      HAL_SMU_GetFlagStatus(SMU_FLAG_EFLASHICS));
    Info("power-on start flag =", HAL_SMU_GetFlagStatus(SMU_FLAG_PWNSTART));
    Info("deep sleep flag =", HAL_SMU_GetFlagStatus(SMU_FLAG_DSSTART));
    Info("sleep flag =", HAL_SMU_GetFlagStatus(SMU_FLAG_SLEEPSTART));
    Info("low power flag =", HAL_SMU_GetFlagStatus(SMU_FLAG_LPWR));
    Info("bus state (BUSS) =", HAL_SMU_GetBusState());
    Info("work mode =", (uint32)HAL_SMU_GetWorkMode());
    g_failures += ChkRange("SRAM0 ready flag is a flag value",
                           HAL_SMU_GetFlagStatus(SMU_FLAG_SRAM0RDY), 0U, 1U);
    g_failures += ChkRange("SRAM1 ready flag is a flag value",
                           HAL_SMU_GetFlagStatus(SMU_FLAG_SRAM1RDY), 0U, 1U);
    g_failures += ChkRange("SRAM2 ready flag is a flag value",
                           HAL_SMU_GetFlagStatus(SMU_FLAG_SRAM2RDY), 0U, 1U);
    g_failures += ChkRange("SRAM3 ready flag is a flag value",
                           HAL_SMU_GetFlagStatus(SMU_FLAG_SRAM3RDY), 0U, 1U);

    /* ---------------- Group 6: extended control functions ------------- */
    printf("--- group 6: extended control functions ---\r\n");
    HAL_SMU_TimerBreak(&hsmu_dev, SMU_TIMBREAK_TIM0);
    g_failures += Chk("TimerBreak selects TIM0",
                      (uint32)SMU_TIMBREAK_TIM0,
                      (SMU->OTHCFGR & SMU_OTHCFGR_TIMBKEN) >> SMU_OTHCFGR_TIMBKEN_Pos);
    HAL_SMU_TIMBreakCmd(&hsmu_dev, SMU_TIMBREAK_TIM2, ENABLE);
    g_failures += Chk("TIMBreakCmd(ENABLE) sets the TIM2 bit",
                      (uint32)(SMU_TIMBREAK_TIM0 | SMU_TIMBREAK_TIM2),
                      (SMU->OTHCFGR & SMU_OTHCFGR_TIMBKEN) >> SMU_OTHCFGR_TIMBKEN_Pos);
    HAL_SMU_TIMBreakCmd(&hsmu_dev, SMU_TIMBREAK_TIM2, DISABLE);
    g_failures += Chk("TIMBreakCmd(DISABLE) clears the TIM2 bit",
                      (uint32)SMU_TIMBREAK_TIM0,
                      (SMU->OTHCFGR & SMU_OTHCFGR_TIMBKEN) >> SMU_OTHCFGR_TIMBKEN_Pos);

    HAL_SMU_SetSRAMLowPower(&hsmu_dev, SMU_SRAMLOWPOWER_SRAM3, DISABLE);
    g_failures += Chk("SetSRAMLowPower(SRAM3, DISABLE) leaves the bit clear",
                      0U,
                      (SMU->OTHCFGR & SMU_OTHCFGR_SRAMLPEN) >> SMU_OTHCFGR_SRAMLPEN_Pos);

    /* The dual core lock step is only exercised in the disable direction */
    HAL_SMU_DCLSCmd(&hsmu_dev, DISABLE);
    g_failures += Chk("DCLSCmd(DISABLE) leaves DCLSEN clear",
                      0U,
                      (SMU->OTHCFGR & SMU_OTHCFGR_DCLSEN) >> SMU_OTHCFGR_DCLSEN_Pos);

    HAL_SMU_ECCCmd(&hsmu_dev, ENABLE);
    g_failures += Chk("ECCCmd(ENABLE) sets ECCEN",
                      (uint32)(SMU_OTHCFGR_ECCEN >> SMU_OTHCFGR_ECCEN_Pos),
                      (SMU->OTHCFGR & SMU_OTHCFGR_ECCEN) >> SMU_OTHCFGR_ECCEN_Pos);
    HAL_SMU_ECCCmd(&hsmu_dev, DISABLE);
    g_failures += Chk("ECCCmd(DISABLE) clears ECCEN",
                      0U,
                      (SMU->OTHCFGR & SMU_OTHCFGR_ECCEN) >> SMU_OTHCFGR_ECCEN_Pos);

    HAL_SMU_SetBUSTimeOutValue(&hsmu_dev, SMU_BUSTIMEOUT_VALUE_MAX);
    g_failures += Chk("SetBUSTimeOutValue(max) is programmed",
                      (uint32)SMU_BUSTIMEOUT_VALUE_MAX,
                      (SMU->BUSTCFGR & SMU_BUSTCFGR_BUSTIMEOUTNUM) >> SMU_BUSTCFGR_BUSTIMEOUTNUM_Pos);
    HAL_SMU_SetBUSTimeOutValue(&hsmu_dev, SMU_BUSTIMEOUT_VALUE_MIN);
    g_failures += Chk("SetBUSTimeOutValue(min) is programmed",
                      (uint32)SMU_BUSTIMEOUT_VALUE_MIN,
                      (SMU->BUSTCFGR & SMU_BUSTCFGR_BUSTIMEOUTNUM) >> SMU_BUSTCFGR_BUSTIMEOUTNUM_Pos);

    HAL_SMU_BUSTimeOutCmd(&hsmu_dev, ENABLE);
    g_failures += Chk("BUSTimeOutCmd(ENABLE) sets the bit",
                      (uint32)(SMU_BUSTCFGR_BUSTIMEOUTEN >> SMU_BUSTCFGR_BUSTIMEOUTEN_Pos),
                      (SMU->BUSTCFGR & SMU_BUSTCFGR_BUSTIMEOUTEN) >> SMU_BUSTCFGR_BUSTIMEOUTEN_Pos);
    HAL_SMU_BUSTimeOutCmd(&hsmu_dev, DISABLE);
    g_failures += Chk("BUSTimeOutCmd(DISABLE) clears the bit",
                      0U,
                      (SMU->BUSTCFGR & SMU_BUSTCFGR_BUSTIMEOUTEN) >> SMU_BUSTCFGR_BUSTIMEOUTEN_Pos);

    /* The clear is a write-1 action on the flag bit: the other bits of
     * OTHCFGR must not be disturbed by it */
    othcfgr = SMU->OTHCFGR;
    HAL_SMU_ClearTimeOutFlag(&hsmu_dev);
    g_failures += Chk("ClearTimeOutFlag keeps the other OTHCFGR bits",
                      (othcfgr & ~(uint32)SMU_OTHCFGR_TIMEOUTCF),
                      (SMU->OTHCFGR & ~(uint32)SMU_OTHCFGR_TIMEOUTCF));

    /* ---------------- Group 7: check macros and constants ------------- */
    printf("--- group 7: check macros and constants ---\r\n");
    g_failures += Chk("__HAL_SMU_MODULE_VERSION", 0x0100U,
                      (uint32)__HAL_SMU_MODULE_VERSION);
    g_failures += Chk("IS_SMU_INSTANCE(SMU)", 1U, (uint32)IS_SMU_INSTANCE(SMU));
    g_failures += Chk("IS_SMU_OSCILLATORTYPE(FIRC)", 1U,
                      (uint32)IS_SMU_OSCILLATORTYPE(SMU_OSCILLATORTYPE_FIRC));
    g_failures += Chk("IS_SMU_OSCILLATORTYPE(NONE) is false", 0U,
                      (uint32)IS_SMU_OSCILLATORTYPE(SMU_OSCILLATORTYPE_NONE));
    g_failures += Chk("IS_SMU_FIRC_STATE(ON)", 1U,
                      (uint32)IS_SMU_FIRC_STATE(SMU_FIRC_ON));
    g_failures += Chk("IS_SMU_PLL_STATE(ON)", 1U,
                      (uint32)IS_SMU_PLL_STATE(SMU_PLL_ON));
    g_failures += Chk("IS_SMU_PLLSOURCE(FIRC)", 1U,
                      (uint32)IS_SMU_PLLSOURCE(SMU_PLLSOURCE_FIRC));
    g_failures += Chk("IS_SMU_SYSCLKSOURCE(OSC)", 1U,
                      (uint32)IS_SMU_SYSCLKSOURCE(SMU_SYSCLKSOURCE_OSC));
    g_failures += Chk("IS_SMU_PLLDIVR_VALUE(0) is false", 0U,
                      (uint32)IS_SMU_PLLDIVR_VALUE(0));
    g_failures += Chk("IS_SMU_PLLDIVR_VALUE(1)", 1U,
                      (uint32)IS_SMU_PLLDIVR_VALUE(1));
    g_failures += Chk("IS_SMU_PLLDIVQ_VALUE(15)", 1U,
                      (uint32)IS_SMU_PLLDIVQ_VALUE(15));
    g_failures += Chk("IS_SMU_PLLDIVQ_VALUE(16) is false", 0U,
                      (uint32)IS_SMU_PLLDIVQ_VALUE(16));
    g_failures += Chk("IS_SMU_PLLDIVN_VALUE(63)", 1U,
                      (uint32)IS_SMU_PLLDIVN_VALUE(63));
    g_failures += Chk("IS_SMU_PLLDIVF_VALUE(49) is false", 0U,
                      (uint32)IS_SMU_PLLDIVF_VALUE(49));
    g_failures += Chk("IS_SMU_PLLDIVF_VALUE(50)", 1U,
                      (uint32)IS_SMU_PLLDIVF_VALUE(50));
    g_failures += Chk("IS_SMU_AXI4BUS3CLKDIV(DIV1)", 1U,
                      (uint32)IS_SMU_AXI4BUS3CLKDIV(SMU_AXI4BUS3CLK_DIV1));
    g_failures += Chk("IS_SMU_AXI4BUS3CLKDIV(DIV4) is false", 0U,
                      (uint32)IS_SMU_AXI4BUS3CLKDIV(SMU_APBBUS0CLK_DIV4));
    g_failures += Chk("IS_SMU_APBBUS0CLKDIV(DIV8)", 1U,
                      (uint32)IS_SMU_APBBUS0CLKDIV(SMU_APBBUS0CLK_DIV8));
    g_failures += Chk("IS_SMU_APBBUS1CLKDIV(DIV4)", 1U,
                      (uint32)IS_SMU_APBBUS1CLKDIV(SMU_APBBUS1CLK_DIV4));
    g_failures += Chk("IS_SMU_CANX2CLKDIV(DIV2)", 1U,
                      (uint32)IS_SMU_CANX2CLKDIV(SMU_CANX2CLK_DIV2));
    g_failures += Chk("IS_SMU_CLKOUTMUX(SIRC)", 1U,
                      (uint32)IS_SMU_CLKOUTMUX(SMU_CLKOUTMUX_SIRC));
    g_failures += Chk("IS_SMU_CLKOUTMUX(0x08) is false", 0U,
                      (uint32)IS_SMU_CLKOUTMUX(0x08U));
    g_failures += Chk("IS_SMU_TIMBREAK(TIM5)", 1U,
                      (uint32)IS_SMU_TIMBREAK(SMU_TIMBREAK_TIM5));
    g_failures += Chk("IS_SMU_TIMBREAK_MASK(TIM0|TIM2)", 1U,
                      (uint32)IS_SMU_TIMBREAK_MASK(SMU_TIMBREAK_TIM0 |
                                                   SMU_TIMBREAK_TIM2));
    g_failures += Chk("IS_SMU_TIMBREAK_MASK(0) is false", 0U,
                      (uint32)IS_SMU_TIMBREAK_MASK(0U));
    g_failures += Chk("IS_SMU_SRAMLOWPOWER(SRAM3)", 1U,
                      (uint32)IS_SMU_SRAMLOWPOWER(SMU_SRAMLOWPOWER_SRAM3));
    g_failures += Chk("IS_SMU_FLAG(PLLLOCK)", 1U,
                      (uint32)IS_SMU_FLAG(SMU_FLAG_PLLLOCK));
    g_failures += Chk("IS_SMU_FLAG(0x8000) is false", 0U,
                      (uint32)IS_SMU_FLAG(0x8000U));
    g_failures += Chk("IS_SMU_BUSTIMEOUTVALUE(min)", 1U,
                      (uint32)IS_SMU_BUSTIMEOUTVALUE(SMU_BUSTIMEOUT_VALUE_MIN));
    g_failures += Chk("IS_SMU_BUSTIMEOUTVALUE(min - 1) is false", 0U,
                      (uint32)IS_SMU_BUSTIMEOUTVALUE(SMU_BUSTIMEOUT_VALUE_MIN - 1U));
    g_failures += Chk("timeout constants are ordered",
                      (uint32)((SMU_TIMEOUT_OSC < SMU_TIMEOUT_PLL) ? 1U : 0U), 1U);
    g_failures += Chk("SMU_TIMEOUT_DEFAULT is SMU_TIMEOUT_PLL",
                      (uint32)SMU_TIMEOUT_PLL, (uint32)SMU_TIMEOUT_DEFAULT);

    /* ---------------- Group 8: shared lock helpers -------------------- */
    printf("--- group 8: SMU_LockHandle / SMU_UnlockHandle ---\r\n");
    g_failures += Chk("SMU_LockHandle takes a free lock",
                      (uint32)HAL_OK, (uint32)SMU_LockHandle(&hsmu_dev, 0U));
    g_failures += Chk("SMU_LockHandle on a locked handle returns HAL_BUSY",
                      (uint32)HAL_BUSY, (uint32)SMU_LockHandle(&hsmu_dev, 0U));
    SMU_UnlockHandle(&hsmu_dev);
    g_failures += Chk("SMU_LockHandle after the unlock succeeds",
                      (uint32)HAL_OK, (uint32)SMU_LockHandle(&hsmu_dev, 0U));
    SMU_UnlockHandle(&hsmu_dev);

    /* ---------------- Group 9 / 10: DeInit and the state gate --------- */
    printf("--- group 9 / 10: DeInit, MspDeInit and the state gate ---\r\n");
    printf("    (the console stays silent until the tree is restored)\r\n");

    Group9_Execute();

    /* Restore the tree and the console, then report groups 9 and 10 */
    g9_reinit_ret = (uint32)HAL_SMU_Init(&hsmu_dev);
    SystemClock_Standard();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);

    printf("\r\nclock tree restored: SYSCLK = %u Hz, PCLK0 = %u Hz\r\n",
           PRINT_U32(HAL_SMU_GetSysClockFreq()), PRINT_U32(HAL_SMU_GetPCLK0Freq()));
    printf("state = %u (1 = READY), error = 0x%08X\r\n",
           PRINT_U32(HAL_SMU_GetState(&hsmu_dev)),
           PRINT_U32(HAL_SMU_GetError(&hsmu_dev)));

    Group9_Report();

    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(g_failures));

    while (1)
    {
    }
}

/**
 * @brief  Apply the standard clock tree (PLL 180 MHz from the OSC).
 * @note   Dividers first (while the system clock is still the FIRC), then
 *         HAL_SMU_OscConfig(), which programs the flash controller clock,
 *         switches the system clock and performs the flash clock update.
 * @param  None
 * @retval None
 */
static void SystemClock_Standard(void)
{
    SMU_OscInitTypeDef   osc;
    SMU_ClockInitTypeDef clk;

    __HAL_CLEAR_STRUCT(&clk);
    clk.Size           = sizeof(clk);
    clk.Version        = SMU_CLOCK_INIT_VERSION;
    clk.AXI4Bus3CLKDiv = STD_AXI4BUS3_DIV;
    clk.APBBus0CLKDiv  = STD_APBBUS0_DIV;
    clk.APBBus1CLKDiv  = STD_APBBUS1_DIV;
    clk.CANX2CLKDiv    = STD_CANX2_DIV;
    (void)HAL_SMU_ClockConfig(&hsmu_dev, &clk);

    __HAL_CLEAR_STRUCT(&osc);
    osc.Size                 = sizeof(osc);
    osc.Version              = SMU_OSC_INIT_VERSION;
    osc.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    osc.FIRCState            = SMU_FIRC_ON;
    osc.FIRCCalibrationValue = 0x00U;
    osc.PLL.Size             = sizeof(osc.PLL);
    osc.PLL.Version          = SMU_PLL_INIT_VERSION;
    osc.PLL.PLLState         = SMU_PLL_ON;
    osc.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    osc.PLL.PLLDivR          = STD_PLL_DIV_R;
    osc.PLL.PLLDivQ          = STD_PLL_DIV_Q;
    osc.PLL.PLLDivN          = STD_PLL_DIV_N;
    osc.PLL.PLLDivF          = STD_PLL_DIV_F;
    osc.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;
    (void)HAL_SMU_OscConfig(&hsmu_dev, &osc, SMU_TIMEOUT_DEFAULT);
}

/**
 * @brief  Group 1: handle initialization, collected before the console exists.
 * @param  None
 * @retval None
 */
static void Group1_Execute(void)
{
    HAL_SMU_HandleTypeDef bad;

    __HAL_CLEAR_STRUCT(&hsmu_dev);
    hsmu_dev.Instance = SMU;

    g1_state_before = (uint32)HAL_SMU_GetState(&hsmu_dev);
    g1_init_ret     = (uint32)HAL_SMU_Init(&hsmu_dev);
    g1_state_after  = (uint32)HAL_SMU_GetState(&hsmu_dev);
    g1_error_after  = HAL_SMU_GetError(&hsmu_dev);

    /* A second Init on a ready handle must not run the low level init again */
    g1_init_again_ret = (uint32)HAL_SMU_Init(&hsmu_dev);

    /* Rejected handles: NULL and a foreign instance */
    g1_init_null_ret = (uint32)HAL_SMU_Init(NULL_PTR);

    __HAL_CLEAR_STRUCT(&bad);
    bad.Instance     = (SMU_TypeDef *)0x40000000U;
    g1_init_bad_ret  = (uint32)HAL_SMU_Init(&bad);

    g1_state_null = (uint32)HAL_SMU_GetState(NULL_PTR);
    g1_error_null = HAL_SMU_GetError(NULL_PTR);
}

/**
 * @brief  Group 1: judge and print the results collected by Group1_Execute().
 * @param  None
 * @retval None
 */
static void Group1_Report(void)
{
    printf("--- group 1: HAL_SMU_Init / GetState / GetError ---\r\n");
    g_failures += Chk("state before Init is RESET",
                      (uint32)HAL_SMU_STATE_RESET, g1_state_before);
    g_failures += Chk("HAL_SMU_Init returns HAL_OK",
                      (uint32)HAL_OK, g1_init_ret);
    g_failures += Chk("state after Init is READY",
                      (uint32)HAL_SMU_STATE_READY, g1_state_after);
    g_failures += Chk("error code is NONE after Init",
                      (uint32)HAL_SMU_ERROR_NONE, g1_error_after);
    g_failures += Chk("MspInit was called once", 1U, g_msp_init_cnt);
    g_failures += Chk("MspInit saw the RESET state",
                      (uint32)HAL_SMU_STATE_RESET, g_msp_init_state);
    g_failures += Chk("MspInit saw an unlocked handle",
                      (uint32)HAL_UNLOCKED, g_msp_init_lock);
    g_failures += Chk("HAL_SMU_Init on a ready handle returns HAL_OK",
                      (uint32)HAL_OK, g1_init_again_ret);
    g_failures += Chk("MspInit is not called again", 1U, g_msp_init_cnt);
    g_failures += Chk("HAL_SMU_Init(NULL) returns HAL_ERROR",
                      (uint32)HAL_ERROR, g1_init_null_ret);
    g_failures += Chk("HAL_SMU_Init(bad instance) returns HAL_ERROR",
                      (uint32)HAL_ERROR, g1_init_bad_ret);
    Info("GetState(NULL) =", g1_state_null);
    Info("GetError(NULL) =", g1_error_null);
}

/**
 * @brief  Groups 9 / 10: de-initialize the SMU and probe the state gate.
 * @note   Nothing is printed here: HAL_SMU_DeInit() moves the system clock
 *         back to the FIRC, so the console baud rate is stale until the
 *         caller restores the tree and re-initializes the console.
 * @param  None
 * @retval None
 */
static void Group9_Execute(void)
{
    SMU_ClockInitTypeDef clk;
    SMU_OscInitTypeDef   osc;

    g9_deinit_ret  = (uint32)HAL_SMU_DeInit(&hsmu_dev, SMU_TIMEOUT_DEFAULT);
    g9_state_after = (uint32)HAL_SMU_GetState(&hsmu_dev);

    /* The clock tree is back on the FIRC after the de-initialization */
    g9_sysclk_after_deinit = HAL_SMU_GetSysClockFreq();

    /* State gate: every configuration call must be refused in RESET */
    __HAL_CLEAR_STRUCT(&clk);
    clk.Size           = sizeof(clk);
    clk.Version        = SMU_CLOCK_INIT_VERSION;
    clk.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV1;
    clk.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV1;
    clk.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV1;
    clk.CANX2CLKDiv    = SMU_CANX2CLK_DIV1;
    g9_clock_ret = (uint32)HAL_SMU_ClockConfig(&hsmu_dev, &clk);

    __HAL_CLEAR_STRUCT(&osc);
    osc.Size                 = sizeof(osc);
    osc.Version              = SMU_OSC_INIT_VERSION;
    osc.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    osc.FIRCState            = SMU_FIRC_ON;
    osc.FIRCCalibrationValue = 0x00U;
    osc.PLL.Size             = sizeof(osc.PLL);
    osc.PLL.Version          = SMU_PLL_INIT_VERSION;
    osc.PLL.PLLState         = SMU_PLL_ON;
    osc.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    osc.PLL.PLLDivR          = STD_PLL_DIV_R;
    osc.PLL.PLLDivQ          = STD_PLL_DIV_Q;
    osc.PLL.PLLDivN          = STD_PLL_DIV_N;
    osc.PLL.PLLDivF          = STD_PLL_DIV_F;
    osc.SYSCLKSelect         = SMU_SYSCLKSOURCE_FIRC;
    g9_osc_ret = (uint32)HAL_SMU_OscConfig(&hsmu_dev, &osc, SMU_TIMEOUT_DEFAULT);

    /* The refused configuration calls must not have touched the clock output */
    g9_mco_before = (SMU->OTHCFGR & SMU_OTHCFGR_CLKOUTMUX) >> SMU_OTHCFGR_CLKOUTMUX_Pos;
    HAL_SMU_MCOConfig(&hsmu_dev, SMU_CLKOUTMUX_SIRC);
    g9_mco_after  = (SMU->OTHCFGR & SMU_OTHCFGR_CLKOUTMUX) >> SMU_OTHCFGR_CLKOUTMUX_Pos;

    g9_init_null_ret   = (uint32)HAL_SMU_Init(NULL_PTR);
    g9_deinit_null_ret = (uint32)HAL_SMU_DeInit(NULL_PTR, SMU_TIMEOUT_DEFAULT);
}

/**
 * @brief  Groups 9 / 10: judge and print the collected results.
 * @param  None
 * @retval None
 */
static void Group9_Report(void)
{
    printf("--- group 9 / 10 results ---\r\n");
    g_failures += Chk("HAL_SMU_DeInit returns HAL_OK",
                      (uint32)HAL_OK, g9_deinit_ret);
    g_failures += Chk("state after DeInit is RESET",
                      (uint32)HAL_SMU_STATE_RESET, g9_state_after);
    g_failures += Chk("MspDeInit was called once", 1U, g_msp_deinit_cnt);
    g_failures += Chk("MspDeInit saw the RESET state",
                      (uint32)HAL_SMU_STATE_RESET, g_msp_deinit_state);
    g_failures += Chk("system clock after DeInit is the FIRC",
                      (uint32)FIRC_VALUE, g9_sysclk_after_deinit);
    g_failures += Chk("ClockConfig on a RESET handle returns HAL_ERROR",
                      (uint32)HAL_ERROR, g9_clock_ret);
    g_failures += Chk("OscConfig on a RESET handle returns HAL_ERROR",
                      (uint32)HAL_ERROR, g9_osc_ret);
    g_failures += Chk("MCOConfig on a RESET handle does not change the register",
                      g9_mco_before, g9_mco_after);
    g_failures += Chk("HAL_SMU_Init(NULL) returns HAL_ERROR",
                      (uint32)HAL_ERROR, g9_init_null_ret);
    g_failures += Chk("HAL_SMU_DeInit(NULL) returns HAL_ERROR",
                      (uint32)HAL_ERROR, g9_deinit_null_ret);
    g_failures += Chk("HAL_SMU_Init after DeInit returns HAL_OK",
                      (uint32)HAL_OK, g9_reinit_ret);
    g_failures += Chk("MspInit ran again after DeInit", 2U, g_msp_init_cnt);
}

/**
 * @brief  Print one check and return the number of failures it contributes.
 * @param  name: check description.
 * @param  expect: expected value.
 * @param  actual: value read back.
 * @retval uint32: 0 when the check passed, 1 otherwise.
 */
static uint32 Chk(const char *name, uint32 expect, uint32 actual)
{
    uint32 fail = 0U;

    if (expect == actual)
    {
        printf("  [PASS] %s : expect %u, read %u\r\n",
               name, PRINT_U32(expect), PRINT_U32(actual));
    }
    else
    {
        printf("  [FAIL] %s : expect %u, read %u\r\n",
               name, PRINT_U32(expect), PRINT_U32(actual));
        fail = 1U;
    }

    return fail;
}

/**
 * @brief  Print a value without judging it.
 * @note   Used for flag values that depend on the start-up source and for
 *         write-1-to-clear bits: they are recorded, not judged.
 * @param  name: label.
 * @param  value: value to print.
 * @retval None
 */
static void Info(const char *name, uint32 value)
{
    printf("  [info] %s %u\r\n", name, PRINT_U32(value));
}

/**
 * @brief  Check that a value lies inside an inclusive range.
 * @param  name: check description.
 * @param  value: value to check.
 * @param  low: lowest accepted value.
 * @param  high: highest accepted value.
 * @retval uint32: 0 when the check passed, 1 otherwise.
 */
static uint32 ChkRange(const char *name, uint32 value, uint32 low, uint32 high)
{
    uint32 fail = 0U;

    if ((value >= low) && (value <= high))
    {
        printf("  [PASS] %s : %u is inside [%u, %u]\r\n",
               name, PRINT_U32(value), PRINT_U32(low), PRINT_U32(high));
    }
    else
    {
        printf("  [FAIL] %s : %u is outside [%u, %u]\r\n",
               name, PRINT_U32(value), PRINT_U32(low), PRINT_U32(high));
        fail = 1U;
    }

    return fail;
}

/**
 * @brief  Low level initialization callback of the SMU driver (weak override).
 * @note   The SMU has no peripheral clock gate and no interrupt, so the
 *         callback only records that it was reached and the handle state it
 *         observed: the driver must call it before taking the handle lock and
 *         only while the handle is in the RESET state (MSP-04 / LOCK-06).
 * @param  hsmu: SMU handle.
 * @retval None
 */
void HAL_SMU_MspInit(HAL_SMU_HandleTypeDef *hsmu)
{
    if (hsmu == &hsmu_dev)
    {
        g_msp_init_cnt++;
        g_msp_init_state = (uint32)hsmu->State;
        g_msp_init_lock  = (uint32)hsmu->Lock;
    }
}

/**
 * @brief  Low level de-initialization callback of the SMU driver (weak
 *         override): counts the calls and records the handle state.
 * @param  hsmu: SMU handle.
 * @retval None
 */
void HAL_SMU_MspDeInit(HAL_SMU_HandleTypeDef *hsmu)
{
    if (hsmu == &hsmu_dev)
    {
        g_msp_deinit_cnt++;
        g_msp_deinit_state = (uint32)hsmu->State;
    }
}

/*****END OF FILE*****/
