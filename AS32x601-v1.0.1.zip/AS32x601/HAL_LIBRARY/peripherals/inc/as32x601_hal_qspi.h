/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_qspi.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.3
 * Date:   2026/09/18
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.1     review pass: document the
 *                                                       DataMode requirement of
 *                                                       AutoPolling / MemoryMapped
 *                                                       and the CCR.FMODE reset of
 *                                                       Abort (source changes are in
 *                                                       as32x601_hal_qspi.c V1.1)
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.2     review pass: synchronize the
 *                                                       transfer trigger point notes
 *                                                       (AR write starts the indirect
 *                                                       read, DR write starts the
 *                                                       indirect write) with the
 *                                                       verified source changes
 *     ANSILIC APPLICATION GROUP  2026/09/18     1.3     align with the source file V1.3: apply the
 *                                                       resource lock and RTOS
 *                                                       rules - export the
 *                                                       QSPI_LockHandle() /
 *                                                       QSPI_UnlockHandle() pair
 *                                                       (Timeout parameter and
 *                                                       uncreated-mutex guard,
 *                                                       RTOS-11) and the
 *                                                       QSPI_CheckState() state
 *                                                       gate with the recoverable
 *                                                       error state
 *                                                       (ARCH-CONST-09,
 *                                                       STATE-04 / STATE-06) in
 *                                                       the shared internal
 *                                                       section, document the
 *                                                       lock taken by
 *                                                       HAL_QSPI_Abort() and its
 *                                                       exemption from the state
 *                                                       gate, document the
 *                                                       LOCK-06 MSP callback
 *                                                       ordering and the first
 *                                                       initialization only call
 *                                                       of MspInit (MSP-04),
 *                                                       document the run time
 *                                                       configuration check of
 *                                                       HAL_QSPI_Init(), add the
 *                                                       bit-encoded state note
 *                                                       and drop the unused
 *                                                       HAL_QSPI_STATE_ABORT and
 *                                                       HAL_QSPI_ERROR_TRANSFER
 *                                                       definitions
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Quad Serial Peripheral
 *                  Interface (QSPI) of the AS32x601:
 *                  - Initialization and de-initialization: HAL_QSPI_Init /
 *                    HAL_QSPI_DeInit, configuration structure handling;
 *                  - Command sequences: instruction / address / alternate
 *                    bytes / dummy cycles / data phases, each phase on
 *                    1, 2 or 4 lines;
 *                  - Polling IO operations: transmit / receive with timeout
 *                    (up to 4 bytes per transfer in polling mode);
 *                  - Auto-polling functional mode: poll a status register
 *                    of the attached device until the masked value matches;
 *                  - Memory-mapped functional mode: read the attached
 *                    device through the AHB mapped window (QSPI_FLASH_BASE);
 *                  - Low level register access: enable / disable, abort
 *                    request, flags, FIFO level, address / alternate bytes /
 *                    data / data length / timeout period / polling registers.
 *
 *                  The command sequences of the attached device (write
 *                  enable, erase, program, status register access, ...) are
 *                  out of the scope of this driver: they are built by the
 *                  application from the low level functions and the command
 *                  sequence API of this module.
 *                  Concurrency follows the architecture resource lock rules
 *                  (section 13): every API that changes the handle state is
 *                  serialized through the QSPI_LockHandle() /
 *                  QSPI_UnlockHandle() pair (bare-metal lock flag, or an RTOS
 *                  mutex with a bounded wait), the QSPI_CheckState() gate
 *                  rejects a new operation while another one is ongoing and
 *                  accepts the recoverable error state so that a failed
 *                  operation can be retried without a DeInit / Init round
 *                  trip (STATE-06), the operation parameters are validated
 *                  before the lock is taken, and the low level register
 *                  access functions stay lock-free so that they remain usable
 *                  from an interrupt service routine (LOCK-04 / RTOS-12).
 * @complexity  Medium
 *              Blocking (polling) only, state machine, no IT/DMA.
 */
#ifndef __AS32X601_HAL_QSPI_H
#define __AS32X601_HAL_QSPI_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "as32x601.h"               /* QSPI_TypeDef, QSPI register bits        */
#include "as32x601_hal_def.h"       /* HAL_StatusTypeDef, HAL_LockTypeDef      */

/* Exported constants --------------------------------------------------------*/

/**
 * @brief QSPI HAL driver module version.
 * @note  0x0100U = V1.0. Bumped only on breaking API changes (architecture
 *        spec COMPAT-13/14/15).
 */
#define __HAL_QSPI_MODULE_VERSION  0x0100U

/* Exported types ------------------------------------------------------------*/

/** @defgroup QSPI_Exported_Types QSPI Exported Types
  * @{
  */

/**
 * @brief HAL QSPI state structures definition.
 * @note  Bit-encoded state values: bit 1 is the "operation ongoing" marker
 *        shared by every busy state (BUSY_INDIRECT_TX / _RX, BUSY_AUTO_POLLING
 *        and BUSY_MEM_MAPPED all set it), so that a single test
 *        (HAL_QSPI_STATE_IS_BUSY) covers all of them; bit 2 is the error
 *        marker. Any future state value shall keep bit 1 clear unless it does
 *        describe an ongoing operation.
 * @note  HAL_QSPI_STATE_ERROR is recoverable: a rejected or failed operation
 *        leaves the handle in that state and the next command / transfer is
 *        accepted directly, without a DeInit / Init round trip (STATE-06).
 */
typedef enum
{
    HAL_QSPI_STATE_RESET             = 0x00U, /*!< Peripheral not initialized                  */
    HAL_QSPI_STATE_READY             = 0x01U, /*!< Peripheral initialized and ready            */
    HAL_QSPI_STATE_BUSY              = 0x02U, /*!< An internal process is ongoing              */
    HAL_QSPI_STATE_BUSY_INDIRECT_TX  = 0x12U, /*!< Data transmission is ongoing                */
    HAL_QSPI_STATE_BUSY_INDIRECT_RX  = 0x22U, /*!< Data reception is ongoing                   */
    HAL_QSPI_STATE_BUSY_AUTO_POLLING = 0x42U, /*!< Automatic polling is ongoing                */
    HAL_QSPI_STATE_BUSY_MEM_MAPPED   = 0x82U, /*!< Memory-mapped mode is ongoing               */
    HAL_QSPI_STATE_ERROR             = 0x04U  /*!< QSPI error state (recoverable)              */
} HAL_QSPI_StateTypeDef;

/**
 * @brief  Tell whether a state value describes an ongoing operation.
 * @note   Every busy state carries bit 1 (see HAL_QSPI_StateTypeDef).
 */
#define HAL_QSPI_STATE_IS_BUSY(__STATE__) (((__STATE__) & 0x02U) != 0U)

/**
 * @brief QSPI configuration structure definition.
 * @note  The field values directly map to the QSPI control register (CR)
 *        of the AS32x601: ClockPrescaler and ChipSelectHighTime are the
 *        PRESCALER / CSHT fields, ClockMode is the CKMODE bit.
 */
typedef struct
{
    uint32 Size;                /*!< sizeof(QSPI_InitTypeDef), set by the user
                                     after clearing the structure */
    uint32 Version;             /*!< Structure semantic version: @ref QSPI_INIT_VERSION
                                     (QSPI_INIT_V1 = 0x0100U) */
    uint32 ClockPrescaler;      /*!< Clock prescaler: division factor 2..256
                                     (the QSPI clock = AXI clock / value).
                                     The application shall set a divider that
                                     keeps the QSPI clock below the maximum
                                     clock frequency of the attached device. */
    uint32 ChipSelectHighTime;  /*!< nCS high time between two commands:
                                     QSPI_CS_HIGH_TIME_1_CYCLE .. _8_CYCLE  */
    uint32 ClockMode;           /*!< CLK idle level between two commands:
                                     QSPI_CLOCK_MODE_0 (low) or
                                     QSPI_CLOCK_MODE_3 (high)              */
    uint32 Reserved[2];         /*!< Reserved for future extension (must be 0) */
} QSPI_InitTypeDef;

/**
 * @brief QSPI init structure version macros.
 * @note  QSPI_INIT_V1 is the current version. Future versions must be
 *        appended after the existing fields (architecture spec section 22.5).
 */
#define QSPI_INIT_V1  0x0100U   /*!< QSPI Init structure version V1.0 */
#define QSPI_INIT_VERSION  QSPI_INIT_V1   /*!< Current QSPI Init structure version */

/**
 * @brief QSPI command sequence configuration structure definition.
 * @note  The mode and size fields are pre-positioned in the CCR register
 *        layout and are OR-ed together by the driver to build the CCR
 *        value; DummyCycles is a raw cycle count (0..31).
 */
typedef struct
{
    uint32 Instruction;         /*!< Instruction opcode, 8 bits (0x00..0xFF)      */
    uint32 Address;             /*!< Address value (1..4 bytes, used when
                                     AddressMode != QSPI_ADDRESS_NONE)           */
    uint32 AlternateBytes;      /*!< Alternate bytes value (1..4 bytes, used when
                                     AlternateByteMode != QSPI_ALTERNATE_BYTES_NONE) */
    uint32 AddressSize;         /*!< Address length: QSPI_ADDRESS_8/16/24/32_BITS */
    uint32 AlternateBytesSize;  /*!< Alternate bytes length:
                                     QSPI_ALTERNATE_BYTES_8/16/24/32_BITS       */
    uint32 DummyCycles;         /*!< Number of dummy cycles (0..31)              */
    uint32 InstructionMode;     /*!< Instruction phase width:
                                     QSPI_INSTRUCTION_NONE / _1_LINE / _2_LINES / _4_LINES */
    uint32 AddressMode;         /*!< Address phase width:
                                     QSPI_ADDRESS_NONE / _1_LINE / _2_LINES / _4_LINES */
    uint32 AlternateByteMode;   /*!< Alternate bytes phase width:
                                     QSPI_ALTERNATE_BYTES_NONE / _1_LINE / _2_LINES / _4_LINES */
    uint32 DataMode;            /*!< Data phase width:
                                     QSPI_DATA_NONE / _1_LINE / _2_LINES / _4_LINES */
    uint32 NbData;              /*!< Number of data bytes to transfer (1..4 in
                                     polling mode, see HAL_QSPI_Command)         */
} QSPI_CommandTypeDef;

/**
 * @brief QSPI auto-polling configuration structure definition.
 * @note  The polling stop condition is fixed by the hardware: the polling
 *        stops as soon as the masked received status equals the match
 *        value (all masked bits must match, i.e. AND semantics); the
 *        PMF flag is set and HAL_QSPI_AutoPolling() returns.
 */
typedef struct
{
    uint32 Match;               /*!< Value compared with the masked received
                                     status (0x00000000..0xFFFFFFFF)            */
    uint32 Mask;                /*!< Mask applied to the received status
                                     (0x00000000..0xFFFFFFFF)                   */
    uint32 Interval;            /*!< Polling interval, in QSPI clock cycles
                                     (0x0000..0xFFFF)                           */
    uint32 StatusBytesSize;     /*!< Number of status bytes received at each
                                     polling step (1..4)                        */
} QSPI_AutoPollingTypeDef;

/**
 * @brief QSPI memory-mapped configuration structure definition.
 * @note  This device has no dedicated timeout-counter enable bit: the
 *        nCS release timeout is enabled by writing a non-zero period to
 *        the TOR register, and disabled by writing 0. TimeOutActivation
 *        selects one of the two behaviors.
 */
typedef struct
{
    uint32 TimeOutPeriod;       /*!< nCS release timeout period, in QSPI clock
                                     cycles (0x0000..0xFFFF)                    */
    uint32 TimeOutActivation;   /*!< QSPI_TIMEOUT_COUNTER_DISABLE / ENABLE      */
} QSPI_MemoryMappedTypeDef;

/**
 * @brief QSPI handle structure definition.
 * @note  Field order follows the architecture spec HANDLE-02:
 *        Instance -> Init -> Lock -> State -> ErrorCode -> module fields.
 *        The transfer counter fields modified by the DMA callbacks are
 *        declared as __IO (HANDLE-03).
 */
typedef struct __HAL_QSPI_HandleTypeDef
{
    QSPI_TypeDef              *Instance;      /*!< QSPI registers base address      */
    QSPI_InitTypeDef          Init;           /*!< QSPI communication parameters    */
    HAL_LockTypeDef           Lock;           /*!< Locking object                   */
    __IO HAL_QSPI_StateTypeDef State;         /*!< QSPI communication state         */
    __IO uint32               ErrorCode;      /*!< QSPI error code                  */
    uint8                     *pTxBuffPtr;    /*!< Pointer to QSPI Tx buffer        */
    __IO uint32               TxXferSize;     /*!< QSPI Tx transfer size (bytes)    */
    __IO uint32               TxXferCount;    /*!< QSPI Tx transfer counter         */
    uint8                     *pRxBuffPtr;    /*!< Pointer to QSPI Rx buffer        */
    __IO uint32               RxXferSize;     /*!< QSPI Rx transfer size (bytes)    */
    __IO uint32               RxXferCount;    /*!< QSPI Rx transfer counter         */
    uint32                    Timeout;        /*!< Default timeout used by the
                                                   internal waits (ms)            */
#if (USE_RTOS == 1)
    HAL_MutexTypeDef          LockMutex;      /*!< RTOS mutex handle (created by the
                                                   user porting layer, e.g. in
                                                   HAL_QSPI_MspInit)              */
#endif /* USE_RTOS */
} HAL_QSPI_HandleTypeDef;

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @defgroup QSPI_Exported_Constants QSPI Exported Constants
  * @{
  */

/** @defgroup QSPI_Error_Code QSPI Error Code
  * @{
  */
#define HAL_QSPI_ERROR_NONE         ((uint32)0x00000000U) /*!< No error             */
#define HAL_QSPI_ERROR_TIMEOUT      ((uint32)0x00000001U) /*!< Flag wait timeout    */
#define HAL_QSPI_ERROR_INVALID_PARAM ((uint32)0x00000004U) /*!< Invalid parameter   */
/**
  * @}
  */

/** @defgroup QSPI_Default_Timeout QSPI Default Timeout
  * @{
  */
#define HAL_QSPI_TIMEOUT_DEFAULT_VALUE  ((uint32)5000U)   /*!< Default internal wait
                                                               timeout, in ms     */
/**
  * @}
  */

/** @defgroup QSPI_Clock_Mode QSPI Clock Mode
  * @{
  */
#define QSPI_CLOCK_MODE_0       ((uint32)0x00000000U)  /*!< CLK stays low while nCS is high */
#define QSPI_CLOCK_MODE_3       ((uint32)QSPI_CR_CKMODE) /*!< CLK stays high while nCS is high */
/**
  * @}
  */

/** @defgroup QSPI_Chip_Select_High_Time QSPI Chip Select High Time
  * @{
  */
#define QSPI_CS_HIGH_TIME_1_CYCLE ((uint32)0x00000000U)                       /*!< nCS high for 1 cycle */
#define QSPI_CS_HIGH_TIME_2_CYCLE ((uint32)QSPI_CR_CSHT_0)                    /*!< nCS high for 2 cycles */
#define QSPI_CS_HIGH_TIME_3_CYCLE ((uint32)QSPI_CR_CSHT_1)                    /*!< nCS high for 3 cycles */
#define QSPI_CS_HIGH_TIME_4_CYCLE ((uint32)(QSPI_CR_CSHT_0 | QSPI_CR_CSHT_1)) /*!< nCS high for 4 cycles */
#define QSPI_CS_HIGH_TIME_5_CYCLE ((uint32)QSPI_CR_CSHT_2)                    /*!< nCS high for 5 cycles */
#define QSPI_CS_HIGH_TIME_6_CYCLE ((uint32)(QSPI_CR_CSHT_0 | QSPI_CR_CSHT_2)) /*!< nCS high for 6 cycles */
#define QSPI_CS_HIGH_TIME_7_CYCLE ((uint32)(QSPI_CR_CSHT_1 | QSPI_CR_CSHT_2)) /*!< nCS high for 7 cycles */
#define QSPI_CS_HIGH_TIME_8_CYCLE ((uint32)(QSPI_CR_CSHT_0 | QSPI_CR_CSHT_1 | QSPI_CR_CSHT_2)) /*!< nCS high for 8 cycles */
/**
  * @}
  */

/** @defgroup QSPI_Instruction_Mode QSPI Instruction Mode
  * @{
  */
#define QSPI_INSTRUCTION_NONE    ((uint32)0x00000000U) /*!< No instruction phase  */
#define QSPI_INSTRUCTION_1_LINE  ((uint32)QSPI_CCR_IMODE_0) /*!< Instruction on 1 line */
#define QSPI_INSTRUCTION_2_LINES ((uint32)QSPI_CCR_IMODE_1) /*!< Instruction on 2 lines */
#define QSPI_INSTRUCTION_4_LINES ((uint32)(QSPI_CCR_IMODE_0 | QSPI_CCR_IMODE_1)) /*!< Instruction on 4 lines */
/**
  * @}
  */

/** @defgroup QSPI_Address_Mode QSPI Address Mode
  * @{
  */
#define QSPI_ADDRESS_NONE    ((uint32)0x00000000U) /*!< No address phase     */
#define QSPI_ADDRESS_1_LINE  ((uint32)QSPI_CCR_ADMODE_0) /*!< Address on 1 line */
#define QSPI_ADDRESS_2_LINES ((uint32)QSPI_CCR_ADMODE_1) /*!< Address on 2 lines */
#define QSPI_ADDRESS_4_LINES ((uint32)(QSPI_CCR_ADMODE_0 | QSPI_CCR_ADMODE_1)) /*!< Address on 4 lines */
/**
  * @}
  */

/** @defgroup QSPI_Alternate_Bytes_Mode QSPI Alternate Bytes Mode
  * @{
  */
#define QSPI_ALTERNATE_BYTES_NONE    ((uint32)0x00000000U) /*!< No alternate bytes phase */
#define QSPI_ALTERNATE_BYTES_1_LINE  ((uint32)QSPI_CCR_ABMODE_0) /*!< Alternate bytes on 1 line */
#define QSPI_ALTERNATE_BYTES_2_LINES ((uint32)QSPI_CCR_ABMODE_1) /*!< Alternate bytes on 2 lines */
#define QSPI_ALTERNATE_BYTES_4_LINES ((uint32)(QSPI_CCR_ABMODE_0 | QSPI_CCR_ABMODE_1)) /*!< Alternate bytes on 4 lines */
/**
  * @}
  */

/** @defgroup QSPI_Data_Mode QSPI Data Mode
  * @{
  */
#define QSPI_DATA_NONE    ((uint32)0x00000000U) /*!< No data phase         */
#define QSPI_DATA_1_LINE  ((uint32)QSPI_CCR_DMODE_0) /*!< Data on 1 line    */
#define QSPI_DATA_2_LINES ((uint32)QSPI_CCR_DMODE_1) /*!< Data on 2 lines   */
#define QSPI_DATA_4_LINES ((uint32)(QSPI_CCR_DMODE_0 | QSPI_CCR_DMODE_1)) /*!< Data on 4 lines */
/**
  * @}
  */

/** @defgroup QSPI_Address_Size QSPI Address Size
  * @{
  */
#define QSPI_ADDRESS_8_BITS  ((uint32)0x00000000U) /*!< 8-bit address  */
#define QSPI_ADDRESS_16_BITS ((uint32)QSPI_CCR_ADSIZE_0) /*!< 16-bit address */
#define QSPI_ADDRESS_24_BITS ((uint32)QSPI_CCR_ADSIZE_1) /*!< 24-bit address */
#define QSPI_ADDRESS_32_BITS ((uint32)(QSPI_CCR_ADSIZE_0 | QSPI_CCR_ADSIZE_1)) /*!< 32-bit address */
/**
  * @}
  */

/** @defgroup QSPI_Alternate_Bytes_Size QSPI Alternate Bytes Size
  * @{
  */
#define QSPI_ALTERNATE_BYTES_8_BITS  ((uint32)0x00000000U) /*!< 8-bit alternate bytes  */
#define QSPI_ALTERNATE_BYTES_16_BITS ((uint32)QSPI_CCR_ABSIZE_0) /*!< 16-bit alternate bytes */
#define QSPI_ALTERNATE_BYTES_24_BITS ((uint32)QSPI_CCR_ABSIZE_1) /*!< 24-bit alternate bytes */
#define QSPI_ALTERNATE_BYTES_32_BITS ((uint32)(QSPI_CCR_ABSIZE_0 | QSPI_CCR_ABSIZE_1)) /*!< 32-bit alternate bytes */
/**
  * @}
  */

/** @defgroup QSPI_Timeout_Counter QSPI Memory-Mapped Timeout Counter
  * @{
  */
#define QSPI_TIMEOUT_COUNTER_DISABLE ((uint32)0x00000000U) /*!< Timeout counter disabled (TOR = 0) */
#define QSPI_TIMEOUT_COUNTER_ENABLE  ((uint32)0x00000001U) /*!< Timeout counter enabled (TOR = period) */
/**
  * @}
  */

/** @defgroup QSPI_Flags QSPI Status Flags
  * @note  The values are the SR register bit positions.
  * @{
  */
#define QSPI_FLAG_BUSY  ((uint32)QSPI_SR_BUSY)  /*!< Busy flag: an operation is ongoing        */
#define QSPI_FLAG_TCF   ((uint32)QSPI_SR_TCF)   /*!< Transfer complete flag                    */
#define QSPI_FLAG_TOF   ((uint32)QSPI_SR_TOF)   /*!< Timeout flag (memory-mapped mode)         */
#define QSPI_FLAG_PMF   ((uint32)QSPI_SR_PMF)   /*!< Polling match flag (auto-polling mode)    */
/**
  * @}
  */

/** @defgroup QSPI_Flag_Clear QSPI Flag Clear Values
  * @note  The values are the FCR register write values (write 1 to clear).
  * @{
  */
#define QSPI_CLEAR_CTCF ((uint32)QSPI_FCR_CTCF) /*!< Clear the transfer complete flag          */
#define QSPI_CLEAR_CTOF ((uint32)QSPI_FCR_CTOF) /*!< Clear the timeout flag                    */
#define QSPI_CLEAR_CPMF ((uint32)QSPI_FCR_CPMF) /*!< Clear the polling match flag              */
/**
  * @}
  */

/** @defgroup QSPI_Enable_Value QSPI Enable Value
  * @{
  */
#define QSPI_ENABLE     1U       /*!< Enable the QSPI peripheral / function     */
#define QSPI_DISABLE    0U       /*!< Disable the QSPI peripheral / function    */
/**
  * @}
  */

/**
  * @}
  */

/* Exported macros ------------------------------------------------------------*/

/** @defgroup QSPI_Exported_Macros QSPI Exported Macros
  * @{
  */

/**
 * @brief  Reset the handle State field.
 * @note   Must be used before passing a local handle to HAL_QSPI_Init() the
 *         first time, so that the low level initialization (MspInit) is
 *         always executed.
 */
#define __HAL_QSPI_RESET_HANDLE_STATE(__HANDLE__) ((__HANDLE__)->State = 0U)

/**
 * @brief  Enable the QSPI peripheral.
 * @note   The macros below directly access the peripheral registers and do
 *         not check the handle: the caller must guarantee a valid handle.
 */
#define __HAL_QSPI_ENABLE(__HANDLE__)             ((__HANDLE__)->Instance->CR |= (QSPI_CR_EN))

/**
 * @brief  Disable the QSPI peripheral.
 */
#define __HAL_QSPI_DISABLE(__HANDLE__)            ((__HANDLE__)->Instance->CR &= ~(QSPI_CR_EN))

/**
 * @brief  Check whether a QSPI status flag is set.
 * @param  __FLAG__: QSPI_FLAG_xxx (SR bit position).
 * @retval 1 if the flag is set, 0 otherwise.
 */
#define __HAL_QSPI_GET_FLAG(__HANDLE__, __FLAG__) (((__HANDLE__)->Instance->SR & (__FLAG__)) != 0U)

/**
 * @brief  Clear a QSPI status flag.
 * @param  __FLAG__: QSPI_CLEAR_xxx (FCR write value).
 */
#define __HAL_QSPI_CLEAR_FLAG(__HANDLE__, __FLAG__) ((__HANDLE__)->Instance->FCR = (__FLAG__))

/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/

/** @addtogroup QSPI_Exported_Functions
  * @{
  */

/** @addtogroup QSPI_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Fills each QSPI_InitStruct member with its default value (NON-BLOCKING)
 *         (prescaler = 2, chip select high time = 7 cycles,
 *         clock mode 0).
 * @note   The default prescaler is the minimum valid value and therefore
 *         gives the fastest QSPI clock; the application shall raise it to
 *         respect the maximum clock frequency of the attached device.
 * @param  QSPI_InitStruct: pointer to a QSPI_InitTypeDef structure which
 *         will be initialized.
 * @retval None
 */
void HAL_QSPI_StructInit(QSPI_InitTypeDef *QSPI_InitStruct);

/**
 * @brief  Initializes the QSPI according to the specified parameters in the
 *         QSPI_InitStruct of the handle. (NON-BLOCKING)
 * @note   The QSPI clock gating and the pin multiplexing must be configured
 *         by the user in HAL_QSPI_MspInit() (the QSPI clock is enabled
 *         through the SMU bus clock configuration, e.g. with
 *         SMU_AB0CFGR_QSPIEN). HAL_QSPI_MspInit() runs only on the first
 *         initialization (while the handle state is HAL_QSPI_STATE_RESET) and
 *         is called before the handle lock is taken, so the callback may use
 *         other HAL APIs (MSP-04 / LOCK-06).
 * @note   The configuration values are re-checked at run time: a value outside
 *         its valid range makes the function return HAL_ERROR with the
 *         HAL_QSPI_ERROR_INVALID_PARAM error code, before the lock is taken
 *         and without changing the handle state.
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure that contains
 *         the configuration information for the specified QSPI module.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_QSPI_Init(HAL_QSPI_HandleTypeDef *hqspi);

/**
 * @brief  De-initializes the QSPI peripheral. (NON-BLOCKING)
 * @note   HAL_QSPI_MspDeInit() is called after the handle lock has been
 *         released, so the callback may use other HAL APIs (LOCK-06).
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_QSPI_DeInit(HAL_QSPI_HandleTypeDef *hqspi);

/**
 * @brief  Initializes the QSPI MSP. Weak empty function; the user implements
 *         the low level hardware initialization (QSPI clock enable through
 *         the SMU bus clock configuration, GPIO pin configuration).
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @retval None
 */
void HAL_QSPI_MspInit(HAL_QSPI_HandleTypeDef *hqspi);

/**
 * @brief  De-initializes the QSPI MSP. Weak empty function; the user
 *         implements the low level hardware de-initialization.
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @retval None
 */
void HAL_QSPI_MspDeInit(HAL_QSPI_HandleTypeDef *hqspi);

/**
  * @}
  */

/** @addtogroup QSPI_Exported_Functions_Group2 IO operation functions
  * @brief    Polling mode IO operations
  * @{
  */

/**
 * @brief  Sends a command sequence to the attached device in blocking mode. (BLOCKING)
 * @note   The command phases (instruction / address / alternate bytes /
 *         dummy cycles / data) are configured in the CCR register; writing
 *         the CCR starts the sequence.
 * @note   When the command has a data phase (DataMode != QSPI_DATA_NONE),
 *         the data bytes shall be transferred afterwards with
 *         HAL_QSPI_Transmit() (indirect write) or HAL_QSPI_Receive()
 *         (indirect read).
 * @note   In polling mode the data length (NbData) is limited to 4 bytes:
 *         a larger value makes the function return HAL_ERROR with the
 *         HAL_QSPI_ERROR_INVALID_PARAM error code.
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  cmd: pointer to a QSPI_CommandTypeDef structure that contains
 *         the command sequence configuration.
 * @param  Timeout: maximum waiting time in ms (HAL_MAX_DELAY for infinite).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_QSPI_Command(HAL_QSPI_HandleTypeDef *hqspi, QSPI_CommandTypeDef *cmd,
                                   uint32 Timeout);

/**
 * @brief  Transmits the data of an indirect write command in blocking mode. (BLOCKING)
 * @note   This function is used only in the indirect write mode, right after
 *         HAL_QSPI_Command() with a data phase; the write sequence itself is
 *         started by the DR push inside this function.
 * @note   The transfer size is read from the DLR register (DLR + 1) and is
 *         limited to 4 bytes in polling mode.
 * @note   The data bytes are packed little-endian into the FIFO word: the
 *         first byte of the buffer is the first byte transmitted.
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  pData: pointer to the data buffer to transmit.
 * @param  Timeout: maximum waiting time in ms (HAL_MAX_DELAY for infinite).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_QSPI_Transmit(HAL_QSPI_HandleTypeDef *hqspi, uint8 *pData, uint32 Timeout);

/**
 * @brief  Receives the data of an indirect read command in blocking mode. (BLOCKING)
 * @note   This function is used only in the indirect read mode, right after
 *         HAL_QSPI_Command() with a data phase: it switches the functional
 *         mode to indirect read and starts the read transfer by re-writing
 *         the address register (on this device the AR write starts the
 *         indirect read).
 * @note   The transfer size is read from the DLR register (DLR + 1) and is
 *         limited to 4 bytes in polling mode.
 * @note   The received bytes are unpacked little-endian from the FIFO word:
 *         the first byte received is stored at the first position of the
 *         buffer.
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  pData: pointer to the data buffer that will store the received data.
 * @param  Timeout: maximum waiting time in ms (HAL_MAX_DELAY for infinite).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_QSPI_Receive(HAL_QSPI_HandleTypeDef *hqspi, uint8 *pData, uint32 Timeout);

/**
 * @brief  Runs the auto-polling functional mode in blocking mode. (BLOCKING)
 * @note   This function is typically used to wait until the busy bit (WIP)
 *         of the attached device is cleared after an erase or program
 *         sequence: set Match to the expected status value, Mask to the
 *         bits to compare, Interval to the polling pace and
 *         StatusBytesSize to 1.
 * @note   A data phase is required (DataMode != QSPI_DATA_NONE): the
 *         controller receives the status byte(s) through the data lines;
 *         otherwise the function returns HAL_ERROR with the
 *         HAL_QSPI_ERROR_INVALID_PARAM error code.
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  cmd: pointer to a QSPI_CommandTypeDef structure that contains the
 *         command sequence configuration (the data length is overwritten by
 *         the status byte count).
 * @param  cfg: pointer to a QSPI_AutoPollingTypeDef structure that contains
 *         the polling configuration (match / mask / interval / size).
 * @param  Timeout: maximum waiting time in ms (HAL_MAX_DELAY for infinite).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_QSPI_AutoPolling(HAL_QSPI_HandleTypeDef *hqspi, QSPI_CommandTypeDef *cmd,
                                       QSPI_AutoPollingTypeDef *cfg,

                                       uint32 Timeout);

/**
 * @brief  Configures the memory-mapped functional mode. (NON-BLOCKING)
 * @note   After this function returns, the attached device is read through
 *         the AHB mapped window at QSPI_FLASH_BASE (0x10000000): any read
 *         in this window generates the configured read sequence. The
 *         instruction and data phases must be enabled (InstructionMode and
 *         DataMode != NONE), the address phase width selects how the AHB
 *         address is turned into a device address.
 * @note   The memory-mapped mode is a read-only window; write enable /
 *         erase / program sequences shall be issued before entering it.
 * @note   The handle state stays HAL_QSPI_STATE_BUSY_MEM_MAPPED until
 *         HAL_QSPI_Abort() is called.
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  cmd: pointer to a QSPI_CommandTypeDef structure that contains the
 *         read sequence configuration (NbData is ignored in this mode).
 * @param  cfg: pointer to a QSPI_MemoryMappedTypeDef structure that contains
 *         the nCS release timeout configuration.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_QSPI_MemoryMapped(HAL_QSPI_HandleTypeDef *hqspi, QSPI_CommandTypeDef *cmd,
                                        QSPI_MemoryMappedTypeDef *cfg);

/**
 * @brief  Aborts the current operation (indirect transfer, auto-polling or
 *         memory-mapped mode) in blocking mode. (BLOCKING)
 * @note   If no operation is ongoing, the function returns HAL_OK without
 *         any effect.
 * @note   This function takes the handle lock itself and is the only state
 *         changing API that is accepted while a busy state is set (the state
 *         gate of ARCH-CONST-09 allows Abort in every state). Exiting the
 *         memory-mapped mode is its typical use, since the mode is left
 *         running after HAL_QSPI_MemoryMapped() has returned.
 * @note   When another context holds the lock (for example a blocking transfer
 *         running in another task), the call waits for the lock according to
 *         the RTOS / bare-metal lock behavior and therefore aborts after that
 *         transfer has finished. To interrupt a running transfer from an
 *         interrupt service routine, use the lock-free
 *         HAL_QSPI_AbortRequest() to set the CR.ABORT bit instead.
 * @note   On success the CCR.FMODE field is reset to the indirect write
 *         default, so the next command configuration always starts from a
 *         known functional mode.
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_QSPI_Abort(HAL_QSPI_HandleTypeDef *hqspi);

/**
  * @}
  */

/** @addtogroup QSPI_Exported_Functions_Group3 Peripheral Control and State functions
  * @{
  */

/**
 * @brief  Returns the QSPI handle state. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @retval HAL_QSPI_StateTypeDef: the current handle state.
 */
HAL_QSPI_StateTypeDef HAL_QSPI_GetState(HAL_QSPI_HandleTypeDef *hqspi);

/**
 * @brief  Returns the QSPI error code. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @retval uint32: the QSPI error code (HAL_QSPI_ERROR_xxx).
 */
uint32 HAL_QSPI_GetError(HAL_QSPI_HandleTypeDef *hqspi);

/**
 * @brief  Sets the default timeout used by the internal waits of the driver. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  Timeout: timeout value in ms (HAL_MAX_DELAY for infinite).
 * @retval None
 */
void HAL_QSPI_SetTimeout(HAL_QSPI_HandleTypeDef *hqspi, uint32 Timeout);

/**
  * @}
  */

/** @addtogroup QSPI_Exported_Functions_Group4 Low level register functions
  * @{
  */

/**
 * @brief  Enables or disables the QSPI peripheral. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  NewState: QSPI_ENABLE or QSPI_DISABLE.
 * @retval None
 */
void HAL_QSPI_Cmd(HAL_QSPI_HandleTypeDef *hqspi, uint32 NewState);

/**
 * @brief  Sets or resets the QSPI abort request bit. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  NewState: QSPI_ENABLE (request an abort) or QSPI_DISABLE.
 * @retval None
 */
void HAL_QSPI_AbortRequest(HAL_QSPI_HandleTypeDef *hqspi, uint32 NewState);

/**
 * @brief  Checks whether a QSPI status flag is set. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  QSPI_FLAG: the flag to check (QSPI_FLAG_xxx).
 * @retval 1 if the flag is set, 0 otherwise.
 */
uint32 HAL_QSPI_GetFlagStatus(HAL_QSPI_HandleTypeDef *hqspi, uint32 QSPI_FLAG);

/**
 * @brief  Clears a QSPI status flag. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  QSPI_FLAG_CLEAR: the flag to clear (QSPI_CLEAR_xxx, FCR write value).
 * @retval None
 */
void HAL_QSPI_ClearFlag(HAL_QSPI_HandleTypeDef *hqspi, uint32 QSPI_FLAG_CLEAR);

/**
 * @brief  Returns the current FIFO level. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @retval uint32: the number of valid bytes currently stored in the FIFO.
 */
uint32 HAL_QSPI_GetFIFOLevel(HAL_QSPI_HandleTypeDef *hqspi);

/**
 * @brief  Sets the address sent to the attached device. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  QSPI_Addr: the address value (AR register).
 * @retval None
 */
void HAL_QSPI_SetAddr(HAL_QSPI_HandleTypeDef *hqspi, uint32 QSPI_Addr);

/**
 * @brief  Sets the alternate bytes sent to the attached device. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  QSPI_AltBytes: the alternate bytes value (ABR register).
 * @retval None
 */
void HAL_QSPI_SetAltBytes(HAL_QSPI_HandleTypeDef *hqspi, uint32 QSPI_AltBytes);

/**
 * @brief  Pushes one data word into the transmit FIFO. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  QSPI_Data: the data word to transmit (DR register).
 * @retval None
 */
void HAL_QSPI_SetData(HAL_QSPI_HandleTypeDef *hqspi, uint32 QSPI_Data);

/**
 * @brief  Reads one data word from the receive FIFO. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @retval uint32: the received data word (DR register).
 */
uint32 HAL_QSPI_ReadData(HAL_QSPI_HandleTypeDef *hqspi);

/**
 * @brief  Sets the number of bytes to transfer (DLR register). (NON-BLOCKING)
 * @note   In polling mode the value is limited to 3 (4 bytes), see the
 *         HAL_QSPI_Command documentation.
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  QSPI_DataLength: the data length, in bytes (0 = 1 byte).
 * @retval None
 */
void HAL_QSPI_SetDataLength(HAL_QSPI_HandleTypeDef *hqspi, uint32 QSPI_DataLength);

/**
 * @brief  Sets the nCS release timeout period used in memory-mapped mode. (NON-BLOCKING)
 * @note   Writing 0 disables the timeout counter, a non-zero value enables
 *         it (TOR register).
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  QSPI_Timeout: the timeout period in QSPI clock cycles (0..0xFFFF).
 * @retval None
 */
void HAL_QSPI_SetTimeoutPeriod(HAL_QSPI_HandleTypeDef *hqspi, uint32 QSPI_Timeout);

/**
 * @brief  Sets the polling interval of the auto-polling mode. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  QSPI_PollingInterval: the polling interval in QSPI clock cycles
 *         (0..0xFFFF, PIR register).
 * @retval None
 */
void HAL_QSPI_SetPollingInterval(HAL_QSPI_HandleTypeDef *hqspi, uint32 QSPI_PollingInterval);

/**
 * @brief  Sets the polling status match value of the auto-polling mode. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  QSPI_MatchData: the status match value (PSMAR register).
 * @retval None
 */
void HAL_QSPI_SetPollingStaMatch(HAL_QSPI_HandleTypeDef *hqspi, uint32 QSPI_MatchData);

/**
 * @brief  Sets the polling status mask of the auto-polling mode. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  QSPI_MatchDataMask: the status mask value (PSMKR register).
 * @retval None
 */
void HAL_QSPI_PollingStaMask(HAL_QSPI_HandleTypeDef *hqspi, uint32 QSPI_MatchDataMask);

/**
  * @}
  */

/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/

/** @defgroup QSPI_Private_Macros QSPI Private Macros
  * @{
  */

/**
 * @brief  Check that the QSPI peripheral instance is valid.
 */
#define IS_QSPI_ALL_INSTANCE(INSTANCE) ((INSTANCE) == QSPI)

/**
 * @brief  Check that the QSPI clock prescaler is a valid value (2..256).
 */
#define IS_QSPI_CLOCK_PRESCALER(PRESCALER) (((PRESCALER) >= 2U) && ((PRESCALER) <= 256U))

/**
 * @brief  Check that the chip select high time is a valid value.
 */
#define IS_QSPI_CS_HIGH_TIME(CSHT) (((CSHT) == QSPI_CS_HIGH_TIME_1_CYCLE) || \
                                    ((CSHT) == QSPI_CS_HIGH_TIME_2_CYCLE) || \
                                    ((CSHT) == QSPI_CS_HIGH_TIME_3_CYCLE) || \
                                    ((CSHT) == QSPI_CS_HIGH_TIME_4_CYCLE) || \
                                    ((CSHT) == QSPI_CS_HIGH_TIME_5_CYCLE) || \
                                    ((CSHT) == QSPI_CS_HIGH_TIME_6_CYCLE) || \
                                    ((CSHT) == QSPI_CS_HIGH_TIME_7_CYCLE) || \
                                    ((CSHT) == QSPI_CS_HIGH_TIME_8_CYCLE))

/**
 * @brief  Check that the clock mode is a valid value.
 */
#define IS_QSPI_CLOCK_MODE(MODE) (((MODE) == QSPI_CLOCK_MODE_0) || ((MODE) == QSPI_CLOCK_MODE_3))

/**
 * @brief  Check that the instruction opcode fits in 8 bits.
 */
#define IS_QSPI_INSTRUCTION(INST) ((INST) <= 0xFFU)

/**
 * @brief  Check that the instruction mode is a valid value.
 */
#define IS_QSPI_INSTRUCTION_MODE(MODE) (((MODE) == QSPI_INSTRUCTION_NONE)    || \
                                        ((MODE) == QSPI_INSTRUCTION_1_LINE)  || \
                                        ((MODE) == QSPI_INSTRUCTION_2_LINES) || \
                                        ((MODE) == QSPI_INSTRUCTION_4_LINES))

/**
 * @brief  Check that the address mode is a valid value.
 */
#define IS_QSPI_ADDRESS_MODE(MODE) (((MODE) == QSPI_ADDRESS_NONE)    || \
                                    ((MODE) == QSPI_ADDRESS_1_LINE)  || \
                                    ((MODE) == QSPI_ADDRESS_2_LINES) || \
                                    ((MODE) == QSPI_ADDRESS_4_LINES))

/**
 * @brief  Check that the address size is a valid value.
 */
#define IS_QSPI_ADDRESS_SIZE(SIZE) (((SIZE) == QSPI_ADDRESS_8_BITS)  || \
                                    ((SIZE) == QSPI_ADDRESS_16_BITS) || \
                                    ((SIZE) == QSPI_ADDRESS_24_BITS) || \
                                    ((SIZE) == QSPI_ADDRESS_32_BITS))

/**
 * @brief  Check that the alternate bytes mode is a valid value.
 */
#define IS_QSPI_ALTERNATE_BYTES_MODE(MODE) (((MODE) == QSPI_ALTERNATE_BYTES_NONE)    || \
                                            ((MODE) == QSPI_ALTERNATE_BYTES_1_LINE)  || \
                                            ((MODE) == QSPI_ALTERNATE_BYTES_2_LINES) || \
                                            ((MODE) == QSPI_ALTERNATE_BYTES_4_LINES))

/**
 * @brief  Check that the alternate bytes size is a valid value.
 */
#define IS_QSPI_ALTERNATE_BYTES_SIZE(SIZE) (((SIZE) == QSPI_ALTERNATE_BYTES_8_BITS)  || \
                                            ((SIZE) == QSPI_ALTERNATE_BYTES_16_BITS) || \
                                            ((SIZE) == QSPI_ALTERNATE_BYTES_24_BITS) || \
                                            ((SIZE) == QSPI_ALTERNATE_BYTES_32_BITS))

/**
 * @brief  Check that the dummy cycle count is a valid value (0..31).
 */
#define IS_QSPI_DUMMY_CYCLES(DUMMY) ((DUMMY) <= 0x1FU)

/**
 * @brief  Check that the data mode is a valid value.
 */
#define IS_QSPI_DATA_MODE(MODE) (((MODE) == QSPI_DATA_NONE)    || \
                                 ((MODE) == QSPI_DATA_1_LINE)  || \
                                 ((MODE) == QSPI_DATA_2_LINES) || \
                                 ((MODE) == QSPI_DATA_4_LINES))

/**
 * @brief  Check that the data byte count is valid (>= 1).
 */
#define IS_QSPI_NBDATA(NBDATA) ((NBDATA) >= 1U)

/**
 * @brief  Check that the polling interval is a valid value (0..0xFFFF).
 */
#define IS_QSPI_INTERVAL(INTERVAL) ((INTERVAL) <= 0xFFFFU)

/**
 * @brief  Check that the status byte count is valid (1..4).
 */
#define IS_QSPI_STATUS_BYTES_SIZE(SIZE) (((SIZE) >= 1U) && ((SIZE) <= 4U))

/**
 * @brief  Check that the timeout activation is a valid value.
 */
#define IS_QSPI_TIMEOUT_ACTIVATION(ACTIVATION) (((ACTIVATION) == QSPI_TIMEOUT_COUNTER_DISABLE) || \
                                                ((ACTIVATION) == QSPI_TIMEOUT_COUNTER_ENABLE))

/**
 * @brief  Check that the timeout period is a valid value (0..0xFFFF).
 */
#define IS_QSPI_TIMEOUT_PERIOD(PERIOD) ((PERIOD) <= 0xFFFFU)

/**
 * @brief  Check that the flag is a valid value.
 */
#define IS_QSPI_GET_FLAG(FLAG) (((FLAG) == QSPI_FLAG_BUSY) || \
                                ((FLAG) == QSPI_FLAG_TCF)  || \
                                ((FLAG) == QSPI_FLAG_TOF)  || \
                                ((FLAG) == QSPI_FLAG_PMF))

/**
 * @brief  Check that the flag clear value is valid.
 */
#define IS_QSPI_CLEAR_FLAG(CLEAR) (((CLEAR) == QSPI_CLEAR_CTCF) || \
                                   ((CLEAR) == QSPI_CLEAR_CTOF) || \
                                   ((CLEAR) == QSPI_CLEAR_CPMF))

/**
 * @brief  Check that the enable value is valid.
 */
#define IS_QSPI_ENABLE_STATE(NEWSTATE) (((NEWSTATE) == QSPI_ENABLE) || ((NEWSTATE) == QSPI_DISABLE))

/**
  * @}
  */

/* Shared internal functions --------------------------------------------------*/

/**
 * @brief  Check the handle state before starting an operation (ARCH-CONST-09).
 * @note   Returns HAL_BUSY while an operation is ongoing (any state with bit 1
 *         set: BUSY, BUSY_INDIRECT_TX / _RX, BUSY_AUTO_POLLING,
 *         BUSY_MEM_MAPPED) and HAL_ERROR while the handle has not been
 *         initialized (HAL_QSPI_Init() is required first). The error state is
 *         recoverable and is accepted, so a failed operation can be retried
 *         without a DeInit / Init round trip (STATE-06). HAL_QSPI_Abort() and
 *         HAL_QSPI_DeInit() do not call this helper: they are accepted in
 *         every state by design.
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef QSPI_CheckState(HAL_QSPI_HandleTypeDef *hqspi);

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_QSPI_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the acquisition is bounded by the Timeout parameter (RTOS
 *         ticks, which with the usual 1 ms tick is the same quantity as the
 *         millisecond Timeout of the public API); HAL_MAX_DELAY waits forever.
 *         A mutex that was never created is reported as HAL_ERROR instead of
 *         being passed to the porting layer as a NULL handle.
 * @note   Called by the public API only; neither the internal wait helper nor
 *         the low level register access functions take the lock, so they stay
 *         usable from an interrupt service routine (LOCK-04 / RTOS-12).
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS, wait expired) /
 *         HAL_ERROR (RTOS, mutex not created) / HAL_BUSY (bare metal, the
 *         handle is already locked).
 */
HAL_StatusTypeDef QSPI_LockHandle(HAL_QSPI_HandleTypeDef *hqspi, uint32 Timeout);

/**
 * @brief  Unlock the handle.
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @retval None
 */
void QSPI_UnlockHandle(HAL_QSPI_HandleTypeDef *hqspi);

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_QSPI_H */

/*****END OF FILE*****/
