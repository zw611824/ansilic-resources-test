# 串口结果采集

先按 [公共规则](../common.md) 确定判据，再结合对应 [功能规则](../index.md) 采样。

使用共享 IDE 串口工具，不写临时主机串口脚本。设备打印的运行结果（用户也可能称为“回显”）使用 serialMonitorTransfer 的 action=receive，不传 data、encoding 或 protocol；按实际功能解释输出，不因“回显”一词发送探测。仅任务明确测试设备按原字节返回发送内容、且应用实现该协议时，使用 `serialMonitorTransfer {"action":"verifyEcho","protocol":"raw-echo"}`；省略 data 时工具生成唯一探测内容，固定载荷按协议提供。命令响应测试只发送已核实的命令。仅串口测试不追加未授权的编译、烧录或复位，失败不自动重发。

完整构建验证流程固定为：编译成功 → 连接或复用已确认的串口并记录采集起点 → 烧录运行 → 采集并判定功能，不因是否依赖启动日志而省略准备。每次烧录前查询 serialMonitorStatus，确认 options 中有实际连接；上轮任务建立的连接可能已释放。未连接时按已确认设备和参数连接，保留用户已有连接及参数。设备身份不明确时询问；连接失败或与下载接口冲突时在烧录前停止说明，不猜端口、不擅自关闭用户连接。仅串口验证时核对当前连接，不追加编译或烧录。

采集起点使用已连接状态的 connectionId 与 rxCursor；每次授权烧录或启动前更新，随后用 receive 的 connectionId 和 fromCursor=该 rxCursor 获取本轮数据，后续以返回的 toCursor 续读。这样无需假定 Promise.all 能让接收与烧录真正并发。缓冲仅保留最近65536字节；返回 RECEIVE_GAP、CONNECTION_CHANGED 或范围不连续时，说明证据缺口，不补猜。默认不带游标的 receive 仍只等待调用后的首批新 RX，不保证完整一行或整个观察窗口。

结果正文取 JSON 的 receivedText，原始字节取 receivedHex（十六进制字节间可有空格），不是 data/text。分包按字节累计后再解码和解析完整记录，避免中文跨包损坏。单次 timeoutMs 为1..10000毫秒；较长任务在总截止时间、次数及数据量上限内顺序续读，按预期事件周期等待，不用100毫秒空轮询。达到完成或失败判据即停止，不能仅因未匹配到 PASS 无限采集。

捕获结果须结合 action 判断：receive 的 TIMEOUT 表示本次等待无新数据（success=true、timedOut=true），是否继续取决于总观察时限，不能据此判定功能通过；verifyEcho 的 TIMEOUT 仍是验证未通过，发送操作超时也不能当作发送成功。NOT_CONNECTED、DISCONNECTED、CONNECTION_CHANGED、CANCELLED 立即退出当前采集循环，再核对状态。不可用空 catch 忽略错误后反复 receive。重连后记录新连接的新游标，不能拼接成同一轮完整证据。

串口与下载冲突时按实际接口处理；不支持上述游标参数的旧工具，以实际 schema 为准，无法可靠采集时说明限制，不靠反复试参、重烧或复位补日志。超时、断开、取消、无新样本或采样缺口都不能冒充完整测试通过。
