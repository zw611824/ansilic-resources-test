/**
 * @file    RTC_IT_DRV_014.c
 * @brief   HAL RTC integration test case 014: API, macro and constant coverage self-check.
 *
 * Self-check case: it touches every public interface, every exported macro and
 * every exported constant of the module, validates the default filler values and
 * the structure versions, and prints the result of each check. It is meant to fail
 * loudly when an interface is renamed, removed or its contract changes.
 *
 * Tested functionality:
 *   HAL_RTC_Init() / HAL_RTC_DeInit() / HAL_RTC_MspInit() / HAL_RTC_MspDeInit()
 *   HAL_RTC_SetTime() / HAL_RTC_GetTime() / HAL_RTC_SetDate() / HAL_RTC_GetDate()
 *   HAL_RTC_SetAlarm() / HAL_RTC_SetAlarm_IT() / HAL_RTC_GetAlarm()
 *   HAL_RTC_TimeStructInit() / HAL_RTC_DateStructInit() / HAL_RTC_AlarmStructInit()
 *   HAL_RTC_AlarmIRQHandler() / HAL_RTC_AlarmEventCallback()
 *   HAL_RTC_Cmd() / HAL_RTC_WakeUpCmd() / HAL_RTC_GetState() / HAL_RTC_GetError()
 *   __HAL_RTC_RESET_HANDLE_STATE() / __HAL_RTC_ENABLE() / __HAL_RTC_DISABLE()
 *   __HAL_RTC_ENABLE_IT() / __HAL_RTC_DISABLE_IT() / __HAL_RTC_GET_IT_SOURCE()
 *   __HAL_RTC_GET_FLAG() / __HAL_RTC_CLEAR_FLAG()
 *   __HAL_RTC_WAKEUPTIMER_ENABLE() / __HAL_RTC_WAKEUPTIMER_DISABLE()
 *   __HAL_RTC_MODULE_VERSION
 *   Every IS_RTC_* validation macro and every exported constant
 *
 * Expected behaviour:
 *   - the version macros and the module version hold their documented values;
 *   - the default fillers produce the documented defaults (time all zero, date
 *     Sunday 00-01-01, alarm all zero with no comparison enabled);
 *   - every exported constant holds its documented value (formats, weekday, month,
 *     alarm comparison enables, interrupt and flag selectors, states, error codes);
 *   - every validation macro accepts its documented values and refuses out of range
 *     ones;
 *   - every public interface is called at least once and the alarm interrupt entry
 *     is exercised with a NULL handle, without an interrupt and through a real
 *     event.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* RTC divider coefficient. 1785 is the project baseline of the reference test
 * cases of this chip, 1638 is the other value documented by the library SRS;
 * both are legal hardware values (the driver only checks the 27 bit field
 * width). No test below depends on the resulting absolute frequency: the
 * checks are register read-backs or "the counter moved" observations. */
#define TEST_RTC_DIVISION           (1785U)

/* Calendar value used by the cases that need a known starting point */
#define TEST_TIME_HOURS             (15U)
#define TEST_TIME_MINUTES           (48U)
#define TEST_TIME_SECONDS           (0U)
#define TEST_TIME_TOS               (0U)
#define TEST_DATE_CENTURY           (20U)
#define TEST_DATE_YEAR              (25U)
#define TEST_DATE_MONTH             (RTC_Month_July)
#define TEST_DATE_DATE              (21U)
#define TEST_DATE_WEEKDAY           (RTC_Weekday_Monday)

/* Polling slice of the wait loops (ms) */
#define TEST_POLL_MS                (10U)

/* Reporting period of the final idle loop (ms) */
#define TEST_IDLE_MS                (1000U)

/* Wait window of the event check (ms) */
#define TEST_EVENT_TIMEOUT_MS       (5000U)

/* Distance of the alarm target of the event step, in RTC seconds: the comparison
 * set is programmed that far ahead of the calendar of the moment, so the match
 * window (one tenth of a second) is still in the future when the alarm is
 * committed. */
#define TEST_ALARM_AHEAD_S          (2U)

/* Private variables ---------------------------------------------------------*/
static RTC_HandleTypeDef hrtc_dev;          /*!< RTC device handle            */
static RTC_InitTypeDef   rtc_init;          /*!< RTC configuration structure  */
static uint32            failures = 0U;     /*!< failed checks                */

/* Alarm interrupt bookkeeping (filled by the overridden weak callback) */
static volatile uint32   alarm_events = 0U; /*!< callback entries             */
static volatile uint32   alarm_cr_seen = 0U;/*!< CR register at callback time */

/* Scratch structures and bookkeeping of this case */
static RTC_TimeTypeDef  time_d;
static RTC_DateTypeDef  date_d;
static RTC_AlarmTypeDef alarm_d;
static RTC_AlarmTypeDef alarm_r;
static RTC_InitTypeDef  init_chk;
static uint32           elapsed;
static uint8            tgt_hours;          /*!< alarm target of the event step */
static uint8            tgt_minutes;
static uint8            tgt_seconds;

/* Last calendar read back by the report helpers */
static uint8 r_time_hours;
static uint8 r_time_minutes;
static uint8 r_time_seconds;
static uint8 r_time_tos;
static uint8 r_date_century;
static uint8 r_date_year;
static uint8 r_date_month;
static uint8 r_date_date;
static uint8 r_date_weekday;

/* Private function prototypes -----------------------------------------------*/
static void Check(const char *name, uint32 condition);
static void SystemClock_Init(void);
static void Rtc_Handle_Setup(void);
static HAL_StatusTypeDef Rtc_Start(void);
static HAL_StatusTypeDef Rtc_SetCalendar(uint8 hours, uint8 minutes, uint8 seconds, uint8 tos,
                                         uint8 century, uint8 year, uint8 month, uint8 date,
                                         uint8 weekday);
static HAL_StatusTypeDef Rtc_GetCalendar(void);
static uint8 Rtc_MonthToNumber(uint8 month);
static const char *Rtc_WeekdayName(uint8 weekday);
static void Rtc_PrintCalendar(const char *tag);
static void Plc_RouteRtcIrq(void);

/* Exported interrupt entry ------------------------------------------------*/
/**
 * @brief  RTC interrupt entry, called by the shared PLIC dispatch table.
 * @note   Overrides the weak RTC_IRQ_Handler() of the PLIC driver; it hands the
 *         event to the HAL RTC interrupt handler, which clears the alarm flag
 *         and then calls HAL_RTC_AlarmEventCallback().
 */
void RTC_IRQ_Handler(void)
{
    HAL_RTC_AlarmIRQHandler(&hrtc_dev);
}

/**
 * @brief  Alarm event callback (weak function of the HAL RTC driver).
 * @note   Counts the events and snapshots CR so that the cases can observe the
 *         flag state the driver left behind. It must not block and must not
 *         call a locking RTC interface (interrupt context).
 * @param  hrtc pointer to a RTC_HandleTypeDef structure.
 * @retval None
 */
void HAL_RTC_AlarmEventCallback(RTC_HandleTypeDef *hrtc)
{
    UNUSED(hrtc);

    alarm_events++;
    alarm_cr_seen = hrtc_dev.Instance->CR;
}

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock tree */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n\r\n==== RTC_IT_DRV_014: API, macro and constant coverage self-check ====\r\n");
    printf("Data : %s\r\n", __DATE__);
    printf("Time : %s\r\n", __TIME__);

        /* ---- Step 1: version macros ---------------------------------------- */
        Check("__HAL_RTC_MODULE_VERSION", (__HAL_RTC_MODULE_VERSION == 0x0100U));
        Check("RTC_INIT_V1", (RTC_INIT_V1 == 0x0100U));
        Check("RTC_INIT_VERSION == RTC_INIT_V1", (RTC_INIT_VERSION == RTC_INIT_V1));

        /* ---- Step 2: structure default fillers ----------------------------- */
        __HAL_CLEAR_STRUCT(&time_d);
        time_d.RTC_Hours = 9U;
        time_d.RTC_Minutes = 9U;
        time_d.RTC_Seconds = 9U;
        time_d.RTC_TenthOfSecond = 9U;
        HAL_RTC_TimeStructInit(&time_d);
        Check("TimeStructInit clears every field",
              ((time_d.RTC_Hours == 0U) && (time_d.RTC_Minutes == 0U) &&
               (time_d.RTC_Seconds == 0U) && (time_d.RTC_TenthOfSecond == 0U)));
        HAL_RTC_TimeStructInit(NULL_PTR);
        Check("TimeStructInit(NULL) is a safe no-op", (1U));

        __HAL_CLEAR_STRUCT(&date_d);
        date_d.RTC_WeekDay = 0x7FU;
        HAL_RTC_DateStructInit(&date_d);
        /* SRS RTC-REQ-020: Monday, January 01 0000 */
        Check("DateStructInit defaults (Monday 00-01-01)",
              ((date_d.RTC_WeekDay == RTC_Weekday_Monday) && (date_d.RTC_Century == 0U) &&
               (date_d.RTC_Year == 0U) && (date_d.RTC_Month == RTC_Month_January) &&
               (date_d.RTC_Date == 1U)));
        Check("DateStructInit default passes the field validation",
              (IS_RTC_MONTH(date_d.RTC_Month) && IS_RTC_DATE(date_d.RTC_Date) &&
               IS_RTC_WEEKDAY(date_d.RTC_WeekDay)));
        HAL_RTC_DateStructInit(NULL_PTR);
        Check("DateStructInit(NULL) is a safe no-op", (1U));

        __HAL_CLEAR_STRUCT(&alarm_d);
        alarm_d.RTC_AlarmTimeCompEn = 0xFFFFFFFFU;
        HAL_RTC_AlarmStructInit(&alarm_d);
        Check("AlarmStructInit zeros the time and the comparisons",
              ((alarm_d.RTC_AlarmTime.RTC_Hours == 0U) &&
               (alarm_d.RTC_AlarmTime.RTC_Minutes == 0U) &&
               (alarm_d.RTC_AlarmTime.RTC_Seconds == 0U) &&
               (alarm_d.RTC_AlarmTime.RTC_TenthOfSecond == 0U) &&
               (alarm_d.RTC_AlarmTimeCompEn == RTC_Alarm_None) &&
               (alarm_d.RTC_AlarmDataCompEn == RTC_Alarm_None)));
        Check("AlarmStructInit default passes the field validation",
              ((IS_RTC_MONTH(alarm_d.RTC_AlarmDate.RTC_Month) != 0U) &&
               (IS_RTC_DATE(alarm_d.RTC_AlarmDate.RTC_Date) != 0U)));
        HAL_RTC_AlarmStructInit(NULL_PTR);
        Check("AlarmStructInit(NULL) is a safe no-op", (1U));

        /* ---- Step 3: exported constants ------------------------------------ */
        Check("RTC_FORMAT_BIN / RTC_FORMAT_BCD",
              ((RTC_FORMAT_BIN == 0U) && (RTC_FORMAT_BCD == 1U)));
        Check("month constants 0x01..0x0C",
              ((RTC_Month_January == 0x01U) && (RTC_Month_February == 0x02U) &&
               (RTC_Month_March == 0x03U) && (RTC_Month_April == 0x04U) &&
               (RTC_Month_May == 0x05U) && (RTC_Month_June == 0x06U) &&
               (RTC_Month_July == 0x07U) && (RTC_Month_August == 0x08U) &&
               (RTC_Month_September == 0x09U) && (RTC_Month_October == 0x0AU) &&
               (RTC_Month_November == 0x0BU) && (RTC_Month_December == 0x0CU)));
        Check("weekday constants 0x01..0x07",
              ((RTC_Weekday_Sunday == 0x01U) && (RTC_Weekday_Monday == 0x02U) &&
               (RTC_Weekday_Tuesday == 0x03U) && (RTC_Weekday_Wednesday == 0x04U) &&
               (RTC_Weekday_Thursday == 0x05U) && (RTC_Weekday_Friday == 0x06U) &&
               (RTC_Weekday_Saturday == 0x07U)));
        Check("alarm comparison enables",
              ((RTC_AlarmTime_TenOfSecond == 0x08000000U) &&
               (RTC_AlarmTime_Seconds == 0x10000000U) &&
               (RTC_AlarmTime_Minutes == 0x20000000U) &&
               (RTC_AlarmTime_Hours == 0x40000000U) &&
               (RTC_AlarmTime_WeekDay == 0x80000000U) &&
               (RTC_AlarmDate_Date == 0x08000000U) &&
               (RTC_AlarmDate_Month == 0x10000000U) &&
               (RTC_AlarmDate_Year == 0x20000000U) &&
               (RTC_AlarmDate_Century == 0x40000000U) &&
               (RTC_Alarm_None == 0U)));
        Check("interrupt and flag selectors",
              ((RTC_IT_ALARM == RTC_CR_IE) && (RTC_FLAG_ALARM == RTC_CR_ALRMT)));
        Check("wake-up enable constant",
              ((RTC_WAKEUP_ENABLE == RTC_WUCR_WUTE) && (RTC_WAKEUP_ENABLE == 0x00000001U)));
        Check("state constants",
              ((HAL_RTC_STATE_RESET == 0U) && (HAL_RTC_STATE_READY == 1U) &&
               (HAL_RTC_STATE_BUSY == 2U) && (HAL_RTC_STATE_TIMEOUT == 3U) &&
               (HAL_RTC_STATE_ERROR == 4U)));
        Check("error code constants",
              ((HAL_RTC_ERROR_NONE == 0U) && (HAL_RTC_ERROR_INVALID_PARAM == 1U) &&
               (HAL_RTC_ERROR_TIMEOUT == 2U)));

        /* ---- Step 4: validation macros ------------------------------------- */
        Check("IS_RTC_ALL_INSTANCE", ((IS_RTC_ALL_INSTANCE(RTC) != 0U) &&
                                      (IS_RTC_ALL_INSTANCE((RTC_TypeDef *)0x40000000U) == 0U)));
        Check("IS_RTC_DIVISION", ((IS_RTC_DIVISION(0U) != 0U) &&
                                  (IS_RTC_DIVISION(0x07FFFFFFU) != 0U) &&
                                  (IS_RTC_DIVISION(0x08000000U) == 0U)));
        Check("IS_RTC_FORMAT", ((IS_RTC_FORMAT(RTC_FORMAT_BIN) != 0U) &&
                                (IS_RTC_FORMAT(RTC_FORMAT_BCD) != 0U) &&
                                (IS_RTC_FORMAT(2U) == 0U)));
        Check("IS_RTC_HOURS", ((IS_RTC_HOURS(0U) != 0U) && (IS_RTC_HOURS(23U) != 0U) &&
                               (IS_RTC_HOURS(24U) == 0U)));
        Check("IS_RTC_MINUTES", ((IS_RTC_MINUTES(59U) != 0U) && (IS_RTC_MINUTES(60U) == 0U)));
        Check("IS_RTC_SECONDS", ((IS_RTC_SECONDS(59U) != 0U) && (IS_RTC_SECONDS(60U) == 0U)));
        Check("IS_RTC_TENOFSECOND", ((IS_RTC_TENOFSECOND(9U) != 0U) &&
                                     (IS_RTC_TENOFSECOND(10U) == 0U)));
        Check("IS_RTC_CENTURY", ((IS_RTC_CENTURY(99U) != 0U) && (IS_RTC_CENTURY(100U) == 0U)));
        Check("IS_RTC_YEAR", ((IS_RTC_YEAR(99U) != 0U) && (IS_RTC_YEAR(100U) == 0U)));
        Check("IS_RTC_MONTH", ((IS_RTC_MONTH(1U) != 0U) && (IS_RTC_MONTH(12U) != 0U) &&
                               (IS_RTC_MONTH(0U) == 0U) && (IS_RTC_MONTH(13U) == 0U)));
        Check("IS_RTC_DATE", ((IS_RTC_DATE(1U) != 0U) && (IS_RTC_DATE(31U) != 0U) &&
                              (IS_RTC_DATE(0U) == 0U) && (IS_RTC_DATE(32U) == 0U)));
        Check("IS_RTC_WEEKDAY", ((IS_RTC_WEEKDAY(RTC_Weekday_Monday) != 0U) &&
                                 (IS_RTC_WEEKDAY(RTC_Weekday_Sunday) != 0U) &&
                                 (IS_RTC_WEEKDAY(0U) == 0U) && (IS_RTC_WEEKDAY(8U) == 0U)));
        Check("IS_RTC_ALARMTIME", ((IS_RTC_ALARMTIME(RTC_AlarmTime_Hours) != 0U) &&
                                   (IS_RTC_ALARMTIME(0x04000000U) == 0U)));
        Check("IS_RTC_ALARMDATE", ((IS_RTC_ALARMDATE(RTC_AlarmDate_Date) != 0U) &&
                                   (IS_RTC_ALARMDATE(0x80000000U) == 0U)));
        __HAL_CLEAR_STRUCT(&init_chk);
        init_chk.Size = sizeof(RTC_InitTypeDef);
        init_chk.Version = RTC_INIT_VERSION;
        Check("IS_RTC_INIT_STRUCT_OK accepts a prepared structure",
              (IS_RTC_INIT_STRUCT_OK(&init_chk) != 0U));
        init_chk.Reserved[1] = 1U;
        Check("IS_RTC_INIT_STRUCT_OK rejects a reserved word",
              (IS_RTC_INIT_STRUCT_OK(&init_chk) == 0U));

        /* ---- Step 5: the module interfaces --------------------------------- */
        Check("HAL_RTC_Init", (Rtc_Start() == HAL_OK));
        Check("HAL_RTC_GetState", (HAL_RTC_GetState(&hrtc_dev) == HAL_RTC_STATE_READY));
        Check("HAL_RTC_GetError", (HAL_RTC_GetError(&hrtc_dev) == HAL_RTC_ERROR_NONE));

        /* the low level callbacks of the module are provided by this case */
        HAL_RTC_MspInit(&hrtc_dev);
        HAL_RTC_MspDeInit(&hrtc_dev);
        Check("the MSP callbacks are callable", (1U));

        Check("HAL_RTC_Cmd(DISABLE)", (HAL_RTC_Cmd(&hrtc_dev, DISABLE) == HAL_OK));
        Check("HAL_RTC_SetTime (BIN)", (Rtc_SetCalendar(TEST_TIME_HOURS, TEST_TIME_MINUTES,
                                                        TEST_TIME_SECONDS, TEST_TIME_TOS,
                                                        TEST_DATE_CENTURY, TEST_DATE_YEAR,
                                                        TEST_DATE_MONTH, TEST_DATE_DATE,
                                                        TEST_DATE_WEEKDAY) == HAL_OK));
        Check("HAL_RTC_GetTime / GetDate", (Rtc_GetCalendar() == HAL_OK));

        __HAL_CLEAR_STRUCT(&time_d);
        HAL_RTC_TimeStructInit(&time_d);
        Check("HAL_RTC_GetTime with RTC_FORMAT_BCD",
              (HAL_RTC_GetTime(&hrtc_dev, &time_d, RTC_FORMAT_BCD) == HAL_OK));
        __HAL_CLEAR_STRUCT(&date_d);
        HAL_RTC_DateStructInit(&date_d);
        Check("HAL_RTC_GetDate with RTC_FORMAT_BCD",
              (HAL_RTC_GetDate(&hrtc_dev, &date_d, RTC_FORMAT_BCD) == HAL_OK));
        Check("HAL_RTC_SetTime with RTC_FORMAT_BCD",
              (HAL_RTC_SetTime(&hrtc_dev, &time_d, RTC_FORMAT_BCD) == HAL_OK));
        Check("HAL_RTC_SetDate with RTC_FORMAT_BCD",
              (HAL_RTC_SetDate(&hrtc_dev, &date_d, RTC_FORMAT_BCD) == HAL_OK));

        __HAL_CLEAR_STRUCT(&alarm_d);
        HAL_RTC_AlarmStructInit(&alarm_d);
        alarm_d.RTC_AlarmTimeCompEn = RTC_AlarmTime_Hours;
        Check("HAL_RTC_SetAlarm", (HAL_RTC_SetAlarm(&hrtc_dev, &alarm_d, RTC_FORMAT_BIN) == HAL_OK));
        __HAL_CLEAR_STRUCT(&alarm_r);
        Check("HAL_RTC_GetAlarm", (HAL_RTC_GetAlarm(&hrtc_dev, &alarm_r, RTC_FORMAT_BIN) == HAL_OK));
        Check("alarm comparison read back",
              (alarm_r.RTC_AlarmTimeCompEn == RTC_AlarmTime_Hours));

        Check("HAL_RTC_SetAlarm_IT",
              (HAL_RTC_SetAlarm_IT(&hrtc_dev, &alarm_d, RTC_FORMAT_BIN) == HAL_OK));
        Check("interrupt enable set by SetAlarm_IT", ((RTC->CR & RTC_CR_IE) != 0U));
        __HAL_RTC_DISABLE_IT(&hrtc_dev, RTC_IT_ALARM);
        Check("__HAL_RTC_DISABLE_IT", ((RTC->CR & RTC_CR_IE) == 0U));
        __HAL_RTC_ENABLE_IT(&hrtc_dev, RTC_IT_ALARM);
        Check("__HAL_RTC_ENABLE_IT", ((RTC->CR & RTC_CR_IE) != 0U));
        Check("__HAL_RTC_GET_IT_SOURCE", (__HAL_RTC_GET_IT_SOURCE(&hrtc_dev, RTC_IT_ALARM) == SET));
        __HAL_RTC_DISABLE_IT(&hrtc_dev, RTC_IT_ALARM);

        __HAL_RTC_ENABLE(&hrtc_dev);
        Check("__HAL_RTC_ENABLE", ((RTC->CR & RTC_CR_EN) != 0U));
        __HAL_RTC_DISABLE(&hrtc_dev);
        Check("__HAL_RTC_DISABLE", ((RTC->CR & RTC_CR_EN) == 0U));

        HAL_RTC_WakeUpCmd(&hrtc_dev, ENABLE);
        Check("HAL_RTC_WakeUpCmd(ENABLE)", ((RTC->WUCR & RTC_WUCR_WUTE) != 0U));
        HAL_RTC_WakeUpCmd(&hrtc_dev, DISABLE);
        Check("HAL_RTC_WakeUpCmd(DISABLE)", ((RTC->WUCR & RTC_WUCR_WUTE) == 0U));

        __HAL_RTC_CLEAR_FLAG(&hrtc_dev, RTC_FLAG_ALARM);
        Check("__HAL_RTC_CLEAR_FLAG / __HAL_RTC_GET_FLAG",
              ((__HAL_RTC_GET_FLAG(&hrtc_dev, RTC_FLAG_ALARM) == RESET) &&
               ((RTC->CR & RTC_CR_ALRMT) == 0U)));

        __HAL_RTC_RESET_HANDLE_STATE(&hrtc_dev);
        Check("__HAL_RTC_RESET_HANDLE_STATE",
              (HAL_RTC_GetState(&hrtc_dev) == HAL_RTC_STATE_RESET));
        Check("HAL_RTC_DeInit", (HAL_RTC_DeInit(&hrtc_dev) == HAL_OK));

        /* ---- Step 6: the interrupt entry ----------------------------------- */
        HAL_RTC_AlarmIRQHandler(NULL_PTR);
        Check("AlarmIRQHandler(NULL) is harmless", (1U));

        Check("re-initialization for the event test", (Rtc_Start() == HAL_OK));
        Plc_RouteRtcIrq();
        Check("calendar programmed for the event",
              (Rtc_SetCalendar(TEST_TIME_HOURS, TEST_TIME_MINUTES, TEST_TIME_SECONDS,
                               TEST_TIME_TOS, TEST_DATE_CENTURY, TEST_DATE_YEAR,
                               TEST_DATE_MONTH, TEST_DATE_DATE,
                               TEST_DATE_WEEKDAY) == HAL_OK));
        Check("calendar enabled", (HAL_RTC_Cmd(&hrtc_dev, ENABLE) == HAL_OK));

        (void)Rtc_GetCalendar();
        /* The alarm has to be programmed a moment in the future: a comparison set
           built from the calendar of the moment points at an instant that has
           already passed (the tenth of a second field makes the window one tenth
           of a second wide), and it would only recur 24 hours later. */
        tgt_hours   = r_time_hours;
        tgt_minutes = r_time_minutes;
        tgt_seconds = (uint8)(r_time_seconds + TEST_ALARM_AHEAD_S);
        if (tgt_seconds >= 60U)
        {
            tgt_seconds = (uint8)(tgt_seconds - 60U);
            tgt_minutes = (uint8)(tgt_minutes + 1U);
            if (tgt_minutes >= 60U)
            {
                tgt_minutes = 0U;
                tgt_hours = (uint8)((tgt_hours + 1U) % 24U);
            }
        }
        __HAL_CLEAR_STRUCT(&alarm_d);
        HAL_RTC_AlarmStructInit(&alarm_d);
        alarm_d.RTC_AlarmTime.RTC_Hours         = tgt_hours;
        alarm_d.RTC_AlarmTime.RTC_Minutes       = tgt_minutes;
        alarm_d.RTC_AlarmTime.RTC_Seconds       = tgt_seconds;
        alarm_d.RTC_AlarmTime.RTC_TenthOfSecond = 0U;
        alarm_d.RTC_AlarmDate.RTC_WeekDay       = r_date_weekday;
        alarm_d.RTC_AlarmDate.RTC_Century       = r_date_century;
        alarm_d.RTC_AlarmDate.RTC_Year          = r_date_year;
        alarm_d.RTC_AlarmDate.RTC_Month         = r_date_month;
        alarm_d.RTC_AlarmDate.RTC_Date          = r_date_date;
        alarm_d.RTC_AlarmTimeCompEn = RTC_AlarmTime_Hours | RTC_AlarmTime_Minutes |
                                      RTC_AlarmTime_Seconds | RTC_AlarmTime_TenOfSecond;
        alarm_d.RTC_AlarmDataCompEn = RTC_AlarmDate_Year | RTC_AlarmDate_Month |
                                      RTC_AlarmDate_Date;
        Check("HAL_RTC_SetAlarm_IT for the event",
              (HAL_RTC_SetAlarm_IT(&hrtc_dev, &alarm_d, RTC_FORMAT_BIN) == HAL_OK));

        alarm_events = 0U;
        elapsed = 0U;
        while ((alarm_events == 0U) && (elapsed < TEST_EVENT_TIMEOUT_MS))
        {
            delay_ms(TEST_POLL_MS);
            elapsed += TEST_POLL_MS;
        }
        printf("event count = %u after %u ms\r\n", PRINT_U32(alarm_events), PRINT_U32(elapsed));
        Check("AlarmIRQHandler / AlarmEventCallback delivered an event", (alarm_events > 0U));
        Check("handle READY after the event",
              (HAL_RTC_GetState(&hrtc_dev) == HAL_RTC_STATE_READY));

        __HAL_RTC_DISABLE_IT(&hrtc_dev, RTC_IT_ALARM);
        __HAL_RTC_CLEAR_FLAG(&hrtc_dev, RTC_FLAG_ALARM);
        Check("module closed down cleanly",
              (((RTC->CR & RTC_CR_IE) == 0U) && ((RTC->CR & RTC_CR_ALRMT) == 0U)));

        /* ---- Step 7: the private field masks ------------------------------- */
        Check("RTC_TR_RESERVED_MASK covers the time fields",
              ((RTC_TR_RESERVED_MASK == 0x00FFFFFFU) &&
               ((RTC_TR_RESERVED_MASK & (RTC_TR_TOS | RTC_TR_SU | RTC_TR_ST | RTC_TR_MNU |
                                         RTC_TR_MNT | RTC_TR_HU | RTC_TR_HT)) != 0U) &&
               ((RTC_TR_RESERVED_MASK & RTC_TR_WDU) == 0U)));
        Check("RTC_DR_RESERVED_MASK covers the date fields",
              ((RTC_DR_RESERVED_MASK == 0x07FFFFFFU) &&
               ((RTC_DR_RESERVED_MASK & (RTC_DR_DU | RTC_DR_DT | RTC_DR_MU | RTC_DR_MT |
                                         RTC_DR_YU | RTC_DR_YT | RTC_DR_CU | RTC_DR_CT)) != 0U)));
        Check("RTC_ALRMTR_RESERVED_MASK covers the comparison enables of ALRMTR",
              ((RTC_ALRMTR_RESERVED_MASK == 0xF8000000U) &&
               ((RTC_ALRMTR_RESERVED_MASK & (RTC_ALRMTR_TOS | RTC_ALRMTR_SU | RTC_ALRMTR_ST |
                                             RTC_ALRMTR_MNU | RTC_ALRMTR_MNT | RTC_ALRMTR_HU |
                                             RTC_ALRMTR_HT | RTC_ALRMTR_WDU)) == 0U)));
        Check("RTC_ALRMDR_RESERVED_MASK covers the comparison enables of ALRMDR",
              ((RTC_ALRMDR_RESERVED_MASK == 0x78000000U) &&
               ((RTC_ALRMDR_RESERVED_MASK & (RTC_ALRMDR_DU | RTC_ALRMDR_DT | RTC_ALRMDR_MU |
                                             RTC_ALRMDR_MT | RTC_ALRMDR_YU | RTC_ALRMDR_YT |
                                             RTC_ALRMDR_CU | RTC_ALRMDR_CT)) == 0U)));

        /* The read path masks the reserved bits of TR and DR: a value written
           directly into the register (bypassing the driver) must not leak into the
           time / date structure. The calendar is stopped first: while CR.EN is set
           the device ignores every write to TR and DR, so the probe values would
           never reach the register. The probe values are laid out for the register
           map of this chip (TOS is the low nibble, then the BCD pair of the
           seconds, ...), so the expected decode is the intended calendar value and
           not the raw byte sequence. */
        Check("calendar stopped for the register probe",
              (HAL_RTC_Cmd(&hrtc_dev, DISABLE) == HAL_OK));
        hrtc_dev.Instance->TR = 0xFB49A566U;    /* 12:34:56.6 + the reserved bits 24..31 */
        __HAL_CLEAR_STRUCT(&time_d);
        HAL_RTC_TimeStructInit(&time_d);
        Check("HAL_RTC_GetTime masks the reserved bits of TR",
              (HAL_RTC_GetTime(&hrtc_dev, &time_d, RTC_FORMAT_BIN) == HAL_OK));
        Check("only the time fields are decoded", ((time_d.RTC_Hours == 12U) &&
                                                   (time_d.RTC_Minutes == 34U) &&
                                                   (time_d.RTC_Seconds == 56U) &&
                                                   (time_d.RTC_TenthOfSecond == 6U)));

        hrtc_dev.Instance->DR = 0xFCCCCC95U;    /* 99-12-15 + the reserved bits 27..31 */
        __HAL_CLEAR_STRUCT(&date_d);
        HAL_RTC_DateStructInit(&date_d);
        Check("HAL_RTC_GetDate masks the reserved bits of DR",
              (HAL_RTC_GetDate(&hrtc_dev, &date_d, RTC_FORMAT_BIN) == HAL_OK));
        Check("only the date fields are decoded", ((date_d.RTC_Century == 99U) &&
                                                   (date_d.RTC_Year == 99U) &&
                                                   (date_d.RTC_Month == 12U) &&
                                                   (date_d.RTC_Date == 15U)));

        /* Restore a legal calendar before the idle loop of the case and let it run
           again (it was stopped for the register probe) */
        (void)Rtc_SetCalendar(TEST_TIME_HOURS, TEST_TIME_MINUTES, TEST_TIME_SECONDS,
                              TEST_TIME_TOS, TEST_DATE_CENTURY, TEST_DATE_YEAR,
                              TEST_DATE_MONTH, TEST_DATE_DATE, TEST_DATE_WEEKDAY);
        (void)HAL_RTC_Cmd(&hrtc_dev, ENABLE);
        Rtc_PrintCalendar("final");
    /* ---- summary ------------------------------------------------------- */
    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(failures));

    /* Idle: keep the calendar observable on the console */
    while (1)
    {
        Rtc_PrintCalendar("idle");
        delay_ms(TEST_IDLE_MS);
    }
}

/* Private functions --------------------------------------------------------*/
/**
 * @brief  Prepare the RTC handle and its configuration structure.
 * @note   The configuration structure metafields (Size / Version / reserved
 *         words) are mandatory: HAL_RTC_Init() validates them at run time and
 *         rejects a structure that does not carry them.
 * @param  None
 * @retval None
 */
static void Rtc_Handle_Setup(void)
{
    __HAL_CLEAR_STRUCT(&hrtc_dev);
    hrtc_dev.Instance = RTC;

    __HAL_CLEAR_STRUCT(&rtc_init);
    rtc_init.Size     = sizeof(RTC_InitTypeDef);
    rtc_init.Version  = RTC_INIT_VERSION;
    rtc_init.Division = TEST_RTC_DIVISION;
    hrtc_dev.Init     = rtc_init;
}

/**
 * @brief  Initialize the RTC and report its state.
 * @param  None
 * @retval HAL status of the initialization.
 */
static HAL_StatusTypeDef Rtc_Start(void)
{
    HAL_StatusTypeDef status;

    Rtc_Handle_Setup();
    status = HAL_RTC_Init(&hrtc_dev);
    printf("RTC state = %u (1 = READY), error = %u\r\n",
           PRINT_U32(HAL_RTC_GetState(&hrtc_dev)),
           PRINT_U32(HAL_RTC_GetError(&hrtc_dev)));

    return status;
}

/**
 * @brief  Write the calendar (time and date) of the RTC.
 * @param  hours / minutes / seconds / tos: time fields.
 * @param  century / year / month / date / weekday: date fields.
 * @retval HAL_OK when both writes succeeded.
 */
static HAL_StatusTypeDef Rtc_SetCalendar(uint8 hours, uint8 minutes, uint8 seconds, uint8 tos,
                                         uint8 century, uint8 year, uint8 month, uint8 date,
                                         uint8 weekday)
{
    RTC_TimeTypeDef time;
    RTC_DateTypeDef dateS;
    HAL_StatusTypeDef status;

    __HAL_CLEAR_STRUCT(&time);
    __HAL_CLEAR_STRUCT(&dateS);
    HAL_RTC_TimeStructInit(&time);
    HAL_RTC_DateStructInit(&dateS);

    time.RTC_Hours         = hours;
    time.RTC_Minutes       = minutes;
    time.RTC_Seconds       = seconds;
    time.RTC_TenthOfSecond = tos;

    dateS.RTC_WeekDay = weekday;
    dateS.RTC_Century = century;
    dateS.RTC_Year    = year;
    dateS.RTC_Month   = month;
    dateS.RTC_Date    = date;

    status = HAL_RTC_SetTime(&hrtc_dev, &time, RTC_FORMAT_BIN);
    if (status == HAL_OK)
    {
        status = HAL_RTC_SetDate(&hrtc_dev, &dateS, RTC_FORMAT_BIN);
    }

    return status;
}

/**
 * @brief  Read the calendar into the report globals.
 * @param  None
 * @retval HAL status of the read (HAL_ERROR when a read was refused).
 */
static HAL_StatusTypeDef Rtc_GetCalendar(void)
{
    RTC_TimeTypeDef time;
    RTC_DateTypeDef dateS;
    HAL_StatusTypeDef status;

    __HAL_CLEAR_STRUCT(&time);
    __HAL_CLEAR_STRUCT(&dateS);

    status = HAL_RTC_GetTime(&hrtc_dev, &time, RTC_FORMAT_BIN);
    if (status == HAL_OK)
    {
        status = HAL_RTC_GetDate(&hrtc_dev, &dateS, RTC_FORMAT_BIN);
    }
    if (status != HAL_OK)
    {
        return status;
    }

    r_time_hours   = time.RTC_Hours;
    r_time_minutes = time.RTC_Minutes;
    r_time_seconds = time.RTC_Seconds;
    r_time_tos     = time.RTC_TenthOfSecond;

    r_date_century = dateS.RTC_Century;
    r_date_year    = dateS.RTC_Year;
    r_date_month   = dateS.RTC_Month;
    r_date_date    = dateS.RTC_Date;
    r_date_weekday = dateS.RTC_WeekDay;

    return HAL_OK;
}

/**
 * @brief  Translate a month constant to its number (1-12).
 * @param  month: month (RTC_Month_xxx).
 * @retval uint8: month number, or 0 when the value is unknown.
 */
static uint8 Rtc_MonthToNumber(uint8 month)
{
    uint8 result;

    switch (month)
    {
        case RTC_Month_January:   result = 1U;  break;
        case RTC_Month_February:  result = 2U;  break;
        case RTC_Month_March:     result = 3U;  break;
        case RTC_Month_April:     result = 4U;  break;
        case RTC_Month_May:       result = 5U;  break;
        case RTC_Month_June:      result = 6U;  break;
        case RTC_Month_July:      result = 7U;  break;
        case RTC_Month_August:    result = 8U;  break;
        case RTC_Month_September: result = 9U;  break;
        case RTC_Month_October:   result = 10U; break;
        case RTC_Month_November:  result = 11U; break;
        case RTC_Month_December:  result = 12U; break;
        default:                  result = 0U;  break;
    }

    return result;
}

/**
 * @brief  Translate a weekday constant to its name.
 * @param  weekday: weekday (RTC_Weekday_xxx).
 * @retval const char*: weekday name, or "?" when the value is unknown.
 */
static const char *Rtc_WeekdayName(uint8 weekday)
{
    switch (weekday)
    {
        case RTC_Weekday_Monday:    return "Monday";
        case RTC_Weekday_Tuesday:   return "Tuesday";
        case RTC_Weekday_Wednesday: return "Wednesday";
        case RTC_Weekday_Thursday:  return "Thursday";
        case RTC_Weekday_Friday:    return "Friday";
        case RTC_Weekday_Saturday:  return "Saturday";
        case RTC_Weekday_Sunday:    return "Sunday";
        default:                    return "?";
    }
}

/**
 * @brief  Read and print the calendar.
 * @param  tag: text printed in front of the value (may be NULL).
 * @retval None
 */
static void Rtc_PrintCalendar(const char *tag)
{
    if (Rtc_GetCalendar() != HAL_OK)
    {
        printf("%s calendar read refused (state = %u)\r\n",
               ((tag != NULL_PTR) ? tag : ""),
               PRINT_U32(HAL_RTC_GetState(&hrtc_dev)));
        return;
    }

    printf("%s %02u-%02u-%02u %02u:%02u:%02u.%u %s\r\n",
           ((tag != NULL_PTR) ? tag : ""),
           PRINT_U32(r_date_century), PRINT_U32(Rtc_MonthToNumber(r_date_month)),
           PRINT_U32(r_date_date), PRINT_U32(r_time_hours), PRINT_U32(r_time_minutes),
           PRINT_U32(r_time_seconds), PRINT_U32(r_time_tos),
           Rtc_WeekdayName(r_date_weekday));
}

/**
 * @brief  Route the RTC alarm interrupt line through the PLIC.
 * @note   The RTC alarm is the only interrupt source of the module; the shared
 *         trap entry dispatches it to RTC_IRQ_Handler() overridden above.
 * @param  None
 * @retval None
 */
static void Plc_RouteRtcIrq(void)
{
    PLIC_InitTypeDef plic_init;

    __HAL_CLEAR_STRUCT(&plic_init);
    plic_init.Size               = sizeof(plic_init);
    plic_init.Version            = PLIC_INIT_VERSION;
    plic_init.PLIC_IRQChannel    = RTC_IRQn;
    plic_init.PLIC_IRQPriority   = 1U;
    plic_init.PLIC_IRQChannelCmd = ENABLE;
    HAL_PLIC_Init(&plic_init);

    Check("RTC interrupt routed in the PLIC",
          (PLIC->AXI_PLIC_PRIORITY[RTC_IRQn - 1U] == 1U));
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition == 0U)
    {
        failures++;
    }
    printf("%-44s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Configure the system clock tree using the HAL SMU driver.
 * @note   Clock tree shared by every integration test suite of this library:
 *         OSC 20 MHz as the PLL source, PLLDivR = 0x04 / PLLDivN = 0x14 /
 *         PLLDivF = 0xB4 / PLLDivQ = 0x01, then AXI4Bus3 = /2, APBBus0 = /2,
 *         APBBus1 = /2 and CANX2 = /8. The bus dividers are written first and
 *         the PLL is switched in afterwards, which is the order the chip
 *         requires (see HAL_SMU_OscConfig()).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;
    HAL_SMU_HandleTypeDef hsmu_clk;

    /* Enable the bus clock gates */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* The RTC lives in the always-on APB-BusS domain: it has no clock gate of
       its own, the module switch of the configuration file is enough. */

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Bus dividers first (the system clock is still the power-on source) */
    __HAL_CLEAR_STRUCT(&SMU_ClockInitStruct);
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;
    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) and switch to it; the
       call also programs the EFLASH controller clock before the switch. */
    __HAL_CLEAR_STRUCT(&SMU_OscInitStruct);
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
