/**
 * @file    SPI_IT_DRV_001.c
 * @brief   HAL SPI integration test case 001 (clock divider sweep).
 *
 * HAL library port of the original AS32x601 standard-library test case
 * SPI_IT_DRV_001.c, which drives SPI3 in master mode and lets the operator
 * choose the SPI clock divider on the console. The port sweeps every divider
 * of the table in one run, so no console interaction is needed and the case is
 * repeatable. Only HAL library APIs are used; the register read backs are
 * there to document what was programmed.
 *
 * Tested functionality:
 *   HAL_SPI_StructInit()
 *   HAL_SPI_Init()
 *   HAL_SPI_ResetFIFO()
 *   HAL_SPI_NSSConfig()         (selects SPI_Slave0 so a peer sees the frames)
 *   HAL_SPI_Transmit()          (blocking, 64 frames of 8 bit)
 *   HAL_SPI_GetState()
 *   HAL_SPI_GetError()
 *   HAL_SPI_MspInit()           (overridden: clock gate, reset pulse, pins)
 *
 * Test procedure:
 *   For every divider of the table (2, 4, 8, 16, 32, 64, 128, 256, 512):
 *     1. program the divider and initialize SPI3 in master mode;
 *     2. reset both FIFOs and select SPI_Slave0 (assert CS0);
 *     3. read the clock divider field back from CLKCR;
 *     4. transmit 64 frames and check the status / state / error code;
 *     5. release SPI_Slave0 and print the resulting SPI clock frequency.
 *
 * Expected behaviour:
 *   - every initialization returns HAL_OK and CLKCR carries the requested
 *     divider;
 *   - every transmission completes with HAL_OK, the handle returns to READY
 *     and the error code stays NONE;
 *   - every check prints [PASS] and "summary : failures = 0";
 *   - an oscilloscope on PD3 (SCK) shows APBBus1 / divider, i.e. the
 *     frequency printed for every step (22.5 MHz / divider with the clock tree
 *     of this suite);
 *   - an oscilloscope on PC10 (CS0) shows it driven low for the whole 64 frame
 *     burst of every step, so a peer latches the frames.
 *
 * Note:
 *   - SPI3 lives on APBBus1, so the printed bus clock is APBBus1.
 *   - The chip drives the slave select from the SSR register, so the CS pin is
 *     mapped to the SPI alternate function (GPIO_MODE_AF_PP) here. SSR must
 *     still be written explicitly: it resets to 0 (no slave selected) and
 *     HAL_SPI_Init() does not touch it, so a case that only transmits asserts
 *     no chip select at all and a peer never sees the frames. The transfer is
 *     therefore wrapped in HAL_SPI_NSSConfig(), as the reference test case
 *     does with SPI_NSSConfig().
 *   - HAL_SPI_Transmit() reads and discards the received frames in master mode
 *     (they keep the full duplex shifter running), so no peer is required for
 *     this case.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console: USART0 on GPIOD pin 8 (TX) / pin 9 (RX), 115200 8N1 */
#define TEST_BAUDRATE                   (115200U)

/* Device under test: SPI3 (as in the reference test case)
 *   CS0  = PC10   SCK  = PD3   MOSI = PD1   MISO = PD2
 */
#define TEST_SPI                        SPI3
#define TEST_CS_PORT                    GPIOC
#define TEST_CS_PIN                     GPIO_PIN_10
#define TEST_CS_SOURCE                  GPIO_PinSource10
#define TEST_SCK_PORT                   GPIOD
#define TEST_SCK_PIN                    GPIO_PIN_3
#define TEST_SCK_SOURCE                 GPIO_PinSource3
#define TEST_MOSI_PORT                  GPIOD
#define TEST_MOSI_PIN                   GPIO_PIN_1
#define TEST_MOSI_SOURCE                GPIO_PinSource1
#define TEST_MISO_PORT                  GPIOD
#define TEST_MISO_PIN                   GPIO_PIN_2
#define TEST_MISO_SOURCE                GPIO_PinSource2
#define TEST_PIN_AF                     GPIO_AF_SPI3

/* Frame geometry, timeouts and the divider table */
#define TX_FRAME_COUNT                  (64U)
#define TRANSFER_TIMEOUT_MS             (1000U)
#define DIV_COUNT                       (9U)

/* Private variables ---------------------------------------------------------*/
static SPI_HandleTypeDef hspi_dev;              /*!< device under test      */
static HAL_SMU_HandleTypeDef hsmu_clk;          /*!< SMU handle (clock tree) */
static uint8 tx_data[TX_FRAME_COUNT];           /*!< transmit pattern        */
static volatile uint32 check_failures = 0U;     /*!< failed check counter    */

/* Divider register value and the factor it stands for (the register field is
 * not a linear divider: 0 = /2, 1 = /4, 3 = /8 ... 0xFF = /512) */
static const uint32 div_reg[DIV_COUNT] = {
    SPI_CLKDiv2, SPI_CLKDiv4, SPI_CLKDiv8, SPI_CLKDiv16, SPI_CLKDiv32,
    SPI_CLKDiv64, SPI_CLKDiv128, SPI_CLKDiv256, SPI_CLKDiv512
};
static const uint32 div_factor[DIV_COUNT] = {
    2U, 4U, 8U, 16U, 32U, 64U, 128U, 256U, 512U
};

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void Check(const char *name, uint32 condition);
static void Summary(void);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    SPI_InitTypeDef spi_init;
    HAL_StatusTypeDef status;
    uint32 index;
    uint32 div_index;
    uint32 divider;
    uint32 frames_sent;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock tree */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART (USART0 on GPIOD pin 8 / pin 9) */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== SPI_IT_DRV_001 : clock divider sweep (SPI3) ===\r\n");

    /* Transmit pattern: 0, 1, 2 .. 63 (as in the reference test case) */
    for (index = 0U; index < TX_FRAME_COUNT; index++)
    {
        tx_data[index] = (uint8)index;
    }

    printf("core clock   : %u Hz\r\n", PRINT_U32(SystemCoreClock));
    printf("APBBus1 clock: %u Hz (SPI3 bus)\r\n", PRINT_U32(HAL_SMU_GetPCLK1Freq()));

    /* The handle is cleared once: the first HAL_SPI_Init() call is the one
     * that takes the handle out of the RESET state and therefore the one that
     * runs HAL_SPI_MspInit() (clock gate, reset pulse and pin mapping). */
    __HAL_CLEAR_STRUCT(&hspi_dev);

    for (div_index = 0U; div_index < DIV_COUNT; div_index++)
    {
        divider = div_factor[div_index];

        /* Step 1: program the divider of this iteration */
        HAL_SPI_StructInit(&spi_init);
        spi_init.SPI_CLKDiv       = div_reg[div_index];
        spi_init.SPI_Mode         = SPI_Mode_Master;
        spi_init.SPI_FrameSize    = SPI_FrameSize_8b;
        spi_init.SPI_MotorolaMode = SPI_Motorola_Mode0;
        spi_init.SPI_TransMode    = SPI_TransNor;

        hspi_dev.Instance = TEST_SPI;
        hspi_dev.Init     = spi_init;

        printf("\r\n-- divider /%u --\r\n", PRINT_U32(divider));

        status = HAL_SPI_Init(&hspi_dev);
        Check("HAL_SPI_Init returns HAL_OK", (uint32)((status == HAL_OK) ? 1U : 0U));
        Check("state after init is READY",
              (uint32)((HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_READY) ? 1U : 0U));
        Check("error code after init is NONE",
              (uint32)((HAL_SPI_GetError(&hspi_dev) == HAL_SPI_ERROR_NONE) ? 1U : 0U));

        /* Step 2: put the FIFOs in a known state and assert the slave select.
         * SSR resets to 0 (no slave selected) and HAL_SPI_Init() does not
         * program it, so this is what makes the frames visible to the peer. */
        HAL_SPI_ResetFIFO(&hspi_dev, SPI_RESETFIFO_TXANDRX);
        HAL_SPI_NSSConfig(&hspi_dev, SPI_Slave0, SPI_ENABLE);

        /* Step 3: the clock divider field must carry the requested value */
        printf("CLKCR        : 0x%08X (divider field 0x%02X, requested 0x%02X) %s\r\n",
               PRINT_U32((uint32)TEST_SPI->CLKCR),
               PRINT_U32((uint32)TEST_SPI->CLKCR & SPI_CLKCR_CLKCR_Msk),
               PRINT_U32(div_reg[div_index] & SPI_CLKCR_CLKCR_Msk),
               ((((uint32)TEST_SPI->CLKCR & SPI_CLKCR_CLKCR_Msk) ==
                 (div_reg[div_index] & SPI_CLKCR_CLKCR_Msk)) ? "[PASS]" : "[FAIL]"));
        if (((uint32)TEST_SPI->CLKCR & SPI_CLKCR_CLKCR_Msk) !=
            (div_reg[div_index] & SPI_CLKCR_CLKCR_Msk))
        {
            check_failures++;
        }

        printf("SPI clock    : %u Hz\r\n", PRINT_U32(HAL_SMU_GetPCLK1Freq() / divider));

        /* Step 4: transmit the pattern */
        status = HAL_SPI_Transmit(&hspi_dev, tx_data, TX_FRAME_COUNT,
                                  TRANSFER_TIMEOUT_MS);
        Check("HAL_SPI_Transmit returns HAL_OK", (uint32)((status == HAL_OK) ? 1U : 0U));
        Check("state after the transfer is READY",
              (uint32)((HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_READY) ? 1U : 0U));
        Check("error code after the transfer is NONE",
              (uint32)((HAL_SPI_GetError(&hspi_dev) == HAL_SPI_ERROR_NONE) ? 1U : 0U));

        /* The peripheral must still be enabled and the shifter stopped */
        Check("CR0.SPE is still set",
              (uint32)((((uint32)TEST_SPI->CR0 & SPI_CR0_SPE) != 0U) ? 1U : 0U));
        Check("SR.BUSS (busy) is cleared",
              (uint32)((((uint32)TEST_SPI->SR & SPI_SR_BUSS) == 0U) ? 1U : 0U));

        frames_sent = TX_FRAME_COUNT;
        printf("frames sent  : %u of %u\r\n",
               PRINT_U32(frames_sent), PRINT_U32(TX_FRAME_COUNT));

        /* Release the slave select again, so the line is not left asserted
         * between the dividers of the sweep */
        HAL_SPI_NSSConfig(&hspi_dev, SPI_Slave0, SPI_DISABLE);
    }

    Summary();

    while (1)
    {
        delay_ms(1000U);
    }
}

/**
 * @brief  Report the result of one check.
 * @param  name: short description of the check.
 * @param  condition: 0 = FAIL, non zero = PASS.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("%-46s : [PASS]\r\n", name);
    }
    else
    {
        check_failures++;
        printf("%-46s : [FAIL]\r\n", name);
    }
}

/**
 * @brief  Print the accumulated failure counter.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(check_failures));
}

/**
 * @brief  MSP initialization of the device under test.
 * @note   Strong override of the weak driver callback: it runs on the first
 *         HAL_SPI_Init() call, before the handle lock is taken and before the
 *         first register access, so the peripheral clock, the reset pulse and
 *         the pin mapping are in place.
 * @param  hspi: SPI handle of the device under test.
 * @retval None
 */
void HAL_SPI_MspInit(SPI_HandleTypeDef *hspi)
{
    GPIO_InitTypeDef gpio;

    if (hspi->Instance != TEST_SPI)
    {
        return;
    }

    /* Peripheral clock gate and reset pulse */
    __HAL_SMU_SPI3_CLK_ENABLE();
    __HAL_SMU_SPI3_FORCE_RESET();
    __HAL_SMU_SPI3_RELEASE_RESET();

    /* Port clock gates used by this case */
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();

    /* CS0 pin: the chip drives it from the SSR register, so it is mapped to
     * the SPI alternate function */
    HAL_GPIO_PinAFConfig(TEST_CS_PORT, TEST_CS_SOURCE, TEST_PIN_AF);
    __HAL_CLEAR_STRUCT(&gpio);
    gpio.Size         = sizeof(gpio);
    gpio.Version      = GPIO_INIT_VERSION;
    gpio.Pin          = TEST_CS_PIN;
    gpio.Mode         = GPIO_MODE_AF_PP;
    gpio.Pull         = GPIO_NOPULL;
    gpio.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    gpio.Alternate    = TEST_PIN_AF;
    HAL_GPIO_Init(TEST_CS_PORT, &gpio);

    /* SCK pin */
    HAL_GPIO_PinAFConfig(TEST_SCK_PORT, TEST_SCK_SOURCE, TEST_PIN_AF);
    gpio.Pin  = TEST_SCK_PIN;
    gpio.Mode = GPIO_MODE_AF_PP;
    HAL_GPIO_Init(TEST_SCK_PORT, &gpio);

    /* MOSI pin */
    HAL_GPIO_PinAFConfig(TEST_MOSI_PORT, TEST_MOSI_SOURCE, TEST_PIN_AF);
    gpio.Pin  = TEST_MOSI_PIN;
    gpio.Mode = GPIO_MODE_AF_PP;
    HAL_GPIO_Init(TEST_MOSI_PORT, &gpio);

    /* MISO pin: alternate function input, floating (as in the reference case) */
    HAL_GPIO_PinAFConfig(TEST_MISO_PORT, TEST_MISO_SOURCE, TEST_PIN_AF);
    gpio.Pin  = TEST_MISO_PIN;
    gpio.Mode = GPIO_MODE_INPUT;
    HAL_GPIO_Init(TEST_MISO_PORT, &gpio);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the CLINT / CMU / MPU / USART integration tests:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2, CANX2 by
 *         8, so the APB bus clock is 22.5 MHz and the SPI clock is
 *         APBBus1 / divider.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef    SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the same set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Clock tree order: the bus dividers are written while the system clock is
       still the power on source (FIRC), then the PLL is configured and the
       system clock is switched to it. HAL_SMU_OscConfig() also programs the
       flash controller clock before the switch and updates SystemCoreClock. */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
