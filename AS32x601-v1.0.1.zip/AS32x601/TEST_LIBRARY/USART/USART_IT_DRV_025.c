/**
 * @file    USART_IT_DRV_025.c
 * @brief   HAL USART integration test case 025 (transmit with DMA on USART0).
 *
 * HAL library port of the original AS32x601 standard-library test case
 * USART_IT_DRV_025.c, which drives USART0. Only HAL library APIs are
 * used; the register read backs are there to document what was programmed.
 *
 * Tested functionality:
 *   HAL_USART_DeInit()
 *   HAL_USART_StructInit()
 *   HAL_USART_Init()
 *   HAL_USART_EnableFIFO()
 *   HAL_USART_GetState()
 *   HAL_USART_GetError()
 *   HAL_USART_Transmit_DMA()
 *   HAL_DMA_Init()
 *   HAL_DMA_ConfigPeriphIF()
 *   HAL_DMA_GetState()
 *   HAL_USART_TxCpltCallback()
 *
 * Test procedure:
 *   1. map and configure the pins of the device under test;
 *   2. program the frame parameters and initialize the USART;
 *   3. initialize the DMA channel, route the USART request number to it and bind it to the handle;
 *   4. start a DMA driven transmission of 8 bytes;
 *   5. wait for the DMA completion callback and check the state of both peripherals;
 *   6. wait one frame period and repeat.
 *
 * Expected behaviour:
 *   - HAL_USART_Transmit_DMA() returns HAL_OK for every frame;
 *   - the DMA completion callback fires exactly once per frame and the USART is back to READY;
 *   - the DMA channel is back to READY and the USART error code stays NONE;
 *   - the serial host receives 0x11 0x22 0x33 0x44 0x55 0x66 0x77 0x88;
 *   - every check prints [PASS] and "summary : failures = 0".
 *
 * Note:
 *   - Frame parameters: baud rate 115200, word length USART_WORDLENGTH_8B, stop bits USART_STOPBITS_1, parity USART_PARITY_NONE, hardware flow control USART_HWCONTROL_NONE, CPOL USART_POLARITY_LOW, CPHA USART_PHASE_1EDGE.
 *   - USART0..USART3 are served by DMA0, USART4..USART7 by DMA1 (one channel each in this case).
 *   - Nothing is printed while the DMA transfer runs: on USART0 the console shares the peripheral with the device under test.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
/* Console: USART0 on GPIOD pin 8 (TX) / pin 9 (RX), 115200 8N1 */
#define TEST_BAUDRATE                   (115200U)

/* Device under test: the pins are the ones the original test case uses */
#define TEST_USART                      USART0
#define TEST_USART_IRQn                 USART0_IRQn
#define TEST_USART_IRQ_HANDLER          USART0_IRQ_Handler
#define TEST_TX_PORT                    GPIOD
#define TEST_TX_PIN                     GPIO_PIN_8
#define TEST_TX_SOURCE                  GPIO_PinSource8
#define TEST_TX_AF                      GPIO_AF_USART0
#define TEST_RX_PORT                    GPIOD
#define TEST_RX_PIN                     GPIO_PIN_9
#define TEST_RX_SOURCE                  GPIO_PinSource9
#define TEST_RX_AF                      GPIO_AF_USART0

/* Frame parameters of this case */
#define TEST_BAUD_RATE                  (115200U)
#define TEST_WORD_LENGTH                USART_WORDLENGTH_8B
#define TEST_STOP_BITS                  USART_STOPBITS_1
#define TEST_PARITY                     USART_PARITY_NONE
#define TEST_MODE                       (USART_MODE_TX_RX)
#define TEST_OVERSAMPLING               USART_OVERSAMPLING_16
#define TEST_FLOW_CONTROL               USART_HWCONTROL_NONE
#define TEST_CLK_POLARITY               USART_POLARITY_LOW
#define TEST_CLK_PHASE                  USART_PHASE_1EDGE
#define TEST_CLK_LASTBIT                USART_LASTBIT_DISABLE
#define TEST_SYNC_MODE                  (0U)
#define TEST_SLAVE_MODE                 (0U)

/* Frame geometry, pacing and timeouts */
#define TX_FRAME_SIZE                   (8U)
#define RX_BURST_SIZE                   (64U)
#define TX_FRAME_PERIOD_MS              (500U)
#define TRANSFER_TIMEOUT_MS             (2000U)
#define WAIT_SPINS                      (20000000U)
#define RX_WAIT_MS                      (1000U)

/* Private variables --------------------------------------------------------*/
static USART_HandleTypeDef husart_dev;          /*!< device under test       */
static HAL_SMU_HandleTypeDef hsmu_clk;          /*!< SMU handle (clock tree) */
static const uint8 tx_data[TX_FRAME_SIZE] = {0x11U, 0x22U, 0x33U, 0x44U,
                                              0x55U, 0x66U, 0x77U, 0x88U};

static volatile uint32 check_failures = 0U;     /*!< failed check counter    */
static DMA_HandleTypeDef hdma_dev;         /*!< DMA channel (transmit) */
static volatile uint32 tx_done = 0U;        /*!< transfer finished flag  */
static volatile uint32 tx_cplt_count = 0U;   /*!< TxCplt callback counter */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void USART_GPIO_Init(void);
static void Check(const char *name, uint32 condition);
static void Summary(void);
static void DMA_Config(void);
static void USART_PLIC_Init(void);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    USART_InitTypeDef usart_init;
    uint32 expected_brr;
    uint32 frame;
    uint32 spins;
    HAL_StatusTypeDef status;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock tree */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART (USART0 on GPIOD pin 8 / pin 9) */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== USART_IT_DRV_025 : transmit with DMA on USART0 ===\r\n");

    /* Step 1: map and configure the pins of the device under test */
    USART_GPIO_Init();

    /* Step 2: program the frame parameters and initialize the USART */
    (void)HAL_USART_DeInit(&husart_dev);

    HAL_USART_StructInit(&usart_init);
    usart_init.BaudRate            = TEST_BAUD_RATE;
    usart_init.WordLength          = TEST_WORD_LENGTH;
    usart_init.StopBits            = TEST_STOP_BITS;
    usart_init.Parity              = TEST_PARITY;
    usart_init.Mode                = TEST_MODE;
    usart_init.OverSampling        = TEST_OVERSAMPLING;
    usart_init.HardwareFlowControl = TEST_FLOW_CONTROL;
    usart_init.CLKPolarity         = TEST_CLK_POLARITY;
    usart_init.CLKPhase            = TEST_CLK_PHASE;
    usart_init.CLKLastBit          = TEST_CLK_LASTBIT;

    husart_dev.Instance = TEST_USART;
    husart_dev.Init     = usart_init;

    Check("HAL_USART_Init", (uint32)((HAL_USART_Init(&husart_dev) == HAL_OK) ? 1U : 0U));
    Check("state after init is READY",
          (uint32)((HAL_USART_GetState(&husart_dev) == HAL_USART_STATE_READY) ? 1U : 0U));
    Check("error code after init is NONE",
          (uint32)((HAL_USART_GetError(&husart_dev) == HAL_USART_ERROR_NONE) ? 1U : 0U));

    /* Cross check the baud rate divider: the driver computes the divider as
     * BRR = bus clock / baud rate. USART0..USART3 are clocked by APBBus0 and
     * USART4..USART7 by APBBus1. */
    expected_brr = HAL_SMU_GetPCLK0Freq() / TEST_BAUD_RATE;

    printf("bus clock       : %u Hz\r\n", PRINT_U32(HAL_SMU_GetPCLK0Freq()));
    printf("divider         : BRR = %u (expected %u) %s\r\n",
           PRINT_U32((uint32)TEST_USART->BRR), PRINT_U32(expected_brr),
           (((uint32)TEST_USART->BRR == expected_brr) ? "[PASS]" : "[FAIL]"));
    if ((uint32)TEST_USART->BRR != expected_brr)
    {
        check_failures++;
    }

    /* Step 3: enable the FIFO mode, as the original test case does */
    Check("HAL_USART_EnableFIFO",
          (uint32)((HAL_USART_EnableFIFO(&husart_dev) == HAL_OK) ? 1U : 0U));

    /* Interrupt routing of this case */
    USART_PLIC_Init();

    /* Step 4: initialize the DMA channel of the transmit request and bind it
     * to the USART handle (the original test case does the same with
     * USART_DMACmd + DMA_Init + DMA_Cmd). The transfer itself is then started
     * through the HAL entry point, which programs the request, the channel and
     * the completion interrupt. */
    DMA_Config();
    husart_dev.hdmatx = &hdma_dev;

    frame = 0U;
    while (1)
    {
        tx_done       = 0U;
        tx_cplt_count = 0U;

        status = HAL_USART_Transmit_DMA(&husart_dev, (uint8 *)tx_data, TX_FRAME_SIZE);
        frame++;

        if (status != HAL_OK)
        {
            check_failures++;
            printf("frame %u : HAL_USART_Transmit_DMA = %u [FAIL]\r\n",
                   PRINT_U32(frame), PRINT_U32((uint32)status));
        }
        else
        {
            /* Wait for the DMA completion callback. Nothing is printed while
             * the transfer is running: on USART0 the console shares the
             * peripheral, so a console write would compete with the DMA
             * stream for the transmit register. */
            spins = 0U;
            while ((tx_done == 0U) && (spins < WAIT_SPINS))
            {
                spins++;
            }

            Check("DMA transmit complete callback fired once",
                  (uint32)(((tx_done != 0U) && (tx_cplt_count == 1U)) ? 1U : 0U));
            Check("USART back to READY after the DMA frame",
                  (uint32)((HAL_USART_GetState(&husart_dev) == HAL_USART_STATE_READY) ? 1U : 0U));
            Check("DMA channel back to READY",
                  (uint32)((HAL_DMA_GetState(&hdma_dev) == HAL_DMA_STATE_READY) ? 1U : 0U));
            Check("no USART error after the DMA frame",
                  (uint32)((HAL_USART_GetError(&husart_dev) == HAL_USART_ERROR_NONE) ? 1U : 0U));

            printf("frame %u : DMA sent 8 bytes, spins = %u\r\n",
                   PRINT_U32(frame), PRINT_U32(spins));
        }

        Summary();
        delay_ms(TX_FRAME_PERIOD_MS);
    }
}

/**
 * @brief  Report the result of one check.
 * @param  name: short description of the check.
 * @param  condition: 0 = FAIL, non zero = PASS.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("%-44s : [PASS]\r\n", name);
    }
    else
    {
        check_failures++;
        printf("%-44s : [FAIL]\r\n", name);
    }
}

/**
 * @brief  Print the accumulated failure counter.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("summary : failures = %u\r\n", PRINT_U32(check_failures));
}
/**
 * @brief  Configure the PLIC source(s) of this case.
 * @param  None
 * @retval None
 */
static void USART_PLIC_Init(void)
{
    PLIC_InitTypeDef plic;

    __HAL_SMU_PLIC_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&plic);
    plic.Size               = sizeof(plic);
    plic.Version            = PLIC_INIT_VERSION;
    plic.PLIC_IRQPriority   = 1U;
    plic.PLIC_IRQChannelCmd = ENABLE;

    plic.PLIC_IRQChannel    = TEST_USART_IRQn;
    HAL_PLIC_Init(&plic);

    /* The DMA controller raises its own interrupt line */
    plic.PLIC_IRQChannel    = DMA0_IRQn;
    HAL_PLIC_Init(&plic);

}

/**
 * @brief  Map and configure the pins of the device under test.
 * @note   The ports are the ones the original test case uses. GPIOH lives in
 *         the always on domain, so the library provides no clock gate for it.
 * @param  None
 * @retval None
 */
static void USART_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    /* Port clock gates used by this case */
    __HAL_SMU_GPIOD_CLK_ENABLE();

    /* TX pin: alternate function push pull */
    HAL_GPIO_PinAFConfig(TEST_TX_PORT, TEST_TX_SOURCE, TEST_TX_AF);
    __HAL_CLEAR_STRUCT(&GPIO_InitStruct);
    GPIO_InitStruct.Size         = sizeof(GPIO_InitStruct);
    GPIO_InitStruct.Version      = GPIO_INIT_VERSION;
    GPIO_InitStruct.Pin          = TEST_TX_PIN;
    GPIO_InitStruct.Mode         = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull         = GPIO_NOPULL;
    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;
    GPIO_InitStruct.Alternate    = TEST_TX_AF;
    HAL_GPIO_Init(TEST_TX_PORT, &GPIO_InitStruct);

    /* RX pin: alternate function input (floating) */
    HAL_GPIO_PinAFConfig(TEST_RX_PORT, TEST_RX_SOURCE, TEST_RX_AF);
    GPIO_InitStruct.Pin       = TEST_RX_PIN;
    GPIO_InitStruct.Mode      = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull      = GPIO_NOPULL;
    GPIO_InitStruct.Alternate = TEST_RX_AF;
    HAL_GPIO_Init(TEST_RX_PORT, &GPIO_InitStruct);

}
/**
 * @brief  USART interrupt handler (weak symbol of the trap entry).
 * @param  None
 * @retval None
 */
void TEST_USART_IRQ_HANDLER(void)
{
    HAL_USART_IRQHandler(&husart_dev);
}
/**
 * @brief  DMA controller interrupt handler (weak symbol of the trap entry).
 * @note   One line is shared by the 16 channels of the controller, so every
 *         active channel handle of the controller is served here.
 * @param  None
 * @retval None
 */
void DMA0_IRQ_Handler(void)
{
    HAL_DMA_IRQHandler(&hdma_dev);
}
/**
 * @brief  DMA transmit complete callback of the device under test.
 * @param  husart: USART handle.
 * @retval None
 */
void HAL_USART_TxCpltCallback(USART_HandleTypeDef *husart)
{
    if (husart == &husart_dev)
    {
        tx_cplt_count++;
        tx_done = 1U;
    }
}

/**
 * @brief  Program the DMA channel that carries the USART transmit request.
 * @note   The request of the USART is routed to the channel with
 *         HAL_DMA_ConfigPeriphIF(); the driver then enables the request and the
 *         channel completion interrupt when the transfer is started.
 * @param  None
 * @retval None
 */
static void DMA_Config(void)
{
    DMA_InitTypeDef dma_init;

    /* DMA controller clock gate and reset pulse */
    __HAL_SMU_DMA0_CLK_ENABLE();
    __HAL_SMU_DMA0_FORCE_RESET();
    __HAL_SMU_DMA0_RELEASE_RESET();

    __HAL_CLEAR_STRUCT(&hdma_dev);
    hdma_dev.Instance = DMA0_Channel0;

    HAL_DMA_StructInit(&dma_init);
    dma_init.DMA_PeripheralBaseAddr = (uint32)&TEST_USART->TDR;
    dma_init.DMA_MemoryBaseAddr     = (uint32)tx_data;
    dma_init.DMA_DIR                = DMA_MEMORY_TO_PERIPH;
    dma_init.DMA_BufferSize         = TX_FRAME_SIZE;
    dma_init.DMA_PeripheralInc      = DMA_PINC_DISABLE;
    dma_init.DMA_MemoryInc          = DMA_MINC_ENABLE;
    dma_init.DMA_PeripheralDataSize = DMA_PDATAALIGN_BYTE;
    dma_init.DMA_MemoryDataSize     = DMA_MDATAALIGN_BYTE;
    dma_init.DMA_Priority           = DMA_PRIORITY_MEDIUM;
    dma_init.DMA_M2M                = DMA_M2M_Disable;
    dma_init.DMA_Mode               = DMA_NORMAL;
    hdma_dev.Init = dma_init;

    Check("HAL_DMA_Init",
          (uint32)((HAL_DMA_Init(&hdma_dev) == HAL_OK) ? 1U : 0U));

    /* Route the USART request number to the channel */
    HAL_DMA_ConfigPeriphIF(&hdma_dev, USART0_IF);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the CLINT / CMU / MPU integration tests: PLL
 *         VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2, CANX2 by 8.
 *         With this tree the APB bus clock is 22.5 MHz, which is the reference
 *         the baud rate divider check of every case is computed from.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef    SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the same set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* Clock gate and reset pulse of the USART under test */
    /* Initialize the PMU before the voltage scaling calls: the LDO API is
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Clock tree order: this is the order the chip requires (and the one the
       reference test case uses):
         1. write the bus dividers while the system clock is still the power on
            source (FIRC), so that the new divider values are already in place
            when the faster clock arrives. Writing them after the switch leaves
            the buses at their reset dividers for a moment at the new core
            clock, which the core does not survive at 180 MHz.
         2. configure the PLL and switch the system clock to it. This call also
            programs the flash controller clock before the switch and update
            SystemCoreClock afterwards. */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
