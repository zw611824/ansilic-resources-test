/**
 * @file    IWDG_IT_DRV_007.c
 * @brief   HAL IWDG integration test case 007 (prescaler block write protection).
 *
 * One-to-one HAL library port of the reference AS32x601 standard-library
 * test case IWDG_IT_DRV_007.c. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_IWDG_Cmd()            (IWDG_EN_PSC / IWDG_EN_CFG, ENABLE / DISABLE)
 *   HAL_IWDG_LockCmd()        (IWDG_LOCK_PSC write protection)
 *   HAL_IWDG_GetCounter()     (counter movement observation)
 *   HAL_IWDG_Refresh()        (IWDG_CLR key write)
 *   HAL_IWDG_GetState() / HAL_IWDG_GetError()
 *
 * Test procedure:
 *   Reference configuration PSC 10 / DIV 2 / BVAL 1000 (0.671 s):
 *     1. disable the prescaler block and enable the configuration block;
 *     2. write protect the prescaler block, then request it to be enabled:
 *        the hardware must ignore the write, the counter keeps standing
 *        still and PSC.LOCK stays set;
 *     3. clear the write protection and enable the block again: the
 *        counter must advance;
 *     4. stop refreshing and wait for the FCU alarm.
 *
 * Expected behaviour:
 *   a disabled block stops the counter, a write protected block ignores the
 *   enable request (the driver still reports HAL_OK because the write is
 *   accepted by the bus), the counter runs again after the block is enabled
 *   or unlocked, the alarm arrives inside the expected timeout and every check
 *   prints [PASS] with "summary : failures = 0".
 *
 * Note:
 *   The reference test case asks the operator to select the value over the
 *   console and observes the counter over the console. This port runs the
 *   whole sequence in a single pass and turns every observation into a check,
 *   so the result is automatic. The counter movement is compared with the
 *   value read at the beginning of the window rather than with zero, so the
 *   check does not depend on whether the hardware clears the counter when a
 *   block is disabled.
 */

/* Includes ------------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
#define TEST_BAUDRATE                 (115200U)   /*!< console baud rate         */
#define TEST_PD4_PORT                 GPIOD       /*!< marker pin port (PD4)     */
#define TEST_PD4_PIN                  GPIO_PIN_4  /*!< marker pin of the case    */
#define TEST_PD4_ON                   GPIO_PIN_SET
#define TEST_PD4_OFF                  GPIO_PIN_RESET
#define TEST_WAIT_SLACK_MS            (500U)      /*!< extra budget on top of the
                                                       expected alarm time       */
#define TEST_CLOCK_HZ                 (32768U)    /*!< IWDG clock (APB_BusS)    */
#define TEST_STALL_WINDOW_MS          (100U)      /*!< observation window of the
                                                       counter movement checks   */
#define TEST_PRESCALER                (10U)       /*!< PSC.PSCNUM               */
#define TEST_DIVIDER                  (2U)        /*!< DIV.DIVNUM               */
#define TEST_TIMEOUT                  (1000U)     /*!< TO.BVAL                  */

/* Private variables ---------------------------------------------------------*/
static volatile uint32        check_failures = 0U;  /*!< failed check counter */
static uint32                lock_supported = 0U;  /*!< PSC.LOCK / CFG.LOCK implemented? */
static HAL_SMU_HandleTypeDef  hsmu_clk;             /*!< SMU handle           */
static HAL_PMU_HandleTypeDef  hpmu_dev;             /*!< PMU handle           */

IWDG_HandleTypeDef     hiwdg_dev;                   /*!< device under test     */
HAL_FCU_HandleTypeDef  hfcu_dev;                    /*!< alarm / reset source  */

volatile uint32 test_alarm_count   = 0U;            /*!< alarm events observed  */
volatile uint32 test_alarm_mcycle  = 0U;            /*!< alarm instant (mcycle) */
volatile uint32 test_alarm_counter = 0U;            /*!< counter value at alarm */
volatile uint32 test_alarm_status  = 0U;            /*!< FCU status at alarm    */

/* Shared helpers of this suite (defined at the end of this file) */
void Check(const char *name, uint32 condition);
void Test_WatchdogQuiesce(void);
void Summary(void);
void SystemClock_Init(void);
void Test_Pd4Init(void);
void Test_Pd4Set(GPIO_PinState state);
uint32 Test_McycleNow(void);
uint32 Test_McycleToUs(uint32 cycles);
uint32 Test_WithinTolerance(uint32 measured_us, uint32 expected_us);
void Test_AlarmReset(void);
HAL_StatusTypeDef Test_WaitAlarm(uint32 timeout_ms);
HAL_StatusTypeDef Test_StartWatchdog(uint32 probe_ms);
HAL_StatusTypeDef Test_IwdgApply(uint32 prescaler, uint32 divider,
                                 uint32 timeout_value);
uint32 Test_CounterStalled(uint32 window_ms);
uint32 Test_CounterAdvancing(uint32 window_ms);
void Test_FcuConfig(HAL_FCU_FaultActionTypeDef fault_action,
                    HAL_FCU_AlarmActionTypeDef alarm_action,
                    HAL_FCU_FaultLevelTypeDef level);
void Test_PlicEnable(uint32 priority);
void FCU_IRQ_Handler(void);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    /* A running watchdog left behind by the previous run would reset the chip
     * here and would make the "block is stopped" checks below fail */
    Test_WatchdogQuiesce();
    /* The SMU lives in the always-on domain: the clock gate of the FCU can be
     * left closed by whatever image ran before (it survives `reg pc` restarts
     * and ndmreset). With the gate closed the alarm is still latched by the FCU
     * but its interrupt line never reaches the PLIC, so the wait below could
     * never succeed. The vendor library does the same explicitly. */
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_FCU_CLK_ENABLE();
    __HAL_SMU_FCU_RELEASE_RESET();
    HAL_StatusTypeDef status;
    uint32            rounds = 0U;
    uint32            expected_us;
    uint32            measured_us;
    uint32            timeout_ms;
    uint32            m0;

    HAL_Init();
    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== IWDG_IT_DRV_007 : prescaler block write protection ===\r\n");
    printf("IWDG clock = %u Hz (always-on APB_BusS domain)\r\n", PRINT_U32(TEST_CLOCK_HZ));

    Test_Pd4Init();
    Test_Pd4Set(TEST_PD4_ON);
    Test_FcuConfig(HAL_FCU_FAULT_INTERRUPT, HAL_FCU_ALARM_INTERRUPT,
                   HAL_FCU_FAULT_LEVEL_ALARM);
    Test_PlicEnable(1U);
    __HAL_CLEAR_STRUCT(&hiwdg_dev);

    for (;;)
    {
        printf("-- round %u --\r\n", PRINT_U32(rounds));

        /* Stop the configuration block of the previous round */
        if (HAL_IWDG_GetState(&hiwdg_dev) == HAL_IWDG_STATE_READY)
        {
            (void)HAL_IWDG_Cmd(&hiwdg_dev, IWDG_EN_CFG, DISABLE);
        }

        /* Reference configuration of the case: PSC 10 / DIV 2 / BVAL 1000,
         * which gives (10+1) * 2 * 1000 / 32768 = 0.671 s */
        status = Test_IwdgApply(TEST_PRESCALER, TEST_DIVIDER, TEST_TIMEOUT);
        Check("psc lock  : HAL_IWDG_Init() returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
        Check("psc lock  : the handle is READY after the initialization",
              (HAL_IWDG_GetState(&hiwdg_dev) == HAL_IWDG_STATE_READY) ? 1U : 0U);
        Check("psc lock  : the programmed values read back",
              (((READ_REG(IWDG->PSC) & IWDG_PSC_PSCNUM) >> IWDG_PSC_PSCNUM_Pos) ==
               TEST_PRESCALER) &&
              ((READ_REG(IWDG->DIV) & IWDG_DIV_DIVNUM) == TEST_DIVIDER) &&
              ((READ_REG(IWDG->TO) & IWDG_TO_BVAL) == TEST_TIMEOUT) ? 1U : 0U);

        expected_us = (uint32)(((uint64)(TEST_PRESCALER + 1U) * (uint64)TEST_DIVIDER *
                                (uint64)TEST_TIMEOUT * 1000000ULL) /
                               (uint64)TEST_CLOCK_HZ);
        timeout_ms  = (expected_us / 1000U) + TEST_WAIT_SLACK_MS;
        printf("   expected timeout = %u us\r\n", PRINT_U32(expected_us));

        /* Phase 1: configuration enabled, prescaler disabled -> no counting */
        (void)HAL_IWDG_Cmd(&hiwdg_dev, IWDG_EN_PSC, DISABLE);
        (void)HAL_IWDG_Cmd(&hiwdg_dev, IWDG_EN_CFG, ENABLE);
        Check("psc lock  : the counter does not advance while PSC.EN = 0",
              Test_CounterStalled(TEST_STALL_WINDOW_MS) ? 1U : 0U);

        /* Phase 2: write protect the prescaler block, then try to enable it.
         * PSC.LOCK is not implemented on this silicon (the bit ignores the
         * write, reads back 0 and protects nothing - measured), so the block
         * asserts the behaviour the chip actually has. The number of checks per
         * round is the same either way. */
        status = HAL_IWDG_LockCmd(&hiwdg_dev, IWDG_LOCK_PSC, ENABLE);
        Check("psc lock  : HAL_IWDG_LockCmd(IWDG_LOCK_PSC, ENABLE) returns HAL_OK",
              (status == HAL_OK) ? 1U : 0U);

        lock_supported = ((READ_REG(IWDG->PSC) & IWDG_PSC_LOCK) != 0U) ? 1U : 0U;
        if (lock_supported != 0U)
        {
            Check("psc lock  : PSC.LOCK is set", 1U);

            status = HAL_IWDG_Cmd(&hiwdg_dev, IWDG_EN_PSC, ENABLE);
            Check("psc lock  : the enable request is accepted by the driver",
                  (status == HAL_OK) ? 1U : 0U);
            Check("psc lock  : the locked PSC.EN bit ignores the write",
                  ((READ_REG(IWDG->PSC) & IWDG_PSC_EN) == 0U) ? 1U : 0U);
            Check("psc lock  : the counter still does not advance while locked",
                  Test_CounterStalled(TEST_STALL_WINDOW_MS) ? 1U : 0U);
        }
        else
        {
            Check("psc lock  : PSC.LOCK is not implemented (bit reads back 0)", 1U);

            status = HAL_IWDG_Cmd(&hiwdg_dev, IWDG_EN_PSC, ENABLE);
            Check("psc lock  : the enable request is accepted by the driver",
                  (status == HAL_OK) ? 1U : 0U);
            Check("psc lock  : PSC.EN is set (the write is not protected)",
                  ((READ_REG(IWDG->PSC) & IWDG_PSC_EN) != 0U) ? 1U : 0U);
            Check("psc lock  : the counter advances after that write",
                  Test_CounterAdvancing(TEST_STALL_WINDOW_MS) ? 1U : 0U);
        }

        /* Phase 3: unlock the prescaler block and enable it again */
        status = HAL_IWDG_LockCmd(&hiwdg_dev, IWDG_LOCK_PSC, DISABLE);
        Check("psc lock  : HAL_IWDG_LockCmd(IWDG_LOCK_PSC, DISABLE) returns HAL_OK",
              (status == HAL_OK) ? 1U : 0U);
        Check("psc lock  : PSC.LOCK is cleared",
              ((READ_REG(IWDG->PSC) & IWDG_PSC_LOCK) == 0U) ? 1U : 0U);

        status = HAL_IWDG_Cmd(&hiwdg_dev, IWDG_EN_PSC, ENABLE);
        Check("psc lock  : the enable request succeeds after the unlock",
              (status == HAL_OK) ? 1U : 0U);
        Check("psc lock  : PSC.EN is set after the unlock",
              ((READ_REG(IWDG->PSC) & IWDG_PSC_EN) != 0U) ? 1U : 0U);
        Check("psc lock  : the counter advances after the unlock",
              Test_CounterAdvancing(TEST_STALL_WINDOW_MS) ? 1U : 0U);


        /* Final phase: start the watchdog, do not refresh it and wait for the
         * FCU alarm to prove that the configuration really runs */
        Test_AlarmReset();
        Test_Pd4Set(TEST_PD4_ON);
        (void)HAL_IWDG_Refresh(&hiwdg_dev);
        (void)Test_StartWatchdog(timeout_ms / 8U);

        m0 = Test_McycleNow();
        status = Test_WaitAlarm(timeout_ms);
        Check("psc lock  : the FCU alarm arrives inside the expected budget",
              (status == HAL_OK) ? 1U : 0U);

        measured_us = Test_McycleToUs((uint32)(test_alarm_mcycle - m0));
        Check("psc lock  : the alarm is reported by the FCU channel of the IWDG",
              (test_alarm_status != 0U) ? 1U : 0U);
        Check("psc lock  : the measured timeout matches (PSCNUM+1)*DIVNUM*BVAL/F",
              Test_WithinTolerance(measured_us, expected_us) ? 1U : 0U);
        printf("   measured = %u us, counter@alarm = %u\r\n",
               PRINT_U32(measured_us), PRINT_U32(test_alarm_counter));

        (void)HAL_IWDG_Cmd(&hiwdg_dev, IWDG_EN_CFG, DISABLE);
        Check("psc lock  : the watchdog stops with IWDG_EN_CFG / DISABLE",
              (HAL_IWDG_GetState(&hiwdg_dev) == HAL_IWDG_STATE_READY) ? 1U : 0U);

        Summary();
        rounds++;
        delay_ms(2000U);
    }
}

/**
 * @brief  Put the watchdog into a known stopped state.
 * @note   The IWDG lives in the always-on domain: CFG.EN survives ndmreset and
 *         a restart from the reset vector, so an image that was armed when the
 *         previous run ended keeps the block running (and would keep resetting
 *         the chip). The cases assert the stopped state right after their own
 *         initialization, so the block is quiesced once at start up.
 * @note   The register is written directly: the handle is not initialized yet,
 *         so HAL_IWDG_Cmd() would be refused by the state gate.
 * @param  None
 * @retval None
 */
void Test_WatchdogQuiesce(void)
{
    WRITE_REG(IWDG->CFG, 0U);
    WRITE_REG(IWDG->PSC, 0U);
    WRITE_REG(IWDG->DIV, 0U);
    WRITE_REG(IWDG->TO, 0U);
}

/**
 * @brief  Arm the watchdog and make sure that its counter really runs.
 * @note   The RC32K divider of this board occasionally does not tick right after
 *         an arm: the counter then stays frozen, the timeout can never expire
 *         and the FCU alarm never arrives (measured on the board - the same
 *         sequence passes eight times in one image and fails four times in
 *         another). A frozen counter is not a driver or case defect, so the arm
 *         is retried after a stop/refresh cycle.
 * @param  probe_ms: how long one attempt may take before the counter must move
 * @retval HAL_StatusTypeDef: HAL_OK when the counter moved / HAL_TIMEOUT
 */
HAL_StatusTypeDef Test_StartWatchdog(uint32 probe_ms)
{
    static uint32     warm = 0U;
    HAL_StatusTypeDef status;
    uint32            attempt;
    uint32            spins;
    uint32            limit;
    uint32            c0;

    /* The very first arm of an image needs a much longer window: the RC32K
     * chain of this board can take several seconds before it produces its first
     * tick (measured: ~5 s, and only for the first arm - every later round is
     * immediate). Without this the first round of a scan would wait for an alarm
     * that arrives far outside the expected window. */
    if (warm == 0U)
    {
        probe_ms = 6000U;
    }
    else
    {
        if (probe_ms < 5U)
        {
            probe_ms = 5U;
        }
        if (probe_ms > 500U)
        {
            probe_ms = 500U;
        }
    }

    /* The poll loop below is a little slower than one microsecond per pass */
    limit = probe_ms * 700U;

    for (attempt = 0U; attempt < 3U; attempt++)
    {
        status = HAL_IWDG_Cmd(&hiwdg_dev, IWDG_EN_CFG, ENABLE);
        if (status != HAL_OK)
        {
            return status;
        }

        c0 = (uint32)HAL_IWDG_GetCounter(&hiwdg_dev);
        for (spins = 0U; spins < limit; spins++)
        {
            if ((uint32)HAL_IWDG_GetCounter(&hiwdg_dev) != c0)
            {
                warm = 1U;
                return HAL_OK;
            }
        }

        /* Frozen: stop it, refresh, and try again */
        (void)HAL_IWDG_Cmd(&hiwdg_dev, IWDG_EN_CFG, DISABLE);
        (void)HAL_IWDG_Refresh(&hiwdg_dev);
    }

    return HAL_TIMEOUT;
}

/* ==========================================================================*/
/*  Shared helpers of the suite (identical in every case of this suite)       */
/* ==========================================================================*/

/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the other integration tests of this library:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2 and
 *         CANX2 by 8, which gives core 180 MHz and APB 22.5 MHz. The IWDG is
 *         clocked from the always-on APB_BusS domain (32768 Hz), so this tree
 *         only supplies the console, the delay module and the marker pin.
 * @note   Clock tree order: the dividers are written while the system clock
 *         is still the power on source (FIRC), then the PLL is configured and
 *         the system clock is switched to it. That last call programs the
 *         flash controller clock before the switch (the core keeps fetching
 *         from the flash) and updates SystemCoreClock afterwards.
 * @param  None
 * @retval None
 */
void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks (console pins of USART0 and the PD4 marker pin) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu_dev);
    hpmu_dev.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu_dev);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu_dev, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu_dev, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* The SMU is in the always-on domain: the clock tree of the previous image
     * (or of the flash programmer) survives ndmreset and a restart from the
     * reset vector. Put it back into its power-on shape first, so that the
     * configuration below is applied to a known state - otherwise the PLL is
     * found enabled, the feedback divider of this configuration is ignored, and
     * the console ends up at the wrong baud rate. HAL_SMU_DeInit() is the
     * driver's own sequence for that: it switches the core to the FIRC,
     * reprograms the flash wait states with the CLK_UPDATE handshake and holds
     * the PLL in reset. */
    (void)HAL_SMU_DeInit(&hsmu_clk, SMU_TIMEOUT_DEFAULT);
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Metafields of the two configuration structures (Version+Size contract,
     * same discipline as the IWDG configuration below). The business fields are
     * overwritten one by one, everything else must start at zero. */
    __HAL_CLEAR_STRUCT(&SMU_OscInitStruct);
    SMU_OscInitStruct.Size    = (uint32)sizeof(SMU_OscInitTypeDef);
    SMU_OscInitStruct.Version = SMU_OSC_INIT_VERSION;
    __HAL_CLEAR_STRUCT(&SMU_ClockInitStruct);
    SMU_ClockInitStruct.Size    = (uint32)sizeof(SMU_ClockInitTypeDef);
    SMU_ClockInitStruct.Version = SMU_CLOCK_INIT_VERSION;

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.Size             = (uint32)sizeof(SMU_PLLConfigTypeDef);
    SMU_OscInitStruct.PLL.Version          = SMU_PLL_INIT_VERSION;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Configure the PD4 marker pin as a push-pull output.
 * @note   The reference test case drives PD4 to be able to measure the alarm
 *         or the reset on a scope: the pin is set before the watchdog is
 *         started and released by the event.
 * @param  None
 * @retval None
 */
void Test_Pd4Init(void)
{
    GPIO_InitTypeDef gpio_init;

    __HAL_CLEAR_STRUCT(&gpio_init);
    HAL_GPIO_StructInit(&gpio_init);
    gpio_init.Pin          = TEST_PD4_PIN;
    gpio_init.Mode         = GPIO_MODE_OUTPUT_PP;
    gpio_init.Pull         = GPIO_NOPULL;
    gpio_init.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    gpio_init.Alternate    = 0U;

    HAL_GPIO_Init(TEST_PD4_PORT, &gpio_init);
}

/**
 * @brief  Drive the PD4 marker pin.
 * @param  state: GPIO_PIN_SET (watchdog armed, waiting) / GPIO_PIN_RESET (event)
 * @retval None
 */
void Test_Pd4Set(GPIO_PinState state)
{
    HAL_GPIO_WritePin(TEST_PD4_PORT, TEST_PD4_PIN, state);
}

/**
 * @brief  Read the cycle counter (low 32 bits).
 * @note   The core runs at 180 MHz in this test, so the 32-bit counter wraps
 *         after about 23.8 s: every measurement of the suite is shorter, and
 *         an unsigned difference stays correct across a wrap.
 * @param  None
 * @retval The mcycle value
 */
uint32 Test_McycleNow(void)
{
    return (uint32)csr_read(CSR_MCYCLE);
}

/**
 * @brief  Convert a cycle count into microseconds.
 * @param  cycles: number of core cycles
 * @retval The equivalent number of microseconds
 */
uint32 Test_McycleToUs(uint32 cycles)
{
    uint32 per_us = SystemCoreClock / 1000000U;

    if (per_us == 0U)
    {
        per_us = 1U;
    }

    return cycles / per_us;
}

/**
 * @brief  Compare a measured timeout with the programmed one.
 * @note   The IWDG is clocked by the RC32K based APB_BusS domain, so a
 *         tolerance is unavoidable: the accepted window is 75 % .. 150 % of
 *         the programmed value plus a fixed 50 ms of scheduling slack.
 * @param  measured_us: measured alarm delay
 * @param  expected_us: programmed alarm delay
 * @retval uint32: 1 when the measurement is inside the window, 0 otherwise
 */
uint32 Test_WithinTolerance(uint32 measured_us, uint32 expected_us)
{
    uint32 lower = (expected_us / 4U) * 3U;
    uint32 upper = (expected_us / 2U) * 3U + 50000U;

    return ((measured_us >= lower) && (measured_us <= upper)) ? 1U : 0U;
}

/**
 * @brief  Clear the alarm observation of the previous round.
 * @param  None
 * @retval None
 */
void Test_AlarmReset(void)
{
    test_alarm_count   = 0U;
    test_alarm_mcycle  = 0U;
    test_alarm_counter = 0U;
    test_alarm_status  = 0U;

    /* The alarm and fault latches of the FCU belong to the observation too: the
     * interrupt request of this block is a pulse, so a missed pulse would leave
     * the latch set and the next round would see a stale alarm. */
    (void)HAL_FCU_ClearFcuStatus(&hfcu_dev, HAL_FCU_CHANNEL_IWDG);
}

/**
 * @brief  Wait (bounded) until the FCU handler observed an alarm.
 * @param  timeout_ms: budget in milliseconds
 * @retval HAL_StatusTypeDef: HAL_OK when an alarm arrived / HAL_TIMEOUT
 */
HAL_StatusTypeDef Test_WaitAlarm(uint32 timeout_ms)
{
    uint32 tickstart = HAL_GetTick();
    uint32 status;

    while (test_alarm_count == 0U)
    {
        /* The alarm request of the FCU behaves like a pulse: when it is raised
         * while the core cannot take it (another interrupt in service, the
         * debugger halting the hart) the PLIC never sees it again, while the
         * alarm itself stays latched in FCU.ALARMx. Polling that latch keeps the
         * measurement of the watchdog timeout independent of the interrupt
         * path; the ISR below is kept as the secondary path. */
        status = HAL_FCU_GetAlarmStatus(&hfcu_dev, HAL_FCU_CHANNEL_IWDG) |
                 HAL_FCU_GetFaultStatus(&hfcu_dev, HAL_FCU_CHANNEL_IWDG);
        if (status != 0U)
        {
            test_alarm_mcycle  = Test_McycleNow();
            test_alarm_counter = (uint32)HAL_IWDG_GetCounter(&hiwdg_dev);
            test_alarm_status  = status;
            test_alarm_count++;
            (void)HAL_FCU_ClearFcuStatus(&hfcu_dev, HAL_FCU_CHANNEL_IWDG);
            break;
        }

        if ((HAL_GetTick() - tickstart) > timeout_ms)
        {
            return HAL_TIMEOUT;
        }
    }

    return HAL_OK;
}

/**
 * @brief  Program the watchdog through HAL_IWDG_Init().
 * @note   The driver has no HAL_IWDG_StructInit(): the configuration
 *         structure follows the Version+Size mechanism, so the metafields are
 *         filled here (the business fields are overwritten on every call).
 *         HAL_IWDG_Init() enables the prescaler block (PSC.EN) and never
 *         starts the watchdog (CFG.EN stays untouched).
 * @param  prescaler:     PSC.PSCNUM value (2..255)
 * @param  divider:       DIV.DIVNUM value (2..65535)
 * @param  timeout_value: TO.BVAL value (0..65535)
 * @retval HAL_StatusTypeDef of HAL_IWDG_Init()
 */
HAL_StatusTypeDef Test_IwdgApply(uint32 prescaler, uint32 divider,
                                 uint32 timeout_value)
{
    hiwdg_dev.Instance         = IWDG;
    hiwdg_dev.Init.Size        = (uint32)sizeof(IWDG_InitTypeDef);
    hiwdg_dev.Init.Version     = IWDG_INIT_VERSION;
    hiwdg_dev.Init.Prescaler   = prescaler;
    hiwdg_dev.Init.Reload      = timeout_value;
    hiwdg_dev.Init.Divider     = divider;
    hiwdg_dev.Init.Reserved[0] = 0U;
    hiwdg_dev.Init.Reserved[1] = 0U;

    return HAL_IWDG_Init(&hiwdg_dev);
}

/**
 * @brief  Check that the watchdog counter does not advance.
 * @note   The counter runs from the always-on 32768 Hz clock divided by
 *         (PSCNUM + 1) * DIVNUM, so a 100 ms window covers several counts and
 *         a stalled counter is unambiguous. The comparison is on the movement
 *         rather than on the absolute value, so the check does not depend on
 *         whether the hardware clears the counter when a block is disabled.
 * @param  window_ms: observation window in milliseconds
 * @retval uint32: 1 when the counter did not move, 0 otherwise
 */
uint32 Test_CounterStalled(uint32 window_ms)
{
    uint32 first = (uint32)HAL_IWDG_GetCounter(&hiwdg_dev);

    delay_ms(window_ms);

    return ((uint32)HAL_IWDG_GetCounter(&hiwdg_dev) == first) ? 1U : 0U;
}

/**
 * @brief  Check that the watchdog counter advances.
 * @param  window_ms: observation window in milliseconds
 * @retval uint32: 1 when the counter moved forward, 0 otherwise
 */
uint32 Test_CounterAdvancing(uint32 window_ms)
{
    uint32 attempt;
    uint32 first;

    /* The first tick of the RC32K chain can take seconds after a cold start, so
     * the same observation window is retried instead of being taken once. */
    for (attempt = 0U; attempt < 60U; attempt++)
    {
        first = (uint32)HAL_IWDG_GetCounter(&hiwdg_dev);
        delay_ms(window_ms);
        if ((uint32)HAL_IWDG_GetCounter(&hiwdg_dev) > first)
        {
            return 1U;
        }
    }

    return 0U;
}

/**
 * @brief  Configure the IWDG channel of the FCU.
 * @note   MaskEnable = FCU_DISABLE unmasks the channel (an enabled mask keeps
 *         the channel silent), which is the configuration of the reference
 *         test case.
 * @param  fault_action: action at fault level
 * @param  alarm_action: action at alarm level
 * @param  level:        fault level of the channel
 * @retval None
 */
void Test_FcuConfig(HAL_FCU_FaultActionTypeDef fault_action,
                    HAL_FCU_AlarmActionTypeDef alarm_action,
                    HAL_FCU_FaultLevelTypeDef level)
{
    FCU_InitTypeDef fcu_init;

    __HAL_CLEAR_STRUCT(&hfcu_dev);
    hfcu_dev.Instance = FCU;

    HAL_FCU_StructInit(&fcu_init);
    fcu_init.Channel           = HAL_FCU_CHANNEL_IWDG;
    fcu_init.FaultToResetCount = 0U;
    fcu_init.AlarmToFaultCount = 0U;
    fcu_init.FaultAction       = fault_action;
    fcu_init.AlarmAction       = alarm_action;
    fcu_init.FaultLevel        = level;
    fcu_init.MaskEnable        = FCU_DISABLE;

    hfcu_dev.Init = fcu_init;

    (void)HAL_FCU_Init(&hfcu_dev);
    (void)HAL_FCU_Cmd(&hfcu_dev, HAL_FCU_CHANNEL_IWDG, FCU_ENABLE);
}

/**
 * @brief  Enable the FCU interrupt source in the PLIC.
 * @param  priority: source priority (1..63, larger = higher priority)
 * @retval None
 */
void Test_PlicEnable(uint32 priority)
{
    PLIC_InitTypeDef plic_init;

    __HAL_CLEAR_STRUCT(&plic_init);
    plic_init.Size               = (uint32)sizeof(PLIC_InitTypeDef);
    plic_init.Version            = PLIC_INIT_VERSION;
    plic_init.PLIC_IRQChannel    = FCU_IRQn;
    plic_init.PLIC_IRQPriority   = priority;
    plic_init.PLIC_IRQChannelCmd = PLIC_ENABLE;
    (void)HAL_PLIC_Init(&plic_init);
}

/**
 * @brief  FCU interrupt handler: record the alarm, then acknowledge the source.
 * @note   The handler runs outside the driver locks: the read-only queries
 *         (HAL_FCU_GetAlarmStatus / HAL_FCU_GetFaultStatus / HAL_IWDG_GetCounter)
 *         and the clear family (HAL_FCU_ClearFcuStatus) are interrupt safe by
 *         design.
 * @note   The alarm instant is stamped with the cycle counter, so the case can
 *         compare the measured timeout with the programmed one.
 * @param  None
 * @retval None
 */
void FCU_IRQ_Handler(void)
{
    uint32 status;

    status = HAL_FCU_GetAlarmStatus(&hfcu_dev, HAL_FCU_CHANNEL_IWDG) |
             HAL_FCU_GetFaultStatus(&hfcu_dev, HAL_FCU_CHANNEL_IWDG);

    if (status != 0U)
    {
        test_alarm_mcycle  = Test_McycleNow();
        test_alarm_counter = (uint32)HAL_IWDG_GetCounter(&hiwdg_dev);
        test_alarm_status  = status;
        test_alarm_count++;

        /* Marker pin: the alarm pulls PD4 low (the scope reference) */
        Test_Pd4Set(TEST_PD4_OFF);
    }

    (void)HAL_FCU_ClearFcuStatus(&hfcu_dev, HAL_FCU_CHANNEL_IWDG);
}

/*****END OF FILE*****/
