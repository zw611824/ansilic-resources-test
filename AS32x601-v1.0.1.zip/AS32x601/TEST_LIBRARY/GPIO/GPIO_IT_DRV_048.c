/**
 * @file    GPIO_IT_DRV_048.c
 * @brief   HAL GPIO integration test case 048 (extension: alternate function
 *          selection, every mode, input type and drive current).
 *
 * This case is not part of the vendor plan (which has 43 cases): it is an
 * extension. It checks the chip specific encodings of the driver in the
 * configuration registers: the 3-bit multiplex field of MI0SR / MI1SR, the
 * MODER field of RWM0CR, the output type of OMCR, the input type of IM0CR, the
 * drive current of OICR and the trigger field of ITYPE0R.
 *
 * Tested functionality:
 *   HAL_GPIO_Init()             (every supported mode, input type and drive
 *                                current, including GPIO_MODE_IDDQ and
 *                                GPIO_PULLKEEP of the extension module)
 *   HAL_GPIO_PinAFConfig()    (MI0SR for the channels 0..9, MI1SR for the
 *                                channels 10..15, argument validation)
 *   HAL_GPIO_ITConfig()       (through the interrupt modes of HAL_GPIO_Init())
 *
 * Test configuration:
 *   GPIOD pins 0..15 : device under test of the register encodings
 *   GPIOH pins 2..9  : pin availability (that port has ten channels only and no
 *                      MI1SR register)
 *
 * Test procedure (every check is recorded in the observation masks below):
 *   step 1  PinAFConfig() writes the selected field of MI0SR / MI1SR  checks 0..5
 *   step 2  rejected pin source / alternate function / port              checks 6..7
 *   step 3  every mode is encoded in RWM0CR / OMCR / MI0SR / ITYPE0R     checks 8..15
 *   step 4  every input type is encoded in IM0CR                         check  16
 *   step 5  every drive current is encoded in OICR                       check  17
 *   step 6  the GPIOH port accepts Pin2..Pin9 and refuses Pin10 / All    check  18
 *
 * Expected behaviour:
 *   The case prints nothing. Bit n of Passed_Mask is set when check n passed and
 *   bit n of Failed_Mask when it failed, so
 *     Failed_Mask == 0x00000000  and  Passed_Mask == 0x0007FFFF  and
 *     Check_Count == 19
 *   means that every check of this case passed. The registers are read back
 *   through the device header, so the case is self checking.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"

/* Private define -----------------------------------------------------------*/
/* GPIOD pins used by the checks */
#define AF_PIN_0                (GPIO_PIN_0)
#define AF_PIN_1                (GPIO_PIN_1)
#define AF_PIN_9                (GPIO_PIN_9)
#define AF_PIN_10               (GPIO_PIN_10)
#define AF_PIN_15               (GPIO_PIN_15)
#define MODE_PIN                (GPIO_PIN_4)

/* GPIOH pins used by the pin availability check */
#define GPIOH_TEST_PIN          (GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_5 | \
                                 GPIO_PIN_6 | GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9)

/* An unsupported alternate function value (only three bits are encoded) */
#define INVALID_AF              ((uint8)0xFFU)

/* Number of checks of this case and the expected observation of the masks */
#define CHECK_ALL               ((uint32)0x0007FFFFU)
#define CHECK_TOTAL             (19U)

/* Private variables ---------------------------------------------------------*/
static HAL_SMU_HandleTypeDef hsmu_clk;    /*!< SMU handle (lock / state / error) */
static volatile uint32 Passed_Mask = 0U;  /*!< bit n set when check n passed      */
static volatile uint32 Failed_Mask = 0U;  /*!< bit n set when check n failed      */
static volatile uint32 Check_Count = 0U;  /*!< number of checks that were run     */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void check(uint32 index, uint32 condition);
static uint32 moder_field(GPIO_TypeDef *GPIOx, uint32 pin);
static uint32 omcr_bit(uint32 pin);
static uint32 im0cr_field(uint32 pin);
static uint32 oicr_field(uint32 pin);
static uint32 itype_field(uint32 pin);
static uint32 mi0sr_field(uint32 pin);
static uint32 mi1sr_field(uint32 pin);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;
    uint32 reg_before;
    uint32 ok;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Enable the clock gate of the device under test (GPIOH has no gate) */
    __HAL_SMU_GPIOD_CLK_ENABLE();

    /* ---- Step 1: the multiplex field selection (checks 0..5) ------------- */

    HAL_GPIO_PinAFConfig(GPIOD, GPIO_PinSource0, GPIO_AF_USART0);
    ok = (mi0sr_field(0U) == (uint32)GPIO_AF_USART0);
    check(0U, ok);

    /* Only the field of the selected channel is written */
    HAL_GPIO_PinAFConfig(GPIOD, GPIO_PinSource1, GPIO_AF_USART1);
    ok = ((mi0sr_field(1U) == (uint32)GPIO_AF_USART1) &&
          (mi0sr_field(0U) == (uint32)GPIO_AF_USART0));
    check(1U, ok);

    /* The last channel of the MI0SR register (channel 9) */
    HAL_GPIO_PinAFConfig(GPIOD, GPIO_PinSource9, GPIO_AF_SPI5);
    ok = ((mi0sr_field(9U) == (uint32)GPIO_AF_SPI5) &&
          (mi0sr_field(1U) == (uint32)GPIO_AF_USART1));
    check(2U, ok);

    /* The channels 10..15 are encoded in the MI1SR register */
    HAL_GPIO_PinAFConfig(GPIOD, GPIO_PinSource10, GPIO_AF_USART0);
    ok = (mi1sr_field(10U) == (uint32)GPIO_AF_USART0);
    check(3U, ok);

    HAL_GPIO_PinAFConfig(GPIOD, GPIO_PinSource15, GPIO_AF_USART2);
    ok = ((mi1sr_field(15U) == (uint32)GPIO_AF_USART2) &&
          (mi1sr_field(10U) == (uint32)GPIO_AF_USART0));
    check(4U, ok);

    /* The plain GPIO function is selected with GPIO_AF_Pin_x */
    HAL_GPIO_PinAFConfig(GPIOD, GPIO_PinSource0, GPIO_AF_Pin_x);
    ok = (mi0sr_field(0U) == (uint32)GPIO_AF_Pin_x);
    check(5U, ok);

    /* ---- Step 2: rejected PinAFConfig arguments (checks 6..7) ----------- */

    /* a pin source outside 0..15 and an alternate function outside 0..7 */
    reg_before = GPIO_READ_REG(GPIOD, MI0SR);
    HAL_GPIO_PinAFConfig(GPIOD, 16U, GPIO_AF_USART0);
    HAL_GPIO_PinAFConfig(GPIOD, GPIO_PinSource2, INVALID_AF);
    ok = (GPIO_READ_REG(GPIOD, MI0SR) == reg_before);
    check(6U, ok);

    /* a NULL port, and the channels 10..15 of the GPIOH port, which has no
       MI1SR register */
    reg_before = GPIOD->MI1SR;
    HAL_GPIO_PinAFConfig(NULL_PTR, GPIO_PinSource2, GPIO_AF_USART0);
    HAL_GPIO_PinAFConfig(GPIOH, GPIO_PinSource10, GPIO_AF_USART0);
    ok = (GPIOD->MI1SR == reg_before);
    check(7U, ok);

    /* ---- Step 3: every mode (checks 8..15) ------------------------------ */

    __HAL_CLEAR_STRUCT(&GPIO_InitStruct);
    HAL_GPIO_StructInit(&GPIO_InitStruct);
    GPIO_InitStruct.Pin          = MODE_PIN;
    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;

    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
    ok = ((moder_field(GPIOD, 4U) == GPIO_MODE_VALUE_OUTPUT) && (omcr_bit(4U) == 1U));
    check(8U, ok);

    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
    ok = ((moder_field(GPIOD, 4U) == GPIO_MODE_VALUE_OUTPUT) && (omcr_bit(4U) == 0U));
    check(9U, ok);

    GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Alternate = GPIO_AF_SPI1;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
    ok = ((moder_field(GPIOD, 4U) == GPIO_MODE_VALUE_OUTPUT) &&
          (mi0sr_field(4U) == (uint32)GPIO_AF_SPI1) &&
          (omcr_bit(4U) == 1U));
    check(10U, ok);

    GPIO_InitStruct.Mode      = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Alternate = GPIO_AF_Pin_x;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
    ok = (moder_field(GPIOD, 4U) == GPIO_MODE_VALUE_ANALOG);
    check(11U, ok);

    /* The IDDQ mode is a chip specific value defined by the extension module */
    GPIO_InitStruct.Mode = GPIO_MODE_IDDQ;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
    ok = (moder_field(GPIOD, 4U) == GPIO_MODE_VALUE_IDDQ);
    check(12U, ok);

    /* The interrupt modes are input modes with an external interrupt line */
    GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
    ok = ((moder_field(GPIOD, 4U) == GPIO_MODE_VALUE_INPUT) &&
          (itype_field(4U) == 1U) &&
          (((GPIO_READ_REG(GPIOD, IMR) >> 4U) & 0x01U) == 0U));
    check(13U, ok);

    GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
    ok = ((moder_field(GPIOD, 4U) == GPIO_MODE_VALUE_INPUT) && (itype_field(4U) == 2U));
    check(14U, ok);

    GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
    ok = ((moder_field(GPIOD, 4U) == GPIO_MODE_VALUE_INPUT) && (itype_field(4U) == 3U));
    check(15U, ok);

    /* ---- Step 4: every input type (check 16) ----------------------------- */

    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;

    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
    ok = (im0cr_field(4U) == GPIO_NOPULL);

    GPIO_InitStruct.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
    if (im0cr_field(4U) != GPIO_PULLUP)
    {
        ok = 0U;
    }

    GPIO_InitStruct.Pull = GPIO_PULLDOWN;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
    if (im0cr_field(4U) != GPIO_PULLDOWN)
    {
        ok = 0U;
    }

    /* The KEEP input type is a chip specific value defined by the extension */
    GPIO_InitStruct.Pull = GPIO_PULLKEEP;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
    if (im0cr_field(4U) != GPIO_PULLKEEP)
    {
        ok = 0U;
    }
    check(16U, ok);

    /* ---- Step 5: every drive current (check 17) -------------------------- */

    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;

    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
    ok = (oicr_field(4U) == GPIO_DRIVE_CURRENT_LOW);

    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
    if (oicr_field(4U) != GPIO_DRIVE_CURRENT_MEDIUM)
    {
        ok = 0U;
    }

    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_HIGH;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
    if (oicr_field(4U) != GPIO_DRIVE_CURRENT_HIGH)
    {
        ok = 0U;
    }

    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_VERY_HIGH;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
    if (oicr_field(4U) != GPIO_DRIVE_CURRENT_VERY_HIGH)
    {
        ok = 0U;
    }
    check(17U, ok);

    /* ---- Step 6: GPIOH availability (check 18) --------------------------- */

    __HAL_CLEAR_STRUCT(&GPIO_InitStruct);
    GPIO_InitStruct.Size         = sizeof(GPIO_InitTypeDef);
    GPIO_InitStruct.Version      = GPIO_INIT_VERSION;
    GPIO_InitStruct.Mode         = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull         = GPIO_NOPULL;
    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    GPIO_InitStruct.Alternate    = GPIO_AF_Pin_x;

    /* The channels 10..15 of that port do not exist */
    reg_before = GPIO_READ_REG(GPIOH, RWM0CR);
    GPIO_InitStruct.Pin = GPIO_PIN_10;
    HAL_GPIO_Init(GPIOH, &GPIO_InitStruct);
    GPIO_InitStruct.Pin = GPIO_PIN_All;
    HAL_GPIO_Init(GPIOH, &GPIO_InitStruct);
    ok = (GPIO_READ_REG(GPIOH, RWM0CR) == reg_before);

    /* while the ten existing channels are accepted */
    GPIO_InitStruct.Pin = GPIOH_TEST_PIN;
    HAL_GPIO_Init(GPIOH, &GPIO_InitStruct);
    if (moder_field(GPIOH, 2U) != GPIO_MODE_VALUE_OUTPUT)
    {
        ok = 0U;
    }
    check(18U, ok);

    /* Every check has been recorded; the loop keeps the observables alive */
    while (1)
    {
        delay_ms(500U);
    }
}

/**
 * @brief  Record the result of one check.
 * @param  index: check number, used as the bit position of the mask.
 * @param  condition: 1 when the check passed, 0 when it failed.
 * @retval None
 */
static void check(uint32 index, uint32 condition)
{
    Check_Count++;

    if (condition != 0U)
    {
        Passed_Mask |= ((uint32)0x01U << index);
    }
    else
    {
        Failed_Mask |= ((uint32)0x01U << index);
    }
}

/**
 * @brief  Read the RWM0CR mode field of one pin (00 input, 01 output, 10 analog,
 *         11 IDDQ).
 * @param  GPIOx: port to read: the GPIOD checks and the GPIOH pin
 *         availability check both observe their mode field through here.
 * @param  pin: pin index (0..15).
 * @retval The two bit mode field of that pin.
 */
static uint32 moder_field(GPIO_TypeDef *GPIOx, uint32 pin)
{
    return ((GPIO_READ_REG(GPIOx, RWM0CR) >> (pin * 2U)) & 0x03U);
}

/**
 * @brief  Read the OMCR output type bit of one pin (1 push-pull, 0 open drain).
 * @param  pin: pin index (0..15).
 * @retval The output type bit of that pin.
 */
static uint32 omcr_bit(uint32 pin)
{
    return ((GPIO_READ_REG(GPIOD, OMCR) >> pin) & 0x01U);
}

/**
 * @brief  Read the IM0CR input type field of one pin.
 * @param  pin: pin index (0..15).
 * @retval The two bit input type field of that pin.
 */
static uint32 im0cr_field(uint32 pin)
{
    return ((GPIO_READ_REG(GPIOD, IM0CR) >> (pin * 2U)) & 0x03U);
}

/**
 * @brief  Read the OICR drive current field of one pin.
 * @param  pin: pin index (0..15).
 * @retval The two bit drive current field of that pin.
 */
static uint32 oicr_field(uint32 pin)
{
    return ((GPIO_READ_REG(GPIOD, OICR) >> (pin * 2U)) & 0x03U);
}

/**
 * @brief  Read the ITYPE0R trigger field of one pin.
 * @param  pin: pin index (0..15).
 * @retval The two bit trigger field of that pin.
 */
static uint32 itype_field(uint32 pin)
{
    return ((GPIO_READ_REG(GPIOD, ITYPE0R) >> (pin * 2U)) & 0x03U);
}

/**
 * @brief  Read the MI0SR multiplex field of one pin (channels 0..9).
 * @param  pin: pin index (0..9).
 * @retval The three bit multiplex field of that pin.
 */
static uint32 mi0sr_field(uint32 pin)
{
    return ((GPIO_READ_REG(GPIOD, MI0SR) >> (pin * 3U)) & 0x07U);
}

/**
 * @brief  Read the MI1SR multiplex field of one pin (channels 10..15).
 * @param  pin: pin index (10..15).
 * @retval The three bit multiplex field of that pin.
 */
static uint32 mi1sr_field(uint32 pin)
{
    return ((GPIOD->MI1SR >> ((pin - 10U) * 3U)) & 0x07U);
}

/**
 * @brief  Configure the system clock tree (PLL 180 MHz, as the original test).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef  SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef   SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    HAL_PMU_LDO2v5VOLSca(&hpmu, 0xf);
    HAL_PMU_LDO1v2VOLSca(&hpmu, 0xf);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it (CLKFRQ above), so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Clock tree order: this is the order the chip requires, and the vendor
       test case uses the same one.
         1. Write the bus clock dividers while the system clock is still the
            power-on source (FIRC), so that the new divider values are already
            in place when the faster clock arrives. Writing them AFTER the
            switch instead leaves the buses at their reset dividers for a
            moment at the new core clock: at 180 MHz that is
            AXI4Bus3 = 90 MHz and APBBus0 = 45 MHz, right at their ratings, and
            the core does not survive it (measured on the board: the core
            trapped before the divider write was reached, so no output was
            produced at all).
         2. Program the EFLASH controller clock: the controller must already
            know the final frequency while the code still runs from the flash.
         3. Then configure the PLL and switch the system clock to it; this call
            also updates SystemCoreClock and re-initializes the HAL time base. */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
