/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_pmu.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.3
 * Date:   2026/10/09
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.1     apply the resource lock / RTOS rules:
 *                                                       run the MSP callbacks outside the
 *                                                       locked region, add a Timeout and a
 *                                                       NULL-mutex guard to the lock helper,
 *                                                       add the busy / reset state gate and
 *                                                       the busy intermediate state, return
 *                                                       HAL_StatusTypeDef from the twenty
 *                                                       configuration interfaces with
 *                                                       run-time parameter validation
 *     ANSILIC APPLICATION GROUP  2026/10/08     1.2     merge the wake-up mask capabilities of the
 *                                                       System Management release of
 *                                                       2026/09/29 into this driver:
 *                                                       HAL_PMU_WakeUpSourceCmd() and
 *                                                       HAL_PMU_ClearFlag() now accept any
 *                                                       combination of the available channels
 *                                                       (the register accesses and the
 *                                                       documentation already described a
 *                                                       combination, but the IS_PMU_WKSOURCE /
 *                                                       IS_PMU_CLEAR checks only accepted one
 *                                                       single value, so a combination was
 *                                                       rejected). Add the PMU_WKSOURCE_ALL and
 *                                                       PMU_CLEAR_ALL masks and the
 *                                                       IS_PMU_WKSOURCE_MASK / IS_PMU_CLEAR_MASK
 *                                                       checks, which keep rejecting the value 0
 *                                                       and the two reserved register bits
 *     ANSILIC APPLICATION GROUP  2026/10/09     1.3     add HAL_PMU_GetWakeUpFlag(), the mask based
 *                                                       wake-up status query (it takes the same mask
 *                                                       family HAL_PMU_ClearFlag() writes, so a set
 *                                                       of wake-up sources can be tested in one call
 *                                                       and cleared with the same value)
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Power Management Unit
 *                  (PMU) of the AS32x601:
 *                  - Initialization and de-initialization: HAL_PMU_Init /
 *                    HAL_PMU_DeInit, configuration structure handling;
 *                  - Power mode control: sleep / deep sleep mode selection
 *                    and current mode read-back;
 *                  - Wake-up source management: enable / disable the
 *                    wake-up channels;
 *                  - LDO control: 3.3V / 2.5V / 1.2V / 1.2V-backup / 1.2V
 *                    reference LDO enable and voltage scaling;
 *                  - Voltage detection: low voltage reset, high / low
 *                    voltage detect enable and threshold scaling;
 *                  - Oscillator control: internal RC 16 MHz enable, RC
 *                    32 kHz frequency scaling;
 *                  - Flag management: LDO ready / wake-up flags query and
 *                    clear;
 *                  - State and error reporting.
 *
 *                  The PMU is located on the APB-BusS clock domain and
 *                  provides no interrupt; the flags are polled with
 *                  HAL_PMU_GetFlagStatus().
 *
 * @note            All the configuration interfaces (power mode, wake-up
 *                  sources, LDO control, voltage detection, oscillators and
 *                  flag clear) take the handle lock and reject a call when the
 *                  handle is busy or not initialized; HAL_PMU_Init() must
 *                  therefore be called before them. The read-only interfaces
 *                  (GetPowerModeStatus / GetFlagStatus / GetState / GetError)
 *                  are lock-free and callable from an interrupt context.
 * @complexity  Medium
 *              State machine (State/ErrorCode) and blocking lock operations.
 */
#ifndef __AS32X601_HAL_PMU_H
#define __AS32X601_HAL_PMU_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "as32x601.h"               /* PMU_TypeDef, PMU register bits          */
#include "as32x601_hal_def.h"       /* HAL_StatusTypeDef, HAL_LockTypeDef      */

/* Exported constants --------------------------------------------------------*/

/**
 * @brief  PMU HAL driver module version.
 * @note   0x0100U = V1.0. Bumped only on breaking API changes (architecture
 *         spec COMPAT-13/14/15).
 */
#define __HAL_PMU_MODULE_VERSION  0x0100U

/* Exported types ------------------------------------------------------------*/

/** @defgroup PMU_Exported_Types PMU Exported Types
  * @{
  */

/**
 * @brief PMU power mode enumeration.
 * @note  The values are the PMCR.POWMC field values; the initial and normal
 *        modes are read-only statuses (they cannot be selected).
 */
typedef enum
{
    HAL_PMU_POWERMODE_INIT      = 0x00U, /*!< Start initial mode              */
    HAL_PMU_POWERMODE_DEEPSLEEP = 0x01U, /*!< Deep sleep mode (selectable)    */
    HAL_PMU_POWERMODE_SLEEP     = 0x02U, /*!< Sleep mode (selectable)         */
    HAL_PMU_POWERMODE_NORMAL    = 0x03U  /*!< Normal mode (read-only status)  */
} HAL_PMU_PowerModeTypeDef;

/**
 * @brief PMU wake-up source enumeration.
 * @note  The values are the WKEN / WKFR register bit masks.
 */
typedef enum
{
    HAL_PMU_WKSOURCE_IWDG = 0x001U,  /*!< IWDG wake-up source  */
    HAL_PMU_WKSOURCE_RTC  = 0x008U,  /*!< RTC wake-up source   */
    HAL_PMU_WKSOURCE_PH0  = 0x010U,  /*!< PH0 wake-up source   */
    HAL_PMU_WKSOURCE_PH1  = 0x020U,  /*!< PH1 wake-up source   */
    HAL_PMU_WKSOURCE_PH2  = 0x040U,  /*!< PH2 wake-up source   */
    HAL_PMU_WKSOURCE_PH3  = 0x080U,  /*!< PH3 wake-up source   */
    HAL_PMU_WKSOURCE_PH4  = 0x100U,  /*!< PH4 wake-up source   */
    HAL_PMU_WKSOURCE_PH5  = 0x200U,  /*!< PH5 wake-up source   */
    HAL_PMU_WKSOURCE_PH6  = 0x400U,  /*!< PH6 wake-up source   */
    HAL_PMU_WKSOURCE_PH7  = 0x800U,  /*!< PH7 wake-up source   */
    HAL_PMU_WKSOURCE_PH8  = 0x1000U, /*!< PH8 wake-up source   */
    HAL_PMU_WKSOURCE_PH9  = 0x2000U  /*!< PH9 wake-up source   */
} HAL_PMU_WKSourceTypeDef;

/**
 * @brief HAL PMU state structures definition.
 */
typedef enum
{
    HAL_PMU_STATE_RESET      = 0x00U, /*!< Peripheral not initialized          */
    HAL_PMU_STATE_READY      = 0x01U, /*!< Peripheral initialized and ready    */
    HAL_PMU_STATE_BUSY       = 0x02U, /*!< An internal process is ongoing      */
    HAL_PMU_STATE_ERROR      = 0x03U  /*!< PMU error state                     */
} HAL_PMU_StateTypeDef;

/**
 * @brief PMU handle structure definition.
 */
typedef struct __HAL_PMU_HandleTypeDef
{
    PMU_TypeDef               *Instance;      /*!< PMU registers base address    */
    HAL_LockTypeDef           Lock;           /*!< Locking object                */
    __IO HAL_PMU_StateTypeDef State;          /*!< PMU communication state       */
    __IO uint32               ErrorCode;      /*!< PMU error code                */
#if (USE_RTOS == 1)
    HAL_MutexTypeDef          LockMutex;      /*!< RTOS mutex handle (created by the
                                                   user porting layer, e.g. in
                                                   HAL_PMU_MspInit)             */
#endif /* USE_RTOS */
} HAL_PMU_HandleTypeDef;

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @defgroup PMU_Exported_Constants PMU Exported Constants
  * @{
  */

/** @defgroup PMU_Error_Code PMU Error Code
  * @{
  */
#define HAL_PMU_ERROR_NONE           ((uint32)0x00000000U) /*!< No error             */
#define HAL_PMU_ERROR_INVALID_PARAM  ((uint32)0x00000001U) /*!< Invalid parameter    */
/**
  * @}
  */

/** @defgroup PMU_Enable_Value PMU Enable Value
  * @{
  */
#define PMU_ENABLE                    1U       /*!< Enable the PMU function     */
#define PMU_DISABLE                   0U       /*!< Disable the PMU function    */
/**
  * @}
  */

/** @defgroup PMU_3V3_Voltage_Scaling PMU 3.3V LDO Voltage Scaling
  * @note  The values are the LDOCR.3V3LDOVOS field values.
  * @{
  */
#define PMU_VO33_2V90    ((uint32)0x00000000U) /*!< 3.3V LDO output 2.90V */
#define PMU_VO33_2V95    ((uint32)0x00000001U) /*!< 3.3V LDO output 2.95V */
#define PMU_VO33_3V00    ((uint32)0x00000002U) /*!< 3.3V LDO output 3.00V */
#define PMU_VO33_3V05    ((uint32)0x00000003U) /*!< 3.3V LDO output 3.05V */
#define PMU_VO33_3V10    ((uint32)0x00000004U) /*!< 3.3V LDO output 3.10V */
#define PMU_VO33_3V15    ((uint32)0x00000005U) /*!< 3.3V LDO output 3.15V */
#define PMU_VO33_3V20    ((uint32)0x00000006U) /*!< 3.3V LDO output 3.20V */
#define PMU_VO33_3V25    ((uint32)0x00000007U) /*!< 3.3V LDO output 3.25V */
#define PMU_VO33_3V30    ((uint32)0x00000008U) /*!< 3.3V LDO output 3.30V (default) */
#define PMU_VO33_3V35    ((uint32)0x00000009U) /*!< 3.3V LDO output 3.35V */
#define PMU_VO33_3V40    ((uint32)0x0000000AU) /*!< 3.3V LDO output 3.40V */
#define PMU_VO33_3V45    ((uint32)0x0000000BU) /*!< 3.3V LDO output 3.45V */
#define PMU_VO33_3V50    ((uint32)0x0000000CU) /*!< 3.3V LDO output 3.50V */
#define PMU_VO33_3V55    ((uint32)0x0000000DU) /*!< 3.3V LDO output 3.55V */
#define PMU_VO33_3V60    ((uint32)0x0000000EU) /*!< 3.3V LDO output 3.60V */
#define PMU_VO33_3V65    ((uint32)0x0000000FU) /*!< 3.3V LDO output 3.65V */
/**
  * @}
  */

/** @defgroup PMU_2V5_Voltage_Scaling PMU 2.5V LDO Voltage Scaling
  * @note  The values are the LDOCR.2V5LDOVOS field values.
  * @{
  */
#define PMU_VO25_2V18    ((uint32)0x00000000U) /*!< 2.5V LDO output 2.18V */
#define PMU_VO25_2V22    ((uint32)0x00000001U) /*!< 2.5V LDO output 2.22V */
#define PMU_VO25_2V26    ((uint32)0x00000002U) /*!< 2.5V LDO output 2.26V */
#define PMU_VO25_2V30    ((uint32)0x00000003U) /*!< 2.5V LDO output 2.30V */
#define PMU_VO25_2V34    ((uint32)0x00000004U) /*!< 2.5V LDO output 2.34V */
#define PMU_VO25_2V38    ((uint32)0x00000005U) /*!< 2.5V LDO output 2.38V */
#define PMU_VO25_2V42    ((uint32)0x00000006U) /*!< 2.5V LDO output 2.42V */
#define PMU_VO25_2V46    ((uint32)0x00000007U) /*!< 2.5V LDO output 2.46V */
#define PMU_VO25_2V50    ((uint32)0x00000008U) /*!< 2.5V LDO output 2.50V (default) */
#define PMU_VO25_2V54    ((uint32)0x00000009U) /*!< 2.5V LDO output 2.54V */
#define PMU_VO25_2V58    ((uint32)0x0000000AU) /*!< 2.5V LDO output 2.58V */
#define PMU_VO25_2V62    ((uint32)0x0000000BU) /*!< 2.5V LDO output 2.62V */
#define PMU_VO25_2V66    ((uint32)0x0000000CU) /*!< 2.5V LDO output 2.66V */
#define PMU_VO25_2V72    ((uint32)0x0000000DU) /*!< 2.5V LDO output 2.72V */
#define PMU_VO25_2V74    ((uint32)0x0000000EU) /*!< 2.5V LDO output 2.74V */
#define PMU_VO25_2V78    ((uint32)0x0000000FU) /*!< 2.5V LDO output 2.78V */
/**
  * @}
  */

/** @defgroup PMU_1V2_Voltage_Scaling PMU 1.2V LDO Voltage Scaling
  * @note  The values are the LDOCR.1V2LDOVOS field values.
  * @{
  */
#define PMU_VO12_1V04    ((uint32)0x00000000U) /*!< 1.2V LDO output 1.04V */
#define PMU_VO12_1V06    ((uint32)0x00000001U) /*!< 1.2V LDO output 1.06V */
#define PMU_VO12_1V08    ((uint32)0x00000002U) /*!< 1.2V LDO output 1.08V */
#define PMU_VO12_1V10    ((uint32)0x00000003U) /*!< 1.2V LDO output 1.10V */
#define PMU_VO12_1V12    ((uint32)0x00000004U) /*!< 1.2V LDO output 1.12V */
#define PMU_VO12_1V14    ((uint32)0x00000005U) /*!< 1.2V LDO output 1.14V */
#define PMU_VO12_1V16    ((uint32)0x00000006U) /*!< 1.2V LDO output 1.16V */
#define PMU_VO12_1V18    ((uint32)0x00000007U) /*!< 1.2V LDO output 1.18V */
#define PMU_VO12_1V20    ((uint32)0x00000008U) /*!< 1.2V LDO output 1.20V (default) */
#define PMU_VO12_1V22    ((uint32)0x00000009U) /*!< 1.2V LDO output 1.22V */
#define PMU_VO12_1V24    ((uint32)0x0000000AU) /*!< 1.2V LDO output 1.24V */
#define PMU_VO12_1V26    ((uint32)0x0000000BU) /*!< 1.2V LDO output 1.26V */
#define PMU_VO12_1V28    ((uint32)0x0000000CU) /*!< 1.2V LDO output 1.28V */
#define PMU_VO12_1V30    ((uint32)0x0000000DU) /*!< 1.2V LDO output 1.30V */
#define PMU_VO12_1V32    ((uint32)0x0000000EU) /*!< 1.2V LDO output 1.32V */
#define PMU_VO12_1V34    ((uint32)0x0000000FU) /*!< 1.2V LDO output 1.34V */
/**
  * @}
  */

/** @defgroup PMU_VREF_1V2_Voltage_Scaling PMU 1.2V Reference Voltage Scaling
  * @note  The values are the LDOCR.1V2VREFS field values.
  * @{
  */
#define PMU_VREF12_1V04  ((uint32)0x00000000U) /*!< 1.2V reference 1.04V */
#define PMU_VREF12_1V06  ((uint32)0x00000001U) /*!< 1.2V reference 1.06V */
#define PMU_VREF12_1V08  ((uint32)0x00000002U) /*!< 1.2V reference 1.08V */
#define PMU_VREF12_1V10  ((uint32)0x00000003U) /*!< 1.2V reference 1.10V */
#define PMU_VREF12_1V12  ((uint32)0x00000004U) /*!< 1.2V reference 1.12V */
#define PMU_VREF12_1V14  ((uint32)0x00000005U) /*!< 1.2V reference 1.14V */
#define PMU_VREF12_1V16  ((uint32)0x00000006U) /*!< 1.2V reference 1.16V */
#define PMU_VREF12_1V18  ((uint32)0x00000007U) /*!< 1.2V reference 1.18V */
#define PMU_VREF12_1V20  ((uint32)0x00000008U) /*!< 1.2V reference 1.20V (default) */
#define PMU_VREF12_1V22  ((uint32)0x00000009U) /*!< 1.2V reference 1.22V */
#define PMU_VREF12_1V24  ((uint32)0x0000000AU) /*!< 1.2V reference 1.24V */
#define PMU_VREF12_1V26  ((uint32)0x0000000BU) /*!< 1.2V reference 1.26V */
#define PMU_VREF12_1V28  ((uint32)0x0000000CU) /*!< 1.2V reference 1.28V */
#define PMU_VREF12_1V30  ((uint32)0x0000000DU) /*!< 1.2V reference 1.30V */
#define PMU_VREF12_1V32  ((uint32)0x0000000EU) /*!< 1.2V reference 1.32V */
#define PMU_VREF12_1V34  ((uint32)0x0000000FU) /*!< 1.2V reference 1.34V */
/**
  * @}
  */

/** @defgroup PMU_HVDTS PMU High Voltage Detect Threshold Scaling
  * @note  The values are the VDCR.HVDTS field values.
  * @{
  */
#define PMU_HVDTS_2V4    ((uint32)0x00000000U) /*!< HVD threshold 2.4V  */
#define PMU_HVDTS_2V5    ((uint32)0x00000001U) /*!< HVD threshold 2.5V  */
#define PMU_HVDTS_2V6    ((uint32)0x00000002U) /*!< HVD threshold 2.6V  */
#define PMU_HVDTS_2V7    ((uint32)0x00000003U) /*!< HVD threshold 2.7V  */
#define PMU_HVDTS_2V8    ((uint32)0x00000004U) /*!< HVD threshold 2.8V  */
#define PMU_HVDTS_2V9    ((uint32)0x00000005U) /*!< HVD threshold 2.9V  */
#define PMU_HVDTS_3V0    ((uint32)0x00000006U) /*!< HVD threshold 3.0V  */
#define PMU_HVDTS_3V1    ((uint32)0x00000007U) /*!< HVD threshold 3.1V  */
#define PMU_HVDTS_3V2    ((uint32)0x00000008U) /*!< HVD threshold 3.2V  */
#define PMU_HVDTS_3V3    ((uint32)0x00000009U) /*!< HVD threshold 3.3V  */
#define PMU_HVDTS_3V4    ((uint32)0x0000000AU) /*!< HVD threshold 3.4V  */
#define PMU_HVDTS_3V5    ((uint32)0x0000000BU) /*!< HVD threshold 3.5V  */
#define PMU_HVDTS_3V6    ((uint32)0x0000000CU) /*!< HVD threshold 3.6V  */
#define PMU_HVDTS_3V7    ((uint32)0x0000000DU) /*!< HVD threshold 3.7V  */
#define PMU_HVDTS_3V8    ((uint32)0x0000000EU) /*!< HVD threshold 3.8V  */
#define PMU_HVDTS_3V9    ((uint32)0x0000000FU) /*!< HVD threshold 3.9V  */
#define PMU_HVDTS_4V0    ((uint32)0x00000010U) /*!< HVD threshold 4.0V  */
#define PMU_HVDTS_4V1    ((uint32)0x00000011U) /*!< HVD threshold 4.1V  */
#define PMU_HVDTS_4V2    ((uint32)0x00000012U) /*!< HVD threshold 4.2V  */
#define PMU_HVDTS_4V3    ((uint32)0x00000013U) /*!< HVD threshold 4.3V  */
#define PMU_HVDTS_4V4    ((uint32)0x00000014U) /*!< HVD threshold 4.4V  */
#define PMU_HVDTS_4V5    ((uint32)0x00000015U) /*!< HVD threshold 4.5V  */
#define PMU_HVDTS_4V6    ((uint32)0x00000016U) /*!< HVD threshold 4.6V  */
#define PMU_HVDTS_4V7    ((uint32)0x00000017U) /*!< HVD threshold 4.7V  */
#define PMU_HVDTS_4V8    ((uint32)0x00000018U) /*!< HVD threshold 4.8V  */
#define PMU_HVDTS_4V9    ((uint32)0x00000019U) /*!< HVD threshold 4.9V  */
#define PMU_HVDTS_5V0    ((uint32)0x0000001AU) /*!< HVD threshold 5.0V  */
#define PMU_HVDTS_5V1    ((uint32)0x0000001BU) /*!< HVD threshold 5.1V  */
#define PMU_HVDTS_5V2    ((uint32)0x0000001CU) /*!< HVD threshold 5.2V  */
#define PMU_HVDTS_5V3    ((uint32)0x0000001DU) /*!< HVD threshold 5.3V  */
#define PMU_HVDTS_5V4    ((uint32)0x0000001EU) /*!< HVD threshold 5.4V  */
#define PMU_HVDTS_5V5    ((uint32)0x0000001FU) /*!< HVD threshold 5.5V (default) */
/**
  * @}
  */

/** @defgroup PMU_LVDTS PMU Low Voltage Detect Threshold Scaling
  * @note  The values are the VDCR.LVDTS field values.
  * @{
  */
#define PMU_LVDTS_2V4    ((uint32)0x00000000U) /*!< LVD threshold 2.4V  */
#define PMU_LVDTS_2V5    ((uint32)0x00000001U) /*!< LVD threshold 2.5V  */
#define PMU_LVDTS_2V6    ((uint32)0x00000002U) /*!< LVD threshold 2.6V  */
#define PMU_LVDTS_2V7    ((uint32)0x00000003U) /*!< LVD threshold 2.7V  */
#define PMU_LVDTS_2V8    ((uint32)0x00000004U) /*!< LVD threshold 2.8V  */
#define PMU_LVDTS_2V9    ((uint32)0x00000005U) /*!< LVD threshold 2.9V (default) */
#define PMU_LVDTS_3V0    ((uint32)0x00000006U) /*!< LVD threshold 3.0V  */
#define PMU_LVDTS_3V1    ((uint32)0x00000007U) /*!< LVD threshold 3.1V  */
#define PMU_LVDTS_3V2    ((uint32)0x00000008U) /*!< LVD threshold 3.2V  */
#define PMU_LVDTS_3V3    ((uint32)0x00000009U) /*!< LVD threshold 3.3V  */
#define PMU_LVDTS_3V4    ((uint32)0x0000000AU) /*!< LVD threshold 3.4V  */
#define PMU_LVDTS_3V5    ((uint32)0x0000000BU) /*!< LVD threshold 3.5V  */
#define PMU_LVDTS_3V6    ((uint32)0x0000000CU) /*!< LVD threshold 3.6V  */
#define PMU_LVDTS_3V7    ((uint32)0x0000000DU) /*!< LVD threshold 3.7V  */
#define PMU_LVDTS_3V8    ((uint32)0x0000000EU) /*!< LVD threshold 3.8V  */
#define PMU_LVDTS_3V9    ((uint32)0x0000000FU) /*!< LVD threshold 3.9V  */
#define PMU_LVDTS_4V0    ((uint32)0x00000010U) /*!< LVD threshold 4.0V  */
#define PMU_LVDTS_4V1    ((uint32)0x00000011U) /*!< LVD threshold 4.1V  */
#define PMU_LVDTS_4V2    ((uint32)0x00000012U) /*!< LVD threshold 4.2V  */
#define PMU_LVDTS_4V3    ((uint32)0x00000013U) /*!< LVD threshold 4.3V  */
#define PMU_LVDTS_4V4    ((uint32)0x00000014U) /*!< LVD threshold 4.4V  */
#define PMU_LVDTS_4V5    ((uint32)0x00000015U) /*!< LVD threshold 4.5V  */
#define PMU_LVDTS_4V6    ((uint32)0x00000016U) /*!< LVD threshold 4.6V  */
#define PMU_LVDTS_4V7    ((uint32)0x00000017U) /*!< LVD threshold 4.7V  */
#define PMU_LVDTS_4V8    ((uint32)0x00000018U) /*!< LVD threshold 4.8V  */
#define PMU_LVDTS_4V9    ((uint32)0x00000019U) /*!< LVD threshold 4.9V  */
#define PMU_LVDTS_5V0    ((uint32)0x0000001AU) /*!< LVD threshold 5.0V  */
#define PMU_LVDTS_5V1    ((uint32)0x0000001BU) /*!< LVD threshold 5.1V  */
#define PMU_LVDTS_5V2    ((uint32)0x0000001CU) /*!< LVD threshold 5.2V  */
#define PMU_LVDTS_5V3    ((uint32)0x0000001DU) /*!< LVD threshold 5.3V  */
#define PMU_LVDTS_5V4    ((uint32)0x0000001EU) /*!< LVD threshold 5.4V  */
#define PMU_LVDTS_5V5    ((uint32)0x0000001FU) /*!< LVD threshold 5.5V  */
/**
  * @}
  */

/** @defgroup PMU_Flags PMU Status Flags
  * @note  The values are encoded: bits[6:5] select the status register
  *        (01 = LDOSR, 10 = WKFR), bits[4:0] give the bit position.
  * @{
  */
#define PMU_FLAG_3V3LDORDY  ((uint32)0x00000020U) /*!< 3.3V LDO ready flag  */
#define PMU_FLAG_2V5LDORDY  ((uint32)0x00000021U) /*!< 2.5V LDO ready flag  */
#define PMU_FLAG_1V2LDORDY  ((uint32)0x00000022U) /*!< 1.2V LDO ready flag  */
#define PMU_FLAG_1V2BLDORDY ((uint32)0x00000023U) /*!< 1.2V backup LDO ready flag */
#define PMU_FLAG_IWDGWK     ((uint32)0x00000040U) /*!< IWDG wake-up flag    */
#define PMU_FLAG_RTCWK      ((uint32)0x00000043U) /*!< RTC wake-up flag     */
#define PMU_FLAG_PH0WK      ((uint32)0x00000044U) /*!< PH0 wake-up flag     */
#define PMU_FLAG_PH1WK      ((uint32)0x00000045U) /*!< PH1 wake-up flag     */
#define PMU_FLAG_PH2WK      ((uint32)0x00000046U) /*!< PH2 wake-up flag     */
#define PMU_FLAG_PH3WK      ((uint32)0x00000047U) /*!< PH3 wake-up flag     */
#define PMU_FLAG_PH4WK      ((uint32)0x00000048U) /*!< PH4 wake-up flag     */
#define PMU_FLAG_PH5WK      ((uint32)0x00000049U) /*!< PH5 wake-up flag     */
#define PMU_FLAG_PH6WK      ((uint32)0x0000004AU) /*!< PH6 wake-up flag     */
#define PMU_FLAG_PH7WK      ((uint32)0x0000004BU) /*!< PH7 wake-up flag     */
#define PMU_FLAG_PH8WK      ((uint32)0x0000004CU) /*!< PH8 wake-up flag     */
#define PMU_FLAG_PH9WK      ((uint32)0x0000004DU) /*!< PH9 wake-up flag     */
#define PMU_FLAG_FOCUR      ((uint32)0x0000004EU) /*!< FOCU reset flag      */
/**
  * @}
  */

/** @defgroup PMU_Flag_Clear PMU Flag Clear Values
  * @note  The values are the WKFR register write values (write 1 to clear).
  * @{
  */
#define PMU_CLEAR_IWDGWKF  ((uint32)0x00000001U)  /*!< Clear IWDG wake-up flag */
#define PMU_CLEAR_RTCWKF   ((uint32)0x00000008U)  /*!< Clear RTC wake-up flag  */
#define PMU_CLEAR_PH0WKF   ((uint32)0x00000010U)  /*!< Clear PH0 wake-up flag  */
#define PMU_CLEAR_PH1WKF   ((uint32)0x00000020U)  /*!< Clear PH1 wake-up flag  */
#define PMU_CLEAR_PH2WKF   ((uint32)0x00000040U)  /*!< Clear PH2 wake-up flag  */
#define PMU_CLEAR_PH3WKF   ((uint32)0x00000080U)  /*!< Clear PH3 wake-up flag  */
#define PMU_CLEAR_PH4WKF   ((uint32)0x00000100U)  /*!< Clear PH4 wake-up flag  */
#define PMU_CLEAR_PH5WKF   ((uint32)0x00000200U)  /*!< Clear PH5 wake-up flag  */
#define PMU_CLEAR_PH6WKF   ((uint32)0x00000400U)  /*!< Clear PH6 wake-up flag  */
#define PMU_CLEAR_PH7WKF   ((uint32)0x00000800U)  /*!< Clear PH7 wake-up flag  */
#define PMU_CLEAR_PH8WKF   ((uint32)0x00001000U)  /*!< Clear PH8 wake-up flag  */
#define PMU_CLEAR_PH9WKF   ((uint32)0x00002000U)  /*!< Clear PH9 wake-up flag  */
#define PMU_CLEAR_FOCURF   ((uint32)0x00004000U)  /*!< Clear FOCU reset flag  */
/**
  * @}
  */

/** @defgroup PMU_WakeUp_Masks PMU Wake-up Source Masks
  * @note  The values are WKEN / WKFR register bit masks, so that several
  *        channels can be enabled or cleared in one call
  *        (HAL_PMU_WakeUpSourceCmd() / HAL_PMU_ClearFlag() accept any
  *        combination of the available channels).
  * @note  The register bits 1 and 2 are reserved: they are deliberately absent
  *        from these masks, so the reserved bits are never written.
  * @{
  */
#define PMU_WKSOURCE_ALL  ((uint32)(HAL_PMU_WKSOURCE_IWDG | HAL_PMU_WKSOURCE_RTC  | \
                                    HAL_PMU_WKSOURCE_PH0  | HAL_PMU_WKSOURCE_PH1  | \
                                    HAL_PMU_WKSOURCE_PH2  | HAL_PMU_WKSOURCE_PH3  | \
                                    HAL_PMU_WKSOURCE_PH4  | HAL_PMU_WKSOURCE_PH5  | \
                                    HAL_PMU_WKSOURCE_PH6  | HAL_PMU_WKSOURCE_PH7  | \
                                    HAL_PMU_WKSOURCE_PH8  | HAL_PMU_WKSOURCE_PH9))
#define PMU_CLEAR_ALL     ((uint32)(PMU_CLEAR_IWDGWKF | PMU_CLEAR_RTCWKF | PMU_CLEAR_PH0WKF | \
                                    PMU_CLEAR_PH1WKF | PMU_CLEAR_PH2WKF | PMU_CLEAR_PH3WKF | \
                                    PMU_CLEAR_PH4WKF | PMU_CLEAR_PH5WKF | PMU_CLEAR_PH6WKF | \
                                    PMU_CLEAR_PH7WKF | PMU_CLEAR_PH8WKF | PMU_CLEAR_PH9WKF | \
                                    PMU_CLEAR_FOCURF))
/**
  * @}
  */

/**
  * @}
  */

/* Exported macros ------------------------------------------------------------*/

/** @defgroup PMU_Exported_Macros PMU Exported Macros
  * @{
  */

/**
 * @brief  Reset the handle State field.
 * @note   Must be used before passing a local handle to HAL_PMU_Init() the
 *         first time, so that the low level initialization (MspInit) is
 *         always executed.
 */
#define __HAL_PMU_RESET_HANDLE_STATE(__HANDLE__) ((__HANDLE__)->State = 0U)

/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/

/** @addtogroup PMU_Exported_Functions
  * @{
  */

/** @addtogroup PMU_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Initializes the PMU handle. (NON-BLOCKING)
 * @note   The PMU is located on the APB-BusS clock domain and is always
 *         clocked; the default HAL_PMU_MspInit() is empty. The user may
 *         override it to configure additional low-level settings.
 * @note   Every configuration interface requires the handle to be READY, so
 *         HAL_PMU_Init() must be called before the LDO / detector / wake-up
 *         interfaces (a handle straight from __HAL_CLEAR_STRUCT() is in the
 *         RESET state and its calls are rejected with HAL_ERROR).
 * @note   LOCK-06: the low level initialization (HAL_PMU_MspInit()) runs
 *         before the handle is locked.
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (NULL pointer or invalid instance)
 */
HAL_StatusTypeDef HAL_PMU_Init(HAL_PMU_HandleTypeDef *hpmu);

/**
 * @brief  De-initializes the PMU peripheral. (NON-BLOCKING)
 * @note   The call is accepted from any handle state, so that a failed
 *         initialization can always be undone; the handle goes back to the
 *         RESET state so that a following HAL_PMU_Init() re-runs
 *         HAL_PMU_MspInit().
 * @note   LOCK-06: the low level de-initialization (HAL_PMU_MspDeInit()) runs
 *         after the unlock.
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (NULL pointer or invalid instance)
 */
HAL_StatusTypeDef HAL_PMU_DeInit(HAL_PMU_HandleTypeDef *hpmu);

/**
 * @brief  Initializes the PMU MSP. Weak empty function; the PMU is always
 *         clocked on the APB-BusS domain, no clock gating is needed.
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @retval None
 */
void HAL_PMU_MspInit(HAL_PMU_HandleTypeDef *hpmu);

/**
 * @brief  De-initializes the PMU MSP. Weak empty function.
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @retval None
 */
void HAL_PMU_MspDeInit(HAL_PMU_HandleTypeDef *hpmu);

/**
  * @}
  */

/** @addtogroup PMU_Exported_Functions_Group2 Power Mode functions
  * @{
  */

/**
 * @brief  Selects the power mode to be switched to (sleep or deep sleep). (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_PMU_Init() is required first).
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  PowerMode: HAL_PMU_POWERMODE_SLEEP or HAL_PMU_POWERMODE_DEEPSLEEP.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_PMU_PowerModeConfig(HAL_PMU_HandleTypeDef *hpmu, HAL_PMU_PowerModeTypeDef PowerMode);

/**
 * @brief  Returns the current working power mode. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context.
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @retval HAL_PMU_PowerModeTypeDef: the current power mode
 *         (HAL_PMU_POWERMODE_INIT when the handle or the instance is invalid).
 */
HAL_PMU_PowerModeTypeDef HAL_PMU_GetPowerModeStatus(HAL_PMU_HandleTypeDef *hpmu);

/**
  * @}
  */

/** @addtogroup PMU_Exported_Functions_Group3 Wake-up Source functions
  * @{
  */

/**
 * @brief  Enables or disables the sleep wake-up source channel(s). (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_PMU_Init() is required first).
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  WakeUpSource: HAL_PMU_WKSOURCE_xxx combination (WKEN bit masks).
 * @param  NewState: PMU_ENABLE or PMU_DISABLE.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_PMU_WakeUpSourceCmd(HAL_PMU_HandleTypeDef *hpmu, uint32 WakeUpSource, FunctionalState NewState);

/**
  * @}
  */

/** @addtogroup PMU_Exported_Functions_Group4 LDO Control functions
  * @{
  */

/**
 * @brief  Enables or disables the 3.3V LDO. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_PMU_Init() is required first).
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  NewState: PMU_ENABLE or PMU_DISABLE.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_PMU_LDO3v3Cmd(HAL_PMU_HandleTypeDef *hpmu, FunctionalState NewState);

/**
 * @brief  Enables or disables the 3.3V LDO bypass. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_PMU_Init() is required first).
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  NewState: PMU_ENABLE or PMU_DISABLE.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_PMU_LDO3v3BypassCmd(HAL_PMU_HandleTypeDef *hpmu, FunctionalState NewState);

/**
 * @brief  Sets the 3.3V LDO output voltage scaling. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_PMU_Init() is required first).
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  VoltageValue: PMU_VO33_xxx voltage selection.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_PMU_LDO3v3VOLSca(HAL_PMU_HandleTypeDef *hpmu, uint32 VoltageValue);

/**
 * @brief  Enables or disables the 2.5V LDO. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_PMU_Init() is required first).
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  NewState: PMU_ENABLE or PMU_DISABLE.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_PMU_LDO2v5Cmd(HAL_PMU_HandleTypeDef *hpmu, FunctionalState NewState);

/**
 * @brief  Sets the 2.5V LDO output voltage scaling. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_PMU_Init() is required first).
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  VoltageValue: PMU_VO25_xxx voltage selection.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_PMU_LDO2v5VOLSca(HAL_PMU_HandleTypeDef *hpmu, uint32 VoltageValue);

/**
 * @brief  Enables or disables the 1.2V LDO. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_PMU_Init() is required first).
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  NewState: PMU_ENABLE or PMU_DISABLE.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_PMU_LDO1v2Cmd(HAL_PMU_HandleTypeDef *hpmu, FunctionalState NewState);

/**
 * @brief  Sets the 1.2V LDO output voltage scaling. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_PMU_Init() is required first).
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  VoltageValue: PMU_VO12_xxx voltage selection.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_PMU_LDO1v2VOLSca(HAL_PMU_HandleTypeDef *hpmu, uint32 VoltageValue);

/**
 * @brief  Sets the 1.2V backup LDO output voltage scaling. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_PMU_Init() is required first).
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  VoltageValue: PMU_VO12_xxx voltage selection.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_PMU_BLDO1v2VOLSca(HAL_PMU_HandleTypeDef *hpmu, uint32 VoltageValue);

/**
 * @brief  Enables or disables the 1.2V reference voltage source. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_PMU_Init() is required first).
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  NewState: PMU_ENABLE or PMU_DISABLE.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_PMU_Refer1v2Cmd(HAL_PMU_HandleTypeDef *hpmu, FunctionalState NewState);

/**
 * @brief  Sets the 1.2V reference voltage source scaling. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_PMU_Init() is required first).
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  VoltageValue: PMU_VREF12_xxx voltage selection.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_PMU_Refer1v2VOLSca(HAL_PMU_HandleTypeDef *hpmu, uint32 VoltageValue);

/**
  * @}
  */

/** @addtogroup PMU_Exported_Functions_Group5 Voltage Detection functions
  * @{
  */

/**
 * @brief  Enables or disables the low voltage reset. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_PMU_Init() is required first).
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  NewState: PMU_ENABLE or PMU_DISABLE.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_PMU_LowVolResetCmd(HAL_PMU_HandleTypeDef *hpmu, FunctionalState NewState);

/**
 * @brief  Enables or disables the high voltage detect. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_PMU_Init() is required first).
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  NewState: PMU_ENABLE or PMU_DISABLE.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_PMU_HighVolDetectCmd(HAL_PMU_HandleTypeDef *hpmu, FunctionalState NewState);

/**
 * @brief  Sets the high voltage detect threshold scaling. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_PMU_Init() is required first).
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  VoltageValue: PMU_HVDTS_xxx threshold selection.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_PMU_HighVolDetectThresholdSca(HAL_PMU_HandleTypeDef *hpmu, uint32 VoltageValue);

/**
 * @brief  Enables or disables the low voltage detect. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_PMU_Init() is required first).
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  NewState: PMU_ENABLE or PMU_DISABLE.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_PMU_LowVolDetectCmd(HAL_PMU_HandleTypeDef *hpmu, FunctionalState NewState);

/**
 * @brief  Sets the low voltage detect threshold scaling. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_PMU_Init() is required first).
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  VoltageValue: PMU_LVDTS_xxx threshold selection.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_PMU_LowVolDetectThresholdSca(HAL_PMU_HandleTypeDef *hpmu, uint32 VoltageValue);

/**
  * @}
  */

/** @addtogroup PMU_Exported_Functions_Group6 Oscillator Control functions
  * @{
  */

/**
 * @brief  Enables or disables the internal RC 16 MHz oscillator. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_PMU_Init() is required first).
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  NewState: PMU_ENABLE or PMU_DISABLE.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_PMU_RC16MCmd(HAL_PMU_HandleTypeDef *hpmu, FunctionalState NewState);

/**
 * @brief  Sets the RC 32 kHz clock frequency scaling. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_PMU_Init() is required first).
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  ClockFrequency: RC 32 kHz frequency scaling (0..0x3F).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_PMU_RC32KFrequencySca(HAL_PMU_HandleTypeDef *hpmu, uint32 ClockFrequency);

/**
  * @}
  */

/** @addtogroup PMU_Exported_Functions_Group7 Flag and State functions
  * @{
  */

/**
 * @brief  Checks whether a PMU flag is set. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context.
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  PMU_FLAG: the flag to check (PMU_FLAG_xxx).
 * @retval 1 if the flag is set, 0 otherwise (also when the handle, the instance
 *         or the flag value is invalid).
 */
uint32 HAL_PMU_GetFlagStatus(HAL_PMU_HandleTypeDef *hpmu, uint32 PMU_FLAG);

/**
 * @brief  Checks whether one or more PMU wake-up status flags are set.
 *         (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context.
 * @note   The parameter is the same mask family that HAL_PMU_ClearFlag()
 *         writes, so one observation window can test and clear exactly the
 *         same wake-up sources with the same value.
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  WakeUpFlag: non-zero combination of the wake-up flag masks
 *         (PMU_CLEAR_IWDGWKF / PMU_CLEAR_RTCWKF / PMU_CLEAR_PH0WKF ..
 *         PMU_CLEAR_PH9WKF / PMU_CLEAR_FOCURF, or PMU_CLEAR_ALL).
 * @retval 1 if at least one of the selected flags is set, 0 otherwise (also
 *         when the handle, the instance binding or the mask is invalid).
 */
uint32 HAL_PMU_GetWakeUpFlag(HAL_PMU_HandleTypeDef *hpmu, uint32 WakeUpFlag);

/**
 * @brief  Clears a PMU wake-up flag. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_PMU_Init() is required first).
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  PMU_FLAG: the flag to clear (PMU_CLEAR_xxx, WKFR write value).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_PMU_ClearFlag(HAL_PMU_HandleTypeDef *hpmu, uint32 PMU_FLAG);

/**
 * @brief  Returns the PMU handle state. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context.
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @retval HAL_PMU_StateTypeDef: the current handle state.
 */
HAL_PMU_StateTypeDef HAL_PMU_GetState(HAL_PMU_HandleTypeDef *hpmu);

/**
 * @brief  Returns the PMU error code. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context.
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @retval uint32: the PMU error code (HAL_PMU_ERROR_xxx).
 */
uint32 HAL_PMU_GetError(HAL_PMU_HandleTypeDef *hpmu);

/**
  * @}
  */

/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/

/** @defgroup PMU_Private_Macros PMU Private Macros
  * @{
  */

/**
 * @brief  Check that the PMU peripheral instance is valid.
 */
#define IS_PMU_ALL_INSTANCE(INSTANCE) ((INSTANCE) == PMU)

/**
 * @brief  Check that the power mode is a valid selectable value.
 */
#define IS_PMU_POWERMODE(MODE) (((MODE) == HAL_PMU_POWERMODE_DEEPSLEEP) || \
                                ((MODE) == HAL_PMU_POWERMODE_SLEEP))

/**
 * @brief  Check that the wake-up source is a valid value.
 */
#define IS_PMU_WKSOURCE(SOURCE) (((SOURCE) == HAL_PMU_WKSOURCE_IWDG) || \
                                 ((SOURCE) == HAL_PMU_WKSOURCE_RTC)  || \
                                 ((SOURCE) == HAL_PMU_WKSOURCE_PH0)  || \
                                 ((SOURCE) == HAL_PMU_WKSOURCE_PH1)  || \
                                 ((SOURCE) == HAL_PMU_WKSOURCE_PH2)  || \
                                 ((SOURCE) == HAL_PMU_WKSOURCE_PH3)  || \
                                 ((SOURCE) == HAL_PMU_WKSOURCE_PH4)  || \
                                 ((SOURCE) == HAL_PMU_WKSOURCE_PH5)  || \
                                 ((SOURCE) == HAL_PMU_WKSOURCE_PH6)  || \
                                 ((SOURCE) == HAL_PMU_WKSOURCE_PH7)  || \
                                 ((SOURCE) == HAL_PMU_WKSOURCE_PH8)  || \
                                 ((SOURCE) == HAL_PMU_WKSOURCE_PH9))

/**
 * @brief  Check that a wake-up source mask is a combination of available
 *         channels.
 * @note   IS_PMU_WKSOURCE() accepts one single channel; this macro accepts any
 *         combination of the twelve channels (PMU_WKSOURCE_ALL) and still
 *         rejects the value 0, the two reserved register bits (0x002 and
 *         0x004) and the FOCU reset bit, so a reserved bit of WKEN can never be
 *         written.
 */
#define IS_PMU_WKSOURCE_MASK(MASK) (((MASK) != 0U) && (((MASK) & ~(PMU_WKSOURCE_ALL)) == 0U))

/**
 * @brief  Check that the enable value is valid.
 */
#define IS_PMU_ENABLE_STATE(NEWSTATE) (((NEWSTATE) == PMU_ENABLE) || ((NEWSTATE) == PMU_DISABLE))

/**
 * @brief  Check that the 3.3V LDO voltage scaling is valid (0..0xF).
 */
#define IS_PMU_VOS3V3(VOS3V3) ((VOS3V3) <= 0xFU)

/**
 * @brief  Check that the 2.5V LDO voltage scaling is valid (0..0xF).
 */
#define IS_PMU_VOS2V5(VOS2V5) ((VOS2V5) <= 0xFU)

/**
 * @brief  Check that the 1.2V LDO voltage scaling is valid (0..0xF).
 */
#define IS_PMU_VOS1V2(VOS1V2) ((VOS1V2) <= 0xFU)

/**
 * @brief  Check that the 1.2V reference voltage scaling is valid (0..0xF).
 */
#define IS_PMU_VREFS1V2(VREFS1V2) ((VREFS1V2) <= 0xFU)

/**
 * @brief  Check that the high voltage detect threshold scaling is valid
 *         (0..0x1F).
 */
#define IS_PMU_HVDTS(HVDTS) ((HVDTS) <= 0x1FU)

/**
 * @brief  Check that the low voltage detect threshold scaling is valid
 *         (0..0x1F).
 */
#define IS_PMU_LVDTS(LVDTS) ((LVDTS) <= 0x1FU)

/**
 * @brief  Check that the RC 32 kHz frequency scaling is valid (0..0x3F).
 */
#define IS_PMU_RC32KFS(RC32KFS) ((RC32KFS) <= 0x3FU)

/**
 * @brief  Check that the flag is a valid value.
 */
#define IS_PMU_FLAG(FLAG) (((FLAG) == PMU_FLAG_3V3LDORDY)  || ((FLAG) == PMU_FLAG_2V5LDORDY) || \
                           ((FLAG) == PMU_FLAG_1V2LDORDY)  || ((FLAG) == PMU_FLAG_1V2BLDORDY) || \
                           ((FLAG) == PMU_FLAG_IWDGWK)     || ((FLAG) == PMU_FLAG_RTCWK)      || \
                           ((FLAG) == PMU_FLAG_PH0WK)      || ((FLAG) == PMU_FLAG_PH1WK)      || \
                           ((FLAG) == PMU_FLAG_PH2WK)      || ((FLAG) == PMU_FLAG_PH3WK)      || \
                           ((FLAG) == PMU_FLAG_PH4WK)      || ((FLAG) == PMU_FLAG_PH5WK)      || \
                           ((FLAG) == PMU_FLAG_PH6WK)      || ((FLAG) == PMU_FLAG_PH7WK)      || \
                           ((FLAG) == PMU_FLAG_PH8WK)      || ((FLAG) == PMU_FLAG_PH9WK)      || \
                           ((FLAG) == PMU_FLAG_FOCUR))

/**
 * @brief  Check that the flag clear value is valid.
 */
#define IS_PMU_CLEAR(CLEAR) (((CLEAR) == PMU_CLEAR_IWDGWKF) || ((CLEAR) == PMU_CLEAR_RTCWKF) || \
                             ((CLEAR) == PMU_CLEAR_PH0WKF)  || ((CLEAR) == PMU_CLEAR_PH1WKF)  || \
                             ((CLEAR) == PMU_CLEAR_PH2WKF)  || ((CLEAR) == PMU_CLEAR_PH3WKF)  || \
                             ((CLEAR) == PMU_CLEAR_PH4WKF)  || ((CLEAR) == PMU_CLEAR_PH5WKF)  || \
                             ((CLEAR) == PMU_CLEAR_PH6WKF)  || ((CLEAR) == PMU_CLEAR_PH7WKF)  || \
                             ((CLEAR) == PMU_CLEAR_PH8WKF)  || ((CLEAR) == PMU_CLEAR_PH9WKF)  || \
                             ((CLEAR) == PMU_CLEAR_FOCURF))

/**
 * @brief  Check that a flag clear mask is a combination of clearable flags.
 * @note   IS_PMU_CLEAR() accepts one single flag; this macro accepts any
 *         combination of the wake-up channels and the FOCU reset flag
 *         (PMU_CLEAR_ALL, i.e. clear every wake-up flag in one access) and
 *         still rejects the value 0 and the two reserved register bits (0x002
 *         and 0x004, which the register uses for the read only supply ready
 *         bits), so a reserved bit of WKFR can never be written.
 */
#define IS_PMU_CLEAR_MASK(MASK) (((MASK) != 0U) && (((MASK) & ~(PMU_CLEAR_ALL)) == 0U))

/**
  * @}
  */

/* Shared internal functions --------------------------------------------------*/

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_PMU_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; when the mutex is not acquired before the
 *         Timeout expires, HAL_TIMEOUT is returned. The value is passed to
 *         HAL_MutexAcquire() as is (RTOS ticks; with the usual 1 ms tick it is
 *         the same quantity as the millisecond Timeout of the public API, and
 *         HAL_MAX_DELAY means an infinite wait).
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef PMU_LockHandle(HAL_PMU_HandleTypeDef *hpmu, uint32 Timeout);

/**
 * @brief  Unlock the handle.
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @retval None
 */
void PMU_UnlockHandle(HAL_PMU_HandleTypeDef *hpmu);

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_PMU_H */

/*****END OF FILE*****/
