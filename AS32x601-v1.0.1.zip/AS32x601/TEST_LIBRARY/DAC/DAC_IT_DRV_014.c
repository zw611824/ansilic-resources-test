/**
 * @file    DAC_IT_DRV_014.c
 * @brief   HAL DAC integration test case 014 (two instances and clock gating).
 *
 * Extension case of the DAC integration test suite: it checks that the two DAC
 * instances are independent (registers, data path, comparator, clock gate and
 * de-initialization) and that the clock gate of the module follows the MSP
 * callbacks, which is what makes the DAC usable at all (the default callbacks
 * of the driver are empty).
 * Only HAL library APIs are used.
 *
 * Tested functionality:
 *   DAC0 / DAC1                   (independent registers and data paths)
 *   HAL_DAC_Init() / HAL_DAC_DeInit()   (per instance life cycle)
 *   HAL_DAC_SetValue() / HAL_DAC_GetValue()
 *   HAL_DAC_ConfigComparator()
 *   the SMU gates of both instances (ALB1CFGR.DAC0EN / ALB2CFGR.DAC1EN)
 *
 * Test procedure:
 *   1. Initialize both instances with different dividers and enable both;
 *   2. Write a different data value to each instance and check that the two
 *      data registers do not influence each other;
 *   3. Check the clock dividers are independent;
 *   4. Program the comparator of DAC0 only and check that DAC1 is untouched;
 *   5. De-initialize DAC0 and check that DAC0 goes back to RESET, that its
 *      clock gate is closed and that DAC1 keeps running;
 *   6. Reject a foreign instance.
 *
 * Expected behaviour:
 *   - both instances hold their own CTRL / DOUT / CLK_DIV / CMP_CTRL values;
 *   - the clock gate of an instance follows its MSP callbacks;
 *   - de-initializing one instance does not disturb the other one;
 *   - every check prints [PASS] and "summary : failures = 0".
 *
 * @note   The DAC0 output is PE4 and the DAC1 output is PC13 (device IO map);
 *         DAC0 comparator inputs are CMP0_P (PE2) / CMP0_N (PE3).
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define -----------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* DAC output pins and comparator input pins of this suite, taken from the
 * device IO map (ioDoc): DAC0_OUT = PE4, DAC1_OUT = PC13,
 * CMP0_P = PE2, CMP0_N = PE3. */
#define TEST_DAC0_PORT              GPIOE
#define TEST_DAC0_PIN               GPIO_PIN_4
#define TEST_DAC0_SOURCE            GPIO_PinSource4
#define TEST_DAC1_PORT              GPIOC
#define TEST_DAC1_PIN               GPIO_PIN_13
#define TEST_DAC1_SOURCE            GPIO_PinSource13
#define TEST_CMP_PORT               GPIOE
#define TEST_CMP_P_PIN              GPIO_PIN_2
#define TEST_CMP_N_PIN              GPIO_PIN_3
#define TEST_CMP_P_SOURCE           GPIO_PinSource2
#define TEST_CMP_N_SOURCE           GPIO_PinSource3

/* Private variables ---------------------------------------------------------*/
static volatile uint32 check_failures = 0U;  /*!< failed check counter        */
static HAL_SMU_HandleTypeDef hsmu_clk;       /*!< SMU handle (clock tree)     */
static DAC_HandleTypeDef hadac_dev;          /*!< DAC under test              */

/* MSP callback bookkeeping (defined with the callbacks at the end of the file) */
extern uint32 Dac_MspInitCount;
extern uint32 Dac_MspDeInitCount;
extern uint32 Dac_MspStateAtInit;
extern uint32 Dac_MspLockAtInit;
extern uint32 Dac_MspStateAtDeInit;

/* Private function prototypes -----------------------------------------------*/
/* Shared helpers of this suite (defined at the end of this file) */
void Check(const char *name, uint32 condition);
void Summary(void);
void SystemClock_Init(void);
void Dac_PeriphClockEnable(DAC_TypeDef *instance);
void Dac_PinConfig(DAC_TypeDef *instance);
void Dac_InitStruct_Default(DAC_InitTypeDef *p_init);
HAL_StatusTypeDef Dac_Config(DAC_TypeDef *instance, FunctionalState enable, uint32 divider);
HAL_StatusTypeDef Dac_ConfigComparator(DAC_HandleTypeDef *hdac, uint32 cmp_enable, uint32 cmp_mode, uint32 cmp_hys);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    DAC_HandleTypeDef hdac0;
    DAC_HandleTypeDef hdac1;
    DAC_InitTypeDef   dac_init;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== DAC_IT_DRV_014 : two instances and clock gating ===\r\n");

    /* ---- Step 1: both instances --------------------------------------- */
    Dac_PinConfig(DAC0);
    Dac_PinConfig(DAC1);

    __HAL_CLEAR_STRUCT(&hdac0);
    hdac0.Instance = DAC0;
    Dac_InitStruct_Default(&dac_init);
    dac_init.DAC_Enable       = ENABLE;
    dac_init.DAC_ClockDivider = 0x10U;
    hdac0.Init = dac_init;
    Check("DAC0 : HAL_DAC_Init() returns HAL_OK", (HAL_DAC_Init(&hdac0) == HAL_OK));
    Check("DAC0 : the divider 0x10 is programmed", (DAC0->CLK_DIV == 0x10U) ? 1U : 0U);

    __HAL_CLEAR_STRUCT(&hdac1);
    hdac1.Instance = DAC1;
    Dac_InitStruct_Default(&dac_init);
    dac_init.DAC_Enable       = ENABLE;
    dac_init.DAC_ClockDivider = 0x20U;
    hdac1.Init = dac_init;
    Check("DAC1 : HAL_DAC_Init() returns HAL_OK", (HAL_DAC_Init(&hdac1) == HAL_OK));
    Check("DAC1 : the divider 0x20 is programmed", (DAC1->CLK_DIV == 0x20U) ? 1U : 0U);
    Check("both instances are READY",
          ((HAL_DAC_GetState(&hdac0) == HAL_DAC_STATE_READY) &&
           (HAL_DAC_GetState(&hdac1) == HAL_DAC_STATE_READY)) ? 1U : 0U);

    Check("DAC0 : HAL_DAC_ResetCmd(1) releases the module reset",
          (HAL_DAC_ResetCmd(&hdac0, 1U) == HAL_OK));
    Check("DAC1 : HAL_DAC_ResetCmd(1) releases the module reset",
          (HAL_DAC_ResetCmd(&hdac1, 1U) == HAL_OK));
    Check("both CTRL registers hold their own reset bit",
          (((DAC0->CTRL & DAC_CTRL_RESETN) != 0U) &&
           ((DAC1->CTRL & DAC_CTRL_RESETN) != 0U)) ? 1U : 0U);

    /* ---- Step 2: the data paths are independent ----------------------- */
    Check("DAC0 accepts the value 0x11", (HAL_DAC_SetValue(&hdac0, 0x11U) == HAL_OK));
    Check("DAC1 accepts the value 0xEE", (HAL_DAC_SetValue(&hdac1, 0xEEU) == HAL_OK));
    Check("the two data registers hold their own value",
          (((uint32)DAC0->DOUT == 0x11U) && ((uint32)DAC1->DOUT == 0xEEU)) ? 1U : 0U);
    Check("HAL_DAC_GetValue() reports the value of the right instance",
          ((HAL_DAC_GetValue(&hdac0) == 0x11U) &&
           (HAL_DAC_GetValue(&hdac1) == 0xEEU)) ? 1U : 0U);

    Check("writing DAC0 again does not change DAC1",
          ((HAL_DAC_SetValue(&hdac0, 0x22U) == HAL_OK) &&
           ((uint32)DAC0->DOUT == 0x22U) && ((uint32)DAC1->DOUT == 0xEEU)) ? 1U : 0U);

    /* ---- Step 3: the dividers are independent ------------------------- */
    Check("the clock dividers are independent",
          ((DAC0->CLK_DIV == 0x10U) && (DAC1->CLK_DIV == 0x20U)) ? 1U : 0U);

    /* ---- Step 4: the comparators are independent ---------------------- */
    Check("DAC0 : the comparator is programmed enabled / CMP_P / 330 mV",
          (Dac_ConfigComparator(&hdac0, DAC_CMP_ENABLE, DAC_CMP_MD_CMP_P,
                                DAC_CMP_HYS_330MV) == HAL_OK));
    Check("DAC0 : DAC_CMP_CTRL holds the configuration",
          ((DAC0->CMP_CTRL & DAC_CMP_CTRL_EN) != 0U) ? 1U : 0U);
    Check("DAC1 : DAC_CMP_CTRL is still at its reset value",
          (DAC1->CMP_CTRL == 0U) ? 1U : 0U);

    /* ---- Step 5: de-initializing one instance ------------------------- */
    Check("DAC0 : HAL_DAC_DeInit() returns HAL_OK", (HAL_DAC_DeInit(&hdac0) == HAL_OK));
    Check("DAC0 : the state is RESET", (HAL_DAC_GetState(&hdac0) == HAL_DAC_STATE_RESET) ? 1U : 0U);
    Check("DAC0 : the clock gate was closed by the MSP callback",
          ((SMU->ALB1CFGR & SMU_ALB1CFGR_DAC0EN) == 0U) ? 1U : 0U);
    Check("DAC1 : the state is still READY",
          (HAL_DAC_GetState(&hdac1) == HAL_DAC_STATE_READY) ? 1U : 0U);
    Check("DAC1 : the clock gate is still open",
          ((SMU->ALB2CFGR & SMU_ALB2CFGR_DAC1EN) != 0U) ? 1U : 0U);
    Check("DAC1 : the data register kept its value",
          ((uint32)DAC1->DOUT == 0xEEU) ? 1U : 0U);
    Check("DAC1 : a new write is still accepted",
          ((HAL_DAC_SetValue(&hdac1, 0x3CU) == HAL_OK) &&
           ((uint32)DAC1->DOUT == 0x3CU)) ? 1U : 0U);

    /* ---- Step 6: a foreign instance ---------------------------------- */
    hdac0.Instance = (DAC_TypeDef *)0x40000000UL;
    Check("HAL_DAC_Init() with a foreign instance returns HAL_ERROR",
          (HAL_DAC_Init(&hdac0) == HAL_ERROR));
    Check("HAL_DAC_GetValue() with a foreign instance returns 0",
          (HAL_DAC_GetValue(&hdac0) == 0U) ? 1U : 0U);

    Summary();

    for (;;)
    {
        /* Keep the console alive for the observation */
        printf("DAC0 state = %u, DAC1 state = %u, DAC1 DOUT = %u\r\n",
               PRINT_U32(HAL_DAC_GetState(&hdac0)),
               PRINT_U32(HAL_DAC_GetState(&hdac1)),
               PRINT_U32(HAL_DAC_GetValue(&hdac1)));
        delay_ms(2000U);
    }
}
/*****END OF FILE*****/

/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the other integration tests of this library:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2 and
 *         CANX2 by 8, which gives core 180 MHz, AXILiteBus1 (the DAC0 clock)
 *         and AXILiteBus2 (the DAC1 clock) 45 MHz and APB 22.5 MHz.
 * @note   Clock tree order: the dividers are written while the system clock
 *         is still the power on source (FIRC), then the PLL is configured and
 *         the system clock is switched to it. That last call programs the
 *         flash controller clock before the switch (the core keeps fetching
 *         from the flash) and updates SystemCoreClock afterwards.
 * @param  None
 * @retval None
 */
void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef    SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks of this suite (the DAC / comparator pins) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Enable the clock gate of a DAC instance and release its bus reset.
 * @note   The default MSP callbacks of the DAC driver are empty by design (the
 *         clock gate belongs to the application), therefore this suite performs
 *         the gate and bus reset handling itself. The macros drive
 *         SMU->ALB1CFGR (DAC0) / SMU->ALB2CFGR (DAC1), which is a different
 *         reset domain than the module reset bit DAC_CTRL.RESETN handled by
 *         HAL_DAC_ResetCmd().
 * @param  instance: DAC0 or DAC1
 * @retval None
 */
void Dac_PeriphClockEnable(DAC_TypeDef *instance)
{
    if (instance == DAC0)
    {
        __HAL_SMU_DAC0_CLK_ENABLE();
        __HAL_SMU_DAC0_FORCE_RESET();
        __HAL_SMU_DAC0_RELEASE_RESET();
    }
    else
    {
        __HAL_SMU_DAC1_CLK_ENABLE();
        __HAL_SMU_DAC1_FORCE_RESET();
        __HAL_SMU_DAC1_RELEASE_RESET();
    }
}

/**
 * @brief  Configure a group of pins as analog pins.
 * @note   Every pin of the mask is configured on its own, so that the
 *         multiplexer register of each pin is programmed with the "plain pin"
 *         alternate function before the pin is switched to the analog mode.
 * @param  port: GPIO port the pins belong to
 * @param  pins: pin mask (GPIO_PIN_x or a combination)
 * @retval None
 */
static void Gpio_AnalogConfig(GPIO_TypeDef *port, uint32 pins)
{
    GPIO_InitTypeDef gpio_init;
    uint32 i;
    uint32 pin;

    __HAL_CLEAR_STRUCT(&gpio_init);
    gpio_init.Size         = sizeof(gpio_init);
    gpio_init.Version      = GPIO_INIT_VERSION;
    gpio_init.Pull         = GPIO_NOPULL;
    gpio_init.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;
    gpio_init.Mode         = GPIO_MODE_ANALOG;
    gpio_init.Alternate    = GPIO_AF_Pin_x;

    for (i = 0U; i < 16U; i++)
    {
        pin = (uint32)(1UL << i);
        if ((pins & pin) != 0U)
        {
            HAL_GPIO_PinAFConfig(port, i, GPIO_AF_Pin_x);
            gpio_init.Pin = pin;
            (void)HAL_GPIO_Init(port, &gpio_init);
        }
    }
}

/**
 * @brief  Configure the analog pins of one DAC instance.
 * @note   DAC0 drives PE4 and uses the comparator inputs CMP0_P (PE2) and
 *         CMP0_N (PE3); DAC1 drives PC13. The pin map comes from the device IO
 *         map (ioDoc.xlsx, column "analog function").
 * @param  instance: DAC0 or DAC1
 * @retval None
 */
void Dac_PinConfig(DAC_TypeDef *instance)
{
    if (instance == DAC0)
    {
        Gpio_AnalogConfig(TEST_DAC0_PORT, TEST_DAC0_PIN);
        Gpio_AnalogConfig(TEST_CMP_PORT, TEST_CMP_P_PIN | TEST_CMP_N_PIN);
    }
    else
    {
        Gpio_AnalogConfig(TEST_DAC1_PORT, TEST_DAC1_PIN);
    }
}

/**
 * @brief  Fill a DAC init structure with the configuration of the reference
 *         test project (the baseline every case starts from).
 * @note   The structure meta fields (Size / Version) are filled by
 *         HAL_DAC_StructInit(), and the initialization interface validates
 *         them at run time, so this helper is the only place where the
 *         baseline is built.
 * @param  p_init: pointer to the init structure to fill
 * @retval None
 */
void Dac_InitStruct_Default(DAC_InitTypeDef *p_init)
{
    HAL_DAC_StructInit(p_init);

    p_init->DAC_Enable       = DISABLE;
    p_init->DAC_Mode         = DAC_OUTPUTBUFFER_ENABLE;
    p_init->DAC_VrefMode     = DAC_VREF_MD_VREFP;
    p_init->DAC_ClockDivider = 0x1EU;      /* the divider of the reference case */
}

/**
 * @brief  Configure and initialize one DAC instance.
 * @note   HAL_DAC_Init() does not release the module reset (DAC_CTRL.RESETN
 *         resets to 0), so HAL_DAC_ResetCmd() is called afterwards to release
 *         it: without that call HAL_DAC_Start() / HAL_DAC_SetValue() report
 *         HAL_ERROR. The clear+settle delay follows the sequence documented by
 *         the driver (release the reset, wait for the data path to settle).
 * @param  instance: DAC0 or DAC1
 * @param  enable: initial value of the DAC enable field (ENABLE / DISABLE)
 * @param  divider: clock divide ratio (1 to 0xFF)
 * @retval HAL status of HAL_DAC_Init()
 */
HAL_StatusTypeDef Dac_Config(DAC_TypeDef *instance, FunctionalState enable, uint32 divider)
{
    DAC_InitTypeDef dac_init;
    HAL_StatusTypeDef status;

    Dac_PinConfig(instance);

    __HAL_CLEAR_STRUCT(&hadac_dev);
    hadac_dev.Instance = instance;

    Dac_InitStruct_Default(&dac_init);
    dac_init.DAC_Enable       = enable;
    dac_init.DAC_ClockDivider = divider;
    hadac_dev.Init = dac_init;

    status = HAL_DAC_Init(&hadac_dev);
    if (status == HAL_OK)
    {
        (void)HAL_DAC_ResetCmd(&hadac_dev, 1U);
        delay_ms(20U);
    }

    return status;
}

/**
 * @brief  Configure the comparator of one DAC instance.
 * @param  hdac: DAC handle
 * @param  cmp_enable: DAC_CMP_ENABLE / DAC_CMP_DISABLE
 * @param  cmp_mode: DAC_CMP_MD_DACO / DAC_CMP_MD_CMP_P
 * @param  cmp_hys: DAC_CMP_HYS_xMV (0 to 7)
 * @retval HAL status of HAL_DAC_ConfigComparator()
 */
HAL_StatusTypeDef Dac_ConfigComparator(DAC_HandleTypeDef *hdac, uint32 cmp_enable,
                                       uint32 cmp_mode, uint32 cmp_hys)
{
    DAC_CMPConfTypeDef cmp_conf;

    HAL_DAC_CMPStructInit(&cmp_conf);
    cmp_conf.CMP_Enable     = cmp_enable;
    cmp_conf.CMP_Mode       = cmp_mode;
    cmp_conf.CMP_Hysteresis = cmp_hys;

    return HAL_DAC_ConfigComparator(hdac, &cmp_conf);
}

/* MSP callback bookkeeping -------------------------------------------------*/

uint32 Dac_MspInitCount    = 0U;   /*!< HAL_DAC_MspInit() call counter        */
uint32 Dac_MspDeInitCount  = 0U;   /*!< HAL_DAC_MspDeInit() call counter      */
uint32 Dac_MspStateAtInit  = 0xFFU;/*!< handle state observed in MspInit      */
uint32 Dac_MspLockAtInit   = 0xFFU;/*!< handle lock observed in MspInit       */
uint32 Dac_MspStateAtDeInit= 0xFFU;/*!< handle state observed in MspDeInit    */

/**
 * @brief  Initialize the low level hardware of the DAC (strong override of the
 *         weak callback of the driver).
 * @note   Records the call and the handle fields it observes, so that the
 *         cases can assert the MSP contract: the callback runs once per
 *         initialization, before the handle is locked (LOCK-06) and while the
 *         handle is still in the RESET state (MSP-04).
 * @param  hdac: DAC handle
 * @retval None
 */
void HAL_DAC_MspInit(DAC_HandleTypeDef *hdac)
{
    if (hdac == NULL_PTR)
    {
        return;
    }

    Dac_MspInitCount++;
    Dac_MspStateAtInit = (uint32)hdac->State;
    Dac_MspLockAtInit  = (uint32)hdac->Lock;

    Dac_PeriphClockEnable(hdac->Instance);
}

/**
 * @brief  De-initialize the low level hardware of the DAC (strong override of
 *         the weak callback of the driver).
 * @note   The callback runs after the handle has been unlocked (LOCK-06) and
 *         after the state has been set back to RESET.
 * @param  hdac: DAC handle
 * @retval None
 */
void HAL_DAC_MspDeInit(DAC_HandleTypeDef *hdac)
{
    if (hdac == NULL_PTR)
    {
        return;
    }

    Dac_MspDeInitCount++;
    Dac_MspStateAtDeInit = (uint32)hdac->State;

    if (hdac->Instance == DAC0)
    {
        __HAL_SMU_DAC0_FORCE_RESET();
        __HAL_SMU_DAC0_CLK_DISABLE();
    }
    else
    {
        __HAL_SMU_DAC1_FORCE_RESET();
        __HAL_SMU_DAC1_CLK_DISABLE();
    }
}
