/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_adc.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.6
 * Date:   2026/10/28
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/20     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.1     add the DMA handle to the ADC handle and the half-conversion callback
 *     ANSILIC APPLICATION GROUP  2026/09/17     1.2     remove the duplicated IS_FUNCTIONAL_STATE macro definition (the macro is now
 *                                                       provided by as32x601_hal_def.h)
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.3     apply the resource lock / RTOS rules:
 *                                                       document the state gate, add the
 *                                                       shared lock helper and the shared
 *                                                       handle / state checks for the
 *                                                       extended driver, change the flag
 *                                                       clear and wait interfaces to
 *                                                       HAL_StatusTypeDef (the wait gains a
 *                                                       Timeout), add the invalid parameter
 *                                                       and timeout error codes and mark the
 *                                                       blocking behaviour of every
 *                                                       interface
 *     ANSILIC APPLICATION GROUP  2026/09/21     1.4     document the value groups without referring to an external
 *                                                       implementation (the generic aliases are described as the same
 *                                                       encodings)
 *     ANSILIC APPLICATION GROUP  2026/10/10     1.5     remove the always-true lower bound of the IS_ADC_INPUT_CH /
 *                                                       IS_ADC_SAMPLE_TIME / IS_ADC_SEQUENCE range checks: their lower
 *                                                       limits are zero, so those comparisons were vacuous and raised
 *                                                       -Wtype-limits at every expansion (the upper bounds alone express
 *                                                       the accepted range, as IS_ADC_REGULAR_RANK already did)
 *     ANSILIC APPLICATION GROUP  2026/10/28     1.6     apply the double version comparison report: (a) include the master HAL header first so that
 *                                                       USE_RTOS is defined before the handle layout is declared (P3-1: a translation unit that
 *                                                       included only this header computed a 136 byte handle while the implementation uses 140),
 *                                                       (b) document the sequence length default of one (P3-2), (c) document the locking, the bounded
 *                                                       average budget and the input validation of the temperature conversion (P3-3 / P3-4),
 *                                                       (d) document the merged timeout state and the DMA snapshot rollback (P3'-1 / P3'-2) and the
 *                                                       renamed data register field macros (ADC_RDR_* / ADC_IDR_*), (e) add the blocking annotation of
 *                                                       the 22 interfaces that only the source marked and refresh the stale DMA skeleton description
 *                                                       (P3'-5). The extended declarations merged from the former _ex pair (2026/10/19) are covered
 *                                                       by this version number

 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Analog to Digital
 *                  Converter (ADC) peripheral:
 *                  - Initialization and de-initialization (HAL_ADC_Init /
 *                    HAL_ADC_DeInit + weak MSP hooks);
 *                  - IO operation (HAL_ADC_Start / HAL_ADC_Stop /
 *                    HAL_ADC_PollForConversion / HAL_ADC_GetValue, interrupt
 *                    mode with HAL_ADC_Start_IT / HAL_ADC_Stop_IT /
 *                    HAL_ADC_IRQHandler, DMA API skeleton);
 *                  - Peripheral control (HAL_ADC_ConfigChannel /
 *                    HAL_ADC_StructInit / HAL_ADC_GetConfig);
 *                  - Peripheral state and errors (HAL_ADC_GetState /
 *                    HAL_ADC_GetError).
 *                  The chip-specific features (injected group, analog
 *                  monitor AMO, temperature sensor, built-in reference,
 *                  high-resistance state, parity, average and temperature
 *                  conversion) are provided by this driver.
 *                  This driver depends on as32x601_hal_def.h (HAL common
 *                  types and utilities) and on the SMU HAL module for the
 *                  peripheral clock enable / reset release in HAL_ADC_MspInit
 *                  (see the weak implementations in as32x601_hal_adc.c).
 * @complexity  Complex
 *              Blocking + IT + DMA modes, state machine, user callbacks.
 */
#ifndef __AS32X601_HAL_ADC_H
#define __AS32X601_HAL_ADC_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
/* P3-1 (self containment): as32x601_hal.h is the only entry point that pulls in
 * as32x601_hal_conf.h, and the configuration file is the only place where
 * USE_RTOS is defined. The handle layout below depends on USE_RTOS (the
 * LockMutex field), so the configuration must be seen before the types are
 * declared: a translation unit that includes only this header would otherwise
 * compute a handle smaller than the one the implementation compiles against
 * (136 vs 140 bytes on this target, an ABI mismatch across translation units).
 * Including the master header first is harmless when the caller has already
 * included it, because both files are idempotent through their own guard. */
#include "as32x601_hal.h"           /* user configuration (USE_RTOS) + def.h   */
#include "as32x601_hal_def.h"       /* HAL common types and utilities          */
#include "as32x601.h"               /* ADC_TypeDef, ADC0/ADC1, register bits   */

/* Exported constants --------------------------------------------------------*/

/**
 * @brief ADC HAL driver module version.
 * @note  0x0100U = V1.0. Bumped only on breaking API changes (architecture
 *        spec COMPAT-13/14/15).
 */
#define __HAL_ADC_MODULE_VERSION  0x0100U

/* Forward declaration of the DMA handle (AS32X601 DMA HAL driver).
 * The struct tag is __DMA_HandleTypeDef to match the definition in
 * as32x601_hal_dma.h. */
typedef struct __DMA_HandleTypeDef DMA_HandleTypeDef;

/* Exported types ------------------------------------------------------------*/

/** @defgroup ADC_Exported_Types ADC Exported Types
  * @{
  */

/**
 * @brief  HAL ADC State structures definition (bitfields)
 * @note  The states are split in 4 scopes: global state, error state,
 *         regular group state, injected group state and analog monitor
 *         state. The State field of the handle can be composed of several
 *         of these values (bitfield encoding).
 * @{
 */
#define HAL_ADC_STATE_RESET             0x00000000U  /*!< ADC not yet initialized or disabled */
#define HAL_ADC_STATE_READY             0x00000001U  /*!< ADC peripheral ready for use        */
#define HAL_ADC_STATE_BUSY_INTERNAL     0x00000002U  /*!< ADC is busy to internal process     */
#define HAL_ADC_STATE_TIMEOUT           0x00000004U  /*!< TimeOut occurrence                  */

/* States of ADC errors */
#define HAL_ADC_STATE_ERROR_INTERNAL    0x00000010U  /*!< Internal error occurrence           */
#define HAL_ADC_STATE_ERROR_CONFIG      0x00000020U  /*!< Configuration error occurrence      */
#define HAL_ADC_STATE_ERROR_DMA         0x00000040U  /*!< DMA error occurrence                */

/* States of ADC group regular */
#define HAL_ADC_STATE_REG_BUSY          0x00000100U  /*!< A conversion on group regular is ongoing */
#define HAL_ADC_STATE_REG_EOC           0x00000200U  /*!< Conversion data available on group regular */

/* States of ADC group injected */
#define HAL_ADC_STATE_INJ_BUSY          0x00001000U  /*!< A conversion on group injected is ongoing */
#define HAL_ADC_STATE_INJ_EOC           0x00002000U  /*!< Conversion data available on group injected */

/* States of ADC analog monitor */
#define HAL_ADC_STATE_AMO               0x00010000U  /*!< Out-of-window occurrence of analog monitor */
/**
  * @}
  */

/**
 * @brief ADC Init Structure definition
 * @note  The fields map the ADC register set one-to-one and keep the device
 *        field names so that migrated code keeps compiling. The generic
 *        aliases (ADC_RESOLUTION_12B / ADC_DATAALIGN_RIGHT /
 *        ADC_SOFTWARE_START ...) are provided as constants aliases.
 *        The RegularSequenceLength / InjectSequenceLength fields are the
 *        real sequence lengths (1..16 / 1..4): a 0 value disables the
 *        corresponding sequence configuration in the SQL register.
 */
typedef struct
{
    uint32 Size;                                  /*!< sizeof(ADC_InitTypeDef), must be set by the
                                                       user after clearing the structure */
    uint32 Version;   /*!< Structure semantic version: @ref
                                                  ADC_INIT_VERSION (ADC_INIT_V1 = 0x0100U) */

    uint32 ADC_ClockDivide;                       /*!< ADC clock divide: ADC_CLK_DIVIDE_x        */
    uint32 ADC_Resolution;   /*!< ADC resolution:
                                                  ADC_RESOLUTION_12BIT/10BIT/8BIT/6BIT */
    uint32 ADC_Alignment;   /*!< ADC result alignment:
                                                  ADC_DATA_ALIGN_RIGHT/LEFT */
    uint32 ADC_Symbol;   /*!< ADC data symbol:
                                                  ADC_DATA_SELDO_UNSIGNED/SIGNED */

    uint32 ADC_RegularTrigger;   /*!< Regular group trigger source:
                                                  ADC_TRIGGER_x */
    uint32 ADC_InjectTrigger;   /*!< Injection group trigger source:
                                                  ADC_TRIGGER_x */

    FunctionalState ADC_RegularEnable;   /*!< Regular group trigger enable
                                                  (ENABLE/DISABLE) */
    FunctionalState ADC_InjectEnable;   /*!< Injection group trigger enable
                                                  (ENABLE/DISABLE) */

    FunctionalState ADC_DmaEnable;   /*!< Enable/disable ADC DMA request
                                                  (ENABLE/DISABLE) */

    uint32 ADC_TtrimRef;   /*!< Built-in reference temperature ratio:
                                                  ADC_TTRIM_x */
    uint32 ADC_VtrimRef;   /*!< Built-in reference voltage output:
                                                  ADC_VTRIM_x */
    uint32 ADC_SelvRefbiRef;   /*!< Built-in reference output voltage:
                                                  ADC_SEL_VREFBI_x */
    FunctionalState ADC_VrefbiEnable;             /*!< Enable/disable built-in reference voltage */
    uint32 ADC_SelvihdlsRef;   /*!< SAR input type:
                                                  ADC_SAR_INPUT_SINGLE_ENDED/DIFFERENTIAL */

    FunctionalState ADC_ScanModeEn;   /*!< Enable/disable scan mode for regular and
                                                  injected groups */
    FunctionalState ADC_ContinuousModeEn;         /*!< Enable/disable continuous mode */
    FunctionalState ADC_RegularDiscontinuousModeEn;   /*!< Enable/disable discontinuous mode for
                                                      regular group */
    FunctionalState ADC_InjectDiscontinuousModeEn;   /*!< Enable/disable discontinuous mode for
                                                     injected group */
    FunctionalState ADC_InjectAutoModeEn;   /*!< Enable/disable automatic mode for injected
                                                  group */
    FunctionalState ADC_IntervalModeEn;           /*!< Enable/disable interval mode for mode3/5 */

    uint8 ADC_RegularDiscontinuousNum;            /*!< Regular discontinuous mode number (0..7) */
    uint8 ADC_RegularSequenceLength;              /*!< Regular sequence length (1..16) */
    uint8 ADC_InjectSequenceLength;               /*!< Injected sequence length (1..4) */

    FunctionalState ADC_PowerEn;   /*!< Enable/disable ADC analog module power
                                                  supply */
    FunctionalState ADC_PowerRegain;   /*!< Enable/disable ADC analog module power regain (reset
                                       release) */
    FunctionalState ADC_BufEn;   /*!< Enable/disable ADC external reference
                                                  input buffer */
    uint32 Reserved[2];                           /*!< Reserved for future extension (must be 0) */
} ADC_InitTypeDef;

/**
 * @brief ADC init structure version macros.
 * @note  ADC_INIT_V1 is the current version. Future versions must be
 *        appended after the existing fields (architecture spec section 22.5).
 */
#define ADC_INIT_V1  0x0100U   /*!< ADC Init structure version V1.0 */
#define ADC_INIT_VERSION  ADC_INIT_V1   /*!< Current ADC Init structure version */

/**
 * @brief ADC Channel Configuration Structure definition
 * @note  The fields map the ADC channel configuration for one sequence rank:
 *        the sample time is written to the SPT register, the channel and the
 *        EOC interrupt enable are written to the RSQR (regular) or ISQR
 *        (injected) register of the selected rank. The Rank field replaces
 *        a separate sequence index parameter and accepts the
 *        ADC_RSEQ_0..15 / ADC_ISEQ_0..3 values.
 */
typedef struct
{
    uint32 ADC_Channel;   /*!< Channel selection: ADC_CH_x / ADC_CH_VTEMP
                                                  / ADC_CH_VBAT ... */
    uint32 ADC_SampleTime;                        /*!< ADC sample time: ADC_SPT_CLK_x */
    FunctionalState ADC_InterruptEn;   /*!< EOC interrupt enable for this rank
                                                  (ENABLE/DISABLE) */
    uint32 Rank;   /*!< Sequence rank: ADC_RSEQ_0..15 or
                                                  ADC_ISEQ_0..3 */
} ADC_ChannelConfTypeDef;

/**
 * @brief  ADC handle Structure definition
 * @note  Field order follows the architecture spec HANDLE-02:
 *        Instance -> Init -> Lock -> State -> ErrorCode -> module fields.
 *        The conversion rank field modified by the ISR / DMA callbacks is
 *        declared as __IO (HANDLE-03).
 */
typedef struct __ADC_HandleTypeDef
{
    ADC_TypeDef               *Instance;          /*!< Register base address                     */
    ADC_InitTypeDef           Init;               /*!< ADC required parameters                   */
    HAL_LockTypeDef           Lock;               /*!< ADC locking object                        */
#if (USE_RTOS == 1)
    HAL_MutexTypeDef          LockMutex;          /*!< RTOS mutex handle                         */
#endif
    __IO uint32               State;              /*!< ADC peripheral state (HAL_ADC_STATE_x) */
    __IO uint32               ErrorCode;          /*!< ADC Error code                            */
    __IO uint32               NbrOfCurrentConversionRank;   /*!< ADC number of current conversion
                                                           rank */
    DMA_HandleTypeDef         *hdma;              /*!< ADC DMA channel handle                   */
} ADC_HandleTypeDef;

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @defgroup ADC_Exported_Constants ADC Exported Constants
  * @{
  */

/** @defgroup ADC_Error_Code ADC Error Code
  * @{
  */
#define HAL_ADC_ERROR_NONE              0x00000000U  /*!< No error                          */
#define HAL_ADC_ERROR_INVALID_PARAM     0x00000002U  /*!< Invalid parameter, invalid
                                                           configuration structure or a
                                                           rejected operation                  */
#define HAL_ADC_ERROR_TIMEOUT           0x00000008U  /*!< Polling wait timeout               */
#define HAL_ADC_ERROR_INTERNAL          0x00000001U  /*!< ADC internal error: clocking, enable/disable, erroneous state */
#define HAL_ADC_ERROR_DMA               0x00000004U  /*!< DMA transfer error                */
/**
  * @}
  */

/** @defgroup ADC_Clock_Divider ADC Clock Divider
  * @note  Values are the ADC_CTRL1.PSC field encodings (device field names kept, plus
  *        generic aliases for the same encodings).
  * @{
  */
#define ADC_CLK_DIVIDE_1                0x00000000U  /*!< Input clock divided by 1  */
#define ADC_CLK_DIVIDE_2                0x00000001U  /*!< Input clock divided by 2  */
#define ADC_CLK_DIVIDE_4                0x00000002U  /*!< Input clock divided by 4  */
#define ADC_CLK_DIVIDE_6                0x00000003U  /*!< Input clock divided by 6  */
#define ADC_CLK_DIVIDE_8                0x00000004U  /*!< Input clock divided by 8  */
#define ADC_CLK_DIVIDE_10               0x00000005U  /*!< Input clock divided by 10 */
#define ADC_CLK_DIVIDE_12               0x00000006U  /*!< Input clock divided by 12 */
#define ADC_CLK_DIVIDE_14               0x00000007U  /*!< Input clock divided by 14 */
#define ADC_CLK_DIVIDE_MAX              0x00000008U  /*!< Invalid clock divide      */

#define ADC_CLOCK_SYNC_PCLK_DIV2        ADC_CLK_DIVIDE_2          /*!< Generic alias */
#define ADC_CLOCK_SYNC_PCLK_DIV4        ADC_CLK_DIVIDE_4          /*!< Generic alias */
#define ADC_CLOCK_SYNC_PCLK_DIV6        ADC_CLK_DIVIDE_6          /*!< Generic alias */
#define ADC_CLOCK_SYNC_PCLK_DIV8        ADC_CLK_DIVIDE_8          /*!< Generic alias */
/**
  * @}
  */

/** @defgroup ADC_Resolution ADC Resolution
  * @note  Values are the ADC_CTRL1.RESL field encodings and are identical to
  *        the generic HAL encodings (12B=0, 10B=1, 8B=2, 6B=3).
  * @{
  */
#define ADC_RESOLUTION_12BIT            0x00000000U  /*!< 12-bit resolution mode */
#define ADC_RESOLUTION_10BIT            0x00000001U  /*!< 10-bit resolution mode */
#define ADC_RESOLUTION_8BIT             0x00000002U  /*!< 8-bit resolution mode  */
#define ADC_RESOLUTION_6BIT             0x00000003U  /*!< 6-bit resolution mode  */
#define ADC_RESOLUTION_MAX              0x00000004U  /*!< Invalid resolution mode */

#define ADC_RESOLUTION_12B              ADC_RESOLUTION_12BIT      /*!< Generic alias */
#define ADC_RESOLUTION_10B              ADC_RESOLUTION_10BIT      /*!< Generic alias */
#define ADC_RESOLUTION_8B               ADC_RESOLUTION_8BIT       /*!< Generic alias */
#define ADC_RESOLUTION_6B               ADC_RESOLUTION_6BIT       /*!< Generic alias */
/**
  * @}
  */

/** @defgroup ADC_Data_Align ADC Data Alignment
  * @note  Values are the ADC_CTRL0.ALIGN field encodings.
  * @{
  */
#define ADC_DATA_ALIGN_RIGHT            0x00000000U  /*!< Data right alignment */
#define ADC_DATA_ALIGN_LEFT             0x00000001U  /*!< Data left alignment  */

#define ADC_DATAALIGN_RIGHT             ADC_DATA_ALIGN_RIGHT      /*!< Generic alias */
#define ADC_DATAALIGN_LEFT              ADC_DATA_ALIGN_LEFT       /*!< Generic alias */
/**
  * @}
  */

/** @defgroup ADC_Data_Symbol ADC Data Symbol
  * @note  Values are the ADC_CTRL0.SELDO field encodings (chip-specific).
  * @{
  */
#define ADC_DATA_SELDO_UNSIGNED         0x00000000U  /*!< Unsigned data */
#define ADC_DATA_SELDO_SIGNED           0x00000001U  /*!< Signed data   */
/**
  * @}
  */

/** @defgroup ADC_SAR_Input_Type ADC SAR Input Type
  * @note  Values are the ADC_CONFIG.SELVI_HD_LS field encodings
  *        (chip specific; the device field names are kept).
  * @{
  */
#define ADC_SAR_INPUT_SINGLE_ENDED      0x00000000U  /*!< Single-ended input */
#define ADC_SAR_INPUT_DIFFERENTIAL      0x00000001U  /*!< Differential input */
/**
  * @}
  */

/** @defgroup ADC_Trigger_Source ADC Trigger Source
  * @note  Values are the ADC_CTRL0.TRIGSRC / ITRIGSRC field encodings. The
  *        internal trigger is the software start (ADC_SOFTWARE_START alias).
  * @{
  */
#define ADC_TRIGGER_INTERNAL            0x00000000U  /*!< Internal software trigger */
#define ADC_TRIGGER_EXTERNAL_0          0x00000001U  /*!< External signal trigger 0 */
#define ADC_TRIGGER_EXTERNAL_1          0x00000002U  /*!< External signal trigger 1 */
#define ADC_TRIGGER_EXTERNAL_2          0x00000003U  /*!< External signal trigger 2 */
#define ADC_TRIGGER_EXTERNAL_MAX        0x00000004U  /*!< Invalid trigger           */

#define ADC_SOFTWARE_START              ADC_TRIGGER_INTERNAL      /*!< Generic alias */
/**
  * @}
  */

/** @defgroup ADC_Channels ADC Channels
  * @note  Values are the channel indexes written to the RSQR/ISQR SEQ fields
  *        and to the AMOCR.AMOCH field. The internal channels are on top of
  *        the 16 external inputs (chip specific; the device field names are kept).
  * @{
  */
#define ADC_CH_1                        0x00000000U  /*!< ADC channel 1 (input 0) */
#define ADC_CH_2                        0x00000001U  /*!< ADC channel 2 (input 1) */
#define ADC_CH_3                        0x00000002U  /*!< ADC channel 3 (input 2) */
#define ADC_CH_4                        0x00000003U  /*!< ADC channel 4 (input 3) */
#define ADC_CH_5                        0x00000004U  /*!< ADC channel 5 (input 4) */
#define ADC_CH_6                        0x00000005U  /*!< ADC channel 6 (input 5) */
#define ADC_CH_7                        0x00000006U  /*!< ADC channel 7 (input 6) */
#define ADC_CH_8                        0x00000007U  /*!< ADC channel 8 (input 7) */
#define ADC_CH_9                        0x00000008U  /*!< ADC channel 9 (input 8) */
#define ADC_CH_10                       0x00000009U  /*!< ADC channel 10 (input 9) */
#define ADC_CH_11                       0x0000000AU  /*!< ADC channel 11 (input 10) */
#define ADC_CH_12                       0x0000000BU  /*!< ADC channel 12 (input 11) */
#define ADC_CH_13                       0x0000000CU  /*!< ADC channel 13 (input 12) */
#define ADC_CH_14                       0x0000000DU  /*!< ADC channel 14 (input 13) */
#define ADC_CH_15                       0x0000000EU  /*!< ADC channel 15 (input 14) */
#define ADC_CH_16                       0x0000000FU  /*!< ADC channel 16 (input 15) */
#define ADC_CH_VTEMP                    0x00000010U  /*!< ADC Temperature sensor channel */
#define ADC_CH_VBAT                     0x00000011U  /*!< ADC external battery voltage channel */
#define ADC_CH_VR_EX_1                  0x00000012U  /*!< ADC external reference input channel 1 */
#define ADC_CH_VR_EX_2                  0x00000013U  /*!< ADC external reference input channel 2 */
#define ADC_CH_VR_EX_3                  0x00000014U  /*!< ADC external reference input channel 3 */
#define ADC_CH_MAX                      0x00000015U  /*!< Invalid channel */
#define ADC_CH_DISABLE                  0x00000020U  /*!< Disabled channel */

#define ADC_CHANNEL_0                   ADC_CH_1                  /*!< Generic alias */
#define ADC_CHANNEL_1                   ADC_CH_2                  /*!< Generic alias */
#define ADC_CHANNEL_2                   ADC_CH_3                  /*!< Generic alias */
#define ADC_CHANNEL_3                   ADC_CH_4                  /*!< Generic alias */
#define ADC_CHANNEL_4                   ADC_CH_5                  /*!< Generic alias */
#define ADC_CHANNEL_5                   ADC_CH_6                  /*!< Generic alias */
#define ADC_CHANNEL_6                   ADC_CH_7                  /*!< Generic alias */
#define ADC_CHANNEL_7                   ADC_CH_8                  /*!< Generic alias */
#define ADC_CHANNEL_8                   ADC_CH_9                  /*!< Generic alias */
#define ADC_CHANNEL_9                   ADC_CH_10                 /*!< Generic alias */
#define ADC_CHANNEL_10                  ADC_CH_11                 /*!< Generic alias */
#define ADC_CHANNEL_11                  ADC_CH_12                 /*!< Generic alias */
#define ADC_CHANNEL_12                  ADC_CH_13                 /*!< Generic alias */
#define ADC_CHANNEL_13                  ADC_CH_14                 /*!< Generic alias */
#define ADC_CHANNEL_14                  ADC_CH_15                 /*!< Generic alias */
#define ADC_CHANNEL_15                  ADC_CH_16                 /*!< Generic alias */
#define ADC_CHANNEL_TEMPSENSOR          ADC_CH_VTEMP              /*!< Generic alias */
#define ADC_CHANNEL_VBAT                ADC_CH_VBAT               /*!< Generic alias */
/**
  * @}
  */

/** @defgroup ADC_Sampling_Times ADC Sampling Times
  * @note  Values are the ADC_SPT.SPT field encodings (device field names kept, plus
  *        generic aliases for the same encodings).
  * @{
  */
#define ADC_SPT_CLK_3                   0x00000000U  /*!< Sample time 3 clock cycles  */
#define ADC_SPT_CLK_5                   0x00000001U  /*!< Sample time 5 clock cycles  */
#define ADC_SPT_CLK_7                   0x00000002U  /*!< Sample time 7 clock cycles  */
#define ADC_SPT_CLK_10                  0x00000003U  /*!< Sample time 10 clock cycles */
#define ADC_SPT_CLK_13                  0x00000004U  /*!< Sample time 13 clock cycles */
#define ADC_SPT_CLK_16                  0x00000005U  /*!< Sample time 16 clock cycles */
#define ADC_SPT_CLK_20                  0x00000006U  /*!< Sample time 20 clock cycles */
#define ADC_SPT_CLK_30                  0x00000007U  /*!< Sample time 30 clock cycles */
#define ADC_SPT_CLK_60                  0x00000008U  /*!< Sample time 60 clock cycles */
#define ADC_SPT_CLK_80                  0x00000009U  /*!< Sample time 80 clock cycles */
#define ADC_SPT_CLK_100                 0x0000000AU  /*!< Sample time 100 clock cycles */
#define ADC_SPT_CLK_120                 0x0000000BU  /*!< Sample time 120 clock cycles */
#define ADC_SPT_CLK_160                 0x0000000CU  /*!< Sample time 160 clock cycles */
#define ADC_SPT_CLK_320                 0x0000000DU  /*!< Sample time 320 clock cycles */
#define ADC_SPT_CLK_480                 0x0000000EU  /*!< Sample time 480 clock cycles */
#define ADC_SPT_CLK_640                 0x0000000FU  /*!< Sample time 640 clock cycles */
#define ADC_SPT_CLK_MAX                 0x00000010U  /*!< Invalid sample time        */

#define ADC_SAMPLETIME_3CYCLES          ADC_SPT_CLK_3             /*!< Generic alias */
#define ADC_SAMPLETIME_15CYCLES         ADC_SPT_CLK_5             /*!< Generic alias */
#define ADC_SAMPLETIME_28CYCLES         ADC_SPT_CLK_7             /*!< Generic alias */
#define ADC_SAMPLETIME_56CYCLES         ADC_SPT_CLK_10            /*!< Generic alias */
#define ADC_SAMPLETIME_84CYCLES         ADC_SPT_CLK_13            /*!< Generic alias */
#define ADC_SAMPLETIME_112CYCLES        ADC_SPT_CLK_16            /*!< Generic alias */
#define ADC_SAMPLETIME_144CYCLES        ADC_SPT_CLK_20            /*!< Generic alias */
#define ADC_SAMPLETIME_480CYCLES        ADC_SPT_CLK_480           /*!< Generic alias */
/**
  * @}
  */

/** @defgroup ADC_Sequence_Index ADC Sequence Index
  * @note  Values are the rank indexes accepted by the Rank field of
  *        ADC_ChannelConfTypeDef and by HAL_ADC_GetSeqResult() etc.
  * @{
  */
#define ADC_RSEQ_0                      0x00000000U  /*!< Regular rank 1  */
#define ADC_RSEQ_1                      0x00000001U  /*!< Regular rank 2  */
#define ADC_RSEQ_2                      0x00000002U  /*!< Regular rank 3  */
#define ADC_RSEQ_3                      0x00000003U  /*!< Regular rank 4  */
#define ADC_RSEQ_4                      0x00000004U  /*!< Regular rank 5  */
#define ADC_RSEQ_5                      0x00000005U  /*!< Regular rank 6  */
#define ADC_RSEQ_6                      0x00000006U  /*!< Regular rank 7  */
#define ADC_RSEQ_7                      0x00000007U  /*!< Regular rank 8  */
#define ADC_RSEQ_8                      0x00000008U  /*!< Regular rank 9  */
#define ADC_RSEQ_9                      0x00000009U  /*!< Regular rank 10 */
#define ADC_RSEQ_10                     0x0000000AU  /*!< Regular rank 11 */
#define ADC_RSEQ_11                     0x0000000BU  /*!< Regular rank 12 */
#define ADC_RSEQ_12                     0x0000000CU  /*!< Regular rank 13 */
#define ADC_RSEQ_13                     0x0000000DU  /*!< Regular rank 14 */
#define ADC_RSEQ_14                     0x0000000EU  /*!< Regular rank 15 */
#define ADC_RSEQ_15                     0x0000000FU  /*!< Regular rank 16 */
#define ADC_ISEQ_0                      0x00000010U  /*!< Injected rank 1 */
#define ADC_ISEQ_1                      0x00000011U  /*!< Injected rank 2 */
#define ADC_ISEQ_2                      0x00000012U  /*!< Injected rank 3 */
#define ADC_ISEQ_3                      0x00000013U  /*!< Injected rank 4 */
#define ADC_SEQ_MAX                     0x00000014U  /*!< Invalid sequence index */
/**
  * @}
  */

/** @defgroup ADC_Flags ADC Flags
  * @note  ADC_FLAG_EOC is the per-rank end of conversion flag located in the
  *        RSQR / ISQR registers: it requires a rank index and is therefore
  *        handled by functions (HAL_ADC_GetFlagStatus / HAL_ADC_ClearFlag /
  *        HAL_ADC_PollForConversion) rather than by the __HAL_ADC_GET_FLAG
  *        macro (which is limited to the STATE register flags).
  * @{
  */
#define ADC_FLAG_CONVCFT                ADC_STATE_CONVCFT         /*!< Convert trigger conflict status flag */
#define ADC_FLAG_IDLE                   ADC_STATE_IDLE            /*!< ADC idle state flag                 */
#define ADC_FLAG_AMO                    ADC_STATE_AMO             /*!< Analog monitor event occurs flag    */
#define ADC_FLAG_EOC                    ADC_RSQR_EOC              /*!< End of conversion flag (per rank)   */
/**
  * @}
  */

/** @defgroup ADC_Interrupts ADC Interrupts Definition
  * @note  The EOC interrupt of the regular / injected ranks is enabled per
  *        rank through the ADC_InterruptEn field of ADC_ChannelConfTypeDef
  *        (RSQR/ISQR.IE bits); only the analog monitor interrupt is a single
  *        register interrupt source and is usable with the __HAL_ADC_*_IT
  *        macros below.
  * @{
  */
#define ADC_IT_AMO                      ADC_AMOCR_AMOIE           /*!< Analog monitor interrupt */
/**
  * @}
  */

/**
  * @}
  */

/* Private constants ---------------------------------------------------------*/

/** @defgroup ADC_Private_Constants ADC Private Constants
  * @{
  */
/* Sequence lengths and helpers: aliases of the register header constants
    (the device layer header defines the *_SEQ_NUM spellings). */
#define ADC_REGULAR_SEQUENCE_LENGTH     ADC_REGULAR_SEQ_NUM
#define ADC_INJECT_SEQUENCE_LENGTH      ADC_INJECT_SEQ_NUM
#define ADC_REGULAR_DISCNUM             0x00000007U
#define ADC_EACH_REG_SPT_NUM            0x00000008U

/* Delay for ADC stabilization time after power on.                         */
/* Unit: us                                                                 */
#define ADC_STAB_DELAY_US               0x00000003U

/* Delay for temperature sensor stabilization time after enable.            */
/* Unit: us                                                                 */
#define ADC_TEMPSENSOR_DELAY_US         0x0000000AU

/* Per sample budget of HAL_ADC_GetAverageValue, in milliseconds.            */
/* Unit: ms                                                                  */
/* The interface has no Timeout parameter (its signature is fixed), so this  */
/* private constant bounds every sample; the whole call is therefore bounded  */
/* by Count times this value, and a conversion that never completes cannot    */
/* hang the caller. A single conversion is far shorter than this budget at    */
/* any supported clock divider.                                               */
#define ADC_AVERAGE_SAMPLE_TIMEOUT_MS   0x0000000AU
/**
  * @}
  */

/* Exported macros ------------------------------------------------------------*/

/** @defgroup ADC_Exported_Macros ADC Exported Macros
  * @{
  */

/** @defgroup ADC_Handle_Management ADC Handle Management
  * @{
  */

/**
 * @brief  Reset the ADC handle state.
 * @param  __HANDLE__: specifies the ADC handle.
 * @retval None
 */
#define __HAL_ADC_RESET_HANDLE_STATE(__HANDLE__) ((__HANDLE__)->State = HAL_ADC_STATE_RESET)
/**
  * @}
  */

/** @defgroup ADC_Enable_Disable ADC Enable / Disable
  * @{
  */

/**
 * @brief  Enable the ADC (set the ADC_CTRL1.ADON bit, analog power on).
 * @param  __HANDLE__: specifies the ADC handle.
 * @retval None
 */
#define __HAL_ADC_ENABLE(__HANDLE__)    (SET_BIT((__HANDLE__)->Instance->CTRL1, ADC_CTRL1_ADON))

/**
 * @brief  Disable the ADC (clear the ADC_CTRL1.ADON bit, analog power off).
 * @param  __HANDLE__: specifies the ADC handle.
 * @retval None
 */
#define __HAL_ADC_DISABLE(__HANDLE__)   (CLEAR_BIT((__HANDLE__)->Instance->CTRL1, ADC_CTRL1_ADON))
/**
  * @}
  */

/** @defgroup ADC_Interrupt_Management ADC Interrupt Management
  * @{
  */

/**
 * @brief  Enable the specified ADC interrupt source (analog monitor).
 * @note   Only the analog monitor interrupt (ADC_IT_AMO) is a single
 *         register interrupt source. The rank EOC interrupts are enabled
 *         through the ADC_InterruptEn field of ADC_ChannelConfTypeDef and
 *         by HAL_ADC_Start_IT().
 * @param  __HANDLE__: specifies the ADC handle.
 * @param  __INTERRUPT__: ADC interrupt (ADC_IT_AMO).
 * @retval None
 */
#define __HAL_ADC_ENABLE_IT(__HANDLE__, __INTERRUPT__)  (SET_BIT((__HANDLE__)->Instance->AMOCR, (__INTERRUPT__)))

/**
 * @brief  Disable the specified ADC interrupt source (analog monitor).
 * @param  __HANDLE__: specifies the ADC handle.
 * @param  __INTERRUPT__: ADC interrupt (ADC_IT_AMO).
 * @retval None
 */
#define __HAL_ADC_DISABLE_IT(__HANDLE__, __INTERRUPT__) (CLEAR_BIT((__HANDLE__)->Instance->AMOCR, (__INTERRUPT__)))

/**
 * @brief  Check whether the specified ADC interrupt source is enabled.
 * @param  __HANDLE__: specifies the ADC handle.
 * @param  __INTERRUPT__: ADC interrupt (ADC_IT_AMO).
 * @retval The new state of __INTERRUPT__ (TRUE or FALSE).
 */
#define __HAL_ADC_GET_IT_SOURCE(__HANDLE__, __INTERRUPT__)  (READ_BIT((__HANDLE__)->Instance->AMOCR, (__INTERRUPT__)) == (__INTERRUPT__))
/**
  * @}
  */

/** @defgroup ADC_Flag_Management ADC Flag Management
  * @{
  */

/**
 * @brief  Clear the selected ADC STATE register flags (write 0 to clear).
 * @note   The EOC flag is located in the RSQR/ISQR rank registers and needs
 *         a rank index: use HAL_ADC_ClearFlag() for it.
 * @param  __HANDLE__: specifies the ADC handle.
 * @param  __FLAG__: ADC flag (ADC_FLAG_CONVCFT / ADC_FLAG_AMO).
 * @retval None
 */
#define __HAL_ADC_CLEAR_FLAG(__HANDLE__, __FLAG__)  (CLEAR_BIT((__HANDLE__)->Instance->STATE, (__FLAG__)))

/**
 * @brief  Get the selected ADC STATE register flag status.
 * @note   The EOC flag is located in the RSQR/ISQR rank registers and needs
 *         a rank index: use HAL_ADC_GetFlagStatus() for it.
 * @param  __HANDLE__: specifies the ADC handle.
 * @param  __FLAG__: ADC flag (ADC_FLAG_CONVCFT / ADC_FLAG_IDLE / ADC_FLAG_AMO).
 * @retval The new state of __FLAG__ (TRUE or FALSE).
 */
#define __HAL_ADC_GET_FLAG(__HANDLE__, __FLAG__)    (READ_BIT((__HANDLE__)->Instance->STATE, (__FLAG__)) == (__FLAG__))
/**
  * @}
  */

/**
  * @}
  */

/* Include ADC HAL Extension module */

/* Exported functions --------------------------------------------------------*/

/** @defgroup ADC_Exported_Functions ADC Exported Functions
  * @{
  */

/** @defgroup ADC_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Initialize the ADC peripheral according to the specified parameters (NON-BLOCKING)
 *         in the hadc->Init structure (clock divide, resolution, alignment,
 *         symbol, triggers, modes, sequence lengths, power) and initialize
 *         the low level hardware.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_ADC_Init(ADC_HandleTypeDef *hadc);

/**
 * @brief  De-initialize the ADC peripheral registers to their default reset (NON-BLOCKING)
 *         values.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_ADC_DeInit(ADC_HandleTypeDef *hadc);

/**
 * @brief  Initialize the ADC MSP (peripheral clock enable, reset release).
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval None
 */
void HAL_ADC_MspInit(ADC_HandleTypeDef *hadc);

/**
 * @brief  De-initialize the ADC MSP (peripheral clock disable, reset assert).
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval None
 */
void HAL_ADC_MspDeInit(ADC_HandleTypeDef *hadc);
/**
  * @}
  */

/** @defgroup ADC_Exported_Functions_Group2 IO operation functions
  * @{
  */

/**
 * @brief  Enable the ADC (if not already powered) and start a regular group (NON-BLOCKING)
 *         conversion with the configured trigger source (software start for
 *         an internal trigger).
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_ADC_Start(ADC_HandleTypeDef *hadc);

/**
 * @brief  Disable the ADC and stop the conversions of both groups. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_ADC_Stop(ADC_HandleTypeDef *hadc);

/**
 * @brief  Poll for the end of conversion of the current regular rank (BLOCKING)
 *         (hadc->NbrOfCurrentConversionRank, advanced by HAL_ADC_GetValue()).
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  Timeout: Timeout value in milliseconds.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT / HAL_ERROR.
 * @note   On a timeout the error code HAL_ADC_ERROR_TIMEOUT and the state bit
 *         HAL_ADC_STATE_TIMEOUT are set, the regular group progress bits of
 *         this call are dropped and the handle stays directly retryable; the
 *         other state bits (ready flag, injected group, analog monitor, error
 *         bits) are preserved because the state field is a bitset.
 */
HAL_StatusTypeDef HAL_ADC_PollForConversion(ADC_HandleTypeDef *hadc, uint32 Timeout);

/**
 * @brief  Enable the ADC and start the regular group conversion in interrupt (NON-BLOCKING / IT)
 *         mode (the EOC interrupt of all configured regular ranks and the
 *         analog monitor interrupt are enabled).
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_ADC_Start_IT(ADC_HandleTypeDef *hadc);

/**
 * @brief  Disable the ADC interrupt mode of the regular group. (NON-BLOCKING / IT)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_ADC_Stop_IT(ADC_HandleTypeDef *hadc);

/**
 * @brief  Handle the ADC interrupt request: scan the EOC flags of all
 *         regular / injected ranks and the analog monitor flag.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval None
 */
void HAL_ADC_IRQHandler(ADC_HandleTypeDef *hadc);

/**
 * @brief  Enable the ADC and start the regular group conversion with DMA
 *         transfer. (NON-BLOCKING / DMA)
 * @note   The DMA channel referenced by hadc->hdma must be initialized
 *         (HAL_DMA_Init) and mapped to the ADC peripheral interface
 *         (HAL_DMA_ConfigPeriphIF); the channel data width must match the ADC
 *         data width. The transfer completion is reported through
 *         HAL_ADC_ConvCpltCallback().
 * @note   The channel parent, the three callbacks and the ADC request bit are
 *         snapshotted before they are changed: a rejected callback
 *         registration or a rejected channel start restores the snapshot and
 *         reports HAL_ERROR with HAL_ADC_ERROR_DMA, so a failed call never
 *         leaves the caller's channel attached to this driver.
 * @note   When the DMA module is not enabled in the configuration
 *         (HAL_DMA_MODULE_ENABLED not defined) the interface returns HAL_ERROR
 *         with HAL_ADC_ERROR_DMA and touches no hardware.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  pData: The destination buffer address.
 * @param  Length: The length of data to be transferred from the ADC
 *         peripheral to memory.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, NULL buffer, zero length, no DMA channel assigned,
 *         rejected registration or channel start, or the handle is not
 *         initialized).
 */
HAL_StatusTypeDef HAL_ADC_Start_DMA(ADC_HandleTypeDef *hadc, uint32 *pData, uint32 Length);

/**
 * @brief  Disable the ADC DMA mode of the regular group. (NON-BLOCKING / DMA)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_ADC_Stop_DMA(ADC_HandleTypeDef *hadc);

/**
 * @brief  Return the conversion result of the current regular rank (NON-BLOCKING)
 *         (hadc->NbrOfCurrentConversionRank) and advance the rank index for
 *         the next polling / reading cycle.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval uint32: the conversion result (RDR[rank] data field).
 */
uint32 HAL_ADC_GetValue(ADC_HandleTypeDef *hadc);

/**
 * @brief  Conversion complete callback in non-blocking mode.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval None
 */
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc);
void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef *hadc);

/**
 * @brief  Analog monitor out-of-window callback.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval None
 */
void HAL_ADC_LevelOutOfWindowCallback(ADC_HandleTypeDef *hadc);

/**
 * @brief  Error callback.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval None
 */
void HAL_ADC_ErrorCallback(ADC_HandleTypeDef *hadc);
/**
  * @}
  */

/** @defgroup ADC_Exported_Functions_Group3 Peripheral Control functions
  * @{
  */

/**
 * @brief  Initialize the ADC_InitTypeDef structure with default values. (NON-BLOCKING)
 * @param  ADC_InitStruct: pointer to an ADC_InitTypeDef structure that will
 *         be filled with the default configuration.
 * @retval None
 */
void HAL_ADC_StructInit(ADC_InitTypeDef *ADC_InitStruct);

/**
 * @brief  Initialize the ADC_ChannelConfTypeDef structure with default (NON-BLOCKING)
 *         values.
 * @note   Fills the structure with safe defaults (channel disabled, sample
 *         time 3 cycles, interrupt disabled, first regular rank).
 * @param  sConfig: pointer to an ADC_ChannelConfTypeDef structure that will
 *         be filled with the default configuration.
 * @retval None
 */
void HAL_ADC_ChannelStructInit(ADC_ChannelConfTypeDef *sConfig);

/**
 * @brief  Configure the selected ADC regular / injected channel rank (NON-BLOCKING)
 *         (sample time, channel, EOC interrupt enable).
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  sConfig: pointer to an ADC_ChannelConfTypeDef structure that
 *         contains the configuration information for the selected rank.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_ADC_ConfigChannel(ADC_HandleTypeDef *hadc, ADC_ChannelConfTypeDef *sConfig);

/**
 * @brief  Get the configuration of the selected rank from the registers. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  sConfig: pointer to an ADC_ChannelConfTypeDef structure that will
 *         be filled with the current register configuration.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_ADC_GetChannelConfig(ADC_HandleTypeDef *hadc,
                                           ADC_ChannelConfTypeDef *sConfig);

/**
 * @brief  Get the ADC converter configuration from the registers. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_ADC_GetConfig(ADC_HandleTypeDef *hadc);

/**
 * @brief  Checks whether the specified ADC flag is set or not. (NON-BLOCKING)
 * @note   The EOC flag requires the rank index of the sequence to check.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  ADC_FLAG: specifies the flag to check (ADC_FLAG_CONVCFT /
 *         ADC_FLAG_IDLE / ADC_FLAG_AMO / ADC_FLAG_EOC).
 * @param  Rank: sequence rank (ADC_RSEQ_0..15 / ADC_ISEQ_0..3, only for
 *         ADC_FLAG_EOC).
 * @retval FlagStatus: SET or RESET.
 */
FlagStatus HAL_ADC_GetFlagStatus(ADC_HandleTypeDef *hadc, uint8 ADC_FLAG, uint32 Rank);

/**
 * @brief  Clears the ADC pending flags. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  ADC_FLAG: specifies the flag to clear (ADC_FLAG_CONVCFT /
 *         ADC_FLAG_AMO / ADC_FLAG_EOC).
 * @param  Rank: sequence rank (ADC_RSEQ_0..15 / ADC_ISEQ_0..3, only for
 *         ADC_FLAG_EOC).
 * @retval None
 */
HAL_StatusTypeDef HAL_ADC_ClearFlag(ADC_HandleTypeDef *hadc, uint8 ADC_FLAG, uint32 Rank);

/**
 * @brief  Wait for the ADC conversion to finish (STATE.IDLE flag). (BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval None
 */
HAL_StatusTypeDef HAL_ADC_WaitConvDone(ADC_HandleTypeDef *hadc, uint32 Timeout);
/**
  * @}
  */

/** @defgroup ADC_Exported_Functions_Group4 Peripheral State and Errors functions
  * @{
  */

/**
 * @brief  Return the ADC state. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval uint32: the ADC state (HAL_ADC_STATE_xxx).
 */
uint32 HAL_ADC_GetState(ADC_HandleTypeDef *hadc);

/**
 * @brief  Return the ADC error code. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval uint32: the ADC error code (HAL_ADC_ERROR_xxx).
 */
uint32 HAL_ADC_GetError(ADC_HandleTypeDef *hadc);
/**
  * @}
  */

/**
  * @}
  */

/* Shared internal functions --------------------------------------------------*/

/** @defgroup ADC_Shared_Internal_Functions ADC Shared Internal Functions
  * @{
  */

/**
 * @brief  ADC initialization delay (busy loop, microseconds).
 * @note   Internal function of this driver, also used by the injected group
 *         and temperature sensor sequences (stabilization delay).
 * @param  Delayus: delay duration in microseconds.
 * @retval None
 */
void ADC_InitDelayus(uint32 Delayus);

/**
 * @brief  Check whether the handle and its instance are valid (shared by every
 *         entry point of this driver).
 * @param  hadc: pointer to an ADC_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
uint32 ADC_HandleIsValid(ADC_HandleTypeDef *hadc);

/**
 * @brief  Check whether the handle accepts a new operation (ARCH-CONST-09).
 * @note   A busy handle reports HAL_BUSY, a handle that has not been
 *         initialized (RESET) reports HAL_ERROR; the recoverable states
 *         (TIMEOUT / ERROR_x) accept the call directly.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef ADC_CheckState(ADC_HandleTypeDef *hadc);

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_ADC_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; when the mutex is not acquired before the
 *         Timeout expires, HAL_TIMEOUT is returned. The value is passed to
 *         HAL_MutexAcquire() as is (RTOS ticks; with the usual 1 ms tick it is
 *         the same quantity as the millisecond Timeout of the public API, and
 *         HAL_MAX_DELAY means an infinite wait).
 * @param  hadc: pointer to an ADC_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef ADC_LockHandle(ADC_HandleTypeDef *hadc, uint32 Timeout);

/**
 * @brief  Unlock the handle.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure.
 * @retval None
 */
void ADC_UnlockHandle(ADC_HandleTypeDef *hadc);

/**
  * @}
  */

/* Exported types ------------------------------------------------------------*/

/** @addtogroup ADC_Exported_Types ADC Exported Types
  * @{
  */

/**
 * @brief ADC Analog Monitor (AMO) Configuration Structure definition
 * @note  The fields map the AMOCR / AMOHR / AMOLR registers. The structure
 *        corresponds to the device layer ADC_AmoTypeDef (renamed to follow the
 *        xxxConfTypeDef naming convention, alias kept for migrated code).
 */
typedef struct
{
    FunctionalState ADC_AmoInterruptEn;       /*!< Enable/disable AMO interrupt            */
    FunctionalState ADC_AmoRegularEn;   /*!< Enable/disable analog monitor regular group
                                              mode */
    FunctionalState ADC_AmoInjectEn;   /*!< Enable/disable analog monitor injected group
                                              mode */
    FunctionalState ADC_AmoSingleModeEn;   /*!< Enable/disable analog monitor single channel
                                              mode */
    uint32 ADC_AmoSingleChannel;              /*!< Analog monitor single channel (ADC_CH_x) */
    uint16 ADC_AmoUpThreshold;                /*!< Analog monitor upper threshold (12-bit) */
    uint16 ADC_AmoLowThreshold;               /*!< Analog monitor lower threshold (12-bit) */
} ADC_AmoConfTypeDef;

/* Device layer compatible alias: the device layer structure was ADC_AmoTypeDef */
typedef ADC_AmoConfTypeDef ADC_AmoTypeDef;

/**
 * @brief ADC Temperature Sensor Configuration Structure definition
 * @note  The fields map the ADC_CONFIG register temperature sensor fields.
 *        The structure corresponds to the device layer ADC_TempTypeDef (renamed to
 *        follow the xxxConfTypeDef naming convention, alias kept).
 */
typedef struct
{
    uint32 ADC_TempSamplePoint;               /*!< Temperature sampling points (ADC_ALG_MEAN_x) */
    uint32 ADC_TempSensorOffset;   /*!< Temperature sensor offset adjustment
                                              (ADC_ADJ_TD_OS_x) */
    uint32 ADC_TempSensorGain;   /*!< Temperature sensor gain adjustment
                                              (ADC_ADJ_TD_GA_x) */
    FunctionalState TempSensorEn;   /*!< Enable/disable temperature sensor
                                              (ENABLE/DISABLE) */
} ADC_TempSensorConfTypeDef;

/* Device layer compatible alias: the device layer structure was ADC_TempTypeDef */
typedef ADC_TempSensorConfTypeDef ADC_TempTypeDef;

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @addtogroup ADC_Exported_Constants ADC Exported Constants
  * @{
  */

/** @defgroup ADC_BuiltIn_Reference_Temperature_Ratio ADC Built-in Reference Temperature Ratio
  * @note  Values are the ADC_CONFIG.TTRIM field encodings (device field names kept).
  * @{
  */
#define ADC_TTRIM_0                         0x00000000U  /*!< Built-In reference voltage temperature ratio control 0 */
#define ADC_TTRIM_1                         0x00000001U  /*!< Built-In reference voltage temperature ratio control 1 */
#define ADC_TTRIM_2                         0x00000002U  /*!< Built-In reference voltage temperature ratio control 2 */
#define ADC_TTRIM_3                         0x00000003U  /*!< Built-In reference voltage temperature ratio control 3 */
#define ADC_TTRIM_4                         0x00000004U  /*!< Built-In reference voltage temperature ratio control 4 */
#define ADC_TTRIM_5                         0x00000005U  /*!< Built-In reference voltage temperature ratio control 5 */
#define ADC_TTRIM_6                         0x00000006U  /*!< Built-In reference voltage temperature ratio control 6 */
#define ADC_TTRIM_7                         0x00000007U  /*!< Built-In reference voltage temperature ratio control 7 */
#define ADC_TTRIM_8                         0x00000008U  /*!< Built-In reference voltage temperature ratio control 8 */
#define ADC_TTRIM_9                         0x00000009U  /*!< Built-In reference voltage temperature ratio control 9 */
#define ADC_TTRIM_10                        0x0000000AU  /*!< Built-In reference voltage temperature ratio control 10 */
#define ADC_TTRIM_11                        0x0000000BU  /*!< Built-In reference voltage temperature ratio control 11 */
#define ADC_TTRIM_12                        0x0000000CU  /*!< Built-In reference voltage temperature ratio control 12 */
#define ADC_TTRIM_13                        0x0000000DU  /*!< Built-In reference voltage temperature ratio control 13 */
#define ADC_TTRIM_14                        0x0000000EU  /*!< Built-In reference voltage temperature ratio control 14 */
#define ADC_TTRIM_15                        0x0000000FU  /*!< Built-In reference voltage temperature ratio control 15 */
#define ADC_TTRIM_MAX                       0x00000010U  /*!< Invalid TTRIM */
/**
  * @}
  */

/** @defgroup ADC_BuiltIn_Reference_Voltage_Output ADC Built-in Reference Voltage Output
  * @note  Values are the ADC_CONFIG.VTRIM field encodings (device field names kept).
  * @{
  */
#define ADC_VTRIM_0                         0x00000000U  /*!< ADC Built-In reference voltage output control 0 */
#define ADC_VTRIM_1                         0x00000001U  /*!< ADC Built-In reference voltage output control 1 */
#define ADC_VTRIM_2                         0x00000002U  /*!< ADC Built-In reference voltage output control 2 */
#define ADC_VTRIM_3                         0x00000003U  /*!< ADC Built-In reference voltage output control 3 */
#define ADC_VTRIM_4                         0x00000004U  /*!< ADC Built-In reference voltage output control 4 */
#define ADC_VTRIM_5                         0x00000005U  /*!< ADC Built-In reference voltage output control 5 */
#define ADC_VTRIM_6                         0x00000006U  /*!< ADC Built-In reference voltage output control 6 */
#define ADC_VTRIM_7                         0x00000007U  /*!< ADC Built-In reference voltage output control 7 */
#define ADC_VTRIM_8                         0x00000008U  /*!< ADC Built-In reference voltage output control 8 */
#define ADC_VTRIM_9                         0x00000009U  /*!< ADC Built-In reference voltage output control 9 */
#define ADC_VTRIM_10                        0x0000000AU  /*!< ADC Built-In reference voltage output control 10 */
#define ADC_VTRIM_11                        0x0000000BU  /*!< ADC Built-In reference voltage output control 11 */
#define ADC_VTRIM_12                        0x0000000CU  /*!< ADC Built-In reference voltage output control 12 */
#define ADC_VTRIM_13                        0x0000000DU  /*!< ADC Built-In reference voltage output control 13 */
#define ADC_VTRIM_14                        0x0000000EU  /*!< ADC Built-In reference voltage output control 14 */
#define ADC_VTRIM_15                        0x0000000FU  /*!< ADC Built-In reference voltage output control 15 */
#define ADC_VTRIM_16                        0x00000010U  /*!< ADC Built-In reference voltage output control 16 */
#define ADC_VTRIM_17                        0x00000011U  /*!< ADC Built-In reference voltage output control 17 */
#define ADC_VTRIM_18                        0x00000012U  /*!< ADC Built-In reference voltage output control 18 */
#define ADC_VTRIM_19                        0x00000013U  /*!< ADC Built-In reference voltage output control 19 */
#define ADC_VTRIM_20                        0x00000014U  /*!< ADC Built-In reference voltage output control 20 */
#define ADC_VTRIM_21                        0x00000015U  /*!< ADC Built-In reference voltage output control 21 */
#define ADC_VTRIM_22                        0x00000016U  /*!< ADC Built-In reference voltage output control 22 */
#define ADC_VTRIM_23                        0x00000017U  /*!< ADC Built-In reference voltage output control 23 */
#define ADC_VTRIM_24                        0x00000018U  /*!< ADC Built-In reference voltage output control 24 */
#define ADC_VTRIM_25                        0x00000019U  /*!< ADC Built-In reference voltage output control 25 */
#define ADC_VTRIM_26                        0x0000001AU  /*!< ADC Built-In reference voltage output control 26 */
#define ADC_VTRIM_27                        0x0000001BU  /*!< ADC Built-In reference voltage output control 27 */
#define ADC_VTRIM_28                        0x0000001CU  /*!< ADC Built-In reference voltage output control 28 */
#define ADC_VTRIM_29                        0x0000001DU  /*!< ADC Built-In reference voltage output control 29 */
#define ADC_VTRIM_30                        0x0000001EU  /*!< ADC Built-In reference voltage output control 30 */
#define ADC_VTRIM_31                        0x0000001FU  /*!< ADC Built-In reference voltage output control 31 */
#define ADC_VTRIM_MAX                       0x00000020U  /*!< Invalid VTRIM */
/**
  * @}
  */

/** @defgroup ADC_BuiltIn_Reference_Output_Voltage ADC Built-in Reference Output Voltage
  * @note  Values are the ADC_CONFIG.SEL_VREFBI field encodings (device field names kept).
  * @{
  */
#define ADC_SEL_VREFBI_1V5                  0x00000000U  /*!< Built-in reference output 1.5V */
#define ADC_SEL_VREFBI_2V0                  0x00000001U  /*!< Built-in reference output 2.0V */
#define ADC_SEL_VREFBI_2V5                  0x00000002U  /*!< Built-in reference output 2.5V */
#define ADC_SEL_VREFBI_MAX                  0x00000004U  /*!< Invalid SEL_VREFBI */
/**
  * @}
  */

/** @defgroup ADC_Temperature_Sampling_Points ADC Temperature Sampling Points
  * @note  Values are the ADC_CONFIG.ALG_MEAN field encodings (device field names kept).
  * @{
  */
#define ADC_ALG_MEAN_32                     0x00000000U  /*!< Temperature sampling points 32  */
#define ADC_ALG_MEAN_64                     0x00000001U  /*!< Temperature sampling points 64  */
#define ADC_ALG_MEAN_128                    0x00000002U  /*!< Temperature sampling points 128 */
#define ADC_ALG_MEAN_256                    0x00000003U  /*!< Temperature sampling points 256 */
#define ADC_ALG_MEAN_MAX                    0x00000004U  /*!< Invalid sampling points */
/**
  * @}
  */

/** @defgroup ADC_Temperature_Sensor_Offset_Adjustment ADC Temperature Sensor Offset Adjustment
  * @note  Values are the ADC_CONFIG.ADJ_TD_OS field encodings (device field names kept).
  * @{
  */
#define ADC_ADJ_TD_OS_0                     0x00000000U  /*!< Temperature sensor offset adjustment 0 */
#define ADC_ADJ_TD_OS_1                     0x00000001U  /*!< Temperature sensor offset adjustment 1 */
#define ADC_ADJ_TD_OS_2                     0x00000002U  /*!< Temperature sensor offset adjustment 2 */
#define ADC_ADJ_TD_OS_3                     0x00000003U  /*!< Temperature sensor offset adjustment 3 */
#define ADC_ADJ_TD_OS_4                     0x00000004U  /*!< Temperature sensor offset adjustment 4 */
#define ADC_ADJ_TD_OS_5                     0x00000005U  /*!< Temperature sensor offset adjustment 5 */
#define ADC_ADJ_TD_OS_6                     0x00000006U  /*!< Temperature sensor offset adjustment 6 */
#define ADC_ADJ_TD_OS_7                     0x00000007U  /*!< Temperature sensor offset adjustment 7 */
#define ADC_ADJ_TD_OS_8                     0x00000008U  /*!< Temperature sensor offset adjustment 8 */
#define ADC_ADJ_TD_OS_9                     0x00000009U  /*!< Temperature sensor offset adjustment 9 */
#define ADC_ADJ_TD_OS_10                    0x0000000AU  /*!< Temperature sensor offset adjustment 10 */
#define ADC_ADJ_TD_OS_11                    0x0000000BU  /*!< Temperature sensor offset adjustment 11 */
#define ADC_ADJ_TD_OS_12                    0x0000000CU  /*!< Temperature sensor offset adjustment 12 */
#define ADC_ADJ_TD_OS_13                    0x0000000DU  /*!< Temperature sensor offset adjustment 13 */
#define ADC_ADJ_TD_OS_14                    0x0000000EU  /*!< Temperature sensor offset adjustment 14 */
#define ADC_ADJ_TD_OS_15                    0x0000000FU  /*!< Temperature sensor offset adjustment 15 */
#define ADC_ADJ_TD_OS_MAX                   0x00000010U  /*!< Invalid offset adjustment */
/**
  * @}
  */

/** @defgroup ADC_Temperature_Sensor_Gain_Adjustment ADC Temperature Sensor Gain Adjustment
  * @note  Values are the ADC_CONFIG.ADJ_TD_GA field encodings (device field names kept).
  * @{
  */
#define ADC_ADJ_TD_GA_0                     0x00000000U  /*!< Temperature sensor gain adjustment 0 */
#define ADC_ADJ_TD_GA_1                     0x00000001U  /*!< Temperature sensor gain adjustment 1 */
#define ADC_ADJ_TD_GA_2                     0x00000002U  /*!< Temperature sensor gain adjustment 2 */
#define ADC_ADJ_TD_GA_3                     0x00000003U  /*!< Temperature sensor gain adjustment 3 */
#define ADC_ADJ_TD_GA_4                     0x00000004U  /*!< Temperature sensor gain adjustment 4 */
#define ADC_ADJ_TD_GA_5                     0x00000005U  /*!< Temperature sensor gain adjustment 5 */
#define ADC_ADJ_TD_GA_6                     0x00000006U  /*!< Temperature sensor gain adjustment 6 */
#define ADC_ADJ_TD_GA_7                     0x00000007U  /*!< Temperature sensor gain adjustment 7 */
#define ADC_ADJ_TD_GA_8                     0x00000008U  /*!< Temperature sensor gain adjustment 8 */
#define ADC_ADJ_TD_GA_9                     0x00000009U  /*!< Temperature sensor gain adjustment 9 */
#define ADC_ADJ_TD_GA_10                    0x0000000AU  /*!< Temperature sensor gain adjustment 10 */
#define ADC_ADJ_TD_GA_11                    0x0000000BU  /*!< Temperature sensor gain adjustment 11 */
#define ADC_ADJ_TD_GA_12                    0x0000000CU  /*!< Temperature sensor gain adjustment 12 */
#define ADC_ADJ_TD_GA_13                    0x0000000DU  /*!< Temperature sensor gain adjustment 13 */
#define ADC_ADJ_TD_GA_14                    0x0000000EU  /*!< Temperature sensor gain adjustment 14 */
#define ADC_ADJ_TD_GA_15                    0x0000000FU  /*!< Temperature sensor gain adjustment 15 */
#define ADC_ADJ_TD_GA_MAX                   0x00000010U  /*!< Invalid gain adjustment */
/**
  * @}
  */

/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/

/** @addtogroup ADC_Exported_Functions ADC Exported Functions
  * @{
  */

/** @addtogroup ADC_Exported_Functions_Group1 Injected group operation functions
  * @{
  */

/**
 * @brief  Start a software triggered injection group conversion. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_ADC_InjectedStart(ADC_HandleTypeDef *hadc);

/**
 * @brief  Get the injection group conversion result of the selected rank. (NON-BLOCKING)
 * @note   Provides ADC_GetSeqResult() for the injected group: the data
 *         is returned through the Result pointer and the function returns
 *         the channel number that produced the data.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  Rank: injected rank (ADC_ISEQ_0..3).
 * @param  Result: pointer to the variable that will receive the conversion
 *         data.
 * @retval uint16: the channel number of the conversion (0..20).
 */
uint16 HAL_ADC_InjectedGetValue(ADC_HandleTypeDef *hadc, uint32 Rank, uint16 *Result);

/**
 * @brief  Set the injection group offset value of the selected rank. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  Rank: injected rank (ADC_ISEQ_0..3).
 * @param  Offset: offset value, subtracted from the converted data, must be
 *         less than 0x1000.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_ADC_InjectedSetOffset(ADC_HandleTypeDef *hadc, uint32 Rank, uint16 Offset);

/**
 * @brief  Get the injection group offset value of the selected rank. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  Rank: injected rank (ADC_ISEQ_0..3).
 * @retval uint16: the offset value.
 */
uint16 HAL_ADC_InjectedGetOffset(ADC_HandleTypeDef *hadc, uint32 Rank);
/**
  * @}
  */

/** @addtogroup ADC_Exported_Functions_Group2 Analog monitor functions
  * @{
  */

/**
 * @brief  Initialize the ADC analog monitor configuration structure with (NON-BLOCKING)
 *         default values.
 * @param  pAmoConf: pointer to an ADC_AmoConfTypeDef structure that will be
 *         filled with the default configuration.
 * @retval None
 */
void HAL_ADC_AMOStructInit(ADC_AmoConfTypeDef *pAmoConf);

/**
 * @brief  Configure the ADC analog monitor (AMO) according to the specified (NON-BLOCKING)
 *         parameters in the pAmoConf structure.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  pAmoConf: pointer to an ADC_AmoConfTypeDef structure that contains
 *         the configuration information for the analog monitor.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_ADC_ConfigAnalogMonitor(ADC_HandleTypeDef *hadc,
                                                ADC_AmoConfTypeDef *pAmoConf);

/**
 * @brief  Get the configuration of the analog monitor from the registers. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  pAmoConf: pointer to an ADC_AmoConfTypeDef structure that will be
 *         filled with the current register configuration.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_ADC_GetAnalogMonitorConfig(ADC_HandleTypeDef *hadc,
                                                   ADC_AmoConfTypeDef *pAmoConf);
/**
  * @}
  */

/** @addtogroup ADC_Exported_Functions_Group3 Temperature sensor functions
  * @{
  */

/**
 * @brief  Initialize the ADC temperature sensor configuration structure with (NON-BLOCKING)
 *         default values.
 * @param  pTempConf: pointer to an ADC_TempSensorConfTypeDef structure that
 *         will be filled with the default configuration.
 * @retval None
 */
void HAL_ADC_TempStructInit(ADC_TempSensorConfTypeDef *pTempConf);

/**
 * @brief  Configure the ADC temperature sensor (gain, offset, sampling (NON-BLOCKING)
 *         points, enable) according to the specified parameters.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  pTempConf: pointer to an ADC_TempSensorConfTypeDef structure that
 *         contains the configuration information for the temperature sensor.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_ADC_ConfigTemperatureSensor(ADC_HandleTypeDef *hadc,
                                                    ADC_TempSensorConfTypeDef *pTempConf);

/**
 * @brief  Get the configuration of the temperature sensor from the registers. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  pTempConf: pointer to an ADC_TempSensorConfTypeDef structure that
 *         will be filled with the current register configuration.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_ADC_GetTemperatureSensorConfig(ADC_HandleTypeDef *hadc,
                                                       ADC_TempSensorConfTypeDef *pTempConf);

/**
 * @brief  Get the temperature sensor enable flag. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval FlagStatus: SET or RESET.
 */
FlagStatus HAL_ADC_GetTemperatureSensorStatus(ADC_HandleTypeDef *hadc);

/**
 * @brief  Clear the temperature sensor enable flag. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance or the handle is not initialized)
 */
HAL_StatusTypeDef HAL_ADC_ClearTemperatureSensorStatus(ADC_HandleTypeDef *hadc);
/**
  * @}
  */

/** @addtogroup ADC_Exported_Functions_Group4 Extended status functions
  * @{
  */

/**
 * @brief  Get the external reference input buffer enable flag. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval FlagStatus: SET or RESET.
 */
FlagStatus HAL_ADC_GetBufferStatus(ADC_HandleTypeDef *hadc);

/**
 * @brief  Clear the external reference input buffer enable flag. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance or the handle is not initialized)
 */
HAL_StatusTypeDef HAL_ADC_ClearBufferStatus(ADC_HandleTypeDef *hadc);

/**
 * @brief  Set the high-resistance state flag (ADC_CONFIG.EN_HIZ bit). (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance or the handle is not initialized)
 */
HAL_StatusTypeDef HAL_ADC_SetHighResStatus(ADC_HandleTypeDef *hadc);

/**
 * @brief  Get the high-resistance state flag. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval FlagStatus: SET or RESET.
 */
FlagStatus HAL_ADC_GetHighResStatus(ADC_HandleTypeDef *hadc);

/**
 * @brief  Clear the high-resistance state flag. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance or the handle is not initialized)
 */
HAL_StatusTypeDef HAL_ADC_ClearHighResStatus(ADC_HandleTypeDef *hadc);

/**
 * @brief  Get the ADC regular group data even parity of the selected rank.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  Rank: regular rank (ADC_RSEQ_0..15).
 * @retval uint8: the even parity value of the conversion data.
 */
uint8 HAL_ADC_GetRegularParity(ADC_HandleTypeDef *hadc, uint32 Rank);

/**
 * @brief  Get the ADC regular group channel number of the selected rank.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  Rank: regular rank (ADC_RSEQ_0..15).
 * @retval uint8: the channel number of the conversion.
 */
uint8 HAL_ADC_GetRegularChannel(ADC_HandleTypeDef *hadc, uint32 Rank);

/**
 * @brief  Get the ADC injected group data even parity of the selected rank.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  Rank: injected rank (ADC_ISEQ_0..3).
 * @retval uint8: the even parity value of the conversion data.
 */
uint8 HAL_ADC_GetInjectParity(ADC_HandleTypeDef *hadc, uint32 Rank);

/**
 * @brief  Get the ADC injected group channel number of the selected rank.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  Rank: injected rank (ADC_ISEQ_0..3).
 * @retval uint8: the channel number of the conversion.
 */
uint8 HAL_ADC_GetInjectChannel(ADC_HandleTypeDef *hadc, uint32 Rank);

/**
 * @brief  Get the conversion result of the selected sequence rank and the (NON-BLOCKING)
 *         channel number that produced it.
 * @note   Provides ADC_GetSeqResult() for both groups: the data is
 *         returned through the Result pointer and the function returns the
 *         channel number. Unlike HAL_ADC_GetValue(), the rank is explicit
 *         and the current rank index of the handle is not modified.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  Rank: sequence rank (ADC_RSEQ_0..15 / ADC_ISEQ_0..3).
 * @param  Result: pointer to the variable that will receive the conversion
 *         data.
 * @retval uint16: the channel number of the conversion (0..20).
 */
uint16 HAL_ADC_GetSeqResult(ADC_HandleTypeDef *hadc, uint32 Rank, uint16 *Result);

/**
 * @brief  Get the average value of the ADC conversion result of the assigned
 *         sequence rank. (BLOCKING)
 * @note   The call takes the resource lock and rejects a busy handle with 0.0F
 *         (HAL_BUSY) and a handle that has not been initialized with 0.0F
 *         (HAL_ERROR), see ADC_CheckState().
 * @note   Each of the Count conversions is waited for with the private budget
 *         ADC_AVERAGE_SAMPLE_TIMEOUT_MS, and the wait yields the CPU in an RTOS
 *         build (RTOS-04), so a conversion that never completes cannot hang the
 *         caller. The EOC flag is cleared after every conversion so that a
 *         consecutive conversion does not read stale data.
 * @note   The average is computed over the collected samples; when the call
 *         times out it returns the average of the samples received so far. The
 *         float return has no status channel, so the outcome is reported through
 *         HAL_ADC_GetError() (HAL_ADC_ERROR_TIMEOUT / HAL_ADC_ERROR_INVALID_PARAM)
 *         and the HAL_ADC_STATE_TIMEOUT state bit.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  Rank: sequence rank (ADC_RSEQ_0..15 / ADC_ISEQ_0..3).
 * @param  Count: number of conversions used for the average (must be greater
 *         than 0).
 * @retval float: the averaged conversion result, or 0.0F when the handle,
 *         the rank or the count is rejected.
 */
float HAL_ADC_GetAverageValue(ADC_HandleTypeDef *hadc, uint32 Rank, uint32 Count);

/**
 * @brief  Convert the ADC value of the internal temperature sensor to a
 *         temperature. (NON-BLOCKING)
 * @note   Pure computation: no handle, no lock, no register access, callable
 *         from any context.
 * @note   An invalid input (Value greater than 4095, or a reference voltage
 *         that is zero, negative, NaN or not finite) is rejected with 0.0F.
 *         The return value has no status channel, so an invalid input and a
 *         legitimate 0.0 degrees centigrade are not distinguishable; the
 *         caller validates its own inputs when that distinction matters.
 * @param  Value: ADC conversion result of the internal temperature sensor
 *         (0..4095).
 * @param  RefVoltage: reference voltage of the ADC, in mV (must be positive
 *         and finite).
 * @retval float: the temperature value in Celsius scale, or 0.0F for an
 *         invalid input.
 */
float HAL_ADC_ConvertToTemperature(uint16 Value, float RefVoltage);

/**
 * @brief  Injected conversion complete callback.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval None
 */
void HAL_ADC_InjectedConvCpltCallback(ADC_HandleTypeDef *hadc);
/**
  * @}
  */

/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/

/** @addtogroup ADC_Private_Macros ADC Private Macros
  * @{
  */

#define IS_ADC_TTRIM(TTRIM)               ((TTRIM) < ADC_TTRIM_MAX)
#define IS_ADC_VTRIM(VTRIM)               ((VTRIM) < ADC_VTRIM_MAX)
#define IS_ADC_SELVREFBI(SELVREFBI)       (((SELVREFBI) == ADC_SEL_VREFBI_1V5) || \
                                           ((SELVREFBI) == ADC_SEL_VREFBI_2V0) || \
                                           ((SELVREFBI) == ADC_SEL_VREFBI_2V5))
#define IS_ADC_ALGMEAN(ALGMEAN)           ((ALGMEAN) < ADC_ALG_MEAN_MAX)
#define IS_ADC_ADJTDOS(ADJTDOS)           ((ADJTDOS) < ADC_ADJ_TD_OS_MAX)
#define IS_ADC_ADJTDGA(ADJTDGA)           ((ADJTDGA) < ADC_ADJ_TD_GA_MAX)
#define IS_ADC_AMO_THRESHOLD(THRESHOLD)   ((THRESHOLD) <= 0x0FFFU)

/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/

/** @defgroup ADC_Private_Macros ADC Private Macros
  * @{
  */

#define IS_ADC_ALL_INSTANCE(INSTANCE)     (((INSTANCE) == ADC0) || \
                                           ((INSTANCE) == ADC1))

#define IS_ADC_CLK_DIVIDE(CLKDIVIDE)      (((CLKDIVIDE) == ADC_CLK_DIVIDE_1) || \
                                           ((CLKDIVIDE) == ADC_CLK_DIVIDE_2) || \
                                           ((CLKDIVIDE) == ADC_CLK_DIVIDE_4) || \
                                           ((CLKDIVIDE) == ADC_CLK_DIVIDE_6) || \
                                           ((CLKDIVIDE) == ADC_CLK_DIVIDE_8) || \
                                           ((CLKDIVIDE) == ADC_CLK_DIVIDE_10) || \
                                           ((CLKDIVIDE) == ADC_CLK_DIVIDE_12) || \
                                           ((CLKDIVIDE) == ADC_CLK_DIVIDE_14))

#define IS_ADC_RESOLUTION(RESOLUTION)     (((RESOLUTION) == ADC_RESOLUTION_12BIT) || \
                                           ((RESOLUTION) == ADC_RESOLUTION_10BIT) || \
                                           ((RESOLUTION) == ADC_RESOLUTION_8BIT) || \
                                           ((RESOLUTION) == ADC_RESOLUTION_6BIT))

#define IS_ADC_ALIGN(ALIGN)               (((ALIGN) == ADC_DATA_ALIGN_RIGHT) || \
                                           ((ALIGN) == ADC_DATA_ALIGN_LEFT))

#define IS_ADC_SELDO(SELDO)               (((SELDO) == ADC_DATA_SELDO_UNSIGNED) || \
                                           ((SELDO) == ADC_DATA_SELDO_SIGNED))

#define IS_ADC_TRIGGER(TRIGGER)           (((TRIGGER) == ADC_TRIGGER_INTERNAL) || \
                                           ((TRIGGER) == ADC_TRIGGER_EXTERNAL_0) || \
                                           ((TRIGGER) == ADC_TRIGGER_EXTERNAL_1) || \
                                           ((TRIGGER) == ADC_TRIGGER_EXTERNAL_2))

#define IS_ADC_SELVIHDLS(SELVIHDLS)       (((SELVIHDLS) == ADC_SAR_INPUT_SINGLE_ENDED) || \
                                           ((SELVIHDLS) == ADC_SAR_INPUT_DIFFERENTIAL))

/* The built-in reference voltage check macros IS_ADC_TTRIM / IS_ADC_VTRIM /
    IS_ADC_SELVREFBI are defined above. */

#define IS_ADC_INPUT_CH(CHANNEL)          ((CHANNEL) <= ADC_CH_VR_EX_3)

#define IS_ADC_SAMPLE_TIME(SAMPLETIME)    ((SAMPLETIME) <= ADC_SPT_CLK_640)

#define IS_ADC_SEQUENCE(SEQUENCE)         ((SEQUENCE) < ADC_SEQ_MAX)

#define IS_ADC_REGULAR_RANK(RANK)         ((RANK) <= ADC_RSEQ_15)

#define IS_ADC_INJECT_RANK(RANK)          (((RANK) >= ADC_ISEQ_0) && \
                                           ((RANK) < ADC_SEQ_MAX))

#define IS_ADC_GET_FLAG(FLAG)             (((FLAG) == ADC_FLAG_CONVCFT) || \
                                           ((FLAG) == ADC_FLAG_IDLE) || \
                                           ((FLAG) == ADC_FLAG_AMO) || \
                                           ((FLAG) == ADC_FLAG_EOC))

#define IS_ADC_CLEAR_FLAG(FLAG)           (((FLAG) == ADC_FLAG_CONVCFT) || \
                                           ((FLAG) == ADC_FLAG_AMO) || \
                                           ((FLAG) == ADC_FLAG_EOC))

/* Compatibility alias: IS_ADC_BitAction is the spelling used by the device
    layer initialization routine (it is an alias of the library wide
    IS_FUNCTIONAL_STATE macro). */
#define IS_ADC_BitAction                  IS_FUNCTIONAL_STATE

/**
  * @}
  */

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_ADC_H */

/*****END OF FILE*****/
