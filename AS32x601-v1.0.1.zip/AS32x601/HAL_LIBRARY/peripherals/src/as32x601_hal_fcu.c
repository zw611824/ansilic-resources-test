/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_fcu.c
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.5
 * Date:   2026/11/02
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/11     1.1     fix the polarity of the FCU reset bit
 *                                                       in HAL_FCU_MspInit (the reset is
 *                                                       released by setting the bit, not by
 *                                                       clearing it)
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.2     apply the resource lock / RTOS rules:
 *                                                       run the MSP callbacks outside the
 *                                                       locked region, add a Timeout and a
 *                                                       NULL-mutex guard to the lock helper,
 *                                                       add the busy / reset state gate,
 *                                                       return HAL_StatusTypeDef from the
 *                                                       seven register writing interfaces
 *                                                       with run-time parameter validation,
 *                                                       and keep the four status clear
 *                                                       interfaces lock free so that they
 *                                                       stay callable from the FCU interrupt
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.3     align the blocking annotations with
 *                                                       the header (five were missing in this
 *                                                       file), clear the error code at the
 *                                                       entry of the three register writing
 *                                                       interfaces, and drop the always-true
 *                                                       uint8 count range check that made the
 *                                                       compiler report a -Wtype-limits
 *                                                       warning
 *     ANSILIC APPLICATION GROUP  2026/10/09     1.4     merge the capabilities of the Error
 *                                                       Handling release of 2026/09/30 into
 *                                                       this driver: add the per channel
 *                                                       run-time setters HAL_FCU_SetLevel /
 *                                                       SetFaultAction / SetAlarmAction, add
 *                                                       the interrupt dispatch entry
 *                                                       HAL_FCU_IRQHandler() with the weak
 *                                                       HAL_FCU_FaultCallback() /
 *                                                       HAL_FCU_AlarmCallback(), reset all
 *                                                       the 42 channels in HAL_FCU_DeInit()
 *                                                       and clear the channel status latch
 *                                                       together with the software fault in
 *                                                       HAL_FCU_ClearSoftwareFault().
 *                                                       HAL_FCU_Cmd() keeps the channel
 *                                                       mask untouched, so a channel
 *                                                       configured as masked stays silent
 *                                                       while it is enabled
 *     ANSILIC APPLICATION GROUP  2026/11/02     1.5     absorb the Error Handling release of
 *                                                       2026/10/10: the channel mask now
 *                                                       drives the enable bit as well, the
 *                                                       software fault trigger threshold is
 *                                                       programmed from
 *                                                       Init.SoftwareTriggerCount, the clear
 *                                                       registers are written directly, the
 *                                                       clear family masks the channel around
 *                                                       the clear and reports a surviving
 *                                                       latch through
 *                                                       HAL_FCU_ERROR_CLEAR_FAILED, the
 *                                                       software trigger latch is read back
 *                                                       in HAL_FCU_ClearSoftwareFault(), and
 *                                                       the new
 *                                                       HAL_FCU_ClearCategoryFaultStatus()
 *                                                       clears a whole fault source category
 *                                                       through the mask pair it is given.
 *                                                       The SFCNT programming is shared with
 *                                                       HAL_FCU_SetSoftwareFaultCount()
 *                                                       through the private
 *                                                       FCU_SetSoftwareCount() helper, and
 *                                                       the latch clearing of both public
 *                                                       clear interfaces through
 *                                                       FCU_ClearLatches()
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Fault Collection Unit
 *                  (FCU) of the AS32x601:
 *                  - Initialization and de-initialization;
 *                  - Peripheral control: channel enable / disable,
 *                    software fault trigger / count / clear;
 *                  - Fault and alarm management: software fault status,
 *                    channel alarm / fault status query and clear, bus
 *                    timeout / ECC fault clear;
 *                  - State and error reporting.
 *
 *                  Typical usage of the FCU:
 *                  (#) Fill the FCU_InitTypeDef with HAL_FCU_StructInit(),
 *                      set the Channel and the fault / alarm configuration
 *                      (MaskEnable = FCU_DISABLE selects an unmasked channel,
 *                      which HAL_FCU_Init() enables), then call
 *                      HAL_FCU_Init() with the handle;
 *                  (#) Enable a channel that was configured as masked with
 *                      HAL_FCU_Cmd(FCU_ENABLE);
 *                  (#) In the FCU interrupt service routine (FCU_IRQn,
 *                      enabled through the PLIC), read the alarm / fault
 *                      status with HAL_FCU_GetAlarmStatus() /
 *                      HAL_FCU_GetFaultStatus() and clear them with
 *                      HAL_FCU_ClearFcuStatus() (or clear a whole fault
 *                      source category with
 *                      HAL_FCU_ClearCategoryFaultStatus() and one of the
 *                      published FCU_CATEGORY_CLEAR_xxx masks);
 *                  (#) Optionally use the software fault channels
 *                      (HAL_FCU_SetSoftwareTrigger / ... ) for test
 *                      purposes.
 */
#include "as32x601_hal.h"          /* HAL_GetTick() / HAL_MAX_DELAY            */
#include "as32x601_hal_fcu.h"            /* FCU HAL API and register macros    */

/* The HAL_FCU_MODULE_ENABLED switch is provided by the user configuration
 * file (as32x601_hal_conf.h, included above through as32x601_hal.h): the
 * whole implementation is compiled only while the module is enabled. */
#ifdef HAL_FCU_MODULE_ENABLED

/* Private define ------------------------------------------------------------*/

/**
 * @brief  Number of channel bits carried by one status (alarm / fault) or
 *         clear register: channels 0..31 live in the register pair member 0,
 *         channels 32..41 in member 1.
 */
#define FCU_STATUS_REGISTER_WIDTH   32U

/**
 * @brief  Bits of the CLEAR1 register which own a channel: channels 32..41
 *         occupy bits 0..9, the bits above them are reserved and must not be
 *         selected by a category mask.
 */
#define FCU_CLEAR1_CHANNEL_MASK     ((uint32)0x000003FFU)

/**
 * @brief  Number of software fault channels of the FCU (SFTR / SFSTA / SFCLR
 *         carry one bit and SFCNT one field per channel).
 */
#define FCU_SOFTWARE_CHANNEL_COUNT  4U

/**
 * @brief  Width of one software fault count field of the SFCNT register, in
 *         bits. It is derived from the device layer positions, so that a
 *         device layer change cannot silently desynchronize the mapping.
 */
#define FCU_SOFTWARE_COUNT_STRIDE   ((uint32)(FCU_SFCNT_CNT1_Pos - FCU_SFCNT_CNT0_Pos))

/* Private function prototypes -----------------------------------------------*/
static uint32 FCU_HandleIsValid(HAL_FCU_HandleTypeDef *hfcu);
static HAL_StatusTypeDef FCU_CheckState(HAL_FCU_HandleTypeDef *hfcu);
static void FCU_SetSoftwareCount(HAL_FCU_HandleTypeDef *hfcu, uint32 Channel, uint32 Count);
static HAL_StatusTypeDef FCU_ClearLatches(HAL_FCU_HandleTypeDef *hfcu, uint32 Mask0, uint32 Mask1);

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Check whether the FCU handle and its instance are valid.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
static uint32 FCU_HandleIsValid(HAL_FCU_HandleTypeDef *hfcu)
{
    if (hfcu == NULL_PTR)
    {
        return 0U;
    }

    if (IS_FCU_ALL_INSTANCE(hfcu->Instance) == 0U)
    {
        return 0U;
    }

    return 1U;
}

/**
 * @brief  Check whether the handle accepts a new operation.
 * @note   Architecture constraint ARCH-CONST-09: a handle that is BUSY (an
 *         operation is ongoing in another context) rejects any other operation
 *         with HAL_BUSY, and a handle that is not initialized (RESET) requires
 *         HAL_FCU_Init() first and is rejected with HAL_ERROR. The recoverable
 *         state ERROR accepts a new operation directly (the entry point of the
 *         operation programs the register again, so that no DeInit / Init
 *         round trip is required).
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK (accepted) / HAL_BUSY / HAL_ERROR.
 */
static HAL_StatusTypeDef FCU_CheckState(HAL_FCU_HandleTypeDef *hfcu)
{
    if (hfcu->State == HAL_FCU_STATE_BUSY)
    {
        return HAL_BUSY;
    }

    if (hfcu->State == HAL_FCU_STATE_RESET)
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Program the software fault count (trigger threshold) of one software
 *         fault channel.
 * @note   The SFCNT register carries one 8 bit field per software fault
 *         channel, at the stride derived from the device layer
 *         (FCU_SFCNT_CNTx_Pos); the fields of the other channels are preserved,
 *         so the helper may be called for one channel at a time.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  Channel: the FCU channel (HAL_FCU_CHANNEL_SOFTWARE0..SOFTWARE3).
 * @param  Count: the count value (the caller validated the 0..0xFF range).
 * @retval None
 */
static void FCU_SetSoftwareCount(HAL_FCU_HandleTypeDef *hfcu, uint32 Channel, uint32 Count)
{
    uint32 shift = ((Channel - (uint32)HAL_FCU_CHANNEL_SOFTWARE0) * FCU_SOFTWARE_COUNT_STRIDE);

    MODIFY_REG(hfcu->Instance->SFCNT, (uint32)(0xFFUL << shift),
               (uint32)((Count & 0xFFU) << shift));
}

/**
 * @brief  Clear the alarm / fault latches selected by a mask pair.
 * @note   The clear registers are write-one-to-clear, so the target masks are
 *         written directly: they are never read back and rewritten, which
 *         would also drop the statuses that are not selected by the mask
 *         whenever the value read back carries them.
 * @note   Every selected channel is masked for the duration of the clear (so
 *         that its source cannot latch the status again in between) and the
 *         channels that were unmasked before are unmasked again afterwards.
 *         The sequence is a read-modify-write of the shared configuration
 *         registers, so it runs inside a short critical section; the interface
 *         itself takes no task lock, so that it stays callable from the FCU
 *         interrupt service routine (LOCK-04 / RTOS-12).
 * @note   The latches are read back before the mask is restored: a status that
 *         survives the clear means that the underlying fault source is still
 *         active, which is reported through HAL_FCU_ERROR_CLEAR_FAILED.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  Mask0: channels 0..31 to clear (bit n selects channel n).
 * @param  Mask1: channels 32..41 to clear (bit n selects channel 32 + n).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (a latch survived the clear).
 */
static HAL_StatusTypeDef FCU_ClearLatches(HAL_FCU_HandleTypeDef *hfcu, uint32 Mask0, uint32 Mask1)
{
    uint32 index = 0U;
    uint32 unmasked0 = 0U;
    uint32 unmasked1 = 0U;
    uint32 stillSet = 0U;
    uint32 irqState = 0U;

    /* Serialize the mask sequence of the shared configuration registers */
    irqState = __disable_irq_and_save();

    /* Remember which selected channels were unmasked, then mask all of them */
    for (index = 0U; index < FCU_STATUS_REGISTER_WIDTH; index++)
    {
        if ((Mask0 & (1UL << index)) != 0U)
        {
            if ((hfcu->Instance->CFG[index] & (uint32)FCU_CFG_MASK_Msk) == 0U)
            {
                unmasked0 |= (uint32)(1UL << index);
            }
            SET_BIT(hfcu->Instance->CFG[index], FCU_CFG_MASK_Msk);
        }
    }

    for (index = 0U; (index + FCU_STATUS_REGISTER_WIDTH) < HAL_FCU_CHANNEL_COUNT; index++)
    {
        if ((Mask1 & (1UL << index)) != 0U)
        {
            if ((hfcu->Instance->CFG[index + FCU_STATUS_REGISTER_WIDTH] &
                 (uint32)FCU_CFG_MASK_Msk) == 0U)
            {
                unmasked1 |= (uint32)(1UL << index);
            }
            SET_BIT(hfcu->Instance->CFG[index + FCU_STATUS_REGISTER_WIDTH], FCU_CFG_MASK_Msk);
        }
    }

    /* Write-one-to-clear: the target masks are written directly */
    if (Mask0 != 0U)
    {
        hfcu->Instance->CLEAR0 = Mask0;
    }

    if (Mask1 != 0U)
    {
        hfcu->Instance->CLEAR1 = Mask1;
    }

    /* A latch that survives the clear means that the source is still active */
    stillSet = (((hfcu->Instance->FAULT0 | hfcu->Instance->ALARM0) & Mask0) |
                ((hfcu->Instance->FAULT1 | hfcu->Instance->ALARM1) & Mask1));

    if (stillSet != 0U)
    {
        hfcu->ErrorCode |= HAL_FCU_ERROR_CLEAR_FAILED;
        hfcu->State = HAL_FCU_STATE_ERROR;
    }

    /* Restore the mask configuration of the channels that were unmasked */
    for (index = 0U; index < FCU_STATUS_REGISTER_WIDTH; index++)
    {
        if ((unmasked0 & (1UL << index)) != 0U)
        {
            CLEAR_BIT(hfcu->Instance->CFG[index], FCU_CFG_MASK_Msk);
        }
    }

    for (index = 0U; (index + FCU_STATUS_REGISTER_WIDTH) < HAL_FCU_CHANNEL_COUNT; index++)
    {
        if ((unmasked1 & (1UL << index)) != 0U)
        {
            CLEAR_BIT(hfcu->Instance->CFG[index + FCU_STATUS_REGISTER_WIDTH], FCU_CFG_MASK_Msk);
        }
    }

    __restore_irq(irqState);

    if (stillSet != 0U)
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_FCU_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; when the mutex is not acquired before the
 *         Timeout expires, HAL_TIMEOUT is returned. The value is passed to
 *         HAL_MutexAcquire() as is (RTOS ticks; with the usual 1 ms tick it is
 *         the same quantity as the millisecond Timeout of the public API, and
 *         HAL_MAX_DELAY means an infinite wait).
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef FCU_LockHandle(HAL_FCU_HandleTypeDef *hfcu, uint32 Timeout)
{
#if (USE_RTOS == 1)
    if (hfcu->LockMutex == NULL_PTR)
    {
        /* The porting layer did not create the mutex (e.g. HAL_FCU_MspInit()
         * was not overridden): report it instead of calling the RTOS with a
         * NULL handle */
        return HAL_ERROR;
    }

    return HAL_MutexAcquire(hfcu->LockMutex, Timeout);
#else
    /* Prevent unused argument compilation warning: the bare-metal lock flag
     * either succeeds immediately or reports HAL_BUSY, it never waits */
    UNUSED(Timeout);

    if (hfcu->Lock == HAL_LOCKED)
    {
        return HAL_BUSY;
    }

    hfcu->Lock = HAL_LOCKED;

    return HAL_OK;
#endif /* USE_RTOS */
}

/**
 * @brief  Unlock the handle.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @retval None
 */
void FCU_UnlockHandle(HAL_FCU_HandleTypeDef *hfcu)
{
#if (USE_RTOS == 1)
    (void)HAL_MutexRelease(hfcu->LockMutex);
#else
    hfcu->Lock = HAL_UNLOCKED;
#endif /* USE_RTOS */
}

/* Exported functions ---------------------------------------------------------*/

/** @addtogroup FCU_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Fills each FCU_InitStruct member with its default value. (NON-BLOCKING)
 * @note   The default channel is EXTENDFAULT1, the fault action is the
 *         global software reset, the alarm action is none, the fault level
 *         is invalid, the mask is requested (the default channel is therefore
 *         masked, so it stays silent until MaskEnable is set to FCU_DISABLE)
 *         and the software trigger threshold is 0 (one trigger reports).
 * @param  FCU_InitStruct: pointer to a FCU_InitTypeDef structure which
 *         will be initialized.
 * @retval None
 */
void HAL_FCU_StructInit(FCU_InitTypeDef *FCU_InitStruct)
{
    if (FCU_InitStruct == NULL_PTR)
    {
        return;
    }

    FCU_InitStruct->Size               = (uint32)sizeof(FCU_InitTypeDef);   /*!< Data structure
                                                                           size */
    FCU_InitStruct->Version            = FCU_INIT_VERSION;   /*!< Data structure
                                                                           version */
    FCU_InitStruct->Channel            = HAL_FCU_CHANNEL_EXTENDFAULT1; /*!< Default channel       */
    FCU_InitStruct->FaultToResetCount  = 0U;        /*!< Count to reset under FOCU  */
    FCU_InitStruct->AlarmToFaultCount  = 0U;        /*!< Count to change alarm to fault */
    FCU_InitStruct->FaultAction        = HAL_FCU_FAULT_GLOBAL_SOFTWARE_RESET;   /*!< Fault action:
                                                                              reset */
    FCU_InitStruct->AlarmAction        = HAL_FCU_ALARM_NONE;  /*!< Alarm action: none          */
    FCU_InitStruct->FaultLevel         = HAL_FCU_FAULT_LEVEL_INVALID;   /*!< Fault level: invalid
                                                                       */
    FCU_InitStruct->MaskEnable         = 1U;         /*!< Channel mask enabled       */
    FCU_InitStruct->SoftwareTriggerCount = 0U;       /*!< One software trigger reports */
    FCU_InitStruct->Reserved           = 0U;         /*!< Reserved for future extension */
}

/**
 * @brief  Initializes the FCU channel according to the specified parameters (NON-BLOCKING)
 *         in the FCU_InitStruct of the handle.
 * @note   The FCU clock gating is enabled by the default HAL_FCU_MspInit()
 *         through the SMU_ALB0CFGR register; the user may override it.
 * @note   The mask field drives the enable bit as well: with
 *         MaskEnable = FCU_ENABLE the channel is masked and its enable bit is
 *         left untouched (a channel that was enabled before stays enabled but
 *         silent), while with MaskEnable = FCU_DISABLE the channel is
 *         unmasked and enabled by this call, so that HAL_FCU_Cmd() is only
 *         needed for the channels that are initialized as masked.
 * @note   When the configured channel is a software fault channel
 *         (SOFTWARE0..SOFTWARE3), Init.SoftwareTriggerCount is programmed into
 *         the matching field of SFCNT before the channel is configured.
 * @note   The parameters and the configuration structure metafields (Size /
 *         Version) are validated at run time: an invalid configuration is
 *         rejected with HAL_ERROR and HAL_FCU_ERROR_INVALID_PARAM without
 *         taking the lock and without changing the handle state.
 * @note   LOCK-06: the low level initialization (HAL_FCU_MspInit()) runs
 *         before the handle is locked, so that an override which calls other
 *         HAL APIs (e.g. HAL_GPIO_Init()) cannot deadlock.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (NULL pointer, invalid instance or invalid
 *         configuration)
 */
HAL_StatusTypeDef HAL_FCU_Init(HAL_FCU_HandleTypeDef *hfcu)
{
    uint32 reg = 0U;

    /* Check the FCU peripheral handle and instance */
    if (FCU_HandleIsValid(hfcu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_FCU_CHANNEL(hfcu->Init.Channel));
    assert_param(IS_FCU_FAULT_ACTION(hfcu->Init.FaultAction));
    assert_param(IS_FCU_ALARM_ACTION(hfcu->Init.AlarmAction));
    assert_param(IS_FCU_FAULT_LEVEL(hfcu->Init.FaultLevel));
    assert_param(IS_FCU_FAULT_COUNT(hfcu->Init.SoftwareTriggerCount));
    /* The two uint8 count fields are always inside the 0..0xFF range that
     * IS_FCU_FAULT_COUNT() checks, so no comparison is written for them (an
     * always-true comparison is reported by the compiler as -Wtype-limits,
     * see FCU-REQ-044); SoftwareTriggerCount is a uint32 member, so its range
     * check is meaningful and both the assertion and the run-time validation
     * below are kept for it */

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((hfcu->Init.Size != sizeof(FCU_InitTypeDef)) ||
        (hfcu->Init.Version != FCU_INIT_VERSION) ||
        (IS_FCU_CHANNEL(hfcu->Init.Channel) == 0U) ||
        (IS_FCU_FAULT_ACTION(hfcu->Init.FaultAction) == 0U) ||
        (IS_FCU_ALARM_ACTION(hfcu->Init.AlarmAction) == 0U) ||
        (IS_FCU_FAULT_LEVEL(hfcu->Init.FaultLevel) == 0U) ||
        (hfcu->Init.MaskEnable > 1U) ||
        (IS_FCU_FAULT_COUNT(hfcu->Init.SoftwareTriggerCount) == 0U))
    {
        hfcu->ErrorCode |= HAL_FCU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Allocate the lock resource before the first use, so that a handle that
     * was never initialized cannot report HAL_BUSY from a stale Lock field */
    if (hfcu->State == HAL_FCU_STATE_RESET)
    {
        hfcu->Lock = HAL_UNLOCKED;

        /* Init the low level hardware: clock, reset. LOCK-06: the MSP callback
         * runs before the handle is locked */
        HAL_FCU_MspInit(hfcu);
    }

    /* Process locked */
    if (FCU_LockHandle(hfcu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hfcu->ErrorCode = HAL_FCU_ERROR_NONE;
    hfcu->State = HAL_FCU_STATE_BUSY;

    /* Program the software fault trigger threshold of the configured channel
       first, so that the threshold is already in place when the channel is
       configured (the SFCNT register is not part of the channel
       configuration) */
    if ((hfcu->Init.Channel >= HAL_FCU_CHANNEL_SOFTWARE0) &&
        (hfcu->Init.Channel <= HAL_FCU_CHANNEL_SOFTWARE3))
    {
        FCU_SetSoftwareCount(hfcu, (uint32)hfcu->Init.Channel,
                             (uint32)hfcu->Init.SoftwareTriggerCount);
    }

    /* Program the channel configuration register (CFGx). The mask field drives
       the enable bit as well: an unmasked channel is enabled by the
       initialization (so that it reports without a further HAL_FCU_Cmd()
       call), while a masked channel keeps its enable bit untouched - it would
       stay silent while enabled anyway, so its enable state is left to
       HAL_FCU_Cmd() */
    reg = hfcu->Instance->CFG[hfcu->Init.Channel];
    reg &= ~((uint32)(FCU_CFG_FOCU_CNT_Msk | FCU_CFG_ATF_CNT_Msk | FCU_CFG_FACT_Msk |
                      FCU_CFG_AACT_Msk | FCU_CFG_LEVEL_Msk | FCU_CFG_MASK_Msk));
    reg |= (uint32)(((uint32)(hfcu->Init.FaultToResetCount) << FCU_CFG_FOCU_CNT_Pos) |
                    ((uint32)(hfcu->Init.AlarmToFaultCount) << FCU_CFG_ATF_CNT_Pos) |
                    ((uint32)(hfcu->Init.FaultAction) << FCU_CFG_FACT_Pos) |
                    ((uint32)(hfcu->Init.AlarmAction) << FCU_CFG_AACT_Pos) |
                    ((uint32)(hfcu->Init.FaultLevel) << FCU_CFG_LEVEL_Pos));
    if (hfcu->Init.MaskEnable != 0U)
    {
        /* Masked: the channel is configured but stays silent */
        reg |= (uint32)FCU_CFG_MASK;
    }
    else
    {
        /* Unmasked: enable the channel along with the configuration */
        reg |= (uint32)FCU_CFG_EN;
    }
    hfcu->Instance->CFG[hfcu->Init.Channel] = reg;

    hfcu->State = HAL_FCU_STATE_READY;

    /* Release Lock */
    FCU_UnlockHandle(hfcu);

    return HAL_OK;
}

/**
 * @brief  De-initializes the FCU peripheral. (NON-BLOCKING)
 * @note   The channel configuration is reset and the FCU clock is disabled.
 * @note   The call is accepted from any handle state, so that a failed
 *         initialization can always be undone; the handle goes back to the
 *         RESET state so that a following HAL_FCU_Init() re-runs
 *         HAL_FCU_MspInit().
 * @note   LOCK-06: the low level de-initialization (HAL_FCU_MspDeInit()) runs
 *         after the unlock, so that an override which calls other HAL APIs
 *         (e.g. HAL_GPIO_DeInit()) cannot deadlock.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (NULL pointer or invalid instance)
 */
HAL_StatusTypeDef HAL_FCU_DeInit(HAL_FCU_HandleTypeDef *hfcu)
{
    uint32 index = 0U;

    /* Check the FCU peripheral handle and instance */
    if (FCU_HandleIsValid(hfcu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Process locked. ARCH-CONST-09: the de-initialization is callable from
     * any handle state, so that a failed initialization can always be undone */
    if (FCU_LockHandle(hfcu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hfcu->ErrorCode = HAL_FCU_ERROR_NONE;
    hfcu->State = HAL_FCU_STATE_BUSY;

    /* Reset every channel: first clear the enable bit of all of them, then
     * write the whole configuration register to 0, so that no channel of a
     * previous configuration keeps driving an alarm or a fault */
    for (index = 0U; index < HAL_FCU_CHANNEL_COUNT; index++)
    {
        MODIFY_REG(hfcu->Instance->CFG[index], FCU_CFG_EN_Msk, 0x0U);
    }

    for (index = 0U; index < HAL_FCU_CHANNEL_COUNT; index++)
    {
        WRITE_REG(hfcu->Instance->CFG[index], 0x00000000U);
    }

    /* Reset the state */
    hfcu->State = HAL_FCU_STATE_RESET;

    /* Release Lock */
    FCU_UnlockHandle(hfcu);

    /* LOCK-06 / ARCH-CONST-04: the low level de-initialization runs OUTSIDE
     * the locked region, as the architecture specification requires for the
     * MSP callbacks ("MspDeInit is called after the unlock") */
    HAL_FCU_MspDeInit(hfcu);

    return HAL_OK;
}

/**
 * @brief  Initializes the FCU MSP. Weak function; the default implementation
 *         enables the FCU clock and releases its reset through the
 *         SMU_ALB0CFGR register.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_FCU_MspInit(HAL_FCU_HandleTypeDef *hfcu)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hfcu);

    /* Enable the FCU clock and release its reset: the reset bit is released by
     * SETTING it (SET = released, CLEAR = reset asserted), which is also what
     * the SMU_ALB0CFGR reset value (every RST bit set) and
     * __HAL_SMU_FCU_RELEASE_RESET() assume. */
    SMU->ALB0CFGR |= SMU_ALB0CFGR_FCUEN;
    SMU->ALB0CFGR |= SMU_ALB0CFGR_FCURST;
}

/**
 * @brief  De-initializes the FCU MSP. Weak function; the default
 *         implementation disables the FCU clock.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_FCU_MspDeInit(HAL_FCU_HandleTypeDef *hfcu)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hfcu);

    /* Disable the FCU clock */
    SMU->ALB0CFGR &= ~SMU_ALB0CFGR_FCUEN;
}

/**
  * @}
  */

/** @addtogroup FCU_Exported_Functions_Group2 Peripheral Control functions
  * @{
  */

/**
 * @brief  Enables or disables the specified FCU channel. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_FCU_Init() is required first).
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  Channel: the FCU channel (HAL_FCU_CHANNEL_xxx).
 * @param  NewState: ENABLE or DISABLE (FCU_ENABLE / FCU_DISABLE).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid channel, invalid parameter or the handle
 *         is not initialized)
 */
HAL_StatusTypeDef HAL_FCU_Cmd(HAL_FCU_HandleTypeDef *hfcu, HAL_FCU_ChannelTypeDef Channel,
                              FunctionalState NewState)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the FCU peripheral handle and instance */
    if (FCU_HandleIsValid(hfcu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_FCU_CHANNEL(Channel));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03) */
    if ((IS_FCU_CHANNEL(Channel) == 0U) || (IS_FUNCTIONAL_STATE(NewState) == 0U))
    {
        hfcu->ErrorCode |= HAL_FCU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_FCU_Init() is
     * required first) */
    status = FCU_CheckState(hfcu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (FCU_LockHandle(hfcu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code of the previous operation (ARCH-CONST-10) */
    hfcu->ErrorCode = HAL_FCU_ERROR_NONE;

    if (NewState != DISABLE)
    {
        /* Enable the channel */
        hfcu->Instance->CFG[Channel] |= ((uint32)(FCU_CFG_EN));
    }
    else
    {
        /* Disable the channel */
        hfcu->Instance->CFG[Channel] &= ~((uint32)(FCU_CFG_EN));
    }

    /* Release Lock */
    FCU_UnlockHandle(hfcu);

    return HAL_OK;
}

/**
 * @brief  Updates the fault level of the specified FCU channel. (NON-BLOCKING)
 * @note   Only the CFG.LEVEL field of the channel is written; its enable,
 *         mask, action and counter fields are preserved. When the channel is
 *         the one configured by HAL_FCU_Init(), the adjusted value is also
 *         written back to the handle Init structure, so that a following
 *         HAL_FCU_Init() keeps it.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_FCU_Init() is required first).
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  Channel: the FCU channel (HAL_FCU_CHANNEL_xxx).
 * @param  Level: the new fault level (HAL_FCU_FAULT_LEVEL_xxx).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid channel, invalid parameter or the handle
 *         is not initialized)
 */
HAL_StatusTypeDef HAL_FCU_SetLevel(HAL_FCU_HandleTypeDef *hfcu, HAL_FCU_ChannelTypeDef Channel,
                                   HAL_FCU_FaultLevelTypeDef Level)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the FCU peripheral handle and instance */
    if (FCU_HandleIsValid(hfcu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_FCU_CHANNEL(Channel));
    assert_param(IS_FCU_FAULT_LEVEL(Level));

    /* Runtime parameter validation (see HAL_FCU_Init()) */
    if ((IS_FCU_CHANNEL(Channel) == 0U) || (IS_FCU_FAULT_LEVEL(Level) == 0U))
    {
        hfcu->ErrorCode |= HAL_FCU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_FCU_Init() is
     * required first) */
    status = FCU_CheckState(hfcu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (FCU_LockHandle(hfcu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code of the previous operation (ARCH-CONST-10) */
    hfcu->ErrorCode = HAL_FCU_ERROR_NONE;

    /* Update the level field, keep every other field of the channel */
    MODIFY_REG(hfcu->Instance->CFG[(uint32)Channel], FCU_CFG_LEVEL_Msk,
               ((uint32)Level << FCU_CFG_LEVEL_Pos));

    /* Keep the handle initialization copy in step with the adjusted value when
     * the channel is the configured one, so that a following HAL_FCU_Init()
     * programs the same level again */
    if (Channel == hfcu->Init.Channel)
    {
        hfcu->Init.FaultLevel = Level;
    }

    /* Release Lock */
    FCU_UnlockHandle(hfcu);

    return HAL_OK;
}

/**
 * @brief  Updates the fault action of the specified FCU channel. (NON-BLOCKING)
 * @note   Only the CFG.FACT field of the channel is written; its alarm action
 *         is preserved.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_FCU_Init() is required first).
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  Channel: the FCU channel (HAL_FCU_CHANNEL_xxx).
 * @param  Action: the new fault action (HAL_FCU_FAULT_INTERRUPT /
 *         HAL_FCU_FAULT_GLOBAL_SOFTWARE_RESET).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid channel, invalid parameter or the handle
 *         is not initialized)
 */
HAL_StatusTypeDef HAL_FCU_SetFaultAction(HAL_FCU_HandleTypeDef *hfcu, HAL_FCU_ChannelTypeDef Channel,
                                         HAL_FCU_FaultActionTypeDef Action)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the FCU peripheral handle and instance */
    if (FCU_HandleIsValid(hfcu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_FCU_CHANNEL(Channel));
    assert_param(IS_FCU_FAULT_ACTION(Action));

    /* Runtime parameter validation (see HAL_FCU_Init()) */
    if ((IS_FCU_CHANNEL(Channel) == 0U) || (IS_FCU_FAULT_ACTION(Action) == 0U))
    {
        hfcu->ErrorCode |= HAL_FCU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_FCU_Init() is
     * required first) */
    status = FCU_CheckState(hfcu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (FCU_LockHandle(hfcu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code of the previous operation (ARCH-CONST-10) */
    hfcu->ErrorCode = HAL_FCU_ERROR_NONE;

    /* Update the fault action field, keep the alarm action of the channel */
    MODIFY_REG(hfcu->Instance->CFG[(uint32)Channel], FCU_CFG_FACT_Msk,
               ((uint32)Action << FCU_CFG_FACT_Pos));

    /* Release Lock */
    FCU_UnlockHandle(hfcu);

    return HAL_OK;
}

/**
 * @brief  Updates the alarm action of the specified FCU channel. (NON-BLOCKING)
 * @note   Only the CFG.AACT field of the channel is written; its fault action
 *         is preserved.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_FCU_Init() is required first).
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  Channel: the FCU channel (HAL_FCU_CHANNEL_xxx).
 * @param  Action: the new alarm action (HAL_FCU_ALARM_NONE /
 *         HAL_FCU_ALARM_INTERRUPT).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid channel, invalid parameter or the handle
 *         is not initialized)
 */
HAL_StatusTypeDef HAL_FCU_SetAlarmAction(HAL_FCU_HandleTypeDef *hfcu, HAL_FCU_ChannelTypeDef Channel,
                                         HAL_FCU_AlarmActionTypeDef Action)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the FCU peripheral handle and instance */
    if (FCU_HandleIsValid(hfcu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_FCU_CHANNEL(Channel));
    assert_param(IS_FCU_ALARM_ACTION(Action));

    /* Runtime parameter validation (see HAL_FCU_Init()) */
    if ((IS_FCU_CHANNEL(Channel) == 0U) || (IS_FCU_ALARM_ACTION(Action) == 0U))
    {
        hfcu->ErrorCode |= HAL_FCU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_FCU_Init() is
     * required first) */
    status = FCU_CheckState(hfcu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (FCU_LockHandle(hfcu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code of the previous operation (ARCH-CONST-10) */
    hfcu->ErrorCode = HAL_FCU_ERROR_NONE;

    /* Update the alarm action field, keep the fault action of the channel */
    MODIFY_REG(hfcu->Instance->CFG[(uint32)Channel], FCU_CFG_AACT_Msk,
               ((uint32)Action << FCU_CFG_AACT_Pos));

    /* Release Lock */
    FCU_UnlockHandle(hfcu);

    return HAL_OK;
}

/**
 * @brief  Triggers the specified software fault channel(s). (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_FCU_Init() is required first).
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  SoftwareChannel: FCU_SOFTWARE_CHANNEL_0..3 combination.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_FCU_SetSoftwareTrigger(HAL_FCU_HandleTypeDef *hfcu, uint32 SoftwareChannel)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the FCU peripheral handle and instance */
    if (FCU_HandleIsValid(hfcu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_FCU_SOFTWARE_CHANNEL(SoftwareChannel));

    /* Runtime parameter validation (see HAL_FCU_Init()) */
    if (IS_FCU_SOFTWARE_CHANNEL(SoftwareChannel) == 0U)
    {
        hfcu->ErrorCode |= HAL_FCU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_FCU_Init() is
     * required first) */
    status = FCU_CheckState(hfcu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (FCU_LockHandle(hfcu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code of the previous operation (ARCH-CONST-10) */
    hfcu->ErrorCode = HAL_FCU_ERROR_NONE;

    hfcu->Instance->SFTR = SoftwareChannel;

    /* Release Lock */
    FCU_UnlockHandle(hfcu);

    return HAL_OK;
}

/**
 * @brief  Returns the software fault status of the specified channel(s). (NON-BLOCKING)
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  SoftwareChannel: FCU_SOFTWARE_CHANNEL_0..3 combination.
 * @retval 1 if the fault status is set, 0 otherwise.
 */
uint32 HAL_FCU_GetSoftwareFaultStatus(HAL_FCU_HandleTypeDef *hfcu, uint32 SoftwareChannel)
{
    /* Check the FCU peripheral handle and instance */
    if (FCU_HandleIsValid(hfcu) == 0U)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_FCU_SOFTWARE_CHANNEL(SoftwareChannel));

    /* An invalid mask would read an arbitrary register bit; report no status
     * instead (read-only: no lock) */
    if (IS_FCU_SOFTWARE_CHANNEL(SoftwareChannel) == 0U)
    {
        return 0U;
    }

    return ((hfcu->Instance->SFSTA & SoftwareChannel) != 0U) ? 1U : 0U;
}

/**
 * @brief  Sets the software fault count of the specified channel(s). (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_FCU_Init() is required first).
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  SoftwareChannel: FCU_SOFTWARE_CHANNEL_0..3 combination.
 * @param  Count: fault count (0..0xFF).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_FCU_SetSoftwareFaultCount(HAL_FCU_HandleTypeDef *hfcu, uint32 SoftwareChannel,
                                                uint8 Count)
{
    uint32 index = 0U;
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the FCU peripheral handle and instance */
    if (FCU_HandleIsValid(hfcu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_FCU_SOFTWARE_CHANNEL(SoftwareChannel));

    /* Runtime parameter validation (see HAL_FCU_Init()) */
    if (IS_FCU_SOFTWARE_CHANNEL(SoftwareChannel) == 0U)
    {
        hfcu->ErrorCode |= HAL_FCU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_FCU_Init() is
     * required first) */
    status = FCU_CheckState(hfcu);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (FCU_LockHandle(hfcu, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code of the previous operation (ARCH-CONST-10) */
    hfcu->ErrorCode = HAL_FCU_ERROR_NONE;

    /* Update the count field of each selected software channel, keep the
       fields of the other channels unchanged */
    for (index = 0U; index < FCU_SOFTWARE_CHANNEL_COUNT; index++)
    {
        if ((SoftwareChannel & (1UL << index)) != 0U)
        {
            FCU_SetSoftwareCount(hfcu, ((uint32)HAL_FCU_CHANNEL_SOFTWARE0 + index), (uint32)Count);
        }
    }

    /* Release Lock */
    FCU_UnlockHandle(hfcu);

    return HAL_OK;
}

/**
 * @brief  Returns the software fault count of the specified channel. (NON-BLOCKING)
 * @note   When several channels are selected, the count of the highest
 *         selected channel is returned (the evaluation order is ch0 -> ch3,
 *         the last matching one wins).
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  SoftwareChannel: FCU_SOFTWARE_CHANNEL_0..3 combination.
 * @retval uint8: the software fault count of the highest selected channel.
 */
uint8 HAL_FCU_GetSoftwareFaultCount(HAL_FCU_HandleTypeDef *hfcu, uint32 SoftwareChannel)
{
    uint8 tmpreg = 0U;

    /* Check the FCU peripheral handle and instance */
    if (FCU_HandleIsValid(hfcu) == 0U)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_FCU_SOFTWARE_CHANNEL(SoftwareChannel));

    /* An invalid mask would read an arbitrary register field; report 0
     * instead (read-only: no lock) */
    if (IS_FCU_SOFTWARE_CHANNEL(SoftwareChannel) == 0U)
    {
        return 0U;
    }

    if ((SoftwareChannel & FCU_SOFTWARE_CHANNEL_0) != 0U)
    {
        tmpreg = (uint8)((hfcu->Instance->SFCNT >> FCU_SFCNT_CNT0_Pos) & 0xFFU);
    }
    if ((SoftwareChannel & FCU_SOFTWARE_CHANNEL_1) != 0U)
    {
        tmpreg = (uint8)((hfcu->Instance->SFCNT >> FCU_SFCNT_CNT1_Pos) & 0xFFU);
    }
    if ((SoftwareChannel & FCU_SOFTWARE_CHANNEL_2) != 0U)
    {
        tmpreg = (uint8)((hfcu->Instance->SFCNT >> FCU_SFCNT_CNT2_Pos) & 0xFFU);
    }
    if ((SoftwareChannel & FCU_SOFTWARE_CHANNEL_3) != 0U)
    {
        tmpreg = (uint8)((hfcu->Instance->SFCNT >> FCU_SFCNT_CNT3_Pos) & 0xFFU);
    }

    return tmpreg;
}

/**
 * @brief  Clears the software fault of the specified channel(s). (NON-BLOCKING)
 * @note   Interrupt safe by design: the interface takes no lock (LOCK-04 /
 *         RTOS-12), so it is callable from an interrupt service routine. The
 *         mask sequence of the shared configuration register is serialized
 *         against an interrupt with a short critical section instead.
 * @note   The software trigger latch (SFSTA) is read back after the clear: a
 *         status which survives it means that the trigger is still active,
 *         HAL_FCU_ERROR_CLEAR_FAILED is reported and the handle moves to
 *         HAL_FCU_STATE_ERROR (a recoverable state).
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  SoftwareChannel: FCU_SOFTWARE_CHANNEL_0..3 combination.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (NULL pointer, invalid
 *         instance, invalid parameter or a latch that survived the clear)
 */
HAL_StatusTypeDef HAL_FCU_ClearSoftwareFault(HAL_FCU_HandleTypeDef *hfcu, uint32 SoftwareChannel)
{
    uint32 index = 0U;
    uint32 channel = 0U;
    uint32 savedMask = 0U;
    uint32 stillSet = 0U;
    uint32 irqState = 0U;

    /* Check the FCU peripheral handle and instance */
    if (FCU_HandleIsValid(hfcu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_FCU_SOFTWARE_CHANNEL(SoftwareChannel));

    /* Runtime parameter validation: an invalid mask would touch an arbitrary
     * register bit (no lock is taken on this path) */
    if (IS_FCU_SOFTWARE_CHANNEL(SoftwareChannel) == 0U)
    {
        hfcu->ErrorCode |= HAL_FCU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Serialize the mask sequence of the shared configuration register */
    irqState = __disable_irq_and_save();

    /* Each selected software channel is cleared as a whole: the FCU channel of
     * software channel n is FCU channel 36 + n and its fault / alarm latch
     * lives in the CLEAR1 register, so clearing only SFCLR would leave the
     * latch set and retrigger the interrupt. The channel is masked around the
     * clear so that the status cannot be latched again in between, and the
     * previous mask configuration is restored afterwards. */
    for (index = 0U; index < FCU_SOFTWARE_CHANNEL_COUNT; index++)
    {
        if ((SoftwareChannel & (1UL << index)) != 0U)
        {
            channel = ((uint32)HAL_FCU_CHANNEL_SOFTWARE0 + index);
            savedMask = hfcu->Instance->CFG[channel] & (uint32)FCU_CFG_MASK_Msk;

            SET_BIT(hfcu->Instance->CFG[channel], FCU_CFG_MASK_Msk);
            WRITE_REG(hfcu->Instance->SFCLR, (1UL << index));

            /* The trigger latch is read back while the channel is still masked */
            if ((hfcu->Instance->SFSTA & (1UL << index)) != 0U)
            {
                stillSet = 1U;
            }

            WRITE_REG(hfcu->Instance->CLEAR1,
                      (1UL << (channel - FCU_STATUS_REGISTER_WIDTH)));
            MODIFY_REG(hfcu->Instance->CFG[channel], FCU_CFG_MASK_Msk, savedMask);
        }
    }

    if (stillSet != 0U)
    {
        hfcu->ErrorCode |= HAL_FCU_ERROR_CLEAR_FAILED;
        hfcu->State = HAL_FCU_STATE_ERROR;
    }

    __restore_irq(irqState);

    if (stillSet != 0U)
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
  * @}
  */

/** @addtogroup FCU_Exported_Functions_Group3 Fault and Alarm functions
  * @{
  */

/**
 * @brief  Returns the alarm status of the specified FCU channel. (NON-BLOCKING)
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  Channel: the FCU channel (HAL_FCU_CHANNEL_xxx).
 * @retval 1 if the alarm is set, 0 otherwise.
 */
uint32 HAL_FCU_GetAlarmStatus(HAL_FCU_HandleTypeDef *hfcu, HAL_FCU_ChannelTypeDef Channel)
{
    /* Check the FCU peripheral handle and instance */
    if (FCU_HandleIsValid(hfcu) == 0U)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_FCU_CHANNEL(Channel));

    /* An out of range channel would shift by an undefined amount; report no
     * status instead (read-only: no lock) */
    if (IS_FCU_CHANNEL(Channel) == 0U)
    {
        return 0U;
    }

    if (Channel < 32U)
    {
        return ((hfcu->Instance->ALARM0 & (1UL << (uint32)Channel)) != 0U) ? 1U : 0U;
    }
    else
    {
        return ((hfcu->Instance->ALARM1 & (1UL << ((uint32)Channel - 32U))) != 0U) ? 1U : 0U;
    }
}

/**
 * @brief  Returns the fault status of the specified FCU channel. (NON-BLOCKING)
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  Channel: the FCU channel (HAL_FCU_CHANNEL_xxx).
 * @retval 1 if the fault is set, 0 otherwise.
 */
uint32 HAL_FCU_GetFaultStatus(HAL_FCU_HandleTypeDef *hfcu, HAL_FCU_ChannelTypeDef Channel)
{
    /* Check the FCU peripheral handle and instance */
    if (FCU_HandleIsValid(hfcu) == 0U)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_FCU_CHANNEL(Channel));

    /* An out of range channel would shift by an undefined amount; report no
     * status instead (read-only: no lock) */
    if (IS_FCU_CHANNEL(Channel) == 0U)
    {
        return 0U;
    }

    if (Channel < 32U)
    {
        return ((hfcu->Instance->FAULT0 & (1UL << (uint32)Channel)) != 0U) ? 1U : 0U;
    }
    else
    {
        return ((hfcu->Instance->FAULT1 & (1UL << ((uint32)Channel - 32U))) != 0U) ? 1U : 0U;
    }
}

/**
 * @brief  Clears the alarm / fault status of the specified FCU channel. (NON-BLOCKING)
 * @note   Interrupt safe by design: the interface takes no lock (LOCK-04 /
 *         RTOS-12), so it is callable from the FCU interrupt service routine.
 *         The mask sequence of the shared configuration register is serialized
 *         against an interrupt with a short critical section instead.
 * @note   The channel is masked for the duration of the clear, the status is
 *         cleared by writing the target mask directly into the write-one-to-
 *         clear register and the previous mask configuration is restored.
 * @note   The latch is read back after the clear: a status which survives it
 *         means that the underlying fault source is still active,
 *         HAL_FCU_ERROR_CLEAR_FAILED is reported and the handle moves to
 *         HAL_FCU_STATE_ERROR (a recoverable state).
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  Channel: the FCU channel (HAL_FCU_CHANNEL_xxx).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (NULL pointer, invalid
 *         instance, invalid parameter or a latch that survived the clear)
 */
HAL_StatusTypeDef HAL_FCU_ClearFcuStatus(HAL_FCU_HandleTypeDef *hfcu, HAL_FCU_ChannelTypeDef Channel)
{
    /* Check the FCU peripheral handle and instance */
    if (FCU_HandleIsValid(hfcu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_FCU_CHANNEL(Channel));

    /* Runtime parameter validation: an out of range channel would shift by an
     * undefined amount (no lock is taken on this path) */
    if (IS_FCU_CHANNEL(Channel) == 0U)
    {
        hfcu->ErrorCode |= HAL_FCU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    if ((uint32)Channel < FCU_STATUS_REGISTER_WIDTH)
    {
        return FCU_ClearLatches(hfcu, (uint32)(1UL << (uint32)Channel), 0U);
    }

    return FCU_ClearLatches(hfcu, 0U,
                            (uint32)(1UL << ((uint32)Channel - FCU_STATUS_REGISTER_WIDTH)));
}

/**
 * @brief  Clears the alarm / fault latches of a fault source category. (NON-BLOCKING)
 * @note   The category is selected by a mask pair that addresses the CLEAR0
 *         (channels 0..31) and CLEAR1 (channels 32..41) registers: the
 *         published FCU_CATEGORY_CLEAR_xxx_MASK0 / MASK1 pairs can be used
 *         directly, and any other pair of channel masks is accepted as well.
 * @note   Interrupt safe by design: same locking and serialization contract as
 *         HAL_FCU_ClearFcuStatus(), which this interface shares its
 *         implementation with.
 * @note   The latches are read back after the clear: a status which survives it
 *         means that at least one selected source is still active,
 *         HAL_FCU_ERROR_CLEAR_FAILED is reported and the handle moves to
 *         HAL_FCU_STATE_ERROR (a recoverable state).
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @param  Mask0: channels 0..31 of the category (bit n selects channel n).
 * @param  Mask1: channels 32..41 of the category (bit n selects channel 32 + n).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (NULL pointer, invalid
 *         instance, an empty selection, a channel above EXTENDFAULT1 or a
 *         latch that survived the clear)
 */
HAL_StatusTypeDef HAL_FCU_ClearCategoryFaultStatus(HAL_FCU_HandleTypeDef *hfcu, uint32 Mask0,
                                                   uint32 Mask1)
{
    /* Check the FCU peripheral handle and instance */
    if (FCU_HandleIsValid(hfcu) == 0U)
    {
        return HAL_ERROR;
    }

    /* Runtime parameter validation: an empty selection is a caller error and a
     * mask which selects a channel above EXTENDFAULT1 would address reserved
     * bits of the clear register (no lock is taken on this path) */
    if (((Mask0 == 0U) && (Mask1 == 0U)) ||
        ((Mask1 & ~FCU_CLEAR1_CHANNEL_MASK) != 0U))
    {
        hfcu->ErrorCode |= HAL_FCU_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    return FCU_ClearLatches(hfcu, Mask0, Mask1);
}

/**
 * @brief  Clears the bus timeout fault status. (NON-BLOCKING)
 * @note   Interrupt safe by design: the interface takes no lock and changes no
 *         handle state (it is a write-one-to-clear signal latch), so it is
 *         callable from an interrupt service routine (LOCK-04 / RTOS-12).
 * @note   The clear register is written directly: the bit is write-one-to-
 *         clear, so reading the register back and rewriting it would clear the
 *         signal that is not selected here as well.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (NULL pointer or invalid
 *         instance)
 */
HAL_StatusTypeDef HAL_FCU_ClearBusTimeoutFaultStatus(HAL_FCU_HandleTypeDef *hfcu)
{
    /* Check the FCU peripheral handle and instance */
    if (FCU_HandleIsValid(hfcu) == 0U)
    {
        return HAL_ERROR;
    }

    hfcu->Instance->OCLR = FCU_OCLR_BTOC;

    return HAL_OK;
}

/**
 * @brief  Clears the ECC fault status. (NON-BLOCKING)
 * @note   Interrupt safe by design: the interface takes no lock and changes no
 *         handle state (it is a write-one-to-clear signal latch), so it is
 *         callable from an interrupt service routine (LOCK-04 / RTOS-12).
 * @note   The clear register is written directly: the bit is write-one-to-
 *         clear, so reading the register back and rewriting it would clear the
 *         signal that is not selected here as well.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (NULL pointer or invalid
 *         instance)
 */
HAL_StatusTypeDef HAL_FCU_ClearECCFaultStatus(HAL_FCU_HandleTypeDef *hfcu)
{
    /* Check the FCU peripheral handle and instance */
    if (FCU_HandleIsValid(hfcu) == 0U)
    {
        return HAL_ERROR;
    }

    hfcu->Instance->OCLR = FCU_OCLR_ECCC;

    return HAL_OK;
}

/**
  * @}
  */

/** @addtogroup FCU_Exported_Functions_Group4 State functions
  * @{
  */

/**
 * @brief  Returns the FCU handle state. (NON-BLOCKING)
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @retval HAL_FCU_StateTypeDef: the current handle state.
 */
HAL_FCU_StateTypeDef HAL_FCU_GetState(HAL_FCU_HandleTypeDef *hfcu)
{
    /* Check the FCU peripheral handle and instance */
    if (FCU_HandleIsValid(hfcu) == 0U)
    {
        return HAL_FCU_STATE_RESET;
    }

    return hfcu->State;
}

/**
 * @brief  Returns the FCU error code. (NON-BLOCKING)
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @retval uint32: the FCU error code (HAL_FCU_ERROR_xxx).
 */
uint32 HAL_FCU_GetError(HAL_FCU_HandleTypeDef *hfcu)
{
    /* Check the FCU peripheral handle and instance */
    if (FCU_HandleIsValid(hfcu) == 0U)
    {
        return HAL_FCU_ERROR_NONE;
    }

    return hfcu->ErrorCode;
}

/**
  * @}
  */

/** @addtogroup FCU_Exported_Functions_Group5 Interrupt handling and callbacks
  * @{
  */

/**
 * @brief  Interrupt dispatch entry of the FCU. (NON-BLOCKING)
 * @note   Call this from the user FCU interrupt service routine (FCU_IRQn,
 *         enabled through the PLIC). One snapshot of the four latch registers
 *         is taken, then HAL_FCU_FaultCallback() is invoked when any fault
 *         latch is set and HAL_FCU_AlarmCallback() when any alarm latch is
 *         set. Both callbacks run in the interrupt context, so they shall only
 *         use the read-only query interfaces and the interrupt safe clear
 *         family (LOCK-04 / RTOS-12), never a locking interface.
 * @note   Read-only with respect to the handle: it takes no lock and changes
 *         no handle state.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @retval None
 */
void HAL_FCU_IRQHandler(HAL_FCU_HandleTypeDef *hfcu)
{
    uint32 alarmSnapshot[2] = {0U, 0U};
    uint32 faultSnapshot[2] = {0U, 0U};

    /* Check the FCU peripheral handle and instance */
    if (FCU_HandleIsValid(hfcu) == 0U)
    {
        return;
    }

    /* One read per latch register: the hardware gives no consistency guarantee
     * between the two registers of one class */
    alarmSnapshot[0] = hfcu->Instance->ALARM0;
    alarmSnapshot[1] = hfcu->Instance->ALARM1;
    faultSnapshot[0] = hfcu->Instance->FAULT0;
    faultSnapshot[1] = hfcu->Instance->FAULT1;

    /* The fault level is serviced first, then the alarm level */
    if ((faultSnapshot[0] != 0U) || (faultSnapshot[1] != 0U))
    {
        HAL_FCU_FaultCallback(hfcu);
    }

    if ((alarmSnapshot[0] != 0U) || (alarmSnapshot[1] != 0U))
    {
        HAL_FCU_AlarmCallback(hfcu);
    }
}

/**
 * @brief  Fault callback. Weak function; called by HAL_FCU_IRQHandler() when at
 *         least one fault latch is set.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_FCU_FaultCallback(HAL_FCU_HandleTypeDef *hfcu)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hfcu);

    /* The application services the FCU fault latches here: read them with
     * HAL_FCU_GetFaultStatus() and clear them with HAL_FCU_ClearFcuStatus() */
}

/**
 * @brief  Alarm callback. Weak function; called by HAL_FCU_IRQHandler() when at
 *         least one alarm latch is set.
 * @param  hfcu: pointer to a HAL_FCU_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_FCU_AlarmCallback(HAL_FCU_HandleTypeDef *hfcu)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hfcu);

    /* The application services the FCU alarm latches here: read them with
     * HAL_FCU_GetAlarmStatus() and clear them with HAL_FCU_ClearFcuStatus() */
}

/**
  * @}
  */

/**
  * @}
  */

#endif /* HAL_FCU_MODULE_ENABLED */

/*****END OF FILE*****/
