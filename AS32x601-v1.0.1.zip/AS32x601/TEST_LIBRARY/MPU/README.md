# MPU 应用与测试参考

供 skill 按需求检索 AS32x601 HAL MPU 示例。关键词：内存保护、I-Port、D-Port、P-Port、取指、数据、外设、DMA、读保护、写保护、地址窗口、RPTS、WPTS、通道使能。共有 12 个独立用例。

HAL 依据：[头文件](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_mpu.h)、[实现](../../HAL_LIBRARY/peripherals/src/as32x601_hal_mpu.c)。按所选案例核对当前驱动，不以接口索引代替实现依据。


## 实例与相关资源

本模块不单独列出外部通信引脚组。按实际功能核对实例、时钟、中断、内存或数据通路；关联 GPIO、定时器或其他外设时，再读取对应分支的引脚资料。具体资源与案例配置见下文。

## 生成前需确认的参数

已有工程、板级资料或用户已明确的值直接复用。仅对影响本次实现的缺失选择使用参数卡询问并等待答复；案例配置不能代替实际接线或应用参数。

| 参数 | 需要核对或确认的内容 |
|---|---|
| 保护对象 | 实际主设备/端口、地址区间、长度及对齐 |
| 权限与响应 | 读写限制、CPU/DMA 访问来源、违规标志与恢复行为 |

## 按需求选择

| 用户需求 / 检索关键词 | 推荐用例 | 选择条件 / 需要补充的逻辑 |
|---|---|---|
| I-Port 单通道取指读保护 | [001](MPU_IT_DRV_001.c) | MPU0 通道 0；违规取指预期停止，需调试器确认 |
| I-Port 多通道取指读保护 | [002](MPU_IT_DRV_002.c) | MPU0 通道 0～15 保护同一函数窗口，非独立代码区 |
| CPU 数据区域读保护；D-Port | [003](MPU_IT_DRV_003.c) | MPU1 通道 0～15，核对缓存和实际总线访问 |
| CPU 数据区域写保护；D-Port | [004](MPU_IT_DRV_004.c) | MPU1 通道 0～15，同时核对状态和写入结果 |
| 外设寄存器读保护；P-Port | [005](MPU_IT_DRV_005.c) | MPU2 通道 0～15，需要被访问外设时钟 |
| 外设寄存器写保护；P-Port | [006](MPU_IT_DRV_006.c) | MPU2 通道 0～15，按源码选寄存器和测试值 |
| DMA0 访问 RAM 写保护 | [007](MPU_IT_DRV_007.c) | MPU3 通道 0～7，内存到内存 DMA |
| DMA0 访问 RAM 读保护 | [008](MPU_IT_DRV_008.c) | MPU3 通道 0～7，不代表 DMA 外设寄存器保护 |
| DMA1 访问 RAM 写保护 | [009](MPU_IT_DRV_009.c) | MPU4 通道 0～7，内存到内存 DMA |
| DMA1 访问 RAM 读保护 | [010](MPU_IT_DRV_010.c) | MPU4 通道 0～7，不代表 DMA 外设寄存器保护 |
| 公共 API、默认值、常量、参数与空指针保护、锁 | [011](MPU_IT_DRV_011.c) | 综合接口检查；MPU0 无写保护 |
| 重新初始化、ChannelEnable 语义、地址与通道边界 | [012](MPU_IT_DRV_012.c) | ChannelEnable=0 保持旧使能状态，不能用于强制关闭 |
| 应用中通过 HAL 初始化句柄并配置保护通道 | [011](MPU_IT_DRV_011.c)、[012](MPU_IT_DRV_012.c) | 先参考 HAL_MPU_StructInit / HAL_MPU_Init，再结合目标端口用例；不复制手工 READY 状态设置 |
| 任务隔离、违规后自动恢复、MPU 中断回调 | 无直接完整模板 | 当前驱动无独立 MPU IRQ/违规回调，需另行设计系统方案 |

## 实现要点与案例配置

MPU0=I-Port、MPU1=D-Port、MPU2=P-Port、MPU3=DMA0、MPU4=DMA1。前三者各 16 通道，后两者各 8 通道。MPU0 无写保护，寄存器布局与其他端口不同。

流程：设置地址范围与保护 → 使能通道 → 配置回读 → 制造目标端口访问 → 检查 RPTS/WPTS → 清除状态并验证关闭保护后的行为。违规记录、访问阻断和软件恢复是不同验证项。

001/002 源码记录违规取指不返回且不进入普通 trap，内核停止；用调试器分别确认 MPU0 RPTS=`0x0001`/`0xFFFF`，复位重跑。这是源码描述，并非本次实测。保留 volatile 函数指针、受保护函数布局与指令缓存刷新，避免优化或缓存命中绕过总线。

003～006 核对缓存、访问宽度和外设时钟。007～010 使用 RAM 窗口和内存到内存 DMA，无需外部串口刺激。源码记录 DMA 外设寄存器访问未被同样报告，不能泛化为任意 DMA 外设保护。预期状态掩码为 `0x00FF`，清除后归零，关闭保护后新传输不再记录。测试主动停止 DMA，不能推断驱动自动中止。

012 中 ChannelEnable=0 恢复原使能状态；强制关闭应使用显式通道控制。HAL_MPU_ERROR_HARDWARE 仅检查错误码定义，不表示已注入硬件读回故障。当前驱动以状态寄存器和转发 FCU 报告违规，没有独立 MPU IRQ 处理及违规回调。

001～010 是低层通道访问测试：源码直接准备句柄并设置 `HAL_MPU_STATE_READY`，并未通过 `HAL_MPU_Init()` 建立完整初始化流程。生成应用时优先参考 011/012 的 `HAL_MPU_StructInit()` 与 `HAL_MPU_Init()`，再结合对应端口的访问和保护逻辑，避免把测试用的手工状态设置当作标准初始化方式。

003/004 的保护数据按 256 字节间距布置，避免多个窗口落在同一 64 字节缓存行；保留相应刷新操作，不能任意压缩成连续数组。按源码预期，003～006 的通道状态掩码为 `0xFFFF`；读保护测试不应把受保护读取的数据值作为唯一通过条件，写保护还需确认原数据或寄存器内容未被改写。记录标志后还应验证清除和关闭保护后的恢复行为。

## 验证方法与适用边界

每个源码有独立 `main()`。选定后读取完整地址窗口、缓存处理、访问触发和清理逻辑，按应用调整，避免直接复用测试地址和故障制造代码。

本次为源码静态整理，未重新编译或上板；源码已有测试记录与本次验证状态分别判断。

## 按接口与辅助宏检索

来自去除注释后的源码调用或定义，包含 HAL 接口、锁助手、寄存器及参数校验宏。MSP、IRQ、回调可能是定义或转发入口，应结合完整源码阅读；出现不代表所有分支均已覆盖。

| 接口 / 宏 | 参考用例 |
|---|---|
| `HAL_MPU_ClearStatus` | [001](MPU_IT_DRV_001.c)、[002](MPU_IT_DRV_002.c)、[003](MPU_IT_DRV_003.c)、[004](MPU_IT_DRV_004.c)、[005](MPU_IT_DRV_005.c)、[006](MPU_IT_DRV_006.c)、[007](MPU_IT_DRV_007.c)、[008](MPU_IT_DRV_008.c)、[009](MPU_IT_DRV_009.c)、[010](MPU_IT_DRV_010.c)、[011](MPU_IT_DRV_011.c) |
| `HAL_MPU_Cmd` | [001](MPU_IT_DRV_001.c)、[002](MPU_IT_DRV_002.c)、[003](MPU_IT_DRV_003.c)、[004](MPU_IT_DRV_004.c)、[005](MPU_IT_DRV_005.c)、[006](MPU_IT_DRV_006.c)、[007](MPU_IT_DRV_007.c)、[008](MPU_IT_DRV_008.c)、[009](MPU_IT_DRV_009.c)、[010](MPU_IT_DRV_010.c)、[011](MPU_IT_DRV_011.c)、[012](MPU_IT_DRV_012.c) |
| `HAL_MPU_DeInit` | [011](MPU_IT_DRV_011.c)、[012](MPU_IT_DRV_012.c) |
| `HAL_MPU_GetAddressRange` | [001](MPU_IT_DRV_001.c)、[011](MPU_IT_DRV_011.c)、[012](MPU_IT_DRV_012.c) |
| `HAL_MPU_GetChannelConfig` | [001](MPU_IT_DRV_001.c)、[002](MPU_IT_DRV_002.c)、[003](MPU_IT_DRV_003.c)、[004](MPU_IT_DRV_004.c)、[005](MPU_IT_DRV_005.c)、[006](MPU_IT_DRV_006.c)、[007](MPU_IT_DRV_007.c)、[008](MPU_IT_DRV_008.c)、[009](MPU_IT_DRV_009.c)、[010](MPU_IT_DRV_010.c)、[011](MPU_IT_DRV_011.c)、[012](MPU_IT_DRV_012.c) |
| `HAL_MPU_GetError` | [011](MPU_IT_DRV_011.c)、[012](MPU_IT_DRV_012.c) |
| `HAL_MPU_GetIPortBlock` | [001](MPU_IT_DRV_001.c)、[002](MPU_IT_DRV_002.c)、[011](MPU_IT_DRV_011.c)、[012](MPU_IT_DRV_012.c) |
| `HAL_MPU_GetReadProtectStatus` | [001](MPU_IT_DRV_001.c)、[002](MPU_IT_DRV_002.c)、[003](MPU_IT_DRV_003.c)、[005](MPU_IT_DRV_005.c)、[008](MPU_IT_DRV_008.c)、[010](MPU_IT_DRV_010.c)、[011](MPU_IT_DRV_011.c) |
| `HAL_MPU_GetRegBlock` | [011](MPU_IT_DRV_011.c) |
| `HAL_MPU_GetState` | [011](MPU_IT_DRV_011.c)、[012](MPU_IT_DRV_012.c) |
| `HAL_MPU_GetWriteProtectStatus` | [004](MPU_IT_DRV_004.c)、[006](MPU_IT_DRV_006.c)、[007](MPU_IT_DRV_007.c)、[009](MPU_IT_DRV_009.c)、[011](MPU_IT_DRV_011.c) |
| `HAL_MPU_Init` | [011](MPU_IT_DRV_011.c)、[012](MPU_IT_DRV_012.c) |
| `HAL_MPU_MspDeInit` | [011](MPU_IT_DRV_011.c) |
| `HAL_MPU_MspInit` | [011](MPU_IT_DRV_011.c) |
| `HAL_MPU_ReadProtectCmd` | [001](MPU_IT_DRV_001.c)、[002](MPU_IT_DRV_002.c)、[003](MPU_IT_DRV_003.c)、[005](MPU_IT_DRV_005.c)、[008](MPU_IT_DRV_008.c)、[010](MPU_IT_DRV_010.c)、[011](MPU_IT_DRV_011.c) |
| `HAL_MPU_ResetInstance` | [011](MPU_IT_DRV_011.c)、[012](MPU_IT_DRV_012.c) |
| `HAL_MPU_SetAddressRange` | [001](MPU_IT_DRV_001.c)、[002](MPU_IT_DRV_002.c)、[003](MPU_IT_DRV_003.c)、[004](MPU_IT_DRV_004.c)、[005](MPU_IT_DRV_005.c)、[006](MPU_IT_DRV_006.c)、[007](MPU_IT_DRV_007.c)、[008](MPU_IT_DRV_008.c)、[009](MPU_IT_DRV_009.c)、[010](MPU_IT_DRV_010.c)、[011](MPU_IT_DRV_011.c) |
| `HAL_MPU_StructInit` | [011](MPU_IT_DRV_011.c)、[012](MPU_IT_DRV_012.c) |
| `HAL_MPU_WriteProtectCmd` | [004](MPU_IT_DRV_004.c)、[006](MPU_IT_DRV_006.c)、[007](MPU_IT_DRV_007.c)、[009](MPU_IT_DRV_009.c)、[011](MPU_IT_DRV_011.c) |
| `IS_MPU_CHANNEL` | [011](MPU_IT_DRV_011.c) |
| `IS_MPU_ENABLE_STATE` | [011](MPU_IT_DRV_011.c) |
| `IS_MPU_INSTANCE` | [011](MPU_IT_DRV_011.c) |
| `IS_MPU_WP_INSTANCE` | [011](MPU_IT_DRV_011.c) |
| `MPU_LockHandle` | [011](MPU_IT_DRV_011.c) |
| `MPU_UnlockHandle` | [011](MPU_IT_DRV_011.c) |
| `__HAL_MPU_RESET_HANDLE_STATE` | [011](MPU_IT_DRV_011.c) |

