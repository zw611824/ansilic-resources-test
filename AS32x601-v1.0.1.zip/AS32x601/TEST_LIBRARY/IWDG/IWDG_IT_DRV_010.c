/**
 * @file    IWDG_IT_DRV_010.c
 * @brief   HAL IWDG integration test case 010 (full API self check).
 *
 * Extension case of the suite: it covers the interfaces and the semantics
 * that the nine reference cases of the vendor never touch. Only HAL library
 * APIs are used.
 *
 * Tested functionality:
 *   HAL_IWDG_Init()            (metafields, value ranges, reserved words)
 *   HAL_IWDG_Cmd() / HAL_IWDG_LockCmd()   (selectors, FunctionalState)
 *   HAL_IWDG_Refresh() / HAL_IWDG_GetCounter()
 *   HAL_IWDG_GetState() / HAL_IWDG_GetError()
 *   IWDG_HandleIsValid() / IWDG_CheckState() / IWDG_LockHandle() / IWDG_UnlockHandle()
 *   IS_IWDG_* validation macros, IWDG_LOCK_TIMEOUT_DEFAULT
 *   __HAL_IWDG_START / __HAL_IWDG_RELOAD_COUNTER / __HAL_IWDG_GET_COUNTER /
 *   __HAL_IWDG_RESET_HANDLE_STATE
 *
 * Test procedure:
 *   The case never lets the watchdog reach its timeout: the valid
 *   configuration used here is PSC 255 / DIV 65535 / BVAL 65535 (about
 *   33500 s) and the configuration block is stopped again right after the
 *   exported start macro is exercised. It checks, in this order:
 *     1. the exported constant and the truth table of the validation macros;
 *     2. the NULL handle and invalid instance protection of every entry;
 *     3. the run time validation of the configuration (Size, Version, the two
 *        reserved words, the prescaler / divider / reload ranges), including
 *        the proof that a rejected call touches no register and no state;
 *     4. a valid initialization: readback, state, error code, counter and
 *        refresh;
 *     5. invalid selectors, an invalid FunctionalState and the four block
 *        enable / write protection combinations;
 *     6. the shared helpers (handle validity, state gate, bare metal lock);
 *     7. the four exported macros.
 *
 * Expected behaviour:
 *   every rejection returns HAL_ERROR with HAL_IWDG_ERROR_INVALID_PARAM and
 *   leaves the registers and the state untouched, every accepted call returns
 *   HAL_OK, and every check prints [PASS] with "summary : failures = 0".
 *
 * Note:
 *   This case does not need the FCU, the marker pin or the console clock tree
 *   beyond the console itself, and it can be run repeatedly.
 */

/* Includes ------------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
#define TEST_BAUDRATE                 (115200U)   /*!< console baud rate         */
#define TEST_PD4_PORT                 GPIOD       /*!< marker pin port (PD4)     */
#define TEST_PD4_PIN                  GPIO_PIN_4  /*!< marker pin of the case    */
#define TEST_PD4_ON                   GPIO_PIN_SET
#define TEST_PD4_OFF                  GPIO_PIN_RESET
#define TEST_WAIT_SLACK_MS            (500U)      /*!< extra budget on top of the
                                                       expected alarm time       */
#define TEST_CLOCK_HZ                 (32768U)    /*!< IWDG clock (APB_BusS)    */
#define TEST_STALL_WINDOW_MS          (100U)      /*!< observation window of the
                                                       counter movement checks   */
#define TEST_LONG_PRESCALER           (0xFFU)     /*!< PSC.PSCNUM (long)        */
#define TEST_LONG_DIVIDER             (0xFFFFU)   /*!< DIV.DIVNUM (long)        */
#define TEST_LONG_TIMEOUT             (0xFFFFU)   /*!< TO.BVAL (long)           */

/* Private variables ---------------------------------------------------------*/
static volatile uint32        check_failures = 0U;  /*!< failed check counter */
static uint32                lock_supported = 0U;  /*!< PSC.LOCK / CFG.LOCK implemented? */
static HAL_SMU_HandleTypeDef  hsmu_clk;             /*!< SMU handle           */
static HAL_PMU_HandleTypeDef  hpmu_dev;             /*!< PMU handle           */

IWDG_HandleTypeDef     hiwdg_dev;                   /*!< device under test     */
HAL_FCU_HandleTypeDef  hfcu_dev;                    /*!< alarm / reset source  */

/* Shared helpers of this suite (defined at the end of this file) */
void Check(const char *name, uint32 condition);
void Test_WatchdogQuiesce(void);
void Summary(void);
void SystemClock_Init(void);
HAL_StatusTypeDef Test_IwdgApply(uint32 prescaler, uint32 divider,
                                 uint32 timeout_value);

/**
 * @brief  Fill the configuration structure with a valid, very long timeout.
 * @note   PSC 255 / DIV 65535 / BVAL 65535 gives about 33500 s, so a mistake in
 *         this case can never reset the system.
 * @param  None
 * @retval None
 */
void Test_IwdgFillValid(void)
{
    hiwdg_dev.Instance         = IWDG;
    hiwdg_dev.Init.Size        = (uint32)sizeof(IWDG_InitTypeDef);
    hiwdg_dev.Init.Version     = IWDG_INIT_VERSION;
    hiwdg_dev.Init.Prescaler   = TEST_LONG_PRESCALER;
    hiwdg_dev.Init.Divider     = TEST_LONG_DIVIDER;
    hiwdg_dev.Init.Reload      = TEST_LONG_TIMEOUT;
    hiwdg_dev.Init.Reserved[0] = 0U;
    hiwdg_dev.Init.Reserved[1] = 0U;
}

/**
 * @brief  Put the watchdog into a known stopped state.
 * @note   The IWDG lives in the always-on domain: CFG.EN survives ndmreset and
 *         a restart from the reset vector, so an image that was armed when the
 *         previous run ended keeps the block running (and would keep resetting
 *         the chip). The cases assert the stopped state right after their own
 *         initialization, so the block is quiesced once at start up.
 * @note   The register is written directly: the handle is not initialized yet,
 *         so HAL_IWDG_Cmd() would be refused by the state gate.
 * @param  None
 * @retval None
 */
void Test_WatchdogQuiesce(void)
{
    WRITE_REG(IWDG->CFG, 0U);
    WRITE_REG(IWDG->PSC, 0U);
    WRITE_REG(IWDG->DIV, 0U);
    WRITE_REG(IWDG->TO, 0U);
}

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    /* A running watchdog left behind by the previous run would reset the chip
     * here and would make the "block is stopped" checks below fail */
    Test_WatchdogQuiesce();
    IWDG_HandleTypeDef bad;
    IWDG_HandleTypeDef local;
    HAL_StatusTypeDef  status;
    uint32             rounds = 0U;
    uint32             psc_snapshot;
    uint32             div_snapshot;
    uint32             to_snapshot;

    HAL_Init();
    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== IWDG_IT_DRV_010 : full API self check ===\r\n");
    printf("IWDG clock = %u Hz (configured with a 33500 s timeout, so the block "
           "can be started and stopped safely)\r\n", PRINT_U32(TEST_CLOCK_HZ));

    __HAL_CLEAR_STRUCT(&hiwdg_dev);

    for (;;)
    {
        printf("-- round %u --\r\n", PRINT_U32(rounds));

        /* ---------------- constants and validation macros ---------------- */
        Check("api       : IWDG_LOCK_TIMEOUT_DEFAULT is 10 ms",
              (IWDG_LOCK_TIMEOUT_DEFAULT == 10U) ? 1U : 0U);
        Check("api       : IS_IWDG_PRESCALER accepts 2 .. 255",
              (IS_IWDG_PRESCALER(2U) && IS_IWDG_PRESCALER(255U) &&
               !IS_IWDG_PRESCALER(1U) && !IS_IWDG_PRESCALER(256U)) ? 1U : 0U);
        Check("api       : IS_IWDG_RELOAD accepts 0 .. 65535",
              (IS_IWDG_RELOAD(0U) && IS_IWDG_RELOAD(0xFFFFU) &&
               !IS_IWDG_RELOAD(0x10000U)) ? 1U : 0U);
        Check("api       : IS_IWDG_DIVIDER accepts 2 .. 65535",
              (IS_IWDG_DIVIDER(2U) && IS_IWDG_DIVIDER(0xFFFFU) &&
               !IS_IWDG_DIVIDER(1U)) ? 1U : 0U);
        Check("api       : IS_IWDG_EN / IS_IWDG_LOCK keep the two selector sets apart",
              (IS_IWDG_EN(IWDG_EN_PSC) && IS_IWDG_EN(IWDG_EN_CFG) &&
               !IS_IWDG_EN(IWDG_LOCK_PSC) && IS_IWDG_LOCK(IWDG_LOCK_PSC) &&
               IS_IWDG_LOCK(IWDG_LOCK_CFG) && !IS_IWDG_LOCK(IWDG_EN_CFG)) ? 1U : 0U);

        /* ---------------- invalid handles ---------------- */
        Check("api       : HAL_IWDG_Init(NULL) is rejected",
              (HAL_IWDG_Init(NULL_PTR) == HAL_ERROR) ? 1U : 0U);
        Check("api       : HAL_IWDG_Refresh(NULL) is rejected",
              (HAL_IWDG_Refresh(NULL_PTR) == HAL_ERROR) ? 1U : 0U);
        Check("api       : HAL_IWDG_Cmd(NULL) is rejected",
              (HAL_IWDG_Cmd(NULL_PTR, IWDG_EN_CFG, ENABLE) == HAL_ERROR) ? 1U : 0U);
        Check("api       : HAL_IWDG_LockCmd(NULL) is rejected",
              (HAL_IWDG_LockCmd(NULL_PTR, IWDG_LOCK_CFG, ENABLE) == HAL_ERROR) ? 1U : 0U);
        Check("api       : the read-only queries survive a NULL handle",
              ((HAL_IWDG_GetCounter(NULL_PTR) == 0U) &&
               (HAL_IWDG_GetState(NULL_PTR) == HAL_IWDG_STATE_RESET) &&
               (HAL_IWDG_GetError(NULL_PTR) == HAL_IWDG_ERROR_NONE)) ? 1U : 0U);

        /* An instance that is not the IWDG must be rejected as well */
        __HAL_CLEAR_STRUCT(&bad);
        bad.Instance = (IWDG_TypeDef *)0x40000000U;
        Test_IwdgFillValid();
        bad.Init = hiwdg_dev.Init;
        Check("api       : an invalid instance is rejected by every entry",
              ((HAL_IWDG_Init(&bad) == HAL_ERROR) &&
               (HAL_IWDG_Refresh(&bad) == HAL_ERROR) &&
               (HAL_IWDG_Cmd(&bad, IWDG_EN_CFG, ENABLE) == HAL_ERROR) &&
               (HAL_IWDG_LockCmd(&bad, IWDG_LOCK_CFG, ENABLE) == HAL_ERROR)) ? 1U : 0U);

        /* ---------------- run time configuration validation ---------------- */
        psc_snapshot = READ_REG(IWDG->PSC);
        div_snapshot = READ_REG(IWDG->DIV);
        to_snapshot  = READ_REG(IWDG->TO);

        Test_IwdgFillValid();
        hiwdg_dev.Init.Size = (uint32)sizeof(IWDG_InitTypeDef) - 4U;
        hiwdg_dev.ErrorCode = HAL_IWDG_ERROR_NONE;
        Check("api       : a wrong Size is rejected",
              (HAL_IWDG_Init(&hiwdg_dev) == HAL_ERROR) ? 1U : 0U);
        Check("api       : a wrong Size reports INVALID_PARAM",
              ((HAL_IWDG_GetError(&hiwdg_dev) & HAL_IWDG_ERROR_INVALID_PARAM) != 0U) ? 1U : 0U);

        Test_IwdgFillValid();
        hiwdg_dev.Init.Version = IWDG_INIT_VERSION + 1U;
        hiwdg_dev.ErrorCode = HAL_IWDG_ERROR_NONE;
        Check("api       : a wrong Version is rejected",
              (HAL_IWDG_Init(&hiwdg_dev) == HAL_ERROR) ? 1U : 0U);
        Check("api       : a wrong Version reports INVALID_PARAM",
              ((HAL_IWDG_GetError(&hiwdg_dev) & HAL_IWDG_ERROR_INVALID_PARAM) != 0U) ? 1U : 0U);

        Test_IwdgFillValid();
        hiwdg_dev.Init.Reserved[0] = 1U;
        hiwdg_dev.ErrorCode = HAL_IWDG_ERROR_NONE;
        Check("api       : a non zero Reserved[0] is rejected",
              (HAL_IWDG_Init(&hiwdg_dev) == HAL_ERROR) ? 1U : 0U);
        Check("api       : a non zero Reserved[0] reports INVALID_PARAM",
              ((HAL_IWDG_GetError(&hiwdg_dev) & HAL_IWDG_ERROR_INVALID_PARAM) != 0U) ? 1U : 0U);

        Test_IwdgFillValid();
        hiwdg_dev.Init.Reserved[1] = 0x5A5A5A5AU;
        hiwdg_dev.ErrorCode = HAL_IWDG_ERROR_NONE;
        Check("api       : a non zero Reserved[1] is rejected",
              (HAL_IWDG_Init(&hiwdg_dev) == HAL_ERROR) ? 1U : 0U);
        Check("api       : a non zero Reserved[1] reports INVALID_PARAM",
              ((HAL_IWDG_GetError(&hiwdg_dev) & HAL_IWDG_ERROR_INVALID_PARAM) != 0U) ? 1U : 0U);

        Test_IwdgFillValid();
        hiwdg_dev.Init.Prescaler = 1U;
        hiwdg_dev.ErrorCode = HAL_IWDG_ERROR_NONE;
        Check("api       : Prescaler = 1 is rejected",
              (HAL_IWDG_Init(&hiwdg_dev) == HAL_ERROR) ? 1U : 0U);
        Check("api       : Prescaler = 1 reports INVALID_PARAM",
              ((HAL_IWDG_GetError(&hiwdg_dev) & HAL_IWDG_ERROR_INVALID_PARAM) != 0U) ? 1U : 0U);

        Test_IwdgFillValid();
        hiwdg_dev.Init.Prescaler = 256U;
        hiwdg_dev.ErrorCode = HAL_IWDG_ERROR_NONE;
        Check("api       : Prescaler = 256 is rejected",
              (HAL_IWDG_Init(&hiwdg_dev) == HAL_ERROR) ? 1U : 0U);
        Check("api       : Prescaler = 256 reports INVALID_PARAM",
              ((HAL_IWDG_GetError(&hiwdg_dev) & HAL_IWDG_ERROR_INVALID_PARAM) != 0U) ? 1U : 0U);

        Test_IwdgFillValid();
        hiwdg_dev.Init.Divider = 1U;
        hiwdg_dev.ErrorCode = HAL_IWDG_ERROR_NONE;
        Check("api       : Divider = 1 is rejected",
              (HAL_IWDG_Init(&hiwdg_dev) == HAL_ERROR) ? 1U : 0U);
        Check("api       : Divider = 1 reports INVALID_PARAM",
              ((HAL_IWDG_GetError(&hiwdg_dev) & HAL_IWDG_ERROR_INVALID_PARAM) != 0U) ? 1U : 0U);

        Test_IwdgFillValid();
        hiwdg_dev.Init.Divider = 0x10000U;
        hiwdg_dev.ErrorCode = HAL_IWDG_ERROR_NONE;
        Check("api       : Divider = 65536 is rejected",
              (HAL_IWDG_Init(&hiwdg_dev) == HAL_ERROR) ? 1U : 0U);
        Check("api       : Divider = 65536 reports INVALID_PARAM",
              ((HAL_IWDG_GetError(&hiwdg_dev) & HAL_IWDG_ERROR_INVALID_PARAM) != 0U) ? 1U : 0U);

        Test_IwdgFillValid();
        hiwdg_dev.Init.Reload = 0x10000U;
        hiwdg_dev.ErrorCode = HAL_IWDG_ERROR_NONE;
        Check("api       : Reload = 65536 is rejected",
              (HAL_IWDG_Init(&hiwdg_dev) == HAL_ERROR) ? 1U : 0U);
        Check("api       : Reload = 65536 reports INVALID_PARAM",
              ((HAL_IWDG_GetError(&hiwdg_dev) & HAL_IWDG_ERROR_INVALID_PARAM) != 0U) ? 1U : 0U);

        Check("api       : no rejected call touched a configuration register",
              ((READ_REG(IWDG->PSC) == psc_snapshot) &&
               (READ_REG(IWDG->DIV) == div_snapshot) &&
               (READ_REG(IWDG->TO) == to_snapshot)) ? 1U : 0U);
        Check("api       : no rejected call changed the handle state",
              (HAL_IWDG_GetState(&hiwdg_dev) == HAL_IWDG_STATE_RESET) ? 1U : 0U);

        /* ---------------- a valid initialization ---------------- */
        hiwdg_dev.ErrorCode = HAL_IWDG_ERROR_NONE;
        status = Test_IwdgApply(TEST_LONG_PRESCALER, TEST_LONG_DIVIDER, TEST_LONG_TIMEOUT);
        Check("api       : a valid configuration is accepted", (status == HAL_OK) ? 1U : 0U);
        Check("api       : the handle is READY and the error code is clean",
              ((HAL_IWDG_GetState(&hiwdg_dev) == HAL_IWDG_STATE_READY) &&
               (HAL_IWDG_GetError(&hiwdg_dev) == HAL_IWDG_ERROR_NONE)) ? 1U : 0U);
        Check("api       : the initialization enables the prescaler block",
              ((READ_REG(IWDG->PSC) & IWDG_PSC_EN) != 0U) ? 1U : 0U);
        Check("api       : the initialization does not start the watchdog",
              ((READ_REG(IWDG->CFG) & IWDG_CFG_EN) == 0U) ? 1U : 0U);
        Check("api       : HAL_IWDG_GetCounter() matches the exported macro",
              (HAL_IWDG_GetCounter(&hiwdg_dev) ==
               __HAL_IWDG_GET_COUNTER(&hiwdg_dev)) ? 1U : 0U);
        Check("api       : HAL_IWDG_Refresh() is accepted in the READY state",
              (HAL_IWDG_Refresh(&hiwdg_dev) == HAL_OK) ? 1U : 0U);

        /* ---------------- invalid selectors and states ---------------- */
        hiwdg_dev.ErrorCode = HAL_IWDG_ERROR_NONE;
        Check("api       : a lock selector is rejected by HAL_IWDG_Cmd()",
              ((HAL_IWDG_Cmd(&hiwdg_dev, IWDG_LOCK_PSC, ENABLE) == HAL_ERROR) &&
               ((HAL_IWDG_GetError(&hiwdg_dev) & HAL_IWDG_ERROR_INVALID_PARAM) != 0U)) ? 1U : 0U);
        hiwdg_dev.ErrorCode = HAL_IWDG_ERROR_NONE;
        Check("api       : an enable selector is rejected by HAL_IWDG_LockCmd()",
              ((HAL_IWDG_LockCmd(&hiwdg_dev, IWDG_EN_CFG, ENABLE) == HAL_ERROR) &&
               ((HAL_IWDG_GetError(&hiwdg_dev) & HAL_IWDG_ERROR_INVALID_PARAM) != 0U)) ? 1U : 0U);
        Check("api       : an invalid FunctionalState is rejected by both calls",
              ((HAL_IWDG_Cmd(&hiwdg_dev, IWDG_EN_CFG, (FunctionalState)2) == HAL_ERROR) &&
               (HAL_IWDG_LockCmd(&hiwdg_dev, IWDG_LOCK_CFG, (FunctionalState)2) == HAL_ERROR)) ? 1U : 0U);

        /* ---------------- block enables and write protection ---------------- */
        Check("api       : IWDG_EN_PSC / DISABLE clears PSC.EN",
              (((HAL_IWDG_Cmd(&hiwdg_dev, IWDG_EN_PSC, DISABLE) == HAL_OK) &&
                ((READ_REG(IWDG->PSC) & IWDG_PSC_EN) == 0U)) ? 1U : 0U));
        Check("api       : IWDG_EN_PSC / ENABLE sets PSC.EN",
              (((HAL_IWDG_Cmd(&hiwdg_dev, IWDG_EN_PSC, ENABLE) == HAL_OK) &&
                ((READ_REG(IWDG->PSC) & IWDG_PSC_EN) != 0U)) ? 1U : 0U));
        lock_supported = ((HAL_IWDG_LockCmd(&hiwdg_dev, IWDG_LOCK_PSC, ENABLE) == HAL_OK) &&
                          ((READ_REG(IWDG->PSC) & IWDG_PSC_LOCK) != 0U)) ? 1U : 0U;
        if (lock_supported != 0U)
        {
            Check("api       : IWDG_LOCK_PSC sets and clears PSC.LOCK",
                  (((HAL_IWDG_LockCmd(&hiwdg_dev, IWDG_LOCK_PSC, DISABLE) == HAL_OK) &&
                    ((READ_REG(IWDG->PSC) & IWDG_PSC_LOCK) == 0U)) ? 1U : 0U));
            Check("api       : IWDG_LOCK_CFG sets and clears CFG.LOCK",
                  (((HAL_IWDG_LockCmd(&hiwdg_dev, IWDG_LOCK_CFG, ENABLE) == HAL_OK) &&
                    ((READ_REG(IWDG->CFG) & IWDG_CFG_LOCK) != 0U) &&
                    (HAL_IWDG_LockCmd(&hiwdg_dev, IWDG_LOCK_CFG, DISABLE) == HAL_OK) &&
                    ((READ_REG(IWDG->CFG) & IWDG_CFG_LOCK) == 0U)) ? 1U : 0U));
        }
        else
        {
            /* PSC.LOCK / CFG.LOCK are not implemented on this silicon: the
             * selectors are still accepted, the bits simply do not stick. */
            Check("api       : IWDG_LOCK_PSC / CFG are accepted (LOCK not implemented)",
                  (((HAL_IWDG_LockCmd(&hiwdg_dev, IWDG_LOCK_PSC, ENABLE) == HAL_OK) &&
                    (HAL_IWDG_LockCmd(&hiwdg_dev, IWDG_LOCK_CFG, ENABLE) == HAL_OK)) ? 1U : 0U));
            Check("api       : neither lock bit is implemented (both read back 0)",
                  (((READ_REG(IWDG->PSC) & IWDG_PSC_LOCK) == 0U) &&
                   ((READ_REG(IWDG->CFG) & IWDG_CFG_LOCK) == 0U)) ? 1U : 0U);
            (void)HAL_IWDG_LockCmd(&hiwdg_dev, IWDG_LOCK_PSC, DISABLE);
            (void)HAL_IWDG_LockCmd(&hiwdg_dev, IWDG_LOCK_CFG, DISABLE);
        }

        /* ---------------- shared helpers ---------------- */
        Check("api       : IWDG_HandleIsValid() recognises a valid handle only",
              ((IWDG_HandleIsValid(&hiwdg_dev) != 0U) &&
               (IWDG_HandleIsValid(NULL_PTR) == 0U) &&
               (IWDG_HandleIsValid(&bad) == 0U)) ? 1U : 0U);

        Check("api       : IWDG_CheckState() accepts a READY handle",
              (IWDG_CheckState(&hiwdg_dev) == HAL_OK) ? 1U : 0U);
        hiwdg_dev.State = HAL_IWDG_STATE_ERROR;
        Check("api       : IWDG_CheckState() accepts a recoverable ERROR handle",
              (IWDG_CheckState(&hiwdg_dev) == HAL_OK) ? 1U : 0U);
        hiwdg_dev.State = HAL_IWDG_STATE_BUSY;
        Check("api       : IWDG_CheckState() rejects a BUSY handle",
              (IWDG_CheckState(&hiwdg_dev) == HAL_BUSY) ? 1U : 0U);
        hiwdg_dev.State = HAL_IWDG_STATE_RESET;
        Check("api       : IWDG_CheckState() rejects an uninitialized handle",
              (IWDG_CheckState(&hiwdg_dev) == HAL_ERROR) ? 1U : 0U);

        /* restore a READY handle through the public API */
        hiwdg_dev.State = HAL_IWDG_STATE_READY;
        Check("api       : the bare metal lock helper serialises the handle",
              ((IWDG_LockHandle(&hiwdg_dev, IWDG_LOCK_TIMEOUT_DEFAULT) == HAL_OK) &&
               (IWDG_LockHandle(&hiwdg_dev, IWDG_LOCK_TIMEOUT_DEFAULT) == HAL_BUSY)) ? 1U : 0U);
        IWDG_UnlockHandle(&hiwdg_dev);
        Check("api       : the handle can be taken again after the unlock",
              ((IWDG_LockHandle(&hiwdg_dev, IWDG_LOCK_TIMEOUT_DEFAULT) == HAL_OK)) ? 1U : 0U);
        IWDG_UnlockHandle(&hiwdg_dev);

        /* ---------------- exported macros ---------------- */
        __HAL_IWDG_RELOAD_COUNTER(&hiwdg_dev);
        Check("api       : __HAL_IWDG_RELOAD_COUNTER() restarts the counter",
              (__HAL_IWDG_GET_COUNTER(&hiwdg_dev) == 0U) ? 1U : 0U);
        __HAL_IWDG_START(&hiwdg_dev);
        Check("api       : __HAL_IWDG_START() sets CFG.EN",
              ((READ_REG(IWDG->CFG) & IWDG_CFG_EN) != 0U) ? 1U : 0U);
        (void)HAL_IWDG_Cmd(&hiwdg_dev, IWDG_EN_CFG, DISABLE);
        Check("api       : the watchdog is stopped again",
              ((READ_REG(IWDG->CFG) & IWDG_CFG_EN) == 0U) ? 1U : 0U);

        __HAL_CLEAR_STRUCT(&local);
        local.State = HAL_IWDG_STATE_BUSY;
        __HAL_IWDG_RESET_HANDLE_STATE(&local);
        Check("api       : __HAL_IWDG_RESET_HANDLE_STATE() clears the state",
              (local.State == HAL_IWDG_STATE_RESET) ? 1U : 0U);

        /* ---------------- clean up ---------------- */
        hiwdg_dev.State = HAL_IWDG_STATE_READY;
        (void)HAL_IWDG_Cmd(&hiwdg_dev, IWDG_EN_CFG, DISABLE);
        (void)HAL_IWDG_LockCmd(&hiwdg_dev, IWDG_LOCK_PSC, DISABLE);
        (void)HAL_IWDG_LockCmd(&hiwdg_dev, IWDG_LOCK_CFG, DISABLE);
        /* The rejection block above expects an uninitialized handle, so every
         * round has to leave the handle the way the first round found it (the
         * HAL_IWDG_Init() of this round published READY). */
        __HAL_IWDG_RESET_HANDLE_STATE(&hiwdg_dev);
        Check("api       : the watchdog is left stopped and unlocked",
              (((READ_REG(IWDG->CFG) & IWDG_CFG_EN) == 0U) &&
               ((READ_REG(IWDG->PSC) & IWDG_PSC_LOCK) == 0U) &&
               ((READ_REG(IWDG->CFG) & IWDG_CFG_LOCK) == 0U)) ? 1U : 0U);

        Summary();
        rounds++;
        delay_ms(2000U);
    }
}

/* ==========================================================================*/
/*  Shared helpers of the suite (identical in every case of this suite)       */
/* ==========================================================================*/

/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the other integration tests of this library:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2 and
 *         CANX2 by 8, which gives core 180 MHz and APB 22.5 MHz. The IWDG is
 *         clocked from the always-on APB_BusS domain (32768 Hz), so this tree
 *         only supplies the console, the delay module and the marker pin.
 * @note   Clock tree order: the dividers are written while the system clock
 *         is still the power on source (FIRC), then the PLL is configured and
 *         the system clock is switched to it. That last call programs the
 *         flash controller clock before the switch (the core keeps fetching
 *         from the flash) and updates SystemCoreClock afterwards.
 * @param  None
 * @retval None
 */
void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks (console pins of USART0 and the PD4 marker pin) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu_dev);
    hpmu_dev.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu_dev);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu_dev, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu_dev, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* The SMU is in the always-on domain: the clock tree of the previous image
     * (or of the flash programmer) survives ndmreset and a restart from the
     * reset vector. Put it back into its power-on shape first, so that the
     * configuration below is applied to a known state - otherwise the PLL is
     * found enabled, the feedback divider of this configuration is ignored, and
     * the console ends up at the wrong baud rate. HAL_SMU_DeInit() is the
     * driver's own sequence for that: it switches the core to the FIRC,
     * reprograms the flash wait states with the CLK_UPDATE handshake and holds
     * the PLL in reset. */
    (void)HAL_SMU_DeInit(&hsmu_clk, SMU_TIMEOUT_DEFAULT);
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Metafields of the two configuration structures (Version+Size contract,
     * same discipline as the IWDG configuration below). The business fields are
     * overwritten one by one, everything else must start at zero. */
    __HAL_CLEAR_STRUCT(&SMU_OscInitStruct);
    SMU_OscInitStruct.Size    = (uint32)sizeof(SMU_OscInitTypeDef);
    SMU_OscInitStruct.Version = SMU_OSC_INIT_VERSION;
    __HAL_CLEAR_STRUCT(&SMU_ClockInitStruct);
    SMU_ClockInitStruct.Size    = (uint32)sizeof(SMU_ClockInitTypeDef);
    SMU_ClockInitStruct.Version = SMU_CLOCK_INIT_VERSION;

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.Size             = (uint32)sizeof(SMU_PLLConfigTypeDef);
    SMU_OscInitStruct.PLL.Version          = SMU_PLL_INIT_VERSION;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Program the watchdog through HAL_IWDG_Init().
 * @note   The driver has no HAL_IWDG_StructInit(): the configuration
 *         structure follows the Version+Size mechanism, so the metafields are
 *         filled here (the business fields are overwritten on every call).
 *         HAL_IWDG_Init() enables the prescaler block (PSC.EN) and never
 *         starts the watchdog (CFG.EN stays untouched).
 * @param  prescaler:     PSC.PSCNUM value (2..255)
 * @param  divider:       DIV.DIVNUM value (2..65535)
 * @param  timeout_value: TO.BVAL value (0..65535)
 * @retval HAL_StatusTypeDef of HAL_IWDG_Init()
 */
HAL_StatusTypeDef Test_IwdgApply(uint32 prescaler, uint32 divider,
                                 uint32 timeout_value)
{
    hiwdg_dev.Instance         = IWDG;
    hiwdg_dev.Init.Size        = (uint32)sizeof(IWDG_InitTypeDef);
    hiwdg_dev.Init.Version     = IWDG_INIT_VERSION;
    hiwdg_dev.Init.Prescaler   = prescaler;
    hiwdg_dev.Init.Reload      = timeout_value;
    hiwdg_dev.Init.Divider     = divider;
    hiwdg_dev.Init.Reserved[0] = 0U;
    hiwdg_dev.Init.Reserved[1] = 0U;

    return HAL_IWDG_Init(&hiwdg_dev);
}

/*****END OF FILE*****/
