# USART 应用与测试参考

用于按需求检索 AS32x601 HAL 串口示例。关键词：USART、UART、阻塞、轮询、中断、DMA、波特率、数据位、停止位、校验、RTS、CTS、同步、主机、从机、FIFO、回调。


## 实例与可选引脚

下表列出 AS32x601 LQFP144 封装的本外设信号。每根信号单独选择引脚，并核对 [GPIO AF 定义](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_gpio.h)；文档功能编号不能直接当作 HAL 编码传入。其他封装需另查引出情况。

| 信号 | 可选引脚 | 封装脚号 | 文档功能 | HAL AF |
|---|---|---|---|---|
| `USART0_CTS` | PD10 | 59 | 功能1 | `GPIO_AF_USART0`（0x02） |
| `USART0_RTS` | PD11 | 58 | 功能1 | `GPIO_AF_USART0`（0x02） |
| `USART0_RX` | PD9 | 60 | 功能1 | `GPIO_AF_USART0`（0x02） |
| `USART0_SCK` | PD12 | 57 | 功能1 | `GPIO_AF_USART0`（0x02） |
| `USART0_TX` | PD8 | 61 | 功能1 | `GPIO_AF_USART0`（0x02） |
| `USART1_CTS` | PH3 | 75 | 功能3 | `GPIO_AF_USART1`（0x04） |
| `USART1_RTS` | PH4 | 72 | 功能3 | `GPIO_AF_USART1`（0x04） |
| `USART1_RX` | PH2 | 76 | 功能3 | `GPIO_AF_USART1`（0x04） |
| `USART1_SCK` | PH5 | 71 | 功能3 | `GPIO_AF_USART1`（0x04） |
| `USART1_TX` | PD15 | 54 | 功能3 | `GPIO_AF_USART1`（0x04） |
| `USART2_CTS` | PA8 | 40 | 功能1 | `GPIO_AF_USART2`（0x02） |
| `USART2_RTS` | PA9 | 39 | 功能1 | `GPIO_AF_USART2`（0x02） |
| `USART2_RX` | PH9 | 67 | 功能1 | `GPIO_AF_USART2`（0x02） |
| `USART2_SCK` | PA10 | 38 | 功能1 | `GPIO_AF_USART2`（0x02） |
| `USART2_TX` | PC9 | 41 | 功能1 | `GPIO_AF_USART2`（0x02） |
| `USART3_CTS` | PA13 | 35 | 功能1 | `GPIO_AF_USART3`（0x02） |
| `USART3_RTS` | PA14 | 34 | 功能1 | `GPIO_AF_USART3`（0x02） |
| `USART3_RX` | PA12 | 36 | 功能1 | `GPIO_AF_USART3`（0x02） |
| `USART3_SCK` | PA15 | 33 | 功能1 | `GPIO_AF_USART3`（0x02） |
| `USART3_TX` | PA11 | 37 | 功能1 | `GPIO_AF_USART3`（0x02） |
| `USART4_CTS` | PG3 | 52 | 功能1 | `GPIO_AF_USART4`（0x02） |
| `USART4_RTS` | PG4 | 51 | 功能1 | `GPIO_AF_USART4`（0x02） |
| `USART4_RX` | PG2 | 53 | 功能1 | `GPIO_AF_USART4`（0x02） |
| `USART4_SCK` | PG5 | 50 | 功能1 | `GPIO_AF_USART4`（0x02） |
| `USART4_TX` | PH8 | 68 | 功能1 | `GPIO_AF_USART4`（0x02） |
| `USART5_CTS` | PG14 | 14 | 功能3 | `GPIO_AF_USART5`（0x04） |
| `USART5_RTS` | PG15 | 13 | 功能3 | `GPIO_AF_USART5`（0x04） |
| `USART5_RX` | PG13 | 15 | 功能3 | `GPIO_AF_USART5`（0x04） |
| `USART5_SCK` | PB3 | 12 | 功能3 | `GPIO_AF_USART5`（0x04） |
| `USART5_TX` | PG12 | 16 | 功能3 | `GPIO_AF_USART5`（0x04） |
| `USART6_CTS` | PE2 | 123 | 功能2 | `GPIO_AF_USART6`（0x03） |
| `USART6_RTS` | PB8 | 6 | 功能2 | `GPIO_AF_USART6`（0x03） |
| `USART6_RX` | PE1 | 64 | 功能2 | `GPIO_AF_USART6`（0x03） |
| `USART6_SCK` | PB9 | 5 | 功能2 | `GPIO_AF_USART6`（0x03） |
| `USART6_TX` | PE0 | 63 | 功能2 | `GPIO_AF_USART6`（0x03） |
| `USART7_CTS` | PC4 | 118 | 功能2 | `GPIO_AF_USART7`（0x03） |
| `USART7_RTS` | PC5 | 116 | 功能2 | `GPIO_AF_USART7`（0x03） |
| `USART7_SCK` | PB0 | 114 | 功能2 | `GPIO_AF_USART7`（0x03） |
| `USART7_TX` | PA6 | 103 | 功能2 | `GPIO_AF_USART7`（0x03） |

候选引脚不代表已验证的接线组合。实例、通道与路由约束按当前驱动和手册核对；同一引脚的其他功能须检查资源冲突。案例配置见下文。

## 生成前需确认的参数

已有工程、板级资料或用户已明确的值直接复用。仅对影响本次实现的缺失选择使用参数卡询问并等待答复；案例配置不能代替实际接线或应用参数。

| 参数 | 需要核对或确认的内容 |
|---|---|
| 实例与接线 | USART 实例、TX/RX、AF，按需确认 RTS/CTS 或同步时钟 |
| 通信参数 | 对端波特率、帧格式、流控及物理接口电平 |
| 数据用途 | 日志输出、协议通信、收发模式及接收帧结束条件 |

## 用于应用生成的入口

当前 USART 案例位于 `USART/`。本文件负责选例与使用边界，不是独立应用工程或验证报告。

按“实例与引脚 → 参数确认 → 按需求选择 → 选中源码与 HAL → 应用迁移”阅读；查特定调用时再查接口索引。

- HAL 依据：[USART 头文件](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_usart.h)、[USART 实现](../../HAL_LIBRARY/peripherals/src/as32x601_hal_usart.c)；DMA 模式还需核对 DMA 驱动和真实请求映射。
- 辅助依赖：抽查的 004 等案例引用 `as32x601_delay.h`、`as32x601_print.h`；对应源码已从 HAL 参考工程复制到 [HAL_LIBRARY/utils](../../HAL_LIBRARY/utils/README.md)。使用前仍须确认工具链、配置、时钟、串口和其他依赖；已有工程优先复用现有实现，避免重复定义。
- “实例与可选引脚”列芯片资料映射，“案例实际配置”列测试接线。未指定实例时可用 001～006 理解流程，但不能据此默认替客户选择 USART7 或 PA6/PA7。

### 从案例迁移为应用

1. 确认实例、引脚、通信参数、收发模式、帧边界、吞吐与时延要求，再检查日志串口、DMA 通道及其他外设冲突。
2. 把必要初始化、收发和状态访问封装到 `Bsp/uart.c / uart.h` 或已有模块；句柄/缓冲区的有效期须覆盖 IRQ 和 DMA 使用期间。
3. 业务逻辑放入按功能命名的 User 模块，如 `serial_protocol.c / serial_protocol.h` 对应 `Serial_Protocol_Process()`；不复制测试 main、PASS/FAIL、Summary、固定测试数据和等待日志。
4. 串口回调是 HAL 的全局入口，多个实例按句柄/Instance 分发，不能为每个模块重复定义同名回调；复用工程真实 IRQ 入口，不重写 TrapEntry。
5. 连续接收须明确接收完成后的处理与重新启动时机；004 是收满 8 字节完成，不是 IDLE 收帧，源码关于两者“等效”的历史说明不能用于推断任意长度协议。其打印、延时和重启间隔也不能直接当作无丢包方案。
6. 中断回显需结合 003 / 004 的接收和发送流程，另外处理忙状态、错误、队列及接收重启；不是把两个 main 拼接。发送完成前不改写发送缓冲，接收缓冲也不能在业务读取时被重新覆盖。
7. 非阻塞发送失败、接收错误和恢复路径按实际 HAL 能力实现，不虚构 Abort、ReceiveToIdle 或环形 DMA API。ISR 只做必要状态通知，格式化和业务处理留在主循环。

案例中的系统时钟、PMU、日志与测试延时按工程依赖取舍；不重复初始化已有资源。生成文件组织与命名遵循 `as32-peripheral-codegen` Skill。

## 按需求选择

按“用户想实现的行为 → 推荐源码 → 适用条件”选择。同一需求涉及多个功能时组合阅读相关用例，不直接拼接多个 `main()`。

| 用户需求 / 检索关键词 | 推荐用例 | 选择条件 / 需要补充的逻辑 |
|---|---|---|
| 发送固定字节；允许等待发送完成；轮询发送 | [001](USART_IT_DRV_001.c) | USART7 阻塞发送；适合学习基本初始化和发送流程 |
| 接收已知长度数据；允许阻塞等待 | [002](USART_IT_DRV_002.c) | 定长阻塞接收；核对超时及外部发送数据 |
| 发送期间继续处理其他任务；发送完成回调 | [003](USART_IT_DRV_003.c) | USART7 中断发送；缓冲区在完成前保持有效 |
| 中断接收固定长度数据；接收完成回调 | [004](USART_IT_DRV_004.c) | 不是不定长数据包模板；核对启动接收和完成标志 |
| DMA 发送数据；减少 CPU 搬运 | [005](USART_IT_DRV_005.c) | USART7 DMA 发送；同时参考 DMA 请求映射、通道和中断 |
| DMA 接收已知长度数据 | [006](USART_IT_DRV_006.c) | 定长 DMA 接收；不等于环形缓冲或空闲线收帧 |
| 9600 波特率发送 | [007](USART_IT_DRV_007.c) | 与外部设备匹配波特率 |
| 6 位数据发送 | [008](USART_IT_DRV_008.c) | 核对有效数据位与外部接收格式 |
| 7 位数据发送 | [009](USART_IT_DRV_009.c) | 核对有效数据位与外部接收格式 |
| 9 位数据发送 | [010](USART_IT_DRV_010.c) | 按 SDK 核对缓冲区元素宽度和长度语义 |
| 2 停止位发送 | [011](USART_IT_DRV_011.c) | 外部接收设备使用匹配停止位 |
| 奇校验发送 | [012](USART_IT_DRV_012.c) | 外部设备使用匹配校验和数据位 |
| 偶校验发送 | [013](USART_IT_DRV_013.c) | 外部设备使用匹配校验和数据位 |
| CTS 硬件流控发送 | [014](USART_IT_DRV_014.c) | 需要外部 CTS 握手信号 |
| RTS 硬件流控接收 | [015](USART_IT_DRV_015.c) | 需要对端配合 RTS 握手 |
| 同步 USART 主机发送；CPOL/CPHA=0/0 | [016](USART_IT_DRV_016.c) | 需匹配主从角色、时钟和接线；不是异步 UART 模板 |
| 同步 USART 主机接收；CPOL/CPHA=0/0 | [017](USART_IT_DRV_017.c) | 需匹配主从角色、时钟和接线；不是异步 UART 模板 |
| 同步 USART 从机发送；CPOL/CPHA=0/0 | [018](USART_IT_DRV_018.c) | 需匹配主从角色、时钟和接线；不是异步 UART 模板 |
| 同步 USART 从机接收；CPOL/CPHA=0/0 | [019](USART_IT_DRV_019.c) | 需匹配主从角色、时钟和接线；不是异步 UART 模板 |
| 同步 USART 主机发送；CPOL/CPHA=1/0 | [020](USART_IT_DRV_020.c) | 需匹配主从角色、时钟和接线；不是异步 UART 模板 |
| 同步 USART 主机发送；CPOL/CPHA=0/1 | [021](USART_IT_DRV_021.c) | 需匹配主从角色、时钟和接线；不是异步 UART 模板 |
| 同步 USART 主机发送；CPOL/CPHA=1/1 | [022](USART_IT_DRV_022.c) | 需匹配主从角色、时钟和接线；不是异步 UART 模板 |
| 指定 USART0：中断发送 | [023](USART_IT_DRV_023.c) | 按该实例的引脚、中断和 DMA 配置复用；注意与日志 USART0 共用外设 |
| 指定 USART0：中断接收 | [024](USART_IT_DRV_024.c) | 按该实例的引脚、中断和 DMA 配置复用；注意与日志 USART0 共用外设 |
| 指定 USART0：DMA 发送 | [025](USART_IT_DRV_025.c) | 按该实例的引脚、中断和 DMA 配置复用；注意与日志 USART0 共用外设 |
| 指定 USART0：DMA 接收 | [026](USART_IT_DRV_026.c) | 按该实例的引脚、中断和 DMA 配置复用；注意与日志 USART0 共用外设 |
| 指定 USART1：中断发送 | [027](USART_IT_DRV_027.c) | 按该实例的引脚、中断和 DMA 配置复用 |
| 指定 USART1：中断接收 | [028](USART_IT_DRV_028.c) | 按该实例的引脚、中断和 DMA 配置复用 |
| 指定 USART1：DMA 发送 | [029](USART_IT_DRV_029.c) | 按该实例的引脚、中断和 DMA 配置复用 |
| 指定 USART1：DMA 接收 | [030](USART_IT_DRV_030.c) | 按该实例的引脚、中断和 DMA 配置复用 |
| 指定 USART2：中断发送 | [031](USART_IT_DRV_031.c) | 按该实例的引脚、中断和 DMA 配置复用 |
| 指定 USART2：中断接收 | [032](USART_IT_DRV_032.c) | 按该实例的引脚、中断和 DMA 配置复用 |
| 指定 USART2：DMA 发送 | [033](USART_IT_DRV_033.c) | 按该实例的引脚、中断和 DMA 配置复用 |
| 指定 USART2：DMA 接收 | [034](USART_IT_DRV_034.c) | 按该实例的引脚、中断和 DMA 配置复用 |
| 指定 USART4：中断发送 | [035](USART_IT_DRV_035.c) | 按该实例的引脚、中断和 DMA 配置复用 |
| 指定 USART4：中断接收 | [036](USART_IT_DRV_036.c) | 按该实例的引脚、中断和 DMA 配置复用 |
| 指定 USART4：DMA 发送 | [037](USART_IT_DRV_037.c) | 按该实例的引脚、中断和 DMA 配置复用 |
| 指定 USART4：DMA 接收 | [038](USART_IT_DRV_038.c) | 按该实例的引脚、中断和 DMA 配置复用 |
| 指定 USART5：中断发送 | [039](USART_IT_DRV_039.c) | 按该实例的引脚、中断和 DMA 配置复用 |
| 指定 USART5：中断接收 | [040](USART_IT_DRV_040.c) | 按该实例的引脚、中断和 DMA 配置复用 |
| 指定 USART5：DMA 发送 | [041](USART_IT_DRV_041.c) | 按该实例的引脚、中断和 DMA 配置复用 |
| 指定 USART5：DMA 接收 | [042](USART_IT_DRV_042.c) | 按该实例的引脚、中断和 DMA 配置复用 |
| 双向传输 API；FIFO 阈值；DMA 暂停恢复停止；状态限制；参数检查；其他扩展接口 | [043](USART_IT_DRV_043.c) | 综合 API 检查，按接口索引读取对应测试段，不整体当作最小应用 |
| 不定长接收；空闲线收帧；环形 DMA；协议解析；RTOS 串口任务 | 无直接对应用例 | 固定长度用例只能提供底层参考；需要另行设计帧边界、缓冲与任务逻辑 |
| 指定 USART3 或 USART6 的独立收发模板 | 无直接对应用例 | 当前 APP 没有对应实例的独立用例；需查 SDK 和芯片映射后迁移 |

未指定实例时，优先选择 001～006 学习基本传输方式；指定实例时，优先选择该实例的独立用例。043 用于补充接口行为，不替代完整通信应用。

## 案例实际配置

以下参数直接摘录自各用例的宏定义，表示代码配置，尚未上板验证。附加信号列仅列出源码定义的引脚，不意味着每个信号都必须连接；结合该用例初始化及收发逻辑确定实际接线。GPIO 名称简写为 PA6 等。

| 用例 | 实例 | TX / RX | 附加信号定义 | 波特率 | 数据位 / 停止位 / 校验 | 流控 |
|---|---|---|---|---|---|---|
| [001](USART_IT_DRV_001.c) | USART7 | PA6 / PA7 | - | (115200U) | 8B / 1 / NONE | NONE |
| [002](USART_IT_DRV_002.c) | USART7 | PA6 / PA7 | - | (115200U) | 8B / 1 / NONE | NONE |
| [003](USART_IT_DRV_003.c) | USART7 | PA6 / PA7 | - | (115200U) | 8B / 1 / NONE | NONE |
| [004](USART_IT_DRV_004.c) | USART7 | PA6 / PA7 | - | (115200U) | 8B / 1 / NONE | NONE |
| [005](USART_IT_DRV_005.c) | USART7 | PA6 / PA7 | - | (115200U) | 8B / 1 / NONE | NONE |
| [006](USART_IT_DRV_006.c) | USART7 | PA6 / PA7 | - | (115200U) | 8B / 1 / NONE | NONE |
| [007](USART_IT_DRV_007.c) | USART7 | PA6 / PA7 | - | (9600U) | 8B / 1 / NONE | NONE |
| [008](USART_IT_DRV_008.c) | USART7 | PA6 / PA7 | - | (115200U) | 6B / 1 / NONE | NONE |
| [009](USART_IT_DRV_009.c) | USART7 | PA6 / PA7 | - | (115200U) | 7B / 1 / NONE | NONE |
| [010](USART_IT_DRV_010.c) | USART7 | PA6 / PA7 | - | (115200U) | 9B / 1 / NONE | NONE |
| [011](USART_IT_DRV_011.c) | USART7 | PA6 / PA7 | - | (115200U) | 8B / 2 / NONE | NONE |
| [012](USART_IT_DRV_012.c) | USART7 | PA6 / PA7 | - | (115200U) | 8B / 1 / ODD | NONE |
| [013](USART_IT_DRV_013.c) | USART7 | PA6 / PA7 | - | (115200U) | 8B / 1 / EVEN | NONE |
| [014](USART_IT_DRV_014.c) | USART7 | PA6 / PA7 | CTS=PC4 | (115200U) | 8B / 1 / NONE | CTS |
| [015](USART_IT_DRV_015.c) | USART7 | PA6 / PA7 | RTS=PC5 | (115200U) | 8B / 1 / NONE | RTS |
| [016](USART_IT_DRV_016.c) | USART7 | PA6 / PA7 | CK=PB0, NSS=PC4, RTS=PC5 | (115200U) | 8B / 1 / NONE | RTS |
| [017](USART_IT_DRV_017.c) | USART7 | PA6 / PA7 | CK=PB0, NSS=PC4, RTS=PC5 | (115200U) | 8B / 1 / NONE | RTS |
| [018](USART_IT_DRV_018.c) | USART7 | PA6 / PA7 | CK=PB0, NSS=PC4, RTS=PC5 | (281250U) | 8B / 1 / NONE | RTS |
| [019](USART_IT_DRV_019.c) | USART7 | PA6 / PA7 | CK=PB0, NSS=PC4, RTS=PC5 | (281250U) | 8B / 1 / NONE | RTS |
| [020](USART_IT_DRV_020.c) | USART7 | PA6 / PA7 | CK=PB0, NSS=PC4, RTS=PC5 | (115200U) | 8B / 1 / NONE | RTS |
| [021](USART_IT_DRV_021.c) | USART7 | PA6 / PA7 | CK=PB0, NSS=PC4, RTS=PC5 | (115200U) | 8B / 1 / NONE | RTS |
| [022](USART_IT_DRV_022.c) | USART7 | PA6 / PA7 | CK=PB0, NSS=PC4, RTS=PC5 | (115200U) | 8B / 1 / NONE | RTS |
| [023](USART_IT_DRV_023.c) | USART0 | PD8 / PD9 | - | (115200U) | 8B / 1 / NONE | NONE |
| [024](USART_IT_DRV_024.c) | USART0 | PD8 / PD9 | - | (115200U) | 8B / 1 / NONE | NONE |
| [025](USART_IT_DRV_025.c) | USART0 | PD8 / PD9 | - | (115200U) | 8B / 1 / NONE | NONE |
| [026](USART_IT_DRV_026.c) | USART0 | PD8 / PD9 | - | (115200U) | 8B / 1 / NONE | NONE |
| [027](USART_IT_DRV_027.c) | USART1 | PD15 / PH2 | - | (115200U) | 8B / 1 / NONE | NONE |
| [028](USART_IT_DRV_028.c) | USART1 | PD15 / PH2 | - | (115200U) | 8B / 1 / NONE | NONE |
| [029](USART_IT_DRV_029.c) | USART1 | PD15 / PH2 | - | (115200U) | 8B / 1 / NONE | NONE |
| [030](USART_IT_DRV_030.c) | USART1 | PD15 / PH2 | - | (115200U) | 8B / 1 / NONE | NONE |
| [031](USART_IT_DRV_031.c) | USART2 | PC9 / PH9 | - | (115200U) | 8B / 1 / NONE | NONE |
| [032](USART_IT_DRV_032.c) | USART2 | PC9 / PH9 | - | (115200U) | 8B / 1 / NONE | NONE |
| [033](USART_IT_DRV_033.c) | USART2 | PC9 / PH9 | - | (115200U) | 8B / 1 / NONE | NONE |
| [034](USART_IT_DRV_034.c) | USART2 | PC9 / PH9 | - | (115200U) | 8B / 1 / NONE | NONE |
| [035](USART_IT_DRV_035.c) | USART4 | PH8 / PG2 | - | (115200U) | 8B / 1 / NONE | NONE |
| [036](USART_IT_DRV_036.c) | USART4 | PH8 / PG2 | - | (115200U) | 8B / 1 / NONE | NONE |
| [037](USART_IT_DRV_037.c) | USART4 | PH8 / PG2 | - | (115200U) | 8B / 1 / NONE | NONE |
| [038](USART_IT_DRV_038.c) | USART4 | PH8 / PG2 | - | (115200U) | 8B / 1 / NONE | NONE |
| [039](USART_IT_DRV_039.c) | USART5 | PG12 / PG13 | - | (115200U) | 8B / 1 / NONE | NONE |
| [040](USART_IT_DRV_040.c) | USART5 | PG12 / PG13 | - | (115200U) | 8B / 1 / NONE | NONE |
| [041](USART_IT_DRV_041.c) | USART5 | PG12 / PG13 | - | (115200U) | 8B / 1 / NONE | NONE |
| [042](USART_IT_DRV_042.c) | USART5 | PG12 / PG13 | - | (115200U) | 8B / 1 / NONE | NONE |
| [043](USART_IT_DRV_043.c) | USART7 | PA6 / PA7 | - | (115200U) | 8B / 1 / NONE | NONE |

USART3、USART6 没有独立实例收发用例，当前索引不能据此声称覆盖全部 USART 实例。接收模式以定长接收测试为主；空闲线收帧、环形 DMA、协议解析和 RTOS 集成等需求，应进一步核对 SDK 支持，不能仅凭这些用例假定已经实现。

## 实现要点与案例配置

基本流程：HAL 初始化 → 系统时钟与延时 → 日志初始化 → 被测 GPIO 复用与 USART 时钟配置 → USART 初始化 → 收发及结果检查。

001 被测串口为 USART7，PA6=TX、PA7=RX，115200、8 位数据、无校验、1 停止位，循环发送 `11 22 33 44 55 66 77 88`，每次发送后延时 500 ms。接收端需匹配参数，并用十六进制观察。

- 发送测试需要外部接收设备；接收测试需要外部发送端按源码提供数据和时序。
- 同步测试需要匹配的主从设备和时钟；流控需要 CTS/RTS 握手信号。额外 CLK、NSS 等引脚见源码。
- 接线前核对电平和公共地。验证时结合 HAL 返回值和状态、PASS/FAIL 与失败计数、回调计数及外部实际数据。软件 PASS 或 DMA 完成不能单独证明引脚数据正确。

配套 print 实现使用 USART0 的 PD8/PD9；波特率由初始化参数决定。023～026 被测设备本身也是 USART0，不可假定日志和被测外设互不影响，应检查初始化顺序、映射及输出内容。

003 链路：PLIC → `TEST_USART_IRQ_HANDLER()` → `HAL_USART_IRQHandler(&husart_dev)` → `HAL_USART_TxCpltCallback()` 更新完成标志；004 参考接收回调。

005 / 006 还包含 DMA 时钟、通道、方向、地址、长度、请求映射及中断。005 的 `DMA1_IRQ_Handler()` 调用 `HAL_DMA_IRQHandler(&hdma_dev)`，USART 入口调用 `HAL_USART_IRQHandler()`；复用时保留完整调用链。

当前 `HAL_GPIO_Init()` 已将 `GPIO_MODE_AF_PP` / `GPIO_MODE_AF_OD` 映射为硬件输出模式，并处理复用选择。因此，用例中关于 AF 模式会直接写成模拟模式的部分历史注释，不能用于描述当前驱动行为。参考应用复用输出时应结合当前驱动使用 AF 模式，或核对显式 `HAL_GPIO_PinAFConfig()` 加输出模式的完整配置；本次未修改这些源码注释，也未上板比较两种写法。

## 验证方法与适用边界

先根据上方需求表选择用例，再核对完整源码中的引脚、时钟、参数、主循环、中断和回调。推荐表示可参考的实现，不表示已经满足完整产品需求；无直接对应项时，说明需要新增的逻辑。

本索引基于源码静态整理，未重新编译或上板；预期结果与实际验证状态分别判断。

当前记录：已抽查代表性源码及相关 HAL 实现；未逐条复核全部用例，未执行编译或上板验证。依赖缺口为本次目录检查结果，补齐后应更新本文。维护格式见 [案例库说明](../README.md#新增外设-readme-的统一写法)。

采用案例前至少确认：设备头、HAL 配置头、USART/GPIO/SMU/PLIC 及 DMA 模式所需驱动、配套 delay/print 或替代依赖均完整，源文件和 include 路径已登记；IRQ/回调与现有工程一致。缺少依赖或版本匹配依据时，不能承诺可编译或可通信。

## 按接口与辅助宏检索

下表按 API 名称提供检索入口，每项最多列出四个参考用例，不是完整调用清单或覆盖率证明。先从需求表选例，再读完整源码及当前 HAL；通用时钟、GPIO 和 DMA 依赖也须一并核对。

| 接口 | 参考用例 |
|---|---|
| `HAL_USART_AutoBaudRateRequest` | [043](USART_IT_DRV_043.c) |
| `HAL_USART_CheckIdleState` | [043](USART_IT_DRV_043.c) |
| `HAL_USART_ClockStructInit` | [016](USART_IT_DRV_016.c), [017](USART_IT_DRV_017.c), [018](USART_IT_DRV_018.c), [019](USART_IT_DRV_019.c) |
| `HAL_USART_ConfigAdvFeature` | [043](USART_IT_DRV_043.c) |
| `HAL_USART_ConfigClock` | [016](USART_IT_DRV_016.c), [017](USART_IT_DRV_017.c), [018](USART_IT_DRV_018.c), [019](USART_IT_DRV_019.c) |
| `HAL_USART_ConfigNSS` | [043](USART_IT_DRV_043.c) |
| `HAL_USART_DMAPause` | [043](USART_IT_DRV_043.c) |
| `HAL_USART_DMAResume` | [043](USART_IT_DRV_043.c) |
| `HAL_USART_DMAStop` | [043](USART_IT_DRV_043.c) |
| `HAL_USART_DeInit` | [001](USART_IT_DRV_001.c), [002](USART_IT_DRV_002.c), [003](USART_IT_DRV_003.c), [004](USART_IT_DRV_004.c) |
| `HAL_USART_DisableFIFO` | [043](USART_IT_DRV_043.c) |
| `HAL_USART_DisableSlaveMode` | [043](USART_IT_DRV_043.c) |
| `HAL_USART_EnableFIFO` | [001](USART_IT_DRV_001.c), [002](USART_IT_DRV_002.c), [003](USART_IT_DRV_003.c), [004](USART_IT_DRV_004.c) |
| `HAL_USART_EnableSlaveMode` | [018](USART_IT_DRV_018.c), [019](USART_IT_DRV_019.c), [043](USART_IT_DRV_043.c) |
| `HAL_USART_GetError` | [001](USART_IT_DRV_001.c), [002](USART_IT_DRV_002.c), [003](USART_IT_DRV_003.c), [004](USART_IT_DRV_004.c) |
| `HAL_USART_GetState` | [001](USART_IT_DRV_001.c), [002](USART_IT_DRV_002.c), [003](USART_IT_DRV_003.c), [004](USART_IT_DRV_004.c) |
| `HAL_USART_HalfDuplexCmd` | [043](USART_IT_DRV_043.c) |
| `HAL_USART_Init` | [001](USART_IT_DRV_001.c), [002](USART_IT_DRV_002.c), [003](USART_IT_DRV_003.c), [004](USART_IT_DRV_004.c) |
| `HAL_USART_LINBreakDetectLengthConfig` | [043](USART_IT_DRV_043.c) |
| `HAL_USART_LINCmd` | [043](USART_IT_DRV_043.c) |
| `HAL_USART_OneBitMethodCmd` | [043](USART_IT_DRV_043.c) |
| `HAL_USART_Receive` | [002](USART_IT_DRV_002.c), [015](USART_IT_DRV_015.c), [017](USART_IT_DRV_017.c), [043](USART_IT_DRV_043.c) |
| `HAL_USART_Receive_DMA` | [006](USART_IT_DRV_006.c), [026](USART_IT_DRV_026.c), [030](USART_IT_DRV_030.c), [034](USART_IT_DRV_034.c) |
| `HAL_USART_Receive_IT` | [004](USART_IT_DRV_004.c), [024](USART_IT_DRV_024.c), [028](USART_IT_DRV_028.c), [032](USART_IT_DRV_032.c) |
| `HAL_USART_RxDataFlush` | [043](USART_IT_DRV_043.c) |
| `HAL_USART_SendBreak` | [043](USART_IT_DRV_043.c) |
| `HAL_USART_SetRxFIFOThreshold` | [043](USART_IT_DRV_043.c) |
| `HAL_USART_SetTxFIFOThreshold` | [043](USART_IT_DRV_043.c) |
| `HAL_USART_StructInit` | [001](USART_IT_DRV_001.c), [002](USART_IT_DRV_002.c), [003](USART_IT_DRV_003.c), [004](USART_IT_DRV_004.c) |
| `HAL_USART_Transmit` | [001](USART_IT_DRV_001.c), [007](USART_IT_DRV_007.c), [008](USART_IT_DRV_008.c), [009](USART_IT_DRV_009.c) |
| `HAL_USART_TransmitReceive` | [043](USART_IT_DRV_043.c) |
| `HAL_USART_TransmitReceive_DMA` | [043](USART_IT_DRV_043.c) |
| `HAL_USART_TransmitReceive_IT` | [019](USART_IT_DRV_019.c), [043](USART_IT_DRV_043.c) |
| `HAL_USART_Transmit_DMA` | [005](USART_IT_DRV_005.c), [025](USART_IT_DRV_025.c), [029](USART_IT_DRV_029.c), [033](USART_IT_DRV_033.c) |
| `HAL_USART_Transmit_IT` | [003](USART_IT_DRV_003.c), [018](USART_IT_DRV_018.c), [023](USART_IT_DRV_023.c), [027](USART_IT_DRV_027.c) |
| `HAL_USART_TxDataFlush` | [018](USART_IT_DRV_018.c), [043](USART_IT_DRV_043.c) |

