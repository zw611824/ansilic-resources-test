# 功能验证规则索引

仅在用户要求运行/功能验证或选择“构建并验证”时读取；只编译、烧录或调试时不加载整套验证规则。

1. 读取 [公共规则](common.md)，确定本次范围、判据、证据和停止条件。
2. 通过串口观察结果时读取 [串口采集](transports/serial.md)。
3. 只读取当前任务涉及的功能规则；其中已包含验证步骤、观察点与预期，需要核对实现时再查 SDK，不遍历所有文件。

这些文件可直接用于当前工程验证，无需原始记录或参考目录。只报告本次实际验证或具体可行的方法。

| 功能 | 规则 |
| --- | --- |
| RTC 走时/闹钟 | [rtc](functions/rtc.md) |
| PMU 睡眠/唤醒 | [pmu](functions/pmu.md) |
| CLINT | [clint](functions/clint.md) |
| GPIO | [gpio](functions/gpio.md) |
| I2C | [i2c](functions/i2c.md) |
| CMU | [cmu](functions/cmu.md) |
| MPU | [mpu](functions/mpu.md) |
| DAC | [dac](functions/dac.md) |
| USART | [usart](functions/usart.md) |

功能规则提供判据类型和结论边界，不替代当前代码、芯片资料和实际案例。具体预期值、误差、样本数及时间窗来自当前测试目标，不把建议当成所有工程的固定门槛。尚无专用规则时依据公共规则和已核实资料制定本次判据，如实说明未覆盖范围。

## 后续维护

公共授权、证据和报告约束只维护在 common.md；采集接口语义只维护在 transports/；功能判据放在 functions/。新增独立功能时增加一份文件并更新本索引；同一外设存在明显不同的测试目标时再按功能拆分子文件，不预建空规则。功能文件写明触发条件、需要的真实证据、判定依据和不能推出的结论；不要重复编译、烧录、调试流程。
