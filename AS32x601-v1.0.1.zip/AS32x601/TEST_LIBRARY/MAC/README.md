# MAC 引脚参考

此处仅整理 AS32x601 LQFP144 引脚资料，当前未收录该外设的独立测试用例。接口以 [HAL 头文件](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_mac.h) 为准。

## 实例与可选引脚

| 信号 | 引脚 | LQFP144 脚号 | 功能 | HAL 配置 |
| --- | --- | --- | --- | --- |
| MAC_MDC | PF8 | 89 | 功能1 | GPIO_AF_MAC（0x02） |
| MAC_MDIO | PF9 | 91 | 功能1 | GPIO_AF_MAC（0x02） |
| MAC_RXCLK | PC15 | 86 | 功能1 | GPIO_AF_MAC（0x02） |
| MAC_RXCOL | PF0 | 88 | 功能1 | GPIO_AF_MAC（0x02） |
| MAC_RXCRS | PF1 | 90 | 功能1 | GPIO_AF_MAC（0x02） |
| MAC_RXD0 | PF4 | 96 | 功能1 | GPIO_AF_MAC（0x02） |
| MAC_RXD1 | PF5 | 99 | 功能1 | GPIO_AF_MAC（0x02） |
| MAC_RXD2 | PF6 | 84 | 功能1 | GPIO_AF_MAC（0x02） |
| MAC_RXD3 | PF7 | 87 | 功能1 | GPIO_AF_MAC（0x02） |
| MAC_RXDV | PF3 | 94 | 功能1 | GPIO_AF_MAC（0x02） |
| MAC_RXER | PF2 | 92 | 功能1 | GPIO_AF_MAC（0x02） |
| MAC_TXCLK | PE2 | 123 | 功能1 | GPIO_AF_MAC（0x02） |
| MAC_TXD0 | PE5 | 127 | 功能1 | GPIO_AF_MAC（0x02） |
| MAC_TXD1 | PE6 | 128 | 功能1 | GPIO_AF_MAC（0x02） |
| MAC_TXD2 | PC13 | 125 | 功能1 | GPIO_AF_MAC（0x02） |
| MAC_TXD3 | PC14 | 85 | 功能1 | GPIO_AF_MAC（0x02） |
| MAC_TXEN | PE4 | 120 | 功能1 | GPIO_AF_MAC（0x02） |
| MAC_TXER | PE3 | 124 | 功能1 | GPIO_AF_MAC（0x02） |
