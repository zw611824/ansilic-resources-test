/**
 * @file    SPACC_IT_DRV_006.c
 * @brief   HAL SPACC integration test case 006 (queue and interrupt behaviour).
 *
 * submission queue, result identification and interrupt acknowledgement behaviour.
 *
 * Tested functionality:
 *   HAL_SPACC_Init (submission), HAL_SPACC_PacketInit, HAL_SPACC_ITConfig, HAL_SPACC_GetITStatus, HAL_SPACC_IRQHandler (write one to clear), HAL_SPACC_StateFIFOFlag, HAL_SPACC_CommandExecResult (miss, hit, empty FIFO guard, identifier width), HAL_SPACC_DeInit (no CTRL write, no FIFO reset) and the three command FIFOs.
 *
 * Expected behaviour:
 *   the enabled status source stays acknowledged (the status FIFO event is not
 *   raised on this device), the handler neither acknowledges nor consumes an
 *   event it does not own, the results are identified by the software ID
 *   independently of the FIFO priority order, and the de-initialization neither
 *   submits a task nor resets the FIFOs, so the summary stays at zero failures.
 *
 * @note    The packet vectors are the ones of the reference test project
 *          (SPACC_IT_DRV_006.c) and are reproduced verbatim, so a case can be
 *          compared one to one with the reference output.
 * @note    The SPACC needs the AXILite4-Bus1 (DSE) clock gate and reset
 *          release: HAL_SPACC_MspInit() is overridden at the end of this file
 *          to do that and to count its calls.
 * @note    The DDT structures are 8-byte aligned through a union with a 64-bit
 *          member, because the driver validates the alignment of the DDT bus
 *          address (SRC_PTR.PTR starts at bit 3).
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Software identifier carried by every submitted task */
#define TEST_SOFTWARE_ID            (0x2DU)

/* Bound of every polling loop (the SPACC completes in microseconds) */
#define TEST_WAIT_GUARD             (20000000U)

/* Reporting period of the final loop (ms) */
#define TEST_POLL_MS                (1000U)

/* Unknown instance used by the handle validation checks */
#define TEST_BAD_INSTANCE           ((SPACC_TypeDef *)0x40000000UL)

/* Processed packet size, in 32-bit words, of this case */
#define TEST_PACKET_WORDS           (4U)

/* Byte-swap helper: the SPACC consumes the packet in the opposite byte order
 * of the C representation, exactly as the reference test project does. */
#define TEST_SWAP32(__VALUE__)      ((((__VALUE__) & 0x000000FFUL) << 24) | \
                                     (((__VALUE__) & 0x0000FF00UL) << 8)  | \
                                     (((__VALUE__) & 0x00FF0000UL) >> 8)  | \
                                     (((__VALUE__) & 0xFF000000UL) >> 24))

/* Private typedef -----------------------------------------------------------*/
/**
 * @brief Data descriptor table (DDT) of a packet segment list.
 * @note  The SPACC reads SRC_PTR / DST_PTR as the bus address of a DDT whose
 *        first pointer is kept on an 8-byte boundary (PTR field starts at bit
 *        3), so the two DDT instances below are wrapped in a union with a
 *        64-bit member to force that alignment on every toolchain.
 */
typedef struct
{
    uint32 *Ptr_0;
    uint32  Len_0;
    uint32 *Ptr_1;
    uint32  Len_1;
} SPACC_DDTTypeDef;

typedef union
{
    SPACC_DDTTypeDef ddt;
    uint64           force_align8;
} SPACC_DDTAlignedTypeDef;

/* Private variables ---------------------------------------------------------*/
static HAL_SPACC_HandleTypeDef hspacc_dev;          /*!< handle under test      */
static HAL_SMU_HandleTypeDef   hsmu_clk;            /*!< SMU handle (clock)     */
static SPACC_InitTypeDef       spacc_init;          /*!< configuration          */
static SPACC_PacketTypeDef     spacc_packet;        /*!< packet descriptor      */
static SPACC_DDTAlignedTypeDef spacc_ddt_src;       /*!< source DDT (8B aligned)*/
static SPACC_DDTAlignedTypeDef spacc_ddt_dst;       /*!< destination DDT        */

/* Accumulated check counters */
static uint32 failures = 0U;
static uint32 checks = 0U;

/* Low level callback instrumentation */
static uint32 msp_init_count = 0U;
static uint32 msp_deinit_count = 0U;
static uint32 error_callback_count = 0U;

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void Section(const char *name);
static void Check(const char *name, uint32 condition);
static void Summary(void);
static void Spacc_StageDdt(uint32 *src, uint32 src_bytes, uint32 *dst, uint32 dst_bytes);
static HAL_StatusTypeDef Spacc_WriteCipherContext(const uint32 *words, uint32 count);
static HAL_StatusTypeDef Spacc_ReadCipherContext(uint32 *words, uint32 count);
static uint32 Spacc_WaitResult(uint32 software_id);
static void Spacc_Drain(uint32 limit);


/* AES-128 material used by the self test (key + IV, the values of case 001) */
static const uint32 test_aes_context[12] =
{
    0xae781dadU, 0x18efd7f1U, 0x4acc012aU, 0x75dbeb3aU,
    0x00000000U, 0x00000000U, 0x00000000U, 0x00000000U,
    0x6fac1192U, 0xeb4540ffU, 0xcb5afd0fU, 0xb408d5c5U
};

static uint32 test_src[4];
static uint32 test_dst_a[4];
static uint32 test_dst_b[4];
static uint32 test_ctx_read[12];


/**
 * @brief  Stage one small packet and submit it with the requested identifiers.
 * @param  software_id: SW_ID written to SW_CTRL.
 * @param  fifo: SW_CTRL.PRIORITY selection (0, 1 or 2).
 * @param  dst: destination buffer of the packet.
 * @retval HAL status of HAL_SPACC_Init() (HAL_OK means "submitted").
 * @note   One submission is one CTRL write, so the descriptor is staged again
 *         for every task: the hardware consumes it at submission time.
 */
static HAL_StatusTypeDef Spacc_Submit(uint32 software_id, uint32 fifo, uint32 *dst)
{
    Spacc_StageDdt(test_src, (uint32)sizeof(test_src), dst, (uint32)sizeof(test_src));
    spacc_packet.SPACC_PROCLen = (uint32)sizeof(test_src);

    HAL_SPACC_PacketInit(&hspacc_dev, &spacc_packet);

    spacc_init.SPACC_SoftwareID          = software_id;
    spacc_init.SPACC_PriorityCommandFIFO = fifo;

    return HAL_SPACC_Init(&hspacc_dev, &spacc_init);
}

/**
 * @brief  Wait until at least one result is available.
 * @retval 1 when a result is pending, 0 when the guard expired.
 */
static uint32 Spacc_WaitPending(void)
{
    uint32 guard = TEST_WAIT_GUARD;

    while ((HAL_SPACC_StateFIFOFlag(&hspacc_dev) == SET) && (guard != 0U))
    {
        guard--;
    }

    CLEAR_CACHE();

    return (guard != 0U) ? 1U : 0U;
}

/**
 * @brief  Case 006: submission queue, result identification and interrupt
 *         acknowledgement behaviour.
 * @retval Never (the final loop keeps reporting).
 */
int main(void)
{
    SPACC_InitTypeDef bad;
    uint32            i;
    uint32            first;
    uint32            second;
    uint32            ctrl_before;
    uint32            fifo_before;
    uint32            src_before;
    HAL_StatusTypeDef status;

    HAL_Init();
    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);

    printf("\r\n ***** SPACC queue and interrupt behaviour test (case 006) ***** \r\n");
    printf("Data : %s\r\n", __DATE__);
    printf("Time : %s\r\n", __TIME__);
    delay_ms(500U);

    for (i = 0U; i < 4U; i++)
    {
        test_src[i]   = 0x20202020U + i;
        test_dst_a[i] = 0U;
        test_dst_b[i] = 0U;
    }

    /* ------------------------------------------------------------ prepare */
    Section("preparation");

    HAL_SPACC_StructInit(&spacc_init);
    spacc_init.SPACC_CipherAlgorithm     = SPACC_CIPHER_ALG_AES;
    spacc_init.SPACC_SM4CipherMode       = SPACC_SM4_CIPHER_MODE_ECB;
    spacc_init.SPACC_HashAlgorithm       = SPACC_HASH_ALG_NULL;
    spacc_init.SPACC_TransferMode        = SPACC_TRANS_TO_APPLY_ENCRYPT;
    spacc_init.SPACC_MessageBegin        = SPACC_MSG_BEGIN_FIRST;
    spacc_init.SPACC_MessageEnd          = SPACC_MSG_END_LAST;
    spacc_init.SPACC_SoftwareID          = TEST_SOFTWARE_ID;
    spacc_init.SPACC_PriorityCommandFIFO = 0U;
    spacc_init.SPACC_KeySize             = 0x10U;
    spacc_init.SPACC_KeyType             = SPACC_KEY_TYPE_CIPHER;

    __HAL_CLEAR_STRUCT(&hspacc_dev);
    hspacc_dev.Instance = SPACC;

    status = Spacc_WriteCipherContext(test_aes_context, 12U);
    Check("cipher context written before the first submission", (status == HAL_OK) ? 1U : 0U);
    Check("the command FIFO is empty before the first submission",
          (HAL_SPACC_StateFIFOFlag(&hspacc_dev) == SET) ? 1U : 0U);

    /* ------------------------------------------- rejected Init does not submit */
    Section("a rejected admission must not touch the queue");

    fifo_before = SPACC->FIFO_STAT;
    bad = spacc_init;
    bad.Size = (uint32)sizeof(SPACC_InitTypeDef) - 4U;
    Spacc_StageDdt(test_src, (uint32)sizeof(test_src), test_dst_a, (uint32)sizeof(test_src));
    HAL_SPACC_PacketInit(&hspacc_dev, &spacc_packet);
    status = HAL_SPACC_Init(&hspacc_dev, &bad);
    Check("an invalid configuration is refused", (status == HAL_ERROR) ? 1U : 0U);
    Check("the rejected admission left the queue untouched",
          (SPACC->FIFO_STAT == fifo_before) ? 1U : 0U);
    Check("the rejected admission left the state in reset",
          (HAL_SPACC_GetState(&hspacc_dev) == HAL_SPACC_STATE_RESET) ? 1U : 0U);
    Check("the rejected admission recorded the parameter error",
          (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_INVALID_PARAM) ? 1U : 0U);

    /* ------------------------------------------------- submission lifecycle */
    Section("submission and completion");

    status = Spacc_Submit(0xA5U, 0U, test_dst_a);
    Check("submission accepted", (status == HAL_OK) ? 1U : 0U);
    Check("state is ready once the task is queued",
          (HAL_SPACC_GetState(&hspacc_dev) == HAL_SPACC_STATE_READY) ? 1U : 0U);
    Check("error code cleared by the accepted admission",
          (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_NONE) ? 1U : 0U);
    Check("low level initialization ran exactly once", (msp_init_count == 1U) ? 1U : 0U);
    Check("a result became available", Spacc_WaitPending());

    /* ------------------------------------------- interrupt acknowledge model */
    Section("interrupt source gating and write one to clear acknowledgement");

    /* IRQ_STAT is write-one-to-clear. The status FIFO event cannot be raised on
     * this device: IRQ_CTRL only implements the command FIFO watermark and its
     * STAT_CNT field reads back as zero, so the STAT source stays acknowledged
     * even while a result is pending. The section therefore observes the raw
     * register and checks that the handler neither acknowledges nor consumes an
     * event it does not own. */
    SPACC->IRQ_STAT = (uint32)SPACC_IT_ALL;

    HAL_SPACC_ITConfig(&hspacc_dev, (uint32)(SPACC_IT_STAT | SPACC_IT_GLBL), ENABLE);
    Check("the status source and the global gate are enabled",
          ((SPACC->IRQ_EN & (uint32)(SPACC_IT_STAT | SPACC_IT_GLBL)) ==
           (uint32)(SPACC_IT_STAT | SPACC_IT_GLBL)) ? 1U : 0U);
    Check("the status source is acknowledged while the result is pending",
          (HAL_SPACC_GetITStatus(&hspacc_dev, (uint32)SPACC_IT_STATE_STAT) == RESET) ? 1U : 0U);

    HAL_SPACC_IRQHandler(&hspacc_dev);
    Check("the handler keeps an un-raised status source acknowledged",
          (HAL_SPACC_GetITStatus(&hspacc_dev, (uint32)SPACC_IT_STATE_STAT) == RESET) ? 1U : 0U);
    Check("the handler left the pending result in the status FIFO",
          (HAL_SPACC_StateFIFOFlag(&hspacc_dev) == RESET) ? 1U : 0U);
    Check("the handler kept the handle ready",
          (HAL_SPACC_GetState(&hspacc_dev) == HAL_SPACC_STATE_READY) ? 1U : 0U);
    Check("the handler did not raise an error", (error_callback_count == 0U) ? 1U : 0U);

    HAL_SPACC_IRQHandler(&hspacc_dev);
    Check("a second entry with no pending event keeps the ready state",
          (HAL_SPACC_GetState(&hspacc_dev) == HAL_SPACC_STATE_READY) ? 1U : 0U);

    Check("the pending result is matched by its software ID",
          (HAL_SPACC_CommandExecResult(&hspacc_dev, 0xA5U) == SET) ? 1U : 0U);
    Check("the status FIFO is empty after the pop",
          (HAL_SPACC_StateFIFOFlag(&hspacc_dev) == SET) ? 1U : 0U);

    HAL_SPACC_ITConfig(&hspacc_dev, (uint32)(SPACC_IT_STAT | SPACC_IT_GLBL), DISABLE);
    Check("the sources are disabled again",
          ((SPACC->IRQ_EN & (uint32)(SPACC_IT_STAT | SPACC_IT_GLBL)) == 0U) ? 1U : 0U);

    /* ------------------------------------------------ result identification */
    Section("result identification by software ID");

    status = Spacc_Submit(0x11U, 0U, test_dst_a);
    Check("second submission accepted", (status == HAL_OK) ? 1U : 0U);
    Check("second result available", Spacc_WaitPending());
    Check("a mismatching software ID is reported as a miss",
          (HAL_SPACC_CommandExecResult(&hspacc_dev, 0x22U) == RESET) ? 1U : 0U);
    Check("a popped entry is never pushed back",
          (HAL_SPACC_StateFIFOFlag(&hspacc_dev) == SET) ? 1U : 0U);

    status = Spacc_Submit(0x33U, 0U, test_dst_a);
    Check("third submission accepted", (status == HAL_OK) ? 1U : 0U);
    Check("the matching software ID is reported as a hit",
          Spacc_WaitResult(0x33U));

    /* ------------------------------------------------------ two command FIFOs */
    Section("two command FIFOs, results identified independently of the order");

    status = Spacc_Submit(0x41U, 0U, test_dst_a);
    Check("submission to command FIFO 0 accepted", (status == HAL_OK) ? 1U : 0U);
    status = Spacc_Submit(0x42U, 1U, test_dst_b);
    Check("submission to command FIFO 1 accepted", (status == HAL_OK) ? 1U : 0U);

    Check("at least one result is pending", Spacc_WaitPending());
    first  = HAL_SPACC_CommandExecResult(&hspacc_dev, 0x41U);
    second = HAL_SPACC_CommandExecResult(&hspacc_dev, (first == SET) ? 0x42U : 0x41U);
    printf("  first pop matched 0x41 : %s\r\n", ((first == SET) ? "yes" : "no"));
    Check("both queued tasks reported exactly one result each", (second == SET) ? 1U : 0U);
    Check("both entries were consumed",
          (HAL_SPACC_StateFIFOFlag(&hspacc_dev) == SET) ? 1U : 0U);

    /* --------------------------------------------------------- empty FIFO */
    Section("empty status FIFO guard");

    /* Drop anything the previous sections may have left behind, so the empty
     * FIFO checks below start from a clean queue. */
    Spacc_Drain(8U);

    fifo_before = SPACC->FIFO_STAT;
    Check("an empty FIFO reports the empty flag",
          (HAL_SPACC_StateFIFOFlag(&hspacc_dev) == SET) ? 1U : 0U);
    Check("popping an empty FIFO reports a miss",
          (HAL_SPACC_CommandExecResult(&hspacc_dev, 0x41U) == RESET) ? 1U : 0U);
    Check("an empty pop leaves FIFO_STAT untouched",
          (SPACC->FIFO_STAT == fifo_before) ? 1U : 0U);

    Check("a software ID above eight bits is refused",
          (HAL_SPACC_CommandExecResult(&hspacc_dev, 0x1FFU) == RESET) ? 1U : 0U);
    Check("the refused identifier recorded the parameter error",
          (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_INVALID_PARAM) ? 1U : 0U);
    Check("the refused identifier did not change FIFO_STAT",
          (SPACC->FIFO_STAT == fifo_before) ? 1U : 0U);

    /* --------------------------------------- de-initialization is not a reset */
    Section("de-initialization does not submit and does not cancel");

    status = Spacc_Submit(0x55U, 0U, test_dst_a);
    Check("a last submission is accepted", (status == HAL_OK) ? 1U : 0U);
    Check("its result is pending before the de-initialization", Spacc_WaitPending());

    ctrl_before = SPACC->CTRL;
    fifo_before = SPACC->FIFO_STAT;
    src_before  = SPACC->SRC_PTR;

    status = HAL_SPACC_DeInit(&hspacc_dev);
    Check("DeInit accepted", (status == HAL_OK) ? 1U : 0U);
    Check("DeInit never wrote CTRL (a CTRL store would submit a task)",
          (SPACC->CTRL == ctrl_before) ? 1U : 0U);
    Check("DeInit did not reset the command or status FIFO",
          ((SPACC->FIFO_STAT & (uint32)SPACC_FIFO_STAT_STAT_CNT) ==
           (fifo_before & (uint32)SPACC_FIFO_STAT_STAT_CNT)) ? 1U : 0U);
    Check("DeInit cleared the staged descriptor",
          ((SPACC->SRC_PTR & (uint32)SPACC_SRC_PTR_PTR) == 0U) ? 1U : 0U);
    Check("SRC_PTR changed as expected", (src_before != 0U) ? 1U : 0U);
    Check("DeInit closed every interrupt source", (SPACC->IRQ_EN == 0U) ? 1U : 0U);
    Check("state is reset", (HAL_SPACC_GetState(&hspacc_dev) == HAL_SPACC_STATE_RESET) ? 1U : 0U);
    Check("the pending result survived the de-initialization",
          (HAL_SPACC_StateFIFOFlag(&hspacc_dev) == RESET) ? 1U : 0U);
    Check("and can still be collected",
          (HAL_SPACC_CommandExecResult(&hspacc_dev, 0x55U) == SET) ? 1U : 0U);
    Check("the de-initialization is idempotent",
          (HAL_SPACC_DeInit(&hspacc_dev) == HAL_OK) ? 1U : 0U);
    Check("a second DeInit does not repeat the teardown callback",
          (msp_deinit_count == 1U) ? 1U : 0U);

    Section("context memory remains reachable after the de-initialization");

    status = Spacc_ReadCipherContext(test_ctx_read, 12U);
    Check("cipher context still readable through the context API", (status == HAL_OK) ? 1U : 0U);

    Section("result");
    Summary();
    printf("***** SPACC queue and interrupt behaviour test %s *****\r\n",
           ((failures == 0U) ? "success" : "failed"));

    for (;;)
    {
        delay_ms(TEST_POLL_MS);
    }
}


/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Report one section of the case.
 * @param  name: section name.
 * @retval None
 */
static void Section(const char *name)
{
    printf("\r\n---- %s ----\r\n", name);
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    checks++;

    if (condition == 0U)
    {
        failures++;
    }

    printf("%-58s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Print the check summary.
 * @retval None
 */
static void Summary(void)
{
    printf("\r\nchecks = %u, failures = %u\r\n", PRINT_U32(checks), PRINT_U32(failures));
    printf("summary : failures = %s\r\n", ((failures == 0U) ? "0 (PASS)" : "NON-ZERO (FAIL)"));
}

/**
 * @brief  Fill the two DDT structures and the pointer fields of the descriptor.
 * @param  src: source buffer.
 * @param  src_bytes: source segment length, in bytes.
 * @param  dst: destination buffer.
 * @param  dst_bytes: destination segment length, in bytes.
 * @retval None
 * @note   Both DDTs describe a single segment, the second entry is the NULL
 *         terminator. The byte counts and every offset of the descriptor are
 *         cleared here; the case overrides the fields it needs afterwards.
 */
static void Spacc_StageDdt(uint32 *src, uint32 src_bytes, uint32 *dst, uint32 dst_bytes)
{
    spacc_ddt_src.ddt.Ptr_0 = src;
    spacc_ddt_src.ddt.Len_0 = src_bytes;
    spacc_ddt_src.ddt.Ptr_1 = NULL_PTR;
    spacc_ddt_src.ddt.Len_1 = 0U;

    spacc_ddt_dst.ddt.Ptr_0 = dst;
    spacc_ddt_dst.ddt.Len_0 = dst_bytes;
    spacc_ddt_dst.ddt.Ptr_1 = NULL_PTR;
    spacc_ddt_dst.ddt.Len_1 = 0U;

    spacc_packet.SPACC_SourcePtr        = (uint32)(&spacc_ddt_src.ddt);
    spacc_packet.SPACC_DestinationPtr   = (uint32)(&spacc_ddt_dst.ddt);
    spacc_packet.SPACC_SouPREAADOffset  = 0U;
    spacc_packet.SPACC_DestPREAADOffset = 0U;
    spacc_packet.SPACC_PREAADLen        = 0U;
    spacc_packet.SPACC_POSTAADLen       = 0U;
    spacc_packet.SPACC_PROCLen          = (TEST_PACKET_WORDS * 4U);
    spacc_packet.SPACC_ICVLen           = 0U;
    spacc_packet.SPACC_ICVOffset        = 0U;
    spacc_packet.SPACC_IVOffset         = 0U;
    spacc_packet.SPACC_IVLocation       = SPACC_IV_LOCATION_CONTEXT;

    CLEAR_CACHE();
}

/**
 * @brief  Write the cipher context (key / IV) through the HAL context API.
 * @param  words: context words in the C representation (big endian wording).
 * @param  count: number of words.
 * @retval HAL status of HAL_SPACC_WriteContext().
 * @note   The values are byte swapped in a local buffer before the transfer,
 *         because the SPACC context store keeps them in the opposite order
 *         (the reference test project writes them through the same swap).
 */
static HAL_StatusTypeDef Spacc_WriteCipherContext(const uint32 *words, uint32 count)
{
    uint32 swapped[16];
    uint32 i;

    for (i = 0U; (i < count) && (i < 16U); i++)
    {
        swapped[i] = TEST_SWAP32(words[i]);
    }

    return HAL_SPACC_WriteContext(&hspacc_dev, SPACC_CIPHER_CONTEXT_BASE, 0U, swapped, count);
}

/**
 * @brief  Read the cipher context and undo the byte swap.
 * @param  words: destination buffer, in the C representation.
 * @param  count: number of words.
 * @retval HAL status of HAL_SPACC_ReadContext().
 */
static HAL_StatusTypeDef Spacc_ReadCipherContext(uint32 *words, uint32 count)
{
    uint32 raw[16];
    uint32 i;
    HAL_StatusTypeDef status;

    status = HAL_SPACC_ReadContext(&hspacc_dev, SPACC_CIPHER_CONTEXT_BASE, 0U, raw, count);

    for (i = 0U; (i < count) && (i < 16U); i++)
    {
        words[i] = TEST_SWAP32(raw[i]);
    }

    return status;
}

/**
 * @brief  Wait for a result and match its software identifier.
 * @param  software_id: identifier of the submitted task.
 * @retval 1 when a result was popped and its identifier matched, 0 otherwise.
 * @note   The wait is bounded, so a silent hardware problem is reported as a
 *         failed check instead of hanging the case.
 */
static uint32 Spacc_WaitResult(uint32 software_id)
{
    uint32 guard = TEST_WAIT_GUARD;

    while ((HAL_SPACC_StateFIFOFlag(&hspacc_dev) == SET) && (guard != 0U))
    {
        guard--;
    }

    CLEAR_CACHE();

    if (guard == 0U)
    {
        return 0U;
    }

    return (HAL_SPACC_CommandExecResult(&hspacc_dev, software_id) == SET) ? 1U : 0U;
}

/**
 * @brief  Pop every pending result so that the next submission starts clean.
 * @param  limit: maximum number of results to pop.
 * @retval None
 */
static void Spacc_Drain(uint32 limit)
{
    uint32 count = 0U;

    CLEAR_CACHE();

    while ((HAL_SPACC_StateFIFOFlag(&hspacc_dev) == RESET) && (count < limit))
    {
        (void)HAL_SPACC_CommandExecResult(&hspacc_dev, 0U);
        count++;
    }
}

/**
 * @brief  SPACC low level initialization: clock gate and reset release.
 * @param  hspacc: SPACC handle.
 * @retval None
 * @note   The SPACC is clocked by the AXILite4-Bus1 (DSE) domain, gated by the
 *         SMU. The call count lets the cases verify that the callback runs
 *         once, before the handle is locked.
 */
void HAL_SPACC_MspInit(HAL_SPACC_HandleTypeDef *hspacc)
{
    if (hspacc == NULL_PTR)
    {
        return;
    }

    msp_init_count++;

    __HAL_SMU_DSE_CLK_ENABLE();
    __HAL_SMU_DSE_FORCE_RESET();
    __HAL_SMU_DSE_RELEASE_RESET();
}

/**
 * @brief  SPACC low level de-initialization, counted for the life cycle checks.
 * @param  hspacc: SPACC handle.
 * @retval None
 */
void HAL_SPACC_MspDeInit(HAL_SPACC_HandleTypeDef *hspacc)
{
    if (hspacc == NULL_PTR)
    {
        return;
    }

    msp_deinit_count++;
}

/**
 * @brief  SPACC error callback, counted for the interrupt checks.
 * @param  hspacc: SPACC handle.
 * @retval None
 */
void HAL_SPACC_ErrorCallback(HAL_SPACC_HandleTypeDef *hspacc)
{
    (void)hspacc;

    error_callback_count++;
}

/**
 * @brief  Configure the system clock and the bus gates.
 * @retval None
 * @note   Same clock tree as the other HAL integration suites: the PLL is fed
 *         by the external oscillator (VCO 180 MHz) and the buses run at
 *         AXI4Bus3 / 2, APBBus0 / 2, APBBus1 / 2 and CANX2 / 8, which keeps
 *         the console USART on its usual 22.5 MHz.
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    smu_osc;
    SMU_ClockInitTypeDef  smu_clock;
    SMU_ClocksTypeDef     smu_clocks;
    HAL_PMU_HandleTypeDef hpmu;

    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Raise the core rail trim before the PLL is switched: the 1.2 V LDO APIs
     * are gated on the handle state, so the PMU must be initialized first */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    __HAL_CLEAR_STRUCT(&smu_osc);
    smu_osc.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    smu_osc.FIRCState            = SMU_FIRC_ON;
    smu_osc.FIRCCalibrationValue = 0x00U;
    smu_osc.PLL.PLLState         = SMU_PLL_ON;
    smu_osc.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    smu_osc.PLL.PLLDivR          = 0x04U;
    smu_osc.PLL.PLLDivQ          = 0x01U;
    smu_osc.PLL.PLLDivN          = 0x14U;
    smu_osc.PLL.PLLDivF          = 0xB4U;
    smu_osc.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    (void)HAL_SMU_OscConfig(&hsmu_clk, &smu_osc, SMU_TIMEOUT_DEFAULT);

    /* Bus dividers */
    __HAL_CLEAR_STRUCT(&smu_clock);
    smu_clock.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    smu_clock.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    smu_clock.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    smu_clock.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &smu_clock);

    (void)HAL_SMU_GetClocksFreq(&smu_clocks);

    /* The packet descriptor and the context memory are programmable before the
     * first initialization, so the AXILite4-Bus1 (DSE) clock gate and its reset
     * release must already be in place: the gate is not guaranteed to be open
     * after a power-on or a hardware reset, and an access of the unclocked block
     * stalls the bus. HAL_SPACC_MspInit() repeats both operations before the
     * first submission. */
    __HAL_SMU_DSE_CLK_ENABLE();
    __HAL_SMU_DSE_FORCE_RESET();
    __HAL_SMU_DSE_RELEASE_RESET();
}

/*****END OF FILE*****/
