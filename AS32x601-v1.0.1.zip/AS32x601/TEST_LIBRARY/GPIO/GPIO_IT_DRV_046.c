/**
 * @file    GPIO_IT_DRV_046.c
 * @brief   HAL GPIO integration test case 046 (extension: output and IO access
 *          coverage, argument protection).
 *
 * This case is not part of the vendor plan (which has 43 cases): it is an
 * extension. It covers the access APIs of the driver that the one-to-one ports
 * exercise only through a waveform, and it checks them at register level.
 *
 * Tested functionality:
 *   HAL_GPIO_Init()
 *   HAL_GPIO_WritePin()          (GPIO_PIN_SET / GPIO_PIN_RESET, GPIO_PIN_All)
 *   HAL_GPIO_TogglePin()
 *   HAL_GPIO_ReadPin()           (input path, internal self check)
 *   HAL_GPIO_WritePort()
 *   HAL_GPIO_ReadOutputPin() / HAL_GPIO_ReadOutputPort()
 *   HAL_GPIO_ReadInputPort()
 *
 * Test configuration:
 *   GPIOD pins 0..3 : push-pull outputs (the access checks)
 *   GPIOD pins 4..5 : inputs used by the internal input path self check; leave
 *                     them floating, the check uses the internal pull-up and
 *                     pull-down of the chip, so no external signal is needed
 *   GPIOH pins 2..9 : push-pull outputs (pin availability on the write path)
 *
 * Test procedure (every check is recorded in the observation masks below):
 *   step 1  set and clear the pins through the bit registers        checks 0..1
 *   step 2  toggle the pins                                        checks 2..3
 *   step 3  whole output register write and read back              checks 4..6
 *   step 4  GPIO_PIN_All set and clear                             checks 7..8
 *   step 5  input path: pull-up then pull-down, no external signal  checks 9..11
 *   step 6  GPIOH availability on the write path                   checks 12..14
 *   step 7  rejected arguments leave the registers untouched       checks 15..17
 *
 * Expected behaviour:
 *   The case prints nothing. Bit n of Passed_Mask is set when check n passed and
 *   bit n of Failed_Mask when it failed, so
 *     Failed_Mask == 0x00000000  and  Passed_Mask == 0x0003FFFF  and
 *     Check_Count == 18
 *   means that every check of this case passed.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"

/* Private define -----------------------------------------------------------*/
/* GPIOD pins driven as outputs */
#define GPIOD_OUT_PIN           (GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3)
/* GPIOD pins used by the input path self check */
#define GPIOD_IN_PIN            (GPIO_PIN_4 | GPIO_PIN_5)
#define GPIOD_IN_PIN_4          (GPIO_PIN_4)
#define GPIOD_IN_PIN_5          (GPIO_PIN_5)
#define GPIOD_IN_PIN_4_POS      (4U)
#define GPIOD_IN_PIN_5_POS      (5U)
/* Pattern written to the whole output register (bits 4..7) */
#define GPIOD_PORT_PATTERN      ((uint16)0x00F0U)
/* GPIOH pins driven as outputs by step 6 */
#define GPIOH_OUT_PIN           (GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_5 | \
                                 GPIO_PIN_6 | GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9)

/* An unsupported output level, refused by the argument validation */
#define INVALID_PIN_STATE       ((GPIO_PinState)0x7F)

/* Number of checks of this case and the expected observation of the masks */
#define CHECK_ALL               ((uint32)0x0003FFFFU)
#define CHECK_TOTAL             (18U)

/* Private variables ---------------------------------------------------------*/
static HAL_SMU_HandleTypeDef hsmu_clk;    /*!< SMU handle (lock / state / error) */
static volatile uint32 Passed_Mask = 0U;  /*!< bit n set when check n passed      */
static volatile uint32 Failed_Mask = 0U;  /*!< bit n set when check n failed      */
static volatile uint32 Check_Count = 0U;  /*!< number of checks that were run     */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void check(uint32 index, uint32 condition);
static void gpio_Configure(GPIO_TypeDef *GPIOx, uint32 pin, uint32 mode, uint32 pull);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    uint32 ocr_before;
    uint32 ocr_after;
    uint32 ok;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Enable the clock gates used by this case (GPIOH has no clock gate) */
    __HAL_SMU_GPIOD_CLK_ENABLE();

    /* Outputs: GPIOD pins 0..3 push-pull. Inputs: pins 4..5 with a pull-up,
       the internal self check of the input path drives the level through that
       pull, so the pins only have to be left floating. */
    gpio_Configure(GPIOD, GPIOD_OUT_PIN, GPIO_MODE_OUTPUT_PP, GPIO_NOPULL);
    gpio_Configure(GPIOD, GPIOD_IN_PIN, GPIO_MODE_INPUT, GPIO_PULLUP);

    /* ---- Step 1: set and clear through the bit registers (checks 0..1) --- */

    HAL_GPIO_WritePin(GPIOD, GPIOD_OUT_PIN, GPIO_PIN_SET);
    ok = ((GPIO_READ_REG(GPIOD, OCR) & (uint32)GPIOD_OUT_PIN) == (uint32)GPIOD_OUT_PIN);
    if (HAL_GPIO_ReadOutputPin(GPIOD, GPIO_PIN_0) != GPIO_PIN_SET)
    {
        ok = 0U;
    }
    check(0U, ok);

    HAL_GPIO_WritePin(GPIOD, GPIOD_OUT_PIN, GPIO_PIN_RESET);
    ok = ((GPIO_READ_REG(GPIOD, OCR) & (uint32)GPIOD_OUT_PIN) == 0U);
    check(1U, ok);

    /* ---- Step 2: toggle (checks 2..3) ------------------------------------ */

    HAL_GPIO_TogglePin(GPIOD, GPIOD_OUT_PIN);
    ok = ((GPIO_READ_REG(GPIOD, OCR) & (uint32)GPIOD_OUT_PIN) == (uint32)GPIOD_OUT_PIN);
    if (HAL_GPIO_ReadOutputPin(GPIOD, GPIO_PIN_3) != GPIO_PIN_SET)
    {
        ok = 0U;
    }
    check(2U, ok);

    HAL_GPIO_TogglePin(GPIOD, GPIOD_OUT_PIN);
    ok = ((GPIO_READ_REG(GPIOD, OCR) & (uint32)GPIOD_OUT_PIN) == 0U);
    check(3U, ok);

    /* ---- Step 3: whole register write and read back (checks 4..6) -------- */

    HAL_GPIO_WritePort(GPIOD, GPIOD_PORT_PATTERN);
    ok = (HAL_GPIO_ReadOutputPort(GPIOD) == (uint32)GPIOD_PORT_PATTERN);
    check(4U, ok);

    ok = (HAL_GPIO_ReadOutputPin(GPIOD, GPIO_PIN_7) == GPIO_PIN_SET);
    if (HAL_GPIO_ReadOutputPin(GPIOD, GPIO_PIN_0) != GPIO_PIN_RESET)
    {
        ok = 0U;
    }
    check(5U, ok);

    /* The whole port value is written, so the pins outside the pattern are
       cleared as well */
    ok = ((GPIO_READ_REG(GPIOD, OCR) & (uint32)GPIOD_OUT_PIN) == 0U);
    check(6U, ok);

    /* ---- Step 4: GPIO_PIN_All (checks 7..8) ------------------------------ */

    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_All, GPIO_PIN_SET);
    ok = (GPIO_READ_REG(GPIOD, OCR) == 0x0000FFFFU);
    check(7U, ok);

    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_All, GPIO_PIN_RESET);
    ok = (GPIO_READ_REG(GPIOD, OCR) == 0x00000000U);
    check(8U, ok);

    /* ---- Step 5: input path self check, no external signal (checks 9..11) - */

    ok = (HAL_GPIO_ReadPin(GPIOD, GPIOD_IN_PIN_4) == GPIO_PIN_SET);
    if (HAL_GPIO_ReadPin(GPIOD, GPIOD_IN_PIN_5) != GPIO_PIN_SET)
    {
        ok = 0U;
    }
    if ((GPIO_READ_REG(GPIOD, IRR) & (uint32)GPIOD_IN_PIN) != (uint32)GPIOD_IN_PIN)
    {
        ok = 0U;
    }
    if ((HAL_GPIO_ReadInputPort(GPIOD) & (uint32)GPIOD_IN_PIN) != (uint32)GPIOD_IN_PIN)
    {
        ok = 0U;
    }
    check(9U, ok);

    /* Pin 5 is switched to a pull-down, so only pin 4 keeps reading high */
    gpio_Configure(GPIOD, GPIOD_IN_PIN_5, GPIO_MODE_INPUT, GPIO_PULLDOWN);
    ok = (HAL_GPIO_ReadPin(GPIOD, GPIOD_IN_PIN_5) == GPIO_PIN_RESET);
    if (HAL_GPIO_ReadPin(GPIOD, GPIOD_IN_PIN_4) != GPIO_PIN_SET)
    {
        ok = 0U;
    }
    if ((HAL_GPIO_ReadInputPort(GPIOD) & (uint32)GPIOD_IN_PIN) != (uint32)GPIOD_IN_PIN_4)
    {
        ok = 0U;
    }
    check(10U, ok);

    /* Both inputs pulled down, so both read low */
    gpio_Configure(GPIOD, GPIOD_IN_PIN_4, GPIO_MODE_INPUT, GPIO_PULLDOWN);
    ok = (HAL_GPIO_ReadPin(GPIOD, GPIOD_IN_PIN_4) == GPIO_PIN_RESET);
    if (HAL_GPIO_ReadPin(GPIOD, GPIOD_IN_PIN_5) != GPIO_PIN_RESET)
    {
        ok = 0U;
    }
    if ((HAL_GPIO_ReadInputPort(GPIOD) & (uint32)GPIOD_IN_PIN) != 0U)
    {
        ok = 0U;
    }
    check(11U, ok);

    /* ---- Step 6: GPIOH availability on the write path (checks 12..14) ---- */

    gpio_Configure(GPIOH, GPIOH_OUT_PIN, GPIO_MODE_OUTPUT_PP, GPIO_NOPULL);

    /* GPIO_PIN_All names the channels 10..15, which the port does not have */
    ocr_before = GPIO_READ_REG(GPIOH, OCR);
    HAL_GPIO_WritePin(GPIOH, GPIO_PIN_All, GPIO_PIN_SET);
    ocr_after = GPIO_READ_REG(GPIOH, OCR);
    ok = (ocr_after == ocr_before);
    check(12U, ok);

    /* The same rule applies to a single non existing channel */
    HAL_GPIO_WritePin(GPIOH, GPIO_PIN_10, GPIO_PIN_SET);
    ok = (GPIO_READ_REG(GPIOH, OCR) == ocr_before);
    check(13U, ok);

    /* An existing channel is accepted */
    HAL_GPIO_WritePin(GPIOH, GPIO_PIN_2, GPIO_PIN_SET);
    ok = ((GPIO_READ_REG(GPIOH, OCR) & (uint32)GPIO_PIN_2) == (uint32)GPIO_PIN_2);
    if (HAL_GPIO_ReadOutputPin(GPIOH, GPIO_PIN_2) != GPIO_PIN_SET)
    {
        ok = 0U;
    }
    check(14U, ok);

    /* ---- Step 7: rejected arguments (checks 15..17) ---------------------- */

    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_0 | GPIO_PIN_1, GPIO_PIN_SET);
    ocr_before = GPIO_READ_REG(GPIOD, OCR);

    /* an empty pin mask, a NULL port and an unsupported pin state are refused
       without any register access */
    HAL_GPIO_WritePin(GPIOD, 0U, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(NULL_PTR, GPIO_PIN_0 | GPIO_PIN_1, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_0 | GPIO_PIN_1, INVALID_PIN_STATE);
    HAL_GPIO_TogglePin(GPIOD, 0U);
    HAL_GPIO_TogglePin(NULL_PTR, GPIO_PIN_0);
    ocr_after = GPIO_READ_REG(GPIOD, OCR);
    ok = (ocr_after == ocr_before);
    check(15U, ok);

    /* a rejected read returns GPIO_PIN_RESET */
    ok = (HAL_GPIO_ReadPin(GPIOD, 0U) == GPIO_PIN_RESET);
    if (HAL_GPIO_ReadPin(NULL_PTR, GPIO_PIN_4) != GPIO_PIN_RESET)
    {
        ok = 0U;
    }
    if (HAL_GPIO_ReadOutputPin(GPIOD, 0U) != GPIO_PIN_RESET)
    {
        ok = 0U;
    }
    check(16U, ok);

    /* a rejected whole port access returns zero and writes nothing */
    ocr_before = GPIO_READ_REG(GPIOD, OCR);
    HAL_GPIO_WritePort(NULL_PTR, 0xFFFFU);
    ocr_after = GPIO_READ_REG(GPIOD, OCR);
    ok = (ocr_after == ocr_before);
    if (HAL_GPIO_ReadOutputPort(NULL_PTR) != 0U)
    {
        ok = 0U;
    }
    if (HAL_GPIO_ReadInputPort(NULL_PTR) != 0U)
    {
        ok = 0U;
    }
    check(17U, ok);

    /* Every check has been recorded; the loop keeps the observables alive */
    while (1)
    {
        delay_ms(500U);
    }
}

/**
 * @brief  Record the result of one check.
 * @param  index: check number, used as the bit position of the mask.
 * @param  condition: 1 when the check passed, 0 when it failed.
 * @retval None
 */
static void check(uint32 index, uint32 condition)
{
    Check_Count++;

    if (condition != 0U)
    {
        Passed_Mask |= ((uint32)0x01U << index);
    }
    else
    {
        Failed_Mask |= ((uint32)0x01U << index);
    }
}

/**
 * @brief  Configure some pins of one port of the device under test.
 * @param  GPIOx: port to configure.
 * @param  pin: pin mask to configure.
 * @param  mode: mode of the pins.
 * @param  pull: input type of the pins.
 * @retval None
 */
static void gpio_Configure(GPIO_TypeDef *GPIOx, uint32 pin, uint32 mode, uint32 pull)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    __HAL_CLEAR_STRUCT(&GPIO_InitStruct);
    GPIO_InitStruct.Size         = sizeof(GPIO_InitTypeDef);
    GPIO_InitStruct.Version      = GPIO_INIT_VERSION;
    GPIO_InitStruct.Pin          = pin;
    GPIO_InitStruct.Mode         = mode;
    GPIO_InitStruct.Pull         = pull;
    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    GPIO_InitStruct.Alternate    = GPIO_AF_Pin_x;

    HAL_GPIO_Init(GPIOx, &GPIO_InitStruct);
}

/**
 * @brief  Configure the system clock tree (PLL 180 MHz, as the original test).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef  SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef   SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    HAL_PMU_LDO2v5VOLSca(&hpmu, 0xf);
    HAL_PMU_LDO1v2VOLSca(&hpmu, 0xf);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it (CLKFRQ above), so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Clock tree order: this is the order the chip requires, and the vendor
       test case uses the same one.
         1. Write the bus clock dividers while the system clock is still the
            power-on source (FIRC), so that the new divider values are already
            in place when the faster clock arrives. Writing them AFTER the
            switch instead leaves the buses at their reset dividers for a
            moment at the new core clock: at 180 MHz that is
            AXI4Bus3 = 90 MHz and APBBus0 = 45 MHz, right at their ratings, and
            the core does not survive it (measured on the board: the core
            trapped before the divider write was reached, so no output was
            produced at all).
         2. Program the EFLASH controller clock: the controller must already
            know the final frequency while the code still runs from the flash.
         3. Then configure the PLL and switch the system clock to it; this call
            also updates SystemCoreClock and re-initializes the HAL time base. */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
