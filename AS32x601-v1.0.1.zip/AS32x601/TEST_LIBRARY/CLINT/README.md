# CLINT 应用与测试参考

供 skill 按需求检索 AS32x601 HAL CLINT 示例。关键词：本地中断、MSI、MTI、软件中断、周期定时、比较器、64 位计数器、tick、句柄锁。共有 6 个独立用例。

HAL 依据：[头文件](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_clint.h)、[实现](../../HAL_LIBRARY/peripherals/src/as32x601_hal_clint.c)。按所选案例核对当前驱动，不以接口索引代替实现依据。


## 实例与相关资源

本模块不单独列出外部通信引脚组。按实际功能核对实例、时钟、中断、内存或数据通路；关联 GPIO、定时器或其他外设时，再读取对应分支的引脚资料。具体资源与案例配置见下文。

## 生成前需确认的参数

已有工程、板级资料或用户已明确的值直接复用。仅对影响本次实现的缺失选择使用参数卡询问并等待答复；案例配置不能代替实际接线或应用参数。

| 参数 | 需要核对或确认的内容 |
|---|---|
| 时基与实例 | 实际 CLINT 时钟频率、目标核与中断来源 |
| 定时行为 | 周期/单次、时间精度及中断处理要求 |

## 按需求选择

| 用户需求 / 检索关键词 | 推荐用例 | 选择条件 / 需要补充的逻辑 |
|---|---|---|
| 按键启动周期定时；组合演示软件与定时中断 | [001](CLINT_IT_DRV_001.c) | K1=PE10、K2=PB4，按目标板修改引脚 |
| 初始化、反初始化、状态与错误、比较值镜像复位 | [002](CLINT_IT_DRV_002.c) | 生命周期检查，不作为最小定时器模板 |
| 产生和清除机器软件中断；MSI | [003](CLINT_IT_DRV_003.c) | 配置本地中断使能，及时清除挂起 |
| 周期 tick；MTI；比较器重装与漂移验证 | [004](CLINT_IT_DRV_004.c) | 示例周期 1 s，保留驱动重装和回调 |
| 读取 64 位计数器；单调计时；测量时间差 | [005](CLINT_IT_DRV_005.c) | 计数不是毫秒，按实际时钟频率换算 |
| 句柄锁、HAL_BUSY 与解锁恢复 | [006](CLINT_IT_DRV_006.c) | 裸机锁检查，不能代替 RTOS 并发测试 |
| 一次性定时、低功耗计时、RTOS 调度 | 无直接完整模板 | 周期和计数用例可作底层参考，应用逻辑另行设计 |

## 实现要点与案例配置

001 的 K1 启动后持续周期运行，不是每次按键仅触发一次。仅需软件中断选 003，仅需周期定时选 004。MSI / MTI 属于内核本地中断，001 的 GPIO 按键才经过 PLIC。

软件入口 `MSoftWare_IRQ_Handler()` 中参考 `HAL_CLINT_ClearSoftInt()` 清除挂起。定时入口 `MTimer_IRQ_Handler()` 转发 `HAL_CLINT_IRQHandler()`，随后执行 `HAL_CLINT_TickCallback()`。

004 验证屏蔽时不计 tick、使能后周期运行、比较值镜像推进和累计漂移。`HAL_CLINT_GetTimerComparator()` 返回软件计划值镜像，不能当作独立硬件回读。005 比较 1 s 延时中的计数增量与 `SystemCoreClock`。`HAL_CLINT_SetTickPeriod()` 的周期单位是计数 tick，示例用秒数乘以 `SystemCoreClock`，不能直接传入毫秒数。复用时核对频率与比较器所有权。

在 RV32 上，GetTimerComparator 返回的 64 位句柄镜像可能在读取两个半字之间被定时中断更新；它不保证运行中得到一致快照。该接口适合诊断或停用时间基准后的观察，不能用来精确测量时间差。测量经过时间应使用 HAL_CLINT_ReadTimerValue，其实现按高位复读规则取得一致计数。

## 验证方法与适用边界

每个源码有独立 `main()`；组合需求可阅读多个用例，不直接合并多个入口。读取完整初始化、中断、回调和主循环，按目标板调整时钟、引脚和测试逻辑。

本次为源码静态整理，未重新编译或上板；源码已有测试记录与本次验证状态分别判断。

## 按接口与辅助宏检索

来自去除注释后的源码调用或定义，包含 HAL 接口、锁助手、寄存器及参数校验宏。MSP、IRQ、回调可能是定义或转发入口，应结合完整源码阅读；出现不代表所有分支均已覆盖。

| 接口 / 宏 | 参考用例 |
|---|---|
| `CLINT_LockHandle` | [006](CLINT_IT_DRV_006.c) |
| `CLINT_UnlockHandle` | [006](CLINT_IT_DRV_006.c) |
| `HAL_CLINT_ClearSoftInt` | [001](CLINT_IT_DRV_001.c)、[003](CLINT_IT_DRV_003.c)、[006](CLINT_IT_DRV_006.c) |
| `HAL_CLINT_DeInit` | [002](CLINT_IT_DRV_002.c) |
| `HAL_CLINT_GetError` | [001](CLINT_IT_DRV_001.c)、[002](CLINT_IT_DRV_002.c)、[003](CLINT_IT_DRV_003.c)、[004](CLINT_IT_DRV_004.c)、[006](CLINT_IT_DRV_006.c) |
| `HAL_CLINT_GetState` | [001](CLINT_IT_DRV_001.c)、[002](CLINT_IT_DRV_002.c)、[003](CLINT_IT_DRV_003.c)、[006](CLINT_IT_DRV_006.c) |
| `HAL_CLINT_GetTimerComparator` | [001](CLINT_IT_DRV_001.c)、[002](CLINT_IT_DRV_002.c)、[004](CLINT_IT_DRV_004.c) |
| `HAL_CLINT_IRQHandler` | [001](CLINT_IT_DRV_001.c)、[004](CLINT_IT_DRV_004.c) |
| `HAL_CLINT_Init` | [001](CLINT_IT_DRV_001.c)、[002](CLINT_IT_DRV_002.c)、[003](CLINT_IT_DRV_003.c)、[004](CLINT_IT_DRV_004.c)、[005](CLINT_IT_DRV_005.c)、[006](CLINT_IT_DRV_006.c) |
| `HAL_CLINT_ReadTimerValue` | [001](CLINT_IT_DRV_001.c)、[002](CLINT_IT_DRV_002.c)、[004](CLINT_IT_DRV_004.c)、[005](CLINT_IT_DRV_005.c) |
| `HAL_CLINT_SetTickPeriod` | [001](CLINT_IT_DRV_001.c)、[004](CLINT_IT_DRV_004.c) |
| `HAL_CLINT_SetTimerComparator` | [001](CLINT_IT_DRV_001.c)、[002](CLINT_IT_DRV_002.c) |
| `HAL_CLINT_SoftIntCmd` | [001](CLINT_IT_DRV_001.c)、[003](CLINT_IT_DRV_003.c)、[006](CLINT_IT_DRV_006.c) |
| `HAL_CLINT_TickCallback` | [001](CLINT_IT_DRV_001.c)、[004](CLINT_IT_DRV_004.c) |
| `HAL_CLINT_TimerIntCmd` | [001](CLINT_IT_DRV_001.c)、[004](CLINT_IT_DRV_004.c) |

