/**
 * @file    CLINT_IT_DRV_001.c
 * @brief   HAL CLINT integration test case 001 (software + timer interrupt).
 *
 * One-to-one HAL library port of the original AS32x601 standard-library
 * test case CLINT_IT_DRV_001.c. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_CLINT_Init()
 *   HAL_CLINT_ReadTimerValue()
 *   HAL_CLINT_SetTimerComparator() (manual programming, mirror kept in step)
 *   HAL_CLINT_GetTimerComparator() (software mirror of the planned instant,
 *   forgotten by HAL_CLINT_Init())
 *   HAL_CLINT_SoftIntCmd()
 *   HAL_CLINT_ClearSoftInt() (interrupt safe clear used by the MSI handler)
 *   HAL_CLINT_SetTickPeriod() (zero period rejected, 1 s period accepted)
 *   HAL_CLINT_TimerIntCmd() (system time base enable / disable)
 *   HAL_CLINT_IRQHandler() + HAL_CLINT_TickCallback() (periodic tick service)
 *
 * Test procedure:
 *   1. Initialize the CLINT and program the system time base period (1 s);
 *   2. Press K1 (GPIOE10) to enable the machine timer interrupt (MTI) through
 *      the driver, hence to start the periodic tick;
 *   3. Press K2 (GPIOB4) to enable the machine software interrupt (MSI).
 *
 * Expected behaviour:
 *   - A zero period is rejected by HAL_CLINT_SetTickPeriod() with
 *     HAL_CLINT_ERROR_INVALID_PARAM (checked before the lock is taken);
 *   - After K1, the machine timer interrupt is taken periodically:
 *     MTimer_IRQ_Handler() forwards it to HAL_CLINT_IRQHandler(), which reloads
 *     the comparator one period ahead and runs HAL_CLINT_TickCallback();
 *   - After K2, the machine software interrupt is taken:
 *     MSoftWare_IRQ_Handler() prints the interrupt and clears the pending bit.
 *
 * Note: the original test case programmed the comparator by hand and masked
 * the machine timer interrupt inside the handler, which produced one
 * interrupt per K1 press.  The driver owns the periodic reload now, so the
 * ticks continue once K1 has been pressed (this is the behaviour the system
 * time base requires).
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"
#include "core_riscv.h"          /* csr_set_bits / csr_clear_bits / CSR_MIE   */

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Key pins: K1 = GPIOE10, K2 = GPIOB4 (as in the original test case) */
#define K1_GPIO                     GPIOE
#define K1_PIN                      GPIO_PIN_10
#define K2_GPIO                     GPIOB
#define K2_PIN                      GPIO_PIN_4

/* Timer comparator reload step: 1 s of CLINT real-time counter ticks */
#define TIMER_STEP_SECONDS          (1U)

/* Private variables ---------------------------------------------------------*/
static HAL_CLINT_HandleTypeDef hclint_dev; /*!< CLINT handle                 */
static volatile uint8  k1_flag = 0U;        /*!< K1 pressed flag              */
static volatile uint8  k2_flag = 0U;        /*!< K2 pressed flag              */
static volatile uint32 softint_count = 0U;  /*!< software interrupt counter   */
static volatile uint32 timerint_count = 0U; /*!< timer interrupt counter      */

static HAL_SMU_HandleTypeDef hsmu_clk;   /*!< SMU handle (lock / state / error) */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void KEY_GPIO_Init(void);
static void KEY_PLIC_Init(void);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    uint64 mtime;
    uint64 compare;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== CLINT_IT_DRV_001: software / timer interrupt ===\r\n");

    /* Initialize the CLINT peripheral */
    hclint_dev.Instance = CLINT;
    if (HAL_CLINT_Init(&hclint_dev) != HAL_OK)
    {
        printf("HAL_CLINT_Init failed\r\n");
        while (1)
        {
        }
    }

    /* Step 0a: the comparator can also be programmed by hand.  The value is
     * written to the hardware and recorded in the software mirror, so that the
     * periodic reload of the time base advances from it (the comparator
     * registers are write only and cannot be read back to recover the value). */
    compare = HAL_CLINT_ReadTimerValue(&hclint_dev) + (TIMER_STEP_SECONDS * SystemCoreClock);
    HAL_CLINT_SetTimerComparator(&hclint_dev, compare);
    printf("manual compare: 0x%08X%08X, mirror 0x%08X%08X [%s]\r\n",
           PRINT_U32(compare >> 32U), PRINT_U32(compare),
           PRINT_U32(HAL_CLINT_GetTimerComparator(&hclint_dev) >> 32U),
           PRINT_U32(HAL_CLINT_GetTimerComparator(&hclint_dev)),
           ((HAL_CLINT_GetTimerComparator(&hclint_dev) == compare) ? "PASS" : "FAIL"));

    /* Step 0b: a fresh initialization forgets the planned instant, so a stale
     * value can never become the base of the periodic reload (the programmed
     * tick period is the only thing that survives, and it is zero here). */
    if (HAL_CLINT_Init(&hclint_dev) != HAL_OK)
    {
        printf("HAL_CLINT_Init (re-init) failed\r\n");
        while (1)
        {
        }
    }
    printf("mirror after re-init: 0x%08X%08X %s\r\n",
           PRINT_U32(HAL_CLINT_GetTimerComparator(&hclint_dev) >> 32U),
           PRINT_U32(HAL_CLINT_GetTimerComparator(&hclint_dev)),
           ((HAL_CLINT_GetTimerComparator(&hclint_dev) == 0U) ? "[PASS]" : "[FAIL]"));

    /* Step 1: a zero period must be rejected before any register access */
    if (HAL_CLINT_SetTickPeriod(&hclint_dev, 0U) == HAL_ERROR)
    {
        printf("zero period rejected, error = 0x%08X [%s]\r\n",
               PRINT_U32(HAL_CLINT_GetError(&hclint_dev)),
               ((HAL_CLINT_GetError(&hclint_dev) == HAL_CLINT_ERROR_INVALID_PARAM)
                    ? "PASS" : "FAIL"));
    }
    else
    {
        printf("zero period NOT rejected [FAIL]\r\n");
    }

    /* Step 2: program the system time base period (1 s) through the driver,
     * which also arms the first tick one period ahead of the counter */
    if (HAL_CLINT_SetTickPeriod(&hclint_dev,
                                TIMER_STEP_SECONDS * SystemCoreClock) != HAL_OK)
    {
        printf("HAL_CLINT_SetTickPeriod failed\r\n");
        while (1)
        {
        }
    }

    mtime = HAL_CLINT_ReadTimerValue(&hclint_dev);
    printf("CLINT state  : %u (1 = READY)\r\n",
           PRINT_U32(HAL_CLINT_GetState(&hclint_dev)));
    printf("mtime        : 0x%08X%08X\r\n",
           PRINT_U32(mtime >> 32U), PRINT_U32(mtime));
    printf("tick period  : %u counter ticks (1 s), error = 0x%08X\r\n",
           PRINT_U32(TIMER_STEP_SECONDS * SystemCoreClock),
           PRINT_U32(HAL_CLINT_GetError(&hclint_dev)));

    /* The compare value mirror is a software record of the instant that was
     * planned (the comparator registers cannot be read back).  After the first
     * arming it must be non zero and must still lie in the future, one period
     * ahead of the counter read when the period was programmed. */
    compare = HAL_CLINT_GetTimerComparator(&hclint_dev);
    printf("compare mirror: 0x%08X%08X (planned instant)\r\n",
           PRINT_U32(compare >> 32U), PRINT_U32(compare));
    printf("mirror is ahead of mtime by %u ticks %s\r\n",
           PRINT_U32((uint32)(compare - mtime)),
           (((compare != 0U) && (compare > mtime)) ? "[PASS]" : "[FAIL]"));
    printf("Press K1 to enable MTI, press K2 to enable MSI\r\n");

    /* Configure the keys and their PLIC interrupt sources */
    KEY_GPIO_Init();
    KEY_PLIC_Init();

    while (1)
    {
        if (k1_flag != 0U)
        {
            k1_flag = 0U;
            /* Step 3: enable the machine timer interrupt through the driver:
             * the periodic reload is done by HAL_CLINT_IRQHandler() */
            HAL_CLINT_TimerIntCmd(&hclint_dev, ENABLE);
            printf("K1: MTI enabled\r\n");
        }

        if (k2_flag != 0U)
        {
            k2_flag = 0U;
            /* Step 4: enable the machine software interrupt and raise it. The
             * machine software interrupt enable bit is not handled by the
             * driver, it is set here (see CLINT VS-REQ-002) */
            csr_set_bits(CSR_MIE, MIE_MSIE);
            HAL_CLINT_SoftIntCmd(&hclint_dev, ENABLE);
            printf("K2: MSI enabled and triggered\r\n");
        }
    }
}

/**
 * @brief  Machine software interrupt handler (weak symbol of the trap entry).
 * @param  None
 * @retval None
 */
void MSoftWare_IRQ_Handler(void)
{
    /* Clear the pending bit and mask the source until the next K2 press */
    /* Interrupt safe clear: takes no handle lock (LOCK-04 / RTOS-12) */
    HAL_CLINT_ClearSoftInt(&hclint_dev);
    csr_clear_bits(CSR_MIE, MIE_MSIE);

    softint_count++;
    printf("[MSI] software interrupt #%u\r\n", PRINT_U32(softint_count));
}

/**
 * @brief  Machine timer interrupt handler (weak symbol of the trap entry).
 * @note   Trampoline of the system time base: the driver entry answers the
 *         interrupt by reloading the comparator and then runs the tick
 *         callback.  No lock is taken here (LOCK-04 / RTOS-12).
 * @param  None
 * @retval None
 */
void MTimer_IRQ_Handler(void)
{
    HAL_CLINT_IRQHandler(&hclint_dev);
}

/**
 * @brief  System time base tick callback (weak symbol of the CLINT driver).
 * @note   Runs in interrupt context once per period, after the next tick has
 *         been armed by HAL_CLINT_IRQHandler().
 * @param  hclint: CLINT handle.
 * @retval None
 */
void HAL_CLINT_TickCallback(HAL_CLINT_HandleTypeDef *hclint)
{
    uint64 now = HAL_CLINT_ReadTimerValue(hclint);

    timerint_count++;

    printf("[MTI] timer interrupt #%u, mtime = 0x%08X%08X\r\n",
           PRINT_U32(timerint_count), PRINT_U32(now >> 32U), PRINT_U32(now));
}

/**
 * @brief  Configure the KEY GPIOs (K1 = GPIOE10, K2 = GPIOB4, pull-up input).
 * @param  None
 * @retval None
 */
static void KEY_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    /* Enable the key port clock gates */
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&GPIO_InitStruct);
    GPIO_InitStruct.Size         = sizeof(GPIO_InitStruct);
    GPIO_InitStruct.Version      = GPIO_INIT_VERSION;
    GPIO_InitStruct.Mode         = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull         = GPIO_PULLUP;
    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;
    GPIO_InitStruct.Alternate    = GPIO_AF_Pin_x;

    /* K1 = GPIOE10 */
    GPIO_InitStruct.Pin = K1_PIN;
    HAL_GPIO_Init(K1_GPIO, &GPIO_InitStruct);

    /* K2 = GPIOB4 */
    GPIO_InitStruct.Pin = K2_PIN;
    HAL_GPIO_Init(K2_GPIO, &GPIO_InitStruct);

    /* Clear the pending state before enabling the falling edge detection */
    HAL_GPIO_ClearITPendingBit(K1_GPIO, K1_PIN);
    HAL_GPIO_ClearITPendingBit(K2_GPIO, K2_PIN);
    HAL_GPIO_ITConfig(K1_GPIO, K1_PIN, GPIO_ITType_EDGEDOWN, ENABLE);
    HAL_GPIO_ITConfig(K2_GPIO, K2_PIN, GPIO_ITType_EDGEDOWN, ENABLE);
}

/**
 * @brief  Configure the PLIC sources of the key ports.
 * @param  None
 * @retval None
 */
static void KEY_PLIC_Init(void)
{
    PLIC_InitTypeDef plic;

    __HAL_SMU_PLIC_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&plic);
    plic.Size             = sizeof(plic);
    plic.Version          = PLIC_INIT_VERSION;
    plic.PLIC_IRQPriority = 1U;
    plic.PLIC_IRQChannelCmd = ENABLE;

    /* K1 port: GPIOE_IRQn */
    plic.PLIC_IRQChannel = GPIOE_IRQn;
    HAL_PLIC_Init(&plic);

    /* K2 port: GPIOB_IRQn */
    plic.PLIC_IRQChannel = GPIOB_IRQn;
    HAL_PLIC_Init(&plic);
}

/**
 * @brief  GPIOE port interrupt handler (K1).
 * @param  None
 * @retval None
 */
void GPIOE_IRQ_Handler(void)
{
    HAL_GPIO_IRQHandler(GPIOE);
}

/**
 * @brief  GPIOB port interrupt handler (K2).
 * @param  None
 * @retval None
 */
void GPIOB_IRQ_Handler(void)
{
    HAL_GPIO_IRQHandler(GPIOB);
}

/**
 * @brief  GPIOE port interrupt line callback (K1).
 * @param  GPIO_Pin: pin mask of the pending pin of the GPIOE port.
 * @retval None
 */
void HAL_GPIOE_EXTI_Callback(uint16 GPIO_Pin)
{
    if ((GPIO_Pin & K1_PIN) != 0U)
    {
        k1_flag = 1U;
    }
}

/**
 * @brief  GPIOB port interrupt line callback (K2).
 * @param  GPIO_Pin: pin mask of the pending pin of the GPIOB port.
 * @retval None
 */
void HAL_GPIOB_EXTI_Callback(uint16 GPIO_Pin)
{
    if ((GPIO_Pin & K2_PIN) != 0U)
    {
        k2_flag = 1U;
    }
}

/**
 * @brief  Configure the system clock tree using the HAL SMU driver.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef  SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef   SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it (CLKFRQ above), so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Clock tree order: this is the order the chip requires, and the vendor
       test case uses the same one.
         1. Write the bus clock dividers while the system clock is still the
            power-on source (FIRC), so that the new divider values are already
            in place when the faster clock arrives. Writing them AFTER the
            switch instead leaves the buses at their reset dividers for a
            moment at the new core clock: at 180 MHz that is
            AXI4Bus3 = 90 MHz and APBBus0 = 45 MHz, right at their ratings, and
            the core does not survive it (measured on the board: the core
            trapped before the divider write was reached, so no output was
            produced at all).
         2. Program the EFLASH controller clock: the controller must already
            know the final frequency while the code still runs from the flash.
         3. Then configure the PLL and switch the system clock to it; this call
            also updates SystemCoreClock and re-initializes the HAL time base. */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
