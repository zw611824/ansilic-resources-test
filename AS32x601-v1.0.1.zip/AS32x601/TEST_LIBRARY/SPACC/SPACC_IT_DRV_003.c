/**
 * @file    SPACC_IT_DRV_003.c
 * @brief   HAL SPACC integration test case 003 (SM3 hash).
 *
 * SM3 hash of one 335-byte message carried through the pre-AAD field.
 *
 * Tested functionality:
 *   HAL_SPACC_StructInit / HAL_SPACC_Init / HAL_SPACC_PacketInit / HAL_SPACC_StateFIFOFlag / HAL_SPACC_CommandExecResult (the digest is read from the destination buffer, no context access is needed).
 *
 * Expected behaviour:
 *   the 256-bit SM3 digest equals the reference vector, so the summary stays at zero failures.
 *
 * @note    The packet vectors are the ones of the reference test project
 *          (SPACC_IT_DRV_003.c) and are reproduced verbatim, so a case can be
 *          compared one to one with the reference output.
 * @note    The SPACC needs the AXILite4-Bus1 (DSE) clock gate and reset
 *          release: HAL_SPACC_MspInit() is overridden at the end of this file
 *          to do that and to count its calls.
 * @note    The DDT structures are 8-byte aligned through a union with a 64-bit
 *          member, because the driver validates the alignment of the DDT bus
 *          address (SRC_PTR.PTR starts at bit 3).
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Software identifier carried by every submitted task */
#define TEST_SOFTWARE_ID            (0x2DU)

/* Bound of every polling loop (the SPACC completes in microseconds) */
#define TEST_WAIT_GUARD             (20000000U)

/* Reporting period of the final loop (ms) */
#define TEST_POLL_MS                (1000U)

/* Unknown instance used by the handle validation checks */
#define TEST_BAD_INSTANCE           ((SPACC_TypeDef *)0x40000000UL)

/* Processed packet size, in 32-bit words, of this case */
#define TEST_PACKET_WORDS           (84U)

/* Byte-swap helper: the SPACC consumes the packet in the opposite byte order
 * of the C representation, exactly as the reference test project does. */
#define TEST_SWAP32(__VALUE__)      ((((__VALUE__) & 0x000000FFUL) << 24) | \
                                     (((__VALUE__) & 0x0000FF00UL) << 8)  | \
                                     (((__VALUE__) & 0x00FF0000UL) >> 8)  | \
                                     (((__VALUE__) & 0xFF000000UL) >> 24))

/* Private typedef -----------------------------------------------------------*/
/**
 * @brief Data descriptor table (DDT) of a packet segment list.
 * @note  The SPACC reads SRC_PTR / DST_PTR as the bus address of a DDT whose
 *        first pointer is kept on an 8-byte boundary (PTR field starts at bit
 *        3), so the two DDT instances below are wrapped in a union with a
 *        64-bit member to force that alignment on every toolchain.
 */
typedef struct
{
    uint32 *Ptr_0;
    uint32  Len_0;
    uint32 *Ptr_1;
    uint32  Len_1;
} SPACC_DDTTypeDef;

typedef union
{
    SPACC_DDTTypeDef ddt;
    uint64           force_align8;
} SPACC_DDTAlignedTypeDef;

/* Private variables ---------------------------------------------------------*/
static HAL_SPACC_HandleTypeDef hspacc_dev;          /*!< handle under test      */
static HAL_SMU_HandleTypeDef   hsmu_clk;            /*!< SMU handle (clock)     */
static SPACC_InitTypeDef       spacc_init;          /*!< configuration          */
static SPACC_PacketTypeDef     spacc_packet;        /*!< packet descriptor      */
static SPACC_DDTAlignedTypeDef spacc_ddt_src;       /*!< source DDT (8B aligned)*/
static SPACC_DDTAlignedTypeDef spacc_ddt_dst;       /*!< destination DDT        */

/* Accumulated check counters */
static uint32 failures = 0U;
static uint32 checks = 0U;

/* Low level callback instrumentation */
static uint32 msp_init_count = 0U;
static uint32 msp_deinit_count = 0U;
static uint32 error_callback_count = 0U;

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void Section(const char *name);
static void Check(const char *name, uint32 condition);
static void Summary(void);
static void Spacc_StageDdt(uint32 *src, uint32 src_bytes, uint32 *dst, uint32 dst_bytes);
static HAL_StatusTypeDef Spacc_WriteCipherContext(const uint32 *words, uint32 count);
static HAL_StatusTypeDef Spacc_ReadCipherContext(uint32 *words, uint32 count);
static uint32 Spacc_WaitResult(uint32 software_id);
static void Spacc_Drain(uint32 limit);


/* Test vectors -------------------------------------------------------------*/
/* vectors extracted verbatim from SPACC_IT_DRV_003.c (only "u32 " normalised to "uint32_t ") */
#define PACKET_LEN	84

/* spacc_sm3_packet [PACKET_LEN] */
uint32_t spacc_sm3_packet[PACKET_LEN] = {0x699356f1, 0x358a24a8, 0xa358d10d, 0x02b0a6c8, 0x09a0bb35, 0x7e744598, 0xd1d66489, 0x10a0bb7c,
                                         0xc8e10edd, 0x467ec947, 0x703bea70, 0x4d8db9e6, 0x42f85662, 0x2386c2fa, 0x2970c5c0, 0x1b14797a,
                                         0xa4fdf11b, 0x63a09eff, 0x66e5c3e4, 0xaa2b9915, 0x85205980, 0x1b64dee9, 0xd1db9c92, 0x3efab1fe,
                                         0xce2e7a8b, 0x4b1595af, 0xad32badb, 0x9ea1bb45, 0xae85d7bd, 0xd92b6daf, 0x6de18fc3, 0x3aee857f,
                                         0xadf20db4, 0x6c120645, 0x34142aae, 0x8d267e0f, 0x9708cbc7, 0x2bf924d7, 0x351fb0ea, 0x2c8b95e7,
                                         0x6e4e528d, 0x84e70516, 0x3b8419b2, 0xba22241f, 0x61b1311a, 0xca60da12, 0x227c0d5c, 0x3a683831,
                                         0x71758f1d, 0x9ee18761, 0x8c2caa3e, 0x1618aa03, 0xf887e4de, 0xa10bd123, 0xb80037b7, 0x1c0b4330,
                                         0x72c2a6fb, 0x7dde9793, 0x3148cb3c, 0x069e13d5, 0x5f48c673, 0xbfab2211, 0xa6e6aca4, 0xbb37b048,
                                         0x3a8e9b29, 0x2af5090d, 0x74bc9a5a, 0x9c8f24b9, 0xe9fad80e, 0x2a061430, 0xc0917b61, 0x8bd93cc8,
                                         0xcd13a726, 0x58505fc4, 0x615b7059, 0x2df70554, 0xc5c45655, 0xfe734e72, 0xc1cee3d3, 0x79f28931,
                                         0x2b5df314, 0xc43377d3, 0x1952319d, 0x2501dc00};

/* spacc_sm3_hash_expect [8] */
uint32_t spacc_sm3_hash_expect[8] = {0xf055fb18, 0xc85a51b3, 0xb4b13d4f, 0x85943c5f, 0x56c4c3c8, 0x7036e91a, 0x0e6fa288, 0x65b284e5};

static uint32 spacc_packet_swp[TEST_PACKET_WORDS];
static uint32 spacc_hash_result[8];
static uint32 ctx_probe[8];
static uint32 ctx_probe_read[8];

/**
 * @brief  Case 003: SM3 hash of one 335-byte message (pre-AAD based input).
 * @retval Never (the final loop keeps reporting).
 */
int main(void)
{
    uint32 i;
    uint32 packet_mismatch = 0U;
    uint32 ctx_ok = 1U;
    HAL_StatusTypeDef status;

    HAL_Init();
    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);

    printf("\r\n ***** SPACC SM3 hash test (case 003) ***** \r\n");
    printf("Data : %s\r\n", __DATE__);
    printf("Time : %s\r\n", __TIME__);
    delay_ms(500U);

    Section("preparation");

    __HAL_CLEAR_STRUCT(&hspacc_dev);
    hspacc_dev.Instance = SPACC;

    /* A warm re-run may leave results behind: drop them before the real task,
     * so the completion check of this run can only observe its own task. */
    Spacc_Drain(8U);
    Check("handle starts in the reset state",
          (HAL_SPACC_GetState(&hspacc_dev) == HAL_SPACC_STATE_RESET) ? 1U : 0U);

    for (i = 0U; i < TEST_PACKET_WORDS; i++)
    {
        spacc_packet_swp[i] = TEST_SWAP32(spacc_sm3_packet[i]);
    }
    for (i = 0U; i < 8U; i++)
    {
        ctx_probe[i] = 0xC0DE0000U + i;
    }
    CLEAR_CACHE();

    /* The message is presented through the pre-AAD field: the source carries
     * PRE_AAD_LEN bytes, the destination only the 8-word digest. */
    Spacc_StageDdt(spacc_packet_swp, (TEST_PACKET_WORDS * 4U),
                   spacc_hash_result, (uint32)sizeof(spacc_hash_result));
    spacc_packet.SPACC_PREAADLen = 0x14FU;
    spacc_packet.SPACC_PROCLen   = 0x14FU;

    Section("descriptor");

    HAL_SPACC_PacketInit(&hspacc_dev, &spacc_packet);
    Check("descriptor accepted", (HAL_SPACC_GetError(&hspacc_dev) == HAL_SPACC_ERROR_NONE) ? 1U : 0U);
    Check("pre-AAD length staged",
          ((SPACC->PRE_AAD_LEN & (uint32)SPACC_PRE_AAD_LEN_LEN) == 0x14FU) ? 1U : 0U);
    Check("processing length staged",
          ((SPACC->PROC_LEN & (uint32)SPACC_PROC_LEN_LEN) == 0x14FU) ? 1U : 0U);

    Section("context memory access");

    /* A pure hash task does not use the cipher context at all; the round trip
     * below only proves that the context window is addressable from the HAL
     * interface used by this suite (it must not influence the digest). */
    status = Spacc_WriteCipherContext(ctx_probe, 8U);
    Check("cipher context writable", (status == HAL_OK) ? 1U : 0U);
    status = Spacc_ReadCipherContext(ctx_probe_read, 8U);
    Check("cipher context readable", (status == HAL_OK) ? 1U : 0U);
    ctx_ok = 1U;
    for (i = 0U; i < 8U; i++)
    {
        if (ctx_probe_read[i] != ctx_probe[i])
        {
            ctx_ok = 0U;
        }
    }
    Check("context write / read round trip", ctx_ok);

    Section("submit and completion");

    /* A pure hash task selects no cipher and no key, so the cipher context of
     * the previous cases is not needed at all. */
    HAL_SPACC_StructInit(&spacc_init);
    spacc_init.SPACC_CipherAlgorithm     = SPACC_CIPHER_ALG_NULL;
    spacc_init.SPACC_SM4CipherMode       = SPACC_SM4_CIPHER_MODE_ECB;
    spacc_init.SPACC_HashAlgorithm       = SPACC_HASH_ALG_SM3;
    spacc_init.SPACC_SM3HashMode         = SPACC_SM3_HASH_MODE_RAW_SHAKE;
    spacc_init.SPACC_TransferMode        = SPACC_TRANS_TO_APPLY_ENCRYPT;
    spacc_init.SPACC_ContextIndex        = 0U;
    spacc_init.SPACC_KeyFrom             = SPACC_KEY_FROM_CTX;
    spacc_init.SPACC_AADCopy             = SPACC_APP_NOT_COPY;
    spacc_init.SPACC_ICVCompute          = SPACC_ICV_COMPUTER_PLAIN;
    spacc_init.SPACC_ICVEncrypt          = SPACC_ICV_NOT_ENCRYPT;
    spacc_init.SPACC_ICVLocation         = SPACC_ICV_LOCATION_OFFSET;
    spacc_init.SPACC_KeyExpand           = SPACC_KEY_EXPAND;
    spacc_init.SPACC_MessageBegin        = SPACC_MSG_BEGIN_FIRST;
    spacc_init.SPACC_MessageEnd          = SPACC_MSG_END_LAST;
    spacc_init.SPACC_SoftwareID          = TEST_SOFTWARE_ID;
    spacc_init.SPACC_PriorityCommandFIFO = 0U;
    spacc_init.SPACC_KeySize             = 0x10U;
    spacc_init.SPACC_KeyIndex            = 0U;
    spacc_init.SPACC_KeyType             = SPACC_KEY_TYPE_CIPHER;

    status = HAL_SPACC_Init(&hspacc_dev, &spacc_init);
    Check("Init accepted (task submitted)", (status == HAL_OK) ? 1U : 0U);
    Check("result available and software ID matched",
          Spacc_WaitResult(TEST_SOFTWARE_ID));
    Check("status FIFO empty after the pop",
          (HAL_SPACC_StateFIFOFlag(&hspacc_dev) == SET) ? 1U : 0U);

    Section("verification");

    for (i = 0U; i < 8U; i++)
    {
        if (spacc_hash_result[i] != TEST_SWAP32(spacc_sm3_hash_expect[i]))
        {
            packet_mismatch++;
            printf("  digest[%u] = %08X, expected %08X\r\n", PRINT_U32(i),
                   PRINT_U32(spacc_hash_result[i]),
                   PRINT_U32(TEST_SWAP32(spacc_sm3_hash_expect[i])));
        }
    }

    Check("SM3 digest equals the expected value", (packet_mismatch == 0U) ? 1U : 0U);
    printf("\r\ndigest: ");
    for (i = 0U; i < 8U; i++)
    {
        printf("%08X", PRINT_U32(spacc_hash_result[i]));
    }
    printf("\r\ndigest mismatches = %u\r\n", PRINT_U32(packet_mismatch));

    Section("result");
    Summary();
    printf("***** SPACC SM3 hash test %s *****\r\n",
           ((failures == 0U) ? "success" : "failed"));

    for (;;)
    {
        delay_ms(TEST_POLL_MS);
    }
}


/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Report one section of the case.
 * @param  name: section name.
 * @retval None
 */
static void Section(const char *name)
{
    printf("\r\n---- %s ----\r\n", name);
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    checks++;

    if (condition == 0U)
    {
        failures++;
    }

    printf("%-58s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Print the check summary.
 * @retval None
 */
static void Summary(void)
{
    printf("\r\nchecks = %u, failures = %u\r\n", PRINT_U32(checks), PRINT_U32(failures));
    printf("summary : failures = %s\r\n", ((failures == 0U) ? "0 (PASS)" : "NON-ZERO (FAIL)"));
}

/**
 * @brief  Fill the two DDT structures and the pointer fields of the descriptor.
 * @param  src: source buffer.
 * @param  src_bytes: source segment length, in bytes.
 * @param  dst: destination buffer.
 * @param  dst_bytes: destination segment length, in bytes.
 * @retval None
 * @note   Both DDTs describe a single segment, the second entry is the NULL
 *         terminator. The byte counts and every offset of the descriptor are
 *         cleared here; the case overrides the fields it needs afterwards.
 */
static void Spacc_StageDdt(uint32 *src, uint32 src_bytes, uint32 *dst, uint32 dst_bytes)
{
    spacc_ddt_src.ddt.Ptr_0 = src;
    spacc_ddt_src.ddt.Len_0 = src_bytes;
    spacc_ddt_src.ddt.Ptr_1 = NULL_PTR;
    spacc_ddt_src.ddt.Len_1 = 0U;

    spacc_ddt_dst.ddt.Ptr_0 = dst;
    spacc_ddt_dst.ddt.Len_0 = dst_bytes;
    spacc_ddt_dst.ddt.Ptr_1 = NULL_PTR;
    spacc_ddt_dst.ddt.Len_1 = 0U;

    spacc_packet.SPACC_SourcePtr        = (uint32)(&spacc_ddt_src.ddt);
    spacc_packet.SPACC_DestinationPtr   = (uint32)(&spacc_ddt_dst.ddt);
    spacc_packet.SPACC_SouPREAADOffset  = 0U;
    spacc_packet.SPACC_DestPREAADOffset = 0U;
    spacc_packet.SPACC_PREAADLen        = 0U;
    spacc_packet.SPACC_POSTAADLen       = 0U;
    spacc_packet.SPACC_PROCLen          = (TEST_PACKET_WORDS * 4U);
    spacc_packet.SPACC_ICVLen           = 0U;
    spacc_packet.SPACC_ICVOffset        = 0U;
    spacc_packet.SPACC_IVOffset         = 0U;
    spacc_packet.SPACC_IVLocation       = SPACC_IV_LOCATION_CONTEXT;

    CLEAR_CACHE();
}

/**
 * @brief  Write the cipher context (key / IV) through the HAL context API.
 * @param  words: context words in the C representation (big endian wording).
 * @param  count: number of words.
 * @retval HAL status of HAL_SPACC_WriteContext().
 * @note   The values are byte swapped in a local buffer before the transfer,
 *         because the SPACC context store keeps them in the opposite order
 *         (the reference test project writes them through the same swap).
 */
static HAL_StatusTypeDef Spacc_WriteCipherContext(const uint32 *words, uint32 count)
{
    uint32 swapped[16];
    uint32 i;

    for (i = 0U; (i < count) && (i < 16U); i++)
    {
        swapped[i] = TEST_SWAP32(words[i]);
    }

    return HAL_SPACC_WriteContext(&hspacc_dev, SPACC_CIPHER_CONTEXT_BASE, 0U, swapped, count);
}

/**
 * @brief  Read the cipher context and undo the byte swap.
 * @param  words: destination buffer, in the C representation.
 * @param  count: number of words.
 * @retval HAL status of HAL_SPACC_ReadContext().
 */
static HAL_StatusTypeDef Spacc_ReadCipherContext(uint32 *words, uint32 count)
{
    uint32 raw[16];
    uint32 i;
    HAL_StatusTypeDef status;

    status = HAL_SPACC_ReadContext(&hspacc_dev, SPACC_CIPHER_CONTEXT_BASE, 0U, raw, count);

    for (i = 0U; (i < count) && (i < 16U); i++)
    {
        words[i] = TEST_SWAP32(raw[i]);
    }

    return status;
}

/**
 * @brief  Wait for a result and match its software identifier.
 * @param  software_id: identifier of the submitted task.
 * @retval 1 when a result was popped and its identifier matched, 0 otherwise.
 * @note   The wait is bounded, so a silent hardware problem is reported as a
 *         failed check instead of hanging the case.
 */
static uint32 Spacc_WaitResult(uint32 software_id)
{
    uint32 guard = TEST_WAIT_GUARD;

    while ((HAL_SPACC_StateFIFOFlag(&hspacc_dev) == SET) && (guard != 0U))
    {
        guard--;
    }

    CLEAR_CACHE();

    if (guard == 0U)
    {
        return 0U;
    }

    return (HAL_SPACC_CommandExecResult(&hspacc_dev, software_id) == SET) ? 1U : 0U;
}

/**
 * @brief  Pop every pending result so that the next submission starts clean.
 * @param  limit: maximum number of results to pop.
 * @retval None
 */
static void Spacc_Drain(uint32 limit)
{
    uint32 count = 0U;

    CLEAR_CACHE();

    while ((HAL_SPACC_StateFIFOFlag(&hspacc_dev) == RESET) && (count < limit))
    {
        (void)HAL_SPACC_CommandExecResult(&hspacc_dev, 0U);
        count++;
    }
}

/**
 * @brief  SPACC low level initialization: clock gate and reset release.
 * @param  hspacc: SPACC handle.
 * @retval None
 * @note   The SPACC is clocked by the AXILite4-Bus1 (DSE) domain, gated by the
 *         SMU. The call count lets the cases verify that the callback runs
 *         once, before the handle is locked.
 */
void HAL_SPACC_MspInit(HAL_SPACC_HandleTypeDef *hspacc)
{
    if (hspacc == NULL_PTR)
    {
        return;
    }

    msp_init_count++;

    __HAL_SMU_DSE_CLK_ENABLE();
    __HAL_SMU_DSE_FORCE_RESET();
    __HAL_SMU_DSE_RELEASE_RESET();
}

/**
 * @brief  SPACC low level de-initialization, counted for the life cycle checks.
 * @param  hspacc: SPACC handle.
 * @retval None
 */
void HAL_SPACC_MspDeInit(HAL_SPACC_HandleTypeDef *hspacc)
{
    if (hspacc == NULL_PTR)
    {
        return;
    }

    msp_deinit_count++;
}

/**
 * @brief  SPACC error callback, counted for the interrupt checks.
 * @param  hspacc: SPACC handle.
 * @retval None
 */
void HAL_SPACC_ErrorCallback(HAL_SPACC_HandleTypeDef *hspacc)
{
    (void)hspacc;

    error_callback_count++;
}

/**
 * @brief  Configure the system clock and the bus gates.
 * @retval None
 * @note   Same clock tree as the other HAL integration suites: the PLL is fed
 *         by the external oscillator (VCO 180 MHz) and the buses run at
 *         AXI4Bus3 / 2, APBBus0 / 2, APBBus1 / 2 and CANX2 / 8, which keeps
 *         the console USART on its usual 22.5 MHz.
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    smu_osc;
    SMU_ClockInitTypeDef  smu_clock;
    SMU_ClocksTypeDef     smu_clocks;
    HAL_PMU_HandleTypeDef hpmu;

    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Raise the core rail trim before the PLL is switched: the 1.2 V LDO APIs
     * are gated on the handle state, so the PMU must be initialized first */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    __HAL_CLEAR_STRUCT(&smu_osc);
    smu_osc.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    smu_osc.FIRCState            = SMU_FIRC_ON;
    smu_osc.FIRCCalibrationValue = 0x00U;
    smu_osc.PLL.PLLState         = SMU_PLL_ON;
    smu_osc.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    smu_osc.PLL.PLLDivR          = 0x04U;
    smu_osc.PLL.PLLDivQ          = 0x01U;
    smu_osc.PLL.PLLDivN          = 0x14U;
    smu_osc.PLL.PLLDivF          = 0xB4U;
    smu_osc.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    (void)HAL_SMU_OscConfig(&hsmu_clk, &smu_osc, SMU_TIMEOUT_DEFAULT);

    /* Bus dividers */
    __HAL_CLEAR_STRUCT(&smu_clock);
    smu_clock.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    smu_clock.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    smu_clock.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    smu_clock.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &smu_clock);

    (void)HAL_SMU_GetClocksFreq(&smu_clocks);

    /* The packet descriptor and the context memory are programmable before the
     * first initialization, so the AXILite4-Bus1 (DSE) clock gate and its reset
     * release must already be in place: the gate is not guaranteed to be open
     * after a power-on or a hardware reset, and an access of the unclocked block
     * stalls the bus. HAL_SPACC_MspInit() repeats both operations before the
     * first submission. */
    __HAL_SMU_DSE_CLK_ENABLE();
    __HAL_SMU_DSE_FORCE_RESET();
    __HAL_SMU_DSE_RELEASE_RESET();
}

/*****END OF FILE*****/
