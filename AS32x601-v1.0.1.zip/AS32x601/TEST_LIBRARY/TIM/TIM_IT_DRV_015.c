/**
 * @file    TIM_IT_DRV_015.c
 * @brief   break function: the main output is released and then disabled
 *
 * HAL library port of the original AS32x601 standard-library test case
 * TIMER_IT_DRV_015.c, which drives TIM0. Only HAL library APIs are used; the register
 * read backs document what was programmed.
 *
 * Tested functionality:
 *   TIM_OCStructInit()      -> HAL_TIM_OC_StructInit()
 *   TIM_OC1Init()..TIM_OC6Init() -> HAL_TIM_PWM_ConfigChannel()
 *   TIM_Cmd(ENABLE)         -> HAL_TIM_PWM_Start() / HAL_TIM_PWMN_Start()
 *   TIM_CtrlPWMOutputs()    -> HAL_TIM_CtrlPWMOutputs()
 *   TIM_BDTRStructInit()/TIM_BDTRConfig() -> HAL_TIM_ConfigBreakDeadTime()
 *
 * Test procedure:
 *   map and configure the output pins (and the complementary pins) of TIM0;
 *   configure every channel with its PWM mode, pulse value and complementary output;
 *   program the break / dead-time register;
 *   start the channels and the main output, then observe the waveforms.
 *
 * Expected behaviour:
 *   every interface returns HAL_OK and the OCxM field reads the programmed mode;
 *   the pulse values are found in the CCR registers;
 *   CCER reads the enable bits (main and complementary) of the configured channels;
 *   BDTR reads the programmed dead time, off-state and automatic output settings;
 *   the disable clears BDTR.MOE immediately and it stays cleared for a whole
 *   PWM period (the automatic output is disabled);
 *   every check prints [PASS] and "summary : failures = 0".
 *
 * Note:
 *   The case enables the main output, waits 1 s and disables it again; BDTR.MOE
 *   documents both states.
 *
 *   All twelve outputs are configured with OCIdleState = SET and
 *   OCNIdleState = SET, so while the main output is disabled every pin (the six
 *   main and the six complementary ones) holds the level defined by those bits;
 *   the case verifies the CR2 read back of all twelve idle-state bits.
 *
 *   HAL_TIM_CtrlPWMOutputs(TIM_DISABLE) clears BDTR.MOE unconditionally, so
 *   the main outputs stop even while the twelve channel outputs are still
 *   enabled.
 *
 *   BDTR is programmed with the break input enabled, the off-state selection
 *   (OSSR / OSSI) enabled and a dead time of 0xF4, but with the automatic output
 *   (BDTR.AOE) disabled. AOE would make the hardware arm MOE again at the next
 *   update event, so a single disable would only hold until the end of the PWM
 *   period; keeping it disabled makes the stop permanent.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
/* Console: USART0 on GPIOD pin 8 (TX) / pin 9 (RX), 115200 8N1 */
#define TEST_BAUDRATE                   (115200U)

#define TEST_ARR                        (100000U - 1U)
#define TEST_PSC                        (9U - 1U)


/* Private variables -------------------------------------------------------*/
static HAL_TIM_HandleTypeDef htim_dev;          /*!< timer under test        */
static HAL_SMU_HandleTypeDef hsmu_clk;          /*!< SMU handle (clock tree) */
static volatile uint32 check_failures = 0U;     /*!< failed check counter    */



/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure one GPIO pin and, for the alternate function modes, the
 *         pin mux of that pin.
 * @param  port: GPIO port
 * @param  pin: pin mask
 * @param  source: pin source number (for the mux configuration)
 * @param  af: alternate function selector
 * @param  mode: GPIO_MODE_AF_PP / GPIO_MODE_INPUT
 * @retval None
 */
static void Gpio_Config(GPIO_TypeDef *port, uint32 pin, uint32 source, uint8 af, uint32 mode)
{
    GPIO_InitTypeDef gpio_init;

    __HAL_CLEAR_STRUCT(&gpio_init);
    gpio_init.Size         = sizeof(GPIO_InitTypeDef);
    gpio_init.Version      = GPIO_INIT_VERSION;
    gpio_init.Pin          = pin;
    gpio_init.Mode         = mode;
    gpio_init.Pull         = GPIO_NOPULL;
    gpio_init.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;
    gpio_init.Alternate    = af;
    if (mode == GPIO_MODE_AF_PP)
    {
        HAL_GPIO_PinAFConfig(port, source, af);
    }
    HAL_GPIO_Init(port, &gpio_init);
}

/**
 * @brief  Configure the time base of the timer under test.
 * @note   The helper keeps the Size / Version meta fields through
 *         HAL_TIM_Base_StructInit(), which the initialization interface
 *         validates at run time.
 * @param  instance: TIM0..TIM7
 * @param  arr: auto reload value
 * @param  psc: prescaler value
 * @param  rcr: repetition counter (advanced timers only)
 * @param  ckd: clock division
 * @param  countermode: counting mode
 * @retval HAL status of HAL_TIM_Base_Init()
 */
static HAL_StatusTypeDef TimeBase_Config(TIM_TypeDef *instance, uint32 arr, uint32 psc,
                                         uint32 rcr, uint32 ckd, uint32 countermode)
{
    TIM_Base_InitTypeDef base_init;

    __HAL_CLEAR_STRUCT(&htim_dev);
    htim_dev.Instance = instance;

    HAL_TIM_Base_StructInit(&base_init);
    base_init.CounterMode       = countermode;
    base_init.ClockDivision     = ckd;
    base_init.Period            = arr;
    base_init.Prescaler         = psc;
    base_init.RepetitionCounter = rcr;
    htim_dev.Init               = base_init;

    return HAL_TIM_Base_Init(&htim_dev);
}

/**
 * @brief  Enable the clock of a timer instance and release its reset.
 * @note   The default MSP callbacks of this module are empty, so the suite
 *         performs the gate and reset handling itself; every MSP callback is
 *         routed to this helper.
 * @param  instance: TIM0..TIM7
 * @retval None
 */
static void Tim_ClockEnable(TIM_TypeDef *instance)
{
    if (instance == TIM0)
    {
        __HAL_SMU_HTIM0_CLK_ENABLE();
        __HAL_SMU_HTIM0_FORCE_RESET();
        __HAL_SMU_HTIM0_RELEASE_RESET();
    }
    else if (instance == TIM1)
    {
        __HAL_SMU_HTIM1_CLK_ENABLE();
        __HAL_SMU_HTIM1_FORCE_RESET();
        __HAL_SMU_HTIM1_RELEASE_RESET();
    }
    else if (instance == TIM2)
    {
        __HAL_SMU_HTIM2_CLK_ENABLE();
        __HAL_SMU_HTIM2_FORCE_RESET();
        __HAL_SMU_HTIM2_RELEASE_RESET();
    }
    else if (instance == TIM3)
    {
        __HAL_SMU_TIM3_CLK_ENABLE();
        __HAL_SMU_TIM3_FORCE_RESET();
        __HAL_SMU_TIM3_RELEASE_RESET();
    }
    else if (instance == TIM4)
    {
        __HAL_SMU_TIM4_CLK_ENABLE();
        __HAL_SMU_TIM4_FORCE_RESET();
        __HAL_SMU_TIM4_RELEASE_RESET();
    }
    else if (instance == TIM5)
    {
        __HAL_SMU_HTIM5_CLK_ENABLE();
        __HAL_SMU_HTIM5_FORCE_RESET();
        __HAL_SMU_HTIM5_RELEASE_RESET();
    }
    else if (instance == TIM6)
    {
        __HAL_SMU_TIM6_CLK_ENABLE();
        __HAL_SMU_TIM6_FORCE_RESET();
        __HAL_SMU_TIM6_RELEASE_RESET();
    }
    else
    {
        __HAL_SMU_TIM7_CLK_ENABLE();
        __HAL_SMU_TIM7_FORCE_RESET();
        __HAL_SMU_TIM7_RELEASE_RESET();
    }
}

/* MSP callbacks: the timer clock and reset of the instance under test */
void HAL_TIM_Base_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_OC_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_PWM_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_IC_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_OnePulse_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_Encoder_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the CLINT / CMU / MPU / USART integration tests:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2, CANX2 by
 *         8 -> core 180 MHz, AXILite4 Bus 1 and Bus 2 = 45 MHz (TIM0, TIM1),
 *         APBBus0 and APBBus1 = 22.5 MHz (TIM2 / TIM3 / TIM4 and TIM5 / TIM6 /
 *         TIM7 - TIM2 and TIM5 are advanced timers on the APB).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef    SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks used by this suite (GPIOH lives in the always on
       domain and has no gate macro) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Clock tree order: write the dividers while the system clock is still
       FIRC, then configure the PLL and switch to it (that call programs the
       flash controller clock before the switch and updates SystemCoreClock
       afterwards). */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}
/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    TIM_OC_InitTypeDef oc_cfg;
    TIM_BreakDeadTimeConfigTypeDef bdtr_cfg;

    HAL_Init();
    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== TIM_IT_DRV_015 : break function: the main output is released and then disabled ===\r\n");

    /* Step 1: the output pins */
    Gpio_Config(GPIOC, GPIO_PIN_3, GPIO_PinSource3, GPIO_AF_HTIM0_M1, GPIO_MODE_AF_PP);
    Gpio_Config(GPIOA, GPIO_PIN_0, GPIO_PinSource0, GPIO_AF_HTIM0_M1, GPIO_MODE_AF_PP);
    Gpio_Config(GPIOA, GPIO_PIN_1, GPIO_PinSource1, GPIO_AF_HTIM0_M1, GPIO_MODE_AF_PP);
    Gpio_Config(GPIOA, GPIO_PIN_2, GPIO_PinSource2, GPIO_AF_HTIM0_M1, GPIO_MODE_AF_PP);
    Gpio_Config(GPIOA, GPIO_PIN_3, GPIO_PinSource3, GPIO_AF_HTIM0_M1, GPIO_MODE_AF_PP);
    Gpio_Config(GPIOA, GPIO_PIN_4, GPIO_PinSource4, GPIO_AF_HTIM0_M1, GPIO_MODE_AF_PP);
    Gpio_Config(GPIOA, GPIO_PIN_5, GPIO_PinSource5, GPIO_AF_HTIM0_M1, GPIO_MODE_AF_PP);
    Gpio_Config(GPIOA, GPIO_PIN_6, GPIO_PinSource6, GPIO_AF_HTIM0_M1, GPIO_MODE_AF_PP);
    Gpio_Config(GPIOA, GPIO_PIN_7, GPIO_PinSource7, GPIO_AF_HTIM0_M1, GPIO_MODE_AF_PP);
    Gpio_Config(GPIOC, GPIO_PIN_4, GPIO_PinSource4, GPIO_AF_HTIM0_M1, GPIO_MODE_AF_PP);
    Gpio_Config(GPIOC, GPIO_PIN_5, GPIO_PinSource5, GPIO_AF_HTIM0_M1, GPIO_MODE_AF_PP);
    Gpio_Config(GPIOB, GPIO_PIN_0, GPIO_PinSource0, GPIO_AF_HTIM0_M1, GPIO_MODE_AF_PP);
    /* Step 2: the time base */
    Check("HAL_TIM_Base_Init() returns HAL_OK",
          (TimeBase_Config(TIM0, TEST_ARR, TEST_PSC, 0U, TIM_CKD_DIV1, TIM_COUNTERMODE_UP) == HAL_OK));

    /* Step 3: the mode and pulse of every channel */
    __HAL_CLEAR_STRUCT(&oc_cfg);
    HAL_TIM_OC_StructInit(&oc_cfg);
    oc_cfg.OCPolarity   = TIM_OCPOLARITY_HIGH;
    oc_cfg.OCNPolarity  = TIM_OCNPOLARITY_HIGH;
    oc_cfg.OCFastMode   = TIM_OCFAST_DISABLE;
    oc_cfg.OCPreload    = TIM_OCPRECONFIG_ENABLE;
    oc_cfg.OCIdleState  = TIM_OCIDLESTATE_SET;
    oc_cfg.OCNIdleState = TIM_OCNIDLESTATE_SET;
    oc_cfg.Pulse = (100000U / 2U);
    oc_cfg.OCMode = TIM_OCMODE_PWM1;
    (void)HAL_TIM_PWM_ConfigChannel(&htim_dev, &oc_cfg, TIM_CHANNEL_1);
    oc_cfg.Pulse = (100000U / 2U);
    oc_cfg.OCMode = TIM_OCMODE_PWM1;
    (void)HAL_TIM_PWM_ConfigChannel(&htim_dev, &oc_cfg, TIM_CHANNEL_2);
    oc_cfg.Pulse = (100000U / 2U);
    oc_cfg.OCMode = TIM_OCMODE_PWM1;
    (void)HAL_TIM_PWM_ConfigChannel(&htim_dev, &oc_cfg, TIM_CHANNEL_3);
    oc_cfg.Pulse = (100000U / 2U);
    oc_cfg.OCMode = TIM_OCMODE_PWM1;
    (void)HAL_TIM_PWM_ConfigChannel(&htim_dev, &oc_cfg, TIM_CHANNEL_4);
    oc_cfg.Pulse = (100000U / 2U);
    oc_cfg.OCMode = TIM_OCMODE_PWM1;
    (void)HAL_TIM_PWM_ConfigChannel(&htim_dev, &oc_cfg, TIM_CHANNEL_5);
    oc_cfg.Pulse = (100000U / 2U);
    oc_cfg.OCMode = TIM_OCMODE_PWM1;
    (void)HAL_TIM_PWM_ConfigChannel(&htim_dev, &oc_cfg, TIM_CHANNEL_6);

    /* Step 4: the programmed modes and pulses */
    Check("OC1 mode = PWM1", ((TIM0->CCMR1 & TIM_CCMR1_OC1M) == TIM_OCMODE_PWM1));
    Check("OC2 mode = PWM1", ((TIM0->CCMR1 & TIM_CCMR1_OC2M) == (TIM_OCMODE_PWM1 << 8U)));
    Check("OC3 mode = PWM1", ((TIM0->CCMR2 & TIM_CCMR2_OC3M) == TIM_OCMODE_PWM1));
    Check("OC4 mode = PWM1", ((TIM0->CCMR2 & TIM_CCMR2_OC4M) == (TIM_OCMODE_PWM1 << 8U)));
    Check("OC5 mode = PWM1", ((TIM0->CCMR3 & TIM_CCMR3_OC5M) == TIM_OCMODE_PWM1));
    Check("OC6 mode = PWM1", ((TIM0->CCMR3 & TIM_CCMR3_OC6M) == (TIM_OCMODE_PWM1 << 8U)));
    Check("CCR1 holds the pulse", (TIM0->CCR1 == (100000U / 2U)));
    Check("CCR2 holds the pulse", (TIM0->CCR2 == (100000U / 2U)));
    Check("CCR3 holds the pulse", (TIM0->CCR3 == (100000U / 2U)));
    Check("CCR4 holds the pulse", (TIM0->CCR4 == (100000U / 2U)));
    Check("CCR5 holds the pulse", (TIM0->CCR5 == (100000U / 2U)));
    Check("CCR6 holds the pulse", (TIM0->CCR6 == (100000U / 2U)));
    __HAL_CLEAR_STRUCT(&bdtr_cfg);
    HAL_TIM_BreakDeadTimeConfig_StructInit(&bdtr_cfg);
    bdtr_cfg.OffStateRunMode  = TIM_OSSR_ENABLE;
    bdtr_cfg.OffStateIDLEMode = TIM_OSSI_ENABLE;
    bdtr_cfg.DeadTime         = 0xF4U;
    bdtr_cfg.BreakState       = TIM_BREAK_ENABLE;
    bdtr_cfg.BreakPolarity    = TIM_BREAKPOLARITY_HIGH;
    bdtr_cfg.BreakFilter      = 0U;
    /* The automatic output is deliberately left disabled: with BDTR.AOE set
       the hardware would re-arm MOE at the next update event, so a single
       disable would only hold until the end of the PWM period */
    bdtr_cfg.AutomaticOutput  = TIM_AUTOMATICOUTPUT_DISABLE;
    Check("HAL_TIM_ConfigBreakDeadTime() returns HAL_OK",
          (HAL_TIM_ConfigBreakDeadTime(&htim_dev, &bdtr_cfg) == HAL_OK));
    Check("BDTR.DTG holds 0xF4", ((TIM0->BDTR & TIM_BDTR_DTG) == 0xF4U));
    Check("BDTR.OSSR is set", ((TIM0->BDTR & TIM_BDTR_OSSR) != 0U));
    Check("BDTR.OSSI is set", ((TIM0->BDTR & TIM_BDTR_OSSI) != 0U));
    Check("BDTR.AOE is not set", ((TIM0->BDTR & TIM_BDTR_AOE) == 0U));
    Check("BDTR.BKE is set", ((TIM0->BDTR & TIM_BDTR_BKE) != 0U));

    /* The twelve output idle states set the level the pins hold while the
       main output is disabled (BDTR.MOE = 0 with OSSR / OSSI set), so the
       case verifies that every channel programmed its own pair of bits. */
    Check("CR2 holds every output idle state",
          ((TIM0->CR2 & (uint32)(TIM_CR2_OIS1 | TIM_CR2_OIS1N | TIM_CR2_OIS2 | TIM_CR2_OIS2N)) ==
           (uint32)(TIM_CR2_OIS1 | TIM_CR2_OIS1N | TIM_CR2_OIS2 | TIM_CR2_OIS2N)));
    Check("CR2 holds the idle state of channels 3 to 6",
          ((TIM0->CR2 & (uint32)(TIM_CR2_OIS3 | TIM_CR2_OIS3N | TIM_CR2_OIS4 | TIM_CR2_OIS4N |
                                TIM_CR2_OIS5 | TIM_CR2_OIS5N | TIM_CR2_OIS6 | TIM_CR2_OIS6N)) ==
           (uint32)(TIM_CR2_OIS3 | TIM_CR2_OIS3N | TIM_CR2_OIS4 | TIM_CR2_OIS4N |
                    TIM_CR2_OIS5 | TIM_CR2_OIS5N | TIM_CR2_OIS6 | TIM_CR2_OIS6N)));

    /* the break input keeps the outputs disabled until the main output is enabled */

    /* Step 5: start the channels */
    Check("HAL_TIM_PWM_Start(CH1) returns HAL_OK", (HAL_TIM_PWM_Start(&htim_dev, TIM_CHANNEL_1) == HAL_OK));
    Check("HAL_TIM_PWM_Start(CH2) returns HAL_OK", (HAL_TIM_PWM_Start(&htim_dev, TIM_CHANNEL_2) == HAL_OK));
    Check("HAL_TIM_PWM_Start(CH3) returns HAL_OK", (HAL_TIM_PWM_Start(&htim_dev, TIM_CHANNEL_3) == HAL_OK));
    Check("HAL_TIM_PWM_Start(CH4) returns HAL_OK", (HAL_TIM_PWM_Start(&htim_dev, TIM_CHANNEL_4) == HAL_OK));
    Check("HAL_TIM_PWM_Start(CH5) returns HAL_OK", (HAL_TIM_PWM_Start(&htim_dev, TIM_CHANNEL_5) == HAL_OK));
    Check("HAL_TIM_PWM_Start(CH6) returns HAL_OK", (HAL_TIM_PWM_Start(&htim_dev, TIM_CHANNEL_6) == HAL_OK));
    Check("HAL_TIM_PWMN_Start(CH1) returns HAL_OK", (HAL_TIM_PWMN_Start(&htim_dev, TIM_CHANNEL_1) == HAL_OK));
    Check("HAL_TIM_PWMN_Start(CH2) returns HAL_OK", (HAL_TIM_PWMN_Start(&htim_dev, TIM_CHANNEL_2) == HAL_OK));
    Check("HAL_TIM_PWMN_Start(CH3) returns HAL_OK", (HAL_TIM_PWMN_Start(&htim_dev, TIM_CHANNEL_3) == HAL_OK));
    Check("HAL_TIM_PWMN_Start(CH4) returns HAL_OK", (HAL_TIM_PWMN_Start(&htim_dev, TIM_CHANNEL_4) == HAL_OK));
    Check("HAL_TIM_PWMN_Start(CH5) returns HAL_OK", (HAL_TIM_PWMN_Start(&htim_dev, TIM_CHANNEL_5) == HAL_OK));
    Check("HAL_TIM_PWMN_Start(CH6) returns HAL_OK", (HAL_TIM_PWMN_Start(&htim_dev, TIM_CHANNEL_6) == HAL_OK));
    Check("BDTR.MOE is set", ((TIM0->BDTR & TIM_BDTR_MOE) != 0U));
    Check("CCER reads CC1E set", ((TIM0->CCER & TIM_CCER_CC1E) != 0U));
    Check("CCER reads CC1NE set", ((TIM0->CCER & TIM_CCER_CC1NE) != 0U));
    Check("CCER reads CC3NE set", ((TIM0->CCER & TIM_CCER_CC3NE) != 0U));
    delay_ms(1000U);
    HAL_TIM_CtrlPWMOutputs(&htim_dev, TIM_DISABLE);
    Check("BDTR.MOE is cleared after the disable", ((TIM0->BDTR & TIM_BDTR_MOE) == 0U));

    /* The automatic output is disabled, so the cleared MOE is not re-armed by
       the hardware: the stop stays. The check waits for more than one PWM
       period (ARR = 100000-1 at 5 MHz = 20 ms) before reading the bit again. */
    delay_ms(30U);
    Check("BDTR.MOE stays cleared for a full PWM period",
          ((TIM0->BDTR & TIM_BDTR_MOE) == 0U));
    printf("after the permanent stop : BDTR = 0x%08X, CCER = 0x%08X, CNT = %d\r\n",
           (unsigned int)TIM0->BDTR, (unsigned int)TIM0->CCER, (int)TIM0->CNT);

    Summary();

    for (;;)
    {
        /* the main output is released at start and disabled after 1 s */

    }
}
