/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:        as32x601_hal_spacc.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.5
 * Date:            2026/10/09
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/09/02     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/17     1.1     remove the local IS_FunctionalState_STATE macro (the functional-state check
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.2     align the module with the library
 *                                                       architecture spec (resource lock and
 *                                                       RTOS chapters): give the shared lock
 *                                                       helper a Timeout parameter and a NULL
 *                                                       mutex guard, add the shared handle
 *                                                       validity and state helpers, run the
 *                                                       MSP callbacks outside the locked
 *                                                       region, report the guard path of
 *                                                       every locked entry point, apply the
 *                                                       state gate to the interrupt
 *                                                       configuration interface while the
 *                                                       packet and context programming
 *                                                       interfaces stay callable before the
 *                                                       initialization (the command sequence
 *                                                       programs the descriptors first),
 *                                                       declare the invalid parameter and
 *                                                       timeout error codes, validate the
 *                                                       arguments at run time and document
 *                                                       the blocking behaviour of every
 *                                                       public prototype
 *                                                       is now provided by IS_FUNCTIONAL_STATE in as32x601_hal_def.h)
 *     ANSILIC APPLICATION GROUP  2026/09/21     1.3     describe the handle structure without referring to an external
 *                                                       implementation, and restore the " *" prefix of the history
 *                                                       continuation lines
 *     ANSILIC APPLICATION GROUP  2026/10/08     1.4     spell the SPACC_Status_Reservend0/1 bit-field
 *                                                       members as Reserved0/1
 *     ANSILIC APPLICATION GROUP  2026/10/09     1.5     align the module header block with the rest
 *                                                       of the library (value column and the
 *                                                       "Version:" label)
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Security Processor
 *                  (SPACC) peripheral:
 *                  - Initialization (HAL_SPACC_Init): configures the
 *                    SW_CTRL (software ID / priority command FIFO),
 *                    KEY_SZ (key size / key index / key type) and CTRL
 *                    (cipher algorithm / SM4 cipher mode / hash algorithm
 *                    / SM3 hash mode / transfer mode / context index /
 *                    key source / AAD copy / ICV compute / ICV encrypt /
 *                    ICV location / key expand / message begin / message
 *                    end) registers from a SPACC_InitTypeDef structure;
 *                  - Packet descriptor configuration
 *                    (HAL_SPACC_PacketInit): configures the SRC_PTR /
 *                    DST_PTR / OFFSET / PRE_AAD_LEN / POST_AAD_LEN /
 *                    PROC_LEN / ICV_LEN / ICV_OFFSET / IV_OFFSET registers
 *                    that describe the packet to process in system memory;
 *                  - Interrupt / flag management: HAL_SPACC_ITConfig()
 *                    (IRQ_EN), HAL_SPACC_GetITStatus() (IRQ_STAT),
 *                    HAL_SPACC_CommandExecResult() (ejects the status FIFO
 *                    and matches the software ID) and
 *                    HAL_SPACC_StateFIFOFlag() (FIFO_STAT.STAT_EMPTY).
 *                  - Context memory access: HAL_SPACC_WriteContext() /
 *                    HAL_SPACC_ReadContext() access the cipher / hash
 *                    context memory areas (SPACC_BASE + 0x4000 / + 0x8000)
 *                    where the key / IV / auxiliary material is loaded.
 *                  This driver depends on as32x601_hal_def.h (HAL common
 *                  types and utilities). The SPACC peripheral is clocked by
 *                  the AXILite4-Bus1 (DSE) domain, gated by the SMU (see
 *                  the DSE_CLK_ENABLE() / DSE_RESET() macros of
 *                  as32x601_smu.h): HAL_SPACC_MspInit() is provided as an
 *                  empty weak function where the user enables the clock.
 *                  The SPACC has a dedicated PLIC interrupt line
 *                  (SPACC_IRQn = 0x0E): the user also enables it in
 *                  HAL_SPACC_MspInit() and implements SPACC_IRQ_Handler()
 *                  calling HAL_SPACC_IRQHandler().
 *                  The chip SPACC is a command-queue style security coprocessor
 *                  (no equivalent in the standard HAL driver set): a command is
 *                  submitted by writing the SW_CTRL / KEY_SZ / CTRL
 *                  configuration registers and the SRC_PTR / DST_PTR /
 *                  OFFSET / length registers describing the packet in system
 *                  memory; the completion is observed by polling the status
 *                  FIFO (FIFO_STAT.STAT_EMPTY reset / IRQ_STAT.STAT) and
 *                  reading the STATUS register (ejected with STAT_POP).
 * @complexity  Simple
 *              Polling only (command-queue), lock + state machine,
 *              interrupt flag / handler support.
 */
#ifndef __AS32X601_HAL_SPACC_H
#define __AS32X601_HAL_SPACC_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "as32x601.h"               /* SPACC_TypeDef, SPACC, register bits     */
#include "as32x601_hal_def.h"       /* HAL_StatusTypeDef, HAL_LockTypeDef      */

/* Exported constants --------------------------------------------------------*/

/**
 * @brief SPACC HAL driver module version.
 * @note  0x0100U = V1.0. Bumped only on breaking API changes (architecture
 *        spec COMPAT-13/14/15).
 */
#define __HAL_SPACC_MODULE_VERSION  0x0100U

/* Exported types ------------------------------------------------------------*/

/** @defgroup SPACC_Exported_Types SPACC Exported Types
  * @{
  */

/**
 * @brief  SPACC State structure definition
 * @note   The SPACC runs as a command-queue coprocessor: the state is
 *         READY after the configuration registers are set. While a command
 *         is being processed the FIFO_STAT.STAT_EMPTY flag is reset; on
 *         completion the STATUS register holds the result of the operation.
 */
typedef enum
{
    HAL_SPACC_STATE_RESET   = 0x00U,                   /*!< SPACC not yet initialized */
    HAL_SPACC_STATE_READY   = 0x01U,                   /*!< SPACC initialized and ready */
    HAL_SPACC_STATE_BUSY    = 0x02U,                   /*!< SPACC command ongoing */
    HAL_SPACC_STATE_ERROR   = 0x03U                    /*!< SPACC error state */
} HAL_SPACC_StateTypeDef;

/**
 * @brief  SPACC Init Structure definition
 * @note   The fields keep the device-layer names (as32x601_spacc.h) so that
 *         existing driver code can be migrated without change. The
 *         structure is applied to the SW_CTRL / KEY_SZ / CTRL registers
 *         by HAL_SPACC_Init().
 * @note   This structure follows the Version+Size compatibility mechanism
 *         (architecture spec section 22): the user must clear the structure
 *         (__HAL_CLEAR_STRUCT / memset), set the Size and Version metafields
 *         before filling the business fields (see HAL_SPACC_StructInit()).
 */
typedef struct
{
    uint32 Size;                    /*!< sizeof(SPACC_InitTypeDef), must be set by the user
                                         after clearing the structure                 */
    uint32 Version;                 /*!< Structure semantic version: @ref SPACC_INIT_VERSION
                                         (SPACC_INIT_V1 = 0x0100U)                   */
    uint32 SPACC_CipherAlgorithm;   /*!< Cipher algorithm (SPACC_CIPHER_ALG_*) */
    uint32 SPACC_SM4CipherMode;     /*!< SM4 cipher mode (SPACC_SM4_CIPHER_MODE_*) */
    uint32 SPACC_HashAlgorithm;     /*!< Hash algorithm (SPACC_HASH_ALG_*) */
    uint32 SPACC_SM3HashMode;       /*!< SM3 hash mode (SPACC_SM3_HASH_MODE_*) */
    uint32 SPACC_TransferMode;      /*!< Transfer mode (SPACC_TRANS_TO_APPLY_*) */
    uint32 SPACC_ContextIndex;      /*!< Context index */
    uint32 SPACC_KeyFrom;           /*!< Key source (SPACC_KEY_FROM_*) */
    uint32 SPACC_AADCopy;           /*!< Copy PRE_AAD to the target buffer (SPACC_APP_*) */
    uint32 SPACC_ICVCompute;        /*!< ICV compute method (SPACC_ICV_COMPUTER_*) */
    uint32 SPACC_ICVEncrypt;        /*!< Whether the ICV is encrypted (SPACC_ICV_*) */
    uint32 SPACC_ICVLocation;       /*!< ICV location (SPACC_ICV_LOCATION_*) */
    uint32 SPACC_KeyExpand;         /*!< Key expand (SPACC_KEY_*) */
    uint32 SPACC_MessageBegin;      /*!< Begin flag (SPACC_MSG_BEGIN_*) */
    uint32 SPACC_MessageEnd;        /*!< End flag (SPACC_MSG_END_*) */
    uint32 SPACC_SoftwareID;        /*!< Software ID of the command */
    uint32 SPACC_PriorityCommandFIFO; /*!< Priority command FIFO selection */
    uint32 SPACC_KeySize;           /*!< Key size */
    uint32 SPACC_KeyIndex;          /*!< Key index */
    uint32 SPACC_KeyType;           /*!< Key type (SPACC_KEY_TYPE_*) */
    uint32 Reserved[2];             /*!< Reserved for future extension (must be 0) */
} SPACC_InitTypeDef;

/**
 * @brief  SPACC / init structure version macros.
 * @note   SPACC_INIT_V1 is the current version. Future versions (e.g. V2
 *         with new fields) must be appended after the existing fields
 *         without changing the layout (architecture spec section 22.5).
 */
#define SPACC_INIT_V1  0x0100U   /*!< SPACC Init structure version V1.0 */
#define SPACC_INIT_VERSION  SPACC_INIT_V1   /*!< Current SPACC Init structure version */

/**
 * @brief  SPACC packet structure definition
 * @note   The fields keep the device-layer names. The structure describes the
 *         packet data structure in system memory that the SPACC processes:
 *         source / destination pointers, PRE-AAD / POST-AAD / processing /
 *         ICV lengths and offsets. It is applied to the SRC_PTR / DST_PTR /
 *         OFFSET / PRE_AAD_LEN / POST_AAD_LEN / PROC_LEN / ICV_LEN /
 *         ICV_OFFSET / IV_OFFSET registers by HAL_SPACC_PacketInit().
 */
typedef struct
{
    uint32 SPACC_SourcePtr;         /*!< Source packet pointer in system memory */
    uint32 SPACC_DestinationPtr;    /*!< Destination packet pointer in system memory */
    uint32 SPACC_SouPREAADOffset;   /*!< Source offset to the start of PRE-AAD */
    uint32 SPACC_DestPREAADOffset;  /*!< Destination offset to the start of PRE-AAD */
    uint32 SPACC_PREAADLen;         /*!< PRE-AAD length in bytes */
    uint32 SPACC_POSTAADLen;        /*!< POST-AAD length in bytes */
    uint32 SPACC_PROCLen;           /*!< Processing length in bytes */
    uint32 SPACC_ICVLen;            /*!< ICV length in bytes */
    uint32 SPACC_ICVOffset;         /*!< ICV offset in bytes */
    uint32 SPACC_IVOffset;          /*!< IV offset in bytes */
    uint32 SPACC_IVLocation;        /*!< IV value location (SPACC_IV_LOCATION_*) */
} SPACC_PacketTypeDef;

/**
 * @brief  SPACC status register bit-field definition
 * @note   Mirrors the STATUS register read after the status FIFO is
 *         ejected by writing STAT_POP. SPACC_Status_Result is the 3-bit
 *         operation result (SPACC_STATUS_RET_CODE_*).
 */
typedef struct
{
    uint32 SPACC_Status_SoftwareID    : 8;            /*!< Software ID */
    uint32 SPACC_Status_Reserved0     : 16;           /*!< Reserved */
    uint32 SPACC_Status_Result        : 3;            /*!< Result of the operation */
    uint32 SPACC_Status_Reserved1     : 4;            /*!< Reserved */
    uint32 SPACC_Status_CommandMode   : 1;            /*!< Command mode */
} SPACC_StatusTypedef;

/**
 * @brief  SPACC Handle Structure definition
 * @note   The handle carries the module context (Instance +
 *         Init + Lock + State + ErrorCode). Init stores the configuration
 *         applied by HAL_SPACC_Init(). The SPACC is a single-instance
 *         peripheral (Instance points to SPACC).
 * @note   Field order follows the architecture spec HANDLE-02:
 *         Instance -> Init -> Lock -> State -> ErrorCode -> module fields.
 */
typedef struct __HAL_SPACC_HandleTypeDef
{
    SPACC_TypeDef            *Instance;             /*!< Register base address */
    SPACC_InitTypeDef         Init;                 /*!< SPACC communication parameters */
    HAL_LockTypeDef           Lock;                 /*!< SPACC locking object */
    __IO HAL_SPACC_StateTypeDef State;              /*!< SPACC communication state */
    __IO uint32               ErrorCode;            /*!< SPACC error code */
#if (USE_RTOS == 1)
    HAL_MutexTypeDef          LockMutex;            /*!< RTOS mutex handle (created by the
                                                       user porting layer, e.g. in
                                                       HAL_SPACC_MspInit)            */
#endif /* USE_RTOS */
} HAL_SPACC_HandleTypeDef;

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @defgroup SPACC_Exported_Constants SPACC Exported Constants
  * @{
  */

/** @defgroup SPACC_Error_Code SPACC Error Code
  * @{
  */
#define HAL_SPACC_ERROR_NONE        ((uint32)0x00000000U) /*!< No error          */
#define HAL_SPACC_ERROR_INVALID_PARAM ((uint32)0x00000004U) /*!< Invalid parameter or rejected operation */
#define HAL_SPACC_ERROR_TIMEOUT     ((uint32)0x00000008U) /*!< Timeout error (reserved: this module has no blocking wait) */
/**
  * @}
  */

/** @defgroup SPACC_Context_Bases SPACC Context Memory Bases
  * @brief  SPACC context memory area base offsets relative to SPACC_BASE.
  *         The cipher context (key / IV / F8-XTS material) starts at
  *         SPACC_BASE + 0x4000 and the hash context at SPACC_BASE + 0x8000.
  *         These are accessed through HAL_SPACC_WriteContext() /
  *         HAL_SPACC_ReadContext().
  * @{
  */
#define SPACC_CIPHER_CONTEXT_BASE                   ((uint32)(SPACC_BASE + 0x4000)) /*!< Cipher context memory base */
#define SPACC_HASH_CONTEXT_BASE                     ((uint32)(SPACC_BASE + 0x8000)) /*!< Hash context memory base */
/**
  * @}
  */

/** @defgroup SPACC_Cipher_Algorithm SPACC Cipher Algorithm selection
  * @brief  Cipher algorithm selection definition (CTRL.SM4_CIPH_ALG).
  * @{
  */
#define SPACC_CIPHER_ALG_NULL                       ((uint32)0x00000000)  /*!< NULL Algorithm is selected */
#define SPACC_CIPHER_ALG_DES                        ((uint32)0x00000001)  /*!< DES Algorithm is selected */
#define SPACC_CIPHER_ALG_AES                        ((uint32)0x00000002)  /*!< AES Algorithm is selected */
#define SPACC_CIPHER_ALG_RC4                        ((uint32)0x00000003)  /*!< RC4 Algorithm is selected */
#define SPACC_CIPHER_ALG_MULTI2                     ((uint32)0x00000004)  /*!< MULTI2 Algorithm is selected */
#define SPACC_CIPHER_ALG_KASUMI                     ((uint32)0x00000005)  /*!< KASUMI Algorithm is selected */
#define SPACC_CIPHER_ALG_SNOW_3G_UEA2               ((uint32)0x00000006)  /*!< SNOW-3G UEA2 Algorithm is selected */
#define SPACC_CIPHER_ALG_ZUC_128_EE3                ((uint32)0x00000007)  /*!< ZUC-128-EE3 Algorithm is selected */
#define SPACC_CIPHER_ALG_CHACHA20                   ((uint32)0x00000008)  /*!< CHACHA20 Algorithm is selected */
#define SPACC_CIPHER_ALG_SM4                        ((uint32)0x00000009)  /*!< SM4 Algorithm is selected */
#define IS_SPACC_CIPHER_ALG(ALG)                    (((ALG) == SPACC_CIPHER_ALG_NULL) || \
                                                     ((ALG) == SPACC_CIPHER_ALG_DES) || \
                                                     ((ALG) == SPACC_CIPHER_ALG_AES) || \
                                                     ((ALG) == SPACC_CIPHER_ALG_RC4) || \
                                                     ((ALG) == SPACC_CIPHER_ALG_MULTI2) || \
                                                     ((ALG) == SPACC_CIPHER_ALG_KASUMI) || \
                                                     ((ALG) == SPACC_CIPHER_ALG_SNOW_3G_UEA2) || \
                                                     ((ALG) == SPACC_CIPHER_ALG_ZUC_128_EE3) || \
                                                     ((ALG) == SPACC_CIPHER_ALG_CHACHA20) || \
                                                     ((ALG) == SPACC_CIPHER_ALG_SM4))
/**
  * @}
  */

/** @defgroup SPACC_SM4_Cipher_Mode SPACC SM4 Cipher Mode selection
  * @brief  SM4 cipher mode selection definition (CTRL.SM4_CIPH_MODE).
  * @{
  */
#define SPACC_SM4_CIPHER_MODE_ECB                   ((uint32)0x00000000)  /*!< ECB Mode is selected */
#define SPACC_SM4_CIPHER_MODE_CBC                   ((uint32)0x00000001)  /*!< CBC Mode is selected */
#define SPACC_SM4_CIPHER_MODE_CTR_STREAM            ((uint32)0x00000002)  /*!< CTR_STREAM Mode is selected */
#define SPACC_SM4_CIPHER_MODE_CCM                   ((uint32)0x00000003)  /*!< CCM Mode is selected */
#define SPACC_SM4_CIPHER_MODE_GCM_AEAD              ((uint32)0x00000005)  /*!< GCM_AEAD Mode is selected */
#define SPACC_SM4_CIPHER_MODE_OFB                   ((uint32)0x00000007)  /*!< OFB Mode is selected */
#define SPACC_SM4_CIPHER_MODE_CFB                   ((uint32)0x00000008)  /*!< CFB Mode is selected */
#define SPACC_SM4_CIPHER_MODE_F8                    ((uint32)0x00000009)  /*!< F8 Mode is selected */
#define SPACC_SM4_CIPHER_MODE_XTS                   ((uint32)0x0000000A)  /*!< XTS Mode is selected */
#define IS_SPACC_SM4_CIPHER_MODE(MODE)              (((MODE) == SPACC_SM4_CIPHER_MODE_ECB) || \
                                                     ((MODE) == SPACC_SM4_CIPHER_MODE_CBC) || \
                                                     ((MODE) == SPACC_SM4_CIPHER_MODE_CTR_STREAM) || \
                                                     ((MODE) == SPACC_SM4_CIPHER_MODE_CCM) || \
                                                     ((MODE) == SPACC_SM4_CIPHER_MODE_GCM_AEAD) || \
                                                     ((MODE) == SPACC_SM4_CIPHER_MODE_OFB) || \
                                                     ((MODE) == SPACC_SM4_CIPHER_MODE_CFB) || \
                                                     ((MODE) == SPACC_SM4_CIPHER_MODE_F8) || \
                                                     ((MODE) == SPACC_SM4_CIPHER_MODE_XTS))
/**
  * @}
  */

/** @defgroup SPACC_Hash_Algorithm SPACC Hash Algorithm selection
  * @brief  Hash algorithm selection definition (CTRL.SM_HASH_ALG).
  * @{
  */
#define SPACC_HASH_ALG_NULL                         ((uint32)0x00000000)  /*!< NULL Algorithm is selected */
#define SPACC_HASH_ALG_MD5                          ((uint32)0x00000001)  /*!< MD5 Algorithm is selected */
#define SPACC_HASH_ALG_SHA1                         ((uint32)0x00000002)  /*!< SHA1 Algorithm is selected */
#define SPACC_HASH_ALG_SHA224                       ((uint32)0x00000003)  /*!< SHA224 Algorithm is selected */
#define SPACC_HASH_ALG_SHA256                       ((uint32)0x00000004)  /*!< SHA256 Algorithm is selected */
#define SPACC_HASH_ALG_SHA384                       ((uint32)0x00000005)  /*!< SHA384 Algorithm is selected */
#define SPACC_HASH_ALG_SHA512                       ((uint32)0x00000006)  /*!< SHA512 Algorithm is selected */
#define SPACC_HASH_ALG_AES_XCBC_MAC                 ((uint32)0x00000007)  /*!< AES_XCBC_MAC Algorithm is selected */
#define SPACC_HASH_ALG_AES_CMAC                     ((uint32)0x00000008)  /*!< AES_CMAC Algorithm is selected */
#define SPACC_HASH_ALG_KASUMI_F9                    ((uint32)0x00000009)  /*!< KASUMI_F9 Algorithm is selected */
#define SPACC_HASH_ALG_SNOW_3G_UIA2                 ((uint32)0x0000000A)  /*!< SNOW-3G_UIA2 Algorithm is selected */
#define SPACC_HASH_ALG_CRC_32_IEEE_802_3            ((uint32)0x0000000B)  /*!< CRC_32_IEEE_802_3 Algorithm is selected */
#define SPACC_HASH_ALG_ZUC_128_EIA3                 ((uint32)0x0000000C)  /*!< ZUC_128_EIA3 Algorithm is selected */
#define SPACC_HASH_ALG_SHA_512_224                  ((uint32)0x0000000D)  /*!< SHA_512_224 Algorithm is selected */
#define SPACC_HASH_ALG_SHA_512_256                  ((uint32)0x0000000E)  /*!< SHA_512_256 Algorithm is selected */
#define SPACC_HASH_ALG_MICHAEL                      ((uint32)0x0000000F)  /*!< MICHAEL Algorithm is selected */
#define SPACC_HASH_ALG_SHA3_224                     ((uint32)0x00000010)  /*!< SHA3_224 Algorithm is selected */
#define SPACC_HASH_ALG_SHA3_256                     ((uint32)0x00000011)  /*!< SHA3_256 Algorithm is selected */
#define SPACC_HASH_ALG_SHA3_384                     ((uint32)0x00000012)  /*!< SHA3_384 Algorithm is selected */
#define SPACC_HASH_ALG_SHA3_512                     ((uint32)0x00000013)  /*!< SHA3_512 Algorithm is selected */
#define SPACC_HASH_ALG_SHAKE128                     ((uint32)0x00000014)  /*!< SHAKE128 Algorithm is selected */
#define SPACC_HASH_ALG_SHAKE256                     ((uint32)0x00000015)  /*!< SHAKE256 Algorithm is selected */
#define SPACC_HASH_ALG_POIY305                      ((uint32)0x00000016)  /*!< POIY305 Algorithm is selected */
#define SPACC_HASH_ALG_SM3                          ((uint32)0x00000017)  /*!< SM3 Algorithm is selected */
#define SPACC_HASH_ALG_SM4_XCBC_MAC                 ((uint32)0x00000018)  /*!< SM4_XCBC_MAC Algorithm is selected */
#define SPACC_HASH_ALG_SM4_CMAC                     ((uint32)0x00000019)  /*!< SM4_CMAC Algorithm is selected */
#define IS_SPACC_HASH_ALG(ALG)                      (((ALG) == SPACC_HASH_ALG_NULL) || ((ALG) == SPACC_HASH_ALG_MD5) || \
                                                     ((ALG) == SPACC_HASH_ALG_SHA1) || ((ALG) == SPACC_HASH_ALG_SHA224) || \
                                                     ((ALG) == SPACC_HASH_ALG_SHA256) || ((ALG) == SPACC_HASH_ALG_SHA384) || \
                                                     ((ALG) == SPACC_HASH_ALG_SHA512) || ((ALG) == SPACC_HASH_ALG_AES_XCBC_MAC) || \
                                                     ((ALG) == SPACC_HASH_ALG_AES_CMAC) || ((ALG) == SPACC_HASH_ALG_KASUMI_F9) || \
                                                     ((ALG) == SPACC_HASH_ALG_SNOW_3G_UIA2) || ((ALG) == SPACC_HASH_ALG_CRC_32_IEEE_802_3) || \
                                                     ((ALG) == SPACC_HASH_ALG_ZUC_128_EIA3) || ((ALG) == SPACC_HASH_ALG_SHA_512_224) || \
                                                     ((ALG) == SPACC_HASH_ALG_SHA_512_256) || ((ALG) == SPACC_HASH_ALG_MICHAEL) || \
                                                     ((ALG) == SPACC_HASH_ALG_SHA3_224) || ((ALG) == SPACC_HASH_ALG_SHA3_256) || \
                                                     ((ALG) == SPACC_HASH_ALG_SHA3_384) || ((ALG) == SPACC_HASH_ALG_SHA3_512) || \
                                                     ((ALG) == SPACC_HASH_ALG_SHAKE128) || ((ALG) == SPACC_HASH_ALG_SHAKE256) || \
                                                     ((ALG) == SPACC_HASH_ALG_POIY305) || ((ALG) == SPACC_HASH_ALG_SM3) || \
                                                     ((ALG) == SPACC_HASH_ALG_SM4_XCBC_MAC) || ((ALG) == SPACC_HASH_ALG_SM4_CMAC))
/**
  * @}
  */

/** @defgroup SPACC_SM3_Hash_Mode SPACC SM3 Hash Mode selection
  * @brief  SM3 hash mode selection definition (CTRL.SM3_HASH_MODE).
  * @{
  */
#define SPACC_SM3_HASH_MODE_RAW_SHAKE               ((uint32)0x00000000)  /*!< RAW_SHAKE mode is selected */
#define SPACC_SM3_HASH_MODE_SSLMAC_CSHAKE           ((uint32)0x00000001)  /*!< SSLMAC_CSHAKE mode is selected */
#define SPACC_SM3_HASH_MODE_HMAC_KMAC               ((uint32)0x00000002)  /*!< HMAC_KMAC mode is selected */
#define IS_SPACC_SM3_HASH_MODE(MODE)                (((MODE) == SPACC_SM3_HASH_MODE_RAW_SHAKE) || \
                                                     ((MODE) == SPACC_SM3_HASH_MODE_SSLMAC_CSHAKE) || \
                                                     ((MODE) == SPACC_SM3_HASH_MODE_HMAC_KMAC))
/**
  * @}
  */

/** @defgroup SPACC_Transform SPACC Transform To Apply selection
  * @brief  Transfer mode selection: encryption or decryption.
  * @{
  */
#define SPACC_TRANS_TO_APPLY_DECRYPT                ((uint32)0x00000000)  /*!< Decrypt mode is selected */
#define SPACC_TRANS_TO_APPLY_ENCRYPT                ((uint32)0x00000001)  /*!< Encrypt mode is selected */
#define IS_SPACC_TRANS_TO_APPLY(MODE)               (((MODE) == SPACC_TRANS_TO_APPLY_DECRYPT) || \
                                                     ((MODE) == SPACC_TRANS_TO_APPLY_ENCRYPT))
/**
  * @}
  */

/** @defgroup SPACC_Key_From SPACC Key From selection
  * @brief  Key source selection: context or SKP.
  * @{
  */
#define SPACC_KEY_FROM_CTX                          ((uint32)0x00000000)  /*!< Use cipher key from context */
#define SPACC_KEY_FROM_SKP                          ((uint32)0x00000001)  /*!< Use cipher key from SKP */
#define IS_SPACC_KEY_FROM(FROM)                     (((FROM) == SPACC_KEY_FROM_CTX) || \
                                                     ((FROM) == SPACC_KEY_FROM_SKP))
/**
  * @}
  */

/** @defgroup SPACC_AAD_Copy SPACC Copy the PRE_AAD to the destination buffer selection
  * @brief  Whether to copy the PRE_AAD to the destination buffer.
  * @{
  */
#define SPACC_APP_NOT_COPY                          ((uint32)0x00000000)  /*!< Do not copy the PRE_AAD to the destination buffer */
#define SPACC_APP_COPY                              ((uint32)0x00000001)  /*!< Copy the PRE_AAD to the destination buffer */
#define IS_SPACC_APP_COPY(COPY)                     (((COPY) == SPACC_APP_NOT_COPY) || \
                                                     ((COPY) == SPACC_APP_COPY))
/**
  * @}
  */

/** @defgroup SPACC_ICV_Compute SPACC ICV Compute selection
  * @brief  Whether the ICV is computed over the plaintext or the ciphertext.
  * @{
  */
#define SPACC_ICV_COMPUTER_PLAIN                    ((uint32)0x00000000)  /*!< ICV is computed over the plaintext */
#define SPACC_ICV_COMPUTER_CIPHER                   ((uint32)0x00000001)  /*!< ICV is computed over the ciphertext */
#define IS_SPACC_ICV_COMPUTER(COMPUTER)             (((COMPUTER) == SPACC_ICV_COMPUTER_PLAIN) || \
                                                     ((COMPUTER) == SPACC_ICV_COMPUTER_CIPHER))
/**
  * @}
  */

/** @defgroup SPACC_ICV_Encrypt SPACC ICV Encrypt selection
  * @brief  Whether the ICV is encrypted.
  * @{
  */
#define SPACC_ICV_NOT_ENCRYPT                       ((uint32)0x00000000)  /*!< ICV is not encrypted */
#define SPACC_ICV_ENCRYPT                           ((uint32)0x00000001)  /*!< ICV is encrypted */
#define IS_SPACC_ICV_ENCRYPT(ENCRYPT)               (((ENCRYPT) == SPACC_ICV_NOT_ENCRYPT) || \
                                                     ((ENCRYPT) == SPACC_ICV_ENCRYPT))
/**
  * @}
  */

/** @defgroup SPACC_ICV_Location SPACC ICV Location selection
  * @brief  ICV location: indicated by ICV offset or at the end of the packet.
  * @{
  */
#define SPACC_ICV_LOCATION_OFFSET                   ((uint32)0x00000000)  /*!< ICV location indicated by ICV OFFSET */
#define SPACC_ICV_LOCATION_APPEND                   ((uint32)0x00000001)  /*!< ICV located at end of packet */
#define IS_SPACC_ICV_LOCATION(LOCATION)             (((LOCATION) == SPACC_ICV_LOCATION_OFFSET) || \
                                                     ((LOCATION) == SPACC_ICV_LOCATION_APPEND))
/**
  * @}
  */

/** @defgroup SPACC_Key_Expand SPACC Key Expand selection
  * @brief  Whether to expand the key.
  * @{
  */
#define SPACC_KEY_NOT_EXPAND                        ((uint32)0x00000000)  /*!< Do not expand the key */
#define SPACC_KEY_EXPAND                            ((uint32)0x00000001)  /*!< Expand the key */
#define IS_SPACC_KEY_EXPAND(EXPAND)                 (((EXPAND) == SPACC_KEY_NOT_EXPAND) || \
                                                     ((EXPAND) == SPACC_KEY_EXPAND))
/**
  * @}
  */

/** @defgroup SPACC_Message_Begin SPACC Message Begin selection
  * @brief  Begin flag for partial packet processing (first segment or not).
  * @{
  */
#define SPACC_MSG_BEGIN_NOT_FIRST                   ((uint32)0x00000000)  /*!< Subsequent segment of packet */
#define SPACC_MSG_BEGIN_FIRST                       ((uint32)0x00000001)  /*!< First segment of packet */
#define IS_SPACC_MSG_BEGIN(BEGIN)                   (((BEGIN) == SPACC_MSG_BEGIN_NOT_FIRST) || \
                                                     ((BEGIN) == SPACC_MSG_BEGIN_FIRST))
/**
  * @}
  */

/** @defgroup SPACC_Message_End SPACC Message End selection
  * @brief  End flag for partial packet processing (last segment or not).
  * @{
  */
#define SPACC_MSG_END_NOT_LAST                      ((uint32)0x00000000)  /*!< Non-last segment of packet */
#define SPACC_MSG_END_LAST                          ((uint32)0x00000001)  /*!< Last segment of packet */
#define IS_SPACC_MSG_END(END)                       (((END) == SPACC_MSG_END_NOT_LAST) || \
                                                     ((END) == SPACC_MSG_END_LAST))
/**
  * @}
  */

/** @defgroup SPACC_IV_Location SPACC IV Location selection
  * @brief  IV value location: context or source buffer.
  * @{
  */
#define SPACC_IV_LOCATION_CONTEXT                   ((uint32)0x00000000)  /*!< The IV value is fetched from the context area */
#define SPACC_IV_LOCATION_SOURCE                    ((uint32)0x00000001)  /*!< The IV value is fetched from the source buffer */
#define IS_SPACC_IV_LOCATION(LOCATION)              (((LOCATION) == SPACC_IV_LOCATION_CONTEXT) || \
                                                     ((LOCATION) == SPACC_IV_LOCATION_SOURCE))
/**
  * @}
  */

/** @defgroup SPACC_Key_Type SPACC Key Type selection
  * @brief  Key type: hash or cipher.
  * @{
  */
#define SPACC_KEY_TYPE_HASH                         ((uint32)0x00000000)  /*!< Hash Key */
#define SPACC_KEY_TYPE_CIPHER                       ((uint32)0x00000001)  /*!< Cipher Key */
#define IS_SPACC_KEY_TYPE(TYPE)                     (((TYPE) == SPACC_KEY_TYPE_HASH) || \
                                                     ((TYPE) == SPACC_KEY_TYPE_CIPHER))
/**
  * @}
  */

/** @defgroup SPACC_IT_Definitions SPACC Interrupt Enable Definitions
  * @brief  SPACC interrupt enable definitions. The values map the IRQ_EN
  *         register bits (one clock gate / enable bit per interrupt source
  *         plus the global gate). The interrupt is enabled with
  *         HAL_SPACC_ITConfig() or __HAL_SPACC_ENABLE_IT().
  * @{
  */
#define SPACC_IT_CMDO                               SPACC_IRQ_EN_CMD0_EN    /*!< Command FIFO priority 0 interrupt enable */
#define SPACC_IT_CMD1                               SPACC_IRQ_EN_CMD1_EN    /*!< Command FIFO priority 1 interrupt enable */
#define SPACC_IT_CMD2                               SPACC_IRQ_EN_CMD2_EN    /*!< Command FIFO priority 2 interrupt enable */
#define SPACC_IT_STAT                               SPACC_IRQ_EN_STAT_EN    /*!< Status FIFO interrupt enable */
#define SPACC_IT_RC4_DMA                            SPACC_IRQ_EN_RC4_DMA_EN /*!< RC4 context DMA interrupt enable */
#define SPACC_IT_STAT_WD                            SPACC_IRQ_EN_STAT_WD_EN /*!< Status watchdog interrupt enable */
#define SPACC_IT_GLBL                               SPACC_IRQ_EN_GLBL_EN    /*!< Global interrupt enable */
#define IS_SPACC_IT(IT)                             (((IT) == SPACC_IT_CMDO) || \
                                                     ((IT) == SPACC_IT_CMD1) || \
                                                     ((IT) == SPACC_IT_CMD2) || \
                                                     ((IT) == SPACC_IT_STAT) || \
                                                     ((IT) == SPACC_IT_RC4_DMA) || \
                                                     ((IT) == SPACC_IT_STAT_WD) || \
                                                     ((IT) == SPACC_IT_GLBL))
/**
  * @}
  */

/** @defgroup SPACC_IT_State_Definitions SPACC Interrupt Status Definitions
  * @brief  SPACC interrupt status definitions. The values map the IRQ_STAT
  *         register bits. These are read as the interrupt source status
  *         flags (the device-layer header names them SPACC_IT_STATE_*, kept for
  *         migration compatibility). The status flags are cleared by the
  *         corresponding FIFO/service operation (no explicit write-1-clear
  *         register is exposed).
  * @{
  */
#define SPACC_IT_STATE_CMDO                         SPACC_IRQ_STAT_CMD0     /*!< Command FIFO priority 0 interrupt state */
#define SPACC_IT_STATE_CMD1                         SPACC_IRQ_STAT_CMD1     /*!< Command FIFO priority 1 interrupt state */
#define SPACC_IT_STATE_CMD2                         SPACC_IRQ_STAT_CMD2     /*!< Command FIFO priority 2 interrupt state */
#define SPACC_IT_STATE_STAT                         SPACC_IRQ_STAT_STAT     /*!< Status FIFO interrupt state */
#define SPACC_IT_STATE_RC4_DMA                      SPACC_IRQ_STAT_RC4_DMA  /*!< RC4 context DMA interrupt state */
#define SPACC_IT_STATE_STAT_WD                      SPACC_IRQ_STAT_STAT_WD  /*!< Status watchdog interrupt state */
#define IS_SPACC_IT_STATE(STATE)                    (((STATE) == SPACC_IT_STATE_CMDO) || \
                                                     ((STATE) == SPACC_IT_STATE_CMD1) || \
                                                     ((STATE) == SPACC_IT_STATE_CMD2) || \
                                                     ((STATE) == SPACC_IT_STATE_STAT) || \
                                                     ((STATE) == SPACC_IT_STATE_RC4_DMA) || \
                                                     ((STATE) == SPACC_IT_STATE_STAT_WD))
/**
  * @}
  */

/**
  * @}
  */

/* Exported macros -----------------------------------------------------------*/

/** @defgroup SPACC_Exported_Macros SPACC Exported Macros
  * @{
  */

/** @brief  Reset SPACC handle state
  * @param  __HANDLE__: SPACC Handle
  * @retval None
  */
#define __HAL_SPACC_RESET_HANDLE_STATE(__HANDLE__) ((__HANDLE__)->State = HAL_SPACC_STATE_RESET)

/**
  * @brief  Enables the selected SPACC interrupt.
  * @param  __HANDLE__: SPACC Handle
  * @param  __IT__: SPACC interrupt to enable (SPACC_IT_*)
  * @retval None
  */
#define __HAL_SPACC_ENABLE_IT(__HANDLE__, __IT__)   SET_BIT((__HANDLE__)->Instance->IRQ_EN, (__IT__))

/**
  * @brief  Disables the selected SPACC interrupt.
  * @param  __HANDLE__: SPACC Handle
  * @param  __IT__: SPACC interrupt to disable (SPACC_IT_*)
  * @retval None
  */
#define __HAL_SPACC_DISABLE_IT(__HANDLE__, __IT__)  CLEAR_BIT((__HANDLE__)->Instance->IRQ_EN, (__IT__))

/**
  * @brief  Checks whether the specified SPACC interrupt status has occurred.
  * @note   The status flags are read from the IRQ_STAT register. The STAT
  *         bit is the completion flag of a command (status FIFO non-empty),
  *         the STAT_WD bit indicates a status watchdog timeout.
  * @param  __HANDLE__: SPACC Handle
  * @param  __IT__: SPACC interrupt status to check (SPACC_IT_STATE_*)
  * @retval The new state of __IT__ (SET or RESET).
  */
#define __HAL_SPACC_GET_IT(__HANDLE__, __IT__)      (READ_BIT((__HANDLE__)->Instance->IRQ_STAT, (__IT__)) != 0U)

/**
  * @brief  Checks whether the specified SPACC status flag is set.
  * @note   The state FIFO empty flag is read from the FIFO_STAT register.
  * @param  __HANDLE__: SPACC Handle
  * @param  __FLAG__: SPACC status flag to check (SPACC_FIFO_STAT_*)
  * @retval The new state of __FLAG__ (SET or RESET).
  */
#define __HAL_SPACC_GET_FLAG(__HANDLE__, __FLAG__)  (READ_BIT((__HANDLE__)->Instance->FIFO_STAT, (__FLAG__)) != 0U)

/**
  * @brief  Pops the status FIFO (ejects the STATUS register entry).
  * @note   Writing a 1 to STAT_POP.POP ejects the current STATUS entry so
  *         that the next result can be read.
  * @param  __HANDLE__: SPACC Handle
  * @retval None
  */
#define __HAL_SPACC_STAT_POP(__HANDLE__)            WRITE_REG((__HANDLE__)->Instance->STAT_POP, 0x1U)

/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/

/** @defgroup SPACC_Exported_Functions SPACC Exported Functions
  * @{
  */

/** @defgroup SPACC_Exported_Functions_Group1 Initialization and de-initialization functions
  *  @brief    Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Fills each SPACC_InitStruct member with its default value (NON-BLOCKING)
 *         (cipher NULL, SM4 ECB, hash NULL, SM3 RAW_SHAKE, decrypt mode,
 *         key from context, ICV over plaintext, key type hash).
 * @param  Init: pointer to a SPACC_InitTypeDef structure which will be
 *         initialized.
 * @retval None
 */
void HAL_SPACC_StructInit(SPACC_InitTypeDef *Init);

/**
 * @brief  Initializes the SPACC peripheral according to the specified (NON-BLOCKING)
 *         parameters in the SPACC_InitStruct of the handle.
 * @note   Applies the configuration to the SW_CTRL / KEY_SZ / CTRL
 *         registers. The command is submitted later through the packet
 *         descriptor registers (HAL_SPACC_PacketInit).
 * @note   The DSE clock gating and the PLIC interrupt line must be
 *         configured by the user in HAL_SPACC_MspInit().
 * @param  hspacc: pointer to a SPACC_HandleTypeDef structure.
 * @param  Init: pointer to a SPACC_InitTypeDef structure that contains
 *         the configuration for the SPACC control registers.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_SPACC_Init(HAL_SPACC_HandleTypeDef *hspacc, const SPACC_InitTypeDef *Init);

/**
 * @brief  De-initializes the SPACC peripheral. (NON-BLOCKING)
 * @note   Disables the interrupts and resets the SW_CTRL / KEY_SZ / CTRL
 *         registers. The IRQ_STAT status flags are not cleared here (no
 *         write-to-clear register is exposed by the hardware).
 * @param  hspacc: pointer to a SPACC_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_SPACC_DeInit(HAL_SPACC_HandleTypeDef *hspacc);

/**
 * @brief  Initializes the SPACC MSP. Weak empty function; the user (NON-BLOCKING)
 *         implements the low level hardware initialization (DSE clock
 *         enable through the SMU, PLIC interrupt enable).
 * @param  hspacc: pointer to a SPACC_HandleTypeDef structure.
 * @retval None
 */
void HAL_SPACC_MspInit(HAL_SPACC_HandleTypeDef *hspacc);

/**
 * @brief  De-initializes the SPACC MSP. Weak empty function; the user (NON-BLOCKING)
 *         implements the low level hardware de-initialization.
 * @param  hspacc: pointer to a SPACC_HandleTypeDef structure.
 * @retval None
 */
void HAL_SPACC_MspDeInit(HAL_SPACC_HandleTypeDef *hspacc);

/**
  * @}
  */

/** @defgroup SPACC_Exported_Functions_Group2 IO operation functions
  *  @brief    IO operation functions
  * @{
  */

/**
 * @brief  Configures the SPACC packet descriptor registers. (NON-BLOCKING)
 * @param  hspacc: pointer to a SPACC_HandleTypeDef structure.
 * @param  Packet: pointer to a SPACC_PacketTypeDef structure that
 *         contains the packet descriptor.
 * @retval None
 */
void HAL_SPACC_PacketInit(HAL_SPACC_HandleTypeDef *hspacc, const SPACC_PacketTypeDef *Packet);

/**
 * @brief  Enables or disables the selected SPACC interrupt. (NON-BLOCKING)
 * @param  hspacc: pointer to a SPACC_HandleTypeDef structure.
 * @param  ITType: SPACC interrupt type (SPACC_IT_*).
 * @param  NewState: ENABLE or DISABLE.
 * @retval None
 */
void HAL_SPACC_ITConfig(HAL_SPACC_HandleTypeDef *hspacc, uint32 ITType, FunctionalState NewState);

/**
 * @brief  Checks whether the specified SPACC interrupt status has occurred. (NON-BLOCKING)
 * @param  hspacc: pointer to a SPACC_HandleTypeDef structure.
 * @param  IT: SPACC interrupt state to check (SPACC_IT_STATE_*).
 * @retval FlagStatus: SET or RESET.
 */
FlagStatus HAL_SPACC_GetITStatus(HAL_SPACC_HandleTypeDef *hspacc, uint32 IT);

/**
 * @brief  Gets the result of the command execution (ejects the status FIFO). (NON-BLOCKING)
 * @param  hspacc: pointer to a SPACC_HandleTypeDef structure.
 * @param  SoftwareID: software ID of the command to match.
 * @retval FlagStatus: SET if the ejected software ID matches, RESET otherwise.
 */
FlagStatus HAL_SPACC_CommandExecResult(HAL_SPACC_HandleTypeDef *hspacc, uint32 SoftwareID);

/**
 * @brief  Gets the state of the SPACC state FIFO. (NON-BLOCKING)
 * @param  hspacc: pointer to a SPACC_HandleTypeDef structure.
 * @retval FlagStatus: SET when the status FIFO is empty, RESET when a
 *         command result is pending.
 */
FlagStatus HAL_SPACC_StateFIFOFlag(HAL_SPACC_HandleTypeDef *hspacc);

/**
 * @brief  Reads the SPACC status register value. (NON-BLOCKING)
 * @param  hspacc: pointer to a SPACC_HandleTypeDef structure.
 * @retval uint32: the raw STATUS register value.
 */
uint32 HAL_SPACC_ReadStatus(HAL_SPACC_HandleTypeDef *hspacc);

/**
 * @brief  Writes data to the SPACC context memory area. (NON-BLOCKING)
 * @param  hspacc: pointer to a SPACC_HandleTypeDef structure.
 * @param  Base: context base address (SPACC_CIPHER_CONTEXT_BASE or
 *               SPACC_HASH_CONTEXT_BASE).
 * @param  Offset: byte offset from the context base.
 * @param  Data: pointer to the buffer to write.
 * @param  Length: number of 32-bit words to write.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_SPACC_WriteContext(HAL_SPACC_HandleTypeDef *hspacc, uint32 Base,
                                         uint32 Offset, uint32 *Data, uint32 Length);

/**
 * @brief  Reads data from the SPACC context memory area. (NON-BLOCKING)
 * @param  hspacc: pointer to a SPACC_HandleTypeDef structure.
 * @param  Base: context base address (SPACC_CIPHER_CONTEXT_BASE or
 *               SPACC_HASH_CONTEXT_BASE).
 * @param  Offset: byte offset from the context base.
 * @param  Data: pointer to the buffer to store the read data.
 * @param  Length: number of 32-bit words to read.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_SPACC_ReadContext(HAL_SPACC_HandleTypeDef *hspacc, uint32 Base,
                                        uint32 Offset, uint32 *Data, uint32 Length);

/**
 * @brief  Handles the SPACC interrupt request. (NON-BLOCKING)
 * @param  hspacc: pointer to a SPACC_HandleTypeDef structure.
 * @retval None
 */
void HAL_SPACC_IRQHandler(HAL_SPACC_HandleTypeDef *hspacc);

/**
 * @brief  SPACC error callback (WEAK). (NON-BLOCKING)
 * @param  hspacc: pointer to a SPACC_HandleTypeDef structure.
 * @retval None
 */
void HAL_SPACC_ErrorCallback(HAL_SPACC_HandleTypeDef *hspacc);

/**
  * @}
  */

/** @defgroup SPACC_Exported_Functions_Group3 Peripheral State functions
  *  @brief    Peripheral State functions
  * @{
  */

/**
 * @brief  Returns the SPACC handle state. (NON-BLOCKING)
 * @param  hspacc: pointer to a SPACC_HandleTypeDef structure.
 * @retval HAL_SPACC_StateTypeDef: the current handle state.
 */
HAL_SPACC_StateTypeDef HAL_SPACC_GetState(HAL_SPACC_HandleTypeDef *hspacc);

/**
 * @brief  Returns the SPACC error code. (NON-BLOCKING)
 * @param  hspacc: pointer to a SPACC_HandleTypeDef structure.
 * @retval uint32: the SPACC error code (HAL_SPACC_ERROR_xxx).
 */
uint32 HAL_SPACC_GetError(HAL_SPACC_HandleTypeDef *hspacc);

/**
  * @}
  */
/**
  * @}
  */

/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/
/** @defgroup SPACC_Private_Macros SPACC Private Macros
  * @{
  */
#define IS_SPACC_ALL_INSTANCE(INSTANCE) (((INSTANCE) == SPACC))
/* Device-layer-compatible periph check alias (as32x601_spacc.h uses IS_SPACC_ALL_PERIPH) */
#define IS_SPACC_ALL_PERIPH IS_SPACC_ALL_INSTANCE
#define IS_SPACC_CONTEXT_BASE(BASE)          (((BASE) == SPACC_CIPHER_CONTEXT_BASE) || \
                                              ((BASE) == SPACC_HASH_CONTEXT_BASE))

/**
  * @}
  */

/* Shared internal functions --------------------------------------------------*/

/**
 * @brief  Checks whether the SPACC handle and its instance are valid.
 * @param  hspacc: pointer to a HAL_SPACC_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
uint32 SPACC_HandleIsValid(HAL_SPACC_HandleTypeDef *hspacc);

/**
 * @brief  Checks whether the handle accepts a new operation (ARCH-CONST-09).
 * @note   A handle that is BUSY (an operation is ongoing in another context)
 *         rejects the call with HAL_BUSY, an uninitialized handle (RESET) with
 *         HAL_ERROR, while the recoverable state ERROR accepts it directly.
 * @param  hspacc: pointer to a HAL_SPACC_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef SPACC_CheckState(HAL_SPACC_HandleTypeDef *hspacc);

/**
 * @brief  Lock the handle (RTOS mutex or single core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_SPACC_MspInit()). The bare metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; the value is passed to HAL_MutexAcquire() as
 *         is (RTOS ticks; HAL_MAX_DELAY means an infinite wait).
 * @param  hspacc: pointer to a HAL_SPACC_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef SPACC_LockHandle(HAL_SPACC_HandleTypeDef *hspacc, uint32 Timeout);

/**
 * @brief  Unlock the handle.
 * @param  hspacc: pointer to a HAL_SPACC_HandleTypeDef structure.
 * @retval None
 */
void SPACC_UnlockHandle(HAL_SPACC_HandleTypeDef *hspacc);

/**
  * @}
  */

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_SPACC_H */

/*****END OF FILE*****/
