/**
 * @file    MPU_IT_DRV_005.c
 * @brief   HAL MPU integration test case 005 (P-Port read protection, channels
 *          0..15).
 *
 * One-to-one HAL library port of the original AS32x601 standard-library test
 * case MPU_IT_DRV_005.c. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_MPU_SetAddressRange()
 *   HAL_MPU_ReadProtectCmd()
 *   HAL_MPU_Cmd()
 *   HAL_MPU_GetReadProtectStatus()
 *   HAL_MPU_ClearStatus()
 *   HAL_MPU_GetChannelConfig()
 *
 * Test procedure:
 *   1. Open the clock gates of the addressed peripherals (GPIOA..GPIOG and
 *      USART0..USART7; GPIOH sits on the always-clocked APB-BusS domain);
 *   2. Select 16 peripheral registers, one per channel: GPIOA..GPIOH OICR and
 *      USART0..USART7 BRR, and protect each one with its own 4-byte window;
 *   3. Enable the read protection of all 16 channels and the channels
 *      themselves, then check the whole configuration from the firmware:
 *      register read-back, HAL_MPU_GetChannelConfig() read-back, the
 *      disable / enable round trip and the clear-status path;
 *   4. Read the 16 peripheral registers: every access passes through the P-Port
 *      and sets the read-protection status of the matching channel;
 *   5. Check the RPTS register and the per channel status, then clear them;
 *   6. Disable the protection and check that a new read records nothing.
 *
 * Test configuration (same as the original test case):
 *   MPU2 (P-Bus) channels 0..15, read protection of 16 peripheral registers
 *   (GPIO OICR 0..7, USART BRR 0..7).  Every window lies in a page of its own,
 *   so no two channels share an alignment block of the port.
 *
 * Expected behaviour:
 *   - RPTEN / PTEN read back as 0xFFFF;
 *   - before the reads the status is clear;
 *   - the 16 reads set RPTS bit 0..15, so the read-protection state reads
 *     0xFFFF (the value the original test specification expects);
 *   - HAL_MPU_GetReadProtectStatus() reports 1 for all 16 channels;
 *   - HAL_MPU_ClearStatus() empties the status;
 *   - after the protection is disabled a new read records nothing.
 * NOTE: A violation is recorded by the MPU (and forwarded to the FCU by its
 *       MPU2 channel); it does not abort the access, so the peripheral responds
 *       normally and the read value is meaningless but harmless.  Measured on
 *       the board: a refused P-Port read returns 0.
 * NOTE: The peripheral registers are not cached, so the cache flush before the
 *       reads (kept because the original case issues it) has no influence on
 *       the result; it is harmless.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Report period (ms) */
#define TEST_PERIOD_MS              (1000U)

/* MPU instance under test (MPU2 = P-Bus peripheral port) */
#define TEST_MPU_INSTANCE           (HAL_MPU_INSTANCE_2_PBUS)

/* Number of channels of MPU2 */
#define TEST_CHANNEL_COUNT          (16U)

/* Length of one protected window (bytes) */
#define TEST_WINDOW_LENGTH          (4U)

/* Private variables ---------------------------------------------------------*/
static HAL_MPU_HandleTypeDef hmpu_dev;        /*!< MPU device handle           */
static uint32          failures = 0U;         /*!< failed checks               */

static volatile uint32 p_port_value;          /*!< sink of the protected reads */
static MPU_Channel_TypeDef * const mpu2_channel[16] =
{
    MPU2_Channel0, MPU2_Channel1, MPU2_Channel2,  MPU2_Channel3,
    MPU2_Channel4, MPU2_Channel5, MPU2_Channel6,  MPU2_Channel7,
    MPU2_Channel8, MPU2_Channel9, MPU2_Channel10, MPU2_Channel11,
    MPU2_Channel12, MPU2_Channel13, MPU2_Channel14, MPU2_Channel15
};

static HAL_SMU_HandleTypeDef hsmu_clk;   /*!< SMU handle (lock / state / error) */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void Check(const char *name, uint32 condition);
static void Read_EnableMasks(HAL_MPU_HandleTypeDef *hmpu, uint32 count,
                             uint32 *pten, uint32 *rpten, uint32 *wpten);

static void Peripheral_ClockEnable(void);
static void Peripheral_Addresses(uint32 *addr);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    uint32 addr[TEST_CHANNEL_COUNT];
    uint32 ch;
    uint32 state;
    uint32 rd_pten;
    uint32 rd_rpten;
    uint32 rd_wpten;
    uint32 ok;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n\r\n ***** MPU Test ***** \r\n");
    printf("case : MPU_IT_DRV_005 (P-Port read protection, channels 0..15)\r\n");
    delay_ms(500U);

    /* ---- Step 1: clocks and protected peripheral registers -------- */
    Peripheral_ClockEnable();
    Peripheral_Addresses(addr);

    printf("\r\n-----------------protected peripheral registers----------------- \r\n");
    __HAL_CLEAR_STRUCT(&hmpu_dev);
    hmpu_dev.Instance = TEST_MPU_INSTANCE;
    /* The channel control functions require an initialized handle: this case
       drives them directly, so the READY state is set up explicitly (no
       channel is programmed by HAL_MPU_Init() here) */
    hmpu_dev.State = HAL_MPU_STATE_READY;

    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        HAL_MPU_SetAddressRange(&hmpu_dev, ch, addr[ch], addr[ch] + TEST_WINDOW_LENGTH);
        printf("channel %2u : 0x%08X\r\n", PRINT_U32(ch), PRINT_U32(addr[ch]));
    }

    ok = 1U;
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        if ((mpu2_channel[ch]->SADDR != addr[ch]) ||
            (mpu2_channel[ch]->EADDR != (addr[ch] + TEST_WINDOW_LENGTH)))
        {
            ok = 0U;
        }
    }
    Check("SADDR / EADDR of all 16 channels", ok);

    /* ---- Step 2: read protection and channel enable -------------- */
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        HAL_MPU_ReadProtectCmd(&hmpu_dev, ch, MPU_ENABLE);
    }
    Check("RPTEN = 0xFFFF", (((MPU2_PBUS->RPTEN & 0xFFFFUL) == 0xFFFFUL) ? 1U : 0U));

    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        HAL_MPU_Cmd(&hmpu_dev, ch, MPU_ENABLE);
    }
    Check("PTEN = 0xFFFF", (((MPU2_PBUS->PTEN & 0xFFFFUL) == 0xFFFFUL) ? 1U : 0U));
    /* read the enable masks back through the HAL API (V1.2); the direct
       register reads above stay as the white-box cross check */
    Read_EnableMasks(&hmpu_dev, TEST_CHANNEL_COUNT, &rd_pten, &rd_rpten, &rd_wpten);
    Check("RPTEN read back by HAL_MPU_GetChannelConfig",
          (((rd_rpten & 0xFFFFUL) == 0xFFFFUL) ? 1U : 0U));
    Check("PTEN read back by HAL_MPU_GetChannelConfig",
          (((rd_pten & 0xFFFFUL) == 0xFFFFUL) ? 1U : 0U));
    Check("no write protection enable (read protection case, HAL read-back)",
          ((rd_wpten == 0U) ? 1U : 0U));

    delay_ms(100U);

    /* ---- Step 3: status path before any protected read ----------- */
    printf("\r\n-----------------configuration------------------------ \r\n");

    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        (void)HAL_MPU_ClearStatus(&hmpu_dev, ch);
    }
    Check("RPTS = 0 before the protected reads",
          ((((uint32)MPU2_PBUS->RPTS & 0xFFFFUL) == 0U) ? 1U : 0U));

    ok = 1U;
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        if (HAL_MPU_GetReadProtectStatus(&hmpu_dev, ch) != 0U)
        {
            ok = 0U;
        }
    }
    Check("HAL_MPU_GetReadProtectStatus = 0 for all 16 channels", ok);

    /* disable / enable round trip of both control bits (no protected read) */
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        HAL_MPU_ReadProtectCmd(&hmpu_dev, ch, MPU_DISABLE);
        HAL_MPU_Cmd(&hmpu_dev, ch, MPU_DISABLE);
    }
    Check("RPTEN = 0 after the disable",
          (((MPU2_PBUS->RPTEN & 0xFFFFUL) == 0U) ? 1U : 0U));
    Check("PTEN = 0 after the disable",
          (((MPU2_PBUS->PTEN & 0xFFFFUL) == 0U) ? 1U : 0U));

    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        HAL_MPU_ReadProtectCmd(&hmpu_dev, ch, MPU_ENABLE);
        HAL_MPU_Cmd(&hmpu_dev, ch, MPU_ENABLE);
    }
    Check("RPTEN = 0xFFFF after the re-enable",
          (((MPU2_PBUS->RPTEN & 0xFFFFUL) == 0xFFFFUL) ? 1U : 0U));
    Check("PTEN = 0xFFFF after the re-enable",
          (((MPU2_PBUS->PTEN & 0xFFFFUL) == 0xFFFFUL) ? 1U : 0U));

    ok = 1U;
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        if ((mpu2_channel[ch]->SADDR != addr[ch]) ||
            (mpu2_channel[ch]->EADDR != (addr[ch] + TEST_WINDOW_LENGTH)))
        {
            ok = 0U;
        }
    }
    Check("SADDR / EADDR of all 16 channels after the round trip", ok);

    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        (void)HAL_MPU_ClearStatus(&hmpu_dev, ch);
    }
    Check("status cleared right before the protected reads",
          ((((uint32)MPU2_PBUS->RPTS & 0xFFFFUL) == 0U) ? 1U : 0U));

    /* ---- Step 4: the protected reads ---------------------------- */
    printf("\r\n-----------------trigger the protection----------------- \r\n");

    /* Kept because the original case issues it; the peripheral registers are
       not cached, so it does not influence the result */
    CLEAR_CACHE();
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        p_port_value = *(volatile uint32 *)(unsigned long)addr[ch];
    }

    state = (uint32)MPU2_PBUS->RPTS;
    printf("MPU2 RPTS : 0x%08X (data of a refused read 0x%08X)\r\n",
           PRINT_U32(state), PRINT_U32(p_port_value));

    Check("read protection state = 0xFFFF", ((state & 0xFFFFUL) == 0xFFFFUL));
    Check("bit 0 (GPIOA OICR window) set", ((state & 0x0001UL) != 0U));
    Check("bit 15 (USART7 BRR window) set", ((state & 0x8000UL) != 0U));

    ok = 1U;
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        if (HAL_MPU_GetReadProtectStatus(&hmpu_dev, ch) == 0U)
        {
            ok = 0U;
        }
    }
    Check("HAL_MPU_GetReadProtectStatus of all 16 channels", ok);

    /* ---- Step 5: clear, then disable ---------------------------- */
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        (void)HAL_MPU_ClearStatus(&hmpu_dev, ch);
    }
    Check("status cleared by HAL_MPU_ClearStatus",
          ((((uint32)MPU2_PBUS->RPTS & 0xFFFFUL) == 0U) ? 1U : 0U));

    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        HAL_MPU_ReadProtectCmd(&hmpu_dev, ch, MPU_DISABLE);
        HAL_MPU_Cmd(&hmpu_dev, ch, MPU_DISABLE);
    }
    Check("RPTEN / PTEN cleared by the disable",
          (((((uint32)MPU2_PBUS->RPTEN & 0xFFFFUL) == 0U) &&
            (((uint32)MPU2_PBUS->PTEN & 0xFFFFUL) == 0U)) ? 1U : 0U));

    CLEAR_CACHE();
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        p_port_value = *(volatile uint32 *)(unsigned long)addr[ch];
    }
    Check("no violation while the protection is disabled",
          ((((uint32)MPU2_PBUS->RPTS & 0xFFFFUL) == 0U) ? 1U : 0U));

    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(failures));

    /* The P-Port only refuses the data: no trap, no exception, so the case can
       keep running.  The protection is left disabled here, which is why the
       trigger is not repeated in the loop (it would report nothing). */
    while (1)
    {
        delay_ms(TEST_PERIOD_MS);
    }
}

/**
 * @brief  Open the clock gates of the peripherals addressed by this case.
 * @note   GPIOH is mapped on the APB-BusS domain, which is always clocked and
 *         has no gate; GPIOA..GPIOG and USART0..USART7 have SMU gates.
 * @param  None
 * @retval None
 */
static void Peripheral_ClockEnable(void)
{
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART1_CLK_ENABLE();
    __HAL_SMU_USART2_CLK_ENABLE();
    __HAL_SMU_USART3_CLK_ENABLE();
    __HAL_SMU_USART4_CLK_ENABLE();
    __HAL_SMU_USART5_CLK_ENABLE();
    __HAL_SMU_USART6_CLK_ENABLE();
    __HAL_SMU_USART7_CLK_ENABLE();
}

/**
 * @brief  Collect the 16 protected peripheral register addresses.
 * @note   Channels 0..7 address the output intensity control register of
 *         GPIOA..GPIOH, channels 8..15 the baud rate register of
 *         USART0..USART7 (same selection as the original test case).
 * @param  addr: array of at least 16 entries filled with the addresses.
 * @retval None
 */
static void Peripheral_Addresses(uint32 *addr)
{
    addr[0]  = (uint32)(unsigned long)&GPIOA->OICR;
    addr[1]  = (uint32)(unsigned long)&GPIOB->OICR;
    addr[2]  = (uint32)(unsigned long)&GPIOC->OICR;
    addr[3]  = (uint32)(unsigned long)&GPIOD->OICR;
    addr[4]  = (uint32)(unsigned long)&GPIOE->OICR;
    addr[5]  = (uint32)(unsigned long)&GPIOF->OICR;
    addr[6]  = (uint32)(unsigned long)&GPIOG->OICR;
    addr[7]  = (uint32)(unsigned long)&GPIOH->OICR;
    addr[8]  = (uint32)(unsigned long)&USART0->BRR;
    addr[9]  = (uint32)(unsigned long)&USART1->BRR;
    addr[10] = (uint32)(unsigned long)&USART2->BRR;
    addr[11] = (uint32)(unsigned long)&USART3->BRR;
    addr[12] = (uint32)(unsigned long)&USART4->BRR;
    addr[13] = (uint32)(unsigned long)&USART5->BRR;
    addr[14] = (uint32)(unsigned long)&USART6->BRR;
    addr[15] = (uint32)(unsigned long)&USART7->BRR;
}


/**
 * @brief  Rebuild the channel enable / protection enable masks of a MPU
 *         instance by reading the configuration of every channel back through
 *         HAL_MPU_GetChannelConfig().
 * @note   The driver provides the configuration read-back interface from V1.2
 *         on: the masks let the case check the programmed enables through the
 *         HAL API in addition to the direct PTEN / RPTEN / WPTEN reads of the
 *         original test case.
 * @param  hmpu: pointer to the MPU handle.
 * @param  count: number of channels of the instance (16 or 8).
 * @param  pten: receives the channel enable mask.
 * @param  rpten: receives the read protection enable mask.
 * @param  wpten: receives the write protection enable mask.
 * @retval None
 */
static void Read_EnableMasks(HAL_MPU_HandleTypeDef *hmpu, uint32 count,
                             uint32 *pten, uint32 *rpten, uint32 *wpten)
{
    uint32 i;
    MPU_InitTypeDef cfg;

    *pten  = 0U;
    *rpten = 0U;
    *wpten = 0U;

    for (i = 0U; i < count; i++)
    {
        __HAL_CLEAR_STRUCT(&cfg);

        if (HAL_MPU_GetChannelConfig(hmpu, i, &cfg) == HAL_OK)
        {
            *pten  |= ((uint32)cfg.ChannelEnable      << i);
            *rpten |= ((uint32)cfg.ReadProtectEnable  << i);
            *wpten |= ((uint32)cfg.WriteProtectEnable << i);
        }
    }
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition == 0U)
    {
        failures++;
    }
    printf("%-46s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Configure the system clock tree using the HAL SMU / PMU drivers.
 * @note   Same clock tree as the CLINT / CMU reference suites: OSC 20 MHz as
 *         the PLL source, PLLDivN = 20 / PLLDivF = 180 / PLLDivQ = 1 /
 *         PLLDivR = 4 -> 180 MHz VCO, AXI4Bus3 = /2, APBBus0 = /2,
 *         APBBus1 = /2, CANX2 = /8; the 2.5V LDO is scaled to 2.78 V and the
 *         1.2V LDO to 1.34 V as in the reference suites.
 * @note   Clock tree order (the order the chip requires, and the order the
 *         vendor test case uses): configure the oscillators and the PLL and
 *         switch the system clock to it, then write the bus clock dividers.
 *         HAL_SMU_OscConfig() programs the EFLASH controller clock (CLKFRQ)
 *         before the switch and lets it follow the new system clock afterwards
 *         (EFLASH_CLK_UPDATE), so no explicit HAL_FLASH_SetClockFrequency() is
 *         needed here; it also updates SystemCoreClock together with the HAL
 *         time base.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef  SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef   SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it (CLKFRQ above), so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Set the bus clock dividers (the system clock source is already set by
       HAL_SMU_OscConfig() above) */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
