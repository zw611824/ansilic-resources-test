/**
 * @file    RTC_IT_DRV_005.c
 * @brief   HAL RTC integration test case 005: configuration metafield and divider validation of HAL_RTC_Init().
 *
 * The configuration structure carries the Size / Version / Reserved metafields of
 * the library compatibility mechanism (architecture spec section 22). HAL_RTC_Init()
 * validates them plus the divider width at run time, before the lock, before the
 * MSP callback and before any register access, so a rejected structure leaves the
 * handle and the peripheral untouched.
 *
 * Tested functionality:
 *   HAL_RTC_Init() (metafield and divider validation)
 *   HAL_RTC_GetState() / HAL_RTC_GetError() (HAL_RTC_ERROR_INVALID_PARAM)
 *   IS_RTC_INIT_STRUCT_OK() / IS_RTC_DIVISION() (validation macros)
 *   RTC_INIT_V1 / RTC_INIT_VERSION / __HAL_RTC_MODULE_VERSION
 *
 * Expected behaviour:
 *   - every rejected structure reports HAL_ERROR and HAL_RTC_ERROR_INVALID_PARAM,
 *     leaves the handle in the RESET state and does not touch CR;
 *   - a legal structure after the rejected attempts still initializes the module
 *     (the retry path stays open);
 *   - the divider field of CR reads back the requested value, and a second Init with
 *     another divider overwrites it.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* RTC divider coefficient. 1785 is the project baseline of the reference test
 * cases of this chip, 1638 is the other value documented by the library SRS;
 * both are legal hardware values (the driver only checks the 27 bit field
 * width). No test below depends on the resulting absolute frequency: the
 * checks are register read-backs or "the counter moved" observations. */
#define TEST_RTC_DIVISION           (1785U)

/* Calendar value used by the cases that need a known starting point */
#define TEST_TIME_HOURS             (15U)
#define TEST_TIME_MINUTES           (48U)
#define TEST_TIME_SECONDS           (0U)
#define TEST_TIME_TOS               (0U)
#define TEST_DATE_CENTURY           (20U)
#define TEST_DATE_YEAR              (25U)
#define TEST_DATE_MONTH             (RTC_Month_July)
#define TEST_DATE_DATE              (21U)
#define TEST_DATE_WEEKDAY           (RTC_Weekday_Monday)

/* Polling slice of the wait loops (ms) */
#define TEST_POLL_MS                (10U)

/* Reporting period of the final idle loop (ms) */
#define TEST_IDLE_MS                (1000U)

/* Alternative divider used by the re-initialization check */
#define TEST_RTC_DIVISION_ALT       (1638U)

/* Private variables ---------------------------------------------------------*/
static RTC_HandleTypeDef hrtc_dev;          /*!< RTC device handle            */
static RTC_InitTypeDef   rtc_init;          /*!< RTC configuration structure  */
static uint32            failures = 0U;     /*!< failed checks                */

/* Alarm interrupt bookkeeping (filled by the overridden weak callback) */
static volatile uint32   alarm_events = 0U; /*!< callback entries             */
static volatile uint32   alarm_cr_seen = 0U;/*!< CR register at callback time */

/* Bookkeeping of this case */
static uint32            register_before;
static RTC_HandleTypeDef bad_handle;

/* Last calendar read back by the report helpers */
static uint8 r_time_hours;
static uint8 r_time_minutes;
static uint8 r_time_seconds;
static uint8 r_time_tos;
static uint8 r_date_century;
static uint8 r_date_year;
static uint8 r_date_month;
static uint8 r_date_date;
static uint8 r_date_weekday;

/* Private function prototypes -----------------------------------------------*/
static void Check(const char *name, uint32 condition);
static void SystemClock_Init(void);
static void Rtc_Handle_Setup(void);
static HAL_StatusTypeDef Rtc_GetCalendar(void);
static uint8 Rtc_MonthToNumber(uint8 month);
static const char *Rtc_WeekdayName(uint8 weekday);
static void Rtc_PrintCalendar(const char *tag);

/* Exported interrupt entry ------------------------------------------------*/
/**
 * @brief  RTC interrupt entry, called by the shared PLIC dispatch table.
 * @note   Overrides the weak RTC_IRQ_Handler() of the PLIC driver; it hands the
 *         event to the HAL RTC interrupt handler, which clears the alarm flag
 *         and then calls HAL_RTC_AlarmEventCallback().
 */
void RTC_IRQ_Handler(void)
{
    HAL_RTC_AlarmIRQHandler(&hrtc_dev);
}

/**
 * @brief  Alarm event callback (weak function of the HAL RTC driver).
 * @note   Counts the events and snapshots CR so that the cases can observe the
 *         flag state the driver left behind. It must not block and must not
 *         call a locking RTC interface (interrupt context).
 * @param  hrtc pointer to a RTC_HandleTypeDef structure.
 * @retval None
 */
void HAL_RTC_AlarmEventCallback(RTC_HandleTypeDef *hrtc)
{
    UNUSED(hrtc);

    alarm_events++;
    alarm_cr_seen = hrtc_dev.Instance->CR;
}

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock tree */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n\r\n==== RTC_IT_DRV_005: configuration metafield and divider validation of HAL_RTC_Init() ====\r\n");
    printf("Data : %s\r\n", __DATE__);
    printf("Time : %s\r\n", __TIME__);

        /* ---- Step 1: configuration structure versions ---------------------- */
        Check("RTC_INIT_V1 is the current structure version", (RTC_INIT_V1 == RTC_INIT_VERSION));
        Check("module version macro", (__HAL_RTC_MODULE_VERSION == 0x0100U));

        /* The handle is prepared once: the rejected attempts below only modify the
           configuration copy, they never reach the peripheral. */
        Rtc_Handle_Setup();
        register_before = hrtc_dev.Instance->CR;

        /* ---- Step 2: Size metafield --------------------------------------- */
        hrtc_dev.Init.Size = sizeof(RTC_InitTypeDef) - 4U;
        Check("wrong Size rejected", (HAL_RTC_Init(&hrtc_dev) == HAL_ERROR));
        Check("INVALID_PARAM reported for the wrong Size",
              ((HAL_RTC_GetError(&hrtc_dev) & HAL_RTC_ERROR_INVALID_PARAM) != 0U));
        Check("handle stays RESET after the rejected Size",
              (HAL_RTC_GetState(&hrtc_dev) == HAL_RTC_STATE_RESET));

        /* ---- Step 3: Version metafield ------------------------------------ */
        hrtc_dev.Init = rtc_init;
        hrtc_dev.Init.Version = 0x0200U;
        Check("unknown Version rejected", (HAL_RTC_Init(&hrtc_dev) == HAL_ERROR));
        Check("handle stays RESET after the rejected Version",
              (HAL_RTC_GetState(&hrtc_dev) == HAL_RTC_STATE_RESET));

        /* ---- Step 4: Reserved words --------------------------------------- */
        hrtc_dev.Init = rtc_init;
        hrtc_dev.Init.Reserved[0] = 1U;
        Check("Reserved[0] != 0 rejected", (HAL_RTC_Init(&hrtc_dev) == HAL_ERROR));

        hrtc_dev.Init = rtc_init;
        hrtc_dev.Init.Reserved[1] = 1U;
        Check("Reserved[1] != 0 rejected", (HAL_RTC_Init(&hrtc_dev) == HAL_ERROR));

        /* ---- Step 5: divider width ---------------------------------------- */
        hrtc_dev.Init = rtc_init;
        hrtc_dev.Init.Division = 0x08000000U;   /* bit 27, outside DIV[26:0] */
        Check("divider above the 27 bit field rejected",
              (HAL_RTC_Init(&hrtc_dev) == HAL_ERROR));
        Check("INVALID_PARAM reported for the divider",
              ((HAL_RTC_GetError(&hrtc_dev) & HAL_RTC_ERROR_INVALID_PARAM) != 0U));

        hrtc_dev.Init = rtc_init;
        hrtc_dev.Init.Division = 0xFFFFFFFFU;
        Check("divider 0xFFFFFFFF rejected", (HAL_RTC_Init(&hrtc_dev) == HAL_ERROR));

        Check("no register write on the rejected configurations",
              (hrtc_dev.Instance->CR == register_before));
        Check("handle still RESET after every rejected configuration",
              (HAL_RTC_GetState(&hrtc_dev) == HAL_RTC_STATE_RESET));

        /* ---- Step 6: validation macros agree with the run time checks ------ */
        hrtc_dev.Init = rtc_init;
        Check("IS_RTC_INIT_STRUCT_OK accepts the legal structure",
              (IS_RTC_INIT_STRUCT_OK(&hrtc_dev.Init) != 0U));
        hrtc_dev.Init.Size = 0U;
        Check("IS_RTC_INIT_STRUCT_OK rejects a zero Size",
              (IS_RTC_INIT_STRUCT_OK(&hrtc_dev.Init) == 0U));
        hrtc_dev.Init = rtc_init;
        Check("IS_RTC_DIVISION accepts 0 and 0x7FFFFFF",
              ((IS_RTC_DIVISION(0U) != 0U) && (IS_RTC_DIVISION(0x07FFFFFFU) != 0U)));
        Check("IS_RTC_DIVISION rejects 0x08000000", (IS_RTC_DIVISION(0x08000000U) == 0U));

        /* ---- Step 7: the legal structure still initializes the module ------ */
        hrtc_dev.Init = rtc_init;
        Check("legal structure accepted after the rejected attempts",
              (HAL_RTC_Init(&hrtc_dev) == HAL_OK));
        Check("handle READY after the accepted initialization",
              (HAL_RTC_GetState(&hrtc_dev) == HAL_RTC_STATE_READY));
        Check("error code cleared by the accepted initialization",
              (HAL_RTC_GetError(&hrtc_dev) == HAL_RTC_ERROR_NONE));
        Check("divider written",
              (((hrtc_dev.Instance->CR & RTC_CR_DIV) >> RTC_CR_DIV_Pos) == TEST_RTC_DIVISION));

        /* ---- Step 8: a second Init overwrites the divider ------------------ */
        hrtc_dev.Init.Division = TEST_RTC_DIVISION_ALT;
        Check("second Init with another divider accepted",
              (HAL_RTC_Init(&hrtc_dev) == HAL_OK));
        Check("divider overwritten",
              (((hrtc_dev.Instance->CR & RTC_CR_DIV) >> RTC_CR_DIV_Pos) == TEST_RTC_DIVISION_ALT));

        /* ---- Step 9: a NULL handle is refused ----------------------------- */
        Check("HAL_RTC_Init(NULL) rejected", (HAL_RTC_Init(NULL_PTR) == HAL_ERROR));

        /* ---- Step 10: an invalid instance is refused ---------------------- */
        __HAL_CLEAR_STRUCT(&bad_handle);
        bad_handle.Instance = (RTC_TypeDef *)0x40000000U;
        bad_handle.Init = rtc_init;
        Check("HAL_RTC_Init with an invalid instance rejected",
              (HAL_RTC_Init(&bad_handle) == HAL_ERROR));
    /* ---- summary ------------------------------------------------------- */
    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(failures));

    /* Idle: keep the calendar observable on the console */
    while (1)
    {
        Rtc_PrintCalendar("idle");
        delay_ms(TEST_IDLE_MS);
    }
}

/* Private functions --------------------------------------------------------*/
/**
 * @brief  Prepare the RTC handle and its configuration structure.
 * @note   The configuration structure metafields (Size / Version / reserved
 *         words) are mandatory: HAL_RTC_Init() validates them at run time and
 *         rejects a structure that does not carry them.
 * @param  None
 * @retval None
 */
static void Rtc_Handle_Setup(void)
{
    __HAL_CLEAR_STRUCT(&hrtc_dev);
    hrtc_dev.Instance = RTC;

    __HAL_CLEAR_STRUCT(&rtc_init);
    rtc_init.Size     = sizeof(RTC_InitTypeDef);
    rtc_init.Version  = RTC_INIT_VERSION;
    rtc_init.Division = TEST_RTC_DIVISION;
    hrtc_dev.Init     = rtc_init;
}

/**
 * @brief  Read the calendar into the report globals.
 * @param  None
 * @retval HAL status of the read (HAL_ERROR when a read was refused).
 */
static HAL_StatusTypeDef Rtc_GetCalendar(void)
{
    RTC_TimeTypeDef time;
    RTC_DateTypeDef dateS;
    HAL_StatusTypeDef status;

    __HAL_CLEAR_STRUCT(&time);
    __HAL_CLEAR_STRUCT(&dateS);

    status = HAL_RTC_GetTime(&hrtc_dev, &time, RTC_FORMAT_BIN);
    if (status == HAL_OK)
    {
        status = HAL_RTC_GetDate(&hrtc_dev, &dateS, RTC_FORMAT_BIN);
    }
    if (status != HAL_OK)
    {
        return status;
    }

    r_time_hours   = time.RTC_Hours;
    r_time_minutes = time.RTC_Minutes;
    r_time_seconds = time.RTC_Seconds;
    r_time_tos     = time.RTC_TenthOfSecond;

    r_date_century = dateS.RTC_Century;
    r_date_year    = dateS.RTC_Year;
    r_date_month   = dateS.RTC_Month;
    r_date_date    = dateS.RTC_Date;
    r_date_weekday = dateS.RTC_WeekDay;

    return HAL_OK;
}

/**
 * @brief  Translate a month constant to its number (1-12).
 * @param  month: month (RTC_Month_xxx).
 * @retval uint8: month number, or 0 when the value is unknown.
 */
static uint8 Rtc_MonthToNumber(uint8 month)
{
    uint8 result;

    switch (month)
    {
        case RTC_Month_January:   result = 1U;  break;
        case RTC_Month_February:  result = 2U;  break;
        case RTC_Month_March:     result = 3U;  break;
        case RTC_Month_April:     result = 4U;  break;
        case RTC_Month_May:       result = 5U;  break;
        case RTC_Month_June:      result = 6U;  break;
        case RTC_Month_July:      result = 7U;  break;
        case RTC_Month_August:    result = 8U;  break;
        case RTC_Month_September: result = 9U;  break;
        case RTC_Month_October:   result = 10U; break;
        case RTC_Month_November:  result = 11U; break;
        case RTC_Month_December:  result = 12U; break;
        default:                  result = 0U;  break;
    }

    return result;
}

/**
 * @brief  Translate a weekday constant to its name.
 * @param  weekday: weekday (RTC_Weekday_xxx).
 * @retval const char*: weekday name, or "?" when the value is unknown.
 */
static const char *Rtc_WeekdayName(uint8 weekday)
{
    switch (weekday)
    {
        case RTC_Weekday_Monday:    return "Monday";
        case RTC_Weekday_Tuesday:   return "Tuesday";
        case RTC_Weekday_Wednesday: return "Wednesday";
        case RTC_Weekday_Thursday:  return "Thursday";
        case RTC_Weekday_Friday:    return "Friday";
        case RTC_Weekday_Saturday:  return "Saturday";
        case RTC_Weekday_Sunday:    return "Sunday";
        default:                    return "?";
    }
}

/**
 * @brief  Read and print the calendar.
 * @param  tag: text printed in front of the value (may be NULL).
 * @retval None
 */
static void Rtc_PrintCalendar(const char *tag)
{
    if (Rtc_GetCalendar() != HAL_OK)
    {
        printf("%s calendar read refused (state = %u)\r\n",
               ((tag != NULL_PTR) ? tag : ""),
               PRINT_U32(HAL_RTC_GetState(&hrtc_dev)));
        return;
    }

    printf("%s %02u-%02u-%02u %02u:%02u:%02u.%u %s\r\n",
           ((tag != NULL_PTR) ? tag : ""),
           PRINT_U32(r_date_century), PRINT_U32(Rtc_MonthToNumber(r_date_month)),
           PRINT_U32(r_date_date), PRINT_U32(r_time_hours), PRINT_U32(r_time_minutes),
           PRINT_U32(r_time_seconds), PRINT_U32(r_time_tos),
           Rtc_WeekdayName(r_date_weekday));
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition == 0U)
    {
        failures++;
    }
    printf("%-44s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Configure the system clock tree using the HAL SMU driver.
 * @note   Clock tree shared by every integration test suite of this library:
 *         OSC 20 MHz as the PLL source, PLLDivR = 0x04 / PLLDivN = 0x14 /
 *         PLLDivF = 0xB4 / PLLDivQ = 0x01, then AXI4Bus3 = /2, APBBus0 = /2,
 *         APBBus1 = /2 and CANX2 = /8. The bus dividers are written first and
 *         the PLL is switched in afterwards, which is the order the chip
 *         requires (see HAL_SMU_OscConfig()).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;
    HAL_SMU_HandleTypeDef hsmu_clk;

    /* Enable the bus clock gates */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* The RTC lives in the always-on APB-BusS domain: it has no clock gate of
       its own, the module switch of the configuration file is enough. */

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Bus dividers first (the system clock is still the power-on source) */
    __HAL_CLEAR_STRUCT(&SMU_ClockInitStruct);
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;
    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) and switch to it; the
       call also programs the EFLASH controller clock before the switch. */
    __HAL_CLEAR_STRUCT(&SMU_OscInitStruct);
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
