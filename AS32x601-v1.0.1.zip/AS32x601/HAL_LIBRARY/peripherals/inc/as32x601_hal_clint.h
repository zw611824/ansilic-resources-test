/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_clint.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.6
 * Date:   2026/10/09
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.1     expose the shared lock
 *                                                       helpers CLINT_LockHandle /
 *                                                       CLINT_UnlockHandle used by
 *                                                       the source file (RTOS
 *                                                       branch uses the LockMutex
 *                                                       handle)
 *     ANSILIC APPLICATION GROUP  2026/09/07     1.2     add the ErrorCode field,
 *                                                       the HAL_CLINT_ERROR_NONE
 *                                                       constant and the
 *                                                       HAL_CLINT_GetError()
 *                                                       reporting API
 *     ANSILIC APPLICATION GROUP  2026/09/17     1.3     align the resource lock
 *                                                       and the RTOS support with
 *                                                       the architecture
 *                                                       specification (section 13
 *                                                       LOCK-01..06 and section 21
 *                                                       RTOS-04..12): the MSP
 *                                                       callbacks run outside the
 *                                                       locked region (LOCK-06) and
 *                                                       the MSP init runs only on
 *                                                       the first initialization
 *                                                       (MSP-04), the handle lock
 *                                                       takes a Timeout and guards
 *                                                       a NULL mutex (RTOS-11), a
 *                                                       state gate rejects the
 *                                                       calls made on a busy or
 *                                                       non initialized handle
 *                                                       (ARCH-CONST-09), and the
 *                                                       software interrupt pending
 *                                                       bit gets an interrupt safe
 *                                                       clear function so that an
 *                                                       interrupt service routine
 *                                                       never takes the lock
 *                                                       (LOCK-04 / RTOS-12)
 *     ANSILIC APPLICATION GROUP  2026/09/21     1.4     add the system time base
 *                                                       (periodic tick) service:
 *                                                       HAL_CLINT_TimerIntCmd(),
 *                                                       HAL_CLINT_SetTickPeriod(),
 *                                                       HAL_CLINT_IRQHandler() and
 *                                                       the weak
 *                                                       HAL_CLINT_TickCallback();
 *                                                       the comparator write
 *                                                       order becomes
 *                                                       low-half-before-high-half,
 *                                                       aligned with the existing
 *                                                       device write order,
 *                                                       and is centralized in a
 *                                                       single private helper;
 *                                                       HAL_CLINT_DeInit() now
 *                                                       disables the machine timer
 *                                                       interrupt and parks the
 *                                                       comparator (the module is
 *                                                       really reset), the default
 *                                                       MspInit() enables the CLINT
 *                                                       clock gate and releases its
 *                                                       reset through the SMU, and
 *                                                       HAL_CLINT_ERROR_INVALID_PARAM
 *                                                       is added for the period
 *                                                       parameter validation
 *     ANSILIC APPLICATION GROUP  2026/09/21     1.5     describe the comparator write order as the device write
 *                                                       order instead of referring to an external implementation
 *     ANSILIC APPLICATION GROUP  2026/10/09     1.6     re-base the periodic tick on the planned compare
 *                                                       value instead of on the counter read inside the
 *                                                       interrupt handler, so that the effective period
 *                                                       equals the programmed period and the interrupt
 *                                                       latency no longer accumulates from tick to tick;
 *                                                       add the CompareValue software mirror to the handle
 *                                                       together with HAL_CLINT_GetTimerComparator(); advance
 *                                                       a planned instant that the counter already passed by
 *                                                       whole periods (late tick guard); forget the mirror on
 *                                                       initialization and de-initialization
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Core-Local Interruptor
 *                  (CLINT), as a HAL peripheral driver of this library:
 *                  - Initialization and de-initialization: HAL_CLINT_Init /
 *                    HAL_CLINT_DeInit;
 *                  - Peripheral control: machine software interrupt
 *                    generation, 64-bit timer comparator programming and
 *                    64-bit real-time counter read-back;
 *                  - System time base: machine timer interrupt enable and
 *                    disable, periodic tick programming with reload, and the
 *                    interrupt entry with its user callback.
 *                  The CLINT of the AS32x601 implements the standard
 *                  RISC-V core-local interruptor: a per-hart software
 *                  interrupt pending register (MSIP), a 64-bit machine
 *                  timer comparator (mtimecmp) and a free-running 64-bit
 *                  machine timer counter (mtime).  The machine timer
 *                  interrupt (MTI) raised by the comparator is the interrupt
 *                  source of the HAL system time base: this driver provides
 *                  the whole service (enable / disable through the standard
 *                  mie.MTIE bit, periodic tick programming with reload, the
 *                  interrupt entry and the weak user callback).
 *                  The HAL common layer does NOT use the CLINT by default:
 *                  its 1 ms time base is derived from the CPU mcycle counter
 *                  by polling and never accesses the CLINT (see
 *                  as32x601_hal.c).  Both time bases may therefore not be
 *                  active at the same time - the application must keep a
 *                  single tick owner (see the HAL_CLINT_TickCallback()
 *                  documentation for the switch recipe).
 * @complexity  Medium
 *              State machine + lock, register primitives, plus the system
 *              time base service (interrupt mode with its own callback).
 */
#ifndef __AS32X601_HAL_CLINT_H
#define __AS32X601_HAL_CLINT_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "as32x601.h"               /* CLINT_TypeDef, CLINT register bits    */
#include "as32x601_hal_def.h"       /* HAL_StatusTypeDef, HAL_LockTypeDef    */

/**
 * @brief CLINT HAL driver module version.
 * @note  0x0100U = V1.0. Bumped only on breaking API changes (architecture
 *        spec COMPAT-13/14/15).
 */
#define __HAL_CLINT_MODULE_VERSION  0x0100U

/* Exported types ------------------------------------------------------------*/

/** @defgroup CLINT_Exported_Types CLINT Exported Types
  * @{
  */

/**
 * @brief HAL CLINT state structures definition.
 */
typedef enum
{
    HAL_CLINT_STATE_RESET  = 0x00U, /*!< Peripheral not initialized            */
    HAL_CLINT_STATE_READY  = 0x01U, /*!< Peripheral initialized and ready      */
    HAL_CLINT_STATE_BUSY   = 0x02U, /*!< An internal process is ongoing        */
    HAL_CLINT_STATE_ERROR  = 0x03U  /*!< Error state                           */
} HAL_CLINT_StateTypeDef;

/**
 * @brief CLINT handle structure definition.
 * @note  The CLINT is a core-local peripheral: the instance is always the
 *        device-level CLINT pointer.
 * @note  Field order follows the architecture spec HANDLE-02
 *        (Instance -> Init -> Lock -> State -> ErrorCode -> module fields).
 *        The CLINT has no configuration structure (the driver takes no
 *        initialization parameters), so the Init field of the template is
 *        absent and the handle starts at the lock.
 */
typedef struct __HAL_CLINT_HandleTypeDef
{
    CLINT_TypeDef            *Instance;   /*!< CLINT registers base address     */
    HAL_LockTypeDef          Lock;        /*!< Locking object                   */
    __IO HAL_CLINT_StateTypeDef State;    /*!< CLINT communication state        */
    __IO uint32              ErrorCode;   /*!< CLINT error code                 */
    __IO uint64              CompareValue;/*!< Software mirror of the compare value
                                               that this handle programmed last
                                               (0 = nothing programmed yet).  The
                                               comparator registers are write
                                               only, so the mirror is the only
                                               record of the planned instant: the
                                               periodic reload advances THIS value
                                               by the tick period, so the effective
                                               period does not accumulate the
                                               interrupt latency.             */
    __IO uint32              TickPeriod;  /*!< System time base period, in mtime
                                               ticks (0 = not programmed).  It is
                                               stored by
                                               HAL_CLINT_SetTickPeriod() and used
                                               by HAL_CLINT_IRQHandler() to reload
                                               the comparator after every tick. */
#if (USE_RTOS == 1)
    HAL_MutexTypeDef         LockMutex;   /*!< RTOS mutex handle (created by the
                                               user porting layer, e.g. in
                                               HAL_CLINT_MspInit)              */
#endif /* USE_RTOS */
} HAL_CLINT_HandleTypeDef;

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @defgroup CLINT_Exported_Constants CLINT Exported Constants
  * @{
  */

/** @defgroup CLINT_Error_Code CLINT Error Code
  * @{
  */
#define HAL_CLINT_ERROR_NONE        ((uint32)0x00000000U) /*!< No error          */
#define HAL_CLINT_ERROR_INVALID_PARAM ((uint32)0x00000001U) /*!< Invalid parameter
                                                                 (e.g. a zero tick
                                                                 period)         */
/**
  * @}
  */

/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/

/** @addtogroup CLINT_Exported_Functions
  * @{
  */

/** @addtogroup CLINT_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Initializes the CLINT peripheral. (NON-BLOCKING)
 * @note   The CLINT clock gating is enabled by the default
 *         HAL_CLINT_MspInit() implementation through the SMU ALB0 clock
 *         configuration register; an override that does its own clock gating
 *         (when the SMU driver is not used) replaces it.
 * @note   The low level initialization callback runs only on the first call
 *         (while the handle is in the reset state) and before the handle is
 *         locked (architecture rules MSP-04 and LOCK-06), so an override may
 *         create an RTOS mutex and call other HAL APIs.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_CLINT_Init(HAL_CLINT_HandleTypeDef *hclint);

/**
 * @brief  De-initializes the CLINT peripheral. (NON-BLOCKING)
 * @note   The module is really reset: the machine timer interrupt is disabled
 *         in the mie CSR bit and the comparator is parked at the maximum
 *         value (0xFFFFFFFFFFFFFFFF), so a machine timer interrupt that was
 *         enabled by the application can no longer fire on the stale period
 *         after this call; the programmed tick period and the compare value
 *         mirror are forgotten (HAL_CLINT_GetTimerComparator() reads 0 again)
 *         and the software interrupt pending bit is cleared.
 * @note   The low level de-initialization callback runs after the handle lock
 *         has been released (architecture rule LOCK-06), so an override may
 *         call other HAL APIs.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_CLINT_DeInit(HAL_CLINT_HandleTypeDef *hclint);

/**
 * @brief  Initializes the CLINT MSP. Weak function; the default
 *         implementation enables the CLINT clock gate and releases its reset
 *         through the SMU ALB0 clock configuration register.
 * @note   The reset bit of the SMU_ALB0CFGR register is released by SETTING
 *         it (SET = released, CLEAR = reset asserted), which is also what the
 *         register reset value (every RST bit set) and
 *         __HAL_SMU_CLINT_RELEASE_RESET() assume.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval None
 */
void HAL_CLINT_MspInit(HAL_CLINT_HandleTypeDef *hclint);

/**
 * @brief  De-initializes the CLINT MSP. Weak empty function; the user
 *         implements the low level hardware de-initialization.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval None
 */
void HAL_CLINT_MspDeInit(HAL_CLINT_HandleTypeDef *hclint);

/**
  * @}
  */

/** @addtogroup CLINT_Exported_Functions_Group2 Peripheral Control functions
  * @{
  */

/**
 * @brief  Enables or disables the machine software interrupt pending bit.
 * @note   Setting the software interrupt pending bit raises the machine
 *         software interrupt (MSI) when enabled in the mstatus/mie
 *         registers.
 * @note   The register access is protected by the handle lock and gated by
 *         the handle state, hence this function shall be called from the
 *         task / main context only: an interrupt service routine shall use
 *         HAL_CLINT_ClearSoftInt() instead, as the architecture specification
 *         forbids taking a lock from an ISR (rules LOCK-04 and RTOS-12).
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @param  NewState: ENABLE = raise the software interrupt, DISABLE = clear it.
 * @retval None
 */
void HAL_CLINT_SoftIntCmd(HAL_CLINT_HandleTypeDef *hclint, FunctionalState NewState);

/**
 * @brief  Clears the machine software interrupt pending bit.
 * @note   This is the interrupt safe counterpart of HAL_CLINT_SoftIntCmd():
 *         it neither takes the handle lock nor checks the handle state, so it
 *         may be called from an interrupt service routine (e.g. from the
 *         MSI handler to acknowledge the request), as required by rules
 *         LOCK-04 and RTOS-12.  The handle pointer is still checked for NULL.
 * @note   It is not thread safe with respect to HAL_CLINT_SoftIntCmd(): a
 *         caller that races a task context request against this clear gets
 *         either the request or the clear, whichever register access wins
 *         last.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval None
 */
void HAL_CLINT_ClearSoftInt(HAL_CLINT_HandleTypeDef *hclint);

/**
 * @brief  Programs the 64-bit machine timer comparator (mtimecmp).
 *         (NON-BLOCKING)
 * @note   The comparator registers are write-only in the device definition, so
 *         they can never be read back; the handle keeps a software mirror of
 *         the value programmed here, which
 *         HAL_CLINT_GetTimerComparator() returns.  Read the free-running
 *         counter with HAL_CLINT_ReadTimerValue() when the elapsed time has
 *         to be measured.
 * @note   The mirror is also the base the periodic reload advances: while the
 *         tick service of HAL_CLINT_SetTickPeriod() is running, the value seen
 *         by HAL_CLINT_GetTimerComparator() is the instant planned next, and a
 *         call to this function re-bases that sequence on the value written
 *         here.  Do not mix the two while the machine timer interrupt is
 *         enabled (see the note below).
 * @note   The current implementation writes the low half before the high
 *         half, which is the write order of the device.  The AS32x601 write
 *         order and commit semantics are still to be confirmed from the chip
 *         datasheet or RTL, and the order is confined to one private helper so
 *         that a confirmation only has to be applied in that single place.  It
 *         is not claimed here as a generic RISC-V CLINT rule.
 * @note   The comparator is not used by the default HAL time base, which is
 *         derived from the CPU mcycle counter and never accesses the CLINT
 *         (see as32x601_hal.c).  If the application switches the time base to
 *         the machine timer interrupt through HAL_CLINT_SetTickPeriod() and
 *         HAL_CLINT_TimerIntCmd(), the comparator belongs to that path and is
 *         reloaded by HAL_CLINT_IRQHandler() after every tick:
 *         HAL_CLINT_SetTimerComparator() must then not be called concurrently
 *         with that handler.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @param  CompareValue: 64-bit compare value.
 * @retval None
 */
void HAL_CLINT_SetTimerComparator(HAL_CLINT_HandleTypeDef *hclint, uint64 CompareValue);

/**
 * @brief  Returns the compare value that was programmed through this handle
 *         last. (NON-BLOCKING)
 * @note   Read only and lock free.  The comparator registers are write only, so
 *         this API never reads them back: it returns the software mirror that
 *         HAL_CLINT_SetTimerComparator(), HAL_CLINT_SetTickPeriod() and the
 *         periodic reload path of HAL_CLINT_IRQHandler() maintain.  The value
 *         is therefore not a hardware read-back and proves nothing about a
 *         hardware atomic commit.
 * @note   While the periodic tick runs, the machine timer interrupt advances
 *         the mirror, so the value observed here is the instant that the
 *         handler is about to program, not the hardware content.  On this
 *         32-bit core the mirror is a 64-bit object that interrupt context may
 *         update, so the API is meant for diagnostics and for a time base that
 *         is stopped; it is not a substitute for
 *         HAL_CLINT_ReadTimerValue() when an exact elapsed time has to be
 *         measured.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval uint64: the mirror value; 0 when nothing was programmed yet, and 0
 *         when the handle is NULL or Instance is not the accepted CLINT
 *         instance (no register is read in that case).
 */
uint64 HAL_CLINT_GetTimerComparator(HAL_CLINT_HandleTypeDef *hclint);

/**
 * @brief  Returns the 64-bit machine timer counter (mtime) value.
 *         (NON-BLOCKING)
 * @note   On RV32 the high part is read twice and checked to detect a wrap
 *         of the low part between the two reads (standard RISC-V CLINT
 *         reading rule), so a consistent 64-bit snapshot is returned.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval uint64: the current mtime value.
 */
uint64 HAL_CLINT_ReadTimerValue(HAL_CLINT_HandleTypeDef *hclint);

/**
 * @brief  Returns the CLINT handle state.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval HAL_CLINT_StateTypeDef: the current handle state.
 */
HAL_CLINT_StateTypeDef HAL_CLINT_GetState(HAL_CLINT_HandleTypeDef *hclint);

/**
 * @brief  Returns the CLINT error code.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval uint32: the CLINT error code (HAL_CLINT_ERROR_xxx).
 */
uint32 HAL_CLINT_GetError(HAL_CLINT_HandleTypeDef *hclint);

/**
  * @}
  */

/** @addtogroup CLINT_Exported_Functions_Group3 System time base (periodic tick) functions
  * @{
  */

/**
 * @brief  Enables or disables the machine timer interrupt (MTI). (NON-BLOCKING)
 * @note   This is the periodic tick interrupt source of the system time base.
 *         Enabling it means: "when the real-time counter reaches the
 *         comparator value, the machine timer interrupt is taken".  Disabling
 *         it stops the interrupt without touching the comparator, so the
 *         programmed period is kept and a later enable resumes it.
 * @note   The interrupt enable bit is the standard mie.MTIE bit of the CPU
 *         (the device provides no interrupt enable register of its own), so
 *         the kernel interrupt-enable register is updated through the core
 *         macros.  The machine timer interrupt is also gated by the global
 *         interrupt enable mstatus.MIE, which is configured by the startup
 *         code and not by this driver.
 * @note   On ENABLE, when a tick period has already been programmed with
 *         HAL_CLINT_SetTickPeriod(), the comparator is re-armed before the
 *         interrupt is enabled: from the instant that was planned last, or from
 *         the current counter value when nothing was planned yet, and an
 *         instant the counter has already passed is advanced by whole periods
 *         until it lies in the future.  A stale comparator from an earlier run
 *         therefore cannot fire immediately.
 * @note   Program the period (or the comparator) BEFORE enabling: with a
 *         comparator that is already reached by the free-running counter the
 *         interrupt is asserted continuously.
 * @note   The access is protected by the handle lock and gated by the handle
 *         state, hence it shall be called from the task / main context only
 *         (architecture rules LOCK-04 and RTOS-12 forbid taking a lock from
 *         an interrupt service routine).
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @param  NewState: ENABLE = let the comparator raise the machine timer
 *         interrupt, DISABLE = mask the machine timer interrupt.
 * @retval None
 */
void HAL_CLINT_TimerIntCmd(HAL_CLINT_HandleTypeDef *hclint, FunctionalState NewState);

/**
 * @brief  Programs the system time base period and arms the first tick.
 *         (NON-BLOCKING)
 * @note   The period is expressed in machine timer counter (mtime) ticks, so
 *         a 1 ms period is "mtime frequency / 1000" and a 1 s period is the
 *         mtime frequency.  The mtime frequency has to be read from the chip
 *         datasheet for the configured clock tree.
 * @note   The function stores the period in the handle and arms the
 *         comparator at "counter + period", so the first tick is one full
 *         period away.  Every following tick is produced by
 *         HAL_CLINT_IRQHandler(), which advances the instant that was planned
 *         last by the period: the reload is based on the planned instant and
 *         not on the counter read inside the handler, so the effective period
 *         stays equal to the programmed period and the interrupt latency does
 *         not accumulate from tick to tick.
 * @note   An instant that the counter has already passed (a handler that ran
 *         longer than one period) is advanced by whole periods until it lies
 *         strictly in the future, which releases the counter >= compare
 *         condition and prevents an endless interrupt loop.
 * @note   The period must be long enough for the handler to run and to be
 *         left before the counter passes the newly programmed comparator;
 *         an extremely small period queues the interrupt immediately again.
 * @note   This function only programs the period: use HAL_CLINT_TimerIntCmd()
 *         to actually let the machine timer interrupt be taken.  Calling it
 *         again while the interrupt is enabled re-bases the periodic sequence
 *         on "counter + period" and continues from there.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @param  Period: tick period, in mtime ticks (must not be zero).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (invalid parameter or handle)
 *         / HAL_BUSY (another operation is ongoing).
 */
HAL_StatusTypeDef HAL_CLINT_SetTickPeriod(HAL_CLINT_HandleTypeDef *hclint, uint32 Period);

/**
 * @brief  Machine timer interrupt entry of the system time base.
 *         (NON-BLOCKING)
 * @note   Call this function from the machine timer interrupt handler of the
 *         trap entry (the weak MTimer_IRQ_Handler() symbol), which is the
 *         trampoline the trap entry dispatches for mcause = 7:
 *         @code
 *         void MTimer_IRQ_Handler(void)
 *         {
 *             HAL_CLINT_IRQHandler(&hclint);
 *         }
 *         @endcode
 * @note   The handler first reloads the comparator with the instant that was
 *         planned last advanced by the programmed tick period (the interrupt
 *         is answered by arming the next tick before the callback runs, so the
 *         callback duration does not accumulate into the period, and the
 *         reload uses the planned instant rather than the counter, so the
 *         interrupt latency does not accumulate either).  The programmed
 *         instant is reported by HAL_CLINT_GetTimerComparator().  When no
 *         period has been programmed the comparator is left untouched and only
 *         the callback runs, so an application that owns the comparator
 *         manually stays in control.
 * @note   It does NOT take the handle lock and does NOT check the handle
 *         state (only the handle pointer and the instance are checked), so it
 *         may be called from an interrupt service routine without violating
 *         rules LOCK-04 and RTOS-12.
 * @note   The callback runs in interrupt context: no blocking operation shall
 *         be executed there.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval None
 */
void HAL_CLINT_IRQHandler(HAL_CLINT_HandleTypeDef *hclint);

/**
 * @brief  System time base tick callback. Weak empty function; the user
 *         implements the task to be executed on every tick.
 * @note   Called by HAL_CLINT_IRQHandler() after the next tick has been
 *         armed.  It runs in interrupt context.
 * @note   SINGLE TICK OWNER (architecture rule on the time base): the HAL
 *         common layer builds its default time base from the CPU mcycle
 *         counter by polling and never uses the CLINT, so only one of the two
 *         may feed the tick at a time.
 *         - To move the tick to the CLINT machine timer interrupt, override
 *           HAL_InitTick() (and, when the application needs HAL_GetTick() /
 *           HAL_Delay() to follow the interrupt, HAL_GetTick() /
 *           HAL_IncTick() as well), call HAL_CLINT_SetTickPeriod() and then
 *           HAL_CLINT_TimerIntCmd(ENABLE), and increment the application tick
 *           from THIS callback.
 *         - Do NOT call HAL_IncTick() from this callback while the default
 *           mcycle-derived tick of as32x601_hal.c is active: HAL_IncTick()
 *           already settles the elapsed mcycle time and then adds one, so
 *           mixing both feeds would count every tick twice.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval None
 */
void HAL_CLINT_TickCallback(HAL_CLINT_HandleTypeDef *hclint);

/**
  * @}
  */

/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/

/** @defgroup CLINT_Private_Macros CLINT Private Macros
  * @{
  */

/**
 * @brief  Check that the CLINT peripheral instance is valid.
 */
#define IS_CLINT_ALL_PERIPH(PERIPH) ((PERIPH) == CLINT)

/**
  * @}
  */

/* Shared internal functions --------------------------------------------------*/

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_CLINT_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the acquisition is bounded by the Timeout parameter (RTOS
 *         ticks, which with the usual 1 ms tick is the same quantity as the
 *         millisecond Timeout of the public API); HAL_MAX_DELAY waits forever.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS, wait expired) /
 *         HAL_ERROR (RTOS, mutex not created) / HAL_BUSY (bare metal, the
 *         handle is already locked).
 */
HAL_StatusTypeDef CLINT_LockHandle(HAL_CLINT_HandleTypeDef *hclint, uint32 Timeout);

/**
 * @brief  Unlock the handle.
 * @param  hclint: pointer to a HAL_CLINT_HandleTypeDef structure.
 * @retval None
 */
void CLINT_UnlockHandle(HAL_CLINT_HandleTypeDef *hclint);

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_CLINT_H */

/*****END OF FILE*****/
