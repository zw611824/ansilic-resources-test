# EFLASH 应用与测试参考

供 skill 按需求检索 AS32x601 HAL 片内 Flash（EFLASH）示例。别名/关键词：EFLASH、P-Flash、D-Flash、扇区擦除、块擦除、编程、读回、写保护、读保护、ECC、Flash 完成中断。共有 6 个独立用例。

HAL 依据：[头文件](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_flash.h)、[实现](../../HAL_LIBRARY/peripherals/src/as32x601_hal_flash.c)。原测试工程的 4_HAL_LIBRARY 未提供，尚不能确认原始链接版本；文中标出的源码与当前 SDK 差异须先解决再迁移。


## 实例与相关资源

本模块不单独列出外部通信引脚组。按实际功能核对实例、时钟、中断、内存或数据通路；关联 GPIO、定时器或其他外设时，再读取对应分支的引脚资料。具体资源与案例配置见下文。

## 生成前需确认的参数

已有工程、板级资料或用户已明确的值直接复用。仅对影响本次实现的缺失选择使用参数卡询问并等待答复；案例配置不能代替实际接线或应用参数。

| 参数 | 需要核对或确认的内容 |
|---|---|
| 操作范围 | 实际 Flash 地址、长度、页/扇区及用途 |
| 数据保护 | 当前代码和保留区边界、擦写授权及已有数据保持需求 |

## 按需求选择

| 用户需求 / 检索关键词 | 推荐用例 | 选择条件 / 需要补充的逻辑 |
|---|---|---|
| 擦除扇区、编程 512 字节、读回校验 | [001](EFLASH_IT_DRV_001.c) | 最小可复用模板，P-Flash 与 D-Flash 各一遍。示例地址 `0x01100000` / `0x02000000` 是测试专用扇区，应用必须换成自己的参数区并确认不覆盖运行镜像 |
| P-Flash 写保护（区域、状态回读、写保护错误） | [002](EFLASH_IT_DRV_002.c) | 用 `FLASH_WP_AREA32`；P-Flash 支持区域 1–32。错误路径为 `HAL_FLASH_ERROR_WRP` + `FLASH_FLAG_WPERR` |
| D-Flash 写保护 | [003](EFLASH_IT_DRV_003.c) | 用 `FLASH_WP_AREA2`；D-Flash 只支持区域 1–8，不能照搬 P-Flash 的区域号 |
| 整块擦除、擦除完成中断、安全/ECC 状态查询 | [004](EFLASH_IT_DRV_004.c) | 默认受限流程只做块擦除、编程和状态查询。文件中的完整读保护流程由 `TEST_RUN_FULL_READ_PROTECTION=1` 显式打开，**会擦除运行镜像并可能锁死芯片**，不能当普通模板 |
| 参数合法性、行边界拆分、句柄状态门控等完整 API 自检 | [005](EFLASH_IT_DRV_005.c) | 防御性/边界自检，不是应用模板；包含跨行测试，实际拆分语义与 SDK 有差异，见下文 |
| 标志位、中断使能/清除、错误码 | [006](EFLASH_IT_DRV_006.c) | 完成中断经 PLIC 路由；应用需实现 `EFLASH_IRQ_Handler()` 并在入口清挂起、关中断源 |
| 掉电安全写入、双区升级、CRC 校验 | 无直接完整模板 | 需在 001 的擦/写/读回基础上自行设计备份区、版本头和校验；示例只做 512 字节单次读写 |

## 实现要点与案例配置

- 初始化顺序：`HAL_Init()` → 系统时钟（示例 PLL 180 MHz，AXI_Bus0 180 MHz）→ `delay_init()` / 串口 → `__HAL_CLEAR_STRUCT(&hflash_dev)`、`Instance = EFLASH` → `HAL_FLASH_StructInit(&hflash_dev.Init)` → `hflash_dev.Init.ClockFreq = SystemCoreClock / 1000000` → `HAL_FLASH_Init()` → `HAL_FLASH_Unlock()`。擦/写完成后 `HAL_FLASH_Lock()`，再 `HAL_FLASH_DeInit()`。
- Program 的地址需 8 字节对齐，Size 非零且为 8 的倍数；Read 的地址/长度按 4 字节对齐，Size 单位均为字节。SDK 按 ROM 命令容量（512 字节）分段，API 总长度不限于 512 字节；DLR 单位为 8 字节。擦除类型、地址、Length 和 AddrError 按接口与源码核对。
- 地址与容量：P-Flash 块 `0x01000000`、D-Flash 块 `0x02000000`；扇区 4 KB、块 512 KB；D-Flash 信息区 `0x02080000` 不可编程；P-Flash 信息扇区示例取 `0x01201000`。这些是测试地址，应用必须按链接脚本和参数区规划重新确认。
- 写保护极性：保护寄存器为 0 表示受保护、1 表示可写（复位值 `0xFFFFFFFF`），因此 `HAL_FLASH_GetPFlashWriteProtStatus()` / `HAL_FLASH_GetDFlashWriteProtStatus()` 在“受保护”时返回 `FLASH_FLAG_RESET`，移除保护后返回 `FLASH_FLAG_SET`。不要按“置位=保护”理解。
- 中断链：HAL FLASH 驱动是轮询式，没有内部分发器；应用覆写 PLIC 的弱入口 `EFLASH_IRQ_Handler()`。示例在入口读 `FLASH_FLAG_FINISH`、用 `HAL_FLASH_ClearITPendingBit(FLASH_CLEAR_IT_FINISH)` 清挂起，并无条件清除 `OPERR/ECC2ERR`、关闭 `FLASH_IT_FINIE`，防止电平中断把核困在 ISR。PLIC 侧先 `HAL_PLIC_Init()` 再使能源（示例优先级 1）。
- 证据边界：擦除后读回 `0xFFFFFFFF`、编程后逐字比较，能证明当前驱动与目标器件的擦写通路；写保护用例能证明保护生效与 `WPERR` 锁存；ECC/安全查询只证明寄存器可读且查询无副作用，不能证明真实 ECC 事件或读保护强度。掉电保持、耐久性和数据完整性需额外老化/断电测试，本次未做。

## 验证方法与适用边界

- 示例会**真实擦写片内 Flash**。运行前必须确认测试地址不在运行镜像、配置区或链接脚本保留区内；004 的完整读保护流程会擦除 P-Flash 块 0，只能从 QSPI 等非被擦除镜像运行。
- 写保护必须先解锁控制器再操作；写保护区域号在 P-Flash 与 D-Flash 上范围不同（1–32 / 1–8），越界会被参数检查拒绝。
- 005 描述跨 512 字节物理行拆分，但 SDK Program 只按剩余长度与 ROM 容量分段，未按起始地址的行内偏移切段。该跨行语义尚未确认兼容，取得工程 HAL 前不能据此生成任意跨行写入代码。分段请求也不保证原子完成，失败后需回读确认。
- `SECKEYERR` 是仅复位清除的锁存位；一旦触发，后续命令都会报错。006 特意不制造该错误，调试时也不要随意试探安全密钥。
- 示例为一次性观察而清旗并关闭源；持续中断应用按事件语义确认和重装，不能泛化为每次 ISR 都必须永久关闭中断。
- 句柄状态门控：未初始化/参数被拒时操作返回错误且不触碰控制器；被拒后句柄仍为 READY，但不要依赖失败调用的副作用。
- Flash 操作期间取指可能停顿；示例的时钟与等待周期按 180 MHz 配置，换频后必须重新设置 `ClockFreq`。

## 按接口与辅助宏检索

| 接口 / 宏 | 参考用例 |
|---|---|
| `HAL_FLASH_StructInit` / `HAL_FLASH_Init` / `HAL_FLASH_DeInit` | [001](EFLASH_IT_DRV_001.c)、[005](EFLASH_IT_DRV_005.c) |
| `HAL_FLASH_Unlock` / `HAL_FLASH_Lock` | [001](EFLASH_IT_DRV_001.c)、[006](EFLASH_IT_DRV_006.c) |
| `HAL_FLASH_Erase` | [001](EFLASH_IT_DRV_001.c)、[004](EFLASH_IT_DRV_004.c)、[005](EFLASH_IT_DRV_005.c) |
| `HAL_FLASH_Program` / `HAL_FLASH_Read` | [001](EFLASH_IT_DRV_001.c)、[005](EFLASH_IT_DRV_005.c) |
| `HAL_FLASH_SetPFlashWriteProtection` / `HAL_FLASH_ResetPFlashWriteProtection` / `HAL_FLASH_GetPFlashWriteProtStatus` | [002](EFLASH_IT_DRV_002.c) |
| `HAL_FLASH_SetDFlashWriteProtection` / `HAL_FLASH_ResetDFlashWriteProtection` / `HAL_FLASH_GetDFlashWriteProtStatus` | [003](EFLASH_IT_DRV_003.c) |
| `HAL_FLASH_ITConfig` / `HAL_FLASH_ClearITPendingBit` | [004](EFLASH_IT_DRV_004.c)、[006](EFLASH_IT_DRV_006.c) |
| `HAL_FLASH_GetFlagStatus` / `HAL_FLASH_ClearFlagStatus` | [001](EFLASH_IT_DRV_001.c)、[006](EFLASH_IT_DRV_006.c) |
| `HAL_FLASH_GetSECFlagStatus` / `HAL_FLASH_InputSECKEY` | [004](EFLASH_IT_DRV_004.c) |
| `HAL_FLASH_GetECCErrorAddress` / `HAL_FLASH_ClearECCErrorAddress` | [004](EFLASH_IT_DRV_004.c) |
| `HAL_FLASH_SetClockFrequency` | [005](EFLASH_IT_DRV_005.c) |

本次为源码静态整理，未重新编译、未上板；源码里的历史测试注释不代表本次验证结果。
