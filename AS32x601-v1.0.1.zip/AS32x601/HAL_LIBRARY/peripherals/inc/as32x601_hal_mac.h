/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):    Xiamen Guoke Anxin Technology Co., LTD
 * FileName:         as32x601_hal_mac.h
 * Author:           ANSILIC APPLICATION GROUP
 * Version:          V1.4
 * Date:             2026/09/20
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/09/07     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/07     1.1     align with the library
 *                                                       conventions: module
 *                                                       version macro, shared
 *                                                       lock helpers
 *                                                       (MAC_LockHandle /
 *                                                       MAC_UnlockHandle, RTOS
 *                                                       branch uses the
 *                                                       LockMutex handle),
 *                                                       NULL guards on every
 *                                                       public function,
 *                                                       Version+Size init
 *                                                       structure, error code
 *                                                       field + HAL_MAC_GetError(),
 *                                                       standard uint32 types
 *                                                       and guard macro
 *     ANSILIC APPLICATION GROUP  2026/09/11     1.2     fix the MAC reset pulse order in
 *                                                       HAL_MAC_DeInit (assert by clearing the
 *                                                       bit, then release by setting it)
 *     ANSILIC APPLICATION GROUP  2026/09/17     1.3     remove the local functional-state check macro
 *                                                       (the check is now provided by
 *                                                       IS_FUNCTIONAL_STATE in as32x601_hal_def.h)
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.4     elevate the module to the Medium level of
 *                                                       the architecture specification: add the run
 *                                                       time validity and state helpers, give the lock
 *                                                       helper a Timeout parameter and a NULL mutex
 *                                                       guard, take the lock and clear the error code
 *                                                       in every register writing entry point, apply
 *                                                       the busy / reset state gate, run the MSP
 *                                                       callbacks outside the locked region, yield the
 *                                                       CPU in the blocking polling loops, report a
 *                                                       timeout through the timeout error code, remove
 *                                                       the reference to an external implementation
 *                                                       and align the version of the two module files
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Ethernet MAC (Media
 *                  Access Control) peripheral:
 *                  - Initialization (HAL_MAC_Init): software reset, DMA
 *                    bus-mode (BUS_MODE), operation-mode (OPT_MODE) and
 *                    general-timer / interrupt-suppression (TIMER_CTRL)
 *                    configuration;
 *                  - IO operation functions: HAL_MAC_TransmitFrame() /
 *                    HAL_MAC_GetReceivedFrame() drive the chip
 *                    descriptor-less transmit/receive model, plus
 *                    HAL_MAC_Start() / HAL_MAC_Stop() and the per-direction
 *                    HAL_MAC_ReceiveCmd() / HAL_MAC_TransmitCmd() start /
 *                    stop commands;
 *                  - Interrupt / flag management: HAL_MAC_ITConfig() /
 *                    HAL_MAC_GetFlagStatus() / HAL_MAC_ClearITStatus() and
 *                    the __HAL_MAC_* macros, plus HAL_MAC_IRQHandler() with
 *                    the HAL_MAC_TxCpltCallback() / HAL_MAC_RxCpltCallback()
 *                    / HAL_MAC_ErrorCallback() callbacks;
 *                  - MDIO management: HAL_MAC_MDIOClockCmd() /
 *                    HAL_MAC_SetMDCPrescaler() and the PHY register access
 *                    HAL_MAC_ReadPHYRegister() / HAL_MAC_WritePHYRegister().
 *                  This driver depends on as32x601_hal_def.h (HAL common
 *                  types and utilities) and on the device layer header
 *                  as32x601.h, which carries the MAC register descriptor.
 *                  Hardware shape: the chip MAC is a reduced 10/100M MAC
 *                  without MAC address filter registers (no MACADDRx /
 *                  MACHTHR / MACHTLR), no frame
 *                  filter register (MACFFR), no flow-control (MACFCR), no
 *                  VLAN, no PTP / timestamp and no MMC counters (only a
 *                  single FRAME_CNT statistic register). Frame filtering is
 *                  limited to the OPT_MODE PR (promiscuous) / PM (pass all
 *                  multicast) / PB (pass bad frame) / RA (receive all) bits
 *                  and must be completed by software. The chip DMA uses a
 *                  simple one-descriptor-per-frame model (mac_tx_descriptor_t
 *                  / mac_rx_descriptor_t) instead of a chained descriptor
 *                  table. The MAC is mapped on
 *                  the APBBus0 domain (MAC_BASE = 0x50000000) and its clock
 *                  is gated by the SMU APB0CFGR register: HAL_MAC_MspInit()
 *                  is provided as an empty weak function where the user
 *                  enables the clock and the MAC reset and enables the PLIC
 *                  line (MAC_IRQn = 0x18).
 * @complexity  Medium
 *              Handle with lock / state / error code, one-descriptor-per-frame
 *              polling model, interrupt flag / handler support. Two blocking
 *              waits exist (the software reset wait of HAL_MAC_Init() and the
 *              MDIO ACK poll of the PHY register access functions), so the
 *              module reaches the "operation with a time cost" level.
 */
#ifndef __AS32X601_HAL_MAC_H
#define __AS32X601_HAL_MAC_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "as32x601.h"               /* MAC_TypeDef, MAC, register bits         */
#include "as32x601_hal_def.h"       /* HAL_StatusTypeDef, HAL_LockTypeDef      */

/* Exported constants --------------------------------------------------------*/

/**
 * @brief MAC HAL driver module version.
 * @note  0x0100U = V1.0. Bumped only on breaking API changes (architecture
 *        spec COMPAT-13/14/15).
 */
#define __HAL_MAC_MODULE_VERSION  0x0100U

/* Exported types ------------------------------------------------------------*/

/** @defgroup MAC_Exported_Types MAC Exported Types
  * @{
  */

/**
 * @brief  MAC Init Structure definition
 * @note   The field names (MAC_AutoPollInterval, MAC_TransmitMode, ...) and
 *         the default values follow the register field description of the
 *         device, so that existing driver code can be
 *         used without change. The MAC_PhyAddress field is a
 *         driver-added extension: the PHY address is held by the Init
 *         structure rather than passed per call, and the PHY register access
 *         functions use it internally.
 * @note   This structure follows the Version+Size compatibility mechanism
 *         (architecture spec section 22): the user must clear the structure
 *         (__HAL_CLEAR_STRUCT / memset), set the Size and Version metafields
 *         before filling the business fields (see HAL_MAC_StructInit()).
 */
typedef struct
{
    uint32 Size;                              /*!< sizeof(MAC_InitTypeDef), must be set by the user
                                                   after clearing the structure              */
    uint32 Version;                           /*!< Structure semantic version: @ref MAC_INIT_VERSION
                                                   (MAC_INIT_V1 = 0x0100U)                  */
    uint32 MAC_AutoPollInterval;   /*!< Transmit auto poll interval
                                                  (BUS_MODE.TAP[2:0]) */
    uint32 MAC_DescriptorByteEndianMode;   /*!< Descriptor byte sort mode (BUS_MODE.DBO)
                                                         */
    uint32 MAC_ProgrammablePulseLength;   /*!< Programmable pulse length
                                                  (BUS_MODE.PBL[5:0])     */
    uint32 MAC_DataEndianMode;   /*!< Data endian mode (BUS_MODE.BLE)
                                                          */
    uint32 MAC_DescriptorSkipLength;   /*!< Descriptor skip length (BUS_MODE.DSL[4:0])
                                                         */
    uint32 MAC_BusArbitrationScheme;   /*!< Bus Arbitration scheme (BUS_MODE.BAR)
                                                          */

    uint32 MAC_ReceiveAll;   /*!< Receives all incoming frames (OPT_MODE.RA)
                                                   */
    uint32 MAC_TransmitThresholdMode;   /*!< Transmit Threshold Mode (OPT_MODE.TTM)
                                                    */
    uint32 MAC_StoreandForward;   /*!< Store and forward (OPT_MODE.SF)
                                                    */
    uint32 MAC_ThresholdControlBits;   /*!< Threshold Control Bits (OPT_MODE.TR)
                                                    */
    uint32 MAC_TransmitMode;   /*!< Transmit Mode (OPT_MODE.FD)
                                                    */
    uint32 MAC_PassAllMulticast;   /*!< Pass All Multicast (OPT_MODE.PM)
                                                    */
    uint32 MAC_PromiscuousMode;   /*!< Promiscuous Mode (OPT_MODE.PR)
                                                    */
    uint32 MAC_PassBadFrame;   /*!< Pass Bad Frame (OPT_MODE.PB)
                                                    */

    uint32 MAC_CycleSize;   /*!< Transmitting and receiving period
                                                  (TIMER_CTRL.CS)  */
    uint32 MAC_TransmitTimer;   /*!< Transmit Timer (TIMER_CTRL.TT[3:0])
                                                         */
    uint32 MAC_TransmitPacketNumber;   /*!< Transmit Packet Number
                                                  (TIMER_CTRL.NTP[2:0])       */
    uint32 MAC_ReceiveTimer;   /*!< Receive Timer (TIMER_CTRL.RT[3:0])
                                                          */
    uint32 MAC_ReceivePacketNumber;   /*!< Receive Packet number
                                                  (TIMER_CTRL.NRP[2:0])        */
    uint32 MAC_ContinuousMode;   /*!< Timer Continuous mode (TIMER_CTRL.CON)
                                                           */
    uint32 MAC_TimerValue;   /*!< Timer value (TIMER_CTRL.TIM[15:0])
                                                           */

    uint32 MAC_PhyAddress;   /*!< External PHY address (0-31), used by the
                                                  MDIO   */
                                                  /*!< register access functions                        */
    uint32 Reserved[2];                           /*!< Reserved for future extension (must be 0) */
} MAC_InitTypeDef;

/**
 * @brief  MAC / init structure version macros.
 * @note   MAC_INIT_V1 is the current version. Future versions (e.g. V2 with
 *         new fields) must be appended after the existing fields without
 *         changing the layout (architecture spec section 22.5).
 */
#define MAC_INIT_V1  0x0100U   /*!< MAC Init structure version V1.0 */
#define MAC_INIT_VERSION  MAC_INIT_V1   /*!< Current MAC Init structure version */

/**
 * @brief  MAC Transmit descriptor structure
 * @note   This is the chip one-descriptor-per-frame transmit descriptor,
 *         matching the device descriptor layout so that existing driver
 *         code can be used without change. A single descriptor carries a
 *         whole frame (first and last segment bits are both set).
 */
typedef struct
{
    uint32         descriptor_0;                  /*!< Transmit status word (TDES0)             */
    uint32         descriptor_1;                  /*!< Transmit control / buffer size (TDES1)   */
    const uint8*   buffer_1;                      /*!< Address of the frame data buffer         */
    uint32         buffer_2;                      /*!< Reserved buffer_2 (not used)             */
} mac_tx_descriptor_t;

/**
 * @brief  MAC Receive descriptor structure
 * @note   This is the chip one-descriptor-per-frame receive descriptor,
 *         matching the device descriptor layout. A single descriptor carries
 *         a whole received frame.
 */
typedef struct
{
    uint32     descriptor_0;                      /*!< Receive status word (RDES0)             */
    uint32     descriptor_1;                      /*!< Receive control / buffer size (RDES1)   */
    uint8*     buffer_1;                          /*!< Address of the frame data buffer        */
    uint32     buffer_2;                          /*!< Reserved buffer_2 (not used)            */
} mac_rx_descriptor_t;

/**
 * @brief  MAC State structure definition
 */
typedef enum
{
    HAL_MAC_STATE_RESET   = 0x00U,                    /*!< MAC not yet initialized or disabled */
    HAL_MAC_STATE_READY   = 0x01U,                    /*!< MAC initialized and ready for use   */
    HAL_MAC_STATE_BUSY    = 0x02U,                    /*!< MAC internal process ongoing        */
    HAL_MAC_STATE_TIMEOUT = 0x03U,                    /*!< MAC timeout state                   */
    HAL_MAC_STATE_ERROR   = 0x04U                     /*!< MAC error state                     */
} HAL_MAC_StateTypeDef;

/**
 * @brief  MAC Handle Structure definition
 * @note   The handle carries the resource lock, the state and the error code
 *         of the module. The RxDesc / TxDesc fields store the receive /
 *         transmit descriptor currently used by HAL_MAC_GetReceivedFrame() /
 *         HAL_MAC_TransmitFrame().
 * @note   Field order follows the architecture spec HANDLE-02:
 *         Instance -> Init -> Lock -> State -> ErrorCode -> module fields.
 * @note   State usage: RESET (not initialized), BUSY (the entry point of an
 *         operation set it), READY (an operation completed) and TIMEOUT (a
 *         blocking wait expired) are produced by this module. ERROR is
 *         produced by HAL_MAC_IRQHandler() when the abnormal interrupt summary
 *         is reported; all four non reset values are recoverable, because the
 *         entry point of the next operation clears the error code and returns
 *         to the ready state.
 */
typedef struct __MAC_HandleTypeDef
{
    MAC_TypeDef                *Instance;          /*!< Register base address */
    MAC_InitTypeDef            Init;               /*!< MAC required parameters */
    HAL_LockTypeDef            Lock;               /*!< MAC locking object */
    __IO HAL_MAC_StateTypeDef  State;              /*!< MAC communication state */
    __IO uint32                ErrorCode;          /*!< MAC error code */
    mac_tx_descriptor_t        *TxDesc;            /*!< Tx descriptor to use */
    mac_rx_descriptor_t        *RxDesc;            /*!< Rx descriptor to use */
#if (USE_RTOS == 1)
    HAL_MutexTypeDef           LockMutex;          /*!< RTOS mutex handle (created by the
                                                        user porting layer, e.g. in
                                                        HAL_MAC_MspInit)               */
#endif /* USE_RTOS */
} MAC_HandleTypeDef;
/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @defgroup MAC_Exported_Constants MAC Exported Constants
  * @{
  */

/** @defgroup MAC_Error_Code MAC Error Code
  * @{
  */
#define HAL_MAC_ERROR_NONE                  ((uint32)0x00000000U) /*!< No error                          */
#define HAL_MAC_ERROR_TIMEOUT               ((uint32)0x00000001U) /*!< A blocking wait timed out          */
#define HAL_MAC_ERROR_HARDWARE              ((uint32)0x00000002U) /*!< Hardware error reported by the MAC */
#define HAL_MAC_ERROR_INVALID_PARAM         ((uint32)0x00000004U) /*!< Invalid parameter or rejected operation */
/**
  * @}
  */

/** @defgroup MAC_Max_Packet_Size MAC max packet size
  * @brief  Maximum size of a MAC frame. The value is a 1500-byte constant;
  *         it is exported here because the receive
  *         descriptor setup (HAL_MAC_GetReceivedFrame) uses it.
  * @{
  */
#define MAC_MAX_PACKET_SIZE                        ((uint32)1500U)
/**
  * @}
  */

/** @defgroup MAC_Process_Status MAC receive / transmit process status
  * @brief  Value of the Process parameter of HAL_MAC_GetProcessStatus().
  * @{
  */
#define MAC_PROCESS_RECEIVE                        ((uint32)0x000E0000U)
#define MAC_PROCESS_TRANSMIT                       ((uint32)0x00700000U)
/**
  * @}
  */

/** @defgroup MAC_IT_Mask_Definitions MAC interrupt enable (INT_ENABLE) definitions
  * @brief  Interrupt source enable values written to the INT_ENABLE register
  *         (used by HAL_MAC_ITConfig() and __HAL_MAC_ENABLE_IT /
  *         __HAL_MAC_DISABLE_IT). The values map the INT_ENABLE bit
  *         positions.
  * @{
  */
#define MAC_IT_NIE                                 ((uint32)0x00010000U)  /*!< Normal Interrupt Summary */
#define MAC_IT_AIE                                 ((uint32)0x00008000U)  /*!< Abnormal Interrupt Summary */
#define MAC_IT_ERE                                 ((uint32)0x00004000U)  /*!< Early Receive Interrupt */
#define MAC_IT_GTE                                 ((uint32)0x00000800U)  /*!< General Timer Interrupt */
#define MAC_IT_ETE                                 ((uint32)0x00000400U)  /*!< Early Transmit Interrupt */
#define MAC_IT_RSE                                 ((uint32)0x00000100U)  /*!< Receive Process Stopped */
#define MAC_IT_RUE                                 ((uint32)0x00000080U)  /*!< Receive Buffer Unavailable */
#define MAC_IT_RIE                                 ((uint32)0x00000040U)  /*!< Receive Interrupt */
#define MAC_IT_UNE                                 ((uint32)0x00000020U)  /*!< Transmit Underflow */
#define MAC_IT_TUE                                 ((uint32)0x00000004U)  /*!< Transmit Buffer Unavailable */
#define MAC_IT_TSE                                 ((uint32)0x00000002U)  /*!< Transmit Process Stopped */
#define MAC_IT_TIE                                 ((uint32)0x00000001U)  /*!< Transmit Interrupt */
/**
  * @}
  */

/** @defgroup MAC_Flags_Definitions MAC status (STATUS) flag definitions
  * @brief  Status / flag values read from the STATUS register (used by
  *         HAL_MAC_GetFlagStatus() and __HAL_MAC_GET_FLAG).
  * @{
  */
#define MAC_Flag_NIS                               ((uint32)0x00010000U)  /*!< Normal Interrupt Summary */
#define MAC_Flag_AIS                               ((uint32)0x00008000U)  /*!< Abnormal Interrupt Summary */
#define MAC_Flag_ERI                               ((uint32)0x00004000U)  /*!< Early Receive Interrupt */
#define MAC_Flag_GTE                               ((uint32)0x00000800U)  /*!< General Timer Interrupt */
#define MAC_Flag_ETI                               ((uint32)0x00000400U)  /*!< Early Transmit Interrupt */
#define MAC_Flag_RPS                               ((uint32)0x00000100U)  /*!< Receive Process Stopped */
#define MAC_Flag_RU                                ((uint32)0x00000080U)  /*!< Receive Buffer Unavailable */
#define MAC_Flag_RI                                ((uint32)0x00000040U)  /*!< Receive Interrupt */
#define MAC_Flag_UNF                               ((uint32)0x00000020U)  /*!< Transmit Underflow */
#define MAC_Flag_TU                                ((uint32)0x00000004U)  /*!< Transmit Buffer Unavailable */
#define MAC_Flag_TPS                               ((uint32)0x00000002U)  /*!< Transmit Process Stopped */
#define MAC_Flag_TI                                ((uint32)0x00000001U)  /*!< Transmit Interrupt */
/**
  * @}
  */

/** @defgroup MAC_ClearIT_Definitions MAC clear interrupt (STATUS) definitions
  * @brief  Value written to the STATUS register to clear an interrupt
  *         (write-1-to-clear), used by HAL_MAC_ClearITStatus() and
  *         __HAL_MAC_CLEAR_IT. The values equal the corresponding
  *         MAC_Flag_* values (same STATUS bits).
  * @{
  */
#define MAC_IT_NIS                                 ((uint32)0x00010000U)  /*!< Normal Interrupt Summary */
#define MAC_IT_AIS                                 ((uint32)0x00008000U)  /*!< Abnormal Interrupt Summary */
#define MAC_IT_ERI                                 ((uint32)0x00004000U)  /*!< Early Receive Interrupt */
#define MAC_IT_GTE                                 ((uint32)0x00000800U)  /*!< General Timer Interrupt */
#define MAC_IT_ETI                                 ((uint32)0x00000400U)  /*!< Early Transmit Interrupt */
#define MAC_IT_RPS                                 ((uint32)0x00000100U)  /*!< Receive Process Stopped */
#define MAC_IT_RU                                  ((uint32)0x00000080U)  /*!< Receive Buffer Unavailable */
#define MAC_IT_RI                                  ((uint32)0x00000040U)  /*!< Receive Interrupt */
#define MAC_IT_UNF                                 ((uint32)0x00000020U)  /*!< Transmit Underflow */
#define MAC_IT_TU                                  ((uint32)0x00000004U)  /*!< Transmit Buffer Unavailable */
#define MAC_IT_TPS                                 ((uint32)0x00000002U)  /*!< Transmit Process Stopped */
#define MAC_IT_TI                                  ((uint32)0x00000001U)  /*!< Transmit Interrupt */
/**
  * @}
  */

/** @defgroup MAC_Transmit_Descriptor_Bits MAC transmit descriptor bits
  * @brief  Transmit descriptor (TDES0 / TDES1) field definitions, matching
  *         the device descriptor layout so that existing descriptor
  *         code can be used without change.
  * @{
  */
#define TDES0_OWN                                  ((uint32)0x80000000U)  /*!< Descriptor OWN bit */
#define TDES0_ES                                   ((uint32)(1U << 15U))   /*!< Error summary */
#define TDES0_LO                                   ((uint32)(1U << 11U))   /*!< Lost carrier */
#define TDES0_NC                                   ((uint32)(1U << 10U))   /*!< No carrier */
#define TDES0_LC                                   ((uint32)(1U << 9U))    /*!< Delayed conflict */
#define TDES0_EC                                   ((uint32)(1U << 8U))    /*!< Excessive collision */
#define TDES0_CC_MASK                              0xFU                      /*!< Collision count mask */
#define TDES0_CC_OFFSET                            3U                        /*!< Collision count offset */
#define TDES0_UF                                   ((uint32)(1U << 1U))    /*!< Underflow error */
#define TDES0_DE                                   ((uint32)(1U))          /*!< Deferred */

#define TDES1_IC                                   ((uint32)(1U << 31U))   /*!< Interrupt on completion */
#define TDES1_LS                                   ((uint32)(1U << 30U))   /*!< Last descriptor */
#define TDES1_FS                                   ((uint32)(1U << 29U))   /*!< First descriptor */
#define TDES1_FT1                                  ((uint32)(1U << 28U))   /*!< Filter type (bit 1) */
#define TDES1_SET                                  ((uint32)(1U << 27U))   /*!< Setup packet */
#define TDES1_AC                                   ((uint32)(1U << 26U))   /*!< Add CRC disable */
#define TDES1_TER                                  ((uint32)(1U << 25U))   /*!< Transmit end of ring */
#define TDES1_TCH                                  ((uint32)(1U << 24U))   /*!< Second address chained */
#define TDES1_DPD                                  ((uint32)(1U << 23U))   /*!< Disable pad */
#define TDES1_FT0                                  ((uint32)(1U << 22U))   /*!< Filter type (bit 0) */
/**
  * @}
  */

/** @defgroup MAC_Receive_Descriptor_Bits MAC receive descriptor bits
  * @brief  Receive descriptor (RDES0 / RDES1) field definitions, matching
  *         the device descriptor layout so that existing descriptor
  *         code can be used without change.
  * @{
  */
#define RDES0_OWN                                  ((uint32)0x80000000U)  /*!< Descriptor OWN bit */
#define RDES0_FF                                   ((uint32)0x40000000U)  /*!< Filtering fail */
#define RDES0_FL_MASK                              ((uint32)0x00003FFFU)  /*!< Frame length mask */
#define RDES0_FL_OFFSET                            16U                       /*!< Frame length offset */
#define RDES0_ES                                   ((uint32)0x00008000U)  /*!< Error summary */
#define RDES0_DE                                   ((uint32)0x00004000U)  /*!< Descriptor error */
#define RDES0_RF                                   ((uint32)0x00000800U)  /*!< Runt frame */
#define RDES0_MF                                   ((uint32)0x00000400U)  /*!< Multicast frame */
#define RDES0_FS                                   ((uint32)0x00000200U)  /*!< First descriptor */
#define RDES0_LS                                   ((uint32)0x00000100U)  /*!< Last descriptor */
#define RDES0_TL                                   ((uint32)0x00000080U)  /*!< Frame too long */
#define RDES0_CS                                   ((uint32)0x00000040U)  /*!< Collision seen */
#define RDES0_FT                                   ((uint32)0x00000020U)  /*!< Frame type */
#define RDES0_RE                                   ((uint32)0x00000008U)  /*!< MII error report */
#define RDES0_DB                                   ((uint32)0x00000004U)  /*!< Dribbling bit */
#define RDES0_CE                                   ((uint32)0x00000002U)  /*!< CRC error */
#define RDES0_ZERO                                 ((uint32)0x00000001U)  /*!< Valid frame length */

#define RDES1_RER                                  ((uint32)0x02000000U)  /*!< Receive end of ring */
#define RDES1_RCH                                  ((uint32)0x01000000U)  /*!< Second address chained */
#define RDES1_RBS2_MASK                            0x7FFU                    /*!< Buffer2 size mask */
#define RDES1_RBS2_OFFSET                          11U                       /*!< Buffer2 size offset */
#define RDES1_RBS1_MASK                            0x7FFU                    /*!< Buffer1 size mask */
#define RDES1_RBS1_OFFSET                          0U                        /*!< Buffer1 size offset */
/**
  * @}
  */

/** @defgroup MAC_Init_Constants MAC init constants
  * @brief  Values of the MAC_InitTypeDef fields, defined by the device
  *         register field description so that driver code can be used
  *         without change.
  * @{
  */
#define MAC_AutoPollInterval_Disable ((uint32)0x00000000U)
#define MAC_AutoPollInterval_1 ((uint32)0x00000001U)
#define MAC_AutoPollInterval_2 ((uint32)0x00000002U)
#define MAC_AutoPollInterval_3 ((uint32)0x00000003U)
#define MAC_AutoPollInterval_4 ((uint32)0x00000004U)
#define MAC_AutoPollInterval_5 ((uint32)0x00000005U)
#define MAC_AutoPollInterval_6 ((uint32)0x00000006U)
#define MAC_AutoPollInterval_7 ((uint32)0x00000007U)

#define MAC_DescriptorEndianMode_Big               ((uint32)0x00000001U)
#define MAC_DescriptorEndianMode_Little            ((uint32)0x00000000U)

#define MAC_ProgrammablePulseLength_0              ((uint32)0x00000000U)
#define MAC_ProgrammablePulseLength_1              ((uint32)0x00000001U)
#define MAC_ProgrammablePulseLength_2              ((uint32)0x00000002U)
#define MAC_ProgrammablePulseLength_4              ((uint32)0x00000004U)
#define MAC_ProgrammablePulseLength_8              ((uint32)0x00000008U)
#define MAC_ProgrammablePulseLength_16             ((uint32)0x00000010U)
#define MAC_ProgrammablePulseLength_32             ((uint32)0x00000020U)

#define MAC_DataEndianMode_Big                     ((uint32)0x00000001U)
#define MAC_DataEndianMode_Little                  ((uint32)0x00000000U)

#define MAC_BuArbitrations_EqualPriority           ((uint32)0x00000001U)
#define MAC_BusArbitration_Intelligent             ((uint32)0x00000000U)

#define MAC_ReceiveAll_Enable                      ((uint32)0x00000001U)
#define MAC_ReceiveAll_Disable                     ((uint32)0x00000000U)

#define MAC_FIFOThreshold_100M                     ((uint32)0x00000001U)
#define MAC_FIFOThreshold_10M                      ((uint32)0x00000000U)

#define MAC_StoreandForward_Enable                 ((uint32)0x00000001U)
#define MAC_StoreandForward_Disable                ((uint32)0x00000000U)

#define MAC_ThresholdControlBits_Enable            ((uint32)0x00000001U)
#define MAC_ThresholdControlBits_Disable           ((uint32)0x00000000U)

#define MAC_TransmitMode_HalfDuplex                ((uint32)0x00000000U)
#define MAC_TransmitMode_FullDuplex                ((uint32)0x00000001U)

#define MAC_PassAllMulticasts_Disable              ((uint32)0x00000000U)
#define MAC_PassAllMulticasts_Enable               ((uint32)0x00000001U)

#define MAC_PromiscuousMode_Disable                ((uint32)0x00000000U)
#define MAC_PromiscuousMode_Enable                 ((uint32)0x00000001U)

#define MAC_PassBadFrame_Disable                   ((uint32)0x00000000U)
#define MAC_PassBadFrame_Enable                    ((uint32)0x00000001U)

#define MAC_TimerWorkMode_OneShot                  ((uint32)0x00000000U)
#define MAC_TimerWorkMode_Continuous               ((uint32)0x00000001U)
/**
  * @}
  */

/**
  * @}
  */

/* Exported macros -----------------------------------------------------------*/

/** @defgroup MAC_Exported_Macros MAC Exported Macros
  * @{
  */

/** @brief  Reset MAC handle state
  * @param  __HANDLE__: MAC Handle
  * @retval None
  */
#define __HAL_MAC_RESET_HANDLE_STATE(__HANDLE__)   ((__HANDLE__)->State = HAL_MAC_STATE_RESET)

/**
  * @brief  Enable the specified MAC interrupt.
  * @note   The interrupt source enable values (MAC_IT_NIE ... MAC_IT_TIE)
  *         map the INT_ENABLE register bits.
  * @param  __HANDLE__: MAC Handle
  * @param  __IT__: MAC interrupt to enable (MAC_IT_*).
  * @retval None
  */
#define __HAL_MAC_ENABLE_IT(__HANDLE__, __IT__)    SET_BIT((__HANDLE__)->Instance->INT_ENABLE, (__IT__))

/**
  * @brief  Disable the specified MAC interrupt.
  * @param  __HANDLE__: MAC Handle
  * @param  __IT__: MAC interrupt to disable (MAC_IT_*).
  * @retval None
  */
#define __HAL_MAC_DISABLE_IT(__HANDLE__, __IT__)   CLEAR_BIT((__HANDLE__)->Instance->INT_ENABLE, (__IT__))

/**
  * @brief  Check whether the specified MAC interrupt status flag is set.
  * @note   The interrupt status flags are read from the STATUS register
  *         (MAC_Flag_* values).
  * @param  __HANDLE__: MAC Handle
  * @param  __IT__: MAC interrupt status to check (MAC_Flag_*).
  * @retval The new state of __IT__ (SET or RESET).
  */
#define __HAL_MAC_GET_IT(__HANDLE__, __IT__)       (READ_BIT((__HANDLE__)->Instance->STATUS, (__IT__)) != 0U)

/**
  * @brief  Check whether the specified MAC flag is set.
  * @param  __HANDLE__: MAC Handle
  * @param  __FLAG__: MAC flag to check (MAC_Flag_*).
  * @retval The new state of __FLAG__ (SET or RESET).
  */
#define __HAL_MAC_GET_FLAG(__HANDLE__, __FLAG__)   (READ_BIT((__HANDLE__)->Instance->STATUS, (__FLAG__)) != 0U)

/**
  * @brief  Clear the specified MAC interrupt status flag.
  * @note   The STATUS register bits are cleared by writing a 1. The clear
  *         values (MAC_IT_NIS ... MAC_IT_TI) equal the corresponding
  *         MAC_Flag_* values.
  * @param  __HANDLE__: MAC Handle
  * @param  __IT__: MAC interrupt status to clear (MAC_IT_*).
  * @retval None
  */
#define __HAL_MAC_CLEAR_IT(__HANDLE__, __IT__)     SET_BIT((__HANDLE__)->Instance->STATUS, (__IT__))

/**
  * @brief  Start the MAC receiver.
  * @param  __HANDLE__: MAC Handle
  * @retval None
  */
#define __HAL_MAC_RX_ENABLE(__HANDLE__)            SET_BIT((__HANDLE__)->Instance->OPT_MODE, MAC_OPT_MODE_SR)

/**
  * @brief  Stop the MAC receiver.
  * @param  __HANDLE__: MAC Handle
  * @retval None
  */
#define __HAL_MAC_RX_DISABLE(__HANDLE__)           CLEAR_BIT((__HANDLE__)->Instance->OPT_MODE, MAC_OPT_MODE_SR)

/**
  * @brief  Start the MAC transmitter.
  * @param  __HANDLE__: MAC Handle
  * @retval None
  */
#define __HAL_MAC_TX_ENABLE(__HANDLE__)            SET_BIT((__HANDLE__)->Instance->OPT_MODE, MAC_OPT_MODE_ST)

/**
  * @brief  Stop the MAC transmitter.
  * @param  __HANDLE__: MAC Handle
  * @retval None
  */
#define __HAL_MAC_TX_DISABLE(__HANDLE__)           CLEAR_BIT((__HANDLE__)->Instance->OPT_MODE, MAC_OPT_MODE_ST)

/**
  * @brief  Trigger a transmit poll demand.
  * @param  __HANDLE__: MAC Handle
  * @retval None
  */
#define __HAL_MAC_TX_POLL_DEMAND(__HANDLE__)       WRITE_REG((__HANDLE__)->Instance->TX_POLL, (uint32)1U)

/**
  * @brief  Trigger a receive poll demand.
  * @param  __HANDLE__: MAC Handle
  * @retval None
  */
#define __HAL_MAC_RX_POLL_DEMAND(__HANDLE__)       WRITE_REG((__HANDLE__)->Instance->RX_POLL, (uint32)1U)

/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/

/** @defgroup MAC_Exported_Functions MAC Exported Functions
  * @{
  */

/** @defgroup MAC_Exported_Functions_Group1 Initialization and de-initialization functions
  *  @brief    Initialization and de-initialization functions.
  * @{
  */

/**
 * @brief  Initializes the MAC peripheral. (BLOCKING)
 * @note   Performs a software reset (BUS_MODE.SWR), waits for the reset to
 *         complete, then configures the DMA bus mode (BUS_MODE), the
 *         operation mode (OPT_MODE) and the general timer / interrupt
 *         suppression control (TIMER_CTRL) registers.
 * @note   The MAC clock gating and the PLIC interrupt line must be
 *         configured by the user in HAL_MAC_MspInit(). LOCK-06: the low level
 *         initialization runs before the handle is locked.
 * @note   The state gate does not apply to this function (it brings the handle
 *         out of the reset state). On a software reset timeout the handle
 *         enters the timeout state and the timeout error code is set.
 * @note   RTOS: the reset wait loop yields the CPU once per iteration.
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (invalid handle) / HAL_TIMEOUT (the software
 *         reset did not complete)
 */
HAL_StatusTypeDef HAL_MAC_Init(MAC_HandleTypeDef *hmac);

/**
 * @brief  De-initializes the MAC peripheral. (NON-BLOCKING)
 * @note   Resets the MAC through the SMU APB0CFGR register (MACRST clear
 *         then set) and calls HAL_MAC_MspDeInit().
 * @note   The state gate does not apply to this function (it accepts any state,
 *         so that a failed initialization can always be undone). LOCK-06: the
 *         low level de-initialization runs after the unlock.
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (invalid handle)
 */
HAL_StatusTypeDef HAL_MAC_DeInit(MAC_HandleTypeDef *hmac);

/**
 * @brief  Initializes the MAC MSP. Weak empty function; the user (NON-BLOCKING)
 *         implements the low level hardware initialization (MAC clock
 *         enable and reset release through the SMU APB0CFGR, PLIC
 *         interrupt enable).
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @retval None
 */
void HAL_MAC_MspInit(MAC_HandleTypeDef *hmac);

/**
 * @brief  De-initializes the MAC MSP. Weak empty function; the user (NON-BLOCKING)
 *         implements the low level hardware de-initialization.
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @retval None
 */
void HAL_MAC_MspDeInit(MAC_HandleTypeDef *hmac);

/**
  * @}
  */

/** @defgroup MAC_Exported_Functions_Group2 IO operation functions
  *  @brief    IO operation functions.
  * @{
  */

/**
 * @brief  Transmits a network packet using the transmit descriptor stored (NON-BLOCKING)
 *         in the handle (hmac->TxDesc).
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @param  FrameLength: the length of the frame to be transmitted.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR
 */
HAL_StatusTypeDef HAL_MAC_TransmitFrame(MAC_HandleTypeDef *hmac, uint32 FrameLength);

/**
 * @brief  Receives a network packet using the receive descriptor stored in (NON-BLOCKING)
 *         the handle (hmac->RxDesc), copies the frame payload into RxBuff
 *         and returns its length.
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @param  RxBuff: pointer to the buffer where the received data will be
 *                 stored.
 * @param  Length: pointer to a variable where the length of the received
 *                 data will be stored.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR
 */
HAL_StatusTypeDef HAL_MAC_GetReceivedFrame(MAC_HandleTypeDef *hmac, uint8 *RxBuff, uint32 *Length);

/**
 * @brief  Enables the MAC receiver and transmitter. (NON-BLOCKING)
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR
 */
HAL_StatusTypeDef HAL_MAC_Start(MAC_HandleTypeDef *hmac);

/**
 * @brief  Disables the MAC receiver and transmitter. (NON-BLOCKING)
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR
 */
HAL_StatusTypeDef HAL_MAC_Stop(MAC_HandleTypeDef *hmac);

/**
 * @brief  Start / stop the MAC receiver. (NON-BLOCKING)
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @param  NewState: ENABLE to start the receiver, DISABLE to stop it.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR
 */
HAL_StatusTypeDef HAL_MAC_ReceiveCmd(MAC_HandleTypeDef *hmac, FunctionalState NewState);

/**
 * @brief  Start / stop the MAC transmitter. (NON-BLOCKING)
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @param  NewState: ENABLE to start the transmitter, DISABLE to stop it.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR
 */
HAL_StatusTypeDef HAL_MAC_TransmitCmd(MAC_HandleTypeDef *hmac, FunctionalState NewState);

/**
 * @brief  Sets the transmit descriptor used by HAL_MAC_TransmitFrame() and (NON-BLOCKING)
 *         writes its base address into the TDES_BASE_ADDR register.
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @param  TxDesc: pointer to the transmit descriptor.
 * @param  Addr: the transmit descriptor base address.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR
 */
HAL_StatusTypeDef HAL_MAC_SetTxDescriptor(MAC_HandleTypeDef *hmac, mac_tx_descriptor_t *TxDesc,
                                          uint32 Addr);

/**
 * @brief  Sets the receive descriptor used by HAL_MAC_GetReceivedFrame() and (NON-BLOCKING)
 *         writes its base address into the RDES_BASE_ADDR register.
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @param  RxDesc: pointer to the receive descriptor.
 * @param  Addr: the receive descriptor base address.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR
 */
HAL_StatusTypeDef HAL_MAC_SetRxDescriptor(MAC_HandleTypeDef *hmac, mac_rx_descriptor_t *RxDesc,
                                          uint32 Addr);

/**
  * @}
  */

/** @defgroup MAC_Exported_Functions_Group3 Peripheral control functions
  *  @brief    Peripheral control functions.
  * @{
  */

/**
 * @brief  Resets all the MAC internal triggers (BUS_MODE.SWR). (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not been
 *         initialized (HAL_MAC_Init() is required first).
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_MAC_SoftwareReset(MAC_HandleTypeDef *hmac);

/**
 * @brief  Fills each MAC_InitStruct member with its default value. (NON-BLOCKING)
 * @param  MAC_InitStruct: pointer to a MAC_InitTypeDef structure which
 *         will be initialized.
 * @retval None
 */
void HAL_MAC_StructInit(MAC_InitTypeDef *MAC_InitStruct);

/**
 * @brief  Gets the status of the MAC receiving and transmitting process. (NON-BLOCKING)
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @param  Process: specifies the process status to read (MAC_PROCESS_RECEIVE
 *                  or MAC_PROCESS_TRANSMIT).
 * @retval uint8: the value of the process status.
 */
uint8 HAL_MAC_GetProcessStatus(MAC_HandleTypeDef *hmac, uint32 Process);

/**
 * @brief  Enables or disables the specified MAC interrupts. (NON-BLOCKING)
 * @note   Interrupt safe by design: this interface takes no handle lock and
 *         applies no state gate, so that it can be called from an interrupt
 *         context (the MAC interrupt sources often have to be reconfigured
 *         from the user interrupt handler while a task holds the lock).
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @param  MAC_IT: the MAC interrupt sources to enable or disable (MAC_IT_*).
 * @param  NewState: ENABLE or DISABLE.
 * @retval None
 */
void HAL_MAC_ITConfig(MAC_HandleTypeDef *hmac, uint32 MAC_IT, FunctionalState NewState);

/**
 * @brief  Checks whether the specified MAC flag is set or not. (NON-BLOCKING)
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @param  MAC_FLAG: the flag to check (MAC_Flag_*).
 * @retval FlagStatus: SET or RESET.
 */
FlagStatus HAL_MAC_GetFlagStatus(MAC_HandleTypeDef *hmac, uint32 MAC_FLAG);

/**
 * @brief  Clears the specified MAC interrupt status flag (write-1-clear). (NON-BLOCKING)
 * @note   Interrupt safe by design: this interface takes no handle lock and
 *         applies no state gate, so that a pending flag can always be cleared
 *         from the interrupt context (clearing it from a locked task would be
 *         impossible once the interrupt line is asserted).
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @param  MAC_IT: the interrupt flag to clear (MAC_IT_*).
 * @retval None
 */
void HAL_MAC_ClearITStatus(MAC_HandleTypeDef *hmac, uint32 MAC_IT);

/**
  * @}
  */

/** @defgroup MAC_Exported_Functions_Group4 MDIO management functions
  *  @brief    MDIO / PHY management functions.
  * @{
  */

/**
 * @brief  Enables or disables the MDIO clock. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not been
 *         initialized (HAL_MAC_Init() is required first).
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @param  NewState: ENABLE or DISABLE.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_MAC_MDIOClockCmd(MAC_HandleTypeDef *hmac, FunctionalState NewState);

/**
 * @brief  Sets the MAC MDC prescaler value. (NON-BLOCKING)
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not been
 *         initialized (HAL_MAC_Init() is required first).
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @param  MAC_Prescaler: the MAC MDC prescaler value (MDIO_CTRL0.MDC_DIV).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_MAC_SetMDCPrescaler(MAC_HandleTypeDef *hmac, uint16 MAC_Prescaler);

/**
 * @brief  Reads data from a register of the specified external PHY. (BLOCKING)
 * @note   On timeout the handle enters the timeout state and the timeout error
 *         code is set.
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @param  PHYReg: the PHY register address (0-31).
 * @param  RegValue: pointer to the register value read.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_MAC_ReadPHYRegister(MAC_HandleTypeDef *hmac, uint16 PHYReg, uint32 *RegValue);

/**
 * @brief  Writes data to a register of the specified external PHY. (BLOCKING)
 * @note   On timeout the handle enters the timeout state and the timeout error
 *         code is set.
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @param  PHYReg: the PHY register address (0-31).
 * @param  RegValue: the value to write.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_MAC_WritePHYRegister(MAC_HandleTypeDef *hmac, uint16 PHYReg, uint32 RegValue);

/**
  * @}
  */

/** @defgroup MAC_Exported_Functions_Group5 Interrupt processing functions
  *  @brief    Interrupt processing functions.
  * @{
  */

/**
 * @brief  Handles the MAC interrupt request. (NON-BLOCKING)
 * @note   The chip MAC has a single PLIC interrupt line (MAC_IRQn = 0x18)
 *         shared by all STATUS interrupt sources. The receive / transmit
 *         complete flags trigger the HAL_MAC_RxCpltCallback() /
 *         HAL_MAC_TxCpltCallback() and the abnormal interrupt summary (AIS)
 *         triggers HAL_MAC_ErrorCallback().
 * @note   LOCK-04 / ARCH-CONST-19: interrupt context. This routine takes no
 *         lock, waits for nothing and never blocks, so it is safe to call it
 *         from the interrupt service routine. On the abnormal summary it sets
 *         the hardware error code and puts the handle in the (recoverable)
 *         error state, so that a task can observe the condition and retry.
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @retval None
 */
void HAL_MAC_IRQHandler(MAC_HandleTypeDef *hmac);

/**
 * @brief  Transmit complete callback (WEAK). (NON-BLOCKING)
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @retval None
 */
void HAL_MAC_TxCpltCallback(MAC_HandleTypeDef *hmac);

/**
 * @brief  Receive complete callback (WEAK). (NON-BLOCKING)
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @retval None
 */
void HAL_MAC_RxCpltCallback(MAC_HandleTypeDef *hmac);

/**
 * @brief  MAC error callback (WEAK). (NON-BLOCKING)
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @retval None
 */
void HAL_MAC_ErrorCallback(MAC_HandleTypeDef *hmac);

/**
  * @}
  */

/** @defgroup MAC_Exported_Functions_Group6 Peripheral State functions
  *  @brief    Peripheral State functions.
  * @{
  */

/**
 * @brief  Returns the MAC handle state. (NON-BLOCKING)
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @retval HAL_MAC_StateTypeDef: the current handle state.
 */
HAL_MAC_StateTypeDef HAL_MAC_GetState(MAC_HandleTypeDef *hmac);

/**
 * @brief  Returns the MAC error code. (NON-BLOCKING)
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @retval uint32: the MAC error code (HAL_MAC_ERROR_xxx).
 */
uint32 HAL_MAC_GetError(MAC_HandleTypeDef *hmac);

/**
  * @}
  */

/**
  * @}
  */

/* Shared internal functions --------------------------------------------------*/

/**
 * @brief  Check whether the MAC handle and its instance are valid.
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
uint32 MAC_HandleIsValid(MAC_HandleTypeDef *hmac);

/**
 * @brief  Check whether the handle accepts a new operation.
 * @note   Architecture constraint ARCH-CONST-09: a handle that is BUSY rejects
 *         any other operation with HAL_BUSY, and a handle that is not
 *         initialized (RESET) requires HAL_MAC_Init() first and is rejected
 *         with HAL_ERROR. The recoverable states TIMEOUT and ERROR accept a
 *         new operation directly.
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK (accepted) / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef MAC_CheckState(MAC_HandleTypeDef *hmac);

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_MAC_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; the value is passed to HAL_MutexAcquire() as
 *         is (RTOS ticks; HAL_MAX_DELAY means an infinite wait).
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef MAC_LockHandle(MAC_HandleTypeDef *hmac, uint32 Timeout);

/**
 * @brief  Unlock the handle.
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @retval None
 */
void MAC_UnlockHandle(MAC_HandleTypeDef *hmac);

/* Private macros ------------------------------------------------------------*/

/** @defgroup MAC_Private_Macros MAC Private Macros
  * @{
  */

#define IS_MAC_ALL_INSTANCE(INSTANCE)              (((INSTANCE) == MAC))

/** @defgroup MAC_IS_Definitions MAC private macros to check input parameters
  * @{
  */
#define IS_VALID_MAC_DESCRIPTOR_SKIP_LENGTH(value)  ((value)<=0x1FFU)
#define IS_VALID_MAC_TIMER_VALUE(value)             ((value)<=0xFFFFU)

#define IS_VALID_MAC_AutoPollInterval(value)    (((value) == MAC_AutoPollInterval_Disable) || \
                                                 ((value) == MAC_AutoPollInterval_1) || \
                                                 ((value) == MAC_AutoPollInterval_2) || \
                                                 ((value) == MAC_AutoPollInterval_3) || \
                                                 ((value) == MAC_AutoPollInterval_4) || \
                                                 ((value) == MAC_AutoPollInterval_5) || \
                                                 ((value) == MAC_AutoPollInterval_6) || \
                                                 ((value) == MAC_AutoPollInterval_7))

#define IS_VALID_MAC_DESCRIPTOR_BYTE_ENDIAN(value) (((value) == MAC_DescriptorEndianMode_Big) || \
                                                  ((value) == MAC_DescriptorEndianMode_Little))

#define IS_VALID_MAC_PROGRAMMABLE_PULSE_LENGTH(value) (((value) == MAC_ProgrammablePulseLength_0) || \
                                                      ((value) == MAC_ProgrammablePulseLength_1) || \
                                                      ((value) == MAC_ProgrammablePulseLength_2) || \
                                                      ((value) == MAC_ProgrammablePulseLength_4) || \
                                                      ((value) == MAC_ProgrammablePulseLength_8) || \
                                                      ((value) == MAC_ProgrammablePulseLength_16) || \
                                                      ((value) == MAC_ProgrammablePulseLength_32))

#define IS_VALID_MAC_DATA_ENDIAN(value)          (((value) == MAC_DataEndianMode_Big) || \
                                                 ((value) == MAC_DataEndianMode_Little))

#define IS_VALID_MAC_BUS_ARBITRATION_SCHEME(value)   (((value) == MAC_BuArbitrations_EqualPriority) || \
                                                  ((value) == MAC_BusArbitration_Intelligent))

#define IS_VALID_MAC_RECEIVE_ALL(value)            (((value) == MAC_ReceiveAll_Enable) || \
                                                  ((value) == MAC_ReceiveAll_Disable))

#define IS_VALID_MAC_FIFO_THRESHOLD_MODE(value)     (((value) == MAC_FIFOThreshold_100M) || \
                                                  ((value) == MAC_FIFOThreshold_10M))

#define IS_VALID_MAC_STORE_AND_FORWARD(value)       (((value) == MAC_StoreandForward_Enable) || \
                                                  ((value) == MAC_StoreandForward_Disable))

#define IS_VALID_MAC_THRESHOLD_CONTROL_BITS(value)  (((value) == MAC_ThresholdControlBits_Enable) || \
                                                  ((value) == MAC_ThresholdControlBits_Disable))

#define IS_VALID_MAC_TRANSMIT_MODE(value)             (((value) == MAC_TransmitMode_HalfDuplex) || \
                                                      ((value) == MAC_TransmitMode_FullDuplex))

#define IS_VALID_MAC_PASSALL_MULTICASTS(value)       (((value) == MAC_PassAllMulticasts_Disable) || \
                                                     ((value) == MAC_PassAllMulticasts_Enable))

#define IS_VALID_MAC_PROMISCUOUS_MODE(value)         (((value) == MAC_PromiscuousMode_Disable) || \
                                                     ((value) == MAC_PromiscuousMode_Enable))

#define IS_VALID_MAC_PASS_BAD_FRAME(value)            (((value) == MAC_PassBadFrame_Disable) || \
                                                     ((value) == MAC_PassBadFrame_Enable))

#define IS_VALID_MAC_TIMERWORK_MODE(value)           (((value) == MAC_TimerWorkMode_OneShot) || \
                                                     ((value) == MAC_TimerWorkMode_Continuous))

#define IS_VALID_MAC_PHY_ADDRESS(ADDRESS)           ((ADDRESS) <= 0x1FU)

#define IS_MAC_PROCESS(value)                       (((value) == MAC_PROCESS_RECEIVE) || \
                                                     ((value) == MAC_PROCESS_TRANSMIT))

#define IS_MAC_IT(value)                            (((value) == MAC_IT_NIE) || \
                                                     ((value) == MAC_IT_AIE) || \
                                                     ((value) == MAC_IT_ERE) || \
                                                     ((value) == MAC_IT_GTE) || \
                                                     ((value) == MAC_IT_ETE) || \
                                                     ((value) == MAC_IT_RSE) || \
                                                     ((value) == MAC_IT_RUE) || \
                                                     ((value) == MAC_IT_RIE) || \
                                                     ((value) == MAC_IT_UNE) || \
                                                     ((value) == MAC_IT_TUE) || \
                                                     ((value) == MAC_IT_TSE) || \
                                                     ((value) == MAC_IT_TIE))

#define IS_MAC_FLAG(value)                         (((value) == MAC_Flag_NIS) || \
                                                    ((value) == MAC_Flag_AIS) || \
                                                    ((value) == MAC_Flag_ERI) || \
                                                    ((value) == MAC_Flag_GTE) || \
                                                    ((value) == MAC_Flag_ETI) || \
                                                    ((value) == MAC_Flag_RPS) || \
                                                    ((value) == MAC_Flag_RU)  || \
                                                    ((value) == MAC_Flag_RI)  || \
                                                    ((value) == MAC_Flag_UNF) || \
                                                    ((value) == MAC_Flag_TU)  || \
                                                    ((value) == MAC_Flag_TPS) || \
                                                    ((value) == MAC_Flag_TI))

#define IS_MAC_ClearIT(value)                          (((value) == MAC_IT_NIS) || \
                                                    ((value) == MAC_IT_AIS) || \
                                                    ((value) == MAC_IT_ERI) || \
                                                    ((value) == MAC_IT_GTE) || \
                                                    ((value) == MAC_IT_ETI) || \
                                                    ((value) == MAC_IT_RPS) || \
                                                    ((value) == MAC_IT_RU)  || \
                                                    ((value) == MAC_IT_RI)  || \
                                                    ((value) == MAC_IT_UNF) || \
                                                    ((value) == MAC_IT_TU)  || \
                                                    ((value) == MAC_IT_TPS) || \
                                                    ((value) == MAC_IT_TI))
/**
  * @}
  */

/**
  * @}
  */

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_MAC_H */

/*****END OF FILE*****/
