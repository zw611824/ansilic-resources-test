/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_adc.c
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.6
 * Date:   2026/10/28
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/20     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.1     implement the ADC DMA transfer (HAL_ADC_Start_DMA) and the DMA callbacks
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.2     add the module guard (HAL_ADC_MODULE_ENABLED) around the whole implementation
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.3     put the as32x601_hal.h include first (module switch from the conf) before the module headers
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.4     apply the resource lock / RTOS rules:
 *                                                       run the MSP callbacks outside the
 *                                                       locked region, add the shared lock
 *                                                       helper with a Timeout and a
 *                                                       NULL-mutex guard, protect every
 *                                                       register writing interface, add the
 *                                                       busy / reset state gate, return
 *                                                       HAL_StatusTypeDef from the flag
 *                                                       clear / wait interfaces with
 *                                                       run-time parameter validation and
 *                                                       make the polling loops yield in an
 *                                                       RTOS build
 *     ANSILIC APPLICATION GROUP  2026/10/19     1.5     merge the former as32x601_hal_adc_ex implementation into this file (injected group, analog
 *                                                       monitor, temperature sensor, external reference buffer and high impedance status, parity and
 *                                                       channel helpers, sequence result, average and temperature conversion) and drop the Ex suffix
 *                                                       from every identifier (the merge itself was performed on 2026/10/19)
 *     ANSILIC APPLICATION GROUP  2026/10/28     1.6     apply the double version comparison report: StructInit fills a sequence length of one (P3-2),
 *                                                       GetAverageValue takes the lock and the state gate and waits with a bounded per sample budget
 *                                                       with an RTOS yield (P3-3), ConvertToTemperature validates its input (P3-4), PollForConversion
 *                                                       merges the timeout into the state bitset instead of assigning the whole word (P3'-1),
 *                                                       Start_DMA snapshots and restores the DMA channel fields and the request bit and the DMA-less
 *                                                       build publishes the DMA error code (P3'-2), the data register field macros follow the renamed
 *                                                       device layer names (ADC_RDR_* / ADC_IDR_*), and the blocking annotations match the header one
 *                                                       to one (P3'-5)

 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Analog to Digital
 *                  Converter (ADC) peripheral:
 *                  - Initialization and de-initialization functions
 *                    (HAL_ADC_Init / HAL_ADC_DeInit + weak MSP hooks);
 *                  - IO operation functions (HAL_ADC_Start / HAL_ADC_Stop /
 *                    HAL_ADC_PollForConversion / HAL_ADC_GetValue, interrupt
 *                    mode with HAL_ADC_Start_IT / HAL_ADC_Stop_IT /
 *                    HAL_ADC_IRQHandler, DMA API skeleton);
 *                  - Peripheral Control functions (HAL_ADC_ConfigChannel /
 *                    HAL_ADC_StructInit / HAL_ADC_GetConfig);
 *                  - Peripheral State and Errors functions (HAL_ADC_GetState /
 *                    HAL_ADC_GetError).
 *                  The chip-specific extended features (injected group,
 *                  analog monitor, temperature sensor, ...) are provided by this
 *                  driver.
 *                  HAL_ADC_MspInit() must be overridden by the user to enable
 *                  the ADC peripheral clock and release its bus reset through
 *                  the SMU HAL macros, e.g. for ADC0:
 *                    __HAL_SMU_ADC0_CLK_ENABLE();
 *                    __HAL_SMU_ADC0_RELEASE_RESET();
 *                  (ADC0/ADC1 clock gates are in SMU->ALB1CFGR, bits
 *                  SMU_ALB1CFGR_ADC0EN/ADC0RST and ADC1EN/ADC1RST).
 */
#include "as32x601_hal.h"           /* module switch from as32x601_hal_conf.h */
#include "as32x601_hal_adc.h"       /* ADC HAL API and register macros         */
#ifdef HAL_DMA_MODULE_ENABLED
#include "as32x601_hal_dma.h"
#endif

/* The HAL_ADC_MODULE_ENABLED switch is provided by the user configuration
 * file (as32x601_hal_conf.h, included above through as32x601_hal.h): the
 * whole implementation is compiled only while the module is enabled. */
#ifdef HAL_ADC_MODULE_ENABLED

/* Private functions prototypes ---------------------------------------------*/
static FlagStatus ADC_GetFlagStatusInternal(ADC_HandleTypeDef *hadc, uint8 ADC_FLAG, uint32 Rank);
static void ADC_ClearFlagInternal(ADC_HandleTypeDef *hadc, uint8 ADC_FLAG, uint32 Rank);
static void ADC_Init(ADC_HandleTypeDef *hadc);
#ifdef HAL_DMA_MODULE_ENABLED
static void ADC_DMAConvCplt(DMA_HandleTypeDef *hdma);
static void ADC_DMAHalfConvCplt(DMA_HandleTypeDef *hdma);
static void ADC_DMAError(DMA_HandleTypeDef *hdma);
#endif
/* ADC_InitDelayus, ADC_HandleIsValid, ADC_CheckState, ADC_LockHandle and
   ADC_UnlockHandle are shared by every entry point: they are declared in
   the header shared internal functions section. */

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Check whether the ADC handle and its instance are valid.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
uint32 ADC_HandleIsValid(ADC_HandleTypeDef *hadc)
{
    if (hadc == NULL_PTR)
    {
        return 0U;
    }

    if (IS_ADC_ALL_INSTANCE(hadc->Instance) == 0U)
    {
        return 0U;
    }

    return 1U;
}

/**
 * @brief  Check whether the handle accepts a new operation.
 * @note   Architecture constraint ARCH-CONST-09: a handle that is busy (an
 *         operation is ongoing in another context) rejects any other operation
 *         with HAL_BUSY, and a handle that is not initialized (RESET) requires
 *         HAL_ADC_Init() first and is rejected with HAL_ERROR. The recoverable
 *         states (TIMEOUT / ERROR_x) accept a new operation directly, so that
 *         no DeInit / Init round trip is required.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK (accepted) / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef ADC_CheckState(ADC_HandleTypeDef *hadc)
{
    if ((hadc->State & (HAL_ADC_STATE_BUSY_INTERNAL | HAL_ADC_STATE_REG_BUSY |
                        HAL_ADC_STATE_INJ_BUSY)) != 0U)
    {
        return HAL_BUSY;
    }

    if (hadc->State == HAL_ADC_STATE_RESET)
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Read one ADC flag (lock free kernel of HAL_ADC_GetFlagStatus).
 * @note   The EOC flag is a per-rank flag (RSQR / ISQR), the other flags live
 *         in the STATE register. This helper takes no lock and changes no
 *         handle state, so it is callable from a locked region and from an
 *         interrupt service routine.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure.
 * @param  ADC_FLAG: specifies the flag to check.
 * @param  Rank: sequence rank (only for ADC_FLAG_EOC).
 * @retval FlagStatus: SET or RESET.
 */
static FlagStatus ADC_GetFlagStatusInternal(ADC_HandleTypeDef *hadc, uint8 ADC_FLAG, uint32 Rank)
{
    FlagStatus bitstatus = RESET;

    if (ADC_FLAG == ADC_FLAG_EOC)
    {
        if (Rank < ADC_REGULAR_SEQ_NUM)
        {
            bitstatus = (FlagStatus)(READ_BIT(hadc->Instance->RSQR[Rank], ADC_RSQR_EOC) >> ADC_RSQR_EOC_Pos);
        }
        else if (IS_ADC_INJECT_RANK(Rank))
        {
            bitstatus = (FlagStatus)(READ_BIT(hadc->Instance->ISQR[Rank - ADC_ISEQ_0],
                                               ADC_ISQR_EOC) >> ADC_ISQR_EOC_Pos);
        }
        else
        {
            /* Nothing to do */
        }
    }
    else
    {
        if (READ_BIT(hadc->Instance->STATE, (uint32)ADC_FLAG) != 0U)
        {
            bitstatus = SET;
        }
    }

    return bitstatus;
}

/**
 * @brief  Clear one ADC flag (lock free kernel of HAL_ADC_ClearFlag).
 * @note   The STATE register flags are cleared by writing 0 to the flag bit,
 *         the EOC flags by writing 1 to the RSQR / ISQR EOC bit. This helper
 *         takes no lock and changes no handle state, so it is callable from a
 *         locked region and from an interrupt service routine.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure.
 * @param  ADC_FLAG: specifies the flag to clear.
 * @param  Rank: sequence rank (only for ADC_FLAG_EOC).
 * @retval None
 */
static void ADC_ClearFlagInternal(ADC_HandleTypeDef *hadc, uint8 ADC_FLAG, uint32 Rank)
{
    if (ADC_FLAG == ADC_FLAG_EOC)
    {
        if (Rank < ADC_REGULAR_SEQ_NUM)
        {
            /* Clear the EOC flag of the regular rank (write-1 to clear) */
            SET_BIT(hadc->Instance->RSQR[Rank], ADC_RSQR_EOC);
        }
        else if (IS_ADC_INJECT_RANK(Rank))
        {
            /* Clear the EOC flag of the injected rank (write-1 to clear) */
            SET_BIT(hadc->Instance->ISQR[Rank - ADC_ISEQ_0], ADC_ISQR_EOC);
        }
        else
        {
            /* Nothing to do */
        }
    }
    else
    {
        /* Clear the STATE register flag (write-0 to clear) */
        CLEAR_BIT(hadc->Instance->STATE, (uint32)ADC_FLAG);
    }
}

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_ADC_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; when the mutex is not acquired before the
 *         Timeout expires, HAL_TIMEOUT is returned. The value is passed to
 *         HAL_MutexAcquire() as is (RTOS ticks; with the usual 1 ms tick it is
 *         the same quantity as the millisecond Timeout of the public API, and
 *         HAL_MAX_DELAY means an infinite wait).
 * @param  hadc: pointer to an ADC_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef ADC_LockHandle(ADC_HandleTypeDef *hadc, uint32 Timeout)
{
#if (USE_RTOS == 1)
    if (hadc->LockMutex == NULL_PTR)
    {
        /* The porting layer did not create the mutex (e.g. HAL_ADC_MspInit()
         * was not overridden): report it instead of calling the RTOS with a
         * NULL handle */
        return HAL_ERROR;
    }

    return HAL_MutexAcquire(hadc->LockMutex, Timeout);
#else
    /* Prevent unused argument compilation warning: the bare-metal lock flag
     * either succeeds immediately or reports HAL_BUSY, it never waits */
    UNUSED(Timeout);

    if (hadc->Lock == HAL_LOCKED)
    {
        return HAL_BUSY;
    }

    hadc->Lock = HAL_LOCKED;

    return HAL_OK;
#endif /* USE_RTOS */
}

/**
 * @brief  Unlock the handle.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure.
 * @retval None
 */
void ADC_UnlockHandle(ADC_HandleTypeDef *hadc)
{
#if (USE_RTOS == 1)
    (void)HAL_MutexRelease(hadc->LockMutex);
#else
    hadc->Lock = HAL_UNLOCKED;
#endif /* USE_RTOS */
}

/* Exported functions ---------------------------------------------------------*/

/** @defgroup ADC_Exported_Functions ADC Exported Functions
  * @{
  */

/** @defgroup ADC_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Initialize the ADC peripheral according to the specified parameters (NON-BLOCKING)
 *         in the hadc->Init structure (clock divide, resolution, alignment,
 *         symbol, triggers, modes, sequence lengths, power) and initialize
 *         the low level hardware.
 * @note   The register write sequence of the device layer initialization is
 *         applied unchanged. Two device layer defects are fixed here: the
 *         ADC_BufEn field is applied with a modify (clear then set) instead
 *         of a read-modify-write OR, and a sequence length of 0 no longer
 *         underflows the SQL register writes (the sequence length field is
 *         left unchanged in that case).
 * @note   The parameters and the configuration structure metafields (Size /
 *         Version) are validated at run time: an invalid configuration is
 *         rejected with HAL_ERROR and HAL_ADC_ERROR_INVALID_PARAM without
 *         taking the lock and without changing the handle state.
 * @note   LOCK-06: the low level initialization (HAL_ADC_MspInit()) runs
 *         before the handle is locked, so that an override which calls other
 *         HAL APIs (e.g. HAL_GPIO_Init()) cannot deadlock.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (NULL pointer, invalid instance or invalid
 *         configuration)
 */
HAL_StatusTypeDef HAL_ADC_Init(ADC_HandleTypeDef *hadc)
{
    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_ADC_CLK_DIVIDE(hadc->Init.ADC_ClockDivide));
    assert_param(IS_ADC_RESOLUTION(hadc->Init.ADC_Resolution));
    assert_param(IS_ADC_ALIGN(hadc->Init.ADC_Alignment));
    assert_param(IS_ADC_SELDO(hadc->Init.ADC_Symbol));
    assert_param(IS_ADC_SELVIHDLS(hadc->Init.ADC_SelvihdlsRef));
    assert_param(IS_ADC_BitAction(hadc->Init.ADC_VrefbiEnable));
    assert_param(IS_ADC_TTRIM(hadc->Init.ADC_TtrimRef));
    assert_param(IS_ADC_VTRIM(hadc->Init.ADC_VtrimRef));
    assert_param(IS_ADC_SELVREFBI(hadc->Init.ADC_SelvRefbiRef));
    assert_param(IS_ADC_BitAction(hadc->Init.ADC_ScanModeEn));
    assert_param(IS_ADC_BitAction(hadc->Init.ADC_ContinuousModeEn));
    assert_param(IS_ADC_BitAction(hadc->Init.ADC_RegularDiscontinuousModeEn));
    assert_param(IS_ADC_BitAction(hadc->Init.ADC_InjectDiscontinuousModeEn));
    assert_param(IS_ADC_BitAction(hadc->Init.ADC_InjectAutoModeEn));
    assert_param(IS_ADC_BitAction(hadc->Init.ADC_IntervalModeEn));
    assert_param(ADC_REGULAR_DISCNUM >= hadc->Init.ADC_RegularDiscontinuousNum);
    assert_param(IS_ADC_TRIGGER(hadc->Init.ADC_RegularTrigger));
    assert_param(IS_ADC_TRIGGER(hadc->Init.ADC_InjectTrigger));
    assert_param(IS_ADC_BitAction(hadc->Init.ADC_RegularEnable));
    assert_param(IS_ADC_BitAction(hadc->Init.ADC_InjectEnable));
    assert_param(IS_ADC_BitAction(hadc->Init.ADC_DmaEnable));
    assert_param(ADC_REGULAR_SEQUENCE_LENGTH >= hadc->Init.ADC_RegularSequenceLength);
    assert_param(ADC_INJECT_SEQUENCE_LENGTH >= hadc->Init.ADC_InjectSequenceLength);
    assert_param(IS_ADC_BitAction(hadc->Init.ADC_PowerEn));
    assert_param(IS_ADC_BitAction(hadc->Init.ADC_PowerRegain));
    assert_param(IS_ADC_BitAction(hadc->Init.ADC_BufEn));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((hadc->Init.Size != sizeof(ADC_InitTypeDef)) ||
        (hadc->Init.Version != ADC_INIT_VERSION) ||
        (IS_ADC_CLK_DIVIDE(hadc->Init.ADC_ClockDivide) == 0U) ||
        (IS_ADC_RESOLUTION(hadc->Init.ADC_Resolution) == 0U) ||
        (IS_ADC_ALIGN(hadc->Init.ADC_Alignment) == 0U) ||
        (IS_ADC_SELDO(hadc->Init.ADC_Symbol) == 0U) ||
        (IS_ADC_TRIGGER(hadc->Init.ADC_RegularTrigger) == 0U) ||
        (IS_ADC_TRIGGER(hadc->Init.ADC_InjectTrigger) == 0U) ||
        (hadc->Init.ADC_RegularDiscontinuousNum > ADC_REGULAR_DISCNUM) ||
        (hadc->Init.ADC_RegularSequenceLength > ADC_REGULAR_SEQUENCE_LENGTH) ||
        (hadc->Init.ADC_InjectSequenceLength > ADC_INJECT_SEQUENCE_LENGTH) ||
        (hadc->Init.ADC_RegularSequenceLength == 0U) ||
        (hadc->Init.ADC_InjectSequenceLength == 0U))
    {
        hadc->ErrorCode |= HAL_ADC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Allocate the lock resource before the first use, so that a handle that
     * was never initialized cannot report HAL_BUSY from a stale Lock field */
    if (hadc->State == HAL_ADC_STATE_RESET)
    {
        hadc->Lock = HAL_UNLOCKED;

        /* Init the low level hardware (peripheral clock / reset release).
         * LOCK-06: the MSP callback runs before the handle is locked */
        HAL_ADC_MspInit(hadc);
    }

    /* Process locked */
    if (ADC_LockHandle(hadc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Set ADC state to the internal busy state */
    hadc->State = HAL_ADC_STATE_BUSY_INTERNAL;

    /* Set ADC error code to none */
    hadc->ErrorCode = HAL_ADC_ERROR_NONE;

    /* Apply the initialization parameters to the registers */
    ADC_Init(hadc);

    /* Set the ADC state */
    hadc->State = HAL_ADC_STATE_READY;

    /* Release Lock */
    ADC_UnlockHandle(hadc);

    /* Return function status */
    return HAL_OK;
}

/**
 * @brief  De-initialize the ADC peripheral registers to their default reset (NON-BLOCKING)
 *         values.
 * @note   The ADC_CTRL1.RESETN bit is kept unchanged (the reset state is
 *         handled by HAL_ADC_MspDeInit() through the SMU bus reset). The
 *         ADC_CONFIG register is cleared as well (built-in reference,
 *         temperature sensor, buffer and high-resistance settings).
 * @note   The call is accepted from any handle state, so that a failed
 *         initialization can always be undone; the handle goes back to the
 *         RESET state so that a following HAL_ADC_Init() re-runs
 *         HAL_ADC_MspInit().
 * @note   LOCK-06: the low level de-initialization (HAL_ADC_MspDeInit()) runs
 *         after the unlock, so that an override which calls other HAL APIs
 *         (e.g. HAL_GPIO_DeInit()) cannot deadlock.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (NULL pointer or invalid instance)
 */
HAL_StatusTypeDef HAL_ADC_DeInit(ADC_HandleTypeDef *hadc)
{
    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return HAL_ERROR;
    }

    /* Process locked. ARCH-CONST-09: the de-initialization is callable from
     * any handle state, so that a failed initialization can always be undone */
    if (ADC_LockHandle(hadc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Change ADC state to the internal busy state */
    hadc->State = HAL_ADC_STATE_BUSY_INTERNAL;

    /* Disable the ADC peripheral */
    __HAL_ADC_DISABLE(hadc);

    /* Restore the control registers to their default values. The
     * ADC_CTRL1.RESETN bit is kept unchanged: the reset state is handled by
     * HAL_ADC_MspDeInit() through the SMU bus reset macros. */
    CLEAR_BIT(hadc->Instance->CTRL1, (ADC_CTRL1_ADON | ADC_CTRL1_PSC | ADC_CTRL1_RESL));
    WRITE_REG(hadc->Instance->CTRL0, 0x00U);
    WRITE_REG(hadc->Instance->CONFIG, 0x00U);
    WRITE_REG(hadc->Instance->AMOCR, 0x00U);
    WRITE_REG(hadc->Instance->SQL, 0x00U);

    /* Set ADC error code to none */
    hadc->ErrorCode = HAL_ADC_ERROR_NONE;

    /* Change ADC state */
    hadc->State = HAL_ADC_STATE_RESET;

    /* Release Lock */
    ADC_UnlockHandle(hadc);

    /* LOCK-06 / ARCH-CONST-04: the low level de-initialization runs OUTSIDE
     * the locked region, as the architecture specification requires for the
     * MSP callbacks ("MspDeInit is called after the unlock") */
    HAL_ADC_MspDeInit(hadc);

    /* Return function status */
    return HAL_OK;
}

/**
 * @brief  Initialize the ADC MSP (peripheral clock enable, reset release).
 * @note   This function should not be modified: when the MSP initialization
 *         is needed, HAL_ADC_MspInit() should be implemented in the user file
 *         (e.g. call __HAL_SMU_ADC0_CLK_ENABLE() / __HAL_SMU_ADC0_RELEASE_RESET()
 *         for ADC0, or the ADC1 counterparts for ADC1).
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval None
 */
__weak void HAL_ADC_MspInit(ADC_HandleTypeDef *hadc)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(hadc);

    /* NOTE : This function should not be modified, when the callback is needed,
              the HAL_ADC_MspInit could be implemented in the user file
    */
}

/**
 * @brief  De-initialize the ADC MSP (peripheral clock disable, reset assert).
 * @note   This function should not be modified: when the MSP de-initialization
 *         is needed, HAL_ADC_MspDeInit() should be implemented in the user file
 *         (e.g. call __HAL_SMU_ADC0_FORCE_RESET() / __HAL_SMU_ADC0_CLK_DISABLE()
 *         for ADC0, or the ADC1 counterparts for ADC1).
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval None
 */
__weak void HAL_ADC_MspDeInit(ADC_HandleTypeDef *hadc)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(hadc);

    /* NOTE : This function should not be modified, when the callback is needed,
              the HAL_ADC_MspDeInit could be implemented in the user file
    */
}

/**
  * @}
  */

/** @defgroup ADC_Exported_Functions_Group2 IO operation functions
  * @{
  */

/**
 * @brief  Enable the ADC (if not already powered) and start a regular group (NON-BLOCKING)
 *         conversion with the configured trigger source (software start for
 *         an internal trigger).
 * @note   The ADC analog power is switched on when needed (ADON) and a
 *         stabilization delay is applied before the software start.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_ADC_Init() is required first).
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance or the handle is not initialized)
 */
HAL_StatusTypeDef HAL_ADC_Start(ADC_HandleTypeDef *hadc)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_ADC_Init() is
     * required first) */
    status = ADC_CheckState(hadc);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (ADC_LockHandle(hadc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Enable the ADC peripheral if not already powered, and wait the
     * stabilization time (ADC_CTRL1.ADON bit) */
    if (READ_BIT(hadc->Instance->CTRL1, ADC_CTRL1_ADON) == 0U)
    {
        __HAL_ADC_ENABLE(hadc);
        ADC_InitDelayus(ADC_STAB_DELAY_US);
    }

    /* Set ADC state: clear the ready and end of conversion states, set the
     * regular group busy state */
    MODIFY_REG(hadc->State,
               (HAL_ADC_STATE_READY | HAL_ADC_STATE_REG_EOC | HAL_ADC_STATE_INJ_EOC),
               HAL_ADC_STATE_REG_BUSY);

    /* Reset the current conversion rank to the first regular rank */
    hadc->NbrOfCurrentConversionRank = ADC_RSEQ_0;

    /* Reset the ADC error code */
    hadc->ErrorCode = HAL_ADC_ERROR_NONE;

    /* Release Lock */
    ADC_UnlockHandle(hadc);

    /* Start the regular group conversion by software (the SWSTART bit is a
     * write-1 trigger, it is harmless in continuous mode) */
    SET_BIT(hadc->Instance->CTRL0, ADC_CTRL0_SWSTART);

    /* Return function status */
    return HAL_OK;
}

/**
 * @brief  Disable the ADC and stop the conversions of both groups. (NON-BLOCKING)
 * @note   The ADC analog power is switched off (ADON cleared). The regular
 *         and injected groups stop converting.
 * @note   The call is accepted from any initialized handle state, so that a
 *         running conversion can always be stopped.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance or the handle is not initialized)
 */
HAL_StatusTypeDef HAL_ADC_Stop(ADC_HandleTypeDef *hadc)
{
    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return HAL_ERROR;
    }

    if (hadc->State == HAL_ADC_STATE_RESET)
    {
        return HAL_ERROR;
    }

    /* Process locked */
    if (ADC_LockHandle(hadc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the software start triggers and disable the ADC peripheral */
    CLEAR_BIT(hadc->Instance->CTRL0, (ADC_CTRL0_SWSTART | ADC_CTRL0_ISWSTART));
    __HAL_ADC_DISABLE(hadc);

    /* Set ADC state: clear the busy states, set the ready state */
    MODIFY_REG(hadc->State,
               (HAL_ADC_STATE_REG_BUSY | HAL_ADC_STATE_INJ_BUSY),
               HAL_ADC_STATE_READY);

    /* Release Lock */
    ADC_UnlockHandle(hadc);

    /* Return function status */
    return HAL_OK;
}

/**
 * @brief  Poll for the end of conversion of the current regular rank (BLOCKING)
 *         (hadc->NbrOfCurrentConversionRank, advanced by HAL_ADC_GetValue()).
 * @note   The end of conversion flag is a per-rank flag in this device
 *         (RSQR[rank].EOC), therefore the polling target is the current rank
 *         index of the handle. The flag is cleared when detected.
 * @note   The wait is bounded by the caller supplied Timeout, measured with
 *         the HAL 1 ms time base (HAL_GetTick()), so that a missing end of
 *         conversion cannot hang the MCU. HAL_MAX_DELAY waits forever; 0
 *         gives the hardware a single chance (no waiting).
 * @note   RTOS-04 / RTOS-05: in an RTOS build the other tasks of the same
 *         priority are allowed to run while waiting (HAL_RTOS_Yield(); the
 *         macro is empty in a bare-metal build).
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  Timeout: Timeout value in milliseconds.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (the end of conversion did
 *         not arrive in time, the state is then HAL_ADC_STATE_TIMEOUT and the
 *         error code HAL_ADC_ERROR_TIMEOUT) / HAL_BUSY / HAL_ERROR (NULL
 *         pointer, invalid instance, invalid rank or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_ADC_PollForConversion(ADC_HandleTypeDef *hadc, uint32 Timeout)
{
    uint32 tickstart = 0U;
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_ADC_SEQUENCE(hadc->NbrOfCurrentConversionRank));

    /* Runtime parameter validation (see HAL_ADC_Init()) */
    if ((IS_ADC_SEQUENCE(hadc->NbrOfCurrentConversionRank) == 0U) ||
        (hadc->State == HAL_ADC_STATE_RESET))
    {
        hadc->ErrorCode |= HAL_ADC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Process locked */
    if (ADC_LockHandle(hadc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Get the start time */
    tickstart = HAL_GetTick();

    /* Wait for the end of conversion of the current regular rank */
    while (ADC_GetFlagStatusInternal(hadc, ADC_FLAG_EOC, hadc->NbrOfCurrentConversionRank) == RESET)
    {
        /* Check for the timeout */
        if (Timeout != HAL_MAX_DELAY)
        {
            if ((Timeout == 0U) || ((HAL_GetTick() - tickstart) > Timeout))
            {
                status = HAL_TIMEOUT;
                break;
            }
        }

        /* ARCH/RTOS-04: let the other tasks of the same priority run instead of
         * busy waiting (empty macro in a bare-metal build) */
        HAL_RTOS_Yield();
    }

    if (status == HAL_OK)
    {
        /* Clear the end of conversion flag of the current rank */
        ADC_ClearFlagInternal(hadc, ADC_FLAG_EOC, hadc->NbrOfCurrentConversionRank);

        /* Update the ADC state: end of conversion reached for the regular group */
        MODIFY_REG(hadc->State,
                   (HAL_ADC_STATE_READY | HAL_ADC_STATE_TIMEOUT | HAL_ADC_STATE_REG_BUSY),
                   HAL_ADC_STATE_REG_EOC);
    }
    else
    {
        /* ARCH-CONST-09: the timeout state is recoverable. The State field is
         * a bitset, so the timeout is merged instead of being assigned to the
         * whole word: only this group's progress bits are dropped and the
         * timeout bit is added. The ready flag, the injected group bits, the
         * analog monitor bit and the error bits of other operations survive,
         * and the handle stays directly retryable (ADC-REQ-052). The former
         * whole word assignment erased all of them and, when no other bit
         * happened to be set, left the handle looking uninitialized (RESET) to
         * the state gate of every other interface. */
        hadc->ErrorCode |= HAL_ADC_ERROR_TIMEOUT;
        hadc->State &= ~(HAL_ADC_STATE_REG_BUSY | HAL_ADC_STATE_REG_EOC);
        hadc->State |= (HAL_ADC_STATE_READY | HAL_ADC_STATE_TIMEOUT);
    }

    /* Release Lock */
    ADC_UnlockHandle(hadc);

    /* Return function status */
    return status;
}

/**
 * @brief  Enable the ADC and start the regular group conversion in interrupt (NON-BLOCKING / IT)
 *         mode.
 * @note   The EOC interrupt of the regular ranks covered by
 *         Init.ADC_RegularSequenceLength is enabled, then the conversion is
 *         triggered. Each end of conversion raises HAL_ADC_ConvCpltCallback()
 *         from HAL_ADC_IRQHandler(). The injected group conversion can be
 *         started with HAL_ADC_InjectedStart(): its EOC interrupt is
 *         enabled per rank through the ADC_InterruptEn field of
 *         ADC_ChannelConfTypeDef.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_ADC_Init() is required first).
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance or the handle is not initialized)
 */
HAL_StatusTypeDef HAL_ADC_Start_IT(ADC_HandleTypeDef *hadc)
{
    uint32 index = 0U;
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_ADC_Init() is
     * required first) */
    status = ADC_CheckState(hadc);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (ADC_LockHandle(hadc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Enable the ADC peripheral if not already powered */
    if (READ_BIT(hadc->Instance->CTRL1, ADC_CTRL1_ADON) == 0U)
    {
        __HAL_ADC_ENABLE(hadc);
        ADC_InitDelayus(ADC_STAB_DELAY_US);
    }

    /* Enable the EOC interrupt of the configured regular ranks */
    for (index = 0U; index < (uint32)hadc->Init.ADC_RegularSequenceLength; index++)
    {
        SET_BIT(hadc->Instance->RSQR[index], ADC_RSQR_IE);
    }

    /* Set ADC state */
    MODIFY_REG(hadc->State,
               (HAL_ADC_STATE_READY | HAL_ADC_STATE_REG_EOC | HAL_ADC_STATE_INJ_EOC),
               HAL_ADC_STATE_REG_BUSY);

    /* Reset the current conversion rank to the first regular rank */
    hadc->NbrOfCurrentConversionRank = ADC_RSEQ_0;

    /* Reset the ADC error code */
    hadc->ErrorCode = HAL_ADC_ERROR_NONE;

    /* Release Lock */
    ADC_UnlockHandle(hadc);

    /* Start the regular group conversion by software */
    SET_BIT(hadc->Instance->CTRL0, ADC_CTRL0_SWSTART);

    /* Return function status */
    return HAL_OK;
}

/**
 * @brief  Disable the ADC interrupt mode of the regular group. (NON-BLOCKING / IT)
 * @note   The call is accepted from any initialized handle state.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance or the handle is not initialized)
 */
HAL_StatusTypeDef HAL_ADC_Stop_IT(ADC_HandleTypeDef *hadc)
{
    uint32 index = 0U;

    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return HAL_ERROR;
    }

    if (hadc->State == HAL_ADC_STATE_RESET)
    {
        return HAL_ERROR;
    }

    /* Process locked */
    if (ADC_LockHandle(hadc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Disable the EOC interrupt of the configured regular ranks */
    for (index = 0U; index < (uint32)hadc->Init.ADC_RegularSequenceLength; index++)
    {
        CLEAR_BIT(hadc->Instance->RSQR[index], ADC_RSQR_IE);
    }

    /* Set ADC state */
    MODIFY_REG(hadc->State,
               (HAL_ADC_STATE_REG_BUSY | HAL_ADC_STATE_INJ_BUSY),
               HAL_ADC_STATE_READY);

    /* Release Lock */
    ADC_UnlockHandle(hadc);

    /* Return function status */
    return HAL_OK;
}

/**
 * @brief  Handle the ADC interrupt request.
 * @note   The EOC flags of the 16 regular ranks and the 4 injected ranks are
 *         scanned: for each rank with the EOC flag and the IE bit set, the
 *         flag is cleared and the corresponding conversion complete callback
 *         is invoked. The analog monitor flag raises the out-of-window
 *         callback. This function must be called from the ADC0_IRQHandler /
 *         ADC1_IRQHandler interrupt service routines.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval None
 */
void HAL_ADC_IRQHandler(ADC_HandleTypeDef *hadc)
{
    uint32 rank = 0U;

    /* Check the ADC peripheral handle and instance. LOCK-04 / RTOS-12: the
     * interrupt service routine neither takes the handle lock nor calls a
     * locking interface */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return;
    }

    /* Scan the regular group ranks for end of conversion */
    for (rank = 0U; rank < ADC_REGULAR_SEQ_NUM; rank++)
    {
        if (READ_BIT(hadc->Instance->RSQR[rank], (ADC_RSQR_EOC | ADC_RSQR_IE)) == (ADC_RSQR_EOC | ADC_RSQR_IE))
        {
            /* Update the state machine and the current rank */
            MODIFY_REG(hadc->State,
                       (HAL_ADC_STATE_READY | HAL_ADC_STATE_REG_BUSY | HAL_ADC_STATE_TIMEOUT),
                       HAL_ADC_STATE_REG_EOC);
            hadc->NbrOfCurrentConversionRank = ADC_RSEQ_0 + rank;

            /* Clear the EOC flag (write-1 to clear) */
            SET_BIT(hadc->Instance->RSQR[rank], ADC_RSQR_EOC);

            /* Conversion complete callback */
            HAL_ADC_ConvCpltCallback(hadc);
        }
    }

    /* Scan the injected group ranks for end of conversion */
    for (rank = 0U; rank < ADC_INJECT_SEQ_NUM; rank++)
    {
        if (READ_BIT(hadc->Instance->ISQR[rank], (ADC_ISQR_EOC | ADC_ISQR_IE)) == (ADC_ISQR_EOC | ADC_ISQR_IE))
        {
            /* Update the state machine. The current rank index is not
             * modified: it is dedicated to the regular group polling /
             * reading cycle (HAL_ADC_PollForConversion / HAL_ADC_GetValue),
             * the injected rank is passed explicitly to the ex functions. */
            MODIFY_REG(hadc->State,
                       (HAL_ADC_STATE_READY | HAL_ADC_STATE_INJ_BUSY | HAL_ADC_STATE_TIMEOUT),
                       HAL_ADC_STATE_INJ_EOC);

            /* Clear the EOC flag (write-1 to clear) */
            SET_BIT(hadc->Instance->ISQR[rank], ADC_ISQR_EOC);

            /* Conversion complete callback */
            HAL_ADC_InjectedConvCpltCallback(hadc);
        }
    }

    /* Check the analog monitor flag (AMO event with interrupt enabled) */
    if (READ_BIT(hadc->Instance->STATE, ADC_STATE_AMO) != 0U)
    {
        if (READ_BIT(hadc->Instance->AMOCR, ADC_AMOCR_AMOIE) != 0U)
        {
            /* Set the AMO state */
            SET_BIT(hadc->State, HAL_ADC_STATE_AMO);

            /* Level out of window callback */
            HAL_ADC_LevelOutOfWindowCallback(hadc);

            /* Clear the analog monitor flag (write-0 to clear) */
            CLEAR_BIT(hadc->Instance->STATE, ADC_STATE_AMO);
        }
    }
}

/**
 * @brief  Enable the ADC and start the regular group conversion with DMA (NON-BLOCKING / DMA)
 *         transfer.
 * @note   The DMA channel referenced by hadc->hdma must be initialized
 *         (HAL_DMA_Init) and mapped to the ADC peripheral interface
 *         (HAL_DMA_ConfigPeriphIF). The channel data width must match the
 *         ADC data width. The transfer completion is reported by
 *         HAL_ADC_ConvCpltCallback().
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_ADC_Init() is required first).
 * @note   The DMA channel fields (parent, completion / half completion / error
 *         callbacks) and the ADC request bit are snapshotted before they are
 *         changed: when a callback registration or the channel start fails, the
 *         snapshot is restored and the request is reported as HAL_ERROR with
 *         HAL_ADC_ERROR_DMA.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  pData: The destination buffer address.
 * @param  Length: The length of data to be transferred from the ADC
 *         peripheral to memory.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, NULL buffer, zero length, no DMA channel assigned
 *         or the handle is not initialized)
 */
#ifdef HAL_DMA_MODULE_ENABLED
HAL_StatusTypeDef HAL_ADC_Start_DMA(ADC_HandleTypeDef *hadc, uint32 *pData, uint32 Length)
{
    HAL_StatusTypeDef status = HAL_OK;
    HAL_StatusTypeDef regStatus = HAL_OK;
    void *previousParent;
    void (*previousCplt)(struct __DMA_HandleTypeDef *hdma);
    void (*previousHalfCplt)(struct __DMA_HandleTypeDef *hdma);
    void (*previousError)(struct __DMA_HandleTypeDef *hdma);
    uint32 dmaenWasSet;

    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_ADC_ALL_INSTANCE(hadc->Instance));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03) */
    if ((pData == NULL_PTR) || (Length == 0U) || (hadc->hdma == NULL_PTR))
    {
        hadc->ErrorCode |= HAL_ADC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_ADC_Init() is
     * required first) */
    status = ADC_CheckState(hadc);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (ADC_LockHandle(hadc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Enable the ADC peripheral if not already powered */
    if (READ_BIT(hadc->Instance->CTRL1, ADC_CTRL1_ADON) == 0U)
    {
        __HAL_ADC_ENABLE(hadc);
        ADC_InitDelayus(ADC_STAB_DELAY_US);
    }

    /* Set ADC state: clear the ready and end of conversion states, set the
     * regular group busy state */
    MODIFY_REG(hadc->State,
               (HAL_ADC_STATE_READY | HAL_ADC_STATE_REG_EOC | HAL_ADC_STATE_INJ_EOC),
               HAL_ADC_STATE_REG_BUSY);

    /* Reset the current conversion rank to the first regular rank */
    hadc->NbrOfCurrentConversionRank = ADC_RSEQ_0;

    /* Reset the ADC error code */
    hadc->ErrorCode = HAL_ADC_ERROR_NONE;

    /* Snapshot the DMA channel fields and the ADC request bit of the caller
     * before any mutation, so that a failure of this call restores exactly what
     * it changed. The former implementation registered the three trampolines
     * and the parent pointer and, when the channel refused to start, left them
     * in place: the caller's channel kept pointing at this driver and its
     * callbacks stayed hijacked by the ADC. */
    previousParent      = hadc->hdma->Parent;
    previousCplt        = hadc->hdma->XferCpltCallback;
    previousHalfCplt    = hadc->hdma->XferHalfCpltCallback;
    previousError       = hadc->hdma->XferErrorCallback;
    dmaenWasSet         = READ_BIT(hadc->Instance->CTRL0, ADC_CTRL0_DMAEN);

    /* Set the DMA channel parent and register the callbacks (a rejected
     * registration is treated exactly like a rejected channel start) */
    hadc->hdma->Parent  = (void *)hadc;
    regStatus = HAL_DMA_RegisterCallback(hadc->hdma, HAL_DMA_XFER_CPLT_CB_ID, ADC_DMAConvCplt);
    if (regStatus == HAL_OK)
    {
        regStatus = HAL_DMA_RegisterCallback(hadc->hdma, HAL_DMA_XFER_HALFCPLT_CB_ID, ADC_DMAHalfConvCplt);
    }
    if (regStatus == HAL_OK)
    {
        regStatus = HAL_DMA_RegisterCallback(hadc->hdma, HAL_DMA_XFER_ERROR_CB_ID, ADC_DMAError);
    }

    /* Start the DMA transfer (ADC data register -> memory). A registration or a
     * channel start failure rolls the snapshot back, restores the ADC request
     * bit and reports the request as a DMA error. */
    if ((regStatus != HAL_OK) ||
        (HAL_DMA_Start_IT(hadc->hdma, (uint32)&hadc->Instance->RDR[0],
                          (uint32)pData, Length) != HAL_OK))
    {
        hadc->hdma->Parent                  = previousParent;
        hadc->hdma->XferCpltCallback        = previousCplt;
        hadc->hdma->XferHalfCpltCallback    = previousHalfCplt;
        hadc->hdma->XferErrorCallback       = previousError;
        MODIFY_REG(hadc->Instance->CTRL0, ADC_CTRL0_DMAEN, dmaenWasSet);

        /* The transfer never started: restore the ready state and report the
         * rejected request without touching the ADC request enable */
        hadc->ErrorCode |= HAL_ADC_ERROR_DMA;
        hadc->State = HAL_ADC_STATE_READY;

        /* Release Lock */
        ADC_UnlockHandle(hadc);

        return HAL_ERROR;
    }

    /* Enable the ADC DMA request */
    SET_BIT(hadc->Instance->CTRL0, ADC_CTRL0_DMAEN);

    /* Release Lock */
    ADC_UnlockHandle(hadc);

    /* Start the regular group conversion by software */
    SET_BIT(hadc->Instance->CTRL0, ADC_CTRL0_SWSTART);

    /* Return function status */
    return HAL_OK;
}
#else
HAL_StatusTypeDef HAL_ADC_Start_DMA(ADC_HandleTypeDef *hadc, uint32 *pData, uint32 Length)
{
    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return HAL_ERROR;
    }

    UNUSED(pData);
    UNUSED(Length);

    /* The DMA HAL module is not enabled: the DMA transfer cannot be started.
     * The rejected request is also published through the error code, so that a
     * caller that inspects HAL_ADC_GetError() sees the cause instead of only
     * the generic HAL_ERROR return value. */
    hadc->ErrorCode |= HAL_ADC_ERROR_DMA;

    return HAL_ERROR;
}
#endif

/**
 * @brief  Disable the ADC DMA mode of the regular group. (NON-BLOCKING / DMA)
 * @note   The call is accepted from any initialized handle state, so that a
 *         running transfer can always be stopped.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance or the handle is not initialized)
 */
HAL_StatusTypeDef HAL_ADC_Stop_DMA(ADC_HandleTypeDef *hadc)
{
    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return HAL_ERROR;
    }

    if (hadc->State == HAL_ADC_STATE_RESET)
    {
        return HAL_ERROR;
    }

    /* Process locked */
    if (ADC_LockHandle(hadc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Disable the ADC DMA request (ADC_CTRL0.DMAEN bit) */
    CLEAR_BIT(hadc->Instance->CTRL0, ADC_CTRL0_DMAEN);

#ifdef HAL_DMA_MODULE_ENABLED
    /* Abort the DMA channel so that no transfer keeps running. LOCK-06: the
     * DMA handle owns an independent lock, so aborting it while the ADC
     * handle is locked cannot deadlock */
    if (hadc->hdma != NULL_PTR)
    {
        (void)HAL_DMA_Abort(hadc->hdma);
    }
#endif /* HAL_DMA_MODULE_ENABLED */

    /* Restore the handle to the ready state */
    MODIFY_REG(hadc->State,
               (HAL_ADC_STATE_READY | HAL_ADC_STATE_REG_BUSY | HAL_ADC_STATE_INJ_BUSY | HAL_ADC_STATE_TIMEOUT),
               HAL_ADC_STATE_READY);

    /* Release Lock */
    ADC_UnlockHandle(hadc);

    /* Return function status */
    return HAL_OK;
}

/**
 * @brief  Return the conversion result of the current regular rank (NON-BLOCKING)
 *         (hadc->NbrOfCurrentConversionRank) and advance the rank index for
 *         the next polling / reading cycle.
 * @note   The rank index is advanced while it stays below
 *         Init.ADC_RegularSequenceLength, so that a Start / PollForConversion
 *         / GetValue loop covers the whole sequence. For an explicit rank
 *         read without advancing the handle, use HAL_ADC_GetSeqResult().
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval uint32: the conversion result (RDR[rank] data field).
 */
uint32 HAL_ADC_GetValue(ADC_HandleTypeDef *hadc)
{
    uint32 value = 0U;

    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return 0U;
    }

    /* Read the data of the current regular rank (the rank index is bound
     * checked against the regular data register array). No lock is taken: the
     * read neither waits nor sets a busy state, only the rank index of the
     * handle is advanced, so the interface stays callable at any time. */
    if (hadc->NbrOfCurrentConversionRank < ADC_REGULAR_SEQ_NUM)
    {
        value = READ_BIT(hadc->Instance->RDR[hadc->NbrOfCurrentConversionRank], ADC_RDR_RDR);

        /* Advance the current rank for the next polling / reading cycle */
        if ((hadc->Init.ADC_RegularSequenceLength > 1U) &&
            (hadc->NbrOfCurrentConversionRank < (uint32)(hadc->Init.ADC_RegularSequenceLength - 1U)))
        {
            hadc->NbrOfCurrentConversionRank++;
        }
    }

    /* Return the conversion result */
    return value;
}

/**
 * @brief  Conversion complete callback in non-blocking mode.
 * @note   This function should not be modified: when the callback is needed,
 *         HAL_ADC_ConvCpltCallback() could be implemented in the user file.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval None
 */
__weak void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(hadc);
}

/**
 * @brief  Half conversion complete callback.
 * @note   This function should not be modified: when the callback is needed,
 *         HAL_ADC_ConvHalfCpltCallback() could be implemented in the user
 *         file.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval None
 */
__weak void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef *hadc)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(hadc);
}

/**
 * @brief  Analog monitor out-of-window callback.
 * @note   This function should not be modified: when the callback is needed,
 *         HAL_ADC_LevelOutOfWindowCallback() could be implemented in the user
 *         file.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval None
 */
__weak void HAL_ADC_LevelOutOfWindowCallback(ADC_HandleTypeDef *hadc)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(hadc);
}

/**
 * @brief  Error callback.
 * @note   This function should not be modified: when the callback is needed,
 *         HAL_ADC_ErrorCallback() could be implemented in the user file.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval None
 */
__weak void HAL_ADC_ErrorCallback(ADC_HandleTypeDef *hadc)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(hadc);
}

/**
  * @}
  */

/** @defgroup ADC_Exported_Functions_Group3 Peripheral Control functions
  * @{
  */

/**
 * @brief  Initialize the ADC_InitTypeDef structure with default values. (NON-BLOCKING)
 * @note   The defaults match the register reset values of the device.
 * @param  ADC_InitStruct: pointer to an ADC_InitTypeDef structure that will
 *         be filled with the default configuration.
 * @retval None
 */
void HAL_ADC_StructInit(ADC_InitTypeDef *ADC_InitStruct)
{
    /* Check the ADC init structure allocation */
    if (ADC_InitStruct == NULL_PTR)
    {
        return;
    }

    /* Reset ADC init structure parameters values */
    ADC_InitStruct->Size                           = sizeof(ADC_InitTypeDef);
    ADC_InitStruct->Version                        = ADC_INIT_VERSION;

    ADC_InitStruct->ADC_ClockDivide                = ADC_CLK_DIVIDE_1;
    ADC_InitStruct->ADC_Resolution                 = ADC_RESOLUTION_12BIT;
    ADC_InitStruct->ADC_Alignment                  = ADC_DATA_ALIGN_RIGHT;
    ADC_InitStruct->ADC_Symbol                     = ADC_DATA_SELDO_UNSIGNED;

    ADC_InitStruct->ADC_RegularTrigger             = ADC_TRIGGER_INTERNAL;
    ADC_InitStruct->ADC_InjectTrigger              = ADC_TRIGGER_INTERNAL;

    ADC_InitStruct->ADC_RegularEnable              = DISABLE;
    ADC_InitStruct->ADC_InjectEnable               = DISABLE;

    ADC_InitStruct->ADC_DmaEnable                  = DISABLE;

    ADC_InitStruct->ADC_TtrimRef                   = ADC_TTRIM_7;
    ADC_InitStruct->ADC_VtrimRef                   = ADC_VTRIM_14;
    ADC_InitStruct->ADC_SelvRefbiRef               = ADC_SEL_VREFBI_2V5;
    ADC_InitStruct->ADC_VrefbiEnable               = DISABLE;
    ADC_InitStruct->ADC_SelvihdlsRef               = ADC_SAR_INPUT_SINGLE_ENDED;

    /* Conversion mode */
    ADC_InitStruct->ADC_ScanModeEn                 = DISABLE;
    ADC_InitStruct->ADC_ContinuousModeEn           = DISABLE;
    ADC_InitStruct->ADC_RegularDiscontinuousModeEn = DISABLE;
    ADC_InitStruct->ADC_InjectDiscontinuousModeEn  = DISABLE;
    ADC_InitStruct->ADC_InjectAutoModeEn           = DISABLE;
    ADC_InitStruct->ADC_IntervalModeEn             = DISABLE;
    ADC_InitStruct->ADC_RegularDiscontinuousNum    = 0x00U;

    /* P3-2: a length of one is the only value that both matches the register
     * reset encoding (SQL.RSQL / SQL.ISQL = 0 means one conversion) and passes
     * the run-time validation of HAL_ADC_Init(), which rejects a zero length.
     * Filling zero here made the documented clear -> StructInit -> Init
     * sequence fail with HAL_ADC_ERROR_INVALID_PARAM, and
     * HAL_ADC_ConfigChannel() does not update the length, so the caller had to
     * repair the structure by hand before it could be initialized. */
    ADC_InitStruct->ADC_RegularSequenceLength      = 1U;
    ADC_InitStruct->ADC_InjectSequenceLength       = 1U;

    ADC_InitStruct->ADC_PowerEn                    = DISABLE;
    ADC_InitStruct->ADC_PowerRegain                = DISABLE;
    ADC_InitStruct->ADC_BufEn                      = DISABLE;
    ADC_InitStruct->Reserved[0]                    = 0U;
    ADC_InitStruct->Reserved[1]                    = 0U;
}

/**
 * @brief  Initialize the ADC_ChannelConfTypeDef structure with default (NON-BLOCKING)
 *         values.
 * @note   Fills the channel structure with safe defaults (channel disabled, sample
 *         time 3 cycles, interrupt disabled, first regular rank).
 * @param  sConfig: pointer to an ADC_ChannelConfTypeDef structure that will
 *         be filled with the default configuration.
 * @retval None
 */
void HAL_ADC_ChannelStructInit(ADC_ChannelConfTypeDef *sConfig)
{
    /* Reset the channel configuration structure parameters values */
    /* Check the sConfig handle allocation */
    if (sConfig == NULL_PTR)
    {
        return;
    }
    sConfig->ADC_Channel      = ADC_CH_DISABLE;
    sConfig->ADC_SampleTime   = ADC_SPT_CLK_3;
    sConfig->ADC_InterruptEn  = DISABLE;
    sConfig->Rank             = ADC_RSEQ_0;
}

/**
 * @brief  Configure the selected ADC regular / injected channel rank (NON-BLOCKING)
 *         (sample time, channel, EOC interrupt enable).
 * @note   The Rank field of the sConfig structure selects the sequence index
 *         to program (it replaces a separate sequence index parameter). The
 *         sample time is written to the SPT register indexed by the channel,
 *         the channel and the EOC interrupt enable are written to the RSQR
 *         (regular) or ISQR (injected) register of the selected rank.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_ADC_Init() is required first).
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  sConfig: pointer to an ADC_ChannelConfTypeDef structure that
 *         contains the configuration information for the selected rank.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_ADC_ConfigChannel(ADC_HandleTypeDef *hadc, ADC_ChannelConfTypeDef *sConfig)
{
    uint8 index = 0x00U;
    uint8 pos = 0x00U;
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the ADC peripheral handle and instance */
    if ((ADC_HandleIsValid(hadc) == 0U) || (sConfig == NULL_PTR))
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_ADC_INPUT_CH(sConfig->ADC_Channel));
    assert_param(IS_ADC_SAMPLE_TIME(sConfig->ADC_SampleTime));
    assert_param(IS_ADC_SEQUENCE(sConfig->Rank));
    assert_param(IS_ADC_BitAction(sConfig->ADC_InterruptEn));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((IS_ADC_INPUT_CH(sConfig->ADC_Channel) == 0U) ||
        (IS_ADC_SAMPLE_TIME(sConfig->ADC_SampleTime) == 0U) ||
        (IS_ADC_SEQUENCE(sConfig->Rank) == 0U))
    {
        hadc->ErrorCode |= HAL_ADC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Check the SAR input type selection: the differential mode cannot be
     * used with the internal channels */
    if (sConfig->ADC_Channel > ADC_CH_16)
    {
        assert_param(READ_BIT(hadc->Instance->CONFIG, ADC_CONFIG_SELVI_HD_LS) == 0U);

        if (READ_BIT(hadc->Instance->CONFIG, ADC_CONFIG_SELVI_HD_LS) != 0U)
        {
            hadc->ErrorCode |= HAL_ADC_ERROR_INVALID_PARAM;
            return HAL_ERROR;
        }
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_ADC_Init() is
     * required first) */
    status = ADC_CheckState(hadc);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (ADC_LockHandle(hadc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Set the sample time of the channel (SPT register, 4 bits per channel) */
    index = (uint8)(sConfig->ADC_Channel / ADC_EACH_REG_SPT_NUM);
    pos = (uint8)((sConfig->ADC_Channel % ADC_EACH_REG_SPT_NUM) * ADC_SPT_Width);
    MODIFY_REG(hadc->Instance->SPT[index], (ADC_SPT_SPT << pos),
               (((uint32)sConfig->ADC_SampleTime) << pos));

    /* Configure the sequence rank (regular or injected group) */
    if (sConfig->Rank < ADC_REGULAR_SEQ_NUM)
    {
        MODIFY_REG(hadc->Instance->RSQR[sConfig->Rank],
                   (ADC_RSQR_SEQ | ADC_RSQR_IE),
                   (((uint32)sConfig->ADC_Channel) << ADC_RSQR_SEQ_Pos) |
                   (((uint32)sConfig->ADC_InterruptEn) << ADC_RSQR_IE_Pos));
    }
    else if (IS_ADC_INJECT_RANK(sConfig->Rank))
    {
        MODIFY_REG(hadc->Instance->ISQR[sConfig->Rank - ADC_ISEQ_0],
                   (ADC_ISQR_SEQ | ADC_ISQR_IE),
                   (((uint32)sConfig->ADC_Channel) << ADC_ISQR_SEQ_Pos) |
                   (((uint32)sConfig->ADC_InterruptEn) << ADC_ISQR_IE_Pos));
    }
    else
    {
        /* Nothing to do */
    }

    /* Release Lock */
    ADC_UnlockHandle(hadc);

    /* Return function status */
    return HAL_OK;
}

/**
 * @brief  Get the configuration of the selected rank from the registers. (NON-BLOCKING)
 * @note   The rank to read is taken from the Rank field of the structure.
 * @note   The registers are read under the handle lock so that a concurrent
 *         configuration cannot produce a torn snapshot. No state gate is
 *         applied: a register snapshot is meaningful in every state.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  sConfig: pointer to an ADC_ChannelConfTypeDef structure that will
 *         be filled with the current register configuration (the Rank field
 *         must be preset to the rank to read).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance or invalid rank)
 */
HAL_StatusTypeDef HAL_ADC_GetChannelConfig(ADC_HandleTypeDef *hadc, ADC_ChannelConfTypeDef *sConfig)
{
    uint8 index = 0x00U;
    uint8 pos = 0x00U;

    /* Check the ADC peripheral handle and instance */
    if ((ADC_HandleIsValid(hadc) == 0U) || (sConfig == NULL_PTR))
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_ADC_SEQUENCE(sConfig->Rank));

    /* Runtime parameter validation */
    if (IS_ADC_SEQUENCE(sConfig->Rank) == 0U)
    {
        hadc->ErrorCode |= HAL_ADC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Process locked */
    if (ADC_LockHandle(hadc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Read the channel and the EOC interrupt enable of the selected rank */
    if (sConfig->Rank < ADC_REGULAR_SEQ_NUM)
    {
        sConfig->ADC_InterruptEn =
            (FunctionalState)(READ_BIT(hadc->Instance->RSQR[sConfig->Rank],
            ADC_RSQR_IE) >> ADC_RSQR_IE_Pos);
        sConfig->ADC_Channel = (uint32)READ_BIT(hadc->Instance->RSQR[sConfig->Rank], ADC_RSQR_SEQ);
    }
    else if (IS_ADC_INJECT_RANK(sConfig->Rank))
    {
        sConfig->ADC_InterruptEn =
            (FunctionalState)(READ_BIT(hadc->Instance->ISQR[sConfig->Rank - ADC_ISEQ_0],
            ADC_ISQR_IE) >> ADC_ISQR_IE_Pos);
        sConfig->ADC_Channel = (uint32)READ_BIT(hadc->Instance->ISQR[sConfig->Rank - ADC_ISEQ_0], ADC_ISQR_SEQ);
    }
    else
    {
        /* Nothing to do */
    }

    /* Read the sample time of the channel (SPT register) */
    index = (uint8)(sConfig->ADC_Channel / ADC_EACH_REG_SPT_NUM);
    pos = (uint8)((sConfig->ADC_Channel % ADC_EACH_REG_SPT_NUM) * ADC_SPT_Width);
    sConfig->ADC_SampleTime = (uint32)(READ_BIT(hadc->Instance->SPT[index], (ADC_SPT_SPT << pos)) >> pos);

    /* Release Lock */
    ADC_UnlockHandle(hadc);

    /* Return function status */
    return HAL_OK;
}

/**
 * @brief  Get the ADC converter configuration from the registers. (NON-BLOCKING)
 * @note   The hadc->Init structure is filled
 *         with the current register configuration.
 * @note   The registers are read under the handle lock so that a concurrent
 *         configuration cannot produce a torn snapshot. No state gate is
 *         applied: a register snapshot is meaningful in every state.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer or
 *         invalid instance)
 */
HAL_StatusTypeDef HAL_ADC_GetConfig(ADC_HandleTypeDef *hadc)
{
    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return HAL_ERROR;
    }

    /* Process locked */
    if (ADC_LockHandle(hadc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    hadc->Init.ADC_ClockDivide =
        (uint32)(READ_BIT(hadc->Instance->CTRL1,
        ADC_CTRL1_PSC) >> ADC_CTRL1_PSC_Pos);
    hadc->Init.ADC_Resolution =
        (uint32)(READ_BIT(hadc->Instance->CTRL1,
        ADC_CTRL1_RESL) >> ADC_CTRL1_RESL_Pos);
    hadc->Init.ADC_Alignment =
        (uint32)(READ_BIT(hadc->Instance->CTRL0,
        ADC_CTRL0_ALIGN) >> ADC_CTRL0_ALIGN_Pos);
    hadc->Init.ADC_Symbol =
        (uint32)(READ_BIT(hadc->Instance->CTRL0,
        ADC_CTRL0_SELDO) >> ADC_CTRL0_SELDO_Pos);

    hadc->Init.ADC_RegularTrigger =
        (uint32)(READ_BIT(hadc->Instance->CTRL0,
        ADC_CTRL0_TRIGSRC) >> ADC_CTRL0_TRIGSRC_Pos);
    hadc->Init.ADC_InjectTrigger =
        (uint32)(READ_BIT(hadc->Instance->CTRL0,
        ADC_CTRL0_ITRIGSRC) >> ADC_CTRL0_ITRIGSRC_Pos);

    hadc->Init.ADC_RegularEnable =
        (FunctionalState)(READ_BIT(hadc->Instance->CTRL0,
        ADC_CTRL0_TRIGEN) >> ADC_CTRL0_TRIGEN_Pos);
    hadc->Init.ADC_InjectEnable =
        (FunctionalState)(READ_BIT(hadc->Instance->CTRL0,
        ADC_CTRL0_ITRIGEN) >> ADC_CTRL0_ITRIGEN_Pos);

    hadc->Init.ADC_DmaEnable =
        (FunctionalState)(READ_BIT(hadc->Instance->CTRL0,
        ADC_CTRL0_DMAEN) >> ADC_CTRL0_DMAEN_Pos);

    hadc->Init.ADC_TtrimRef =
        (uint32)(READ_BIT(hadc->Instance->CONFIG,
        ADC_CONFIG_TTRIM) >> ADC_CONFIG_TTRIM_Pos);
    hadc->Init.ADC_VtrimRef =
        (uint32)(READ_BIT(hadc->Instance->CONFIG,
        ADC_CONFIG_VTRIM) >> ADC_CONFIG_VTRIM_Pos);
    hadc->Init.ADC_SelvRefbiRef =
        (uint32)(READ_BIT(hadc->Instance->CONFIG,
        ADC_CONFIG_SEL_VREFBI) >> ADC_CONFIG_SEL_VREFBI_Pos);
    hadc->Init.ADC_VrefbiEnable =
        (FunctionalState)(READ_BIT(hadc->Instance->CONFIG,
        ADC_CONFIG_EN_VREFBI) >> ADC_CONFIG_EN_VREFBI_Pos);
    hadc->Init.ADC_SelvihdlsRef =
        (uint32)(READ_BIT(hadc->Instance->CONFIG,
        ADC_CONFIG_SELVI_HD_LS) >> ADC_CONFIG_SELVI_HD_LS_Pos);

    hadc->Init.ADC_ScanModeEn =
        (FunctionalState)(READ_BIT(hadc->Instance->CTRL0,
        ADC_CTRL0_SCAN) >> ADC_CTRL0_SCAN_Pos);
    hadc->Init.ADC_ContinuousModeEn =
        (FunctionalState)(READ_BIT(hadc->Instance->CTRL0,
        ADC_CTRL0_CONT) >> ADC_CTRL0_CONT_Pos);
    hadc->Init.ADC_RegularDiscontinuousModeEn =
        (FunctionalState)(READ_BIT(hadc->Instance->CTRL0,
        ADC_CTRL0_DISCEN) >> ADC_CTRL0_DISCEN_Pos);
    hadc->Init.ADC_InjectDiscontinuousModeEn =
        (FunctionalState)(READ_BIT(hadc->Instance->CTRL0,
        ADC_CTRL0_IDISCEN) >> ADC_CTRL0_IDISCEN_Pos);
    hadc->Init.ADC_InjectAutoModeEn =
        (FunctionalState)(READ_BIT(hadc->Instance->CTRL0,
        ADC_CTRL0_IAUTO) >> ADC_CTRL0_IAUTO_Pos);
    hadc->Init.ADC_IntervalModeEn =
        (FunctionalState)(READ_BIT(hadc->Instance->CTRL0,
        ADC_CTRL0_INTERVAL) >> ADC_CTRL0_INTERVAL_Pos);
    hadc->Init.ADC_RegularDiscontinuousNum =
        (uint8)(READ_BIT(hadc->Instance->CTRL0,
        ADC_CTRL0_DISCNUM) >> ADC_CTRL0_DISCNUM_Pos);

    hadc->Init.ADC_RegularSequenceLength =
        (uint8)((READ_BIT(hadc->Instance->SQL,
        ADC_SQL_RSQL) >> ADC_SQL_RSQL_Pos) + 1U);
    hadc->Init.ADC_InjectSequenceLength =
        (uint8)((READ_BIT(hadc->Instance->SQL,
        ADC_SQL_ISQL) >> ADC_SQL_ISQL_Pos) + 1U);

    hadc->Init.ADC_PowerEn =
        (FunctionalState)(READ_BIT(hadc->Instance->CTRL1,
        ADC_CTRL1_ADON) >> ADC_CTRL1_ADON_Pos);
    hadc->Init.ADC_PowerRegain =
        (FunctionalState)(READ_BIT(hadc->Instance->CTRL1,
        ADC_CTRL1_RESETN) >> ADC_CTRL1_RESETN_Pos);
    hadc->Init.ADC_BufEn =
        (FunctionalState)(READ_BIT(hadc->Instance->CONFIG,
        ADC_CONFIG_EN_BUF) >> ADC_CONFIG_EN_BUF_Pos);

    /* Release Lock */
    ADC_UnlockHandle(hadc);

    /* Return function status */
    return HAL_OK;
}

/**
 * @brief  Checks whether the specified ADC flag is set or not. (NON-BLOCKING)
 * @note   The ADC_FLAG_EOC flag requires the rank index of the sequence to
 *         check.
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  ADC_FLAG: specifies the flag to check (ADC_FLAG_CONVCFT /
 *         ADC_FLAG_IDLE / ADC_FLAG_AMO / ADC_FLAG_EOC).
 * @param  Rank: sequence rank (ADC_RSEQ_0..15 / ADC_ISEQ_0..3, only for
 *         ADC_FLAG_EOC).
 * @retval FlagStatus: SET or RESET (also RESET when the handle, the instance,
 *         the flag or the rank is invalid).
 */
FlagStatus HAL_ADC_GetFlagStatus(ADC_HandleTypeDef *hadc, uint8 ADC_FLAG, uint32 Rank)
{
    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return RESET;
    }

    /* Check the parameters */
    assert_param(IS_ADC_GET_FLAG(ADC_FLAG));
    assert_param(IS_ADC_SEQUENCE(Rank));

    /* An invalid flag or rank would read an arbitrary register / bit; report
     * no flag instead (read-only: no lock) */
    if ((IS_ADC_GET_FLAG(ADC_FLAG) == 0U) || (IS_ADC_SEQUENCE(Rank) == 0U))
    {
        return RESET;
    }

    return ADC_GetFlagStatusInternal(hadc, ADC_FLAG, Rank);
}

/**
 * @brief  Clears the ADC pending flags. (NON-BLOCKING)
 * @note   The STATE register flags (CONVCFT / AMO) are cleared by writing 0
 *         to the flag bit, the EOC flags are cleared by writing 1 to the
 *         RSQR / ISQR EOC bit.
 * @note   This interface takes no lock and changes no handle state, so it is
 *         callable from an interrupt service routine (LOCK-04 / RTOS-12).
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  ADC_FLAG: specifies the flag to clear (ADC_FLAG_CONVCFT /
 *         ADC_FLAG_AMO / ADC_FLAG_EOC).
 * @param  Rank: sequence rank (ADC_RSEQ_0..15 / ADC_ISEQ_0..3, only for
 *         ADC_FLAG_EOC).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (NULL pointer, invalid
 *         instance, invalid flag or invalid rank)
 */
HAL_StatusTypeDef HAL_ADC_ClearFlag(ADC_HandleTypeDef *hadc, uint8 ADC_FLAG, uint32 Rank)
{
    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_ADC_CLEAR_FLAG(ADC_FLAG));
    assert_param(IS_ADC_SEQUENCE(Rank));

    /* Runtime parameter validation: an invalid flag or rank would touch an
     * arbitrary register / bit (no lock is taken on this path) */
    if ((IS_ADC_CLEAR_FLAG(ADC_FLAG) == 0U) || (IS_ADC_SEQUENCE(Rank) == 0U))
    {
        hadc->ErrorCode |= HAL_ADC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    ADC_ClearFlagInternal(hadc, ADC_FLAG, Rank);

    return HAL_OK;
}

/**
 * @brief  Wait for the ADC conversion to finish (BLOCKING)
 *         (STATE.IDLE flag).
 * @note   The wait is bounded by the caller supplied Timeout, measured with
 *         the HAL 1 ms time base (HAL_GetTick()), so that a conversion which
 *         never finishes cannot hang the MCU. HAL_MAX_DELAY waits forever; 0
 *         gives the hardware a single chance (no waiting).
 * @note   RTOS-04 / RTOS-05: in an RTOS build the other tasks of the same
 *         priority are allowed to run while waiting (HAL_RTOS_Yield(); the
 *         macro is empty in a bare-metal build).
 * @note   This interface changes no handle state, so it neither takes the
 *         lock nor requires the handle to be initialized beyond the instance
 *         check.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  Timeout: Timeout value in milliseconds.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (the ADC did not become
 *         idle in time) / HAL_ERROR (NULL pointer or invalid instance)
 */
HAL_StatusTypeDef HAL_ADC_WaitConvDone(ADC_HandleTypeDef *hadc, uint32 Timeout)
{
    uint32 tickstart = 0U;

    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return HAL_ERROR;
    }

    /* Get the start time */
    tickstart = HAL_GetTick();

    /* Wait until the ADC is idle */
    while (READ_BIT(hadc->Instance->STATE, ADC_STATE_IDLE) == 0U)
    {
        /* Check for the timeout */
        if (Timeout != HAL_MAX_DELAY)
        {
            if ((Timeout == 0U) || ((HAL_GetTick() - tickstart) > Timeout))
            {
                return HAL_TIMEOUT;
            }
        }

        /* ARCH/RTOS-04: let the other tasks of the same priority run instead of
         * busy waiting (empty macro in a bare-metal build) */
        HAL_RTOS_Yield();
    }

    /* Return function status */
    return HAL_OK;
}

/**
  * @}
  */

/** @defgroup ADC_Exported_Functions_Group4 Peripheral State and Errors functions
  * @{
  */

/**
 * @brief  Return the ADC state. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval uint32: the ADC state (HAL_ADC_STATE_xxx).
 */
uint32 HAL_ADC_GetState(ADC_HandleTypeDef *hadc)
{
    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return 0U;
    }

    return hadc->State;
}

/**
 * @brief  Return the ADC error code. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval uint32: the ADC error code (HAL_ADC_ERROR_xxx).
 */
uint32 HAL_ADC_GetError(ADC_HandleTypeDef *hadc)
{
    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return 0U;
    }

    return hadc->ErrorCode;
}

/**
  * @}
  */

/**
  * @}
  */

/* Exported functions ---------------------------------------------------------*/

/** @defgroup ADC_Exported_Functions ADC Exported Functions
  * @{
  */

/** @defgroup ADC_Exported_Functions_Group1 Injected group operation functions
  * @{
  */

/**
 * @brief  Start a software triggered injection group conversion. (NON-BLOCKING)
 * @note   The EOC flag of the injected
 *         rank can be polled with HAL_ADC_GetFlagStatus() and the data read
 *         with HAL_ADC_InjectedGetValue().
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_ADC_InjectedStart(ADC_HandleTypeDef *hadc)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_ADC_Init() is
     * required first) */
    status = ADC_CheckState(hadc);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (ADC_LockHandle(hadc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Start the injection group conversion by software (write-1 trigger) */
    SET_BIT(hadc->Instance->CTRL0, ADC_CTRL0_ISWSTART);

    /* Update the ADC state */
    SET_BIT(hadc->State, HAL_ADC_STATE_INJ_BUSY);

    /* Release Lock */
    ADC_UnlockHandle(hadc);

    /* Return function status */
    return HAL_OK;
}

/**
 * @brief  Get the injection group conversion result of the selected rank. (NON-BLOCKING)
 * @note   For the injected group the data
 *         is returned through the Result pointer and the function returns
 *         the channel number that produced the data.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  Rank: injected rank (ADC_ISEQ_0..3).
 * @param  Result: pointer to the variable that will receive the conversion
 *         data.
 * @retval uint16: the channel number of the conversion (0..20).
 */
uint16 HAL_ADC_InjectedGetValue(ADC_HandleTypeDef *hadc, uint32 Rank, uint16 *Result)
{
    uint32 tmpreg = 0U;
    uint16 returnValue = 0U;

    /* Check the parameters */
    assert_param(IS_ADC_ALL_INSTANCE(hadc->Instance));
    assert_param(IS_ADC_INJECT_RANK(Rank));

    /* Read the injected data register of the selected rank */
    tmpreg = READ_REG(hadc->Instance->IDR[Rank - ADC_ISEQ_0]);
    if (Result != NULL)
    {
        *Result = (uint16)((tmpreg & ADC_IDR_IDR) >> ADC_IDR_IDR_Pos);
    }
    returnValue = (uint16)((tmpreg & ADC_IDR_CH) >> ADC_IDR_CH_Pos);

    /* Return the channel number of the conversion */
    return returnValue;
}

/**
 * @brief  Set the injection group offset value of the selected rank. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  Rank: injected rank (ADC_ISEQ_0..3).
 * @param  Offset: offset value, subtracted from the converted data, must be
 *         less than 0x1000.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_ADC_InjectedSetOffset(ADC_HandleTypeDef *hadc, uint32 Rank, uint16 Offset)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_ADC_INJECT_RANK(Rank));
    assert_param(Offset < 0x1000U);

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03) */
    if ((IS_ADC_INJECT_RANK(Rank) == 0U) || (Offset >= 0x1000U))
    {
        hadc->ErrorCode |= HAL_ADC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_ADC_Init() is
     * required first) */
    status = ADC_CheckState(hadc);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (ADC_LockHandle(hadc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Set the offset value of the selected injected rank (IOFR register) */
    MODIFY_REG(hadc->Instance->IOFR[Rank - ADC_ISEQ_0], ADC_IOFR_IOFR,
               (((uint32)Offset) << ADC_IOFR_IOFR_Pos));

    /* Release Lock */
    ADC_UnlockHandle(hadc);

    /* Return function status */
    return HAL_OK;
}

/**
 * @brief  Get the injection group offset value of the selected rank. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  Rank: injected rank (ADC_ISEQ_0..3).
 * @retval uint16: the offset value.
 */
uint16 HAL_ADC_InjectedGetOffset(ADC_HandleTypeDef *hadc, uint32 Rank)
{
    uint16 value = 0x00U;

    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return 0U;
    }
    assert_param(IS_ADC_INJECT_RANK(Rank));

    /* Read the offset value of the selected injected rank */
    value = (uint16)(READ_BIT(hadc->Instance->IOFR[Rank - ADC_ISEQ_0], ADC_IOFR_IOFR) >> ADC_IOFR_IOFR_Pos);

    /* Return the offset value */
    return value;
}

/**
  * @}
  */

/** @defgroup ADC_Exported_Functions_Group2 Analog monitor functions
  * @{
  */

/**
 * @brief  Initialize the ADC analog monitor configuration structure with (NON-BLOCKING)
 *         default values.
 * @param  pAmoConf: pointer to an ADC_AmoConfTypeDef structure that will be
 *         filled with the default configuration (all disabled, channel 1,
 *         thresholds 0).
 * @retval None
 */
void HAL_ADC_AMOStructInit(ADC_AmoConfTypeDef *pAmoConf)
{
    /* Reset the analog monitor configuration structure parameters values */
    /* Check the pAmoConf handle allocation */
    if (pAmoConf == NULL_PTR)
    {
        return;
    }
    pAmoConf->ADC_AmoInterruptEn  = DISABLE;
    pAmoConf->ADC_AmoRegularEn    = DISABLE;
    pAmoConf->ADC_AmoInjectEn     = DISABLE;
    pAmoConf->ADC_AmoSingleModeEn = DISABLE;
    pAmoConf->ADC_AmoSingleChannel = ADC_CH_1;

    pAmoConf->ADC_AmoUpThreshold  = 0x00U;
    pAmoConf->ADC_AmoLowThreshold = 0x00U;
}

/**
 * @brief  Configure the ADC analog monitor (AMO) according to the specified (NON-BLOCKING)
 *         parameters in the pAmoConf structure.
 * @note   The AMOCR / AMOHR / AMOLR registers are programmed in one locked sequence.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  pAmoConf: pointer to an ADC_AmoConfTypeDef structure that contains
 *         the configuration information for the analog monitor.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_ADC_ConfigAnalogMonitor(ADC_HandleTypeDef *hadc, ADC_AmoConfTypeDef *pAmoConf)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the ADC peripheral handle and instance, and the configuration pointer */
    if ((ADC_HandleIsValid(hadc) == 0U) || (pAmoConf == NULL_PTR))
    {
        return HAL_ERROR;
    }
    assert_param(IS_ADC_BitAction(pAmoConf->ADC_AmoRegularEn));
    assert_param(IS_ADC_BitAction(pAmoConf->ADC_AmoInjectEn));
    assert_param(IS_ADC_BitAction(pAmoConf->ADC_AmoSingleModeEn));
    assert_param(IS_ADC_INPUT_CH(pAmoConf->ADC_AmoSingleChannel));
    assert_param(IS_ADC_BitAction(pAmoConf->ADC_AmoInterruptEn));
    assert_param(IS_ADC_AMO_THRESHOLD(pAmoConf->ADC_AmoUpThreshold));
    assert_param(IS_ADC_AMO_THRESHOLD(pAmoConf->ADC_AmoLowThreshold));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03) */
    if ((IS_ADC_INPUT_CH(pAmoConf->ADC_AmoSingleChannel) == 0U) ||
        (IS_ADC_AMO_THRESHOLD(pAmoConf->ADC_AmoUpThreshold) == 0U) ||
        (IS_ADC_AMO_THRESHOLD(pAmoConf->ADC_AmoLowThreshold) == 0U))
    {
        hadc->ErrorCode |= HAL_ADC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_ADC_Init() is
     * required first) */
    status = ADC_CheckState(hadc);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (ADC_LockHandle(hadc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Set the analog monitor configuration (AMOCR register) */
    MODIFY_REG(hadc->Instance->AMOCR, ADC_AMOCR_AMOEN,
               (((uint32)pAmoConf->ADC_AmoRegularEn) << ADC_AMOCR_AMOEN_Pos));
    MODIFY_REG(hadc->Instance->AMOCR, ADC_AMOCR_IAMOEN,
               (((uint32)pAmoConf->ADC_AmoInjectEn) << ADC_AMOCR_IAMOEN_Pos));
    MODIFY_REG(hadc->Instance->AMOCR, ADC_AMOCR_AMOSGL,
               (((uint32)pAmoConf->ADC_AmoSingleModeEn) << ADC_AMOCR_AMOSGL_Pos));
    MODIFY_REG(hadc->Instance->AMOCR, ADC_AMOCR_AMOCH,
               (((uint32)pAmoConf->ADC_AmoSingleChannel) << ADC_AMOCR_AMOCH_Pos));

    /* Set the analog monitor thresholds (AMOHR / AMOLR registers) */
    MODIFY_REG(hadc->Instance->AMOHR, ADC_AMOHR_AMOHT,
               (((uint32)pAmoConf->ADC_AmoUpThreshold) << ADC_AMOHR_AMOHT_Pos));
    MODIFY_REG(hadc->Instance->AMOLR, ADC_AMOLR_AMOLT,
               (((uint32)pAmoConf->ADC_AmoLowThreshold) << ADC_AMOLR_AMOLT_Pos));

    /* Set the analog monitor interrupt enable (AMOCR.AMOIE bit) */
    MODIFY_REG(hadc->Instance->AMOCR, ADC_AMOCR_AMOIE,
               (((uint32)pAmoConf->ADC_AmoInterruptEn) << ADC_AMOCR_AMOIE_Pos));

    /* Release Lock */
    ADC_UnlockHandle(hadc);

    /* Return function status */
    return HAL_OK;
}

/**
 * @brief  Get the configuration of the analog monitor from the registers. (NON-BLOCKING)
 * @note   The analog monitor registers are read as one snapshot.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  pAmoConf: pointer to an ADC_AmoConfTypeDef structure that will be
 *         filled with the current register configuration.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_ADC_GetAnalogMonitorConfig(ADC_HandleTypeDef *hadc, ADC_AmoConfTypeDef *pAmoConf)
{
    /* Check the ADC peripheral handle and instance, and the configuration pointer */
    if ((ADC_HandleIsValid(hadc) == 0U) || (pAmoConf == NULL_PTR))
    {
        return HAL_ERROR;
    }

    /* Read the analog monitor configuration (AMOCR register) */
    pAmoConf->ADC_AmoRegularEn =
        (FunctionalState)(READ_BIT(hadc->Instance->AMOCR,
        ADC_AMOCR_AMOEN) >> ADC_AMOCR_AMOEN_Pos);
    pAmoConf->ADC_AmoInjectEn =
        (FunctionalState)(READ_BIT(hadc->Instance->AMOCR,
        ADC_AMOCR_IAMOEN) >> ADC_AMOCR_IAMOEN_Pos);
    pAmoConf->ADC_AmoSingleModeEn =
        (FunctionalState)(READ_BIT(hadc->Instance->AMOCR,
        ADC_AMOCR_AMOSGL) >> ADC_AMOCR_AMOSGL_Pos);
    pAmoConf->ADC_AmoSingleChannel = (uint32)(READ_BIT(hadc->Instance->AMOCR, ADC_AMOCR_AMOCH) >> ADC_AMOCR_AMOCH_Pos);

    /* Read the analog monitor thresholds (AMOHR / AMOLR registers) */
    pAmoConf->ADC_AmoUpThreshold  = (uint16)(READ_BIT(hadc->Instance->AMOHR, ADC_AMOHR_AMOHT) >> ADC_AMOHR_AMOHT_Pos);
    pAmoConf->ADC_AmoLowThreshold = (uint16)(READ_BIT(hadc->Instance->AMOLR, ADC_AMOLR_AMOLT) >> ADC_AMOLR_AMOLT_Pos);

    /* Read the analog monitor interrupt enable (AMOCR.AMOIE bit) */
    pAmoConf->ADC_AmoInterruptEn =
        (FunctionalState)(READ_BIT(hadc->Instance->AMOCR,
        ADC_AMOCR_AMOIE) >> ADC_AMOCR_AMOIE_Pos);

    /* Return function status */
    return HAL_OK;
}

/**
  * @}
  */

/** @defgroup ADC_Exported_Functions_Group3 Temperature sensor functions
  * @{
  */

/**
 * @brief  Initialize the ADC temperature sensor configuration structure with (NON-BLOCKING)
 *         default values.
 * @param  pTempConf: pointer to an ADC_TempSensorConfTypeDef structure that
 *         will be filled with the default configuration (gain 8, offset 8,
 *         sampling points 128, disabled).
 * @retval None
 */
void HAL_ADC_TempStructInit(ADC_TempSensorConfTypeDef *pTempConf)
{
    /* Reset the temperature sensor configuration structure parameters values */
    /* Check the pTempConf handle allocation */
    if (pTempConf == NULL_PTR)
    {
        return;
    }
    pTempConf->ADC_TempSensorGain   = ADC_ADJ_TD_GA_8;
    pTempConf->ADC_TempSensorOffset = ADC_ADJ_TD_OS_8;
    pTempConf->ADC_TempSamplePoint  = ADC_ALG_MEAN_128;
    pTempConf->TempSensorEn         = DISABLE;
}

/**
 * @brief  Configure the ADC temperature sensor (gain, offset, sampling (NON-BLOCKING)
 *         points, enable) according to the specified parameters.
 * @note   The RESETN bit is kept asserted
 *         while the EN_TS bit is toggled, then released, and a stabilization
 *         delay is applied.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  pTempConf: pointer to an ADC_TempSensorConfTypeDef structure that
 *         contains the configuration information for the temperature sensor.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_ADC_ConfigTemperatureSensor(ADC_HandleTypeDef *hadc, ADC_TempSensorConfTypeDef *pTempConf)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the ADC peripheral handle and instance, and the configuration pointer */
    if ((ADC_HandleIsValid(hadc) == 0U) || (pTempConf == NULL_PTR))
    {
        return HAL_ERROR;
    }
    assert_param(IS_ADC_ADJTDGA(pTempConf->ADC_TempSensorGain));
    assert_param(IS_ADC_ADJTDOS(pTempConf->ADC_TempSensorOffset));
    assert_param(IS_ADC_ALGMEAN(pTempConf->ADC_TempSamplePoint));
    assert_param(IS_ADC_BitAction(pTempConf->TempSensorEn));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((IS_ADC_ADJTDGA(pTempConf->ADC_TempSensorGain) == 0U) ||
        (IS_ADC_ADJTDOS(pTempConf->ADC_TempSensorOffset) == 0U) ||
        (IS_ADC_ALGMEAN(pTempConf->ADC_TempSamplePoint) == 0U))
    {
        hadc->ErrorCode |= HAL_ADC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_ADC_Init() is
     * required first) */
    status = ADC_CheckState(hadc);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (ADC_LockHandle(hadc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Set the temperature sensor adjustment fields (ADC_CONFIG) */
    MODIFY_REG(hadc->Instance->CONFIG, ADC_CONFIG_ADJ_TD_GA,
               (((uint32)pTempConf->ADC_TempSensorGain) << ADC_CONFIG_ADJ_TD_GA_Pos));
    MODIFY_REG(hadc->Instance->CONFIG, ADC_CONFIG_ADJ_TD_OS,
               (((uint32)pTempConf->ADC_TempSensorOffset) << ADC_CONFIG_ADJ_TD_OS_Pos));
    MODIFY_REG(hadc->Instance->CONFIG, ADC_CONFIG_ALG_MEAN,
               (((uint32)pTempConf->ADC_TempSamplePoint) << ADC_CONFIG_ALG_MEAN_Pos));

    /* When EN_TS is set from 0 to 1, the temperature sensor start time is
     * 6us@Typ, 10us@Max: assert the reset, set the enable bit, wait, then
     * release the reset */
    CLEAR_BIT(hadc->Instance->CTRL1, ADC_CTRL1_RESETN);
    MODIFY_REG(hadc->Instance->CONFIG, ADC_CONFIG_EN_TS,
               (((uint32)pTempConf->TempSensorEn) << ADC_CONFIG_EN_TS_Pos));
    ADC_InitDelayus(ADC_TEMPSENSOR_DELAY_US);
    SET_BIT(hadc->Instance->CTRL1, ADC_CTRL1_RESETN);

    /* Release Lock */
    ADC_UnlockHandle(hadc);

    /* Return function status */
    return HAL_OK;
}

/**
 * @brief  Get the configuration of the temperature sensor from the registers. (NON-BLOCKING)
 * @note   The temperature sensor configuration registers are read as one snapshot.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  pTempConf: pointer to an ADC_TempSensorConfTypeDef structure that
 *         will be filled with the current register configuration.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_ADC_GetTemperatureSensorConfig(ADC_HandleTypeDef *hadc, ADC_TempSensorConfTypeDef *pTempConf)
{
    /* Check the ADC peripheral handle and instance, and the configuration pointer */
    if ((ADC_HandleIsValid(hadc) == 0U) || (pTempConf == NULL_PTR))
    {
        return HAL_ERROR;
    }

    /* Read the temperature sensor adjustment fields (ADC_CONFIG) */
    pTempConf->ADC_TempSensorGain =
        (uint32)(READ_BIT(hadc->Instance->CONFIG,
        ADC_CONFIG_ADJ_TD_GA) >> ADC_CONFIG_ADJ_TD_GA_Pos);
    pTempConf->ADC_TempSensorOffset =
        (uint32)(READ_BIT(hadc->Instance->CONFIG,
        ADC_CONFIG_ADJ_TD_OS) >> ADC_CONFIG_ADJ_TD_OS_Pos);
    pTempConf->ADC_TempSamplePoint =
        (uint32)(READ_BIT(hadc->Instance->CONFIG,
        ADC_CONFIG_ALG_MEAN) >> ADC_CONFIG_ALG_MEAN_Pos);
    pTempConf->TempSensorEn =
        (FunctionalState)(READ_BIT(hadc->Instance->CONFIG,
        ADC_CONFIG_EN_TS) >> ADC_CONFIG_EN_TS_Pos);

    /* Return function status */
    return HAL_OK;
}

/**
 * @brief  Get the temperature sensor enable flag. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval FlagStatus: SET or RESET.
 */
FlagStatus HAL_ADC_GetTemperatureSensorStatus(ADC_HandleTypeDef *hadc)
{
    FlagStatus bitstatus = RESET;

    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return RESET;
    }

    if (READ_BIT(hadc->Instance->CONFIG, ADC_CONFIG_EN_TS) != 0U)
    {
        bitstatus = SET;
    }
    else
    {
        bitstatus = RESET;
    }

    /* Return the temperature sensor enable flag */
    return bitstatus;
}

/**
 * @brief  Clear the temperature sensor enable flag. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval None
 */
HAL_StatusTypeDef HAL_ADC_ClearTemperatureSensorStatus(ADC_HandleTypeDef *hadc)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_ADC_Init() is
     * required first) */
    status = ADC_CheckState(hadc);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (ADC_LockHandle(hadc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the temperature sensor enable bit */
    CLEAR_BIT(hadc->Instance->CONFIG, ADC_CONFIG_EN_TS);

    /* Release Lock */
    ADC_UnlockHandle(hadc);

    /* Return function status */
    return HAL_OK;
}

/**
  * @}
  */

/** @defgroup ADC_Exported_Functions_Group4 Extended status functions
  * @{
  */

/**
 * @brief  Get the external reference input buffer enable flag. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval FlagStatus: SET or RESET.
 */
FlagStatus HAL_ADC_GetBufferStatus(ADC_HandleTypeDef *hadc)
{
    FlagStatus bitstatus = RESET;

    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return RESET;
    }

    if (READ_BIT(hadc->Instance->CONFIG, ADC_CONFIG_EN_BUF) != 0U)
    {
        bitstatus = SET;
    }
    else
    {
        bitstatus = RESET;
    }

    /* Return the buffer enable flag */
    return bitstatus;
}

/**
 * @brief  Clear the external reference input buffer enable flag. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval None
 */
HAL_StatusTypeDef HAL_ADC_ClearBufferStatus(ADC_HandleTypeDef *hadc)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_ADC_Init() is
     * required first) */
    status = ADC_CheckState(hadc);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (ADC_LockHandle(hadc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the external reference input buffer enable bit */
    CLEAR_BIT(hadc->Instance->CONFIG, ADC_CONFIG_EN_BUF);

    /* Release Lock */
    ADC_UnlockHandle(hadc);

    /* Return function status */
    return HAL_OK;
}

/**
 * @brief  Set the high-resistance state flag (ADC_CONFIG.EN_HIZ bit). (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval None
 */
HAL_StatusTypeDef HAL_ADC_SetHighResStatus(ADC_HandleTypeDef *hadc)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_ADC_Init() is
     * required first) */
    status = ADC_CheckState(hadc);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (ADC_LockHandle(hadc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Set the high-resistance state flag */
    SET_BIT(hadc->Instance->CONFIG, ADC_CONFIG_EN_HIZ);

    /* Release Lock */
    ADC_UnlockHandle(hadc);

    /* Return function status */
    return HAL_OK;
}

/**
 * @brief  Get the high-resistance state flag. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval FlagStatus: SET or RESET.
 */
FlagStatus HAL_ADC_GetHighResStatus(ADC_HandleTypeDef *hadc)
{
    FlagStatus bitstatus = RESET;

    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return RESET;
    }

    if (READ_BIT(hadc->Instance->CONFIG, ADC_CONFIG_EN_HIZ) != 0U)
    {
        bitstatus = SET;
    }
    else
    {
        bitstatus = RESET;
    }

    /* Return the high-resistance state flag */
    return bitstatus;
}

/**
 * @brief  Clear the high-resistance state flag. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval None
 */
HAL_StatusTypeDef HAL_ADC_ClearHighResStatus(ADC_HandleTypeDef *hadc)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_ADC_Init() is
     * required first) */
    status = ADC_CheckState(hadc);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    if (ADC_LockHandle(hadc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the high-resistance state flag */
    CLEAR_BIT(hadc->Instance->CONFIG, ADC_CONFIG_EN_HIZ);

    /* Release Lock */
    ADC_UnlockHandle(hadc);

    /* Return function status */
    return HAL_OK;
}

/**
 * @brief  Get the ADC regular group data even parity of the selected rank. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  Rank: regular rank (ADC_RSEQ_0..15).
 * @retval uint8: the even parity value of the conversion data.
 */
uint8 HAL_ADC_GetRegularParity(ADC_HandleTypeDef *hadc, uint32 Rank)
{
    uint8 value = 0x00U;

    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return 0U;
    }
    assert_param(IS_ADC_REGULAR_RANK(Rank));

    /* Read the parity of the regular conversion data */
    value = (uint8)(READ_BIT(hadc->Instance->RDR[Rank], ADC_RDR_PARITY) >> ADC_RDR_PARITY_Pos);

    /* Return the parity value */
    return value;
}

/**
 * @brief  Get the ADC regular group channel number of the selected rank. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  Rank: regular rank (ADC_RSEQ_0..15).
 * @retval uint8: the channel number of the conversion.
 */
uint8 HAL_ADC_GetRegularChannel(ADC_HandleTypeDef *hadc, uint32 Rank)
{
    uint8 value = 0x00U;

    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return 0U;
    }
    assert_param(IS_ADC_REGULAR_RANK(Rank));

    /* Read the channel number of the regular conversion data */
    value = (uint8)(READ_BIT(hadc->Instance->RDR[Rank], ADC_RDR_CH) >> ADC_RDR_CH_Pos);

    /* Return the channel number */
    return value;
}

/**
 * @brief  Get the ADC injected group data even parity of the selected rank. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  Rank: injected rank (ADC_ISEQ_0..3).
 * @retval uint8: the even parity value of the conversion data.
 */
uint8 HAL_ADC_GetInjectParity(ADC_HandleTypeDef *hadc, uint32 Rank)
{
    uint8 value = 0x00U;

    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return 0U;
    }
    assert_param(IS_ADC_INJECT_RANK(Rank));

    /* Read the parity of the injected conversion data */
    value = (uint8)(READ_BIT(hadc->Instance->IDR[Rank - ADC_ISEQ_0], ADC_IDR_PARITY) >> ADC_IDR_PARITY_Pos);

    /* Return the parity value */
    return value;
}

/**
 * @brief  Get the ADC injected group channel number of the selected rank. (NON-BLOCKING)
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  Rank: injected rank (ADC_ISEQ_0..3).
 * @retval uint8: the channel number of the conversion.
 */
uint8 HAL_ADC_GetInjectChannel(ADC_HandleTypeDef *hadc, uint32 Rank)
{
    uint8 value = 0x00U;

    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return 0U;
    }
    assert_param(IS_ADC_INJECT_RANK(Rank));

    /* Read the channel number of the injected conversion data */
    value = (uint8)(READ_BIT(hadc->Instance->IDR[Rank - ADC_ISEQ_0], ADC_IDR_CH) >> ADC_IDR_CH_Pos);

    /* Return the channel number */
    return value;
}

/**
 * @brief  Get the conversion result of the selected sequence rank and the (NON-BLOCKING)
 *         channel number that produced it.
 * @note   For both groups the data is
 *         returned through the Result pointer and the function returns the
 *         channel number. Unlike HAL_ADC_GetValue(), the rank is explicit
 *         and the current rank index of the handle is not modified.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  Rank: sequence rank (ADC_RSEQ_0..15 / ADC_ISEQ_0..3).
 * @param  Result: pointer to the variable that will receive the conversion
 *         data.
 * @retval uint16: the channel number of the conversion (0..20).
 */
uint16 HAL_ADC_GetSeqResult(ADC_HandleTypeDef *hadc, uint32 Rank, uint16 *Result)
{
    uint32 tmpreg = 0U;
    uint16 returnValue = 0U;

    /* Check the parameters */
    assert_param(IS_ADC_ALL_INSTANCE(hadc->Instance));
    assert_param(IS_ADC_SEQUENCE(Rank));

    if (Rank < ADC_REGULAR_SEQ_NUM)
    {
        /* Read the regular data register of the selected rank */
        tmpreg = READ_REG(hadc->Instance->RDR[Rank]);
        if (Result != NULL)
        {
            *Result = (uint16)((tmpreg & ADC_RDR_RDR) >> ADC_RDR_RDR_Pos);
        }
        returnValue = (uint16)((tmpreg & ADC_RDR_CH) >> ADC_RDR_CH_Pos);
    }
    else if (IS_ADC_INJECT_RANK(Rank))
    {
        /* Read the injected data register of the selected rank */
        tmpreg = READ_REG(hadc->Instance->IDR[Rank - ADC_ISEQ_0]);
        if (Result != NULL)
        {
            *Result = (uint16)((tmpreg & ADC_IDR_IDR) >> ADC_IDR_IDR_Pos);
        }
        returnValue = (uint16)((tmpreg & ADC_IDR_CH) >> ADC_IDR_CH_Pos);
    }
    else
    {
        /* Nothing to do */
    }

    /* Return the channel number of the conversion */
    return returnValue;
}

/**
 * @brief  Get the average value of the ADC conversion result of the assigned (BLOCKING)
 *         sequence rank.
 * @note   P3-3: the interface takes the resource lock and the state gate like
 *         every other operation of this driver, and every sample is waited for
 *         with the private budget ADC_AVERAGE_SAMPLE_TIMEOUT_MS with a yield in
 *         an RTOS build (RTOS-04). The former implementation waited in an
 *         unbounded empty loop (while (flag == RESET) { ; }) without a lock, so
 *         a conversion that never completed hung the caller forever.
 * @note   The wait and the result read use the lock free kernels of the flag
 *         and read interfaces (LOCK-05: a locked region calls no public
 *         interface), and the state gate is applied before the lock (LOCK-02:
 *         the rejected paths hold no lock).
 * @note   The EOC flag is cleared after each conversion so that consecutive
 *         conversions are not reading stale data (deliberate behaviour).
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @param  Rank: sequence rank (ADC_RSEQ_0..15 / ADC_ISEQ_0..3).
 * @param  Count: number of conversions used for the average.
 * @retval float: the averaged conversion result; the average over the samples
 *         collected so far when the call times out (the timeout is then
 *         reported by HAL_ADC_ERROR_TIMEOUT and HAL_ADC_STATE_TIMEOUT), or
 *         0.0F when the parameters, the handle state or the lock is rejected.
 */
float HAL_ADC_GetAverageValue(ADC_HandleTypeDef *hadc, uint32 Rank, uint32 Count)
{
    HAL_StatusTypeDef status = HAL_OK;
    float sum = 0.0F;
    float result = 0.0F;
    uint32 i = 0U;
    uint32 tickstart = 0U;
    uint32 timedOut = 0U;
    uint32 raw = 0U;
    uint16 value = 0x00U;

    /* Check the ADC peripheral handle and instance */
    if (ADC_HandleIsValid(hadc) == 0U)
    {
        return 0.0F;
    }

    /* Check the parameters */
    assert_param(IS_ADC_ALL_INSTANCE(hadc->Instance));
    assert_param(Count > 0U);
    assert_param(IS_ADC_SEQUENCE(Rank));

    /* Runtime parameter validation, so that the checks stay effective in a
     * build with the assertions disabled (ERR-03). The rejected call neither
     * takes the lock nor changes the handle state. */
    if ((Count == 0U) || (IS_ADC_SEQUENCE(Rank) == 0U))
    {
        hadc->ErrorCode |= HAL_ADC_ERROR_INVALID_PARAM;
        return 0.0F;
    }

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (RESET, HAL_ADC_Init() is
     * required first) */
    status = ADC_CheckState(hadc);
    if (status != HAL_OK)
    {
        return 0.0F;
    }

    /* Process locked */
    if (ADC_LockHandle(hadc, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return 0.0F;
    }

    for (i = 0U; i < Count; i++)
    {
        tickstart = HAL_GetTick();

        /* Trigger the conversion by software */
        SET_BIT(hadc->Instance->CTRL0, ADC_CTRL0_SWSTART);

        /* Wait for the conversion complete, bounded by the private per sample
         * budget so that a missing end of conversion cannot hang the caller */
        while (ADC_GetFlagStatusInternal(hadc, ADC_FLAG_EOC, Rank) == RESET)
        {
            if ((HAL_GetTick() - tickstart) > ADC_AVERAGE_SAMPLE_TIMEOUT_MS)
            {
                timedOut = 1U;
                break;
            }

            /* ARCH/RTOS-04: let the other tasks of the same priority run instead
             * of busy waiting (empty macro in a bare-metal build) */
            HAL_RTOS_Yield();
        }

        if (timedOut != 0U)
        {
            break;
        }

        /* Read the conversion result of the selected rank through the register
         * read (the same data field the read interface publishes) */
        if (Rank < ADC_REGULAR_SEQ_NUM)
        {
            raw = READ_REG(hadc->Instance->RDR[Rank]);
        }
        else
        {
            raw = READ_REG(hadc->Instance->IDR[Rank - ADC_ISEQ_0]);
        }
        value = (uint16)(raw & ADC_RDR_RDR);

        /* Clear the EOC flag for the next conversion (deliberate behaviour) */
        ADC_ClearFlagInternal(hadc, ADC_FLAG_EOC, Rank);

        sum += (float)value;
    }

    if (timedOut != 0U)
    {
        /* ARCH-CONST-09: the timeout is recorded and stays recoverable */
        hadc->ErrorCode |= HAL_ADC_ERROR_TIMEOUT;
        hadc->State |= HAL_ADC_STATE_TIMEOUT;
    }

    /* Release Lock */
    ADC_UnlockHandle(hadc);

    /* Average of the samples received so far: the float return has no status
     * channel, so a partial result is published together with the timeout
     * error code rather than being hidden */
    result = (sum / (float)Count);

    /* Return the averaged conversion result */
    return result;
}

/**
 * @brief  Convert the ADC value of the internal temperature sensor to a (NON-BLOCKING)
 *         temperature.
 * @note   The output slope KT is about
 *         6 mV/C, the output VVTEMP is about 1.1V at 0C.
 * @note   P3-4: the input is validated (the former implementation computed with
 *         any value). A conversion result above 4095 is out of the 12 bit
 *         range, and a reference that is zero, negative, NaN or not finite
 *         cannot produce a temperature. This is a pure computation without a
 *         handle and without a status channel, so an invalid input is reported
 *         as 0.0F (documented in the header).
 * @param  Value: ADC conversion result of the internal temperature sensor.
 * @param  RefVoltage: reference voltage of the ADC, in mV.
 * @retval float: the temperature value in Celsius scale, or 0.0F for an
 *         invalid input.
 */
float HAL_ADC_ConvertToTemperature(uint16 Value, float RefVoltage)
{
    float temperature = 0.0F;
    /* Voltage of ADC, in mV. The output slope KT is about 6mV/C. The output
     * VVTEMP is about 1.1V at 0C. */
    const float slope = 6.0F;
    const float volTempBase = 1100.0F;

    /* The first test rejects an out of range conversion result. The second test
     * rejects zero, a negative reference and NaN; the third rejects a non finite
     * (infinite) reference without any <math.h> facility: for a finite value
     * (x - x) is exactly +0, while for an infinity it is NaN, which compares
     * unequal to 0. */
    if ((Value > 4095U) || (!(RefVoltage > 0.0F)) || ((RefVoltage - RefVoltage) != 0.0F))
    {
        return 0.0F;
    }

    temperature = (((float)Value / 4096.0F) * RefVoltage - volTempBase) / slope;

    /* Return the temperature value */
    return temperature;
}

/**
 * @brief  Injected conversion complete callback.
 * @note   This function should not be modified: when the callback is needed,
 *         HAL_ADC_InjectedConvCpltCallback() could be implemented in the
 *         user file.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval None
 */
__weak void HAL_ADC_InjectedConvCpltCallback(ADC_HandleTypeDef *hadc)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(hadc);
}

/**
  * @}
  */

/**
  * @}
  */

/* Private functions ---------------------------------------------------------*/

/** @defgroup ADC_Private_Functions ADC Private Functions
  * @{
  */

/**
 * @brief  Apply the initialization parameters to the ADC registers.
 * @note   Applies the register write sequence of the device layer initialization.
 * @param  hadc: pointer to an ADC_HandleTypeDef structure that contains the
 *         configuration information for the specified ADC.
 * @retval None
 */
static void ADC_Init(ADC_HandleTypeDef *hadc)
{
    uint32 frequence = ADC_CLOCK_FREQ_MAX_RUNTIME;

    /* Check the ADC clock frequency against the maximum runtime frequency */
    if (hadc->Init.ADC_ClockDivide == ADC_CLK_DIVIDE_1)
    {
        frequence = frequence;
    }
    else
    {
        frequence = frequence / (((uint32)hadc->Init.ADC_ClockDivide) * 2U);
    }
    assert_param(frequence <= ADC_CLOCK_FREQ_MAX_RUNTIME);
    UNUSED(frequence);

    /* Set clock divide (ADC_CTRL1.PSC) */
    MODIFY_REG(hadc->Instance->CTRL1, ADC_CTRL1_PSC,
               (((uint32)hadc->Init.ADC_ClockDivide) << ADC_CTRL1_PSC_Pos));

    /* Set DMA enable flag (ADC_CTRL0.DMAEN) */
    MODIFY_REG(hadc->Instance->CTRL0, ADC_CTRL0_DMAEN,
               (((uint32)hadc->Init.ADC_DmaEnable) << ADC_CTRL0_DMAEN_Pos));

    /* Set resolution (ADC_CTRL1.RESL) */
    MODIFY_REG(hadc->Instance->CTRL1, ADC_CTRL1_RESL,
               (((uint32)hadc->Init.ADC_Resolution) << ADC_CTRL1_RESL_Pos));

    /* Set symbols (ADC_CTRL0.SELDO) */
    MODIFY_REG(hadc->Instance->CTRL0, ADC_CTRL0_SELDO,
               (((uint32)hadc->Init.ADC_Symbol) << ADC_CTRL0_SELDO_Pos));

    /* Set alignment (ADC_CTRL0.ALIGN) */
    MODIFY_REG(hadc->Instance->CTRL0, ADC_CTRL0_ALIGN,
               (((uint32)hadc->Init.ADC_Alignment) << ADC_CTRL0_ALIGN_Pos));

    /* Set SAR input type (ADC_CONFIG.SELVI_HD_LS) */
    MODIFY_REG(hadc->Instance->CONFIG, ADC_CONFIG_SELVI_HD_LS,
               (((uint32)hadc->Init.ADC_SelvihdlsRef) << ADC_CONFIG_SELVI_HD_LS_Pos));

    /* Set the built-in reference voltage (ADC_CONFIG fields) */
    MODIFY_REG(hadc->Instance->CONFIG, ADC_CONFIG_EN_VREFBI,
               (((uint32)hadc->Init.ADC_VrefbiEnable) << ADC_CONFIG_EN_VREFBI_Pos));
    if (hadc->Init.ADC_VrefbiEnable == ENABLE)
    {
        MODIFY_REG(hadc->Instance->CONFIG, ADC_CONFIG_TTRIM,
                   (((uint32)hadc->Init.ADC_TtrimRef) << ADC_CONFIG_TTRIM_Pos));
        MODIFY_REG(hadc->Instance->CONFIG, ADC_CONFIG_VTRIM,
                   (((uint32)hadc->Init.ADC_VtrimRef) << ADC_CONFIG_VTRIM_Pos));
        MODIFY_REG(hadc->Instance->CONFIG, ADC_CONFIG_SEL_VREFBI,
                   (((uint32)hadc->Init.ADC_SelvRefbiRef) << ADC_CONFIG_SEL_VREFBI_Pos));
    }
    else
    {
        /* Nothing to do */
    }

    /* Set the ADC conversion modes (ADC_CTRL0) */
    MODIFY_REG(hadc->Instance->CTRL0, ADC_CTRL0_SCAN,
               (((uint32)hadc->Init.ADC_ScanModeEn) << ADC_CTRL0_SCAN_Pos));
    MODIFY_REG(hadc->Instance->CTRL0, ADC_CTRL0_CONT,
               (((uint32)hadc->Init.ADC_ContinuousModeEn) << ADC_CTRL0_CONT_Pos));
    MODIFY_REG(hadc->Instance->CTRL0, ADC_CTRL0_DISCEN,
               (((uint32)hadc->Init.ADC_RegularDiscontinuousModeEn) << ADC_CTRL0_DISCEN_Pos));
    MODIFY_REG(hadc->Instance->CTRL0, ADC_CTRL0_IDISCEN,
               (((uint32)hadc->Init.ADC_InjectDiscontinuousModeEn) << ADC_CTRL0_IDISCEN_Pos));
    MODIFY_REG(hadc->Instance->CTRL0, ADC_CTRL0_IAUTO,
               (((uint32)hadc->Init.ADC_InjectAutoModeEn) << ADC_CTRL0_IAUTO_Pos));
    MODIFY_REG(hadc->Instance->CTRL0, ADC_CTRL0_INTERVAL,
               (((uint32)hadc->Init.ADC_IntervalModeEn) << ADC_CTRL0_INTERVAL_Pos));
    MODIFY_REG(hadc->Instance->CTRL0, ADC_CTRL0_DISCNUM,
               (((uint32)hadc->Init.ADC_RegularDiscontinuousNum) << ADC_CTRL0_DISCNUM_Pos));

    /* Set the regular / injected group trigger sources (ADC_CTRL0) */
    MODIFY_REG(hadc->Instance->CTRL0, ADC_CTRL0_TRIGSRC,
               (((uint32)hadc->Init.ADC_RegularTrigger) << ADC_CTRL0_TRIGSRC_Pos));
    MODIFY_REG(hadc->Instance->CTRL0, ADC_CTRL0_ITRIGSRC,
               (((uint32)hadc->Init.ADC_InjectTrigger) << ADC_CTRL0_ITRIGSRC_Pos));

    /* Set the regular / injected group trigger enables (ADC_CTRL0) */
    MODIFY_REG(hadc->Instance->CTRL0, ADC_CTRL0_TRIGEN,
               (((uint32)hadc->Init.ADC_RegularEnable) << ADC_CTRL0_TRIGEN_Pos));
    MODIFY_REG(hadc->Instance->CTRL0, ADC_CTRL0_ITRIGEN,
               (((uint32)hadc->Init.ADC_InjectEnable) << ADC_CTRL0_ITRIGEN_Pos));

    /* Set the sequence lengths (ADC_SQL): a length of 0 leaves the field
     * unchanged (a length of 0 no longer underflows the SQL write) */
    if (hadc->Init.ADC_RegularSequenceLength > 0U)
    {
        MODIFY_REG(hadc->Instance->SQL, ADC_SQL_RSQL,
                   (((uint32)hadc->Init.ADC_RegularSequenceLength - 1U) << ADC_SQL_RSQL_Pos));
    }
    if (hadc->Init.ADC_InjectSequenceLength > 0U)
    {
        MODIFY_REG(hadc->Instance->SQL, ADC_SQL_ISQL,
                   (((uint32)hadc->Init.ADC_InjectSequenceLength - 1U) << ADC_SQL_ISQL_Pos));
    }

    /* Set the ADC analog power (ADC_CTRL1.ADON) */
    MODIFY_REG(hadc->Instance->CTRL1, ADC_CTRL1_ADON,
               (((uint32)hadc->Init.ADC_PowerEn) << ADC_CTRL1_ADON_Pos));

    /* Set the external reference input buffer (ADC_CONFIG.EN_BUF) */
    MODIFY_REG(hadc->Instance->CONFIG, ADC_CONFIG_EN_BUF,
               (((uint32)hadc->Init.ADC_BufEn) << ADC_CONFIG_EN_BUF_Pos));

    /* When EN_BUF is set from 0 to 1, the buffer start time is 3us@Typ,
     * 8us@Max: apply the stabilization delay accordingly */
    if (hadc->Init.ADC_BufEn == DISABLE)
    {
        ADC_InitDelayus(2U);
    }
    else
    {
        ADC_InitDelayus(8U);
    }

    /* Release the ADC analog reset (ADC_CTRL1.RESETN) */
    MODIFY_REG(hadc->Instance->CTRL1, ADC_CTRL1_RESETN,
               (((uint32)hadc->Init.ADC_PowerRegain) << ADC_CTRL1_RESETN_Pos));
}

/**
 * @brief  ADC initialization delay.
 * @note   The delay is implemented with a volatile busy loop (portable, no
 *         compiler specific inline assembly) instead of the IAR __asm used
 *         by inline assembly. This function is also used by the injected group
 *         and temperature sensor sequences (stabilization delay).
 * @param  Delayus: delay duration in microseconds.
 * @retval None
 */
void ADC_InitDelayus(uint32 Delayus)
{
    volatile uint32 i = 0U;
    /* Set this value based on the CPU clock (MHz) */
    const uint32 count = 40U;

    /* Check the parameters */
    assert_param(Delayus > 0U);

    /* The volatile counter prevents the compiler from optimizing the empty
     * loop away */
    for (i = 0U; i < (count * Delayus); i++)
    {
        /* Empty loop */
    }
}

#ifdef HAL_DMA_MODULE_ENABLED
/**
 * @brief  DMA conversion complete callback.
 * @note   This function is called by the DMA driver on full transfer
 *         completion; the ADC regular group state is set to end of
 *         conversion and the HAL_ADC_ConvCpltCallback() is invoked.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @retval None
 */
static void ADC_DMAConvCplt(DMA_HandleTypeDef *hdma)
{
    ADC_HandleTypeDef *hadc = (ADC_HandleTypeDef *)(hdma->Parent);

    /* Update the ADC state: end of conversion reached for the regular group */
    MODIFY_REG(hadc->State,
               (HAL_ADC_STATE_REG_BUSY | HAL_ADC_STATE_READY | HAL_ADC_STATE_TIMEOUT),
               HAL_ADC_STATE_REG_EOC);

    /* Conversion complete callback */
    HAL_ADC_ConvCpltCallback(hadc);
}

/**
 * @brief  DMA half conversion complete callback.
 * @note   This function is called by the DMA driver on half transfer
 *         completion; the HAL_ADC_ConvHalfCpltCallback() is invoked.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @retval None
 */
static void ADC_DMAHalfConvCplt(DMA_HandleTypeDef *hdma)
{
    ADC_HandleTypeDef *hadc = (ADC_HandleTypeDef *)(hdma->Parent);

    /* Half conversion complete callback */
    HAL_ADC_ConvHalfCpltCallback(hadc);
}

/**
 * @brief  DMA error callback.
 * @note   This function is called by the DMA driver on transfer error; the
 *         ADC error code is set to HAL_ADC_ERROR_DMA and the
 *         HAL_ADC_ErrorCallback() is invoked.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure that contains the
 *         configuration information for the specified DMA channel.
 * @retval None
 */
static void ADC_DMAError(DMA_HandleTypeDef *hdma)
{
    ADC_HandleTypeDef *hadc = (ADC_HandleTypeDef *)(hdma->Parent);

    /* Set the ADC state to ready and report the DMA error */
    hadc->State = HAL_ADC_STATE_READY;
    hadc->ErrorCode |= HAL_ADC_ERROR_DMA;

    /* Error callback */
    HAL_ADC_ErrorCallback(hadc);
}
#endif /* HAL_DMA_MODULE_ENABLED */

/**
  * @}
  */

#endif /* HAL_ADC_MODULE_ENABLED */

/*****END OF FILE*****/

