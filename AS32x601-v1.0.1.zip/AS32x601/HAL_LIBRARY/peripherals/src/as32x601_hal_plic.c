/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_plic.c
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.6
 * Date:   2026/10/10
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.1     add the module guard (HAL_PLIC_MODULE_ENABLED) around the whole implementation
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.2     put the as32x601_hal.h include first (module switch from the conf) before the module headers
 *     ANSILIC APPLICATION GROUP  2026/09/10     1.3     move the weak interrupt handler stubs here from as32x601_hal_plic.h
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.4     unify the two file versions, replace
 *                                                       the bare NULL comparisons with
 *                                                       NULL_PTR, validate the arguments at
 *                                                       run time (invalid source numbers and
 *                                                       configuration metafields are refused
 *                                                       before the first register access, so
 *                                                       a rejected call can no longer reach
 *                                                       an out of bounds register index with
 *                                                       the assertions disabled), give every
 *                                                       public prototype its doxygen block
 *                                                       with the blocking marker and state
 *                                                       the RTOS non-applicability of a
 *                                                       handle-less Simple module
 *     ANSILIC APPLICATION GROUP  2026/10/09     1.5     restore the " *" prefix of the history
 *                                                       continuation lines
 *     ANSILIC APPLICATION GROUP  2026/10/10     1.6     guarantee the PLIC clock ahead of both
 *                                                       initialisation branches (until now the
 *                                                       disable branch wrote the enable register
 *                                                       with the clock still ungated), factor the
 *                                                       priority and enable-bit register access
 *                                                       into private helpers, mask the priority
 *                                                       read-back to the implemented field, drive
 *                                                       the PLIC reset gate together with the
 *                                                       clock gate, and restore the interrupted
 *                                                       description sentence
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Platform-Level
 *                  Interrupt Controller (PLIC), following the structure of
 *                  a conventional NVIC-style HAL driver:
 *                  - Initialization: HAL_PLIC_StructInit / HAL_PLIC_Init;
 *                  - Peripheral control: HAL_PLIC_EnableIRQ,
 *                    HAL_PLIC_DisableIRQ, HAL_PLIC_SetPriority,
 *                    HAL_PLIC_GetPriority, HAL_PLIC_GetEnabledIRQ.
 *                  The trap dispatch (mcause decode, PLIC claim / complete
 *                  handshake and the weak handler table) is implemented by
 *                  the as32x601_trapentry assembly module, see the
 *                  AS32x601_SRS_TrapEntry requirements (TRAP-REQ-004 / 005 /
 *                  012): the claim is a read of AXI_PLIC_ID, the complete
 *                  is a write back of the claimed source ID.  The weak
 *                  default stubs of every dispatched interrupt / exception
 *                  handler are implemented at the end of this file.
 *                  RTOS configuration: this module needs no RTOS specific code
 *                  (no polling loop to yield in, no handle and no lock), so the
 *                  rules of the RTOS chapter are either not applicable or already
 *                  satisfied by the stateless design - the header lists them one
 *                  by one.
 */
#include "as32x601_hal.h"           /* module switch from as32x601_hal_conf.h */
#include "as32x601_hal_plic.h"     /* PLIC HAL API and register macros       */

/* The HAL_PLIC_MODULE_ENABLED switch is provided by the user configuration
 * file (as32x601_hal_conf.h, included above through as32x601_hal.h): the
 * whole implementation is compiled only while the module is enabled. */
#ifdef HAL_PLIC_MODULE_ENABLED

/* Private constants ---------------------------------------------------------*/
#define PLIC_EN0_MAX_IRQN          ((IRQn_Type)32U)   /*!< EN[0] covers IRQn 1..32  */
#define PLIC_EN0_BIT_BASE          1U                /*!< EN[0] bit = IRQn - 1     */
#define PLIC_EN1_BIT_BASE          33U               /*!< EN[1] bit = IRQn - 33    */

/* The priority is stored in bits 7:0 of the priority record; the reserved
 * encodings above PLIC_PRIORITY_MAX are not usable, so a read-back is masked
 * to the implemented field. */
#define PLIC_PRIORITY_FIELD_MASK   0xFFU

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Ensure that the PLIC clock is enabled and the PLIC reset is released.
 * @note   The PLIC sits on the AXI-Lite4 Bus0 and is clock-gated by the
 *         SMU ALB0CFGR register.  Any PLIC register access while the clock
 *         is off causes a bus error / CPU stall, therefore the clock is
 *         enabled here (SMU_ALB0CFGR.PLICEN) as the very first step of
 *         every operation that reads or writes PLIC registers.  This matches
 *         the "configure the PLIC only when it is actually used" policy: the
 *         startup file does NOT enable the PLIC clock.
 * @note   The reset gate (SMU_ALB0CFGR.PLICRST) is driven together with the
 *         clock gate so that a PLIC left held in reset by other code is
 *         released here as well.  Following the gate convention of this
 *         device a SET bit means "reset released"; the register reset value
 *         already has PLICRST set, so under the default power-on state the
 *         reset write is idempotent.  No reset pulse is generated (the bit is
 *         never cleared).
 * @note   The shared gate register read-modify-write must be serialized by the
 *         caller or by a selected cross-module critical section.
 * @retval None
 */
static void PLIC_EnableClock(void)
{
    uint32 gate = SMU->ALB0CFGR;

    if (((gate & SMU_ALB0CFGR_PLICEN) != 0U) && ((gate & SMU_ALB0CFGR_PLICRST) != 0U))
    {
        return;
    }

    SMU->ALB0CFGR = gate | SMU_ALB0CFGR_PLICEN | SMU_ALB0CFGR_PLICRST;
}

/**
 * @brief  Writes the priority record of one valid, non-None source.
 * @note   The index of the priority record is independent of the bit position
 *         of the enable register.
 * @param  IRQn: valid interrupt source number (1..50).
 * @param  Priority: priority value already validated against the model range.
 * @retval None
 */
static void PLIC_WritePriority(IRQn_Type IRQn, uint32 Priority)
{
    PLIC->AXI_PLIC_PRIORITY[IRQn - 1U] = Priority;
}

/**
 * @brief  Reads the priority field of one valid, non-None source.
 * @param  IRQn: valid interrupt source number (1..50).
 * @retval uint32: hardware priority field value (bits 7:0).
 */
static uint32 PLIC_ReadPriority(IRQn_Type IRQn)
{
    return (PLIC->AXI_PLIC_PRIORITY[IRQn - 1U] & PLIC_PRIORITY_FIELD_MASK);
}

/**
 * @brief  Sets the enable bit of one valid, non-None source.
 * @note   Sources 1..32 use EN[0] with bit = IRQn - 1; sources 33..50 use
 *         EN[1] with bit = IRQn - 33.  The other sources of the same word keep
 *         their value.
 * @param  IRQn: valid interrupt source number (1..50).
 * @retval None
 */
static void PLIC_EnableSource(IRQn_Type IRQn)
{
    if (IRQn <= PLIC_EN0_MAX_IRQN)
    {
        PLIC->AXI_PLIC_EN[0] |= ((uint32)0x01U << (IRQn - PLIC_EN0_BIT_BASE));
    }
    else
    {
        PLIC->AXI_PLIC_EN[1] |= ((uint32)0x01U << (IRQn - PLIC_EN1_BIT_BASE));
    }
}

/**
 * @brief  Clears the enable bit of one valid, non-None source.
 * @note   The other sources of the same word keep their value.
 * @param  IRQn: valid interrupt source number (1..50).
 * @retval None
 */
static void PLIC_DisableSource(IRQn_Type IRQn)
{
    if (IRQn <= PLIC_EN0_MAX_IRQN)
    {
        PLIC->AXI_PLIC_EN[0] &= ~((uint32)0x01U << (IRQn - PLIC_EN0_BIT_BASE));
    }
    else
    {
        PLIC->AXI_PLIC_EN[1] &= ~((uint32)0x01U << (IRQn - PLIC_EN1_BIT_BASE));
    }
}

/**
 * @brief  Reads the enable bit of one valid, non-None source.
 * @param  IRQn: valid interrupt source number (1..50).
 * @retval uint32: 1 when the enable bit of the source is set, 0 otherwise.
 */
static uint32 PLIC_ReadSourceEnabled(IRQn_Type IRQn)
{
    uint32 enable_reg = 0U;
    uint32 bit_mask   = 0U;

    if (IRQn <= PLIC_EN0_MAX_IRQN)
    {
        enable_reg = PLIC->AXI_PLIC_EN[0];
        bit_mask   = ((uint32)0x01U << (IRQn - PLIC_EN0_BIT_BASE));
    }
    else
    {
        enable_reg = PLIC->AXI_PLIC_EN[1];
        bit_mask   = ((uint32)0x01U << (IRQn - PLIC_EN1_BIT_BASE));
    }

    return ((enable_reg & bit_mask) != 0U) ? 1U : 0U;
}

/* Exported functions --------------------------------------------------------*/

/** @addtogroup PLIC_Exported_Functions
  * @{
  */

/** @addtogroup PLIC_Exported_Functions_Group1 Initialization functions
  * @{
  */

/**
 * @brief  Fills each PLIC_InitStruct member with its default value. (NON-BLOCKING)
 * @param  PLIC_InitStruct: pointer to a PLIC_InitTypeDef structure which
 *         will be initialized.
 * @retval None
 */
void HAL_PLIC_StructInit(PLIC_InitTypeDef *PLIC_InitStruct)
{
    /* Check the PLIC init structure allocation */
    if (PLIC_InitStruct == NULL_PTR)
    {
        return;
    }

    /* Reset the PLIC init structure parameters values */
    PLIC_InitStruct->Size               = sizeof(PLIC_InitTypeDef);  /*!< sizeof struct */
    PLIC_InitStruct->Version            = PLIC_INIT_VERSION;         /*!< V1            */
    PLIC_InitStruct->PLIC_IRQChannel    = None;         /*!< Interrupt source selection */
    PLIC_InitStruct->PLIC_IRQPriority   = 0U;           /*!< Interrupt source priority  */
    PLIC_InitStruct->PLIC_IRQChannelCmd = PLIC_DISABLE; /*!< Interrupt channel enable   */
    PLIC_InitStruct->Reserved[0]        = 0U;           /*!< Reserved for future use    */
    PLIC_InitStruct->Reserved[1]        = 0U;           /*!< Reserved for future use    */
}

/**
 * @brief  Initializes the PLIC interrupt channel according to the specified
 *         parameters in the PLIC_InitStruct. (NON-BLOCKING)
 * @note   Enabling a channel first enables the PLIC clock
 *         (SMU_ALB0CFGR.PLICEN).  IRQChannel = None (0) is ignored.
 * @param  PLIC_InitStruct: pointer to a PLIC_InitTypeDef structure that
 *         contains the configuration information for the specified PLIC
 *         interrupt channel.
 * @retval None
 */
void HAL_PLIC_Init(PLIC_InitTypeDef *PLIC_InitStruct)
{
    /* Check the PLIC init structure allocation */
    if (PLIC_InitStruct == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_PLIC_IRQn(PLIC_InitStruct->PLIC_IRQChannel));
    assert_param(IS_PLIC_PRIORITY(PLIC_InitStruct->PLIC_IRQPriority));

    /* Run time validation, so that the checks stay effective in a build with
     * the assertions disabled. The metafields of the configuration structure
     * (Size / Version, architecture spec section 22) and the two reserved words
     * are validated as well. A rejected call touches no register at all. */
    if ((IS_PLIC_IRQn(PLIC_InitStruct->PLIC_IRQChannel) == 0U) ||
        (IS_PLIC_PRIORITY(PLIC_InitStruct->PLIC_IRQPriority) == 0U) ||
        ((PLIC_InitStruct->PLIC_IRQChannelCmd != PLIC_DISABLE) &&
         (PLIC_InitStruct->PLIC_IRQChannelCmd != PLIC_ENABLE)) ||
        (PLIC_InitStruct->Size != sizeof(PLIC_InitTypeDef)) ||
        (PLIC_InitStruct->Version != PLIC_INIT_VERSION) ||
        (PLIC_InitStruct->Reserved[0] != 0U) ||
        (PLIC_InitStruct->Reserved[1] != 0U))
    {
        return;
    }

    /* None (0) is not a real source: nothing to configure */
    if (PLIC_InitStruct->PLIC_IRQChannel == None)
    {
        return;
    }

    /* Make sure the PLIC clock is running before any register access.  Both the
     * enable branch and the disable branch write a PLIC register (the enable
     * register respectively the priority register), so the clock is guaranteed
     * here, once, ahead of the branch. */
    PLIC_EnableClock();

    if (PLIC_InitStruct->PLIC_IRQChannelCmd != PLIC_DISABLE)
    {
        /* Interrupt source priority selection (gatekeeper value) */
        PLIC_WritePriority(PLIC_InitStruct->PLIC_IRQChannel, PLIC_InitStruct->PLIC_IRQPriority);

        /* Enable the interrupt channel (EN[0]: sources 1..32, EN[1]: 33..50) */
        PLIC_EnableSource(PLIC_InitStruct->PLIC_IRQChannel);
    }
    else
    {
        /* Disable the interrupt channel */
        PLIC_DisableSource(PLIC_InitStruct->PLIC_IRQChannel);
    }
}

/**
  * @}
  */

/** @addtogroup PLIC_Exported_Functions_Group2 Peripheral Control functions
  * @{
  */

/**
 * @brief  Enables a device specific interrupt source in the PLIC. (NON-BLOCKING)
 * @note   The PLIC clock (SMU_ALB0CFGR.PLICEN) is enabled automatically
 *         before the enable bit is written.  IRQn = None (0) is ignored.
 * @param  IRQn: IRQn_Type interrupt source number (1..50).
 * @retval None
 */
void HAL_PLIC_EnableIRQ(IRQn_Type IRQn)
{
    /* Check the parameters */
    assert_param(IS_PLIC_IRQn(IRQn));

    /* Run time validation, so that the checks stay effective in a build with
     * the assertions disabled: an invalid source number is refused here, before
     * the first register access (a rejected call touches no register at all),
     * which also keeps the register index in range. */
    if (IS_PLIC_IRQn(IRQn) == 0U)
    {
        return;
    }

    /* None (0) is not a real source: nothing to configure */
    if (IRQn == None)
    {
        return;
    }

    /* Make sure the PLIC clock is running before any register access */
    PLIC_EnableClock();

    /* Enable the interrupt channel */
    PLIC_EnableSource(IRQn);
}

/**
 * @brief  Disables a device specific interrupt source in the PLIC. (NON-BLOCKING)
 * @param  IRQn: IRQn_Type interrupt source number (1..50).
 * @retval None
 */
void HAL_PLIC_DisableIRQ(IRQn_Type IRQn)
{
    /* Check the parameters */
    assert_param(IS_PLIC_IRQn(IRQn));

    /* Run time validation, so that the checks stay effective in a build with
     * the assertions disabled: an invalid source number is refused here, before
     * the first register access (a rejected call touches no register at all),
     * which also keeps the register index in range. */
    if (IS_PLIC_IRQn(IRQn) == 0U)
    {
        return;
    }

    /* None (0) is not a real source: nothing to configure */
    if (IRQn == None)
    {
        return;
    }

    /* Ensure the PLIC clock is running before accessing its registers. */
    PLIC_EnableClock();

    /* Disable the interrupt channel */
    PLIC_DisableSource(IRQn);
}

/**
 * @brief  Sets the priority of an interrupt source in the PLIC. (NON-BLOCKING)
 * @note   PLIC priority semantics: 0 disables the source, 1..63 enable it,
 *         a larger value has a higher priority (opposite to conventional priority ordering).
 *         IRQn = None (0) is ignored.
 * @param  IRQn: IRQn_Type interrupt source number (1..50).
 * @param  Priority: PLIC_PRIORITY_MIN..PLIC_PRIORITY_MAX (0x00..0x3F).
 * @retval None
 */
void HAL_PLIC_SetPriority(IRQn_Type IRQn, uint32 Priority)
{
    /* Check the parameters */
    assert_param(IS_PLIC_IRQn(IRQn));
    assert_param(IS_PLIC_PRIORITY(Priority));

    /* Run time validation, so that the checks stay effective in a build with
     * the assertions disabled: an invalid source number or an out of range
     * priority is refused here, before the first register access (a rejected
     * call touches no register at all). */
    if ((IS_PLIC_IRQn(IRQn) == 0U) || (IS_PLIC_PRIORITY(Priority) == 0U))
    {
        return;
    }

    /* None (0) is not a real source: nothing to configure */
    if (IRQn == None)
    {
        return;
    }

    /* Make sure the PLIC clock is running before any register access */
    PLIC_EnableClock();

    /* Interrupt source priority selection */
    PLIC_WritePriority(IRQn, Priority);
}

/**
 * @brief  Gets the priority of an interrupt source in the PLIC. (NON-BLOCKING)
 * @param  IRQn: IRQn_Type interrupt source number (1..50).
 * @retval uint32: current priority value (0x00..0x3F); 0 for IRQn = None.
 */
uint32 HAL_PLIC_GetPriority(IRQn_Type IRQn)
{
    /* Check the parameters */
    assert_param(IS_PLIC_IRQn(IRQn));

    /* Run time validation, so that the checks stay effective in a build with
     * the assertions disabled: an invalid source number is refused here, so that
     * the register read stays in range. */
    if (IS_PLIC_IRQn(IRQn) == 0U)
    {
        return 0U;
    }

    if (IRQn == None)
    {
        return 0U;
    }

    /* Ensure the PLIC clock is running before accessing its registers. */
    PLIC_EnableClock();

    /* Return the source priority */
    return PLIC_ReadPriority(IRQn);
}

/**
 * @brief  Reads the enable status of an interrupt source in the PLIC. (NON-BLOCKING)
 * @param  IRQn: IRQn_Type interrupt source number (1..50).
 * @retval uint32: 1 if the source is enabled, 0 otherwise (also for
 *         IRQn = None).
 */
uint32 HAL_PLIC_GetEnabledIRQ(IRQn_Type IRQn)
{
    /* Check the parameters */
    assert_param(IS_PLIC_IRQn(IRQn));

    /* Run time validation, so that the checks stay effective in a build with
     * the assertions disabled: an invalid source number is refused here, so that
     * the register read stays in range. */
    if (IS_PLIC_IRQn(IRQn) == 0U)
    {
        return 0U;
    }

    if (IRQn == None)
    {
        return 0U;
    }

    /* Ensure the PLIC clock is running before accessing its registers. */
    PLIC_EnableClock();

    /* Return 1 if enabled else 0 */
    return PLIC_ReadSourceEnabled(IRQn);
}

/**
  * @}
  */

/**
  * @}
  */

#endif /* HAL_PLIC_MODULE_ENABLED */

/* Weak interrupt handler stubs ---------------------------------------------*/
/*
 * Default (weak) implementations of the interrupt / exception handlers
 * declared in as32x601_hal_plic.h and referenced by the as32x601_trapentry
 * assembly module.  A strong user definition, wherever it is placed (main.c,
 * a driver module, ...), overrides the stub at link time.
 *
 * These definitions deliberately sit OUTSIDE the HAL_PLIC_MODULE_ENABLED
 * section above: the trap entry references every handler unconditionally, so
 * the symbols must exist even when the PLIC HAL API is switched off
 * (otherwise the link fails with Error[Li005] no definition).
 *
 * NOTE: keep them in a single .c module.  A __weak definition in a header
 * would be emitted into every module that includes it, which would prevent
 * those modules from supplying their own strong handler (Error[Pe247]).
 */

/**
 * @brief Default hook for unregistered / unhandled interrupt sources.
 * @note  Spins forever: reaching it means an unexpected trap was taken.
 */
__weak void Default_Int_Handler(void)
{
    for (;;)
    {
    }
}

/* PLIC interrupt source handlers ------------------------------------------*/
__weak void EFLASH_IRQ_Handler(void)          { Default_Int_Handler(); }
__weak void FCU_IRQ_Handler(void)             { Default_Int_Handler(); }
__weak void DMA0_IRQ_Handler(void)            { Default_Int_Handler(); }
__weak void DMA1_IRQ_Handler(void)            { Default_Int_Handler(); }
__weak void TIM0_IRQ_Handler(void)            { Default_Int_Handler(); }
__weak void CANFD0_IRQ_Handler(void)          { Default_Int_Handler(); }
__weak void CANFD1_IRQ_Handler(void)          { Default_Int_Handler(); }
__weak void ADC0_IRQ_Handler(void)            { Default_Int_Handler(); }
__weak void ADC1_IRQ_Handler(void)            { Default_Int_Handler(); }
__weak void GPIOA_IRQ_Handler(void)           { Default_Int_Handler(); }
__weak void GPIOB_IRQ_Handler(void)           { Default_Int_Handler(); }
__weak void GPIOC_IRQ_Handler(void)           { Default_Int_Handler(); }
__weak void PKA_IRQ_Handler(void)             { Default_Int_Handler(); }
__weak void SPACC_IRQ_Handler(void)           { Default_Int_Handler(); }
__weak void TRNG_IRQ_Handler(void)            { Default_Int_Handler(); }
__weak void TIM1_IRQ_Handler(void)            { Default_Int_Handler(); }
__weak void CANFD2_IRQ_Handler(void)          { Default_Int_Handler(); }
__weak void CANFD3_IRQ_Handler(void)          { Default_Int_Handler(); }
__weak void GPIOD_IRQ_Handler(void)           { Default_Int_Handler(); }
__weak void GPIOE_IRQ_Handler(void)           { Default_Int_Handler(); }
__weak void GPIOF_IRQ_Handler(void)           { Default_Int_Handler(); }
__weak void GPIOG_IRQ_Handler(void)           { Default_Int_Handler(); }
__weak void MAC_IRQ_Handler(void)             { Default_Int_Handler(); }
__weak void SPI0_IRQ_Handler(void)            { Default_Int_Handler(); }
__weak void SPI1_IRQ_Handler(void)            { Default_Int_Handler(); }
__weak void SPI2_IRQ_Handler(void)            { Default_Int_Handler(); }
__weak void I2C0_IRQ_Handler(void)            { Default_Int_Handler(); }
__weak void I2C1_IRQ_Handler(void)            { Default_Int_Handler(); }
__weak void USART0_IRQ_Handler(void)          { Default_Int_Handler(); }
__weak void USART1_IRQ_Handler(void)          { Default_Int_Handler(); }
__weak void USART2_IRQ_Handler(void)          { Default_Int_Handler(); }
__weak void USART3_IRQ_Handler(void)          { Default_Int_Handler(); }
__weak void TIM2_IRQ_Handler(void)            { Default_Int_Handler(); }
__weak void TIM3_IRQ_Handler(void)            { Default_Int_Handler(); }
__weak void TIM4_IRQ_Handler(void)            { Default_Int_Handler(); }
__weak void SPI3_IRQ_Handler(void)            { Default_Int_Handler(); }
__weak void SPI4_IRQ_Handler(void)            { Default_Int_Handler(); }
__weak void SPI5_IRQ_Handler(void)            { Default_Int_Handler(); }
__weak void I2C2_IRQ_Handler(void)            { Default_Int_Handler(); }
__weak void I2C3_IRQ_Handler(void)            { Default_Int_Handler(); }
__weak void USART4_IRQ_Handler(void)          { Default_Int_Handler(); }
__weak void USART5_IRQ_Handler(void)          { Default_Int_Handler(); }
__weak void USART6_IRQ_Handler(void)          { Default_Int_Handler(); }
__weak void USART7_IRQ_Handler(void)          { Default_Int_Handler(); }
__weak void TIM5_IRQ_Handler(void)            { Default_Int_Handler(); }
__weak void TIM6_IRQ_Handler(void)            { Default_Int_Handler(); }
__weak void TIM7_IRQ_Handler(void)            { Default_Int_Handler(); }
__weak void GPIOH_IRQ_Handler(void)           { Default_Int_Handler(); }
__weak void RTC_IRQ_Handler(void)             { Default_Int_Handler(); }

/* Core interrupt handlers -------------------------------------------------*/
__weak void MSoftWare_IRQ_Handler(void)        { Default_Int_Handler(); }
__weak void MTimer_IRQ_Handler(void)           { Default_Int_Handler(); }

/* Exception handlers ------------------------------------------------------*/
__weak void InstAddrMisalign_Handler(void)     { Default_Int_Handler(); }
__weak void InstAccessFault_Handler(void)      { Default_Int_Handler(); }
__weak void IllegalInst_Handler(void)          { Default_Int_Handler(); }
__weak void Breakpoint_Handler(void)           { Default_Int_Handler(); }
__weak void LoadAddrMisalign_Handler(void)     { Default_Int_Handler(); }
__weak void LoadAccessFault_Handler(void)      { Default_Int_Handler(); }
__weak void StoreAMOAddrMisalign_Handler(void) { Default_Int_Handler(); }
__weak void StoreAMOAccessFault_Handler(void)  { Default_Int_Handler(); }
__weak void ECall_Handler(void)                { Default_Int_Handler(); }
__weak void InstPageFault_Handler(void)        { Default_Int_Handler(); }
__weak void LoadPageFault_Handler(void)        { Default_Int_Handler(); }
__weak void StoreAMOPageFault_Handler(void)    { Default_Int_Handler(); }

/*****END OF FILE*****/
