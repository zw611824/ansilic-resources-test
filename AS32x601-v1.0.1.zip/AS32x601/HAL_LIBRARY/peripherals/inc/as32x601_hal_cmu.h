/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_cmu.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.4
 * Date:   2026/10/09
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.1     expose the shared lock
 *                                                       helpers CMU_LockHandle /
 *                                                       CMU_UnlockHandle (the
 *                                                       RTOS branch uses the
 *                                                       LockMutex handle) and
 *                                                       protect every register
 *                                                       writing function with
 *                                                       them (Init / DeInit /
 *                                                       Cmd / SetMode /
 *                                                       SetWindowLength /
 *                                                       SetReferenceThreshold /
 *                                                       ClearFlag); the read-only
 *                                                       functions stay lock-free
 *     ANSILIC APPLICATION GROUP  2026/09/11     1.2     fix the polarity of the CMU reset bit
 *                                                       in HAL_CMU_MspInit (the reset is
 *                                                       released by setting the bit, not by
 *                                                       clearing it)
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.3     apply the resource lock / RTOS rules:
 *                                                       run the MSP callbacks outside the
 *                                                       locked region, add a Timeout and a
 *                                                       NULL-mutex guard to the lock helper,
 *                                                       add the busy / reset state gate,
 *                                                       return HAL_StatusTypeDef from the
 *                                                       control setters with run-time
 *                                                       parameter validation, drop the unused
 *                                                       timeout error code
 *     ANSILIC APPLICATION GROUP  2026/10/09     1.4     merge the capabilities of the System
 *                                                       Management release of 2026/09/29 into
 *                                                       this driver: add the window length
 *                                                       lower bound CMU_WINLEN_MIN (the
 *                                                       reference counter minimum value
 *                                                       documented for the hardware) and make
 *                                                       HAL_CMU_StructInit() default to it,
 *                                                       accept a mask of flags in
 *                                                       HAL_CMU_GetFlagStatus() and a mask of
 *                                                       latched events in HAL_CMU_ClearFlag()
 *                                                       with the new CMU_FLAG_ALL constant,
 *                                                       make HAL_CMU_Cmd() enable the
 *                                                       monitoring with the mode recorded in
 *                                                       the handle (a handle without a
 *                                                       recorded non-zero mode keeps the
 *                                                       earlier all ones enable value)
 *                                                       and record the
 *                                                       values programmed by the setters, add
 *                                                       the instance binding check to the
 *                                                       read-only interfaces and to
 *                                                       HAL_CMU_MspInit() /
 *                                                       HAL_CMU_MspDeInit() (their
 *                                                       default no longer falls
 *                                                       back to the CMU3 clock
 *                                                       gate), record the values
 *                                                       programmed by every
 *                                                       setter (mode, window
 *                                                       length and both
 *                                                       thresholds) in the handle
 *                                                       Init structure, and align
 *                                                       HAL_CMU_ERROR_INVALID_PARAM with the
 *                                                       SMU / PMU siblings (0x1)
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Clock Monitoring Unit
 *                  (CMU) of the AS32x601:
 *                  - Initialization and de-initialization: HAL_CMU_Init /
 *                    HAL_CMU_DeInit, configuration structure handling;
 *                  - Peripheral control: enable / disable the monitoring,
 *                    set the monitoring mode, the reference count window
 *                    length and the high / low frequency reference
 *                    thresholds;
 *                  - Flag management: query and clear the monitoring
 *                    status flags;
 *                  - State and error reporting.
 *
 *                  The CMU monitors a clock source (FIRC / PLLQ / PLLR /
 *                  OSC) against a reference count window: the controller
 *                  counts the clock cycles during a window of WINLEN
 *                  reference-clock cycles and compares the result with the
 *                  high (HFREF) and low (LFREF) frequency reference
 *                  thresholds. The monitoring result is reported through
 *                  the status flags (WORK, FHH, FLL, LOSSCLK, CHCDONE).
 * @note            All the register writing interfaces (Init / DeInit / Cmd /
 *                  SetMode / SetWindowLength / SetReferenceThreshold /
 *                  ClearFlag) take the handle lock and reject a call when the
 *                  handle is busy or not initialized; the read-only interfaces
 *                  (GetFlagStatus / GetState / GetError) are lock-free.
 * @complexity  Simple
 *              Polling only, lock + state machine + error code, no blocking
 *              operation and no interrupt mode.
 */
#ifndef __AS32X601_HAL_CMU_H
#define __AS32X601_HAL_CMU_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "as32x601.h"               /* CMU_TypeDef, CMU register bits         */
#include "as32x601_hal_def.h"       /* HAL_StatusTypeDef, HAL_LockTypeDef     */

/**
 * @brief CMU HAL driver module version.
 * @note  0x0100U = V1.0. Bumped only on breaking API changes (architecture
 *        spec COMPAT-13/14/15).
 */
#define __HAL_CMU_MODULE_VERSION  0x0100U

/* Exported types ------------------------------------------------------------*/

/** @defgroup CMU_Exported_Types CMU Exported Types
  * @{
  */

/**
 * @brief CMU configuration structure definition.
 * @note  The field values directly map to the CMU registers: MonitoringMode
 *        is the CR.MODE field, WindowLength the CCR.WINLEN field, and
 *        HighThreshold / LowThreshold the HTCR.HFREF / LTCR.LFREF fields.
 * @note  This structure follows the Version+Size compatibility mechanism
 *        (architecture spec section 22): the user must clear the structure
 *        (__HAL_CLEAR_STRUCT / memset), set the Size and Version metafields
 *        before filling the business fields (see HAL_CMU_StructInit()).
 */
typedef struct
{
    uint32 Size;                /*!< sizeof(CMU_InitTypeDef), must be set by the user
                                     after clearing the structure           */
    uint32 Version;             /*!< Structure semantic version: @ref CMU_INIT_VERSION
                                     (CMU_INIT_V1 = 0x0100U)                */
    uint32 MonitoringMode;      /*!< Clock monitoring mode: CMU_MODE_0..CMU_MODE_7
                                     (0 disables the monitoring, a non-zero
                                     value selects the monitoring mode)      */
    uint32 WindowLength;        /*!< Reference count window length, in reference
                                     clock cycles (CMU_WINLEN_MIN..CMU_WINLEN_MAX,
                                     CCR.WINLEN)                             */
    uint32 HighThreshold;       /*!< High frequency reference threshold
                                     (0..0xFFFFFF, HTCR.HFREF)               */
    uint32 LowThreshold;        /*!< Low frequency reference threshold
                                     (0..0xFFFFFF, LTCR.LFREF)               */
    uint32 Reserved[2];         /*!< Reserved for future extension (must be 0)     */
} CMU_InitTypeDef;

/**
 * @brief CMU / init structure version macros.
 * @note  CMU_INIT_V1 is the current version. Future versions (e.g. V2 with
 *        new fields) must be appended after the existing fields without
 *        changing the layout (architecture spec section 22.5).
 */
#define CMU_INIT_V1  0x0100U   /*!< CMU Init structure version V1.0 */
#define CMU_INIT_VERSION  CMU_INIT_V1   /*!< Current CMU Init structure version */

/**
 * @brief HAL CMU state structures definition.
 */
typedef enum
{
    HAL_CMU_STATE_RESET      = 0x00U, /*!< Peripheral not initialized          */
    HAL_CMU_STATE_READY      = 0x01U, /*!< Peripheral initialized and ready    */
    HAL_CMU_STATE_BUSY       = 0x02U, /*!< An internal process is ongoing      */
    HAL_CMU_STATE_ERROR      = 0x03U  /*!< CMU error state                     */
} HAL_CMU_StateTypeDef;

/**
 * @brief CMU handle structure definition.
 */
typedef struct __HAL_CMU_HandleTypeDef
{
    CMU_TypeDef               *Instance;      /*!< CMU registers base address    */
    CMU_InitTypeDef           Init;           /*!< CMU configuration parameters  */
    HAL_LockTypeDef           Lock;           /*!< Locking object                */
    __IO HAL_CMU_StateTypeDef State;          /*!< CMU communication state       */
    __IO uint32               ErrorCode;      /*!< CMU error code                */
#if (USE_RTOS == 1)
    HAL_MutexTypeDef          LockMutex;      /*!< RTOS mutex handle (created by the
                                                   user porting layer, e.g. in
                                                   HAL_CMU_MspInit)             */
#endif /* USE_RTOS */
} HAL_CMU_HandleTypeDef;

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @defgroup CMU_Exported_Constants CMU Exported Constants
  * @{
  */

/** @defgroup CMU_Error_Code CMU Error Code
  * @note  The codes are independent bit flags so that a combination can be
  *        reported with the bitwise OR operator.
  * @{
  */
#define HAL_CMU_ERROR_NONE          ((uint32)0x00000000U) /*!< No error                             */
#define HAL_CMU_ERROR_INVALID_PARAM ((uint32)0x00000001U) /*!< Invalid parameter, invalid
                                                               configuration structure or a
                                                               rejected operation              */
/**
  * @}
  */

/** @defgroup CMU_Mode CMU Monitoring Mode
  * @note  The values are the CR.MODE field values (3 bits). A zero value
  *        disables the monitoring, a non-zero value enables it and selects
  *        the monitoring mode.
  * @{
  */
#define CMU_MODE_0                  ((uint32)0x00000000U) /*!< Monitoring disabled  */
#define CMU_MODE_1                  ((uint32)0x00000001U) /*!< Monitoring mode 1    */
#define CMU_MODE_2                  ((uint32)0x00000002U) /*!< Monitoring mode 2    */
#define CMU_MODE_3                  ((uint32)0x00000003U) /*!< Monitoring mode 3    */
#define CMU_MODE_4                  ((uint32)0x00000004U) /*!< Monitoring mode 4    */
#define CMU_MODE_5                  ((uint32)0x00000005U) /*!< Monitoring mode 5    */
#define CMU_MODE_6                  ((uint32)0x00000006U) /*!< Monitoring mode 6    */
#define CMU_MODE_7                  ((uint32)0x00000007U) /*!< Monitoring mode 7    */
/**
  * @}
  */

/** @defgroup CMU_Window_Length CMU Reference Count Window Length
  * @note  The window length is written to the CCR.WINLEN field. The hardware
  *        counts the monitored clock cycles during a window of that many
  *        reference clock cycles, so the counter has a documented minimum
  *        value below which the count would be meaningless.
  * @{
  */
#define CMU_WINLEN_MIN              ((uint32)10U)         /*!< Reference counter minimum value   */
#define CMU_WINLEN_MAX              ((uint32)0x00FFFFFFU) /*!< Reference counter maximum value   */
/**
  * @}
  */

/** @defgroup CMU_Flags CMU Status Flags
  * @note  The values are the SR register bit positions.
  * @{
  */
#define CMU_FLAG_WORK               ((uint32)CMU_SR_WORK)    /*!< Working condition    */
#define CMU_FLAG_CHCDONE            ((uint32)CMU_SR_CHCDONE) /*!< Status detection     */
#define CMU_FLAG_LOSSCLK            ((uint32)CMU_SR_LOSSCLK) /*!< Clock loss status    */
#define CMU_FLAG_FHH                ((uint32)CMU_SR_FHH)     /*!< Frequency above the high
                                                                  reference threshold  */
#define CMU_FLAG_FLL                ((uint32)CMU_SR_FLL)     /*!< Frequency below the low
                                                                  reference threshold  */
/**
  * @brief  All the status flags accepted by HAL_CMU_GetFlagStatus().
  * @note   The query accepts any non-zero combination of these flags and
  *         reports whether at least one of the selected flags is set.
  */
#define CMU_FLAG_ALL                (CMU_FLAG_WORK | CMU_FLAG_CHCDONE | \
                                     CMU_FLAG_LOSSCLK | CMU_FLAG_FHH | CMU_FLAG_FLL)
/**
  * @}
  */

/** @defgroup CMU_Flag_Clear CMU Flag Clear Values
  * @note  The values are the SR register write values (write 1 to clear).
  * @{
  */
#define CMU_CLEAR_FLL               ((uint32)CMU_SR_FLL)      /*!< Clear the FLL flag   */
#define CMU_CLEAR_FHH               ((uint32)CMU_SR_FHH)      /*!< Clear the FHH flag   */
/**
  * @}
  */

/** @defgroup CMU_Enable_Value CMU Enable Value
  * @{
  */
#define CMU_ENABLE                  1U       /*!< Enable the CMU monitoring     */
#define CMU_DISABLE                 0U       /*!< Disable the CMU monitoring    */
/**
  * @}
  */

/**
  * @}
  */

/* Exported macros ------------------------------------------------------------*/

/** @defgroup CMU_Exported_Macros CMU Exported Macros
  * @{
  */

/**
 * @brief  Reset the handle State field.
 * @note   Must be used before passing a local handle to HAL_CMU_Init() the
 *         first time, so that the low level initialization (MspInit) is
 *         always executed.
 */
#define __HAL_CMU_RESET_HANDLE_STATE(__HANDLE__) ((__HANDLE__)->State = 0U)

/**
 * @brief  Enable the CMU monitoring (set the CR.MODE field).
 * @note   The macros below directly access the peripheral registers and do
 *         not check the handle: the caller must guarantee a valid handle.
 */
#define __HAL_CMU_ENABLE(__HANDLE__)            ((__HANDLE__)->Instance->CR |= (CMU_CR_MODE))

/**
 * @brief  Disable the CMU monitoring (clear the CR.MODE field).
 */
#define __HAL_CMU_DISABLE(__HANDLE__)           ((__HANDLE__)->Instance->CR &= ~(CMU_CR_MODE))

/**
 * @brief  Check whether a CMU status flag is set.
 * @param  __FLAG__: CMU_FLAG_xxx (SR bit position).
 * @retval 1 if the flag is set, 0 otherwise.
 */
#define __HAL_CMU_GET_FLAG(__HANDLE__, __FLAG__) (((__HANDLE__)->Instance->SR & (__FLAG__)) != 0U)

/**
 * @brief  Clear a CMU status flag.
 * @param  __FLAG__: CMU_CLEAR_xxx (SR write value).
 */
#define __HAL_CMU_CLEAR_FLAG(__HANDLE__, __FLAG__) ((__HANDLE__)->Instance->SR = (__FLAG__))

/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/

/** @addtogroup CMU_Exported_Functions
  * @{
  */

/** @addtogroup CMU_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Fills each CMU_InitStruct member with its default value
 *         (monitoring disabled, window length = CMU_WINLEN_MIN, thresholds =
 *         0). (NON-BLOCKING)
 * @param  CMU_InitStruct: pointer to a CMU_InitTypeDef structure which
 *         will be initialized.
 * @retval None
 * @note   The window length default is the minimum legal value, so that the
 *         filled structure is accepted by HAL_CMU_Init() as is.
 */
void HAL_CMU_StructInit(CMU_InitTypeDef *CMU_InitStruct);

/**
 * @brief  Initializes the CMU according to the specified parameters in the
 *         CMU_InitStruct of the handle. (NON-BLOCKING)
 * @note   The CMU clock gating is enabled by the default HAL_CMU_MspInit()
 *         through the SMU_ALB0CFGR register; the user may override it.
 * @note   After the initialization the monitoring state depends on the
 *         MonitoringMode field: 0 keeps the monitoring disabled, a non-zero
 *         value enables it with the selected mode.
 * @note   The parameters and the configuration structure metafields (Size /
 *         Version) are validated at run time: an invalid configuration is
 *         rejected with HAL_ERROR and HAL_CMU_ERROR_INVALID_PARAM without
 *         changing the handle state.
 * @note   LOCK-06: the low level initialization (HAL_CMU_MspInit()) runs
 *         before the handle is locked.
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (NULL pointer, invalid instance or invalid
 *         configuration)
 */
HAL_StatusTypeDef HAL_CMU_Init(HAL_CMU_HandleTypeDef *hcmu);

/**
 * @brief  De-initializes the CMU peripheral. (NON-BLOCKING)
 * @note   The monitoring is disabled and the configuration registers
 *         (CR / CCR / HTCR / LTCR) are cleared; the handle goes back to the
 *         RESET state so that a following HAL_CMU_Init() re-runs
 *         HAL_CMU_MspInit().
 * @note   The call is accepted from any handle state, so that a failed
 *         initialization can always be undone.
 * @note   LOCK-06: the low level de-initialization (HAL_CMU_MspDeInit()) runs
 *         after the unlock.
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY (the handle lock could not be
 *         taken) / HAL_ERROR (NULL pointer or invalid instance)
 */
HAL_StatusTypeDef HAL_CMU_DeInit(HAL_CMU_HandleTypeDef *hcmu);

/**
 * @brief  Initializes the CMU MSP. Weak function; the default implementation
 *         enables the selected CMU clock and releases its reset through the
 *         SMU_ALB0CFGR register.
 * @note   The instance binding is validated before the first register access:
 *         a NULL handle or an instance outside the four CMU register blocks
 *         returns without touching any register.
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @retval None
 */
void HAL_CMU_MspInit(HAL_CMU_HandleTypeDef *hcmu);

/**
 * @brief  De-initializes the CMU MSP. Weak function; the default
 *         implementation disables the selected CMU clock.
 * @note   The instance binding is validated before the first register access:
 *         a NULL handle or an instance outside the four CMU register blocks
 *         returns without touching any register.
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @retval None
 */
void HAL_CMU_MspDeInit(HAL_CMU_HandleTypeDef *hcmu);

/**
  * @}
  */

/** @addtogroup CMU_Exported_Functions_Group2 Peripheral Control functions
  * @{
  */

/**
 * @brief  Enables or disables the CMU clock monitoring. (NON-BLOCKING)
 * @note   The enable writes the non-zero monitoring mode recorded in the
 *         handle (the value programmed by HAL_CMU_Init() or the last
 *         HAL_CMU_SetMode()), so that a mode already selected by the caller
 *         is not overwritten; a handle that has no recorded non-zero mode
 *         still enables the monitoring, with the enable value used by the
 *         earlier releases (every bit of the CR.MODE field set). The disable
 *         writes the disabled mode (CMU_MODE_0).
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_CMU_Init() is required first).
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @param  NewState: ENABLE or DISABLE (CMU_ENABLE / CMU_DISABLE).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_CMU_Cmd(HAL_CMU_HandleTypeDef *hcmu, FunctionalState NewState);

/**
 * @brief  Sets the CMU monitoring mode (CR.MODE field). (NON-BLOCKING)
 * @note   The accepted value is recorded in the MonitoringMode field of the
 *         handle Init structure, so that a following HAL_CMU_Cmd(CMU_ENABLE)
 *         restarts the monitoring with this mode.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_CMU_Init() is required first).
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @param  Mode: CMU_MODE_0..CMU_MODE_7 (0 disables the monitoring).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_CMU_SetMode(HAL_CMU_HandleTypeDef *hcmu, uint32 Mode);

/**
 * @brief  Sets the reference count window length (CCR.WINLEN field). (NON-BLOCKING)
 * @note   The accepted value is recorded in the WindowLength field of the
 *         handle Init structure, so that the handle configuration stays in
 *         step with the register.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_CMU_Init() is required first).
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @param  WindowLength: window length in reference clock cycles
 *         (CMU_WINLEN_MIN..CMU_WINLEN_MAX).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_CMU_SetWindowLength(HAL_CMU_HandleTypeDef *hcmu, uint32 WindowLength);

/**
 * @brief  Sets the high and low frequency reference thresholds
 *         (HTCR.HFREF / LTCR.LFREF fields). (NON-BLOCKING)
 * @note   The accepted values are recorded in the HighThreshold /
 *         LowThreshold fields of the handle Init structure, so that the
 *         handle configuration stays in step with the registers.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_CMU_Init() is required first).
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @param  HighThreshold: high frequency reference threshold (0..0xFFFFFF).
 * @param  LowThreshold: low frequency reference threshold (0..0xFFFFFF).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_CMU_SetReferenceThreshold(HAL_CMU_HandleTypeDef *hcmu, uint32 HighThreshold,
                                                uint32 LowThreshold);

/**
  * @}
  */

/** @addtogroup CMU_Exported_Functions_Group3 Flag and State functions
  * @{
  */

/**
 * @brief  Checks whether one or more CMU status flags are set. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context. The instance binding is validated before the
 *         status register is read.
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @param  CMU_FLAG: the flag or the mask of flags to check (a non-zero
 *         combination of the CMU_FLAG_xxx values, e.g. CMU_FLAG_ALL).
 * @retval 1 if at least one of the selected flags is set, 0 otherwise (also
 *         when the handle, the instance binding or the mask is invalid).
 */
uint32 HAL_CMU_GetFlagStatus(HAL_CMU_HandleTypeDef *hcmu, uint32 CMU_FLAG);

/**
 * @brief  Clears one or more latched CMU status flags. (NON-BLOCKING)
 * @note   The selected mask is written directly to the status register
 *         (write 1 to clear) without a read-modify-write cycle, so that a
 *         latched event that appears at the same time is not lost. The mask
 *         accepts a single event or the combination of both latched events
 *         (CMU_CLEAR_FLL | CMU_CLEAR_FHH); the read-only states have no
 *         documented clear bit.
 * @note   ARCH-CONST-09: the call is rejected with HAL_BUSY while another
 *         operation is ongoing and with HAL_ERROR when the handle has not
 *         been initialized (HAL_CMU_Init() is required first).
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @param  CMU_FLAG: the mask to clear (CMU_CLEAR_FLL, CMU_CLEAR_FHH or their
 *         combination; SR write value).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR (NULL pointer,
 *         invalid instance, invalid parameter or the handle is not
 *         initialized)
 */
HAL_StatusTypeDef HAL_CMU_ClearFlag(HAL_CMU_HandleTypeDef *hcmu, uint32 CMU_FLAG);

/**
 * @brief  Returns the CMU handle state. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context. The instance binding is validated before the
 *         handle state is read.
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @retval HAL_CMU_StateTypeDef: the current handle state; HAL_CMU_STATE_RESET
 *         when the handle is NULL or bound to an address outside the four CMU
 *         register blocks.
 */
HAL_CMU_StateTypeDef HAL_CMU_GetState(HAL_CMU_HandleTypeDef *hcmu);

/**
 * @brief  Returns the CMU error code. (NON-BLOCKING)
 * @note   Read-only interface: it takes no lock, so it is callable from an
 *         interrupt context. The instance binding is validated before the
 *         handle error code is read.
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @retval uint32: the CMU error code (HAL_CMU_ERROR_xxx); HAL_CMU_ERROR_NONE
 *         when the handle is NULL and HAL_CMU_ERROR_INVALID_PARAM when the
 *         handle is bound to an address outside the four CMU register blocks.
 */
uint32 HAL_CMU_GetError(HAL_CMU_HandleTypeDef *hcmu);

/**
  * @}
  */

/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/

/** @defgroup CMU_Private_Macros CMU Private Macros
  * @{
  */

/**
 * @brief  Check that the CMU peripheral instance is valid.
 */
#define IS_CMU_ALL_INSTANCE(INSTANCE) (((INSTANCE) == CMU_FIRC) || \
                                       ((INSTANCE) == CMU_PLLQ) || \
                                       ((INSTANCE) == CMU_PLLR) || \
                                       ((INSTANCE) == CMU_OSC))

/**
 * @brief  Check that the monitoring mode is a valid value (0..7).
 */
#define IS_CMU_MODE(MODE) ((MODE) <= 0x7U)

/**
 * @brief  Check that the window length is a valid value
 *         (CMU_WINLEN_MIN..CMU_WINLEN_MAX).
 * @note   The lower bound is the documented minimum value of the reference
 *         counter; a shorter window would not produce a meaningful count.
 */
#define IS_CMU_WINDOW_LENGTH(LENGTH) (((LENGTH) >= CMU_WINLEN_MIN) && \
                                      ((LENGTH) <= CMU_WINLEN_MAX))

/**
 * @brief  Check that a frequency reference threshold is a valid value
 *         (0..0xFFFFFF).
 */
#define IS_CMU_THRESHOLD(THRESHOLD) ((THRESHOLD) <= 0xFFFFFFU)

/**
 * @brief  Check that the flag mask is valid: a non-zero combination of the
 *         five status flags.
 * @note   A single flag is the special case of a one bit mask.
 */
#define IS_CMU_FLAG(FLAG) (((FLAG) != 0U) && (((FLAG) & ~(CMU_FLAG_ALL)) == 0U))

/**
 * @brief  Check that the flag clear mask is valid: a non-zero combination of
 *         the two latched events.
 * @note   A single event is the special case of a one bit mask.
 */
#define IS_CMU_CLEAR(CLEAR) (((CLEAR) != 0U) && \
                             (((CLEAR) & ~(CMU_CLEAR_FLL | CMU_CLEAR_FHH)) == 0U))

/**
 * @brief  Check that the enable value is valid.
 * @note   Kept for backward compatibility: the driver validates the parameter
 *         of HAL_CMU_Cmd() with the library wide IS_FUNCTIONAL_STATE() macro
 *         (the CMU_ENABLE / CMU_DISABLE constants themselves stay in use).
 */
#define IS_CMU_ENABLE_STATE(NEWSTATE) (((NEWSTATE) == CMU_ENABLE) || ((NEWSTATE) == CMU_DISABLE))

/**
  * @}
  */

/* Shared internal functions --------------------------------------------------*/

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_CMU_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; when the mutex is not acquired before the
 *         Timeout expires, HAL_TIMEOUT is returned. The value is passed to
 *         HAL_MutexAcquire() as is (RTOS ticks; with the usual 1 ms tick it is
 *         the same quantity as the millisecond Timeout of the public API, and
 *         HAL_MAX_DELAY means an infinite wait).
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef CMU_LockHandle(HAL_CMU_HandleTypeDef *hcmu, uint32 Timeout);

/**
 * @brief  Unlock the handle.
 * @param  hcmu: pointer to a HAL_CMU_HandleTypeDef structure.
 * @retval None
 */
void CMU_UnlockHandle(HAL_CMU_HandleTypeDef *hcmu);

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_CMU_H */

/*****END OF FILE*****/
