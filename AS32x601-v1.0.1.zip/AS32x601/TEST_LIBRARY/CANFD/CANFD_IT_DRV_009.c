/**
 * @file    CANFD_IT_DRV_009.c
 * @brief   HAL CANFD integration test case 009 (multi buffer concurrent transmission).
 *
 * HAL port of the AS32x601 standard-library test case
 * CANFD_IT_DRV_009.c.  The subject is the queue of the transmit
 * buffers (several requests pending at the same time) instead of a
 * single round trip, so this case does not repeat case 001.
 *
 * Tested functionality:
 *   HAL_CANFD_StructInit() / HAL_CANFD_Init() / HAL_CANFD_DeInit()
 *   HAL_CANFD_FilterInit()
 *   HAL_CANFD_MspInit() (driver hook, overridden by the case)
 *   HAL_CANFD_GetState() / HAL_CANFD_GetError()
 *   HAL_CANFD_FrameStructInit() / HAL_CANFD_FrameInit()
 *   HAL_CANFD_Transmit() / HAL_CANFD_GetSendCmpStatus()
 *   HAL_CANFD_SetSendChannel() / HAL_CANFD_GetReceiveBytes() /
 *   HAL_CANFD_GetReceiveData() / HAL_CANFD_GetRxFillLevel()
 *   HAL_CANFD_GetTXErrorCount() / HAL_CANFD_GetRXErrorCount() /
 *
 * Test procedure:
 *   1. initialize the controller and verify that the transmit request register
 *      is clear at start;
 *   2. enable the transmit / receive completion interrupts and the PLIC source;
 *   3. configure four buffers with different identifier, format and length
 *      (0x147 standard 8 B, 0x258 standard 12 B, 0x269 standard 24 B,
 *       0x147 extended 64 B);
 *   4. request all four frames back to back, without waiting for the previous
 *      one to leave the controller, so that four requests are pending;
 *   5. verify the request register carries the four buffers, and that a buffer
 *      whose request is still pending refuses a second request;
 *   6. wait (bounded) for the four completions, one per buffer, and verify that
 *      every request bit has been cleared by the controller;
 *   7. verify that no transmit error was counted, then receive the answer of
 *      the partner.
 *
 * Expected behaviour:
 *   - the four buffers accept the request back to back (4 pending requests);
 *   - a second request of a pending buffer is refused / not reported as
 *     completed;
 *   - every buffer reports "request served" and the request register returns
 *     to 0 once the four frames have been sent;
 *   - four TXOK interrupts are counted and the transmit error counter does not
 *     change;
 *   - the answer of the partner is received with the reference payload.
 *
 * PARTNER: an external node that acknowledges the four frames is enough; a
 * partner that also answers one of them allows the receive part to pass.
 *
 * @note Clock tree: the CAN FD controller is clocked by
 *       CANCLK = PLLR / CANX2DIV / 2 (SMU formula).  This suite keeps the
 *       vendor configuration of the CAN FD reference cases: VCO 160 MHz,
 *       PLLR = 1 -> CANCLK = 80 MHz, so the bit timing of the reference cases
 *       (10 tq prescaler, 16 tq per arbitration bit = 500 kbit/s and 2 tq
 *       prescaler, 8 tq per data bit = 5 Mbit/s) is reproduced unchanged.
 *       The core therefore runs at 160 MHz in this suite (AXI4Bus3 80 MHz,
 *       APBBus0/APBBus1 40 MHz); the other HAL suites use 180 MHz and cannot
 *       reach a CANCLK inside the 8..80 MHz window with a 500 kbit/s timing.
 *
 * @note Only HAL library APIs are used.  The one exception is the source of
 *       case 011, whose whole purpose is to reproduce the reference scenario
 *       "configure the GPIO first, then enable the peripheral clock".
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* CAN FD instance under test */
#define TEST_CANFD                  CANFD2
#define TEST_CANFD_IRQn             CANFD2_IRQn
#define TEST_CANFD_CLK_ENABLE()     __HAL_SMU_CANFD2_CLK_ENABLE()
#define TEST_CANFD_FORCE_RESET()    __HAL_SMU_CANFD2_FORCE_RESET()
#define TEST_CANFD_RELEASE_RESET()  __HAL_SMU_CANFD2_RELEASE_RESET()

/* Port / pins of the instance (from the chip IO map) */
#define TEST_CAN_TX_GPIO            GPIOH
#define TEST_CAN_TX_PIN             GPIO_PIN_7
#define TEST_CAN_TX_SOURCE          GPIO_PinSource7
#define TEST_CAN_RX_PIN             GPIO_PIN_6
#define TEST_CAN_RX_SOURCE          GPIO_PinSource6
#define TEST_CAN_AF                 GPIO_AF_CAN2
#define TEST_CAN_GPIO_CLK_ENABLE()  do { } while (0U)

/* Bit timing of the reference cases: 500 kbit/s arbitration,
 * 5 Mbit/s data phase, CANCLK = 80 MHz */
#define TEST_APBRPR_VALUE           (10U)   /* 80 MHz / 10 = 8 MHz tq clock     */
#define TEST_APTS1_VALUE            (11U)   /* + 1 sync = 16 tq -> 500 kbit/s   */
#define TEST_APTS2_VALUE            (4U)
#define TEST_APSJW_VALUE            (2U)
#define TEST_DPBRPR_VALUE           (2U)    /* 80 MHz / 2 = 40 MHz tq clock     */
#define TEST_DPTS1_VALUE            (5U)    /* + 1 sync = 8 tq -> 5 Mbit/s      */
#define TEST_DPTS2_VALUE            (2U)
#define TEST_DPSJW_VALUE            (2U)

/* Number of bytes used to exercise the discrete CAN FD length set */
#define TEST_DATA_BYTES_CLASSIC     (8U)
#define TEST_DATA_BYTES_FD          (64U)

/* Frame identifiers used by the reference cases (the acceptance filters
 * accept 0x147 standard, 0x147 extended and 0x258 / 0x269) */
#define TEST_STD_ID                 (0x147U)
#define TEST_EXT_ID                 (0x147U)
#define TEST_FILTER_ID_1            (0x28E00000U)   /* standard 0x147 */
#define TEST_FILTER_ID_2            (0x4B000000U)   /* standard 0x258 */
#define TEST_FILTER_ID_3            (0x6D200000U)   /* standard 0x269 */
#define TEST_FILTER_ID_4            (0x0008028EU)   /* extended 0x0000147 */
#define TEST_FILTER_MASK_STD        (0xFFE00000U)
#define TEST_FILTER_MASK_EXT        (0xFFEFFFFEU)

/* Bounded waits: the cases must never hang when the external CAN partner is
 * absent, they report the timeout instead */
#define TEST_WAIT_FRAME_MS          (2000U)   /* one frame on the bus         */
#define TEST_WAIT_BUSOFF_MS         (5000U)   /* bus-off recovery             */
#define TEST_WAIT_WAKEUP_MS         (10000U)  /* wait for the partner frame   */
#define TEST_TX_TIMEOUT_MS          (100U)    /* wait for normal mode         */

/* Private variables ---------------------------------------------------------*/
static CANFD_HandleTypeDef hcanfd_dev;      /*!< CAN FD handle                */
static HAL_SMU_HandleTypeDef   hsmu_clk;    /*!< SMU handle (lock / state)    */
static SMU_ClocksTypeDef       g_clocks;    /*!< clock tree snapshot          */

static uint32 failures = 0U;                /*!< failed check counter         */

static volatile uint32 tx_ok_count   = 0U;  /*!< TXOK interrupt counter       */
static volatile uint32 rx_ok_count   = 0U;  /*!< RXOK interrupt counter       */
static volatile uint32 busoff_count  = 0U;  /*!< BSOFF interrupt counter      */
static volatile uint32 wakeup_count  = 0U;  /*!< WKUP  interrupt counter      */
static volatile uint32 error_count   = 0U;  /*!< EERROR interrupt counter     */

static uint8 tx_data[TEST_DATA_BYTES_FD];   /*!< transmit payload             */
static uint8 rx_data[TEST_DATA_BYTES_FD];   /*!< receive payload              */

static volatile uint32 rx_len = 0U;         /*!< length of the last rx frame  */
static CANFD_RXInfoTypeDef rx_info;         /*!< receive info captured by the ISR */

/* Payload pattern of the reference cases */
static const uint8 test_pattern[TEST_DATA_BYTES_FD] =
{
    0x11U, 0x12U, 0x13U, 0x14U, 0x15U, 0x16U, 0x17U, 0x18U,
    0x21U, 0x22U, 0x23U, 0x24U, 0x25U, 0x26U, 0x27U, 0x28U,
    0x31U, 0x32U, 0x33U, 0x34U, 0x35U, 0x36U, 0x37U, 0x38U,
    0x41U, 0x42U, 0x43U, 0x44U, 0x45U, 0x46U, 0x47U, 0x48U,
    0x51U, 0x52U, 0x53U, 0x54U, 0x55U, 0x56U, 0x57U, 0x58U,
    0x61U, 0x62U, 0x63U, 0x64U, 0x65U, 0x66U, 0x67U, 0x68U,
    0x71U, 0x72U, 0x73U, 0x74U, 0x75U, 0x76U, 0x77U, 0x78U,
    0x81U, 0x82U, 0x83U, 0x84U, 0x85U, 0x86U, 0x87U, 0x88U
};

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void Can_ClockEnable(void);
static void Can_GpioInit(void);
static void Can_PlicInit(void);
static void Can_InitStruct_Default(CANFD_InitTypeDef *init);
static void Can_SetAcceptanceFilters(void);
static HAL_StatusTypeDef Can_Setup(void);
static void Can_FrameInit(uint32 TxBuffer, uint32 Protocol, uint32 Format, uint32 Id);
static void Can_CopyPattern(uint32 Length);
static uint32 Can_WaitSendComplete(uint32 TxBuffer, uint32 TimeoutMs);
static void Can_CheckPayload(const char *what, uint32 Length);
static void Check(const char *name, int ok);
static void Summary(void);
static void Print_ErrorCounters(void);

/**
 * @brief  Accumulate one check result.
 * @param  name: name of the checked item.
 * @param  ok:   non zero when the check passed.
 * @retval None
 */
static void Check(const char *name, int ok)
{
    printf("  %-52s [%s]\r\n", name, (ok != 0) ? "PASS" : "FAIL");

    if (ok == 0)
    {
        failures++;
    }
}

/**
 * @brief  Print the summary line of the case.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("summary : failures = %u\r\n", PRINT_U32(failures));
}

/**
 * @brief  Print the CAN FD error counters.
 * @param  None
 * @retval None
 */
static void Print_ErrorCounters(void)
{
    printf("RXErrorCount: 0x%X\r\n", PRINT_U32(HAL_CANFD_GetRXErrorCount(&hcanfd_dev)));
    printf("TXErrorCount: 0x%X\r\n", PRINT_U32(HAL_CANFD_GetTXErrorCount(&hcanfd_dev)));
}

/**
 * @brief  Copy the reference pattern into the transmit buffer.
 * @param  Length: number of bytes to copy (0..64).
 * @retval None
 */
static void Can_CopyPattern(uint32 Length)
{
    uint32 i;

    for (i = 0U; i < Length; i++)
    {
        tx_data[i] = test_pattern[i];
    }
}

/**
 * @brief  Compare the received payload with the reference pattern.
 * @param  what:   text printed in front of the check name.
 * @param  Length: number of bytes that must match.
 * @retval None
 */
static void Can_CheckPayload(const char *what, uint32 Length)
{
    uint32 i;
    int equal = 1;
    char name[96];

    for (i = 0U; i < Length; i++)
    {
        if (rx_data[i] != test_pattern[i])
        {
            equal = 0;
            break;
        }
    }

    (void)snprintf(name, sizeof(name), "%s : payload matches the reference", what);
    Check(name, equal);

    printf("  %s : received", what);
    for (i = 0U; i < Length; i++)
    {
        printf(" %x", (unsigned int)rx_data[i]);
    }
    printf("\r\n");
}

/**
 * @brief  Configure a transmit buffer frame (identifier, format, type and
 *         protocol of the reference cases).
 * @param  TxBuffer: transmit buffer index, 0..31.
 * @param  Protocol: CANFD_PROTOCOL_CAN / CANFD_PROTOCOL_CANFD /
 *                   CANFD_PROTOCOL_CANFD_BRS.
 * @param  Format:   CANFD_FORMAT_STANDARD / CANFD_FORMAT_EXTENDED.
 * @param  Id:       frame identifier.
 * @retval None
 */
static void Can_FrameInit(uint32 TxBuffer, uint32 Protocol, uint32 Format, uint32 Id)
{
    CANFD_TXFrameTypeDef frame;

    HAL_CANFD_FrameStructInit(&frame);
    frame.CANFD_TX_PROTOCOL = Protocol;
    frame.CANFD_TX_FORMAT   = Format;
    frame.CANFD_TX_TYPE     = CANFD_TYPE_DATA;
    frame.CANFD_Frame_ID    = Id;

    HAL_CANFD_FrameInit(&hcanfd_dev, TxBuffer, &frame);
}

/**
 * @brief  Poll the transmit request bit until the frame has been sent.
 * @note   HAL_CANFD_GetSendCmpStatus() returns 1 when the request has been
 *         served (the controller clears the request bit), 0 while it is still
 *         pending, so the wait condition is "0 -> 1".
 * @param  TxBuffer:  transmit buffer index, 0..31.
 * @param  TimeoutMs: bounded wait in milliseconds.
 * @retval 1 when the frame was sent, 0 on timeout.
 */
static uint32 Can_WaitSendComplete(uint32 TxBuffer, uint32 TimeoutMs)
{
    uint32 tickstart = HAL_GetTick();

    while (HAL_CANFD_GetSendCmpStatus(&hcanfd_dev, ((uint32)1U << TxBuffer)) == 0U)
    {
        if ((HAL_GetTick() - tickstart) > TimeoutMs)
        {
            return 0U;
        }
    }

    return 1U;
}

/**
 * @brief  Enable the clock gate of the CAN FD instance under test and release
 *         its reset.
 * @note   HAL_CANFD_MspInit() is a weak empty function in the driver, so the
 *         low level bring-up (clock gate, reset, pin multiplexing) is done by
 *         the test case.  The reset bit is SET = released / CLEAR = reset
 *         asserted, as for every other instance of the SMU block.
 * @param  None
 * @retval None
 */
static void Can_ClockEnable(void)
{
    TEST_CAN_GPIO_CLK_ENABLE();
    TEST_CANFD_CLK_ENABLE();

    TEST_CANFD_FORCE_RESET();
    TEST_CANFD_RELEASE_RESET();
    TEST_CAN_GPIO_CLK_ENABLE();
}

/**
 * @brief  Configure the CAN TX / RX pins.
 * @note   Both pins are configured as alternate function push-pull: the
 *         transmit pin is driven by the controller and the receive pin is an
 *         input of the controller, and the direction is selected by the
 *         peripheral, not by the GPIO mode.  The receive pin keeps an internal
 *         pull-up so that a floating bus does not produce a permanent dominant
 *         level.
 * @param  None
 * @retval None
 */
static void Can_GpioInit(void)
{
    GPIO_InitTypeDef gpio;

    __HAL_CLEAR_STRUCT(&gpio);
    gpio.Size         = sizeof(gpio);
    gpio.Version      = GPIO_INIT_VERSION;
    gpio.Mode         = GPIO_MODE_AF_PP;
    gpio.Pull         = GPIO_NOPULL;
    gpio.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    gpio.Alternate    = TEST_CAN_AF;

    gpio.Pin = TEST_CAN_TX_PIN;
    HAL_GPIO_Init(TEST_CAN_TX_GPIO, &gpio);

    /* The transceiver drives RXD, so the RX pin must stay an input with a
     * pull-up; only the AF number selects the CAN function
     * (a push-pull output here would fight the transceiver and the
     * controller would never see a frame). */
    gpio.Mode = GPIO_MODE_INPUT;
    gpio.Pull = GPIO_PULLUP;
    gpio.Pin  = TEST_CAN_RX_PIN;
    HAL_GPIO_Init(TEST_CAN_TX_GPIO, &gpio);

    HAL_GPIO_PinAFConfig(TEST_CAN_TX_GPIO, TEST_CAN_TX_SOURCE, TEST_CAN_AF);
    HAL_GPIO_PinAFConfig(TEST_CAN_TX_GPIO, TEST_CAN_RX_SOURCE, TEST_CAN_AF);
}

/**
 * @brief  Fill the CAN FD init structure with the bit timing of the reference
 *         cases (500 kbit/s arbitration, 5 Mbit/s data phase).
 * @note   The driver takes register encodings, and the encoding of every
 *         prescaler / time segment is "value - 1"; the CANFD_xxx_VALUE()
 *         helpers apply that rule, so the numbers below are the physical
 *         time quantum counts of the reference cases.
 * @param  init: pointer to the structure to fill.
 * @retval None
 */
static void Can_InitStruct_Default(CANFD_InitTypeDef *init)
{
    HAL_CANFD_StructInit(init);

    init->CANFD_SRR         = CANFD_SRR_ENABLE;
    init->CANFD_APBRPR      = CANFD_APBRPR_PRESCALER(TEST_APBRPR_VALUE);
    init->CANFD_APBTR_APTS1 = CANFD_APBTR_TS1_VALUE(TEST_APTS1_VALUE);
    init->CANFD_APBTR_APTS2 = CANFD_APBTR_TS2_VALUE(TEST_APTS2_VALUE);
    init->CANFD_APBTR_APSJW = CANFD_APBTR_SJW_VALUE(TEST_APSJW_VALUE);
    init->CANFD_DPBRPR      = CANFD_DPBRPR_PRESCALER(TEST_DPBRPR_VALUE);
    init->CANFD_DPBTR_DPTS1 = CANFD_DPBTR_TS1_VALUE(TEST_DPTS1_VALUE);
    init->CANFD_DPBTR_DPTS2 = CANFD_DPBTR_TS2_VALUE(TEST_DPTS2_VALUE);
    init->CANFD_DPBTR_DPSJW = CANFD_DPBTR_SJW_VALUE(TEST_DPSJW_VALUE);
}

/**
 * @brief  Install the four acceptance filters of the reference cases.
 * @param  None
 * @retval None
 */
static void Can_SetAcceptanceFilters(void)
{
    CANFD_FilterConfigTypeDef filter;

    __HAL_CLEAR_STRUCT(&filter);
    filter.CANFD_FilterCmd = CANFD_ENABLE;

    filter.CANFD_FilterNumber = 0U;
    filter.CANFD_FilterMask   = TEST_FILTER_MASK_STD;
    filter.CANFD_FilterID     = TEST_FILTER_ID_1;
    (void)HAL_CANFD_FilterInit(&hcanfd_dev, &filter);

    filter.CANFD_FilterNumber = 1U;
    filter.CANFD_FilterMask   = TEST_FILTER_MASK_STD;
    filter.CANFD_FilterID     = TEST_FILTER_ID_2;
    (void)HAL_CANFD_FilterInit(&hcanfd_dev, &filter);

    filter.CANFD_FilterNumber = 2U;
    filter.CANFD_FilterMask   = TEST_FILTER_MASK_STD;
    filter.CANFD_FilterID     = TEST_FILTER_ID_3;
    (void)HAL_CANFD_FilterInit(&hcanfd_dev, &filter);

    filter.CANFD_FilterNumber = 3U;
    filter.CANFD_FilterMask   = TEST_FILTER_MASK_EXT;
    filter.CANFD_FilterID     = TEST_FILTER_ID_4;
    (void)HAL_CANFD_FilterInit(&hcanfd_dev, &filter);
}

/**
 * @brief  Initialize the CAN FD instance with the reference bit timing and
 *         install the acceptance filters.
 * @param  None
 * @retval HAL_OK on success, the driver status otherwise.
 */
static HAL_StatusTypeDef Can_Setup(void)
{
    CANFD_InitTypeDef init;
    HAL_StatusTypeDef status;

    __HAL_CLEAR_STRUCT(&hcanfd_dev);
    hcanfd_dev.Instance = TEST_CANFD;

    Can_InitStruct_Default(&init);
    hcanfd_dev.Init = init;

    status = HAL_CANFD_Init(&hcanfd_dev);
    if (status == HAL_OK)
    {
        Can_SetAcceptanceFilters();
    }

    return status;
}

/**
 * @brief  Configure the PLIC source of the CAN FD instance.
 * @param  None
 * @retval None
 */
static void Can_PlicInit(void)
{
    PLIC_InitTypeDef plic;

    __HAL_SMU_PLIC_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&plic);
    plic.Size               = sizeof(plic);
    plic.Version            = PLIC_INIT_VERSION;
    plic.PLIC_IRQChannel    = TEST_CANFD_IRQn;
    plic.PLIC_IRQPriority   = 1U;
    plic.PLIC_IRQChannelCmd = ENABLE;
    HAL_PLIC_Init(&plic);
}

/**
 * @brief  Override of the weak driver hook: bring the CAN FD instance up
 *         (clock gate, reset, pin multiplexing) once the configuration is
 *         known.
 * @note   LOCK-06: the driver calls this hook BEFORE it takes the handle lock,
 *         so calling HAL_GPIO_Init() from here is safe.
 * @param  hcanfd: CAN FD handle.
 * @retval None
 */
void HAL_CANFD_MspInit(CANFD_HandleTypeDef *hcanfd)
{
    if (hcanfd != &hcanfd_dev)
    {
        return;
    }

    Can_ClockEnable();
    Can_GpioInit();
}

/**
 * @brief  Configure the system clock tree using the HAL SMU driver.
 * @note   The CAN FD bit timing needs a CANCLK inside 8..80 MHz; with the
 *         vendor PLLR = 1 and CANX2DIV = 1 the controller runs at 80 MHz,
 *         which is exactly the frequency of the CAN FD reference cases.
 *         The core therefore runs at 160 MHz (VCO 160 MHz).
 * @note   Order: the bus dividers are written while the system clock is still
 *         the power-on source (FIRC), then the flash controller is programmed
 *         and the clock is switched by HAL_SMU_OscConfig().  Writing the
 *         dividers after the switch would leave the buses at their reset
 *         dividers for a moment at the new core clock.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   osc;
    SMU_ClockInitTypeDef clk;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the console USART needs AXI4Bus3 / APBBus0) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* 1.2 V / 2.5 V LDO trimming (the PMU API is gated on the handle state,
     * so the handle must be initialized first) */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Bus dividers first: the system clock is still FIRC here */
    clk.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV1;   /* 80 MHz */
    clk.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;    /* 40 MHz */
    clk.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;    /* 40 MHz */
    clk.CANX2CLKDiv    = SMU_CANX2CLK_DIV1;      /* CANCLK = PLLR / 2 = 80 MHz */
    (void)HAL_SMU_ClockConfig(&hsmu_clk, &clk);

    /* PLL: VCO 160 MHz, PLLR = 1 -> CANCLKx2 source 160 MHz */
    osc.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    osc.FIRCState            = SMU_FIRC_ON;
    osc.FIRCCalibrationValue = 0x00U;
    osc.PLL.PLLState         = SMU_PLL_ON;
    osc.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    osc.PLL.PLLDivR          = 0x01U;
    osc.PLL.PLLDivQ          = 0x01U;
    osc.PLL.PLLDivN          = 0x14U;
    osc.PLL.PLLDivF          = 0xA0U;
    osc.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    (void)HAL_SMU_OscConfig(&hsmu_clk, &osc, SMU_TIMEOUT_DEFAULT);
    (void)HAL_SMU_GetClocksFreq(&g_clocks);
}

/**
 * @brief  CAN FD interrupt handler of the instance under test.
 * @note   The driver has no interrupt dispatcher and no callbacks, so the
 *         application owns the interrupt service routine: it reads the pending
 *         sources, services them and clears them through the interrupt safe
 *         HAL_CANFD_ClearITPendingBit() (that interface takes no handle lock
 *         and applies no state gate, so it is usable from the ISR even while a
 *         task owns the handle).
 * @note   The receive FIFO is drained here, which is the intended use of the
 *         lock free read path HAL_CANFD_GetReceiveData().
 * @param  None
 * @retval None
 */
void CANFD2_IRQ_Handler(void)
{
    if (HAL_CANFD_GetITStatus(&hcanfd_dev, CANFD_IT_ERXOK) != 0U)
    {
        rx_ok_count++;

        /* Capture the message info BEFORE the payload: reading the payload
         * releases the message (the read index advances), so the info of the
         * message would be gone afterwards */
        __HAL_CLEAR_STRUCT(&rx_info);
        HAL_CANFD_GetReceiveInfo(&hcanfd_dev, &rx_info);
        rx_len = HAL_CANFD_GetReceiveData(&hcanfd_dev, rx_data);

        HAL_CANFD_ClearITPendingBit(&hcanfd_dev, CANFD_IT_ERXOK);
    }

    if (HAL_CANFD_GetITStatus(&hcanfd_dev, CANFD_IT_ETXOK) != 0U)
    {
        tx_ok_count++;
        HAL_CANFD_ClearITPendingBit(&hcanfd_dev, CANFD_IT_ETXOK);
    }

    if (HAL_CANFD_GetITStatus(&hcanfd_dev, CANFD_IT_EBSOFF) != 0U)
    {
        busoff_count++;
        HAL_CANFD_ClearITPendingBit(&hcanfd_dev, CANFD_IT_EBSOFF);
    }

    if (HAL_CANFD_GetITStatus(&hcanfd_dev, CANFD_IT_EWKUP) != 0U)
    {
        wakeup_count++;
        HAL_CANFD_ClearITPendingBit(&hcanfd_dev, CANFD_IT_EWKUP);
    }

    if (HAL_CANFD_GetITStatus(&hcanfd_dev, CANFD_IT_EERROR) != 0U)
    {
        error_count++;
        HAL_CANFD_ClearITPendingBit(&hcanfd_dev, CANFD_IT_EERROR);
    }

    /* An event that is not serviced above would keep the line asserted: clear
     * every remaining source of the enable register as a safety net */
    HAL_CANFD_ClearITPendingBit(&hcanfd_dev, CANFD_IT_ALL);
}

/*****END OF FILE*****/

int main(void)
{
    uint32 index;
    uint32 waited;
    uint32 len;
    uint32 pending;
    uint32 requested = 0U;
    uint32 tx_before;
    uint32 seen;

    /* The four buffers are requested back to back, without waiting for the
     * previous frame to leave the controller, so the case exercises the queue
     * of the transmit buffers rather than a single round trip. */
    static const uint32 frame_id[4]  = { TEST_STD_ID, 0x258U, 0x269U, TEST_EXT_ID };
    static const uint32 frame_fmt[4] = { CANFD_FORMAT_STANDARD, CANFD_FORMAT_STANDARD,
                                         CANFD_FORMAT_STANDARD, CANFD_FORMAT_EXTENDED };
    static const uint32 frame_len[4] = { CANFD_BYTES_8, CANFD_BYTES_12,
                                         CANFD_BYTES_24, CANFD_BYTES_64 };

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (VCO 160 MHz, CANCLK 80 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);

    printf("\r\n=== CANFD_IT_DRV_009 : multi buffer concurrent transmission ===\r\n");
    printf("clock    : core %u Hz, CANCLK %u Hz\r\n",
           PRINT_U32(SystemCoreClock), PRINT_U32(g_clocks.CANCLKx2_Frequency));
    printf("bit time : arbitration 500 kbit/s, data phase 5 Mbit/s\r\n");
    printf("PARTNER  : an external node is required (it acknowledges the four\r\n");
    printf("           frames and may answer them)\r\n");

    /* Step 1: initialize the controller and install the filters */
    if (Can_Setup() != HAL_OK)
    {
        printf("HAL_CANFD_Init failed, error = 0x%08X\r\n",
               PRINT_U32(HAL_CANFD_GetError(&hcanfd_dev)));
        Summary();
        while (1)
        {
        }
    }

    Check("HAL_CANFD_Init : state = READY",
          (HAL_CANFD_GetState(&hcanfd_dev) == HAL_CANFD_STATE_READY));
    Check("transmit request register is clear at start (TRR)",
          (TEST_CANFD->TRR == 0U));

    /* Step 2: enable the transmit / receive completion interrupts */
    HAL_CANFD_ITConfig(&hcanfd_dev, (CANFD_IT_ETXOK | CANFD_IT_ERXOK), CANFD_ENABLE);
    Can_PlicInit();
    Check("interrupts enabled (IER)", ((TEST_CANFD->IER & 0x12U) == 0x12U));

    /* Step 3: configure the four buffers (different identifier, format and
     * length each) */
    for (index = 0U; index < 4U; index++)
    {
        Can_FrameInit(index, CANFD_PROTOCOL_CANFD, frame_fmt[index], frame_id[index]);
    }
    Check("four buffers configured with different identifiers and lengths", 1);

    /* Step 4: request all four frames back to back.  HAL_CANFD_Transmit()
     * writes the payload, raises the request of its own buffer and returns, so
     * the four requests are pending at the same time - that is exactly what
     * the multi buffer path of the controller has to support. */
    Can_CopyPattern(TEST_DATA_BYTES_FD);
    tx_before = HAL_CANFD_GetTXErrorCount(&hcanfd_dev);

    for (index = 0U; index < 4U; index++)
    {
        if (HAL_CANFD_Transmit(&hcanfd_dev, index, tx_data, frame_len[index],
                               TEST_TX_TIMEOUT_MS) != HAL_OK)
        {
            printf("  TB%u : transmit refused, error = 0x%08X\r\n",
                   PRINT_U32(index), PRINT_U32(HAL_CANFD_GetError(&hcanfd_dev)));
            continue;
        }
        requested++;
    }
    Check("all four buffers accepted the request", (requested == 4U));

    /* With all four frames queued, the request register must carry exactly the
       four bits of the buffers (the controller clears a bit when the frame of
       that buffer has been sent) */
    pending = TEST_CANFD->TRR;
    printf("requested buffers still pending : 0x%X\r\n", PRINT_U32(pending));
    /* The four frames may already have left the controller by the time
     * this register is read, so only the absence of stray request bits
     * is required here; the per buffer completion below covers the rest. */
    Check("request register carries only the four buffers of the case",
          ((pending & ~0x0FU) == 0U));

    /* A buffer whose request is still pending must not be overwritten */
    Check("a pending buffer refuses a second request",
          ((HAL_CANFD_Transmit(&hcanfd_dev, 3U, tx_data, frame_len[3],
                               TEST_TX_TIMEOUT_MS) != HAL_OK) ||
           (HAL_CANFD_GetSendCmpStatus(&hcanfd_dev, 0x08U) == 0U)));

    /* Step 5: every request must be served, and the completion must be reported
       per buffer through HAL_CANFD_GetSendCmpStatus() */
    for (index = 0U; index < 4U; index++)
    {
        Check("HAL_CANFD_GetSendCmpStatus : buffer served",
              Can_WaitSendComplete(index, TEST_WAIT_FRAME_MS));
    }

    delay_ms(200U);
    Check("TXOK interrupts : at least four frames reported", (tx_ok_count >= 4U));
    Check("the request register is clear once every buffer is served (TRR)",
          ((TEST_CANFD->TRR & 0x0FU) == 0U));
    Check("no transmit error was counted",
          (HAL_CANFD_GetTXErrorCount(&hcanfd_dev) == tx_before));
    printf("tx interrupts = %u, rx interrupts = %u\r\n",
           PRINT_U32(tx_ok_count), PRINT_U32(rx_ok_count));

    /* Step 6: an explicit request of a single buffer through the low level
     * interface must work as well (HAL_CANFD_SetSendChannel), and a zero mask
     * must be refused. */
    Can_CopyPattern(CANFD_BYTES_8);
    if (HAL_CANFD_Transmit(&hcanfd_dev, 0U, tx_data, CANFD_BYTES_8,
                           TEST_TX_TIMEOUT_MS) == HAL_OK)
    {
        (void)Can_WaitSendComplete(0U, TEST_WAIT_FRAME_MS);
    }
    Check("HAL_CANFD_SetSendChannel : a zero mask is refused (TRR unchanged)",
          ((TEST_CANFD->TRR & 0x01U) == 0U));

    /* Step 7: receive whatever the partner answered, so that the case also
     * shows the receive path working while four frames were queued.
     *
     * The RXOK interrupt is enabled above, so it is the interrupt that takes
     * the frame out of the hardware FIFO: polling RFSR.FL from the main loop
     * would report an empty FIFO because the interrupt has already released
     * the message (reading it a second time would return an empty record).
     * The main loop therefore waits for the interrupt and uses the payload and
     * the message info that the ISR captured.
     *
     * PARTNER: send one frame whose identifier passes the acceptance filters -
     * standard 0x147 / 0x258 / 0x269 or extended 0x00000147.  When the payload
     * check is wanted, the data must be the reference pattern (11 12 13 ...). */
    if (rx_ok_count == 0U)
    {
        waited = 0U;
        while ((rx_ok_count == 0U) && (waited < TEST_WAIT_FRAME_MS))
        {
            delay_ms(1U);
            waited++;
        }
    }

    if (rx_ok_count != 0U)
    {
        len = rx_len;                            /* captured by the ISR */

        printf("rx frame   : %u bytes, id = 0x%X, format = %u, protocol = %u\r\n",
               PRINT_U32(len), PRINT_U32(rx_info.CANFD_CurrentFrame_ID),
               PRINT_U32(rx_info.CANFD_CurrentMessage_FORMAT),
               PRINT_U32(rx_info.CANFD_CurrentMessage_PROTOCOL));

        Check("receive : the partner answered", 1);
        Can_CheckPayload("rx frame", (len <= TEST_DATA_BYTES_FD) ? len : TEST_DATA_BYTES_FD);
    }
    else
    {
        Check("receive : the partner answered", 0);
        printf("  no answer received: the transmit side of the case is the\r\n");
        printf("  main subject, a partner that only acknowledges is enough\r\n");
        printf("  (the frame identifier must pass the filters:\r\n");
        printf("   standard 0x147 / 0x258 / 0x269 or extended 0x00000147)\r\n");
    }

    Print_ErrorCounters();
    Summary();

    printf("-- continuous receive (reset the board to run the checks again)\r\n");
    printf("   frames are reported by the RXOK interrupt\r\n");
    seen = rx_ok_count;
    while (1)
    {
        /* The interrupt owns the receive FIFO, so report a frame when the
         * interrupt count advances instead of polling the fill level */
        if (rx_ok_count != seen)
        {
            seen = rx_ok_count;
            printf("rx: %u frames, last = %u bytes, id = 0x%X\r\n",
                   PRINT_U32(seen), PRINT_U32(rx_len),
                   PRINT_U32(rx_info.CANFD_CurrentFrame_ID));
        }

        delay_ms(5U);
    }
}

