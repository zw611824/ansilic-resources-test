/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_spi.c
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.6
 * Date:   2026/10/26
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.1     fix frame-width handling
 *                                                       in the blocking IO
 *                                                       functions: the transfer
 *                                                       buffers are now stepped
 *                                                       by 1 / 2 / 4 bytes
 *                                                       according to the frame
 *                                                       size (little-endian),
 *                                                       so 16/32-bit frames are
 *                                                       no longer split into
 *                                                       bytes; add
 *                                                       SPI_GetFrameBytes /
 *                                                       SPI_AssembleFrame /
 *                                                       SPI_StoreFrame helpers;
 *                                                       validate the raw status
 *                                                       parameter
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.2     add NULL pointer guards
 *                                                       to every public function
 *                                                       (StructInit, polling IO,
 *                                                       state/error reporting and
 *                                                       all low level register
 *                                                       functions) so that a NULL
 *                                                       handle is rejected before
 *                                                       any register access or
 *                                                       lock operation
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.3     add the interrupt (_IT)
 *                                                       and DMA (_DMA) transfer
 *                                                       modes, the
 *                                                       HAL_SPI_IRQHandler() and
 *                                                       the user callbacks; the
 *                                                       DMA modes are compiled
 *                                                       only while the DMA module
 *                                                       is enabled
 *     ANSILIC APPLICATION GROUP  2026/09/18     1.4     apply the resource lock and RTOS
 *                                                       rules: replace the
 *                                                       __HAL_LOCK macro by the
 *                                                       SPI_LockHandle() /
 *                                                       SPI_UnlockHandle() pair
 *                                                       (Timeout parameter and
 *                                                       uncreated-mutex guard,
 *                                                       RTOS-11), lock Init /
 *                                                       DeInit (LOCK-01), call
 *                                                       MspInit on the first
 *                                                       initialization only
 *                                                       (MSP-04), call MspDeInit
 *                                                       after the unlock
 *                                                       (LOCK-06), add the
 *                                                       lock-free private
 *                                                       SPI_ITConfigInternal()
 *                                                       and
 *                                                       SPI_GetFlagStatusInternal()
 *                                                       helpers and route every
 *                                                       internal call through
 *                                                       them so that neither the
 *                                                       transfer API nor the
 *                                                       interrupt path calls the
 *                                                       public HAL_SPI_ITConfig()
 *                                                       / HAL_SPI_GetFlagStatus()
 *                                                       (LOCK-04 / LOCK-05), add
 *                                                       the SPI_CheckState() gate
 *                                                       with the recoverable
 *                                                       ERROR / TIMEOUT states, a
 *                                                       transfer_started guard
 *                                                       that keeps a rejected
 *                                                       request from touching the
 *                                                       state of the on-going
 *                                                       operation and the
 *                                                       HAL_SPI_STATE_TIMEOUT
 *                                                       state (ARCH-CONST-09,
 *                                                       STATE-04 / STATE-06),
 *                                                       validate the transfer
 *                                                       parameters before the
 *                                                       lock is taken and report
 *                                                       HAL_SPI_ERROR_INVALID_PARAM,
 *                                                       yield from the blocking
 *                                                       polling loops (RTOS-04 /
 *                                                       RTOS-05), document the
 *                                                       blocking behaviour of
 *                                                       every API (POLL-04), and
 *                                                       drop the unused
 *                                                       HAL_SPI_ERROR_TXE /
 *                                                       HAL_SPI_ERROR_UNKNOWN
 *                                                       codes
 *     ANSILIC APPLICATION GROUP  2026/10/26     1.5     align the time budget
 *                                                       with the rest of the
 *                                                       library: a transfer
 *                                                       takes a single tick
 *                                                       stamp and every wait
 *                                                       (lock, flags,
 *                                                       cleanup) shares it, so
 *                                                       the sum of the waits
 *                                                       never exceeds the
 *                                                       Timeout of the API,
 *                                                       and the tick
 *                                                       frequency is honoured
 *                                                       through
 *                                                       HAL_GetTickFreq()
 *                                                       (SPI_ElapsedMs); mask
 *                                                       the received frames to
 *                                                       their width
 *                                                       (SPI_FrameMask, also
 *                                                       applied to the buffer
 *                                                       a DMA channel filled),
 *                                                       validate the DMA
 *                                                       channel against the
 *                                                       frame width
 *                                                       (SPI_CheckDmaLink),
 *                                                       stop and clean up a
 *                                                       failed transfer before
 *                                                       its state is published
 *                                                       (SPI_AbortTransfer:
 *                                                       block the sources, wait
 *                                                       for the shifter, reset
 *                                                       both FIFOs, clear the
 *                                                       pending events), use
 *                                                       the end-of-send data
 *                                                       register for the DMA
 *                                                       transmit channel, and
 *                                                       protect the bare-metal
 *                                                       lock flag with a
 *                                                       critical section
 *     ANSILIC APPLICATION GROUP  2026/10/26     1.6     read the frame width
 *                                                       from the frame size
 *                                                       field of the SPI mode
 *                                                       register instead of the
 *                                                       handle configuration,
 *                                                       so the byte step and the
 *                                                       receive value mask
 *                                                       follow the width the
 *                                                       shifter is actually
 *                                                       moving (the handle value
 *                                                       stays as the fallback
 *                                                       while the register holds
 *                                                       a reset value); arm the
 *                                                       virtual transmit stream
 *                                                       of a master receive in
 *                                                       DMA mode, so the receive
 *                                                       clock is generated like
 *                                                       in the interrupt driven
 *                                                       receive, and disarm the
 *                                                       sources of a completed
 *                                                       or failed DMA transfer
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Serial Peripheral
 *                  Interface (SPI):
 *                  - Initialization and de-initialization: HAL_SPI_Init /
 *                    HAL_SPI_DeInit, configuration structure handling;
 *                  - Peripheral control: polling transmit / receive /
 *                    transmit-receive with timeout, state and error
 *                    reporting;
 *                  - Interrupt and DMA transfers (HAL_SPI_xxx_IT / _DMA),
 *                    the HAL_SPI_IRQHandler() and the user callbacks;
 *                  - Low level register access: enable / disable, FIFO
 *                    reset, slave select, data send / receive, interrupt
 *                    configuration, flag / interrupt status query and
 *                    pending clear.
 *                  Concurrency follows the architecture resource lock rules
 *                  (section 13): every API that changes the handle state is
 *                  serialized through the SPI_LockHandle() /
 *                  SPI_UnlockHandle() pair (bare-metal lock flag, or an RTOS
 *                  mutex with a bounded wait), the SPI_CheckState() gate
 *                  rejects a new transfer while another one is in progress
 *                  and accepts the recoverable ERROR / TIMEOUT states so that
 *                  a failed transfer can be retried without a DeInit / Init
 *                  round trip (STATE-06), the transfer parameters are
 *                  validated before the lock is taken, and the low level
 *                  register access helpers stay lock-free so that they remain
 *                  usable from an interrupt service routine (LOCK-04 /
 *                  RTOS-12). The interrupt services never take the lock and
 *                  use the internal SPI_ITConfigInternal() helper instead of
 *                  the public HAL_SPI_ITConfig().
 */
#include "as32x601_hal.h"           /* HAL_GetTick() / HAL_MAX_DELAY        */
#include "as32x601_hal_spi.h"       /* SPI HAL API and register macros       */

/* The DMA transfer functions are compiled only while the DMA module is
 * enabled: the DMA_HandleTypeDef type and the HAL_DMA_* API are provided by
 * as32x601_hal_dma.h. When the DMA module is disabled the _DMA functions
 * return HAL_ERROR at runtime. */
#ifdef HAL_DMA_MODULE_ENABLED
#include "as32x601_hal_dma.h"       /* DMA_HandleTypeDef, HAL_DMA_* APIs     */
#endif

/* The HAL_SPI_MODULE_ENABLED switch is provided by the user configuration
 * file (as32x601_hal_conf.h, included above through as32x601_hal.h): the
 * whole implementation is compiled only while the module is enabled. */
#ifdef HAL_SPI_MODULE_ENABLED

/* Private constants ---------------------------------------------------------*/
/* Encoded interrupt source convention: bits [6:5] = register selector
 * (01 = CR0, 10 = IER), bits [4:0] = bit position in the register. */
#define SPI_CR_MASK      ((uint32)0x000000E0U)   /*!< Register selector mask   */
#define SPI_CR_POS       ((uint32)0x00000005U)   /*!< Register selector shift  */
#define SPI_IT_MASK      ((uint32)0x0000001FU)   /*!< Bit position mask        */

/* Direction selector of the private DMA channel validation helper. It is not
 * the DMA_DIR_xxx encoding of the DMA module: it only tells which side of the
 * transfer the channel serves. */
#define SPI_DMA_DIR_TX   ((uint32)0U)            /*!< Memory -> peripheral     */
#define SPI_DMA_DIR_RX   ((uint32)1U)            /*!< Peripheral -> memory     */

/* Private functions ---------------------------------------------------------*/

/* Private function prototypes -----------------------------------------------*/
static void SPI_Transmit_IT(SPI_HandleTypeDef *hspi);
static void SPI_Receive_IT(SPI_HandleTypeDef *hspi);
static HAL_StatusTypeDef SPI_CheckState(SPI_HandleTypeDef *hspi);
static void SPI_ITConfigInternal(SPI_HandleTypeDef *hspi, uint32 SPI_IT, uint32 NewState);
static uint32 SPI_GetFlagStatusInternal(SPI_HandleTypeDef *hspi, uint32 SPI_FLAG);
static uint32 SPI_ElapsedMs(uint32 start);
static uint32 SPI_GetFrameBits(const SPI_HandleTypeDef *hspi);
static uint32 SPI_GetFrameBytes(const SPI_HandleTypeDef *hspi);
static uint32 SPI_FrameMask(const SPI_HandleTypeDef *hspi);
static void SPI_MaskReceivedFrames(SPI_HandleTypeDef *hspi, uint32 frames);
static void SPI_AbortTransfer(SPI_HandleTypeDef *hspi, uint32 Tickstart, uint32 Timeout);
#ifdef HAL_DMA_MODULE_ENABLED
static HAL_StatusTypeDef SPI_CheckDmaLink(const SPI_HandleTypeDef *hspi,
                                         const DMA_HandleTypeDef *hdma, uint32 Dir);
static void SPI_DMATransmitCplt(DMA_HandleTypeDef *hdma);
static void SPI_DMAReceiveCplt(DMA_HandleTypeDef *hdma);
static void SPI_DMATransmitReceiveCplt(DMA_HandleTypeDef *hdma);
static void SPI_DMAHalfTransmitCplt(DMA_HandleTypeDef *hdma);
static void SPI_DMAHalfReceiveCplt(DMA_HandleTypeDef *hdma);
static void SPI_DMAHalfTransmitReceiveCplt(DMA_HandleTypeDef *hdma);
static void SPI_DMAError(DMA_HandleTypeDef *hdma);
static void SPI_DMAAbortOnError(DMA_HandleTypeDef *hdma);
#endif

/**
 * @brief  Milliseconds elapsed since a tick stamp, on the HAL time base.
 * @note   The tick counter runs at HAL_GetTickFreq(), which is not guaranteed
 *         to be 1000 Hz: the difference is converted to milliseconds with a
 *         wide enough computation, so a Timeout is honoured whatever the
 *         configured time base frequency is. The HAL tick is the single
 *         source of time of this driver, and the unsigned subtraction makes
 *         the computation wrap safe.
 * @param  start: tick value captured with HAL_GetTick() when the operation
 *         started.
 * @retval uint32: elapsed milliseconds (0 when the time base is unusable).
 */
static uint32 SPI_ElapsedMs(uint32 start)
{
    uint32 freq = HAL_GetTickFreq();
    uint32 ticks;

    if (freq == 0U)
    {
        /* No trustworthy time base: report no elapsed progress, so that a
         * bounded wait gives the hardware the benefit of the doubt instead of
         * failing straight away */
        return 0U;
    }

    ticks = HAL_GetTick() - start;   /* unsigned difference: wrap safe */

    return ((ticks / freq) * 1000U) + (((ticks % freq) * 1000U) / freq);
}

/**
 * @brief  Wait for a given flag to reach the expected state, within a budget.
 * @note   The budget is shared by the whole transfer: Tickstart is the stamp
 *         taken once when the public API was entered, so the sum of every wait
 *         of a transfer (including the cleanup of a failed attempt) never
 *         exceeds Timeout. In an RTOS build the loop yields the CPU on every
 *         iteration so that a lower or equal priority task is not starved by
 *         the busy wait (RTOS-04 / RTOS-05).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  Flag: the SPI status flag to wait for (SPI_Flag_xxx).
 * @param  State: expected flag state (1 = set, 0 = reset).
 * @param  Tickstart: tick stamp of the transfer start (HAL_GetTick()).
 * @param  Timeout: budget of the whole transfer in ms (HAL_MAX_DELAY for
 *         infinite).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT
 */
static HAL_StatusTypeDef SPI_WaitFlagStateUntilTimeout(SPI_HandleTypeDef *hspi, uint32 Flag, uint32 State,
                                                       uint32 Tickstart, uint32 Timeout)
{
    uint32 flagstate = SPI_GetFlagStatusInternal(hspi, Flag);

    /* Poll the flag until it reaches the expected state */
    while (flagstate != State)
    {
        /* Check the timeout against the shared budget of the transfer */
        if ((Timeout != HAL_MAX_DELAY) && (SPI_ElapsedMs(Tickstart) >= Timeout))
        {
            /* Flag not reached within the timeout */
            return HAL_TIMEOUT;
        }

#if (USE_RTOS == 1)
        /* RTOS-04: let the other tasks of the same priority run instead of
         * busy waiting (empty macro in a bare-metal build, RTOS-05) */
        HAL_RTOS_Yield();
#endif /* USE_RTOS */

        flagstate = SPI_GetFlagStatusInternal(hspi, Flag);
    }

    return HAL_OK;
}

/**
 * @brief  Read the frame width of the instance from its mode register.
 * @note   The width is taken from the frame size field of the SPI mode register
 *         (one bit per data bit), because that register is the authority for
 *         the frame the shifter is actually moving: the interface may be
 *         programmed through HAL_SPI_Init() or directly through the low level
 *         register functions, and only the register then reflects the hardware
 *         state the transfer has to follow.
 * @note   While the field still holds its reset value the width recorded in the
 *         handle configuration is used instead, so the helpers stay usable
 *         before the first configuration.
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval uint32: the frame width in bits (4..32).
 */
static uint32 SPI_GetFrameBits(const SPI_HandleTypeDef *hspi)
{
    uint32 bits;

    if ((hspi == NULL_PTR) || (hspi->Instance == NULL_PTR))
    {
        return 8U;
    }

    /* The mode register is the authority: its frame size field carries the
     * frame width in bits */
    bits = (((uint32)hspi->Instance->CFG) & (uint32)SPI_CFG_FS_Msk) >> SPI_CFG_FS_Pos;

    if ((bits >= 4U) && (bits <= 32U))
    {
        return bits;
    }

    /* The field still holds a reset value: fall back to the width the handle
     * was configured with, so a usable width exists before the first
     * initialization */
    bits = (((uint32)hspi->Init.SPI_FrameSize) & (uint32)SPI_CFG_FS_Msk) >> SPI_CFG_FS_Pos;

    if ((bits >= 4U) && (bits <= 32U))
    {
        return bits;
    }

    /* Neither source is usable: report the byte wide frame */
    return 8U;
}

/**
 * @brief  Compute the number of bytes per frame from the register frame width.
 * @note   The transfer buffers are addressed byte-wise; a frame wider than
 *         8 bits occupies 2 (9..16 bits) or 4 (17..32 bits) bytes, stored
 *         little-endian in the buffer. The width is read from the mode register
 *         (see SPI_GetFrameBits), so a frame size programmed directly in the
 *         register is honoured as well.
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval uint32: 1 / 2 / 4 bytes per frame.
 */
static uint32 SPI_GetFrameBytes(const SPI_HandleTypeDef *hspi)
{
    uint32 bits = SPI_GetFrameBits(hspi);

    if (bits <= 8U)
    {
        return 1U;
    }
    else if (bits <= 16U)
    {
        return 2U;
    }
    else
    {
        return 4U;
    }
}

/**
 * @brief  Compute the value mask of a frame from the register frame width.
 * @note   The transfer buffers are byte addressed: a frame narrower than its
 *         storage width only uses the low bits of it. Masking the value read
 *         from the receive register (and, after a DMA transfer, the buffer
 *         written by the DMA channel) clears the unused upper bits, so a
 *         9..32 bit frame never leaves undefined data in the receive buffer.
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval uint32: 0xFF / 0xFFFF / 0xFFFFFFFF for a 1 / 2 / 4 byte frame.
 */
static uint32 SPI_FrameMask(const SPI_HandleTypeDef *hspi)
{
    uint32 bits = SPI_GetFrameBits(hspi);

    if (bits <= 8U)
    {
        return (uint32)0x000000FFU;
    }
    else if (bits <= 16U)
    {
        return (uint32)0x0000FFFFU;
    }
    else
    {
        return (uint32)0xFFFFFFFFU;
    }
}

/**
 * @brief  Assemble a frame word from the transmit buffer (little-endian).
 * @param  pData: pointer to the first byte of the frame in the buffer.
 * @param  ByteCount: number of bytes of the frame (1 / 2 / 4).
 * @retval uint32: the frame word, right-aligned in the register.
 */
static uint32 SPI_AssembleFrame(uint8 *pData, uint32 ByteCount)
{
    uint32 data = 0U;
    uint32 i = 0U;

    for (i = 0U; i < ByteCount; i++)
    {
        data |= ((uint32)pData[i]) << (8U * i);
    }

    return data;
}

/**
 * @brief  Store a received frame word into the receive buffer (little-endian).
 * @param  pData: pointer to the first byte of the frame in the buffer.
 * @param  Data: the frame word read from the RX register.
 * @param  ByteCount: number of bytes of the frame (1 / 2 / 4).
 * @retval None
 */
static void SPI_StoreFrame(uint8 *pData, uint32 Data, uint32 ByteCount)
{
    uint32 i = 0U;

    for (i = 0U; i < ByteCount; i++)
    {
        pData[i] = (uint8)(Data >> (8U * i));
    }
}

/**
 * @brief  Apply the frame value mask to the frames a DMA channel wrote into
 *         the receive buffer.
 * @note   A DMA channel moves whole storage units (1 / 2 / 4 bytes per frame),
 *         so the unused upper bits of a frame narrower than its storage width
 *         are stored as the peripheral drove them. Every frame of the given
 *         range is read back, masked and written again (little-endian), so the
 *         caller sees exactly the bits the frame is made of. The helper takes
 *         no lock and is called from the DMA completion callbacks.
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  frames: number of leading frames of the receive buffer to mask.
 * @retval None
 */
static void SPI_MaskReceivedFrames(SPI_HandleTypeDef *hspi, uint32 frames)
{
    uint32 frame_bytes = SPI_GetFrameBytes(hspi);
    uint32 mask        = SPI_FrameMask(hspi);
    uint32 index;
    uint32 value;

    if ((hspi->pRxBuffPtr == NULL_PTR) || (frame_bytes == 4U))
    {
        /* No buffer to mask, or a 4 byte frame that already uses all 32 bits */
        return;
    }

    for (index = 0U; index < frames; index++)
    {
        value = SPI_AssembleFrame(&hspi->pRxBuffPtr[index * frame_bytes], frame_bytes) & mask;
        SPI_StoreFrame(&hspi->pRxBuffPtr[index * frame_bytes], value, frame_bytes);
    }
}

/**
 * @brief  Stop a failed transfer and clean up the peripheral before its state
 *         is published.
 * @note   A transfer that timed out (or failed) may leave the shifter running
 *         and stale frames inside the receive FIFO. The interrupt sources of
 *         the transfer are blocked first, then the shifter is waited for
 *         within the remaining budget of the same transfer, then both FIFOs
 *         are reset and the pending events are cleared: a retry can never read
 *         stale frames nor inherit an event of the failed attempt (STATE-06).
 *         When the shifter does not stop within the budget the peripheral is
 *         left untouched and the failure is reported as it is - stopping a
 *         stuck instance is the job of HAL_SPI_DeInit().
 * @note   The helper takes no lock: it runs inside the locked transfer APIs,
 *         and it only uses the lock-free internal helpers (LOCK-05).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  Tickstart: tick stamp of the transfer start (HAL_GetTick()).
 * @param  Timeout: budget of the whole transfer in ms (HAL_MAX_DELAY for
 *         infinite).
 * @retval None
 */
static void SPI_AbortTransfer(SPI_HandleTypeDef *hspi, uint32 Tickstart, uint32 Timeout)
{
    /* Block the interrupt sources of this transfer first, so that no event of
     * the failed attempt can drive the state machine again */
    SPI_ITConfigInternal(hspi, SPI_IT_TXNE, SPI_DISABLE);
    SPI_ITConfigInternal(hspi, SPI_IT_RXNE, SPI_DISABLE);
    SPI_ITConfigInternal(hspi, SPI_IT_RXO, SPI_DISABLE);

    /* Wait for the shifter to stop before the FIFOs are reset: the wait shares
     * the remaining budget of this transfer, so the cleanup can never extend
     * the timeout granted by the caller */
    if (SPI_WaitFlagStateUntilTimeout(hspi, SPI_Flag_BUSS, 0U, Tickstart, Timeout) != HAL_OK)
    {
        /* Still transmitting: leave the peripheral as it is and report the
         * failure unchanged */
        return;
    }

    /* Reset both FIFOs through the buffer reset control register */
    hspi->Instance->CR1 = (SPI_RESETFIFO_RX | SPI_RESETFIFO_TX);

    /* Clear every pending event through the interrupt clear register (written
     * directly: the public clear API must not be called while the handle lock
     * is held, LOCK-05) */
    hspi->Instance->IFCR = (SPI_CLEAR_TD | SPI_CLEAR_RXO | SPI_CLEAR_TXE |
                            SPI_CLEAR_RXNE | SPI_CLEAR_TXNF | SPI_CLEAR_NSSV);
}

#ifdef HAL_DMA_MODULE_ENABLED
/**
 * @brief  Validate that a DMA channel can move the configured frame width.
 * @note   The channel of a SPI transfer has to move exactly one frame per
 *         request: the direction, the increment modes and both data widths
 *         must match the frame storage width, otherwise the channel silently
 *         transfers truncated or misaligned data. The two width declarations
 *         (peripheral and memory) are validated independently, because the DMA
 *         module keeps one separate field for each of them.
 * @param  hspi: pointer to a SPI_HandleTypeDef structure; the frame width is
 *         read from its mode register (SPI_GetFrameBits).
 * @param  hdma: pointer to the DMA channel handle (hdmatx or hdmarx).
 * @param  Dir: SPI_DMA_DIR_TX (memory -> peripheral) or SPI_DMA_DIR_RX.
 * @retval HAL_StatusTypeDef: HAL_OK when the channel is usable, HAL_ERROR
 *         otherwise.
 */
static HAL_StatusTypeDef SPI_CheckDmaLink(const SPI_HandleTypeDef *hspi,
                                         const DMA_HandleTypeDef *hdma, uint32 Dir)
{
    uint32 frame_bytes = SPI_GetFrameBytes(hspi);

    if ((hdma == NULL_PTR) || (hdma->Instance == NULL_PTR))
    {
        return HAL_ERROR;
    }

    /* Direction: a transmit channel feeds the data register, a receive channel
     * reads it */
    if (Dir == SPI_DMA_DIR_TX)
    {
        if (hdma->Init.DMA_DIR != DMA_MEMORY_TO_PERIPH)
        {
            return HAL_ERROR;
        }
    }
    else
    {
        if (hdma->Init.DMA_DIR != DMA_PERIPH_TO_MEMORY)
        {
            return HAL_ERROR;
        }
    }

    /* One data register against many frames: the peripheral address is fixed,
     * the buffer address steps by one frame, and the memory-to-memory mode is
     * not a SPI transfer */
    if ((hdma->Init.DMA_PeripheralInc != DMA_PINC_DISABLE) ||
        (hdma->Init.DMA_MemoryInc != DMA_MINC_ENABLE) ||
        (hdma->Init.DMA_M2M != DMA_M2M_Disable))
    {
        return HAL_ERROR;
    }

    /* Both width declarations must equal the frame storage width */
    if (frame_bytes == 1U)
    {
        if ((hdma->Init.DMA_PeripheralDataSize != DMA_PDATAALIGN_BYTE) ||
            (hdma->Init.DMA_MemoryDataSize != DMA_MDATAALIGN_BYTE))
        {
            return HAL_ERROR;
        }
    }
    else if (frame_bytes == 2U)
    {
        if ((hdma->Init.DMA_PeripheralDataSize != DMA_PDATAALIGN_HALFWORD) ||
            (hdma->Init.DMA_MemoryDataSize != DMA_MDATAALIGN_HALFWORD))
        {
            return HAL_ERROR;
        }
    }
    else
    {
        if ((hdma->Init.DMA_PeripheralDataSize != DMA_PDATAALIGN_WORD) ||
            (hdma->Init.DMA_MemoryDataSize != DMA_MDATAALIGN_WORD))
        {
            return HAL_ERROR;
        }
    }

    return HAL_OK;
}
#endif /* HAL_DMA_MODULE_ENABLED */

/**
 * @brief  Check whether the handle accepts a new transfer.
 * @note   Architecture constraint ARCH-CONST-09: while a transfer is ongoing
 *         (BUSY / BUSY_TX / BUSY_RX / BUSY_TX_RX) any other transfer is
 *         rejected with HAL_BUSY, and an uninitialized handle (RESET) requires
 *         HAL_SPI_Init() first and is rejected with HAL_ERROR. The recoverable
 *         states ERROR and TIMEOUT accept a new transfer directly, because the
 *         entry point of a transfer resets the handle state to busy, so a
 *         failed transfer can be retried without a DeInit / Init round trip
 *         (STATE-04 / STATE-06).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK (accepted) / HAL_BUSY / HAL_ERROR.
 */
static HAL_StatusTypeDef SPI_CheckState(SPI_HandleTypeDef *hspi)
{
    if (hspi == NULL_PTR)
    {
        return HAL_ERROR;
    }

    if ((hspi->State == HAL_SPI_STATE_BUSY) || (hspi->State == HAL_SPI_STATE_BUSY_TX) ||
        (hspi->State == HAL_SPI_STATE_BUSY_RX) || (hspi->State == HAL_SPI_STATE_BUSY_TX_RX))
    {
        return HAL_BUSY;
    }

    if (hspi->State == HAL_SPI_STATE_RESET)
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Enable or disable an SPI interrupt source without the handle lock.
 * @note   Private body shared by the public HAL_SPI_ITConfig() and by the
 *         internal transfer paths (the interrupt mode start functions and the
 *         interrupt services). It takes no lock and checks no state, so that it
 *         stays callable while the handle lock is held by the calling API and
 *         from an interrupt service routine (LOCK-04 / LOCK-05 / RTOS-12).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  SPI_IT: the interrupt source to enable/disable (SPI_IT_xxx).
 * @param  NewState: 1 = enable, 0 = disable.
 * @retval None
 */
static void SPI_ITConfigInternal(SPI_HandleTypeDef *hspi, uint32 SPI_IT, uint32 NewState)
{
    uint32 itmask = 0U;
    uint32 regsel = 0U;

    /* Decode the register selector and the bit position of the interrupt */
    regsel = (SPI_IT & SPI_CR_MASK) >> SPI_CR_POS;
    itmask = ((uint32)1U << (SPI_IT & SPI_IT_MASK));

    if (NewState != SPI_DISABLE)
    {
        /* Enable the interrupt in the selected register */
        if (regsel == 1U)
        {
            hspi->Instance->CR0 |= itmask;
        }
        else
        {
            hspi->Instance->IER |= itmask;
        }
    }
    else
    {
        /* Disable the interrupt in the selected register */
        if (regsel == 1U)
        {
            hspi->Instance->CR0 &= ~itmask;
        }
        else
        {
            hspi->Instance->IER &= ~itmask;
        }
    }
}

/**
 * @brief  Check whether a SPI status flag is set, without the handle lock.
 * @note   Private body shared by the public HAL_SPI_GetFlagStatus() and by the
 *         internal transfer paths (the blocking wait helper, the full duplex
 *         polling loop and the interrupt services). It takes no lock and
 *         checks no state, so that it stays callable while the handle lock is
 *         held by the calling API and from an interrupt service routine
 *         (LOCK-04 / LOCK-05 / RTOS-12).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  SPI_FLAG: the flag to check (SPI_Flag_xxx).
 * @retval uint32: 1 if the flag is set, 0 otherwise.
 */
static uint32 SPI_GetFlagStatusInternal(SPI_HandleTypeDef *hspi, uint32 SPI_FLAG)
{
    if ((hspi->Instance->SR & SPI_FLAG) != 0U)
    {
        return 1U;
    }

    return 0U;
}

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_SPI_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; when the mutex is not acquired before the
 *         Timeout expires, HAL_TIMEOUT is returned. The value is passed to
 *         HAL_MutexAcquire() as is (RTOS ticks; with the usual 1 ms tick it is
 *         the same quantity as the millisecond Timeout of the public API, and
 *         HAL_MAX_DELAY means an infinite wait).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef SPI_LockHandle(SPI_HandleTypeDef *hspi, uint32 Timeout)
{
#if (USE_RTOS == 1)
    if (hspi->LockMutex == NULL_PTR)
    {
        /* The porting layer did not create the mutex (e.g. HAL_SPI_MspInit()
         * was not overridden): report it instead of calling the RTOS with a
         * NULL handle */
        return HAL_ERROR;
    }

    return HAL_MutexAcquire(hspi->LockMutex, Timeout);
#else
    uint32 primask;
    HAL_StatusTypeDef status;

    /* Prevent unused argument compilation warning: the bare-metal lock flag
     * either succeeds immediately or reports HAL_BUSY, it never waits */
    UNUSED(Timeout);

    /* The lock flag is read, tested and written inside a critical section: the
     * bare-metal lock never polls, it only has to be race free against an
     * interrupt context that may try to take the same handle */
    primask = __disable_irq_and_save();

    if (hspi->Lock == HAL_LOCKED)
    {
        status = HAL_BUSY;
    }
    else
    {
        hspi->Lock = HAL_LOCKED;
        status = HAL_OK;
    }

    __restore_irq(primask);

    return status;
#endif /* USE_RTOS */
}

/**
 * @brief  Unlock the handle.
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval None
 */
void SPI_UnlockHandle(SPI_HandleTypeDef *hspi)
{
#if (USE_RTOS == 1)
    (void)HAL_MutexRelease(hspi->LockMutex);
#else
    uint32 primask = __disable_irq_and_save();

    hspi->Lock = HAL_UNLOCKED;

    __restore_irq(primask);
#endif /* USE_RTOS */
}

/* Exported functions --------------------------------------------------------*/

/** @addtogroup SPI_Exported_Functions
  * @{
  */

/** @addtogroup SPI_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Fills each SPI_InitStruct member with its default value. (NON-BLOCKING)
 * @param  SPI_InitStruct: pointer to a SPI_InitTypeDef structure which will
 *         be initialized.
 * @retval None
 */
void HAL_SPI_StructInit(SPI_InitTypeDef *SPI_InitStruct)
{
    /* Check the parameter */
    if (SPI_InitStruct == NULL_PTR)
    {
        return;
    }

    /* Reset the SPI init structure parameters values */
    SPI_InitStruct->Size            = sizeof(SPI_InitTypeDef);  /*!< sizeof struct */
    SPI_InitStruct->Version         = SPI_INIT_VERSION;         /*!< V1            */
    SPI_InitStruct->SPI_CLKDiv      = SPI_CLKDiv2;        /*!< Clock frequency division     */
    SPI_InitStruct->SPI_Mode        = SPI_Mode_Master;    /*!< SPI operating mode           */
    SPI_InitStruct->SPI_FrameSize   = SPI_FrameSize_8b;   /*!< SPI data frame size          */
    SPI_InitStruct->SPI_MotorolaMode = SPI_Motorola_Mode0; /*!< SPI Motorola mode            */
    SPI_InitStruct->SPI_TransMode   = SPI_TransNor;       /*!< SPI transmission mode        */
    SPI_InitStruct->Reserved[0]     = 0U;                 /*!< Reserved for future use      */
    SPI_InitStruct->Reserved[1]     = 0U;                 /*!< Reserved for future use      */
}

/**
 * @brief  Initializes the SPI according to the specified parameters in the
 *         SPI_InitStruct of the handle. (NON-BLOCKING)
 * @note   The SPI clock gating and the pin multiplexing must be configured
 *         by the user in HAL_SPI_MspInit(). The callback is invoked on the
 *         first initialization only (while the handle state is
 *         HAL_SPI_STATE_RESET) and before the handle lock is taken, so it may
 *         use other HAL APIs (MSP-04 / LOCK-06).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_SPI_Init(SPI_HandleTypeDef *hspi)
{
    uint32 tmpreg = 0U;

    /* Check the SPI peripheral handle */
    if (hspi == NULL_PTR)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_SPI_ALL_PERIPH(hspi->Instance));
    assert_param(IS_SPI_CLKDIV(hspi->Init.SPI_CLKDiv));
    assert_param(IS_SPI_MODE(hspi->Init.SPI_Mode));
    assert_param(IS_SPI_FRAMESIZE(hspi->Init.SPI_FrameSize));
    assert_param(IS_SPI_MOTOROLAMODE(hspi->Init.SPI_MotorolaMode));
    assert_param(IS_SPI_TRANSMODE(hspi->Init.SPI_TransMode));

    /* Re-check the configuration at run time: assert_param() is compiled out
     * when USE_FULL_ASSERT is not defined. The request is rejected before any
     * register access and before the lock is taken, and the handle state is
     * left untouched, so a rejected call neither enters a busy state nor
     * consumes the lock (ARCH-CONST-10 / ERR-03). */
    if (((IS_SPI_ALL_PERIPH(hspi->Instance)) == 0U) ||
        ((IS_SPI_CLKDIV(hspi->Init.SPI_CLKDiv)) == 0U) ||
        ((IS_SPI_MODE(hspi->Init.SPI_Mode)) == 0U) ||
        ((IS_SPI_FRAMESIZE(hspi->Init.SPI_FrameSize)) == 0U) ||
        ((IS_SPI_MOTOROLAMODE(hspi->Init.SPI_MotorolaMode)) == 0U) ||
        ((IS_SPI_TRANSMODE(hspi->Init.SPI_TransMode)) == 0U))
    {
        hspi->ErrorCode |= HAL_SPI_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* MSP-04: initialize the MSP on the first initialization only, while the
     * handle is still in the reset state, and before the first register access
     * so that the peripheral clock and the pin multiplexing are available.
     * LOCK-06: the callback runs before the lock is taken, hence it may use
     * other HAL APIs. */
    if (hspi->State == HAL_SPI_STATE_RESET)
    {
        hspi->Lock = HAL_UNLOCKED;
        HAL_SPI_MspInit(hspi);
    }

    /* Process locked */
    if (SPI_LockHandle(hspi, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Enter the busy state and clear the error code (ARCH-CONST-10) */
    hspi->State     = HAL_SPI_STATE_BUSY;
    hspi->ErrorCode = HAL_SPI_ERROR_NONE;

    /* Set the SPI clock frequency division (CLKCR register) */
    tmpreg = hspi->Instance->CLKCR;
    tmpreg &= ~((uint32)(SPI_CLKCR_CLKCR));
    tmpreg |= ((uint32)(hspi->Init.SPI_CLKDiv));
    hspi->Instance->CLKCR = tmpreg;

    /* Set the SPI master / slave mode (CR0.MSTR bit) */
    tmpreg = hspi->Instance->CR0;
    tmpreg &= ~((uint32)(SPI_CR0_MSTR));
    tmpreg |= ((uint32)(hspi->Init.SPI_Mode));
    hspi->Instance->CR0 = tmpreg;

    /* Set the SPI frame size, Motorola mode and transmission mode
     * (CFG register, written in a single access) */
    hspi->Instance->CFG = ((uint32)(hspi->Init.SPI_FrameSize |
                                    hspi->Init.SPI_MotorolaMode |
                                    hspi->Init.SPI_TransMode));

    /* Set the state to ready */
    hspi->State = HAL_SPI_STATE_READY;

    /* Process unlocked */
    SPI_UnlockHandle(hspi);

    return HAL_OK;
}

/**
 * @brief  De-initializes the SPI peripheral. (NON-BLOCKING)
 * @note   HAL_SPI_MspDeInit() is called after the handle lock has been
 *         released, so the callback may use other HAL APIs (LOCK-06).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_SPI_DeInit(SPI_HandleTypeDef *hspi)
{
    /* Check the SPI peripheral handle */
    if (hspi == NULL_PTR)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_SPI_ALL_PERIPH(hspi->Instance));

    /* Process locked */
    if (SPI_LockHandle(hspi, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Enter the busy state and clear the error code (ARCH-CONST-10) */
    hspi->State     = HAL_SPI_STATE_BUSY;
    hspi->ErrorCode = HAL_SPI_ERROR_NONE;

    /* Disable the SPI peripheral */
    hspi->Instance->CR0 &= ~((uint32)(SPI_CR0_SPE));

    /* Reset the handle state */
    hspi->State = HAL_SPI_STATE_RESET;

    /* Process unlocked */
    SPI_UnlockHandle(hspi);

    /* LOCK-06: de-initialize the MSP after the lock has been released, so the
     * callback may use other HAL APIs */
    HAL_SPI_MspDeInit(hspi);

    return HAL_OK;
}

/**
 * @brief  Initializes the SPI MSP. Weak empty function; the user implements
 *         the low level hardware initialization.
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_SPI_MspInit(SPI_HandleTypeDef *hspi)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hspi);
}

/**
 * @brief  De-initializes the SPI MSP. Weak empty function; the user
 *         implements the low level hardware de-initialization.
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_SPI_MspDeInit(SPI_HandleTypeDef *hspi)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hspi);
}

/**
  * @}
  */

/** @addtogroup SPI_Exported_Functions_Group2 IO operation functions
  * @brief    Polling mode IO operations
  * @{
  */

/**
 * @brief  Transmits an amount of data in blocking mode. (BLOCKING)
 * @note   In master mode the received data is read and discarded to keep
 *         the SPI clock running (full duplex).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  pData: pointer to the data buffer to transmit.
 * @param  Size: number of frames to transmit.
 * @param  Timeout: maximum waiting time in ms (HAL_MAX_DELAY for infinite).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_SPI_Transmit(SPI_HandleTypeDef *hspi, uint8 *pData, uint32 Size, uint32 Timeout)
{
    HAL_StatusTypeDef errorcode = HAL_OK;
    uint32 tickstart = HAL_GetTick();
    uint32 frame_bytes = 0U;
    uint32 txdata = 0U;
    uint32 transfer_started = 0U;

    /* Check the SPI peripheral handle */
    if (hspi == NULL_PTR)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_SPI_ALL_PERIPH(hspi->Instance));

    /* Reject an invalid transfer request before the lock is taken: the invalid
     * parameter error is reported without changing the handle state and
     * without consuming the lock (ARCH-CONST-10 / ERR-03) */
    if ((pData == NULL_PTR) || (Size == 0U))
    {
        hspi->ErrorCode |= HAL_SPI_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Process locked */
    if (SPI_LockHandle(hspi, Timeout) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    do
    {
        /* ARCH-CONST-09: reject a new transfer while another one is on-going;
         * the recoverable ERROR / TIMEOUT states accept a retry without a
         * DeInit / Init round trip (STATE-06) */
        errorcode = SPI_CheckState(hspi);
        if (errorcode != HAL_OK)
        {
            /* The handle is busy with another transfer or has not been
             * initialized: report it without touching the state of the
             * on-going operation */
            break;
        }

        transfer_started = 1U;

        /* Set the SPI state to busy TX and reset the error code */
        hspi->State       = HAL_SPI_STATE_BUSY_TX;
        hspi->ErrorCode   = HAL_SPI_ERROR_NONE;
        hspi->pTxBuffPtr  = pData;
        hspi->TxXferSize  = Size;
        hspi->TxXferCount = Size;

        /* Enable the SPI peripheral if it is not already enabled */
        if ((hspi->Instance->CR0 & SPI_CR0_SPE) == 0U)
        {
            hspi->Instance->CR0 |= ((uint32)(SPI_CR0_SPE));
        }

        /* Compute the number of bytes per frame according to the frame size */
        frame_bytes = SPI_GetFrameBytes(hspi);

        /* Transmit all frames */
        while (hspi->TxXferCount > 0U)
        {
            /* Wait until the TX buffer is not full */
            if (SPI_WaitFlagStateUntilTimeout(hspi, SPI_Flag_TXF, 0U, tickstart, Timeout) != HAL_OK)
            {
                errorcode = HAL_TIMEOUT;
                break;
            }

            /* Assemble and send the current frame; the last frame goes to the
             * end-of-send data register so that the DONE flag can be asserted
             * afterwards */
            txdata = SPI_AssembleFrame(hspi->pTxBuffPtr, frame_bytes);
            if (hspi->TxXferCount == 1U)
            {
                hspi->Instance->TXEDR = txdata;
            }
            else
            {
                hspi->Instance->TXDR = txdata;
            }
            hspi->pTxBuffPtr += frame_bytes;
            hspi->TxXferCount--;

            /* Wait until the RX buffer is not empty and read the received frame
             * (required to keep the full duplex flow running in master mode) */
            if (SPI_WaitFlagStateUntilTimeout(hspi, SPI_Flag_RXE, 0U, tickstart, Timeout) != HAL_OK)
            {
                errorcode = HAL_TIMEOUT;
                break;
            }
            (void)hspi->Instance->RXDR;
        }
    }
    while (0);

    /* Only a transfer that was actually started owns the handle state: a
     * rejected request (busy handle) leaves the state of the other operation
     * untouched (ARCH-CONST-09) */
    if (transfer_started != 0U)
    {
        if (errorcode != HAL_OK)
        {
            /* Stop and clean up the failed transfer before its state is
             * published: the shifter is parked and both FIFOs are reset, so a
             * retry can never read stale frames nor inherit a pending event.
             * The cleanup shares the remaining budget of the transfer. */
            SPI_AbortTransfer(hspi, tickstart, Timeout);
        }

        if (errorcode == HAL_TIMEOUT)
        {
            /* STATE-03: a timed out transfer leaves the handle in the
             * recoverable TIMEOUT state */
            if (hspi->ErrorCode == HAL_SPI_ERROR_NONE)
            {
                hspi->ErrorCode |= HAL_SPI_ERROR_FLAG;
            }
            hspi->State = HAL_SPI_STATE_TIMEOUT;
        }
        else if (errorcode != HAL_OK)
        {
            if (hspi->ErrorCode == HAL_SPI_ERROR_NONE)
            {
                hspi->ErrorCode |= HAL_SPI_ERROR_FLAG;
            }
            hspi->State = HAL_SPI_STATE_ERROR;
        }
        else
        {
            hspi->State = HAL_SPI_STATE_READY;
        }
    }

    /* Process unlocked */
    SPI_UnlockHandle(hspi);

    return errorcode;
}

/**
 * @brief  Receives an amount of data in blocking mode. (BLOCKING)
 * @note   In master mode dummy frames are transmitted to generate the SPI
 *         clock.
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  pData: pointer to the data buffer to store the received data.
 * @param  Size: number of frames to receive.
 * @param  Timeout: maximum waiting time in ms (HAL_MAX_DELAY for infinite).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_SPI_Receive(SPI_HandleTypeDef *hspi, uint8 *pData, uint32 Size, uint32 Timeout)
{
    HAL_StatusTypeDef errorcode = HAL_OK;
    uint32 tickstart = HAL_GetTick();
    uint32 frame_bytes = 0U;
    uint32 rxdata = 0U;
    uint32 transfer_started = 0U;

    /* Check the SPI peripheral handle */
    if (hspi == NULL_PTR)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_SPI_ALL_PERIPH(hspi->Instance));

    /* Reject an invalid transfer request before the lock is taken: the invalid
     * parameter error is reported without changing the handle state and
     * without consuming the lock (ARCH-CONST-10 / ERR-03) */
    if ((pData == NULL_PTR) || (Size == 0U))
    {
        hspi->ErrorCode |= HAL_SPI_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Process locked */
    if (SPI_LockHandle(hspi, Timeout) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    do
    {
        /* ARCH-CONST-09: reject a new transfer while another one is on-going;
         * the recoverable ERROR / TIMEOUT states accept a retry without a
         * DeInit / Init round trip (STATE-06) */
        errorcode = SPI_CheckState(hspi);
        if (errorcode != HAL_OK)
        {
            /* The handle is busy with another transfer or has not been
             * initialized: report it without touching the state of the
             * on-going operation */
            break;
        }

        transfer_started = 1U;

        /* Set the SPI state to busy RX and reset the error code */
        hspi->State       = HAL_SPI_STATE_BUSY_RX;
        hspi->ErrorCode   = HAL_SPI_ERROR_NONE;
        hspi->pRxBuffPtr  = pData;
        hspi->RxXferSize  = Size;
        hspi->RxXferCount = Size;

        /* Enable the SPI peripheral if it is not already enabled */
        if ((hspi->Instance->CR0 & SPI_CR0_SPE) == 0U)
        {
            hspi->Instance->CR0 |= ((uint32)(SPI_CR0_SPE));
        }

        /* Compute the number of bytes per frame according to the frame size */
        frame_bytes = SPI_GetFrameBytes(hspi);

        /* Receive all frames */
        while (hspi->RxXferCount > 0U)
        {
            /* In master mode, transmit a dummy frame to generate the clock */
            if (hspi->Init.SPI_Mode == SPI_Mode_Master)
            {
                /* Wait until the TX buffer is not full */
                if (SPI_WaitFlagStateUntilTimeout(hspi, SPI_Flag_TXF, 0U, tickstart, Timeout) != HAL_OK)
                {
                    errorcode = HAL_TIMEOUT;
                    break;
                }
                if (hspi->RxXferCount == 1U)
                {
                    hspi->Instance->TXEDR = 0U;
                }
                else
                {
                    hspi->Instance->TXDR = 0U;
                }
            }

            /* Wait until the RX buffer is not empty */
            if (SPI_WaitFlagStateUntilTimeout(hspi, SPI_Flag_RXE, 0U, tickstart, Timeout) != HAL_OK)
            {
                errorcode = HAL_TIMEOUT;
                break;
            }

            /* Read the received frame (masked to its width), store it
             * (little-endian) */
            rxdata = hspi->Instance->RXDR & SPI_FrameMask(hspi);
            SPI_StoreFrame(hspi->pRxBuffPtr, rxdata, frame_bytes);
            hspi->pRxBuffPtr += frame_bytes;
            hspi->RxXferCount--;
        }
    }
    while (0);

    /* Only a transfer that was actually started owns the handle state: a
     * rejected request (busy handle) leaves the state of the other operation
     * untouched (ARCH-CONST-09) */
    if (transfer_started != 0U)
    {
        if (errorcode != HAL_OK)
        {
            /* Stop and clean up the failed transfer before its state is
             * published: the shifter is parked and both FIFOs are reset, so a
             * retry can never read stale frames nor inherit a pending event.
             * The cleanup shares the remaining budget of the transfer. */
            SPI_AbortTransfer(hspi, tickstart, Timeout);
        }

        if (errorcode == HAL_TIMEOUT)
        {
            /* STATE-03: a timed out transfer leaves the handle in the
             * recoverable TIMEOUT state */
            if (hspi->ErrorCode == HAL_SPI_ERROR_NONE)
            {
                hspi->ErrorCode |= HAL_SPI_ERROR_FLAG;
            }
            hspi->State = HAL_SPI_STATE_TIMEOUT;
        }
        else if (errorcode != HAL_OK)
        {
            if (hspi->ErrorCode == HAL_SPI_ERROR_NONE)
            {
                hspi->ErrorCode |= HAL_SPI_ERROR_FLAG;
            }
            hspi->State = HAL_SPI_STATE_ERROR;
        }
        else
        {
            hspi->State = HAL_SPI_STATE_READY;
        }
    }

    /* Process unlocked */
    SPI_UnlockHandle(hspi);

    return errorcode;
}

/**
 * @brief  Transmits and receives an amount of data in blocking mode. (BLOCKING)
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  pTxData: pointer to the data buffer to transmit.
 * @param  pRxData: pointer to the data buffer to store the received data.
 * @param  Size: number of frames to transmit and receive.
 * @param  Timeout: maximum waiting time in ms (HAL_MAX_DELAY for infinite).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_SPI_TransmitReceive(SPI_HandleTypeDef *hspi, uint8 *pTxData, uint8 *pRxData, uint32 Size,
                                          uint32 Timeout)
{
    HAL_StatusTypeDef errorcode = HAL_OK;
    uint32 tickstart = HAL_GetTick();
    /* Variable used to alternate RX and TX during the transfer */
    uint32 txallowed = 1U;
    uint32 frame_bytes = 0U;
    uint32 txdata = 0U;
    uint32 rxdata = 0U;
    uint32 transfer_started = 0U;

    /* Check the SPI peripheral handle */
    if (hspi == NULL_PTR)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_SPI_ALL_PERIPH(hspi->Instance));

    /* Reject an invalid transfer request before the lock is taken: the invalid
     * parameter error is reported without changing the handle state and
     * without consuming the lock (ARCH-CONST-10 / ERR-03) */
    if ((pTxData == NULL_PTR) || (pRxData == NULL_PTR) || (Size == 0U))
    {
        hspi->ErrorCode |= HAL_SPI_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Process locked */
    if (SPI_LockHandle(hspi, Timeout) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    do
    {
        /* ARCH-CONST-09: reject a new transfer while another one is on-going;
         * the recoverable ERROR / TIMEOUT states accept a retry without a
         * DeInit / Init round trip (STATE-06) */
        errorcode = SPI_CheckState(hspi);
        if (errorcode != HAL_OK)
        {
            /* The handle is busy with another transfer or has not been
             * initialized: report it without touching the state of the
             * on-going operation */
            break;
        }

        transfer_started = 1U;

        /* Set the SPI state to busy TX/RX and reset the error code */
        hspi->State       = HAL_SPI_STATE_BUSY_TX_RX;
        hspi->ErrorCode   = HAL_SPI_ERROR_NONE;
        hspi->pTxBuffPtr  = pTxData;
        hspi->TxXferSize  = Size;
        hspi->TxXferCount = Size;
        hspi->pRxBuffPtr  = pRxData;
        hspi->RxXferSize  = Size;
        hspi->RxXferCount = Size;

        /* Enable the SPI peripheral if it is not already enabled */
        if ((hspi->Instance->CR0 & SPI_CR0_SPE) == 0U)
        {
            hspi->Instance->CR0 |= ((uint32)(SPI_CR0_SPE));
        }

        /* Compute the number of bytes per frame according to the frame size */
        frame_bytes = SPI_GetFrameBytes(hspi);

        /* Transmit and receive all frames (full duplex, TX/RX alternated) */
        while ((hspi->TxXferCount > 0U) || (hspi->RxXferCount > 0U))
        {
            /* Transmit the next frame when allowed and the TX buffer is free */
            if ((txallowed == 1U) && (hspi->TxXferCount > 0U) &&
                (SPI_GetFlagStatusInternal(hspi, SPI_Flag_TXF) == 0U))
            {
                /* Assemble the frame; the last frame goes to the end-of-send
                 * data register */
                txdata = SPI_AssembleFrame(hspi->pTxBuffPtr, frame_bytes);
                if (hspi->TxXferCount == 1U)
                {
                    hspi->Instance->TXEDR = txdata;
                }
                else
                {
                    hspi->Instance->TXDR = txdata;
                }
                hspi->pTxBuffPtr += frame_bytes;
                hspi->TxXferCount--;
                /* The next step must be a reception */
                txallowed = 0U;
            }

            /* Receive the next frame when the RX buffer is not empty */
            if ((hspi->RxXferCount > 0U) &&
                (SPI_GetFlagStatusInternal(hspi, SPI_Flag_RXE) == 0U))
            {
                rxdata = hspi->Instance->RXDR & SPI_FrameMask(hspi);
                SPI_StoreFrame(hspi->pRxBuffPtr, rxdata, frame_bytes);
                hspi->pRxBuffPtr += frame_bytes;
                hspi->RxXferCount--;
                /* The next step can be a transmission */
                txallowed = 1U;
            }

            /* Check the timeout against the single budget of this transfer */
            if ((Timeout != HAL_MAX_DELAY) && (SPI_ElapsedMs(tickstart) >= Timeout))
            {
                errorcode = HAL_TIMEOUT;
                break;
            }

#if (USE_RTOS == 1)
            /* RTOS-04: let the other tasks of the same priority run instead of
             * busy waiting (empty macro in a bare-metal build, RTOS-05) */
            HAL_RTOS_Yield();
#endif /* USE_RTOS */
        }
    }
    while (0);

    /* Only a transfer that was actually started owns the handle state: a
     * rejected request (busy handle) leaves the state of the other operation
     * untouched (ARCH-CONST-09) */
    if (transfer_started != 0U)
    {
        if (errorcode != HAL_OK)
        {
            /* Stop and clean up the failed transfer before its state is
             * published: the shifter is parked and both FIFOs are reset, so a
             * retry can never read stale frames nor inherit a pending event.
             * The cleanup shares the remaining budget of the transfer. */
            SPI_AbortTransfer(hspi, tickstart, Timeout);
        }

        if (errorcode == HAL_TIMEOUT)
        {
            /* STATE-03: a timed out transfer leaves the handle in the
             * recoverable TIMEOUT state */
            if (hspi->ErrorCode == HAL_SPI_ERROR_NONE)
            {
                hspi->ErrorCode |= HAL_SPI_ERROR_FLAG;
            }
            hspi->State = HAL_SPI_STATE_TIMEOUT;
        }
        else if (errorcode != HAL_OK)
        {
            if (hspi->ErrorCode == HAL_SPI_ERROR_NONE)
            {
                hspi->ErrorCode |= HAL_SPI_ERROR_FLAG;
            }
            hspi->State = HAL_SPI_STATE_ERROR;
        }
        else
        {
            hspi->State = HAL_SPI_STATE_READY;
        }
    }

    /* Process unlocked */
    SPI_UnlockHandle(hspi);

    return errorcode;
}

/**
  * @}
  */

/** @addtogroup SPI_Exported_Functions_Group2_IT IO operation functions in interrupt mode
  * @brief    Interrupt mode IO operations
  * @{
  */

/**
 * @brief  Transmits an amount of data in non-blocking mode with Interrupt. (NON-BLOCKING / IT)
 * @note   In master mode the received frame is read back and discarded to
 *         keep the full-duplex flow running. The transfer completion is
 *         reported by the HAL_SPI_TxCpltCallback().
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  pData: pointer to the data buffer to transmit.
 * @param  Size: number of frames to transmit.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_SPI_Transmit_IT(SPI_HandleTypeDef *hspi, uint8 *pData, uint32 Size)
{
    HAL_StatusTypeDef errorcode = HAL_OK;

    /* Check the SPI peripheral handle */
    if (hspi == NULL_PTR)
    {
        return HAL_ERROR;
    }
    assert_param(IS_SPI_ALL_PERIPH(hspi->Instance));

    /* Reject an invalid transfer request before the lock is taken: the invalid
     * parameter error is reported without changing the handle state and
     * without consuming the lock (ARCH-CONST-10 / ERR-03) */
    if ((pData == NULL_PTR) || (Size == 0U))
    {
        hspi->ErrorCode |= HAL_SPI_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Process locked */
    if (SPI_LockHandle(hspi, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    do
    {
        /* ARCH-CONST-09: reject a new transfer while another one is on-going;
         * the recoverable ERROR / TIMEOUT states accept a retry without a
         * DeInit / Init round trip (STATE-06) */
        errorcode = SPI_CheckState(hspi);
        if (errorcode != HAL_OK)
        {
            /* The handle is busy with another transfer or has not been
             * initialized */
            break;
        }

        /* Prepare the transmit transfer */
        hspi->State       = HAL_SPI_STATE_BUSY_TX;
        hspi->ErrorCode   = HAL_SPI_ERROR_NONE;
        hspi->pTxBuffPtr  = pData;
        hspi->TxXferSize  = Size;
        hspi->TxXferCount = Size;

        /* In master full duplex the received frame must be read and discarded */
        if (hspi->Init.SPI_Mode == SPI_Mode_Master)
        {
            hspi->pRxBuffPtr  = NULL_PTR;
            hspi->RxXferSize  = Size;
            hspi->RxXferCount = Size;
        }
        else
        {
            hspi->pRxBuffPtr  = NULL_PTR;
            hspi->RxXferSize  = 0U;
            hspi->RxXferCount = 0U;
        }

        /* Enable the SPI peripheral if it is not already enabled */
        if ((hspi->Instance->CR0 & SPI_CR0_SPE) == 0U)
        {
            hspi->Instance->CR0 |= ((uint32)(SPI_CR0_SPE));
        }

        /* Enable the Tx buffer / Rx buffer interrupts through the lock-free
         * internal helper: this function holds the handle lock, so the public
         * HAL_SPI_ITConfig() must not be used here (LOCK-05) */
        SPI_ITConfigInternal(hspi, SPI_IT_TXNE, SPI_ENABLE);
        SPI_ITConfigInternal(hspi, SPI_IT_RXO, SPI_ENABLE);
        if ((hspi->Init.SPI_Mode == SPI_Mode_Master) && (hspi->RxXferCount > 0U))
        {
            SPI_ITConfigInternal(hspi, SPI_IT_RXNE, SPI_ENABLE);
        }
    }
    while (0);

    /* Process unlocked */
    SPI_UnlockHandle(hspi);
    return errorcode;
}

/**
 * @brief  Receives an amount of data in non-blocking mode with Interrupt. (NON-BLOCKING / IT)
 * @note   In master mode dummy frames are transmitted to generate the SPI
 *         clock (full duplex receive). The transfer completion is reported
 *         by the HAL_SPI_RxCpltCallback().
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  pData: pointer to the data buffer to store the received data.
 * @param  Size: number of frames to receive.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_SPI_Receive_IT(SPI_HandleTypeDef *hspi, uint8 *pData, uint32 Size)
{
    HAL_StatusTypeDef errorcode = HAL_OK;

    /* Check the SPI peripheral handle */
    if (hspi == NULL_PTR)
    {
        return HAL_ERROR;
    }
    assert_param(IS_SPI_ALL_PERIPH(hspi->Instance));

    /* Reject an invalid transfer request before the lock is taken: the invalid
     * parameter error is reported without changing the handle state and
     * without consuming the lock (ARCH-CONST-10 / ERR-03) */
    if ((pData == NULL_PTR) || (Size == 0U))
    {
        hspi->ErrorCode |= HAL_SPI_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Process locked */
    if (SPI_LockHandle(hspi, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    do
    {
        /* ARCH-CONST-09: reject a new transfer while another one is on-going;
         * the recoverable ERROR / TIMEOUT states accept a retry without a
         * DeInit / Init round trip (STATE-06) */
        errorcode = SPI_CheckState(hspi);
        if (errorcode != HAL_OK)
        {
            /* The handle is busy with another transfer or has not been
             * initialized */
            break;
        }

        /* Prepare the receive transfer */
        hspi->State       = HAL_SPI_STATE_BUSY_RX;
        hspi->ErrorCode   = HAL_SPI_ERROR_NONE;
        hspi->pRxBuffPtr  = pData;
        hspi->RxXferSize  = Size;
        hspi->RxXferCount = Size;

        /* In master full duplex a dummy frame stream generates the clock */
        if (hspi->Init.SPI_Mode == SPI_Mode_Master)
        {
            hspi->pTxBuffPtr  = NULL_PTR;
            hspi->TxXferSize  = Size;
            hspi->TxXferCount = Size;
        }
        else
        {
            hspi->pTxBuffPtr  = NULL_PTR;
            hspi->TxXferSize  = 0U;
            hspi->TxXferCount = 0U;
        }

        /* Enable the SPI peripheral if it is not already enabled */
        if ((hspi->Instance->CR0 & SPI_CR0_SPE) == 0U)
        {
            hspi->Instance->CR0 |= ((uint32)(SPI_CR0_SPE));
        }

        /* Enable the Rx / Tx buffer interrupts through the lock-free internal
         * helper: this function holds the handle lock, so the public
         * HAL_SPI_ITConfig() must not be used here (LOCK-05) */
        SPI_ITConfigInternal(hspi, SPI_IT_RXNE, SPI_ENABLE);
        SPI_ITConfigInternal(hspi, SPI_IT_RXO, SPI_ENABLE);
        if ((hspi->Init.SPI_Mode == SPI_Mode_Master) && (hspi->TxXferCount > 0U))
        {
            SPI_ITConfigInternal(hspi, SPI_IT_TXNE, SPI_ENABLE);
        }
    }
    while (0);

    /* Process unlocked */
    SPI_UnlockHandle(hspi);
    return errorcode;
}

/**
 * @brief  Transmits and receives an amount of data in non-blocking mode
 *         with Interrupt. (NON-BLOCKING / IT)
 * @note   The transfer completion is reported by HAL_SPI_TxRxCpltCallback().
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  pTxData: pointer to the data buffer to transmit.
 * @param  pRxData: pointer to the data buffer to store the received data.
 * @param  Size: number of frames to transmit and receive.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_SPI_TransmitReceive_IT(SPI_HandleTypeDef *hspi, uint8 *pTxData, uint8 *pRxData, uint32 Size)
{
    HAL_StatusTypeDef errorcode = HAL_OK;

    /* Check the SPI peripheral handle */
    if (hspi == NULL_PTR)
    {
        return HAL_ERROR;
    }
    assert_param(IS_SPI_ALL_PERIPH(hspi->Instance));

    /* Reject an invalid transfer request before the lock is taken: the invalid
     * parameter error is reported without changing the handle state and
     * without consuming the lock (ARCH-CONST-10 / ERR-03) */
    if ((pTxData == NULL_PTR) || (pRxData == NULL_PTR) || (Size == 0U))
    {
        hspi->ErrorCode |= HAL_SPI_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Process locked */
    if (SPI_LockHandle(hspi, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    do
    {
        /* ARCH-CONST-09: reject a new transfer while another one is on-going;
         * the recoverable ERROR / TIMEOUT states accept a retry without a
         * DeInit / Init round trip (STATE-06) */
        errorcode = SPI_CheckState(hspi);
        if (errorcode != HAL_OK)
        {
            /* The handle is busy with another transfer or has not been
             * initialized */
            break;
        }

        /* Prepare the full duplex transfer */
        hspi->State       = HAL_SPI_STATE_BUSY_TX_RX;
        hspi->ErrorCode   = HAL_SPI_ERROR_NONE;
        hspi->pTxBuffPtr  = pTxData;
        hspi->TxXferSize  = Size;
        hspi->TxXferCount = Size;
        hspi->pRxBuffPtr  = pRxData;
        hspi->RxXferSize  = Size;
        hspi->RxXferCount = Size;

        /* Enable the SPI peripheral if it is not already enabled */
        if ((hspi->Instance->CR0 & SPI_CR0_SPE) == 0U)
        {
            hspi->Instance->CR0 |= ((uint32)(SPI_CR0_SPE));
        }

        /* Enable the Tx / Rx buffer interrupts through the lock-free internal
         * helper: this function holds the handle lock, and the interrupt path
         * calls the same helper, so the public HAL_SPI_ITConfig() must not be
         * used here (LOCK-05) */
        SPI_ITConfigInternal(hspi, SPI_IT_TXNE, SPI_ENABLE);
        SPI_ITConfigInternal(hspi, SPI_IT_RXNE, SPI_ENABLE);
        SPI_ITConfigInternal(hspi, SPI_IT_RXO, SPI_ENABLE);
    }
    while (0);

    /* Process unlocked */
    SPI_UnlockHandle(hspi);
    return errorcode;
}

/**
  * @}
  */

/** @addtogroup SPI_Exported_Functions_Group2_DMA IO operation functions in DMA mode
  * @brief    DMA mode IO operations
  * @{
  */

#ifdef HAL_DMA_MODULE_ENABLED

/**
 * @brief  Transmits an amount of data in non-blocking mode with DMA. (NON-BLOCKING / DMA)
 * @note   The DMA channel referenced by hspi->hdmatx must be initialized
 *         (HAL_DMA_Init) and mapped to the SPI peripheral interface
 *         (HAL_DMAEx_ConfigPeriphIF); the channel data width must match the
 *         SPI frame width. The transfer completion is reported by
 *         HAL_SPI_TxCpltCallback().
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  pData: pointer to the data buffer to transmit.
 * @param  Size: number of frames to transmit.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_SPI_Transmit_DMA(SPI_HandleTypeDef *hspi, uint8 *pData, uint32 Size)
{
    HAL_StatusTypeDef errorcode = HAL_OK;
    uint32 transfer_started = 0U;

    /* Check the SPI peripheral handle */
    if (hspi == NULL_PTR)
    {
        return HAL_ERROR;
    }
    assert_param(IS_SPI_ALL_PERIPH(hspi->Instance));

    /* Reject an invalid transfer request before the lock is taken: the invalid
     * parameter error (including a missing DMA handle) is reported without
     * changing the handle state and without consuming the lock
     * (ARCH-CONST-10 / ERR-03) */
    if ((pData == NULL_PTR) || (Size == 0U) || (hspi->hdmatx == NULL_PTR))
    {
        hspi->ErrorCode |= HAL_SPI_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Reject a channel that cannot move the configured frame width: the
     * direction, the increment modes and both data widths must match the frame
     * storage width (ARCH-CONST-10) */
    if (SPI_CheckDmaLink(hspi, hspi->hdmatx, SPI_DMA_DIR_TX) != HAL_OK)
    {
        hspi->ErrorCode |= HAL_SPI_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Process locked */
    if (SPI_LockHandle(hspi, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    do
    {
        /* ARCH-CONST-09: reject a new transfer while another one is on-going;
         * the recoverable ERROR / TIMEOUT states accept a retry without a
         * DeInit / Init round trip (STATE-06) */
        errorcode = SPI_CheckState(hspi);
        if (errorcode != HAL_OK)
        {
            /* The handle is busy with another transfer or has not been
             * initialized */
            break;
        }

        transfer_started = 1U;

        hspi->State       = HAL_SPI_STATE_BUSY_TX;
        hspi->ErrorCode   = HAL_SPI_ERROR_NONE;
        hspi->pTxBuffPtr  = pData;
        hspi->TxXferSize  = Size;
        hspi->TxXferCount = Size;
        hspi->pRxBuffPtr  = NULL_PTR;
        hspi->RxXferSize  = 0U;
        hspi->RxXferCount = 0U;

        /* Set the DMA channel parent and register the callbacks */
        hspi->hdmatx->Parent  = (void *)hspi;
        HAL_DMA_RegisterCallback(hspi->hdmatx, HAL_DMA_XFER_CPLT_CB_ID, SPI_DMATransmitCplt);
        HAL_DMA_RegisterCallback(hspi->hdmatx, HAL_DMA_XFER_HALFCPLT_CB_ID, SPI_DMAHalfTransmitCplt);
        HAL_DMA_RegisterCallback(hspi->hdmatx, HAL_DMA_XFER_ERROR_CB_ID, SPI_DMAError);
        HAL_DMA_RegisterCallback(hspi->hdmatx, HAL_DMA_XFER_ABORT_CB_ID, SPI_DMAAbortOnError);

        /* Enable the SPI peripheral if it is not already enabled */
        if ((hspi->Instance->CR0 & SPI_CR0_SPE) == 0U)
        {
            hspi->Instance->CR0 |= ((uint32)(SPI_CR0_SPE));
        }

        /* Start the DMA transfer (memory -> SPI TX data register) */
        errorcode = HAL_DMA_Start_IT(hspi->hdmatx, (uint32)hspi->pTxBuffPtr,
                                     (uint32)&hspi->Instance->TXEDR, hspi->TxXferCount);
        if (errorcode != HAL_OK)
        {
            hspi->ErrorCode |= HAL_SPI_ERROR_DMA;
            errorcode = HAL_ERROR;
            break;
        }

        /* Enable the SPI receive overflow interruption to catch a stall,
         * through the lock-free internal helper: this function holds the
         * handle lock, so the public HAL_SPI_ITConfig() must not be used here
         * (LOCK-05) */
        SPI_ITConfigInternal(hspi, SPI_IT_RXO, SPI_ENABLE);
    }
    while (0);

    /* Only a transfer that was actually started owns the handle state: a
     * rejected request (busy handle) leaves the state of the other operation
     * untouched (ARCH-CONST-09) */
    if (transfer_started != 0U)
    {
        if (errorcode != HAL_OK)
        {
            hspi->State = HAL_SPI_STATE_ERROR;
        }
    }

    /* Process unlocked */
    SPI_UnlockHandle(hspi);
    return errorcode;
}

/**
 * @brief  Receives an amount of data in non-blocking mode with DMA. (NON-BLOCKING / DMA)
 * @note   In master mode the receive is a full-duplex transmit/receive flow
 *         (dummy frames are clocked out to generate the SPI clock). The DMA
 *         channel referenced by hspi->hdmarx must be initialized and mapped
 *         to the SPI peripheral interface. The transfer completion is
 *         reported by HAL_SPI_RxCpltCallback().
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  pData: pointer to the data buffer to store the received data.
 * @param  Size: number of frames to receive.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_SPI_Receive_DMA(SPI_HandleTypeDef *hspi, uint8 *pData, uint32 Size)
{
    HAL_StatusTypeDef errorcode = HAL_OK;
    uint32 transfer_started = 0U;

    /* Check the SPI peripheral handle */
    if (hspi == NULL_PTR)
    {
        return HAL_ERROR;
    }
    assert_param(IS_SPI_ALL_PERIPH(hspi->Instance));

    /* Reject an invalid transfer request before the lock is taken: the invalid
     * parameter error (including a missing DMA handle) is reported without
     * changing the handle state and without consuming the lock
     * (ARCH-CONST-10 / ERR-03) */
    if ((pData == NULL_PTR) || (Size == 0U) || (hspi->hdmarx == NULL_PTR))
    {
        hspi->ErrorCode |= HAL_SPI_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Reject a channel that cannot move the configured frame width (see
     * SPI_CheckDmaLink) */
    if (SPI_CheckDmaLink(hspi, hspi->hdmarx, SPI_DMA_DIR_RX) != HAL_OK)
    {
        hspi->ErrorCode |= HAL_SPI_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Process locked */
    if (SPI_LockHandle(hspi, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    do
    {
        /* ARCH-CONST-09: reject a new transfer while another one is on-going;
         * the recoverable ERROR / TIMEOUT states accept a retry without a
         * DeInit / Init round trip (STATE-06) */
        errorcode = SPI_CheckState(hspi);
        if (errorcode != HAL_OK)
        {
            /* The handle is busy with another transfer or has not been
             * initialized */
            break;
        }

        transfer_started = 1U;

        hspi->State       = HAL_SPI_STATE_BUSY_RX;
        hspi->ErrorCode   = HAL_SPI_ERROR_NONE;
        hspi->pRxBuffPtr  = pData;
        hspi->RxXferSize  = Size;
        hspi->RxXferCount = Size;

        /* A master receive is clocked by the frames it transmits: the receive
         * clock only exists while data is written to the transmit side, so the
         * virtual transmit stream is armed here exactly like the interrupt
         * driven receive does (SPI-REQ-060). A slave is clocked by the external
         * master and needs no virtual stream. */
        hspi->pTxBuffPtr  = NULL_PTR;
        if (hspi->Init.SPI_Mode == SPI_Mode_Master)
        {
            hspi->TxXferSize  = Size;
            hspi->TxXferCount = Size;
        }
        else
        {
            hspi->TxXferSize  = 0U;
            hspi->TxXferCount = 0U;
        }

        /* Set the DMA channel parent and register the callbacks */
        hspi->hdmarx->Parent  = (void *)hspi;
        HAL_DMA_RegisterCallback(hspi->hdmarx, HAL_DMA_XFER_CPLT_CB_ID, SPI_DMAReceiveCplt);
        HAL_DMA_RegisterCallback(hspi->hdmarx, HAL_DMA_XFER_HALFCPLT_CB_ID, SPI_DMAHalfReceiveCplt);
        HAL_DMA_RegisterCallback(hspi->hdmarx, HAL_DMA_XFER_ERROR_CB_ID, SPI_DMAError);
        HAL_DMA_RegisterCallback(hspi->hdmarx, HAL_DMA_XFER_ABORT_CB_ID, SPI_DMAAbortOnError);

        /* Enable the SPI peripheral if it is not already enabled */
        if ((hspi->Instance->CR0 & SPI_CR0_SPE) == 0U)
        {
            hspi->Instance->CR0 |= ((uint32)(SPI_CR0_SPE));
        }

        /* Start the DMA transfer (SPI RX data register -> memory) */
        errorcode = HAL_DMA_Start_IT(hspi->hdmarx, (uint32)&hspi->Instance->RXDR,
                                     (uint32)hspi->pRxBuffPtr, hspi->RxXferCount);
        if (errorcode != HAL_OK)
        {
            hspi->ErrorCode |= HAL_SPI_ERROR_DMA;
            errorcode = HAL_ERROR;
            break;
        }

        /* Enable the SPI receive overflow interruption to catch a stall,
         * through the lock-free internal helper: this function holds the
         * handle lock, so the public HAL_SPI_ITConfig() must not be used here
         * (LOCK-05) */
        SPI_ITConfigInternal(hspi, SPI_IT_RXO, SPI_ENABLE);

        /* The receive path is running: arm the virtual transmit stream that
         * provides the master clock. The transmission interrupt service writes
         * one dummy frame per received frame, and the source is armed only now,
         * so a receive path that failed to start never leaves it enabled
         * (SPI-REQ-060). */
        if (hspi->TxXferCount > 0U)
        {
            SPI_ITConfigInternal(hspi, SPI_IT_TXNE, SPI_ENABLE);
        }
    }
    while (0);

    /* Only a transfer that was actually started owns the handle state: a
     * rejected request (busy handle) leaves the state of the other operation
     * untouched (ARCH-CONST-09) */
    if (transfer_started != 0U)
    {
        if (errorcode != HAL_OK)
        {
            hspi->State = HAL_SPI_STATE_ERROR;
        }
    }

    /* Process unlocked */
    SPI_UnlockHandle(hspi);
    return errorcode;
}

/**
 * @brief  Transmits and receives an amount of data in non-blocking mode
 *         with DMA. (NON-BLOCKING / DMA)
 * @note   Both DMA channels referenced by hspi->hdmatx and hspi->hdmarx
 *         must be initialized and mapped to the SPI peripheral interface.
 *         The transfer completion is reported by HAL_SPI_TxRxCpltCallback().
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  pTxData: pointer to the data buffer to transmit.
 * @param  pRxData: pointer to the data buffer to store the received data.
 * @param  Size: number of frames to transmit and receive.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_SPI_TransmitReceive_DMA(SPI_HandleTypeDef *hspi, uint8 *pTxData, uint8 *pRxData, uint32 Size)
{
    HAL_StatusTypeDef errorcode = HAL_OK;
    uint32 transfer_started = 0U;

    /* Check the SPI peripheral handle */
    if (hspi == NULL_PTR)
    {
        return HAL_ERROR;
    }
    assert_param(IS_SPI_ALL_PERIPH(hspi->Instance));

    /* Reject an invalid transfer request before the lock is taken: the invalid
     * parameter error (including a missing DMA handle) is reported without
     * changing the handle state and without consuming the lock
     * (ARCH-CONST-10 / ERR-03) */
    if ((pTxData == NULL_PTR) || (pRxData == NULL_PTR) || (Size == 0U) ||
        (hspi->hdmatx == NULL_PTR) || (hspi->hdmarx == NULL_PTR))
    {
        hspi->ErrorCode |= HAL_SPI_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Reject a channel that cannot move the configured frame width (see
     * SPI_CheckDmaLink) */
    if ((SPI_CheckDmaLink(hspi, hspi->hdmatx, SPI_DMA_DIR_TX) != HAL_OK) ||
        (SPI_CheckDmaLink(hspi, hspi->hdmarx, SPI_DMA_DIR_RX) != HAL_OK))
    {
        hspi->ErrorCode |= HAL_SPI_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Process locked */
    if (SPI_LockHandle(hspi, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    do
    {
        /* ARCH-CONST-09: reject a new transfer while another one is on-going;
         * the recoverable ERROR / TIMEOUT states accept a retry without a
         * DeInit / Init round trip (STATE-06) */
        errorcode = SPI_CheckState(hspi);
        if (errorcode != HAL_OK)
        {
            /* The handle is busy with another transfer or has not been
             * initialized */
            break;
        }

        transfer_started = 1U;

        hspi->State       = HAL_SPI_STATE_BUSY_TX_RX;
        hspi->ErrorCode   = HAL_SPI_ERROR_NONE;
        hspi->pTxBuffPtr  = pTxData;
        hspi->TxXferSize  = Size;
        hspi->TxXferCount = Size;
        hspi->pRxBuffPtr  = pRxData;
        hspi->RxXferSize  = Size;
        hspi->RxXferCount = Size;

        /* Set the DMA channel parents and register the callbacks */
        hspi->hdmatx->Parent  = (void *)hspi;
        hspi->hdmarx->Parent  = (void *)hspi;
        HAL_DMA_RegisterCallback(hspi->hdmarx, HAL_DMA_XFER_CPLT_CB_ID, SPI_DMATransmitReceiveCplt);
        HAL_DMA_RegisterCallback(hspi->hdmarx, HAL_DMA_XFER_HALFCPLT_CB_ID, SPI_DMAHalfTransmitReceiveCplt);
        HAL_DMA_RegisterCallback(hspi->hdmarx, HAL_DMA_XFER_ERROR_CB_ID, SPI_DMAError);
        HAL_DMA_RegisterCallback(hspi->hdmarx, HAL_DMA_XFER_ABORT_CB_ID, SPI_DMAAbortOnError);
        HAL_DMA_RegisterCallback(hspi->hdmatx, HAL_DMA_XFER_CPLT_CB_ID, NULL);
        HAL_DMA_RegisterCallback(hspi->hdmatx, HAL_DMA_XFER_ERROR_CB_ID, SPI_DMAError);
        HAL_DMA_RegisterCallback(hspi->hdmatx, HAL_DMA_XFER_ABORT_CB_ID, SPI_DMAAbortOnError);

        /* Enable the SPI peripheral if it is not already enabled */
        if ((hspi->Instance->CR0 & SPI_CR0_SPE) == 0U)
        {
            hspi->Instance->CR0 |= ((uint32)(SPI_CR0_SPE));
        }

        /* Start the DMA transfers (SPI RX data register <- memory and
         * SPI TX data register <- memory). The reception is driven by the Rx
         * DMA channel completion; the Tx DMA channel callback is left empty. */
        errorcode = HAL_DMA_Start_IT(hspi->hdmarx, (uint32)&hspi->Instance->RXDR,
                                     (uint32)hspi->pRxBuffPtr, hspi->RxXferCount);
        if (errorcode != HAL_OK)
        {
            hspi->ErrorCode |= HAL_SPI_ERROR_DMA;
            errorcode = HAL_ERROR;
            break;
        }
        errorcode = HAL_DMA_Start_IT(hspi->hdmatx, (uint32)hspi->pTxBuffPtr,
                                     (uint32)&hspi->Instance->TXEDR, hspi->TxXferCount);
        if (errorcode != HAL_OK)
        {
            hspi->ErrorCode |= HAL_SPI_ERROR_DMA;
            errorcode = HAL_ERROR;
            break;
        }

        /* Enable the SPI receive overflow interruption to catch a stall,
         * through the lock-free internal helper: this function holds the
         * handle lock, so the public HAL_SPI_ITConfig() must not be used here
         * (LOCK-05) */
        SPI_ITConfigInternal(hspi, SPI_IT_RXO, SPI_ENABLE);
    }
    while (0);

    /* Only a transfer that was actually started owns the handle state: a
     * rejected request (busy handle) leaves the state of the other operation
     * untouched (ARCH-CONST-09) */
    if (transfer_started != 0U)
    {
        if (errorcode != HAL_OK)
        {
            hspi->State = HAL_SPI_STATE_ERROR;
        }
    }

    /* Process unlocked */
    SPI_UnlockHandle(hspi);
    return errorcode;
}

#else /* HAL_DMA_MODULE_ENABLED == 1U */

/**
 * @brief  Transmits an amount of data in non-blocking mode with DMA. (NON-BLOCKING / DMA)
 * @note   Not supported: the DMA module is disabled in the configuration.
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  pData: pointer to the data buffer to transmit.
 * @param  Size: number of frames to transmit.
 * @retval HAL_StatusTypeDef: HAL_ERROR
 */
HAL_StatusTypeDef HAL_SPI_Transmit_DMA(SPI_HandleTypeDef *hspi, uint8 *pData, uint32 Size)
{
    /* Check the hspi handle allocation */
    if (hspi == NULL_PTR)
    {
        return HAL_ERROR;
    }
    UNUSED(hspi);
    UNUSED(pData);
    UNUSED(Size);
    return HAL_ERROR;
}

/**
 * @brief  Receives an amount of data in non-blocking mode with DMA. (NON-BLOCKING / DMA)
 * @note   Not supported: the DMA module is disabled in the configuration.
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  pData: pointer to the data buffer to store the received data.
 * @param  Size: number of frames to receive.
 * @retval HAL_StatusTypeDef: HAL_ERROR
 */
HAL_StatusTypeDef HAL_SPI_Receive_DMA(SPI_HandleTypeDef *hspi, uint8 *pData, uint32 Size)
{
    /* Check the hspi handle allocation */
    if (hspi == NULL_PTR)
    {
        return HAL_ERROR;
    }
    UNUSED(hspi);
    UNUSED(pData);
    UNUSED(Size);
    return HAL_ERROR;
}

/**
 * @brief  Transmits and receives an amount of data in non-blocking mode
 *         with DMA. (NON-BLOCKING / DMA)
 * @note   Not supported: the DMA module is disabled in the configuration.
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  pTxData: pointer to the data buffer to transmit.
 * @param  pRxData: pointer to the data buffer to store the received data.
 * @param  Size: number of frames to transmit and receive.
 * @retval HAL_StatusTypeDef: HAL_ERROR
 */
HAL_StatusTypeDef HAL_SPI_TransmitReceive_DMA(SPI_HandleTypeDef *hspi, uint8 *pTxData, uint8 *pRxData, uint32 Size)
{
    /* Check the hspi handle allocation */
    if (hspi == NULL_PTR)
    {
        return HAL_ERROR;
    }
    UNUSED(hspi);
    UNUSED(pTxData);
    UNUSED(pRxData);
    UNUSED(Size);
    return HAL_ERROR;
}

#endif /* HAL_DMA_MODULE_ENABLED == 1U */

/**
  * @}
  */

/** @addtogroup SPI_Exported_Functions_Group3 Peripheral Control functions
  * @{
  */

/**
 * @brief  Return the SPI handle state. (NON-BLOCKING)
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval HAL_SPI_StateTypeDef: the current handle state.
 */
HAL_SPI_StateTypeDef HAL_SPI_GetState(SPI_HandleTypeDef *hspi)
{
    /* Check the SPI peripheral handle */
    if (hspi == NULL_PTR)
    {
        return HAL_SPI_STATE_RESET;
    }

    return hspi->State;
}

/**
 * @brief  Return the SPI error code. (NON-BLOCKING)
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval uint32: the SPI error code (HAL_SPI_ERROR_xxx).
 */
uint32 HAL_SPI_GetError(SPI_HandleTypeDef *hspi)
{
    /* Check the SPI peripheral handle */
    if (hspi == NULL_PTR)
    {
        return HAL_SPI_ERROR_NONE;
    }

    return hspi->ErrorCode;
}

/**
  * @}
  */

/** @addtogroup SPI_Exported_Functions_Group3_Callbacks IRQ handler and callbacks
  * @{
  */

/**
 * @brief  Handle the SPI interrupt request.
 * @note   Called by the user SPI0..SPI5 IRQ handlers (see as32x601_plic.h).
 *         The receive buffer overflow is treated as a blocking error; the
 *         receive and transmit paths are serviced and the corresponding
 *         user callbacks are invoked when a side completes.
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval None
 */
void HAL_SPI_IRQHandler(SPI_HandleTypeDef *hspi)
{
    uint32 isrflags = 0U;

    if (hspi == NULL_PTR)
    {
        return;
    }

    /* Read the masked interrupt status register */
    isrflags = hspi->Instance->ISR;

    /* Receive buffer overflow: blocking error */
    if ((isrflags & SPI_ITStatus_RXO) != 0U)
    {
        hspi->ErrorCode |= HAL_SPI_ERROR_RXO;
        HAL_SPI_ClearITPendingBit(hspi, SPI_CLEAR_RXO);
        hspi->State = HAL_SPI_STATE_ERROR;
        HAL_SPI_ErrorCallback(hspi);
        return;
    }

    /* RX buffer non-empty: service the receive path */
    if ((isrflags & SPI_ITStatus_RXNE) != 0U)
    {
        SPI_Receive_IT(hspi);
    }

    /* TX buffer not full: service the transmit path */
    if ((isrflags & SPI_ITStatus_TXNF) != 0U)
    {
        SPI_Transmit_IT(hspi);
    }
}

/**
 * @brief  Tx Half Transfer completed callback (WEAK).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_SPI_TxHalfCpltCallback(SPI_HandleTypeDef *hspi)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hspi);
}

/**
 * @brief  Tx Transfer completed callback (WEAK).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_SPI_TxCpltCallback(SPI_HandleTypeDef *hspi)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hspi);
}

/**
 * @brief  Rx Half Transfer completed callback (WEAK).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_SPI_RxHalfCpltCallback(SPI_HandleTypeDef *hspi)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hspi);
}

/**
 * @brief  Rx Transfer completed callback (WEAK).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_SPI_RxCpltCallback(SPI_HandleTypeDef *hspi)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hspi);
}

/**
 * @brief  Tx/Rx Transfer completed callback (WEAK).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_SPI_TxRxCpltCallback(SPI_HandleTypeDef *hspi)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hspi);
}

/**
 * @brief  SPI error callback (WEAK).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_SPI_ErrorCallback(SPI_HandleTypeDef *hspi)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hspi);
}

/**
  * @}
  */

/** @addtogroup SPI_Exported_Functions_Group4 Low level register functions
  * @{
  */

/**
 * @brief  Enables or disables the specified SPI peripheral. (NON-BLOCKING)
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  NewState: SPI_ENABLE or SPI_DISABLE.
 * @retval None
 */
void HAL_SPI_Cmd(SPI_HandleTypeDef *hspi, uint32 NewState)
{
    /* Check the SPI peripheral handle */
    if (hspi == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_SPI_ALL_PERIPH(hspi->Instance));

    if (NewState != SPI_DISABLE)
    {
        /* Enable the SPI peripheral */
        hspi->Instance->CR0 |= ((uint32)(SPI_CR0_SPE));
    }
    else
    {
        /* Disable the SPI peripheral */
        hspi->Instance->CR0 &= ~((uint32)(SPI_CR0_SPE));
    }
}

/**
 * @brief  Resets the specified SPI FIFO (receive / transmit / both). (NON-BLOCKING)
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  SPI_FIFOType: SPI_RESETFIFO_RX / SPI_RESETFIFO_TX /
 *         SPI_RESETFIFO_TXANDRX.
 * @retval None
 */
void HAL_SPI_ResetFIFO(SPI_HandleTypeDef *hspi, uint32 SPI_FIFOType)
{
    /* Check the SPI peripheral handle */
    if (hspi == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_SPI_ALL_PERIPH(hspi->Instance));
    assert_param(IS_SPI_RESETFIFO(SPI_FIFOType));

    /* Reset the selected FIFO(s) through the buffer reset control register */
    hspi->Instance->CR1 = SPI_FIFOType;
}

/**
 * @brief  Sets or resets the specified SPI slave selection. (NON-BLOCKING)
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  Slavex: SPI_Slave0 / SPI_Slave1 / SPI_Slave2 / SPI_Slave3.
 * @param  NewState: 1 = select, 0 = deselect.
 * @retval None
 */
void HAL_SPI_NSSConfig(SPI_HandleTypeDef *hspi, uint32 Slavex, uint32 NewState)
{
    /* Check the SPI peripheral handle */
    if (hspi == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_SPI_ALL_PERIPH(hspi->Instance));
    assert_param(IS_SPI_SLAVESEL(Slavex));

    /* SSR is write-only: select exactly Slavex when enabled, or deselect all
     * slaves when disabled. A read-modify-write sequence is not valid. */
    if (NewState != SPI_DISABLE)
    {
        hspi->Instance->SSR = Slavex;
    }
    else
    {
        hspi->Instance->SSR = 0U;
    }
}

/**
 * @brief  Transmits a single data frame through the SPI peripheral. (NON-BLOCKING)
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  Data: the data frame to transmit (right-aligned in the register).
 * @retval None
 */
void HAL_SPI_SendData(SPI_HandleTypeDef *hspi, uint32 Data)
{
    /* Check the SPI peripheral handle */
    if (hspi == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_SPI_ALL_PERIPH(hspi->Instance));

    /* Transmit the data frame */
    hspi->Instance->TXDR = Data;
}

/**
 * @brief  Transmits the last data frame of a transfer. (NON-BLOCKING)
 * @note   The last frame is written to the end-of-send data register.
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  DataLast: the last data frame to transmit.
 * @retval None
 */
void HAL_SPI_SendDataLast(SPI_HandleTypeDef *hspi, uint32 DataLast)
{
    /* Check the SPI peripheral handle */
    if (hspi == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_SPI_ALL_PERIPH(hspi->Instance));

    /* Transmit the last data frame */
    hspi->Instance->TXEDR = DataLast;
}

/**
 * @brief  Returns the most recent received data frame by the SPI peripheral. (NON-BLOCKING)
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval uint32: the received data frame.
 */
uint32 HAL_SPI_ReceiveData(SPI_HandleTypeDef *hspi)
{
    /* Check the SPI peripheral handle */
    if (hspi == NULL_PTR)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_SPI_ALL_PERIPH(hspi->Instance));

    /* Return the received data frame */
    return (uint32)hspi->Instance->RXDR;
}

/**
 * @brief  Enables or disables the specified SPI interrupt source. (NON-BLOCKING)
 * @note   Lock-free and state-free on purpose: the register access is
 *         performed by the internal SPI_ITConfigInternal() helper, which is
 *         also used by the transfer start functions and by the interrupt
 *         services. This keeps the helper callable from an interrupt service
 *         routine (LOCK-04) and while the handle lock is held by the calling
 *         API (LOCK-05 / RTOS-12).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  SPI_IT: the interrupt source to enable/disable (SPI_IT_xxx).
 * @param  NewState: 1 = enable, 0 = disable.
 * @retval None
 */
void HAL_SPI_ITConfig(SPI_HandleTypeDef *hspi, uint32 SPI_IT, uint32 NewState)
{
    /* Check the SPI peripheral handle */
    if (hspi == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_SPI_ALL_PERIPH(hspi->Instance));
    assert_param(IS_SPI_CONFIG_IT(SPI_IT));

    SPI_ITConfigInternal(hspi, SPI_IT, NewState);
}

/**
 * @brief  Checks whether the specified SPI interrupt status (masked) is set. (NON-BLOCKING)
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  SPI_ITSTA: the interrupt status to check (SPI_ITStatus_xxx).
 * @retval 1 if the status is set, 0 otherwise.
 */
uint32 HAL_SPI_GetITStatus(SPI_HandleTypeDef *hspi, uint32 SPI_ITSTA)
{
    uint32 bitstatus = 0U;

    /* Check the SPI peripheral handle */
    if (hspi == NULL_PTR)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_SPI_ALL_PERIPH(hspi->Instance));
    assert_param(IS_SPI_GETSTA_IT(SPI_ITSTA));

    /* Check the masked interrupt status register */
    if ((hspi->Instance->ISR & SPI_ITSTA) != 0U)
    {
        bitstatus = 1U;
    }

    return bitstatus;
}

/**
 * @brief  Checks whether the specified SPI interrupt raw status is set. (NON-BLOCKING)
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  SPI_ITRaw: the interrupt raw status to check (SPI_ITRaw_xxx).
 * @retval 1 if the raw status is set, 0 otherwise.
 */
uint32 HAL_SPI_GetITRawStatus(SPI_HandleTypeDef *hspi, uint32 SPI_ITRaw)
{
    uint32 bitstatus = 0U;

    /* Check the SPI peripheral handle */
    if (hspi == NULL_PTR)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_SPI_ALL_PERIPH(hspi->Instance));
    assert_param(IS_SPI_GETRAW_IT(SPI_ITRaw));

    /* Check the raw interrupt status register */
    if ((hspi->Instance->IRSR & SPI_ITRaw) != 0U)
    {
        bitstatus = 1U;
    }

    return bitstatus;
}

/**
 * @brief  Checks whether the specified SPI status flag is set. (NON-BLOCKING)
 * @note   The register read is performed by the internal
 *         SPI_GetFlagStatusInternal() helper, which is shared with the
 *         transfer paths and with the interrupt services. It takes no lock,
 *         so this read-only helper stays usable from an interrupt service
 *         routine and while the handle lock is held (LOCK-04 / LOCK-05).
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  SPI_FLAG: the flag to check (SPI_Flag_xxx).
 * @retval 1 if the flag is set, 0 otherwise.
 */
uint32 HAL_SPI_GetFlagStatus(SPI_HandleTypeDef *hspi, uint32 SPI_FLAG)
{
    /* Check the SPI peripheral handle */
    if (hspi == NULL_PTR)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_SPI_ALL_PERIPH(hspi->Instance));
    assert_param(IS_SPI_FLAG(SPI_FLAG));

    /* Check the status register */
    return SPI_GetFlagStatusInternal(hspi, SPI_FLAG);
}

/**
 * @brief  Clears the specified SPI interrupt pending bit. (NON-BLOCKING)
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @param  SPI_ITSTA: the interrupt pending bit to clear (SPI_CLEAR_xxx).
 * @retval None
 */
void HAL_SPI_ClearITPendingBit(SPI_HandleTypeDef *hspi, uint32 SPI_ITSTA)
{
    /* Check the SPI peripheral handle */
    if (hspi == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_SPI_ALL_PERIPH(hspi->Instance));
    assert_param(IS_SPI_CLEAR_IT(SPI_ITSTA));

    /* Clear the interrupt pending bit through the interrupt clear register */
    hspi->Instance->IFCR = (uint32)SPI_ITSTA;
}

/**
  * @}
  */

/**
  * @}
  */

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Close an interrupt-driven SPI transfer once both sides are done.
 * @note   The State still holds the logical direction (BUSY_TX / BUSY_RX /
 *         BUSY_TX_RX) so the matching completion callback is invoked; the
 *         transfer is not closed until BOTH the Tx and Rx counters are zero.
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval None
 */
static void SPI_EndTransfer_IT(SPI_HandleTypeDef *hspi)
{
    if ((hspi->TxXferCount == 0U) && (hspi->RxXferCount == 0U))
    {
        if (hspi->State == HAL_SPI_STATE_BUSY_TX)
        {
            hspi->State = HAL_SPI_STATE_READY;
            HAL_SPI_TxCpltCallback(hspi);
        }
        else if (hspi->State == HAL_SPI_STATE_BUSY_RX)
        {
            hspi->State = HAL_SPI_STATE_READY;
            HAL_SPI_RxCpltCallback(hspi);
        }
        else if (hspi->State == HAL_SPI_STATE_BUSY_TX_RX)
        {
            hspi->State = HAL_SPI_STATE_READY;
            HAL_SPI_TxRxCpltCallback(hspi);
        }
    }
}

/**
 * @brief  Transmit the next frame in interrupt mode.
 * @note   In master full duplex the matching received frame is read back and
 *         discarded. When both the Tx and the Rx counters reach zero the
 *         transfer is closed by SPI_EndTransfer_IT().
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval None
 */
static void SPI_Transmit_IT(SPI_HandleTypeDef *hspi)
{
    uint32 frame_bytes = SPI_GetFrameBytes(hspi);
    uint32 txdata;

    /* Only write the next frame when the Tx buffer is not full: the handler
     * may be invoked for an RX event alone, in which case Transmit side has
     * nothing to do. */
    if ((hspi->TxXferCount > 0U) && (SPI_GetFlagStatusInternal(hspi, SPI_Flag_TXF) == 0U))
    {
        if (hspi->pTxBuffPtr != NULL_PTR)
        {
            txdata = SPI_AssembleFrame(hspi->pTxBuffPtr, frame_bytes);
            if (hspi->TxXferCount == 1U)
            {
                hspi->Instance->TXEDR = txdata;
            }
            else
            {
                hspi->Instance->TXDR = txdata;
            }
            hspi->pTxBuffPtr += frame_bytes;
        }
        else
        {
            /* Master receive-only: write a dummy frame to generate the clock */
            if (hspi->TxXferCount == 1U)
            {
                hspi->Instance->TXEDR = 0U;
            }
            else
            {
                hspi->Instance->TXDR = 0U;
            }
        }
        hspi->TxXferCount--;

        if (hspi->TxXferCount == 0U)
        {
            /* Disable the Tx interrupt: the closure is completed when the
             * Rx side is done as well (SPI_EndTransfer_IT). The interrupt path
             * takes no lock and performs no state check, hence the lock-free
             * internal helper is used instead of the public
             * HAL_SPI_ITConfig() (LOCK-04 / RTOS-12). */
            SPI_ITConfigInternal(hspi, SPI_IT_TXNE, SPI_DISABLE);
        }

        SPI_EndTransfer_IT(hspi);
    }
}

/**
 * @brief  Receive the next frame in interrupt mode.
 * @note   In master transmit-only mode the received frame is discarded. When
 *         both the Tx and the Rx counters reach zero the transfer is closed
 *         by SPI_EndTransfer_IT().
 * @param  hspi: pointer to a SPI_HandleTypeDef structure.
 * @retval None
 */
static void SPI_Receive_IT(SPI_HandleTypeDef *hspi)
{
    uint32 frame_bytes = SPI_GetFrameBytes(hspi);
    uint32 rxdata;

    if (SPI_GetFlagStatusInternal(hspi, SPI_Flag_RXE) == 0U)   /* RX buffer not empty */
    {
        rxdata = hspi->Instance->RXDR & SPI_FrameMask(hspi);

        if (hspi->pRxBuffPtr != NULL_PTR)
        {
            SPI_StoreFrame(hspi->pRxBuffPtr, rxdata, frame_bytes);
            hspi->pRxBuffPtr += frame_bytes;
        }
        /* else: master transmit-only, the frame is discarded */
        hspi->RxXferCount--;

        if (hspi->RxXferCount == 0U)
        {
            /* Disable the Rx interrupt: the closure is completed when the
             * Tx side is done as well (SPI_EndTransfer_IT). The interrupt path
             * takes no lock and performs no state check, hence the lock-free
             * internal helper is used instead of the public
             * HAL_SPI_ITConfig() (LOCK-04 / RTOS-12). */
            SPI_ITConfigInternal(hspi, SPI_IT_RXNE, SPI_DISABLE);
        }

        SPI_EndTransfer_IT(hspi);
    }
}

#ifdef HAL_DMA_MODULE_ENABLED

/**
 * @brief  DMA SPI transmit process complete callback.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure.
 * @retval None
 */
static void SPI_DMATransmitCplt(DMA_HandleTypeDef *hdma)
{
    SPI_HandleTypeDef *hspi = (SPI_HandleTypeDef *)((DMA_HandleTypeDef *)hdma)->Parent;

    if (hspi == NULL_PTR)
    {
        return;
    }

    hspi->TxXferCount = 0U;
    hspi->State       = HAL_SPI_STATE_READY;
    HAL_SPI_TxCpltCallback(hspi);
}

/**
 * @brief  DMA SPI receive process complete callback.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure.
 * @retval None
 */
static void SPI_DMAReceiveCplt(DMA_HandleTypeDef *hdma)
{
    SPI_HandleTypeDef *hspi = (SPI_HandleTypeDef *)((DMA_HandleTypeDef *)hdma)->Parent;

    if (hspi == NULL_PTR)
    {
        return;
    }

    hspi->RxXferCount = 0U;
    hspi->TxXferCount = 0U;
    /* The virtual transmit stream (the master receive clock) is no longer
     * needed: its state has just been cleared, so the source is disarmed */
    SPI_ITConfigInternal(hspi, SPI_IT_TXNE, SPI_DISABLE);
    /* The DMA channel stored whole storage units: mask every received frame
     * before the callback reads the buffer */
    SPI_MaskReceivedFrames(hspi, hspi->RxXferSize);
    hspi->State       = HAL_SPI_STATE_READY;
    HAL_SPI_RxCpltCallback(hspi);
}

/**
 * @brief  DMA SPI transmit/receive process complete callback.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure.
 * @retval None
 */
static void SPI_DMATransmitReceiveCplt(DMA_HandleTypeDef *hdma)
{
    SPI_HandleTypeDef *hspi = (SPI_HandleTypeDef *)((DMA_HandleTypeDef *)hdma)->Parent;

    if (hspi == NULL_PTR)
    {
        return;
    }

    hspi->RxXferCount = 0U;
    hspi->TxXferCount = 0U;
    /* The DMA channel stored whole storage units: mask every received frame
     * before the callback reads the buffer */
    SPI_MaskReceivedFrames(hspi, hspi->RxXferSize);
    hspi->State       = HAL_SPI_STATE_READY;
    HAL_SPI_TxRxCpltCallback(hspi);
}

/**
 * @brief  DMA SPI half transmit process complete callback.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure.
 * @retval None
 */
static void SPI_DMAHalfTransmitCplt(DMA_HandleTypeDef *hdma)
{
    SPI_HandleTypeDef *hspi = (SPI_HandleTypeDef *)((DMA_HandleTypeDef *)hdma)->Parent;

    if (hspi == NULL_PTR)
    {
        return;
    }
    HAL_SPI_TxHalfCpltCallback(hspi);
}

/**
 * @brief  DMA SPI half receive process complete callback.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure.
 * @retval None
 */
static void SPI_DMAHalfReceiveCplt(DMA_HandleTypeDef *hdma)
{
    SPI_HandleTypeDef *hspi = (SPI_HandleTypeDef *)((DMA_HandleTypeDef *)hdma)->Parent;

    if (hspi == NULL_PTR)
    {
        return;
    }

    /* The first half of the receive buffer is complete: mask the frames the
     * DMA channel already stored there before the callback reads them */
    SPI_MaskReceivedFrames(hspi, hspi->RxXferSize / 2U);

    HAL_SPI_RxHalfCpltCallback(hspi);
}

/**
 * @brief  DMA SPI half transmit/receive process complete callback.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure.
 * @retval None
 */
static void SPI_DMAHalfTransmitReceiveCplt(DMA_HandleTypeDef *hdma)
{
    SPI_HandleTypeDef *hspi = (SPI_HandleTypeDef *)((DMA_HandleTypeDef *)hdma)->Parent;

    if (hspi == NULL_PTR)
    {
        return;
    }

    /* The first half of the receive buffer is complete: mask the frames the
     * DMA channel already stored there before the callback reads them */
    SPI_MaskReceivedFrames(hspi, hspi->RxXferSize / 2U);

    HAL_SPI_TxRxCpltCallback(hspi);
}

/**
 * @brief  DMA SPI communication error callback.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure.
 * @retval None
 */
static void SPI_DMAError(DMA_HandleTypeDef *hdma)
{
    SPI_HandleTypeDef *hspi = (SPI_HandleTypeDef *)((DMA_HandleTypeDef *)hdma)->Parent;

    if (hspi == NULL_PTR)
    {
        return;
    }

    /* A failed transfer must not leave any source enabled: the transfer is
     * closed here, so no event of it may reach the interrupt service again */
    SPI_ITConfigInternal(hspi, SPI_IT_TXNE, SPI_DISABLE);
    SPI_ITConfigInternal(hspi, SPI_IT_RXNE, SPI_DISABLE);
    SPI_ITConfigInternal(hspi, SPI_IT_RXO, SPI_DISABLE);

    hspi->ErrorCode |= HAL_SPI_ERROR_DMA;
    hspi->State      = HAL_SPI_STATE_READY;
    HAL_SPI_ErrorCallback(hspi);
}

/**
 * @brief  DMA SPI communication abort callback.
 * @param  hdma: pointer to a DMA_HandleTypeDef structure.
 * @retval None
 */
static void SPI_DMAAbortOnError(DMA_HandleTypeDef *hdma)
{
    SPI_HandleTypeDef *hspi = (SPI_HandleTypeDef *)((DMA_HandleTypeDef *)hdma)->Parent;

    if (hspi == NULL_PTR)
    {
        return;
    }

    hspi->RxXferCount = 0U;
    hspi->TxXferCount = 0U;
    /* Disarm every source of the aborted transfer (see SPI_DMAError) */
    SPI_ITConfigInternal(hspi, SPI_IT_TXNE, SPI_DISABLE);
    SPI_ITConfigInternal(hspi, SPI_IT_RXNE, SPI_DISABLE);
    SPI_ITConfigInternal(hspi, SPI_IT_RXO, SPI_DISABLE);
    HAL_SPI_ErrorCallback(hspi);
}

#endif /* HAL_DMA_MODULE_ENABLED == 1U */

#endif /* HAL_SPI_MODULE_ENABLED */

/*****END OF FILE*****/

