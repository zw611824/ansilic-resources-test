/**
 * @file    GPIO_IT_DRV_014.c
 * @brief   HAL GPIO integration test case 014 (GPIOC, output waveform, every output API).
 *
 * One-to-one HAL library port of the original AS32x601 standard-library
 * test case GPIO_IT_DRV_014.c. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_GPIO_Init()        (output push-pull, 9 mA drive current)
 *   HAL_GPIO_WritePin()    (GPIO_PIN_SET / GPIO_PIN_RESET)
 *   HAL_GPIO_TogglePin()
 *   HAL_GPIO_WritePort() (whole output register write)
 *
 * Test configuration:
 *   GPIOC test pins : GPIO_Pin_0 .. GPIO_Pin_15 (mask 0xFFFF)
 *   GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15 are driven by the FlexBus interface out
 *   of reset: the case selects the plain GPIO function for them before configuring
 *   them, as the original test case does. Every other channel is a plain GPIO.
 *
 * Test procedure:
 *   1. initialize the GPIOC test pins as push-pull outputs
 *   2. set the test pins high, wait 50 ms
 *   3. clear the test pins, wait 50 ms
 *   4. toggle the test pins, wait 50 ms
 *   5. toggle the test pins again, wait 50 ms
 *   6. set the test pins high, wait 50 ms
 *   7. clear the test pins, wait 50 ms
 *   8. write the test pin pattern to the whole output register, wait 50 ms
 *   9. clear the test pins, wait 50 ms
 *   10. loop over steps 2..9
 *
 * Expected behaviour:
 *   Logic analyser on the test pins: a 10 Hz square wave with a 50 % duty cycle.
 *   The eight 50 ms phases alternate high and low, so one period takes 100 ms
 *   while every output API of the driver is exercised.
 *
 * Note: this case prints nothing. The observation variables below and the
 * register values are meant to be watched with the debugger, and the pin
 * waveform with a logic analyser.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"

/* Private define -----------------------------------------------------------*/
/* GPIOC test pins */
#define TEST_PIN        (GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | \
                         GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7 | \
                         GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_11 | \
                         GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15)

/* Test pin mask, kept in a 32 bit type for the accumulated observations */
#define TEST_PIN_MASK   ((uint32)0xFFFFU)

/* Private variables ---------------------------------------------------------*/
static HAL_SMU_HandleTypeDef hsmu_clk;   /*!< SMU handle (lock / state / error) */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void gpioc_Config(void);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Configure the GPIOC test pins */
    gpioc_Config();

    while (1)
    {
        /* Steps 2..9: eight 50 ms phases (set / clear / toggle / toggle / set /
           clear / whole port write / clear). The phases alternate high and low, so
           every test pin carries a 10 Hz square wave with a 50 % duty cycle. */
        HAL_GPIO_WritePin(GPIOC, TEST_PIN, GPIO_PIN_SET);
        delay_ms(50U);

        HAL_GPIO_WritePin(GPIOC, TEST_PIN, GPIO_PIN_RESET);
        delay_ms(50U);

        HAL_GPIO_TogglePin(GPIOC, TEST_PIN);
        delay_ms(50U);

        HAL_GPIO_TogglePin(GPIOC, TEST_PIN);
        delay_ms(50U);

        HAL_GPIO_WritePin(GPIOC, TEST_PIN, GPIO_PIN_SET);
        delay_ms(50U);

        HAL_GPIO_WritePin(GPIOC, TEST_PIN, GPIO_PIN_RESET);
        delay_ms(50U);

        HAL_GPIO_WritePort(GPIOC, (uint16)TEST_PIN);
        delay_ms(50U);

        HAL_GPIO_WritePin(GPIOC, TEST_PIN, GPIO_PIN_RESET);
        delay_ms(50U);
    }
}

/**
 * @brief  Configure the system clock tree. Every case of this suite uses the
 *         same clock tree as the original standard-library test (PLL 180 MHz).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef  SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef   SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it (CLKFRQ above), so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Clock tree order: this is the order the chip requires, and the vendor
       test case uses the same one.
         1. Write the bus clock dividers while the system clock is still the
            power-on source (FIRC), so that the new divider values are already
            in place when the faster clock arrives. Writing them AFTER the
            switch instead leaves the buses at their reset dividers for a
            moment at the new core clock: at 180 MHz that is
            AXI4Bus3 = 90 MHz and APBBus0 = 45 MHz, right at their ratings, and
            the core does not survive it (measured on the board: the core
            trapped before the divider write was reached, so no output was
            produced at all).
         2. Program the EFLASH controller clock: the controller must already
            know the final frequency while the code still runs from the flash.
         3. Then configure the PLL and switch the system clock to it; this call
            also updates SystemCoreClock and re-initializes the HAL time base. */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Configure the GPIOC test pins.
 * @param  None
 * @retval None
 */
static void gpioc_Config(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    /* Enable the GPIOC clock gate */
    __HAL_SMU_GPIOC_CLK_ENABLE();

    /* Pins 13..15 are driven by the FlexBus interface out of reset: select the
       plain GPIO function for them, as the original test case does */
    HAL_GPIO_PinAFConfig(GPIOC, GPIO_PinSource13, GPIO_AF_Pin_x);
    HAL_GPIO_PinAFConfig(GPIOC, GPIO_PinSource14, GPIO_AF_Pin_x);
    HAL_GPIO_PinAFConfig(GPIOC, GPIO_PinSource15, GPIO_AF_Pin_x);

    /* Clear the structure and set the Size / Version metafields */
    __HAL_CLEAR_STRUCT(&GPIO_InitStruct);
    GPIO_InitStruct.Size    = sizeof(GPIO_InitStruct);
    GPIO_InitStruct.Version = GPIO_INIT_VERSION;

    /* Configure the test pins */
    GPIO_InitStruct.Pin          = TEST_PIN;
    GPIO_InitStruct.Mode         = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull         = GPIO_NOPULL;
    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    GPIO_InitStruct.Alternate    = GPIO_AF_Pin_x;

    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
}

/*****END OF FILE*****/
