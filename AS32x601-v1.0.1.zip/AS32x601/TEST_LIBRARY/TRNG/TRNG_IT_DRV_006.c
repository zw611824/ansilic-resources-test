/**
 * @file    TRNG_IT_DRV_006.c
 * @brief   HAL TRNG integration test case 006 (event semantics at register level (GLBL, W1C, ownership, aliases)).
 *
 * HAL library extension case (no reference standard-library counterpart).
 * Only HAL library APIs are used.
 *
 * Tested functionality:
 *   TRNG_IT_ALL / TRNG_EVENT_ALL / IS_TRNG_IT / IS_TRNG_FLAG
 *   __HAL_TRNG_ENABLE_IT / DISABLE_IT / GET_IT / GET_FLAG / CLEAR_IT
 *   HAL_TRNG_GetITStatus() / HAL_TRNG_ClearITPendingBit()
 *   HAL_TRNG_IRQHandler() / HAL_TRNG_GenerateRandomNumber_IT()
 *   HAL_TRNG_ReadyDataCallback() / HAL_TRNG_ErrorCallback()
 *
 * Test procedure:
 *   Walk the register level contract of the event register:
 *     A. the aggregate masks and the mask based checks;
 *     B. the exported macros agree with the driver API;
 *     C. the completion of a raw command is left to its owner, so the
 *        interrupt entry neither consumes nor publishes it;
 *     D. acknowledging a NON pending event must not disturb a pending one
 *        (a read-modify-write acknowledge would clear it as collateral);
 *     E. two different events pending at the same time, only the selected
 *        one is acknowledged;
 *     F. the interrupt generation enables IE.DONE together with IE.GLBL and
 *        its owned completion is consumed by the interrupt entry;
 *     G. the alarm path (cannot be provoked from software) and the weak
 *        error callback;
 *     H. the interrupt sources can be closed again in one call.
 *
 * Expected behaviour:
 *   ISTAT keeps every event that was not explicitly acknowledged, the
 *   normalised flag query answers SET for any pending bit, IE.DONE and
 *   IE.GLBL are both set by the interrupt generation, and
 *   "summary : failures = 0" is printed.
 *
 * Note:
 *   HAL extension case. ISTAT is a write-one-to-clear register, therefore
 *   an alarm cannot be fabricated from software (writing one clears it and
 *   only a health test failure raises it); the error callback is invoked
 *   once directly to prove that the weak symbol can be replaced.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
#define TEST_BAUDRATE                  (115200U)   /*!< console baud rate     */
#define TEST_STEP_TIMEOUT_MS           (1000U)     /*!< per step wait budget  */
#define TEST_ROUND_DELAY_MS            (2000U)     /*!< delay between rounds  */

/* Private variables ---------------------------------------------------------*/
static volatile uint32 check_failures = 0U;   /*!< failed check counter        */
static HAL_SMU_HandleTypeDef hsmu_clk;        /*!< SMU handle (clock tree)     */

/**
 * @brief  TRNG handle used by every case of this suite.
 * @note   The peripheral is a single instance, so one handle is enough; the
 *         lifecycle case uses additional local handles for the refusal paths.
 */
TRNG_HandleTypeDef htrng_dev;

/* MSP callback bookkeeping (written by the shared MSP callbacks) */
uint32 Trng_MspInitCount   = 0U;              /*!< HAL_TRNG_MspInit() calls    */
uint32 Trng_MspDeInitCount = 0U;              /*!< HAL_TRNG_MspDeInit() calls  */
uint32 Trng_MspStateAtInit = 0xFFFFFFFFU;     /*!< handle state seen in the MSP */
uint32 Trng_MspLockAtInit  = 0xFFFFFFFFU;     /*!< handle lock seen in the MSP  */

/* Shared helpers of this suite (defined at the end of this file) */
void Check(const char *name, uint32 condition);
void Summary(void);
void SystemClock_Init(void);
void Trng_ClockEnable(void);
void Trng_PlicEnable(uint8 priority);
HAL_StatusTypeDef Trng_WaitFlag(uint32 flag, uint32 timeout_ms);
HAL_StatusTypeDef Trng_Seed(uint32 timeout_ms);



/* Private variables ---------------------------------------------------------*/
static volatile uint32 ready_callbacks = 0U;   /*!< data ready callbacks       */
static volatile uint32 done_events     = 0U;   /*!< DONE events served         */
static volatile uint32 error_callbacks = 0U;   /*!< error callbacks            */

/* Private function prototypes -----------------------------------------------*/
static HAL_StatusTypeDef Trng_RawCommandAndWait(uint32 command, uint32 flag);

/**
 * @brief  TRNG interrupt entry (overrides the weak PLIC dispatch entry).
 * @note   The interrupt line is never enabled by this case; the entry is
 *         provided so that an unexpected request can never reach the fatal
 *         default handler, and so that the acknowledgement contract is
 *         documented in one place.
 * @param  None
 * @retval None
 */
void TRNG_IRQ_Handler(void)
{
    HAL_TRNG_IRQHandler(&htrng_dev);

    if (HAL_TRNG_GetITStatus(&htrng_dev, TRNG_FLAG_DONE) != RESET)
    {
        HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_DONE);
        done_events++;
    }
}

/**
 * @brief  Weak data ready callback of the driver (overridden for the check).
 * @param  htrng: TRNG handle
 * @param  random32bit: generated random number
 * @retval None
 */
void HAL_TRNG_ReadyDataCallback(TRNG_HandleTypeDef *htrng, uint32 random32bit)
{
    (void)htrng;
    (void)random32bit;

    ready_callbacks++;
}

/**
 * @brief  Weak error callback of the driver (overridden for the check).
 * @note   An alarm cannot be provoked from software (the ISTAT.ALARMS bit is
 *         write-one-to-clear and is only raised by a health test failure), so
 *         the callback is invoked once directly to prove that the weak symbol
 *         of the library can be replaced by the application.
 * @param  htrng: TRNG handle
 * @retval None
 */
void HAL_TRNG_ErrorCallback(TRNG_HandleTypeDef *htrng)
{
    (void)htrng;

    error_callbacks++;
}

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    TRNG_InitTypeDef  trng_init;
    HAL_StatusTypeDef status;
    uint32 background;
    uint32 before;
    uint32 after;
    uint32 round = 0U;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== TRNG_IT_DRV_006 : event semantics at register level ===\r\n");

    /* Handle preparation */
    __HAL_CLEAR_STRUCT(&htrng_dev);
    htrng_dev.Instance = TRNG;
    HAL_TRNG_StructInit(&trng_init);
    htrng_dev.Init = trng_init;

    status = HAL_TRNG_Init(&htrng_dev);
    Check("HAL_TRNG_Init() returns HAL_OK", (status == HAL_OK) ? 1U : 0U);

    /* ---- A. the event and interrupt source aliases of the header ---------- */
    Check("TRNG_IT_ALL covers the six interrupt enable bits",
          (TRNG_IT_ALL == 0x8000001FU) ? 1U : 0U);
    Check("TRNG_EVENT_ALL covers the five status bits and not the global gate",
          ((TRNG_EVENT_ALL == 0x0000001FU) && ((TRNG_EVENT_ALL & TRNG_IT_GLBL) == 0U)) ? 1U : 0U);
    Check("IS_TRNG_FLAG accepts the whole event aggregate",
          (IS_TRNG_FLAG(TRNG_EVENT_ALL) != 0U) ? 1U : 0U);
    Check("IS_TRNG_IT accepts a combination and refuses an empty mask",
          ((IS_TRNG_IT((uint32)(TRNG_IT_DONE | TRNG_IT_GLBL)) != 0U) &&
           (IS_TRNG_IT(0U) == 0U)) ? 1U : 0U);

    /* ---- B. the exported macros agree with the driver API ----------------- */
    __HAL_TRNG_ENABLE_IT(&htrng_dev, TRNG_IT_DONE);
    Check("__HAL_TRNG_ENABLE_IT sets the same bit as the driver API",
          ((TRNG->IE & TRNG_IT_DONE) != 0U) ? 1U : 0U);
    __HAL_TRNG_DISABLE_IT(&htrng_dev, TRNG_IT_DONE);
    Check("__HAL_TRNG_DISABLE_IT clears the bit that was set",
          ((TRNG->IE & TRNG_IT_DONE) == 0U) ? 1U : 0U);
    HAL_TRNG_ITConfig(&htrng_dev, TRNG_IT_DONE, ENABLE);
    Check("the driver API sets the same bit as the macro",
          ((TRNG->IE & TRNG_IT_DONE) != 0U) ? 1U : 0U);
    HAL_TRNG_ITConfig(&htrng_dev, TRNG_IT_DONE, DISABLE);
    Check("the driver API clears the bit again",
          ((TRNG->IE & TRNG_IT_DONE) == 0U) ? 1U : 0U);

    /* ---- C. the completion of a raw command is left to its owner ---------- */
    status = Trng_RawCommandAndWait(TRNG_COMMAND_GEN_NOISE, TRNG_FLAG_DONE);
    Check("a raw GEN_NOISE command completes", (status == HAL_OK) ? 1U : 0U);
    Check("__HAL_TRNG_GET_FLAG reports the pending completion",
          (__HAL_TRNG_GET_FLAG(&htrng_dev, TRNG_FLAG_DONE) != RESET) ? 1U : 0U);
    Check("__HAL_TRNG_GET_IT reports the pending completion",
          (__HAL_TRNG_GET_IT(&htrng_dev, TRNG_FLAG_DONE) != RESET) ? 1U : 0U);
    Check("HAL_TRNG_GetITStatus normalises the pending completion to SET",
          (HAL_TRNG_GetITStatus(&htrng_dev, TRNG_FLAG_DONE) == SET) ? 1U : 0U);
    Check("the masked query answers SET as well",
          (HAL_TRNG_GetITStatus(&htrng_dev, TRNG_EVENT_ALL) == SET) ? 1U : 0U);

    /* The handle is not BUSY (a raw command publishes no ownership), therefore
     * the interrupt entry must not consume the completion of the application */
    before = ready_callbacks;
    HAL_TRNG_IRQHandler(&htrng_dev);
    Check("the interrupt entry does not consume a completion it does not own",
          (HAL_TRNG_GetITStatus(&htrng_dev, TRNG_FLAG_DONE) == SET) ? 1U : 0U);
    Check("the interrupt entry publishes no data for an unowned completion",
          (ready_callbacks == before) ? 1U : 0U);

    /* ---- D. acknowledging one event must not disturb another ------------- */
    /* The event below is NOT pending: a read-modify-write acknowledgement
     * (STATUS |= mask) would write the pending DONE bit back as one and clear
     * it as collateral, while the single value write of the driver cannot. */
    before = TRNG->ISTAT;
    HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_KAT_COMPLETE);
    after = TRNG->ISTAT;
    Check("acknowledging a non pending event keeps the pending completion",
          ((before & TRNG_FLAG_DONE) != 0U) && (after == before) ? 1U : 0U);
    printf("ack test    : ISTAT 0x%08X -> 0x%08X\r\n", PRINT_U32(before), PRINT_U32(after));

    /* Same check through the two exported macros */
    before = TRNG->ISTAT;
    __HAL_TRNG_CLEAR_IT(&htrng_dev, TRNG_FLAG_KAT_COMPLETE);
    Check("the __HAL_TRNG_CLEAR_IT macro is a single value write as well",
          (TRNG->ISTAT == before) ? 1U : 0U);
    __HAL_TRNG_CLEAR_FLAG(&htrng_dev, TRNG_FLAG_NOISE_RDY);
    Check("the __HAL_TRNG_CLEAR_FLAG macro is a single value write as well",
          (TRNG->ISTAT == before) ? 1U : 0U);

    /* The pending completion is acknowledged by its owner (the application) */
    HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_DONE);
    Check("the owned completion is cleared by the application acknowledge",
          (HAL_TRNG_GetITStatus(&htrng_dev, TRNG_EVENT_ALL) == RESET) ? 1U : 0U);

    /* ---- E. two pending events, only the selected one is acknowledged ---- */
    before = TRNG->ISTAT;
    background = 0U;

    status = HAL_TRNG_SendCommand(&htrng_dev, TRNG_COMMAND_GEN_NOISE);
    if (status == HAL_OK)
    {
        status = Trng_WaitFlag(TRNG_FLAG_DONE, TEST_STEP_TIMEOUT_MS);
    }
    if (status == HAL_OK)
    {
        status = HAL_TRNG_SendCommand(&htrng_dev, TRNG_COMMAND_ZEROIZE);
    }
    if (status == HAL_OK)
    {
        status = Trng_WaitFlag(TRNG_FLAG_ZEROIZED, TEST_STEP_TIMEOUT_MS);
    }
    Check("two completions of different events can be pending at the same time",
          (status == HAL_OK) ? 1U : 0U);

    before = TRNG->ISTAT;
    background = before & TRNG_FLAG_DONE;
    HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_ZEROIZED);
    after = TRNG->ISTAT;
    Check("acknowledging ZEROIZED clears that bit",
          ((before & TRNG_FLAG_ZEROIZED) != 0U) && ((after & TRNG_FLAG_ZEROIZED) == 0U) ? 1U : 0U);
    if (background != 0U)
    {
        Check("acknowledging ZEROIZED keeps the pending DONE bit",
              ((after & TRNG_FLAG_DONE) != 0U) ? 1U : 0U);
    }
    else
    {
        printf("note         : the device cleared DONE when the ZEROIZE command was issued\r\n");
    }
    printf("two events   : ISTAT 0x%08X -> 0x%08X\r\n", PRINT_U32(before), PRINT_U32(after));

    HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_EVENT_ALL);
    Check("the event aggregate acknowledge leaves no pending event",
          ((TRNG->ISTAT & TRNG_EVENT_ALL) == 0U) ? 1U : 0U);

    /* ---- F0. rebuild the DRBG state ---------------------------------- */
    /* Section E issued a ZEROIZE command to make two events pending at the
     * same time. ZEROIZE zeroizes the DRBG, so a GEN_RANDOM issued on that
     * state reports an ALARMED health test failure (measured on the board:
     * ISTAT.ALARMED is set and the driver publishes no data by design).
     * Rebuild the state before the interrupt generation of section F. */
    status = Trng_Seed(TEST_STEP_TIMEOUT_MS);
    Check("the DRBG state is rebuilt after the ZEROIZE of section E",
          (status == HAL_OK) ? 1U : 0U);
    HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_EVENT_ALL);

    /* ---- F. the interrupt generation publishes IE.DONE and IE.GLBL -------- */
    /* The interrupt line stays closed: the completion is consumed by the
     * explicit call below, so the register state can be observed first. */
    HAL_TRNG_ITConfig(&htrng_dev, (uint32)(TRNG_IT_DONE | TRNG_IT_GLBL), DISABLE);

    status = HAL_TRNG_GenerateRandomNumber_IT(&htrng_dev);
    Check("HAL_TRNG_GenerateRandomNumber_IT() returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("the completion source is enabled together with the global gate",
          ((TRNG->IE & (TRNG_IT_DONE | TRNG_IT_GLBL)) == (TRNG_IT_DONE | TRNG_IT_GLBL)) ? 1U : 0U);
    Check("the handle publishes BUSY for the started generation",
          (HAL_TRNG_GetState(&htrng_dev) == HAL_TRNG_STATE_BUSY) ? 1U : 0U);

    before = ready_callbacks;
    HAL_TRNG_IRQHandler(&htrng_dev);
    Check("the owned completion is consumed by the interrupt entry",
          (HAL_TRNG_GetITStatus(&htrng_dev, TRNG_FLAG_DONE) == RESET) ? 1U : 0U);
    Check("the owned completion publishes READY",
          (HAL_TRNG_GetState(&htrng_dev) == HAL_TRNG_STATE_READY) ? 1U : 0U);
    Check("the owned completion publishes the data callback once",
          ((ready_callbacks - before) == 1U) ? 1U : 0U);
    Check("the global gate is left enabled for the next generation",
          ((TRNG->IE & TRNG_IT_GLBL) != 0U) ? 1U : 0U);

    /* ---- G. the alarm reporting path cannot be provoked from software ----- */
    Check("no alarm is reported on a healthy generator",
          (HAL_TRNG_GetITStatus(&htrng_dev, TRNG_FLAG_ALARMED) == RESET) ? 1U : 0U);
    Check("the error code carries no alarm and no timeout",
          ((HAL_TRNG_GetError(&htrng_dev) &
            (HAL_TRNG_ERROR_ALARMED | HAL_TRNG_ERROR_TIMEOUT)) == 0U) ? 1U : 0U);

    before = error_callbacks;
    HAL_TRNG_ErrorCallback(&htrng_dev);
    Check("the weak error callback can be replaced by the application",
          ((error_callbacks - before) == 1U) ? 1U : 0U);

    /* ---- H. the interrupt sources can be closed again --------------------- */
    HAL_TRNG_ITConfig(&htrng_dev, TRNG_IT_ALL, DISABLE);
    Check("the whole interrupt source aggregate can be closed in one call",
          ((TRNG->IE & TRNG_IT_ALL) == 0U) ? 1U : 0U);
    HAL_TRNG_ITConfig(&htrng_dev, TRNG_IT_DONE, ENABLE);
    HAL_TRNG_ITConfig(&htrng_dev, TRNG_IT_DONE, DISABLE);
    Check("a single source can be toggled without changing the others",
          ((TRNG->IE & TRNG_IT_ALL) == 0U) ? 1U : 0U);

    Summary();

    for (;;)
    {
        printf("alive %u : ISTAT=0x%08X IE=0x%08X\r\n", PRINT_U32(round),
               PRINT_U32(TRNG->ISTAT), PRINT_U32(TRNG->IE));
        round++;
        delay_ms(TEST_ROUND_DELAY_MS);
    }
}

/**
 * @brief  Send one raw command and wait for its completion event.
 * @param  command: TRNG_COMMAND_x
 * @param  flag: event that signals the completion (TRNG_FLAG_DONE / ZEROIZED)
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_TIMEOUT
 */
static HAL_StatusTypeDef Trng_RawCommandAndWait(uint32 command, uint32 flag)
{
    if (HAL_TRNG_SendCommand(&htrng_dev, command) != HAL_OK)
    {
        return HAL_ERROR;
    }

    return Trng_WaitFlag(flag, TEST_STEP_TIMEOUT_MS);
}

/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the other integration tests of this library:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2 and
 *         CANX2 by 8, which gives core 180 MHz and APB 22.5 MHz (the console
 *         USART is clocked from APBBus0). The TRNG sits on the AXILite4-Bus1
 *         bus, which is not divided by this tree.
 * @note   Clock tree order: the dividers are written while the system clock
 *         is still the power on source (FIRC), then the PLL is configured and
 *         the system clock is switched to it. That last call programs the
 *         flash controller clock before the switch (the core keeps fetching
 *         from the flash) and updates SystemCoreClock afterwards.
 * @param  None
 * @retval None
 */
void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks (console pins of USART0 on GPIOD) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Open the clock gate of the security domain and release its reset.
 * @note   The TRNG has no dedicated SMU gate: it is clocked and reset through
 *         the DSE (security engine) domain bits of SMU->ALB1CFGR, exactly like
 *         the reference test case does with its DSE_CLK_ENABLE / DSE_RESET /
 *         DSE_SET sequence. The HAL TRNG driver has no default MSP body, so
 *         this helper is what HAL_TRNG_MspInit() / the cases call.
 * @note   The gate is never closed again (not even by HAL_TRNG_MspDeInit):
 *         the DSE domain is shared with the other security peripherals, and a
 *         closed gate makes any later register access stall the bus.
 * @param  None
 * @retval None
 */
void Trng_ClockEnable(void)
{
    __HAL_SMU_DSE_CLK_ENABLE();
    __HAL_SMU_DSE_FORCE_RESET();
    __HAL_SMU_DSE_RELEASE_RESET();
}

/**
 * @brief  Enable the TRNG interrupt source in the PLIC.
 * @param  priority: source priority (1..63, larger = higher priority)
 * @retval None
 */
void Trng_PlicEnable(uint8 priority)
{
    PLIC_InitTypeDef plic_init;

    __HAL_CLEAR_STRUCT(&plic_init);
    plic_init.Size               = sizeof(plic_init);
    plic_init.Version            = PLIC_INIT_VERSION;
    plic_init.PLIC_IRQChannel    = TRNG_IRQn;
    plic_init.PLIC_IRQPriority   = priority;
    plic_init.PLIC_IRQChannelCmd = PLIC_ENABLE;
    (void)HAL_PLIC_Init(&plic_init);
}

/**
 * @brief  Wait (bounded) until one ISTAT event flag of the handle is set.
 * @note   The flag is not cleared here: the caller decides who acknowledges it
 *         (the driver for the completions it owns, the application for the
 *         events it enabled itself).
 * @param  flag: event mask (TRNG_FLAG_x or a combination)
 * @param  timeout_ms: timeout in milliseconds
 * @retval HAL_StatusTypeDef: HAL_OK when the flag was observed / HAL_TIMEOUT
 */
HAL_StatusTypeDef Trng_WaitFlag(uint32 flag, uint32 timeout_ms)
{
    uint32 tickstart = HAL_GetTick();

    while (HAL_TRNG_GetITStatus(&htrng_dev, flag) == RESET)
    {
        if ((HAL_GetTick() - tickstart) > timeout_ms)
        {
            return HAL_TIMEOUT;
        }
    }

    return HAL_OK;
}

/**
 * @brief  Run the DRBG startup sequence: ZEROIZE -> GEN_NOISE -> CREATE_STATE.
 * @note   This is the sequence the reference test case runs at the beginning of
 *         every round; it is factored out here because the cases that use the
 *         HAL generation interfaces only need the DRBG to be seeded once.
 * @param  timeout_ms: per step timeout in milliseconds
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (command refused) / HAL_TIMEOUT
 */
HAL_StatusTypeDef Trng_Seed(uint32 timeout_ms)
{
    if (HAL_TRNG_SendCommand(&htrng_dev, TRNG_COMMAND_ZEROIZE) != HAL_OK)
    {
        return HAL_ERROR;
    }
    if (Trng_WaitFlag(TRNG_FLAG_ZEROIZED, timeout_ms) != HAL_OK)
    {
        return HAL_TIMEOUT;
    }
    HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_ZEROIZED);
    HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_DONE);

    if (HAL_TRNG_SendCommand(&htrng_dev, TRNG_COMMAND_GEN_NOISE) != HAL_OK)
    {
        return HAL_ERROR;
    }
    if (Trng_WaitFlag(TRNG_FLAG_DONE, timeout_ms) != HAL_OK)
    {
        return HAL_TIMEOUT;
    }
    HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_DONE);

    if (HAL_TRNG_SendCommand(&htrng_dev, TRNG_COMMAND_CREATE_STATE) != HAL_OK)
    {
        return HAL_ERROR;
    }
    if (Trng_WaitFlag(TRNG_FLAG_DONE, timeout_ms) != HAL_OK)
    {
        return HAL_TIMEOUT;
    }
    HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_DONE);

    return HAL_OK;
}

/* MSP callbacks ------------------------------------------------------------*/

/**
 * @brief  Initialize the TRNG MSP (security domain clock gate and reset).
 * @note   The default implementation of the driver is empty, so the DSE domain
 *         is opened here (the TRNG has no gate of its own).
 * @note   The call is recorded so that the lifecycle case can verify the
 *         LOCK-06 / MSP-04 contract: the callback must run outside the handle
 *         lock and only on the first initialization (state RESET).
 * @param  htrng: TRNG handle
 * @retval None
 */
void HAL_TRNG_MspInit(TRNG_HandleTypeDef *htrng)
{
    Trng_MspInitCount++;
    Trng_MspStateAtInit = (uint32)htrng->State;
    Trng_MspLockAtInit  = (uint32)htrng->Lock;

    Trng_ClockEnable();
}

/**
 * @brief  De-initialize the TRNG MSP.
 * @note   The DSE clock gate is shared with the other security peripherals and
 *         is left open on purpose, so that a case may read the TRNG registers
 *         after a de-initialization without stalling the bus.
 * @param  htrng: TRNG handle
 * @retval None
 */
void HAL_TRNG_MspDeInit(TRNG_HandleTypeDef *htrng)
{
    Trng_MspDeInitCount++;

    (void)htrng;
}

/*****END OF FILE*****/
