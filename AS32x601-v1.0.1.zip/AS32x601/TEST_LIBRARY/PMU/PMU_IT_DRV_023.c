/**
 * @file    PMU_IT_DRV_023.c
 * @brief   HAL PMU integration test case 023 (full API self check).
 *
 * Extension case of the suite: it exercises every public PMU API and the
 * run-time behaviour the driver adds on top of the standard-library original
 * (handle state machine, resource lock, run-time parameter validation and
 * error reporting). It is a self checking case: every check prints PASS or
 * FAIL and the final summary counts the failures, so the case passes when
 * "summary : failures = 0" is printed.
 *
 * Tested functionality:
 *   HAL_PMU_Init() / HAL_PMU_DeInit() / HAL_PMU_MspInit() / HAL_PMU_MspDeInit()
 *   HAL_PMU_PowerModeConfig() / HAL_PMU_GetPowerModeStatus()
 *   HAL_PMU_WakeUpSourceCmd()
 *   HAL_PMU_LDO3v3Cmd() / HAL_PMU_LDO3v3BypassCmd() / HAL_PMU_LDO3v3VOLSca()
 *   HAL_PMU_LDO2v5Cmd() / HAL_PMU_LDO2v5VOLSca()
 *   HAL_PMU_LDO1v2Cmd() / HAL_PMU_LDO1v2VOLSca() / HAL_PMU_BLDO1v2VOLSca()
 *   HAL_PMU_Refer1v2Cmd() / HAL_PMU_Refer1v2VOLSca()
 *   HAL_PMU_LowVolResetCmd()
 *   HAL_PMU_HighVolDetectCmd() / HAL_PMU_HighVolDetectThresholdSca()
 *   HAL_PMU_LowVolDetectCmd() / HAL_PMU_LowVolDetectThresholdSca()
 *   HAL_PMU_RC16MCmd() / HAL_PMU_RC32KFrequencySca()
 *   HAL_PMU_GetFlagStatus() / HAL_PMU_GetWakeUpFlag() / HAL_PMU_ClearFlag()
 *   HAL_PMU_GetState() / HAL_PMU_GetError()
 *   PMU_LockHandle() / PMU_UnlockHandle() (shared lock helpers)
 *
 * Test procedure:
 *   1. Handle life cycle: a second initialization is accepted, the handle
 *      can be de-initialized and re-initialized, and the configuration APIs
 *      refuse to work on a handle that is not initialized;
 *   2. Scaling, oscillation and detector APIs: each value is written and read
 *      back from the register field;
 *   3. Wake-up sources and flags: every source is enabled and disabled in
 *      turn, the mask based helpers are used afterwards;
 *   4. Run-time parameter validation: out of range values are refused with
 *      HAL_PMU_ERROR_INVALID_PARAM and must leave the register untouched;
 *   5. Resource lock: the shared lock helpers refuse a second lock and the
 *      unlock releases it.
 *
 * Note on the voltage scaling groups: the case never lowers a rail that the
 * running system depends on. The 3.3 V LDO is only moved within the range
 * that keeps the IO supply at or above its default (the console USART and
 * the debug interface run on it), and the 1.2 V domain -- the core LDO and
 * the backup LDO -- is only ever moved upward from the trim the board boots
 * with, because the backup LDO sits on the same 1.2 V node as the core: its
 * lowest trim (PMU_VO12_1V04) under-volts the core and the device stops
 * responding. The sweeps that cover a whole field range are restricted to
 * what is really not used by the running system (2.5 V LDO, the HVD / LVD
 * thresholds and the RC32K trim), and every field is left at a safe value
 * when its group ends.
 *
 * Expected behaviour:
 *   - every check prints PASS and the summary stays at zero failures;
 *   - the case never enters a power mode (the power mode request is only
 *     tested through its parameter validation), so it can be run repeatedly.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Current (already scaled) rail values: the case restores these profiles */
#define TEST_VO33_SAFE              (PMU_VO33_3V30)   /* IO rail default       */
#define TEST_VO33_SAFE_HIGH         (PMU_VO33_3V35)   /* one step above default */
#define TEST_VO25_SWEEP_LAST        (PMU_VO25_2V78)   /* 2.5V LDO sweep end     */
#define TEST_VO12_SAFE              (PMU_VO12_1V34)   /* core LDO of this project */
#define TEST_BLDO12_SWEEP_LAST      (PMU_VO12_1V34)   /* backup LDO sweep end   */

/* Voltage detector thresholds used by the case */
#define TEST_HVDTS_LOW              (PMU_HVDTS_2V4)   /* lowest HVD threshold   */
#define TEST_HVDTS_DEFAULT          (PMU_HVDTS_5V5)   /* default HVD threshold  */
#define TEST_LVDTS_LOW              (PMU_LVDTS_2V4)   /* lowest LVD threshold   */
#define TEST_LVDTS_DEFAULT          (PMU_LVDTS_2V9)   /* default LVD threshold  */

/* RC32K scaling sweep range (OCR.RC32KFS is a 6 bit field) */
#define TEST_RC32KFS_LAST           (0x3FU)
#define TEST_RC32KFS_SAFE           (0x00U)

/* Out of range values used by the parameter validation group */
#define TEST_BAD_VOLTAGE            (0x10U)   /* voltage fields are 4 bit wide  */
#define TEST_BAD_THRESHOLD          (0x20U)   /* HVDTS / LVDTS are 5 bit wide   */
#define TEST_BAD_RC32KFS            (0x40U)   /* RC32KFS is 6 bit wide          */
#define TEST_BAD_WKSOURCE           (0x8000U) /* reserved bit of WKEN           */
#define TEST_BAD_CLEAR              (0x8000U) /* reserved bit of WKFR           */
#define TEST_BAD_FLAG               (0x000000FFU) /* not a PMU_FLAG_xxx value   */

/* Reporting period of the final loop (ms) */
#define TEST_POLL_MS                (1000U)

/* Private variables ---------------------------------------------------------*/
static HAL_PMU_HandleTypeDef hpmu_dev;      /*!< PMU device handle            */
static uint32                failures = 0U; /*!< failed checks                */
static uint32                checks = 0U;   /*!< executed checks              */

static HAL_SMU_HandleTypeDef hsmu_clk;   /*!< SMU handle (lock / state / error) */

/* Wake-up flag selectors and their clear values, in WKFR bit order */
static const uint32 wakeup_flags_mask[] =
{
    PMU_FLAG_IWDGWK, PMU_FLAG_RTCWK,
    PMU_FLAG_PH0WK,  PMU_FLAG_PH1WK, PMU_FLAG_PH2WK,  PMU_FLAG_PH3WK,
    PMU_FLAG_PH4WK,  PMU_FLAG_PH5WK, PMU_FLAG_PH6WK,  PMU_FLAG_PH7WK,
    PMU_FLAG_PH8WK,  PMU_FLAG_PH9WK,
    PMU_FLAG_FOCUR
};

static const uint32 wakeup_flags_clear[] =
{
    PMU_CLEAR_IWDGWKF, PMU_CLEAR_RTCWKF,
    PMU_CLEAR_PH0WKF,  PMU_CLEAR_PH1WKF, PMU_CLEAR_PH2WKF, PMU_CLEAR_PH3WKF,
    PMU_CLEAR_PH4WKF,  PMU_CLEAR_PH5WKF, PMU_CLEAR_PH6WKF, PMU_CLEAR_PH7WKF,
    PMU_CLEAR_PH8WKF,  PMU_CLEAR_PH9WKF,
    PMU_CLEAR_FOCURF
};

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void Section(const char *name);
static void Check(const char *name, uint32 condition);
static void GetLdoFields(uint32 *vo33, uint32 *vo25, uint32 *vo12, uint32 *vref,
                         uint32 *bldo);
static uint32 SweepField(__IO uint32 *reg, HAL_StatusTypeDef (*setter)(HAL_PMU_HandleTypeDef *, uint32),
                         uint32 fieldPos, uint32 fieldMsk, uint32 first, uint32 last);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    uint32 vo33;
    uint32 vo25;
    uint32 vo12;
    uint32 vref;
    uint32 bldo;
    uint32 vref_save;
    uint32 bldo_save;
    uint32 value;
    uint32 field;
    uint32 expected;
    uint32 i;
    uint32 state;
    static const uint32 wakeup_sources[] =
    {
        HAL_PMU_WKSOURCE_IWDG, HAL_PMU_WKSOURCE_RTC,
        HAL_PMU_WKSOURCE_PH0,  HAL_PMU_WKSOURCE_PH1,
        HAL_PMU_WKSOURCE_PH2,  HAL_PMU_WKSOURCE_PH3,
        HAL_PMU_WKSOURCE_PH4,  HAL_PMU_WKSOURCE_PH5,
        HAL_PMU_WKSOURCE_PH6,  HAL_PMU_WKSOURCE_PH7,
        HAL_PMU_WKSOURCE_PH8,  HAL_PMU_WKSOURCE_PH9
    };

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL, 45 MHz core clock) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n\r\n==== PMU_IT_DRV_023: full API self check ====\r\n");
    printf("Data : %s\r\n", __DATE__);
    printf("Time : %s\r\n", __TIME__);

    /* ==================================================================== *
     *  Group 1: handle life cycle and the initialization state gate
     * ==================================================================== */
    Section("Group 1: handle life cycle / state gate");

    /* an uninitialized handle is refused by the configuration APIs: the
     * state gate reports through the return value and leaves the state in
     * RESET, so the request is rejected before any register is touched */
    __HAL_CLEAR_STRUCT(&hpmu_dev);
    hpmu_dev.Instance = PMU;
    Check("configuration refused before Init",
          (HAL_PMU_LDO1v2VOLSca(&hpmu_dev, TEST_VO12_SAFE) == HAL_ERROR));
    Check("state still RESET after the refused call",
          (HAL_PMU_GetState(&hpmu_dev) == HAL_PMU_STATE_RESET));

    /* first initialization (the DELAY module and the console are up already) */
    Check("PMU init", (HAL_PMU_Init(&hpmu_dev) == HAL_OK));
    Check("state READY after Init", (HAL_PMU_GetState(&hpmu_dev) == HAL_PMU_STATE_READY));
    Check("error code clear after Init", (HAL_PMU_GetError(&hpmu_dev) == HAL_PMU_ERROR_NONE));

    /* a second initialization of an initialized handle is accepted (it re-runs
     * the low level initialization only when the state is RESET) */
    Check("second Init accepted", (HAL_PMU_Init(&hpmu_dev) == HAL_OK));
    Check("state READY after the second Init",
          (HAL_PMU_GetState(&hpmu_dev) == HAL_PMU_STATE_READY));

    /* de-initialization returns the handle to RESET without touching the
     * registers (the PMU LDOs keep running, which is what the board needs) */
    Check("DeInit accepted", (HAL_PMU_DeInit(&hpmu_dev) == HAL_OK));
    Check("state RESET after DeInit",
          (HAL_PMU_GetState(&hpmu_dev) == HAL_PMU_STATE_RESET));
    Check("configuration refused after DeInit",
          (HAL_PMU_LDO1v2VOLSca(&hpmu_dev, TEST_VO12_SAFE) == HAL_ERROR));
    Check("re-Init accepted after DeInit", (HAL_PMU_Init(&hpmu_dev) == HAL_OK));

    /* NULL handle protection: every public API refuses a NULL handle through
     * PMU_HandleIsValid(). The lock helpers are deliberately not checked here:
     * their empty-pointer guard is on the RTOS mutex (USE_RTOS == 1) only, the
     * bare-metal branch uses the Lock flag of the handle and does not validate
     * the handle pointer at all (same shape in every module of this library,
     * see WWDG-REQ-033 / RTC-REQ-039 / TRNG-REQ-041) */
    Check("NULL handle refused (configuration API)",
          (HAL_PMU_LDO1v2VOLSca(NULL_PTR, TEST_VO12_SAFE) == HAL_ERROR));
    Check("NULL handle state = RESET", (HAL_PMU_GetState(NULL_PTR) == HAL_PMU_STATE_RESET));
    Check("NULL handle error = NONE", (HAL_PMU_GetError(NULL_PTR) == HAL_PMU_ERROR_NONE));
    Check("NULL handle flag = 0", (HAL_PMU_GetFlagStatus(NULL_PTR, PMU_FLAG_IWDGWK) == 0U));
    Check("NULL handle power mode = INIT",
          (HAL_PMU_GetPowerModeStatus(NULL_PTR) == HAL_PMU_POWERMODE_INIT));

    /* ==================================================================== *
     *  Group 2: 3.3 V LDO (enable / bypass / scaling)
     * ==================================================================== */
    Section("Group 2: 3.3V LDO");

    Check("LDO3v3 enable", (HAL_PMU_LDO3v3Cmd(&hpmu_dev, ENABLE) == HAL_OK));
    Check("LDOCR.3V3LDOEN set",
          ((hpmu_dev.Instance->LDOCR & PMU_LDOCR_3V3LDOEN) != 0U));

    Check("LDO3v3 bypass enable",
          (HAL_PMU_LDO3v3BypassCmd(&hpmu_dev, ENABLE) == HAL_OK));
    Check("LDOCR.3V3LDOBYP set",
          ((hpmu_dev.Instance->LDOCR & PMU_LDOCR_3V3LDOBYP) != 0U));
    Check("LDO3v3 bypass disable",
          (HAL_PMU_LDO3v3BypassCmd(&hpmu_dev, DISABLE) == HAL_OK));
    Check("LDOCR.3V3LDOBYP cleared",
          ((hpmu_dev.Instance->LDOCR & PMU_LDOCR_3V3LDOBYP) == 0U));

    /* the IO rail stays at or above the default 3.30 V, so the console and
     * the debug interface keep working whatever the current board setup is */
    Check("LDO3v3 scale to 3.30V",
          (HAL_PMU_LDO3v3VOLSca(&hpmu_dev, TEST_VO33_SAFE) == HAL_OK));
    Check("LDO3v3 scale to 3.35V",
          (HAL_PMU_LDO3v3VOLSca(&hpmu_dev, TEST_VO33_SAFE_HIGH) == HAL_OK));
    Check("LDO3v3 scale to 3.65V",
          (HAL_PMU_LDO3v3VOLSca(&hpmu_dev, PMU_VO33_3V65) == HAL_OK));
    Check("LDO3v3 restored to 3.30V",
          (HAL_PMU_LDO3v3VOLSca(&hpmu_dev, TEST_VO33_SAFE) == HAL_OK));

    GetLdoFields(&vo33, &vo25, &vo12, &vref, &bldo);
    printf("LDOCR = 0x%08X (3V3 = %u, 2V5 = %u, 1V2 = %u, VREF = %u, BLDO = %u)\r\n",
           PRINT_U32(hpmu_dev.Instance->LDOCR), PRINT_U32(vo33), PRINT_U32(vo25),
           PRINT_U32(vo12), PRINT_U32(vref), PRINT_U32(bldo));
    Check("3V3 scaling read-back", (vo33 == (uint32)TEST_VO33_SAFE));

    /* ==================================================================== *
     *  Group 3: 2.5 V LDO (enable / scaling sweep)
     * ==================================================================== */
    Section("Group 3: 2.5V LDO");

    Check("LDO2v5 enable", (HAL_PMU_LDO2v5Cmd(&hpmu_dev, ENABLE) == HAL_OK));
    Check("LDOCR.2V5LDOEN set",
          ((hpmu_dev.Instance->LDOCR & PMU_LDOCR_2V5LDOEN) != 0U));

    /* the 2.5 V rail is not used by the running system, so its whole defined
     * scaling range is swept (each step is written and read back). The sweep
     * starts at PMU_VO25_2V22: the field code 0 is not a defined 2.5 V value */
    value = SweepField(&hpmu_dev.Instance->LDOCR, HAL_PMU_LDO2v5VOLSca,
                       PMU_LDOCR_2V5LDOVOS_Pos,
                       PMU_LDOCR_2V5LDOVOS_Msk, PMU_VO25_2V22, TEST_VO25_SWEEP_LAST);
    Check("LDO2v5 scaling sweep (2.22V..2.78V)",
          (value == (uint32)TEST_VO25_SWEEP_LAST));

    Check("LDO2v5 restore default",
          (HAL_PMU_LDO2v5VOLSca(&hpmu_dev, PMU_VO25_2V78) == HAL_OK));
    Check("LDO2v5 disable", (HAL_PMU_LDO2v5Cmd(&hpmu_dev, DISABLE) == HAL_OK));
    Check("LDOCR.2V5LDOEN cleared",
          ((hpmu_dev.Instance->LDOCR & PMU_LDOCR_2V5LDOEN) == 0U));

    /* ==================================================================== *
     *  Group 4: 1.2 V core LDO and 1.2 V backup LDO
     * ==================================================================== */
    Section("Group 4: 1.2V core / backup LDO");

    Check("LDO1v2 enable", (HAL_PMU_LDO1v2Cmd(&hpmu_dev, ENABLE) == HAL_OK));
    Check("LDOCR.1V2LDOEN set",
          ((hpmu_dev.Instance->LDOCR & PMU_LDOCR_1V2LDOEN) != 0U));

    /* the core rail is already scaled to 1.34 V by the system clock setup of
     * this project: the case re-writes that same value (a lower value would
     * under-voltage the core) and verifies the field read-back */
    Check("LDO1v2 keep the core profile",
          (HAL_PMU_LDO1v2VOLSca(&hpmu_dev, TEST_VO12_SAFE) == HAL_OK));
    GetLdoFields(&vo33, &vo25, &vo12, &vref, &bldo);
    Check("1V2 core scaling read-back", (vo12 == (uint32)TEST_VO12_SAFE));

    /* the backup LDO sits on the same 1.2 V node as the core, so the field
     * must never be swept downward: it is moved from the trim the board boots
     * with up to the top of the range and then restored (writing the lowest
     * trim, PMU_VO12_1V04, under-volts the core and the device stops) */
    bldo_save = bldo;
    value = SweepField(&hpmu_dev.Instance->LDOCR, HAL_PMU_BLDO1v2VOLSca,
                       PMU_LDOCR_1V2BLDOVOS_Pos,
                       PMU_LDOCR_1V2BLDOVOS_Msk, bldo_save, TEST_BLDO12_SWEEP_LAST);
    Check("BLDO1v2 sweep from the current trim up to 1.34V",
          (value == (uint32)TEST_BLDO12_SWEEP_LAST));
    Check("BLDO1v2 restored to the current trim",
          (HAL_PMU_BLDO1v2VOLSca(&hpmu_dev, bldo_save) == HAL_OK));

    /* ==================================================================== *
     *  Group 5: 1.2 V flash reference
     * ==================================================================== */
    Section("Group 5: 1.2V reference");

    Check("Refer1v2 enable", (HAL_PMU_Refer1v2Cmd(&hpmu_dev, ENABLE) == HAL_OK));
    Check("LDOCR.1V2VREFEN set",
          ((hpmu_dev.Instance->LDOCR & PMU_LDOCR_1V2VREFEN) != 0U));

    /* the flash reference trim belongs to the board and not to this case: it
     * is written back with the value that was read, never with a lower one */
    GetLdoFields(&vo33, &vo25, &vo12, &vref, &bldo);
    vref_save = vref;
    Check("Refer1v2 keep the current profile",
          (HAL_PMU_Refer1v2VOLSca(&hpmu_dev, vref_save) == HAL_OK));
    GetLdoFields(&vo33, &vo25, &vo12, &vref, &bldo);
    Check("1V2 reference scaling read-back", (vref == vref_save));

    /* ==================================================================== *
     *  Group 6: voltage detectors (LVR / HVD / LVD)
     * ==================================================================== */
    Section("Group 6: voltage detectors");

    Check("low voltage reset enable",
          (HAL_PMU_LowVolResetCmd(&hpmu_dev, ENABLE) == HAL_OK));
    Check("VDCR.LVREN set", ((hpmu_dev.Instance->VDCR & PMU_VDCR_LVREN) != 0U));
    Check("low voltage reset disable",
          (HAL_PMU_LowVolResetCmd(&hpmu_dev, DISABLE) == HAL_OK));
    Check("VDCR.LVREN cleared", ((hpmu_dev.Instance->VDCR & PMU_VDCR_LVREN) == 0U));

    /* HVD threshold sweep: the detector itself stays disabled, so the sweep
     * only exercises the scaling field */
    value = SweepField(&hpmu_dev.Instance->VDCR, HAL_PMU_HighVolDetectThresholdSca,
                       PMU_VDCR_HVDTS_Pos, PMU_VDCR_HVDTS_Msk,
                       TEST_HVDTS_LOW, PMU_HVDTS_5V5);
    Check("HVD threshold sweep (32 steps)", (value == (uint32)PMU_HVDTS_5V5));

    Check("HVD threshold restore default",
          (HAL_PMU_HighVolDetectThresholdSca(&hpmu_dev, TEST_HVDTS_DEFAULT) == HAL_OK));
    Check("HVD enable", (HAL_PMU_HighVolDetectCmd(&hpmu_dev, ENABLE) == HAL_OK));
    Check("VDCR.HVDEN set", ((hpmu_dev.Instance->VDCR & PMU_VDCR_HVDEN) != 0U));
    Check("HVD disable", (HAL_PMU_HighVolDetectCmd(&hpmu_dev, DISABLE) == HAL_OK));
    Check("VDCR.HVDEN cleared", ((hpmu_dev.Instance->VDCR & PMU_VDCR_HVDEN) == 0U));

    /* LVD threshold sweep (detector disabled as well) */
    value = SweepField(&hpmu_dev.Instance->VDCR, HAL_PMU_LowVolDetectThresholdSca,
                       PMU_VDCR_LVDTS_Pos, PMU_VDCR_LVDTS_Msk,
                       TEST_LVDTS_LOW, PMU_LVDTS_5V5);
    Check("LVD threshold sweep (32 steps)", (value == (uint32)PMU_LVDTS_5V5));

    /* the lowest threshold (2.4 V) is far below the 3.3 V supply of this
     * board, so enabling the detector for a moment cannot trigger a reset */
    Check("LVD threshold to the lowest value",
          (HAL_PMU_LowVolDetectThresholdSca(&hpmu_dev, TEST_LVDTS_LOW) == HAL_OK));
    Check("LVD enable", (HAL_PMU_LowVolDetectCmd(&hpmu_dev, ENABLE) == HAL_OK));
    Check("VDCR.LVDEN set", ((hpmu_dev.Instance->VDCR & PMU_VDCR_LVDEN) != 0U));
    Check("LVD disable", (HAL_PMU_LowVolDetectCmd(&hpmu_dev, DISABLE) == HAL_OK));
    Check("VDCR.LVDEN cleared", ((hpmu_dev.Instance->VDCR & PMU_VDCR_LVDEN) == 0U));
    Check("LVD threshold restore default",
          (HAL_PMU_LowVolDetectThresholdSca(&hpmu_dev, TEST_LVDTS_DEFAULT) == HAL_OK));

    /* ==================================================================== *
     *  Group 7: RC oscillators (RC16M / RC32K)
     * ==================================================================== */
    Section("Group 7: RC oscillators");

    Check("RC16M enable", (HAL_PMU_RC16MCmd(&hpmu_dev, ENABLE) == HAL_OK));
    Check("OCR.IRC16MEN set", ((hpmu_dev.Instance->OCR & PMU_OCR_IRC16MEN) != 0U));
    Check("RC16M disable", (HAL_PMU_RC16MCmd(&hpmu_dev, DISABLE) == HAL_OK));
    Check("OCR.IRC16MEN cleared", ((hpmu_dev.Instance->OCR & PMU_OCR_IRC16MEN) == 0U));

    /* the RC32K scaling is a 6 bit field: the whole range is swept */
    value = SweepField(&hpmu_dev.Instance->OCR, HAL_PMU_RC32KFrequencySca,
                       PMU_OCR_RC32KFS_Pos, PMU_OCR_RC32KFS_Msk,
                       TEST_RC32KFS_SAFE, TEST_RC32KFS_LAST);
    Check("RC32K scaling sweep (64 steps)", (value == (uint32)TEST_RC32KFS_LAST));
    Check("RC32K scaling restore",
          (HAL_PMU_RC32KFrequencySca(&hpmu_dev, TEST_RC32KFS_SAFE) == HAL_OK));

    /* ==================================================================== *
     *  Group 8: wake-up sources
     * ==================================================================== */
    Section("Group 8: wake-up sources");

    /* every source is enabled and disabled in turn, verifying the WKEN bit */
    for (i = 0U; i < (uint32)(sizeof(wakeup_sources) / sizeof(wakeup_sources[0])); i++)
    {
        field = 1U;

        if (HAL_PMU_WakeUpSourceCmd(&hpmu_dev, wakeup_sources[i], ENABLE) != HAL_OK)
        {
            field = 0U;
        }
        if ((hpmu_dev.Instance->WKEN & wakeup_sources[i]) == 0U)
        {
            field = 0U;
        }
        if (HAL_PMU_WakeUpSourceCmd(&hpmu_dev, wakeup_sources[i], DISABLE) != HAL_OK)
        {
            field = 0U;
        }
        if ((hpmu_dev.Instance->WKEN & wakeup_sources[i]) != 0U)
        {
            field = 0U;
        }

        Check("wake-up source enable/disable round trip", field);
    }
    Check("all wake-up sources at once",
          (HAL_PMU_WakeUpSourceCmd(&hpmu_dev, PMU_WKSOURCE_ALL, ENABLE) == HAL_OK));
    Check("WKEN = PMU_WKSOURCE_ALL",
          ((hpmu_dev.Instance->WKEN & PMU_WKSOURCE_ALL) == PMU_WKSOURCE_ALL));
    Check("wake-up sources cleared again",
          (HAL_PMU_WakeUpSourceCmd(&hpmu_dev, PMU_WKSOURCE_ALL, DISABLE) == HAL_OK));
    Check("WKEN cleared",
          ((hpmu_dev.Instance->WKEN & PMU_WKSOURCE_ALL) == 0U));

    /* ==================================================================== *
     *  Group 9: flags (status / mask query / clear)
     * ==================================================================== */
    Section("Group 9: flags");

    printf("ready flags: 3V3 = %u, 2V5 = %u, 1V2 = %u, 1V2B = %u\r\n",
           PRINT_U32(HAL_PMU_GetFlagStatus(&hpmu_dev, PMU_FLAG_3V3LDORDY)),
           PRINT_U32(HAL_PMU_GetFlagStatus(&hpmu_dev, PMU_FLAG_2V5LDORDY)),
           PRINT_U32(HAL_PMU_GetFlagStatus(&hpmu_dev, PMU_FLAG_1V2LDORDY)),
           PRINT_U32(HAL_PMU_GetFlagStatus(&hpmu_dev, PMU_FLAG_1V2BLDORDY)));

    /* the wake-up flags are read one by one and then in a single mask query;
     * both must agree with the WKFR register */
    field = 1U;
    for (i = 0U; i < (uint32)(sizeof(wakeup_flags_mask) / sizeof(wakeup_flags_mask[0])); i++)
    {
        value    = HAL_PMU_GetFlagStatus(&hpmu_dev, wakeup_flags_mask[i]);
        expected = ((hpmu_dev.Instance->WKFR & wakeup_flags_clear[i]) != 0U) ? 1U : 0U;

        if (value != expected)
        {
            field = 0U;
            printf("flag %u read %u, WKFR says %u\r\n", PRINT_U32(i), PRINT_U32(value),
                   PRINT_U32(expected));
        }
    }
    Check("flag read-back matches WKFR (13 flags)", field);

    /* HAL_PMU_GetWakeUpFlag() answers the OR of the selected flags, not the
     * mask itself: it reports 1 when at least one of the selected wake-up
     * flags is set (the reservation of the value 0 for "no status" is what
     * makes the mask family usable for a single observation window) */
    value = HAL_PMU_GetWakeUpFlag(&hpmu_dev, PMU_CLEAR_ALL);
    printf("GetWakeUpFlag(PMU_CLEAR_ALL) = %u, WKFR = 0x%X\r\n",
           PRINT_U32(value), PRINT_U32(hpmu_dev.Instance->WKFR));
    Check("mask query is the OR of the selected flags",
          (value == (((hpmu_dev.Instance->WKFR & PMU_CLEAR_ALL) != 0U) ? 1U : 0U)));
    Check("single flag mask query",
          (HAL_PMU_GetWakeUpFlag(&hpmu_dev, PMU_CLEAR_IWDGWKF) ==
           (((hpmu_dev.Instance->WKFR & PMU_CLEAR_IWDGWKF) != 0U) ? 1U : 0U)));

    Check("clear all wake-up flags",
          (HAL_PMU_ClearFlag(&hpmu_dev, PMU_CLEAR_ALL) == HAL_OK));
    Check("WKFR cleared", (hpmu_dev.Instance->WKFR == 0U));
    Check("mask query reads 0 after the clear",
          (HAL_PMU_GetWakeUpFlag(&hpmu_dev, PMU_CLEAR_ALL) == 0U));

    /* ==================================================================== *
     *  Group 10: power mode status and parameter validation
     * ==================================================================== */
    Section("Group 10: power mode / parameter validation");

    /* PMCR.POWMC is the field that *requests* a power mode: selecting SLEEP or
     * DEEPSLEEP enters the mode right away (no WFI is needed, see the sleep /
     * deep sleep cases of the suite), so the field reports the last requested
     * mode and not "the core is running". This case never requests a mode, so
     * the decoded status is compared with the field itself and with the value
     * range of the enumeration instead of being forced to NORMAL */
    state = (uint32)HAL_PMU_GetPowerModeStatus(&hpmu_dev);
    printf("PMCR = 0x%X (power mode status = %u)\r\n",
           PRINT_U32(hpmu_dev.Instance->PMCR), PRINT_U32(state));
    Check("power mode status decodes PMCR.POWMC",
          (state == (uint32)((hpmu_dev.Instance->PMCR & PMU_PMCR_POWMC_Msk) >>
                             PMU_PMCR_POWMC_Pos)));
    Check("power mode status is a defined code",
          (state <= (uint32)HAL_PMU_POWERMODE_NORMAL));

    /* NORMAL is a status code and not a selectable mode, so a request for it is
     * refused with INVALID_PARAM and must leave PMCR untouched */
    value = hpmu_dev.Instance->PMCR;
    Check("invalid power mode refused",
          (HAL_PMU_PowerModeConfig(&hpmu_dev, HAL_PMU_POWERMODE_NORMAL) == HAL_ERROR));
    Check("PMCR untouched by the refused request",
          (hpmu_dev.Instance->PMCR == value));
    Check("error code = INVALID_PARAM",
          (HAL_PMU_GetError(&hpmu_dev) == HAL_PMU_ERROR_INVALID_PARAM));

    /* out of range values of every scaling / mask field */
    value = hpmu_dev.Instance->LDOCR;
    Check("3V3 scaling out of range refused",
          (HAL_PMU_LDO3v3VOLSca(&hpmu_dev, TEST_BAD_VOLTAGE) == HAL_ERROR));
    Check("2V5 scaling out of range refused",
          (HAL_PMU_LDO2v5VOLSca(&hpmu_dev, TEST_BAD_VOLTAGE) == HAL_ERROR));
    Check("1V2 scaling out of range refused",
          (HAL_PMU_LDO1v2VOLSca(&hpmu_dev, TEST_BAD_VOLTAGE) == HAL_ERROR));
    Check("BLDO scaling out of range refused",
          (HAL_PMU_BLDO1v2VOLSca(&hpmu_dev, TEST_BAD_VOLTAGE) == HAL_ERROR));
    Check("reference scaling out of range refused",
          (HAL_PMU_Refer1v2VOLSca(&hpmu_dev, TEST_BAD_VOLTAGE) == HAL_ERROR));
    Check("LDOCR untouched by the refused requests",
          (hpmu_dev.Instance->LDOCR == value));

    value = hpmu_dev.Instance->VDCR;
    Check("HVD threshold out of range refused",
          (HAL_PMU_HighVolDetectThresholdSca(&hpmu_dev, TEST_BAD_THRESHOLD) == HAL_ERROR));
    Check("LVD threshold out of range refused",
          (HAL_PMU_LowVolDetectThresholdSca(&hpmu_dev, TEST_BAD_THRESHOLD) == HAL_ERROR));
    Check("VDCR untouched by the refused requests",
          (hpmu_dev.Instance->VDCR == value));

    value = hpmu_dev.Instance->OCR;
    Check("RC32K scaling out of range refused",
          (HAL_PMU_RC32KFrequencySca(&hpmu_dev, TEST_BAD_RC32KFS) == HAL_ERROR));
    Check("OCR untouched by the refused request",
          (hpmu_dev.Instance->OCR == value));

    value = hpmu_dev.Instance->WKEN;
    Check("reserved wake-up source bit refused",
          (HAL_PMU_WakeUpSourceCmd(&hpmu_dev, TEST_BAD_WKSOURCE, ENABLE) == HAL_ERROR));
    Check("zero wake-up source mask refused",
          (HAL_PMU_WakeUpSourceCmd(&hpmu_dev, 0U, ENABLE) == HAL_ERROR));
    Check("WKEN untouched by the refused requests",
          (hpmu_dev.Instance->WKEN == value));

    Check("reserved flag selector refused",
          (HAL_PMU_ClearFlag(&hpmu_dev, TEST_BAD_CLEAR) == HAL_ERROR));
    Check("unknown flag selector reads 0",
          (HAL_PMU_GetFlagStatus(&hpmu_dev, TEST_BAD_FLAG) == 0U));
    Check("unknown mask query reads 0",
          (HAL_PMU_GetWakeUpFlag(&hpmu_dev, TEST_BAD_CLEAR) == 0U));

    /* ==================================================================== *
     *  Group 11: resource lock helpers
     * ==================================================================== */
    Section("Group 11: resource lock");

    Check("lock acquired", (PMU_LockHandle(&hpmu_dev, HAL_MAX_DELAY) == HAL_OK));
    Check("second lock refused (bare metal Lock flag)",
          (PMU_LockHandle(&hpmu_dev, 1U) == HAL_BUSY));
    PMU_UnlockHandle(&hpmu_dev);
    Check("lock acquired again after the unlock",
          (PMU_LockHandle(&hpmu_dev, HAL_MAX_DELAY) == HAL_OK));
    PMU_UnlockHandle(&hpmu_dev);

    /* a configuration API must still work with the lock released */
    Check("configuration API works after the lock cycle",
          (HAL_PMU_LDO3v3VOLSca(&hpmu_dev, TEST_VO33_SAFE) == HAL_OK));

    /* ==================================================================== *
     *  Group 12: module version and error code constants
     * ==================================================================== */
    Section("Group 12: version / error codes");

    printf("module version = 0x%08X\r\n", PRINT_U32(__HAL_PMU_MODULE_VERSION));
    Check("module version = 0x0100", (__HAL_PMU_MODULE_VERSION == 0x0100U));
    Check("error code NONE = 0", (HAL_PMU_ERROR_NONE == 0U));
    Check("error code INVALID_PARAM = 1", (HAL_PMU_ERROR_INVALID_PARAM == 1U));

    /* ==================================================================== *
     *  Final report
     * ==================================================================== */
    printf("\r\nfinal : checks = %u, failures = %u\r\n",
           PRINT_U32(checks), PRINT_U32(failures));

    while (1)
    {
        printf("LDOCR = 0x%08X | VDCR = 0x%08X | OCR = 0x%08X | PMCR = 0x%X | checks = %u | summary : failures = %u\r\n",
               PRINT_U32(hpmu_dev.Instance->LDOCR),
               PRINT_U32(hpmu_dev.Instance->VDCR),
               PRINT_U32(hpmu_dev.Instance->OCR),
               PRINT_U32(HAL_PMU_GetPowerModeStatus(&hpmu_dev)),
               PRINT_U32(checks), PRINT_U32(failures));
        delay_ms(TEST_POLL_MS);
    }
}

/**
 * @brief  Print the header of a test group.
 * @param  name: group name.
 * @retval None
 */
static void Section(const char *name)
{
    printf("\r\n-- %s --\r\n", name);
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    checks++;

    if (condition == 0U)
    {
        failures++;
    }
    printf("%-52s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Read the five voltage scaling fields of LDOCR.
 * @param  vo33: 3.3 V LDO scaling field.
 * @param  vo25: 2.5 V LDO scaling field.
 * @param  vo12: 1.2 V core LDO scaling field.
 * @param  vref: 1.2 V reference scaling field.
 * @param  bldo: 1.2 V backup LDO scaling field.
 * @retval None
 */
static void GetLdoFields(uint32 *vo33, uint32 *vo25, uint32 *vo12, uint32 *vref,
                         uint32 *bldo)
{
    uint32 reg;

    reg = hpmu_dev.Instance->LDOCR;

    *vo33 = (reg & PMU_LDOCR_3V3LDOVOS_Msk) >> PMU_LDOCR_3V3LDOVOS_Pos;
    *vo25 = (reg & PMU_LDOCR_2V5LDOVOS_Msk) >> PMU_LDOCR_2V5LDOVOS_Pos;
    *vo12 = (reg & PMU_LDOCR_1V2LDOVOS_Msk) >> PMU_LDOCR_1V2LDOVOS_Pos;
    *vref = (reg & PMU_LDOCR_1V2VREFS_Msk) >> PMU_LDOCR_1V2VREFS_Pos;
    *bldo = (reg & PMU_LDOCR_1V2BLDOVOS_Msk) >> PMU_LDOCR_1V2BLDOVOS_Pos;
}

/**
 * @brief  Write a scaling field with every value of its range an read it back.
 * @note   The loop index is the PMU_VOxx / PMU_xxxTS / RC32KFS value itself:
 *         the scaling setters shift it into their own field, so the same
 *         helper works for the 4 bit voltage fields, the 5 bit detector
 *         thresholds and the 6 bit RC32K field. Reading the field back with
 *         its mask also proves that the setter updated the right position.
 * @param  reg: address of the register that holds the field.
 * @param  setter: scaling API of the field.
 * @param  fieldPos: bit position of the field.
 * @param  fieldMsk: mask of the field.
 * @param  first: lowest value of the range. A rail the running system depends
 *         on is never swept below the trim it boots with, so the caller passes
 *         that trim here instead of 0.
 * @param  last: highest value of the range.
 * @retval uint32: the value the last iteration left in the field (0 on error).
 */
static uint32 SweepField(__IO uint32 *reg, HAL_StatusTypeDef (*setter)(HAL_PMU_HandleTypeDef *, uint32),
                         uint32 fieldPos, uint32 fieldMsk, uint32 first, uint32 last)
{
    uint32 i;
    uint32 readBack;
    uint32 result;

    result = 0U;

    for (i = first; i <= last; i++)
    {
        if (setter(&hpmu_dev, i) != HAL_OK)
        {
            return 0U;
        }

        readBack = ((*reg) & fieldMsk) >> fieldPos;
        if (readBack != i)
        {
            return 0U;
        }

        result = readBack;
    }

    return result;
}

/**
 * @brief  Configure the system clock tree using the HAL SMU driver.
 * @note   Clock tree shared by every integration test suite of this library:
 *         OSC 20 MHz as the PLL source, PLLDivR = 0x04 / PLLDivN = 0x14 /
 *         PLLDivF = 0xB4 / PLLDivQ = 0x01 -> 45 MHz core clock, then
 *         AXI4Bus3 = /2, APBBus0 = /2, APBBus1 = /2 and CANX2 = /8.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Bus dividers, then the system clock source is the PLL as requested */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
