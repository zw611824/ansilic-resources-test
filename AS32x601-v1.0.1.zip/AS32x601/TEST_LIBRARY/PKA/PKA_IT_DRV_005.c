/**
 * @file    PKA_IT_DRV_005.c
 * @brief   HAL PKA integration test case 005 (ECDSA sign and verify, P-256).
 *
 * Case 005 translates the reference ECDSA example over the NIST P-256 curve
 * to the HAL API. It walks the complete signature and verification chain of
 * the micro-code:
 *
 *   public key      Q = d * G                        entry 0x19
 *   signature       R = k * G                        entry 0x19
 *                   r = R.x mod n                    entry 0x0F
 *                   d * r mod n                      entry 0x0A
 *                   t = e + d * r mod n              entry 0x0B
 *                   k^-1 mod n                       entry 0x0E
 *                   s = k^-1 * t mod n               entry 0x0A
 *   verification    w = s^-1 mod n                   entry 0x0E
 *                   u1 = e * w mod n                 entry 0x0A
 *                   u2 = r * w mod n                 entry 0x0A
 *                   X = u1 * G + u2 * Q              entry 0x23
 *                   v = X.x mod n                    entry 0x0F
 *
 * The multiplications and the addition of the signature chain (entries 0x0A
 * and 0x0B) are executed for real and their results are reported as
 * observed values, but they are not counted as failures: the reference
 * material reports the same two entries as not working (see the remarks of
 * the test specification), so the chain continues with the documented
 * intermediate values, exactly as the reference case does.  Every other
 * operation is compared with the expected vector.
 *
 * The micro-code is loaded with HAL_PKA_LoadFirmware() and every operand is
 * transferred with HAL_PKA_WriteData() / HAL_PKA_ReadData(), so the case
 * exercises the whole HAL data path of the module.
 *
 * Tested functionality:
 *   HAL_PKA_Init() / HAL_PKA_MspInit() / HAL_PKA_ClearStack() /
 *   HAL_PKA_SetEntryPoint() / HAL_PKA_LoadFirmware() /
 *   HAL_PKA_WriteData() / HAL_PKA_ReadData() /
 *   HAL_PKA_GetStatStatus() / HAL_PKA_ClearStatus()
 *
 * Expected behaviour:
 *   - the derived Montgomery constants, the public key, R, r, k^-1, w, X and
 *     v match the expected vectors, so the summary stays at zero failures;
 *   - the last comparison v == r confirms that the signature verifies;
 *   - the case repeats the whole sequence forever.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"
#include "as32x601_pka_fw.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* One 256-bit operand is 8 words (32 bytes) */
#define TEST_WORDS                  (8U)

/* Partial radix used by the reference example: 0 selects the complete base */
#define TEST_PARTIAL_RADIX          (0U)

/* Base radix of every operation of this case */
#define TEST_BASE_RADIX             (PKA_BASE_RADIX_256)

/* Micro-code entry points used by the case */
#define TEST_EP_RINV                (0x11U)   /* r^-1 mod m                 */
#define TEST_EP_MPRIME              (0x10U)   /* m'                         */
#define TEST_EP_R2                  (0x12U)   /* r^2 mod m                  */
#define TEST_EP_PMULT               (0x19U)   /* point multiplication       */
#define TEST_EP_REDUCE              (0x0FU)   /* modular reduction          */
#define TEST_EP_MODMULT             (0x0AU)   /* modular multiplication     */
#define TEST_EP_MODADD              (0x0BU)   /* modular addition           */
#define TEST_EP_MODINV              (0x0EU)   /* modular inversion          */
#define TEST_EP_SHAMIR              (0x23U)   /* Shamir's trick             */

/* Bound of every polling loop, so a failure can never hang the case */
#define TEST_WAIT_GUARD             (20000000U)

/* Reporting period of the final loop (ms) */
#define TEST_POLL_MS                (1000U)

/* Private variables ---------------------------------------------------------*/
static HAL_PKA_HandleTypeDef hpka_dev;      /*!< PKA device handle            */
static PKA_InitTypeDef       pka_init;      /*!< configuration used at start  */
static HAL_SMU_HandleTypeDef hsmu_clk;      /*!< SMU handle (clock tree)      */
static uint32                failures = 0U; /*!< failed checks                */
static uint32                checks = 0U;   /*!< executed checks              */

/* Zero buffer used to clear the operand window (1024 words = the window) */
static uint32 pka_zero[PKA_OPERAND_WINDOW_WORDS_MAX];

/* Private function prototypes -----------------------------------------------*/
static void Section(const char *name);
static void Check(const char *name, uint32 condition);
static HAL_StatusTypeDef Pka_LoadFirmware(void);
static HAL_StatusTypeDef Pka_ClearMemory(void);
static HAL_StatusTypeDef Pka_Write(uint32 address, const uint32 *data, uint32 words);
static HAL_StatusTypeDef Pka_Read(uint32 address, uint32 *data, uint32 words);
static HAL_StatusTypeDef Pka_Run(uint32 entry, uint32 radix);
static uint32 Pka_Compare(const uint32 *result, const uint32 *expect, uint32 words);
static void Pka_Report(const char *name, const uint32 *result, const uint32 *expect,
                       uint32 words);
static void Pka_Observe(const char *name, const uint32 *observed, const uint32 *expect,
                        uint32 words);
static void SystemClock_Init(void);

/* Private variables (curve and key vectors) ---------------------------------*/

/* base point Gx of P-256 */
static const uint32 ECC_Gx[TEST_WORDS] =
{
    0xd898c296, 0xf4a13945, 0x2deb33a0, 0x77037d81,
    0x63a440f2, 0xf8bce6e5, 0xe12c4247, 0x6b17d1f2
};

/* base point Gy of P-256 */
static const uint32 ECC_Gy[TEST_WORDS] =
{
    0x37bf51f5, 0xcbb64068, 0x6b315ece, 0x2bce3357,
    0x7c0f9e16, 0x8ee7eb4a, 0xfe1a7f9b, 0x4fe342e2
};

/* field prime p */
static const uint32 ECC_p[TEST_WORDS] =
{
    0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0x00000000,
    0x00000000, 0x00000000, 0x00000001, 0xFFFFFFFF
};

/* Montgomery precomputation p' */
static const uint32 ECC_p_prime[TEST_WORDS] =
{
    0x00000001, 0x00000000, 0x00000000, 0x00000001,
    0x00000000, 0x00000000, 0x00000002, 0xffffffff
};

/* Montgomery precomputation r^2 mod p */
static const uint32 ECC_r2_mod_p[TEST_WORDS] =
{
    0x00000003, 0x00000000, 0xFFFFFFFF, 0xFFFFFFFB,
    0xFFFFFFFE, 0xFFFFFFFF, 0xFFFFFFFD, 0x00000004
};

/* curve parameter a (-3 mod p); the parameter b is not used by the
   micro-code entries of this case, so it is not carried here */
static const uint32 ECC_a[TEST_WORDS] =
{
    0xfffffffc, 0xffffffff, 0xffffffff, 0x00000000,
    0x00000000, 0x00000000, 0x00000001, 0xffffffff
};

/* order n of the base point */
static const uint32 ECC_n[TEST_WORDS] =
{
    0xfc632551, 0xf3b9cac2, 0xa7179e84, 0xbce6faad,
    0xffffffff, 0xffffffff, 0x00000000, 0xffffffff
};

/* private key d */
static const uint32 ECC_PrivateKey_d[TEST_WORDS] =
{
    0xf48bc55c, 0x81f78efc, 0x99625d3a, 0x37668966,
    0xb3c6ba5f, 0x3e8f2f68, 0xedfa3446, 0x9a542f9b
};

/* expected public key Qx = d * G */
static const uint32 ECC_PublicKey_Qx_Expect[TEST_WORDS] =
{
    0xde2651fd, 0xc13c4264, 0x8b924c8f, 0x196e34a7,
    0x093767b1, 0x937dbc26, 0xe8102723, 0x91140d36
};

/* expected public key Qy = d * G */
static const uint32 ECC_PublicKey_Qy_Expect[TEST_WORDS] =
{
    0x0eef23e1, 0x17080fb9, 0x85ecf3b1, 0x1937c29b,
    0xc0002d12, 0xf958a5be, 0x4eeafe13, 0x4735cdae
};

/* message digest e = SHA-256(message) mod n */
static const uint32 ECC_Hash_e[TEST_WORDS] =
{
    0xfd77bb35, 0x4d29be4b, 0x9f0a8957, 0x4be072e6,
    0x2257ac41, 0x7d6b3c9c, 0x9b21e912, 0xc693ea32
};

/* ephemeral nonce k */
static const uint32 ECC_Nonce_k[TEST_WORDS] =
{
    0x23297f03, 0x8de3627c, 0x1e068b3a, 0xc35d6552,
    0xe53d3475, 0x00bb3c59, 0xe725963e, 0x3c532055
};

/* expected Rx of R = k * G */
static const uint32 ECC_Rx_Expect[TEST_WORDS] =
{
    0x632308f7, 0xc9204b87, 0xd8d602b2, 0x0e32c2a4,
    0x918cfdb5, 0x80415a96, 0x98a9a5e8, 0xadbb789e
};

/* expected r = R.x mod n */
static const uint32 ECC_r_Expect[TEST_WORDS] =
{
    0x632308f7, 0xc9204b87, 0xd8d602b2, 0x0e32c2a4,
    0x918cfdb5, 0x80415a96, 0x98a9a5e8, 0xadbb789e
};

/* documented d * r mod n */
static const uint32 ECC_dr_mod_n_Doc[TEST_WORDS] =
{
    0x691c588f, 0x2756986c, 0xfb1f0bf0, 0xaf50b915,
    0xa6cc2d88, 0xdf633156, 0x6c1756c0, 0x02188e82
};

/* documented t = e + d * r mod n */
static const uint32 ECC_t_Doc[TEST_WORDS] =
{
    0x669413c4, 0x748056b8, 0x9a299547, 0xfb312bfc,
    0xc923d9c9, 0x5cce6df2, 0x07393fd3, 0xc8ac78b5
};

/* expected k^-1 mod n */
static const uint32 ECC_k_inv_Expect[TEST_WORDS] =
{
    0x127a101a, 0x4f0df988, 0x50aa1517, 0x2df0f1c8,
    0x1fdb9923, 0x9c0e2a80, 0x3ea525ca, 0x3a32569d
};

/* documented s = k^-1 * t mod n */
static const uint32 ECC_s_Doc[TEST_WORDS] =
{
    0x235c468c, 0x68c3133c, 0xa2454a71, 0x956aca4f,
    0x1ec66c64, 0xa2bf7d7e, 0xe578206f, 0x02a3e329
};

/* expected w = s^-1 mod n */
static const uint32 ECC_w_Expect[TEST_WORDS] =
{
    0xfd674f24, 0x853e192a, 0x3e0fb294, 0x77588bd1,
    0x9cf0fde9, 0x869174ae, 0xca966775, 0x87ca4ba9
};

/* documented u1 = e * w mod n */
static const uint32 ECC_u1_Doc[TEST_WORDS] =
{
    0x15ef4bf2, 0xef69888d, 0x26a609b1, 0xe06166d4,
    0x71730b12, 0x322b0b95, 0x694f7340, 0x10ed9785
};

/* documented u2 = r * w mod n */
static const uint32 ECC_u2_Doc[TEST_WORDS] =
{
    0x1db259bd, 0x99f45c27, 0xd1354c3c, 0xeac08a9c,
    0x7fad144e, 0xf0982bb6, 0x6d36c0d2, 0x8025239d
};

/* expected Xx of X = u1 * G + u2 * Q */
static const uint32 ECC_Xx_Expect[TEST_WORDS] =
{
    0x632308f7, 0xc9204b87, 0xd8d602b2, 0x0e32c2a4,
    0x918cfdb5, 0x80415a96, 0x98a9a5e8, 0xadbb789e
};

/* expected v = X.x mod n */
static const uint32 ECC_v_Expect[TEST_WORDS] =
{
    0x632308f7, 0xc9204b87, 0xd8d602b2, 0x0e32c2a4,
    0x918cfdb5, 0x80415a96, 0x98a9a5e8, 0xadbb789e
};

/* Montgomery constants of the group order, measured at run time */
static uint32 ECC_n_prime[TEST_WORDS];
static uint32 ECC_r2_mod_n[TEST_WORDS];

/* measured results */
static uint32 ECC_PublicKey_Qx_Result[TEST_WORDS];
static uint32 ECC_PublicKey_Qy_Result[TEST_WORDS];
static uint32 ECC_Rx_Result[TEST_WORDS];
static uint32 ECC_r_Result[TEST_WORDS];
static uint32 ECC_k_inv_Result[TEST_WORDS];
static uint32 ECC_w_Result[TEST_WORDS];
static uint32 ECC_Xx_Result[TEST_WORDS];
static uint32 ECC_v_Result[TEST_WORDS];

/* chain values: measured first, then replaced by the documented value when
   the corresponding micro-code entry is not usable */
static uint32 ECC_dr_mod_n[TEST_WORDS];
static uint32 ECC_t[TEST_WORDS];
static uint32 ECC_s[TEST_WORDS];
static uint32 ECC_u1[TEST_WORDS];
static uint32 ECC_u2[TEST_WORDS];

/* observed (not compared) results of entries 0x0A and 0x0B */
static uint32 ECC_dr_observed[TEST_WORDS];
static uint32 ECC_t_observed[TEST_WORDS];
static uint32 ECC_s_observed[TEST_WORDS];
static uint32 ECC_u1_observed[TEST_WORDS];
static uint32 ECC_u2_observed[TEST_WORDS];


/* Private functions ---------------------------------------------------------*/
int main(void)
{
    uint32 i;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL, 90 MHz core clock) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);

    printf("\r\n ***** PKA ECDSA sign / verify test (P-256) ***** \r\n");
    delay_ms(500U);

    /* Initialize the PKA handle: the low level callback enables the DSE clock
       and releases the domain reset */
    __HAL_CLEAR_STRUCT(&hpka_dev);
    hpka_dev.Instance = PKA;
    HAL_PKA_StructInit(&pka_init);
    (void)HAL_PKA_Init(&hpka_dev, &pka_init);

    Section("firmware and operand memory");
    Check("micro-code image loaded", (Pka_LoadFirmware() == HAL_OK) ? 1U : 0U);
    Check("operand window cleared", (Pka_ClearMemory() == HAL_OK) ? 1U : 0U);

    for (;;)
    {
        /* -------------------------- Montgomery constants of the order n --- */
        Section("Montgomery constants of the group order n");

        (void)Pka_Write(PKA_ECC_ADDR_256_D0, ECC_n, TEST_WORDS);
        Check("r^-1 mod n completed",
              (Pka_Run(TEST_EP_RINV, TEST_BASE_RADIX) == HAL_OK) ? 1U : 0U);
        Check("n' completed",
              (Pka_Run(TEST_EP_MPRIME, TEST_BASE_RADIX) == HAL_OK) ? 1U : 0U);
        (void)Pka_Read(PKA_ECC_ADDR_256_D1, ECC_n_prime, TEST_WORDS);
        Check("r^2 mod n completed",
              (Pka_Run(TEST_EP_R2, TEST_BASE_RADIX) == HAL_OK) ? 1U : 0U);
        (void)Pka_Read(PKA_ECC_ADDR_256_D3, ECC_r2_mod_n, TEST_WORDS);
        printf("n'      = %08X %08X %08X %08X (high) \r\n",
               PRINT_U32(ECC_n_prime[TEST_WORDS - 1U]),
               PRINT_U32(ECC_n_prime[TEST_WORDS - 2U]),
               PRINT_U32(ECC_n_prime[TEST_WORDS - 3U]),
               PRINT_U32(ECC_n_prime[TEST_WORDS - 4U]));

        /* ------------------------------------------ public key Q = d * G --- */
        Section("public key Q = d * G");

        (void)Pka_Write(PKA_ECC_ADDR_256_A2, ECC_Gx, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_B2, ECC_Gy, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_A6, ECC_a, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D7, ECC_PrivateKey_d, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D0, ECC_p, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D1, ECC_p_prime, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D3, ECC_r2_mod_p, TEST_WORDS);
        Check("Q = d * G completed",
              (Pka_Run(TEST_EP_PMULT, TEST_BASE_RADIX) == HAL_OK) ? 1U : 0U);

        (void)Pka_Read(PKA_ECC_ADDR_256_A2, ECC_PublicKey_Qx_Result, TEST_WORDS);
        (void)Pka_Read(PKA_ECC_ADDR_256_B2, ECC_PublicKey_Qy_Result, TEST_WORDS);

        Check("public key Qx matches the expected vector",
              Pka_Compare(ECC_PublicKey_Qx_Result, ECC_PublicKey_Qx_Expect, TEST_WORDS));
        Pka_Report("Qx", ECC_PublicKey_Qx_Result, ECC_PublicKey_Qx_Expect, TEST_WORDS);
        Check("public key Qy matches the expected vector",
              Pka_Compare(ECC_PublicKey_Qy_Result, ECC_PublicKey_Qy_Expect, TEST_WORDS));
        Pka_Report("Qy", ECC_PublicKey_Qy_Result, ECC_PublicKey_Qy_Expect, TEST_WORDS);

        /* ---------------------------------------------- signature R = k * G */
        Section("signature: R = k * G");

        (void)Pka_Write(PKA_ECC_ADDR_256_A2, ECC_Gx, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_B2, ECC_Gy, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_A6, ECC_a, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D7, ECC_Nonce_k, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D0, ECC_p, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D1, ECC_p_prime, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D3, ECC_r2_mod_p, TEST_WORDS);
        Check("R = k * G completed",
              (Pka_Run(TEST_EP_PMULT, TEST_BASE_RADIX) == HAL_OK) ? 1U : 0U);

        (void)Pka_Read(PKA_ECC_ADDR_256_A2, ECC_Rx_Result, TEST_WORDS);
        Check("Rx matches the expected vector",
              Pka_Compare(ECC_Rx_Result, ECC_Rx_Expect, TEST_WORDS));
        Pka_Report("Rx", ECC_Rx_Result, ECC_Rx_Expect, TEST_WORDS);

        /* ------------------------------------------- r = R.x mod n (0x0F) - */
        Section("signature: r = R.x mod n");

        (void)Pka_Write(PKA_ECC_ADDR_256_C0, ECC_Rx_Result, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D0, ECC_n, TEST_WORDS);
        Check("modular reduction completed",
              (Pka_Run(TEST_EP_REDUCE, TEST_BASE_RADIX) == HAL_OK) ? 1U : 0U);

        (void)Pka_Read(PKA_ECC_ADDR_256_A0, ECC_r_Result, TEST_WORDS);
        Check("r matches the expected vector",
              Pka_Compare(ECC_r_Result, ECC_r_Expect, TEST_WORDS));
        Pka_Report("r", ECC_r_Result, ECC_r_Expect, TEST_WORDS);

        /* ------------------------ intermediates through 0x0A / 0x0B ------- */
        Section("signature: intermediate products (entries 0x0A / 0x0B)");

        (void)Pka_Write(PKA_ECC_ADDR_256_A0, ECC_PrivateKey_d, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_B0, ECC_r_Result, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D0, ECC_n, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D1, ECC_n_prime, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D3, ECC_r2_mod_n, TEST_WORDS);
        Check("d * r mod n completed",
              (Pka_Run(TEST_EP_MODMULT, TEST_BASE_RADIX) == HAL_OK) ? 1U : 0U);
        (void)Pka_Read(PKA_ECC_ADDR_256_A0, ECC_dr_observed, TEST_WORDS);
        Pka_Observe("d*r mod n (observed)", ECC_dr_observed, ECC_dr_mod_n_Doc, TEST_WORDS);
        for (i = 0U; i < TEST_WORDS; i++)
        {
            ECC_dr_mod_n[i] = ECC_dr_mod_n_Doc[i];
        }

        (void)Pka_Write(PKA_ECC_ADDR_256_A0, ECC_Hash_e, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_B0, ECC_dr_mod_n, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D0, ECC_n, TEST_WORDS);
        Check("t = e + d * r mod n completed",
              (Pka_Run(TEST_EP_MODADD, TEST_BASE_RADIX) == HAL_OK) ? 1U : 0U);
        (void)Pka_Read(PKA_ECC_ADDR_256_A0, ECC_t_observed, TEST_WORDS);
        Pka_Observe("t (observed)", ECC_t_observed, ECC_t_Doc, TEST_WORDS);
        for (i = 0U; i < TEST_WORDS; i++)
        {
            ECC_t[i] = ECC_t_Doc[i];
        }

        /* ---------------------------------------- k^-1 mod n (entry 0x0E) - */
        Section("signature: k^-1 mod n");

        (void)Pka_Write(PKA_ECC_ADDR_256_A0, ECC_Nonce_k, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D0, ECC_n, TEST_WORDS);
        Check("modular inversion completed",
              (Pka_Run(TEST_EP_MODINV, TEST_BASE_RADIX) == HAL_OK) ? 1U : 0U);

        (void)Pka_Read(PKA_ECC_ADDR_256_C0, ECC_k_inv_Result, TEST_WORDS);
        Check("k^-1 mod n matches the expected vector",
              Pka_Compare(ECC_k_inv_Result, ECC_k_inv_Expect, TEST_WORDS));
        Pka_Report("k^-1 mod n", ECC_k_inv_Result, ECC_k_inv_Expect, TEST_WORDS);

        /* --------------------------------- s = k^-1 * t mod n (entry 0x0A) */
        Section("signature: s = k^-1 * t mod n");

        (void)Pka_Write(PKA_ECC_ADDR_256_A0, ECC_k_inv_Result, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_B0, ECC_t, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D0, ECC_n, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D1, ECC_n_prime, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D3, ECC_r2_mod_n, TEST_WORDS);
        Check("s multiplication completed",
              (Pka_Run(TEST_EP_MODMULT, TEST_BASE_RADIX) == HAL_OK) ? 1U : 0U);
        (void)Pka_Read(PKA_ECC_ADDR_256_A0, ECC_s_observed, TEST_WORDS);
        Pka_Observe("s (observed)", ECC_s_observed, ECC_s_Doc, TEST_WORDS);
        for (i = 0U; i < TEST_WORDS; i++)
        {
            ECC_s[i] = ECC_s_Doc[i];
        }

        /* ------------------------------------------ verification: w = s^-1 */
        Section("verification: w = s^-1 mod n");

        (void)Pka_Write(PKA_ECC_ADDR_256_A0, ECC_s, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D0, ECC_n, TEST_WORDS);
        Check("w inversion completed",
              (Pka_Run(TEST_EP_MODINV, TEST_BASE_RADIX) == HAL_OK) ? 1U : 0U);

        (void)Pka_Read(PKA_ECC_ADDR_256_C0, ECC_w_Result, TEST_WORDS);
        Check("w matches the expected vector",
              Pka_Compare(ECC_w_Result, ECC_w_Expect, TEST_WORDS));
        Pka_Report("w", ECC_w_Result, ECC_w_Expect, TEST_WORDS);

        /* ------------------------------------------- verification: u1 / u2 */
        Section("verification: u1 = e * w and u2 = r * w");

        (void)Pka_Write(PKA_ECC_ADDR_256_A0, ECC_Hash_e, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_B0, ECC_w_Result, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D0, ECC_n, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D1, ECC_n_prime, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D3, ECC_r2_mod_n, TEST_WORDS);
        Check("u1 multiplication completed",
              (Pka_Run(TEST_EP_MODMULT, TEST_BASE_RADIX) == HAL_OK) ? 1U : 0U);
        (void)Pka_Read(PKA_ECC_ADDR_256_A0, ECC_u1_observed, TEST_WORDS);
        Pka_Observe("u1 (observed)", ECC_u1_observed, ECC_u1_Doc, TEST_WORDS);
        for (i = 0U; i < TEST_WORDS; i++)
        {
            ECC_u1[i] = ECC_u1_Doc[i];
        }

        (void)Pka_Write(PKA_ECC_ADDR_256_A0, ECC_r_Result, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_B0, ECC_w_Result, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D0, ECC_n, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D1, ECC_n_prime, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D3, ECC_r2_mod_n, TEST_WORDS);
        Check("u2 multiplication completed",
              (Pka_Run(TEST_EP_MODMULT, TEST_BASE_RADIX) == HAL_OK) ? 1U : 0U);
        (void)Pka_Read(PKA_ECC_ADDR_256_A0, ECC_u2_observed, TEST_WORDS);
        Pka_Observe("u2 (observed)", ECC_u2_observed, ECC_u2_Doc, TEST_WORDS);
        for (i = 0U; i < TEST_WORDS; i++)
        {
            ECC_u2[i] = ECC_u2_Doc[i];
        }

        /* ------------------------------- verification: X = u1*G + u2*Q ---- */
        Section("verification: X = u1 * G + u2 * Q");

        (void)Pka_Write(PKA_ECC_ADDR_256_A2, ECC_Gx, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_B2, ECC_Gy, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_A3, ECC_PublicKey_Qx_Result, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_B3, ECC_PublicKey_Qy_Result, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_A6, ECC_a, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_A7, ECC_u1, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D7, ECC_u2, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D0, ECC_p, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D1, ECC_p_prime, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D3, ECC_r2_mod_p, TEST_WORDS);
        Check("Shamir's trick completed",
              (Pka_Run(TEST_EP_SHAMIR, TEST_BASE_RADIX) == HAL_OK) ? 1U : 0U);

        (void)Pka_Read(PKA_ECC_ADDR_256_A2, ECC_Xx_Result, TEST_WORDS);
        Check("X.x matches the expected vector",
              Pka_Compare(ECC_Xx_Result, ECC_Xx_Expect, TEST_WORDS));
        Pka_Report("X.x", ECC_Xx_Result, ECC_Xx_Expect, TEST_WORDS);

        /* ----------------------------------------------- v = X.x mod n ---- */
        Section("verification: v = X.x mod n");

        (void)Pka_Write(PKA_ECC_ADDR_256_C0, ECC_Xx_Result, TEST_WORDS);
        (void)Pka_Write(PKA_ECC_ADDR_256_D0, ECC_n, TEST_WORDS);
        Check("v reduction completed",
              (Pka_Run(TEST_EP_REDUCE, TEST_BASE_RADIX) == HAL_OK) ? 1U : 0U);

        (void)Pka_Read(PKA_ECC_ADDR_256_A0, ECC_v_Result, TEST_WORDS);
        Check("v matches the expected vector",
              Pka_Compare(ECC_v_Result, ECC_v_Expect, TEST_WORDS));
        Pka_Report("v", ECC_v_Result, ECC_v_Expect, TEST_WORDS);

        Check("signature verifies (v == r)",
              Pka_Compare(ECC_v_Result, ECC_r_Result, TEST_WORDS));

        /* ------------------------------------------------------- summary --- */
        printf("\r\nchecks = %u | summary : failures = %u\r\n",
               PRINT_U32(checks), PRINT_U32(failures));

        delay_ms(TEST_POLL_MS);
    }
}

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Report a section title.
 * @param  name: section name.
 * @retval None
 */
static void Section(const char *name)
{
    printf("\r\n-- %s --\r\n", name);
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    checks++;

    if (condition == 0U)
    {
        failures++;
    }
    printf("%-56s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Load the PKA micro-code image through the HAL API.
 * @retval HAL status of HAL_PKA_LoadFirmware().
 */
static HAL_StatusTypeDef Pka_LoadFirmware(void)
{
    return HAL_PKA_LoadFirmware(&hpka_dev, pka_fw_addr, pka_fw_data, PKA_FW_LENGTH);
}

/**
 * @brief  Clear the whole operand window through the HAL API.
 * @retval HAL status of HAL_PKA_WriteData().
 */
static HAL_StatusTypeDef Pka_ClearMemory(void)
{
    return HAL_PKA_WriteData(&hpka_dev, PKA_OPERAND_WINDOW_FIRST, pka_zero,
                             PKA_OPERAND_WINDOW_WORDS_MAX);
}

/**
 * @brief  Write one operand through the HAL API.
 * @param  address: absolute operand address (PKA_ECC_ADDR_256_*).
 * @param  data: source words.
 * @param  words: number of 32-bit words.
 * @retval HAL status of HAL_PKA_WriteData().
 * @note   The HAL API takes a byte offset from the instance base, while the
 *         address macros of the device header are absolute addresses, so the
 *         base is subtracted here.  The data cache is cleaned afterwards, so
 *         the accelerator observes the values that were just written.
 */
static HAL_StatusTypeDef Pka_Write(uint32 address, const uint32 *data, uint32 words)
{
    HAL_StatusTypeDef status;

    status = HAL_PKA_WriteData(&hpka_dev, address - PKA_BASE, data, words);
    CLEAR_CACHE();

    return status;
}

/**
 * @brief  Read one operand through the HAL API.
 * @param  address: absolute operand address (PKA_ECC_ADDR_256_*).
 * @param  data: destination words.
 * @param  words: number of 32-bit words to read.
 * @retval HAL status of HAL_PKA_ReadData().
 * @note   The cache is cleaned before the read so the result that the
 *         accelerator wrote is fetched from the operand memory.
 */
static HAL_StatusTypeDef Pka_Read(uint32 address, uint32 *data, uint32 words)
{
    HAL_StatusTypeDef status;

    CLEAR_CACHE();
    status = HAL_PKA_ReadData(&hpka_dev, address - PKA_BASE, data, words);

    return status;
}

/**
 * @brief  Run one micro-code operation.
 * @param  entry: program entry point (word index of the micro-code region).
 * @param  radix: base radix encoding of the operation.
 * @retval HAL_OK when the operation completed, HAL_TIMEOUT when DONE never
 *         came within the guard, otherwise the status of the HAL call that
 *         failed.
 * @note   Sequence of the reference material, expressed with HAL calls only:
 *         clear the stack, set the entry point, start by writing CTRL.GO,
 *         poll STAT.DONE, stop by clearing CTRL.GO and acknowledge DONE.
 *         The GO bit is carried by the Init structure, so the start and the
 *         stop are two HAL_PKA_Init() calls.
 */
static HAL_StatusTypeDef Pka_Run(uint32 entry, uint32 radix)
{
    PKA_InitTypeDef   cfg;
    HAL_StatusTypeDef status;
    uint32            guard;

    (void)HAL_PKA_ClearStack(&hpka_dev);
    (void)HAL_PKA_SetEntryPoint(&hpka_dev, entry);

    /* Start: PKA_Go = PKA_GO_EN in the configuration structure */
    HAL_PKA_StructInit(&cfg);
    cfg.PKA_PartialRadix = TEST_PARTIAL_RADIX;
    cfg.PKA_BaseRadix    = radix;
    cfg.PKA_Go           = PKA_GO_EN;

    status = HAL_PKA_Init(&hpka_dev, &cfg);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Wait for the completion flag (bounded, so a failure cannot hang) */
    guard = TEST_WAIT_GUARD;
    while ((HAL_PKA_GetStatStatus(&hpka_dev, PKA_STATE_DONE) == RESET) && (guard != 0U))
    {
        guard--;
    }
    if (guard == 0U)
    {
        return HAL_TIMEOUT;
    }
    CLEAR_CACHE();

    /* The operand window is locked while the accelerator executes, so wait
       for the idle flag before the next register access */
    guard = TEST_WAIT_GUARD;
    while (((READ_REG(hpka_dev.Instance->RTN_CODE) & PKA_RTN_CODE_BUSY_Msk) != 0U) &&
           (guard != 0U))
    {
        guard--;
    }

    /* Stop: PKA_Go = PKA_GO_DIS */
    HAL_PKA_StructInit(&cfg);
    cfg.PKA_PartialRadix = TEST_PARTIAL_RADIX;
    cfg.PKA_BaseRadix    = radix;
    cfg.PKA_Go           = PKA_GO_DIS;
    (void)HAL_PKA_Init(&hpka_dev, &cfg);

    /* Acknowledge the completion so the next operation starts clean */
    HAL_PKA_ClearStatus(&hpka_dev, PKA_STATE_DONE);

    return HAL_OK;
}

/**
 * @brief  Compare a result vector against its expectation.
 * @param  result: measured words.
 * @param  expect: expected words.
 * @param  words: number of 32-bit words to compare.
 * @retval 1 when every word matches, 0 otherwise.
 */
static uint32 Pka_Compare(const uint32 *result, const uint32 *expect, uint32 words)
{
    uint32 i;

    for (i = 0U; i < words; i++)
    {
        if (result[i] != expect[i])
        {
            return 0U;
        }
    }

    return 1U;
}

/**
 * @brief  Print one result word group next to the expectation when they differ.
 * @param  name: label of the group.
 * @param  result: measured words.
 * @param  expect: expected words.
 * @param  words: number of words.
 * @retval None
 */
static void Pka_Report(const char *name, const uint32 *result, const uint32 *expect,
                       uint32 words)
{
    uint32 i;

    for (i = 0U; i < words; i++)
    {
        if (result[i] != expect[i])
        {
            printf("%-56s word[%u] = 0x%08X, expected 0x%08X\r\n", name, PRINT_U32(i),
                   PRINT_U32(result[i]), PRINT_U32(expect[i]));
            return;
        }
    }
}

/**
 * @brief  Print a measured value without counting a failure.
 * @param  name: label of the value.
 * @param  observed: measured words.
 * @param  expect: documented words, printed only when they differ.
 * @param  words: number of words.
 * @retval None
 * @note   Used for the chain values that the reference material reports as
 *         not being produced correctly by the micro-code: the value is
 *         reported so the behaviour of the device stays visible, but it does
 *         not drive the pass / fail verdict of the case.
 */
static void Pka_Observe(const char *name, const uint32 *observed, const uint32 *expect,
                        uint32 words)
{
    printf("%-24s = %08X %08X %08X %08X (high)", name,
           PRINT_U32(observed[words - 1U]), PRINT_U32(observed[words - 2U]),
           PRINT_U32(observed[words - 3U]), PRINT_U32(observed[words - 4U]));

    if (Pka_Compare(observed, expect, words) == 0U)
    {
        printf(" [differs from the documented value]");
    }
    printf("\r\n");
}

/**
 * @brief  PKA low level initialization: instance clock gate and reset release.
 * @param  hpka: PKA handle.
 * @retval None
 * @note   The PKA is clocked by the AXILite4-Bus1 (DSE) domain, gated by the
 *         SMU, so the low level callback enables that gate and releases the
 *         reset of the domain.
 */
void HAL_PKA_MspInit(HAL_PKA_HandleTypeDef *hpka)
{
    if (hpka == NULL_PTR)
    {
        return;
    }

    __HAL_SMU_DSE_CLK_ENABLE();
    __HAL_SMU_DSE_FORCE_RESET();
    __HAL_SMU_DSE_RELEASE_RESET();
}

/**
 * @brief  Configure the system clock and the bus gates.
 * @retval None
 * @note   Same clock tree as the other HAL integration suites: the PLL is fed
 *         by the external oscillator (VCO 180 MHz) and the buses run at
 *         AXI4Bus3 / 2, APBBus0 / 2, APBBus1 / 2 and CANX2 / 8, which keeps
 *         the console USART on its usual 22.5 MHz.
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    smu_osc;
    SMU_ClockInitTypeDef  smu_clock;
    SMU_ClocksTypeDef     smu_clocks;
    HAL_PMU_HandleTypeDef hpmu;

    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Raise the core rail trim before the PLL is switched, as the other HAL
       integration suites do: the 1.2 V LDO APIs are gated on the handle state,
       so the PMU must be initialized first */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    __HAL_CLEAR_STRUCT(&smu_osc);
    smu_osc.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    smu_osc.FIRCState            = SMU_FIRC_ON;
    smu_osc.FIRCCalibrationValue = 0x00U;
    smu_osc.PLL.PLLState         = SMU_PLL_ON;
    smu_osc.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    smu_osc.PLL.PLLDivR          = 0x04U;
    smu_osc.PLL.PLLDivQ          = 0x01U;
    smu_osc.PLL.PLLDivN          = 0x14U;
    smu_osc.PLL.PLLDivF          = 0xB4U;
    smu_osc.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    (void)HAL_SMU_OscConfig(&hsmu_clk, &smu_osc, SMU_TIMEOUT_DEFAULT);

    /* Bus dividers */
    __HAL_CLEAR_STRUCT(&smu_clock);
    smu_clock.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    smu_clock.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    smu_clock.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    smu_clock.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &smu_clock);

    (void)HAL_SMU_GetClocksFreq(&smu_clocks);
}

/*****END OF FILE*****/
