/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):    Xiamen Guoke Anxin Technology Co., LTD
 * FileName:         as32x601_hal_mac.c
 * Author:           ANSILIC APPLICATION GROUP
 * Version:          V1.4
 * Date:             2026/09/20
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/09/07     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/07     1.1     align with the library
 *                                                       conventions: module
 *                                                       switch guard, shared
 *                                                       lock helpers
 *                                                       (MAC_LockHandle /
 *                                                       MAC_UnlockHandle, RTOS
 *                                                       branch uses the
 *                                                       LockMutex handle),
 *                                                       NULL guards on every
 *                                                       public function,
 *                                                       error code field +
 *                                                       HAL_MAC_GetError(),
 *                                                       IRQ handler without
 *                                                       lock operations,
 *                                                       standard NULL_PTR
 *                                                       checks and Tier-3
 *                                                       naming
 *     ANSILIC APPLICATION GROUP  2026/09/11     1.2     fix the MAC reset pulse order in
 *                                                       HAL_MAC_DeInit (assert by clearing the
 *                                                       bit, then release by setting it)
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.4     elevate the module to the Medium level of
 *                                                       the architecture specification: add the shared
 *                                                       validity and state helpers, give the lock
 *                                                       helper a Timeout parameter and a NULL mutex
 *                                                       guard, take the lock and clear the error code
 *                                                       in every register writing entry point, apply
 *                                                       the busy / reset state gate, run the MSP
 *                                                       callbacks outside the locked region, yield the
 *                                                       CPU in the blocking polling loops, report a
 *                                                       timeout through the timeout error code,
 *                                                       program the software reset through an internal
 *                                                       helper so that no public interface is called
 *                                                       inside a locked region, remove the reference to
 *                                                       an external implementation and align the
 *                                                       version of the two module files
 * Description:     This file provides firmware functions to manage the
 *                  Ethernet MAC (Media Access Control) peripheral.
 */
#include "as32x601_hal.h"          /* HAL common types and utilities          */
#include "as32x601_hal_mac.h"      /* MAC HAL API and register macros         */

#include <string.h>                /* memcpy: frame payload copy              */

/* The HAL_MAC_MODULE_ENABLED switch is provided by the user configuration
 * file (as32x601_hal_conf.h, included above through as32x601_hal.h): the
 * whole implementation is compiled only while the module is enabled. */
#ifdef HAL_MAC_MODULE_ENABLED

/* Private includes ----------------------------------------------------------*/

/* Private typedef -----------------------------------------------------------*/

/* Private define ------------------------------------------------------------*/
/** @defgroup MAC_Private_Define MAC Private Defines
  * @{
  */
#define MAC_TIMEOUT_SWRESET     1000U    /*!< Timeout (in ms) for the software
                                              reset wait loop.                   */
#define MAC_MDIO_TIMEOUT_VALUE  1000U    /*!< Timeout (in ms) for the MDIO
                                              read / write ACK poll.             */
/**
  * @}
  */

/* Private macro -------------------------------------------------------------*/

/* Private variables ---------------------------------------------------------*/

/* Private function prototypes -----------------------------------------------*/
static uint32 MAC_GetRxPacketLength(uint32 descriptor0);
static uint32 MAC_AdjustTxPktLength(uint32 tx_length);
static void MAC_SoftwareResetInternal(MAC_HandleTypeDef *hmac);

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Check whether the MAC handle and its instance are valid.
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
uint32 MAC_HandleIsValid(MAC_HandleTypeDef *hmac)
{
    if (hmac == NULL_PTR)
    {
        return 0U;
    }

    if (IS_MAC_ALL_INSTANCE(hmac->Instance) == 0U)
    {
        return 0U;
    }

    return 1U;
}

/**
 * @brief  Check whether the handle accepts a new operation.
 * @note   ARCH-CONST-09: a handle that is BUSY (an operation is ongoing in
 *         another context) rejects any other operation with HAL_BUSY, and a
 *         handle that is not initialized (RESET) requires HAL_MAC_Init()
 *         first and is rejected with HAL_ERROR. The recoverable states TIMEOUT
 *         and ERROR accept a new operation directly.
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK (accepted) / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef MAC_CheckState(MAC_HandleTypeDef *hmac)
{
    if (hmac->State == HAL_MAC_STATE_BUSY)
    {
        return HAL_BUSY;
    }

    if (hmac->State == HAL_MAC_STATE_RESET)
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_MAC_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; the value is passed to HAL_MutexAcquire() as
 *         is (RTOS ticks; HAL_MAX_DELAY means an infinite wait).
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef MAC_LockHandle(MAC_HandleTypeDef *hmac, uint32 Timeout)
{
#if (USE_RTOS == 1)
    if (hmac->LockMutex == NULL_PTR)
    {
        /* The porting layer did not create the mutex (e.g. HAL_MAC_MspInit()
         * was not overridden): report it instead of calling the RTOS with a
         * NULL handle */
        return HAL_ERROR;
    }

    return HAL_MutexAcquire(hmac->LockMutex, Timeout);
#else
    /* Prevent unused argument compilation warning: the bare-metal lock flag
     * either succeeds immediately or reports HAL_BUSY, it never waits */
    UNUSED(Timeout);

    if (hmac->Lock == HAL_LOCKED)
    {
        return HAL_BUSY;
    }

    hmac->Lock = HAL_LOCKED;

    return HAL_OK;
#endif /* USE_RTOS */
}

/**
 * @brief  Unlock the handle.
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @retval None
 */
void MAC_UnlockHandle(MAC_HandleTypeDef *hmac)
{
#if (USE_RTOS == 1)
    (void)HAL_MutexRelease(hmac->LockMutex);
#else
    hmac->Lock = HAL_UNLOCKED;
#endif /* USE_RTOS */
}

/**
  * @brief  Adjusts the transmit packet length to ensure it does not exceed
  *         the maximum allowable size.
  * @param  tx_length: The original length of the packet to be transmitted.
  * @retval uint32: The adjusted packet length (original length or the
  *                 maximum allowable size if the original exceeds it).
  */
static uint32 MAC_AdjustTxPktLength(uint32 tx_length)
{
    uint32 adjusted_tx_pkt_length;

    if (tx_length > MAC_MAX_PACKET_SIZE)
    {
        adjusted_tx_pkt_length = MAC_MAX_PACKET_SIZE;
    }
    else
    {
        adjusted_tx_pkt_length = tx_length;
    }

    return adjusted_tx_pkt_length;
}

/**
  * @brief  Retrieves the length of the received packet from the descriptor,
  *         stripping off the CRC if present.
  * @param  descriptor0: The value of the descriptor's first word, which
  *                      contains the packet length and status.
  * @retval uint32: The length of the received packet, with CRC stripped.
  *                 Returns 0 if the descriptor is still owned by DMA.
  */
static uint32 MAC_GetRxPacketLength(uint32 descriptor0)
{
    uint32 pckt_length;

    if ((descriptor0 & RDES0_OWN) != 0U)
    {
        /* Current descriptor is empty */
        pckt_length = 0U;
    }
    else
    {
        pckt_length = (descriptor0 >> RDES0_FL_OFFSET) & RDES0_FL_MASK;

        /* strip crc */
        if (pckt_length > 4U)
        {
            pckt_length -= 4U;
        }
        else
        {
            pckt_length = 0U;
        }
    }

    return pckt_length;
}

/**
 * @brief  Issue the MAC software reset (BUS_MODE.SWR).
 * @note   Tier 3 helper: it performs the register access only, without any
 *         lock, state or parameter handling. HAL_MAC_Init() uses it so that
 *         no public interface is called inside its locked region (LOCK-05);
 *         HAL_MAC_SoftwareReset() wraps it for the direct callers.
 * @param  hmac: pointer to a MAC_HandleTypeDef structure.
 * @retval None
 */
static void MAC_SoftwareResetInternal(MAC_HandleTypeDef *hmac)
{
    /* Reset all internal triggers */
    hmac->Instance->BUS_MODE |= MAC_BUS_MODE_SWR;
}

/** @addtogroup MAC_Exported_Functions
  * @{
  */

/** @addtogroup MAC_Exported_Functions_Group1
  *  @brief   Initialization and de-initialization functions.
  * @{
  */

/**
  * @brief  Initializes the MAC peripheral. (BLOCKING)
  * @note   This function performs a software reset (BUS_MODE.SWR), waits for
  *         the reset to complete, then configures the DMA bus mode
  *         (BUS_MODE), the operation mode (OPT_MODE) and the general timer /
  *         interrupt suppression control (TIMER_CTRL) registers according to
  *         the MAC_InitTypeDef fields. It does not start the receiver /
  *         transmitter: the start/stop is controlled by HAL_MAC_Start()/
  *         HAL_MAC_Stop() or by the per-direction HAL_MAC_ReceiveCmd() /
  *         HAL_MAC_TransmitCmd().
  * @param  hmac: pointer to a MAC_HandleTypeDef structure that contains
  *               the configuration information for MAC.
  * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_TIMEOUT.
  */
HAL_StatusTypeDef HAL_MAC_Init(MAC_HandleTypeDef *hmac)
{
    uint32 tmpreg = 0U;
    uint32 tickstart = 0U;

    /* Check the MAC handle and instance */
    if (MAC_HandleIsValid(hmac) == 0U)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_MAC_ALL_INSTANCE(hmac->Instance));
    assert_param(IS_VALID_MAC_AutoPollInterval(hmac->Init.MAC_AutoPollInterval));
    assert_param(IS_VALID_MAC_DESCRIPTOR_BYTE_ENDIAN(hmac->Init.MAC_DescriptorByteEndianMode));
    assert_param(IS_VALID_MAC_PROGRAMMABLE_PULSE_LENGTH(hmac->Init.MAC_ProgrammablePulseLength));
    assert_param(IS_VALID_MAC_DATA_ENDIAN(hmac->Init.MAC_DataEndianMode));
    assert_param(IS_VALID_MAC_DESCRIPTOR_SKIP_LENGTH(hmac->Init.MAC_DescriptorSkipLength));
    assert_param(IS_VALID_MAC_BUS_ARBITRATION_SCHEME(hmac->Init.MAC_BusArbitrationScheme));
    assert_param(IS_VALID_MAC_RECEIVE_ALL(hmac->Init.MAC_ReceiveAll));
    assert_param(IS_VALID_MAC_FIFO_THRESHOLD_MODE(hmac->Init.MAC_TransmitThresholdMode));
    assert_param(IS_VALID_MAC_STORE_AND_FORWARD(hmac->Init.MAC_StoreandForward));
    assert_param(IS_VALID_MAC_THRESHOLD_CONTROL_BITS(hmac->Init.MAC_ThresholdControlBits));
    assert_param(IS_VALID_MAC_TRANSMIT_MODE(hmac->Init.MAC_TransmitMode));
    assert_param(IS_VALID_MAC_PASSALL_MULTICASTS(hmac->Init.MAC_PassAllMulticast));
    assert_param(IS_VALID_MAC_PROMISCUOUS_MODE(hmac->Init.MAC_PromiscuousMode));
    assert_param(IS_VALID_MAC_PASS_BAD_FRAME(hmac->Init.MAC_PassBadFrame));
    assert_param(IS_VALID_MAC_TIMERWORK_MODE(hmac->Init.MAC_ContinuousMode));
    assert_param(IS_VALID_MAC_TIMER_VALUE(hmac->Init.MAC_TimerValue));
    assert_param(IS_VALID_MAC_PHY_ADDRESS(hmac->Init.MAC_PhyAddress));

    /* Run time parameter validation, so that the checks stay effective in a
     * build with the assertions disabled. The metafields of the configuration
     * structure (Size / Version, architecture spec section 22) and the two
     * reserved words are validated as well. A rejected call neither takes the
     * lock nor changes the handle state nor touches a register. */
    if ((IS_MAC_ALL_INSTANCE(hmac->Instance) == 0U) ||
        (hmac->Init.Size != sizeof(MAC_InitTypeDef)) ||
        (hmac->Init.Version != MAC_INIT_VERSION) ||
        (IS_VALID_MAC_AutoPollInterval(hmac->Init.MAC_AutoPollInterval) == 0U) ||
        (IS_VALID_MAC_DESCRIPTOR_BYTE_ENDIAN(hmac->Init.MAC_DescriptorByteEndianMode) == 0U) ||
        (IS_VALID_MAC_PROGRAMMABLE_PULSE_LENGTH(hmac->Init.MAC_ProgrammablePulseLength) == 0U) ||
        (IS_VALID_MAC_DATA_ENDIAN(hmac->Init.MAC_DataEndianMode) == 0U) ||
        (IS_VALID_MAC_DESCRIPTOR_SKIP_LENGTH(hmac->Init.MAC_DescriptorSkipLength) == 0U) ||
        (IS_VALID_MAC_BUS_ARBITRATION_SCHEME(hmac->Init.MAC_BusArbitrationScheme) == 0U) ||
        (IS_VALID_MAC_RECEIVE_ALL(hmac->Init.MAC_ReceiveAll) == 0U) ||
        (IS_VALID_MAC_FIFO_THRESHOLD_MODE(hmac->Init.MAC_TransmitThresholdMode) == 0U) ||
        (IS_VALID_MAC_STORE_AND_FORWARD(hmac->Init.MAC_StoreandForward) == 0U) ||
        (IS_VALID_MAC_THRESHOLD_CONTROL_BITS(hmac->Init.MAC_ThresholdControlBits) == 0U) ||
        (IS_VALID_MAC_TRANSMIT_MODE(hmac->Init.MAC_TransmitMode) == 0U) ||
        (IS_VALID_MAC_PASSALL_MULTICASTS(hmac->Init.MAC_PassAllMulticast) == 0U) ||
        (IS_VALID_MAC_PROMISCUOUS_MODE(hmac->Init.MAC_PromiscuousMode) == 0U) ||
        (IS_VALID_MAC_PASS_BAD_FRAME(hmac->Init.MAC_PassBadFrame) == 0U) ||
        (IS_VALID_MAC_TIMERWORK_MODE(hmac->Init.MAC_ContinuousMode) == 0U) ||
        (IS_VALID_MAC_TIMER_VALUE(hmac->Init.MAC_TimerValue) == 0U) ||
        (IS_VALID_MAC_PHY_ADDRESS(hmac->Init.MAC_PhyAddress) == 0U) ||
        (hmac->Init.Reserved[0] != 0U) ||
        (hmac->Init.Reserved[1] != 0U))
    {
        hmac->ErrorCode |= HAL_MAC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Allocate the lock resource before its first use, so that a handle that
     * was never initialized cannot report HAL_BUSY from a stale Lock field.
     * LOCK-06: the low level initialization runs before the handle is locked,
     * so that an override which calls other HAL APIs cannot deadlock. */
    if (hmac->State == HAL_MAC_STATE_RESET)
    {
        hmac->Lock = HAL_UNLOCKED;
        /* Init the low level hardware : CLOCK, reset, NVIC. */
        HAL_MAC_MspInit(hmac);
    }

    /* Process locked */
    if (MAC_LockHandle(hmac, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    hmac->State = HAL_MAC_STATE_BUSY;
    hmac->ErrorCode = HAL_MAC_ERROR_NONE;

    /* Software reset: reset all internal triggers. LOCK-05: the reset is
       issued through the private helper, so that no public interface is called
       inside the locked region. */
    MAC_SoftwareResetInternal(hmac);

    /* Get tick */
    tickstart = HAL_GetTick();

    /* Wait for reset to complete */
    while ((hmac->Instance->BUS_MODE & MAC_BUS_MODE_SWR) != RESET)
    {
        /* RTOS-04/05: yield the CPU so that a task polling the peripheral does
           not starve the other tasks (empty macro in a bare-metal build) */
        HAL_RTOS_Yield();

        /* Check for the Timeout */
        if ((HAL_GetTick() - tickstart) > MAC_TIMEOUT_SWRESET)
        {
            hmac->State = HAL_MAC_STATE_TIMEOUT;
            hmac->ErrorCode |= HAL_MAC_ERROR_TIMEOUT;

            /* Process Unlocked */
            MAC_UnlockHandle(hmac);

            return HAL_TIMEOUT;
        }
    }

    /*----------------------------- MAC BUS_MODE ----------------------------*/
    /* Set Descriptor byte sort mode, Transmit auto poll interval,
       Programmable pulse length, Data byte sort mode, Descriptor skip length
       and Bus arbitration scheme. */
    tmpreg = hmac->Instance->BUS_MODE;
    tmpreg &= ~((uint32)(MAC_BUS_MODE_BAR | MAC_BUS_MODE_DSL |
                         MAC_BUS_MODE_BLE | MAC_BUS_MODE_PBL |
                         MAC_BUS_MODE_TAP | MAC_BUS_MODE_DBO));
    tmpreg |= (((uint32)hmac->Init.MAC_DescriptorByteEndianMode << 20) |
               ((uint32)hmac->Init.MAC_AutoPollInterval << 17)             |
               ((uint32)hmac->Init.MAC_ProgrammablePulseLength << 8)       |
               ((uint32)hmac->Init.MAC_DataEndianMode << 7)                |
               ((uint32)hmac->Init.MAC_DescriptorSkipLength << 2)          |
               ((uint32)hmac->Init.MAC_BusArbitrationScheme << 1));
    hmac->Instance->BUS_MODE = tmpreg;

    /*---------------------------- MAC TIMER_CTRL ---------------------------*/
    /* Set Transmitting and receiving period, Transmit Timer, Transmit Packet
       Number, Receive Timer, Receive Packet number, Timer Continuous mode
       and Timer value. */
    tmpreg = hmac->Instance->TIMER_CTRL;
    tmpreg &= ~((uint32)(MAC_TIMER_CTRL_TIM | MAC_TIMER_CTRL_CON |
                         MAC_TIMER_CTRL_NRP | MAC_TIMER_CTRL_RT |
                         MAC_TIMER_CTRL_TT | MAC_TIMER_CTRL_CS));
    tmpreg |= (((uint32)hmac->Init.MAC_CycleSize << 31)             |
               ((uint32)hmac->Init.MAC_TransmitTimer << 27)         |
               ((uint32)hmac->Init.MAC_TransmitPacketNumber << 24)  |
               ((uint32)hmac->Init.MAC_ReceiveTimer << 20)          |
               ((uint32)hmac->Init.MAC_ReceivePacketNumber << 17)   |
               ((uint32)hmac->Init.MAC_ContinuousMode << 16)        |
               ((uint32)hmac->Init.MAC_TimerValue << 0));
    hmac->Instance->TIMER_CTRL = tmpreg;

    /*----------------------------- MAC OPT_MODE ----------------------------*/
    /* Set Receive All, Transmit Threshold Mode, Store and Forward, Threshold
       Control Bit, Transmit Mode, Pass All Multicast, Promiscuous Mode and
       Pass Bad Frame. */
    tmpreg = hmac->Instance->OPT_MODE;
    tmpreg &= ~((uint32)(MAC_OPT_MODE_PB | MAC_OPT_MODE_PR |
                         MAC_OPT_MODE_PM | MAC_OPT_MODE_FD |
                         MAC_OPT_MODE_TR | MAC_OPT_MODE_SF |
                         MAC_OPT_MODE_TTM | MAC_OPT_MODE_RA));
    tmpreg |= ((uint32)hmac->Init.MAC_ReceiveAll << 30)               |
              ((uint32)hmac->Init.MAC_TransmitThresholdMode << 22)    |
              ((uint32)hmac->Init.MAC_StoreandForward << 21)          |
              ((uint32)hmac->Init.MAC_ThresholdControlBits << 15)     |
              ((uint32)hmac->Init.MAC_TransmitMode << 9)              |
              ((uint32)hmac->Init.MAC_PassAllMulticast << 7)          |
              ((uint32)hmac->Init.MAC_PromiscuousMode << 6)           |
              ((uint32)hmac->Init.MAC_PassBadFrame << 3);
    hmac->Instance->OPT_MODE = tmpreg;

    hmac->State = HAL_MAC_STATE_READY;

    /* Process Unlocked */
    MAC_UnlockHandle(hmac);

    return HAL_OK;
}

/**
  * @brief  DeInitializes the MAC peripheral. (NON-BLOCKING)
  * @note   The MAC clock is gated by the SMU APB0CFGR register: the
  *         de-initialization clears then sets the MACRST bit (the reset is
  *         asserted by clearing and released by setting it). The user must
  *         still call HAL_MAC_MspDeInit() to switch off the clock.
  * @param  hmac: pointer to a MAC_HandleTypeDef structure that contains
  *               the configuration information for MAC.
  * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
  */
HAL_StatusTypeDef HAL_MAC_DeInit(MAC_HandleTypeDef *hmac)
{
    /* Check the MAC handle and instance */
    if (MAC_HandleIsValid(hmac) == 0U)
    {
        return HAL_ERROR;
    }

    /* Process locked. ARCH-CONST-09: the de-initialization is callable from
     * any handle state, so that a failed initialization can always be undone */
    if (MAC_LockHandle(hmac, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hmac->ErrorCode = HAL_MAC_ERROR_NONE;
    hmac->State = HAL_MAC_STATE_BUSY;

    /* Reset the MAC through the SMU APB0CFGR.MACRST bit: the reset is asserted
     * by CLEARING the bit and released by SETTING it, so the pulse is
     * "clear then set" (SET = released, CLEAR = reset asserted). */
    SMU->APB0CFGR &= ~((uint32)SMU_APB0CFGR_MACRST);
    SMU->APB0CFGR |= (uint32)SMU_APB0CFGR_MACRST;

    /* Reset the state */
    hmac->State = HAL_MAC_STATE_RESET;

    /* Release Lock */
    MAC_UnlockHandle(hmac);

    /* LOCK-06 / ARCH-CONST-04: the low level de-initialization runs OUTSIDE
     * the locked region, as the architecture specification requires for the
     * MSP callbacks ("MspDeInit is called after the unlock") */
    HAL_MAC_MspDeInit(hmac);

    return HAL_OK;
}

/**
  * @brief  Initializes the MAC MSP. (NON-BLOCKING)
  * @note   This weak function is empty by default. The MAC clock is gated by
  *         the SMU APB0CFGR register (SMU_APB0CFGR_MACEN bit) and the MAC
  *         reset is released with the SMU_APB0CFGR_MACRST bit. The MAC has a
  *         dedicated PLIC interrupt line (MAC_IRQn = 0x18): the user must
  *         enable the clock, release the reset, enable the PLIC line and
  *         implement MAC_IRQ_Handler() calling HAL_MAC_IRQHandler().
  * @param  hmac: pointer to a MAC_HandleTypeDef structure that contains
  *               the configuration information for MAC.
  * @retval None
  */
__weak void HAL_MAC_MspInit(MAC_HandleTypeDef *hmac)
{
    /* Prevent unused argument(s) compilation warning */
    (void)hmac;

    /* NOTE : This function should not be modified. When the callback is needed,
              function HAL_MAC_MspInit must be implemented in the user file.
    */
}

/**
  * @brief  DeInitializes the MAC MSP. (NON-BLOCKING)
  * @param  hmac: pointer to a MAC_HandleTypeDef structure that contains
  *               the configuration information for MAC.
  * @retval None
  */
__weak void HAL_MAC_MspDeInit(MAC_HandleTypeDef *hmac)
{
    /* Prevent unused argument(s) compilation warning */
    (void)hmac;

    /* NOTE : This function should not be modified. When the callback is needed,
              function HAL_MAC_MspDeInit must be implemented in the user file.
    */
}

/**
  * @}
  */

/** @addtogroup MAC_Exported_Functions_Group2
  *  @brief   IO operation functions.
  * @{
  */

/**
  * @brief  Transmits a network packet using the transmit descriptor stored in (NON-BLOCKING)
  *         the handle (hmac->TxDesc).
  * @note   The chip uses a one-descriptor-per-frame transmit model: the first
  *         and last segment bits (TDES1_FS / TDES1_LS) are both set. The
  *         transmit poll demand is issued (TX_POLL) and the transmitter is
  *         started.
  * @param  hmac: pointer to a MAC_HandleTypeDef structure.
  * @param  FrameLength: the length of the frame to be transmitted.
  * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
  */
HAL_StatusTypeDef HAL_MAC_TransmitFrame(MAC_HandleTypeDef *hmac, uint32 FrameLength)
{
    /* Check the MAC handle and instance */
    if (MAC_HandleIsValid(hmac) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_MAC_ALL_INSTANCE(hmac->Instance));

    /* Run time parameter validation, so that the checks stay effective in a
     * build with the assertions disabled */
    if ((IS_MAC_ALL_INSTANCE(hmac->Instance) == 0U) || (hmac->TxDesc == NULL_PTR))
    {
        hmac->ErrorCode |= HAL_MAC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: state gate */
    if (MAC_CheckState(hmac) != HAL_OK)
    {
        return MAC_CheckState(hmac);
    }

    /* Process locked */
    if (MAC_LockHandle(hmac, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hmac->ErrorCode = HAL_MAC_ERROR_NONE;
    hmac->State = HAL_MAC_STATE_BUSY;

    if ((hmac->TxDesc->descriptor_0 & TDES0_OWN) == RESET)
    {
        /* Disable transmitter */
        __HAL_MAC_TX_DISABLE(hmac);

        /* Each buffer can hold a full frame, so it is always the first and
           last descriptor */
        hmac->TxDesc->descriptor_1 = TDES1_TCH | TDES1_LS | TDES1_FS |
                                     (MAC_AdjustTxPktLength(FrameLength) << 0U);
        /* The descriptor is DMA owned */
        hmac->TxDesc->descriptor_0 = TDES0_OWN;

        CLEAR_CACHE();

        /* Transmit Poll Demand */
        __HAL_MAC_TX_POLL_DEMAND(hmac);
        /* Enable transmitter */
        __HAL_MAC_TX_ENABLE(hmac);

        hmac->State = HAL_MAC_STATE_READY;

        /* Release Lock */
        MAC_UnlockHandle(hmac);

        return HAL_OK;
    }
    else
    {
        /* Descriptor is still owned by the DMA: report the hardware side
           condition through the error code and leave the handle ready, so
           that the call can simply be retried */
        hmac->ErrorCode |= HAL_MAC_ERROR_HARDWARE;
        hmac->State = HAL_MAC_STATE_READY;

        /* Release Lock */
        MAC_UnlockHandle(hmac);

        return HAL_ERROR;
    }
}

/**
  * @brief  Receives a network packet using the receive descriptor stored in (NON-BLOCKING)
  *         the handle (hmac->RxDesc), copies the frame payload into RxBuff
  *         and returns its length.
  * @note   The packet length reported by the DMA (RDES0.FL) is stripped of the
  *         4-byte CRC. The receive descriptor is re-armed and the receiver
  *         is started.
  * @param  hmac: pointer to a MAC_HandleTypeDef structure.
  * @param  RxBuff: pointer to the buffer where the received data will be
  *                 stored.
  * @param  Length: pointer to a variable where the length of the received
  *                 data will be stored.
  * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
  */
HAL_StatusTypeDef HAL_MAC_GetReceivedFrame(MAC_HandleTypeDef *hmac, uint8 *RxBuff, uint32 *Length)
{
    uint8 *read_buffer;

    /* Check the MAC handle and instance */
    if (MAC_HandleIsValid(hmac) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_MAC_ALL_INSTANCE(hmac->Instance));

    /* Run time parameter validation, so that the checks stay effective in a
     * build with the assertions disabled */
    if ((IS_MAC_ALL_INSTANCE(hmac->Instance) == 0U) || (hmac->RxDesc == NULL_PTR) ||
        (RxBuff == NULL_PTR) || (Length == NULL_PTR))
    {
        hmac->ErrorCode |= HAL_MAC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: state gate */
    if (MAC_CheckState(hmac) != HAL_OK)
    {
        return MAC_CheckState(hmac);
    }

    /* Process locked */
    if (MAC_LockHandle(hmac, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hmac->ErrorCode = HAL_MAC_ERROR_NONE;
    hmac->State = HAL_MAC_STATE_BUSY;

    if ((hmac->RxDesc->descriptor_0 & RDES0_OWN) == RESET)
    {
        /* Get the length of data and buffer address */
        *Length = MAC_GetRxPacketLength(hmac->RxDesc->descriptor_0);
        read_buffer = (uint8 *)(hmac->RxDesc->buffer_1);

        /* Get data */
        memcpy(RxBuff, read_buffer, *Length);

        /* Set receive descriptor */
        hmac->RxDesc->descriptor_1 = RDES1_RCH | (uint32)MAC_MAX_PACKET_SIZE;
        hmac->RxDesc->descriptor_0 = RDES0_OWN | (3U << 8);

        CLEAR_CACHE();

        __HAL_MAC_RX_ENABLE(hmac);

        hmac->State = HAL_MAC_STATE_READY;

        /* Release Lock */
        MAC_UnlockHandle(hmac);

        return HAL_OK;
    }
    else
    {
        /* Descriptor is still owned by the DMA: report the hardware side
           condition through the error code and leave the handle ready, so
           that the call can simply be retried */
        hmac->ErrorCode |= HAL_MAC_ERROR_HARDWARE;
        hmac->State = HAL_MAC_STATE_READY;

        /* Release Lock */
        MAC_UnlockHandle(hmac);

        return HAL_ERROR;
    }
}

/**
  * @brief  Enables the MAC receiver and transmitter. (NON-BLOCKING)
  * @note   Sets both the OPT_MODE.SR (start receive) and OPT_MODE.ST (start
  *         transmit) command bits.
  * @param  hmac: pointer to a MAC_HandleTypeDef structure.
  * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
  */
HAL_StatusTypeDef HAL_MAC_Start(MAC_HandleTypeDef *hmac)
{
    /* Check the MAC handle and instance */
    if (MAC_HandleIsValid(hmac) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_MAC_ALL_INSTANCE(hmac->Instance));

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (HAL_MAC_Init() is required
     * first) */
    if (MAC_CheckState(hmac) != HAL_OK)
    {
        return MAC_CheckState(hmac);
    }

    /* Process locked */
    if (MAC_LockHandle(hmac, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hmac->ErrorCode = HAL_MAC_ERROR_NONE;
    hmac->State = HAL_MAC_STATE_BUSY;

    /* Enable Receive and Transmit Command */
    __HAL_MAC_RX_ENABLE(hmac);
    __HAL_MAC_TX_ENABLE(hmac);

    hmac->State = HAL_MAC_STATE_READY;

    /* Release Lock */
    MAC_UnlockHandle(hmac);

    return HAL_OK;
}

/**
  * @brief  Disables the MAC receiver and transmitter. (NON-BLOCKING)
  * @note   Clears both the OPT_MODE.SR and OPT_MODE.ST command bits.
  * @param  hmac: pointer to a MAC_HandleTypeDef structure.
  * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
  */
HAL_StatusTypeDef HAL_MAC_Stop(MAC_HandleTypeDef *hmac)
{
    /* Check the MAC handle and instance */
    if (MAC_HandleIsValid(hmac) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_MAC_ALL_INSTANCE(hmac->Instance));

    /* ARCH-CONST-09: reject the call when another operation is ongoing (busy)
     * or when the handle has not been initialized (HAL_MAC_Init() is required
     * first) */
    if (MAC_CheckState(hmac) != HAL_OK)
    {
        return MAC_CheckState(hmac);
    }

    /* Process locked */
    if (MAC_LockHandle(hmac, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hmac->ErrorCode = HAL_MAC_ERROR_NONE;
    hmac->State = HAL_MAC_STATE_BUSY;

    /* Disable Receive and Transmit Command */
    __HAL_MAC_RX_DISABLE(hmac);
    __HAL_MAC_TX_DISABLE(hmac);

    hmac->State = HAL_MAC_STATE_READY;

    /* Release Lock */
    MAC_UnlockHandle(hmac);

    return HAL_OK;
}

/**
  * @brief  Start / stop the MAC receiver. (NON-BLOCKING)
  * @note   This command toggles the OPT_MODE.SR start-receive command bit.
  * @param  hmac: pointer to a MAC_HandleTypeDef structure.
  * @param  NewState: ENABLE to start the receiver, DISABLE to stop it.
  * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
  */
HAL_StatusTypeDef HAL_MAC_ReceiveCmd(MAC_HandleTypeDef *hmac, FunctionalState NewState)
{
    /* Check the MAC handle and instance */
    if (MAC_HandleIsValid(hmac) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_MAC_ALL_INSTANCE(hmac->Instance));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Run time parameter validation, so that the checks stay effective in a
     * build with the assertions disabled */
    if ((IS_MAC_ALL_INSTANCE(hmac->Instance) == 0U) ||
        (IS_FUNCTIONAL_STATE(NewState) == 0U))
    {
        hmac->ErrorCode |= HAL_MAC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: state gate */
    if (MAC_CheckState(hmac) != HAL_OK)
    {
        return MAC_CheckState(hmac);
    }

    /* Process locked */
    if (MAC_LockHandle(hmac, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hmac->ErrorCode = HAL_MAC_ERROR_NONE;
    hmac->State = HAL_MAC_STATE_BUSY;

    if (NewState != DISABLE)
    {
        /* Enable Receive Command */
        __HAL_MAC_RX_ENABLE(hmac);
    }
    else
    {
        /* Disable Receive Command */
        __HAL_MAC_RX_DISABLE(hmac);
    }

    hmac->State = HAL_MAC_STATE_READY;

    /* Release Lock */
    MAC_UnlockHandle(hmac);

    return HAL_OK;
}

/**
  * @brief  Start / stop the MAC transmitter. (NON-BLOCKING)
  * @note   This command toggles the OPT_MODE.ST start-transmit command bit.
  * @param  hmac: pointer to a MAC_HandleTypeDef structure.
  * @param  NewState: ENABLE to start the transmitter, DISABLE to stop it.
  * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
  */
HAL_StatusTypeDef HAL_MAC_TransmitCmd(MAC_HandleTypeDef *hmac, FunctionalState NewState)
{
    /* Check the MAC handle and instance */
    if (MAC_HandleIsValid(hmac) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_MAC_ALL_INSTANCE(hmac->Instance));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Run time parameter validation, so that the checks stay effective in a
     * build with the assertions disabled */
    if ((IS_MAC_ALL_INSTANCE(hmac->Instance) == 0U) ||
        (IS_FUNCTIONAL_STATE(NewState) == 0U))
    {
        hmac->ErrorCode |= HAL_MAC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: state gate */
    if (MAC_CheckState(hmac) != HAL_OK)
    {
        return MAC_CheckState(hmac);
    }

    /* Process locked */
    if (MAC_LockHandle(hmac, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hmac->ErrorCode = HAL_MAC_ERROR_NONE;
    hmac->State = HAL_MAC_STATE_BUSY;

    if (NewState != DISABLE)
    {
        /* Enable Transmit Command */
        __HAL_MAC_TX_ENABLE(hmac);
    }
    else
    {
        /* Disable Transmit Command */
        __HAL_MAC_TX_DISABLE(hmac);
    }

    hmac->State = HAL_MAC_STATE_READY;

    /* Release Lock */
    MAC_UnlockHandle(hmac);

    return HAL_OK;
}

/**
  * @brief  Sets the transmit descriptor used by HAL_MAC_TransmitFrame() and (NON-BLOCKING)
  *         writes its base address into the TDES_BASE_ADDR register.
  * @note   The descriptor becomes the handle transmit descriptor.
  * @param  hmac: pointer to a MAC_HandleTypeDef structure.
  * @param  TxDesc: pointer to the transmit descriptor.
  * @param  Addr: the transmit descriptor base address (TDES_BASE_ADDR value).
  * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
  */
HAL_StatusTypeDef HAL_MAC_SetTxDescriptor(MAC_HandleTypeDef *hmac, mac_tx_descriptor_t *TxDesc, uint32 Addr)
{
    /* Check the MAC handle and instance */
    if (MAC_HandleIsValid(hmac) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_MAC_ALL_INSTANCE(hmac->Instance));

    /* Run time parameter validation, so that the checks stay effective in a
     * build with the assertions disabled; a NULL descriptor would be accepted
     * by the register write and only fail later in HAL_MAC_TransmitFrame() */
    if ((IS_MAC_ALL_INSTANCE(hmac->Instance) == 0U) || (TxDesc == NULL_PTR))
    {
        hmac->ErrorCode |= HAL_MAC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: state gate */
    if (MAC_CheckState(hmac) != HAL_OK)
    {
        return MAC_CheckState(hmac);
    }

    /* Process locked */
    if (MAC_LockHandle(hmac, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hmac->ErrorCode = HAL_MAC_ERROR_NONE;
    hmac->State = HAL_MAC_STATE_BUSY;

    hmac->TxDesc = TxDesc;

    /* Set Transmit Descriptor Address */
    hmac->Instance->TDES_BASE_ADDR = Addr;

    hmac->State = HAL_MAC_STATE_READY;

    /* Release Lock */
    MAC_UnlockHandle(hmac);

    return HAL_OK;
}

/**
  * @brief  Sets the receive descriptor used by HAL_MAC_GetReceivedFrame() and (NON-BLOCKING)
  *         writes its base address into the RDES_BASE_ADDR register.
  * @note   The descriptor becomes the handle receive descriptor.
  * @param  hmac: pointer to a MAC_HandleTypeDef structure.
  * @param  RxDesc: pointer to the receive descriptor.
  * @param  Addr: the receive descriptor base address (RDES_BASE_ADDR value).
  * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR.
  */
HAL_StatusTypeDef HAL_MAC_SetRxDescriptor(MAC_HandleTypeDef *hmac, mac_rx_descriptor_t *RxDesc, uint32 Addr)
{
    /* Check the MAC handle and instance */
    if (MAC_HandleIsValid(hmac) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_MAC_ALL_INSTANCE(hmac->Instance));

    /* Run time parameter validation, so that the checks stay effective in a
     * build with the assertions disabled; a NULL descriptor would be accepted
     * by the register write and only fail later in HAL_MAC_GetReceivedFrame() */
    if ((IS_MAC_ALL_INSTANCE(hmac->Instance) == 0U) || (RxDesc == NULL_PTR))
    {
        hmac->ErrorCode |= HAL_MAC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: state gate */
    if (MAC_CheckState(hmac) != HAL_OK)
    {
        return MAC_CheckState(hmac);
    }

    /* Process locked */
    if (MAC_LockHandle(hmac, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hmac->ErrorCode = HAL_MAC_ERROR_NONE;
    hmac->State = HAL_MAC_STATE_BUSY;

    hmac->RxDesc = RxDesc;

    /* Set Receive Descriptor Address */
    hmac->Instance->RDES_BASE_ADDR = Addr;

    hmac->State = HAL_MAC_STATE_READY;

    /* Release Lock */
    MAC_UnlockHandle(hmac);

    return HAL_OK;
}

/**
  * @}
  */

/** @addtogroup MAC_Exported_Functions_Group3
  *  @brief   Peripheral control functions.
  * @{
  */

/**
  * @brief  Resets all the MAC internal triggers (BUS_MODE.SWR). (NON-BLOCKING)
  * @note   The reset is asynchronous: HAL_MAC_Init() waits for BUS_MODE.SWR
  *         to clear before configuring the registers.
  * @param  hmac: pointer to a MAC_HandleTypeDef structure.
  * @retval None
  */
HAL_StatusTypeDef HAL_MAC_SoftwareReset(MAC_HandleTypeDef *hmac)
{
    /* Check the MAC handle and instance */
    if (MAC_HandleIsValid(hmac) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_MAC_ALL_INSTANCE(hmac->Instance));

    /* ARCH-CONST-09: state gate */
    if (MAC_CheckState(hmac) != HAL_OK)
    {
        return MAC_CheckState(hmac);
    }

    /* Process locked */
    if (MAC_LockHandle(hmac, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hmac->ErrorCode = HAL_MAC_ERROR_NONE;
    hmac->State = HAL_MAC_STATE_BUSY;

    /* Reset all internal triggers */
    MAC_SoftwareResetInternal(hmac);

    hmac->State = HAL_MAC_STATE_READY;

    /* Release Lock */
    MAC_UnlockHandle(hmac);

    return HAL_OK;
}

/**
  * @brief  Fills each MAC_InitStruct member with its default value. (NON-BLOCKING)
  * @note   The default values are applied to every MAC_InitTypeDef field,
  *         including the driver-added MAC_PhyAddress field (default 0).
  * @param  MAC_InitStruct: pointer to a MAC_InitTypeDef structure which will
  *                         be initialized.
  * @retval None
  */
void HAL_MAC_StructInit(MAC_InitTypeDef *MAC_InitStruct)
{
    /* Check the MAC init structure allocation */
    if (MAC_InitStruct == NULL_PTR)
    {
        return;
    }

    MAC_InitStruct->Size                            = sizeof(MAC_InitTypeDef); /*!< sizeof struct */
    MAC_InitStruct->Version                         = MAC_INIT_VERSION;        /*!< V1            */
    MAC_InitStruct->MAC_AutoPollInterval          = MAC_AutoPollInterval_Disable;
    MAC_InitStruct->MAC_DescriptorByteEndianMode  = MAC_DescriptorEndianMode_Little;
    MAC_InitStruct->MAC_ProgrammablePulseLength   = MAC_ProgrammablePulseLength_8;
    MAC_InitStruct->MAC_DataEndianMode            = MAC_DataEndianMode_Little;
    MAC_InitStruct->MAC_DescriptorSkipLength      = 0x00;
    MAC_InitStruct->MAC_BusArbitrationScheme      = MAC_BuArbitrations_EqualPriority;
    MAC_InitStruct->MAC_ReceiveAll                = MAC_ReceiveAll_Disable;
    MAC_InitStruct->MAC_TransmitThresholdMode     = MAC_FIFOThreshold_10M;
    MAC_InitStruct->MAC_StoreandForward           = MAC_StoreandForward_Disable;
    MAC_InitStruct->MAC_ThresholdControlBits      = MAC_ThresholdControlBits_Disable;
    MAC_InitStruct->MAC_TransmitMode              = MAC_TransmitMode_FullDuplex;
    MAC_InitStruct->MAC_PassAllMulticast          = MAC_PassAllMulticasts_Enable;
    MAC_InitStruct->MAC_PromiscuousMode           = MAC_PromiscuousMode_Enable;
    MAC_InitStruct->MAC_PassBadFrame              = MAC_PassBadFrame_Disable;
    MAC_InitStruct->MAC_ContinuousMode            = MAC_TimerWorkMode_OneShot;
    MAC_InitStruct->MAC_CycleSize                 = 0;
    MAC_InitStruct->MAC_TimerValue                = 0;
    MAC_InitStruct->MAC_TransmitPacketNumber      = 0;
    MAC_InitStruct->MAC_ReceiveTimer              = 0;
    MAC_InitStruct->MAC_ReceivePacketNumber       = 0;
    MAC_InitStruct->MAC_TransmitTimer             = 0;
    MAC_InitStruct->MAC_PhyAddress                = 0;
}

/**
  * @brief  Gets the status of the MAC receiving and transmitting process. (NON-BLOCKING)
  * @note   It reads the STATUS.RS (receive process state) or STATUS.TS
  *         (transmit process state) field.
  * @param  hmac: pointer to a MAC_HandleTypeDef structure.
  * @param  Process: specifies the process status to read. This parameter can
  *                  be one of the following values:
  *                    @arg MAC_PROCESS_RECEIVE: Receiving process
  *                    @arg MAC_PROCESS_TRANSMIT: Transmitting process
  * @retval uint8: The value of the process status.
  */
uint8 HAL_MAC_GetProcessStatus(MAC_HandleTypeDef *hmac, uint32 Process)
{
    uint8 status = 0;

    /* Check the MAC handle allocation */
    if (hmac == NULL_PTR)
    {
        return 0U;
    }

    assert_param(IS_MAC_ALL_INSTANCE(hmac->Instance));
    assert_param(IS_MAC_PROCESS(Process));

    if (Process == MAC_PROCESS_RECEIVE)
    {
        /* Get Receive Process Status */
        status = (uint8)(hmac->Instance->STATUS & MAC_STATUS_RS);
    }
    else if (Process == MAC_PROCESS_TRANSMIT)
    {
        /* Get Transmit Process Status */
        status = (uint8)(hmac->Instance->STATUS & MAC_STATUS_TS);
    }

    return status;
}

/**
  * @brief  Enables or disables the specified MAC interrupts. (NON-BLOCKING)
  * @note   The interrupt source enable values (MAC_IT_* with the INT_ENABLE
  *         bit positions) are written into the INT_ENABLE register.
  * @param  hmac: pointer to a MAC_HandleTypeDef structure.
  * @param  MAC_IT: the MAC interrupt sources to enable or disable. This
  *                 parameter can be one or a combination of the following
  *                 values:
  *                   @arg MAC_IT_NIE: Normal Interrupt Summary
  *                   @arg MAC_IT_AIE: Abnormal Interrupt Summary
  *                   @arg MAC_IT_ERE: Early Receive Interrupt
  *                   @arg MAC_IT_GTE: General Timer Interrupt
  *                   @arg MAC_IT_ETE: Early Transmit Interrupt
  *                   @arg MAC_IT_RSE: Receive Process Stopped
  *                   @arg MAC_IT_RUE: Receive Buffer Unavailable
  *                   @arg MAC_IT_RIE: Receive Interrupt
  *                   @arg MAC_IT_UNE: Transmit Underflow
  *                   @arg MAC_IT_TUE: Transmit Buffer Unavailable
  *                   @arg MAC_IT_TSE: Transmit Process Stopped
  *                   @arg MAC_IT_TIE: Transmit Interrupt
  * @param  NewState: the new state of the interrupts (ENABLE or DISABLE).
  * @retval None
  */
void HAL_MAC_ITConfig(MAC_HandleTypeDef *hmac, uint32 MAC_IT, FunctionalState NewState)
{
    /* Check the MAC handle allocation */
    if (hmac == NULL_PTR)
    {
        return;
    }

    assert_param(IS_MAC_ALL_INSTANCE(hmac->Instance));
    assert_param(IS_MAC_IT(MAC_IT));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    if (NewState != DISABLE)
    {
        /* Enable the selected MAC interrupt */
        __HAL_MAC_ENABLE_IT(hmac, MAC_IT);
    }
    else
    {
        /* Disable the selected MAC interrupt */
        __HAL_MAC_DISABLE_IT(hmac, MAC_IT);
    }
}

/**
  * @brief  Checks whether the specified MAC flag is set or not. (NON-BLOCKING)
  * @note   The flag values (MAC_Flag_*) are read from the STATUS register.
  * @param  hmac: pointer to a MAC_HandleTypeDef structure.
  * @param  MAC_FLAG: the flag to check. This parameter can be one of the
  *                   following values:
  *                     @arg MAC_Flag_NIS: Normal Interrupt Summary
  *                     @arg MAC_Flag_AIS: Abnormal Interrupt Summary
  *                     @arg MAC_Flag_ERI: Early Receive Interrupt
  *                     @arg MAC_Flag_GTE: General Timer Interrupt
  *                     @arg MAC_Flag_ETI: Early Transmit Interrupt
  *                     @arg MAC_Flag_RPS: Receive Process Stopped
  *                     @arg MAC_Flag_RU: Receive Buffer Unavailable
  *                     @arg MAC_Flag_RI: Receive Interrupt
  *                     @arg MAC_Flag_UNF: Transmit Underflow
  *                     @arg MAC_Flag_TU: Transmit Buffer Unavailable
  *                     @arg MAC_Flag_TPS: Transmit Process Stopped
  *                     @arg MAC_Flag_TI: Transmit Interrupt
  * @retval FlagStatus: SET or RESET.
  */
FlagStatus HAL_MAC_GetFlagStatus(MAC_HandleTypeDef *hmac, uint32 MAC_FLAG)
{
    FlagStatus bitstatus = RESET;

    /* Check the MAC handle allocation */
    if (hmac == NULL_PTR)
    {
        return RESET;
    }

    assert_param(IS_MAC_ALL_INSTANCE(hmac->Instance));
    assert_param(IS_MAC_FLAG(MAC_FLAG));

    if ((hmac->Instance->STATUS & MAC_FLAG) != (uint32)RESET)
    {
        bitstatus = SET;
    }
    else
    {
        bitstatus = RESET;
    }

    return bitstatus;
}

/**
  * @brief  Clears the specified MAC interrupt status flag. (NON-BLOCKING)
  * @note   The STATUS register bits are cleared by writing a 1. The clear values
  *         (MAC_IT_* with STATUS bit positions) equal the corresponding
  *         MAC_Flag_* values.
  * @param  hmac: pointer to a MAC_HandleTypeDef structure.
  * @param  MAC_IT: the interrupt flag to clear. This parameter can be one of
  *                 the following values:
  *                   @arg MAC_IT_NIS: Normal Interrupt Summary
  *                   @arg MAC_IT_AIS: Abnormal Interrupt Summary
  *                   @arg MAC_IT_ERI: Early Receive Interrupt
  *                   @arg MAC_IT_GTE: General Timer Interrupt
  *                   @arg MAC_IT_ETI: Early Transmit Interrupt
  *                   @arg MAC_IT_RPS: Receive Process Stopped
  *                   @arg MAC_IT_RU: Receive Buffer Unavailable
  *                   @arg MAC_IT_RI: Receive Interrupt
  *                   @arg MAC_IT_UNF: Transmit Underflow
  *                   @arg MAC_IT_TU: Transmit Buffer Unavailable
  *                   @arg MAC_IT_TPS: Transmit Process Stopped
  *                   @arg MAC_IT_TI: Transmit Interrupt
  * @retval None
  */
void HAL_MAC_ClearITStatus(MAC_HandleTypeDef *hmac, uint32 MAC_IT)
{
    /* Check the MAC handle allocation */
    if (hmac == NULL_PTR)
    {
        return;
    }

    assert_param(IS_MAC_ALL_INSTANCE(hmac->Instance));
    assert_param(IS_MAC_ClearIT(MAC_IT));

    /* Clear the STATUS flag (write 1) */
    __HAL_MAC_CLEAR_IT(hmac, MAC_IT);
}

/**
  * @}
  */

/** @addtogroup MAC_Exported_Functions_Group4
  *  @brief   MDIO / PHY management functions.
  * @{
  */

/**
  * @brief  Enables or disables the MDIO clock. (NON-BLOCKING)
  * @note   This command toggles the MDIO_CTRL0.MDCE bit.
  * @param  hmac: pointer to a MAC_HandleTypeDef structure.
  * @param  NewState: ENABLE or DISABLE.
  * @retval None
  */
HAL_StatusTypeDef HAL_MAC_MDIOClockCmd(MAC_HandleTypeDef *hmac, FunctionalState NewState)
{
    /* Check the MAC handle and instance */
    if (MAC_HandleIsValid(hmac) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_MAC_ALL_INSTANCE(hmac->Instance));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    /* Run time parameter validation, so that the checks stay effective in a
     * build with the assertions disabled */
    if ((IS_MAC_ALL_INSTANCE(hmac->Instance) == 0U) ||
        (IS_FUNCTIONAL_STATE(NewState) == 0U))
    {
        hmac->ErrorCode |= HAL_MAC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: state gate */
    if (MAC_CheckState(hmac) != HAL_OK)
    {
        return MAC_CheckState(hmac);
    }

    /* Process locked */
    if (MAC_LockHandle(hmac, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hmac->ErrorCode = HAL_MAC_ERROR_NONE;
    hmac->State = HAL_MAC_STATE_BUSY;

    if (NewState != DISABLE)
    {
        /* Enable MDIO Clock */
        hmac->Instance->MDIO_CTRL0 |= MAC_MDIO_CTRL0_MDCE;
    }
    else
    {
        /* Disable MDIO Clock */
        hmac->Instance->MDIO_CTRL0 &= ~MAC_MDIO_CTRL0_MDCE;
    }

    hmac->State = HAL_MAC_STATE_READY;

    /* Release Lock */
    MAC_UnlockHandle(hmac);

    return HAL_OK;
}

/**
  * @brief  Sets the MAC MDC prescaler value. (NON-BLOCKING)
  * @note   It writes the MDIO_CTRL0.MDC_DIV prescaler field. The MDC clock rate
  *         is derived from the APB clock divided by this prescaler.
  * @param  hmac: pointer to a MAC_HandleTypeDef structure.
  * @param  MAC_Prescaler: the MAC MDC prescaler value (MDIO_CTRL0.MDC_DIV).
  * @retval None
  */
HAL_StatusTypeDef HAL_MAC_SetMDCPrescaler(MAC_HandleTypeDef *hmac, uint16 MAC_Prescaler)
{
    /* Check the MAC handle and instance */
    if (MAC_HandleIsValid(hmac) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_MAC_ALL_INSTANCE(hmac->Instance));

    /* ARCH-CONST-09: state gate */
    if (MAC_CheckState(hmac) != HAL_OK)
    {
        return MAC_CheckState(hmac);
    }

    /* Process locked */
    if (MAC_LockHandle(hmac, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hmac->ErrorCode = HAL_MAC_ERROR_NONE;
    hmac->State = HAL_MAC_STATE_BUSY;

    /* Set MAC MDC prescaler value */
    hmac->Instance->MDIO_CTRL0 &= ~MAC_MDIO_CTRL0_MDC_DIV;
    hmac->Instance->MDIO_CTRL0 |= MAC_Prescaler;

    hmac->State = HAL_MAC_STATE_READY;

    /* Release Lock */
    MAC_UnlockHandle(hmac);

    return HAL_OK;
}

/**
  * @brief  Reads data from a register of the specified external PHY. (BLOCKING)
  * @note   The PHY address is taken from hmac->Init.MAC_PhyAddress and the
  *         operation
  *         completes by polling the MDIO_CTRL1.ACK bit.
  * @param  hmac: pointer to a MAC_HandleTypeDef structure.
  * @param  PHYReg: the PHY register address (0-31).
  * @param  RegValue: pointer to the register value read.
  * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_TIMEOUT.
  */
HAL_StatusTypeDef HAL_MAC_ReadPHYRegister(MAC_HandleTypeDef *hmac, uint16 PHYReg, uint32 *RegValue)
{
    uint32 tmpreg = 0U;
    uint32 tickstart = 0U;

    /* Check the MAC handle and instance */
    if (MAC_HandleIsValid(hmac) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_MAC_ALL_INSTANCE(hmac->Instance));
    assert_param(IS_VALID_MAC_PHY_ADDRESS(hmac->Init.MAC_PhyAddress));
    assert_param(IS_VALID_MAC_PHY_ADDRESS(PHYReg));

    /* Run time parameter validation, so that the checks stay effective in a
     * build with the assertions disabled */
    if ((IS_MAC_ALL_INSTANCE(hmac->Instance) == 0U) ||
        (IS_VALID_MAC_PHY_ADDRESS(hmac->Init.MAC_PhyAddress) == 0U) ||
        (IS_VALID_MAC_PHY_ADDRESS(PHYReg) == 0U) ||
        (RegValue == NULL_PTR))
    {
        hmac->ErrorCode |= HAL_MAC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: state gate */
    if (MAC_CheckState(hmac) != HAL_OK)
    {
        return MAC_CheckState(hmac);
    }

    /* Process locked */
    if (MAC_LockHandle(hmac, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hmac->ErrorCode = HAL_MAC_ERROR_NONE;
    hmac->State = HAL_MAC_STATE_BUSY;

    /* Configure the MDIO_CTRL1 register */
    tmpreg = hmac->Instance->MDIO_CTRL1;
    tmpreg &= ~((uint32)(MAC_MDIO_CTRL1_TURN    | MAC_MDIO_CTRL1_START1 |
                         MAC_MDIO_CTRL1_START0 | MAC_MDIO_CTRL1_PHY_ADDR |
                         MAC_MDIO_CTRL1_RDWR    | MAC_MDIO_CTRL1_REG_ADDR));
    tmpreg |= ((uint32)(hmac->Init.MAC_PhyAddress << 23) |
               (uint32)(PHYReg << 18)                    |
               MAC_MDIO_CTRL1_START0 | MAC_MDIO_CTRL1_RDWR_1);
    hmac->Instance->MDIO_CTRL1 = tmpreg;

    /* Get tick */
    tickstart = HAL_GetTick();

    /* Wait for the ACK bit */
    while ((hmac->Instance->MDIO_CTRL1 & MAC_MDIO_CTRL1_ACK) == RESET)
    {
        /* RTOS-04/05: yield the CPU so that a task polling the peripheral does
           not starve the other tasks (empty macro in a bare-metal build) */
        HAL_RTOS_Yield();

        /* Check for the Timeout */
        if ((HAL_GetTick() - tickstart) > MAC_MDIO_TIMEOUT_VALUE)
        {
            hmac->ErrorCode |= HAL_MAC_ERROR_TIMEOUT;
            hmac->State = HAL_MAC_STATE_TIMEOUT;

            /* Release Lock */
            MAC_UnlockHandle(hmac);

            return HAL_TIMEOUT;
        }
    }

    /* Read the PHY register data */
    *RegValue = (uint32)(hmac->Instance->MDIO_CTRL1 & MAC_MDIO_CTRL1_RDATA);

    hmac->State = HAL_MAC_STATE_READY;

    /* Release Lock */
    MAC_UnlockHandle(hmac);

    return HAL_OK;
}

/**
  * @brief  Writes data to a register of the specified external PHY. (BLOCKING)
  * @note   The PHY address is taken from hmac->Init.MAC_PhyAddress and the
  *         operation
  *         completes by polling the MDIO_CTRL1.ACK bit.
  * @param  hmac: pointer to a MAC_HandleTypeDef structure.
  * @param  PHYReg: the PHY register address (0-31).
  * @param  RegValue: the value to write.
  * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_TIMEOUT.
  */
HAL_StatusTypeDef HAL_MAC_WritePHYRegister(MAC_HandleTypeDef *hmac, uint16 PHYReg, uint32 RegValue)
{
    uint32 tmpreg = 0U;
    uint32 tickstart = 0U;

    /* Check the MAC handle and instance */
    if (MAC_HandleIsValid(hmac) == 0U)
    {
        return HAL_ERROR;
    }

    assert_param(IS_MAC_ALL_INSTANCE(hmac->Instance));
    assert_param(IS_VALID_MAC_PHY_ADDRESS(hmac->Init.MAC_PhyAddress));
    assert_param(IS_VALID_MAC_PHY_ADDRESS(PHYReg));
    assert_param(RegValue <= 0xFFFFU);

    /* Run time parameter validation, so that the checks stay effective in a
     * build with the assertions disabled */
    if ((IS_MAC_ALL_INSTANCE(hmac->Instance) == 0U) ||
        (IS_VALID_MAC_PHY_ADDRESS(hmac->Init.MAC_PhyAddress) == 0U) ||
        (IS_VALID_MAC_PHY_ADDRESS(PHYReg) == 0U) ||
        (RegValue > 0xFFFFU))
    {
        hmac->ErrorCode |= HAL_MAC_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: state gate */
    if (MAC_CheckState(hmac) != HAL_OK)
    {
        return MAC_CheckState(hmac);
    }

    /* Process locked */
    if (MAC_LockHandle(hmac, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Clear the error code and enter the busy state */
    hmac->ErrorCode = HAL_MAC_ERROR_NONE;
    hmac->State = HAL_MAC_STATE_BUSY;

    /* Configure the MDIO_CTRL1 register */
    tmpreg = hmac->Instance->MDIO_CTRL1;
    tmpreg &= ~((uint32)(MAC_MDIO_CTRL1_RDATA   | MAC_MDIO_CTRL1_TURN |
                         MAC_MDIO_CTRL1_START1 | MAC_MDIO_CTRL1_START0 |
                         MAC_MDIO_CTRL1_PHY_ADDR | MAC_MDIO_CTRL1_RDWR  |
                         MAC_MDIO_CTRL1_REG_ADDR));
    tmpreg |= ((uint32)(hmac->Init.MAC_PhyAddress << 23) |
               (uint32)(PHYReg << 18)                    |
               (uint32)(RegValue << 0)                   |
               MAC_MDIO_CTRL1_START0 | MAC_MDIO_CTRL1_RDWR_0 | MAC_MDIO_CTRL1_TURN_1);
    hmac->Instance->MDIO_CTRL1 = tmpreg;

    /* Get tick */
    tickstart = HAL_GetTick();

    /* Wait for the ACK bit */
    while ((hmac->Instance->MDIO_CTRL1 & MAC_MDIO_CTRL1_ACK) == RESET)
    {
        /* RTOS-04/05: yield the CPU so that a task polling the peripheral does
           not starve the other tasks (empty macro in a bare-metal build) */
        HAL_RTOS_Yield();

        /* Check for the Timeout */
        if ((HAL_GetTick() - tickstart) > MAC_MDIO_TIMEOUT_VALUE)
        {
            hmac->ErrorCode |= HAL_MAC_ERROR_TIMEOUT;
            hmac->State = HAL_MAC_STATE_TIMEOUT;

            /* Release Lock */
            MAC_UnlockHandle(hmac);

            return HAL_TIMEOUT;
        }
    }

    hmac->State = HAL_MAC_STATE_READY;

    /* Release Lock */
    MAC_UnlockHandle(hmac);

    return HAL_OK;
}

/**
  * @}
  */

/** @addtogroup MAC_Exported_Functions_Group5
  *  @brief   Interrupt processing functions.
  * @{
  */

/**
  * @brief  Handles the MAC interrupt request. (NON-BLOCKING)
  * @note   The chip MAC has a single PLIC interrupt line (MAC_IRQn = 0x18)
  *         shared by all STATUS interrupt sources. The user must implement
  *         MAC_IRQ_Handler() and call HAL_MAC_IRQHandler(). The receive /
  *         transmit complete flags trigger the HAL_MAC_RxCpltCallback() /
  *         HAL_MAC_TxCpltCallback() and the abnormal interrupt summary (AIS)
  *         triggers HAL_MAC_ErrorCallback().
  * @param  hmac: pointer to a MAC_HandleTypeDef structure.
  * @retval None
  */
void HAL_MAC_IRQHandler(MAC_HandleTypeDef *hmac)
{
    /* Check the MAC handle and instance. Interrupt context: this routine takes
       no lock and waits for nothing (ARCH-CONST-19) */
    if (MAC_HandleIsValid(hmac) == 0U)
    {
        return;
    }

    /* Frame received */
    if (__HAL_MAC_GET_FLAG(hmac, MAC_Flag_RI) != RESET)
    {
        /* Clear the receive interrupt pending bit first (R-FN-CPX-005:
         * flags are cleared before the business logic to avoid losing a
         * re-entrant interrupt) */
        __HAL_MAC_CLEAR_IT(hmac, MAC_IT_RI);

        hmac->State = HAL_MAC_STATE_READY;

        /* Receive complete callback */
        HAL_MAC_RxCpltCallback(hmac);
    }
    /* Frame transmitted */
    else if (__HAL_MAC_GET_FLAG(hmac, MAC_Flag_TI) != RESET)
    {
        /* Clear the transmit interrupt pending bit first (R-FN-CPX-005) */
        __HAL_MAC_CLEAR_IT(hmac, MAC_IT_TI);

        hmac->State = HAL_MAC_STATE_READY;

        /* Transfer complete callback */
        HAL_MAC_TxCpltCallback(hmac);
    }

    /* Clear the normal interrupt summary */
    __HAL_MAC_CLEAR_IT(hmac, MAC_IT_NIS);

    /* Abnormal Interrupt Summary */
    if (__HAL_MAC_GET_FLAG(hmac, MAC_Flag_AIS) != RESET)
    {
        /* Clear the abnormal interrupt summary first (R-FN-CPX-005) */
        __HAL_MAC_CLEAR_IT(hmac, MAC_IT_AIS);

        /* Report the hardware side condition: the abnormal summary covers the
         * transmit underflow / receive buffer unavailable / process stopped
         * sources. The error state is recoverable (the entry point of the next
         * operation clears the error code and returns to the ready state), so a
         * reporting task can retry. */
        hmac->ErrorCode |= HAL_MAC_ERROR_HARDWARE;
        hmac->State = HAL_MAC_STATE_ERROR;

        /* Ethernet error callback */
        HAL_MAC_ErrorCallback(hmac);
    }
}

/**
  * @brief  Transmit complete callback. (NON-BLOCKING)
  * @param  hmac: pointer to a MAC_HandleTypeDef structure.
  * @retval None
  */
__weak void HAL_MAC_TxCpltCallback(MAC_HandleTypeDef *hmac)
{
    /* Prevent unused argument(s) compilation warning */
    (void)hmac;

    /* NOTE : This function should not be modified. When the callback is needed,
              function HAL_MAC_TxCpltCallback could be implemented in the user file.
    */
}

/**
  * @brief  Receive complete callback. (NON-BLOCKING)
  * @param  hmac: pointer to a MAC_HandleTypeDef structure.
  * @retval None
  */
__weak void HAL_MAC_RxCpltCallback(MAC_HandleTypeDef *hmac)
{
    /* Prevent unused argument(s) compilation warning */
    (void)hmac;

    /* NOTE : This function should not be modified. When the callback is needed,
              function HAL_MAC_RxCpltCallback could be implemented in the user file.
    */
}

/**
  * @brief  MAC error callback. (NON-BLOCKING)
  * @param  hmac: pointer to a MAC_HandleTypeDef structure.
  * @retval None
  */
__weak void HAL_MAC_ErrorCallback(MAC_HandleTypeDef *hmac)
{
    /* Prevent unused argument(s) compilation warning */
    (void)hmac;

    /* NOTE : This function should not be modified. When the callback is needed,
              function HAL_MAC_ErrorCallback could be implemented in the user file.
    */
}

/**
  * @}
  */

/** @addtogroup MAC_Exported_Functions_Group6
  *  @brief   Peripheral State functions.
  * @{
  */

/**
  * @brief  Returns the MAC state. (NON-BLOCKING)
  * @param  hmac: pointer to a MAC_HandleTypeDef structure.
  * @retval HAL_MAC_StateTypeDef: The MAC state.
  */
HAL_MAC_StateTypeDef HAL_MAC_GetState(MAC_HandleTypeDef *hmac)
{
    /* Check the MAC handle allocation */
    if (hmac == NULL_PTR)
    {
        return HAL_MAC_STATE_RESET;
    }

    return hmac->State;
}

/**
  * @brief  Returns the MAC error code. (NON-BLOCKING)
  * @param  hmac: pointer to a MAC_HandleTypeDef structure.
  * @retval uint32: the MAC error code (HAL_MAC_ERROR_xxx).
  */
uint32 HAL_MAC_GetError(MAC_HandleTypeDef *hmac)
{
    /* Check the MAC handle allocation */
    if (hmac == NULL_PTR)
    {
        return HAL_MAC_ERROR_NONE;
    }

    return hmac->ErrorCode;
}

/**
  * @}
  */

/**
  * @}
  */

#endif /* HAL_MAC_MODULE_ENABLED */

/*****END OF FILE*****/
