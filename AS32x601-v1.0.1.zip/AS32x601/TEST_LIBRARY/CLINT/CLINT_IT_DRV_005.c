/**
 * @file    CLINT_IT_DRV_005.c
 * @brief   HAL CLINT integration test case 005 (64-bit real-time counter).
 *
 * One-to-one HAL library port of the original AS32x601 standard-library
 * test case CLINT_IT_DRV_005.c. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_CLINT_Init()
 *   HAL_CLINT_ReadTimerValue()
 *
 * Test procedure:
 *   1. Initialize the CLINT;
 *   2. Read the 64-bit counter 32 times back to back: check that the value
 *      never decreases (the counter is a free-running up counter) and that the
 *      high half does not change inside the short observation window;
 *   3. Measure the counter increment over a 1 s HAL delay and compare it with
 *      SystemCoreClock;
 *   4. Repeat steps 2..3 periodically.
 *
 * Expected behaviour:
 *   - All 32 samples are monotonically non-decreasing and share the same high
 *     half;
 *   - The measured increment over a 1 s delay equals SystemCoreClock
 *     (180 000 000 ticks), i.e. the CLINT real-time counter is clocked at the
 *     core clock frequency.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Number of back-to-back samples used for the monotonicity check */
#define SAMPLE_COUNT                (32U)

/* Duration of the tick rate measurement window */
#define TICK_WINDOW_MS              (1000U)

/* Accepted relative error of the tick rate measurement (percent) */
#define TICK_TOLERANCE_PERCENT      (1U)

/* Pause between two measurement rounds */
#define ROUND_PAUSE_MS              (1000U)

/* Private variables ---------------------------------------------------------*/
static HAL_CLINT_HandleTypeDef hclint;      /*!< CLINT handle                 */

static HAL_SMU_HandleTypeDef hsmu_clk;   /*!< SMU handle (lock / state / error) */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void test_CounterMonotonic(void);
static void test_CounterRate(void);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    uint32 round = 0U;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== CLINT_IT_DRV_005: 64-bit real-time counter ===\r\n");
    printf("SystemCoreClock = %u Hz\r\n", PRINT_U32(SystemCoreClock));

    /* Initialize the CLINT peripheral */
    hclint.Instance = CLINT;
    if (HAL_CLINT_Init(&hclint) != HAL_OK)
    {
        printf("HAL_CLINT_Init failed\r\n");
        while (1)
        {
        }
    }

    while (1)
    {
        round++;
        printf("\r\n--- round %u ---\r\n", PRINT_U32(round));

        test_CounterMonotonic();
        test_CounterRate();

        delay_ms(ROUND_PAUSE_MS);
    }
}

/**
 * @brief  Check that the 64-bit counter is a monotonic free-running counter.
 * @param  None
 * @retval None
 */
static void test_CounterMonotonic(void)
{
    uint64 first;
    uint64 prev;
    uint64 now;
    uint32 i;
    uint32 ok = 1U;

    first = HAL_CLINT_ReadTimerValue(&hclint);
    printf("first sample    = 0x%08X%08X\r\n",
           PRINT_U32(first >> 32U), PRINT_U32(first));

    prev = first;

    for (i = 0U; i < SAMPLE_COUNT; i++)
    {
        now = HAL_CLINT_ReadTimerValue(&hclint);

        if (now < prev)
        {
            ok = 0U;
            printf("  [FAIL] sample %u decreased: 0x%08X%08X -> 0x%08X%08X\r\n",
                   PRINT_U32(i), PRINT_U32(prev >> 32U), PRINT_U32(prev),
                   PRINT_U32(now >> 32U), PRINT_U32(now));
        }
        else if ((now >> 32U) != (prev >> 32U))
        {
            ok = 0U;
            printf("  [FAIL] high half changed inside the window at sample %u\r\n",
                   PRINT_U32(i));
        }

        prev = now;
    }

    now = HAL_CLINT_ReadTimerValue(&hclint);
    printf("last sample     = 0x%08X%08X, delta = %u ticks\r\n",
           PRINT_U32(now >> 32U), PRINT_U32(now), PRINT_U32(now - first));
    printf("monotonic       : [%s]\r\n", (ok != 0U) ? "PASS" : "FAIL");
}

/**
 * @brief  Measure the CLINT counter increment over a 1 s HAL delay.
 * @param  None
 * @retval None
 */
static void test_CounterRate(void)
{
    uint64 start;
    uint64 stop;
    uint64 ticks;
    uint64 expected;
    uint64 tolerance;
    uint64 diff;
    uint32 ok;

    /* Measure */
    start = HAL_CLINT_ReadTimerValue(&hclint);
    delay_ms(TICK_WINDOW_MS);
    stop  = HAL_CLINT_ReadTimerValue(&hclint);

    ticks     = stop - start;
    expected  = (uint64)SystemCoreClock;                    /* 1 s at core clock */
    tolerance = expected / (uint64)TICK_TOLERANCE_PERCENT / 100U;
    diff      = (ticks > expected) ? (ticks - expected) : (expected - ticks);

    ok = (diff <= tolerance) ? 1U : 0U;

    printf("ticks per %u ms = %u (expected %u, +-%u%%) [%s]\r\n",
           PRINT_U32(TICK_WINDOW_MS), PRINT_U32(ticks), PRINT_U32(expected),
           PRINT_U32(TICK_TOLERANCE_PERCENT), (ok != 0U) ? "PASS" : "FAIL");
}

/**
 * @brief  Configure the system clock tree using the HAL SMU driver.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef  SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef   SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it (CLKFRQ above), so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Clock tree order: this is the order the chip requires, and the vendor
       test case uses the same one.
         1. Write the bus clock dividers while the system clock is still the
            power-on source (FIRC), so that the new divider values are already
            in place when the faster clock arrives. Writing them AFTER the
            switch instead leaves the buses at their reset dividers for a
            moment at the new core clock: at 180 MHz that is
            AXI4Bus3 = 90 MHz and APBBus0 = 45 MHz, right at their ratings, and
            the core does not survive it (measured on the board: the core
            trapped before the divider write was reached, so no output was
            produced at all).
         2. Program the EFLASH controller clock: the controller must already
            know the final frequency while the code still runs from the flash.
         3. Then configure the PLL and switch the system clock to it; this call
            also updates SystemCoreClock and re-initializes the HAL time base. */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
