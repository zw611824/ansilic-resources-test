/**
 * @file    PMU_IT_DRV_024.c
 * @brief   HAL PMU integration test case 024 (MSP callbacks and handle life cycle).
 *
 * Extension case of the suite: it makes the two low level callbacks of the
 * driver observable (they are weak empty functions in the driver, so the case
 * overrides them with strong definitions that count the calls and record the
 * handle state they observe) and checks the handle life cycle rules the driver
 * implements on top of the standard-library original.
 *
 * Tested functionality:
 *   HAL_PMU_Init() / HAL_PMU_DeInit()
 *   HAL_PMU_MspInit() / HAL_PMU_MspDeInit() (overridden weak callbacks)
 *   __HAL_PMU_RESET_HANDLE_STATE()
 *   HAL_PMU_GetState() / HAL_PMU_GetError()
 *   HAL_PMU_LDO1v2VOLSca() (used as a configuration API that goes through the
 *   state gate)
 *
 * Test procedure:
 *   1. Before the first initialization the callbacks must not have run;
 *   2. The first HAL_PMU_Init() runs the low level initialization exactly once,
 *      and it runs it while the handle is still in the RESET state and its lock
 *      is released (the MSP callback runs before the handle is locked);
 *   3. A second HAL_PMU_Init() on an initialized handle must NOT run the low
 *      level initialization again (it would reset the hardware behind the
 *      driver's back);
 *   4. HAL_PMU_DeInit() runs the low level de-initialization exactly once, and
 *      by then the handle is already back in the RESET state (the callback runs
 *      after the unlock, so it may use the HAL API safely);
 *   5. De-initializing an already de-initialized handle runs the callback again
 *      (the driver does not keep a "was initialized" flag) but leaves the state
 *      in RESET, which is what makes a failed initialization recoverable;
 *   6. __HAL_PMU_RESET_HANDLE_STATE() forces a READY handle back to RESET, so
 *      that the next initialization runs the low level initialization again;
 *   7. NULL and invalid handles are refused without running the callbacks.
 *
 * Expected behaviour:
 *   - every check prints PASS and the summary stays at zero failures;
 *   - the case never enters a power mode and never changes a rail that the
 *     running system depends on (only the core LDO is re-written with its
 *     current value).
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Current (already scaled) core rail value: the case re-writes this value */
#define TEST_VO12_SAFE              (PMU_VO12_1V34)

/* Reporting period of the final loop (ms) */
#define TEST_POLL_MS                (1000U)

/* Private variables ---------------------------------------------------------*/
static HAL_PMU_HandleTypeDef hpmu_dev;      /*!< PMU device handle            */
static uint32                failures = 0U; /*!< failed checks                */
static uint32                checks = 0U;   /*!< executed checks              */

/* Observations of the low level callbacks */
static volatile uint32 msp_init_calls = 0U;     /*!< MspInit() invocations    */
static volatile uint32 msp_deinit_calls = 0U;   /*!< MspDeInit() invocations  */
static volatile uint32 msp_init_state = 0xFFU;  /*!< state seen by MspInit()  */
static volatile uint32 msp_init_lock = 0xFFU;   /*!< lock seen by MspInit()   */
static volatile uint32 msp_deinit_state = 0xFFU;/*!< state seen by MspDeInit() */

static HAL_SMU_HandleTypeDef hsmu_clk;   /*!< SMU handle (lock / state / error) */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void Section(const char *name);
static void Check(const char *name, uint32 condition);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    HAL_PMU_HandleTypeDef bad_handle;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL, 45 MHz core clock) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n\r\n==== PMU_IT_DRV_024: MSP callbacks and handle life cycle ====\r\n");
    printf("Data : %s\r\n", __DATE__);
    printf("Time : %s\r\n", __TIME__);

    /* ==================================================================== *
     *  Group 1: the callbacks have not run yet
     * ==================================================================== */
    Section("Group 1: callbacks before the first initialization");

    printf("MspInit calls = %u, MspDeInit calls = %u\r\n",
           PRINT_U32(msp_init_calls), PRINT_U32(msp_deinit_calls));
    Check("no MSP callback ran before Init", (msp_init_calls == 0U));
    Check("no de-init callback ran before Init", (msp_deinit_calls == 0U));

    __HAL_CLEAR_STRUCT(&hpmu_dev);
    hpmu_dev.Instance = PMU;
    Check("state is RESET before Init",
          (HAL_PMU_GetState(&hpmu_dev) == HAL_PMU_STATE_RESET));

    /* ==================================================================== *
     *  Group 2: the first initialization runs the low level init once
     * ==================================================================== */
    Section("Group 2: first initialization");

    Check("PMU init", (HAL_PMU_Init(&hpmu_dev) == HAL_OK));
    Check("state READY after Init",
          (HAL_PMU_GetState(&hpmu_dev) == HAL_PMU_STATE_READY));
    Check("error code clear after Init",
          (HAL_PMU_GetError(&hpmu_dev) == HAL_PMU_ERROR_NONE));

    printf("MspInit calls = %u, state seen = %u, lock seen = %u\r\n",
           PRINT_U32(msp_init_calls), PRINT_U32(msp_init_state),
           PRINT_U32(msp_init_lock));
    Check("low level init ran exactly once", (msp_init_calls == 1U));
    Check("low level init saw the RESET state",
          (msp_init_state == (uint32)HAL_PMU_STATE_RESET));
    Check("low level init saw a released lock",
          (msp_init_lock == (uint32)HAL_UNLOCKED));

    /* ==================================================================== *
     *  Group 3: a second initialization does not touch the low level layer
     * ==================================================================== */
    Section("Group 3: second initialization");

    Check("second Init accepted", (HAL_PMU_Init(&hpmu_dev) == HAL_OK));
    printf("MspInit calls after the second Init = %u\r\n", PRINT_U32(msp_init_calls));
    Check("low level init not repeated on a READY handle", (msp_init_calls == 1U));
    Check("state READY after the second Init",
          (HAL_PMU_GetState(&hpmu_dev) == HAL_PMU_STATE_READY));

    /* a configuration API still works (it goes through the state gate) */
    Check("configuration API accepted on a READY handle",
          (HAL_PMU_LDO1v2VOLSca(&hpmu_dev, TEST_VO12_SAFE) == HAL_OK));

    /* ==================================================================== *
     *  Group 4: de-initialization runs the low level de-init once
     * ==================================================================== */
    Section("Group 4: de-initialization");

    Check("DeInit accepted", (HAL_PMU_DeInit(&hpmu_dev) == HAL_OK));
    printf("MspDeInit calls = %u, state seen = %u\r\n",
           PRINT_U32(msp_deinit_calls), PRINT_U32(msp_deinit_state));
    Check("low level de-init ran exactly once", (msp_deinit_calls == 1U));
    Check("de-init callback saw the RESET state",
          (msp_deinit_state == (uint32)HAL_PMU_STATE_RESET));
    Check("state RESET after DeInit",
          (HAL_PMU_GetState(&hpmu_dev) == HAL_PMU_STATE_RESET));
    Check("error code clear after DeInit",
          (HAL_PMU_GetError(&hpmu_dev) == HAL_PMU_ERROR_NONE));

    /* the configuration APIs are gated again */
    Check("configuration API refused after DeInit",
          (HAL_PMU_LDO1v2VOLSca(&hpmu_dev, TEST_VO12_SAFE) == HAL_ERROR));

    /* ==================================================================== *
     *  Group 5: re-initialization and the reset-state macro
     * ==================================================================== */
    Section("Group 5: re-initialization / __HAL_PMU_RESET_HANDLE_STATE");

    Check("re-Init accepted after DeInit", (HAL_PMU_Init(&hpmu_dev) == HAL_OK));
    Check("low level init ran again after DeInit", (msp_init_calls == 2U));

    /* the macro returns a READY handle to RESET without touching the hardware:
     * the next initialization then re-runs the low level initialization, which
     * is what a failing peripheral needs */
    __HAL_PMU_RESET_HANDLE_STATE(&hpmu_dev);
    Check("macro returns the handle to RESET",
          (HAL_PMU_GetState(&hpmu_dev) == HAL_PMU_STATE_RESET));

    Check("Init accepted after the macro", (HAL_PMU_Init(&hpmu_dev) == HAL_OK));
    Check("low level init ran after the macro", (msp_init_calls == 3U));

    /* DeInit on an already de-initialized handle: the driver has no separate
     * "initialized" flag, so the callback runs again, but the state stays in
     * RESET and the call still succeeds (a failed initialization can always be
     * undone) */
    Check("DeInit accepted again", (HAL_PMU_DeInit(&hpmu_dev) == HAL_OK));
    Check("second DeInit accepted", (HAL_PMU_DeInit(&hpmu_dev) == HAL_OK));
    printf("MspDeInit calls after two extra DeInit = %u\r\n", PRINT_U32(msp_deinit_calls));
    Check("de-init callback ran for every DeInit", (msp_deinit_calls == 3U));
    Check("state still RESET", (HAL_PMU_GetState(&hpmu_dev) == HAL_PMU_STATE_RESET));

    /* ==================================================================== *
     *  Group 6: NULL and invalid handles never reach the callbacks
     * ==================================================================== */
    Section("Group 6: NULL / invalid handle protection");

    Check("Init(NULL) refused", (HAL_PMU_Init(NULL_PTR) == HAL_ERROR));
    Check("DeInit(NULL) refused", (HAL_PMU_DeInit(NULL_PTR) == HAL_ERROR));

    /* an invalid instance is refused as well: the driver checks the instance
     * before it touches a register or a callback */
    __HAL_CLEAR_STRUCT(&bad_handle);
    bad_handle.Instance = (PMU_TypeDef *)0x40000000U;
    Check("Init with an invalid instance refused",
          (HAL_PMU_Init(&bad_handle) == HAL_ERROR));
    Check("DeInit with an invalid instance refused",
          (HAL_PMU_DeInit(&bad_handle) == HAL_ERROR));

    printf("MspInit calls = %u, MspDeInit calls = %u after the refused calls\r\n",
           PRINT_U32(msp_init_calls), PRINT_U32(msp_deinit_calls));
    Check("no low level init ran for the refused calls", (msp_init_calls == 3U));
    Check("no low level de-init ran for the refused calls", (msp_deinit_calls == 3U));

    /* ==================================================================== *
     *  Group 7: the PMU is left initialized for the final report
     * ==================================================================== */
    Section("Group 7: final state");

    Check("final Init accepted", (HAL_PMU_Init(&hpmu_dev) == HAL_OK));
    Check("final state READY",
          (HAL_PMU_GetState(&hpmu_dev) == HAL_PMU_STATE_READY));
    Check("low level init ran for the final Init", (msp_init_calls == 4U));

    printf("\r\nfinal : checks = %u, failures = %u\r\n",
           PRINT_U32(checks), PRINT_U32(failures));

    while (1)
    {
        printf("state = %u | MspInit = %u | MspDeInit = %u | checks = %u | summary : failures = %u\r\n",
               PRINT_U32(HAL_PMU_GetState(&hpmu_dev)),
               PRINT_U32(msp_init_calls), PRINT_U32(msp_deinit_calls),
               PRINT_U32(checks), PRINT_U32(failures));
        delay_ms(TEST_POLL_MS);
    }
}

/**
 * @brief  Low level initialization callback (strong override of the weak one).
 * @note   The driver calls it only while the handle is in the RESET state and
 *         before the handle is locked, so the recorded values shall be
 *         HAL_PMU_STATE_RESET / HAL_UNLOCKED. It must not call a PMU API that
 *         takes the lock (the lock is not held here, so such a call would work,
 *         but it would recurse into the driver during the initialization).
 * @note   Only the handle of this test case is counted: the clock setup of the
 *         suite initializes a local PMU handle of its own (for the rail
 *         scaling), and that initialization must not disturb the counters.
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @retval None
 */
void HAL_PMU_MspInit(HAL_PMU_HandleTypeDef *hpmu)
{
    if (hpmu != &hpmu_dev)
    {
        return;
    }

    msp_init_calls++;
    msp_init_state = (uint32)hpmu->State;
    msp_init_lock  = (uint32)hpmu->Lock;
}

/**
 * @brief  Low level de-initialization callback (strong override of the weak one).
 * @note   The driver calls it after the unlock and after the state went back to
 *         RESET, so the HAL API is safe to use here (LOCK-06).
 * @param  hpmu: pointer to a HAL_PMU_HandleTypeDef structure.
 * @retval None
 */
void HAL_PMU_MspDeInit(HAL_PMU_HandleTypeDef *hpmu)
{
    if (hpmu != &hpmu_dev)
    {
        return;
    }

    msp_deinit_calls++;
    msp_deinit_state = (uint32)hpmu->State;
}

/**
 * @brief  Print the header of a test group.
 * @param  name: group name.
 * @retval None
 */
static void Section(const char *name)
{
    printf("\r\n-- %s --\r\n", name);
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    checks++;

    if (condition == 0U)
    {
        failures++;
    }
    printf("%-52s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Configure the system clock tree using the HAL SMU driver.
 * @note   Clock tree shared by every integration test suite of this library:
 *         OSC 20 MHz as the PLL source, PLLDivR = 0x04 / PLLDivN = 0x14 /
 *         PLLDivF = 0xB4 / PLLDivQ = 0x01 -> 45 MHz core clock, then
 *         AXI4Bus3 = /2, APBBus0 = /2, APBBus1 = /2 and CANX2 = /8.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Bus dividers, then the system clock source is the PLL as requested */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
