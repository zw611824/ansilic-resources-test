/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:        as32x601_hal_gpio.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.13
 * Date:            2026/10/20
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/19     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/07     1.1     add the Size / Version
 *                                                       metafields and the
 *                                                       Reserved array to the
 *                                                       GPIO_InitTypeDef
 *                                                       structure (Version+Size
 *                                                       compatibility mechanism,
 *                                                       architecture spec
 *                                                       section 22); add the
 *                                                       GPIO_INIT_V1 /
 *                                                       GPIO_INIT_VERSION macros
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.4     align the version number of the four
 *                                                       module files; extend IS_GPIO_MODE /
 *                                                       IS_GPIO_PULL with the chip specific
 *                                                       values the driver actually implements
 *                                                       (GPIO_MODE_IDDQ, GPIO_PULLKEEP);
 *                                                       document the deliberate handle-less /
 *                                                       lock-free design of a Simple module
 *                                                       with its architecture basis; document
 *                                                       the run time parameter validation and
 *                                                       the companion include of the
 *                                                       extension header; add the doxygen
 *                                                       block of every public prototype
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.5     add the explicit RTOS
 *                                                       non-applicability statement: list the
 *                                                       RTOS rules that do not apply to a
 *                                                       handle-less Simple module (no polling
 *                                                       loop to yield in, no handle to carry
 *                                                       a mutex, no lock to time out) and the
 *                                                       one that is satisfied (the interrupt
 *                                                       handler takes no lock), so that the
 *                                                       absence of any RTOS specific code is
 *                                                       documented as a deliberate design
 *                                                       rather than an omission
 *     ANSILIC APPLICATION GROUP  2026/10/09     1.6     align the module header block with the rest
 *                                                       of the library (value column and the
 *                                                       "Version:" label) and restore the " *"
 *                                                       prefix of the 1.5 history continuation
 *                                                       lines
 *     ANSILIC APPLICATION GROUP  2026/10/10     1.7     state the pin availability rule of every interface
 *                                                       that takes a pin mask and document the ten channels
 *                                                       of the GPIOH port; align the version number and the
 *                                                       date of the four module files
 *     ANSILIC APPLICATION GROUP  2026/10/10     1.8     restate the relationship between this header and its extension: the
 *                                                       two headers include each other (safe thanks to the include guards),
 *                                                       so the extension header is self contained (architecture spec DEP-01)
 *     ANSILIC APPLICATION GROUP  2026/10/12     1.9     state that the drive constants select an output drive current
 *                                                       range (4.5 / 9 / 13.5 / 18 mA), not a slew rate and not
 *                                                       a frequency, and document the check macro, which had no
 *                                                       doxygen block at all
 *     ANSILIC APPLICATION GROUP  2026/10/12     1.10    rename the output drive current constants (GPIO_DRIVE_CURRENT_*),
 *                                                       the check macro (IS_GPIO_DRIVE_CURRENT) and the GPIO_InitTypeDef
 *                                                       member (DriveCurrent) so that no identifier suggests a slew rate:
 *                                                       the field selects the maximum output drive current written to OICR
 *     ANSILIC APPLICATION GROUP  2026/10/12     1.11    document that HAL_GPIO_DeInit() leaves the pins whose reset
 *                                                       default function is multiplexed untouched (GPIOx_PIN_DEFAULT_FUNC
 *                                                       in the extension header, controlled by
 *                                                       HAL_GPIO_DEINIT_PROTECT_DEFAULT_FUNC), at module level and on the
 *                                                       function prototype
 *     ANSILIC APPLICATION GROUP  2026/10/12     1.12    drop the pin mask parameter of HAL_GPIO_DeInit(): the prototype is
 *                                                       HAL_GPIO_DeInit(GPIOx) and the function restores the whole port (every channel
 *                                                       that exists on the port, the protected pins excepted)
 *     ANSILIC APPLICATION GROUP  2026/10/20     1.13    split the GPIO interrupt callback per port: HAL_GPIO_IRQHandler() now forwards every pending pin
 *                                                       to the weak callback of the port it was called for (HAL_GPIOA_EXTI_Callback() ...
 *                                                       HAL_GPIOH_EXTI_Callback()) instead of the single aggregated HAL_GPIO_EXTI_Callback(), because
 *                                                       the same bit position exists on every port and the aggregated callback could not tell
 *                                                       GPIOA Pin1 from GPIOC Pin1
 * Description:     This file contains all the functions prototypes for the GPIO HAL firmware library.
 *                  It declares the pin initialization / de-initialization and the basic IO operations
 *                  (read / write / toggle) plus the port interrupt handling for the GPIO peripheral.
 *                  The interrupt path raises one weak callback per port
 *                  (HAL_GPIOA_EXTI_Callback() ... HAL_GPIOH_EXTI_Callback()), selected by
 *                  HAL_GPIO_IRQHandler(), so the callback identifies the port and its parameter
 *                  identifies the pin of the event.
 *                  Prerequisite: the file "as32x601_hal_def.h" shall be provided by the user (HAL common
 *                  definitions: HAL_StatusTypeDef, HAL_LockTypeDef, HAL_MAX_DELAY, __HAL_LOCK/__HAL_UNLOCK,
 *                  HAL_GetTick(), ...).
 * @complexity  Simple
 *              Pin configuration plus IO read / write / toggle, no handle and
 *              no state machine, IT handling only.
 * @note  Deliberate behaviour - the module keeps the handle-less design of a
 *        Simple module (architecture spec section 4.1: "state machine: none",
 *        "handle: minimal", and the note that a Simple module such as GPIO
 *        drives the registers directly and returns immediately). The lock
 *        rules of section 13.1 apply to the APIs that move a handle into the
 *        BUSY state; this module has neither a handle nor a State field, so it
 *        takes no lock and provides no state gate. Consequence for the caller:
 *        two contexts configuring the same port at the same time may interleave
 *        on the read-modify-write register accesses of that port, and
 *        serialising such accesses (for example by configuring a port from one
 *        task only) is the responsibility of the application.
 * @note  Every public function validates its arguments at run time before the
 *        first register access, so that the checks stay effective in a build
 *        with the assertions disabled; a rejected call performs no register
 *        access at all. Since these functions return no status code (the module
 *        is a direct-return Simple module), a rejected call is reported through
 *        assert_param() in a USE_FULL_ASSERT build and is otherwise a no-op.
 * @note  Pin availability: every interface that takes a pin mask rejects a mask
 *        that names a pin which does not exist on the given port (see
 *        IS_GPIO_PIN_AVAILABLE). The GPIOH port exposes ten channels
 *        (Pin0..Pin9) only, so its channels 10..15 are refused; that port has
 *        no MI1SR register either. Ports A..G expose all sixteen channels.
 *        HAL_GPIO_IRQHandler() applies the same rule to its interrupt-status
 *        snapshot, so a callback is never raised for a non-existent pin.
 * @note  Interrupt callbacks: the driver has no single aggregated callback but
 *        one weak callback per port (HAL_GPIOA_EXTI_Callback(),
 *        HAL_GPIOB_EXTI_Callback(), ... HAL_GPIOH_EXTI_Callback()).
 *        HAL_GPIO_IRQHandler() is called with the port it serves and forwards
 *        every pending pin to the callback of that port, so the callback that
 *        is entered already identifies the port while its parameter (a single
 *        GPIO_PIN_x bit) identifies the pin. The split is required because the
 *        chip has one interrupt line per port and every port carries the same
 *        sixteen bit positions: with a single callback, bit 1 of GPIOA and
 *        bit 1 of GPIOC (both 0x0002) could not be told apart. An application
 *        implements the callbacks of the ports it uses only; the remaining weak
 *        definitions stay empty.
 * @note  HAL_GPIO_DeInit() restores the whole port (the function takes no pin
 *        mask), but it leaves the pins whose reset default function is a
 *        multiplexed function untouched, because those pins come out of reset
 *        already driving a specific interface, so resetting them to the plain
 *        GPIO default would drop that function: QSPI on GPIOA Pin8..Pin13,
 *        JTAG on GPIOB Pin5..Pin9, BOOT0 / BOOT1 on GPIOH Pin0..Pin1 and the
 *        FlexBus pins of GPIOC (Pin13..Pin15) and GPIOF (Pin0..Pin9). The
 *        protected mask of each port is GPIOx_PIN_DEFAULT_FUNC in the
 *        extension header and the filtering is controlled by
 *        HAL_GPIO_DEINIT_PROTECT_DEFAULT_FUNC in the configuration file.
 *        HAL_GPIO_Init() is not restricted by this rule: an application that
 *        wants to use one of those pins as a plain GPIO can configure it
 *        explicitly.
 * @note  RTOS configuration - this module needs no RTOS specific code and
 *        therefore compiles and behaves identically in the bare-metal and in
 *        the RTOS configuration. The rules of the RTOS chapter are mapped as
 *        follows:
 *          - "a blocking API shall yield the CPU in every polling iteration":
 *            not applicable, the module contains no polling loop and calls
 *            neither HAL_GetTick() nor HAL_Delay() (every function drives the
 *            registers once and returns);
 *          - "the handle may carry a MutexHandle field instead of the
 *            bare-metal Lock field": not applicable, the module has no handle
 *            structure at all;
 *          - "an RTOS lock shall support the Timeout parameter": not
 *            applicable, the module takes no lock (see the deliberate
 *            behaviour note above), hence there is no waiting point that
 *            could time out;
 *          - "no lock operation from an interrupt context": satisfied,
 *            HAL_GPIO_IRQHandler() and the per-port callbacks it raises perform
 *            no lock operation and no blocking wait;
 *          - the remaining rules of that chapter (tick source, HAL_Delay()
 *            remapping, notification from the weak callbacks, calling the
 *            FromISR variants) concern the common layer and the application,
 *            not this module.
 *        The only concurrency constraint that remains is the one stated in the
 *        deliberate behaviour note above: the application owns the
 *        serialisation of the read-modify-write sequences on a shared port.
 */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __AS32X601_HAL_GPIO_H
#define __AS32X601_HAL_GPIO_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include <stddef.h>
#include "as32x601_hal_def.h"
#include "as32x601.h"

/**
  * @brief GPIO HAL driver module version.
  * @note   0x0100U = V1.0. Bumped only on breaking API changes (architecture
  *         spec COMPAT-13/14/15).
  */
#define __HAL_GPIO_MODULE_VERSION  0x0100U

/** @addtogroup AS32X601_HAL_Driver
  * @{
  */

/** @addtogroup GPIO
  * @{
  */

/* Exported types ------------------------------------------------------------*/
/** @defgroup GPIO_Exported_Types GPIO Exported Types
  * @{
  */

/**
  * @brief GPIO Init structure definition
  * @note  This structure follows the Version+Size compatibility mechanism
  *        (architecture spec section 22): the user must clear the structure
  *        (__HAL_CLEAR_STRUCT / memset), set the Size and Version metafields
  *        before filling the business fields.
  */
typedef struct
{
    uint32 Size;       /*!< sizeof(GPIO_InitTypeDef), must be set by the user
                            after clearing the structure              */
    uint32 Version;    /*!< Structure semantic version: @ref GPIO_INIT_VERSION
                            (GPIO_INIT_V1 = 0x0100U)                  */
    uint32 Pin;       /*!< Specifies the GPIO pins to be configured.
                             This parameter can be any value of @ref GPIO_pins_define */

    uint32 Mode;      /*!< Specifies the operating mode for the selected pins.
                             This parameter can be a value of @ref GPIO_mode_define
                             @note The IDDQ mode (chip specific) is available in the
                                   extension module as GPIO_MODE_IDDQ. */

    uint32 Pull;      /*!< Specifies the Pull-up or Pull-Down activation for the selected pins.
                             This parameter can be a value of @ref GPIO_pull_define
                             @note The chip specific "KEEP" input type (pull-up and pull-down
                                   activated together) is available in the extension module
                                   as GPIO_PULLKEEP. */

    uint32 DriveCurrent; /*!< Specifies the maximum output drive current for the selected pins
                              as a drive current range (4.5 / 9 / 13.5 / 18 mA), not a slew
                              rate and not a frequency: the driver programs the value in the
                              output intensity control register OICR.
                              This parameter can be a value of @ref GPIO_drive_current_define */

    uint32 Alternate; /*!< Peripheral to be connected to the selected pins.
                             This parameter can be a value of @ref GPIO_Alternate_function_selection */

    uint32 Reserved[2]; /*!< Reserved for future extension (must be 0) */
} GPIO_InitTypeDef;

/**
  * @brief GPIO / init structure version macros.
  * @note  GPIO_INIT_V1 is the current version. Future versions (e.g. V2 with
  *        new fields) must be appended after the existing fields without
  *        changing the layout (architecture spec section 22.5).
  */
#define GPIO_INIT_V1  0x0100U   /*!< GPIO Init structure version V1.0 */
#define GPIO_INIT_VERSION  GPIO_INIT_V1   /*!< Current GPIO Init structure version */

/**
  * @brief  GPIO Bit SET and Bit RESET enumeration
  */
typedef enum
{
    GPIO_PIN_RESET = 0,
    GPIO_PIN_SET
} GPIO_PinState;
/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/
/** @defgroup GPIO_Exported_Constants GPIO Exported Constants
  * @{
  */

/** @defgroup GPIO_pins_define GPIO pins define
  * @{
  */
#define GPIO_PIN_0                 ((uint16)0x0001U)  /* Pin 0 selected    */
#define GPIO_PIN_1                 ((uint16)0x0002U)  /* Pin 1 selected    */
#define GPIO_PIN_2                 ((uint16)0x0004U)  /* Pin 2 selected    */
#define GPIO_PIN_3                 ((uint16)0x0008U)  /* Pin 3 selected    */
#define GPIO_PIN_4                 ((uint16)0x0010U)  /* Pin 4 selected    */
#define GPIO_PIN_5                 ((uint16)0x0020U)  /* Pin 5 selected    */
#define GPIO_PIN_6                 ((uint16)0x0040U)  /* Pin 6 selected    */
#define GPIO_PIN_7                 ((uint16)0x0080U)  /* Pin 7 selected    */
#define GPIO_PIN_8                 ((uint16)0x0100U)  /* Pin 8 selected    */
#define GPIO_PIN_9                 ((uint16)0x0200U)  /* Pin 9 selected    */
#define GPIO_PIN_10                ((uint16)0x0400U)  /* Pin 10 selected   */
#define GPIO_PIN_11                ((uint16)0x0800U)  /* Pin 11 selected   */
#define GPIO_PIN_12                ((uint16)0x1000U)  /* Pin 12 selected   */
#define GPIO_PIN_13                ((uint16)0x2000U)  /* Pin 13 selected   */
#define GPIO_PIN_14                ((uint16)0x4000U)  /* Pin 14 selected   */
#define GPIO_PIN_15                ((uint16)0x8000U)  /* Pin 15 selected   */
#define GPIO_PIN_All               ((uint16)0xFFFFU)  /* All pins selected */

#define GPIO_PIN_MASK              ((uint32)0x0000FFFFU) /* PIN mask for assert test */
/**
  * @}
  */

/** @defgroup GPIO_mode_define GPIO mode define
  * @brief GPIO Configuration Mode
  *        Elements values convention: 0xX0yz00YZ
  *           - X  : GPIO mode or EXTI Mode
  *           - y  : External IT trigger detection
  *           - z  : IO configuration on External IT
  *           - Y  : Output type (Push Pull or Open Drain)
  *           - Z  : IO Direction mode (Input, Output, Alternate or Analog)
  * @note  The AS32X601 has no event mode: GPIO_MODE_EVT_* is not provided.
  *        The chip specific IDDQ mode is provided in the extension module.
  * @{
  */
#define  GPIO_MODE_INPUT                        ((uint32)0x00000000U)   /*!< Input Floating Mode                   */
#define  GPIO_MODE_OUTPUT_PP                    ((uint32)0x00000001U)   /*!< Output Push Pull Mode                 */
#define  GPIO_MODE_OUTPUT_OD                    ((uint32)0x00000011U)   /*!< Output Open Drain Mode                */
#define  GPIO_MODE_AF_PP                        ((uint32)0x00000002U)   /*!< Alternate Function Push Pull Mode     */
#define  GPIO_MODE_AF_OD                        ((uint32)0x00000012U)   /*!< Alternate Function Open Drain Mode    */

#define  GPIO_MODE_ANALOG                       ((uint32)0x00000003U)   /*!< Analog Mode  */

#define  GPIO_MODE_IT_RISING                    ((uint32)0x10110000U)   /*!< External Interrupt Mode with Rising edge trigger detection          */
#define  GPIO_MODE_IT_FALLING                   ((uint32)0x10210000U)   /*!< External Interrupt Mode with Falling edge trigger detection         */
#define  GPIO_MODE_IT_RISING_FALLING            ((uint32)0x10310000U)   /*!< External Interrupt Mode with Rising/Falling edge trigger detection  */
/**
  * @}
  */

/** @defgroup GPIO_drive_current_define  GPIO maximum output drive current define
  * @brief  Maximum output drive current of the selected pins.
  * @note   On the AS32X601 this setting selects a drive current range (4.5 / 9 / 13.5 /
  *         18 mA): it is neither a slew rate nor a frequency. The driver programs the
  *         value in the output intensity control register OICR, two bits per pin.
  * @note   The four values are mutually exclusive and IS_GPIO_DRIVE_CURRENT() accepts
  *         exactly them.
  * @{
  */
#define  GPIO_DRIVE_CURRENT_LOW         ((uint32)0x00000000U)  /*!< Output maximum drive current 4.5mA  */
#define  GPIO_DRIVE_CURRENT_MEDIUM      ((uint32)0x00000001U)  /*!< Output maximum drive current 9mA    */
#define  GPIO_DRIVE_CURRENT_HIGH        ((uint32)0x00000002U)  /*!< Output maximum drive current 13.5mA */
#define  GPIO_DRIVE_CURRENT_VERY_HIGH   ((uint32)0x00000003U)  /*!< Output maximum drive current 18mA   */
/**
  * @}
  */

/** @defgroup GPIO_pull_define GPIO pull define
  * @brief GPIO Pull-Up or Pull-Down Activation (input type control register IM0CR)
  * @{
  */
#define  GPIO_NOPULL        ((uint32)0x00000000U)   /*!< Floating input mode (no pull)        */
#define  GPIO_PULLUP        ((uint32)0x00000001U)   /*!< Pull-up activation                   */
#define  GPIO_PULLDOWN      ((uint32)0x00000002U)   /*!< Pull-down activation                 */
/**
  * @}
  */

/**
  * @}
  */

/* Exported macro ------------------------------------------------------------*/
/** @defgroup GPIO_Exported_Macros GPIO Exported Macros
  * @{
  */

/**
  * @brief  Checks whether the specified GPIO line interrupt status flag is set or not.
  * @note   Only the lines whose interrupt is unmasked are reported (ISR = raw & !mask).
  * @param  __GPIOx__: where x can be (A..H) to select the GPIO peripheral.
  * @param  __GPIO_Pin__: specifies the GPIO pin to check.
  *         This parameter can be GPIO_PIN_x where x can be(0..15).
  * @retval The new state of __GPIO_Pin__ (SET or RESET).
  */
#define __HAL_GPIO_GET_IT(__GPIOx__, __GPIO_Pin__) \
  (GPIO_READ_REG(__GPIOx__, ISR) & (__GPIO_Pin__))

/**
  * @brief  Clears the GPIO line pending bits.
  * @param  __GPIOx__: where x can be (A..H) to select the GPIO peripheral.
  * @param  __GPIO_Pin__: specifies the GPIO lines to clear.
  *         This parameter can be any combination of GPIO_PIN_x where x can be (0..15).
  * @retval None
  */
#define __HAL_GPIO_CLEAR_IT(__GPIOx__, __GPIO_Pin__) \
  (GPIO_WRITE_REG(__GPIOx__, IRSR, (__GPIO_Pin__)))

/**
  * @brief  Generates a Software interrupt on the selected GPIO lines.
  * @param  __GPIOx__: where x can be (A..H) to select the GPIO peripheral.
  * @param  __GPIO_Pin__: specifies the GPIO lines to force.
  *         This parameter can be any combination of GPIO_PIN_x where x can be (0..15).
  * @retval None
  */
#define __HAL_GPIO_FORCE_IT(__GPIOx__, __GPIO_Pin__) \
  (GPIO_SET_REG(__GPIOx__, IFR, (__GPIO_Pin__)))

/**
  * @brief  Masks (disables) the interrupt of the selected GPIO lines.
  * @note   On the AS32X601 the IMR bit value 1 masks the interrupt.
  * @param  __GPIOx__: where x can be (A..H) to select the GPIO peripheral.
  * @param  __GPIO_Pin__: specifies the GPIO lines to mask.
  *         This parameter can be any combination of GPIO_PIN_x where x can be (0..15).
  * @retval None
  */
#define __HAL_GPIO_MASK_IT(__GPIOx__, __GPIO_Pin__) \
  (GPIO_SET_REG(__GPIOx__, IMR, (__GPIO_Pin__)))

/**
  * @brief  Unmasks (enables) the interrupt of the selected GPIO lines.
  * @param  __GPIOx__: where x can be (A..H) to select the GPIO peripheral.
  * @param  __GPIO_Pin__: specifies the GPIO lines to unmask.
  *         This parameter can be any combination of GPIO_PIN_x where x can be (0..15).
  * @retval None
  */
#define __HAL_GPIO_UNMASK_IT(__GPIOx__, __GPIO_Pin__) \
  (GPIO_CLEAR_REG(__GPIOx__, IMR, (__GPIO_Pin__)))
/**
  * @}
  */

/* Include GPIO HAL Extension module.
 * The extension header is a companion of this one: it consumes the types, the
 * pin macros and the register access macros defined above. The two headers
 * include each other, which is safe because both have include guards and every
 * type the extension needs is defined above this point; the practical effect is
 * that a translation unit gets the full GPIO API whichever of the two headers
 * it includes first (architecture spec DEP-01). */

/* Exported functions --------------------------------------------------------*/
/** @addtogroup GPIO_Exported_Functions
  * @{
  */

/** @addtogroup GPIO_Exported_Functions_Group1
  * @{
  */
/* Initialization and de-initialization functions *****************************/
/**
  * @brief  Initializes the GPIOx peripheral according to the parameters held by
  *         the GPIO_Init structure. (NON-BLOCKING)
  * @note   The structure must have been cleared and its Size / Version
  *         metafields filled in (architecture spec section 22); both are
  *         validated at run time.
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @param  GPIO_Init: pointer to a GPIO_InitTypeDef structure that holds the
  *         configuration of the selected pins.
  * @retval None (the call is rejected without any register access when the
  *         instance, the configuration or a field is not valid).
  */
void  HAL_GPIO_Init(GPIO_TypeDef  *GPIOx, GPIO_InitTypeDef *GPIO_Init);
/**
  * @brief  De-initializes the GPIOx port: restores every channel of the port
  *         to its reset state. (NON-BLOCKING)
  * @note   The function takes no pin mask (the whole port is restored); the
  *         channels that do not exist on the port are skipped, so the ten
  *         channel GPIOH port is restored over Pin0..Pin9 only.
  * @note   The pins whose reset default function is a multiplexed function
  *         (GPIOx_PIN_DEFAULT_FUNC: QSPI / JTAG / BOOT / FlexBus) are left
  *         untouched, so that the interface they carry is not dropped. Set
  *         HAL_GPIO_DEINIT_PROTECT_DEFAULT_FUNC to 0 to reset them as well.
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @retval None (the call is rejected without any register access when the
  *         instance is not a GPIO port).
  */
void  HAL_GPIO_DeInit(GPIO_TypeDef  *GPIOx);
/**
  * @}
  */

/** @addtogroup GPIO_Exported_Functions_Group2
  * @{
  */
/* IO operation functions *****************************************************/
/**
  * @brief  Reads the specified input port pin. (NON-BLOCKING)
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @param  GPIO_Pin: pin to read, one GPIO_PIN_x.
  * @retval The input port pin value; GPIO_PIN_RESET is returned when the
  *         instance or the pin mask is not valid.
  */
GPIO_PinState HAL_GPIO_ReadPin(GPIO_TypeDef* GPIOx, uint16 GPIO_Pin);
/**
  * @brief  Sets or clears the selected data port bit. (NON-BLOCKING)
  * @note   The OPBR / OBCR registers are written, so the operation is a single
  *         write access and no read-modify-write is involved.
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @param  GPIO_Pin: bit mask of the pins to write (GPIO_PIN_x).
  * @param  PinState: GPIO_PIN_SET to set, GPIO_PIN_RESET to clear.
  * @retval None (the call is rejected without any register access when the
  *         instance, the pin mask or the pin state is not valid).
  */
void HAL_GPIO_WritePin(GPIO_TypeDef* GPIOx, uint16 GPIO_Pin, GPIO_PinState PinState);
/**
  * @brief  Toggles the selected GPIO pins. (NON-BLOCKING)
  * @note   The OBTR register is written, so the operation is a single write
  *         access and no read-modify-write is involved.
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @param  GPIO_Pin: bit mask of the pins to toggle (GPIO_PIN_x).
  * @retval None (the call is rejected without any register access when the
  *         instance or the pin mask is not valid).
  */
void HAL_GPIO_TogglePin(GPIO_TypeDef* GPIOx, uint16 GPIO_Pin);
/**
  * @brief  Handles the port interrupt request of the selected GPIO port.
  * @note   Interrupt context: this function performs no lock operation and no
  *         blocking wait, as required for a routine called from an ISR.
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @retval None
  */
void HAL_GPIO_IRQHandler(GPIO_TypeDef* GPIOx);
/**
  * @brief  GPIOA port interrupt line detection callback. Weak function; the user
  *         implements it to receive the pins that raised an interrupt on the
  *         GPIOA port.
  * @param  GPIO_Pin: bit mask of the pending pin (a single GPIO_PIN_x bit).
  * @retval None
  * @note   There is one callback per port (HAL_GPIOA_EXTI_Callback() ...
  *         HAL_GPIOH_EXTI_Callback()) instead of a single aggregated callback:
  *         every port carries the same sixteen bit positions, so the pin mask
  *         alone would not tell an event on GPIOA from the same bit of another
  *         port. HAL_GPIO_IRQHandler() invokes the callback of the port it was
  *         called for, hence the callback that is entered identifies the port
  *         and its parameter identifies the pin.
  */
void HAL_GPIOA_EXTI_Callback(uint16 GPIO_Pin);
/**
  * @brief  GPIOB port interrupt line detection callback. Weak function; the user
  *         implements it to receive the pins that raised an interrupt on the
  *         GPIOB port.
  * @param  GPIO_Pin: bit mask of the pending pin (a single GPIO_PIN_x bit).
  * @retval None
  */
void HAL_GPIOB_EXTI_Callback(uint16 GPIO_Pin);
/**
  * @brief  GPIOC port interrupt line detection callback. Weak function; the user
  *         implements it to receive the pins that raised an interrupt on the
  *         GPIOC port.
  * @param  GPIO_Pin: bit mask of the pending pin (a single GPIO_PIN_x bit).
  * @retval None
  */
void HAL_GPIOC_EXTI_Callback(uint16 GPIO_Pin);
/**
  * @brief  GPIOD port interrupt line detection callback. Weak function; the user
  *         implements it to receive the pins that raised an interrupt on the
  *         GPIOD port.
  * @param  GPIO_Pin: bit mask of the pending pin (a single GPIO_PIN_x bit).
  * @retval None
  */
void HAL_GPIOD_EXTI_Callback(uint16 GPIO_Pin);
/**
  * @brief  GPIOE port interrupt line detection callback. Weak function; the user
  *         implements it to receive the pins that raised an interrupt on the
  *         GPIOE port.
  * @param  GPIO_Pin: bit mask of the pending pin (a single GPIO_PIN_x bit).
  * @retval None
  */
void HAL_GPIOE_EXTI_Callback(uint16 GPIO_Pin);
/**
  * @brief  GPIOF port interrupt line detection callback. Weak function; the user
  *         implements it to receive the pins that raised an interrupt on the
  *         GPIOF port.
  * @param  GPIO_Pin: bit mask of the pending pin (a single GPIO_PIN_x bit).
  * @retval None
  */
void HAL_GPIOF_EXTI_Callback(uint16 GPIO_Pin);
/**
  * @brief  GPIOG port interrupt line detection callback. Weak function; the user
  *         implements it to receive the pins that raised an interrupt on the
  *         GPIOG port.
  * @param  GPIO_Pin: bit mask of the pending pin (a single GPIO_PIN_x bit).
  * @retval None
  */
void HAL_GPIOG_EXTI_Callback(uint16 GPIO_Pin);
/**
  * @brief  GPIOH port interrupt line detection callback. Weak function; the user
  *         implements it to receive the pins that raised an interrupt on the
  *         GPIOH port.
  * @param  GPIO_Pin: bit mask of the pending pin (a single GPIO_PIN_x bit).
  * @retval None
  * @note   The GPIOH port exposes ten channels (Pin0..Pin9) only, so only those
  *         bits can reach this callback.
  */
void HAL_GPIOH_EXTI_Callback(uint16 GPIO_Pin);

/**
  * @}
  */

/**
  * @}
  */
/* Exported types ------------------------------------------------------------*/
/** @addtogroup GPIO_Exported_Types GPIO Exported Types
  * @{
  */

/**
  * @brief GPIO Interrupt triggering mode enumeration
  * @note  The enumerator names follow the register field naming of the
  *        AS32X601 so that the encoding stays recognisable in the code.
  */
typedef enum
{
    GPIO_ITType_CLOSE    = 0x00, /* The GPIO no-interrupt triggering          */
    GPIO_ITType_EDGEUP   = 0x01, /* The GPIO rising edge triggers interrupt   */
    GPIO_ITType_EDGEDOWN = 0x02, /* The GPIO falling edge triggers interrupt  */
    GPIO_ITType_EDGE     = 0x03  /* The GPIO rising or falling edge triggers  */
} GPIO_ITType_TypeDef;
/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/
/** @addtogroup GPIO_Exported_Constants GPIO Exported Constants
  * @{
  */

/** @addtogroup GPIO_mode_define GPIO mode define
  * @{
  */
#define GPIO_MODE_IDDQ                        ((uint32)0x00000004U)   /*!< IDDQ mode (chip specific) */
/**
  * @}
  */

/** @addtogroup GPIO_pull_define GPIO pull define
  * @{
  */
#define GPIO_PULLKEEP                         ((uint32)0x00000003U)   /*!< KEEP input type: pull-up and pull-down activated together (chip specific) */
/**
  * @}
  */

/** @defgroup GPIO_pin_source_define GPIO pin source define
  * @{
  */
#define GPIO_PinSource0               ((uint32)0x00)  /* GPIO pin source 0 selected */
#define GPIO_PinSource1               ((uint32)0x01)  /* GPIO pin source 1 selected */
#define GPIO_PinSource2               ((uint32)0x02)  /* GPIO pin source 2 selected */
#define GPIO_PinSource3               ((uint32)0x03)  /* GPIO pin source 3 selected */
#define GPIO_PinSource4               ((uint32)0x04)  /* GPIO pin source 4 selected */
#define GPIO_PinSource5               ((uint32)0x05)  /* GPIO pin source 5 selected */
#define GPIO_PinSource6               ((uint32)0x06)  /* GPIO pin source 6 selected */
#define GPIO_PinSource7               ((uint32)0x07)  /* GPIO pin source 7 selected */
#define GPIO_PinSource8               ((uint32)0x08)  /* GPIO pin source 8 selected */
#define GPIO_PinSource9               ((uint32)0x09)  /* GPIO pin source 9 selected */
#define GPIO_PinSource10              ((uint32)0x0A)  /* GPIO pin source 10 selected */
#define GPIO_PinSource11              ((uint32)0x0B)  /* GPIO pin source 11 selected */
#define GPIO_PinSource12              ((uint32)0x0C)  /* GPIO pin source 12 selected */
#define GPIO_PinSource13              ((uint32)0x0D)  /* GPIO pin source 13 selected */
#define GPIO_PinSource14              ((uint32)0x0E)  /* GPIO pin source 14 selected */
#define GPIO_PinSource15              ((uint32)0x0F)  /* GPIO pin source 15 selected */
/**
  * @}
  */

/** @defgroup GPIO_Alternate_function_selection GPIO Alternate Function Selection
  * @{
  */

/**
  * @brief   AF 0 selection
  */
#define GPIO_AF_Pin_x       ((uint8)0x00)     /* GPIO pin x Alternate Function mapping */

/**
  * @brief   AF 1 selection
  */
#define GPIO_AF_FB          ((uint8)0x01)     /* FB Alternate Function mapping */
#define GPIO_AF_QSPI        ((uint8)0x01)     /* QSPI Alternate Function mapping */
#define GPIO_AF_FAULT       ((uint8)0x01)     /* FAULT Alternate Function mapping */
#define GPIO_AF_JTAG        ((uint8)0x01)     /* JTAG Alternate Function mapping */

/**
  * @brief   AF 2 selection
  */
#define GPIO_AF_USART0      ((uint8)0x02)     /* USART0 Alternate Function mapping */
#define GPIO_AF_USART2      ((uint8)0x02)     /* USART2 Alternate Function mapping */
#define GPIO_AF_USART3      ((uint8)0x02)     /* USART3 Alternate Function mapping */
#define GPIO_AF_USART4      ((uint8)0x02)     /* USART4 Alternate Function mapping */
#define GPIO_AF_CAN0_M1     ((uint8)0x02)     /* CAN0 Alternate Function mapping */
#define GPIO_AF_CAN1        ((uint8)0x02)     /* CAN1 Alternate Function mapping */
#define GPIO_AF_CAN2        ((uint8)0x02)     /* CAN2 Alternate Function mapping */
#define GPIO_AF_CAN3        ((uint8)0x02)     /* CAN3 Alternate Function mapping */
#define GPIO_AF_IIC0_M1     ((uint8)0x02)     /* IIC0 Alternate Function mapping */
#define GPIO_AF_IIC1        ((uint8)0x02)     /* IIC1 Alternate Function mapping */
#define GPIO_AF_IIC3        ((uint8)0x02)     /* IIC3 Alternate Function mapping */
#define GPIO_AF_SPI0        ((uint8)0x02)     /* SPI0 Alternate Function mapping */
#define GPIO_AF_SPI3        ((uint8)0x02)     /* SPI3 Alternate Function mapping */
#define GPIO_AF_HTIM0_M1    ((uint8)0x02)     /* HTIM0 Alternate Function mapping */
#define GPIO_AF_HTIM1       ((uint8)0x02)     /* HTIM1 Alternate Function mapping */
#define GPIO_AF_TIM3        ((uint8)0x02)     /* TIM3 Alternate Function mapping */
#define GPIO_AF_TIM6_M1     ((uint8)0x02)     /* TIM6 Alternate Function mapping */
#define GPIO_AF_TIM7        ((uint8)0x02)     /* TIM7 Alternate Function mapping */
#define GPIO_AF_MAC         ((uint8)0x02)     /* MAC Alternate Function mapping */
#define GPIO_AF_CLKOUT      ((uint8)0x02)     /* CLKOUT Alternate Function mapping */
#define GPIO_AF_CMP0_M1     ((uint8)0x02)     /* CMP0 Alternate Function mapping */
#define GPIO_AF_CMP1_M1     ((uint8)0x02)     /* CMP1 Alternate Function mapping */

/**
  * @brief   AF 3 selection
  */
#define GPIO_AF_USART6      ((uint8)0x03)     /* USART6 Alternate Function mapping */
#define GPIO_AF_USART7      ((uint8)0x03)     /* USART7 Alternate Function mapping */
#define GPIO_AF_SPI1        ((uint8)0x03)     /* SPI1 Alternate Function mapping */
#define GPIO_AF_SPI2        ((uint8)0x03)     /* SPI2 Alternate Function mapping */
#define GPIO_AF_SPI4        ((uint8)0x03)     /* SPI4 Alternate Function mapping */
#define GPIO_AF_HTIM0_M2    ((uint8)0x03)     /* HTIM0 Alternate Function mapping */
#define GPIO_AF_HTIM2       ((uint8)0x03)     /* HTIM2 Alternate Function mapping */
#define GPIO_AF_HTIM5       ((uint8)0x03)     /* HTIM5 Alternate Function mapping */
#define GPIO_AF_TIM4        ((uint8)0x03)     /* TIM4 Alternate Function mapping */
#define GPIO_AF_TIM6_M2     ((uint8)0x03)     /* TIM6 Alternate Function mapping */

/**
  * @brief   AF 4 selection
  */
#define GPIO_AF_USART1      ((uint8)0x04)     /* USART1 Alternate Function mapping */
#define GPIO_AF_USART5      ((uint8)0x04)     /* USART5 Alternate Function mapping */
#define GPIO_AF_CAN0_M3     ((uint8)0x04)     /* CAN0 Alternate Function mapping */
#define GPIO_AF_IIC0_M3     ((uint8)0x04)     /* IIC0 Alternate Function mapping */
#define GPIO_AF_IIC2        ((uint8)0x04)     /* IIC2 Alternate Function mapping */
#define GPIO_AF_SPI5        ((uint8)0x04)     /* SPI5 Alternate Function mapping */
#define GPIO_AF_CMP0_M3     ((uint8)0x04)     /* CMP0 Alternate Function mapping */
#define GPIO_AF_CMP1_M3     ((uint8)0x04)     /* CMP1 Alternate Function mapping */

/**
  * @}
  */

/**
  * @}
  */

/* Exported macro ------------------------------------------------------------*/
/** @addtogroup GPIO_Exported_Macros GPIO Exported Macros
  * @{
  */
/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/
/** @defgroup GPIO_Exported_Functions GPIO Exported Functions
  * @{
  */

/* Initialization and de-initialization functions *****************************/
/**
  * @brief  Fills each GPIO_InitStruct member with its default value, including
  *         the Size / Version metafields. (NON-BLOCKING)
  * @param  GPIO_InitStruct: pointer to the GPIO_InitTypeDef structure to fill.
  * @retval None (a NULL pointer is rejected without any memory access).
  */
void HAL_GPIO_StructInit(GPIO_InitTypeDef *GPIO_InitStruct);

/* IO operation functions *****************************************************/
/**
  * @brief  Sets the multiplex function of one GPIO pin. (NON-BLOCKING)
  * @note   The GPIOH port has 10 channels (Pin0..Pin9) and no MI1SR register,
  *         so that port has no multiplex field at all for channels 10..15 and
  *         such a request is rejected by the pin availability check.
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @param  GPIO_PinSource: pin source to configure, one GPIO_PinSourcex (0..15).
  * @param  GPIO_AF: alternate function to connect, see @ref GPIO_Alternate_function_selection.
  * @retval None (the call is rejected without any register access when the
  *         instance, the pin source or the alternate function is not valid).
  */
void HAL_GPIO_PinAFConfig(GPIO_TypeDef *GPIOx, uint32 GPIO_PinSource, uint8 GPIO_AF);
/**
  * @brief  Configures the interrupt trigger type of the selected pins and
  *         enables or disables (masks) the corresponding lines. (NON-BLOCKING)
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @param  GPIO_Pin: bit mask of the pins to configure (GPIO_PIN_x).
  * @param  ITType: trigger type, see @ref GPIO_ITType_TypeDef.
  * @param  NewState: ENABLE to program the trigger and unmask the line, DISABLE
  *         to clear the trigger and mask the line.
  * @retval None (the call is rejected without any register access when the
  *         instance, the pin mask, the trigger type or the state is not valid).
  */
void HAL_GPIO_ITConfig(GPIO_TypeDef *GPIOx, uint32 GPIO_Pin, GPIO_ITType_TypeDef ITType,
                         FunctionalState NewState);
/**
  * @brief  Returns the interrupt status of the selected pins. (NON-BLOCKING)
  * @note   The status register reports the raw status AND NOT mask, so only the
  *         unmasked lines are reported.
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @param  GPIO_Pin: bit mask of the pins to test (GPIO_PIN_x).
  * @retval SET when the mask matches at least one pending line, RESET otherwise
  *         (also RESET when the instance or the pin mask is not valid).
  */
ITStatus HAL_GPIO_GetITStatus(GPIO_TypeDef *GPIOx, uint32 GPIO_Pin);
/**
  * @brief  Forces (raises in software) the interrupt of the selected pins.
  *         (NON-BLOCKING)
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @param  GPIO_Pin: bit mask of the pins to force (GPIO_PIN_x).
  * @retval None (the call is rejected without any register access when the
  *         instance or the pin mask is not valid).
  */
void HAL_GPIO_ForceINT(GPIO_TypeDef *GPIOx, uint32 GPIO_Pin);
/**
  * @brief  Masks or unmasks the interrupt of the selected pins. (NON-BLOCKING)
  * @note   On the AS32X601 an IMR bit value of 1 masks the interrupt.
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @param  GPIO_Pin: bit mask of the pins to mask or unmask (GPIO_PIN_x).
  * @param  NewState: DISABLE to mask the lines, ENABLE to unmask them.
  * @retval None (the call is rejected without any register access when the
  *         instance, the pin mask or the state is not valid).
  */
void HAL_GPIO_ITMaskConfig(GPIO_TypeDef *GPIOx, uint32 GPIO_Pin, FunctionalState NewState);
/**
  * @brief  Clears the interrupt pending bits of the selected pins.
  *         (NON-BLOCKING)
  * @note   Interrupt safe: no lock and no blocking wait, so it is callable from
  *         an interrupt service routine.
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @param  GPIO_Pin: bit mask of the pins to clear (GPIO_PIN_x).
  * @retval None (the call is rejected without any register access when the
  *         instance or the pin mask is not valid).
  */
void HAL_GPIO_ClearITPendingBit(GPIO_TypeDef *GPIOx, uint32 GPIO_Pin);
/**
  * @brief  Writes the whole output data value of the port. (NON-BLOCKING)
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @param  PortVal: 16 bit value written to the output control register.
  * @retval None (the call is rejected without any register access when the
  *         instance is not valid).
  */
void HAL_GPIO_WritePort(GPIO_TypeDef *GPIOx, uint16 PortVal);
/**
  * @brief  Reads the output value of the selected pins. (NON-BLOCKING)
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @param  GPIO_Pin: bit mask of the pins to read (GPIO_PIN_x).
  * @retval The output pin value; GPIO_PIN_RESET when the instance or the pin
  *         mask is not valid.
  */
GPIO_PinState HAL_GPIO_ReadOutputPin(GPIO_TypeDef *GPIOx, uint32 GPIO_Pin);
/**
  * @brief  Reads the whole output data value of the port. (NON-BLOCKING)
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @retval The output data port value; 0 when the instance is not valid.
  */
uint32 HAL_GPIO_ReadOutputPort(GPIO_TypeDef *GPIOx);
/**
  * @brief  Reads the whole input data value of the port. (NON-BLOCKING)
  * @param  GPIOx: where x can be (A..H) to select the GPIO peripheral.
  * @retval The input data port value; 0 when the instance is not valid.
  */
uint32 HAL_GPIO_ReadInputPort(GPIO_TypeDef *GPIOx);

/**
  * @}
  */
/* Private types -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private constants ---------------------------------------------------------*/
/** @addtogroup GPIO_Private_Constants GPIO Private Constants
  * @{
  */

/**
  * @brief   GPIO pin available on the platform
  */
/* Defines the available pins per GPIOs.
    Note: the GPIOH port has only 10 channels (Pin0..Pin9).  That port has no
    MI1SR register and its RWM0CR / IM0CR registers implement ten 2-bit fields
    only (the MI0SR register ten 3-bit fields), so channels 10..15 do not exist
    and the whole 15th bit of a pin mask must be rejected on this port. */
#define GPIOA_PIN_AVAILABLE  GPIO_PIN_All
#define GPIOB_PIN_AVAILABLE  GPIO_PIN_All
#define GPIOC_PIN_AVAILABLE  GPIO_PIN_All
#define GPIOD_PIN_AVAILABLE  GPIO_PIN_All
#define GPIOE_PIN_AVAILABLE  GPIO_PIN_All
#define GPIOF_PIN_AVAILABLE  GPIO_PIN_All
#define GPIOG_PIN_AVAILABLE  GPIO_PIN_All
#define GPIOH_PIN_AVAILABLE  (GPIO_PIN_0  | GPIO_PIN_1  | GPIO_PIN_2  | GPIO_PIN_3  | \
                              GPIO_PIN_4  | GPIO_PIN_5  | GPIO_PIN_6  | GPIO_PIN_7  | \
                              GPIO_PIN_8  | GPIO_PIN_9)

/**
  * @brief   Protection of the pins whose reset default function is multiplexed
  * @note    When enabled, HAL_GPIO_DeInit() filters out GPIOx_PIN_DEFAULT_FUNC
  *          (see below), so that those pins are not reset to the plain GPIO
  *          default. The parameter is normally set in the configuration file
  *          (as32x601_hal_conf.h); this fallback keeps the protection active
  *          for a configuration file that predates the parameter.
  * @note    Set it to 0 only when the application does not use the function
  *          those pins carry out of reset (QSPI / JTAG / BOOT / FlexBus) and
  *          wants HAL_GPIO_DeInit() to reset them like any other pin.
  */
#ifndef HAL_GPIO_DEINIT_PROTECT_DEFAULT_FUNC
    #define HAL_GPIO_DEINIT_PROTECT_DEFAULT_FUNC  1U
#endif /* HAL_GPIO_DEINIT_PROTECT_DEFAULT_FUNC */

/**
  * @brief   Pins whose reset default function is a multiplexed function
  * @note    These pins are driven out of reset with multiplex function 1 already
  *          selected (the reset value of the AFR field of MI0SR / MI1SR is 1 for
  *          them) and with a specific direction and output type, so each of them
  *          belongs to a specific interface:
  *            GPIOA Pin8 .. Pin13   QSPI    (CSN / SCK / DIO0 .. DIO3)
  *            GPIOB Pin5 .. Pin9    JTAG    (RSTN / TDO / TCK / TDI / TMS)
  *            GPIOC Pin13 .. Pin15  FlexBus (TCK / RST / TMSC0)
  *            GPIOF Pin0 .. Pin9    FlexBus (TMSC1 .. TMSC4 / FR0 .. FR4 / MS)
  *            GPIOH Pin0 .. Pin1    BOOT0 / BOOT1
  *          The ports D, E and G have no such pin (mask 0).
  * @note    HAL_GPIO_DeInit() leaves these pins untouched, because their reset
  *          state is not the plain GPIO default: resetting them would drop the
  *          function they carry and could break, for example, the QSPI boot path,
  *          the debug port or the external bus. The filtering is controlled by
  *          HAL_GPIO_DEINIT_PROTECT_DEFAULT_FUNC above.
  * @note    HAL_GPIO_Init() is not restricted by this rule: an application that
  *          wants to use one of these pins as a plain GPIO can still configure it
  *          explicitly.
  */
#define GPIOA_PIN_DEFAULT_FUNC  (GPIO_PIN_8  | GPIO_PIN_9  | GPIO_PIN_10 | \
                                 GPIO_PIN_11 | GPIO_PIN_12 | GPIO_PIN_13)
#define GPIOB_PIN_DEFAULT_FUNC  (GPIO_PIN_5  | GPIO_PIN_6  | GPIO_PIN_7  | \
                                 GPIO_PIN_8  | GPIO_PIN_9)
#define GPIOC_PIN_DEFAULT_FUNC  (GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15)
#define GPIOD_PIN_DEFAULT_FUNC  (0U)
#define GPIOE_PIN_DEFAULT_FUNC  (0U)
#define GPIOF_PIN_DEFAULT_FUNC  (GPIO_PIN_0  | GPIO_PIN_1  | GPIO_PIN_2  | GPIO_PIN_3  | \
                                 GPIO_PIN_4  | GPIO_PIN_5  | GPIO_PIN_6  | GPIO_PIN_7  | \
                                 GPIO_PIN_8  | GPIO_PIN_9)
#define GPIOG_PIN_DEFAULT_FUNC  (0U)
#define GPIOH_PIN_DEFAULT_FUNC  (GPIO_PIN_0  | GPIO_PIN_1)
/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/
/** @addtogroup GPIO_Private_Macros GPIO Private Macros
  * @{
  */
#define IS_GPIO_ITTYPE(ITType) (((ITType) == GPIO_ITType_CLOSE)    || ((ITType) == GPIO_ITType_EDGEUP) || \
                                ((ITType) == GPIO_ITType_EDGEDOWN) || ((ITType) == GPIO_ITType_EDGE))

#define IS_GPIO_PIN_SOURCE(PINSOURCE) (((PINSOURCE) == GPIO_PinSource0)  || \
                                       ((PINSOURCE) == GPIO_PinSource1)  || \
                                       ((PINSOURCE) == GPIO_PinSource2)  || \
                                       ((PINSOURCE) == GPIO_PinSource3)  || \
                                       ((PINSOURCE) == GPIO_PinSource4)  || \
                                       ((PINSOURCE) == GPIO_PinSource5)  || \
                                       ((PINSOURCE) == GPIO_PinSource6)  || \
                                       ((PINSOURCE) == GPIO_PinSource7)  || \
                                       ((PINSOURCE) == GPIO_PinSource8)  || \
                                       ((PINSOURCE) == GPIO_PinSource9)  || \
                                       ((PINSOURCE) == GPIO_PinSource10) || \
                                       ((PINSOURCE) == GPIO_PinSource11) || \
                                       ((PINSOURCE) == GPIO_PinSource12) || \
                                       ((PINSOURCE) == GPIO_PinSource13) || \
                                       ((PINSOURCE) == GPIO_PinSource14) || \
                                       ((PINSOURCE) == GPIO_PinSource15))

#define IS_GPIO_ALL_INSTANCE(INSTANCE) (((INSTANCE) == GPIOA) || ((INSTANCE) == GPIOB) || \
                                        ((INSTANCE) == GPIOC) || ((INSTANCE) == GPIOD) || \
                                        ((INSTANCE) == GPIOE) || ((INSTANCE) == GPIOF) || \
                                        ((INSTANCE) == GPIOG) || ((INSTANCE) == GPIOH))

#define IS_GPIO_AF(AF) (((AF) == GPIO_AF_Pin_x)    || ((AF) == GPIO_AF_USART0)   || \
                        ((AF) == GPIO_AF_USART1)   || ((AF) == GPIO_AF_USART2)   || \
                        ((AF) == GPIO_AF_USART3)   || ((AF) == GPIO_AF_USART4)   || \
                        ((AF) == GPIO_AF_USART5)   || ((AF) == GPIO_AF_USART6)   || \
                        ((AF) == GPIO_AF_USART7)   || ((AF) == GPIO_AF_CAN0_M1)  || \
                        ((AF) == GPIO_AF_CAN0_M3)  || ((AF) == GPIO_AF_CAN1)     || \
                        ((AF) == GPIO_AF_CAN2)     || ((AF) == GPIO_AF_CAN3)     || \
                        ((AF) == GPIO_AF_IIC0_M1)  || ((AF) == GPIO_AF_IIC0_M3)  || \
                        ((AF) == GPIO_AF_IIC1)     || ((AF) == GPIO_AF_IIC2)     || \
                        ((AF) == GPIO_AF_IIC3)     || ((AF) == GPIO_AF_SPI0)     || \
                        ((AF) == GPIO_AF_SPI1)     || ((AF) == GPIO_AF_SPI2)     || \
                        ((AF) == GPIO_AF_SPI3)     || ((AF) == GPIO_AF_SPI4)     || \
                        ((AF) == GPIO_AF_SPI5)     || ((AF) == GPIO_AF_HTIM0_M1) || \
                        ((AF) == GPIO_AF_HTIM0_M2) || ((AF) == GPIO_AF_HTIM1)    || \
                        ((AF) == GPIO_AF_HTIM2)    || ((AF) == GPIO_AF_HTIM5)    || \
                        ((AF) == GPIO_AF_TIM3)     || ((AF) == GPIO_AF_TIM4)     || \
                        ((AF) == GPIO_AF_TIM6_M1)  || ((AF) == GPIO_AF_TIM6_M2)  || \
                        ((AF) == GPIO_AF_TIM7)     || ((AF) == GPIO_AF_MAC)      || \
                        ((AF) == GPIO_AF_FB)       || ((AF) == GPIO_AF_QSPI)     || \
                        ((AF) == GPIO_AF_FAULT)    || ((AF) == GPIO_AF_CLKOUT)   || \
                        ((AF) == GPIO_AF_JTAG)     || ((AF) == GPIO_AF_CMP0_M1)  || \
                        ((AF) == GPIO_AF_CMP0_M3)  || ((AF) == GPIO_AF_CMP1_M1)  || \
                        ((AF) == GPIO_AF_CMP1_M3))

#define IS_GPIO_PIN_AVAILABLE(__INSTANCE__,__PIN__)  \
           ((((__INSTANCE__) == GPIOA) && (((__PIN__) & (GPIOA_PIN_AVAILABLE)) != 0) && (((__PIN__) | (GPIOA_PIN_AVAILABLE)) == (GPIOA_PIN_AVAILABLE))) || \
            (((__INSTANCE__) == GPIOB) && (((__PIN__) & (GPIOB_PIN_AVAILABLE)) != 0) && (((__PIN__) | (GPIOB_PIN_AVAILABLE)) == (GPIOB_PIN_AVAILABLE))) || \
            (((__INSTANCE__) == GPIOC) && (((__PIN__) & (GPIOC_PIN_AVAILABLE)) != 0) && (((__PIN__) | (GPIOC_PIN_AVAILABLE)) == (GPIOC_PIN_AVAILABLE))) || \
            (((__INSTANCE__) == GPIOD) && (((__PIN__) & (GPIOD_PIN_AVAILABLE)) != 0) && (((__PIN__) | (GPIOD_PIN_AVAILABLE)) == (GPIOD_PIN_AVAILABLE))) || \
            (((__INSTANCE__) == GPIOE) && (((__PIN__) & (GPIOE_PIN_AVAILABLE)) != 0) && (((__PIN__) | (GPIOE_PIN_AVAILABLE)) == (GPIOE_PIN_AVAILABLE))) || \
            (((__INSTANCE__) == GPIOF) && (((__PIN__) & (GPIOF_PIN_AVAILABLE)) != 0) && (((__PIN__) | (GPIOF_PIN_AVAILABLE)) == (GPIOF_PIN_AVAILABLE))) || \
            (((__INSTANCE__) == GPIOG) && (((__PIN__) & (GPIOG_PIN_AVAILABLE)) != 0) && (((__PIN__) | (GPIOG_PIN_AVAILABLE)) == (GPIOG_PIN_AVAILABLE))) || \
            (((__INSTANCE__) == GPIOH) && (((__PIN__) & (GPIOH_PIN_AVAILABLE)) != 0) && (((__PIN__) | (GPIOH_PIN_AVAILABLE)) == (GPIOH_PIN_AVAILABLE))))
/**
  * @}
  */

/* Private functions ---------------------------------------------------------*/
/** @addtogroup GPIO_Private_Functions GPIO Private Functions
  * @{
  */

/**
  * @}
  */

/**
  */

/**
  */

/* Private types -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private constants ---------------------------------------------------------*/
/** @defgroup GPIO_Private_Constants GPIO Private Constants
  * @{
  */
#define GPIO_MODE_IT          ((uint32)0x00010000U)
#define RISING_EDGE           ((uint32)0x00100000U)
#define FALLING_EDGE          ((uint32)0x00200000U)
#define GPIO_OUTPUT_TYPE      ((uint32)0x00000010U)
#define EXTI_MODE             ((uint32)0x10000000U)

#define GPIO_MODE_VALUE_INPUT ((uint32)0x00000000U)  /* RWM0CR MODER encoding: input mode  */
#define GPIO_MODE_VALUE_OUTPUT ((uint32)0x00000001U)  /* RWM0CR MODER encoding: output mode */
#define GPIO_MODE_VALUE_ANALOG  ((uint32)0x00000002U)  /* RWM0CR MODER encoding: analog mode */
#define GPIO_MODE_VALUE_IDDQ  ((uint32)0x00000003U)  /* RWM0CR MODER encoding: IDDQ mode   */

#define GPIO_NUMBER           ((uint32)16U)
/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/
/** @defgroup GPIO_Private_Macros GPIO Private Macros
  * @{
  */

/**
  * @brief  Reads a GPIO port register.
  * @note   The GPIOH port is mapped at a dedicated address (GPIOHMAP) whose register
  *         layout has no MI1SR field. This macro redirects every register access of
  *         the GPIOH port to the GPIOHMAP structure.
  * @note   This macro is read-only (the C conditional operator result is not an
  *         lvalue): use GPIO_WRITE_REG / GPIO_SET_REG / GPIO_CLEAR_REG to write.
  * @note   It must NOT be used with the MI1SR register (the GPIOH port has no
  *         MI1SR): use the GPIOx->MI1SR access guarded by a (GPIOx != GPIOH) test.
  */
#define GPIO_READ_REG(__GPIOx__, __REG__) \
  (((__GPIOx__) == GPIOH) ? ((GPIOHMAP)->__REG__) : ((__GPIOx__)->__REG__))

/**
  * @brief  Writes a GPIO port register.
  */
#define GPIO_WRITE_REG(__GPIOx__, __REG__, __VAL__) \
  (((__GPIOx__) == GPIOH) ? ((GPIOHMAP)->__REG__ = (__VAL__)) : ((__GPIOx__)->__REG__ = (__VAL__)))

/**
  * @brief  Sets bits in a GPIO port register.
  */
#define GPIO_SET_REG(__GPIOx__, __REG__, __MASK__) \
  (((__GPIOx__) == GPIOH) ? ((GPIOHMAP)->__REG__ |= (__MASK__)) : ((__GPIOx__)->__REG__ |= (__MASK__)))

/**
  * @brief  Clears bits in a GPIO port register.
  */
#define GPIO_CLEAR_REG(__GPIOx__, __REG__, __MASK__) \
  (((__GPIOx__) == GPIOH) ? ((GPIOHMAP)->__REG__ &= ~(__MASK__)) : ((__GPIOx__)->__REG__ &= ~(__MASK__)))

#define IS_GPIO_PIN_ACTION(ACTION) (((ACTION) == GPIO_PIN_RESET) || ((ACTION) == GPIO_PIN_SET))
#define IS_GPIO_PIN(PIN)           (((PIN) & GPIO_PIN_MASK ) != (uint32)0x00)
/**
  * @brief  Checks that a pin mask is non-zero and names only pins that exist on
  *         the given port.
  * @note   The per-port availability masks live in the extension header
  *         (GPIOx_PIN_AVAILABLE). Ports A..G expose all sixteen channels; the
  *         GPIOH port exposes ten of them (Pin0..Pin9) and has no MI1SR
  *         register, so a mask that names its channels 10..15 is rejected.
  * @note   This macro is an integer constant expression for a constant instance
  *         token and mask, so it can be used in a compile-time context (array
  *         size, static assertion) as well as at run time.
  */
#ifndef IS_GPIO_PIN_AVAILABLE
#define IS_GPIO_PIN_AVAILABLE(GPIOx, PIN) \
    (((GPIOx) == GPIOH) ? ((((PIN) & GPIOH_PIN_AVAILABLE) == (PIN)) && ((PIN) != 0U)) : \
                         (((PIN) & GPIO_PIN_MASK) != 0U))
#endif
/* The chip specific IDDQ mode is provided by the extension header and is
 * handled by the base driver as well, so it belongs to the accepted values. */
#define IS_GPIO_MODE(MODE) (((MODE) == GPIO_MODE_INPUT)              ||\
                            ((MODE) == GPIO_MODE_OUTPUT_PP)          ||\
                            ((MODE) == GPIO_MODE_OUTPUT_OD)          ||\
                            ((MODE) == GPIO_MODE_AF_PP)              ||\
                            ((MODE) == GPIO_MODE_AF_OD)              ||\
                            ((MODE) == GPIO_MODE_IT_RISING)          ||\
                            ((MODE) == GPIO_MODE_IT_FALLING)         ||\
                            ((MODE) == GPIO_MODE_IT_RISING_FALLING)  ||\
                            ((MODE) == GPIO_MODE_ANALOG)             ||\
                            ((MODE) == GPIO_MODE_IDDQ))
/** @brief  Check the output drive current setting of a pin.
  * @note   HAL_GPIO_Init() programs this value in the output intensity control register
  *         OICR: it selects a drive current range (4.5 / 9 / 13.5 / 18 mA), it is not a
  *         slew rate and not a frequency.
  * @param  DRIVE_CURRENT: specifies the output drive current, see
  *         @ref GPIO_drive_current_define.
  * @retval None
  */
#define IS_GPIO_DRIVE_CURRENT(DRIVE_CURRENT) (((DRIVE_CURRENT) == GPIO_DRIVE_CURRENT_LOW)  || ((DRIVE_CURRENT) == GPIO_DRIVE_CURRENT_MEDIUM) || \
                                              ((DRIVE_CURRENT) == GPIO_DRIVE_CURRENT_HIGH) || ((DRIVE_CURRENT) == GPIO_DRIVE_CURRENT_VERY_HIGH))
/* The chip specific "KEEP" input type (pull-up and pull-down together) is
 * provided by the extension header and is written by the base driver through
 * the same IM0CR field, so it belongs to the accepted values. */
#define IS_GPIO_PULL(PULL) (((PULL) == GPIO_NOPULL)   || ((PULL) == GPIO_PULLUP) || \
                            ((PULL) == GPIO_PULLDOWN) || ((PULL) == GPIO_PULLKEEP))
/**
  * @}
  */

/* Private functions ---------------------------------------------------------*/
/** @defgroup GPIO_Private_Functions GPIO Private Functions
  * @{
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_GPIO_H */

/*****END OF FILE*****/
