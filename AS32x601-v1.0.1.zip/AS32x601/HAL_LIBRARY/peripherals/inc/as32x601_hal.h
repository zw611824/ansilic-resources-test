/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.6
 * Date:   2026/10/19
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/12     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.1     add the compile time
 *                                                       module dependency
 *                                                       checks (all peripherals
 *                                                       <- SMU; USART/SPI/I2C/
 *                                                       ADC/DAC/QSPI/TIM/CANFD
 *                                                       <- GPIO)
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.4     align the version number with the
 *                                                       rest of the common layer; declare
 *                                                       the HAL_TICK_FREQ_HZ time base
 *                                                       frequency system parameter (with a
 *                                                       guarded fallback for configuration
 *                                                       files that predate it) and derive
 *                                                       the tick services from it, so that
 *                                                       HAL_GetTickFreq() can no longer
 *                                                       disagree with the time base;
 *                                                       document the HAL_Delay precondition,
 *                                                       annotate the blocking property of
 *                                                       every public service and correct
 *                                                       the dependency map comment so that
 *                                                       it lists the checks actually
 *                                                       performed
 *     ANSILIC APPLICATION GROUP  2026/10/08     1.5     document the hand-off details of the common
 *                                                       layer: the power-on initial value of
 *                                                       SystemCoreClock (the fast internal RC
 *                                                       oscillator, not the external one), the
 *                                                       multiply-then-divide conversion of
 *                                                       HAL_Delay together with the missing result
 *                                                       value of its public signature, and the
 *                                                       clock precondition of HAL_Init
 *     ANSILIC APPLICATION GROUP  2026/10/19     1.6     add the SMU <- FLASH compile time
 *                                                       dependency check: the SMU clock tree
 *                                                       service programs the EFLASH
 *                                                       controller wait states (CR.CLKFRQ)
 *                                                       through the FLASH driver before it
 *                                                       switches the system clock, so a
 *                                                       configuration that enables SMU
 *                                                       without FLASH is now rejected here
 *                                                       with a readable message instead of
 *                                                       failing inside as32x601_hal_smu.c
 * Description:     This file is the unique entry of the AS32x601 HAL library.
 *                  It includes the user configuration file and the HAL common
 *                  definitions, performs the compile time module dependency
 *                  checks, and declares the HAL common system services
 *                  (initialization / de-initialization, time base and tick
 *                  services, HAL version identification).
 */
#ifndef __AS32X601_HAL_H
#define __AS32X601_HAL_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "as32x601_hal_conf.h"      /* user configuration                     */
#include "as32x601_hal_def.h"       /* common types, lock mechanism, utilities */

/* Time base frequency --------------------------------------------------------*/
/* The value is owned by the user configuration file (as32x601_hal_conf.h).
 * The guarded fallback below keeps a configuration file that predates the
 * parameter working with the default 1 ms time base. HAL_InitTick() and
 * HAL_GetTickFreq() both derive from this single value, so the reported tick
 * frequency can never drift away from the frequency the time base is built
 * with (HAL-REQ-028).
 */
#ifndef HAL_TICK_FREQ_HZ
    #define HAL_TICK_FREQ_HZ   1000U   /*!< Time base frequency, in Hz */
#endif /* HAL_TICK_FREQ_HZ */

#if (HAL_TICK_FREQ_HZ < 1U)
    #error "HAL_TICK_FREQ_HZ must be greater than zero!"
#endif /* HAL_TICK_FREQ_HZ < 1U */

/* Exported constants --------------------------------------------------------*/

/**
 * @brief AS32x601 HAL library version number V1.5.0
 * @note  The common layer is delivered as one version: the three public
 *        headers and the implementation file all carry the file version
 *        V1.5 and the four fields below match it, so that HAL_GetHalVersion()
 *        and the delivered file versions can never disagree (HAL-REQ-035).
 */
#define __AS32X601_HAL_VERSION_MAIN   (0x01U)   /*!< [31:24] main version */
#define __AS32X601_HAL_VERSION_SUB1   (0x05U)   /*!< [23:16] sub1 version */
#define __AS32X601_HAL_VERSION_SUB2   (0x00U)   /*!< [15:8]  sub2 version */
#define __AS32X601_HAL_VERSION_RC     (0x00U)   /*!< [7:0]   release candidate */
#define __AS32X601_HAL_VERSION         ((__AS32X601_HAL_VERSION_MAIN << 24U) | \
                                        (__AS32X601_HAL_VERSION_SUB1 << 16U) | \
                                        (__AS32X601_HAL_VERSION_SUB2 << 8U)  | \
                                        (__AS32X601_HAL_VERSION_RC))

/* Configuration check --------------------------------------------------------*/
#ifndef HAL_MODULE_ENABLED
    #error "Please include as32x601_hal_conf.h before as32x601_hal.h!"
#endif /* HAL_MODULE_ENABLED */

/* Module dependency checks ---------------------------------------------------
 * Hard dependencies are verified at compile time (rule DEP-02): a module
 * cannot be enabled while one of the modules it depends on is disabled. The
 * module switches are defined as empty macros, so the checks use the
 * "#if defined()" form instead of "== 1U" (library convention).
 *
 * Dependency map (the checks actually performed below):
 *   USART <- GPIO + SMU                  SPI <- GPIO + SMU
 *   I2C   <- GPIO + SMU                  ADC <- GPIO + SMU
 *   DAC   <- GPIO + SMU                  QSPI <- GPIO + SMU
 *   TIM   <- GPIO + SMU                  CANFD <- GPIO + SMU
 *   DMA   <- SMU                         MAC <- SMU
 *   PKA   <- SMU                         SPACC <- SMU
 *   SMU   <- FLASH (EFLASH controller)
 * Rationale: a module needs the SMU module as soon as its clock gating and
 * reset are provided through the SMU registers (the <module>EN / <module>RST
 * bits of SMU_ALB0CFGR / SMU_ALB1CFGR / SMU_APB0CFGR / SMU_APB1CFGR), since
 * the peripheral clock is switched on by the MspInit callback of the driver
 * or by the user override of it. A module that drives external pins needs
 * GPIO for the same reason. Modules of the always-on domain (PMU, MPU, IWDG,
 * WWDG) and of the core-local group (PLIC, CLINT) are intentionally left
 * unconstrained.
 * SMU <- FLASH is the one dependency that points the other way: the SMU clock
 * tree service programs the EFLASH controller wait states (CR.CLKFRQ) before
 * it switches the system clock to its final value, because the flash
 * controller must already know the new frequency while the code is still
 * fetched from it. That programming is done through the FLASH driver
 * (HAL_FLASH_HandleTypeDef and HAL_FLASH_SetClockFrequency()), so enabling
 * SMU without FLASH cannot compile - it is rejected here with a readable
 * message instead of failing deep inside as32x601_hal_smu.c.
 * Soft dependencies (USART/SPI/ADC/CANFD <- DMA) are optional and are NOT
 * hard-checked (rule DEP-03): they are controlled by the user configuration.
 * --------------------------------------------------------------------------*/
#if defined(HAL_USART_MODULE_ENABLED) && !defined(HAL_GPIO_MODULE_ENABLED)
    #error "USART module requires GPIO module!"
#endif /* defined(HAL_USART_MODULE_ENABLED) && !defined(HAL_GPIO_MODULE_ENABLED) */
#if defined(HAL_USART_MODULE_ENABLED) && !defined(HAL_SMU_MODULE_ENABLED)
    #error "USART module requires SMU module!"
#endif /* defined(HAL_USART_MODULE_ENABLED) && !defined(HAL_SMU_MODULE_ENABLED) */
#if defined(HAL_SPI_MODULE_ENABLED) && !defined(HAL_GPIO_MODULE_ENABLED)
    #error "SPI module requires GPIO module!"
#endif /* defined(HAL_SPI_MODULE_ENABLED) && !defined(HAL_GPIO_MODULE_ENABLED) */
#if defined(HAL_SPI_MODULE_ENABLED) && !defined(HAL_SMU_MODULE_ENABLED)
    #error "SPI module requires SMU module!"
#endif /* defined(HAL_SPI_MODULE_ENABLED) && !defined(HAL_SMU_MODULE_ENABLED) */
#if defined(HAL_I2C_MODULE_ENABLED) && !defined(HAL_GPIO_MODULE_ENABLED)
    #error "I2C module requires GPIO module!"
#endif /* defined(HAL_I2C_MODULE_ENABLED) && !defined(HAL_GPIO_MODULE_ENABLED) */
#if defined(HAL_I2C_MODULE_ENABLED) && !defined(HAL_SMU_MODULE_ENABLED)
    #error "I2C module requires SMU module!"
#endif /* defined(HAL_I2C_MODULE_ENABLED) && !defined(HAL_SMU_MODULE_ENABLED) */
#if defined(HAL_ADC_MODULE_ENABLED) && !defined(HAL_GPIO_MODULE_ENABLED)
    #error "ADC module requires GPIO module!"
#endif /* defined(HAL_ADC_MODULE_ENABLED) && !defined(HAL_GPIO_MODULE_ENABLED) */
#if defined(HAL_ADC_MODULE_ENABLED) && !defined(HAL_SMU_MODULE_ENABLED)
    #error "ADC module requires SMU module!"
#endif /* defined(HAL_ADC_MODULE_ENABLED) && !defined(HAL_SMU_MODULE_ENABLED) */
#if defined(HAL_DAC_MODULE_ENABLED) && !defined(HAL_GPIO_MODULE_ENABLED)
    #error "DAC module requires GPIO module!"
#endif /* defined(HAL_DAC_MODULE_ENABLED) && !defined(HAL_GPIO_MODULE_ENABLED) */
#if defined(HAL_DAC_MODULE_ENABLED) && !defined(HAL_SMU_MODULE_ENABLED)
    #error "DAC module requires SMU module!"
#endif /* defined(HAL_DAC_MODULE_ENABLED) && !defined(HAL_SMU_MODULE_ENABLED) */
#if defined(HAL_QSPI_MODULE_ENABLED) && !defined(HAL_GPIO_MODULE_ENABLED)
    #error "QSPI module requires GPIO module!"
#endif /* defined(HAL_QSPI_MODULE_ENABLED) && !defined(HAL_GPIO_MODULE_ENABLED) */
#if defined(HAL_QSPI_MODULE_ENABLED) && !defined(HAL_SMU_MODULE_ENABLED)
    #error "QSPI module requires SMU module!"
#endif /* defined(HAL_QSPI_MODULE_ENABLED) && !defined(HAL_SMU_MODULE_ENABLED) */
#if defined(HAL_TIM_MODULE_ENABLED) && !defined(HAL_GPIO_MODULE_ENABLED)
    #error "TIM module requires GPIO module!"
#endif /* defined(HAL_TIM_MODULE_ENABLED) && !defined(HAL_GPIO_MODULE_ENABLED) */
#if defined(HAL_TIM_MODULE_ENABLED) && !defined(HAL_SMU_MODULE_ENABLED)
    #error "TIM module requires SMU module!"
#endif /* defined(HAL_TIM_MODULE_ENABLED) && !defined(HAL_SMU_MODULE_ENABLED) */
#if defined(HAL_DMA_MODULE_ENABLED) && !defined(HAL_SMU_MODULE_ENABLED)
    #error "DMA module requires SMU module!"
#endif /* defined(HAL_DMA_MODULE_ENABLED) && !defined(HAL_SMU_MODULE_ENABLED) */
#if defined(HAL_CANFD_MODULE_ENABLED) && !defined(HAL_GPIO_MODULE_ENABLED)
    #error "CANFD module requires GPIO module!"
#endif /* defined(HAL_CANFD_MODULE_ENABLED) && !defined(HAL_GPIO_MODULE_ENABLED) */
#if defined(HAL_CANFD_MODULE_ENABLED) && !defined(HAL_SMU_MODULE_ENABLED)
    #error "CANFD module requires SMU module!"
#endif /* defined(HAL_CANFD_MODULE_ENABLED) && !defined(HAL_SMU_MODULE_ENABLED) */
#if defined(HAL_PKA_MODULE_ENABLED) && !defined(HAL_SMU_MODULE_ENABLED)
    #error "PKA module requires SMU module!"
#endif /* defined(HAL_PKA_MODULE_ENABLED) && !defined(HAL_SMU_MODULE_ENABLED) */
#if defined(HAL_SPACC_MODULE_ENABLED) && !defined(HAL_SMU_MODULE_ENABLED)
    #error "SPACC module requires SMU module!"
#endif /* defined(HAL_SPACC_MODULE_ENABLED) && !defined(HAL_SMU_MODULE_ENABLED) */
#if defined(HAL_MAC_MODULE_ENABLED) && !defined(HAL_SMU_MODULE_ENABLED)
    #error "MAC module requires SMU module!"
#endif /* defined(HAL_MAC_MODULE_ENABLED) && !defined(HAL_SMU_MODULE_ENABLED) */
#if defined(HAL_SMU_MODULE_ENABLED) && !defined(HAL_FLASH_MODULE_ENABLED)
    #error "SMU module requires FLASH module (EFLASH controller clock synchronization)!"
#endif /* defined(HAL_SMU_MODULE_ENABLED) && !defined(HAL_FLASH_MODULE_ENABLED) */

/* Exported variables ---------------------------------------------------------*/

/**
 * @brief System clock frequency, in Hz.
 * @note  This variable is the frequency reference of the HAL time base. It
 *        shall be updated whenever the system clock changes and shall match
 *        the CPU mcycle counting frequency; call HAL_InitTick() afterwards to
 *        establish a new cycle baseline.
 * @note  The value is initialized to the frequency of the clock source that
 *        reset selects, i.e. the fast internal RC oscillator (16 MHz), and not
 *        to the external oscillator. An application that programs another
 *        clock tree must assign the new frequency here before it rebuilds the
 *        tick: a value that does not match the mcycle frequency scales every
 *        tick and every delay by the same factor.
 */
extern __IO uint32 SystemCoreClock;

/* Exported functions ---------------------------------------------------------*/

/** @defgroup HAL_Exported_Functions_Group1 Initialization and de-initialization
 *  @brief    Initialization and de-initialization functions
 *  @{
 */

/**
 * @brief  Initialize the HAL library; it must be the first instruction to be
 *         executed in the main program, before calling any other HAL function. (NON-BLOCKING)
 * @note   The default implementation initializes a polled 1 ms time base from
 *         CPU mcycle and calls HAL_MspInit(). It does not configure interrupts
 *         or access CLINT resources.
 * @note   SystemCoreClock shall match the mcycle frequency. If the clock is
 *         changed later, settle the old tick with HAL_GetTick(), update
 *         SystemCoreClock, and call HAL_InitTick() to rebuild the baseline.
 * @note   The clock the application has selected must be at least as fast as
 *         the tick frequency and an integer multiple of it, otherwise
 *         HAL_InitTick() fails and this function reports that as HAL_ERROR.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR
 */
HAL_StatusTypeDef HAL_Init(void);

/**
 * @brief  De-initialize the common part of the HAL and stop the time base
 *         source. This function is optional. (NON-BLOCKING)
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR
 */
HAL_StatusTypeDef HAL_DeInit(void);

/**
 * @brief  Initializes the MSP (MCU Support Package). Weak empty function,
 *         implemented by the user when the global low level hardware
 *         initialization is needed.
 * @retval None
 */
__weak void HAL_MspInit(void);

/**
 * @brief  De-initializes the MSP. Weak empty function, implemented by the
 *         user when the global low level hardware de-initialization is
 *         needed.
 * @retval None
 */
__weak void HAL_MspDeInit(void);

/**
 * @brief  Configure the source of the time base to have a 1 ms time base. (NON-BLOCKING)
 * @note   Called automatically by HAL_Init(). The default implementation uses
 *         csr_read(CSR_MCYCLE/CSR_MCYCLEH) and requires SystemCoreClock to
 *         match the mcycle frequency and be divisible by 1000. No interrupt
 *         or CLINT resource is configured. Declared as __weak for replacement
 *         by a complete custom time-base implementation.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR
 */
__weak HAL_StatusTypeDef HAL_InitTick(void);

/**
 * @}
 */

/** @defgroup HAL_Exported_Functions_Group2 HAL Control functions
 *  @brief    HAL Control functions
 *  @{
 */

/**
 * @brief  Increment the global tick variable "uwTick" used as the application
 *         time base. Declared as __weak to be overridden in case of another
 *         implementation in the user file. (NON-BLOCKING)
 * @note   The default implementation is a compatibility hook that settles
 *         elapsed mcycle time and increments the tick without touching MTI.
 * @retval None
 */
__weak void HAL_IncTick(void);

/**
 * @brief  Provide a tick value in milliseconds. (NON-BLOCKING)
 * @note   Declared as __weak to be overridden in case of another
 *         implementation in the user file.
 * @retval uint32: tick value
 */
__weak uint32 HAL_GetTick(void);

/**
 * @brief  Provide a blocking delay (in milliseconds) based directly on the
 *         CPU mcycle counter. Declared as __weak to be overridden in case of
 *         another implementation in the user file. (BLOCKING)
 * @note   This implementation polls mcycle and does not require an interrupt
 *         or access CLINT resources.
 * @note   The conversion to cycles multiplies before it divides
 *         (Delay * SystemCoreClock / 1000, widened to 64 bits), so it stays
 *         exact for every SystemCoreClock value and a frequency that is not an
 *         integer multiple of 1000 Hz is not a precondition.
 * @note   Precondition: SystemCoreClock shall be >= 1000 Hz and equal to the
 *         mcycle frequency. When it is not, the requested time cannot be
 *         converted into cycles; the interface then reports that through
 *         assert_param() (visible in a USE_FULL_ASSERT build) and returns
 *         without delaying, instead of silently delaying a wrong amount of
 *         time (HAL-REQ-029). The public signature carries no result value, so
 *         the assertion and this documented precondition are the only channels
 *         through which the violation can be reported.
 * @param  Delay: specifies the delay time length, in milliseconds.
 * @retval None
 */
__weak void HAL_Delay(uint32 Delay);

/**
 * @brief  Suspend the tick increment. (NON-BLOCKING)
 * @note   Settles and freezes the cycle-derived tick without changing any
 *         interrupt or CLINT state.
 * @retval None
 */
__weak void HAL_SuspendTick(void);

/**
 * @brief  Resume the tick increment. (NON-BLOCKING)
 * @note   Re-establishes the mcycle baseline so the cycle-derived tick
 *         resumes, without changing any interrupt or CLINT state.
 * @retval None
 */
__weak void HAL_ResumeTick(void);

/**
 * @brief  Return the HAL library revision. (NON-BLOCKING)
 * @retval uint32: version, 0xXYZR (8 bits for each decimal, R for RC)
 */
uint32 HAL_GetHalVersion(void);

/**
 * @brief  Return the time base frequency of the HAL tick. (NON-BLOCKING)
 * @note   The returned value is the HAL_TICK_FREQ_HZ system parameter of the
 *         user configuration file (1000 Hz for the default 1 ms time base),
 *         therefore it always matches the frequency the time base is built
 *         with. A time base built with another frequency (through a
 *         re-implemented HAL_InitTick()) shall update that parameter.
 * @retval uint32: tick frequency, in Hz
 */
uint32 HAL_GetTickFreq(void);

/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_H */

/*****END OF FILE*****/
