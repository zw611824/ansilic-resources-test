/**
 * @file    SPI_IT_DRV_011.c
 * @brief   HAL SPI integration test case 011 (DMA driven full duplex and the
 *          CPU driven loopback of the data path).
 *
 * HAL library port of the original AS32x601 standard-library test case
 * SPI_IT_DRV_011.c, which drives SPI3 in master mode and exchanges 64 frames
 * through the DMA controller (one channel per direction). Only HAL library APIs
 * are used.
 *
 * Tested functionality:
 *   HAL_SPI_StructInit()
 *   HAL_SPI_Init()
 *   HAL_SPI_ResetFIFO()
 *   HAL_SPI_NSSConfig()         (asserts SPI_Slave0 around every transfer)
 *   HAL_SPI_Cmd()
 *   HAL_SPI_SendData() / HAL_SPI_SendDataLast() / HAL_SPI_ReceiveData()
 *   HAL_SPI_GetFlagStatus()
 *   HAL_DMA_StructInit() / HAL_DMA_Init()
 *   HAL_DMA_ConfigPeriphIF()    (SPI3_IF on both channels)
 *   HAL_SPI_TransmitReceive_DMA()
 *   HAL_SPI_IRQHandler() / HAL_DMA_IRQHandler()
 *   HAL_SPI_TxRxCpltCallback()
 *   HAL_PLIC_Init()             (SPI3 and DMA1 interrupt lines)
 *   HAL_SPI_GetState() / HAL_SPI_GetError() / HAL_DMA_GetState()
 *   HAL_SPI_MspInit()           (overridden: clock gate, reset pulse, pins)
 *
 * Test procedure:
 *   Phase 1 (three rounds) - DMA driven full duplex:
 *   1. initialize SPI3 in master mode (8 bit, Motorola mode 0, normal
 *      transmission, divider /512);
 *   2. initialize the two DMA channels of the SPI3 request (one per direction),
 *      route the request number to both and bind them to the handle. The
 *      peripheral side of a channel always moves one 32 bit FIFO word, the
 *      memory side one frame (8 bit here);
 *   3. start a DMA driven full duplex transfer of 64 frames (0x00 .. 0x3F);
 *   4. wait for the completion callback and check the API behaviour: return
 *      code, reported completion, handle states and error code.
 *   Phase 2 (three rounds) - CPU driven loopback:
 *   5. transmit 16 frames with HAL_SPI_SendData() / HAL_SPI_SendDataLast() and
 *      receive them with HAL_SPI_ReceiveData(), then compare the buffer.
 *
 * Expected behaviour:
 *   - HAL_SPI_TransmitReceive_DMA() returns HAL_OK, the completion callback is
 *     reported, the SPI handle and both DMA channels return to READY and the
 *     error code stays NONE;
 *   - the loopback buffer holds 0x00 .. 0x0F, so the comparison prints [PASS]
 *     and "summary : failures = 0".
 *
 * Note (why the received buffer of the DMA phase is only reported):
 *   - This device keeps ONE DMA request per SPI instance (see the DMA
 *     connection table of the design manual: DMA1 request 2 = SPI3) and the
 *     request is driven by the transmit FIFO space, not by the received frames.
 *     Two channels mapped on that single request steal each other's request:
 *     the receive channel is granted transfers while the receive FIFO is still
 *     empty (reading 0) and the transmit channel only gets a part of the
 *     requests, so the received buffer of a two channel DMA transfer is
 *     incomplete by an amount that changes from run to run (measured: the
 *     correct tail is 24 / 32 / 56 / 64 frames in different runs).
 *     The DMA phase therefore validates the API and the state machine of the
 *     driver; the data path is validated by the CPU driven loopback phase,
 *     which is deterministic.
 *   - External stimulus is required for the data comparison: an SPI slave (or a
 *     MOSI to MISO loop) must return the frames. Without it the DMA transfer
 *     still completes (the master generates its own clock) but the received
 *     frames do not match.
 *   - SPI3 is served by DMA1 (SPI0..SPI2 are served by DMA0).
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console: USART0 on GPIOD pin 8 (TX) / pin 9 (RX), 115200 8N1 */
#define TEST_BAUDRATE                   (115200U)

/* Device under test: SPI3 (as in the reference test case)
 *   CS0  = PC10   SCK  = PD3   MOSI = PD1   MISO = PD2
 */
#define TEST_SPI                        SPI3
#define TEST_SPI_IRQn                   SPI3_IRQn
#define TEST_DMA                        DMA1
#define TEST_DMA_IRQn                   DMA1_IRQn
#define TEST_DMA_RX_INSTANCE            DMA1_Channel12
#define TEST_DMA_TX_INSTANCE            DMA1_Channel13
#define TEST_CS_PORT                    GPIOC
#define TEST_CS_PIN                     GPIO_PIN_10
#define TEST_CS_SOURCE                  GPIO_PinSource10
#define TEST_SCK_PORT                   GPIOD
#define TEST_SCK_PIN                    GPIO_PIN_3
#define TEST_SCK_SOURCE                 GPIO_PinSource3
#define TEST_MOSI_PORT                  GPIOD
#define TEST_MOSI_PIN                   GPIO_PIN_1
#define TEST_MOSI_SOURCE                GPIO_PinSource1
#define TEST_MISO_PORT                  GPIOD
#define TEST_MISO_PIN                   GPIO_PIN_2
#define TEST_MISO_SOURCE                GPIO_PinSource2
#define TEST_PIN_AF                     GPIO_AF_SPI3

/* Frame geometry, pacing and the poll bound of the wait loops */
#define FRAME_COUNT                     (64U)
#define LOOPBACK_FRAMES                 (16U)
#define WAIT_POLLS                      (20000000U)
#define ROUNDS                          (3U)
#define SETTLE_MS                       (20U)
#define RETRY_PERIOD_MS                 (1000U)

/* Private variables ---------------------------------------------------------*/
static SPI_HandleTypeDef hspi_dev;              /*!< device under test      */
static HAL_SMU_HandleTypeDef hsmu_clk;          /*!< SMU handle (clock tree) */
static DMA_HandleTypeDef hdma_rx;               /*!< receive channel        */
static DMA_HandleTypeDef hdma_tx;               /*!< transmit channel       */
static uint8 tx_data[FRAME_COUNT];              /*!< transmit pattern        */
static uint8 rx_data[FRAME_COUNT];              /*!< received frames         */
static uint8 rx_expected[FRAME_COUNT];          /*!< expected frames         */
static volatile uint32 check_failures = 0U;     /*!< failed check counter    */
static volatile uint32 rxrx_cplt_count = 0U;    /*!< completion callbacks    */
static volatile uint32 transfer_done = 0U;      /*!< completion flag         */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void DMA_Config(void);
static void SPI_PLIC_Init(void);
static void BufferInit(void);
static void SPI_Restart(void);
static void DMA_Phase(void);
static void Loopback_Phase(void);
static void Check(const char *name, uint32 condition);
static void Summary(void);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    SPI_InitTypeDef spi_init;
    HAL_StatusTypeDef status;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock tree */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART (USART0 on GPIOD pin 8 / pin 9) */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== SPI_IT_DRV_011 : DMA driven full duplex (SPI3) ===\r\n");

    /* Transmit pattern 0x00 .. 0x00 + n, same expected pattern from the peer */
    BufferInit();

    /* Step 1: initialize the device under test */
    __HAL_CLEAR_STRUCT(&hspi_dev);
    HAL_SPI_StructInit(&spi_init);
    spi_init.SPI_CLKDiv       = SPI_CLKDiv512;
    spi_init.SPI_Mode         = SPI_Mode_Master;
    spi_init.SPI_FrameSize    = SPI_FrameSize_8b;
    spi_init.SPI_MotorolaMode = SPI_Motorola_Mode0;
    spi_init.SPI_TransMode    = SPI_TransNor;

    hspi_dev.Instance = TEST_SPI;
    hspi_dev.Init     = spi_init;

    status = HAL_SPI_Init(&hspi_dev);
    /* The slave select is not part of the initialization: SSR
     * resets to 0 (no slave selected) and HAL_SPI_Init() does not
     * touch it, so the selection has to be programmed here. */
    HAL_SPI_ResetFIFO(&hspi_dev, SPI_RESETFIFO_TXANDRX);
    HAL_SPI_NSSConfig(&hspi_dev, SPI_Slave0, SPI_ENABLE);
    Check("HAL_SPI_Init returns HAL_OK", (uint32)((status == HAL_OK) ? 1U : 0U));
    Check("state after init is READY",
          (uint32)((HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_READY) ? 1U : 0U));

    /* Step 2: DMA channels and interrupt routing */
    DMA_Config();
    SPI_PLIC_Init();

    hspi_dev.hdmatx = &hdma_tx;
    hspi_dev.hdmarx = &hdma_rx;
    Check("DMA receive channel is READY",
          (uint32)((HAL_DMA_GetState(&hdma_rx) == HAL_DMA_STATE_READY) ? 1U : 0U));
    Check("DMA transmit channel is READY",
          (uint32)((HAL_DMA_GetState(&hdma_tx) == HAL_DMA_STATE_READY) ? 1U : 0U));

    /* Phase 1: the DMA driven full duplex API */
    DMA_Phase();

    /* Phase 2: the data path, moved by the CPU (deterministic) */
    Loopback_Phase();

    /* Release the slave select, so the lines are not left asserted */
    HAL_SPI_NSSConfig(&hspi_dev, SPI_Slave0, SPI_DISABLE);

    Summary();

    while (1)
    {
        delay_ms(1000U);
    }
}

/**
 * @brief  Fill the transmit and the expected receive buffer.
 * @param  None
 * @retval None
 */
static void BufferInit(void)
{
    uint32 index;

    for (index = 0U; index < FRAME_COUNT; index++)
    {
        tx_data[index]     = (uint8)index;
        rx_expected[index] = (uint8)index;
        rx_data[index]     = 0x00U;
    }
}

/**
 * @brief  Initialize the two DMA channels that carry the SPI3 request.
 * @note   Both directions use the same request number (SPI3_IF). The peripheral
 *         side of a channel moves one 32 bit FIFO word per frame (the FIFO is
 *         word organized whatever the frame size is), the memory side moves one
 *         8 bit frame.
 * @param  None
 * @retval None
 */
static void DMA_Config(void)
{
    DMA_InitTypeDef dma_init;

    /* DMA controller clock gate and reset pulse */
    __HAL_SMU_DMA1_CLK_ENABLE();
    __HAL_SMU_DMA1_FORCE_RESET();
    __HAL_SMU_DMA1_RELEASE_RESET();

    /* Receive channel: peripheral (RXDR) to memory */
    __HAL_CLEAR_STRUCT(&hdma_rx);
    hdma_rx.Instance = TEST_DMA_RX_INSTANCE;

    HAL_DMA_StructInit(&dma_init);
    dma_init.DMA_PeripheralBaseAddr = (uint32)&TEST_SPI->RXDR;
    dma_init.DMA_MemoryBaseAddr     = (uint32)rx_data;
    dma_init.DMA_DIR                = DMA_PERIPH_TO_MEMORY;
    dma_init.DMA_BufferSize         = FRAME_COUNT;
    dma_init.DMA_PeripheralInc      = DMA_PINC_DISABLE;
    dma_init.DMA_MemoryInc          = DMA_MINC_ENABLE;
    dma_init.DMA_PeripheralDataSize = DMA_PDATAALIGN_WORD;
    dma_init.DMA_MemoryDataSize     = DMA_MDATAALIGN_BYTE;
    dma_init.DMA_Priority           = DMA_PRIORITY_HIGH;
    dma_init.DMA_M2M                = DMA_M2M_Disable;
    dma_init.DMA_Mode               = DMA_NORMAL;
    hdma_rx.Init = dma_init;

    Check("HAL_DMA_Init (receive channel)",
          (uint32)((HAL_DMA_Init(&hdma_rx) == HAL_OK) ? 1U : 0U));
    HAL_DMA_ConfigPeriphIF(&hdma_rx, SPI3_IF);

    /* Transmit channel: memory to peripheral (the end of send register, as the
     * driver uses it for the last frame of a transfer) */
    __HAL_CLEAR_STRUCT(&hdma_tx);
    hdma_tx.Instance = TEST_DMA_TX_INSTANCE;

    HAL_DMA_StructInit(&dma_init);
    dma_init.DMA_PeripheralBaseAddr = (uint32)&TEST_SPI->TXEDR;
    dma_init.DMA_MemoryBaseAddr     = (uint32)tx_data;
    dma_init.DMA_DIR                = DMA_MEMORY_TO_PERIPH;
    dma_init.DMA_BufferSize         = FRAME_COUNT;
    dma_init.DMA_PeripheralInc      = DMA_PINC_DISABLE;
    dma_init.DMA_MemoryInc          = DMA_MINC_ENABLE;
    dma_init.DMA_PeripheralDataSize = DMA_PDATAALIGN_WORD;
    dma_init.DMA_MemoryDataSize     = DMA_MDATAALIGN_BYTE;
    dma_init.DMA_Priority           = DMA_PRIORITY_HIGH;
    dma_init.DMA_M2M                = DMA_M2M_Disable;
    dma_init.DMA_Mode               = DMA_NORMAL;
    hdma_tx.Init = dma_init;

    Check("HAL_DMA_Init (transmit channel)",
          (uint32)((HAL_DMA_Init(&hdma_tx) == HAL_OK) ? 1U : 0U));
    HAL_DMA_ConfigPeriphIF(&hdma_tx, SPI3_IF);
}

/**
 * @brief  Route the SPI3 and DMA1 interrupt lines through the PLIC.
 * @param  None
 * @retval None
 */
static void SPI_PLIC_Init(void)
{
    PLIC_InitTypeDef plic;

    __HAL_SMU_PLIC_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&plic);
    plic.Size               = sizeof(plic);
    plic.Version            = PLIC_INIT_VERSION;
    plic.PLIC_IRQPriority   = 1U;
    plic.PLIC_IRQChannelCmd = ENABLE;

    plic.PLIC_IRQChannel    = TEST_SPI_IRQn;
    HAL_PLIC_Init(&plic);

    /* The DMA controller raises its own interrupt line */
    plic.PLIC_IRQChannel    = TEST_DMA_IRQn;
    HAL_PLIC_Init(&plic);
}

/**
 * @brief  Put the device under test back into a clean, enabled state.
 * @note   The instance is disabled, both FIFOs are reset and every latched
 *         event is cleared before it is enabled again, so that the leftovers of
 *         a transfer that was cut short by the round boundary cannot drive the
 *         next round.
 * @param  None
 * @retval None
 */
static void SPI_Restart(void)
{
    HAL_SPI_Cmd(&hspi_dev, SPI_DISABLE);
    HAL_SPI_ResetFIFO(&hspi_dev, SPI_RESETFIFO_TXANDRX);
    hspi_dev.Instance->IFCR = (SPI_CLEAR_TD | SPI_CLEAR_RXO | SPI_CLEAR_TXE |
                               SPI_CLEAR_NSSV | SPI_CLEAR_RXNE | SPI_CLEAR_TXNF);
    HAL_SPI_Cmd(&hspi_dev, SPI_ENABLE);
    HAL_SPI_NSSConfig(&hspi_dev, SPI_Slave0, SPI_ENABLE);
}

/**
 * @brief  Phase 1: drive the full duplex transfer through the two DMA channels.
 * @note   The received buffer is printed but not compared: the single DMA
 *         request of this device cannot pace a receive channel (see the note in
 *         the file header).
 * @param  None
 * @retval None
 */
static void DMA_Phase(void)
{
    HAL_StatusTypeDef status;
    HAL_SPI_StateTypeDef spi_state;
    HAL_DMA_StateTypeDef dma_rx_state;
    HAL_DMA_StateTypeDef dma_tx_state;
    uint32 index;
    uint32 round;
    uint32 polls;
    uint32 callbacks;
    uint32 error;
    uint32 mismatches;

    for (round = 1U; round <= ROUNDS; round++)
    {
        printf("\r\n-- round %u : HAL_SPI_TransmitReceive_DMA --\r\n",
               PRINT_U32(round));

        for (index = 0U; index < FRAME_COUNT; index++)
        {
            rx_data[index] = 0x00U;
        }
        rxrx_cplt_count = 0U;
        transfer_done   = 0U;
        SPI_Restart();

        status = HAL_SPI_TransmitReceive_DMA(&hspi_dev, tx_data, rx_data,
                                             FRAME_COUNT);
        Check("HAL_SPI_TransmitReceive_DMA returns HAL_OK",
              (uint32)((status == HAL_OK) ? 1U : 0U));
        if (status != HAL_OK)
        {
            printf("error code     : 0x%08X (0x10 = DMA, 0x20 = parameter)\r\n",
                   PRINT_U32(HAL_SPI_GetError(&hspi_dev)));
        }

        /* Wait for the completion callback (bounded: without a peer the
         * transfer still completes, the master generates its own clock) */
        polls = 0U;
        while ((transfer_done == 0U) && (polls < WAIT_POLLS))
        {
            polls++;
        }

        /* The two channels share one DMA request, so an extra completion can
         * still be reported a moment after the first one: let the handle states
         * settle before they are sampled */
        delay_ms(SETTLE_MS);

        spi_state    = HAL_SPI_GetState(&hspi_dev);
        dma_rx_state = HAL_DMA_GetState(&hdma_rx);
        dma_tx_state = HAL_DMA_GetState(&hdma_tx);
        error        = HAL_SPI_GetError(&hspi_dev);
        callbacks    = rxrx_cplt_count;

        Check("the completion callback is reported",
              (uint32)((callbacks >= 1U) ? 1U : 0U));
        Check("state is READY after the transfer",
              (uint32)((spi_state == HAL_SPI_STATE_READY) ? 1U : 0U));
        Check("DMA receive channel is READY again",
              (uint32)((dma_rx_state == HAL_DMA_STATE_READY) ? 1U : 0U));
        Check("DMA transmit channel is READY again",
              (uint32)((dma_tx_state == HAL_DMA_STATE_READY) ? 1U : 0U));
        Check("error code after the transfer is NONE",
              (uint32)((error == HAL_SPI_ERROR_NONE) ? 1U : 0U));

        mismatches = 0U;
        for (index = 0U; index < FRAME_COUNT; index++)
        {
            if (rx_data[index] != rx_expected[index])
            {
                mismatches++;
            }
        }

        printf("callbacks      : %u\r\n", PRINT_U32(callbacks));
        printf("rx[0..7]       : ");
        for (index = 0U; index < 8U; index++)
        {
            printf("0x%02X ", PRINT_U32(rx_data[index]));
        }
        printf("... (mismatches %u)\r\n", PRINT_U32(mismatches));
        printf("note           : the DMA phase checks the API and the handle\n");
        printf("                 states; the data path is checked by the CPU\n");
        printf("                 loopback phase below\r\n");

        if (transfer_done == 0U)
        {
            printf("note           : no completion - an SPI slave (or a MOSI to\n");
            printf("                 MISO loop) is required to return the frames\n");
        }

        HAL_SPI_NSSConfig(&hspi_dev, SPI_Slave0, SPI_DISABLE);
        delay_ms(RETRY_PERIOD_MS);
    }
}

/**
 * @brief  Phase 2: exchange a small block through the data path with the CPU.
 * @note   The block has to be no larger than the receive FIFO depth (32 frames),
 *         because the frames are queued before they are read back.
 * @param  None
 * @retval None
 */
static void Loopback_Phase(void)
{
    uint32 index;
    uint32 round;
    uint32 polls;
    uint32 mismatches;
    uint32 starved;

    printf("\r\n-- CPU driven loopback of the data path --\r\n");

    for (round = 1U; round <= ROUNDS; round++)
    {
        printf("\r\n-- round %u : CPU driven loopback --\r\n", PRINT_U32(round));

        for (index = 0U; index < FRAME_COUNT; index++)
        {
            rx_data[index] = 0x00U;
        }
        mismatches = 0U;
        starved    = 0U;
        SPI_Restart();

        /* Transmit the block: the write is held while the transmit FIFO
         * reports full, the last frame closes the transfer */
        for (index = 0U; index < LOOPBACK_FRAMES; index++)
        {
            polls = 0U;
            while ((HAL_SPI_GetFlagStatus(&hspi_dev, SPI_Flag_TXF) != 0U) &&
                   (polls < WAIT_POLLS))
            {
                polls++;
            }
            if (index == (LOOPBACK_FRAMES - 1U))
            {
                HAL_SPI_SendDataLast(&hspi_dev, (uint32)tx_data[index]);
            }
            else
            {
                HAL_SPI_SendData(&hspi_dev, (uint32)tx_data[index]);
            }
        }

        /* Collect the echoed frames */
        for (index = 0U; index < LOOPBACK_FRAMES; index++)
        {
            polls = 0U;
            while ((HAL_SPI_GetFlagStatus(&hspi_dev, SPI_Flag_RXE) != 0U) &&
                   (polls < WAIT_POLLS))
            {
                polls++;
            }
            if (HAL_SPI_GetFlagStatus(&hspi_dev, SPI_Flag_RXE) != 0U)
            {
                starved = 1U;
                break;
            }
            rx_data[index] = (uint8)(HAL_SPI_ReceiveData(&hspi_dev) & 0xFFU);
        }

        for (index = 0U; index < LOOPBACK_FRAMES; index++)
        {
            if (rx_data[index] != rx_expected[index])
            {
                mismatches++;
            }
        }

        printf("frames         : %u (starved %u, mismatches %u)\r\n",
               PRINT_U32(LOOPBACK_FRAMES), PRINT_U32(starved),
               PRINT_U32(mismatches));
        printf("rx[0..7]       : ");
        for (index = 0U; index < 8U; index++)
        {
            printf("0x%02X ", PRINT_U32(rx_data[index]));
        }
        printf("\r\n");

        Check("the loopback frames match the transmitted pattern",
              (uint32)(((starved == 0U) && (mismatches == 0U)) ? 1U : 0U));
        /* The last frame closes the transfer: the shifter is idle again and the
         * slave select has been released by the interface */
        Check("the interface reports the end of the transfer",
              (uint32)((HAL_SPI_GetFlagStatus(&hspi_dev, SPI_Flag_BUSS) == 0U) ? 1U : 0U));

        HAL_SPI_NSSConfig(&hspi_dev, SPI_Slave0, SPI_DISABLE);
        delay_ms(RETRY_PERIOD_MS);
    }
}

/**
 * @brief  Report the result of one check.
 * @param  name: short description of the check.
 * @param  condition: 0 = FAIL, non zero = PASS.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("%-46s : [PASS]\r\n", name);
    }
    else
    {
        check_failures++;
        printf("%-46s : [FAIL]\r\n", name);
    }
}

/**
 * @brief  Print the accumulated failure counter.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(check_failures));
}

/**
 * @brief  SPI3 interrupt handler (weak symbol of the trap entry).
 * @param  None
 * @retval None
 */
void SPI3_IRQ_Handler(void)
{
    HAL_SPI_IRQHandler(&hspi_dev);
}

/**
 * @brief  DMA1 interrupt handler (weak symbol of the trap entry).
 * @note   One line is shared by the 16 channels of the controller, so every
 *         active channel handle of this case is served here.
 * @param  None
 * @retval None
 */
void DMA1_IRQ_Handler(void)
{
    HAL_DMA_IRQHandler(&hdma_rx);
    HAL_DMA_IRQHandler(&hdma_tx);
}

/**
 * @brief  Full duplex completion callback of the device under test.
 * @param  hspi: SPI handle.
 * @retval None
 */
void HAL_SPI_TxRxCpltCallback(SPI_HandleTypeDef *hspi)
{
    if (hspi == &hspi_dev)
    {
        rxrx_cplt_count++;
        transfer_done = 1U;
    }
}

/**
 * @brief  Error callback of the device under test.
 * @param  hspi: SPI handle.
 * @retval None
 */
void HAL_SPI_ErrorCallback(SPI_HandleTypeDef *hspi)
{
    if (hspi == &hspi_dev)
    {
        printf("[irq] SPI error, error code 0x%08X\r\n",
               PRINT_U32(HAL_SPI_GetError(&hspi_dev)));
    }
}

/**
 * @brief  MSP initialization of the device under test.
 * @note   Strong override of the weak driver callback.
 * @param  hspi: SPI handle of the device under test.
 * @retval None
 */
void HAL_SPI_MspInit(SPI_HandleTypeDef *hspi)
{
    GPIO_InitTypeDef gpio;

    if (hspi->Instance != TEST_SPI)
    {
        return;
    }

    /* Peripheral clock gate and reset pulse */
    __HAL_SMU_SPI3_CLK_ENABLE();
    __HAL_SMU_SPI3_FORCE_RESET();
    __HAL_SMU_SPI3_RELEASE_RESET();

    /* Port clock gates used by this case */
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&gpio);
    gpio.Size         = sizeof(gpio);
    gpio.Version      = GPIO_INIT_VERSION;
    gpio.Pull         = GPIO_NOPULL;
    gpio.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    gpio.Alternate    = TEST_PIN_AF;

    /* CS0 (driven by the SSR register) */
    HAL_GPIO_PinAFConfig(TEST_CS_PORT, TEST_CS_SOURCE, TEST_PIN_AF);
    gpio.Pin  = TEST_CS_PIN;
    gpio.Mode = GPIO_MODE_AF_PP;
    HAL_GPIO_Init(TEST_CS_PORT, &gpio);

    /* SCK */
    HAL_GPIO_PinAFConfig(TEST_SCK_PORT, TEST_SCK_SOURCE, TEST_PIN_AF);
    gpio.Pin = TEST_SCK_PIN;
    HAL_GPIO_Init(TEST_SCK_PORT, &gpio);

    /* MOSI */
    HAL_GPIO_PinAFConfig(TEST_MOSI_PORT, TEST_MOSI_SOURCE, TEST_PIN_AF);
    gpio.Pin = TEST_MOSI_PIN;
    HAL_GPIO_Init(TEST_MOSI_PORT, &gpio);

    /* MISO: alternate function input, floating */
    HAL_GPIO_PinAFConfig(TEST_MISO_PORT, TEST_MISO_SOURCE, TEST_PIN_AF);
    gpio.Pin  = TEST_MISO_PIN;
    gpio.Mode = GPIO_MODE_INPUT;
    HAL_GPIO_Init(TEST_MISO_PORT, &gpio);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the CLINT / CMU / MPU / USART integration tests.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef    SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the same set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls (PMU_CheckState) */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
