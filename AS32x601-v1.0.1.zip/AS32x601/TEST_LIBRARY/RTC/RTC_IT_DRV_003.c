/**
 * @file    RTC_IT_DRV_003.c
 * @brief   HAL RTC integration test case 003: binary time / date round trip with boundary values.
 *
 * The calendar is written and read back in RTC_FORMAT_BIN with the calendar
 * stopped, so the round trip is exact (a running calendar would move the tenth of
 * a second field between the write and the read). Boundary values of every field
 * are covered, and the counter is then observed running.
 *
 * Tested functionality:
 *   HAL_RTC_Init() / HAL_RTC_Cmd()
 *   HAL_RTC_SetTime() / HAL_RTC_GetTime() (RTC_FORMAT_BIN)
 *   HAL_RTC_SetDate() / HAL_RTC_GetDate() (RTC_FORMAT_BIN)
 *   HAL_RTC_TimeStructInit() / HAL_RTC_DateStructInit()
 *   HAL_RTC_GetState() / HAL_RTC_GetError()
 *
 * Expected behaviour:
 *   - every written field reads back unchanged while the calendar is stopped,
 *     including the boundary values (23:59:59.8, century 99, year 99, 12-31);
 *   - the tenth of a second field is a modulo ten counter and 8 is the highest
 *     value it stores: a written 9 completes the decade, so 23:59:59.9 carries
 *     into 00:00:00.0 of the next day instead of reading back unchanged;
 *   - with the calendar enabled the counters advance (the tenth of a second or the
 *     seconds field moves within the observation window);
 *   - disabling the calendar again freezes the counter.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* RTC divider coefficient. 1785 is the project baseline of the reference test
 * cases of this chip, 1638 is the other value documented by the library SRS;
 * both are legal hardware values (the driver only checks the 27 bit field
 * width). No test below depends on the resulting absolute frequency: the
 * checks are register read-backs or "the counter moved" observations. */
#define TEST_RTC_DIVISION           (1785U)

/* Calendar value used by the cases that need a known starting point */
#define TEST_TIME_HOURS             (15U)
#define TEST_TIME_MINUTES           (48U)
#define TEST_TIME_SECONDS           (0U)
#define TEST_TIME_TOS               (0U)
#define TEST_DATE_CENTURY           (20U)
#define TEST_DATE_YEAR              (25U)
#define TEST_DATE_MONTH             (RTC_Month_July)
#define TEST_DATE_DATE              (21U)
#define TEST_DATE_WEEKDAY           (RTC_Weekday_Monday)

/* Highest tenth of a second value the counter stores. The field is a modulo ten
 * counter: a written 9 completes the decade and the hardware carries into the
 * seconds at once, so 9 can never be read back. */
#define TEST_TIME_TOS_MAX           (8U)

/* Polling slice of the wait loops (ms) */
#define TEST_POLL_MS                (10U)

/* Reporting period of the final idle loop (ms) */
#define TEST_IDLE_MS                (1000U)

/* Number of month / weekday constants */
#define TEST_MONTH_COUNT            (12U)
#define TEST_WEEKDAY_COUNT          (7U)

/* Observation windows of the counter checks (ms) */
#define TEST_ADVANCE_MS             (1000U)
#define TEST_FREEZE_MS              (200U)

/* Private variables ---------------------------------------------------------*/
static RTC_HandleTypeDef hrtc_dev;          /*!< RTC device handle            */
static RTC_InitTypeDef   rtc_init;          /*!< RTC configuration structure  */
static RTC_TimeTypeDef   time_carry;        /*!< time only write of the carry */
static uint32            failures = 0U;     /*!< failed checks                */

/* Alarm interrupt bookkeeping (filled by the overridden weak callback) */
static volatile uint32   alarm_events = 0U; /*!< callback entries             */
static volatile uint32   alarm_cr_seen = 0U;/*!< CR register at callback time */

/* Loop bookkeeping of this case */
static uint8  month_table[TEST_MONTH_COUNT];
static uint8  weekday_table[TEST_WEEKDAY_COUNT];
static uint32 index;
static uint32 months_ok;
static uint32 weekdays_ok;
static uint32 elapsed;
static uint32 moved;
static uint8  start_tos;
static uint8  start_seconds;
static uint8  frozen_tos;
static uint8  frozen_seconds;

/* Last calendar read back by the report helpers */
static uint8 r_time_hours;
static uint8 r_time_minutes;
static uint8 r_time_seconds;
static uint8 r_time_tos;
static uint8 r_date_century;
static uint8 r_date_year;
static uint8 r_date_month;
static uint8 r_date_date;
static uint8 r_date_weekday;

/* Private function prototypes -----------------------------------------------*/
static void Check(const char *name, uint32 condition);
static void SystemClock_Init(void);
static void Rtc_Handle_Setup(void);
static HAL_StatusTypeDef Rtc_Start(void);
static HAL_StatusTypeDef Rtc_SetCalendar(uint8 hours, uint8 minutes, uint8 seconds, uint8 tos,
                                         uint8 century, uint8 year, uint8 month, uint8 date,
                                         uint8 weekday);
static HAL_StatusTypeDef Rtc_GetCalendar(void);
static uint8 Rtc_MonthToNumber(uint8 month);
static const char *Rtc_WeekdayName(uint8 weekday);
static void Rtc_PrintCalendar(const char *tag);

/* Exported interrupt entry ------------------------------------------------*/
/**
 * @brief  RTC interrupt entry, called by the shared PLIC dispatch table.
 * @note   Overrides the weak RTC_IRQ_Handler() of the PLIC driver; it hands the
 *         event to the HAL RTC interrupt handler, which clears the alarm flag
 *         and then calls HAL_RTC_AlarmEventCallback().
 */
void RTC_IRQ_Handler(void)
{
    HAL_RTC_AlarmIRQHandler(&hrtc_dev);
}

/**
 * @brief  Alarm event callback (weak function of the HAL RTC driver).
 * @note   Counts the events and snapshots CR so that the cases can observe the
 *         flag state the driver left behind. It must not block and must not
 *         call a locking RTC interface (interrupt context).
 * @param  hrtc pointer to a RTC_HandleTypeDef structure.
 * @retval None
 */
void HAL_RTC_AlarmEventCallback(RTC_HandleTypeDef *hrtc)
{
    UNUSED(hrtc);

    alarm_events++;
    alarm_cr_seen = hrtc_dev.Instance->CR;
}

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock tree */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n\r\n==== RTC_IT_DRV_003: binary time / date round trip with boundary values ====\r\n");
    printf("Data : %s\r\n", __DATE__);
    printf("Time : %s\r\n", __TIME__);

        /* ---- Step 1: initialization --------------------------------------- */
        Check("RTC init", (Rtc_Start() == HAL_OK));

        /* The round trip below is exact only when the counters are stopped: the
           tenth of a second field of a running calendar changes every tick. */
        Check("calendar stopped", (HAL_RTC_Cmd(&hrtc_dev, DISABLE) == HAL_OK));
        Check("RTC enable bit clear", ((RTC->CR & RTC_CR_EN) == 0U));

        /* ---- Step 2: time round trip (BIN) -------------------------------- */
        Check("time 00:00:00.0 accepted",
              (Rtc_SetCalendar(0U, 0U, 0U, 0U, TEST_DATE_CENTURY, TEST_DATE_YEAR,
                               TEST_DATE_MONTH, TEST_DATE_DATE, TEST_DATE_WEEKDAY) == HAL_OK));
        (void)Rtc_GetCalendar();
        Check("time 00:00:00.0 round trip",
              ((r_time_hours == 0U) && (r_time_minutes == 0U) &&
               (r_time_seconds == 0U) && (r_time_tos == 0U)));

        Check("time 23:59:59.8 accepted",
              (Rtc_SetCalendar(23U, 59U, 59U, TEST_TIME_TOS_MAX, TEST_DATE_CENTURY,
                               TEST_DATE_YEAR, TEST_DATE_MONTH, TEST_DATE_DATE,
                               TEST_DATE_WEEKDAY) == HAL_OK));
        (void)Rtc_GetCalendar();
        Check("time 23:59:59.8 round trip",
              ((r_time_hours == 23U) && (r_time_minutes == 59U) &&
               (r_time_seconds == 59U) && (r_time_tos == TEST_TIME_TOS_MAX)));

        /* One tenth of a second above the highest storable value: the write is
           accepted, but the counter completes the decade at once, so the value
           that reads back is 00:00:00.0 of the next day. Only the time is
           written here (HAL_RTC_SetTime) so that the date carried by the roll
           over stays observable. */
        __HAL_CLEAR_STRUCT(&time_carry);
        HAL_RTC_TimeStructInit(&time_carry);
        time_carry.RTC_Hours         = 23U;
        time_carry.RTC_Minutes       = 59U;
        time_carry.RTC_Seconds       = 59U;
        time_carry.RTC_TenthOfSecond = (uint8)(TEST_TIME_TOS_MAX + 1U);
        Check("time 23:59:59.9 accepted",
              (HAL_RTC_SetTime(&hrtc_dev, &time_carry, RTC_FORMAT_BIN) == HAL_OK));
        (void)Rtc_GetCalendar();
        Check("time 23:59:59.9 carries into the next day",
              ((r_time_hours == 0U) && (r_time_minutes == 0U) &&
               (r_time_seconds == 0U) && (r_time_tos == 0U) &&
               (r_date_century == TEST_DATE_CENTURY) && (r_date_year == TEST_DATE_YEAR) &&
               (r_date_month == TEST_DATE_MONTH) &&
               (r_date_date == (uint8)(TEST_DATE_DATE + 1U))));

        Check("time 12:34:56.7 accepted",
              (Rtc_SetCalendar(12U, 34U, 56U, 7U, TEST_DATE_CENTURY, TEST_DATE_YEAR,
                               TEST_DATE_MONTH, TEST_DATE_DATE, TEST_DATE_WEEKDAY) == HAL_OK));
        (void)Rtc_GetCalendar();
        Check("time 12:34:56.7 round trip",
              ((r_time_hours == 12U) && (r_time_minutes == 34U) &&
               (r_time_seconds == 56U) && (r_time_tos == 7U)));
        Rtc_PrintCalendar("time");

        /* ---- Step 3: date round trip (BIN) -------------------------------- */
        Check("date 00-01-01 (Sunday) accepted",
              (Rtc_SetCalendar(TEST_TIME_HOURS, TEST_TIME_MINUTES, TEST_TIME_SECONDS,
                               TEST_TIME_TOS, 0U, 0U, RTC_Month_January, 1U,
                               RTC_Weekday_Sunday) == HAL_OK));
        (void)Rtc_GetCalendar();
        Check("date 00-01-01 (Sunday) round trip",
              ((r_date_century == 0U) && (r_date_year == 0U) &&
               (r_date_month == RTC_Month_January) && (r_date_date == 1U) &&
               (r_date_weekday == RTC_Weekday_Sunday)));

        Check("date 99-12-31 (Saturday) accepted",
              (Rtc_SetCalendar(TEST_TIME_HOURS, TEST_TIME_MINUTES, TEST_TIME_SECONDS,
                               TEST_TIME_TOS, 99U, 99U, RTC_Month_December, 31U,
                               RTC_Weekday_Saturday) == HAL_OK));
        (void)Rtc_GetCalendar();
        Check("date 99-12-31 (Saturday) round trip",
              ((r_date_century == 99U) && (r_date_year == 99U) &&
               (r_date_month == RTC_Month_December) && (r_date_date == 31U) &&
               (r_date_weekday == RTC_Weekday_Saturday)));
        Rtc_PrintCalendar("date");

        /* ---- Step 4: every month constant is accepted ---------------------- */
        months_ok = 1U;
        for (index = 0U; index < (uint32)TEST_MONTH_COUNT; index++)
        {
            month_table[index] = (uint8)(RTC_Month_January + index);
            if (Rtc_SetCalendar(TEST_TIME_HOURS, TEST_TIME_MINUTES, TEST_TIME_SECONDS,
                                TEST_TIME_TOS, TEST_DATE_CENTURY, TEST_DATE_YEAR,
                                month_table[index], 15U, TEST_DATE_WEEKDAY) != HAL_OK)
            {
                months_ok = 0U;
                printf("month 0x%02X rejected\r\n", PRINT_U32(month_table[index]));
                continue;
            }
            (void)Rtc_GetCalendar();
            if (r_date_month != month_table[index])
            {
                months_ok = 0U;
                printf("month 0x%02X read back as 0x%02X\r\n",
                       PRINT_U32(month_table[index]), PRINT_U32(r_date_month));
            }
        }
        Check("all 12 month constants round trip", months_ok);

        /* ---- Step 5: every weekday constant is accepted -------------------- */
        weekdays_ok = 1U;
        for (index = 0U; index < (uint32)TEST_WEEKDAY_COUNT; index++)
        {
            weekday_table[index] = (uint8)(RTC_Weekday_Sunday + index);
            if (Rtc_SetCalendar(TEST_TIME_HOURS, TEST_TIME_MINUTES, TEST_TIME_SECONDS,
                                TEST_TIME_TOS, TEST_DATE_CENTURY, TEST_DATE_YEAR,
                                TEST_DATE_MONTH, 15U, weekday_table[index]) != HAL_OK)
            {
                weekdays_ok = 0U;
                printf("weekday 0x%02X rejected\r\n", PRINT_U32(weekday_table[index]));
                continue;
            }
            (void)Rtc_GetCalendar();
            if (r_date_weekday != weekday_table[index])
            {
                weekdays_ok = 0U;
                printf("weekday 0x%02X read back as 0x%02X\r\n",
                       PRINT_U32(weekday_table[index]), PRINT_U32(r_date_weekday));
            }
        }
        Check("all 7 weekday constants round trip", weekdays_ok);

        /* ---- Step 6: the counter advances when the calendar runs ----------- */
        Check("calendar re-enabled", (HAL_RTC_Cmd(&hrtc_dev, ENABLE) == HAL_OK));
        Check("known calendar programmed",
              (Rtc_SetCalendar(TEST_TIME_HOURS, TEST_TIME_MINUTES, TEST_TIME_SECONDS,
                               TEST_TIME_TOS, TEST_DATE_CENTURY, TEST_DATE_YEAR,
                               TEST_DATE_MONTH, TEST_DATE_DATE,
                               TEST_DATE_WEEKDAY) == HAL_OK));
        (void)Rtc_GetCalendar();
        start_tos = r_time_tos;
        start_seconds = r_time_seconds;

        elapsed = 0U;
        moved = 0U;
        while ((elapsed < TEST_ADVANCE_MS) && (moved == 0U))
        {
            delay_ms(TEST_POLL_MS);
            elapsed += TEST_POLL_MS;
            (void)Rtc_GetCalendar();
            if ((r_time_tos != start_tos) || (r_time_seconds != start_seconds))
            {
                moved = 1U;
            }
        }
        printf("counter moved after %u ms (tos %u -> %u, sec %u -> %u)\r\n",
               PRINT_U32(elapsed), PRINT_U32(start_tos), PRINT_U32(r_time_tos),
               PRINT_U32(start_seconds), PRINT_U32(r_time_seconds));
        Check("counter advances while the calendar runs", moved);

        /* ---- Step 7: the counter stops again ------------------------------- */
        Check("calendar disabled again", (HAL_RTC_Cmd(&hrtc_dev, DISABLE) == HAL_OK));
        (void)Rtc_GetCalendar();
        frozen_tos = r_time_tos;
        frozen_seconds = r_time_seconds;
        delay_ms(TEST_FREEZE_MS);
        (void)Rtc_GetCalendar();
        Check("counter frozen while the calendar is disabled",
              ((r_time_tos == frozen_tos) && (r_time_seconds == frozen_seconds)));
    /* ---- summary ------------------------------------------------------- */
    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(failures));

    /* Idle: keep the calendar observable on the console */
    while (1)
    {
        Rtc_PrintCalendar("idle");
        delay_ms(TEST_IDLE_MS);
    }
}

/* Private functions --------------------------------------------------------*/
/**
 * @brief  Prepare the RTC handle and its configuration structure.
 * @note   The configuration structure metafields (Size / Version / reserved
 *         words) are mandatory: HAL_RTC_Init() validates them at run time and
 *         rejects a structure that does not carry them.
 * @param  None
 * @retval None
 */
static void Rtc_Handle_Setup(void)
{
    __HAL_CLEAR_STRUCT(&hrtc_dev);
    hrtc_dev.Instance = RTC;

    __HAL_CLEAR_STRUCT(&rtc_init);
    rtc_init.Size     = sizeof(RTC_InitTypeDef);
    rtc_init.Version  = RTC_INIT_VERSION;
    rtc_init.Division = TEST_RTC_DIVISION;
    hrtc_dev.Init     = rtc_init;
}

/**
 * @brief  Initialize the RTC and report its state.
 * @param  None
 * @retval HAL status of the initialization.
 */
static HAL_StatusTypeDef Rtc_Start(void)
{
    HAL_StatusTypeDef status;

    Rtc_Handle_Setup();
    status = HAL_RTC_Init(&hrtc_dev);
    printf("RTC state = %u (1 = READY), error = %u\r\n",
           PRINT_U32(HAL_RTC_GetState(&hrtc_dev)),
           PRINT_U32(HAL_RTC_GetError(&hrtc_dev)));

    return status;
}

/**
 * @brief  Write the calendar (time and date) of the RTC.
 * @param  hours / minutes / seconds / tos: time fields.
 * @param  century / year / month / date / weekday: date fields.
 * @retval HAL_OK when both writes succeeded.
 */
static HAL_StatusTypeDef Rtc_SetCalendar(uint8 hours, uint8 minutes, uint8 seconds, uint8 tos,
                                         uint8 century, uint8 year, uint8 month, uint8 date,
                                         uint8 weekday)
{
    RTC_TimeTypeDef time;
    RTC_DateTypeDef dateS;
    HAL_StatusTypeDef status;

    __HAL_CLEAR_STRUCT(&time);
    __HAL_CLEAR_STRUCT(&dateS);
    HAL_RTC_TimeStructInit(&time);
    HAL_RTC_DateStructInit(&dateS);

    time.RTC_Hours         = hours;
    time.RTC_Minutes       = minutes;
    time.RTC_Seconds       = seconds;
    time.RTC_TenthOfSecond = tos;

    dateS.RTC_WeekDay = weekday;
    dateS.RTC_Century = century;
    dateS.RTC_Year    = year;
    dateS.RTC_Month   = month;
    dateS.RTC_Date    = date;

    status = HAL_RTC_SetTime(&hrtc_dev, &time, RTC_FORMAT_BIN);
    if (status == HAL_OK)
    {
        status = HAL_RTC_SetDate(&hrtc_dev, &dateS, RTC_FORMAT_BIN);
    }

    return status;
}

/**
 * @brief  Read the calendar into the report globals.
 * @param  None
 * @retval HAL status of the read (HAL_ERROR when a read was refused).
 */
static HAL_StatusTypeDef Rtc_GetCalendar(void)
{
    RTC_TimeTypeDef time;
    RTC_DateTypeDef dateS;
    HAL_StatusTypeDef status;

    __HAL_CLEAR_STRUCT(&time);
    __HAL_CLEAR_STRUCT(&dateS);

    status = HAL_RTC_GetTime(&hrtc_dev, &time, RTC_FORMAT_BIN);
    if (status == HAL_OK)
    {
        status = HAL_RTC_GetDate(&hrtc_dev, &dateS, RTC_FORMAT_BIN);
    }
    if (status != HAL_OK)
    {
        return status;
    }

    r_time_hours   = time.RTC_Hours;
    r_time_minutes = time.RTC_Minutes;
    r_time_seconds = time.RTC_Seconds;
    r_time_tos     = time.RTC_TenthOfSecond;

    r_date_century = dateS.RTC_Century;
    r_date_year    = dateS.RTC_Year;
    r_date_month   = dateS.RTC_Month;
    r_date_date    = dateS.RTC_Date;
    r_date_weekday = dateS.RTC_WeekDay;

    return HAL_OK;
}

/**
 * @brief  Translate a month constant to its number (1-12).
 * @param  month: month (RTC_Month_xxx).
 * @retval uint8: month number, or 0 when the value is unknown.
 */
static uint8 Rtc_MonthToNumber(uint8 month)
{
    uint8 result;

    switch (month)
    {
        case RTC_Month_January:   result = 1U;  break;
        case RTC_Month_February:  result = 2U;  break;
        case RTC_Month_March:     result = 3U;  break;
        case RTC_Month_April:     result = 4U;  break;
        case RTC_Month_May:       result = 5U;  break;
        case RTC_Month_June:      result = 6U;  break;
        case RTC_Month_July:      result = 7U;  break;
        case RTC_Month_August:    result = 8U;  break;
        case RTC_Month_September: result = 9U;  break;
        case RTC_Month_October:   result = 10U; break;
        case RTC_Month_November:  result = 11U; break;
        case RTC_Month_December:  result = 12U; break;
        default:                  result = 0U;  break;
    }

    return result;
}

/**
 * @brief  Translate a weekday constant to its name.
 * @param  weekday: weekday (RTC_Weekday_xxx).
 * @retval const char*: weekday name, or "?" when the value is unknown.
 */
static const char *Rtc_WeekdayName(uint8 weekday)
{
    switch (weekday)
    {
        case RTC_Weekday_Monday:    return "Monday";
        case RTC_Weekday_Tuesday:   return "Tuesday";
        case RTC_Weekday_Wednesday: return "Wednesday";
        case RTC_Weekday_Thursday:  return "Thursday";
        case RTC_Weekday_Friday:    return "Friday";
        case RTC_Weekday_Saturday:  return "Saturday";
        case RTC_Weekday_Sunday:    return "Sunday";
        default:                    return "?";
    }
}

/**
 * @brief  Read and print the calendar.
 * @param  tag: text printed in front of the value (may be NULL).
 * @retval None
 */
static void Rtc_PrintCalendar(const char *tag)
{
    if (Rtc_GetCalendar() != HAL_OK)
    {
        printf("%s calendar read refused (state = %u)\r\n",
               ((tag != NULL_PTR) ? tag : ""),
               PRINT_U32(HAL_RTC_GetState(&hrtc_dev)));
        return;
    }

    printf("%s %02u-%02u-%02u %02u:%02u:%02u.%u %s\r\n",
           ((tag != NULL_PTR) ? tag : ""),
           PRINT_U32(r_date_century), PRINT_U32(Rtc_MonthToNumber(r_date_month)),
           PRINT_U32(r_date_date), PRINT_U32(r_time_hours), PRINT_U32(r_time_minutes),
           PRINT_U32(r_time_seconds), PRINT_U32(r_time_tos),
           Rtc_WeekdayName(r_date_weekday));
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition == 0U)
    {
        failures++;
    }
    printf("%-44s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Configure the system clock tree using the HAL SMU driver.
 * @note   Clock tree shared by every integration test suite of this library:
 *         OSC 20 MHz as the PLL source, PLLDivR = 0x04 / PLLDivN = 0x14 /
 *         PLLDivF = 0xB4 / PLLDivQ = 0x01, then AXI4Bus3 = /2, APBBus0 = /2,
 *         APBBus1 = /2 and CANX2 = /8. The bus dividers are written first and
 *         the PLL is switched in afterwards, which is the order the chip
 *         requires (see HAL_SMU_OscConfig()).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;
    HAL_SMU_HandleTypeDef hsmu_clk;

    /* Enable the bus clock gates */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* The RTC lives in the always-on APB-BusS domain: it has no clock gate of
       its own, the module switch of the configuration file is enough. */

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Bus dividers first (the system clock is still the power-on source) */
    __HAL_CLEAR_STRUCT(&SMU_ClockInitStruct);
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;
    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) and switch to it; the
       call also programs the EFLASH controller clock before the switch. */
    __HAL_CLEAR_STRUCT(&SMU_OscInitStruct);
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
