/**
 * @file    TRNG_IT_DRV_001.c
 * @brief   HAL TRNG integration test case 001 (command sequence, polling mode).
 *
 * One-to-one HAL library port of the reference AS32x601 standard-library
 * test case TRNG_IT_DRV_001.c. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_TRNG_StructInit()
 *   HAL_TRNG_Init()
 *   HAL_TRNG_SendCommand()            (ZEROIZE / GEN_NOISE / CREATE_STATE / GEN_RANDOM)
 *   HAL_TRNG_GetITStatus() / HAL_TRNG_ClearITPendingBit()
 *   HAL_TRNG_GetRandomNumber0() .. HAL_TRNG_GetRandomNumber3()
 *   HAL_TRNG_GetState() / HAL_TRNG_GetError()
 *
 * Test procedure:
 *   Prepare the handle (clear, Instance, metadata from StructInit) and
 *   initialize the peripheral; the command field must read NOP.
 *   Every round then repeats the startup sequence of the reference test
 *   case in polling mode:
 *     1. ZEROIZE       -> wait for the ZEROIZED event, acknowledge it;
 *     2. GEN_NOISE     -> wait for the DONE event, acknowledge it;
 *     3. CREATE_STATE  -> wait for the DONE event, acknowledge it;
 *     4. GEN_RANDOM    -> wait for the DONE event, read RAND0..3,
 *                         acknowledge the completion;
 *     5. print the four words and repeat after a 2 s pause.
 *
 * Expected behaviour:
 *   every command is accepted and its completion arrives inside the
 *   1 s budget, the cached word equals the last generated block, the
 *   two first blocks differ, and every check prints [PASS] with
 *   "summary : failures = 0".
 *
 * Note:
 *   One-to-one port of the reference standard-library case
 *   TRNG_IT_DRV_001.c. The reference case submits the command through its
 *   initialization interface; the HAL driver separates the two concerns, so
 *   the command goes through HAL_TRNG_SendCommand() while HAL_TRNG_Init()
 *   only brings the command field back to NOP. The DRBG startup sequence
 *   (ZEROIZE -> GEN_NOISE -> CREATE_STATE) is therefore identical.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
#define TEST_BAUDRATE                  (115200U)   /*!< console baud rate     */
#define TEST_STEP_TIMEOUT_MS           (1000U)     /*!< per step wait budget  */
#define TEST_ROUND_DELAY_MS            (2000U)     /*!< delay between rounds  */

/* Private variables ---------------------------------------------------------*/
static volatile uint32 check_failures = 0U;   /*!< failed check counter        */
static HAL_SMU_HandleTypeDef hsmu_clk;        /*!< SMU handle (clock tree)     */

/**
 * @brief  TRNG handle used by every case of this suite.
 * @note   The peripheral is a single instance, so one handle is enough; the
 *         lifecycle case uses additional local handles for the refusal paths.
 */
TRNG_HandleTypeDef htrng_dev;

/* MSP callback bookkeeping (written by the shared MSP callbacks) */
uint32 Trng_MspInitCount   = 0U;              /*!< HAL_TRNG_MspInit() calls    */
uint32 Trng_MspDeInitCount = 0U;              /*!< HAL_TRNG_MspDeInit() calls  */
uint32 Trng_MspStateAtInit = 0xFFFFFFFFU;     /*!< handle state seen in the MSP */
uint32 Trng_MspLockAtInit  = 0xFFFFFFFFU;     /*!< handle lock seen in the MSP  */

/* Shared helpers of this suite (defined at the end of this file) */
void Check(const char *name, uint32 condition);
void Summary(void);
void SystemClock_Init(void);
void Trng_ClockEnable(void);
void Trng_PlicEnable(uint8 priority);
HAL_StatusTypeDef Trng_WaitFlag(uint32 flag, uint32 timeout_ms);
HAL_StatusTypeDef Trng_Seed(uint32 timeout_ms);



/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    TRNG_InitTypeDef  trng_init;
    HAL_StatusTypeDef status;
    uint32 round = 0U;
    uint32 r0 = 0U;
    uint32 r1 = 0U;
    uint32 r2 = 0U;
    uint32 r3 = 0U;
    uint32 previous[4];
    uint32 same_as_previous;
    uint32 i;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== TRNG_IT_DRV_001 : command sequence, polling mode ===\r\n");

    /* Handle preparation: clear the structure, then take the metadata from
     * HAL_TRNG_StructInit() (the driver validates Size / Version / Reserved) */
    __HAL_CLEAR_STRUCT(&htrng_dev);
    htrng_dev.Instance = TRNG;
    HAL_TRNG_StructInit(&trng_init);
    Check("HAL_TRNG_StructInit() fills the Size metafield",
          (trng_init.Size == (uint32)sizeof(TRNG_InitTypeDef)) ? 1U : 0U);
    Check("HAL_TRNG_StructInit() fills the Version metafield",
          (trng_init.Version == TRNG_INIT_VERSION) ? 1U : 0U);
    htrng_dev.Init = trng_init;

    /* Step 0: the driver comes up with the command field cleared (NOP) */
    status = HAL_TRNG_Init(&htrng_dev);
    Check("HAL_TRNG_Init() returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("the handle is READY after the initialization",
          (HAL_TRNG_GetState(&htrng_dev) == HAL_TRNG_STATE_READY) ? 1U : 0U);
    Check("the error code is NONE after the initialization",
          (HAL_TRNG_GetError(&htrng_dev) == HAL_TRNG_ERROR_NONE) ? 1U : 0U);
    Check("CTRL.CMD is cleared by the initialization (NOP)",
          ((TRNG->CTRL & TRNG_CTRL_CMD) == 0U) ? 1U : 0U);
    Check("the interrupt enables are left untouched by the initialization",
          ((TRNG->IE & TRNG_IT_ALL) == 0U) ? 1U : 0U);

    printf("startup sequence : ZEROIZE -> GEN_NOISE -> CREATE_STATE -> GEN_RANDOM\r\n");

    for (;;)
    {
        /* Step 1: zeroize the DRBG state and wait for the ZEROIZED event */
        status = HAL_TRNG_SendCommand(&htrng_dev, TRNG_COMMAND_ZEROIZE);
        if (round == 0U)
        {
            Check("HAL_TRNG_SendCommand(ZEROIZE) returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
        }

        status = Trng_WaitFlag(TRNG_FLAG_ZEROIZED, TEST_STEP_TIMEOUT_MS);
        if (round == 0U)
        {
            Check("the ZEROIZED event arrives inside the timeout", (status == HAL_OK) ? 1U : 0U);
            Check("ISTAT.ZEROIZED is readable through HAL_TRNG_GetITStatus()",
                  (HAL_TRNG_GetITStatus(&htrng_dev, TRNG_FLAG_ZEROIZED) == SET) ? 1U : 0U);
            /* A masked query of a flagged event must answer SET: bit 0 is not the
             * only flag, so a raw mask cast would answer 2 / 4 / 8 / 16 here */
            Check("the flag query answers SET for a pending event",
                  (HAL_TRNG_GetITStatus(&htrng_dev, TRNG_EVENT_ALL) == SET) ? 1U : 0U);
        }

        /* Acknowledge the zeroize completion and the completion flag */
        HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_ZEROIZED);
        HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_DONE);
        if (round == 0U)
        {
            Check("ISTAT.ZEROIZED is cleared after the acknowledge",
                  (HAL_TRNG_GetITStatus(&htrng_dev, TRNG_FLAG_ZEROIZED) == RESET) ? 1U : 0U);
        }

        /* Step 2: generate a full entropy seed from the noise source */
        status = HAL_TRNG_SendCommand(&htrng_dev, TRNG_COMMAND_GEN_NOISE);
        if (round == 0U)
        {
            Check("HAL_TRNG_SendCommand(GEN_NOISE) returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
        }
        status = Trng_WaitFlag(TRNG_FLAG_DONE, TEST_STEP_TIMEOUT_MS);
        if (round == 0U)
        {
            Check("the DONE event of GEN_NOISE arrives inside the timeout",
                  (status == HAL_OK) ? 1U : 0U);
        }
        HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_DONE);

        /* Step 3: create the DRBG state */
        status = HAL_TRNG_SendCommand(&htrng_dev, TRNG_COMMAND_CREATE_STATE);
        if (round == 0U)
        {
            Check("HAL_TRNG_SendCommand(CREATE_STATE) returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
        }
        status = Trng_WaitFlag(TRNG_FLAG_DONE, TEST_STEP_TIMEOUT_MS);
        if (round == 0U)
        {
            Check("the DONE event of CREATE_STATE arrives inside the timeout",
                  (status == HAL_OK) ? 1U : 0U);
        }
        HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_DONE);

        /* Step 4: generate one 128-bit random block */
        status = HAL_TRNG_SendCommand(&htrng_dev, TRNG_COMMAND_GEN_RANDOM);
        if (round == 0U)
        {
            Check("HAL_TRNG_SendCommand(GEN_RANDOM) returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
        }
        status = Trng_WaitFlag(TRNG_FLAG_DONE, TEST_STEP_TIMEOUT_MS);
        if (round == 0U)
        {
            Check("the DONE event of GEN_RANDOM arrives inside the timeout",
                  (status == HAL_OK) ? 1U : 0U);
        }

        r0 = HAL_TRNG_GetRandomNumber0(&htrng_dev);
        r1 = HAL_TRNG_GetRandomNumber1(&htrng_dev);
        r2 = HAL_TRNG_GetRandomNumber2(&htrng_dev);
        r3 = HAL_TRNG_GetRandomNumber3(&htrng_dev);

        HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_DONE);

        if (round == 0U)
        {
            Check("the four random words are not all zero",
                  ((r0 | r1 | r2 | r3) != 0U) ? 1U : 0U);
            Check("ISTAT.DONE is cleared after the acknowledge",
                  (HAL_TRNG_GetITStatus(&htrng_dev, TRNG_FLAG_DONE) == RESET) ? 1U : 0U);
            Check("the handle stays READY between the raw commands",
                  (HAL_TRNG_GetState(&htrng_dev) == HAL_TRNG_STATE_READY) ? 1U : 0U);
            previous[0] = r0;
            previous[1] = r1;
            previous[2] = r2;
            previous[3] = r3;
        }
        else if (round == 1U)
        {
            /* The second block must differ from the first one: the DRBG keeps
             * advancing, and a repeated block would mean that the completion of
             * the previous round was reported again */
            same_as_previous = 0U;
            if ((r0 == previous[0]) && (r1 == previous[1]) &&
                (r2 == previous[2]) && (r3 == previous[3]))
            {
                same_as_previous = 1U;
            }
            Check("the second 128-bit block differs from the first one",
                  (same_as_previous == 0U) ? 1U : 0U);
            Summary();
        }
        else
        {
            /* Subsequent rounds only repeat the sequence */
        }

        printf("round %u :", (int)round);
        for (i = 0U; i < 4U; i++)
        {
            printf(" RAND%u=%08X", PRINT_U32(i),
                   PRINT_U32((i == 0U) ? r0 : ((i == 1U) ? r1 : ((i == 2U) ? r2 : r3))));
        }
        printf("\r\n");

        round++;
        delay_ms(TEST_ROUND_DELAY_MS);
    }
}

/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the other integration tests of this library:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2 and
 *         CANX2 by 8, which gives core 180 MHz and APB 22.5 MHz (the console
 *         USART is clocked from APBBus0). The TRNG sits on the AXILite4-Bus1
 *         bus, which is not divided by this tree.
 * @note   Clock tree order: the dividers are written while the system clock
 *         is still the power on source (FIRC), then the PLL is configured and
 *         the system clock is switched to it. That last call programs the
 *         flash controller clock before the switch (the core keeps fetching
 *         from the flash) and updates SystemCoreClock afterwards.
 * @param  None
 * @retval None
 */
void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks (console pins of USART0 on GPIOD) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Open the clock gate of the security domain and release its reset.
 * @note   The TRNG has no dedicated SMU gate: it is clocked and reset through
 *         the DSE (security engine) domain bits of SMU->ALB1CFGR, exactly like
 *         the reference test case does with its DSE_CLK_ENABLE / DSE_RESET /
 *         DSE_SET sequence. The HAL TRNG driver has no default MSP body, so
 *         this helper is what HAL_TRNG_MspInit() / the cases call.
 * @note   The gate is never closed again (not even by HAL_TRNG_MspDeInit):
 *         the DSE domain is shared with the other security peripherals, and a
 *         closed gate makes any later register access stall the bus.
 * @param  None
 * @retval None
 */
void Trng_ClockEnable(void)
{
    __HAL_SMU_DSE_CLK_ENABLE();
    __HAL_SMU_DSE_FORCE_RESET();
    __HAL_SMU_DSE_RELEASE_RESET();
}

/**
 * @brief  Enable the TRNG interrupt source in the PLIC.
 * @param  priority: source priority (1..63, larger = higher priority)
 * @retval None
 */
void Trng_PlicEnable(uint8 priority)
{
    PLIC_InitTypeDef plic_init;

    __HAL_CLEAR_STRUCT(&plic_init);
    plic_init.Size               = sizeof(plic_init);
    plic_init.Version            = PLIC_INIT_VERSION;
    plic_init.PLIC_IRQChannel    = TRNG_IRQn;
    plic_init.PLIC_IRQPriority   = priority;
    plic_init.PLIC_IRQChannelCmd = PLIC_ENABLE;
    (void)HAL_PLIC_Init(&plic_init);
}

/**
 * @brief  Wait (bounded) until one ISTAT event flag of the handle is set.
 * @note   The flag is not cleared here: the caller decides who acknowledges it
 *         (the driver for the completions it owns, the application for the
 *         events it enabled itself).
 * @param  flag: event mask (TRNG_FLAG_x or a combination)
 * @param  timeout_ms: timeout in milliseconds
 * @retval HAL_StatusTypeDef: HAL_OK when the flag was observed / HAL_TIMEOUT
 */
HAL_StatusTypeDef Trng_WaitFlag(uint32 flag, uint32 timeout_ms)
{
    uint32 tickstart = HAL_GetTick();

    while (HAL_TRNG_GetITStatus(&htrng_dev, flag) == RESET)
    {
        if ((HAL_GetTick() - tickstart) > timeout_ms)
        {
            return HAL_TIMEOUT;
        }
    }

    return HAL_OK;
}

/**
 * @brief  Run the DRBG startup sequence: ZEROIZE -> GEN_NOISE -> CREATE_STATE.
 * @note   This is the sequence the reference test case runs at the beginning of
 *         every round; it is factored out here because the cases that use the
 *         HAL generation interfaces only need the DRBG to be seeded once.
 * @param  timeout_ms: per step timeout in milliseconds
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (command refused) / HAL_TIMEOUT
 */
HAL_StatusTypeDef Trng_Seed(uint32 timeout_ms)
{
    if (HAL_TRNG_SendCommand(&htrng_dev, TRNG_COMMAND_ZEROIZE) != HAL_OK)
    {
        return HAL_ERROR;
    }
    if (Trng_WaitFlag(TRNG_FLAG_ZEROIZED, timeout_ms) != HAL_OK)
    {
        return HAL_TIMEOUT;
    }
    HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_ZEROIZED);
    HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_DONE);

    if (HAL_TRNG_SendCommand(&htrng_dev, TRNG_COMMAND_GEN_NOISE) != HAL_OK)
    {
        return HAL_ERROR;
    }
    if (Trng_WaitFlag(TRNG_FLAG_DONE, timeout_ms) != HAL_OK)
    {
        return HAL_TIMEOUT;
    }
    HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_DONE);

    if (HAL_TRNG_SendCommand(&htrng_dev, TRNG_COMMAND_CREATE_STATE) != HAL_OK)
    {
        return HAL_ERROR;
    }
    if (Trng_WaitFlag(TRNG_FLAG_DONE, timeout_ms) != HAL_OK)
    {
        return HAL_TIMEOUT;
    }
    HAL_TRNG_ClearITPendingBit(&htrng_dev, TRNG_FLAG_DONE);

    return HAL_OK;
}

/* MSP callbacks ------------------------------------------------------------*/

/**
 * @brief  Initialize the TRNG MSP (security domain clock gate and reset).
 * @note   The default implementation of the driver is empty, so the DSE domain
 *         is opened here (the TRNG has no gate of its own).
 * @note   The call is recorded so that the lifecycle case can verify the
 *         LOCK-06 / MSP-04 contract: the callback must run outside the handle
 *         lock and only on the first initialization (state RESET).
 * @param  htrng: TRNG handle
 * @retval None
 */
void HAL_TRNG_MspInit(TRNG_HandleTypeDef *htrng)
{
    Trng_MspInitCount++;
    Trng_MspStateAtInit = (uint32)htrng->State;
    Trng_MspLockAtInit  = (uint32)htrng->Lock;

    Trng_ClockEnable();
}

/**
 * @brief  De-initialize the TRNG MSP.
 * @note   The DSE clock gate is shared with the other security peripherals and
 *         is left open on purpose, so that a case may read the TRNG registers
 *         after a de-initialization without stalling the bus.
 * @param  htrng: TRNG handle
 * @retval None
 */
void HAL_TRNG_MspDeInit(TRNG_HandleTypeDef *htrng)
{
    Trng_MspDeInitCount++;

    (void)htrng;
}

/*****END OF FILE*****/
