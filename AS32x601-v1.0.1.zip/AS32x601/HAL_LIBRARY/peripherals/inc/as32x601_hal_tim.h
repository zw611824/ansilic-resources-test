/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_tim.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.9
 * Date:             2026/11/05
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.1     add the DMA mode of the
 *                                                       output compare and PWM
 *                                                       interfaces
 *                                                       (HAL_TIM_OC_Start_DMA /
 *                                                       HAL_TIM_OC_Stop_DMA /
 *                                                       HAL_TIM_PWM_Start_DMA /
 *                                                       HAL_TIM_PWM_Stop_DMA) and
 *                                                       the supporting constants
 *                                                       (TIM_DMA_* /
 *                                                       TIM_DMABase_* /
 *                                                       TIM_DMABurstLength_*),
 *                                                       macros
 *                                                       (__HAL_TIM_ENABLE_DMA /
 *                                                       __HAL_TIM_DISABLE_DMA /
 *                                                       __HAL_TIM_SET_DMABURSTBASE /
 *                                                       __HAL_TIM_SET_DMABURSTLENGTH)
 *                                                       and the per-channel DMA
 *                                                       handle table of the
 *                                                       HAL_TIM_HandleTypeDef
 *     ANSILIC APPLICATION GROUP  2026/09/21     1.2     align the resource lock and the RTOS support with the
 *                                                       architecture specification (section 13 LOCK-01..06 and
 *                                                       section 21 RTOS-04/11): the MSP callbacks run outside
 *                                                       the locked region (LOCK-06) and the MSP init runs only
 *                                                       on the first initialization (MSP-04), the handle lock
 *                                                       takes a Timeout and guards a NULL mutex (RTOS-11),
 *                                                       every lock failure return is documented as a path
 *                                                       where the lock is not held (LOCK-02), a state gate
 *                                                       rejects the calls made on a non initialized handle
 *                                                       (ARCH-CONST-09) while BUSY stays accepted because it
 *                                                       means that the counter is running, the handle and the
 *                                                       instance are checked through one shared helper, the
 *                                                       configuration structure is validated at run time in
 *                                                       the six initialization functions, and the header now
 *                                                       carries the API documentation and the blocking marker
 *                                                       of every prototype
 *     ANSILIC APPLICATION GROUP  2026/10/26     1.3     capture/compare register bit encoding, the wide channel support and the
 *                                                       de-initialization of the instance: TIM_IT_CC1..CC6 / TIM_FLAG_CC1..CC6 /
 *                                                       TIM_FLAG_CC1OF..CC6OF / TIM_EVENTSOURCE_CC1..CC6 now carry the real high
 *                                                       half bit positions of DIER / SR / EGR (bits 16..21 and 24..29), the
 *                                                       trigger and break sources move to TIE/TIF (bit2) and BIE/BIF (bit3),
 *                                                       TIM_EVENTSOURCE_COM points at EGR.COMG and the two commutation constants
 *                                                       that had no hardware bit (TIM_IT_COM / TIM_FLAG_COM) are removed; the flag
 *                                                       and event source validation masks follow the same layout. Adds
 *                                                       TIM_CHANNEL_NONE as the unambiguous "no channel owner" callback sentinel,
 *                                                       HAL_TIM_OC_ConfigChannel now programs the new TIM_OC_InitTypeDef OCPreload
 *                                                       field into CCMRx.OCxPE, TIM_CLOCKSOURCE_INTERNAL moves to 0x00000100 so it
 *                                                       no longer collides with TIM_CLOCKSOURCE_ITR1, TIM_BREAK_FILTER_Pos is 16
 *                                                       (BDTR.BKF), the de-initialization silences the instance, a running timer
 *                                                       refuses a new initialization, the interrupt handler serves channels 5 and 6
 *                                                       of the advanced timers and the ten StructInit helpers are added
 *     ANSILIC APPLICATION GROUP  2026/11/05     1.9     expose the capture/compare DMA source selection (CR2.CCDS) as
 *                                                       HAL_TIM_SelectCCDMA(): on this device the capture/compare DMA request
 *                                                       of a channel only reaches the DMA controller while the bit is set, so
 *                                                       a transfer started with HAL_TIM_OC_Start_DMA() or
 *                                                       HAL_TIM_PWM_Start_DMA() stays idle on an otherwise correct
 *                                                       configuration (the timer sets DIER.*DE and SR.CCxIF as usual but no
 *                                                       request is issued). The driver does not set the bit on its own, so a
 *                                                       request driven by the update event keeps working; the new interface
 *                                                       takes the handle and the selection, validates the selection at run
 *                                                       time, applies the state gate and serializes the register access
 *                                                       through the handle lock, and the documentation of the two DMA start
 *                                                       functions names the bit as a prerequisite
 *     ANSILIC APPLICATION GROUP  2026/11/04     1.8     program the output idle state of every channel correctly: CR2 carries one
 *                                                       OISx and one OISxN bit per channel with a two bit stepping (OIS1 = bit8 ...
 *                                                       OIS6N = bit19), but TIM_OC2 / OC3 / OC4_SetConfig() masked the value without
 *                                                       shifting it, so the mask cancelled it and the bit was never set, and channels
 *                                                       4, 5 and 6 never wrote the complementary idle bit at all; with BDTR.OSSR (or
 *                                                       OSSI) set those bits define the level the pin takes while the main output is
 *                                                       disabled, so the twelve outputs settled in a mixture of levels instead of all
 *                                                       following OCIdleState / OCNIdleState
 *     ANSILIC APPLICATION GROUP  2026/11/04     1.7     clear the main output unconditionally when it is disabled: the
 *                                                       HAL_TIM_CtrlPWMOutputs() DISABLE path used the conditional macro, which only
 *                                                       clears BDTR.MOE while every CCxE / CCxNE bit of CCER is already cleared, so
 *                                                       the call did nothing at all while the channel outputs were enabled and the
 *                                                       main output could not be switched off; the new
 *                                                        __HAL_TIM_MOE_DISABLE_UNCONDITIONALLY() macro (same name and semantics as
 *                                                       the reference timer API) is used there instead, while the Stop functions keep
 *                                                       the conditional variant because they clear their own channel first
 *     ANSILIC APPLICATION GROUP  2026/11/04     1.6     accept the complementary outputs of channels 4, 5 and 6: the device drives
 *                                                       CC4NE / CC5NE / CC6NE (CCER bits 14, 18 and 22) and routes them to PC4,
 *                                                       PC5 and PB0 in the HTIM0 M1 option (PD12, PD13 and PD14 in M2), so
 *                                                       IS_TIM_COMPLEMENTARY_CHANNELS() now accepts TIM_CHANNEL_1..6 on the
 *                                                       advanced timers and the eight complementary start / stop functions (OCN
 *                                                       and PWMN, polling and interrupt modes) cover the six channels;
 *                                                       TIM_OC4 / OC5 / OC6_SetConfig() now also program the complementary enable
 *                                                       and polarity bits of their channel, which they previously left untouched;
 *                                                       before this version a call with channel 4, 5 or 6 was refused with
 *                                                       HAL_ERROR before any register was written, which left those complementary
 *                                                       outputs permanently disabled
 *     ANSILIC APPLICATION GROUP  2026/11/02     1.5     expose the second master output trigger (TRGO2,
 *                                                       CR2.MMS2) of the advanced timers: the master
 *                                                       configuration structure gains the
 *                                                       MasterOutputTrigger2 field (appended, so the
 *                                                       two existing fields keep their offsets), the
 *                                                       sixteen TIM_TRGO2_xxx sources and the
 *                                                       IS_TIM_TRGO2_SOURCE() validation macro are
 *                                                       added, HAL_TIM_MasterConfigSynchronization()
 *                                                       now programs CR2.MMS and CR2.MMS2 in one locked
 *                                                       access (a real TRGO2 source on a general
 *                                                       purpose timer is refused with
 *                                                       HAL_TIM_ERROR_INVALID_PARAM without touching the
 *                                                       register) and the new
 *                                                       HAL_TIM_SetMasterOutputTrigger2() changes TRGO2
 *                                                       alone; HAL_TIM_MasterConfig_StructInit() fills
 *                                                       the neutral TIM_TRGO2_RESET
 *     ANSILIC APPLICATION GROUP  2026/10/27     1.4     extend the capture/compare channel support of the advanced timers to
 *                                                       channels 5 and 6 and add the four bit output compare modes: the three
 *                                                       channel configuration functions, the six interrupt start / stop
 *                                                       functions and the captured value read back now cover channels 1..6
 *                                                       (CCMR3 carries the two extra channels, their CCER enable and polarity
 *                                                       bits follow the 4 bit channel stepping, the preload and fast mode bits
 *                                                       of the two extra channels are written in CCMR3 and the two channels are
 *                                                       refused on the general purpose instances), and the header gains the
 *                                                       selectors of the extended modes (asymmetric PWM 1/2, combined PWM 1/2
 *                                                       and the two remaining OCxM values), which the configuration functions
 *                                                       write unchanged because the OCxM field is four bits wide
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the timer (TIM) of the
 *                  AS32x601, structured as a HAL peripheral driver:
 *                  - Initialization and de-initialization of the time base,
 *                    output compare, PWM, input capture, one pulse and
 *                    encoder interfaces;
 *                  - Start / stop operations in polling, interrupt and
 *                    DMA modes;
 *                  - Channel configuration (OC / PWM / IC / one pulse);
 *                  - Interrupt service routine dispatch;
 *                  - State and error reporting.
 *
 *                  The AS32x601 embeds eight timer instances:
 *                  - Advanced timers TIM0 / TIM1 / TIM2 / TIM5 (32-bit
 *                    prescaler and auto-reload register, repetition counter,
 *                    channels 1..6, break and dead-time);
 *                  - General-purpose timers TIM3 / TIM4 / TIM6 / TIM7
 *                    (16-bit prescaler and auto-reload register, channels
 *                    1..4), with a reduced feature set.
 *
 *                  The complementary output / PWM start and the break /
 *                  dead-time, commutation and master synchronization features
 *                  of the advanced timers are provided by this driver as well.
 * @complexity  Complex
 *              Blocking + IT + DMA modes, state machine, user callbacks.
 */
#ifndef __AS32X601_HAL_TIM_H
#define __AS32X601_HAL_TIM_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "as32x601.h"               /* TIM_TypeDef, TIM register bits         */
#include "as32x601_hal_def.h"       /* HAL_StatusTypeDef, HAL_LockTypeDef     */

/* Exported constants --------------------------------------------------------*/

/**
 * @brief TIM HAL driver module version.
 * @note  0x0100U = V1.0. Bumped only on breaking API changes (architecture
 *        spec COMPAT-13/14/15).
 */
#define __HAL_TIM_MODULE_VERSION  0x0100U

/* Forward declaration of the DMA handle type (defined in as32x601_hal_dma.h).
    The TIM handle stores a table of DMA channel handles so that the DMA mode
    start / stop functions can be implemented without including the DMA module
    header here. The pointer table is always present: the _Start_DMA / _Stop_DMA
    functions are compiled only while the DMA module is enabled. */
typedef struct __DMA_HandleTypeDef DMA_HandleTypeDef;

/* Exported types ------------------------------------------------------------*/

/** @defgroup TIM_Exported_Types TIM Exported Types
  * @{
  */

/**
 * @brief TIM Time base configuration structure definition.
 * @note  On the general-purpose timers (TIM3 / TIM4 / TIM6 / TIM7) the
 *        prescaler and the period are limited to 16 bits and the repetition
 *        counter is ignored.
 */
typedef struct
{
    uint32 Size;                /*!< sizeof(TIM_Base_InitTypeDef), set by the user
                                     after clearing the structure */
    uint32 Version;             /*!< Structure semantic version: @ref TIM_INIT_VERSION
                                     (TIM_INIT_V1 = 0x0100U) */
    uint32 Prescaler;           /*!< Specifies the prescaler value used to divide the TIM clock  */
    uint32 CounterMode;         /*!< Specifies the counter mode: TIM_COUNTERMODE_xxx              */
    uint32 Period;   /*!< Specifies the period value loaded into the auto-reload
                                register */
    uint32 ClockDivision;   /*!< Specifies the clock division: TIM_CKD_xxx
                                 */
    uint32 RepetitionCounter;   /*!< Specifies the repetition counter (advanced timers only)
                                 */
    uint32 Reserved[2];         /*!< Reserved for future extension (must be 0) */
} TIM_Base_InitTypeDef;

/**
 * @brief TIM init structure version macros.
 * @note  TIM_INIT_V1 is the current version. Future versions must be
 *        appended after the existing fields (architecture spec section 22.5).
 */
#define TIM_INIT_V1  0x0100U   /*!< TIM Init structure version V1.0 */
#define TIM_INIT_VERSION  TIM_INIT_V1   /*!< Current TIM Init structure version */

/**
 * @brief TIM Output Compare configuration structure definition.
 * @note  The complementary fields are only used on the advanced timers.
 */
typedef struct
{
    uint32 OCMode;              /*!< Specifies the TIM mode: TIM_OCMODE_xxx            */
    uint32 Pulse;   /*!< Specifies the pulse value loaded into the capture/compare
                                register */
    uint32 OCPolarity;          /*!< Specifies the output polarity: TIM_OCPOLARITY_xxx  */
    uint32 OCNPolarity;         /*!< Specifies the complementary output polarity (advanced only) */
    uint32 OCFastMode;          /*!< Specifies the fast mode state: TIM_OCFAST_xxx      */
    uint32 OCPreload;           /*!< Specifies the preload state: TIM_OCPRECONFIG_xxx
                                     (written to the CCMRx.OCxPE bit by
                                     HAL_TIM_OC_ConfigChannel; HAL_TIM_PWM_ConfigChannel
                                     always enables the preload, as in the reference HAL) */
    uint32 OCIdleState;         /*!< Specifies the output idle state (advanced only)    */
    uint32 OCNIdleState;   /*!< Specifies the complementary output idle state (advanced
                                only) */
} TIM_OC_InitTypeDef;

/**
 * @brief TIM Input Capture configuration structure definition.
 */
typedef struct
{
    uint32 ICPolarity;          /*!< Specifies the active edge: TIM_ICPOLARITY_xxx */
    uint32 ICSelection;         /*!< Specifies the input: TIM_ICSEL_xxx           */
    uint32 ICPrescaler;         /*!< Specifies the input capture prescaler: TIM_ICPSC_xxx */
    uint32 ICFilter;            /*!< Specifies the input capture filter (0..15)   */
} TIM_IC_InitTypeDef;

/**
 * @brief TIM One Pulse configuration structure definition.
 */
typedef struct
{
    uint32 OCMode;              /*!< Specifies the output mode: TIM_OCMODE_xxx      */
    uint32 Pulse;               /*!< Specifies the pulse value in the CCR register  */
    uint32 OCPolarity;          /*!< Specifies the output polarity: TIM_OCPOLARITY_xxx */
    uint32 OCNPolarity;         /*!< Specifies the complementary polarity (advanced only) */
    uint32 OCIdleState;         /*!< Specifies the output idle state (advanced only) */
    uint32 OCNIdleState;        /*!< Specifies the complementary idle state (advanced only) */
    uint32 ICPolarity;          /*!< Specifies the capture polarity: TIM_ICPOLARITY_xxx */
    uint32 ICSelection;         /*!< Specifies the capture input: TIM_ICSEL_xxx    */
    uint32 ICFilter;            /*!< Specifies the input filter (0..15)            */
} TIM_OnePulse_InitTypeDef;

/**
 * @brief TIM Encoder configuration structure definition.
 */
typedef struct
{
    uint32 EncoderMode;         /*!< Specifies the encoder mode: TIM_ENCODERMODE_xxx */
    uint32 IC1Polarity;         /*!< Specifies the IC1 polarity: TIM_ICPOLARITY_xxx  */
    uint32 IC1Selection;        /*!< Specifies the IC1 input: TIM_ICSEL_xxx          */
    uint32 IC1Prescaler;        /*!< Specifies the IC1 prescaler: TIM_ICPSC_xxx      */
    uint32 IC1Filter;           /*!< Specifies the IC1 filter (0..15)                */
    uint32 IC2Polarity;         /*!< Specifies the IC2 polarity: TIM_ICPOLARITY_xxx  */
    uint32 IC2Selection;        /*!< Specifies the IC2 input: TIM_ICSEL_xxx          */
    uint32 IC2Prescaler;        /*!< Specifies the IC2 prescaler: TIM_ICPSC_xxx      */
    uint32 IC2Filter;           /*!< Specifies the IC2 filter (0..15)                */
} TIM_Encoder_InitTypeDef;

/**
 * @brief TIM Clock configuration structure definition.
 */
typedef struct
{
    uint32 ClockSource;         /*!< Specifies the clock source: TIM_CLOCKSOURCE_xxx  */
    uint32 ClockPolarity;       /*!< Specifies the clock polarity: TIM_CLOCKPOLARITY_xxx */
    uint32 ClockPrescaler;      /*!< Specifies the clock prescaler: TIM_CLOCKPRESCALER_xxx */
    uint32 ClockFilter;         /*!< Specifies the clock filter (0..15)               */
} TIM_ClockConfigTypeDef;

/**
 * @brief TIM Clear Input configuration structure definition.
 */
typedef struct
{
    uint32 ClearInputState;      /*!< Specifies the clear input state: TIM_CLEARINPUT_xxx  */
    uint32 ClearInputSource;     /*!< Specifies the clear input source: TIM_CLEARINPUTSOURCE_xxx */
    uint32 ClearInputPolarity;   /*!< Specifies the clear input polarity:
                                 TIM_CLEARINPUTPOLARITY_xxx */
    uint32 ClearInputPrescaler;   /*!< Specifies the clear input prescaler:
                                 TIM_CLEARINPUTPRESCALER_xxx */
    uint32 ClearInputFilter;     /*!< Specifies the clear input filter (0..15)             */
} TIM_ClearInputConfigTypeDef;

/**
 * @brief TIM Slave configuration structure definition.
 */
typedef struct
{
    uint32 SlaveMode;            /*!< Specifies the slave mode: TIM_SLAVEMODE_xxx       */
    uint32 InputTrigger;         /*!< Specifies the input trigger: TIM_TS_xxx           */
    uint32 TriggerPolarity;      /*!< Specifies the trigger polarity: TIM_TRIGGERPOLARITY_xxx */
    uint32 TriggerPrescaler;     /*!< Specifies the trigger prescaler: TIM_TRIGGERPRESCALER_xxx */
    uint32 TriggerFilter;        /*!< Specifies the trigger filter (0..15)              */
} TIM_SlaveConfigTypeDef;

/**
 * @brief TIM Master configuration structure definition.
 * @note  The second master output (TRGO2, CR2.MMS2) only exists on the
 *        advanced timers TIM0 / TIM1 / TIM2 / TIM5. On a general purpose
 *        timer the field must keep TIM_TRGO2_RESET (the neutral value written
 *        by HAL_TIM_MasterConfig_StructInit()): a request for a real TRGO2
 *        source is refused by HAL_TIM_MasterConfigSynchronization() and
 *        HAL_TIM_SetMasterOutputTrigger2().
 */
typedef struct
{
    uint32 MasterOutputTrigger;  /*!< Specifies the TRGO output: TIM_TRGO_xxx           */
    uint32 MasterSlaveMode;      /*!< Specifies the master-slave mode: TIM_MASTERSLAVEMODE_xxx */
    uint32 MasterOutputTrigger2; /*!< Specifies the TRGO2 output: TIM_TRGO2_xxx
                                      (advanced timers only; keep TIM_TRGO2_RESET on a
                                      general purpose timer) */
} TIM_MasterConfigTypeDef;

/**
 * @brief TIM Break / dead-time configuration structure definition (advanced).
 */
typedef struct
{
    uint32 OffStateRunMode;      /*!< OSSR state: TIM_OSSR_xxx           */
    uint32 OffStateIDLEMode;     /*!< OSSI state: TIM_OSSI_xxx           */
    uint32 LockLevel;            /*!< Lock level: TIM_LOCKLEVEL_xxx      */
    uint32 DeadTime;             /*!< Dead-time value (0..0xFF)          */
    uint32 BreakState;           /*!< Break state: TIM_BREAK_xxx         */
    uint32 BreakPolarity;        /*!< Break polarity: TIM_BREAKPOLARITY_xxx */
    uint32 BreakFilter;          /*!< Break filter (0..15)               */
    uint32 AutomaticOutput;      /*!< Automatic output: TIM_AUTOMATICOUTPUT_xxx */
} TIM_BreakDeadTimeConfigTypeDef;

/**
 * @brief HAL TIM state structures definition.
 */
typedef enum
{
    HAL_TIM_STATE_RESET      = 0x00U, /*!< Peripheral not initialized               */
    HAL_TIM_STATE_READY      = 0x01U, /*!< Peripheral initialized and ready         */
    HAL_TIM_STATE_BUSY       = 0x02U, /*!< An internal process is ongoing           */
    HAL_TIM_STATE_TIMEOUT    = 0x03U, /*!< Timeout state                            */
    HAL_TIM_STATE_ERROR      = 0x04U  /*!< TIM error state                          */
} HAL_TIM_StateTypeDef;

/**
 * @brief  TIM DMA handle indices.
 * @note   The handle embeds a table of DMA channel handles, indexed by the
 *         DMA request source (capture/compare or update). The indices use the
 *         standard HAL TIM numbering so that the dedicated DMA channel of a
 *         given event can be selected by the application (and bound in the
 *         MspInit through the corresponding DMA handle).
 * @{
 */
#define TIM_DMA_ID_CC1     ((uint32)0x0000U)  /*!< CC1 DMA channel handle index   */
#define TIM_DMA_ID_CC2     ((uint32)0x0001U)  /*!< CC2 DMA channel handle index   */
#define TIM_DMA_ID_CC3     ((uint32)0x0002U)  /*!< CC3 DMA channel handle index   */
#define TIM_DMA_ID_CC4     ((uint32)0x0003U)  /*!< CC4 DMA channel handle index   */
#define TIM_DMA_ID_UPDATE  ((uint32)0x0004U)  /*!< Update DMA channel handle index */
#define TIM_DMA_ID_CC5     ((uint32)0x0005U)  /*!< CC5 DMA channel handle index   */
#define TIM_DMA_ID_CC6     ((uint32)0x0006U)  /*!< CC6 DMA channel handle index   */
#define TIM_DMA_ID_TIM     ((uint32)0x0007U)  /*!< TIM (complementary / link) DMA handle index */
#define TIM_DMA_ID_MAX     ((uint32)0x0008U)  /*!< Number of DMA handle entries   */
/**
  * @}
  */

/**
 * @brief TIM handle structure definition.
 */
typedef struct __HAL_TIM_HandleTypeDef
{
    TIM_TypeDef               *Instance;      /*!< TIM registers base address   */
    TIM_Base_InitTypeDef      Init;           /*!< TIM time base parameters     */
    HAL_LockTypeDef           Lock;           /*!< Locking object               */
    __IO HAL_TIM_StateTypeDef State;          /*!< TIM communication state      */
    __IO uint32               ErrorCode;      /*!< TIM error code               */
    uint32                    Channel;        /*!< Active capture/compare channel */
    DMA_HandleTypeDef        *hdma[TIM_DMA_ID_MAX];  /*!< DMA channel handles
                                                          (indexed by TIM_DMA_ID_xxx) */
#if (USE_RTOS == 1)
    HAL_MutexTypeDef          LockMutex;      /*!< RTOS mutex handle (created by the
                                                   user porting layer, e.g. in
                                                   HAL_TIM_Base_MspInit)         */
#endif /* USE_RTOS */
} HAL_TIM_HandleTypeDef;

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @defgroup TIM_Exported_Constants TIM Exported Constants
  * @{
  */

/** @defgroup TIM_Error_Code TIM Error Code
  * @{
  */
#define HAL_TIM_ERROR_NONE           ((uint32)0x00000000U) /*!< No error          */
#define HAL_TIM_ERROR_TIMEOUT        ((uint32)0x00000001U) /*!< Flag wait timeout */
#define HAL_TIM_ERROR_INVALID_PARAM  ((uint32)0x00000002U) /*!< Invalid parameter */
#define HAL_TIM_ERROR_TRANSFER       ((uint32)0x00000004U) /*!< Transfer error    */
/**
  * @}
  */

/** @defgroup TIM_Channel TIM Channels
  * @note  The values are the CCER bit-step / CCR register offsets.
  * @{
  */
#define TIM_CHANNEL_1  ((uint32)0x00000000U) /*!< Channel 1 */
#define TIM_CHANNEL_2  ((uint32)0x00000004U) /*!< Channel 2 */
#define TIM_CHANNEL_3  ((uint32)0x00000008U) /*!< Channel 3 */
#define TIM_CHANNEL_4  ((uint32)0x0000000CU) /*!< Channel 4 */
#define TIM_CHANNEL_5  ((uint32)0x00000010U) /*!< Channel 5 (advanced timers only) */
#define TIM_CHANNEL_6  ((uint32)0x00000014U) /*!< Channel 6 (advanced timers only) */
#define TIM_CHANNEL_ALL ((uint32)0x0000003CU) /*!< All channels                 */
/** @brief Software-only "no channel" sentinel. It is disjoint from every
  *        TIM_CHANNEL_1..6 selector (whose lowest value is 0x00, the same
  *        value as TIM_CHANNEL_1) and is never a valid argument to a channel
  *        API. HAL_TIM_IRQHandler stores it in the handle Channel field before
  *        the callbacks that have no single channel owner (period, trigger,
  *        break) and restores it after every callback, so a "channel 1" value
  *        cannot be confused with "no channel". */
#define TIM_CHANNEL_NONE ((uint32)0xFFFFFFFFU) /*!< No channel (callback sentinel) */
/**
  * @}
  */

/** @defgroup TIM_Counter_Mode TIM Counter Mode
  * @{
  */
#define TIM_COUNTERMODE_UP             ((uint32)0x00000000U) /*!< Up counting mode */
#define TIM_COUNTERMODE_DOWN           ((uint32)0x00000010U) /*!< Down counting mode */
#define TIM_COUNTERMODE_CENTERALIGNED1 ((uint32)0x00000020U) /*!< Center-aligned mode 1 */
#define TIM_COUNTERMODE_CENTERALIGNED2 ((uint32)0x00000040U) /*!< Center-aligned mode 2 */
#define TIM_COUNTERMODE_CENTERALIGNED3 ((uint32)0x00000060U) /*!< Center-aligned mode 3 */
#define IS_TIM_COUNTER_MODE(MODE) (((MODE) == TIM_COUNTERMODE_UP) || \
                                   ((MODE) == TIM_COUNTERMODE_DOWN) || \
                                   ((MODE) == TIM_COUNTERMODE_CENTERALIGNED1) || \
                                   ((MODE) == TIM_COUNTERMODE_CENTERALIGNED2) || \
                                   ((MODE) == TIM_COUNTERMODE_CENTERALIGNED3))
/**
  * @}
  */

/** @defgroup TIM_Clock_Division TIM Clock Division
  * @{
  */
#define TIM_CKD_DIV1 ((uint32)0x00000000U) /*!< TDTS = Tck_tim */
#define TIM_CKD_DIV2 ((uint32)0x00000100U) /*!< TDTS = 2 * Tck_tim */
#define TIM_CKD_DIV4 ((uint32)0x00000200U) /*!< TDTS = 4 * Tck_tim */
#define IS_TIM_CKD_DIV(DIV) (((DIV) == TIM_CKD_DIV1) || \
                             ((DIV) == TIM_CKD_DIV2) || \
                             ((DIV) == TIM_CKD_DIV4))
/**
  * @}
  */

/** @defgroup TIM_Output_Compare_and_PWM_modes TIM Output Compare and PWM Modes
  * @{
  */
#define TIM_OCMODE_TIMING           ((uint32)0x00000000U) /*!< Timing mode        */
#define TIM_OCMODE_ACTIVE           ((uint32)0x00000010U) /*!< Active mode        */
#define TIM_OCMODE_INACTIVE         ((uint32)0x00000020U) /*!< Inactive mode      */
#define TIM_OCMODE_TOGGLE           ((uint32)0x00000030U) /*!< Toggle mode        */
#define TIM_OCMODE_FORCED_INACTIVE  ((uint32)0x00000040U) /*!< Forced inactive    */
#define TIM_OCMODE_FORCED_ACTIVE    ((uint32)0x00000050U) /*!< Forced active      */
#define TIM_OCMODE_PWM1             ((uint32)0x00000060U) /*!< PWM mode 1         */
#define TIM_OCMODE_PWM2             ((uint32)0x00000070U) /*!< PWM mode 2         */
/* The output compare mode field (CCMRx.OCxM) is four bits wide: the three
 * lower bits live next to the channel selection bits, the fourth one
 * (OCxM[3]) is placed in the upper half of the same register (CCMR1.OC1M_3 at
 * bit16, CCMR1.OC2M_3 at bit24, CCMR2.OC3M_3 at bit16, CCMR2.OC4M_3 at bit24,
 * CCMR3.OC5M_3 at bit16, CCMR3.OC6M_3 at bit24). The selectors below carry
 * the same layout as the register field, so they can be written straight into
 * the register (the high channel of every register is reached with a left
 * shift of 8, which maps 0x00010000 to the matching 0x01000000 bit). */
#define TIM_OCMODE_ASYM_PWM1        ((uint32)0x00010000U) /*!< Asymmetric PWM mode 1 (OCxM = 1000) */
#define TIM_OCMODE_ASYM_PWM2        ((uint32)0x00010010U) /*!< Asymmetric PWM mode 2 (OCxM = 1001) */
#define TIM_OCMODE_COMBINED_PWM1    ((uint32)0x00010040U) /*!< Combined PWM mode 1   (OCxM = 1100) */
#define TIM_OCMODE_COMBINED_PWM2    ((uint32)0x00010050U) /*!< Combined PWM mode 2   (OCxM = 1101) */
#define TIM_OCMODE_1110             ((uint32)0x00010060U) /*!< OCxM = 1110 mode                    */
#define TIM_OCMODE_1111             ((uint32)0x00010070U) /*!< OCxM = 1111 mode                    */
#define IS_TIM_OC_MODE(MODE) (((MODE) == TIM_OCMODE_TIMING) || \
                              ((MODE) == TIM_OCMODE_ACTIVE) || \
                              ((MODE) == TIM_OCMODE_INACTIVE) || \
                              ((MODE) == TIM_OCMODE_TOGGLE) || \
                              ((MODE) == TIM_OCMODE_FORCED_INACTIVE) || \
                              ((MODE) == TIM_OCMODE_FORCED_ACTIVE) || \
                              ((MODE) == TIM_OCMODE_PWM1) || \
                              ((MODE) == TIM_OCMODE_PWM2) || \
                              ((MODE) == TIM_OCMODE_ASYM_PWM1) || \
                              ((MODE) == TIM_OCMODE_ASYM_PWM2) || \
                              ((MODE) == TIM_OCMODE_COMBINED_PWM1) || \
                              ((MODE) == TIM_OCMODE_COMBINED_PWM2) || \
                              ((MODE) == TIM_OCMODE_1110) || \
                              ((MODE) == TIM_OCMODE_1111))
#define IS_TIM_PWM_MODE(MODE) (((MODE) == TIM_OCMODE_PWM1) || \
                               ((MODE) == TIM_OCMODE_PWM2) || \
                               ((MODE) == TIM_OCMODE_ASYM_PWM1) || \
                               ((MODE) == TIM_OCMODE_ASYM_PWM2) || \
                               ((MODE) == TIM_OCMODE_COMBINED_PWM1) || \
                               ((MODE) == TIM_OCMODE_COMBINED_PWM2) || \
                               ((MODE) == TIM_OCMODE_1110) || \
                               ((MODE) == TIM_OCMODE_1111))
/**
  * @}
  */

/** @defgroup TIM_Output_Compare_Fast_Mode TIM Output Compare Fast Mode
  * @note  The values are the CCMRx.OCxFE bit values; the fast mode is only
  *        effective in the PWM modes.
  * @{
  */
#define TIM_OCFAST_ENABLE  ((uint32)0x00000004U) /*!< OC fast mode enabled  */
#define TIM_OCFAST_DISABLE ((uint32)0x00000000U) /*!< OC fast mode disabled */
#define IS_TIM_OCFAST(STATE) (((STATE) == TIM_OCFAST_ENABLE) || \
                              ((STATE) == TIM_OCFAST_DISABLE))
/**
  * @}
  */

/** @defgroup TIM_Output_Compare_Preload TIM Output Compare Preload Enable
  * @note  The values are the CCMRx.OCxPE bit values. When the preload is
  *        enabled the CCRx write is buffered into the preload register and
  *        becomes active on the next update event, so a pulse update cannot
  *        produce a spurious compare match inside the current period.
  * @{
  */
#define TIM_OCPRECONFIG_DISABLE ((uint32)0x00000000U) /*!< OC preload disabled */
#define TIM_OCPRECONFIG_ENABLE  ((uint32)0x00000008U) /*!< OC preload enabled  */
#define IS_TIM_OCPRELOAD_STATE(STATE) (((STATE) == TIM_OCPRECONFIG_DISABLE) || \
                                       ((STATE) == TIM_OCPRECONFIG_ENABLE))
/**
  * @}
  */

/** @defgroup TIM_Output_Compare_State TIM Output Compare State
  * @{
  */
#define TIM_OUTPUTSTATE_DISABLE ((uint32)0x00000000U) /*!< Output disabled */
#define TIM_OUTPUTSTATE_ENABLE  ((uint32)0x00000001U) /*!< Output enabled  */
#define IS_TIM_OUTPUT_STATE(STATE) (((STATE) == TIM_OUTPUTSTATE_DISABLE) || \
                                    ((STATE) == TIM_OUTPUTSTATE_ENABLE))
#define TIM_OUTPUTNSTATE_DISABLE ((uint32)0x00000000U) /*!< Complementary output disabled */
#define TIM_OUTPUTNSTATE_ENABLE  ((uint32)0x00000004U) /*!< Complementary output enabled  */
#define IS_TIM_OUTPUTN_STATE(STATE) (((STATE) == TIM_OUTPUTNSTATE_DISABLE) || \
                                     ((STATE) == TIM_OUTPUTNSTATE_ENABLE))
/**
  * @}
  */

/** @defgroup TIM_Output_Compare_Polarity TIM Output Compare Polarity
  * @{
  */
#define TIM_OCPOLARITY_HIGH ((uint32)0x00000000U) /*!< Output active high */
#define TIM_OCPOLARITY_LOW  ((uint32)0x00000002U) /*!< Output active low  */
#define IS_TIM_OC_POLARITY(POL) (((POL) == TIM_OCPOLARITY_HIGH) || \
                                 ((POL) == TIM_OCPOLARITY_LOW))
#define TIM_OCNPOLARITY_HIGH ((uint32)0x00000000U) /*!< Complementary active high */
#define TIM_OCNPOLARITY_LOW  ((uint32)0x00000008U) /*!< Complementary active low  */
#define IS_TIM_OCN_POLARITY(POL) (((POL) == TIM_OCNPOLARITY_HIGH) || \
                                  ((POL) == TIM_OCNPOLARITY_LOW))
/**
  * @}
  */

/** @defgroup TIM_Output_Compare_Idle_State TIM Output Idle State (advanced only)
  * @{
  */
#define TIM_OCIDLESTATE_RESET ((uint32)0x00000000U) /*!< Output reset in idle */
#define TIM_OCIDLESTATE_SET   ((uint32)0x00000100U) /*!< Output set in idle   */
#define IS_TIM_OCIDLE_STATE(STATE) (((STATE) == TIM_OCIDLESTATE_RESET) || \
                                    ((STATE) == TIM_OCIDLESTATE_SET))
#define TIM_OCNIDLESTATE_RESET ((uint32)0x00000000U) /*!< Complementary reset in idle */
#define TIM_OCNIDLESTATE_SET   ((uint32)0x00000200U) /*!< Complementary set in idle   */
#define IS_TIM_OCNIDLE_STATE(STATE) (((STATE) == TIM_OCNIDLESTATE_RESET) || \
                                     ((STATE) == TIM_OCNIDLESTATE_SET))
/**
  * @}
  */

/** @defgroup TIM_Input_Capture_Polarity TIM Input Capture Polarity
  * @{
  */
#define TIM_ICPOLARITY_RISING  ((uint32)0x00000000U) /*!< Capture on rising edge  */
#define TIM_ICPOLARITY_FALLING ((uint32)0x00000002U) /*!< Capture on falling edge */
#define TIM_ICPOLARITY_BOTHEDGE ((uint32)0x0000000AU) /*!< Capture on both edges   */
#define IS_TIM_IC_POLARITY(POL) (((POL) == TIM_ICPOLARITY_RISING) || \
                                 ((POL) == TIM_ICPOLARITY_FALLING) || \
                                 ((POL) == TIM_ICPOLARITY_BOTHEDGE))
/**
  * @}
  */

/** @defgroup TIM_Input_Capture_Selection TIM Input Capture Selection
  * @{
  */
#define TIM_ICSEL_DIRECTTI   ((uint32)0x00000001U) /*!< Direct TI input  */
#define TIM_ICSEL_INDIRECTTI ((uint32)0x00000002U) /*!< Indirect TI input */
#define TIM_ICSEL_TRC        ((uint32)0x00000003U) /*!< Internal trigger input */
#define IS_TIM_IC_SELECTION(SEL) (((SEL) == TIM_ICSEL_DIRECTTI) || \
                                   ((SEL) == TIM_ICSEL_INDIRECTTI) || \
                                   ((SEL) == TIM_ICSEL_TRC))
/**
  * @}
  */

/** @defgroup TIM_Input_Capture_Prescaler TIM Input Capture Prescaler
  * @{
  */
#define TIM_ICPSC_DIV1 ((uint32)0x00000000U) /*!< Capture every event    */
#define TIM_ICPSC_DIV2 ((uint32)0x00000004U) /*!< Capture every 2 events */
#define TIM_ICPSC_DIV4 ((uint32)0x00000008U) /*!< Capture every 4 events */
#define TIM_ICPSC_DIV8 ((uint32)0x0000000CU) /*!< Capture every 8 events */
#define IS_TIM_IC_PRESCALER(PSC) (((PSC) == TIM_ICPSC_DIV1) || \
                                  ((PSC) == TIM_ICPSC_DIV2) || \
                                  ((PSC) == TIM_ICPSC_DIV4) || \
                                  ((PSC) == TIM_ICPSC_DIV8))
/**
  * @}
  */

/** @defgroup TIM_Encoder_Mode TIM Encoder Mode
  * @{
  */
#define TIM_ENCODERMODE_TI1  ((uint32)0x00000001U) /*!< Encoder mode 1 */
#define TIM_ENCODERMODE_TI2  ((uint32)0x00000002U) /*!< Encoder mode 2 */
#define TIM_ENCODERMODE_TI12 ((uint32)0x00000003U) /*!< Encoder mode 3 */
#define IS_TIM_ENCODER_MODE(MODE) (((MODE) == TIM_ENCODERMODE_TI1) || \
                                   ((MODE) == TIM_ENCODERMODE_TI2) || \
                                   ((MODE) == TIM_ENCODERMODE_TI12))
/**
  * @}
  */

/** @defgroup TIM_One_Pulse_Mode TIM One Pulse Mode
  * @{
  */
#define TIM_OPMODE_SINGLE     ((uint32)0x00000008U) /*!< Single pulse mode  */
#define TIM_OPMODE_REPETITIVE ((uint32)0x00000000U) /*!< Repetitive mode    */
#define IS_TIM_OPM_MODE(MODE) (((MODE) == TIM_OPMODE_SINGLE) || \
                               ((MODE) == TIM_OPMODE_REPETITIVE))
/**
  * @}
  */

/** @defgroup TIM_Interrupt_Source TIM Interrupt Sources
  * @note  The values are the DIER register bit masks and are used directly
  *        against DIER by the __HAL_TIM_ENABLE_IT / __HAL_TIM_DISABLE_IT /
  *        __HAL_TIM_GET_IT_SOURCE macros, so they are not codes to be shifted.
  *        This device places the capture/compare enables in the high half of
  *        the register (CCxIE = bits 16..21) and the update / trigger / break
  *        enables in the low half (UIE = bit0, TIE = bit2, BIE = bit3).
  * @note  There is no commutation interrupt on this device (DIER has no COMIE
  *        bit): only the EGR.COMG event source exists, see
  *        TIM_EVENTSOURCE_COM.
  * @{
  */
#define TIM_IT_UPDATE  ((uint32)0x00000001U) /*!< Update interrupt (DIER.UIE, bit0)                  */
#define TIM_IT_CC1     ((uint32)0x00010000U) /*!< Channel 1 capture/compare interrupt (DIER.CC1IE)   */
#define TIM_IT_CC2     ((uint32)0x00020000U) /*!< Channel 2 capture/compare interrupt (DIER.CC2IE)   */
#define TIM_IT_CC3     ((uint32)0x00040000U) /*!< Channel 3 capture/compare interrupt (DIER.CC3IE)   */
#define TIM_IT_CC4     ((uint32)0x00080000U) /*!< Channel 4 capture/compare interrupt (DIER.CC4IE)   */
#define TIM_IT_CC5     ((uint32)0x00100000U) /*!< Channel 5 capture/compare interrupt (advanced only) */
#define TIM_IT_CC6     ((uint32)0x00200000U) /*!< Channel 6 capture/compare interrupt (advanced only) */
#define TIM_IT_TRIGGER ((uint32)0x00000004U) /*!< Trigger interrupt (DIER.TIE, bit2)                 */
#define TIM_IT_BREAK   ((uint32)0x00000008U) /*!< Break interrupt (DIER.BIE, bit3, advanced only)    */
/* Allowed DIER bits: UIE(bit0), TIE(bit2), BIE(bit3), CC1IE..CC6IE(bits16..21).
   Every other bit of DIER is reserved on this device. */
#define IS_TIM_IT(IT) ((((IT) & (uint32)0xFFC0FFF2U) == 0x00000000U) && ((IT) != 0x00000000U))
/**
  * @}
  */

/** @defgroup TIM_Event_Source TIM Event Generation Sources
  * @note  The values are the EGR register write values and are written to EGR
  *        directly (HAL_TIM_GenerateEvent assigns the whole register), so they
  *        are masks, not codes to be shifted. This device places the
  *        capture/compare generations in the high half (CCxG = bits 16..21)
  *        and UG / COMG / TG / BG in bits 0..3.
  * @{
  */
#define TIM_EVENTSOURCE_UPDATE  ((uint32)0x00000001U) /*!< Generate an update event (EGR.UG, bit0)   */
#define TIM_EVENTSOURCE_COM     ((uint32)0x00000002U) /*!< Generate a COM event (EGR.COMG, bit1)      */
#define TIM_EVENTSOURCE_TRIGGER ((uint32)0x00000004U) /*!< Generate a trigger event (EGR.TG, bit2)    */
#define TIM_EVENTSOURCE_BREAK   ((uint32)0x00000008U) /*!< Generate a break event (EGR.BG, bit3,
                                                           advanced only)                               */
#define TIM_EVENTSOURCE_CC1     ((uint32)0x00010000U) /*!< Generate a CC1 event (EGR.CC1G)            */
#define TIM_EVENTSOURCE_CC2     ((uint32)0x00020000U) /*!< Generate a CC2 event (EGR.CC2G)            */
#define TIM_EVENTSOURCE_CC3     ((uint32)0x00040000U) /*!< Generate a CC3 event (EGR.CC3G)            */
#define TIM_EVENTSOURCE_CC4     ((uint32)0x00080000U) /*!< Generate a CC4 event (EGR.CC4G)            */
#define TIM_EVENTSOURCE_CC5     ((uint32)0x00100000U) /*!< Generate a CC5 event (EGR.CC5G, advanced)  */
#define TIM_EVENTSOURCE_CC6     ((uint32)0x00200000U) /*!< Generate a CC6 event (EGR.CC6G, advanced)  */
/* Allowed EGR bits: UG(0), COMG(1), TG(2), BG(3), CC1G..CC6G(bits16..21). */
#define IS_TIM_EVENT_SOURCE(SOURCE) ((((SOURCE) & (uint32)0xFFC0FFF0U) == 0x00000000U) && ((SOURCE) != 0x00000000U))
/**
  * @}
  */

/** @defgroup TIM_Flag TIM Status Flags
  * @note  The values are the SR register bit masks and are used directly
  *        against SR by the __HAL_TIM_GET_FLAG / __HAL_TIM_CLEAR_FLAG macros,
  *        so they are not codes to be shifted. UIF / TIF / BIF are bits 0/2/3
  *        and CC1IF..CC6IF / CC1OF..CC6OF are bits 16..21 / 24..29.
  * @note  There is no commutation flag on this device (SR has no COMIF bit).
  * @{
  */
#define TIM_FLAG_UPDATE  ((uint32)0x00000001U) /*!< Update flag (SR.UIF, bit0)                     */
#define TIM_FLAG_TRIGGER ((uint32)0x00000004U) /*!< Trigger flag (SR.TIF, bit2)                    */
#define TIM_FLAG_BREAK   ((uint32)0x00000008U) /*!< Break flag (SR.BIF, bit3, advanced only)       */
#define TIM_FLAG_CC1     ((uint32)0x00010000U) /*!< Channel 1 flag (SR.CC1IF)                      */
#define TIM_FLAG_CC2     ((uint32)0x00020000U) /*!< Channel 2 flag (SR.CC2IF)                      */
#define TIM_FLAG_CC3     ((uint32)0x00040000U) /*!< Channel 3 flag (SR.CC3IF)                      */
#define TIM_FLAG_CC4     ((uint32)0x00080000U) /*!< Channel 4 flag (SR.CC4IF)                      */
#define TIM_FLAG_CC5     ((uint32)0x00100000U) /*!< Channel 5 flag (SR.CC5IF, advanced only)        */
#define TIM_FLAG_CC6     ((uint32)0x00200000U) /*!< Channel 6 flag (SR.CC6IF, advanced only)        */
#define TIM_FLAG_CC1OF   ((uint32)0x01000000U) /*!< Channel 1 over-capture flag (SR.CC1OF)          */
#define TIM_FLAG_CC2OF   ((uint32)0x02000000U) /*!< Channel 2 over-capture flag (SR.CC2OF)          */
#define TIM_FLAG_CC3OF   ((uint32)0x04000000U) /*!< Channel 3 over-capture flag (SR.CC3OF)          */
#define TIM_FLAG_CC4OF   ((uint32)0x08000000U) /*!< Channel 4 over-capture flag (SR.CC4OF)          */
#define TIM_FLAG_CC5OF   ((uint32)0x10000000U) /*!< Channel 5 over-capture flag (SR.CC5OF, advanced) */
#define TIM_FLAG_CC6OF   ((uint32)0x20000000U) /*!< Channel 6 over-capture flag (SR.CC6OF, advanced) */
/* Allowed SR bits: bits 0..29. SR bits 30 and 31 are reserved. */
#define IS_TIM_GET_FLAG(FLAG) ((((FLAG) & (uint32)0xC0000000U) == 0x00000000U) && ((FLAG) != 0x00000000U))
/**
  * @}
  */

/** @defgroup TIM_Enable_Value TIM Enable Value
  * @{
  */
#define TIM_ENABLE                   1U       /*!< Enable the TIM counter  */
#define TIM_DISABLE                  0U       /*!< Disable the TIM counter */
#define IS_TIM_ENABLE_STATE(NEWSTATE) (((NEWSTATE) == TIM_ENABLE) || ((NEWSTATE) == TIM_DISABLE))
/**
  * @}
  */

/** @defgroup TIM_Slave_Mode TIM Slave Mode
  * @note  The values are the SMCR.SMS field values.
  * @{
  */
#define TIM_SLAVEMODE_DISABLE          ((uint32)0x00000000U) /*!< Slave mode disabled           */
#define TIM_SLAVEMODE_RESET            ((uint32)0x00000004U) /*!< Reset mode                    */
#define TIM_SLAVEMODE_GATED            ((uint32)0x00000005U) /*!< Gated mode                    */
#define TIM_SLAVEMODE_TRIGGER          ((uint32)0x00000006U) /*!< Trigger mode                  */
#define TIM_SLAVEMODE_EXTERNAL1        ((uint32)0x00000007U) /*!< External clock mode 1         */
#define IS_TIM_SLAVE_MODE(MODE) (((MODE) == TIM_SLAVEMODE_DISABLE) || \
                                 ((MODE) == TIM_SLAVEMODE_RESET) || \
                                 ((MODE) == TIM_SLAVEMODE_GATED) || \
                                 ((MODE) == TIM_SLAVEMODE_TRIGGER) || \
                                 ((MODE) == TIM_SLAVEMODE_EXTERNAL1))
/**
  * @}
  */

/** @defgroup TIM_Trigger_Selection TIM Internal Trigger Selection
  * @note  The values are the SMCR.TS field values.
  * @{
  */
#define TIM_TS_ITR0     ((uint32)0x00000000U) /*!< Internal trigger 0  */
#define TIM_TS_ITR1     ((uint32)0x00000010U) /*!< Internal trigger 1  */
#define TIM_TS_ITR2     ((uint32)0x00000020U) /*!< Internal trigger 2  */
#define TIM_TS_ITR3     ((uint32)0x00000030U) /*!< Internal trigger 3  */
#define TIM_TS_TI1F_ED  ((uint32)0x00000040U) /*!< TI1 edge detector   */
#define TIM_TS_TI1FP1   ((uint32)0x00000050U) /*!< TI1 filtered input  */
#define TIM_TS_TI2FP2   ((uint32)0x00000060U) /*!< TI2 filtered input  */
#define TIM_TS_ETRF     ((uint32)0x00000070U) /*!< External trigger    */
#define IS_TIM_TRIGGER_SELECTION(SEL) (((SEL) == TIM_TS_ITR0) || \
                                       ((SEL) == TIM_TS_ITR1) || \
                                       ((SEL) == TIM_TS_ITR2) || \
                                       ((SEL) == TIM_TS_ITR3) || \
                                       ((SEL) == TIM_TS_TI1F_ED) || \
                                       ((SEL) == TIM_TS_TI1FP1) || \
                                       ((SEL) == TIM_TS_TI2FP2) || \
                                       ((SEL) == TIM_TS_ETRF))
/**
  * @}
  */

/** @defgroup TIM_Trigger_Polarity TIM Trigger Polarity
  * @{
  */
#define TIM_TRIGGERPOLARITY_NONINVERTED ((uint32)0x00000000U) /*!< Non-inverted trigger polarity */
#define TIM_TRIGGERPOLARITY_INVERTED    ((uint32)0x00008000U) /*!< Inverted trigger polarity     */
#define TIM_TRIGGERPOLARITY_RISING      ((uint32)0x00000000U) /*!< Rising edge                   */
#define TIM_TRIGGERPOLARITY_FALLING     ((uint32)0x00000002U) /*!< Falling edge                  */
#define TIM_TRIGGERPOLARITY_BOTHEDGE    ((uint32)0x0000000AU) /*!< Both edges                    */
#define IS_TIM_TRIGGER_POLARITY(POL) (((POL) == TIM_TRIGGERPOLARITY_NONINVERTED) || \
                                      ((POL) == TIM_TRIGGERPOLARITY_INVERTED) || \
                                      ((POL) == TIM_TRIGGERPOLARITY_RISING) || \
                                      ((POL) == TIM_TRIGGERPOLARITY_FALLING) || \
                                      ((POL) == TIM_TRIGGERPOLARITY_BOTHEDGE))
/**
  * @}
  */

/** @defgroup TIM_Clock_Source TIM Clock Source
  * @note  The values are the SMCR clock selection codes. All the trigger
  *        selections are written to the SMCR.TS field unchanged, so they are
  *        the TS field masks: ITR0 = 0x00, ITR1 = 0x10, TI1F_ED = 0x40,
  *        TI1FP1 = 0x50, TI2FP2 = 0x60, ETRF = 0x70.
  * @note  TIM_CLOCKSOURCE_INTERNAL is a selector that is never written into
  *        SMCR (it selects the internal CK_INT clock, so
  *        HAL_TIM_ConfigClockSource writes SMCR = 0 for it). It must not
  *        collide with any TS code, so the value 0x00000100 is used: an
  *        earlier value of 0x10 collided with TIM_CLOCKSOURCE_ITR1 and made
  *        the ITR1 selection indistinguishable from the internal clock.
  * @note  This device does not support the ITR2 and ITR3 internal triggers:
  *        their selections are always rejected by
  *        HAL_TIM_ConfigClockSource (see the timers chapter of the data
  *        manual), so they must not be used.
  * @{
  */
#define TIM_CLOCKSOURCE_INTERNAL  ((uint32)0x00000100U) /*!< Internal clock (CK_INT, SMCR=0) */
#define TIM_CLOCKSOURCE_ITR0      ((uint32)0x00000000U) /*!< Internal trigger 0        */
#define TIM_CLOCKSOURCE_ITR1      ((uint32)0x00000010U) /*!< Internal trigger 1        */
#define TIM_CLOCKSOURCE_ITR2      ((uint32)0x00000020U) /*!< Internal trigger 2        */
#define TIM_CLOCKSOURCE_ITR3      ((uint32)0x00000030U) /*!< Internal trigger 3        */
#define TIM_CLOCKSOURCE_TI1ED     ((uint32)0x00000040U) /*!< TI1 edge detector         */
#define TIM_CLOCKSOURCE_TI1       ((uint32)0x00000050U) /*!< TI1 filtered input        */
#define TIM_CLOCKSOURCE_TI2       ((uint32)0x00000060U) /*!< TI2 filtered input        */
#define TIM_CLOCKSOURCE_ETRMODE1  ((uint32)0x00000070U) /*!< ETR clock mode 1          */
#define TIM_CLOCKSOURCE_ETRMODE2  ((uint32)0x00002000U) /*!< ETR clock mode 2          */
#define IS_TIM_CLOCK_SOURCE(SOURCE) (((SOURCE) == TIM_CLOCKSOURCE_INTERNAL) || \
                                     ((SOURCE) == TIM_CLOCKSOURCE_ITR0) || \
                                     ((SOURCE) == TIM_CLOCKSOURCE_ITR1) || \
                                     ((SOURCE) == TIM_CLOCKSOURCE_ITR2) || \
                                     ((SOURCE) == TIM_CLOCKSOURCE_ITR3) || \
                                     ((SOURCE) == TIM_CLOCKSOURCE_TI1ED) || \
                                     ((SOURCE) == TIM_CLOCKSOURCE_TI1) || \
                                     ((SOURCE) == TIM_CLOCKSOURCE_TI2) || \
                                     ((SOURCE) == TIM_CLOCKSOURCE_ETRMODE1) || \
                                     ((SOURCE) == TIM_CLOCKSOURCE_ETRMODE2))
/**
  * @}
  */

/** @defgroup TIM_Master_Output_Trigger TIM Master Output Trigger (TRGO)
  * @note  The values are the CR2.MMS field values.
  * @{
  */
#define TIM_TRGO_RESET     ((uint32)0x00000000U) /*!< Reset        */
#define TIM_TRGO_ENABLE    ((uint32)0x00000010U) /*!< Enable       */
#define TIM_TRGO_UPDATE    ((uint32)0x00000020U) /*!< Update       */
#define TIM_TRGO_OC1       ((uint32)0x00000030U) /*!< OC1          */
#define TIM_TRGO_OC1REF    ((uint32)0x00000040U) /*!< OC1 reference */
#define TIM_TRGO_OC2REF    ((uint32)0x00000050U) /*!< OC2 reference */
#define TIM_TRGO_OC3REF    ((uint32)0x00000060U) /*!< OC3 reference */
#define TIM_TRGO_OC4REF    ((uint32)0x00000070U) /*!< OC4 reference */
#define IS_TIM_TRGO_SOURCE(SOURCE) (((SOURCE) == TIM_TRGO_RESET) || \
                                    ((SOURCE) == TIM_TRGO_ENABLE) || \
                                    ((SOURCE) == TIM_TRGO_UPDATE) || \
                                    ((SOURCE) == TIM_TRGO_OC1) || \
                                    ((SOURCE) == TIM_TRGO_OC1REF) || \
                                    ((SOURCE) == TIM_TRGO_OC2REF) || \
                                    ((SOURCE) == TIM_TRGO_OC3REF) || \
                                    ((SOURCE) == TIM_TRGO_OC4REF))
/**
  * @}
  */

/** @defgroup TIM_Master_Output_Trigger_2 TIM Second Master Output Trigger (TRGO2)
  * @note  The values are the CR2.MMS2 field values (four bits wide on this
  *        device, so all sixteen encodings are addressable).
  * @note  TRGO2 only exists on the advanced timers TIM0 / TIM1 / TIM2 / TIM5;
  *        CR2.MMS2 is not implemented on the general purpose timers
  *        TIM3 / TIM4 / TIM6 / TIM7 (the device layer keeps the field for the
  *        shared register definition only), therefore a real TRGO2 source is
  *        refused on those instances.
  * @{
  */
#define TIM_TRGO2_RESET                         ((uint32)0x00000000U) /*!< Reset                            */
#define TIM_TRGO2_ENABLE                        ((uint32)0x00100000U) /*!< Enable                           */
#define TIM_TRGO2_UPDATE                        ((uint32)0x00200000U) /*!< Update                           */
#define TIM_TRGO2_OC1                           ((uint32)0x00300000U) /*!< OC1                              */
#define TIM_TRGO2_OC1REF                        ((uint32)0x00400000U) /*!< OC1 reference                    */
#define TIM_TRGO2_OC2REF                        ((uint32)0x00500000U) /*!< OC2 reference                    */
#define TIM_TRGO2_OC3REF                        ((uint32)0x00600000U) /*!< OC3 reference                    */
#define TIM_TRGO2_OC4REF                        ((uint32)0x00700000U) /*!< OC4 reference                    */
#define TIM_TRGO2_OC5REF                        ((uint32)0x00800000U) /*!< OC5 reference                    */
#define TIM_TRGO2_OC6REF                        ((uint32)0x00900000U) /*!< OC6 reference                    */
#define TIM_TRGO2_OC4REF_RISINGFALLING          ((uint32)0x00A00000U) /*!< OC4REF rising or falling         */
#define TIM_TRGO2_OC6REF_RISINGFALLING          ((uint32)0x00B00000U) /*!< OC6REF rising or falling         */
#define TIM_TRGO2_OC4REF_RISING_OC6REF_RISING   ((uint32)0x00C00000U) /*!< OC4REF or OC6REF rising          */
#define TIM_TRGO2_OC4REF_RISINGFALLING_OC6REF_RISING ((uint32)0x00D00000U) /*!< OC4REF rising/falling or OC6REF rising */
#define TIM_TRGO2_OC5REF_RISING_OC6REF_RISING   ((uint32)0x00E00000U) /*!< OC5REF or OC6REF rising          */
#define TIM_TRGO2_OC5REF_RISINGFALLING_OC6REF_RISING ((uint32)0x00F00000U) /*!< OC5REF rising/falling or OC6REF rising */
#define IS_TIM_TRGO2_SOURCE(SOURCE) (((SOURCE) == TIM_TRGO2_RESET) || \
                                      ((SOURCE) == TIM_TRGO2_ENABLE) || \
                                      ((SOURCE) == TIM_TRGO2_UPDATE) || \
                                      ((SOURCE) == TIM_TRGO2_OC1) || \
                                      ((SOURCE) == TIM_TRGO2_OC1REF) || \
                                      ((SOURCE) == TIM_TRGO2_OC2REF) || \
                                      ((SOURCE) == TIM_TRGO2_OC3REF) || \
                                      ((SOURCE) == TIM_TRGO2_OC4REF) || \
                                      ((SOURCE) == TIM_TRGO2_OC5REF) || \
                                      ((SOURCE) == TIM_TRGO2_OC6REF) || \
                                      ((SOURCE) == TIM_TRGO2_OC4REF_RISINGFALLING) || \
                                      ((SOURCE) == TIM_TRGO2_OC6REF_RISINGFALLING) || \
                                      ((SOURCE) == TIM_TRGO2_OC4REF_RISING_OC6REF_RISING) || \
                                      ((SOURCE) == TIM_TRGO2_OC4REF_RISINGFALLING_OC6REF_RISING) || \
                                      ((SOURCE) == TIM_TRGO2_OC5REF_RISING_OC6REF_RISING) || \
                                      ((SOURCE) == TIM_TRGO2_OC5REF_RISINGFALLING_OC6REF_RISING))
/**
  * @}
  */

/** @defgroup TIM_Master_Slave_Mode TIM Master Slave Mode
  * @{
  */
#define TIM_MASTERSLAVEMODE_ENABLE  ((uint32)0x00000080U) /*!< Master-slave mode enabled  */
#define TIM_MASTERSLAVEMODE_DISABLE ((uint32)0x00000000U) /*!< Master-slave mode disabled */
#define IS_TIM_MASTERSLAVEMODE(MODE) (((MODE) == TIM_MASTERSLAVEMODE_ENABLE) || \
                                      ((MODE) == TIM_MASTERSLAVEMODE_DISABLE))
/**
  * @}
  */

/** @defgroup TIM_Off_State TIM Off State (advanced)
  * @{
  */
#define TIM_OSSR_ENABLE  ((uint32)0x00000800U) /*!< OSSR enabled  */
#define TIM_OSSR_DISABLE ((uint32)0x00000000U) /*!< OSSR disabled */
#define TIM_OSSI_ENABLE  ((uint32)0x00000400U) /*!< OSSI enabled  */
#define TIM_OSSI_DISABLE ((uint32)0x00000000U) /*!< OSSI disabled */
#define IS_TIM_OSSSR_STATE(STATE) (((STATE) == TIM_OSSR_ENABLE) || ((STATE) == TIM_OSSR_DISABLE))
#define IS_TIM_OSSSI_STATE(STATE) (((STATE) == TIM_OSSI_ENABLE) || ((STATE) == TIM_OSSI_DISABLE))
/**
  * @}
  */

/** @defgroup TIM_Lock_Level TIM Lock Level (advanced)
  * @{
  */
#define TIM_LOCKLEVEL_OFF    ((uint32)0x00000000U) /*!< Lock level off    */
#define TIM_LOCKLEVEL_1      ((uint32)0x00000100U) /*!< Lock level 1      */
#define TIM_LOCKLEVEL_2      ((uint32)0x00000200U) /*!< Lock level 2      */
#define TIM_LOCKLEVEL_3      ((uint32)0x00000300U) /*!< Lock level 3      */
#define IS_TIM_LOCK_LEVEL(LEVEL) (((LEVEL) == TIM_LOCKLEVEL_OFF) || \
                                  ((LEVEL) == TIM_LOCKLEVEL_1) || \
                                  ((LEVEL) == TIM_LOCKLEVEL_2) || \
                                  ((LEVEL) == TIM_LOCKLEVEL_3))
/**
  * @}
  */

/** @defgroup TIM_Break_Input TIM Break Input (advanced)
  * @{
  */
#define TIM_BREAK_ENABLE      ((uint32)0x00001000U) /*!< Break enabled  */
#define TIM_BREAK_DISABLE     ((uint32)0x00000000U) /*!< Break disabled */
#define TIM_BREAKPOLARITY_HIGH ((uint32)0x00002000U) /*!< Break polarity high */
#define TIM_BREAKPOLARITY_LOW  ((uint32)0x00000000U) /*!< Break polarity low  */
#define IS_TIM_BREAK_STATE(STATE) (((STATE) == TIM_BREAK_ENABLE) || ((STATE) == TIM_BREAK_DISABLE))
#define IS_TIM_BREAK_POLARITY(POL) (((POL) == TIM_BREAKPOLARITY_HIGH) || ((POL) == TIM_BREAKPOLARITY_LOW))
/**
  * @}
  */

/** @defgroup TIM_Automatic_Output TIM Automatic Output (advanced)
  * @{
  */
#define TIM_AUTOMATICOUTPUT_ENABLE  ((uint32)0x00004000U) /*!< Automatic output enabled  */
#define TIM_AUTOMATICOUTPUT_DISABLE ((uint32)0x00000000U) /*!< Automatic output disabled */
#define IS_TIM_AUTOMATIC_OUTPUT_STATE(STATE) (((STATE) == TIM_AUTOMATICOUTPUT_ENABLE) || \
                                              ((STATE) == TIM_AUTOMATICOUTPUT_DISABLE))
/**
  * @}
  */

/** @defgroup TIM_CC_Channel_State TIM Capture/Compare Channel State
  * @{
  */
#define TIM_CCx_ENABLE   ((uint32)0x00000001U) /*!< Channel output / capture enabled  */
#define TIM_CCx_DISABLE  ((uint32)0x00000000U) /*!< Channel output / capture disabled */
#define TIM_CCxN_ENABLE  ((uint32)0x00000004U) /*!< Complementary output enabled      */
#define TIM_CCxN_DISABLE ((uint32)0x00000000U) /*!< Complementary output disabled     */
#define IS_TIM_CCX(CCX) (((CCX) == TIM_CCx_ENABLE) || ((CCX) == TIM_CCx_DISABLE))
#define IS_TIM_CCXN(CCXN) (((CCXN) == TIM_CCxN_ENABLE) || ((CCXN) == TIM_CCxN_DISABLE))
/**
  * @}
  */

/** @defgroup TIM_Clock_Prescaler TIM Clock Prescaler
  * @{
  */
#define TIM_CLOCKPRESCALER_DIV1 ((uint32)0x00000000U) /*!< Clock prescaler DIV1 */
#define TIM_CLOCKPRESCALER_DIV2 ((uint32)0x00001000U) /*!< Clock prescaler DIV2 */
#define TIM_CLOCKPRESCALER_DIV4 ((uint32)0x00002000U) /*!< Clock prescaler DIV4 */
#define TIM_CLOCKPRESCALER_DIV8 ((uint32)0x00003000U) /*!< Clock prescaler DIV8 */
/**
  * @}
  */

/** @defgroup TIM_ETR_Polarity TIM External Trigger Polarity
  * @{
  */
#define TIM_ETRPOLARITY_NONINVERTED ((uint32)0x00000000U) /*!< ETR non-inverted */
#define TIM_ETRPOLARITY_INVERTED    ((uint32)0x00008000U) /*!< ETR inverted     */
#define IS_TIM_ETR_POLARITY(POL) (((POL) == TIM_ETRPOLARITY_NONINVERTED) || \
                                  ((POL) == TIM_ETRPOLARITY_INVERTED))
/**
  * @}
  */

/** @defgroup TIM_Clear_Input TIM Clear Input
  * @{
  */
#define TIM_CLEARINPUT_DISABLE ((uint32)0x00000000U) /*!< Clear input disabled */
#define TIM_CLEARINPUT_ENABLE  ((uint32)0x00000001U) /*!< Clear input enabled  */
#define TIM_CLEARINPUTSOURCE_NONE     ((uint32)0x00000000U) /*!< No clear input source */
#define TIM_CLEARINPUTSOURCE_ETR      ((uint32)0x00000001U) /*!< ETR clear input source */
#define TIM_CLEARINPUTSOURCE_OCREFCLR ((uint32)0x00000002U) /*!< OCREFCLR clear input source */
#define TIM_CLEARINPUTPOLARITY_NONINVERTED ((uint32)0x00000000U) /*!< Non-inverted polarity */
#define TIM_CLEARINPUTPOLARITY_INVERTED    ((uint32)0x00008000U) /*!< Inverted polarity     */
#define TIM_CLEARINPUTPRESCALER_DIV1 ((uint32)0x00000000U) /*!< Prescaler DIV1 */
#define TIM_CLEARINPUTPRESCALER_DIV2 ((uint32)0x00001000U) /*!< Prescaler DIV2 */
#define TIM_CLEARINPUTPRESCALER_DIV4 ((uint32)0x00002000U) /*!< Prescaler DIV4 */
#define TIM_CLEARINPUTPRESCALER_DIV8 ((uint32)0x00003000U) /*!< Prescaler DIV8 */
#define IS_TIM_CLEARINPUT_PRESCALER(PSC) IS_TIM_CLOCK_PRESCALER(PSC)
/**
  * @}
  */

/** @defgroup TIM_DMA_Request_Source TIM DMA Request Sources
  * @note  The values are the DIER register *DE bits; a capture/compare event or
  *        the update event asserts the corresponding DMA request.
  * @{
  */
#define TIM_DMA_Update   ((uint32)0x00000100U) /*!< Update DMA request enable  */
#define TIM_DMA_CC1      ((uint32)0x01000000U) /*!< Channel 1 DMA request enable */
#define TIM_DMA_CC2      ((uint32)0x02000000U) /*!< Channel 2 DMA request enable */
#define TIM_DMA_CC3      ((uint32)0x04000000U) /*!< Channel 3 DMA request enable */
#define TIM_DMA_CC4      ((uint32)0x08000000U) /*!< Channel 4 DMA request enable */
#define TIM_DMA_CC5      ((uint32)0x10000000U) /*!< Channel 5 DMA request enable (advanced) */
#define TIM_DMA_CC6      ((uint32)0x20000000U) /*!< Channel 6 DMA request enable (advanced) */
#define IS_TIM_DMA(DMA)  ((((DMA) == TIM_DMA_Update) || \
                           ((DMA) == TIM_DMA_CC1) || \
                           ((DMA) == TIM_DMA_CC2) || \
                           ((DMA) == TIM_DMA_CC3) || \
                           ((DMA) == TIM_DMA_CC4) || \
                           ((DMA) == TIM_DMA_CC5) || \
                           ((DMA) == TIM_DMA_CC6)))
/**
  * @}
  */

/** @defgroup TIM_DMA_Burst_Base_Address TIM DMA Burst Base Address
  * @note  The values are the DCR.DBA field values (register index within the
  *        timer register file). The ARR base code is the register index of the
  *        ARR register (0x0C), as derived from the ARR register offset (0x30).
  * @{
  */
#define TIM_DMABase_CR1    ((uint32)0x00000000U) /*!< CR1 register base       */
#define TIM_DMABase_CR2    ((uint32)0x00000001U) /*!< CR2 register base       */
#define TIM_DMABase_SMCR   ((uint32)0x00000002U) /*!< SMCR register base      */
#define TIM_DMABase_DIER   ((uint32)0x00000003U) /*!< DIER register base      */
#define TIM_DMABase_SR     ((uint32)0x00000004U) /*!< SR register base        */
#define TIM_DMABase_EGR    ((uint32)0x00000005U) /*!< EGR register base       */
#define TIM_DMABase_CCMR1  ((uint32)0x00000006U) /*!< CCMR1 register base     */
#define TIM_DMABase_CCMR2  ((uint32)0x00000007U) /*!< CCMR2 register base     */
#define TIM_DMABase_CCMR3  ((uint32)0x00000008U) /*!< CCMR3 register base     */
#define TIM_DMABase_CCER   ((uint32)0x00000009U) /*!< CCER register base      */
#define TIM_DMABase_CNT    ((uint32)0x0000000AU) /*!< CNT register base       */
#define TIM_DMABase_PSC    ((uint32)0x0000000BU) /*!< PSC register base       */
#define TIM_DMABase_ARR    ((uint32)0x0000000CU) /*!< ARR register base       */
#define TIM_DMABase_RCR    ((uint32)0x0000000DU) /*!< RCR register base       */
#define TIM_DMABase_CCR1   ((uint32)0x0000000EU) /*!< CCR1 register base      */
#define TIM_DMABase_CCR2   ((uint32)0x0000000FU) /*!< CCR2 register base      */
#define TIM_DMABase_CCR3   ((uint32)0x00000010U) /*!< CCR3 register base      */
#define TIM_DMABase_CCR4   ((uint32)0x00000011U) /*!< CCR4 register base      */
#define TIM_DMABase_CCR5   ((uint32)0x00000012U) /*!< CCR5 register base      */
#define TIM_DMABase_CCR6   ((uint32)0x00000013U) /*!< CCR6 register base      */
#define TIM_DMABase_BDTR   ((uint32)0x00000014U) /*!< BDTR register base      */
#define TIM_DMABase_DCR    ((uint32)0x00000015U) /*!< DCR register base       */
#define TIM_DMABase_DMAR   ((uint32)0x00000016U) /*!< DMAR register base      */
#define TIM_DMABase_AF1    ((uint32)0x00000017U) /*!< AF1 register base       */
#define IS_TIM_DMA_BASE(BASE)  ((BASE) <= 0x00000017U)
/**
  * @}
  */

/** @defgroup TIM_DMA_Burst_Length TIM DMA Burst Length
  * @note  The values are the DCR.DBL field values (bits [12:8]); a burst of
  *        N transfers is encoded as (N-1) << 8. The output compare / PWM DMA
  *        start functions always use a single transfer burst.
  * @{
  */
#define TIM_DMABurstLength_1Transfer      ((uint32)0x00000000U) /*!< 1 transfer per burst      */
#define TIM_DMABurstLength_2Transfers     ((uint32)0x00000100U) /*!< 2 transfers per burst     */
#define TIM_DMABurstLength_3Transfers     ((uint32)0x00000200U) /*!< 3 transfers per burst     */
#define TIM_DMABurstLength_4Transfers     ((uint32)0x00000300U) /*!< 4 transfers per burst     */
#define TIM_DMABurstLength_5Transfers     ((uint32)0x00000400U) /*!< 5 transfers per burst     */
#define TIM_DMABurstLength_6Transfers     ((uint32)0x00000500U) /*!< 6 transfers per burst     */
#define TIM_DMABurstLength_7Transfers     ((uint32)0x00000600U) /*!< 7 transfers per burst     */
#define TIM_DMABurstLength_8Transfers     ((uint32)0x00000700U) /*!< 8 transfers per burst     */
#define TIM_DMABurstLength_9Transfers     ((uint32)0x00000800U) /*!< 9 transfers per burst     */
#define TIM_DMABurstLength_10Transfers    ((uint32)0x00000900U) /*!< 10 transfers per burst    */
#define TIM_DMABurstLength_11Transfers    ((uint32)0x00000A00U) /*!< 11 transfers per burst    */
#define TIM_DMABurstLength_12Transfers    ((uint32)0x00000B00U) /*!< 12 transfers per burst    */
#define TIM_DMABurstLength_13Transfers    ((uint32)0x00000C00U) /*!< 13 transfers per burst    */
#define TIM_DMABurstLength_14Transfers    ((uint32)0x00000D00U) /*!< 14 transfers per burst    */
#define TIM_DMABurstLength_15Transfers    ((uint32)0x00000E00U) /*!< 15 transfers per burst    */
#define TIM_DMABurstLength_16Transfers    ((uint32)0x00000F00U) /*!< 16 transfers per burst    */
#define IS_TIM_DMA_BURST_LENGTH(LENGTH)  (((LENGTH) <= 0x00000F00U) && \
                                          (((LENGTH) & 0xFFFFE000U) == 0x00000000U))
/**
  * @}
  */

/**
  * @}
  */

/* Exported macros ------------------------------------------------------------*/

/** @defgroup TIM_Exported_Macros TIM Exported Macros
  * @{
  */

/**
 * @brief  Reset the handle State field.
 * @note   Must be used before passing a local handle to HAL_TIM_Base_Init()
 *         the first time, so that the low level initialization (MspInit) is
 *         always executed.
 */
#define __HAL_TIM_RESET_HANDLE_STATE(__HANDLE__) ((__HANDLE__)->State = 0U)

/**
 * @brief  Enable the TIM counter (set the CEN bit).
 * @note   The macros below directly access the peripheral registers and do
 *         not check the handle: the caller must guarantee a valid handle.
 */
#define __HAL_TIM_ENABLE(__HANDLE__)            ((__HANDLE__)->Instance->CR1 |= (TIM_CR1_CEN))

/**
 * @brief  Disable the TIM counter.
 * @note   The CEN bit is only cleared when every CCxE / CCxNE bit of the
 *         CCER register is already cleared (conditional disable).
 */
#define __HAL_TIM_DISABLE(__HANDLE__) \
    do { \
        if (((__HANDLE__)->Instance->CCER & (TIM_CCER_CC1E | TIM_CCER_CC2E | TIM_CCER_CC3E | TIM_CCER_CC4E | \
                                              TIM_CCER_CC1NE | TIM_CCER_CC2NE | TIM_CCER_CC3NE)) == 0U) \
        { \
            (__HANDLE__)->Instance->CR1 &= ~(TIM_CR1_CEN); \
        } \
    } while (0U)

/**
 * @brief  Check whether a TIM flag is set.
 * @param  __FLAG__: TIM_FLAG_xxx (SR bit position).
 * @retval 1 if the flag is set, 0 otherwise.
 */
#define __HAL_TIM_GET_FLAG(__HANDLE__, __FLAG__) (((__HANDLE__)->Instance->SR & (__FLAG__)) != 0U)

/**
 * @brief  Clear a TIM flag.
 * @param  __FLAG__: TIM_FLAG_xxx (SR bit position, write 0 to clear).
 */
#define __HAL_TIM_CLEAR_FLAG(__HANDLE__, __FLAG__) ((__HANDLE__)->Instance->SR &= ~(__FLAG__))

/**
 * @brief  Check whether a TIM interrupt source is enabled.
 * @param  __INTERRUPT__: TIM_IT_xxx (DIER bit mask).
 */
#define __HAL_TIM_GET_IT_SOURCE(__HANDLE__, __INTERRUPT__) (((__HANDLE__)->Instance->DIER & (__INTERRUPT__)) != 0U)

/**
 * @brief  Enable a TIM interrupt source.
 */
#define __HAL_TIM_ENABLE_IT(__HANDLE__, __INTERRUPT__) ((__HANDLE__)->Instance->DIER |= (__INTERRUPT__))

/**
 * @brief  Disable a TIM interrupt source.
 */
#define __HAL_TIM_DISABLE_IT(__HANDLE__, __INTERRUPT__) ((__HANDLE__)->Instance->DIER &= ~(__INTERRUPT__))

/**
 * @brief  Check whether a TIM interrupt flag is set.
 */
#define __HAL_TIM_GET_IT(__HANDLE__, __INTERRUPT__) (((__HANDLE__)->Instance->SR & (__INTERRUPT__)) != 0U)

/**
 * @brief  Clear a TIM interrupt flag.
 */
#define __HAL_TIM_CLEAR_IT(__HANDLE__, __INTERRUPT__) ((__HANDLE__)->Instance->SR &= ~(__INTERRUPT__))

/**
 * @brief  Enable the main outputs (MOE bit of the BDTR register).
 * @note   For the advanced timers only.
 */
#define __HAL_TIM_MOE_ENABLE(__HANDLE__) ((__HANDLE__)->Instance->BDTR |= (TIM_BDTR_MOE))

/**
 * @brief  Disable the main outputs.
 * @note   The MOE bit is only cleared when every CCxE / CCxNE bit of the
 *         CCER register is already cleared (conditional disable).
 */
#define __HAL_TIM_MOE_DISABLE(__HANDLE__) \
    do { \
        if (((__HANDLE__)->Instance->CCER & (TIM_CCER_CC1E | TIM_CCER_CC2E | TIM_CCER_CC3E | TIM_CCER_CC4E | \
                                              TIM_CCER_CC1NE | TIM_CCER_CC2NE | TIM_CCER_CC3NE)) == 0U) \
        { \
            (__HANDLE__)->Instance->BDTR &= ~(TIM_BDTR_MOE); \
        } \
    } while (0U)

/**
 * @brief  Disable the main outputs unconditionally.
 * @note   The MOE bit is cleared whatever the CCxE / CCxNE bits of the
 *         CCER register hold. HAL_TIM_CtrlPWMOutputs() uses this variant
 *         for its TIM_DISABLE path, because the purpose of that call is to
 *         switch the main outputs off at once (emergency stop, break
 *         handling), while the conditional __HAL_TIM_MOE_DISABLE() above is
 *         the one the Stop functions use after clearing their own channel.
 */
#define __HAL_TIM_MOE_DISABLE_UNCONDITIONALLY(__HANDLE__) \
    ((__HANDLE__)->Instance->BDTR &= ~(TIM_BDTR_MOE))

/**
 * @brief  Set the counter value.
 */
#define __HAL_TIM_SET_COUNTER(__HANDLE__, __COUNTER__) ((__HANDLE__)->Instance->CNT = (__COUNTER__))

/**
 * @brief  Get the current counter value.
 */
#define __HAL_TIM_GET_COUNTER(__HANDLE__) ((__HANDLE__)->Instance->CNT)

/**
 * @brief  Set the auto-reload value and update the handle period.
 */
#define __HAL_TIM_SET_AUTORELOAD(__HANDLE__, __AUTORELOAD__) \
    do { \
        (__HANDLE__)->Instance->ARR = (__AUTORELOAD__); \
        (__HANDLE__)->Init.Period = (__AUTORELOAD__); \
    } while (0U)

/**
 * @brief  Get the current auto-reload value.
 */
#define __HAL_TIM_GET_AUTORELOAD(__HANDLE__) ((__HANDLE__)->Instance->ARR)

/**
 * @brief  Set the compare value of a channel.
 */
#define __HAL_TIM_SET_COMPARE(__HANDLE__, __CHANNEL__, __COMPARE__) \
    (((__CHANNEL__) == TIM_CHANNEL_1) ? ((__HANDLE__)->Instance->CCR1 = (__COMPARE__)) : \
     ((__CHANNEL__) == TIM_CHANNEL_2) ? ((__HANDLE__)->Instance->CCR2 = (__COMPARE__)) : \
     ((__CHANNEL__) == TIM_CHANNEL_3) ? ((__HANDLE__)->Instance->CCR3 = (__COMPARE__)) : \
     ((__CHANNEL__) == TIM_CHANNEL_4) ? ((__HANDLE__)->Instance->CCR4 = (__COMPARE__)) : \
     ((__CHANNEL__) == TIM_CHANNEL_5) ? ((__HANDLE__)->Instance->CCR5 = (__COMPARE__)) : \
                                        ((__HANDLE__)->Instance->CCR6 = (__COMPARE__)))

/**
 * @brief  Get the compare value of a channel.
 */
#define __HAL_TIM_GET_COMPARE(__HANDLE__, __CHANNEL__) \
    (((__CHANNEL__) == TIM_CHANNEL_1) ? ((__HANDLE__)->Instance->CCR1) : \
     ((__CHANNEL__) == TIM_CHANNEL_2) ? ((__HANDLE__)->Instance->CCR2) : \
     ((__CHANNEL__) == TIM_CHANNEL_3) ? ((__HANDLE__)->Instance->CCR3) : \
     ((__CHANNEL__) == TIM_CHANNEL_4) ? ((__HANDLE__)->Instance->CCR4) : \
     ((__CHANNEL__) == TIM_CHANNEL_5) ? ((__HANDLE__)->Instance->CCR5) : \
                                        ((__HANDLE__)->Instance->CCR6))

/**
 * @brief  Enable the DMA request of the given source (set the DIER *DE bit).
 * @param  __HANDLE__: TIM handle.
 * @param  __DMA_SOURCE__: TIM_DMA_Update / TIM_DMA_CC1..CC6.
 */
#define __HAL_TIM_ENABLE_DMA(__HANDLE__, __DMA_SOURCE__) \
    ((__HANDLE__)->Instance->DIER |= (__DMA_SOURCE__))

/**
 * @brief  Disable the DMA request of the given source (clear the DIER *DE bit).
 * @param  __HANDLE__: TIM handle.
 * @param  __DMA_SOURCE__: TIM_DMA_Update / TIM_DMA_CC1..CC6.
 */
#define __HAL_TIM_DISABLE_DMA(__HANDLE__, __DMA_SOURCE__) \
    ((__HANDLE__)->Instance->DIER &= ~(__DMA_SOURCE__))

/**
 * @brief  Set the DMA burst length (DCR.DBL field).
 * @param  __HANDLE__: TIM handle.
 * @param  __DMA_BURST_LENGTH__: TIM_DMABurstLength_xxx.
 */
#define __HAL_TIM_SET_DMABURSTLENGTH(__HANDLE__, __DMA_BURST_LENGTH__) \
    ((__HANDLE__)->Instance->DCR = ((__HANDLE__)->Instance->DCR & ~TIM_DCR_DBL) | (__DMA_BURST_LENGTH__))

/**
 * @brief  Set the DMA burst base address (DCR.DBA field).
 * @param  __HANDLE__: TIM handle.
 * @param  __DMA_BASE__: TIM_DMABase_xxx.
 */
#define __HAL_TIM_SET_DMABURSTBASE(__HANDLE__, __DMA_BASE__) \
    ((__HANDLE__)->Instance->DCR = ((__HANDLE__)->Instance->DCR & ~TIM_DCR_DBA) | (__DMA_BASE__))

/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/

/** @addtogroup TIM_Exported_Functions
  * @{
  */

/** @addtogroup TIM_Exported_Functions_Group1 Time Base functions
  * @{
  */
/**
 * @brief  Initializes the TIM time base unit. (NON-BLOCKING)
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_Base_Init(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  De-initializes the TIM base unit. (NON-BLOCKING)
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_Base_DeInit(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  Initializes the TIM base MSP. Weak empty function.
 */
void HAL_TIM_Base_MspInit(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  De-initializes the TIM base MSP. Weak empty function.
 */
void HAL_TIM_Base_MspDeInit(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  Starts the TIM base generation in polling mode. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_Base_Start(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  Stops the TIM base generation in polling mode. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_Base_Stop(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  Starts the TIM base generation in interrupt mode. (NON-BLOCKING / IT)
 */
HAL_StatusTypeDef HAL_TIM_Base_Start_IT(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  Stops the TIM base generation in interrupt mode. (NON-BLOCKING / IT)
 */
HAL_StatusTypeDef HAL_TIM_Base_Stop_IT(HAL_TIM_HandleTypeDef *htim);
/**
  * @}
  */

/** @addtogroup TIM_Exported_Functions_Group2 Output Compare functions
  * @{
  */
/**
 * @brief  Initializes the TIM output compare unit. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_OC_Init(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  De-initializes the TIM output compare unit. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_OC_DeInit(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  Initializes the TIM OC MSP. Weak empty function.
 */
void HAL_TIM_OC_MspInit(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  De-initializes the TIM OC MSP. Weak empty function.
 */
void HAL_TIM_OC_MspDeInit(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  Starts the PWM signal generation on the given channel. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_OC_Start(HAL_TIM_HandleTypeDef *htim, uint32 Channel);
/**
 * @brief  Stops the output compare signal generation. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_OC_Stop(HAL_TIM_HandleTypeDef *htim, uint32 Channel);
/**
 * @brief  Starts the output compare signal generation in interrupt mode. (NON-BLOCKING / IT)
 */
HAL_StatusTypeDef HAL_TIM_OC_Start_IT(HAL_TIM_HandleTypeDef *htim, uint32 Channel);
/**
 * @brief  Stops the output compare signal generation in interrupt mode. (NON-BLOCKING / IT)
 */
HAL_StatusTypeDef HAL_TIM_OC_Stop_IT(HAL_TIM_HandleTypeDef *htim, uint32 Channel);
/**
 * @brief  Starts the output compare signal generation with DMA. (NON-BLOCKING / DMA)
 * @note   The DMA channel referenced by
 *         htim->hdma[TIM_DMA_ID_CCx] must previously be initialized
 *         (HAL_DMA_Init) with the DMA_MEMORY_TO_PERIPH direction and mapped
 *         to the timer peripheral interface (HAL_DMA_ConfigPeriphIF), and
 *         the channel data width must match the single-word DMAR burst. The
 *         completion is reported by HAL_TIM_OC_DelayElapsedCallback().
 * @note   CR2.CCDS must be set (HAL_TIM_SelectCCDMA(htim, TIM_ENABLE))
 *         before the transfer is started: without it the channel event
 *         never reaches the DMA controller on this device and the transfer
 *         stays idle even though every timer register looks correct.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  Channel: the output compare channel (TIM_CHANNEL_1..6).
 * @param  pData: pointer to the buffer that holds the compare values.
 * @param  Length: number of compare values to transfer.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_OC_Start_DMA(HAL_TIM_HandleTypeDef *htim, uint32 Channel, uint32 *pData,
                                       uint16 Length);
/**
 * @brief  Stops the output compare signal generation with DMA. (NON-BLOCKING / DMA)
 * @note   The DMA channel is aborted and the
 *         capture/compare DMA request is disabled.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  Channel: the output compare channel (TIM_CHANNEL_1..6).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_OC_Stop_DMA(HAL_TIM_HandleTypeDef *htim, uint32 Channel);
/**
  * @}
  */

/** @addtogroup TIM_Exported_Functions_Group3 PWM functions
  * @{
  */
/**
 * @brief  Initializes the TIM PWM unit. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_PWM_Init(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  De-initializes the TIM PWM unit. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_PWM_DeInit(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  Initializes the TIM PWM MSP. Weak empty function.
 */
void HAL_TIM_PWM_MspInit(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  De-initializes the TIM PWM MSP. Weak empty function.
 */
void HAL_TIM_PWM_MspDeInit(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  Starts the PWM signal generation on the given channel. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_PWM_Start(HAL_TIM_HandleTypeDef *htim, uint32 Channel);
/**
 * @brief  Stops the PWM signal generation on the given channel. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_PWM_Stop(HAL_TIM_HandleTypeDef *htim, uint32 Channel);
/**
 * @brief  Starts the PWM signal generation in interrupt mode. (NON-BLOCKING / IT)
 */
HAL_StatusTypeDef HAL_TIM_PWM_Start_IT(HAL_TIM_HandleTypeDef *htim, uint32 Channel);
/**
 * @brief  Stops the PWM signal generation in interrupt mode. (NON-BLOCKING / IT)
 */
HAL_StatusTypeDef HAL_TIM_PWM_Stop_IT(HAL_TIM_HandleTypeDef *htim, uint32 Channel);
/**
 * @brief  Starts the PWM signal generation with DMA. (NON-BLOCKING / DMA)
 * @note   The DMA channel referenced by
 *         htim->hdma[TIM_DMA_ID_CCx] must previously be initialized
 *         (HAL_DMA_Init) with the DMA_MEMORY_TO_PERIPH direction and mapped
 *         to the timer peripheral interface (HAL_DMA_ConfigPeriphIF), and
 *         the channel data width must match the single-word DMAR burst. The
 *         completion is reported by HAL_TIM_PWM_PulseFinishedCallback().
 * @note   CR2.CCDS must be set (HAL_TIM_SelectCCDMA(htim, TIM_ENABLE))
 *         before the transfer is started: without it the channel event
 *         never reaches the DMA controller on this device and the transfer
 *         stays idle even though every timer register looks correct.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  Channel: the PWM channel (TIM_CHANNEL_1..6).
 * @param  pData: pointer to the buffer that holds the duty cycle values.
 * @param  Length: number of duty cycle values to transfer.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_PWM_Start_DMA(HAL_TIM_HandleTypeDef *htim, uint32 Channel, uint32 *pData,
                                        uint16 Length);
/**
 * @brief  Stops the PWM signal generation with DMA. (NON-BLOCKING / DMA)
 * @note   The DMA channel is aborted and the
 *         capture/compare DMA request is disabled.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  Channel: the PWM channel (TIM_CHANNEL_1..6).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_PWM_Stop_DMA(HAL_TIM_HandleTypeDef *htim, uint32 Channel);
/**
  * @}
  */

/** @addtogroup TIM_Exported_Functions_Group4 Input Capture functions
  * @{
  */
/**
 * @brief  Initializes the TIM input capture unit. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_IC_Init(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  De-initializes the TIM input capture unit. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_IC_DeInit(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  Initializes the TIM IC MSP. Weak empty function.
 */
void HAL_TIM_IC_MspInit(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  De-initializes the TIM IC MSP. Weak empty function.
 */
void HAL_TIM_IC_MspDeInit(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  Starts the input capture measurement. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_IC_Start(HAL_TIM_HandleTypeDef *htim, uint32 Channel);
/**
 * @brief  Stops the input capture measurement. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_IC_Stop(HAL_TIM_HandleTypeDef *htim, uint32 Channel);
/**
 * @brief  Starts the input capture measurement in interrupt mode. (NON-BLOCKING / IT)
 */
HAL_StatusTypeDef HAL_TIM_IC_Start_IT(HAL_TIM_HandleTypeDef *htim, uint32 Channel);
/**
 * @brief  Stops the input capture measurement in interrupt mode. (NON-BLOCKING / IT)
 */
HAL_StatusTypeDef HAL_TIM_IC_Stop_IT(HAL_TIM_HandleTypeDef *htim, uint32 Channel);
/**
  * @}
  */

/** @addtogroup TIM_Exported_Functions_Group5 One Pulse functions
  * @{
  */
/**
 * @brief  Initializes the TIM one pulse mode. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_OnePulse_Init(HAL_TIM_HandleTypeDef *htim, uint32 OnePulseMode);
/**
 * @brief  De-initializes the TIM one pulse mode. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_OnePulse_DeInit(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  Initializes the TIM one pulse MSP. Weak empty function.
 */
void HAL_TIM_OnePulse_MspInit(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  De-initializes the TIM one pulse MSP. Weak empty function.
 */
void HAL_TIM_OnePulse_MspDeInit(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  Starts the one pulse generation. (NON-BLOCKING)
 * @note   The output channel and its input counterpart are both enabled.
 */
HAL_StatusTypeDef HAL_TIM_OnePulse_Start(HAL_TIM_HandleTypeDef *htim, uint32 OutputChannel);
/**
 * @brief  Stops the one pulse generation. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_OnePulse_Stop(HAL_TIM_HandleTypeDef *htim, uint32 OutputChannel);
/**
 * @brief  Starts the one pulse generation in interrupt mode. (NON-BLOCKING / IT)
 */
HAL_StatusTypeDef HAL_TIM_OnePulse_Start_IT(HAL_TIM_HandleTypeDef *htim, uint32 OutputChannel);
/**
 * @brief  Stops the one pulse generation in interrupt mode. (NON-BLOCKING / IT)
 */
HAL_StatusTypeDef HAL_TIM_OnePulse_Stop_IT(HAL_TIM_HandleTypeDef *htim, uint32 OutputChannel);
/**
  * @}
  */

/** @addtogroup TIM_Exported_Functions_Group6 Encoder functions
  * @{
  */
/**
 * @brief  Initializes the TIM encoder interface. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_Encoder_Init(HAL_TIM_HandleTypeDef *htim,
                                       TIM_Encoder_InitTypeDef *sConfig);
/**
 * @brief  De-initializes the TIM encoder interface. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_Encoder_DeInit(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  Initializes the TIM encoder MSP. Weak empty function.
 */
void HAL_TIM_Encoder_MspInit(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  De-initializes the TIM encoder MSP. Weak empty function.
 */
void HAL_TIM_Encoder_MspDeInit(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  Starts the encoder interface. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_Encoder_Start(HAL_TIM_HandleTypeDef *htim, uint32 Channel);
/**
 * @brief  Stops the encoder interface. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_Encoder_Stop(HAL_TIM_HandleTypeDef *htim, uint32 Channel);
/**
 * @brief  Starts the encoder interface in interrupt mode. (NON-BLOCKING / IT)
 */
HAL_StatusTypeDef HAL_TIM_Encoder_Start_IT(HAL_TIM_HandleTypeDef *htim, uint32 Channel);
/**
 * @brief  Stops the encoder interface in interrupt mode. (NON-BLOCKING / IT)
 */
HAL_StatusTypeDef HAL_TIM_Encoder_Stop_IT(HAL_TIM_HandleTypeDef *htim, uint32 Channel);
/**
  * @}
  */

/** @addtogroup TIM_Exported_Functions_Group7 IRQ Handler
  * @{
  */
/**
 * @brief  Handle the TIM interrupts (update, CC1..CC6, trigger, break).
 * @note   The CCx handler checks the CCMR CCxS field to dispatch between
 *         the input capture and the output compare callbacks.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @retval None
 */
void HAL_TIM_IRQHandler(HAL_TIM_HandleTypeDef *htim);
/**
  * @}
  */

/** @addtogroup TIM_Exported_Functions_Group8 Peripheral Control functions
  * @{
  */
/**
 * @brief  Configures the OC channel in output compare mode. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_OC_ConfigChannel(HAL_TIM_HandleTypeDef *htim, TIM_OC_InitTypeDef *sConfig,
                                           uint32 Channel);
/**
 * @brief  Configures the OC channel in PWM mode. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_PWM_ConfigChannel(HAL_TIM_HandleTypeDef *htim,
                                            TIM_OC_InitTypeDef *sConfig,

                                            uint32 Channel);
/**
 * @brief  Configures the IC channel. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_IC_ConfigChannel(HAL_TIM_HandleTypeDef *htim, TIM_IC_InitTypeDef *sConfig,
                                           uint32 Channel);
/**
 * @brief  Configures the one pulse channel. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_OnePulse_ConfigChannel(HAL_TIM_HandleTypeDef *htim,
                                                 TIM_OnePulse_InitTypeDef *sConfig, uint32 OutputChannel,

                                                 uint32 InputChannel);
/**
 * @brief  Configures the TI1 input (TI1S bit of CR2). (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_ConfigTI1Input(HAL_TIM_HandleTypeDef *htim, uint32 TI1_Selection);
/**
 * @brief  Selects the capture/compare DMA source (CCDS bit of CR2).
 *         (NON-BLOCKING)
 * @note   The capture/compare DMA request of a channel is only issued while
 *         CR2.CCDS is set; with the bit cleared the timer keeps setting
 *         DIER.*DE and the channel event, but the DMA controller never sees
 *         a request and the transfer does not start. Call this function
 *         (TIM_ENABLE) before HAL_TIM_OC_Start_DMA() /
 *         HAL_TIM_PWM_Start_DMA(); the driver does not set the bit on its
 *         own so that a request driven by the update event (CR2.CCDS
 *         cleared, DIER.UDE) stays possible.
 * @note   Only CR2.CCDS is modified; the other CR2 fields are preserved.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  NewState: TIM_ENABLE or TIM_DISABLE.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_SelectCCDMA(HAL_TIM_HandleTypeDef *htim, uint32 NewState);
/**
 * @brief  Configures the clock source of the timer (SMCR clock selection). (NON-BLOCKING)
 * @note   The internal / ITRx / TIx / TI1ED clock sources select the slave
 *         mode controller (SMS) and the trigger (TS) field; the external
 *         trigger modes additionally configure the ETR input stage
 *         (ETF / ETPS / ETP / ECE).
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  sClockConfig: pointer to the TIM_ClockConfigTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_ConfigClockSource(HAL_TIM_HandleTypeDef *htim,
                                            TIM_ClockConfigTypeDef *sClockConfig);
/**
 * @brief  Configures the OCREF clear input of an output channel. (NON-BLOCKING)
 * @note   The selected clear source is directly programmed into the channel
 *         OCxCE bit of the CCMR register (no OCCS source selection bit is
 *         available on this device).
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  sClearInputConfig: pointer to the TIM_ClearInputConfigTypeDef
 *         structure.
 * @param  Channel: the output channel (TIM_CHANNEL_1..4).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_ConfigOCrefClear(HAL_TIM_HandleTypeDef *htim,
                                           TIM_ClearInputConfigTypeDef *sClearInputConfig,

                                           uint32 Channel);
/**
 * @brief  Configures the slave mode synchronization. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_SlaveConfigSynchronization(HAL_TIM_HandleTypeDef *htim,
                                                     TIM_SlaveConfigTypeDef *sSlaveConfig);
/**
 * @brief  Generates the selected events by software. (NON-BLOCKING)
 */
HAL_StatusTypeDef HAL_TIM_GenerateEvent(HAL_TIM_HandleTypeDef *htim, uint32 EventSource);
/**
 * @brief  Returns the captured value of a channel. (NON-BLOCKING)
 */
uint32 HAL_TIM_ReadCapturedValue(HAL_TIM_HandleTypeDef *htim, uint32 Channel);
/**
 * @brief  Sets the compare value of a channel. (NON-BLOCKING)
 */
void HAL_TIM_SetCompare(HAL_TIM_HandleTypeDef *htim, uint32 Compare, uint32 Channel);
/**
 * @brief  Sets the second master output trigger (TRGO2, CR2.MMS2) alone.
 *        (NON-BLOCKING)
 * @note   Same contract as HAL_TIM_MasterConfigSynchronization(): the handle
 *         and the instance are checked, the source is validated at run time,
 *         the handle state must not be RESET and the register access is
 *         serialized by the handle lock. Only the MMS2 field is modified, so
 *         the TRGO selection (CR2.MMS) and every other CR2 bit are preserved
 *         (a device that needs the two master outputs is configured with one
 *         call of HAL_TIM_MasterConfigSynchronization()).
 * @note   TRGO2 exists on the advanced timers only (TIM0 / TIM1 / TIM2 /
 *         TIM5): a real source on a general purpose timer (TIM3 / TIM4 /
 *         TIM6 / TIM7) is refused with HAL_ERROR and
 *         HAL_TIM_ERROR_INVALID_PARAM, without touching the register.
 *         TIM_TRGO2_RESET is accepted on any instance (it disables TRGO2 and
 *         is the neutral value).
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  MasterOutputTrigger2: the TRGO2 source (TIM_TRGO2_xxx).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef HAL_TIM_SetMasterOutputTrigger2(HAL_TIM_HandleTypeDef *htim,
                                                  uint32 MasterOutputTrigger2);
/**
 * @brief  Sets the auto-reload value and updates the handle period. (NON-BLOCKING)
 */
void HAL_TIM_SetAutoreload(HAL_TIM_HandleTypeDef *htim, uint32 Autoreload);
/**
 * @brief  Sets the prescaler value. (NON-BLOCKING)
 */
void HAL_TIM_SetPrescaler(HAL_TIM_HandleTypeDef *htim, uint32 Prescaler);
/**
 * @brief  Returns the current counter value. (NON-BLOCKING)
 */
uint32 HAL_TIM_GetCounter(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  Returns the current prescaler value. (NON-BLOCKING)
 */
uint32 HAL_TIM_GetPrescaler(HAL_TIM_HandleTypeDef *htim);
/**
  * @}
  */

/** @addtogroup TIM_Exported_Functions_Group9 Callbacks (weak)
  * @{
  */
/**
 * @brief  Period elapsed callback (weak empty function).
 */
void HAL_TIM_PeriodElapsedCallback(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  Output compare delay elapsed callback (weak empty function).
 */
void HAL_TIM_OC_DelayElapsedCallback(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  Input capture callback (weak empty function).
 */
void HAL_TIM_IC_CaptureCallback(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  PWM pulse finished callback (weak empty function).
 */
void HAL_TIM_PWM_PulseFinishedCallback(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  Trigger callback (weak empty function).
 */
void HAL_TIM_TriggerCallback(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  Error callback (weak empty function).
 */
void HAL_TIM_ErrorCallback(HAL_TIM_HandleTypeDef *htim);
/**
  * @}
  */

/** @addtogroup TIM_Exported_Functions_Group10 State functions
  * @{
  */
/**
 * @brief  Returns the TIM base handle state. (NON-BLOCKING)
 */
HAL_TIM_StateTypeDef HAL_TIM_Base_GetState(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  Returns the TIM OC handle state. (NON-BLOCKING)
 */
HAL_TIM_StateTypeDef HAL_TIM_OC_GetState(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  Returns the TIM PWM handle state. (NON-BLOCKING)
 */
HAL_TIM_StateTypeDef HAL_TIM_PWM_GetState(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  Returns the TIM IC handle state. (NON-BLOCKING)
 */
HAL_TIM_StateTypeDef HAL_TIM_IC_GetState(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  Returns the TIM OnePulse handle state. (NON-BLOCKING)
 */
HAL_TIM_StateTypeDef HAL_TIM_OnePulse_GetState(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  Returns the TIM Encoder handle state. (NON-BLOCKING)
 */
HAL_TIM_StateTypeDef HAL_TIM_Encoder_GetState(HAL_TIM_HandleTypeDef *htim);
/**
 * @brief  Returns the TIM error code. (NON-BLOCKING)
 */
uint32 HAL_TIM_GetError(HAL_TIM_HandleTypeDef *htim);
/**
  * @}
  */

/** @addtogroup TIM_Exported_Functions_Group11 Configuration structure defaults
  * @{
  */

/**
 * @brief  Fills the time base configuration structure with the reset defaults.
 *         (NON-BLOCKING)
 * @param  InitStruct: pointer to a TIM_Base_InitTypeDef structure.
 * @note   The base structure is the only one carrying the Size / Version meta
 *         fields, and the initialization functions require them to match the
 *         running library, so this helper also writes Size and Version (and
 *         clears the reserved words). The other helpers fill their business
 *         fields only.
 */
void HAL_TIM_Base_StructInit(TIM_Base_InitTypeDef *InitStruct);

/**
 * @brief  Fills the output compare configuration structure with the reset
 *         defaults. (NON-BLOCKING)
 * @param  InitStruct: pointer to a TIM_OC_InitTypeDef structure.
 */
void HAL_TIM_OC_StructInit(TIM_OC_InitTypeDef *InitStruct);

/**
 * @brief  Fills the input capture configuration structure with the reset
 *         defaults. (NON-BLOCKING)
 * @param  InitStruct: pointer to a TIM_IC_InitTypeDef structure.
 */
void HAL_TIM_IC_StructInit(TIM_IC_InitTypeDef *InitStruct);

/**
 * @brief  Fills the one pulse configuration structure with the reset defaults.
 *         (NON-BLOCKING)
 * @param  InitStruct: pointer to a TIM_OnePulse_InitTypeDef structure.
 */
void HAL_TIM_OnePulse_StructInit(TIM_OnePulse_InitTypeDef *InitStruct);

/**
 * @brief  Fills the encoder configuration structure with the reset defaults.
 *         (NON-BLOCKING)
 * @param  InitStruct: pointer to a TIM_Encoder_InitTypeDef structure.
 */
void HAL_TIM_Encoder_StructInit(TIM_Encoder_InitTypeDef *InitStruct);

/**
 * @brief  Fills the clock source configuration structure with the reset
 *         defaults. (NON-BLOCKING)
 * @param  InitStruct: pointer to a TIM_ClockConfigTypeDef structure.
 */
void HAL_TIM_ClockConfig_StructInit(TIM_ClockConfigTypeDef *InitStruct);

/**
 * @brief  Fills the OCREF clear input configuration structure with the reset
 *         defaults. (NON-BLOCKING)
 * @param  InitStruct: pointer to a TIM_ClearInputConfigTypeDef structure.
 */
void HAL_TIM_ClearInputConfig_StructInit(TIM_ClearInputConfigTypeDef *InitStruct);

/**
 * @brief  Fills the slave mode configuration structure with the reset
 *         defaults. (NON-BLOCKING)
 * @param  InitStruct: pointer to a TIM_SlaveConfigTypeDef structure.
 */
void HAL_TIM_SlaveConfig_StructInit(TIM_SlaveConfigTypeDef *InitStruct);

/**
 * @brief  Fills the master mode configuration structure with the reset
 *         defaults. (NON-BLOCKING)
 * @param  InitStruct: pointer to a TIM_MasterConfigTypeDef structure.
 */
void HAL_TIM_MasterConfig_StructInit(TIM_MasterConfigTypeDef *InitStruct);

/**
 * @brief  Fills the break and dead-time configuration structure with the reset
 *         defaults. (NON-BLOCKING)
 * @param  InitStruct: pointer to a TIM_BreakDeadTimeConfigTypeDef structure.
 * @note   The lock level keeps the neutral value: this device does not
 *         implement the BDTR.LOCK field.
 */
void HAL_TIM_BreakDeadTimeConfig_StructInit(TIM_BreakDeadTimeConfigTypeDef *InitStruct);
/**
  * @}
  */

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @addtogroup TIM_Exported_Constants TIM Exported Constants
  * @{
  */

/** @defgroup TIM_Dead_Time TIM Dead Time (advanced)
  * @{
  */
#define IS_TIM_DEADTIME(DEADTIME) ((DEADTIME) <= 0xFFU)
/**
  * @}
  */

/** @defgroup TIM_Break_Filter TIM Break Filter (advanced)
  * @{
  */
#define IS_TIM_BREAK_FILTER(FILTER) ((FILTER) <= 0xFU)
/**
  * @}
  */

/** @defgroup TIM_Break_Deadtime_Pos TIM Break / Dead-time Position Shifts
  * @note  The value is the BDTR register bit position of the break filter
  *        field (BKF = bits 19:16). The dead-time generator field DTG is bits
  *        7:0 and needs no shift; the OSSI / OSSR / BKE / BKP / AOE bits are
  *        already masks in their own constant families.
  * @{
  */
#define TIM_BREAK_FILTER_Pos         ((uint32)16U) /*!< Break filter (BKF) position   */

/**
  * @}
  */

/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/

/** @addtogroup TIM_Exported_Functions
  * @{
  */

/** @addtogroup TIM_Exported_Functions_Group12 Complementary Output Compare / PWM functions
  * @{
  */

/**
 * @brief  Starts the complementary output compare signal generation. (NON-BLOCKING)
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  Channel: the complementary output channel (TIM_CHANNEL_1..6).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_OCN_Start(HAL_TIM_HandleTypeDef *htim, uint32 Channel);

/**
 * @brief  Stops the complementary output compare signal generation. (NON-BLOCKING)
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  Channel: the complementary output channel (TIM_CHANNEL_1..6).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_OCN_Stop(HAL_TIM_HandleTypeDef *htim, uint32 Channel);

/**
 * @brief  Starts the complementary output compare signal generation in (NON-BLOCKING / IT)
 *         interrupt mode.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  Channel: the complementary output channel (TIM_CHANNEL_1..6).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_OCN_Start_IT(HAL_TIM_HandleTypeDef *htim, uint32 Channel);

/**
 * @brief  Stops the complementary output compare signal generation in (NON-BLOCKING / IT)
 *         interrupt mode.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  Channel: the complementary output channel (TIM_CHANNEL_1..6).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_OCN_Stop_IT(HAL_TIM_HandleTypeDef *htim, uint32 Channel);

/**
 * @brief  Starts the complementary PWM signal generation. (NON-BLOCKING)
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  Channel: the complementary PWM channel (TIM_CHANNEL_1..6).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_PWMN_Start(HAL_TIM_HandleTypeDef *htim, uint32 Channel);

/**
 * @brief  Stops the complementary PWM signal generation. (NON-BLOCKING)
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  Channel: the complementary PWM channel (TIM_CHANNEL_1..6).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_PWMN_Stop(HAL_TIM_HandleTypeDef *htim, uint32 Channel);

/**
 * @brief  Starts the complementary PWM signal generation in interrupt mode. (NON-BLOCKING / IT)
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  Channel: the complementary PWM channel (TIM_CHANNEL_1..6).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_PWMN_Start_IT(HAL_TIM_HandleTypeDef *htim, uint32 Channel);

/**
 * @brief  Stops the complementary PWM signal generation in interrupt mode. (NON-BLOCKING / IT)
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  Channel: the complementary PWM channel (TIM_CHANNEL_1..6).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_PWMN_Stop_IT(HAL_TIM_HandleTypeDef *htim, uint32 Channel);

/**
  * @}
  */

/** @addtogroup TIM_Exported_Functions_Group13 Extended Control functions
  * @{
  */

/**
 * @brief  Configures the break and dead-time features of the advanced timer. (NON-BLOCKING)
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  sBreakDeadTimeConfig: pointer to the
 *         TIM_BreakDeadTimeConfigTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_ConfigBreakDeadTime(HAL_TIM_HandleTypeDef *htim,
                                                TIM_BreakDeadTimeConfigTypeDef *sBreakDeadTimeConfig);

/**
 * @brief  Configures the master output triggers (TRGO and TRGO2) and the (NON-BLOCKING)
 *         master-slave mode of the timer.
 * @note   Both master outputs are programmed in one locked access: CR2.MMS
 *         receives MasterOutputTrigger (TIM_TRGO_xxx, any instance) and
 *         CR2.MMS2 receives MasterOutputTrigger2 (TIM_TRGO2_xxx, advanced
 *         timers only). The master-slave mode field has no effect on this
 *         device (SMCR has no MSM bit), only the neutral value is accepted.
 * @note   On a general purpose timer (TIM3 / TIM4 / TIM6 / TIM7) the second
 *         master output does not exist: the field must keep TIM_TRGO2_RESET
 *         (the value written by HAL_TIM_MasterConfig_StructInit()), otherwise
 *         the call is refused with HAL_ERROR and
 *         HAL_TIM_ERROR_INVALID_PARAM and no register is written. Use
 *         HAL_TIM_SetMasterOutputTrigger2() to change TRGO2 alone.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  sMasterConfig: pointer to the TIM_MasterConfigTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_TIM_MasterConfigSynchronization(HAL_TIM_HandleTypeDef *htim,
                                                        TIM_MasterConfigTypeDef *sMasterConfig);

/**
 * @brief  Enables or disables the main outputs (MOE bit). (NON-BLOCKING)
 * @note   Provided for the applications that manage the main outputs
 *         independently; the complementary start functions call it anyway.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  NewState: TIM_ENABLE or TIM_DISABLE.
 * @note   TIM_DISABLE clears BDTR.MOE unconditionally, so the main outputs
 *         stop even while the channel outputs are still enabled. With
 *         BDTR.AOE set the hardware arms MOE again at the next update
 *         event, so a permanent stop needs AOE cleared too.
 * @retval None
 */
void HAL_TIM_CtrlPWMOutputs(HAL_TIM_HandleTypeDef *htim, uint32 NewState);

/**
  * @}
  */

/** @addtogroup TIM_Exported_Functions_Group14 Extended Callbacks (weak)
  * @{
  */

/**
 * @brief  Break interrupt callback (weak empty function).
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @retval None
 */
void HAL_TIM_BreakCallback(HAL_TIM_HandleTypeDef *htim);

/**
  * @}
  */

/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/

/** @defgroup TIM_Private_Macros TIM Private Macros
  * @{
  */

/**
 * @brief  Check that the TIM peripheral instance is valid (TIM0..TIM7).
 */
#define IS_TIM_ALL_INSTANCE(INSTANCE) (((INSTANCE) == TIM0) || \
                                       ((INSTANCE) == TIM1) || \
                                       ((INSTANCE) == TIM2) || \
                                       ((INSTANCE) == TIM3) || \
                                       ((INSTANCE) == TIM4) || \
                                       ((INSTANCE) == TIM5) || \
                                       ((INSTANCE) == TIM6) || \
                                       ((INSTANCE) == TIM7))

/**
 * @brief  Check that the TIM instance is an advanced timer (TIM0/1/2/5).
 */
#define IS_TIM_ADV_INSTANCE(INSTANCE) (((INSTANCE) == TIM0) || \
                                       ((INSTANCE) == TIM1) || \
                                       ((INSTANCE) == TIM2) || \
                                       ((INSTANCE) == TIM5))

/**
 * @brief  Check that the TIM instance is a general-purpose timer
 *         (TIM3/4/6/7).
 */
#define IS_TIM_GEN_INSTANCE(INSTANCE) (((INSTANCE) == TIM3) || \
                                       ((INSTANCE) == TIM4) || \
                                       ((INSTANCE) == TIM6) || \
                                       ((INSTANCE) == TIM7))

/**
 * @brief  Check that the channel is valid (1..6, 5/6 advanced only).
 */
#define IS_TIM_CHANNEL(CHANNEL) (((CHANNEL) == TIM_CHANNEL_1) || \
                                 ((CHANNEL) == TIM_CHANNEL_2) || \
                                 ((CHANNEL) == TIM_CHANNEL_3) || \
                                 ((CHANNEL) == TIM_CHANNEL_4) || \
                                 ((CHANNEL) == TIM_CHANNEL_5) || \
                                 ((CHANNEL) == TIM_CHANNEL_6))

/**
 * @brief  Check that the channel is valid for the given instance (general
 *         timers support channels 1..4 only).
 */
#define IS_TIM_CHANNELS(INSTANCE, CHANNEL) \
    ((IS_TIM_GEN_INSTANCE(INSTANCE)) ? (((CHANNEL) == TIM_CHANNEL_1) || \
                                        ((CHANNEL) == TIM_CHANNEL_2) || \
                                        ((CHANNEL) == TIM_CHANNEL_3) || \
                                        ((CHANNEL) == TIM_CHANNEL_4)) : \
                                        IS_TIM_CHANNEL(CHANNEL))

/**
 * @brief  Check that the complementary channel is valid (channels 1..6 on
 *         the advanced timers).
 * @note   Every channel of an advanced timer drives a complementary output
 *         on this device: CCER carries CC1NE..CC6NE at bits 2, 6, 10, 14,
 *         18 and 22, so channels 4, 5 and 6 are accepted as well.
 */
#define IS_TIM_COMPLEMENTARY_CHANNELS(INSTANCE, CHANNEL) \
    ((IS_TIM_ADV_INSTANCE(INSTANCE)) && (((CHANNEL) == TIM_CHANNEL_1) || \
                                         ((CHANNEL) == TIM_CHANNEL_2) || \
                                         ((CHANNEL) == TIM_CHANNEL_3) || \
                                         ((CHANNEL) == TIM_CHANNEL_4) || \
                                         ((CHANNEL) == TIM_CHANNEL_5) || \
                                         ((CHANNEL) == TIM_CHANNEL_6)))

/**
 * @brief  Check that the filter is valid (0..15).
 */
#define IS_TIM_IC_FILTER(FILTER) ((FILTER) <= 0xFU)

/**
 * @brief  Check that the clock polarity is valid.
 */
#define IS_TIM_CLOCK_POLARITY(POL) IS_TIM_TRIGGER_POLARITY(POL)

/**
 * @brief  Check that the clock prescaler is valid.
 */
#define IS_TIM_CLOCK_PRESCALER(PSC) (((PSC) == TIM_CLOCKPRESCALER_DIV1) || \
                                     ((PSC) == TIM_CLOCKPRESCALER_DIV2) || \
                                     ((PSC) == TIM_CLOCKPRESCALER_DIV4) || \
                                     ((PSC) == TIM_CLOCKPRESCALER_DIV8))

/**
 * @brief  Check that the clear input state is valid.
 */
#define IS_TIM_CLEARINPUT_STATE(STATE) (((STATE) == TIM_CLEARINPUT_DISABLE) || \
                                        ((STATE) == TIM_CLEARINPUT_ENABLE))

/**
 * @brief  Check that the clear input polarity is valid.
 */
#define IS_TIM_CLEARINPUT_POLARITY(POL) (((POL) == TIM_CLEARINPUTPOLARITY_NONINVERTED) || \
                                         ((POL) == TIM_CLEARINPUTPOLARITY_INVERTED))

/**
  * @}
  */

/* Shared internal functions --------------------------------------------------*/

/**
 * @brief  Check whether the TIM handle and its instance are valid.
 * @note   Every public entry point of the module performs its handle check
 *         through it, so the NULL pointer and the instance validity are
 *         verified in one place.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
uint32 TIM_HandleIsValid(HAL_TIM_HandleTypeDef *htim);

/**
 * @brief  Check whether the handle has been initialized, so that a register
 *         accessing operation may run. (NON-BLOCKING)
 * @note   ARCH-CONST-09: a handle that is not initialized (RESET) requires one
 *         of the initialization functions first and is rejected with
 *         HAL_ERROR.
 * @note   The BUSY state is accepted on purpose. In this module BUSY means that
 *         the counter is running (the Start functions leave it set) and not
 *         that an operation is ongoing, so the Stop, the compare update and
 *         the configuration calls have to stay usable while the timer runs.
 *         The transient BUSY windows of the initialization and the
 *         de-initialization are protected by the handle lock. The TIMEOUT and
 *         ERROR states are recoverable and accepted as well.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK (accepted) / HAL_ERROR (not initialized).
 */
HAL_StatusTypeDef TIM_CheckInitState(HAL_TIM_HandleTypeDef *htim);

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_TIM_Base_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared timer; the value is passed to HAL_MutexAcquire() as is
 *         (RTOS ticks; HAL_MAX_DELAY means an infinite wait).
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS, wait expired) /
 *         HAL_ERROR (RTOS, mutex not created) / HAL_BUSY (bare metal, the
 *         handle is already locked).
 */
HAL_StatusTypeDef TIM_LockHandle(HAL_TIM_HandleTypeDef *htim, uint32 Timeout);

/**
 * @brief  Unlock the handle.
 * @param  htim: pointer to a HAL_TIM_HandleTypeDef structure.
 * @retval None
 */
void TIM_UnlockHandle(HAL_TIM_HandleTypeDef *htim);

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_TIM_H */

/*****END OF FILE*****/