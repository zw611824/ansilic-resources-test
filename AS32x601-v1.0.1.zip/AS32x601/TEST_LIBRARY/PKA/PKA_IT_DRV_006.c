/**
 * @file    PKA_IT_DRV_006.c
 * @brief   HAL PKA integration test case 006 (API coverage self test).
 *
 * Case 006 is the extension case of the suite: it does not repeat a
 * cryptographic vector, it checks the interface contract of the driver that
 * the vector cases cannot observe:
 *
 *   1. the default values produced by HAL_PKA_StructInit();
 *   2. the run time configuration validation of HAL_PKA_Init() (metafields,
 *      field domains, partial radix against the selected base, M-521 mode);
 *   3. the life cycle: state transitions, the low level callback call counts,
 *      the idempotency of HAL_PKA_DeInit() and the lock helper;
 *   4. the state gate: an uninitialized handle never touches a register;
 *   5. the run time parameter validation of the operand access functions
 *      (window bounds, 4-byte alignment, micro-code region, field widths);
 *   6. the register level read-back of the entry point, the stack pointer and
 *      the interrupt enable bits;
 *   7. one real operation with the status flag handling (DONE set, then
 *      acknowledged), the flag accessors, the stop reason, the interrupt
 *      handler, the error callback and the exported helper macros.
 *
 * Tested functionality:
 *   the whole exported API of the PKA driver, including
 *   HAL_PKA_StructInit() / HAL_PKA_Init() / HAL_PKA_DeInit() /
 *   HAL_PKA_MspInit() / HAL_PKA_MspDeInit() / HAL_PKA_ITConfig() /
 *   HAL_PKA_GetStatStatus() / HAL_PKA_GetFlagStatus() /
 *   HAL_PKA_ClearStatus() / HAL_PKA_SetEntryPoint() / HAL_PKA_ClearStack() /
 *   HAL_PKA_SetStackPointer() / HAL_PKA_GetStopReasonCode() /
 *   HAL_PKA_LoadFirmware() / HAL_PKA_WriteData() / HAL_PKA_ReadData() /
 *   HAL_PKA_IRQHandler() / HAL_PKA_ErrorCallback() /
 *   HAL_PKA_GetState() / HAL_PKA_GetError() and the shared lock helpers
 *   PKA_LockHandle() / PKA_UnlockHandle().
 *
 * Expected behaviour:
 *   every check passes, so the summary stays at zero failures;
 *   the case performs no cryptographic comparison and can be run repeatedly
 *   on any board, it only needs the micro-code image.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"
#include "as32x601_pka_fw.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* One 256-bit operand is 8 words */
#define TEST_WORDS                  (8U)

/* Base radix used by the self test operations */
#define TEST_BASE_RADIX             (PKA_BASE_RADIX_256)

/* Micro-code entry points used by the self test */
#define TEST_EP_RINV                (0x11U)   /* r^-1 mod m                 */

/* Stack pointer written by the register read-back check: STACK_PNTR.PNTR is
   a 4-bit field (16 F-Stack entries), so 5 is a value inside the field that
   cannot be confused with the 0 left behind by HAL_PKA_ClearStack() */
#define TEST_STACK_POINTER          (0x00000005U)

/* Stack pointer above the field: bit 4 and higher do not exist, so the
   driver must reject it instead of letting the hardware truncate it */
#define TEST_STACK_POINTER_BAD      (0x00000010U)

/* Bound of every polling loop */
#define TEST_WAIT_GUARD             (20000000U)

/* Reporting period of the final loop (ms) */
#define TEST_POLL_MS                (1000U)

/* Invalid instance address used by the handle validation checks */
#define TEST_BAD_INSTANCE           ((PKA_TypeDef *)0x40000000UL)

/* Private variables ---------------------------------------------------------*/
static HAL_PKA_HandleTypeDef hpka_dev;      /*!< handle under test            */
static HAL_PKA_HandleTypeDef hpka_gate;     /*!< never initialized handle     */
static HAL_SMU_HandleTypeDef hsmu_clk;      /*!< SMU handle (clock tree)      */
static uint32                failures = 0U; /*!< failed checks                */
static uint32                checks = 0U;   /*!< executed checks              */

/* Call counts of the low level callbacks */
static uint32 msp_init_count = 0U;
static uint32 msp_deinit_count = 0U;
static HAL_PKA_StateTypeDef msp_last_state = HAL_PKA_STATE_RESET;

/* Zero buffer used to clear the operand window */
static uint32 pka_zero[PKA_OPERAND_WINDOW_WORDS_MAX];

/* Operand buffer used by the validation checks */
static uint32 pka_buffer[TEST_WORDS];

/* Byte buffer used by the alignment check: the odd address must be refused */
static uint8 pka_bytes[(TEST_WORDS * 4U) + 8U];

/* Odd 256-bit modulus used by the single self-test operation.  Entry 0x11
   derives r^-1 mod m and never terminates when the modulus is zero (measured
   on silicon: RTN_CODE.BUSY stays set and STAT.DONE never appears), so the
   operand has to be written before the operation starts - exactly what the
   vector cases do.  Word 0 is the least significant word and must be odd. */
static const uint32 test_modulus[TEST_WORDS] =
{
    0xF1E2D3C5U, 0x9A8B7C6DU, 0x5F4E3D2CU, 0x1A2B3C4DU,
    0x8E7F6A5BU, 0x3C4D5E6FU, 0x2B1A0F9EU, 0x00C3D5E7U
};

/* Private function prototypes -----------------------------------------------*/
static void Section(const char *name);
static void Report_Note(const char *text);
static void Check(const char *name, uint32 condition);
static HAL_StatusTypeDef Pka_LoadFirmware(void);
static HAL_StatusTypeDef Pka_ClearMemory(void);
static HAL_StatusTypeDef Pka_WriteModulus(void);
static uint32 Pka_StartAndWait(uint32 entry, uint32 radix);
static void SystemClock_Init(void);

/* Private functions ---------------------------------------------------------*/
int main(void)
{
    PKA_InitTypeDef cfg;
    uint32          entry_before;
    uint32          stack_before;
    uint32          irq_before;
    uint32          status_before;
    uint32          i;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL, 90 MHz core clock) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);

    printf("\r\n ***** PKA API coverage self test ***** \r\n");
    delay_ms(500U);

    for (i = 0U; i < TEST_WORDS; i++)
    {
        pka_buffer[i] = 0x11111111U * (i + 1U);
    }
    for (i = 0U; i < (uint32)sizeof(pka_bytes); i++)
    {
        pka_bytes[i] = 0x5AU;
    }

    /* ------------------------------------------------ module and defaults */
    Section("module version and structure defaults");

    printf("module version = 0x%04X\r\n", PRINT_U32((uint32)__HAL_PKA_MODULE_VERSION));
    Check("module version is at least V1.0",
          ((uint32)__HAL_PKA_MODULE_VERSION >= 0x0100U) ? 1U : 0U);

    HAL_PKA_StructInit(&cfg);
    Check("StructInit : Size", (cfg.Size == sizeof(PKA_InitTypeDef)) ? 1U : 0U);
    Check("StructInit : Version", (cfg.Version == PKA_INIT_VERSION) ? 1U : 0U);
    Check("StructInit : partial radix = 8 words", (cfg.PKA_PartialRadix == 8U) ? 1U : 0U);
    Check("StructInit : base radix = 256 bit",
          (cfg.PKA_BaseRadix == PKA_BASE_RADIX_256) ? 1U : 0U);
    Check("StructInit : M-521 mode off", (cfg.PKA_M521Mode == PKA_M521_MODE_NONE) ? 1U : 0U);
    Check("StructInit : stop request off",
          (cfg.PKA_StopRqst == PKA_STOP_RQST_DIS) ? 1U : 0U);
    Check("StructInit : GO off", (cfg.PKA_Go == PKA_GO_DIS) ? 1U : 0U);
    Check("StructInit : alternate access normal",
          (cfg.PKA_AltAccess == PKA_ALT_ACCESS_NORMAL) ? 1U : 0U);
    Check("StructInit : little endian",
          (cfg.PKA_EndianSwap == PKA_ENDIAN_SWAP_LITTLE) ? 1U : 0U);
    Check("StructInit : reserved words cleared",
          ((cfg.Reserved[0] == 0U) && (cfg.Reserved[1] == 0U)) ? 1U : 0U);
    Check("StructInit of a NULL pointer is a no-op",
          (HAL_PKA_StructInit(NULL_PTR), 1U));

    /* ---------------------------------------------- initialization domain */
    Section("HAL_PKA_Init run time validation and life cycle");

    __HAL_CLEAR_STRUCT(&hpka_dev);
    hpka_dev.Instance = PKA;
    Check("a cleared handle reports the reset state",
          (HAL_PKA_GetState(&hpka_dev) == HAL_PKA_STATE_RESET) ? 1U : 0U);
    Check("a cleared handle reports no error",
          (HAL_PKA_GetError(&hpka_dev) == HAL_PKA_ERROR_NONE) ? 1U : 0U);

    Check("Init with a NULL handle is refused",
          (HAL_PKA_Init(NULL_PTR, &cfg) == HAL_ERROR) ? 1U : 0U);
    Check("Init with a NULL configuration is refused",
          (HAL_PKA_Init(&hpka_dev, NULL_PTR) == HAL_ERROR) ? 1U : 0U);

    hpka_dev.Instance = TEST_BAD_INSTANCE;
    Check("Init with an unknown instance is refused",
          (HAL_PKA_Init(&hpka_dev, &cfg) == HAL_ERROR) ? 1U : 0U);
    hpka_dev.Instance = PKA;

    HAL_PKA_StructInit(&cfg);
    cfg.Size = 0U;
    Check("Init with a wrong Size is refused",
          (HAL_PKA_Init(&hpka_dev, &cfg) == HAL_ERROR) ? 1U : 0U);
    Check("the refused call reports an invalid parameter",
          ((HAL_PKA_GetError(&hpka_dev) & HAL_PKA_ERROR_INVALID_PARAM) != 0U) ? 1U : 0U);

    HAL_PKA_StructInit(&cfg);
    cfg.Version = 0xFFFFU;
    Check("Init with a wrong Version is refused",
          (HAL_PKA_Init(&hpka_dev, &cfg) == HAL_ERROR) ? 1U : 0U);

    HAL_PKA_StructInit(&cfg);
    cfg.Reserved[0] = 1U;
    Check("Init with a reserved word set is refused",
          (HAL_PKA_Init(&hpka_dev, &cfg) == HAL_ERROR) ? 1U : 0U);

    HAL_PKA_StructInit(&cfg);
    cfg.PKA_BaseRadix = 0U;
    Check("Init with an illegal base radix is refused",
          (HAL_PKA_Init(&hpka_dev, &cfg) == HAL_ERROR) ? 1U : 0U);

    HAL_PKA_StructInit(&cfg);
    cfg.PKA_PartialRadix = 17U;
    Check("Init with a partial radix above the base is refused",
          (HAL_PKA_Init(&hpka_dev, &cfg) == HAL_ERROR) ? 1U : 0U);

    HAL_PKA_StructInit(&cfg);
    cfg.PKA_BaseRadix = PKA_BASE_RADIX_512;
    cfg.PKA_PartialRadix = 17U;
    Report_Note("a 512-bit base holds 16 words, so a 17-word partial radix is above the domain");
    Check("Init with 17 words on a 512-bit base is refused",
          (HAL_PKA_Init(&hpka_dev, &cfg) == HAL_ERROR) ? 1U : 0U);

    HAL_PKA_StructInit(&cfg);
    cfg.PKA_M521Mode = PKA_M521_MODE_M521;
    cfg.PKA_PartialRadix = 8U;
    Check("M-521 mode without the 17-word length is refused",
          (HAL_PKA_Init(&hpka_dev, &cfg) == HAL_ERROR) ? 1U : 0U);

    Check("a refused Init leaves the handle in the reset state",
          (HAL_PKA_GetState(&hpka_dev) == HAL_PKA_STATE_RESET) ? 1U : 0U);
    Check("no low level initialization ran for a refused call",
          (msp_init_count == 0U) ? 1U : 0U);

    /* A legal configuration now starts the module */
    HAL_PKA_StructInit(&cfg);
    Check("Init with a legal configuration succeeds",
          (HAL_PKA_Init(&hpka_dev, &cfg) == HAL_OK) ? 1U : 0U);
    Check("the handle is ready after Init",
          (HAL_PKA_GetState(&hpka_dev) == HAL_PKA_STATE_READY) ? 1U : 0U);
    Check("the error code is cleared by a successful Init",
          (HAL_PKA_GetError(&hpka_dev) == HAL_PKA_ERROR_NONE) ? 1U : 0U);
    Check("the low level initialization ran exactly once",
          (msp_init_count == 1U) ? 1U : 0U);
    Check("the low level callback saw the reset state",
          (msp_last_state == HAL_PKA_STATE_RESET) ? 1U : 0U);

    Check("a second Init on a ready handle succeeds",
          (HAL_PKA_Init(&hpka_dev, &cfg) == HAL_OK) ? 1U : 0U);
    Check("the second Init does not repeat the low level initialization",
          (msp_init_count == 1U) ? 1U : 0U);

    /* ------------------------------------------------------- lock helper */
    Section("lock helper");

    Check("the lock is free after Init",
          (PKA_LockHandle(&hpka_dev, 0U) == HAL_OK) ? 1U : 0U);
    Check("a second lock is rejected with HAL_BUSY",
          (PKA_LockHandle(&hpka_dev, 0U) == HAL_BUSY) ? 1U : 0U);
    PKA_UnlockHandle(&hpka_dev);
    Check("the lock can be taken again after the release",
          (PKA_LockHandle(&hpka_dev, 0U) == HAL_OK) ? 1U : 0U);
    PKA_UnlockHandle(&hpka_dev);

    /* ------------------------------------------------------ state gate */
    Section("state gate on an uninitialized handle");

    __HAL_CLEAR_STRUCT(&hpka_gate);
    hpka_gate.Instance = PKA;

    entry_before = READ_REG(PKA->ENTRY_PNT);
    stack_before = READ_REG(PKA->STACK_PNTR);
    irq_before   = READ_REG(PKA->IRQ_EN);
    status_before = READ_REG(PKA->STAT);

    HAL_PKA_SetEntryPoint(&hpka_gate, TEST_EP_RINV);
    HAL_PKA_SetStackPointer(&hpka_gate, 0x00000123U);
    HAL_PKA_ClearStack(&hpka_gate);
    HAL_PKA_ClearStatus(&hpka_gate, PKA_STATE_DONE);
    HAL_PKA_ITConfig(&hpka_gate, PKA_IT_DONE, ENABLE);

    Check("the entry point was not written by a reset handle",
          (READ_REG(PKA->ENTRY_PNT) == entry_before) ? 1U : 0U);
    Check("the stack pointer was not written by a reset handle",
          (READ_REG(PKA->STACK_PNTR) == stack_before) ? 1U : 0U);
    Check("the interrupt enable was not written by a reset handle",
          (READ_REG(PKA->IRQ_EN) == irq_before) ? 1U : 0U);
    Check("the status was not acknowledged by a reset handle",
          (READ_REG(PKA->STAT) == status_before) ? 1U : 0U);

    Check("WriteData on a reset handle is refused",
          (HAL_PKA_WriteData(&hpka_gate, PKA_OPERAND_A_OFFSET, pka_buffer,
                             TEST_WORDS) == HAL_ERROR) ? 1U : 0U);
    Check("ReadData on a reset handle is refused",
          (HAL_PKA_ReadData(&hpka_gate, PKA_OPERAND_A_OFFSET, pka_buffer,
                            TEST_WORDS) == HAL_ERROR) ? 1U : 0U);
    Check("LoadFirmware on a reset handle is refused",
          (HAL_PKA_LoadFirmware(&hpka_gate, pka_fw_addr, pka_fw_data,
                                PKA_FW_LENGTH) == HAL_ERROR) ? 1U : 0U);

    /* ------------------------------------- run time parameter validation */
    Section("operand access run time validation");

    Check("the micro-code image loads",
          (Pka_LoadFirmware() == HAL_OK) ? 1U : 0U);
    Check("the operand window is cleared",
          (Pka_ClearMemory() == HAL_OK) ? 1U : 0U);

    Check("LoadFirmware outside the micro-code region is refused",
          (HAL_PKA_LoadFirmware(&hpka_dev, pka_fw_addr, pka_fw_data,
                                PKA_FIRMWARE_WORDS_MAX + 1U) == HAL_ERROR) ? 1U : 0U);

    Check("LoadFirmware with a NULL image is refused",
          (HAL_PKA_LoadFirmware(&hpka_dev, NULL_PTR, pka_fw_data, 1U) == HAL_ERROR) ? 1U : 0U);

    Check("LoadFirmware with a NULL data pointer is refused",
          (HAL_PKA_LoadFirmware(&hpka_dev, pka_fw_addr, NULL_PTR, 1U) == HAL_ERROR) ? 1U : 0U);

    Check("WriteData with a NULL buffer is refused",
          (HAL_PKA_WriteData(&hpka_dev, PKA_OPERAND_A_OFFSET, NULL_PTR,
                             TEST_WORDS) == HAL_ERROR) ? 1U : 0U);

    Check("WriteData with an unaligned buffer is refused",
          (HAL_PKA_WriteData(&hpka_dev, PKA_OPERAND_A_OFFSET,
                             (const uint32 *)(void *)&pka_bytes[1],
                             TEST_WORDS) == HAL_ERROR) ? 1U : 0U);

    Check("WriteData below the operand window is refused",
          (HAL_PKA_WriteData(&hpka_dev, PKA_OPERAND_A_OFFSET - 4U, pka_buffer,
                             TEST_WORDS) == HAL_ERROR) ? 1U : 0U);

    Check("WriteData above the operand window is refused",
          (HAL_PKA_WriteData(&hpka_dev, PKA_OPERAND_WINDOW_END, pka_buffer,
                             TEST_WORDS) == HAL_ERROR) ? 1U : 0U);

    Check("WriteData across the end of the window is refused",
          (HAL_PKA_WriteData(&hpka_dev, PKA_OPERAND_WINDOW_END - 4U, pka_buffer,
                             TEST_WORDS) == HAL_ERROR) ? 1U : 0U);

    Check("WriteData with a wrapping length is refused",
          (HAL_PKA_WriteData(&hpka_dev, PKA_OPERAND_A_OFFSET, pka_buffer,
                             0x40000000U) == HAL_ERROR) ? 1U : 0U);

    Check("ReadData with a NULL buffer is refused",
          (HAL_PKA_ReadData(&hpka_dev, PKA_OPERAND_A_OFFSET, NULL_PTR,
                            TEST_WORDS) == HAL_ERROR) ? 1U : 0U);

    Check("ReadData above the operand window is refused",
          (HAL_PKA_ReadData(&hpka_dev, PKA_OPERAND_WINDOW_END, pka_buffer,
                            TEST_WORDS) == HAL_ERROR) ? 1U : 0U);

    Check("a legal WriteData / ReadData pair succeeds",
          ((HAL_PKA_WriteData(&hpka_dev, PKA_OPERAND_A_OFFSET, pka_buffer, TEST_WORDS) == HAL_OK) &&
           (HAL_PKA_ReadData(&hpka_dev, PKA_OPERAND_A_OFFSET, pka_buffer, TEST_WORDS) == HAL_OK)) ? 1U : 0U);

    /* -------------------------------------------- register level read back */
    Section("register level read back");

    HAL_PKA_SetEntryPoint(&hpka_dev, TEST_EP_RINV);
    Check("the entry point reads back",
          (((READ_REG(PKA->ENTRY_PNT) & PKA_ENTRY_PNT_ADDR_Msk) >> PKA_ENTRY_PNT_ADDR_Pos)
           == TEST_EP_RINV) ? 1U : 0U);

    HAL_PKA_SetStackPointer(&hpka_dev, TEST_STACK_POINTER);
    Check("the stack pointer reads back",
          (((READ_REG(PKA->STACK_PNTR) & PKA_STACK_PNTR_PNTR_Msk) >> PKA_STACK_PNTR_PNTR_Pos)
           == TEST_STACK_POINTER) ? 1U : 0U);

    /* PNTR is a 4-bit field: a value above it must be rejected instead of
       being truncated by the hardware */
    HAL_PKA_SetStackPointer(&hpka_dev, TEST_STACK_POINTER_BAD);
    Check("a stack pointer outside the 4-bit field is refused",
          (((READ_REG(PKA->STACK_PNTR) & PKA_STACK_PNTR_PNTR_Msk) >> PKA_STACK_PNTR_PNTR_Pos)
           == TEST_STACK_POINTER) ? 1U : 0U);
    HAL_PKA_ClearStack(&hpka_dev);
    Check("the stack pointer is cleared",
          (READ_REG(PKA->STACK_PNTR) == 0U) ? 1U : 0U);

    HAL_PKA_SetEntryPoint(&hpka_dev, 0x1000U);
    Check("an entry point outside the 12-bit field is refused",
          (((READ_REG(PKA->ENTRY_PNT) & PKA_ENTRY_PNT_ADDR_Msk) >> PKA_ENTRY_PNT_ADDR_Pos)
           == TEST_EP_RINV) ? 1U : 0U);

    HAL_PKA_ITConfig(&hpka_dev, PKA_IT_DONE, ENABLE);
    Check("the DONE interrupt enable is set",
          ((READ_REG(PKA->IRQ_EN) & PKA_IT_DONE) != 0U) ? 1U : 0U);
    HAL_PKA_ITConfig(&hpka_dev, PKA_IT_DONE, DISABLE);
    Check("the DONE interrupt enable is cleared",
          ((READ_REG(PKA->IRQ_EN) & PKA_IT_DONE) == 0U) ? 1U : 0U);

    irq_before = READ_REG(PKA->IRQ_EN);
    HAL_PKA_ITConfig(&hpka_dev, 0U, ENABLE);
    Check("an unknown interrupt selector leaves the register unchanged",
          (READ_REG(PKA->IRQ_EN) == irq_before) ? 1U : 0U);

    /* ----------------------------------------- one operation and its flags */
    Section("operation, status flags and remaining API");

    Check("the modulus of the operation is written to D0",
          (Pka_WriteModulus() == HAL_OK) ? 1U : 0U);

    HAL_PKA_ClearStack(&hpka_dev);
    HAL_PKA_SetEntryPoint(&hpka_dev, TEST_EP_RINV);
    (void)HAL_PKA_ClearStatus(&hpka_dev, PKA_STATE_DONE);
    Check("the preparation of the operation completes", 1U);

    Check("the operation starts", Pka_StartAndWait(TEST_EP_RINV, TEST_BASE_RADIX));

    Check("the DONE flag is set after the operation",
          (HAL_PKA_GetStatStatus(&hpka_dev, PKA_STATE_DONE) == SET) ? 1U : 0U);
    Check("the raw STAT accessor sees the same flag",
          (((uint32)__HAL_PKA_GET_STAT(&hpka_dev, PKA_STATE_DONE) != 0U)) ? 1U : 0U);
    Check("the instruction counter advanced",
          (((uint32)__HAL_PKA_GET_INSTR_SINCE_GO(&hpka_dev) != 0U)) ? 1U : 0U);

    HAL_PKA_ClearStatus(&hpka_dev, PKA_STATE_DONE);
    Check("the DONE flag is acknowledged",
          (HAL_PKA_GetStatStatus(&hpka_dev, PKA_STATE_DONE) == RESET) ? 1U : 0U);

    /* Stop the program: clearing CTRL.GO cannot halt a running micro-code, so
       the driver raises CTRL.STOP_RQST and waits for RTN_CODE.BUSY instead */
    Check("the stop request completes",
          (HAL_PKA_Stop(&hpka_dev, PKA_STOP_TIMEOUT_DEFAULT) == HAL_OK) ? 1U : 0U);
    Check("the operation is stopped",
          ((READ_REG(PKA->CTRL) & PKA_CTRL_GO) == 0U) ? 1U : 0U);

    /* The flag accessors must be callable for every documented flag */
    (void)HAL_PKA_GetFlagStatus(&hpka_dev, PKA_FLAG_ZERO);
    (void)HAL_PKA_GetFlagStatus(&hpka_dev, PKA_FLAG_MEMORYTEST);
    (void)HAL_PKA_GetFlagStatus(&hpka_dev, PKA_FLAG_BORROW);
    (void)HAL_PKA_GetFlagStatus(&hpka_dev, PKA_FLAG_CARRY);
    (void)HAL_PKA_GetFlagStatus(&hpka_dev, PKA_FLAG_USERFLAG0);
    (void)HAL_PKA_GetFlagStatus(&hpka_dev, PKA_FLAG_USERFLAG1);
    (void)HAL_PKA_GetFlagStatus(&hpka_dev, PKA_FLAG_USERFLAG2);
    (void)HAL_PKA_GetFlagStatus(&hpka_dev, PKA_FLAG_USERFLAG3);
    Check("the flag accessors are callable", 1U);
    printf("flags        = 0x%08X\r\n", PRINT_U32((uint32)READ_REG(PKA->FLAGS)));
    printf("stop reason  = %u\r\n", PRINT_U32((uint32)HAL_PKA_GetStopReasonCode(&hpka_dev)));
    printf("cycles       = %u\r\n", PRINT_U32((uint32)__HAL_PKA_GET_CYCLES_SINCE_GO(&hpka_dev)));

    /* The interrupt handler and the error callback must be NULL safe */
    HAL_PKA_IRQHandler(&hpka_dev);
    HAL_PKA_IRQHandler(NULL_PTR);
    HAL_PKA_ErrorCallback(&hpka_dev);
    HAL_PKA_ErrorCallback(NULL_PTR);
    Check("the interrupt handler and the callback are NULL safe", 1U);

    /* ------------------------------------------------- de-initialization */
    Section("de-initialization");

    /* An idle accelerator turns this into a no-op, so the teardown below is
       never rejected by the hardware-busy gate of HAL_PKA_DeInit() */
    Check("the accelerator is idle before the teardown",
          (HAL_PKA_Stop(&hpka_dev, PKA_STOP_TIMEOUT_DEFAULT) == HAL_OK) ? 1U : 0U);

    Check("DeInit succeeds", (HAL_PKA_DeInit(&hpka_dev) == HAL_OK) ? 1U : 0U);
    Check("the handle is reset after DeInit",
          (HAL_PKA_GetState(&hpka_dev) == HAL_PKA_STATE_RESET) ? 1U : 0U);
    Check("the low level de-initialization ran exactly once",
          (msp_deinit_count == 1U) ? 1U : 0U);
    Check("a repeated DeInit is a no-op",
          (HAL_PKA_DeInit(&hpka_dev) == HAL_OK) ? 1U : 0U);
    Check("the repeated DeInit does not repeat the teardown",
          (msp_deinit_count == 1U) ? 1U : 0U);

    /* The exported handle reset helper brings a handle back to RESET */
    HAL_PKA_StructInit(&cfg);
    (void)HAL_PKA_Init(&hpka_dev, &cfg);
    __HAL_PKA_RESET_HANDLE_STATE(&hpka_dev);
    Check("the handle reset helper restores the reset state",
          (HAL_PKA_GetState(&hpka_dev) == HAL_PKA_STATE_RESET) ? 1U : 0U);
    Check("the module restarts after the helper",
          (HAL_PKA_Init(&hpka_dev, &cfg) == HAL_OK) ? 1U : 0U);

    /* ------------------------------------------------------- summary --- */
    for (;;)
    {
        printf("\r\nchecks = %u | summary : failures = %u\r\n",
               PRINT_U32(checks), PRINT_U32(failures));

        delay_ms(TEST_POLL_MS);
    }
}

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Report a section title.
 * @param  name: section name.
 * @retval None
 */
static void Section(const char *name)
{
    printf("\r\n-- %s --\r\n", name);
}

/**
 * @brief  Report a note line (no check is counted).
 * @param  text: text to print.
 * @retval None
 */
static void Report_Note(const char *text)
{
    printf("note: %s\r\n", text);
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    checks++;

    if (condition == 0U)
    {
        failures++;
    }
    printf("%-56s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Load the PKA micro-code image through the HAL API.
 * @retval HAL status of HAL_PKA_LoadFirmware().
 */
static HAL_StatusTypeDef Pka_LoadFirmware(void)
{
    return HAL_PKA_LoadFirmware(&hpka_dev, pka_fw_addr, pka_fw_data, PKA_FW_LENGTH);
}

/**
 * @brief  Clear the whole operand window through the HAL API.
 * @retval HAL status of HAL_PKA_WriteData().
 */
static HAL_StatusTypeDef Pka_ClearMemory(void)
{
    return HAL_PKA_WriteData(&hpka_dev, PKA_OPERAND_WINDOW_FIRST, pka_zero,
                             PKA_OPERAND_WINDOW_WORDS_MAX);
}

/**
 * @brief  Write the modulus of the self-test operation to D0.
 * @retval HAL status of HAL_PKA_WriteData().
 * @note   HAL_PKA_WriteData() takes a byte offset from PKA_BASE, while
 *         PKA_ECC_ADDR_256_D0 is the absolute operand address, so the base has
 *         to be subtracted here (the same rule the vector cases follow).
 */
static HAL_StatusTypeDef Pka_WriteModulus(void)
{
    return HAL_PKA_WriteData(&hpka_dev, PKA_ECC_ADDR_256_D0 - PKA_BASE,
                             test_modulus, TEST_WORDS);
}

/**
 * @brief  Start one operation by setting CTRL.GO and wait for DONE.
 * @param  entry: program entry point.
 * @param  radix: base radix encoding.
 * @retval 1 when the operation completed, 0 when the guard expired.
 * @note   This is the raw sequence of the reference material without the
 *         stop step, so the caller can observe the DONE flag before it is
 *         acknowledged.
 */
static uint32 Pka_StartAndWait(uint32 entry, uint32 radix)
{
    PKA_InitTypeDef cfg;
    uint32          guard;

    (void)HAL_PKA_SetEntryPoint(&hpka_dev, entry);

    HAL_PKA_StructInit(&cfg);
    cfg.PKA_PartialRadix = 0U;
    cfg.PKA_BaseRadix    = radix;
    cfg.PKA_Go           = PKA_GO_EN;

    if (HAL_PKA_Init(&hpka_dev, &cfg) != HAL_OK)
    {
        return 0U;
    }

    guard = TEST_WAIT_GUARD;
    while ((HAL_PKA_GetStatStatus(&hpka_dev, PKA_STATE_DONE) == RESET) && (guard != 0U))
    {
        guard--;
    }
    CLEAR_CACHE();

    return (guard != 0U) ? 1U : 0U;
}

/**
 * @brief  PKA low level initialization, counted for the life cycle checks.
 * @param  hpka: PKA handle.
 * @retval None
 * @note   The PKA is clocked by the AXILite4-Bus1 (DSE) domain, gated by the
 *         SMU, so the low level callback enables that gate and releases the
 *         reset of the domain.  The call count and the state of the handle
 *         at the time of the call are recorded, which lets the case verify
 *         that the callback runs once and before the handle is locked.
 */
void HAL_PKA_MspInit(HAL_PKA_HandleTypeDef *hpka)
{
    if (hpka == NULL_PTR)
    {
        return;
    }

    msp_init_count++;
    msp_last_state = hpka->State;

    __HAL_SMU_DSE_CLK_ENABLE();
    __HAL_SMU_DSE_FORCE_RESET();
    __HAL_SMU_DSE_RELEASE_RESET();
}

/**
 * @brief  PKA low level de-initialization, counted for the life cycle checks.
 * @param  hpka: PKA handle.
 * @retval None
 */
void HAL_PKA_MspDeInit(HAL_PKA_HandleTypeDef *hpka)
{
    if (hpka == NULL_PTR)
    {
        return;
    }

    msp_deinit_count++;
}

/**
 * @brief  Configure the system clock and the bus gates.
 * @retval None
 * @note   Same clock tree as the other HAL integration suites: the PLL is fed
 *         by the external oscillator (VCO 180 MHz) and the buses run at
 *         AXI4Bus3 / 2, APBBus0 / 2, APBBus1 / 2 and CANX2 / 8, which keeps
 *         the console USART on its usual 22.5 MHz.
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    smu_osc;
    SMU_ClockInitTypeDef  smu_clock;
    SMU_ClocksTypeDef     smu_clocks;
    HAL_PMU_HandleTypeDef hpmu;

    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Raise the core rail trim before the PLL is switched, as the other HAL
       integration suites do: the 1.2 V LDO APIs are gated on the handle state,
       so the PMU must be initialized first */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    __HAL_CLEAR_STRUCT(&smu_osc);
    smu_osc.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    smu_osc.FIRCState            = SMU_FIRC_ON;
    smu_osc.FIRCCalibrationValue = 0x00U;
    smu_osc.PLL.PLLState         = SMU_PLL_ON;
    smu_osc.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    smu_osc.PLL.PLLDivR          = 0x04U;
    smu_osc.PLL.PLLDivQ          = 0x01U;
    smu_osc.PLL.PLLDivN          = 0x14U;
    smu_osc.PLL.PLLDivF          = 0xB4U;
    smu_osc.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    (void)HAL_SMU_OscConfig(&hsmu_clk, &smu_osc, SMU_TIMEOUT_DEFAULT);

    /* Bus dividers */
    __HAL_CLEAR_STRUCT(&smu_clock);
    smu_clock.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    smu_clock.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    smu_clock.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    smu_clock.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &smu_clock);

    (void)HAL_SMU_GetClocksFreq(&smu_clocks);
}

/*****END OF FILE*****/
