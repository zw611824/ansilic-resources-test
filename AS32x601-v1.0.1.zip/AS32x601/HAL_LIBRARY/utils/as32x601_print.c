/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):  	Xiamen Guoke Anxin Technology Co., LTD
 * FileName:     	as32x601_print.c
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.1
 * Date:			2026/09/10
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/09/10     1.0     print module for the
 *                                                       USART integration test
 *     ANSILIC APPLICATION GROUP  2026/09/10     1.1     added the minimal
 *                                                       newlib system call
 *                                                       stubs, so that the
 *                                                       libnosys members are
 *                                                       not linked in
 * Description:     Print (printf) retarget for the AS32x601 CLINT integration
 *                  test project. HAL-library flavoured port of Bsp/print.c of
 *                  the AS32x601 CLINT test project:
 *                  - USART0 clock gate is opened through the SMU HAL layer
 *                    (__HAL_SMU_USART0_CLK_ENABLE) and the GPIOD clock gate
 *                    through __HAL_SMU_GPIOD_CLK_ENABLE;
 *                  - GPIOD pin 8 (USART0_TX) / pin 9 (USART0_RX) are mapped to
 *                    the USART0 alternate function through
 *                    HAL_GPIO_PinAFConfig() and configured through
 *                    HAL_GPIO_Init();
 *                  - USART0 is programmed through HAL_USART_StructInit() /
 *                    HAL_USART_Init() and enabled by HAL_USART_Init();
 *                  - putchar() and _write() push the characters with
 *                    HAL_USART_Transmit(), so printf() output (newlib /
 *                    IAR DLIB) is routed to the console USART;
 *                  - _sbrk() provides the minimal heap required by the newlib
 *                    stdio initialization (the nosys default implementation
 *                    refers to the "end" symbol, which the HAL linker script
 *                    does not provide);
 *                  - _close() / _fstat() / _isatty() / _lseek() / _read() with
 *                    the console behaviour of a character device, which keeps
 *                    the libnosys "not implemented" linker warnings away.
 *                  API: User_Print_Init().
 */

/* Includes ------------------------------------------------------------------*/
#include "as32x601_print.h"
#include <stdio.h>              /* printf / putchar / setvbuf                 */
#ifndef _IAR_C_AS32x601_
#include <sys/stat.h>           /* struct stat / S_IFCHR (newlib syscalls)    */
#endif

/* Private variables ---------------------------------------------------------*/
static USART_HandleTypeDef husart_print;    /*!< console USART handle         */
static uint8 print_ready = 0U;              /*!< set once the console is ready*/

/* Exported functions --------------------------------------------------------*/

/**
 * @brief  Initialize the print (console) USART (USART0 on GPIOD pin 8/9).
 * @param  BaudRate: USART communication baud rate, in bit/s.
 * @retval None
 */
void User_Print_Init(uint32 BaudRate)
{
    USART_InitTypeDef USART_InitStruct;
    GPIO_InitTypeDef  GPIO_InitStruct;

    /* Enable the GPIOD / USART0 clock gates (USART0 belongs to APBBus0) */
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_USART0_CLK_ENABLE();

    /* Set the GPIO multiplex mapping: PD8 = USART0_TX, PD9 = USART0_RX */
    HAL_GPIO_PinAFConfig(PRINT_USART_GPIO, PRINT_USART_TX_SOURCE, PRINT_USART_AF);
    HAL_GPIO_PinAFConfig(PRINT_USART_GPIO, PRINT_USART_RX_SOURCE, PRINT_USART_AF);

    /* TX pin: alternate function push-pull output */
    __HAL_CLEAR_STRUCT(&GPIO_InitStruct);
    GPIO_InitStruct.Size         = sizeof(GPIO_InitStruct);
    GPIO_InitStruct.Version      = GPIO_INIT_VERSION;
    GPIO_InitStruct.Pin          = PRINT_USART_TX_PIN;
    GPIO_InitStruct.Mode         = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull         = GPIO_NOPULL;
    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;
    GPIO_InitStruct.Alternate    = PRINT_USART_AF;
    HAL_GPIO_Init(PRINT_USART_GPIO, &GPIO_InitStruct);

    /* RX pin: floating input */
    GPIO_InitStruct.Pin          = PRINT_USART_RX_PIN;
    GPIO_InitStruct.Mode         = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull         = GPIO_NOPULL;
    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;
    GPIO_InitStruct.Alternate    = PRINT_USART_AF;
    HAL_GPIO_Init(PRINT_USART_GPIO, &GPIO_InitStruct);

    /* Reset the console USART before reprogramming it */
    (void)HAL_USART_DeInit(&husart_print);

    /* Program the communication parameters (8 data bits, no parity, 1 stop) */
    HAL_USART_StructInit(&USART_InitStruct);

    USART_InitStruct.BaudRate     = BaudRate;
    USART_InitStruct.WordLength   = USART_WORDLENGTH_8B;
    USART_InitStruct.StopBits     = USART_STOPBITS_1;
    USART_InitStruct.Parity       = USART_PARITY_NONE;
    USART_InitStruct.Mode         = USART_MODE_TX_RX;
    USART_InitStruct.OverSampling = USART_OVERSAMPLING_16;

    husart_print.Instance = PRINT_USART;
    husart_print.Init     = USART_InitStruct;

    (void)HAL_USART_Init(&husart_print);

    /* Route the C library output to the console USART without buffering, so
     * that every printf() call appears on the terminal immediately. */
    (void)setvbuf(stdout, NULL, _IONBF, 0);

    print_ready = 1U;
}

/**
 * @brief  Send one character to the console USART (C library retarget hook).
 * @param  ch: character to send.
 * @retval The character sent.
 */
int putchar(int ch)
{
    uint8 data = (uint8)ch;

    if (print_ready != 0U)
    {
        (void)HAL_USART_Transmit(&husart_print, &data, 1U, PRINT_USART_TIMEOUT);
    }

    return ch;
}

/**
 * @brief  Low level write hook used by newlib (GCC toolchain): routes the
 *         C library output buffer to the console USART.
 * @param  file: file descriptor (unused, the console USART is the only sink).
 * @param  ptr: pointer to the data to send.
 * @param  len: number of bytes to send.
 * @retval Number of bytes sent.
 */
int _write(int file, char *ptr, int len)
{
    int i;

    /* Prevent unused argument compilation warning */
    (void)file;

    for (i = 0; i < len; i++)
    {
        (void)putchar((int)ptr[i]);
    }

    return len;
}

#ifndef _IAR_C_AS32x601_

/**
 * @brief  Minimal heap for the newlib (GCC) toolchain.
 * @note   The default nosys implementation refers to the "end" symbol, which
 *         the HAL linker script does not provide, so it is replaced here by a
 *         bump allocator running in the RAM area between the end of .bss and
 *         the bottom of the stack (the area the HAL linker script reserves
 *         for the heap and the stack).
 * @param  incr: number of bytes to allocate.
 * @retval Pointer to the allocated block, or (void *)-1 when the heap is
 *         exhausted.
 */
void *_sbrk(int incr)
{
    extern char _bss_end;           /* provided by the HAL linker script      */
    extern char _stack_bottom;      /* provided by the HAL linker script      */

    static char *heap = NULL_PTR;
    char        *previous;

    if (heap == NULL_PTR)
    {
        heap = &_bss_end;
    }

    if ((heap + incr) > (&_stack_bottom))
    {
        return (void *)-1;
    }

    previous = heap;
    heap += incr;

    return (void *)previous;
}

/**
 * @brief  Close a file descriptor (newlib system call stub).
 * @note   The console USART is the only channel of the test project and it is
 *         never closed, so every descriptor is rejected.
 * @param  file: file descriptor (unused).
 * @retval -1, the call always fails.
 */
int _close(int file)
{
    (void)file;

    return -1;
}

/**
 * @brief  Status of a file descriptor (newlib system call stub).
 * @note   Every descriptor is reported as a character device, which is what
 *         directs the C library to the unbuffered console path.
 * @param  file: file descriptor (unused).
 * @param  st: pointer to the status structure to fill in.
 * @retval 0 on success.
 */
int _fstat(int file, struct stat *st)
{
    (void)file;

    st->st_mode = S_IFCHR;

    return 0;
}

/**
 * @brief  Tell whether a file descriptor is a terminal (newlib system call
 *         stub).
 * @param  file: file descriptor (unused).
 * @retval 1, the console USART is always a terminal.
 */
int _isatty(int file)
{
    (void)file;

    return 1;
}

/**
 * @brief  Reposition a file descriptor (newlib system call stub).
 * @note   The console USART is a sequential stream and cannot be positioned.
 * @param  file: file descriptor (unused).
 * @param  offset: requested offset (unused).
 * @param  whence: reference of the offset (unused).
 * @retval 0, the position is left unchanged.
 */
int _lseek(int file, int offset, int whence)
{
    (void)file;
    (void)offset;
    (void)whence;

    return 0;
}

/**
 * @brief  Read from a file descriptor (newlib system call stub).
 * @note   The test cases are driven from the keys and the timers, so the
 *         console USART is write only: a read always reports end of file.
 * @param  file: file descriptor (unused).
 * @param  ptr: receive buffer (unused).
 * @param  len: number of bytes requested (unused).
 * @retval 0, end of file.
 */
int _read(int file, char *ptr, int len)
{
    (void)file;
    (void)ptr;
    (void)len;

    return 0;
}

#endif /* _IAR_C_AS32x601_ */

/*****END OF FILE*****/
