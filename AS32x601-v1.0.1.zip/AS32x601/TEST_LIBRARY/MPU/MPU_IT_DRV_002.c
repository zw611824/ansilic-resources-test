/**
 * @file    MPU_IT_DRV_002.c
 * @brief   HAL MPU integration test case 002 (I-Port read protection, channels
 *          0..15).
 *
 * One-to-one HAL library port of the original AS32x601 standard-library test
 * case MPU_IT_DRV_002.c. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_MPU_SetAddressRange()
 *   HAL_MPU_ReadProtectCmd()
 *   HAL_MPU_Cmd()
 *   HAL_MPU_GetReadProtectStatus()
 *   HAL_MPU_ClearStatus()
 *   HAL_MPU_GetIPortBlock()      (I-Port register block of MPU0)
 *
 * Test procedure:
 *   1. Program the range of every MPU0 channel (0..15) with the same protected
 *      window, derived from the address of the protected function
 *      Mpu_ProtectFunc();
 *   2. Enable the read protection of all 16 channels and then the channels
 *      themselves;
 *   3. Check the RPTEN / PTEN registers (the original case expects
 *      RPTEN = 0xFFFF), both directly and through HAL_MPU_GetChannelConfig();
 *   4. Check the status path before any violating fetch: the status of every
 *      channel reads 0, and the disable / enable round trip of RPTEN and PTEN
 *      works (none of these touches the protected range, so all of them run);
 *   5. Call the protected function.  Its instruction fetch passes through the
 *      MPU0 instruction port, is refused and is recorded in RPTS.  All 16
 *      channels carry the same window, so all 16 status bits are expected.  On
 *      this device the refused fetch does not complete and raises no trap: the
 *      core STOPS on it.  The status is therefore confirmed with the debugger
 *      (MPU0 RPTS = 0x0000FFFF) and the board is reset to run the case again.
 *
 * Test configuration (same as the original test case):
 *   MPU0 (I-Bus) channels 0..15, read protection on the same window around the
 *   protected function. The original case used a dedicated linker script that
 *   placed the function in a fixed flash window (.mpu_test section); the
 *   integration test project shares one linker script, so the window is
 *   derived from the function address instead.
 *
 *   Two properties the original case took for granted have to be arranged
 *   explicitly here, otherwise the status never gets set:
 *   - the call must really be emitted: Mpu_ProtectFunc() has no side effect
 *     that the compiler has to keep and its result is not used, so a direct
 *     "(void)Mpu_ProtectFunc();" is removed at -Og and the protected range is
 *     never fetched at all.  The test calls it through a volatile function
 *     pointer (pProtectFunc) instead;
 *   - the fetch has to MISS the instruction cache: a fetch that is served from
 *     the cache never reaches the bus, so it is neither refused nor recorded,
 *     and a line left over from a previously flashed image even lets stale
 *     code run.  Measured on the board: without the cache flush the very same
 *     configuration reported RPTS = 0 and took an illegal-instruction trap on
 *     the first instruction of the protected range; flushing the cache right
 *     before the triggering call (the call the original case makes there)
 *     recorded RPTS = 0x0000FFFF.  The function is given a section of its own
 *     with 64-byte alignment (so its first line belongs to it alone) and a
 *     body several cache lines long, so one call always crosses lines.
 *
 * Expected behaviour:
 *   - SADDR / EADDR of the 16 channels are programmed as requested;
 *   - RPTEN = 0xFFFF and PTEN = 0xFFFF after the enable calls (the value the
 *     original test specification expects), for the registers and for the
 *     HAL_MPU_GetChannelConfig() read-back;
 *   - the status of every channel is clear while only the configuration is
 *     exercised, and the disable / enable round trip works;
 *   - the call of the protected function is refused and sets the read
 *     protection status of all 16 channels, so RPTS reads 0x0000FFFF; the core
 *     stops on that fetch (no trap, no return), which is expected and is what
 *     the debugger check in step 5 confirms.
 * NOTE: A violation is recorded by the MPU (and forwarded to the FCU by its
 *       MPU0 channel).  Measured on the board a refused instruction fetch does
 *       not return and does not raise a trap, so unlike the original case this
 *       port cannot keep running after the violating call; every check that
 *       the firmware can make is printed before it.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Protected window: derived from the protected function address.
   The window starts on the cache line that holds the first instruction of the
   protected function and is 256 bytes long. */
#define TEST_RANGE_LENGTH           (256U)
#define TEST_RANGE_ALIGN            (0x3FU)

/* MPU instance under test (MPU0 = I-Bus instruction port) */
#define TEST_MPU_INSTANCE           (HAL_MPU_INSTANCE_0_IBUS)

/* Number of channels of MPU0 */
#define TEST_CHANNEL_COUNT          (16U)

/* Mask of the channels of MPU0 (the status of all of them is expected to be
   reported, because they all carry the same protected window) */
#define TEST_CHANNEL_MASK           (0xFFFFU)

/* Private variables ---------------------------------------------------------*/
static HAL_MPU_HandleTypeDef hmpu_dev;        /*!< MPU device handle           */
static uint32          failures = 0U;         /*!< failed checks               */

static MPU_Channel_TypeDef * const mpu0_channel[16] =
{
    MPU0_Channel0, MPU0_Channel1, MPU0_Channel2,  MPU0_Channel3,
    MPU0_Channel4, MPU0_Channel5, MPU0_Channel6,  MPU0_Channel7,
    MPU0_Channel8, MPU0_Channel9, MPU0_Channel10, MPU0_Channel11,
    MPU0_Channel12, MPU0_Channel13, MPU0_Channel14, MPU0_Channel15
};

static HAL_SMU_HandleTypeDef hsmu_clk;   /*!< SMU handle (lock / state / error) */

/* Volatile input / output of the protected function.  They are volatile so
   that the compiler cannot fold the arithmetic chain into a constant and drop
   the body, and they are globals (not locals) so that the function needs no
   stack frame. */
static volatile uint32 protect_seed = 1U;     /*!< input of the arithmetic    */
static volatile uint32 protect_sink = 0U;     /*!< side effect of the chain   */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void Check(const char *name, uint32 condition);
static void Read_EnableMasks(HAL_MPU_HandleTypeDef *hmpu, uint32 count,
                             uint32 *pten, uint32 *rpten, uint32 *wpten);

static uint32 Mpu_ProtectFunc(void);
static uint32 Iport_ReadStatus(void);

/* The call goes through a volatile function pointer on purpose: the function
   has no side effect that the compiler has to keep and its return value is not
   used by the test, so a direct "(void)Mpu_ProtectFunc();" is removed entirely
   at -Og and no instruction fetch of the protected range ever happens. */
static uint32 (* volatile pProtectFunc)(void) = Mpu_ProtectFunc;

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    uint32 start;
    uint32 end;
    uint32 ch;
    uint32 state;
    uint32 rd_pten;
    uint32 rd_rpten;
    uint32 rd_wpten;
    uint32 ok;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n\r\n ***** MPU Test ***** \r\n");
    printf("case : MPU_IT_DRV_002 (I-Port read protection, channels 0..15)\r\n");
    delay_ms(500U);

    /* ---- Step 1: protected range and per channel programming ----- */
    start = ((uint32)(unsigned long)&Mpu_ProtectFunc) & ~TEST_RANGE_ALIGN;
    end   = start + TEST_RANGE_LENGTH;

    printf("\r\n-----------------protected range----------------- \r\n");
    printf("SADDR / EADDR    : 0x%08X / 0x%08X\r\n", PRINT_U32(start), PRINT_U32(end));

    __HAL_CLEAR_STRUCT(&hmpu_dev);
    hmpu_dev.Instance = TEST_MPU_INSTANCE;
    /* The channel control functions require an initialized handle: this case
       drives them directly, so the READY state is set up explicitly (no
       channel is programmed by HAL_MPU_Init() here) */
    hmpu_dev.State = HAL_MPU_STATE_READY;

    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        HAL_MPU_SetAddressRange(&hmpu_dev, ch, start, end);
    }

    ok = 1U;
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        if ((mpu0_channel[ch]->SADDR != start) || (mpu0_channel[ch]->EADDR != end))
        {
            ok = 0U;
        }
    }
    Check("SADDR / EADDR of all 16 channels", ok);

    /* ---- Step 2: read protection and channel enable -------------- */
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        HAL_MPU_ReadProtectCmd(&hmpu_dev, ch, MPU_ENABLE);
    }
    Check("RPTEN = 0xFFFF",
          (((HAL_MPU_GetIPortBlock(TEST_MPU_INSTANCE)->RPTEN & 0xFFFFUL) == 0xFFFFUL) ? 1U : 0U));

    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        HAL_MPU_Cmd(&hmpu_dev, ch, MPU_ENABLE);
    }
    Check("PTEN = 0xFFFF",
          (((HAL_MPU_GetIPortBlock(TEST_MPU_INSTANCE)->PTEN & 0xFFFFUL) == 0xFFFFUL) ? 1U : 0U));
    /* read the enable masks back through the HAL API (V1.2); the direct
       register reads above stay as the white-box cross check */
    Read_EnableMasks(&hmpu_dev, TEST_CHANNEL_COUNT, &rd_pten, &rd_rpten, &rd_wpten);
    Check("RPTEN read back by HAL_MPU_GetChannelConfig",
          (((rd_rpten & 0xFFFFUL) == 0xFFFFUL) ? 1U : 0U));
    Check("PTEN read back by HAL_MPU_GetChannelConfig",
          (((rd_pten & 0xFFFFUL) == 0xFFFFUL) ? 1U : 0U));
    Check("no write protection enable (read protection case, HAL read-back)",
          ((rd_wpten == 0U) ? 1U : 0U));

    delay_ms(100U);

    /* ---- Step 3: status path, no violating fetch yet ------------- */
    /* Everything below runs with all 16 channels protected but without
       touching the protected range, so that the whole HAL configuration path
       of the case can be checked on the target. */
    printf("\r\n-----------------configuration------------------------ \r\n");

    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        HAL_MPU_ClearStatus(&hmpu_dev, ch);
    }
    state = Iport_ReadStatus();
    Check("RPTS = 0 before the violating fetch", ((state == 0U) ? 1U : 0U));

    ok = 1U;
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        if (HAL_MPU_GetReadProtectStatus(&hmpu_dev, ch) != 0U)
        {
            ok = 0U;
        }
    }
    Check("HAL_MPU_GetReadProtectStatus = 0 for all 16 channels", ok);

    /* disable / enable round trip of both control bits (no fetch involved) */
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        HAL_MPU_ReadProtectCmd(&hmpu_dev, ch, MPU_DISABLE);
        HAL_MPU_Cmd(&hmpu_dev, ch, MPU_DISABLE);
    }
    Check("RPTEN = 0 after the disable",
          (((HAL_MPU_GetIPortBlock(TEST_MPU_INSTANCE)->RPTEN & TEST_CHANNEL_MASK) == 0U) ? 1U : 0U));
    Check("PTEN = 0 after the disable",
          (((HAL_MPU_GetIPortBlock(TEST_MPU_INSTANCE)->PTEN & TEST_CHANNEL_MASK) == 0U) ? 1U : 0U));
    Check("status stays clear while the protection is disabled",
          ((Iport_ReadStatus() == 0U) ? 1U : 0U));

    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        HAL_MPU_ReadProtectCmd(&hmpu_dev, ch, MPU_ENABLE);
        HAL_MPU_Cmd(&hmpu_dev, ch, MPU_ENABLE);
    }
    Check("RPTEN = 0xFFFF after the re-enable",
          (((HAL_MPU_GetIPortBlock(TEST_MPU_INSTANCE)->RPTEN & TEST_CHANNEL_MASK) == TEST_CHANNEL_MASK) ? 1U : 0U));
    Check("PTEN = 0xFFFF after the re-enable",
          (((HAL_MPU_GetIPortBlock(TEST_MPU_INSTANCE)->PTEN & TEST_CHANNEL_MASK) == TEST_CHANNEL_MASK) ? 1U : 0U));

    /* the address ranges must have survived the whole round trip */
    ok = 1U;
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        if ((mpu0_channel[ch]->SADDR != start) || (mpu0_channel[ch]->EADDR != end))
        {
            ok = 0U;
        }
    }
    Check("SADDR / EADDR of all 16 channels after the round trip", ok);

    /* A status bit may be recorded while the configuration is exercised: the
       fetch unit prefetches ahead of the program counter, and a prefetched
       address inside the protected range is recorded even when it is not
       architecturally demanded (no trap follows, the core keeps running).
       Requiring the status to be untouched is therefore not a valid check;
       what has to hold is that the status can be cleared and reads 0 right
       before the trigger, which is what the case verifies here. */
    for (ch = 0U; ch < TEST_CHANNEL_COUNT; ch++)
    {
        HAL_MPU_ClearStatus(&hmpu_dev, ch);
    }
    Check("status cleared right before the violating fetch",
          ((Iport_ReadStatus() == 0U) ? 1U : 0U));

    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(failures));

    /* ---- Step 4: the violating fetch ---------------------------- */
    /* This is the step the whole case is about.  Measured on the board: the
       refused instruction fetch does NOT complete and does NOT raise a trap;
       the core stops on it (the debugger loses the hart as well), while the
       violation is recorded.  All 16 channels carry the same window, so the
       status of all of them is expected (RPTS = 0x0000FFFF).  There is
       therefore no way to continue in the same run: the status cannot be read
       and cleared from the firmware, and the case is written so that every
       check that can be made from the firmware has already been printed above.
       Use the debugger to confirm the recorded violation, then reset the board
       to run the case again. */
    printf("\r\n-----------------violating fetch----------------- \r\n");
    printf("the next instruction fetch enters the protected range of MPU0,\r\n");
    printf("it is refused, and the core stops on it (no trap, no return).\r\n");
    printf("expected on the debugger : MPU0 RPTS = 0x%08X\r\n",
           PRINT_U32(TEST_CHANNEL_MASK));
    printf("reset the board to run the case again.\r\n");
    delay_ms(500U);

    /* The cache has to be cleared first: a fetch that is served from the
       cache never reaches the bus, so it is neither refused nor recorded (and
       a line left over from a previous image would let stale code run as
       well).  This is the call the original case uses before its trigger. */
    CLEAR_CACHE();
    (void)pProtectFunc();          /* the core stops on this fetch */

    /* not reached */
    while (1)
    {
    }
}

/**
 * @brief  Read the read-protection status of the MPU0 instruction port.
 * @note   MPU0 uses the I-Port register layout (PTEN / RPTEN / RPTS), which
 *         differs from the D-Port layout of MPU1..MPU4.
 * @param  None
 * @retval RPTS register value.
 */
static uint32 Iport_ReadStatus(void)
{
    return (uint32)HAL_MPU_GetIPortBlock(TEST_MPU_INSTANCE)->RPTS;
}

/**
 * @brief  The protected function.
 * @note   Placement matters: the function lives in a section of its own
 *         (.text.mpu_test, collected by the "*(.text.*)" rule of the linker
 *         script) and is 64-byte aligned, so its first instruction starts on a
 *         cache line boundary and the whole line belongs to this function.
 * @note   Length matters as well: an instruction fetch that is served from the
 *         cache never reaches the bus, and the I-Port read protection only
 *         reports the fetches that do reach it.  A two instruction body would
 *         be covered by the line the surrounding code had already fetched and
 *         no violation would be reported at all - that is exactly what the
 *         first revision of this port did.  The arithmetic chain below keeps
 *         the body several cache lines long.
 * @note   No stack frame: the chain works on registers and global volatile
 *         variables only, so the function body is self contained.
 * @param  None
 * @retval 3 (a + b).  The chain feeds protect_sink and is what makes the
 *         compiler emit the body at all.
 */
static uint32 __attribute__((noinline, section(".text.mpu_test"), aligned(64)))
Mpu_ProtectFunc(void)
{
    uint32 a = 1U;
    uint32 b = 2U;
    uint32 v = protect_seed;

    v = (v * 3U) + 1U;      v = (v >> 1) + 5U;      v = (v * 5U) + 3U;      v = v ^ 0x00A5A5A5U;
    v = (v * 3U) + 1U;      v = (v >> 1) + 5U;      v = (v * 5U) + 3U;      v = v ^ 0x00A5A5A5U;
    v = (v * 3U) + 1U;      v = (v >> 1) + 5U;      v = (v * 5U) + 3U;      v = v ^ 0x00A5A5A5U;
    v = (v * 3U) + 1U;      v = (v >> 1) + 5U;      v = (v * 5U) + 3U;      v = v ^ 0x00A5A5A5U;
    v = (v * 3U) + 1U;      v = (v >> 1) + 5U;      v = (v * 5U) + 3U;      v = v ^ 0x00A5A5A5U;
    v = (v * 3U) + 1U;      v = (v >> 1) + 5U;      v = (v * 5U) + 3U;      v = v ^ 0x00A5A5A5U;
    v = (v * 3U) + 1U;      v = (v >> 1) + 5U;      v = (v * 5U) + 3U;      v = v ^ 0x00A5A5A5U;
    v = (v * 3U) + 1U;      v = (v >> 1) + 5U;      v = (v * 5U) + 3U;      v = v ^ 0x00A5A5A5U;
    v = (v * 3U) + 1U;      v = (v >> 1) + 5U;      v = (v * 5U) + 3U;      v = v ^ 0x00A5A5A5U;
    v = (v * 3U) + 1U;      v = (v >> 1) + 5U;      v = (v * 5U) + 3U;      v = v ^ 0x00A5A5A5U;

    protect_sink = v;

    return (a + b);
}


/**
 * @brief  Rebuild the channel enable / protection enable masks of a MPU
 *         instance by reading the configuration of every channel back through
 *         HAL_MPU_GetChannelConfig().
 * @note   The driver provides the configuration read-back interface from V1.2
 *         on: the masks let the case check the programmed enables through the
 *         HAL API in addition to the direct PTEN / RPTEN / WPTEN reads of the
 *         original test case.
 * @param  hmpu: pointer to the MPU handle.
 * @param  count: number of channels of the instance (16 or 8).
 * @param  pten: receives the channel enable mask.
 * @param  rpten: receives the read protection enable mask.
 * @param  wpten: receives the write protection enable mask.
 * @retval None
 */
static void Read_EnableMasks(HAL_MPU_HandleTypeDef *hmpu, uint32 count,
                             uint32 *pten, uint32 *rpten, uint32 *wpten)
{
    uint32 i;
    MPU_InitTypeDef cfg;

    *pten  = 0U;
    *rpten = 0U;
    *wpten = 0U;

    for (i = 0U; i < count; i++)
    {
        __HAL_CLEAR_STRUCT(&cfg);

        if (HAL_MPU_GetChannelConfig(hmpu, i, &cfg) == HAL_OK)
        {
            *pten  |= ((uint32)cfg.ChannelEnable      << i);
            *rpten |= ((uint32)cfg.ReadProtectEnable  << i);
            *wpten |= ((uint32)cfg.WriteProtectEnable << i);
        }
    }
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition == 0U)
    {
        failures++;
    }
    printf("%-46s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Configure the system clock tree using the HAL SMU / PMU drivers.
 * @note   Same clock tree as the CLINT / CMU reference suites: OSC 20 MHz as
 *         the PLL source, PLLDivN = 20 / PLLDivF = 180 / PLLDivQ = 1 /
 *         PLLDivR = 4 -> 180 MHz VCO, AXI4Bus3 = /2, APBBus0 = /2,
 *         APBBus1 = /2, CANX2 = /8; the 2.5V LDO is scaled to 2.78 V and the
 *         1.2V LDO to 1.34 V as in the reference suites.
 * @note   Clock tree order (the order the chip requires, and the order the
 *         vendor test case uses): configure the oscillators and the PLL and
 *         switch the system clock to it, then write the bus clock dividers.
 *         HAL_SMU_OscConfig() programs the EFLASH controller clock (CLKFRQ)
 *         before the switch and lets it follow the new system clock afterwards
 *         (EFLASH_CLK_UPDATE), so no explicit HAL_FLASH_SetClockFrequency() is
 *         needed here; it also updates SystemCoreClock together with the HAL
 *         time base.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef  SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef   SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Enable the bus clock gates (same clock tree as the original test) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Configure the PLL and switch the system clock to it. From this point the
       core runs at the PLL frequency, and the flash controller is already
       programmed for it (CLKFRQ above), so the code keeps running from Flash. */
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Set the bus clock dividers (the system clock source is already set by
       HAL_SMU_OscConfig() above) */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/

