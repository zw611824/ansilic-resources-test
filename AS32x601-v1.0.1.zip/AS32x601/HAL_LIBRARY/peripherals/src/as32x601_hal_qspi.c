/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_qspi.c
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.3
 * Date:   2026/09/18
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.1     review pass: remove all goto
 *                                                       statements, align the wait
 *                                                       helper timeout return with
 *                                                       the documentation, add a
 *                                                       runtime DataMode check in
 *                                                       AutoPolling / MemoryMapped,
 *                                                       protect Abort with the BUSY
 *                                                       flag and reset CCR.FMODE on
 *                                                       abort completion
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.2     review pass: verified the
 *                                                       transfer trigger points
 *                                                       (indirect read started by the
 *                                                       AR write, indirect write by
 *                                                       the DR write, instruction /
 *                                                       auto-polling / memory-mapped
 *                                                       by the CCR write); clarified
 *                                                       the QSPI_Config and Transmit /
 *                                                       Receive comments
 *     ANSILIC APPLICATION GROUP  2026/09/18     1.3     apply the resource lock and RTOS
 *                                                       rules: replace the
 *                                                       __HAL_LOCK macro by the
 *                                                       QSPI_LockHandle() /
 *                                                       QSPI_UnlockHandle() pair
 *                                                       (Timeout parameter and
 *                                                       uncreated-mutex guard,
 *                                                       RTOS-11), lock
 *                                                       HAL_QSPI_SetTimeout()
 *                                                       (LOCK-01), take the lock
 *                                                       inside HAL_QSPI_Abort()
 *                                                       instead of releasing a
 *                                                       lock owned by another
 *                                                       context (LOCK-01 /
 *                                                       LOCK-02), move the MSP
 *                                                       callbacks out of the
 *                                                       locked regions
 *                                                       (MSP-04 / LOCK-06), stop
 *                                                       releasing the bare-metal
 *                                                       lock inside the Init
 *                                                       locked region, add the
 *                                                       QSPI_CheckState() gate
 *                                                       with the recoverable
 *                                                       error state, the
 *                                                       transfer_started guard
 *                                                       and the
 *                                                       HAL_QSPI_STATE_IS_BUSY()
 *                                                       test (ARCH-CONST-09,
 *                                                       STATE-04 / STATE-06),
 *                                                       route the flag reads
 *                                                       through the lock-free
 *                                                       QSPI_GetFlagStatusInternal()
 *                                                       helper (LOCK-05), hand
 *                                                       the state and error code
 *                                                       bookkeeping over to the
 *                                                       callers of the wait
 *                                                       helper, validate the
 *                                                       operation parameters
 *                                                       before the lock is taken,
 *                                                       yield from the blocking
 *                                                       wait loop (RTOS-04 /
 *                                                       RTOS-05), document the
 *                                                       blocking behaviour of
 *                                                       every API (POLL-04), and
 *                                                       drop the unused
 *                                                       HAL_QSPI_STATE_ABORT and
 *                                                       HAL_QSPI_ERROR_TRANSFER
 *                                                       definitions
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the Quad Serial Peripheral
 *                  Interface (QSPI) of the AS32x601:
 *                  - Initialization and de-initialization;
 *                  - Command sequences: instruction / address / alternate
 *                    bytes / dummy cycles / data phases on 1, 2 or 4 lines;
 *                  - Polling IO operations: transmit / receive with timeout
 *                    (up to 4 bytes per transfer in polling mode);
 *                  - Auto-polling functional mode (match / mask / interval);
 *                  - Memory-mapped functional mode (AHB mapped window at
 *                    QSPI_FLASH_BASE);
 *                  - Low level register access functions.
 *
 *                  Typical usage of the indirect write mode:
 *                  (#) Configure the command sequence with
 *                      HAL_QSPI_Command() (instruction + data phase), then
 *                      push the data with HAL_QSPI_Transmit();
 *                  Typical usage of the indirect read mode:
 *                  (#) Configure the command sequence with
 *                      HAL_QSPI_Command() (instruction + data phase), then
 *                      fetch the data with HAL_QSPI_Receive() (the read
 *                      transfer is started inside HAL_QSPI_Receive() by
 *                      re-writing the address register);
 *                  Typical usage of the auto-polling mode:
 *                  (#) HAL_QSPI_AutoPolling() with the command sequence and
 *                      the match / mask / interval configuration; the
 *                      function returns once the masked status matches
 *                      (e.g. the busy bit of the attached device cleared);
 *                  Typical usage of the memory-mapped mode:
 *                  (#) HAL_QSPI_MemoryMapped(), then read the attached
 *                      device through the window at QSPI_FLASH_BASE
 *                      (0x10000000);
 *                  The device specific sequences (write enable, erase,
 *                  program, status register access, ...) are built by the
 *                  application from the functions of this module.
 *
 *                  Concurrency follows the architecture resource lock rules
 *                  (section 13): every API that changes the handle state is
 *                  serialized through the QSPI_LockHandle() /
 *                  QSPI_UnlockHandle() pair (bare-metal lock flag, or an RTOS
 *                  mutex with a bounded wait), the QSPI_CheckState() gate
 *                  rejects a new operation while another one is ongoing and
 *                  accepts the recoverable error state so that a failed
 *                  operation can be retried without a DeInit / Init round
 *                  trip (STATE-06), the operation parameters are validated
 *                  before the lock is taken, and the low level register
 *                  access functions stay lock-free so that they remain usable
 *                  from an interrupt service routine (LOCK-04 / RTOS-12).
 *                  The waiting helper never takes the lock and never touches
 *                  the handle state: it reads the flags through the lock-free
 *                  QSPI_GetFlagStatusInternal() helper and leaves the state /
 *                  error code bookkeeping to its callers.
 */
#include "as32x601_hal.h"          /* HAL_GetTick() / HAL_MAX_DELAY            */
#include "as32x601_hal_qspi.h"     /* QSPI HAL API and register macros         */

/* The HAL_QSPI_MODULE_ENABLED switch is provided by the user configuration
 * file (as32x601_hal_conf.h, included above through as32x601_hal.h): the
 * whole implementation is compiled only while the module is enabled. */
#ifdef HAL_QSPI_MODULE_ENABLED

/* Private define ------------------------------------------------------------*/

/* Functional mode codes, pre-positioned in the CCR FMODE field */
#define QSPI_FUNCTIONAL_MODE_INDIRECT_WRITE ((uint32)0x00000000U) /*!< Indirect write mode  */
#define QSPI_FUNCTIONAL_MODE_INDIRECT_READ  ((uint32)QSPI_CCR_FMODE_0) /*!< Indirect read mode   */
#define QSPI_FUNCTIONAL_MODE_AUTO_POLLING   ((uint32)QSPI_CCR_FMODE_1) /*!< Auto-polling mode    */
#define QSPI_FUNCTIONAL_MODE_MEMORY_MAPPED  ((uint32)QSPI_CCR_FMODE)   /*!< Memory-mapped mode   */

/* Maximum number of bytes transferred in one polling transmit / receive:
 * the data FIFO of the controller is accessed as a single 32-bit word in
 * polling mode */
#define QSPI_POLLING_MAX_BYTES              ((uint32)4U)

/* Private macros ------------------------------------------------------------*/

/**
 * @brief  Check that the functional mode is valid.
 */
#define IS_QSPI_FUNCTIONAL_MODE(MODE) (((MODE) == QSPI_FUNCTIONAL_MODE_INDIRECT_WRITE) || \
                                       ((MODE) == QSPI_FUNCTIONAL_MODE_INDIRECT_READ)  || \
                                       ((MODE) == QSPI_FUNCTIONAL_MODE_AUTO_POLLING)   || \
                                       ((MODE) == QSPI_FUNCTIONAL_MODE_MEMORY_MAPPED))

/* Private function prototypes -----------------------------------------------*/
static HAL_StatusTypeDef QSPI_WaitFlagStateUntilTimeout(HAL_QSPI_HandleTypeDef *hqspi, uint32 Flag, uint32 State,
                                                        uint32 Timeout);
static void QSPI_Config(HAL_QSPI_HandleTypeDef *hqspi, QSPI_CommandTypeDef *cmd, uint32 FunctionalMode);
static uint32 QSPI_GetFlagStatusInternal(HAL_QSPI_HandleTypeDef *hqspi, uint32 QSPI_FLAG);

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Check whether the handle accepts a new operation.
 * @note   Architecture constraint ARCH-CONST-09: while an operation is ongoing
 *         (any busy state, i.e. any state with bit 1 set) another operation is
 *         rejected with HAL_BUSY, and an uninitialized handle (RESET) requires
 *         HAL_QSPI_Init() first and is rejected with HAL_ERROR. The error
 *         state is recoverable and is accepted, because the entry point of an
 *         operation resets the handle state to busy, so a failed operation can
 *         be retried without a DeInit / Init round trip (STATE-04 /
 *         STATE-06). HAL_QSPI_Abort() and HAL_QSPI_DeInit() deliberately do
 *         not call this helper: they are accepted in every state.
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK (accepted) / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef QSPI_CheckState(HAL_QSPI_HandleTypeDef *hqspi)
{
    if (hqspi == NULL_PTR)
    {
        return HAL_ERROR;
    }

    if (HAL_QSPI_STATE_IS_BUSY(hqspi->State) != 0U)
    {
        return HAL_BUSY;
    }

    if (hqspi->State == HAL_QSPI_STATE_RESET)
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Read a QSPI status flag without the handle lock.
 * @note   Private body shared by the public HAL_QSPI_GetFlagStatus() and by
 *         the internal wait helper, which is called while the handle lock is
 *         held by the calling API. It takes no lock and checks no state, so
 *         that it stays callable from an interrupt service routine too
 *         (LOCK-04 / LOCK-05 / RTOS-12).
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  QSPI_FLAG: the flag to check (QSPI_FLAG_xxx).
 * @retval uint32: 1 if the flag is set, 0 otherwise.
 */
static uint32 QSPI_GetFlagStatusInternal(HAL_QSPI_HandleTypeDef *hqspi, uint32 QSPI_FLAG)
{
    return ((hqspi->Instance->SR & QSPI_FLAG) != 0U) ? 1U : 0U;
}

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_QSPI_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; when the mutex is not acquired before the
 *         Timeout expires, HAL_TIMEOUT is returned. The value is passed to
 *         HAL_MutexAcquire() as is (RTOS ticks; with the usual 1 ms tick it is
 *         the same quantity as the millisecond Timeout of the public API, and
 *         HAL_MAX_DELAY means an infinite wait).
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef QSPI_LockHandle(HAL_QSPI_HandleTypeDef *hqspi, uint32 Timeout)
{
#if (USE_RTOS == 1)
    if (hqspi->LockMutex == NULL_PTR)
    {
        /* The porting layer did not create the mutex (e.g. HAL_QSPI_MspInit()
         * was not overridden): report it instead of calling the RTOS with a
         * NULL handle */
        return HAL_ERROR;
    }

    return HAL_MutexAcquire(hqspi->LockMutex, Timeout);
#else
    /* Prevent unused argument compilation warning: the bare-metal lock flag
     * either succeeds immediately or reports HAL_BUSY, it never waits */
    UNUSED(Timeout);

    if (hqspi->Lock == HAL_LOCKED)
    {
        return HAL_BUSY;
    }

    hqspi->Lock = HAL_LOCKED;

    return HAL_OK;
#endif /* USE_RTOS */
}

/**
 * @brief  Unlock the handle.
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @retval None
 */
void QSPI_UnlockHandle(HAL_QSPI_HandleTypeDef *hqspi)
{
#if (USE_RTOS == 1)
    (void)HAL_MutexRelease(hqspi->LockMutex);
#else
    hqspi->Lock = HAL_UNLOCKED;
#endif /* USE_RTOS */
}

/**
 * @brief  Wait for a given flag to reach the expected state, with timeout.
 * @note   The wait is bounded by the caller supplied Timeout, measured with
 *         the HAL 1 ms time base (HAL_GetTick()). In an RTOS build the loop
 *         yields the CPU on every iteration so that a lower or equal priority
 *         task is not starved by the busy wait (RTOS-04 / RTOS-05).
 * @note   The helper takes no lock and does not touch the handle state: the
 *         register read goes through the lock-free
 *         QSPI_GetFlagStatusInternal() helper (LOCK-05) and the callers own
 *         the state / error code bookkeeping, so that it stays callable from
 *         an interrupt service routine (LOCK-04).
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  Flag: the QSPI status flag to wait for (QSPI_FLAG_xxx).
 * @param  State: expected flag state (1 = set, 0 = reset).
 * @param  Timeout: maximum waiting time in ms (HAL_MAX_DELAY for infinite).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT
 */
static HAL_StatusTypeDef QSPI_WaitFlagStateUntilTimeout(HAL_QSPI_HandleTypeDef *hqspi, uint32 Flag, uint32 State,
                                                        uint32 Timeout)
{
    uint32 tickstart = HAL_GetTick();
    uint32 flagstate = QSPI_GetFlagStatusInternal(hqspi, Flag);

    /* Poll the flag until it reaches the expected state */
    while (flagstate != State)
    {
        /* Check the timeout */
        if ((Timeout != HAL_MAX_DELAY) && ((HAL_GetTick() - tickstart) >= Timeout))
        {
            /* Flag not reached within the timeout */
            return HAL_TIMEOUT;
        }

#if (USE_RTOS == 1)
        /* RTOS-04: let the other tasks of the same priority run instead of
         * busy waiting (empty macro in a bare-metal build, RTOS-05) */
        HAL_RTOS_Yield();
#endif /* USE_RTOS */

        flagstate = QSPI_GetFlagStatusInternal(hqspi, Flag);
    }

    return HAL_OK;
}

/**
 * @brief  Configure the communication registers (DLR / ABR / AR / CCR) from
 *         the command sequence and the functional mode.
 * @note   The writing of the CCR register (last write of this function)
 *         programs the command sequence; it starts the sequence itself for
 *         the instruction-only commands, the auto-polling mode and the
 *         memory-mapped mode. For a data phase the sequence is started
 *         later by the data flow: by the AR write inside HAL_QSPI_Receive()
 *         (indirect read) or by the DR write inside HAL_QSPI_Transmit()
 *         (indirect write). The address and the data length are not
 *         programmed in the memory-mapped mode: the AHB access provides
 *         the address and runs the transfer.
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  cmd: pointer to a QSPI_CommandTypeDef structure that contains the
 *         command sequence configuration.
 * @param  FunctionalMode: the functional mode code (QSPI_FUNCTIONAL_MODE_xxx).
 * @retval None
 */
static void QSPI_Config(HAL_QSPI_HandleTypeDef *hqspi, QSPI_CommandTypeDef *cmd, uint32 FunctionalMode)
{
    uint32 reg = 0U;

    assert_param(IS_QSPI_FUNCTIONAL_MODE(FunctionalMode));

    /* Data length: programmed only in the indirect and auto-polling modes */
    if ((cmd->DataMode != QSPI_DATA_NONE) && (FunctionalMode != QSPI_FUNCTIONAL_MODE_MEMORY_MAPPED))
    {
        hqspi->Instance->DLR = (cmd->NbData - 1U);
    }

    /* Alternate bytes */
    if (cmd->AlternateByteMode != QSPI_ALTERNATE_BYTES_NONE)
    {
        hqspi->Instance->ABR = cmd->AlternateBytes;
    }

    /* Address (the memory-mapped mode gets the address from the AHB bus) */
    if ((cmd->AddressMode != QSPI_ADDRESS_NONE) && (FunctionalMode != QSPI_FUNCTIONAL_MODE_MEMORY_MAPPED))
    {
        hqspi->Instance->AR = cmd->Address;
    }

    /* Assemble and write the CCR: writing the CCR starts the sequence */
    reg = (cmd->Instruction | cmd->InstructionMode | cmd->AddressMode | cmd->AddressSize |
           cmd->AlternateByteMode | cmd->AlternateBytesSize |
           ((cmd->DummyCycles) << QSPI_CCR_DUMMY_Pos) | cmd->DataMode | FunctionalMode);
    hqspi->Instance->CCR = reg;
}

/* Exported functions ---------------------------------------------------------*/

/** @addtogroup QSPI_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Fills each QSPI_InitStruct member with its default value
 *         (prescaler = 2, chip select high time = 7 cycles, clock mode 0). (NON-BLOCKING)
 * @param  QSPI_InitStruct: pointer to a QSPI_InitTypeDef structure which
 *         will be initialized.
 * @retval None
 */
void HAL_QSPI_StructInit(QSPI_InitTypeDef *QSPI_InitStruct)
{
    if (QSPI_InitStruct == NULL_PTR)
    {
        return;
    }

    QSPI_InitStruct->Size               = sizeof(QSPI_InitTypeDef);
    QSPI_InitStruct->Version            = QSPI_INIT_VERSION;

    QSPI_InitStruct->ClockPrescaler     = 2U;              /*!< Minimum valid prescaler */
    QSPI_InitStruct->ChipSelectHighTime = QSPI_CS_HIGH_TIME_7_CYCLE;
    QSPI_InitStruct->ClockMode          = QSPI_CLOCK_MODE_0;
    QSPI_InitStruct->Reserved[0]        = 0U;              /*!< Reserved for future use */
    QSPI_InitStruct->Reserved[1]        = 0U;              /*!< Reserved for future use */
}

/**
 * @brief  Initializes the QSPI according to the specified parameters in the
 *         QSPI_InitStruct of the handle. (NON-BLOCKING)
 * @note   The QSPI clock gating and the pin multiplexing must be configured
 *         by the user in HAL_QSPI_MspInit().
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_QSPI_Init(HAL_QSPI_HandleTypeDef *hqspi)
{
    HAL_StatusTypeDef status = HAL_OK;
    uint32 reg = 0U;

    /* Check the QSPI peripheral handle */
    if (hqspi == NULL_PTR)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_QSPI_ALL_INSTANCE(hqspi->Instance));
    assert_param(IS_QSPI_CLOCK_PRESCALER(hqspi->Init.ClockPrescaler));
    assert_param(IS_QSPI_CS_HIGH_TIME(hqspi->Init.ChipSelectHighTime));
    assert_param(IS_QSPI_CLOCK_MODE(hqspi->Init.ClockMode));

    /* Re-check the configuration at run time: assert_param() is compiled out
     * when USE_FULL_ASSERT is not defined. The request is rejected before any
     * register access and before the lock is taken, and the handle state is
     * left untouched, so a rejected call neither enters a busy state nor
     * consumes the lock (ARCH-CONST-10 / ERR-03). */
    if (((IS_QSPI_ALL_INSTANCE(hqspi->Instance)) == 0U) ||
        ((IS_QSPI_CLOCK_PRESCALER(hqspi->Init.ClockPrescaler)) == 0U) ||
        ((IS_QSPI_CS_HIGH_TIME(hqspi->Init.ChipSelectHighTime)) == 0U) ||
        ((IS_QSPI_CLOCK_MODE(hqspi->Init.ClockMode)) == 0U))
    {
        hqspi->ErrorCode |= HAL_QSPI_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* MSP-04: initialize the MSP on the first initialization only, while the
     * handle is still in the reset state, and before the first register access
     * so that the peripheral clock and the pin multiplexing are available.
     * LOCK-06: the callback runs before the lock is taken, hence it may use
     * other HAL APIs. The lock object is initialized here as well: doing it
     * inside the locked region below would release the bare-metal lock flag
     * in the middle of the protected operation. */
    if (hqspi->State == HAL_QSPI_STATE_RESET)
    {
        hqspi->Lock = HAL_UNLOCKED;

        HAL_QSPI_MspInit(hqspi);

        /* Configure the default timeout for the internal waits */
        hqspi->Timeout = HAL_QSPI_TIMEOUT_DEFAULT_VALUE;
    }

    /* Process locked */
    if (QSPI_LockHandle(hqspi, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Enter the busy state and clear the error code (ARCH-CONST-10) */
    hqspi->State     = HAL_QSPI_STATE_BUSY;
    hqspi->ErrorCode = HAL_QSPI_ERROR_NONE;

    /* Wait until the BUSY flag is reset before reconfiguring the CR */
    status = QSPI_WaitFlagStateUntilTimeout(hqspi, QSPI_FLAG_BUSY, 0U, hqspi->Timeout);
    if (status == HAL_OK)
    {
        /* Set the PRESCALER / CSHT / CKMODE fields, keep the other CR bits */
        reg = hqspi->Instance->CR;
        reg &= ~(uint32)(QSPI_CR_PRESCALER | QSPI_CR_CSHT | QSPI_CR_CKMODE);
        reg |= (uint32)(((hqspi->Init.ClockPrescaler - 1U) << QSPI_CR_PRESCALER_Pos) |
                        hqspi->Init.ChipSelectHighTime | hqspi->Init.ClockMode);
        hqspi->Instance->CR = reg;

        /* Enable the QSPI peripheral */
        __HAL_QSPI_ENABLE(hqspi);

        hqspi->State = HAL_QSPI_STATE_READY;
    }
    else
    {
        /* STATE-03: the failed initialization leaves the recoverable error
         * state; the error code carries the reason */
        hqspi->ErrorCode |= HAL_QSPI_ERROR_TIMEOUT;
        hqspi->State = HAL_QSPI_STATE_ERROR;
    }

    /* Process unlocked */
    QSPI_UnlockHandle(hqspi);

    return status;
}

/**
 * @brief  De-initializes the QSPI peripheral. (NON-BLOCKING)
 * @note   HAL_QSPI_MspDeInit() is called after the handle lock has been
 *         released, so the callback may use other HAL APIs (LOCK-06).
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR
 */
HAL_StatusTypeDef HAL_QSPI_DeInit(HAL_QSPI_HandleTypeDef *hqspi)
{
    /* Check the QSPI handle allocation */
    if (hqspi == NULL_PTR)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_QSPI_ALL_INSTANCE(hqspi->Instance));

    /* Process locked */
    if (QSPI_LockHandle(hqspi, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    /* Enter the busy state and clear the error code (ARCH-CONST-10) */
    hqspi->State     = HAL_QSPI_STATE_BUSY;
    hqspi->ErrorCode = HAL_QSPI_ERROR_NONE;

    /* Disable the QSPI peripheral */
    __HAL_QSPI_DISABLE(hqspi);

    /* Reset the handle state */
    hqspi->State = HAL_QSPI_STATE_RESET;

    /* Process unlocked */
    QSPI_UnlockHandle(hqspi);

    /* LOCK-06: de-initialize the MSP after the lock has been released, so the
     * callback may use other HAL APIs */
    HAL_QSPI_MspDeInit(hqspi);

    return HAL_OK;
}

/**
 * @brief  Initializes the QSPI MSP. Weak empty function; the user implements
 *         the low level hardware initialization.
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_QSPI_MspInit(HAL_QSPI_HandleTypeDef *hqspi)
{
    UNUSED(hqspi);
}

/**
 * @brief  De-initializes the QSPI MSP. Weak empty function; the user
 *         implements the low level hardware de-initialization.
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_QSPI_MspDeInit(HAL_QSPI_HandleTypeDef *hqspi)
{
    UNUSED(hqspi);
}

/**
  * @}
  */

/** @addtogroup QSPI_Exported_Functions_Group2 IO operation functions
  * @{
  */

/**
 * @brief  Sends a command sequence to the attached device in blocking mode. (BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  cmd: pointer to a QSPI_CommandTypeDef structure that contains the
 *         command sequence configuration.
 * @param  Timeout: maximum waiting time in ms (HAL_MAX_DELAY for infinite).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_QSPI_Command(HAL_QSPI_HandleTypeDef *hqspi, QSPI_CommandTypeDef *cmd, uint32 Timeout)
{
    HAL_StatusTypeDef status = HAL_OK;
    uint32 transfer_started = 0U;

    /* Check the QSPI handle and the command structure */
    if ((hqspi == NULL_PTR) || (cmd == NULL_PTR))
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_QSPI_ALL_INSTANCE(hqspi->Instance));
    assert_param(IS_QSPI_INSTRUCTION_MODE(cmd->InstructionMode));
    if (cmd->InstructionMode != QSPI_INSTRUCTION_NONE)
    {
        assert_param(IS_QSPI_INSTRUCTION(cmd->Instruction));
    }
    assert_param(IS_QSPI_ADDRESS_MODE(cmd->AddressMode));
    if (cmd->AddressMode != QSPI_ADDRESS_NONE)
    {
        assert_param(IS_QSPI_ADDRESS_SIZE(cmd->AddressSize));
    }
    assert_param(IS_QSPI_ALTERNATE_BYTES_MODE(cmd->AlternateByteMode));
    if (cmd->AlternateByteMode != QSPI_ALTERNATE_BYTES_NONE)
    {
        assert_param(IS_QSPI_ALTERNATE_BYTES_SIZE(cmd->AlternateBytesSize));
    }
    assert_param(IS_QSPI_DUMMY_CYCLES(cmd->DummyCycles));
    assert_param(IS_QSPI_DATA_MODE(cmd->DataMode));
    if (cmd->DataMode != QSPI_DATA_NONE)
    {
        assert_param(IS_QSPI_NBDATA(cmd->NbData));
    }

    /* Reject an invalid command sequence before the lock is taken: the
     * invalid parameter error is reported without changing the handle state
     * and without consuming the lock (ARCH-CONST-10 / ERR-03). In polling mode
     * a data phase is limited to one FIFO word (4 bytes); a 0 value would
     * program an enormous length. */
    if ((cmd->DataMode != QSPI_DATA_NONE) &&
        ((cmd->NbData < 1U) || (cmd->NbData > QSPI_POLLING_MAX_BYTES)))
    {
        hqspi->ErrorCode |= HAL_QSPI_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Process locked */
    if (QSPI_LockHandle(hqspi, Timeout) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    do
    {
        /* ARCH-CONST-09: reject a new command while another operation is
         * ongoing; the recoverable error state accepts a retry without a
         * DeInit / Init round trip (STATE-06) */
        status = QSPI_CheckState(hqspi);
        if (status != HAL_OK)
        {
            /* The handle is busy with another operation or has not been
             * initialized: report it without touching the state of the
             * ongoing operation */
            break;
        }

        transfer_started = 1U;

        hqspi->ErrorCode = HAL_QSPI_ERROR_NONE;
        hqspi->State = HAL_QSPI_STATE_BUSY;

        /* Wait until the BUSY flag is reset before reconfiguring the
           controller */
        status = QSPI_WaitFlagStateUntilTimeout(hqspi, QSPI_FLAG_BUSY, 0U, Timeout);
        if (status != HAL_OK)
        {
            hqspi->ErrorCode |= HAL_QSPI_ERROR_TIMEOUT;
            break;
        }

        /* Configure the command sequence in the indirect write functional
           mode */
        QSPI_Config(hqspi, cmd, QSPI_FUNCTIONAL_MODE_INDIRECT_WRITE);

        if (cmd->DataMode == QSPI_DATA_NONE)
        {
            /* No data phase: the sequence completes as soon as the CCR is
               written, wait until the transfer complete flag is set */
            status = QSPI_WaitFlagStateUntilTimeout(hqspi, QSPI_FLAG_TCF, 1U, Timeout);
            if (status != HAL_OK)
            {
                hqspi->ErrorCode |= HAL_QSPI_ERROR_TIMEOUT;
                break;
            }
            __HAL_QSPI_CLEAR_FLAG(hqspi, QSPI_CLEAR_CTCF);
        }

        /* With a data phase the transfer is continued by HAL_QSPI_Transmit()
           / HAL_QSPI_Receive(); the handle goes back to the READY state so
           that the data transfer functions can be entered */
        hqspi->State = HAL_QSPI_STATE_READY;
    }
    while (0U);

    /* Only an operation that was actually started owns the handle state: a
     * rejected request (busy handle) leaves the state of the other operation
     * untouched (ARCH-CONST-09) */
    if ((transfer_started != 0U) && (status != HAL_OK))
    {
        hqspi->State = HAL_QSPI_STATE_ERROR;
    }

    /* Process unlocked */
    QSPI_UnlockHandle(hqspi);

    return status;
}

/**
 * @brief  Transmits the data of an indirect write command in blocking mode. (BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  pData: pointer to the data buffer to transmit.
 * @param  Timeout: maximum waiting time in ms (HAL_MAX_DELAY for infinite).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_QSPI_Transmit(HAL_QSPI_HandleTypeDef *hqspi, uint8 *pData, uint32 Timeout)
{
    HAL_StatusTypeDef status = HAL_OK;
    uint32 xfercount = 0U;
    uint32 data = 0U;
    uint32 reg = 0U;
    uint32 i = 0U;
    uint32 transfer_started = 0U;

    /* Check the QSPI handle and the data buffer */
    if ((hqspi == NULL_PTR) || (pData == NULL_PTR))
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_QSPI_ALL_INSTANCE(hqspi->Instance));

    /* Process locked */
    if (QSPI_LockHandle(hqspi, Timeout) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    do
    {
        /* ARCH-CONST-09: reject a new transfer while another operation is
         * ongoing; the recoverable error state accepts a retry without a
         * DeInit / Init round trip (STATE-06) */
        status = QSPI_CheckState(hqspi);
        if (status != HAL_OK)
        {
            /* The handle is busy with another operation or has not been
             * initialized: report it without touching the state of the
             * ongoing operation */
            break;
        }

        transfer_started = 1U;

        hqspi->ErrorCode = HAL_QSPI_ERROR_NONE;

        /* Transfer size is the DLR content + 1 (programmed by HAL_QSPI_Command) */
        xfercount = (hqspi->Instance->DLR & QSPI_DLR_DATALENGTH_Msk) + 1U;

        /* Polling transfers are limited to one FIFO word (4 bytes). The
         * length is rejected before the busy state is entered, so a rejected
         * call leaves the handle state untouched (ARCH-CONST-10 / ERR-03). */
        if (xfercount > QSPI_POLLING_MAX_BYTES)
        {
            hqspi->ErrorCode |= HAL_QSPI_ERROR_INVALID_PARAM;
            status = HAL_ERROR;
            break;
        }

        /* Update the handle transfer counters */
        hqspi->State       = HAL_QSPI_STATE_BUSY_INDIRECT_TX;
        hqspi->pTxBuffPtr  = pData;
        hqspi->TxXferSize  = xfercount;
        hqspi->TxXferCount = xfercount;

        /* Make sure the functional mode is the indirect write (defensive: the
           CCR reset value is the indirect read); the write sequence itself is
           started by the DR push below */
        reg = hqspi->Instance->CCR;
        reg &= ~(uint32)QSPI_CCR_FMODE_Msk;
        reg |= QSPI_FUNCTIONAL_MODE_INDIRECT_WRITE;
        hqspi->Instance->CCR = reg;

        /* Pack the bytes (little-endian) and push the FIFO word */
        for (i = 0U; i < xfercount; i++)
        {
            data |= ((uint32)(*pData)) << (8U * i);
            pData++;
        }
        hqspi->Instance->DR = data;

        /* Wait until the transfer is complete */
        status = QSPI_WaitFlagStateUntilTimeout(hqspi, QSPI_FLAG_TCF, 1U, Timeout);
        if (status != HAL_OK)
        {
            hqspi->ErrorCode |= HAL_QSPI_ERROR_TIMEOUT;
            break;
        }

        __HAL_QSPI_CLEAR_FLAG(hqspi, QSPI_CLEAR_CTCF);
        hqspi->State = HAL_QSPI_STATE_READY;
    }
    while (0U);

    /* Only an operation that was actually started owns the handle state: a
     * rejected request (busy handle) leaves the state of the other operation
     * untouched (ARCH-CONST-09) */
    if ((transfer_started != 0U) && (status != HAL_OK))
    {
        hqspi->State = HAL_QSPI_STATE_ERROR;
    }

    /* Process unlocked */
    QSPI_UnlockHandle(hqspi);

    return status;
}

/**
 * @brief  Receives the data of an indirect read command in blocking mode. (BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  pData: pointer to the data buffer that will store the received data.
 * @param  Timeout: maximum waiting time in ms (HAL_MAX_DELAY for infinite).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_QSPI_Receive(HAL_QSPI_HandleTypeDef *hqspi, uint8 *pData, uint32 Timeout)
{
    HAL_StatusTypeDef status = HAL_OK;
    uint32 xfercount = 0U;
    uint32 data = 0U;
    uint32 addr = 0U;
    uint32 reg = 0U;
    uint32 i = 0U;
    uint32 transfer_started = 0U;

    /* Check the QSPI handle and the data buffer */
    if ((hqspi == NULL_PTR) || (pData == NULL_PTR))
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_QSPI_ALL_INSTANCE(hqspi->Instance));

    /* Process locked */
    if (QSPI_LockHandle(hqspi, Timeout) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    do
    {
        /* ARCH-CONST-09: reject a new transfer while another operation is
         * ongoing; the recoverable error state accepts a retry without a
         * DeInit / Init round trip (STATE-06) */
        status = QSPI_CheckState(hqspi);
        if (status != HAL_OK)
        {
            /* The handle is busy with another operation or has not been
             * initialized: report it without touching the state of the
             * ongoing operation */
            break;
        }

        transfer_started = 1U;

        hqspi->ErrorCode = HAL_QSPI_ERROR_NONE;

        /* Transfer size is the DLR content + 1 (programmed by HAL_QSPI_Command) */
        xfercount = (hqspi->Instance->DLR & QSPI_DLR_DATALENGTH_Msk) + 1U;

        /* Polling transfers are limited to one FIFO word (4 bytes). The
         * length is rejected before the busy state is entered, so a rejected
         * call leaves the handle state untouched (ARCH-CONST-10 / ERR-03). */
        if (xfercount > QSPI_POLLING_MAX_BYTES)
        {
            hqspi->ErrorCode |= HAL_QSPI_ERROR_INVALID_PARAM;
            status = HAL_ERROR;
            break;
        }

        /* Update the handle transfer counters */
        hqspi->State       = HAL_QSPI_STATE_BUSY_INDIRECT_RX;
        hqspi->pRxBuffPtr  = pData;
        hqspi->RxXferSize  = xfercount;
        hqspi->RxXferCount = xfercount;

        /* Switch the functional mode to indirect read and keep the address:
           the read transfer is (re)started by re-writing the AR register
           (on this device the indirect read is triggered by the AR write
           rather than by the CCR write) */
        addr = hqspi->Instance->AR;
        reg = hqspi->Instance->CCR;
        reg &= ~(uint32)QSPI_CCR_FMODE_Msk;
        reg |= QSPI_FUNCTIONAL_MODE_INDIRECT_READ;
        hqspi->Instance->CCR = reg;
        hqspi->Instance->AR  = addr;

        /* Wait until the transfer is complete, then read the FIFO word */
        status = QSPI_WaitFlagStateUntilTimeout(hqspi, QSPI_FLAG_TCF, 1U, Timeout);
        if (status != HAL_OK)
        {
            hqspi->ErrorCode |= HAL_QSPI_ERROR_TIMEOUT;
            break;
        }

        data = hqspi->Instance->DR;
        __HAL_QSPI_CLEAR_FLAG(hqspi, QSPI_CLEAR_CTCF);

        /* Unpack the FIFO word (little-endian) into the receive buffer */
        for (i = 0U; i < xfercount; i++)
        {
            *pData = (uint8)((data >> (8U * i)) & 0xFFU);
            pData++;
        }

        hqspi->State = HAL_QSPI_STATE_READY;
    }
    while (0U);

    /* Only an operation that was actually started owns the handle state: a
     * rejected request (busy handle) leaves the state of the other operation
     * untouched (ARCH-CONST-09) */
    if ((transfer_started != 0U) && (status != HAL_OK))
    {
        hqspi->State = HAL_QSPI_STATE_ERROR;
    }

    /* Process unlocked */
    QSPI_UnlockHandle(hqspi);

    return status;
}

/**
 * @brief  Runs the auto-polling functional mode in blocking mode. (BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  cmd: pointer to a QSPI_CommandTypeDef structure that contains the
 *         command sequence configuration.
 * @param  cfg: pointer to a QSPI_AutoPollingTypeDef structure that contains
 *         the polling configuration (match / mask / interval / size).
 * @param  Timeout: maximum waiting time in ms (HAL_MAX_DELAY for infinite).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_QSPI_AutoPolling(HAL_QSPI_HandleTypeDef *hqspi,
                                       QSPI_CommandTypeDef *cmd,
                                       QSPI_AutoPollingTypeDef *cfg, uint32 Timeout)
{
    HAL_StatusTypeDef status = HAL_OK;
    uint32 transfer_started = 0U;

    /* Check the QSPI handle and the configuration structures */
    if ((hqspi == NULL_PTR) || (cmd == NULL_PTR) || (cfg == NULL_PTR))
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_QSPI_ALL_INSTANCE(hqspi->Instance));
    assert_param(IS_QSPI_INSTRUCTION_MODE(cmd->InstructionMode));
    if (cmd->InstructionMode != QSPI_INSTRUCTION_NONE)
    {
        assert_param(IS_QSPI_INSTRUCTION(cmd->Instruction));
    }
    assert_param(IS_QSPI_ADDRESS_MODE(cmd->AddressMode));
    if (cmd->AddressMode != QSPI_ADDRESS_NONE)
    {
        assert_param(IS_QSPI_ADDRESS_SIZE(cmd->AddressSize));
    }
    assert_param(IS_QSPI_ALTERNATE_BYTES_MODE(cmd->AlternateByteMode));
    if (cmd->AlternateByteMode != QSPI_ALTERNATE_BYTES_NONE)
    {
        assert_param(IS_QSPI_ALTERNATE_BYTES_SIZE(cmd->AlternateBytesSize));
    }
    assert_param(IS_QSPI_DUMMY_CYCLES(cmd->DummyCycles));
    assert_param(IS_QSPI_DATA_MODE(cmd->DataMode));
    assert_param(IS_QSPI_INTERVAL(cfg->Interval));
    assert_param(IS_QSPI_STATUS_BYTES_SIZE(cfg->StatusBytesSize));

    /* Reject an invalid configuration before the lock is taken: a data phase
     * is required to receive the status byte(s). The request is reported
     * without changing the handle state and without consuming the lock
     * (ARCH-CONST-10 / ERR-03). */
    if (cmd->DataMode == QSPI_DATA_NONE)
    {
        hqspi->ErrorCode |= HAL_QSPI_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Process locked */
    if (QSPI_LockHandle(hqspi, Timeout) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    do
    {
        /* ARCH-CONST-09: reject a new operation while another one is ongoing;
         * the recoverable error state accepts a retry without a DeInit / Init
         * round trip (STATE-06) */
        status = QSPI_CheckState(hqspi);
        if (status != HAL_OK)
        {
            /* The handle is busy with another operation or has not been
             * initialized */
            break;
        }

        transfer_started = 1U;

        hqspi->ErrorCode = HAL_QSPI_ERROR_NONE;
        hqspi->State = HAL_QSPI_STATE_BUSY_AUTO_POLLING;

        /* Wait until the BUSY flag is reset before reconfiguring the
           controller */
        status = QSPI_WaitFlagStateUntilTimeout(hqspi, QSPI_FLAG_BUSY, 0U, Timeout);
        if (status != HAL_OK)
        {
            hqspi->ErrorCode |= HAL_QSPI_ERROR_TIMEOUT;
            break;
        }

        /* Configure the polling match value, mask and interval */
        hqspi->Instance->PSMAR = cfg->Match;
        hqspi->Instance->PSMKR = cfg->Mask;
        hqspi->Instance->PIR   = cfg->Interval;

        /* The data length of the polling command is the status byte count */
        cmd->NbData = cfg->StatusBytesSize;

        /* Configure the command sequence in the auto-polling functional
           mode */
        QSPI_Config(hqspi, cmd, QSPI_FUNCTIONAL_MODE_AUTO_POLLING);

        /* Wait until the polling match flag is set: the controller stops
           polling as soon as the masked status equals the match value */
        status = QSPI_WaitFlagStateUntilTimeout(hqspi, QSPI_FLAG_PMF, 1U, Timeout);
        if (status != HAL_OK)
        {
            hqspi->ErrorCode |= HAL_QSPI_ERROR_TIMEOUT;
            break;
        }
        __HAL_QSPI_CLEAR_FLAG(hqspi, QSPI_CLEAR_CPMF);

        hqspi->State = HAL_QSPI_STATE_READY;
    }
    while (0U);

    /* Only an operation that was actually started owns the handle state: a
     * rejected request (busy handle) leaves the state of the other operation
     * untouched (ARCH-CONST-09) */
    if ((transfer_started != 0U) && (status != HAL_OK))
    {
        hqspi->State = HAL_QSPI_STATE_ERROR;
    }

    /* Process unlocked */
    QSPI_UnlockHandle(hqspi);

    return status;
}

/**
 * @brief  Configures the memory-mapped functional mode. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  cmd: pointer to a QSPI_CommandTypeDef structure that contains the
 *         read sequence configuration (NbData is ignored in this mode).
 * @param  cfg: pointer to a QSPI_MemoryMappedTypeDef structure that contains
 *         the nCS release timeout configuration.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_QSPI_MemoryMapped(HAL_QSPI_HandleTypeDef *hqspi, QSPI_CommandTypeDef *cmd,
                                        QSPI_MemoryMappedTypeDef *cfg)
{
    HAL_StatusTypeDef status = HAL_OK;
    uint32 transfer_started = 0U;

    /* Check the QSPI handle and the configuration structures */
    if ((hqspi == NULL_PTR) || (cmd == NULL_PTR) || (cfg == NULL_PTR))
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_QSPI_ALL_INSTANCE(hqspi->Instance));
    assert_param(IS_QSPI_INSTRUCTION_MODE(cmd->InstructionMode));
    if (cmd->InstructionMode != QSPI_INSTRUCTION_NONE)
    {
        assert_param(IS_QSPI_INSTRUCTION(cmd->Instruction));
    }
    assert_param(IS_QSPI_ADDRESS_MODE(cmd->AddressMode));
    if (cmd->AddressMode != QSPI_ADDRESS_NONE)
    {
        assert_param(IS_QSPI_ADDRESS_SIZE(cmd->AddressSize));
    }
    assert_param(IS_QSPI_ALTERNATE_BYTES_MODE(cmd->AlternateByteMode));
    if (cmd->AlternateByteMode != QSPI_ALTERNATE_BYTES_NONE)
    {
        assert_param(IS_QSPI_ALTERNATE_BYTES_SIZE(cmd->AlternateBytesSize));
    }
    assert_param(IS_QSPI_DUMMY_CYCLES(cmd->DummyCycles));
    assert_param(IS_QSPI_DATA_MODE(cmd->DataMode));
    assert_param(IS_QSPI_TIMEOUT_ACTIVATION(cfg->TimeOutActivation));

    /* Reject an invalid configuration before the lock is taken: a data phase
     * is required to read the attached device. The request is reported without
     * changing the handle state and without consuming the lock
     * (ARCH-CONST-10 / ERR-03). */
    if (cmd->DataMode == QSPI_DATA_NONE)
    {
        hqspi->ErrorCode |= HAL_QSPI_ERROR_INVALID_PARAM;
        return HAL_ERROR;
    }

    /* Process locked */
    if (QSPI_LockHandle(hqspi, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    do
    {
        /* ARCH-CONST-09: reject a new operation while another one is ongoing;
         * the recoverable error state accepts a retry without a DeInit / Init
         * round trip (STATE-06) */
        status = QSPI_CheckState(hqspi);
        if (status != HAL_OK)
        {
            /* The handle is busy with another operation or has not been
             * initialized */
            break;
        }

        transfer_started = 1U;

        hqspi->ErrorCode = HAL_QSPI_ERROR_NONE;
        hqspi->State = HAL_QSPI_STATE_BUSY_MEM_MAPPED;

        /* Wait until the BUSY flag is reset before reconfiguring the controller */
        status = QSPI_WaitFlagStateUntilTimeout(hqspi, QSPI_FLAG_BUSY, 0U, hqspi->Timeout);
        if (status != HAL_OK)
        {
            hqspi->ErrorCode |= HAL_QSPI_ERROR_TIMEOUT;
            break;
        }

        /* Configure the nCS release timeout: a non-zero TOR enables the timeout
           counter, 0 disables it (there is no dedicated enable bit) */
        if (cfg->TimeOutActivation == QSPI_TIMEOUT_COUNTER_ENABLE)
        {
            assert_param(IS_QSPI_TIMEOUT_PERIOD(cfg->TimeOutPeriod));
            hqspi->Instance->TOR = cfg->TimeOutPeriod;
        }
        else
        {
            hqspi->Instance->TOR = 0U;
        }

        /* Configure the read sequence in the memory-mapped functional mode:
           the address and the data length are not written, the AHB access
           provides the address and runs the transfer */
        QSPI_Config(hqspi, cmd, QSPI_FUNCTIONAL_MODE_MEMORY_MAPPED);

        /* The handle stays in the memory-mapped busy state until
           HAL_QSPI_Abort() is called to exit the mode */
    }
    while (0U);

    /* Only an operation that was actually started owns the handle state: a
     * rejected request (busy handle) leaves the state of the other operation
     * untouched (ARCH-CONST-09) */
    if ((transfer_started != 0U) && (status != HAL_OK))
    {
        hqspi->State = HAL_QSPI_STATE_ERROR;
    }

    /* Process unlocked */
    QSPI_UnlockHandle(hqspi);

    return status;
}

/**
 * @brief  Aborts the current operation (indirect transfer, auto-polling or
 *         memory-mapped mode) in blocking mode. (BLOCKING)
 * @note   The handle lock is taken by this function itself and released before
 *         returning: it never releases a lock owned by another context, which
 *         would be an error in an RTOS build. HAL_QSPI_Abort() is the only
 *         state changing API that is not gated by QSPI_CheckState(): it is
 *         accepted in every state by design (ARCH-CONST-09), since aborting an
 *         ongoing operation is its very purpose.
 * @note   Exiting the memory-mapped mode is its typical use: the mode is left
 *         running after HAL_QSPI_MemoryMapped() has returned, so the handle
 *         stays in a busy state until this function is called. When another
 *         context holds the lock (a blocking transfer running in another
 *         task), the call waits for the lock and aborts after that transfer
 *         has finished; to interrupt a running transfer from an interrupt
 *         service routine, use the lock-free HAL_QSPI_AbortRequest() instead.
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_QSPI_Abort(HAL_QSPI_HandleTypeDef *hqspi)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the QSPI handle allocation */
    if (hqspi == NULL_PTR)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_QSPI_ALL_INSTANCE(hqspi->Instance));

    /* Process locked */
    if (QSPI_LockHandle(hqspi, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return HAL_BUSY;
    }

    do
    {
        /* Check whether an operation is ongoing (all busy states share the
           bit pattern "xx1x") */
        if (HAL_QSPI_STATE_IS_BUSY(hqspi->State) == 0U)
        {
            /* No operation to abort */
            break;
        }

        /* Clear the error code: this is the entry point of an operation
           (ARCH-CONST-10) */
        hqspi->ErrorCode = HAL_QSPI_ERROR_NONE;

        /* Only an ongoing transfer needs the abort sequence: if the controller
           is already idle, go back to READY directly */
        if ((hqspi->Instance->SR & QSPI_FLAG_BUSY) != 0U)
        {
            /* Request the abort */
            hqspi->Instance->CR |= QSPI_CR_ABORT;

            /* Wait until the transfer complete flag is set */
            status = QSPI_WaitFlagStateUntilTimeout(hqspi, QSPI_FLAG_TCF, 1U, hqspi->Timeout);
            if (status == HAL_OK)
            {
                __HAL_QSPI_CLEAR_FLAG(hqspi, QSPI_CLEAR_CTCF);

                /* Wait until the BUSY flag is reset */
                status = QSPI_WaitFlagStateUntilTimeout(hqspi, QSPI_FLAG_BUSY, 0U, hqspi->Timeout);
            }

            /* Clear the abort request bit (the hardware may have already
               cleared it) */
            hqspi->Instance->CR &= ~(QSPI_CR_ABORT);
        }

        if (status == HAL_OK)
        {
            /* Reset the functional mode to the indirect write default, so that
               the next command configuration always starts from a known CCR */
            hqspi->Instance->CCR &= ~(uint32)(QSPI_CCR_FMODE);

            hqspi->State = HAL_QSPI_STATE_READY;
        }
        else
        {
            /* STATE-03: the failed abort leaves the recoverable error state;
               the error code carries the reason */
            hqspi->ErrorCode |= HAL_QSPI_ERROR_TIMEOUT;
            hqspi->State = HAL_QSPI_STATE_ERROR;
        }
    }
    while (0U);

    /* Process unlocked */
    QSPI_UnlockHandle(hqspi);

    return status;
}

/**
  * @}
  */

/** @addtogroup QSPI_Exported_Functions_Group3 Peripheral Control and State functions
  * @{
  */

/**
 * @brief  Returns the QSPI handle state. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @retval HAL_QSPI_StateTypeDef: the current handle state.
 */
HAL_QSPI_StateTypeDef HAL_QSPI_GetState(HAL_QSPI_HandleTypeDef *hqspi)
{
    /* Check the QSPI handle allocation */
    if (hqspi == NULL_PTR)
    {
        return HAL_QSPI_STATE_RESET;
    }

    return hqspi->State;
}

/**
 * @brief  Returns the QSPI error code. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @retval uint32: the QSPI error code (HAL_QSPI_ERROR_xxx).
 */
uint32 HAL_QSPI_GetError(HAL_QSPI_HandleTypeDef *hqspi)
{
    /* Check the QSPI handle allocation */
    if (hqspi == NULL_PTR)
    {
        return HAL_QSPI_ERROR_NONE;
    }

    return hqspi->ErrorCode;
}

/**
 * @brief  Sets the default timeout used by the internal waits of the driver. (NON-BLOCKING)
 * @note   The handle field is shared with the operations that read it, so the
 *         write is serialized through the handle lock. A call that does not
 *         acquire the lock does not modify the handle.
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  Timeout: timeout value in ms (HAL_MAX_DELAY for infinite).
 * @retval None
 */
void HAL_QSPI_SetTimeout(HAL_QSPI_HandleTypeDef *hqspi, uint32 Timeout)
{
    /* Check the QSPI handle allocation */
    if (hqspi == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_QSPI_ALL_INSTANCE(hqspi->Instance));

    /* Process locked */
    if (QSPI_LockHandle(hqspi, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is required */
        return;
    }

    hqspi->Timeout = Timeout;

    /* Process unlocked */
    QSPI_UnlockHandle(hqspi);
}

/**
  * @}
  */

/** @addtogroup QSPI_Exported_Functions_Group4 Low level register functions
  * @{
  */

/**
 * @brief  Enables or disables the QSPI peripheral. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  NewState: QSPI_ENABLE or QSPI_DISABLE.
 * @retval None
 */
void HAL_QSPI_Cmd(HAL_QSPI_HandleTypeDef *hqspi, uint32 NewState)
{
    /* Check the QSPI handle allocation */
    if (hqspi == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_QSPI_ALL_INSTANCE(hqspi->Instance));
    assert_param(IS_QSPI_ENABLE_STATE(NewState));

    if (NewState != QSPI_DISABLE)
    {
        /* Enable the QSPI peripheral */
        hqspi->Instance->CR |= ((uint32)(QSPI_CR_EN));
    }
    else
    {
        /* Disable the QSPI peripheral */
        hqspi->Instance->CR &= ~((uint32)(QSPI_CR_EN));
    }
}

/**
 * @brief  Sets or resets the QSPI abort request bit. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  NewState: QSPI_ENABLE (request an abort) or QSPI_DISABLE.
 * @retval None
 */
void HAL_QSPI_AbortRequest(HAL_QSPI_HandleTypeDef *hqspi, uint32 NewState)
{
    /* Check the QSPI handle allocation */
    if (hqspi == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_QSPI_ALL_INSTANCE(hqspi->Instance));
    assert_param(IS_QSPI_ENABLE_STATE(NewState));

    if (NewState != QSPI_DISABLE)
    {
        /* Request the abort */
        hqspi->Instance->CR |= ((uint32)(QSPI_CR_ABORT));
    }
    else
    {
        /* Reset the abort request */
        hqspi->Instance->CR &= ~((uint32)(QSPI_CR_ABORT));
    }
}

/**
 * @brief  Checks whether a QSPI status flag is set. (NON-BLOCKING)
 * @note   The register read is performed by the lock-free
 *         QSPI_GetFlagStatusInternal() helper, which is shared with the
 *         internal wait helper. It takes no lock, so this read-only function
 *         stays usable from an interrupt service routine and while the handle
 *         lock is held (LOCK-04 / LOCK-05).
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  QSPI_FLAG: the flag to check (QSPI_FLAG_xxx).
 * @retval 1 if the flag is set, 0 otherwise.
 */
uint32 HAL_QSPI_GetFlagStatus(HAL_QSPI_HandleTypeDef *hqspi, uint32 QSPI_FLAG)
{
    /* Check the QSPI handle allocation */
    if (hqspi == NULL_PTR)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_QSPI_ALL_INSTANCE(hqspi->Instance));
    assert_param(IS_QSPI_GET_FLAG(QSPI_FLAG));

    return QSPI_GetFlagStatusInternal(hqspi, QSPI_FLAG);
}

/**
 * @brief  Clears a QSPI status flag. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  QSPI_FLAG_CLEAR: the flag to clear (QSPI_CLEAR_xxx).
 * @retval None
 */
void HAL_QSPI_ClearFlag(HAL_QSPI_HandleTypeDef *hqspi, uint32 QSPI_FLAG_CLEAR)
{
    /* Check the QSPI handle allocation */
    if (hqspi == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_QSPI_ALL_INSTANCE(hqspi->Instance));
    assert_param(IS_QSPI_CLEAR_FLAG(QSPI_FLAG_CLEAR));

    hqspi->Instance->FCR = QSPI_FLAG_CLEAR;
}

/**
 * @brief  Returns the current FIFO level. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @retval uint32: the number of valid bytes currently stored in the FIFO.
 */
uint32 HAL_QSPI_GetFIFOLevel(HAL_QSPI_HandleTypeDef *hqspi)
{
    /* Check the QSPI handle allocation */
    if (hqspi == NULL_PTR)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_QSPI_ALL_INSTANCE(hqspi->Instance));

    return (uint32)((hqspi->Instance->SR & QSPI_SR_FLEVEL_Msk) >> QSPI_SR_FLEVEL_Pos);
}

/**
 * @brief  Sets the address sent to the attached device. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  QSPI_Addr: the address value (AR register).
 * @retval None
 */
void HAL_QSPI_SetAddr(HAL_QSPI_HandleTypeDef *hqspi, uint32 QSPI_Addr)
{
    /* Check the QSPI handle allocation */
    if (hqspi == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_QSPI_ALL_INSTANCE(hqspi->Instance));

    hqspi->Instance->AR = QSPI_Addr;
}

/**
 * @brief  Sets the alternate bytes sent to the attached device. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  QSPI_AltBytes: the alternate bytes value (ABR register).
 * @retval None
 */
void HAL_QSPI_SetAltBytes(HAL_QSPI_HandleTypeDef *hqspi, uint32 QSPI_AltBytes)
{
    /* Check the QSPI handle allocation */
    if (hqspi == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_QSPI_ALL_INSTANCE(hqspi->Instance));

    hqspi->Instance->ABR = QSPI_AltBytes;
}

/**
 * @brief  Pushes one data word into the transmit FIFO. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  QSPI_Data: the data word to transmit (DR register).
 * @retval None
 */
void HAL_QSPI_SetData(HAL_QSPI_HandleTypeDef *hqspi, uint32 QSPI_Data)
{
    /* Check the QSPI handle allocation */
    if (hqspi == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_QSPI_ALL_INSTANCE(hqspi->Instance));

    hqspi->Instance->DR = QSPI_Data;
}

/**
 * @brief  Reads one data word from the receive FIFO. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @retval uint32: the received data word (DR register).
 */
uint32 HAL_QSPI_ReadData(HAL_QSPI_HandleTypeDef *hqspi)
{
    /* Check the QSPI handle allocation */
    if (hqspi == NULL_PTR)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_QSPI_ALL_INSTANCE(hqspi->Instance));

    return hqspi->Instance->DR;
}

/**
 * @brief  Sets the number of bytes to transfer (DLR register). (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  QSPI_DataLength: the data length, in bytes (0 = 1 byte).
 * @retval None
 */
void HAL_QSPI_SetDataLength(HAL_QSPI_HandleTypeDef *hqspi, uint32 QSPI_DataLength)
{
    /* Check the QSPI handle allocation */
    if (hqspi == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_QSPI_ALL_INSTANCE(hqspi->Instance));

    hqspi->Instance->DLR = QSPI_DataLength;
}

/**
 * @brief  Sets the nCS release timeout period used in memory-mapped mode. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  QSPI_Timeout: the timeout period in QSPI clock cycles (0..0xFFFF).
 * @retval None
 */
void HAL_QSPI_SetTimeoutPeriod(HAL_QSPI_HandleTypeDef *hqspi, uint32 QSPI_Timeout)
{
    /* Check the QSPI handle allocation */
    if (hqspi == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_QSPI_ALL_INSTANCE(hqspi->Instance));
    assert_param(IS_QSPI_TIMEOUT_PERIOD(QSPI_Timeout));

    hqspi->Instance->TOR = QSPI_Timeout;
}

/**
 * @brief  Sets the polling interval of the auto-polling mode. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  QSPI_PollingInterval: the polling interval in QSPI clock cycles
 *         (0..0xFFFF, PIR register).
 * @retval None
 */
void HAL_QSPI_SetPollingInterval(HAL_QSPI_HandleTypeDef *hqspi, uint32 QSPI_PollingInterval)
{
    /* Check the QSPI handle allocation */
    if (hqspi == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_QSPI_ALL_INSTANCE(hqspi->Instance));
    assert_param(IS_QSPI_INTERVAL(QSPI_PollingInterval));

    hqspi->Instance->PIR = QSPI_PollingInterval;
}

/**
 * @brief  Sets the polling status match value of the auto-polling mode. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  QSPI_MatchData: the status match value (PSMAR register).
 * @retval None
 */
void HAL_QSPI_SetPollingStaMatch(HAL_QSPI_HandleTypeDef *hqspi, uint32 QSPI_MatchData)
{
    /* Check the QSPI handle allocation */
    if (hqspi == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_QSPI_ALL_INSTANCE(hqspi->Instance));

    hqspi->Instance->PSMAR = QSPI_MatchData;
}

/**
 * @brief  Sets the polling status mask of the auto-polling mode. (NON-BLOCKING)
 * @param  hqspi: pointer to a HAL_QSPI_HandleTypeDef structure.
 * @param  QSPI_MatchDataMask: the status mask value (PSMKR register).
 * @retval None
 */
void HAL_QSPI_PollingStaMask(HAL_QSPI_HandleTypeDef *hqspi, uint32 QSPI_MatchDataMask)
{
    /* Check the QSPI handle allocation */
    if (hqspi == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_QSPI_ALL_INSTANCE(hqspi->Instance));

    hqspi->Instance->PSMKR = QSPI_MatchDataMask;
}

/**
  * @}
  */

#endif /* HAL_QSPI_MODULE_ENABLED */

/*****END OF FILE*****/
