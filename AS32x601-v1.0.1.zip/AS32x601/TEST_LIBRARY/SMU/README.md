# SMU 应用与测试参考

供 skill 按需求检索 AS32x601 HAL 系统管理单元（SMU）示例。别名/关键词：SMU、系统时钟、时钟树、FIRC、OSC、SIRC/RC32K、PLL、PLLQ、总线分频、AXI4Bus3、AXIBus1、APBBus0/1、CANX2、MCO 时钟输出、SystemCoreClock。共有 15 个独立用例。

HAL 依据：[头文件](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_smu.h)、[实现](../../HAL_LIBRARY/peripherals/src/as32x601_hal_smu.c)。原测试工程的 4_HAL_LIBRARY 未提供，尚不能确认原始链接版本；文中标出的源码与当前 SDK 差异须先解决再迁移。

注意：SMU 负责系统时钟树、总线分频和时钟输出；**时钟监测/阈值告警是 CMU**，两者不要混用。


## 实例与可选引脚

下表列出 LQFP144 封装的时钟相关引脚。GPIO 编码见 [GPIO AF 定义](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_gpio.h)。

| 信号 | 引脚 | LQFP144 脚号 | 配置 |
|---|---|---|---|
| `CLK_OUT` | PB4 | 11 | 功能1，`GPIO_AF_CLKOUT`（0x02） |
| 外部振荡器输入 | OSCIN | 3 | 专用振荡器引脚，按 SMU 时钟源和板级电路配置 |
| 外部振荡器输出 | OSCOUT | 4 | 专用振荡器引脚，按晶振电路配置 |

时钟输出功能按实际 SMU 选择配置；使用外部时钟输入或晶振时，先核对输入方式、电路及频率。

## 生成前需确认的参数

已有工程、板级资料或用户已明确的值直接复用。仅对影响本次实现的缺失选择使用参数卡询问并等待答复；案例配置不能代替实际接线或应用参数。

| 参数 | 需要核对或确认的内容 |
|---|---|
| 时钟来源 | 板载晶振/外部时钟及频率 |
| 目标时钟树 | 系统频率、总线分频及相关外设要求 |
| 工作条件 | 供电、Flash 等待周期及切换失败处理 |

## 按需求选择

| 用户需求 / 检索关键词 | 推荐用例 | 选择条件 / 需要补充的逻辑 |
|---|---|---|
| 最短路径：配置系统时钟树并读出频率 | [015](SMU_IT_DRV_015.c) | 标准 180 MHz 树 + 全 API 读取（Sys/HCLK/PCLK0/PCLK1/ClocksFreq）。频率读取取对应段，静态时钟配置可同时参考 006 |
| FIRC 作为系统时钟（默认校准） | [001](SMU_IT_DRV_001.c) | 同时把 SYSCLK/8 输出到 PB4 供示波器测量 |
| FIRC 校准到最大 0x3F | [002](SMU_IT_DRV_002.c) | 校准值改变 FIRC 频率；不要把标称 16 MHz 当实际值 |
| FIRC 校准到最小 0x00 | [003](SMU_IT_DRV_003.c) | 该用例刻意不把 FIRC 作 SYSCLK（见安全说明），只输出 FIRC 观察；照搬前先读文件头 |
| OSC（20 MHz）作为系统时钟 | [004](SMU_IT_DRV_004.c) | 外部晶振必须起振；PB4 预期 2.5 MHz |
| PLL 输入 FIRC，PLLCLK_Q=180 MHz | [005](SMU_IT_DRV_005.c) | 源码按描述使用 FIRC 作为 PLL 输入（N=0x10），与厂商代码注释不一致；以本用例为准 |
| PLL 输入 OSC，PLLCLK_Q=180 MHz | [006](SMU_IT_DRV_006.c) | 标准 180 MHz 树的直接参考；R=4、Q=1、N=0x14、F=0xB4 |
| 时钟输出测量：AXIBus1/8 | [007](SMU_IT_DRV_007.c) | PB4 输出 90/8=11.25 MHz；需要示波器 |
| 时钟输出测量：AXI4Bus3/8 | [008](SMU_IT_DRV_008.c) | PB4 输出 45/8=5.625 MHz |
| 时钟输出测量：APBBus0/8 | [009](SMU_IT_DRV_009.c) | PB4 输出 22.5/8=2.8125 MHz |
| 时钟输出测量：APBBus1/8 | [010](SMU_IT_DRV_010.c) | 与 009 同值，但源为 APBBus1 |
| 时钟输出测量：FIRC/8 | [011](SMU_IT_DRV_011.c) | FIRC 标称 16 MHz → 2 MHz；实际随校准变化 |
| 时钟输出测量：OSC/8 | [012](SMU_IT_DRV_012.c) | 20 MHz OSC → 2.5 MHz |
| 时钟输出测量：SIRC（RC32K） | [013](SMU_IT_DRV_013.c) | 无分频，约 32768 Hz；RC32K 有偏差 |
| 总线分频器扫描 | [014](SMU_IT_DRV_014.c) | 用 FIRC 16 MHz 跑扫描，避免 APB 超频；分组 1/2/4/8 回读 |
| 外设时钟门控、单个外设复位 | 无独立 SMU 用例 | 其他外设套件的 `MspInit()` 里有 `__HAL_SMU_xxx_CLK_ENABLE()`；本目录的 SMU 用例只做系统时钟树，不能据此替代外设门控设计 |
| 运行时动态调频、调压协同 | 无直接完整模板 | 需结合 PMU/LDO 和 Flash 等待周期自行设计；006 只给出静态切换顺序 |

## 实现要点与案例配置

- 标准时钟树（多数用例使用）：PLL VCO 180 MHz，`PLLDivR=0x04`、`PLLDivQ=0x01`、`PLLDivN=0x14`、`PLLDivF=0xB4`；`AXI4Bus3CLKDiv=/2`、`APBBus0CLKDiv=/2`、`APBBus1CLKDiv=/2`、`CANX2CLKDiv=/8`。由此 PLLCLK_Q=180 MHz、AXIBus1=90 MHz、AXI4Bus3=45 MHz、APBBus0/1=22.5 MHz；CANCLK 再按 `CANX2` 链路计算。
- 初始化顺序：`HAL_Init()` → `__HAL_CLEAR_STRUCT`、`Instance = SMU`、`HAL_SMU_Init()` → **先** `HAL_SMU_ClockConfig()` 写总线分频（此时系统时钟仍是 FIRC）→ **后** `HAL_SMU_OscConfig()` 配 PLL/时钟源并切换；`OscConfig` 会同时编程 Flash 等待周期并更新 `SystemCoreClock`。切换完成后才 `delay_init()` / 初始化串口，否则波特率分频按旧时钟计算。
- MCO 测量：`HAL_SMU_MCOConfig()` 把所选时钟（多数为 /8）送到 PB4，用例保持 5 秒供示波器测量。SIRC 选中时不分频，约 32.768 kHz。
- 两阶段写法：切换系统时钟会让串口波特率失效，所以 001–013 在“被测时钟”阶段不打印，恢复标准时钟树并重新初始化串口后才输出检查结果。应用做在线调频时也要处理控制台/外设时钟的重新分频。
- 读取接口：`HAL_SMU_GetSysClockFreq()` / `GetHCLKFreq()` / `GetPCLK0Freq()` / `GetPCLK1Freq()` / `GetClocksFreq()` 给出固件计算值；`HAL_SMU_GetClockConfig()` / `GetOscConfig()` 回读配置字段。
- 证据边界：寄存器回读和频率计算能证明配置写入与固件换算；PB4 示波器测量才能证明实际输出频率。FIRC/RC32K 的校准与温漂需实测。

## 验证方法与适用边界

- 分频器必须在切换 PLL 之前写好；先切 PLL 再改分频会让总线在切换瞬间超频。014 还说明 APB 有频率上限（示例把扫描放到 FIRC 16 MHz 下做，避免 180 MHz 树里出现 90 MHz APB）。
- 切换 SYSCLK 会改变串口、延时和外设时钟：必须在切换后重新计算波特率/延时；测量类用例的两阶段结构就是为此设计的。
- `HAL_SMU_OscConfig()` 负责 PLL 锁定等待、Flash 等待周期和 `SystemCoreClock` 更新；不要绕过它直接写寄存器。
- PLL 输入源要与分频参数匹配：005 明确纠正了厂商用例“描述写 FIRC、代码却写 OSC”的矛盾，按 FIRC + N=0x10 才能得到 180 MHz。
- `HAL_SMU_DeInit()` 会把系统时钟退回 FIRC，随后的打印/串口时序会变化；015 因此把结果先收集、恢复后再打印。
- 003 出于安全考虑没有把校准到 0x00 的 FIRC 作为 SYSCLK；不要为了“复现原厂用例”而跳过该偏差。
- `HAL_SMU_DCLSCmd(ENABLE)`、`SetSRAMLowPower(ENABLE)` 等在单核/栈驻留 SRAM 的场景会挂死，015 只做禁用方向；应用启用前必须评估核间与内存布局。
- 不要用 SMU 用例替代 CMU 的时钟监测；也不要把它当作 PMU 的低功耗模式配置。

## 按接口与辅助宏检索

| 接口 / 宏 | 参考用例 |
|---|---|
| `HAL_SMU_Init` / `HAL_SMU_DeInit` | [001](SMU_IT_DRV_001.c)、[015](SMU_IT_DRV_015.c) |
| `HAL_SMU_ClockConfig` | [006](SMU_IT_DRV_006.c)、[014](SMU_IT_DRV_014.c) |
| `HAL_SMU_OscConfig` | [004](SMU_IT_DRV_004.c)、[005](SMU_IT_DRV_005.c)、[006](SMU_IT_DRV_006.c) |
| `HAL_SMU_GetClocksFreq` / `HAL_SMU_GetSysClockFreq` / `HAL_SMU_GetPCLK0Freq` / `HAL_SMU_GetPCLK1Freq` | [015](SMU_IT_DRV_015.c) |
| `HAL_SMU_GetClockConfig` / `HAL_SMU_GetOscConfig` | [014](SMU_IT_DRV_014.c)、[015](SMU_IT_DRV_015.c) |
| `HAL_SMU_MCOConfig` | [007](SMU_IT_DRV_007.c)、[013](SMU_IT_DRV_013.c) |
| `HAL_SMU_GetFlagStatus` / `HAL_SMU_GetBusState` / `HAL_SMU_GetWorkMode` | [015](SMU_IT_DRV_015.c) |
| `HAL_SMU_TimerBreak` / `HAL_SMU_TIMBreakCmd` | [015](SMU_IT_DRV_015.c) |
| `HAL_SMU_SetSRAMLowPower` / `HAL_SMU_DCLSCmd` / `HAL_SMU_ECCCmd` / `HAL_SMU_BUSTimeOutCmd` | [015](SMU_IT_DRV_015.c) |
| `SMU_AXI4BUS3CLK_DIV1` / `DIV2` 等分频宏 | [014](SMU_IT_DRV_014.c) |


本次为源码静态整理，未重新编译、未上板；源码里的历史测试注释不代表本次验证结果。
