/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_flash.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.7
 * Date:   2026/10/09
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.1     split the erase / write
 *                                                       protection / ECC /
 *                                                       security functions into
 *                                                       the dedicated extended
 *                                                       driver "as32x601_hal_
 *                                                       flash_ex.c / .h"; the
 *                                                       low level command
 *                                                       helpers shared with the
 *                                                       extended driver are now
 *                                                       declared below in the
 *                                                       "Private functions"
 *                                                       section
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.2     document review fixes:
 *                                                       ClearITPendingBit W1C
 *                                                       write, Read alignment
 *                                                       requirement, Init clock
 *                                                       frequency range
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.3     FLASH_StartCmd and
 *                                                       HAL_FLASH_Init return
 *                                                       documentation adds the
 *                                                       HAL_TIMEOUT value
 *     ANSILIC APPLICATION GROUP  2026/08/25     1.4     HAL_FLASH_SetClock-
 *                                                       Frequency return
 *                                                       documentation adds the
 *                                                       HAL_TIMEOUT value;
 *                                                       remove the external
 *                                                       reference descriptions
 *                                                       from the comments
 *     ANSILIC APPLICATION GROUP  2026/09/11     1.5     fix the polarity of the EFLASH reset
 *                                                       bit in HAL_FLASH_MspInit (the reset is
 *                                                       released by setting the bit, not by
 *                                                       clearing it)
 *     ANSILIC APPLICATION GROUP  2026/09/17     1.6     align the resource lock and the RTOS support with the architecture specification (sections 13 and 21):
 *                                                       expose the lock helper with a Timeout
 *                                                       parameter (RTOS-11) in the shared section,
 *                                                       document the LOCK-06 MSP callback ordering
 *                                                       and the ARCH-CONST-09 state gate of the
 *                                                       register accessing APIs; the lock / unlock
 *                                                       and the clock frequency programming remain
 *                                                       usable before HAL_FLASH_Init()
 *     ANSILIC APPLICATION GROUP  2026/10/09     1.7     restore the " *" prefix of the history
 *                                                       continuation lines
 * Description:     This file provides firmware functions to manage the
 *                  following functionalities of the embedded FLASH (EFLASH)
 *                  controller of the AS32x601:
 *                  - Initialization and de-initialization;
 *                  - Peripheral control: unlock / lock, clock frequency
 *                    configuration;
 *                  - Program operations (8-byte write unit, ROM-based
 *                    command of up to 512 bytes);
 *                  - Read operations;
 *                  - Flag and interrupt management.
 *
 *                  The extended functionalities (erase, write protection,
 *                  ECC and security) are provided by this driver.
 *
 *                  The embedded FLASH of the AS32x601 is organized as:
 *                  - P-Flash main region @ 0x01000000 (2 MB, 4 blocks of
 *                    512 KB, sectors of 4 KB);
 *                  - P-Flash info region @ 0x01200000 (16 KB);
 *                  - D-Flash main region @ 0x02000000 (512 KB, 1 block of
 *                    512 KB, sectors of 4 KB);
 *                  - D-Flash info region @ 0x02080000 (4 KB).
 * @complexity  Medium
 *              Blocking (polling) only, state machine, no IT/DMA.
 */
#ifndef __AS32X601_HAL_FLASH_H
#define __AS32X601_HAL_FLASH_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "as32x601.h"               /* FLASH_TypeDef, EFLASH, FLASH register bits */
#include "as32x601_hal_def.h"       /* HAL_StatusTypeDef, HAL_LockTypeDef         */

/* Exported constants --------------------------------------------------------*/

/**
 * @brief FLASH HAL driver module version.
 * @note  0x0100U = V1.0. Bumped only on breaking API changes (architecture
 *        spec COMPAT-13/14/15).
 */
#define __HAL_FLASH_MODULE_VERSION  0x0100U

/* Exported types ------------------------------------------------------------*/

/** @defgroup FLASH_Exported_Types FLASH Exported Types
  * @{
  */

/**
 * @brief  FLASH handle state enumeration.
 */
typedef enum
{
    HAL_FLASH_STATE_RESET = 0x00U,  /*!< Peripheral not initialized              */
    HAL_FLASH_STATE_READY = 0x01U,  /*!< Peripheral initialized and ready        */
    HAL_FLASH_STATE_BUSY  = 0x02U,  /*!< An internal operation is ongoing        */
    HAL_FLASH_STATE_ERROR = 0x03U   /*!< Error state                             */
} HAL_FLASH_StateTypeDef;

/**
 * @brief  FLASH flag state enumeration.
 * @note   The HAL library core does not provide a generic "FlagStatus"
 *         enumeration, so the flag state is defined locally for the FLASH
 *         module.
 */
typedef enum
{
    FLASH_FLAG_RESET = 0x00U,       /*!< Flag is reset                          */
    FLASH_FLAG_SET   = 0x01U        /*!< Flag is set                            */
} FLASH_FlagStatusTypeDef;

/**
 * @brief  FLASH interrupt new state enumeration.
 */
typedef enum
{
    FLASH_IT_DISABLE = 0x00U,       /*!< Disable the selected interrupt         */
    FLASH_IT_ENABLE  = 0x01U        /*!< Enable the selected interrupt          */
} FLASH_ITStateTypeDef;

/**
 * @brief  FLASH command ID enumeration (written to the CIDR register).
 */
typedef enum
{
    FLASH_Cmd_SectorErase       = 0x01U,  /*!< Sector erase                       */
    FLASH_Cmd_BlockErase        = 0x02U,  /*!< Block erase                        */
    FLASH_Cmd_WPInfoSectorErase = 0x03U,  /*!< Write protection info sector erase */
    FLASH_Cmd_AllBlockErase     = 0x04U,  /*!< All blocks erase                   */
    FLASH_Cmd_Program           = 0x10U,  /*!< Program                            */
    FLASH_Cmd_SecKEYVerif       = 0x20U   /*!< Security key verification          */
} FLASHCmd_TypeDef;

/**
 * @brief  FLASH initialization structure definition.
 */
typedef struct
{
    uint32 Size;        /*!< sizeof(FLASH_InitTypeDef), set by the user
                             after clearing the structure */
    uint32 Version;     /*!< Structure semantic version: @ref FLASH_INIT_VERSION
                             (FLASH_INIT_V1 = 0x0100U) */
    uint32 ClockFreq;   /*!< EFLASH controller clock frequency, in MHz. It shall
                             match the AXI_Bus0 clock frequency (e.g. 180 for a
                             180 MHz AXI bus). 0 means "skip the clock frequency
                             configuration in HAL_FLASH_Init".                  */
    uint32 Reserved[2]; /*!< Reserved for future extension (must be 0) */
} FLASH_InitTypeDef;

/**
 * @brief FLASH init structure version macros.
 * @note  FLASH_INIT_V1 is the current version. Future versions must be
 *        appended after the existing fields (architecture spec section 22.5).
 */
#define FLASH_INIT_V1  0x0100U   /*!< FLASH Init structure version V1.0 */
#define FLASH_INIT_VERSION  FLASH_INIT_V1   /*!< Current FLASH Init structure version */

/**
 * @brief  FLASH handle structure definition.
 */
typedef struct __HAL_FLASH_HandleTypeDef
{
    FLASH_TypeDef          *Instance;  /*!< FLASH registers base address           */
    FLASH_InitTypeDef      Init;       /*!< FLASH configuration parameters         */
    HAL_LockTypeDef        Lock;       /*!< Locking object                         */
    __IO HAL_FLASH_StateTypeDef State; /*!< FLASH operation state                  */
    __IO uint32            ErrorCode;  /*!< FLASH error code                       */
#if (USE_RTOS == 1)
    HAL_MutexTypeDef       LockMutex;  /*!< RTOS mutex handle (created by the
                                            user porting layer, e.g. in
                                            HAL_FLASH_MspInit)                   */
#endif /* USE_RTOS */
} HAL_FLASH_HandleTypeDef;

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @defgroup FLASH_Exported_Constants FLASH Exported Constants
  * @{
  */

/** @defgroup FLASH_Unlock_Keys FLASH Unlock Keys
  * @{
  */
#define FLASH_UNLOCK_KEY1              ((uint32)0x01020304U)   /*!< First unlock key  */
#define FLASH_UNLOCK_KEY2              ((uint32)0x0A0B0C0DU)   /*!< Second unlock key */
/**
  * @}
  */

/** @defgroup FLASH_Error_Code FLASH Error Code
  * @{
  */
#define HAL_FLASH_ERROR_NONE           ((uint32)0x00000000U)   /*!< No error                          */
#define HAL_FLASH_ERROR_OPERATION      ((uint32)0x00000001U)   /*!< Operation error (OPERR)           */
#define HAL_FLASH_ERROR_ECC1           ((uint32)0x00000002U)   /*!< ECC 1-bit error                   */
#define HAL_FLASH_ERROR_ECC2           ((uint32)0x00000004U)   /*!< ECC 2-bit error                   */
#define HAL_FLASH_ERROR_WRP            ((uint32)0x00000008U)   /*!< Write protection error            */
#define HAL_FLASH_ERROR_SECKEY         ((uint32)0x00000010U)   /*!< Security key verification error   */
#define HAL_FLASH_ERROR_ADDRESS        ((uint32)0x00000020U)   /*!< Address out of the flash range    */
#define HAL_FLASH_ERROR_PARAM          ((uint32)0x00000040U)   /*!< Invalid parameter                 */
#define HAL_FLASH_ERROR_LOCK           ((uint32)0x00000080U)   /*!< Unlock / lock sequence failed     */
/**
  * @}
  */

/** @defgroup FLASH_Memory FLASH Memory Region
  * @{
  */
#define FLASH_MEMORY_PFLASH            ((uint32)0x00000000U)   /*!< P-Flash                          */
#define FLASH_MEMORY_DFLASH            ((uint32)0x00000001U)   /*!< D-Flash                          */
/**
  * @}
  */

/** @defgroup FLASH_Size FLASH Size Definitions
  * @{
  */
#define DFLASH_MAIN_SIZE               ((uint32)(512U * 1024U))    /*!< D-Flash main size, 512 KB    */
#define DFLASH_INFO_SIZE               ((uint32)(4U * 1024U))      /*!< D-Flash info size, 4 KB       */
#define PFLASH_MAIN_SIZE               ((uint32)(4U * 512U * 1024U))  /*!< P-Flash main size, 2 MB   */
#define PFLASH_INFO_SIZE               ((uint32)(4U * 4U * 1024U))    /*!< P-Flash info size, 16 KB  */
#define DFLASH_BLOCK_SIZE              ((uint32)(512U * 1024U))   /*!< D-Flash block size, 512 KB    */
#define PFLASH_BLOCK_SIZE              ((uint32)(512U * 1024U))   /*!< P-Flash block size, 512 KB    */
#define DFLASH_SECTOR_SIZE             ((uint32)(4U * 1024U))     /*!< D-Flash sector size, 4 KB     */
#define PFLASH_SECTOR_SIZE             ((uint32)(4U * 1024U))     /*!< P-Flash sector size, 4 KB     */
#define DFLASH_ROM_SIZE                ((uint32)512U)             /*!< D-Flash program ROM size      */
#define PFLASH_ROM_SIZE                ((uint32)512U)             /*!< P-Flash program ROM size      */
#define EFLASH_PROGRAM_MAXLEN          ((uint32)64U)              /*!< Max data length per command (DLR), in 8-byte units */
#define EFLASH_WRITE_UNIT_SIZE         ((uint32)8U)               /*!< FLASH write unit, in bytes    */
/**
  * @}
  */

/** @defgroup FLASH_Flag_definition FLASH Flag definition
  * @brief FLASH status flag definition (SR register bits)
  * @{
  */
#define FLASH_FLAG_LOCK                ((uint32)0x00000001U)      /*!< Flash lock status flag                  */
#define FLASH_FLAG_BUSY                ((uint32)0x00000002U)      /*!< Flash busy flag                         */
#define FLASH_FLAG_FINISH              ((uint32)0x00000004U)      /*!< Flash command finish flag               */
#define FLASH_FLAG_OPERR               ((uint32)0x00000008U)      /*!< Flash operation error flag              */
#define FLASH_FLAG_ECC1ERR             ((uint32)0x00000010U)      /*!< Flash ECC 1-bit error flag              */
#define FLASH_FLAG_ECC2ERR             ((uint32)0x00000020U)      /*!< Flash ECC 2-bit error flag              */
#define FLASH_FLAG_WPERR               ((uint32)0x00000040U)      /*!< Flash write protection error flag       */
#define FLASH_FLAG_SECKEYERR           ((uint32)0x00000080U)      /*!< Flash security key verification error   */
#define FLASH_FLAG_CLKSWRDY            ((uint32)0x00010000U)      /*!< Flash clock switching status flag       */
/**
  * @}
  */

/** @defgroup FLASH_Flag_Clear_definition FLASH Flag Clear definition
  * @brief FLASH status flag clear values (write-1-to-clear to SR)
  * @{
  */
#define FLASH_CLEAR_FINISH             ((uint32)0x00000004U)      /*!< Flash command finish clear flag  */
#define FLASH_CLEAR_OPERR              ((uint32)0x00000008U)      /*!< Flash operation error clear flag */
#define FLASH_CLEAR_ECC1ERR            ((uint32)0x00000010U)      /*!< Flash ECC 1-bit error clear flag */
#define FLASH_CLEAR_ECC2ERR            ((uint32)0x00000020U)      /*!< Flash ECC 2-bit error clear flag */
#define FLASH_CLEAR_WPERR              ((uint32)0x00000040U)      /*!< Flash write protection error clear */
/**
  * @}
  */

/** @defgroup FLASH_Interrupt_definition FLASH Interrupt definition
  * @{
  */
#define FLASH_IT_FINIE                 ((uint32)0x00000001U)      /*!< Flash command finish interrupt enable */
#define FLASH_IT_OPEIE                 ((uint32)0x00000002U)      /*!< Flash operation error interrupt enable */
#define FLASH_IT_ECC2EIE               ((uint32)0x00000004U)      /*!< Flash ECC 2-bit error interrupt enable */
/**
  * @}
  */

/** @defgroup FLASH_Interrupt_Clear_definition FLASH Interrupt Clear definition
  * @{
  */
#define FLASH_CLEAR_IT_FINISH          ((uint32)0x00000004U)      /*!< Flash command finish clear flag  */
#define FLASH_CLEAR_IT_OPERR           ((uint32)0x00000008U)      /*!< Flash operation error clear flag */
#define FLASH_CLEAR_IT_ECC2ERR         ((uint32)0x00000020U)      /*!< Flash ECC 2-bit error clear flag */
/**
  * @}
  */

/** @defgroup FLASH_State_Error_Bits FLASH State Error Bits
  * @brief Combination of the SR error flags considered as an operation error.
  * @{
  */
#define FLASH_STATE_ERROR_BITS         (EFLASH_SR_OPERR | EFLASH_SR_ECC1ERR | \
                                        EFLASH_SR_ECC2ERR | EFLASH_SR_WPERR | \
                                        EFLASH_SR_SECKEYERR)
/**
  * @}
  */

/**
  * @}
  */

/* Exported macros ------------------------------------------------------------*/

/** @defgroup FLASH_Exported_Macros FLASH Exported Macros
  * @{
  */

/**
 * @brief  Get the specified FLASH flag status.
 * @param  __HANDLE__: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  __FLAG__: specifies the FLASH flag to check (FLASH_FLAG_xxx).
 * @retval The value of the SR register masked with __FLAG__ (non-zero = set).
 */
#define __HAL_FLASH_GET_FLAG(__HANDLE__, __FLAG__)   (((__HANDLE__)->Instance->SR & (__FLAG__)))

/**
 * @brief  Clear the specified FLASH flags.
 * @param  __HANDLE__: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  __FLAG__: specifies the FLASH flags to clear (FLASH_CLEAR_xxx).
 * @retval None
 */
#define __HAL_FLASH_CLEAR_FLAG(__HANDLE__, __FLAG__) ((__HANDLE__)->Instance->SR = (__FLAG__))

/**
 * @brief  Enable the specified FLASH interrupt.
 * @param  __HANDLE__: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  __INTERRUPT__: specifies the FLASH interrupt source (FLASH_IT_xxx).
 * @retval None
 */
#define __HAL_FLASH_ENABLE_IT(__HANDLE__, __INTERRUPT__)  ((__HANDLE__)->Instance->CR |= (__INTERRUPT__))

/**
 * @brief  Disable the specified FLASH interrupt.
 * @param  __HANDLE__: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  __INTERRUPT__: specifies the FLASH interrupt source (FLASH_IT_xxx).
 * @retval None
 */
#define __HAL_FLASH_DISABLE_IT(__HANDLE__, __INTERRUPT__) ((__HANDLE__)->Instance->CR &= ~(uint32)(__INTERRUPT__))

/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/

/** @addtogroup FLASH_Exported_Functions
  * @{
  */

/** @addtogroup FLASH_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Fills each FLASH_InitStruct member with its default value
 *         (ClockFreq = 0: clock frequency not configured by HAL_FLASH_Init).
 * @param  InitStruct: pointer to a FLASH_InitTypeDef structure.
 * @retval None
 */
void HAL_FLASH_StructInit(FLASH_InitTypeDef *InitStruct);

/**
 * @brief  Initializes the EFLASH controller according to the parameters in
 *         the Init field of the handle.
 * @note   The following operations are performed:
 *         - The low level hardware initialization (EFLASH clock enable) is
 *           done in the HAL_FLASH_MspInit() callback;
 *         - If Init.ClockFreq is not zero, the controller is unlocked, the
 *           clock frequency field (CR.CLKFRQ) is set and the controller is
 *           locked again. This step shall be done BEFORE the system clock
 *           is switched to its final frequency (the CLKFRQ field must
 *           always match the AXI_Bus0 frequency).
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_FLASH_Init(HAL_FLASH_HandleTypeDef *hflash);

/**
 * @brief  De-initializes the EFLASH controller.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR
 */
HAL_StatusTypeDef HAL_FLASH_DeInit(HAL_FLASH_HandleTypeDef *hflash);

/**
 * @brief  Initializes the FLASH MSP. Weak function; the user may override
 *         it. The default implementation enables the EFLASH peripheral
 *         clock and releases its reset through the SMU (AB0CFGR register).
 * @note   The AXI bus clocks (AXI4Bus3 / AXILite4Bus2) feeding the FLASH
 *         controller are expected to be already enabled by the system
 *         clock configuration code (SMU module).
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval None
 */
void HAL_FLASH_MspInit(HAL_FLASH_HandleTypeDef *hflash);

/**
 * @brief  De-initializes the FLASH MSP. Weak function; the user may
 *         override it. The default implementation disables the EFLASH
 *         peripheral clock.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval None
 */
void HAL_FLASH_MspDeInit(HAL_FLASH_HandleTypeDef *hflash);

/**
  * @}
  */

/** @addtogroup FLASH_Exported_Functions_Group2 Peripheral Control functions
  * @{
  */

/**
 * @brief  Unlocks the EFLASH controller registers.
 * @note   Must be called before any erase / program / protection operation.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_FLASH_Unlock(HAL_FLASH_HandleTypeDef *hflash);

/**
 * @brief  Locks the EFLASH controller registers.
 * @note   Shall be called after the erase / program / protection sequence
 *         to protect the flash against spurious writes.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_FLASH_Lock(HAL_FLASH_HandleTypeDef *hflash);

/**
 * @brief  Sets the EFLASH controller clock frequency (CR.CLKFRQ field).
 * @note   The controller must be unlocked before calling this function (the
 *         HAL_FLASH_Init() function handles the unlock / lock sequence
 *         itself when Init.ClockFreq is not zero). The value shall be equal
 *         to the AXI_Bus0 clock frequency, in MHz.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  ClockFreq: EFLASH clock frequency in MHz (e.g. 180).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY / HAL_TIMEOUT
 */
HAL_StatusTypeDef HAL_FLASH_SetClockFrequency(HAL_FLASH_HandleTypeDef *hflash, uint16 ClockFreq);

/**
  * @}
  */

/** @addtogroup FLASH_Exported_Functions_Group3 Programming operation functions
  * @{
  */

/**
 * @brief  Programs the specified flash region.
 * @note   The address, the size and the buffer shall be aligned on the
 *         8-byte write unit (EFLASH_WRITE_UNIT_SIZE). The controller shall
 *         be unlocked before the call. The data buffer is fed to the
 *         controller in 8-byte pairs (DR0 = low 32-bit, DR1 = high 32-bit)
 *         and programmed by ROM-sized (512 bytes) commands.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  Address: start address to program (P-Flash / D-Flash main or info
 *         region).
 * @param  Size: size in bytes to program (multiple of 8).
 * @param  pData: pointer to the data buffer to program.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_FLASH_Program(HAL_FLASH_HandleTypeDef *hflash, uint32 Address, uint32 Size,
                                    const uint32 *pData);

/**
  * @}
  */

/** @addtogroup FLASH_Exported_Functions_Group4 Read operation functions
  * @{
  */

/**
 * @brief  Reads data from the specified flash region.
 * @note   The address and the size shall be aligned on 4 bytes. The ECC
 *         1-bit / 2-bit error flags are checked while reading; an ECC
 *         error aborts the read operation.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  Address: start address to read (4-byte aligned).
 * @param  Size: size in bytes to read (multiple of 4).
 * @param  pData: pointer to the destination buffer.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_FLASH_Read(HAL_FLASH_HandleTypeDef *hflash, uint32 Address, uint32 Size,
                                 uint32 *pData);

/**
  * @}
  */

/** @addtogroup FLASH_Exported_Functions_Group5 Flag and interrupt management functions
  * @{
  */

/**
 * @brief  Checks whether the specified flash flag is set or not.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  FlashFlag: specifies the flag to check (FLASH_FLAG_xxx).
 * @retval FLASH_FlagStatusTypeDef: FLASH_FLAG_SET / FLASH_FLAG_RESET
 */
FLASH_FlagStatusTypeDef HAL_FLASH_GetFlagStatus(HAL_FLASH_HandleTypeDef *hflash, uint32 FlashFlag);

/**
 * @brief  Clears the specified flash flags.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  FlashFlag: specifies the flags to clear (FLASH_CLEAR_xxx).
 * @retval None
 */
void HAL_FLASH_ClearFlagStatus(HAL_FLASH_HandleTypeDef *hflash, uint32 FlashFlag);

/**
 * @brief  Enables or disables the specified flash interrupts.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  FlashIT: specifies the interrupt source (FLASH_IT_xxx).
 * @param  NewState: new state (FLASH_IT_ENABLE / FLASH_IT_DISABLE).
 * @retval None
 */
void HAL_FLASH_ITConfig(HAL_FLASH_HandleTypeDef *hflash, uint32 FlashIT,
                        FLASH_ITStateTypeDef NewState);

/**
 * @brief  Clears the flash interrupt pending bits.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  FlashIT: specifies the pending bit to clear (FLASH_CLEAR_IT_xxx).
 * @retval None
 */
void HAL_FLASH_ClearITPendingBit(HAL_FLASH_HandleTypeDef *hflash, uint32 FlashIT);

/**
  * @}
  */

/** @addtogroup FLASH_Exported_Functions_Group6 State functions
  * @{
  */

/**
 * @brief  Returns the FLASH error code.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval uint32: the error code (HAL_FLASH_ERROR_xxx combination).
 */
uint32 HAL_FLASH_GetError(HAL_FLASH_HandleTypeDef *hflash);

/**
 * @brief  Returns the FLASH handle state.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval HAL_FLASH_StateTypeDef: the current handle state.
 */
HAL_FLASH_StateTypeDef HAL_FLASH_GetState(HAL_FLASH_HandleTypeDef *hflash);

/**
  * @}
  */

/**
  * @}
  */

/* Exported types ------------------------------------------------------------*/

/** @addtogroup FLASH_Exported_Types FLASH Exported Types
  * @{
  */

/**
 * @brief  FLASH erase initialization structure definition.
 * @note   The AS32x601 FLASH controller is addressed by absolute addresses
 *         (not by sector indexes), so this structure holds an address and a
 *         length instead.
 */
typedef struct
{
    uint32 TypeErase;   /*!< Erase type: FLASH_TYPEERASE_SECTORS /
                             FLASH_TYPEERASE_BLOCKS / FLASH_TYPEERASE_MASSERASE */
    uint32 Address;     /*!< Start address to erase (SECTORS / BLOCKS only)     */
    uint32 Length;      /*!< Length in bytes to erase (SECTORS / BLOCKS only)   */
} FLASH_EraseInitTypeDef;

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @addtogroup FLASH_Exported_Constants FLASH Exported Constants
  * @{
  */

/** @defgroup FLASH_Type_Erase FLASH Type Erase
  * @{
  */
#define FLASH_TYPEERASE_SECTORS        ((uint32)0x00000000U)   /*!< Erase by 4 KB sector             */
#define FLASH_TYPEERASE_BLOCKS         ((uint32)0x00000001U)   /*!< Erase by 512 KB block            */
#define FLASH_TYPEERASE_MASSERASE      ((uint32)0x00000002U)   /*!< Erase all main blocks            */
/**
  * @}
  */

/** @defgroup FLASH_Write_Protection FLASH Write Protection Areas
  * @{
  */
#define FLASH_WP_AREA1                 ((uint32)0x00000001U)      /*!< Write protection area 1  */
#define FLASH_WP_AREA2                 ((uint32)0x00000002U)      /*!< Write protection area 2  */
#define FLASH_WP_AREA3                 ((uint32)0x00000004U)      /*!< Write protection area 3  */
#define FLASH_WP_AREA4                 ((uint32)0x00000008U)      /*!< Write protection area 4  */
#define FLASH_WP_AREA5                 ((uint32)0x00000010U)      /*!< Write protection area 5  */
#define FLASH_WP_AREA6                 ((uint32)0x00000020U)      /*!< Write protection area 6  */
#define FLASH_WP_AREA7                 ((uint32)0x00000040U)      /*!< Write protection area 7  */
#define FLASH_WP_AREA8                 ((uint32)0x00000080U)      /*!< Write protection area 8  */
#define FLASH_WP_AREA9                 ((uint32)0x00000100U)      /*!< Write protection area 9  */
#define FLASH_WP_AREA10                ((uint32)0x00000200U)      /*!< Write protection area 10 */
#define FLASH_WP_AREA11                ((uint32)0x00000400U)      /*!< Write protection area 11 */
#define FLASH_WP_AREA12                ((uint32)0x00000800U)      /*!< Write protection area 12 */
#define FLASH_WP_AREA13                ((uint32)0x00001000U)      /*!< Write protection area 13 */
#define FLASH_WP_AREA14                ((uint32)0x00002000U)      /*!< Write protection area 14 */
#define FLASH_WP_AREA15                ((uint32)0x00004000U)      /*!< Write protection area 15 */
#define FLASH_WP_AREA16                ((uint32)0x00008000U)      /*!< Write protection area 16 */
#define FLASH_WP_AREA17                ((uint32)0x00010000U)      /*!< Write protection area 17 */
#define FLASH_WP_AREA18                ((uint32)0x00020000U)      /*!< Write protection area 18 */
#define FLASH_WP_AREA19                ((uint32)0x00040000U)      /*!< Write protection area 19 */
#define FLASH_WP_AREA20                ((uint32)0x00080000U)      /*!< Write protection area 20 */
#define FLASH_WP_AREA21                ((uint32)0x00100000U)      /*!< Write protection area 21 */
#define FLASH_WP_AREA22                ((uint32)0x00200000U)      /*!< Write protection area 22 */
#define FLASH_WP_AREA23                ((uint32)0x00400000U)      /*!< Write protection area 23 */
#define FLASH_WP_AREA24                ((uint32)0x00800000U)      /*!< Write protection area 24 */
#define FLASH_WP_AREA25                ((uint32)0x01000000U)      /*!< Write protection area 25 */
#define FLASH_WP_AREA26                ((uint32)0x02000000U)      /*!< Write protection area 26 */
#define FLASH_WP_AREA27                ((uint32)0x04000000U)      /*!< Write protection area 27 */
#define FLASH_WP_AREA28                ((uint32)0x08000000U)      /*!< Write protection area 28 */
#define FLASH_WP_AREA29                ((uint32)0x10000000U)      /*!< Write protection area 29 */
#define FLASH_WP_AREA30                ((uint32)0x20000000U)      /*!< Write protection area 30 */
#define FLASH_WP_AREA31                ((uint32)0x40000000U)      /*!< Write protection area 31 */
#define FLASH_WP_AREA32                ((uint32)0x80000000U)      /*!< Write protection area 32 */
/**
  * @}
  */

/** @defgroup FLASH_Security FLASH Security Flags
  * @{
  */
/* NOTE on the security key flag value: the SECR register field is
 * SECKEYEN[1:0] located at bits [3:2], i.e. mask 0xC, consistent with the
 * register manual. The AS32x601 header "as32x601.h" defines
 * EFLASH_SECR_SECKEYEN_DPos = 0 (mask 0x3), which contradicts the register
 * manual (device header defect); this driver deliberately uses the hard-coded
 * 0xC value and never references the EFLASH_SECR_SECKEYEN* macros. */
#define FLASH_SECFLAG_KEY              ((uint32)0x0000000CU)      /*!< Flash security key flag (SECKEYEN[1:0] @ bit[3:2]) */
#define FLASH_SECFLAG_RP               ((uint32)0x00000003U)      /*!< Flash read protection flag (RPROT) */
/**
  * @}
  */

/**
  * @}
  */

/* Exported functions --------------------------------------------------------*/

/** @addtogroup FLASH_Exported_Functions
  * @{
  */

/** @addtogroup FLASH_Exported_Functions_Group1 Erase operation functions
  * @{
  */

/**
 * @brief  Performs a mass erase / a sector erase / a block erase on the
 *         flash main regions.
 * @note   The controller shall be unlocked before the call. For
 *         FLASH_TYPEERASE_SECTORS / BLOCKS, the [Address, Address+Length]
 *         range shall be fully contained in the P-Flash main or the D-Flash
 *         main region, and the start address shall be aligned on the erase
 *         unit (4 KB sector / 512 KB block). The last erase step is rounded
 *         up to the erase unit.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  pEraseInit: pointer to a FLASH_EraseInitTypeDef structure.
 * @param  AddressError: pointer to a uint32 variable that receives the
 *         address of the erase step that failed (optional, may be NULL).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_FLASH_Erase(HAL_FLASH_HandleTypeDef *hflash,
                                    FLASH_EraseInitTypeDef *pEraseInit,

                                    uint32 *AddressError);

/**
 * @brief  Erases the write-protection information sector (P-Flash info
 *         region @ 0x01200000).
 * @note   The controller shall be unlocked before the call. This operation
 *         is used to remove the write protection settings.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_FLASH_EraseWriteProtection(HAL_FLASH_HandleTypeDef *hflash);

/**
  * @}
  */

/** @addtogroup FLASH_Exported_Functions_Group2 Write protection functions
  * @{
  */

/**
 * @brief  Checks the write protection status of a P-Flash area.
 * @note   The write protection register bit is 1 when the area is NOT
 *         protected (inverted logic: '0' = protected, '1' = unprotected):
 *         'SET' means unprotected.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  ProtectArea: write protection area (FLASH_WP_AREA1..32).
 * @retval FLASH_FlagStatusTypeDef: FLASH_FLAG_SET (unprotected) /
 *         FLASH_FLAG_RESET (protected)
 */
FLASH_FlagStatusTypeDef HAL_FLASH_GetPFlashWriteProtStatus(HAL_FLASH_HandleTypeDef *hflash,
                                                           uint32 ProtectArea);

/**
 * @brief  Sets the write protection of a P-Flash area.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  ProtectArea: write protection area (FLASH_WP_AREA1..32).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_FLASH_SetPFlashWriteProtection(HAL_FLASH_HandleTypeDef *hflash,
                                                     uint32 ProtectArea);

/**
 * @brief  Resets the write protection of a P-Flash area.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  ProtectArea: write protection area (FLASH_WP_AREA1..32).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_FLASH_ResetPFlashWriteProtection(HAL_FLASH_HandleTypeDef *hflash,
                                                       uint32 ProtectArea);

/**
 * @brief  Checks the write protection status of a D-Flash area.
 * @note   The write protection register bit is 1 when the area is NOT
 *         protected (inverted logic: '0' = protected, '1' = unprotected):
 *         'SET' means unprotected.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  ProtectArea: write protection area (FLASH_WP_AREA1..8).
 * @retval FLASH_FlagStatusTypeDef: FLASH_FLAG_SET (unprotected) /
 *         FLASH_FLAG_RESET (protected)
 */
FLASH_FlagStatusTypeDef HAL_FLASH_GetDFlashWriteProtStatus(HAL_FLASH_HandleTypeDef *hflash,
                                                           uint32 ProtectArea);

/**
 * @brief  Sets the write protection of a D-Flash area.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  ProtectArea: write protection area (FLASH_WP_AREA1..8).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_FLASH_SetDFlashWriteProtection(HAL_FLASH_HandleTypeDef *hflash,
                                                     uint32 ProtectArea);

/**
 * @brief  Resets the write protection of a D-Flash area.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  ProtectArea: write protection area (FLASH_WP_AREA1..8).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_FLASH_ResetDFlashWriteProtection(HAL_FLASH_HandleTypeDef *hflash,
                                                       uint32 ProtectArea);

/**
  * @}
  */

/** @addtogroup FLASH_Exported_Functions_Group3 ECC error management functions
  * @{
  */

/**
 * @brief  Returns the ECC 2-bit error address.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval uint32: ECC 2-bit error address.
 */
uint32 HAL_FLASH_GetECCErrorAddress(HAL_FLASH_HandleTypeDef *hflash);

/**
 * @brief  Clears the ECC 2-bit error address register.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval None
 */
void HAL_FLASH_ClearECCErrorAddress(HAL_FLASH_HandleTypeDef *hflash);

/**
  * @}
  */

/** @addtogroup FLASH_Exported_Functions_Group4 Security functions
  * @{
  */

/**
 * @brief  Checks the security flag status (read protection / security key).
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  FlashSECFlag: security flag to check (FLASH_SECFLAG_KEY /
 *         FLASH_SECFLAG_RP).
 * @retval FLASH_FlagStatusTypeDef: FLASH_FLAG_SET / FLASH_FLAG_RESET
 */
FLASH_FlagStatusTypeDef HAL_FLASH_GetSECFlagStatus(HAL_FLASH_HandleTypeDef *hflash,
                                                   uint32 FlashSECFlag);

/**
 * @brief  Enters the flash security key and launches the key verification.
 * @note   The controller shall be unlocked before the call.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  SEC_KEY0: security key, low 32 bits.
 * @param  SEC_KEY1: security key, high 32 bits.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY
 */
HAL_StatusTypeDef HAL_FLASH_InputSECKEY(HAL_FLASH_HandleTypeDef *hflash, uint32 SEC_KEY0,
                                        uint32 SEC_KEY1);

/**
  * @}
  */

/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/

/** @addtogroup FLASH_Private_Macros FLASH Private Macros
  * @{
  */

/**
 * @brief  Check that the erase type is valid.
 */
#define IS_FLASH_TYPEERASE(TYPEERASE) (((TYPEERASE) == FLASH_TYPEERASE_SECTORS) || \
                                       ((TYPEERASE) == FLASH_TYPEERASE_BLOCKS)  || \
                                       ((TYPEERASE) == FLASH_TYPEERASE_MASSERASE))

/**
 * @brief  Check that the P-Flash write protection area is valid.
 */
#define IS_PFLASH_WP_AREAx(AREAx) (((AREAx) == FLASH_WP_AREA1)  || ((AREAx) == FLASH_WP_AREA2)  || \
                                   ((AREAx) == FLASH_WP_AREA3)  || ((AREAx) == FLASH_WP_AREA4)  || \
                                   ((AREAx) == FLASH_WP_AREA5)  || ((AREAx) == FLASH_WP_AREA6)  || \
                                   ((AREAx) == FLASH_WP_AREA7)  || ((AREAx) == FLASH_WP_AREA8)  || \
                                   ((AREAx) == FLASH_WP_AREA9)  || ((AREAx) == FLASH_WP_AREA10) || \
                                   ((AREAx) == FLASH_WP_AREA11) || ((AREAx) == FLASH_WP_AREA12) || \
                                   ((AREAx) == FLASH_WP_AREA13) || ((AREAx) == FLASH_WP_AREA14) || \
                                   ((AREAx) == FLASH_WP_AREA15) || ((AREAx) == FLASH_WP_AREA16) || \
                                   ((AREAx) == FLASH_WP_AREA17) || ((AREAx) == FLASH_WP_AREA18) || \
                                   ((AREAx) == FLASH_WP_AREA19) || ((AREAx) == FLASH_WP_AREA20) || \
                                   ((AREAx) == FLASH_WP_AREA21) || ((AREAx) == FLASH_WP_AREA22) || \
                                   ((AREAx) == FLASH_WP_AREA23) || ((AREAx) == FLASH_WP_AREA24) || \
                                   ((AREAx) == FLASH_WP_AREA25) || ((AREAx) == FLASH_WP_AREA26) || \
                                   ((AREAx) == FLASH_WP_AREA27) || ((AREAx) == FLASH_WP_AREA28) || \
                                   ((AREAx) == FLASH_WP_AREA29) || ((AREAx) == FLASH_WP_AREA30) || \
                                   ((AREAx) == FLASH_WP_AREA31) || ((AREAx) == FLASH_WP_AREA32))

/**
 * @brief  Check that the D-Flash write protection area is valid.
 */
#define IS_DFLASH_WP_AREAx(AREAx) (((AREAx) == FLASH_WP_AREA1) || ((AREAx) == FLASH_WP_AREA2) || \
                                   ((AREAx) == FLASH_WP_AREA3) || ((AREAx) == FLASH_WP_AREA4) || \
                                   ((AREAx) == FLASH_WP_AREA5) || ((AREAx) == FLASH_WP_AREA6) || \
                                   ((AREAx) == FLASH_WP_AREA7) || ((AREAx) == FLASH_WP_AREA8))

/**
 * @brief  Check that the security flag is valid.
 */
#define IS_FLASH_SECFLAG(SECFLAG) (((SECFLAG) == FLASH_SECFLAG_KEY) || ((SECFLAG) == FLASH_SECFLAG_RP))

/**
  * @}
  */

/* Private constants ---------------------------------------------------------*/

/** @defgroup FLASH_Private_Constants FLASH Private Constants
  * @brief Internal flash region identifiers of this driver.
  * @{
  */
#define FLASH_REGION_PFLASH_MAIN        ((uint32)0x00U)
#define FLASH_REGION_DFLASH_MAIN        ((uint32)0x01U)
#define FLASH_REGION_PFLASH_INFO        ((uint32)0x02U)
#define FLASH_REGION_DFLASH_INFO        ((uint32)0x03U)
#define FLASH_REGION_INVALID            ((uint32)0xFFU)
/**
  * @}
  */

/* Private macros ------------------------------------------------------------*/

/** @defgroup FLASH_Private_Macros FLASH Private Macros
  * @{
  */

/**
 * @brief  Check that the FLASH peripheral instance is valid.
 */
#define IS_FLASH_INSTANCE(INSTANCE) ((INSTANCE) == EFLASH)

/**
 * @brief  Check that the flash command is valid.
 */
#define IS_FLASH_CMD(CMD) (((CMD) == FLASH_Cmd_SectorErase)       || ((CMD) == FLASH_Cmd_BlockErase)    || \
                           ((CMD) == FLASH_Cmd_WPInfoSectorErase) || ((CMD) == FLASH_Cmd_AllBlockErase) || \
                           ((CMD) == FLASH_Cmd_Program)           || ((CMD) == FLASH_Cmd_SecKEYVerif))

/**
 * @brief  Check that the flash flag is valid.
 */
#define IS_FLASH_FLAG(FLAG) (((FLAG) == FLASH_FLAG_LOCK)    || ((FLAG) == FLASH_FLAG_BUSY)   || \
                             ((FLAG) == FLASH_FLAG_FINISH)  || ((FLAG) == FLASH_FLAG_OPERR)  || \
                             ((FLAG) == FLASH_FLAG_ECC1ERR) || ((FLAG) == FLASH_FLAG_ECC2ERR) || \
                             ((FLAG) == FLASH_FLAG_WPERR)   || ((FLAG) == FLASH_FLAG_SECKEYERR) || \
                             ((FLAG) == FLASH_FLAG_CLKSWRDY))

/**
 * @brief  Check that the flash clear flag value is valid.
 */
#define IS_FLASH_CLEAR(CLEAR) (((CLEAR) == FLASH_CLEAR_FINISH)  || ((CLEAR) == FLASH_CLEAR_OPERR) || \
                               ((CLEAR) == FLASH_CLEAR_ECC1ERR) || ((CLEAR) == FLASH_CLEAR_ECC2ERR) || \
                               ((CLEAR) == FLASH_CLEAR_WPERR))

/**
 * @brief  Check that the flash interrupt source is valid.
 */
#define IS_FLASH_IT(IT) (((IT) == FLASH_IT_FINIE) || ((IT) == FLASH_IT_OPEIE) || \
                         ((IT) == FLASH_IT_ECC2EIE))

/**
 * @brief  Check that the flash interrupt clear value is valid.
 */
#define IS_FLASH_CLEAR_IT(CLEAR) (((CLEAR) == FLASH_CLEAR_IT_FINISH) || ((CLEAR) == FLASH_CLEAR_IT_OPERR) || \
                                  ((CLEAR) == FLASH_CLEAR_IT_ECC2ERR))

/**
 * @brief  Check that the memory region is valid.
 */
#define IS_FLASH_MEMORY(MEMORY) (((MEMORY) == FLASH_MEMORY_PFLASH) || \
                                 ((MEMORY) == FLASH_MEMORY_DFLASH))

/**
  * @}
  */

/* Private functions ---------------------------------------------------------*/

/** @defgroup FLASH_Private_Functions FLASH Private Functions
  * @brief Internal helpers of this driver. They are not part of the public API.
  * @{
  */

/**
 * @brief  Check the FLASH handle and its peripheral instance.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval uint32: 1 if the handle is valid, 0 otherwise.
 */
uint32 FLASH_HandleIsValid(const HAL_FLASH_HandleTypeDef *hflash);

/**
 * @brief  Check the handle state before a flash operation (ARCH-CONST-09).
 * @note   Returns HAL_BUSY while the handle is busy with another operation and
 *         HAL_ERROR while it has not been initialized (HAL_FLASH_Init() is
 *         required first). The error state is recoverable.
 * @note   The lock management (HAL_FLASH_Unlock / HAL_FLASH_Lock) and the
 *         clock frequency programming are deliberately not gated: they are the
 *         configuration path that may legitimately run before
 *         HAL_FLASH_Init().
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_BUSY / HAL_ERROR.
 */
HAL_StatusTypeDef FLASH_CheckState(HAL_FLASH_HandleTypeDef *hflash);

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_FLASH_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the acquisition is bounded by the Timeout parameter (RTOS
 *         ticks, which with the usual 1 ms tick is the same quantity as the
 *         millisecond Timeout of the public API); HAL_MAX_DELAY waits forever.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS, wait expired) /
 *         HAL_ERROR (RTOS, mutex not created) / HAL_BUSY (bare metal, the
 *         handle is already locked).
 */
HAL_StatusTypeDef FLASH_LockHandle(HAL_FLASH_HandleTypeDef *hflash, uint32 Timeout);

/**
 * @brief  Unlock the handle.
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @retval None
 */
void FLASH_UnlockHandle(HAL_FLASH_HandleTypeDef *hflash);

/**
 * @brief  Determine the flash region containing the [Address, Address+Length]
 *         range.
 * @param  Address: start address.
 * @param  Length: length in bytes.
 * @retval uint32: FLASH_REGION_xxx, or FLASH_REGION_INVALID when the range
 *         is not fully contained in a single flash region.
 */
uint32 FLASH_GetRegion(uint32 Address, uint32 Length);

/**
 * @brief  Return the sector size (bytes) of the given flash region.
 * @param  Region: flash region (FLASH_REGION_xxx).
 * @retval uint32: sector size in bytes (0 for an invalid region).
 */
uint32 FLASH_GetSectorSize(uint32 Region);

/**
 * @brief  Set the flash operation command (CIDR register).
 * @param  Cmd: operation command (FLASHCmd_TypeDef).
 * @retval None
 */
void FLASH_SetCommand(FLASHCmd_TypeDef Cmd);

/**
 * @brief  Set the flash operation address (AR register).
 * @param  Address: operation address.
 * @retval None
 */
void FLASH_SetAddress(uint32 Address);

/**
 * @brief  Launch a flash command and wait for its completion.
 * @note   The command, address, data length and data must have been set
 *         beforehand (FLASH_SetCommand / FLASH_SetAddress /
 *         FLASH_SetDataLength / DR0 / DR1).
 * @param  hflash: pointer to a HAL_FLASH_HandleTypeDef structure.
 * @param  Timeout: maximum wait duration in ms.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY / HAL_TIMEOUT
 */
HAL_StatusTypeDef FLASH_StartCmd(HAL_FLASH_HandleTypeDef *hflash, uint32 Timeout);

/**
  * @}
  */

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_FLASH_H */

/*****END OF FILE*****/
