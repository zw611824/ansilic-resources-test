# SPI 应用与测试参考

供 skill 按需求检索 AS32x601 HAL SPI 示例。别名/关键词：SPI、主机、从机、全双工、片选、NSS/SSR、CPOL、CPHA、帧宽、分频、轮询、中断、DMA、FIFO、接收溢出。共有 18 个独立用例。

HAL 依据：[头文件](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_spi.h)、[实现](../../HAL_LIBRARY/peripherals/src/as32x601_hal_spi.c)。原测试工程的 4_HAL_LIBRARY 未提供，尚不能确认原始链接版本；文中标出的源码与当前 SDK 差异须先解决再迁移。


## 实例与可选引脚

下表列出 AS32x601 LQFP144 封装的本外设信号。每根信号单独选择引脚，并核对 [GPIO AF 定义](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_gpio.h)；文档功能编号不能直接当作 HAL 编码传入。其他封装需另查引出情况。

| 信号 | 可选引脚 | 封装脚号 | 文档功能 | HAL AF |
|---|---|---|---|---|
| `SPI0_CS0` | PB12 | 101 | 功能1 | `GPIO_AF_SPI0`（0x02） |
| `SPI0_CS1` | PB11 | 129 | 功能1 | `GPIO_AF_SPI0`（0x02） |
| `SPI0_CS2` | PB10 | 131 | 功能1 | `GPIO_AF_SPI0`（0x02） |
| `SPI0_CS3` | PE15 | 135 | 功能1 | `GPIO_AF_SPI0`（0x02） |
| `SPI0_MISO` | PB15 | 62 | 功能1 | `GPIO_AF_SPI0`（0x02） |
| `SPI0_MOSI` | PB14 | 126 | 功能1 | `GPIO_AF_SPI0`（0x02） |
| `SPI0_SCK` | PB13 | 110 | 功能1 | `GPIO_AF_SPI0`（0x02） |
| `SPI1_CS0` | PG13 | 15 | 功能2 | `GPIO_AF_SPI1`（0x03） |
| `SPI1_CS1` | PG12 | 16 | 功能2 | `GPIO_AF_SPI1`（0x03） |
| `SPI1_CS2` | PG11 | 17 | 功能2 | `GPIO_AF_SPI1`（0x03） |
| `SPI1_CS3` | PG10 | 18 | 功能2 | `GPIO_AF_SPI1`（0x03） |
| `SPI1_MISO` | PB3 | 12 | 功能2 | `GPIO_AF_SPI1`（0x03） |
| `SPI1_MOSI` | PG15 | 13 | 功能2 | `GPIO_AF_SPI1`（0x03） |
| `SPI1_SCK` | PG14 | 14 | 功能2 | `GPIO_AF_SPI1`（0x03） |
| `SPI2_CS1` | PA0 | 119 | 功能2 | `GPIO_AF_SPI2`（0x03） |
| `SPI2_CS2` | PA1 | 117 | 功能2 | `GPIO_AF_SPI2`（0x03） |
| `SPI2_CS3` | PA2 | 115 | 功能2 | `GPIO_AF_SPI2`（0x03） |
| `SPI2_MISO` | PA5 | 105 | 功能2 | `GPIO_AF_SPI2`（0x03） |
| `SPI2_MOSI` | PA4 | 109 | 功能2 | `GPIO_AF_SPI2`（0x03） |
| `SPI2_SCK` | PA3 | 112 | 功能2 | `GPIO_AF_SPI2`（0x03） |
| `SPI3_CS0` | PC10 | 32 | 功能1 | `GPIO_AF_SPI3`（0x02） |
| `SPI3_CS1` | PC11 | 31 | 功能1 | `GPIO_AF_SPI3`（0x02） |
| `SPI3_CS2` | PC12 | 30 | 功能1 | `GPIO_AF_SPI3`（0x02） |
| `SPI3_CS3` | PD0 | 29 | 功能1 | `GPIO_AF_SPI3`（0x02） |
| `SPI3_MISO` | PD2 | 27 | 功能1 | `GPIO_AF_SPI3`（0x02） |
| `SPI3_MOSI` | PD1 | 28 | 功能1 | `GPIO_AF_SPI3`（0x02） |
| `SPI3_SCK` | PD3 | 26 | 功能1 | `GPIO_AF_SPI3`（0x02） |
| `SPI4_CS0` | PG4 | 51 | 功能2 | `GPIO_AF_SPI4`（0x03） |
| `SPI4_CS1` | PG3 | 52 | 功能2 | `GPIO_AF_SPI4`（0x03） |
| `SPI4_CS2` | PG2 | 53 | 功能2 | `GPIO_AF_SPI4`（0x03） |
| `SPI4_CS3` | PH8 | 68 | 功能2 | `GPIO_AF_SPI4`（0x03） |
| `SPI4_MISO` | PG7 | 46 | 功能2 | `GPIO_AF_SPI4`（0x03） |
| `SPI4_MOSI` | PG6 | 49 | 功能2 | `GPIO_AF_SPI4`（0x03） |
| `SPI4_SCK` | PG5 | 50 | 功能2 | `GPIO_AF_SPI4`（0x03） |
| `SPI5_CS0` | PC9 | 41 | 功能3 | `GPIO_AF_SPI5`（0x04） |
| `SPI5_CS1` | PH9 | 67 | 功能3 | `GPIO_AF_SPI5`（0x04） |
| `SPI5_CS2` | PA8 | 40 | 功能3 | `GPIO_AF_SPI5`（0x04） |
| `SPI5_CS3` | PA9 | 39 | 功能3 | `GPIO_AF_SPI5`（0x04） |
| `SPI5_MISO` | PA12 | 36 | 功能3 | `GPIO_AF_SPI5`（0x04） |
| `SPI5_MOSI` | PA11 | 37 | 功能3 | `GPIO_AF_SPI5`（0x04） |
| `SPI5_SCK` | PA10 | 38 | 功能3 | `GPIO_AF_SPI5`（0x04） |

候选引脚不代表已验证的接线组合。实例、通道与路由约束按当前驱动和手册核对；同一引脚的其他功能须检查资源冲突。案例配置见下文。

## 生成前需确认的参数

已有工程、板级资料或用户已明确的值直接复用。仅对影响本次实现的缺失选择使用参数卡询问并等待答复；案例配置不能代替实际接线或应用参数。

| 参数 | 需要核对或确认的内容 |
|---|---|
| 实例与信号 | 主从角色及 SCK、MOSI、MISO 的实际引脚与 AF |
| 片选与附加控制 | 每个从设备的硬件 CS 或软件 GPIO、有效电平，以及器件所需 RESET/DC/BUSY |
| 器件协议 | 目标器件、CPOL/CPHA、帧宽、位序、最高频率与片选时序 |

## 按需求选择

| 用户需求 / 检索关键词 | 推荐用例 | 选择条件 / 需要补充的逻辑 |
|---|---|---|
| 主机阻塞发送（最简单） | [001](SPI_IT_DRV_001.c) | 最小发送模板，扫分频 2–512；应用只留目标分频。`HAL_SPI_Transmit()` 主机模式会丢弃接收帧，无对端也能跑通状态检查 |
| 主机全双工 64 帧 | [012](SPI_IT_DRV_012.c) | 同一文件也从机模式；从机半段需要外部主机 |
| 从机全双工（外部主机驱动） | [006](SPI_IT_DRV_006.c) | 从机模式 MISO 为开漏；无主机时钟时返回 `HAL_TIMEOUT`，这是预期行为 |
| 选择硬件片选 CS0–CS3 | [002](SPI_IT_DRV_002.c) | 先 `HAL_SPI_NSSConfig()` 选从机再传输。SSR 复位为 0，`HAL_SPI_Init()` 不写 SSR；漏掉这一步对端看不到帧 |
| 调整 SCK 频率 / 分频 | [001](SPI_IT_DRV_001.c) | 分频 2/4/8/…/512；SPI3 时钟为 APBBus1（示例 22.5 MHz） |
| 选择 CPOL/CPHA（Mode0–3） | [003](SPI_IT_DRV_003.c) | CFG 回读 0x00/0x04/0x08/0x0C；实际波形需示波器确认 |
| 帧宽 8/16/24/32 位 | [004](SPI_IT_DRV_004.c) | Size 是帧数，缓冲容量按存储宽度计算；24 位布局有版本差异 |
| 普通 / back-to-back 传输 | [005](SPI_IT_DRV_005.c) | 区别在 CS 是否在帧间回到空闲；观察 CS0 |
| 中断方式全双工（RXNE/TXNE） | [007](SPI_IT_DRV_007.c) | SPI3 的完整中断模板；需要从机或 MOSI→MISO 回环提供数据 |
| 其他实例上的中断全双工 | [013](SPI_IT_DRV_013.c) SPI0、[014](SPI_IT_DRV_014.c) SPI1、[015](SPI_IT_DRV_015.c) SPI2、[016](SPI_IT_DRV_016.c) SPI4 | 相似中断用例，仍需分别核对实例配置、引脚和 IRQ；SPI2 无 CS0，用 CS3(PA2) |
| 发送完成中断 | [009](SPI_IT_DRV_009.c) | TD 事件不在驱动传输状态机内，需直接用 `HAL_SPI_ITConfig/GetITStatus/ClearITPendingBit` 写 ISR |
| 接收溢出中断 | [010](SPI_IT_DRV_010.c) | 故意不读接收 FIFO 触发 RXO；用于错误处理验证，不是正常收发模板 |
| 查询 FIFO 深度 / TXF 标志 | [008](SPI_IT_DRV_008.c) | 数据 FIFO 为 32 字深；用 `HAL_SPI_GetFlagStatus(SPI_Flag_TXF/RXE)` |
| DMA 全双工流程参考 | [011](SPI_IT_DRV_011.c) | 通道宽度与已安装 SDK 校验不兼容，先看下文版本差异。源码另记录单请求与接收限制，不作为已验证的完整 DMA 收发模板 |
| 检索全部传输 API | [017](SPI_IT_DRV_017.c) | 阻塞/中断/DMA 共 9 个阶段；具体参数须结合实际驱动，不能仅凭接口齐全认定所有传输已验证 |
| 参数/状态机/低层寄存器接口自检 | [018](SPI_IT_DRV_018.c) | 防御性自检，不是应用模板 |
| 驱动真实 Flash/传感器、多从机管理 | 无直接模板 | 需在 001/002 基础上实现设备命令序列、忙等待和错误重试；多从机还需管理多个 CS 与切换时序 |
| 软件 NSS / 单线模式 | 无 | 本目录只覆盖硬件片选与标准四线全双工，不能据此断言芯片其他模式可用 |

## 实现要点与案例配置

- 实例与引脚（示例）：

| 实例 | CS | SCK | MOSI | MISO | 用例 |
|---|---|---|---|---|---|
| SPI3 | CS0=PC10, CS1=PC11, CS2=PC12, CS3=PD0 | PD3 | PD1 | PD2 | 001–012、017、018 |
| SPI0 | PB12 | PB13 | PB14 | PB15 | 013 |
| SPI1 | PG13 | PG14 | PG15 | PB3 | 014 |
| SPI2 | CS3=PA2（无 CS0） | PA3 | PA4 | PA5 | 015 |
| SPI4 | PG4 | PG5 | PG6 | PG7 | 016 |

- 初始化参考：HAL、系统时钟、GPIO/SPI 门控及复位 → 按主从角色配置引脚方向和复用 → StructInit/Init → 清 FIFO → 设置片选。不能将全部信号统一配置成 AF 推挽，从机 MISO 的开漏与输入脚按对应源码核对。
- 硬件片选：当前案例通过 SSR 寄存器驱动 CS，引脚须映射为 SPI 复用功能。软件 GPIO 片选需由应用显式控制电平，并核对控制器工作条件和器件时序，本目录无直接模板。
- 时钟与分频：SPI3 在 APBBus1；示例分频覆盖 2–512，SCK = APBBus1 / 分频。其他实例的时钟域以各自 `MspInit`/SMU 门控为准。
- 数据通路：主机发送时自行产生时钟，接收帧被 `HAL_SPI_Transmit()` 丢弃；需要校验接收数据时要接从机或做 MOSI→MISO 回环。从机必须由外部主机提供时钟，否则阻塞接口超时。帧宽改变后，缓冲长度按帧字节数计算。
- 中断链：PLIC 使能 SPI IRQ → `SPIx_IRQ_Handler()` → `HAL_SPI_IRQHandler()` → `HAL_SPI_TxRxCpltCallback()` 等回调。RXNE/TXNE 由驱动状态机处理；TD、RXO 不在状态机内，示例用低层中断接口在应用 ISR 中自行确认。
- DMA 流程参考 011/017，但 011 使用外设 word、内存 byte；已安装 SDK 的 SPI_DMA_ValidateConfig 要求两侧宽度都等于帧存储宽度，二者不兼容。取得实际 HAL 前，只作流程参考，不作为确认可运行的 DMA 模板；单请求限制亦按硬件核对。
- 证据边界：寄存器回读、状态/错误码和回调计数能证明配置与驱动状态机；真实波形、对端数据正确性和从机时序需要示波器/逻辑分析仪及外部主从设备。

## 验证方法与适用边界

- `HAL_SPI_Init()` 不写 SSR；使用 HAL 的硬件片选路径时，需调用 `HAL_SPI_NSSConfig()` 并配置相应 CS 的 AF。该要求不代替软件 GPIO 片选方案的单独设计与验证。
- 每个 SPI 实例只有一个 DMA 请求，且由发送 FIFO 空间触发；把 TX/RX 两个通道都绑到同一请求会互相抢占。要做 DMA 接收，需按 011 的说明评估单请求限制，不能直接把双向 DMA 当稳定方案。
- 中断/DMA 模式下发送、接收缓冲必须在传输完成前保持有效；示例用静态数组。DMA 还需注意缓存一致性。
- 接收 FIFO 只有 32 字深，长时间不读会溢出并置 RXO；错误回调/中断必须处理，否则后续数据不可信。
- 传输 Size 按帧计数，缓冲容量另算。004 对 8/16/24/32 位分别步进 1/2/3/4 字节，SDK 的 SPI_GetFrameBytes 对 17～32 位均返回 4。24 位布局不一致，须先解决，不能按“24 位必占 3 字节”生成代码。
- 从机模式 MISO 为开漏，需要外部上拉；没有主机时阻塞调用会超时，不能把超时误判为驱动故障。
- 多个从机共享 SCK/MOSI/MISO 时，只有被选中的 CS 有效；切换从机前先释放当前片选，避免总线冲突。
- 018 的 BUSY 保护说明：中断传输进行中再次发起传输会被拒绝，应用不能靠重复调用“抢占”。

## 按接口与辅助宏检索

| 接口 / 宏 | 参考用例 |
|---|---|
| `HAL_SPI_StructInit` / `HAL_SPI_Init` / `HAL_SPI_DeInit` | [001](SPI_IT_DRV_001.c)、[018](SPI_IT_DRV_018.c) |
| `HAL_SPI_Transmit` / `HAL_SPI_Receive` / `HAL_SPI_TransmitReceive` | [001](SPI_IT_DRV_001.c)、[006](SPI_IT_DRV_006.c)、[012](SPI_IT_DRV_012.c) |
| `HAL_SPI_Transmit_IT` / `HAL_SPI_Receive_IT` / `HAL_SPI_TransmitReceive_IT` | [007](SPI_IT_DRV_007.c)、[017](SPI_IT_DRV_017.c) |
| `HAL_SPI_Transmit_DMA` / `HAL_SPI_Receive_DMA` / `HAL_SPI_TransmitReceive_DMA` | [011](SPI_IT_DRV_011.c)、[017](SPI_IT_DRV_017.c) |
| `HAL_SPI_NSSConfig` | [002](SPI_IT_DRV_002.c)、[015](SPI_IT_DRV_015.c) |
| `HAL_SPI_ResetFIFO` / `HAL_SPI_GetFlagStatus` | [008](SPI_IT_DRV_008.c)、[010](SPI_IT_DRV_010.c) |
| `HAL_SPI_ITConfig` / `HAL_SPI_GetITStatus` / `HAL_SPI_ClearITPendingBit` | [009](SPI_IT_DRV_009.c)、[010](SPI_IT_DRV_010.c) |
| `HAL_SPI_IRQHandler` / `HAL_SPI_TxRxCpltCallback` | [007](SPI_IT_DRV_007.c)、[017](SPI_IT_DRV_017.c) |
| `HAL_DMA_Init` / `HAL_DMA_ConfigPeriphIF` | [011](SPI_IT_DRV_011.c)、[017](SPI_IT_DRV_017.c) |
| `HAL_SPI_GetState` / `HAL_SPI_GetError` | [018](SPI_IT_DRV_018.c) |


本次为源码静态整理，未重新编译、未上板；源码里的历史测试注释不代表本次验证结果。
