/**
 * @file    RTC_IT_DRV_006.c
 * @brief   HAL RTC integration test case 006: run time parameter validation (fields, formats, pointers).
 *
 * Every interface that accepts a value validates it at run time, independently of
 * the assertion build: the field ranges, the representation selector and the
 * pointers are checked before the lock is taken, so a rejected call neither writes
 * a register nor changes the handle state. This case drives each rejection path
 * and verifies that the peripheral keeps its content.
 *
 * Tested functionality:
 *   HAL_RTC_SetTime() / HAL_RTC_GetTime()
 *   HAL_RTC_SetDate() / HAL_RTC_GetDate()
 *   HAL_RTC_SetAlarm() / HAL_RTC_SetAlarm_IT() / HAL_RTC_GetAlarm()
 *   HAL_RTC_AlarmIRQHandler() (NULL handle)
 *   HAL_RTC_GetError() (HAL_RTC_ERROR_INVALID_PARAM) / HAL_RTC_GetState()
 *   HAL_RTC_StructInit() family
 *
 * Expected behaviour:
 *   - out-of-range time fields (hour 24, minute 60, second 60, tenth 10) are
 *     rejected with HAL_ERROR and HAL_RTC_ERROR_INVALID_PARAM;
 *   - out-of-range date fields (weekday 0 / 8, month 0 / 13, day 0 / 32,
 *     century 100, year 100) are rejected;
 *   - an unknown representation selector and a NULL pointer are rejected;
 *   - every rejection leaves TR / DR unchanged and the handle in the READY state;
 *   - a legal call afterwards succeeds and clears the error code.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* RTC divider coefficient. 1785 is the project baseline of the reference test
 * cases of this chip, 1638 is the other value documented by the library SRS;
 * both are legal hardware values (the driver only checks the 27 bit field
 * width). No test below depends on the resulting absolute frequency: the
 * checks are register read-backs or "the counter moved" observations. */
#define TEST_RTC_DIVISION           (1785U)

/* Calendar value used by the cases that need a known starting point */
#define TEST_TIME_HOURS             (15U)
#define TEST_TIME_MINUTES           (48U)
#define TEST_TIME_SECONDS           (0U)
#define TEST_TIME_TOS               (0U)
#define TEST_DATE_CENTURY           (20U)
#define TEST_DATE_YEAR              (25U)
#define TEST_DATE_MONTH             (RTC_Month_July)
#define TEST_DATE_DATE              (21U)
#define TEST_DATE_WEEKDAY           (RTC_Weekday_Monday)

/* Polling slice of the wait loops (ms) */
#define TEST_POLL_MS                (10U)

/* Reporting period of the final idle loop (ms) */
#define TEST_IDLE_MS                (1000U)

/* Private variables ---------------------------------------------------------*/
static RTC_HandleTypeDef hrtc_dev;          /*!< RTC device handle            */
static RTC_InitTypeDef   rtc_init;          /*!< RTC configuration structure  */
static uint32            failures = 0U;     /*!< failed checks                */

/* Alarm interrupt bookkeeping (filled by the overridden weak callback) */
static volatile uint32   alarm_events = 0U; /*!< callback entries             */
static volatile uint32   alarm_cr_seen = 0U;/*!< CR register at callback time */

/* Snapshots and scratch structures of this case */
static uint32           tr_before;
static uint32           dr_before;
static RTC_TimeTypeDef  time_bad;
static RTC_DateTypeDef  date_bad;
static RTC_AlarmTypeDef alarm_bad;

/* Last calendar read back by the report helpers */
static uint8 r_time_hours;
static uint8 r_time_minutes;
static uint8 r_time_seconds;
static uint8 r_time_tos;
static uint8 r_date_century;
static uint8 r_date_year;
static uint8 r_date_month;
static uint8 r_date_date;
static uint8 r_date_weekday;

/* Private function prototypes -----------------------------------------------*/
static void Check(const char *name, uint32 condition);
static void SystemClock_Init(void);
static void Rtc_Handle_Setup(void);
static HAL_StatusTypeDef Rtc_Start(void);
static HAL_StatusTypeDef Rtc_SetCalendar(uint8 hours, uint8 minutes, uint8 seconds, uint8 tos,
                                         uint8 century, uint8 year, uint8 month, uint8 date,
                                         uint8 weekday);
static HAL_StatusTypeDef Rtc_GetCalendar(void);
static uint8 Rtc_MonthToNumber(uint8 month);
static const char *Rtc_WeekdayName(uint8 weekday);
static void Rtc_PrintCalendar(const char *tag);

/* Exported interrupt entry ------------------------------------------------*/
/**
 * @brief  RTC interrupt entry, called by the shared PLIC dispatch table.
 * @note   Overrides the weak RTC_IRQ_Handler() of the PLIC driver; it hands the
 *         event to the HAL RTC interrupt handler, which clears the alarm flag
 *         and then calls HAL_RTC_AlarmEventCallback().
 */
void RTC_IRQ_Handler(void)
{
    HAL_RTC_AlarmIRQHandler(&hrtc_dev);
}

/**
 * @brief  Alarm event callback (weak function of the HAL RTC driver).
 * @note   Counts the events and snapshots CR so that the cases can observe the
 *         flag state the driver left behind. It must not block and must not
 *         call a locking RTC interface (interrupt context).
 * @param  hrtc pointer to a RTC_HandleTypeDef structure.
 * @retval None
 */
void HAL_RTC_AlarmEventCallback(RTC_HandleTypeDef *hrtc)
{
    UNUSED(hrtc);

    alarm_events++;
    alarm_cr_seen = hrtc_dev.Instance->CR;
}

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock tree */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n\r\n==== RTC_IT_DRV_006: run time parameter validation (fields, formats, pointers) ====\r\n");
    printf("Data : %s\r\n", __DATE__);
    printf("Time : %s\r\n", __TIME__);

        /* ---- Step 1: initialization --------------------------------------- */
        Check("RTC init", (Rtc_Start() == HAL_OK));
        Check("known calendar programmed",
              (Rtc_SetCalendar(TEST_TIME_HOURS, TEST_TIME_MINUTES, TEST_TIME_SECONDS,
                               TEST_TIME_TOS, TEST_DATE_CENTURY, TEST_DATE_YEAR,
                               TEST_DATE_MONTH, TEST_DATE_DATE,
                               TEST_DATE_WEEKDAY) == HAL_OK));

        /* The rejected calls below must not touch the calendar registers, so a
           snapshot of both is taken first. */
        tr_before = hrtc_dev.Instance->TR;
        dr_before = hrtc_dev.Instance->DR;

        /* ---- Step 2: out-of-range time fields ----------------------------- */
        __HAL_CLEAR_STRUCT(&time_bad);
        HAL_RTC_TimeStructInit(&time_bad);
        time_bad.RTC_Hours = 24U;
        Check("hour 24 rejected", (HAL_RTC_SetTime(&hrtc_dev, &time_bad, RTC_FORMAT_BIN) == HAL_ERROR));
        Check("INVALID_PARAM reported", ((HAL_RTC_GetError(&hrtc_dev) & HAL_RTC_ERROR_INVALID_PARAM) != 0U));

        __HAL_CLEAR_STRUCT(&time_bad);
        HAL_RTC_TimeStructInit(&time_bad);
        time_bad.RTC_Minutes = 60U;
        Check("minute 60 rejected", (HAL_RTC_SetTime(&hrtc_dev, &time_bad, RTC_FORMAT_BIN) == HAL_ERROR));

        __HAL_CLEAR_STRUCT(&time_bad);
        HAL_RTC_TimeStructInit(&time_bad);
        time_bad.RTC_Seconds = 60U;
        Check("second 60 rejected", (HAL_RTC_SetTime(&hrtc_dev, &time_bad, RTC_FORMAT_BIN) == HAL_ERROR));

        __HAL_CLEAR_STRUCT(&time_bad);
        HAL_RTC_TimeStructInit(&time_bad);
        time_bad.RTC_TenthOfSecond = 10U;
        Check("tenth of second 10 rejected",
              (HAL_RTC_SetTime(&hrtc_dev, &time_bad, RTC_FORMAT_BIN) == HAL_ERROR));

        Check("TR unchanged by the rejected time writes", (hrtc_dev.Instance->TR == tr_before));

        /* ---- Step 3: out-of-range date fields ----------------------------- */
        __HAL_CLEAR_STRUCT(&date_bad);
        HAL_RTC_DateStructInit(&date_bad);
        date_bad.RTC_WeekDay = 0U;
        Check("weekday 0 rejected", (HAL_RTC_SetDate(&hrtc_dev, &date_bad, RTC_FORMAT_BIN) == HAL_ERROR));

        __HAL_CLEAR_STRUCT(&date_bad);
        HAL_RTC_DateStructInit(&date_bad);
        date_bad.RTC_WeekDay = 8U;
        Check("weekday 8 rejected", (HAL_RTC_SetDate(&hrtc_dev, &date_bad, RTC_FORMAT_BIN) == HAL_ERROR));

        __HAL_CLEAR_STRUCT(&date_bad);
        HAL_RTC_DateStructInit(&date_bad);
        date_bad.RTC_Month = 0U;
        Check("month 0 rejected", (HAL_RTC_SetDate(&hrtc_dev, &date_bad, RTC_FORMAT_BIN) == HAL_ERROR));

        __HAL_CLEAR_STRUCT(&date_bad);
        HAL_RTC_DateStructInit(&date_bad);
        date_bad.RTC_Month = 13U;
        Check("month 13 rejected", (HAL_RTC_SetDate(&hrtc_dev, &date_bad, RTC_FORMAT_BIN) == HAL_ERROR));

        __HAL_CLEAR_STRUCT(&date_bad);
        HAL_RTC_DateStructInit(&date_bad);
        date_bad.RTC_Date = 0U;
        Check("day 0 rejected", (HAL_RTC_SetDate(&hrtc_dev, &date_bad, RTC_FORMAT_BIN) == HAL_ERROR));

        __HAL_CLEAR_STRUCT(&date_bad);
        HAL_RTC_DateStructInit(&date_bad);
        date_bad.RTC_Date = 32U;
        Check("day 32 rejected", (HAL_RTC_SetDate(&hrtc_dev, &date_bad, RTC_FORMAT_BIN) == HAL_ERROR));

        __HAL_CLEAR_STRUCT(&date_bad);
        HAL_RTC_DateStructInit(&date_bad);
        date_bad.RTC_Century = 100U;
        Check("century 100 rejected", (HAL_RTC_SetDate(&hrtc_dev, &date_bad, RTC_FORMAT_BIN) == HAL_ERROR));

        __HAL_CLEAR_STRUCT(&date_bad);
        HAL_RTC_DateStructInit(&date_bad);
        date_bad.RTC_Year = 100U;
        Check("year 100 rejected", (HAL_RTC_SetDate(&hrtc_dev, &date_bad, RTC_FORMAT_BIN) == HAL_ERROR));

        Check("DR unchanged by the rejected date writes", (hrtc_dev.Instance->DR == dr_before));

        /* ---- Step 4: unknown representation selector ---------------------- */
        __HAL_CLEAR_STRUCT(&time_bad);
        HAL_RTC_TimeStructInit(&time_bad);
        Check("unknown format on SetTime rejected",
              (HAL_RTC_SetTime(&hrtc_dev, &time_bad, 0x00000002U) == HAL_ERROR));
        Check("unknown format on GetTime rejected",
              (HAL_RTC_GetTime(&hrtc_dev, &time_bad, 0x00000002U) == HAL_ERROR));
        __HAL_CLEAR_STRUCT(&date_bad);
        HAL_RTC_DateStructInit(&date_bad);
        Check("unknown format on SetDate rejected",
              (HAL_RTC_SetDate(&hrtc_dev, &date_bad, 0x00000002U) == HAL_ERROR));
        Check("unknown format on GetDate rejected",
              (HAL_RTC_GetDate(&hrtc_dev, &date_bad, 0x00000002U) == HAL_ERROR));
        __HAL_CLEAR_STRUCT(&alarm_bad);
        HAL_RTC_AlarmStructInit(&alarm_bad);
        Check("unknown format on SetAlarm rejected",
              (HAL_RTC_SetAlarm(&hrtc_dev, &alarm_bad, 0x00000002U) == HAL_ERROR));
        Check("unknown format on GetAlarm rejected",
              (HAL_RTC_GetAlarm(&hrtc_dev, &alarm_bad, 0x00000002U) == HAL_ERROR));

        /* ---- Step 5: NULL pointers ---------------------------------------- */
        Check("SetTime(NULL structure) rejected",
              (HAL_RTC_SetTime(&hrtc_dev, NULL_PTR, RTC_FORMAT_BIN) == HAL_ERROR));
        Check("GetTime(NULL structure) rejected",
              (HAL_RTC_GetTime(&hrtc_dev, NULL_PTR, RTC_FORMAT_BIN) == HAL_ERROR));
        Check("SetDate(NULL structure) rejected",
              (HAL_RTC_SetDate(&hrtc_dev, NULL_PTR, RTC_FORMAT_BIN) == HAL_ERROR));
        Check("GetDate(NULL structure) rejected",
              (HAL_RTC_GetDate(&hrtc_dev, NULL_PTR, RTC_FORMAT_BIN) == HAL_ERROR));
        Check("SetAlarm(NULL structure) rejected",
              (HAL_RTC_SetAlarm(&hrtc_dev, NULL_PTR, RTC_FORMAT_BIN) == HAL_ERROR));
        Check("SetAlarm_IT(NULL structure) rejected",
              (HAL_RTC_SetAlarm_IT(&hrtc_dev, NULL_PTR, RTC_FORMAT_BIN) == HAL_ERROR));
        Check("GetAlarm(NULL structure) rejected",
              (HAL_RTC_GetAlarm(&hrtc_dev, NULL_PTR, RTC_FORMAT_BIN) == HAL_ERROR));

        /* ---- Step 6: NULL handle ------------------------------------------ */
        Check("SetTime(NULL handle) rejected",
              (HAL_RTC_SetTime(NULL_PTR, &time_bad, RTC_FORMAT_BIN) == HAL_ERROR));
        Check("GetTime(NULL handle) rejected",
              (HAL_RTC_GetTime(NULL_PTR, &time_bad, RTC_FORMAT_BIN) == HAL_ERROR));
        Check("Cmd(NULL handle) rejected", (HAL_RTC_Cmd(NULL_PTR, ENABLE) == HAL_ERROR));
        Check("GetState(NULL handle) reported as RESET",
              (HAL_RTC_GetState(NULL_PTR) == HAL_RTC_STATE_RESET));
        Check("GetError(NULL handle) reported as NONE",
              (HAL_RTC_GetError(NULL_PTR) == HAL_RTC_ERROR_NONE));
        HAL_RTC_AlarmIRQHandler(NULL_PTR);
        Check("AlarmIRQHandler(NULL handle) is harmless", (1U));

        /* ---- Step 7: a legal call succeeds and clears the error ----------- */
        Check("legal time accepted after the rejections",
              (Rtc_SetCalendar(TEST_TIME_HOURS, TEST_TIME_MINUTES, TEST_TIME_SECONDS,
                               TEST_TIME_TOS, TEST_DATE_CENTURY, TEST_DATE_YEAR,
                               TEST_DATE_MONTH, TEST_DATE_DATE,
                               TEST_DATE_WEEKDAY) == HAL_OK));
        Check("error code cleared by the accepted call",
              (HAL_RTC_GetError(&hrtc_dev) == HAL_RTC_ERROR_NONE));
        (void)Rtc_GetCalendar();
        Check("calendar still consistent", ((r_time_hours == TEST_TIME_HOURS) &&
                                            (r_date_date == TEST_DATE_DATE)));
    /* ---- summary ------------------------------------------------------- */
    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(failures));

    /* Idle: keep the calendar observable on the console */
    while (1)
    {
        Rtc_PrintCalendar("idle");
        delay_ms(TEST_IDLE_MS);
    }
}

/* Private functions --------------------------------------------------------*/
/**
 * @brief  Prepare the RTC handle and its configuration structure.
 * @note   The configuration structure metafields (Size / Version / reserved
 *         words) are mandatory: HAL_RTC_Init() validates them at run time and
 *         rejects a structure that does not carry them.
 * @param  None
 * @retval None
 */
static void Rtc_Handle_Setup(void)
{
    __HAL_CLEAR_STRUCT(&hrtc_dev);
    hrtc_dev.Instance = RTC;

    __HAL_CLEAR_STRUCT(&rtc_init);
    rtc_init.Size     = sizeof(RTC_InitTypeDef);
    rtc_init.Version  = RTC_INIT_VERSION;
    rtc_init.Division = TEST_RTC_DIVISION;
    hrtc_dev.Init     = rtc_init;
}

/**
 * @brief  Initialize the RTC and report its state.
 * @param  None
 * @retval HAL status of the initialization.
 */
static HAL_StatusTypeDef Rtc_Start(void)
{
    HAL_StatusTypeDef status;

    Rtc_Handle_Setup();
    status = HAL_RTC_Init(&hrtc_dev);
    printf("RTC state = %u (1 = READY), error = %u\r\n",
           PRINT_U32(HAL_RTC_GetState(&hrtc_dev)),
           PRINT_U32(HAL_RTC_GetError(&hrtc_dev)));

    return status;
}

/**
 * @brief  Write the calendar (time and date) of the RTC.
 * @param  hours / minutes / seconds / tos: time fields.
 * @param  century / year / month / date / weekday: date fields.
 * @retval HAL_OK when both writes succeeded.
 */
static HAL_StatusTypeDef Rtc_SetCalendar(uint8 hours, uint8 minutes, uint8 seconds, uint8 tos,
                                         uint8 century, uint8 year, uint8 month, uint8 date,
                                         uint8 weekday)
{
    RTC_TimeTypeDef time;
    RTC_DateTypeDef dateS;
    HAL_StatusTypeDef status;

    __HAL_CLEAR_STRUCT(&time);
    __HAL_CLEAR_STRUCT(&dateS);
    HAL_RTC_TimeStructInit(&time);
    HAL_RTC_DateStructInit(&dateS);

    time.RTC_Hours         = hours;
    time.RTC_Minutes       = minutes;
    time.RTC_Seconds       = seconds;
    time.RTC_TenthOfSecond = tos;

    dateS.RTC_WeekDay = weekday;
    dateS.RTC_Century = century;
    dateS.RTC_Year    = year;
    dateS.RTC_Month   = month;
    dateS.RTC_Date    = date;

    status = HAL_RTC_SetTime(&hrtc_dev, &time, RTC_FORMAT_BIN);
    if (status == HAL_OK)
    {
        status = HAL_RTC_SetDate(&hrtc_dev, &dateS, RTC_FORMAT_BIN);
    }

    return status;
}

/**
 * @brief  Read the calendar into the report globals.
 * @param  None
 * @retval HAL status of the read (HAL_ERROR when a read was refused).
 */
static HAL_StatusTypeDef Rtc_GetCalendar(void)
{
    RTC_TimeTypeDef time;
    RTC_DateTypeDef dateS;
    HAL_StatusTypeDef status;

    __HAL_CLEAR_STRUCT(&time);
    __HAL_CLEAR_STRUCT(&dateS);

    status = HAL_RTC_GetTime(&hrtc_dev, &time, RTC_FORMAT_BIN);
    if (status == HAL_OK)
    {
        status = HAL_RTC_GetDate(&hrtc_dev, &dateS, RTC_FORMAT_BIN);
    }
    if (status != HAL_OK)
    {
        return status;
    }

    r_time_hours   = time.RTC_Hours;
    r_time_minutes = time.RTC_Minutes;
    r_time_seconds = time.RTC_Seconds;
    r_time_tos     = time.RTC_TenthOfSecond;

    r_date_century = dateS.RTC_Century;
    r_date_year    = dateS.RTC_Year;
    r_date_month   = dateS.RTC_Month;
    r_date_date    = dateS.RTC_Date;
    r_date_weekday = dateS.RTC_WeekDay;

    return HAL_OK;
}

/**
 * @brief  Translate a month constant to its number (1-12).
 * @param  month: month (RTC_Month_xxx).
 * @retval uint8: month number, or 0 when the value is unknown.
 */
static uint8 Rtc_MonthToNumber(uint8 month)
{
    uint8 result;

    switch (month)
    {
        case RTC_Month_January:   result = 1U;  break;
        case RTC_Month_February:  result = 2U;  break;
        case RTC_Month_March:     result = 3U;  break;
        case RTC_Month_April:     result = 4U;  break;
        case RTC_Month_May:       result = 5U;  break;
        case RTC_Month_June:      result = 6U;  break;
        case RTC_Month_July:      result = 7U;  break;
        case RTC_Month_August:    result = 8U;  break;
        case RTC_Month_September: result = 9U;  break;
        case RTC_Month_October:   result = 10U; break;
        case RTC_Month_November:  result = 11U; break;
        case RTC_Month_December:  result = 12U; break;
        default:                  result = 0U;  break;
    }

    return result;
}

/**
 * @brief  Translate a weekday constant to its name.
 * @param  weekday: weekday (RTC_Weekday_xxx).
 * @retval const char*: weekday name, or "?" when the value is unknown.
 */
static const char *Rtc_WeekdayName(uint8 weekday)
{
    switch (weekday)
    {
        case RTC_Weekday_Monday:    return "Monday";
        case RTC_Weekday_Tuesday:   return "Tuesday";
        case RTC_Weekday_Wednesday: return "Wednesday";
        case RTC_Weekday_Thursday:  return "Thursday";
        case RTC_Weekday_Friday:    return "Friday";
        case RTC_Weekday_Saturday:  return "Saturday";
        case RTC_Weekday_Sunday:    return "Sunday";
        default:                    return "?";
    }
}

/**
 * @brief  Read and print the calendar.
 * @param  tag: text printed in front of the value (may be NULL).
 * @retval None
 */
static void Rtc_PrintCalendar(const char *tag)
{
    if (Rtc_GetCalendar() != HAL_OK)
    {
        printf("%s calendar read refused (state = %u)\r\n",
               ((tag != NULL_PTR) ? tag : ""),
               PRINT_U32(HAL_RTC_GetState(&hrtc_dev)));
        return;
    }

    printf("%s %02u-%02u-%02u %02u:%02u:%02u.%u %s\r\n",
           ((tag != NULL_PTR) ? tag : ""),
           PRINT_U32(r_date_century), PRINT_U32(Rtc_MonthToNumber(r_date_month)),
           PRINT_U32(r_date_date), PRINT_U32(r_time_hours), PRINT_U32(r_time_minutes),
           PRINT_U32(r_time_seconds), PRINT_U32(r_time_tos),
           Rtc_WeekdayName(r_date_weekday));
}

/**
 * @brief  Report the result of one check and count the failures.
 * @param  name: text of the check.
 * @param  condition: 0 = failed, non-zero = passed.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition == 0U)
    {
        failures++;
    }
    printf("%-44s [%s]\r\n", name, ((condition != 0U) ? "PASS" : "FAIL"));
}

/**
 * @brief  Configure the system clock tree using the HAL SMU driver.
 * @note   Clock tree shared by every integration test suite of this library:
 *         OSC 20 MHz as the PLL source, PLLDivR = 0x04 / PLLDivN = 0x14 /
 *         PLLDivF = 0xB4 / PLLDivQ = 0x01, then AXI4Bus3 = /2, APBBus0 = /2,
 *         APBBus1 = /2 and CANX2 = /8. The bus dividers are written first and
 *         the PLL is switched in afterwards, which is the order the chip
 *         requires (see HAL_SMU_OscConfig()).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;
    HAL_SMU_HandleTypeDef hsmu_clk;

    /* Enable the bus clock gates */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* The RTC lives in the always-on APB-BusS domain: it has no clock gate of
       its own, the module switch of the configuration file is enough. */

    /* Initialize the PMU before the voltage scaling calls: the LDO APIs are
       gated on the handle state, so a handle that is only cleared would have
       its requests rejected with HAL_ERROR (PMU_CheckState). */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare-metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Bus dividers first (the system clock is still the power-on source) */
    __HAL_CLEAR_STRUCT(&SMU_ClockInitStruct);
    SMU_ClockInitStruct.AXI4Bus3CLKDiv  = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv   = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv   = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv     = SMU_CANX2CLK_DIV8;
    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);

    /* Set the oscillator / PLL parameters (VCO 180 MHz) and switch to it; the
       call also programs the EFLASH controller clock before the switch. */
    __HAL_CLEAR_STRUCT(&SMU_OscInitStruct);
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Get the system clock values (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
