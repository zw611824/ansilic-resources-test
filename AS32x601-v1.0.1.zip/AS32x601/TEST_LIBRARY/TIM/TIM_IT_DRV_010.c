/**
 * @file    TIM_IT_DRV_010.c
 * @brief   PWM input mode (channel 1 period, channel 2 duty cycle)
 *
 * HAL library port of the original AS32x601 standard-library test case
 * TIMER_IT_DRV_010.c, which drives TIM0. Only HAL library APIs are used; the register
 * read backs document what was programmed.
 *
 * Tested functionality:
 *   TIM_ICStructInit()      -> HAL_TIM_IC_StructInit()
 *   TIM_ICInit()            -> HAL_TIM_IC_ConfigChannel() (channel 1 direct, channel 2 indirect)
 *   TIM_SelectInputTrigger()-> HAL_TIM_SlaveConfigSynchronization()
 *   TIM_SelectSlaveMode()   -> HAL_TIM_SlaveConfigSynchronization(TIM_SLAVEMODE_RESET)
 *   TIM_GetCapture1()/TIM_GetCapture2() -> HAL_TIM_ReadCapturedValue()
 *
 * Test procedure:
 *   configure PC3 (TI1) as the PWM input and PA0 (TI2) as the second input;
 *   channel 1 captures on the rising edge (direct), channel 2 on the falling edge (indirect);
 *   select TI1FP1 as the trigger and reset the counter on it (reset slave mode);
 *   feed a 20 kHz square wave into PC3 and print the two capture values.
 *
 * Expected behaviour:
 *   both channel configurations return HAL_OK and CCMR1 reads CC1S = 01 (direct) and CC2S = 10 (indirect);
 *   SMCR reads TS = TI1FP1 and SMS = 100 (reset mode);
 *   CCR1 holds the period and CCR2 the high time of the input signal;
 *   every check prints [PASS] and "summary : failures = 0".
 *
 * Note:
 *   An external 20 kHz square wave is required on PC3. TIM0 runs from AXILite4 Bus 1 = 45 MHz,
 *   so with PSC = 9-1 the counter runs at 4.5 MHz and one 20 kHz period is about 225 counts
 *   (CCR1); CCR2 holds the high time. Note that ARR only has to be larger than the captured
 *   period.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
/* Console: USART0 on GPIOD pin 8 (TX) / pin 9 (RX), 115200 8N1 */
#define TEST_BAUDRATE                   (115200U)


#define TEST_ARR                        (100000U - 1U)
#define TEST_PSC                        (9U - 1U)


/* Private variables -------------------------------------------------------*/
static HAL_TIM_HandleTypeDef htim_dev;          /*!< timer under test        */
static HAL_SMU_HandleTypeDef hsmu_clk;          /*!< SMU handle (clock tree) */
static volatile uint32 check_failures = 0U;     /*!< failed check counter    */



/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure one GPIO pin and, for the alternate function modes, the
 *         pin mux of that pin.
 * @param  port: GPIO port
 * @param  pin: pin mask
 * @param  source: pin source number (for the mux configuration)
 * @param  af: alternate function selector
 * @param  mode: GPIO_MODE_AF_PP / GPIO_MODE_INPUT
 * @retval None
 */
static void Gpio_Config(GPIO_TypeDef *port, uint32 pin, uint32 source, uint8 af, uint32 mode)
{
    GPIO_InitTypeDef gpio_init;

    __HAL_CLEAR_STRUCT(&gpio_init);
    gpio_init.Size         = sizeof(GPIO_InitTypeDef);
    gpio_init.Version      = GPIO_INIT_VERSION;
    gpio_init.Pin          = pin;
    gpio_init.Mode         = mode;
    gpio_init.Pull         = GPIO_NOPULL;
    gpio_init.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;
    gpio_init.Alternate    = af;
    /* The multiplex selection is independent of the pin direction: a pin that
       feeds a peripheral input (timer capture input, external clock input, ...)
       keeps MODER = input while the AFR field routes the pad to that peripheral.
       HAL_GPIO_Init() programs the AFR field only for the alternate function
       modes, so the input case must select the mux explicitly, otherwise the
       pad stays on its default function and the peripheral never sees it. */
    if (af != GPIO_AF_Pin_x)
    {
        HAL_GPIO_PinAFConfig(port, source, af);
    }
    HAL_GPIO_Init(port, &gpio_init);
}

/**
 * @brief  Configure the time base of the timer under test.
 * @note   The helper keeps the Size / Version meta fields through
 *         HAL_TIM_Base_StructInit(), which the initialization interface
 *         validates at run time.
 * @param  instance: TIM0..TIM7
 * @param  arr: auto reload value
 * @param  psc: prescaler value
 * @param  rcr: repetition counter (advanced timers only)
 * @param  ckd: clock division
 * @param  countermode: counting mode
 * @retval HAL status of HAL_TIM_Base_Init()
 */
static HAL_StatusTypeDef TimeBase_Config(TIM_TypeDef *instance, uint32 arr, uint32 psc,
                                         uint32 rcr, uint32 ckd, uint32 countermode)
{
    TIM_Base_InitTypeDef base_init;

    __HAL_CLEAR_STRUCT(&htim_dev);
    htim_dev.Instance = instance;

    HAL_TIM_Base_StructInit(&base_init);
    base_init.CounterMode       = countermode;
    base_init.ClockDivision     = ckd;
    base_init.Period            = arr;
    base_init.Prescaler         = psc;
    base_init.RepetitionCounter = rcr;
    htim_dev.Init               = base_init;

    return HAL_TIM_Base_Init(&htim_dev);
}

/**
 * @brief  Enable the clock of a timer instance and release its reset.
 * @note   The default MSP callbacks of this module are empty, so the suite
 *         performs the gate and reset handling itself; every MSP callback is
 *         routed to this helper.
 * @param  instance: TIM0..TIM7
 * @retval None
 */
static void Tim_ClockEnable(TIM_TypeDef *instance)
{
    if (instance == TIM0)
    {
        __HAL_SMU_HTIM0_CLK_ENABLE();
        __HAL_SMU_HTIM0_FORCE_RESET();
        __HAL_SMU_HTIM0_RELEASE_RESET();
    }
    else if (instance == TIM1)
    {
        __HAL_SMU_HTIM1_CLK_ENABLE();
        __HAL_SMU_HTIM1_FORCE_RESET();
        __HAL_SMU_HTIM1_RELEASE_RESET();
    }
    else if (instance == TIM2)
    {
        __HAL_SMU_HTIM2_CLK_ENABLE();
        __HAL_SMU_HTIM2_FORCE_RESET();
        __HAL_SMU_HTIM2_RELEASE_RESET();
    }
    else if (instance == TIM3)
    {
        __HAL_SMU_TIM3_CLK_ENABLE();
        __HAL_SMU_TIM3_FORCE_RESET();
        __HAL_SMU_TIM3_RELEASE_RESET();
    }
    else if (instance == TIM4)
    {
        __HAL_SMU_TIM4_CLK_ENABLE();
        __HAL_SMU_TIM4_FORCE_RESET();
        __HAL_SMU_TIM4_RELEASE_RESET();
    }
    else if (instance == TIM5)
    {
        __HAL_SMU_HTIM5_CLK_ENABLE();
        __HAL_SMU_HTIM5_FORCE_RESET();
        __HAL_SMU_HTIM5_RELEASE_RESET();
    }
    else if (instance == TIM6)
    {
        __HAL_SMU_TIM6_CLK_ENABLE();
        __HAL_SMU_TIM6_FORCE_RESET();
        __HAL_SMU_TIM6_RELEASE_RESET();
    }
    else
    {
        __HAL_SMU_TIM7_CLK_ENABLE();
        __HAL_SMU_TIM7_FORCE_RESET();
        __HAL_SMU_TIM7_RELEASE_RESET();
    }
}

/* MSP callbacks: the timer clock and reset of the instance under test */
void HAL_TIM_Base_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_OC_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_PWM_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_IC_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_OnePulse_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

void HAL_TIM_Encoder_MspInit(HAL_TIM_HandleTypeDef *htim)
{
    Tim_ClockEnable(htim->Instance);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the CLINT / CMU / MPU / USART integration tests:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2, CANX2 by
 *         8 -> core 180 MHz, AXILite4 Bus 1 and Bus 2 = 45 MHz (TIM0, TIM1),
 *         APBBus0 and APBBus1 = 22.5 MHz (TIM2 / TIM3 / TIM4 and TIM5 / TIM6 /
 *         TIM7 - TIM2 and TIM5 are advanced timers on the APB).
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef    SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks used by this suite (GPIOH lives in the always on
       domain and has no gate macro) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    /* Clock tree order: write the dividers while the system clock is still
       FIRC, then configure the PLL and switch to it (that call programs the
       flash controller clock before the switch and updates SystemCoreClock
       afterwards). */
    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    TIM_IC_InitTypeDef ic_cfg;
    TIM_SlaveConfigTypeDef slave_cfg;

    HAL_Init();
    SystemClock_Init();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== TIM_IT_DRV_010 : PWM input mode ===\r\n");

    /* Step 1: the two input pins */
    Gpio_Config(GPIOC, GPIO_PIN_3, GPIO_PinSource3, GPIO_AF_HTIM0_M1, GPIO_MODE_INPUT);
    Gpio_Config(GPIOA, GPIO_PIN_0, GPIO_PinSource0, GPIO_AF_HTIM0_M1, GPIO_MODE_INPUT);

    /* Step 2: the time base */
    Check("HAL_TIM_Base_Init() returns HAL_OK",
          (TimeBase_Config(TIM0, TEST_ARR, TEST_PSC, 0U, TIM_CKD_DIV1, TIM_COUNTERMODE_UP) == HAL_OK));

    /* Step 3: channel 1 direct rising, channel 2 indirect falling */
    __HAL_CLEAR_STRUCT(&ic_cfg);
    HAL_TIM_IC_StructInit(&ic_cfg);
    ic_cfg.ICPolarity  = TIM_ICPOLARITY_RISING;
    ic_cfg.ICSelection = TIM_ICSEL_DIRECTTI;
    ic_cfg.ICPrescaler = TIM_ICPSC_DIV1;
    ic_cfg.ICFilter    = 0U;
    Check("HAL_TIM_IC_ConfigChannel(CH1) returns HAL_OK",
          (HAL_TIM_IC_ConfigChannel(&htim_dev, &ic_cfg, TIM_CHANNEL_1) == HAL_OK));

    ic_cfg.ICPolarity  = TIM_ICPOLARITY_FALLING;
    ic_cfg.ICSelection = TIM_ICSEL_INDIRECTTI;
    Check("HAL_TIM_IC_ConfigChannel(CH2) returns HAL_OK",
          (HAL_TIM_IC_ConfigChannel(&htim_dev, &ic_cfg, TIM_CHANNEL_2) == HAL_OK));
    Check("CCMR1.CC1S = 01 (direct)", ((TIM0->CCMR1 & TIM_CCMR1_CC1S) == TIM_ICSEL_DIRECTTI));
    Check("CCMR1.CC2S = 10 (indirect)",
          ((TIM0->CCMR1 & TIM_CCMR1_CC2S) == (TIM_ICSEL_INDIRECTTI << 8U)));

    /* Step 4: TI1FP1 trigger and reset slave mode */
    __HAL_CLEAR_STRUCT(&slave_cfg);
    slave_cfg.SlaveMode      = TIM_SLAVEMODE_RESET;
    slave_cfg.InputTrigger   = TIM_TS_TI1FP1;
    slave_cfg.TriggerPolarity = TIM_TRIGGERPOLARITY_RISING;
    slave_cfg.TriggerPrescaler = 0U;
    slave_cfg.TriggerFilter  = 0U;
    Check("HAL_TIM_SlaveConfigSynchronization() returns HAL_OK",
          (HAL_TIM_SlaveConfigSynchronization(&htim_dev, &slave_cfg) == HAL_OK));
    Check("SMCR.TS = TI1FP1", ((TIM0->SMCR & TIM_SMCR_TS) == TIM_TS_TI1FP1));
    Check("SMCR.SMS = 100 (reset mode)",
          ((TIM0->SMCR & TIM_SMCR_SMS) == TIM_SLAVEMODE_RESET));

    /* Step 5: start the two capture channels */
    Check("HAL_TIM_IC_Start(CH1) returns HAL_OK", (HAL_TIM_IC_Start(&htim_dev, TIM_CHANNEL_1) == HAL_OK));
    Check("HAL_TIM_IC_Start(CH2) returns HAL_OK", (HAL_TIM_IC_Start(&htim_dev, TIM_CHANNEL_2) == HAL_OK));

    Summary();

    for (;;)
    {
        printf("CCR1 value: %d\r\n", (int)HAL_TIM_ReadCapturedValue(&htim_dev, TIM_CHANNEL_1));
        printf("CCR2 value: %d\r\n", (int)HAL_TIM_ReadCapturedValue(&htim_dev, TIM_CHANNEL_2));
        delay_ms(1000U);
    }
}
