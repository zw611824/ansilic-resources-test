# PMU 应用与测试参考

供 skill 按用户需求定位 AS32x601 HAL PMU 示例，共 25 个独立用例。

HAL 依据：[头文件](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_pmu.h)、[实现](../../HAL_LIBRARY/peripherals/src/as32x601_hal_pmu.c)。按所选案例核对当前驱动，不以接口索引代替实现依据。


## 实例与可选引脚

PMU 按睡眠模式选择内部或外部唤醒源。当前案例包含 PH2、PH3、PH4 等 GPIO 边沿唤醒，以及 RTC、IWDG 唤醒；对应案例和条件见下文。外部唤醒脚需按 PMU 唤醒选择定义、[GPIO 封装脚号](../GPIO/README.md#lqfp144-脚号与默认功能) 和板级电路共同核对，不能按普通外设 AF 名称推断可用唤醒源。

## 生成前需确认的参数

已有工程、板级资料或用户已明确的值直接复用。仅对影响本次实现的缺失选择使用参数卡询问并等待答复；案例配置不能代替实际接线或应用参数。

| 参数 | 需要核对或确认的内容 |
|---|---|
| 低功耗目标 | 睡眠模式、状态保持需求及醒后继续或复位的要求 |
| 唤醒条件 | RTC、外部引脚等实际来源、接线、极性和清标志时机 |
| 板级供电 | 供电条件、外接器件的电源/使能及功耗测量方式 |

## 按需求选择

按目标行为选择，再核对完整源码；组合需求可阅读多个用例，不直接合并多个 main。

| 用户需求 / 检索关键词 | 推荐用例 | 选择条件 / 需要补充的逻辑 |
|---|---|---|
| RC32K 最小调节值；SIRC 频率输出 | [001](PMU_IT_DRV_001.c) | PB4 CLKOUT；RC32KFS=0，需外部测频 |
| RC32K 最大调节值；SIRC 频率输出 | [002](PMU_IT_DRV_002.c) | PB4 CLKOUT；RC32KFS=0x3F，需外部测频 |
| Sleep 睡眠；IWDG 定时唤醒 | [003](PMU_IT_DRV_003.c) | 示例 10 s，准备看门狗与 PMU 唤醒源 |
| Sleep 睡眠；RTC 闹钟唤醒 | [004](PMU_IT_DRV_004.c) | 示例闹钟 20 s，核对 RTC 与 PMU 两侧配置 |
| Sleep 睡眠；PH2 边沿唤醒 | [005](PMU_IT_DRV_005.c) | 上拉输入、双边沿；需要外部信号，核对唤醒源掩码 |
| Sleep 睡眠；PH3 边沿唤醒 | [006](PMU_IT_DRV_006.c) | 上拉输入、双边沿；需要外部信号，核对唤醒源掩码 |
| Sleep 睡眠；PH4 边沿唤醒 | [007](PMU_IT_DRV_007.c) | 上拉输入、双边沿；需要外部信号，核对唤醒源掩码 |
| Sleep 睡眠；PH5 边沿唤醒 | [008](PMU_IT_DRV_008.c) | 上拉输入、双边沿；需要外部信号，核对唤醒源掩码 |
| Sleep 睡眠；PH6 边沿唤醒 | [009](PMU_IT_DRV_009.c) | 上拉输入、双边沿；需要外部信号，核对唤醒源掩码 |
| Sleep 睡眠；PH7 边沿唤醒 | [010](PMU_IT_DRV_010.c) | 上拉输入、双边沿；需要外部信号，核对唤醒源掩码 |
| Sleep 睡眠；PH8 边沿唤醒 | [011](PMU_IT_DRV_011.c) | 上拉输入、双边沿；需要外部信号，核对唤醒源掩码 |
| Sleep 睡眠；PH9 边沿唤醒 | [012](PMU_IT_DRV_012.c) | 上拉输入、双边沿；需要外部信号，核对唤醒源掩码 |
| Deep Sleep 深睡；IWDG 唤醒 | [013](PMU_IT_DRV_013.c) | 示例 5 s；唤醒复位重启，不从调用后继续 |
| Deep Sleep 深睡；RTC 唤醒 | [014](PMU_IT_DRV_014.c) | 示例 20 s；唤醒复位重启，启动时读取标志 |
| Deep Sleep 深睡；PH2 边沿唤醒 | [015](PMU_IT_DRV_015.c) | 外部边沿触发；唤醒复位重启，启动时读取标志 |
| Deep Sleep 深睡；PH3 边沿唤醒 | [016](PMU_IT_DRV_016.c) | 外部边沿触发；唤醒复位重启，启动时读取标志 |
| Deep Sleep 深睡；PH4 边沿唤醒 | [017](PMU_IT_DRV_017.c) | 外部边沿触发；唤醒复位重启，启动时读取标志 |
| Deep Sleep 深睡；PH5 边沿唤醒 | [018](PMU_IT_DRV_018.c) | 外部边沿触发；唤醒复位重启，启动时读取标志 |
| Deep Sleep 深睡；PH6 边沿唤醒 | [019](PMU_IT_DRV_019.c) | 外部边沿触发；唤醒复位重启，启动时读取标志 |
| Deep Sleep 深睡；PH7 边沿唤醒 | [020](PMU_IT_DRV_020.c) | 外部边沿触发；唤醒复位重启，启动时读取标志 |
| Deep Sleep 深睡；PH8 边沿唤醒 | [021](PMU_IT_DRV_021.c) | 外部边沿触发；唤醒复位重启，启动时读取标志 |
| Deep Sleep 深睡；PH9 边沿唤醒 | [022](PMU_IT_DRV_022.c) | 外部边沿触发；唤醒复位重启，启动时读取标志 |
| LDO、参考电压、电压检测、唤醒源、状态与锁 API | [023](PMU_IT_DRV_023.c) | 综合自检，不进入实际低功耗；不应任意降低运行电源 |
| MSP 生命周期、重复初始化与状态门控 | [024](PMU_IT_DRV_024.c) | 不进入实际低功耗，按生命周期需求读取 |
| 参数宏、唤醒掩码映射、组合掩码与 LDO ready | [025](PMU_IT_DRV_025.c) | 映射和寄存器一致性验证，不代表逐项实际唤醒测试 |

## 实现要点与案例配置

进入测试前的检查包括：001/002 回读 LDO 就绪标志；003/013 回读 IWDG 分频、超时和使能状态；004/014 检查 RTC 写入与启用状态；005～012、015～022 回读唤醒脚的 GPIO 复用和中断屏蔽位。检查结果与实际低功耗、唤醒现象分别判断。

001/002 将 SIRC 路由至 PB4 CLKOUT，分别写 RC32K 调节最小/最大值。源码引用约 22/42 kHz 的原测试观察值，不是本次测得或所有板卡的保证值；需示波器或频率计实测。

003～012 为 Sleep，013～022 为 Deep Sleep。先清理旧唤醒标志，准备源与门控，再进入对应模式。Sleep 观察返回后的唤醒标志；Deep Sleep 按源码预期会复位重启，应在启动时读取并清除来源，不能用“函数是否返回”判断通过。PH2～PH9 用例需要外部边沿，RTC / IWDG 示例时间取决于实际时钟配置。

验证 WKEN、模式请求、目标来源标志及清除结果，并结合真实唤醒现象；寄存器设置成功不证明已进入低功耗，功耗指标需仪表测量。023～025 是扩展自检，不代表实际进入电源模式。023 对运行依赖的电源轨只在约束范围内操作，电压调节代码不能脱离板卡供电条件直接复用；LDO ready 与真实输出电压也需分别判断。

当前 `HAL_PMU_PowerModeConfig()` 写入 PMCR.POWMC 字段并返回状态。HAL_OK 或模式状态读回只能确认请求/字段，不能单独证明实际休眠；应结合真实唤醒验证，不根据函数名假定存在 WFI 或通用低功耗入口。唤醒使能、来源查询和清除使用不同常量族，不能互换 WKEN 掩码、FLAG 选择值和 CLEAR 掩码，映射参考 025。

## 验证方法与适用边界

每个用例是独立测试程序。选定后核对实例、引脚或地址、时钟、配置、主循环、中断与回调，按目标板调整测试初值、日志和故障制造逻辑。综合接口自检只提供对应行为参考，不代表完整产品需求已覆盖。

本次为源码静态整理，未重新编译或上板；源码已有记录、预期结果与本次验证状态分别判断。

## 按接口与辅助宏检索

索引来自去除注释和字符串后的源码调用或定义，包含本模块 HAL、锁助手、寄存器及参数校验宏。MSP、IRQ、回调可能是定义或转发入口，需结合完整实现阅读；出现不代表所有分支都已验证。

| 接口 / 宏 | 参考用例 |
|---|---|
| `HAL_PMU_BLDO1v2VOLSca` | [023](PMU_IT_DRV_023.c) |
| `HAL_PMU_ClearFlag` | [003](PMU_IT_DRV_003.c)、[004](PMU_IT_DRV_004.c)、[005](PMU_IT_DRV_005.c)、[006](PMU_IT_DRV_006.c)、[007](PMU_IT_DRV_007.c)、[008](PMU_IT_DRV_008.c)、[009](PMU_IT_DRV_009.c)、[010](PMU_IT_DRV_010.c)、[011](PMU_IT_DRV_011.c)、[012](PMU_IT_DRV_012.c)、[013](PMU_IT_DRV_013.c)、[014](PMU_IT_DRV_014.c)、[015](PMU_IT_DRV_015.c)、[016](PMU_IT_DRV_016.c)、[017](PMU_IT_DRV_017.c)、[018](PMU_IT_DRV_018.c)、[019](PMU_IT_DRV_019.c)、[020](PMU_IT_DRV_020.c)、[021](PMU_IT_DRV_021.c)、[022](PMU_IT_DRV_022.c)、[023](PMU_IT_DRV_023.c)、[025](PMU_IT_DRV_025.c) |
| `HAL_PMU_DeInit` | [023](PMU_IT_DRV_023.c)、[024](PMU_IT_DRV_024.c) |
| `HAL_PMU_GetError` | [001](PMU_IT_DRV_001.c)、[002](PMU_IT_DRV_002.c)、[003](PMU_IT_DRV_003.c)、[004](PMU_IT_DRV_004.c)、[005](PMU_IT_DRV_005.c)、[006](PMU_IT_DRV_006.c)、[007](PMU_IT_DRV_007.c)、[008](PMU_IT_DRV_008.c)、[009](PMU_IT_DRV_009.c)、[010](PMU_IT_DRV_010.c)、[011](PMU_IT_DRV_011.c)、[012](PMU_IT_DRV_012.c)、[013](PMU_IT_DRV_013.c)、[014](PMU_IT_DRV_014.c)、[015](PMU_IT_DRV_015.c)、[016](PMU_IT_DRV_016.c)、[017](PMU_IT_DRV_017.c)、[018](PMU_IT_DRV_018.c)、[019](PMU_IT_DRV_019.c)、[020](PMU_IT_DRV_020.c)、[021](PMU_IT_DRV_021.c)、[022](PMU_IT_DRV_022.c)、[023](PMU_IT_DRV_023.c)、[024](PMU_IT_DRV_024.c) |
| `HAL_PMU_GetFlagStatus` | [003](PMU_IT_DRV_003.c)、[004](PMU_IT_DRV_004.c)、[005](PMU_IT_DRV_005.c)、[006](PMU_IT_DRV_006.c)、[007](PMU_IT_DRV_007.c)、[008](PMU_IT_DRV_008.c)、[009](PMU_IT_DRV_009.c)、[010](PMU_IT_DRV_010.c)、[011](PMU_IT_DRV_011.c)、[012](PMU_IT_DRV_012.c)、[013](PMU_IT_DRV_013.c)、[014](PMU_IT_DRV_014.c)、[015](PMU_IT_DRV_015.c)、[016](PMU_IT_DRV_016.c)、[017](PMU_IT_DRV_017.c)、[018](PMU_IT_DRV_018.c)、[019](PMU_IT_DRV_019.c)、[020](PMU_IT_DRV_020.c)、[021](PMU_IT_DRV_021.c)、[022](PMU_IT_DRV_022.c)、[023](PMU_IT_DRV_023.c)、[025](PMU_IT_DRV_025.c) |
| `HAL_PMU_GetPowerModeStatus` | [003](PMU_IT_DRV_003.c)、[004](PMU_IT_DRV_004.c)、[005](PMU_IT_DRV_005.c)、[006](PMU_IT_DRV_006.c)、[007](PMU_IT_DRV_007.c)、[008](PMU_IT_DRV_008.c)、[009](PMU_IT_DRV_009.c)、[010](PMU_IT_DRV_010.c)、[011](PMU_IT_DRV_011.c)、[012](PMU_IT_DRV_012.c)、[013](PMU_IT_DRV_013.c)、[014](PMU_IT_DRV_014.c)、[015](PMU_IT_DRV_015.c)、[016](PMU_IT_DRV_016.c)、[017](PMU_IT_DRV_017.c)、[018](PMU_IT_DRV_018.c)、[019](PMU_IT_DRV_019.c)、[020](PMU_IT_DRV_020.c)、[021](PMU_IT_DRV_021.c)、[022](PMU_IT_DRV_022.c)、[023](PMU_IT_DRV_023.c) |
| `HAL_PMU_GetState` | [001](PMU_IT_DRV_001.c)、[002](PMU_IT_DRV_002.c)、[003](PMU_IT_DRV_003.c)、[004](PMU_IT_DRV_004.c)、[005](PMU_IT_DRV_005.c)、[006](PMU_IT_DRV_006.c)、[007](PMU_IT_DRV_007.c)、[008](PMU_IT_DRV_008.c)、[009](PMU_IT_DRV_009.c)、[010](PMU_IT_DRV_010.c)、[011](PMU_IT_DRV_011.c)、[012](PMU_IT_DRV_012.c)、[013](PMU_IT_DRV_013.c)、[014](PMU_IT_DRV_014.c)、[015](PMU_IT_DRV_015.c)、[016](PMU_IT_DRV_016.c)、[017](PMU_IT_DRV_017.c)、[018](PMU_IT_DRV_018.c)、[019](PMU_IT_DRV_019.c)、[020](PMU_IT_DRV_020.c)、[021](PMU_IT_DRV_021.c)、[022](PMU_IT_DRV_022.c)、[023](PMU_IT_DRV_023.c)、[024](PMU_IT_DRV_024.c) |
| `HAL_PMU_GetWakeUpFlag` | [023](PMU_IT_DRV_023.c)、[025](PMU_IT_DRV_025.c) |
| `HAL_PMU_HighVolDetectCmd` | [023](PMU_IT_DRV_023.c) |
| `HAL_PMU_HighVolDetectThresholdSca` | [023](PMU_IT_DRV_023.c) |
| `HAL_PMU_Init` | [001](PMU_IT_DRV_001.c)、[002](PMU_IT_DRV_002.c)、[003](PMU_IT_DRV_003.c)、[004](PMU_IT_DRV_004.c)、[005](PMU_IT_DRV_005.c)、[006](PMU_IT_DRV_006.c)、[007](PMU_IT_DRV_007.c)、[008](PMU_IT_DRV_008.c)、[009](PMU_IT_DRV_009.c)、[010](PMU_IT_DRV_010.c)、[011](PMU_IT_DRV_011.c)、[012](PMU_IT_DRV_012.c)、[013](PMU_IT_DRV_013.c)、[014](PMU_IT_DRV_014.c)、[015](PMU_IT_DRV_015.c)、[016](PMU_IT_DRV_016.c)、[017](PMU_IT_DRV_017.c)、[018](PMU_IT_DRV_018.c)、[019](PMU_IT_DRV_019.c)、[020](PMU_IT_DRV_020.c)、[021](PMU_IT_DRV_021.c)、[022](PMU_IT_DRV_022.c)、[023](PMU_IT_DRV_023.c)、[024](PMU_IT_DRV_024.c)、[025](PMU_IT_DRV_025.c) |
| `HAL_PMU_LDO1v2Cmd` | [023](PMU_IT_DRV_023.c) |
| `HAL_PMU_LDO1v2VOLSca` | [001](PMU_IT_DRV_001.c)、[002](PMU_IT_DRV_002.c)、[003](PMU_IT_DRV_003.c)、[004](PMU_IT_DRV_004.c)、[005](PMU_IT_DRV_005.c)、[006](PMU_IT_DRV_006.c)、[007](PMU_IT_DRV_007.c)、[008](PMU_IT_DRV_008.c)、[009](PMU_IT_DRV_009.c)、[010](PMU_IT_DRV_010.c)、[011](PMU_IT_DRV_011.c)、[012](PMU_IT_DRV_012.c)、[013](PMU_IT_DRV_013.c)、[014](PMU_IT_DRV_014.c)、[015](PMU_IT_DRV_015.c)、[016](PMU_IT_DRV_016.c)、[017](PMU_IT_DRV_017.c)、[018](PMU_IT_DRV_018.c)、[019](PMU_IT_DRV_019.c)、[020](PMU_IT_DRV_020.c)、[021](PMU_IT_DRV_021.c)、[022](PMU_IT_DRV_022.c)、[023](PMU_IT_DRV_023.c)、[024](PMU_IT_DRV_024.c)、[025](PMU_IT_DRV_025.c) |
| `HAL_PMU_LDO2v5Cmd` | [023](PMU_IT_DRV_023.c) |
| `HAL_PMU_LDO2v5VOLSca` | [001](PMU_IT_DRV_001.c)、[002](PMU_IT_DRV_002.c)、[003](PMU_IT_DRV_003.c)、[004](PMU_IT_DRV_004.c)、[005](PMU_IT_DRV_005.c)、[006](PMU_IT_DRV_006.c)、[007](PMU_IT_DRV_007.c)、[008](PMU_IT_DRV_008.c)、[009](PMU_IT_DRV_009.c)、[010](PMU_IT_DRV_010.c)、[011](PMU_IT_DRV_011.c)、[012](PMU_IT_DRV_012.c)、[013](PMU_IT_DRV_013.c)、[014](PMU_IT_DRV_014.c)、[015](PMU_IT_DRV_015.c)、[016](PMU_IT_DRV_016.c)、[017](PMU_IT_DRV_017.c)、[018](PMU_IT_DRV_018.c)、[019](PMU_IT_DRV_019.c)、[020](PMU_IT_DRV_020.c)、[021](PMU_IT_DRV_021.c)、[022](PMU_IT_DRV_022.c)、[023](PMU_IT_DRV_023.c)、[024](PMU_IT_DRV_024.c)、[025](PMU_IT_DRV_025.c) |
| `HAL_PMU_LDO3v3BypassCmd` | [023](PMU_IT_DRV_023.c) |
| `HAL_PMU_LDO3v3Cmd` | [023](PMU_IT_DRV_023.c)、[025](PMU_IT_DRV_025.c) |
| `HAL_PMU_LDO3v3VOLSca` | [023](PMU_IT_DRV_023.c)、[025](PMU_IT_DRV_025.c) |
| `HAL_PMU_LowVolDetectCmd` | [023](PMU_IT_DRV_023.c) |
| `HAL_PMU_LowVolDetectThresholdSca` | [023](PMU_IT_DRV_023.c) |
| `HAL_PMU_LowVolResetCmd` | [023](PMU_IT_DRV_023.c) |
| `HAL_PMU_MspDeInit` | [024](PMU_IT_DRV_024.c) |
| `HAL_PMU_MspInit` | [024](PMU_IT_DRV_024.c) |
| `HAL_PMU_PowerModeConfig` | [003](PMU_IT_DRV_003.c)、[004](PMU_IT_DRV_004.c)、[005](PMU_IT_DRV_005.c)、[006](PMU_IT_DRV_006.c)、[007](PMU_IT_DRV_007.c)、[008](PMU_IT_DRV_008.c)、[009](PMU_IT_DRV_009.c)、[010](PMU_IT_DRV_010.c)、[011](PMU_IT_DRV_011.c)、[012](PMU_IT_DRV_012.c)、[013](PMU_IT_DRV_013.c)、[014](PMU_IT_DRV_014.c)、[015](PMU_IT_DRV_015.c)、[016](PMU_IT_DRV_016.c)、[017](PMU_IT_DRV_017.c)、[018](PMU_IT_DRV_018.c)、[019](PMU_IT_DRV_019.c)、[020](PMU_IT_DRV_020.c)、[021](PMU_IT_DRV_021.c)、[022](PMU_IT_DRV_022.c)、[023](PMU_IT_DRV_023.c) |
| `HAL_PMU_RC16MCmd` | [023](PMU_IT_DRV_023.c) |
| `HAL_PMU_RC32KFrequencySca` | [001](PMU_IT_DRV_001.c)、[002](PMU_IT_DRV_002.c)、[023](PMU_IT_DRV_023.c) |
| `HAL_PMU_Refer1v2Cmd` | [023](PMU_IT_DRV_023.c) |
| `HAL_PMU_Refer1v2VOLSca` | [023](PMU_IT_DRV_023.c) |
| `HAL_PMU_WakeUpSourceCmd` | [003](PMU_IT_DRV_003.c)、[004](PMU_IT_DRV_004.c)、[005](PMU_IT_DRV_005.c)、[006](PMU_IT_DRV_006.c)、[007](PMU_IT_DRV_007.c)、[008](PMU_IT_DRV_008.c)、[009](PMU_IT_DRV_009.c)、[010](PMU_IT_DRV_010.c)、[011](PMU_IT_DRV_011.c)、[012](PMU_IT_DRV_012.c)、[013](PMU_IT_DRV_013.c)、[014](PMU_IT_DRV_014.c)、[015](PMU_IT_DRV_015.c)、[016](PMU_IT_DRV_016.c)、[017](PMU_IT_DRV_017.c)、[018](PMU_IT_DRV_018.c)、[019](PMU_IT_DRV_019.c)、[020](PMU_IT_DRV_020.c)、[021](PMU_IT_DRV_021.c)、[022](PMU_IT_DRV_022.c)、[023](PMU_IT_DRV_023.c)、[025](PMU_IT_DRV_025.c) |
| `IS_PMU_ALL_INSTANCE` | [025](PMU_IT_DRV_025.c) |
| `IS_PMU_CLEAR` | [025](PMU_IT_DRV_025.c) |
| `IS_PMU_CLEAR_MASK` | [025](PMU_IT_DRV_025.c) |
| `IS_PMU_ENABLE_STATE` | [025](PMU_IT_DRV_025.c) |
| `IS_PMU_FLAG` | [025](PMU_IT_DRV_025.c) |
| `IS_PMU_HVDTS` | [025](PMU_IT_DRV_025.c) |
| `IS_PMU_LVDTS` | [025](PMU_IT_DRV_025.c) |
| `IS_PMU_POWERMODE` | [025](PMU_IT_DRV_025.c) |
| `IS_PMU_WKSOURCE` | [025](PMU_IT_DRV_025.c) |
| `IS_PMU_WKSOURCE_MASK` | [025](PMU_IT_DRV_025.c) |
| `PMU_LockHandle` | [023](PMU_IT_DRV_023.c) |
| `PMU_UnlockHandle` | [023](PMU_IT_DRV_023.c) |
| `__HAL_PMU_RESET_HANDLE_STATE` | [024](PMU_IT_DRV_024.c) |

