/**
 * @file    CRC_IT_DRV_003.c
 * @brief   HAL CRC integration test case 003 (accumulate versus calculate).
 *
 * HAL library extension case, and the regression case of the "reset services
 * must not disturb the configuration" requirement (CRC-REQ-041): the reset of
 * HAL_CRC_Calculate() and of HAL_CRC_Reset() only sets the RESET bit of the
 * control register, so the configured data size, polynomial size, input /
 * output reversal and output XOR survive.
 *
 * Tested functionality:
 *   HAL_CRC_StructInit() / HAL_CRC_Init()
 *   HAL_CRC_Accumulate()
 *   HAL_CRC_Calculate()
 *   HAL_CRC_Reset()
 *   HAL_CRC_GetCRC() / HAL_CRC_GetState() / HAL_CRC_GetError()
 *
 * Test procedure (a deliberately non-default configuration is used, so any
 * accidental reset of the control fields becomes visible):
 *   1. configure 16-bit data size, output XOR enabled, output reversal on,
 *      input reversal by byte, 16-bit polynomial size, initial value 0xFFFF,
 *      CRC-16/DNP polynomial, XOR value 0xFFFF;
 *   2. snapshot the control register;
 *   3. HAL_CRC_Calculate() over the buffer: the result must equal
 *      "HAL_CRC_Reset() + HAL_CRC_Accumulate()" over the same buffer, and the
 *      control register must be unchanged afterwards (this is the defect that
 *      the whole-word write of the control register used to cause);
 *   4. HAL_CRC_Reset() alone: the control register must stay unchanged and the
 *      accumulator must restart from the configured initial value (the data
 *      register keeps the last computed result until the next element is fed,
 *      so the restart is observed through the following Accumulate());
 *   5. the same calculate call twice gives the same value (the configuration
 *      is not degraded by the first call);
 *   6. segmented accumulation (two halves) equals one calculate over the whole
 *      buffer;
 *   7. the same equality is repeated with the default CRC-32 configuration, and
 *      the two configurations give different values (the configuration really
 *      reaches the hardware).
 *
 * Expected behaviour:
 *   every equality holds, the control register keeps its fields across the
 *   reset services, and the summary prints "summary : failures = 0".
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
#define TEST_BAUDRATE                  (115200U)   /*!< console baud rate        */
#define TEST_ROUND_DELAY_MS            (2000U)     /*!< delay between two rounds */

#define TEST_HALF_COUNT                (8U)        /*!< 16-bit element count     */
#define TEST_WORD_COUNT                (4U)        /*!< 32-bit element count     */

/* Private variables ---------------------------------------------------------*/
static volatile uint32 check_failures = 0U;   /*!< failed check counter           */
static HAL_SMU_HandleTypeDef hsmu_clk;        /*!< SMU handle (clock tree)        */

/** @brief CRC handle used by this case. */
HAL_CRC_HandleTypeDef hcrc_dev;

/* MSP callback bookkeeping (written by the shared MSP callbacks) */
uint32 Crc_MspInitCount   = 0U;               /*!< HAL_CRC_MspInit() calls        */
uint32 Crc_MspDeInitCount = 0U;               /*!< HAL_CRC_MspDeInit() calls      */
uint32 Crc_MspStateAtInit = 0xFFFFFFFFU;      /*!< handle state seen in the MSP   */
uint32 Crc_MspLockAtInit  = 0xFFFFFFFFU;      /*!< handle lock seen in the MSP    */

/* Test pattern */
static uint16 test_halfs[TEST_HALF_COUNT] =
{
    0x1234U, 0x5678U, 0x9ABCU, 0xDEF0U, 0x0F1EU, 0x2D3CU, 0x4B5AU, 0x6978U
};

static uint32 test_words[TEST_WORD_COUNT] =
{
    0x11223344U, 0x55667788U, 0x99AABBCCU, 0xDDEEFF00U
};

/* Shared helpers of this suite (defined at the end of this file) */
void Check(const char *name, uint32 condition);
void Summary(void);
void SystemClock_Init(void);
void Crc_ClockEnable(void);



/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    CRC_InitTypeDef   crc_init;
    HAL_StatusTypeDef status;
    uint32 round = 0U;
    uint32 cr_configured;
    uint32 result_calculate;
    uint32 result_accumulate;
    uint32 result_second;
    uint32 result_segmented;
    uint32 result_default;
    uint32 result_nondefault;
    uint32 reset_value;

/* The RESET bit of the control register is self clearing on the device, so
 * every control register comparison below masks it out: what must survive is
 * the configuration (data size, polynomial size, input / output reversal and
 * output XOR), which is exactly the defect this case guards against. */

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock (PLL 180 MHz) */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== CRC_IT_DRV_003 : accumulate versus calculate ===\r\n");

    /* Handle preparation */
    __HAL_CLEAR_STRUCT(&hcrc_dev);
    hcrc_dev.Instance = CRC;
    HAL_CRC_StructInit(&crc_init);
    Check("HAL_CRC_StructInit() fills the Size metafield",
          (crc_init.Size == (uint32)sizeof(CRC_InitTypeDef)) ? 1U : 0U);
    Check("HAL_CRC_StructInit() fills the Version metafield",
          (crc_init.Version == CRC_INIT_VERSION) ? 1U : 0U);
    hcrc_dev.Init = crc_init;
    hcrc_dev.InputDataFormat = HAL_CRC_INPUTDATA_FORMAT_HALFWORDS;

    status = HAL_CRC_Init(&hcrc_dev);
    Check("HAL_CRC_Init() returns HAL_OK", (status == HAL_OK) ? 1U : 0U);
    Check("the handle is READY", (HAL_CRC_GetState(&hcrc_dev) == HAL_CRC_STATE_READY) ? 1U : 0U);

    for (;;)
    {
        /* ---------------- non-default configuration ----------------------- */
        hcrc_dev.Init.CRC_Size     = CRC_SIZE_16B;
        hcrc_dev.Init.CRC_OXOR     = CRC_OXOR_ENABLE;
        hcrc_dev.Init.CRC_OReverse = CRC_OREVERSE_BIT;
        hcrc_dev.Init.CRC_IReverse = CRC_IREVERSE_BYTE;
        hcrc_dev.Init.CRC_PolySize = CRC_POLYSIZE_16B;
        hcrc_dev.Init.CRC_INIT     = 0x0000FFFFU;
        hcrc_dev.Init.CRC_Poly     = CRC_POLY_16DNP;
        hcrc_dev.Init.CRC_XOR      = 0x0000FFFFU;
        hcrc_dev.InputDataFormat   = HAL_CRC_INPUTDATA_FORMAT_HALFWORDS;

        status = HAL_CRC_Init(&hcrc_dev);
        if (round == 0U)
        {
            Check("the non-default configuration is accepted", (status == HAL_OK) ? 1U : 0U);
            Check("the control register holds the 16-bit data size",
                  ((CRC->CR & CRC_CR_SIZE) == ((uint32)CRC_SIZE_16B << CRC_CR_SIZE_Pos)) ? 1U : 0U);
            Check("the control register holds the output XOR enable",
                  ((CRC->CR & CRC_CR_XOROUT) != 0U) ? 1U : 0U);
            Check("the control register holds the output reversal enable",
                  ((CRC->CR & CRC_CR_REVOUT) != 0U) ? 1U : 0U);
            Check("the control register holds the input reversal mode (byte)",
                  ((CRC->CR & CRC_CR_REVIN) == ((uint32)CRC_IREVERSE_BYTE << CRC_CR_REVIN_Pos)) ? 1U : 0U);
            Check("the control register holds the 16-bit polynomial size",
                  ((CRC->CR & CRC_CR_POLYSIZE) == ((uint32)CRC_POLYSIZE_16B << CRC_CR_POLYSIZE_Pos)) ? 1U : 0U);
        }
        cr_configured = CRC->CR;

        /* ---------------- calculate: reset + feed in one transaction ------- */
        result_calculate = HAL_CRC_Calculate(&hcrc_dev, test_halfs, TEST_HALF_COUNT);
        if (round == 0U)
        {
            Check("Calculate() keeps every configured control field (CRC-REQ-041)",
                  ((CRC->CR & ~(uint32)CRC_CR_RESET) ==
                   (cr_configured & ~(uint32)CRC_CR_RESET)) ? 1U : 0U);
            Check("Calculate() keeps the 16-bit data size",
                  ((CRC->CR & CRC_CR_SIZE) == ((uint32)CRC_SIZE_16B << CRC_CR_SIZE_Pos)) ? 1U : 0U);
            Check("Calculate() keeps the output XOR / reversal enables",
                  ((CRC->CR & (CRC_CR_XOROUT | CRC_CR_REVOUT)) ==
                   (cr_configured & (CRC_CR_XOROUT | CRC_CR_REVOUT))) ? 1U : 0U);
            Check("Calculate() keeps the input reversal mode",
                  ((CRC->CR & CRC_CR_REVIN) == (cr_configured & CRC_CR_REVIN)) ? 1U : 0U);
            Check("Calculate() leaves the handle READY",
                  (HAL_CRC_GetState(&hcrc_dev) == HAL_CRC_STATE_READY) ? 1U : 0U);
        }

        /* ---------------- reset keeps the configuration -------------------- */
        HAL_CRC_Reset(&hcrc_dev);
        reset_value = HAL_CRC_GetCRC(&hcrc_dev);
        if (round == 0U)
        {
            Check("Reset() keeps every configured control field (CRC-REQ-041)",
                  ((CRC->CR & ~(uint32)CRC_CR_RESET) ==
                   (cr_configured & ~(uint32)CRC_CR_RESET)) ? 1U : 0U);
            /* the data register keeps the last computed result across the
             * reset (no preload on this device); the restart from CRC_INIT is
             * proven by the Calculate() == Reset() + Accumulate() check below */
            Check("Reset() keeps the last result in CRC_DR until the next element",
                  (reset_value == result_calculate) ? 1U : 0U);
        }

        /* ---------------- accumulate from the initial value ---------------- */
        result_accumulate = HAL_CRC_Accumulate(&hcrc_dev, test_halfs, TEST_HALF_COUNT);
        if (round == 0U)
        {
            Check("Calculate() equals Reset() + Accumulate()",
                  (result_calculate == result_accumulate) ? 1U : 0U);
            Check("the result read back equals the returned value",
                  (HAL_CRC_GetCRC(&hcrc_dev) == result_accumulate) ? 1U : 0U);
        }

        /* ---------------- repeatability ------------------------------------ */
        result_second = HAL_CRC_Calculate(&hcrc_dev, test_halfs, TEST_HALF_COUNT);
        if (round == 0U)
        {
            Check("a repeated Calculate() gives the same value (configuration intact)",
                  (result_second == result_calculate) ? 1U : 0U);
            Check("the configuration is still intact after the second Calculate()",
                  ((CRC->CR & ~(uint32)CRC_CR_RESET) ==
                   (cr_configured & ~(uint32)CRC_CR_RESET)) ? 1U : 0U);
        }

        /* ---------------- segmented accumulation --------------------------- */
        HAL_CRC_Reset(&hcrc_dev);
        (void)HAL_CRC_Accumulate(&hcrc_dev, test_halfs, TEST_HALF_COUNT / 2U);
        result_segmented = HAL_CRC_Accumulate(&hcrc_dev,
                                              &test_halfs[TEST_HALF_COUNT / 2U],
                                              TEST_HALF_COUNT / 2U);
        if (round == 0U)
        {
            Check("two accumulated halves equal one Calculate() over both",
                  (result_segmented == result_calculate) ? 1U : 0U);
        }

        /* ---------------- default configuration ---------------------------- */
        HAL_CRC_StructInit(&crc_init);
        hcrc_dev.Init = crc_init;
        hcrc_dev.InputDataFormat = HAL_CRC_INPUTDATA_FORMAT_WORDS;
        status = HAL_CRC_Init(&hcrc_dev);
        cr_configured = CRC->CR;
        if (round == 0U)
        {
            Check("the default configuration is accepted again", (status == HAL_OK) ? 1U : 0U);
        }

        result_default = HAL_CRC_Calculate(&hcrc_dev, test_words, TEST_WORD_COUNT);
        HAL_CRC_Reset(&hcrc_dev);
        result_nondefault = HAL_CRC_Accumulate(&hcrc_dev, test_words, TEST_WORD_COUNT);

        if (round == 0U)
        {
            Check("the default configuration keeps its control fields",
                  ((CRC->CR & ~(uint32)CRC_CR_RESET) ==
                   (cr_configured & ~(uint32)CRC_CR_RESET)) ? 1U : 0U);
            Check("Calculate() equals Reset() + Accumulate() with the default configuration",
                  (result_default == result_nondefault) ? 1U : 0U);
        }

        printf("non-default : calculate 0x%08X / accumulate 0x%08X / segmented 0x%08X\r\n",
               (unsigned int)result_calculate, (unsigned int)result_accumulate, (unsigned int)result_segmented);
        printf("default     : calculate 0x%08X / accumulate 0x%08X\r\n",
               (unsigned int)result_default, (unsigned int)result_nondefault);

        if (round == 0U)
        {
            Check("no error was recorded", (HAL_CRC_GetError(&hcrc_dev) == HAL_CRC_ERROR_NONE) ? 1U : 0U);
            Summary();
        }

        round++;
        delay_ms(TEST_ROUND_DELAY_MS);
    }
}

/* Private functions -------------------------------------------------------*/

/**
 * @brief  Record the result of one check.
 * @param  name: description of the check
 * @param  condition: non zero when the check passed
 * @retval None
 */
void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("  [PASS] %s\r\n", name);
    }
    else
    {
        check_failures++;
        printf("  [FAIL] %s\r\n", name);
    }
}

/**
 * @brief  Print the check summary of this case.
 * @param  None
 * @retval None
 */
void Summary(void)
{
    printf("summary : failures = %d\r\n", (int)check_failures);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the other integration tests of this library:
 *         PLL VCO 180 MHz, AXI4Bus3 / APBBus0 / APBBus1 divided by 2 and
 *         CANX2 by 8, which gives core 180 MHz and APB 22.5 MHz.
 * @param  None
 * @retval None
 */
void SystemClock_Init(void)
{
    SMU_OscInitTypeDef    SMU_OscInitStruct;
    SMU_ClockInitTypeDef  SMU_ClockInitStruct;
    SMU_ClocksTypeDef     SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();
    __HAL_SMU_CLINT_CLK_ENABLE();

    /* GPIO port clocks (console pins of USART0 on GPIOD) */
    __HAL_SMU_GPIOA_CLK_ENABLE();
    __HAL_SMU_GPIOB_CLK_ENABLE();
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();
    __HAL_SMU_GPIOE_CLK_ENABLE();
    __HAL_SMU_GPIOF_CLK_ENABLE();
    __HAL_SMU_GPIOG_CLK_ENABLE();

    /* Console USART0 */
    __HAL_SMU_USART0_CLK_ENABLE();
    __HAL_SMU_USART0_FORCE_RESET();
    __HAL_SMU_USART0_RELEASE_RESET();

    /* PMU first: the LDO API is gated on the handle state */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    /* Read back the clock tree (for reference) */
    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/**
 * @brief  Open the clock gate of the CRC unit and release its reset.
 * @param  None
 * @retval None
 */
void Crc_ClockEnable(void)
{
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_CRC_CLK_ENABLE();
    __HAL_SMU_CRC_FORCE_RESET();
    __HAL_SMU_CRC_RELEASE_RESET();
}

/* MSP callbacks ------------------------------------------------------------*/

/**
 * @brief  Initialize the CRC MSP (clock gate and reset release).
 * @param  hcrc: CRC handle
 * @retval None
 */
void HAL_CRC_MspInit(HAL_CRC_HandleTypeDef *hcrc)
{
    Crc_MspInitCount++;
    Crc_MspStateAtInit = (uint32)hcrc->State;
    Crc_MspLockAtInit  = (uint32)hcrc->Lock;

    Crc_ClockEnable();
}

/**
 * @brief  De-initialize the CRC MSP (the clock gate is left open).
 * @param  hcrc: CRC handle
 * @retval None
 */
void HAL_CRC_MspDeInit(HAL_CRC_HandleTypeDef *hcrc)
{
    Crc_MspDeInitCount++;

    (void)hcrc;
}

/*****END OF FILE*****/
