/**
 * @file    SMU_IT_DRV_001.c
 * @brief   HAL SMU integration test case 001 (FIRC as the system clock, default calibration).
 *
 * One-to-one HAL library port of the original AS32x601 standard-library test
 * case SMU_IT_DRV_001.c. Only HAL library APIs are used.
 *
 * Tested functionality:
 *   HAL_SMU_Init()
 *   HAL_SMU_ClockConfig()   (bus dividers: AXI4Bus3 /2, APBBus0 /2,
 *                            APBBus1 /2, CANCLKx2 /8)
 *   HAL_SMU_OscConfig()     (oscillator / PLL / system clock source)
 *   HAL_SMU_GetClocksFreq() / HAL_SMU_GetClockConfig() /
 *   HAL_SMU_GetOscConfig()
 *   HAL_SMU_MCOConfig()     (clock output on PB4, measured with a scope)
 *
 * Test procedure:
 *   1. The standard clock tree (PLL 180 MHz, the same tree the other
 *      integration suites use) is applied first, so that the console runs at
 *      a known baud rate and the result can be reported on it;
 *   2. Stage 1 applies the clock under test (FIRC as the system clock, default calibration) and drives it to PB4
 *      through the SMU clock output (selection Core clock / 8 (SYSCLK = FIRC)), then holds
 *      it for 5000 ms for the oscilloscope measurement.  Nothing is
 *      printed during stage 1: the console clock is derived from the system
 *      clock, so a print would leave the console at a wrong baud rate;
 *   3. Stage 2 restores the standard clock tree, re-initializes the console
 *      (its baud rate divider is recomputed from the restored clock) and
 *      prints every check that stage 1 collected.
 *
 * Expected behaviour:
 *   - Oscilloscope on PB4 during stage 1: about 2.0 MHz - the 16 MHz FIRC divided by 8
 *     (nominal value computed by the firmware: FIRC_VALUE (16 MHz nominal) / 8);
 *   - every register / API check printed in stage 2 must pass and the last
 *     line must read "summary : failures = 0".
 *
 * Note: the original standard-library test case relied on the oscilloscope
 * only.  This port keeps the PB4 output (so the measurement can be repeated
 * exactly as before) and adds the firmware side checks, so that the test can
 * also be run without an oscilloscope.

 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ----------------------------------------------------------*/
/* Console baud rate */
#define TEST_BAUDRATE               (115200U)

/* Window during which PB4 carries the clock under test */
#define TEST_WINDOW_MS              (5000U)

/* Standard clock tree (the same tree the other HAL integration suites use):
 * PLL fed by the 20 MHz OSC, VCO 180 MHz, PLLCLK_Q = 180 MHz, bus dividers
 * AXI4Bus3 /2, APBBus0 /2, APBBus1 /2, CANCLKx2 /8. */
#define STD_PLL_DIV_R               (0x04U)
#define STD_PLL_DIV_Q               (0x01U)
#define STD_PLL_DIV_N               (0x14U)
#define STD_PLL_DIV_F               (0xB4U)
#define STD_AXI4BUS3_DIV            SMU_AXI4BUS3CLK_DIV2
#define STD_APBBUS0_DIV             SMU_APBBUS0CLK_DIV2
#define STD_APBBUS1_DIV             SMU_APBBUS1CLK_DIV2
#define STD_CANX2_DIV               SMU_CANX2CLK_DIV8

/* FIRC calibration: 0x00..0x3F programs the register, TEST_FIRC_CAL_KEEP
 * leaves the calibration the device came up with (used by the cases that need
 * the FIRC running but must not change its frequency). */
#define TEST_FIRC_CAL_MAX           (0x3FU)
#define TEST_FIRC_CAL_KEEP          (0x100U)

/* The clock output of the SIRC (RC32K) source has no divider; the nominal
 * frequency is the 32768 Hz given by the vendor test plan. */
#define TEST_SIRC_NOMINAL_HZ        (32768U)

/* Check list size */
#define TEST_CHECK_MAX              (20U)

/* ---------------------- parameters of this test case --------------------- */
#define TEST_SYSCLK_SOURCE          SMU_SYSCLKSOURCE_FIRC
#define TEST_OSC_TYPE               SMU_OSCILLATORTYPE_OSC
#define TEST_FIRC_STATE             SMU_FIRC_ON
#define TEST_FIRC_CAL               (TEST_FIRC_CAL_KEEP)
#define TEST_PLL_STATE              SMU_PLL_NONE
#define TEST_PLL_SOURCE             SMU_PLLSOURCE_OSC
#define TEST_PLL_DIV_N              (0x14U)
#define TEST_CLKOUT_MUX             SMU_CLKOUTMUX_CORECLK_DIV8
#define TEST_CLKOUT_NAME            "Core clock / 8 (SYSCLK = FIRC)"
#define TEST_SCOPE_EXPECT           "about 2.0 MHz - the 16 MHz FIRC divided by 8"
#define TEST_NOMINAL_HZ             (2000000U)
#define TEST_NOMINAL_TEXT           "FIRC_VALUE (16 MHz nominal) / 8"

/* Private typedef ---------------------------------------------------------*/
/**
 * @brief One firmware side check: a name, the expected and the actual value.
 */
typedef struct
{
    const char *name;       /*!< check description                        */
    uint32      expect;     /*!< expected value                           */
    uint32      actual;     /*!< value read back by the driver            */
} SMU_CheckTypeDef;

/* Private variables -------------------------------------------------------*/
static HAL_SMU_HandleTypeDef hsmu_dev;      /*!< SMU handle (lock/state/error) */
static HAL_PMU_HandleTypeDef hpmu_dev;      /*!< PMU handle (LDO scaler)       */

/* Values collected while the clock under test was applied (stage 1) */
static SMU_ClocksTypeDef    g_clk_tested;   /*!< HAL_SMU_GetClocksFreq()      */
static SMU_OscInitTypeDef   g_osc_readback; /*!< HAL_SMU_GetOscConfig()       */
static SMU_ClockInitTypeDef g_div_readback; /*!< HAL_SMU_GetClockConfig()     */
static uint32               g_osc_status;   /*!< HAL_SMU_OscConfig() result   */
static uint32               g_clk_status;   /*!< HAL_SMU_ClockConfig() result */
static uint32               g_clkout_reg;   /*!< OTHCFGR.CLKOUTMUX read back  */
static uint32               g_sysclk_hz;    /*!< HAL_SMU_GetSysClockFreq()    */
static uint32               g_hclk_hz;      /*!< HAL_SMU_GetHCLKFreq()        */
static uint32               g_pclk0_hz;     /*!< HAL_SMU_GetPCLK0Freq()       */
static uint32               g_pclk1_hz;     /*!< HAL_SMU_GetPCLK1Freq()       */
static uint32               g_clkout_hz;    /*!< frequency driven to PB4      */
static SMU_CheckTypeDef     g_check[TEST_CHECK_MAX];
static uint32               g_check_n;      /*!< number of collected checks   */
static uint32               g_setup_fail;   /*!< stage 1 setup failures       */

/* Private function prototypes ---------------------------------------------*/
static void   SystemClock_Standard(void);
static void   SystemClock_UnderTest(void);
static void   CLKOUT_GPIO_Init(void);
static void   Periph_Init(void);
static uint32 ClockoutSourceFreq(const SMU_ClocksTypeDef *clk, uint32 mux);
static void   CkAdd(const char *name, uint32 expect, uint32 actual);
static uint32 CkPrint(const SMU_CheckTypeDef *ck);
static void   PrintClocks(const char *tag, const SMU_ClocksTypeDef *clk);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    uint32 i;
    uint32 failures;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Initialize the SMU and the PMU handles (bare metal: no RTOS mutex) */
    Periph_Init();

    /* Bring up the standard clock tree before anything else */
    SystemClock_Standard();

    /* Initialize the delay module (cycles per microsecond) and the console */
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);

    printf("\r\n=== SMU_IT_DRV_001: FIRC as the system clock, default calibration ===\r\n");
    printf("standard tree: SYSCLK = %u Hz, PCLK0 = %u Hz\r\n",
           PRINT_U32(g_sysclk_hz), PRINT_U32(g_pclk0_hz));
    printf("stage 1 will drive PB4 with %s for %u ms\r\n",
           TEST_CLKOUT_NAME, PRINT_U32(TEST_WINDOW_MS));

    /* Configure PB4 as the SMU clock output pin (AF = CLKOUT) */
    CLKOUT_GPIO_Init();

    /* ---------------------------------------------------------------------
     * Stage 1: apply the clock under test.  The console is deliberately
     * silent from here until the standard tree has been restored.
     * --------------------------------------------------------------------- */
    SystemClock_UnderTest();

    /* Collect the firmware side evidence while the clock under test runs */
    CkAdd("HAL_SMU_ClockConfig() returns HAL_OK", (uint32)HAL_OK, g_clk_status);
    CkAdd("HAL_SMU_OscConfig() returns HAL_OK", (uint32)HAL_OK, g_osc_status);
    CkAdd("HAL_SMU_GetClocksFreq() returns HAL_OK",
          (uint32)HAL_OK, (uint32)HAL_SMU_GetClocksFreq(&g_clk_tested));
    CkAdd("HAL_SMU_GetClockConfig() returns HAL_OK",
          (uint32)HAL_OK, (uint32)HAL_SMU_GetClockConfig(&g_div_readback));
    CkAdd("HAL_SMU_GetOscConfig() returns HAL_OK",
          (uint32)HAL_OK, (uint32)HAL_SMU_GetOscConfig(&g_osc_readback));
    CkAdd("bus divider AXI4Bus3 read back",
          (uint32)STD_AXI4BUS3_DIV, g_div_readback.AXI4Bus3CLKDiv);
    CkAdd("bus divider APBBus0 read back",
          (uint32)STD_APBBUS0_DIV, g_div_readback.APBBus0CLKDiv);
    CkAdd("bus divider APBBus1 read back",
          (uint32)STD_APBBUS1_DIV, g_div_readback.APBBus1CLKDiv);
    CkAdd("bus divider CANCLKx2 read back",
          (uint32)STD_CANX2_DIV, g_div_readback.CANX2CLKDiv);
    CkAdd("system clock source in the register",
          (uint32)TEST_SYSCLK_SOURCE, g_osc_readback.SYSCLKSelect);
    CkAdd("clock output mux in the register",
          (uint32)TEST_CLKOUT_MUX, g_clkout_reg);
    CkAdd("PB4 frequency estimate agrees with the tree",
          (uint32)TEST_NOMINAL_HZ, g_clkout_hz);

    /* Keep the clock under test on PB4 for the oscilloscope window */
    delay_ms(TEST_WINDOW_MS);

    /* ---------------------------------------------------------------------
     * Stage 2: restore the standard tree and report.
     * --------------------------------------------------------------------- */
    SystemClock_Standard();
    delay_init(SystemCoreClock / 1000000U);
    User_Print_Init(TEST_BAUDRATE);

    printf("\r\n--- stage 1 collected %u check(s), %u setup failure(s) ---\r\n",
           PRINT_U32(g_check_n), PRINT_U32(g_setup_fail));

    failures = g_setup_fail;
    for (i = 0U; i < g_check_n; i++)
    {
        failures += CkPrint(&g_check[i]);
    }

    printf("\r\noscilloscope on PB4 (stage 1) : %s\r\n", TEST_SCOPE_EXPECT);
    printf("firmware estimate of PB4      : %u Hz\r\n", PRINT_U32(g_clkout_hz));
    printf("value used for the estimate   : %s\r\n", TEST_NOMINAL_TEXT);
    printf("SYSCLK under test             : %u Hz\r\n", PRINT_U32(g_sysclk_hz));
    printf("HCLK / PCLK0 / PCLK1          : %u / %u / %u Hz\r\n",
           PRINT_U32(g_hclk_hz), PRINT_U32(g_pclk0_hz), PRINT_U32(g_pclk1_hz));
    printf("\r\nclocks with the clock under test applied:\r\n");
    PrintClocks("under test", &g_clk_tested);

    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(failures));

    while (1)
    {
    }
}

/**
 * @brief  Initialize the SMU and PMU handles used by this test case.
 * @note   The PMU is initialized before the LDO scaling calls: the PMU APIs
 *         are gated on the handle state, so a handle that is only cleared
 *         would have its requests rejected (PMU_CheckState).
 * @param  None
 * @retval None
 */
static void Periph_Init(void)
{
    __HAL_CLEAR_STRUCT(&hsmu_dev);
    hsmu_dev.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_dev);
    
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&hpmu_dev);
    hpmu_dev.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu_dev);
    (void)HAL_PMU_LDO2v5VOLSca(&hpmu_dev, PMU_VO25_2V78);
    (void)HAL_PMU_LDO1v2VOLSca(&hpmu_dev, PMU_VO12_1V34);
}

/**
 * @brief  Configure PB4 as the SMU clock output (alternate function CLKOUT).
 * @note   The original test case uses the same pin for the same purpose: the
 *         SMU drives the selected internal clock to PB4 so that it can be
 *         measured with an oscilloscope.  PB4 is not one of the pins whose
 *         default function is MUL0, so it is free to use.
 * @param  None
 * @retval None
 */
static void CLKOUT_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    __HAL_SMU_GPIOB_CLK_ENABLE();

    HAL_GPIO_PinAFConfig(GPIOB, GPIO_PinSource4, GPIO_AF_CLKOUT);

    __HAL_CLEAR_STRUCT(&GPIO_InitStruct);
    GPIO_InitStruct.Size         = sizeof(GPIO_InitStruct);
    GPIO_InitStruct.Version      = GPIO_INIT_VERSION;
    GPIO_InitStruct.Pin          = GPIO_PIN_4;
    GPIO_InitStruct.Mode         = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull         = GPIO_NOPULL;
    GPIO_InitStruct.DriveCurrent = GPIO_DRIVE_CURRENT_LOW;
    GPIO_InitStruct.Alternate    = GPIO_AF_CLKOUT;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}

/**
 * @brief  Apply the standard clock tree (PLL 180 MHz from the OSC).
 * @note   The order matters and follows the chip requirement: the bus
 *         dividers are written first, while the system clock is still the
 *         power-on FIRC, then HAL_SMU_OscConfig() programs the flash
 *         controller clock, switches the system clock to the PLL and performs
 *         the flash clock update.  Writing the dividers after the switch
 *         would leave the buses at their reset dividers for a moment at the
 *         new core clock.
 * @param  None
 * @retval None
 */
static void SystemClock_Standard(void)
{
    SMU_OscInitTypeDef   osc;
    SMU_ClockInitTypeDef clk;

    /* Bus dividers of the standard tree */
    __HAL_CLEAR_STRUCT(&clk);
    clk.Size            = sizeof(clk);
    clk.Version         = SMU_CLOCK_INIT_VERSION;
    clk.AXI4Bus3CLKDiv  = STD_AXI4BUS3_DIV;
    clk.APBBus0CLKDiv   = STD_APBBUS0_DIV;
    clk.APBBus1CLKDiv   = STD_APBBUS1_DIV;
    clk.CANX2CLKDiv     = STD_CANX2_DIV;
    (void)HAL_SMU_ClockConfig(&hsmu_dev, &clk);

    /* PLL from the OSC, then switch the system clock to it */
    __HAL_CLEAR_STRUCT(&osc);
    osc.Size                 = sizeof(osc);
    osc.Version              = SMU_OSC_INIT_VERSION;
    osc.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    osc.FIRCState            = SMU_FIRC_ON;
    osc.FIRCCalibrationValue = 0x00U;
    osc.PLL.Size             = sizeof(osc.PLL);
    osc.PLL.Version          = SMU_PLL_INIT_VERSION;
    osc.PLL.PLLState         = SMU_PLL_ON;
    osc.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    osc.PLL.PLLDivR          = STD_PLL_DIV_R;
    osc.PLL.PLLDivQ          = STD_PLL_DIV_Q;
    osc.PLL.PLLDivN          = STD_PLL_DIV_N;
    osc.PLL.PLLDivF          = STD_PLL_DIV_F;
    osc.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;
    (void)HAL_SMU_OscConfig(&hsmu_dev, &osc, SMU_TIMEOUT_DEFAULT);

    g_sysclk_hz = HAL_SMU_GetSysClockFreq();
    g_pclk0_hz  = HAL_SMU_GetPCLK0Freq();
    g_pclk1_hz  = HAL_SMU_GetPCLK1Freq();
}

/**
 * @brief  Apply the clock under test and drive it to PB4.
 * @note   Nothing is printed here on purpose (see the file header).
 * @param  None
 * @retval None
 */
static void SystemClock_UnderTest(void)
{
    SMU_OscInitTypeDef   osc;
    SMU_ClockInitTypeDef clk;
    SMU_OscInitTypeDef   now;

    /* Bus dividers: the standard dividers, so that the comparison with the
     * other suites is meaningful */
    __HAL_CLEAR_STRUCT(&clk);
    clk.Size            = sizeof(clk);
    clk.Version         = SMU_CLOCK_INIT_VERSION;
    clk.AXI4Bus3CLKDiv  = STD_AXI4BUS3_DIV;
    clk.APBBus0CLKDiv   = STD_APBBUS0_DIV;
    clk.APBBus1CLKDiv   = STD_APBBUS1_DIV;
    clk.CANX2CLKDiv     = STD_CANX2_DIV;
    g_clk_status = (uint32)HAL_SMU_ClockConfig(&hsmu_dev, &clk);
    if (g_clk_status != (uint32)HAL_OK)
    {
        g_setup_fail++;
    }

    /* FIRC calibration: either the value of the case, or the calibration the
     * device came up with (used by the cases that need the FIRC as the PLL
     * input but must not change its frequency) */
    (void)HAL_SMU_GetOscConfig(&now);

    __HAL_CLEAR_STRUCT(&osc);
    osc.Size           = sizeof(osc);
    osc.Version        = SMU_OSC_INIT_VERSION;
    osc.OscillatorType = TEST_OSC_TYPE;
    osc.FIRCState      = TEST_FIRC_STATE;
    osc.SYSCLKSelect   = TEST_SYSCLK_SOURCE;
    osc.PLL.Size       = sizeof(osc.PLL);
    osc.PLL.Version    = SMU_PLL_INIT_VERSION;
    osc.PLL.PLLState   = TEST_PLL_STATE;
    osc.PLL.PLLSource  = TEST_PLL_SOURCE;
    osc.PLL.PLLDivR    = STD_PLL_DIV_R;
    osc.PLL.PLLDivQ    = STD_PLL_DIV_Q;
    osc.PLL.PLLDivN    = TEST_PLL_DIV_N;
    osc.PLL.PLLDivF    = STD_PLL_DIV_F;

    if (TEST_FIRC_CAL <= TEST_FIRC_CAL_MAX)
    {
        osc.FIRCCalibrationValue = TEST_FIRC_CAL;
    }
    else
    {
        osc.FIRCCalibrationValue = now.FIRCCalibrationValue;
    }

    g_osc_status = (uint32)HAL_SMU_OscConfig(&hsmu_dev, &osc, SMU_TIMEOUT_DEFAULT);
    if (g_osc_status != (uint32)HAL_OK)
    {
        g_setup_fail++;
    }

    /* Drive the selected clock to PB4 */
    HAL_SMU_MCOConfig(&hsmu_dev, TEST_CLKOUT_MUX);

    /* Read back the clock output selection and the produced frequencies */
    g_clkout_reg = (SMU->OTHCFGR & SMU_OTHCFGR_CLKOUTMUX) >> SMU_OTHCFGR_CLKOUTMUX_Pos;
    g_sysclk_hz  = HAL_SMU_GetSysClockFreq();
    g_hclk_hz    = HAL_SMU_GetHCLKFreq();
    g_pclk0_hz   = HAL_SMU_GetPCLK0Freq();
    g_pclk1_hz   = HAL_SMU_GetPCLK1Freq();
    (void)HAL_SMU_GetClocksFreq(&g_clk_tested);
    g_clkout_hz  = ClockoutSourceFreq(&g_clk_tested, TEST_CLKOUT_MUX);

    /* Re-scale the delay module: the system clock has just changed, and the
     * oscilloscope window below is timed with it */
    delay_init(SystemCoreClock / 1000000U);
}

/**
 * @brief  Compute the frequency driven to PB4 for a clock output selection.
 * @param  clk: clock tree read back by HAL_SMU_GetClocksFreq().
 * @param  mux: SMU_CLKOUTMUX_xxx selection.
 * @retval uint32: frequency in Hz (0 if the selection is unknown).
 */
static uint32 ClockoutSourceFreq(const SMU_ClocksTypeDef *clk, uint32 mux)
{
    uint32 freq = 0U;

    switch (mux)
    {
        case SMU_CLKOUTMUX_CORECLK_DIV8:
            freq = clk->AXIBus0_Frequency / 8U;
            break;
        case SMU_CLKOUTMUX_AXIBUS1_DIV8:
            freq = clk->AXIBus1_Frequency / 8U;
            break;
        case SMU_CLKOUTMUX_AXIBUS3_DIV8:
            freq = clk->AXIBus3_Frequency / 8U;
            break;
        case SMU_CLKOUTMUX_APBBUS0_DIV8:
            freq = clk->APBBus0_Frequency / 8U;
            break;
        case SMU_CLKOUTMUX_APBBUS1_DIV8:
            freq = clk->APBBus1_Frequency / 8U;
            break;
        case SMU_CLKOUTMUX_FIRC_DIV8:
            freq = FIRC_VALUE / 8U;
            break;
        case SMU_CLKOUTMUX_OSC_DIV8:
            freq = OSC_VALUE / 8U;
            break;
        case SMU_CLKOUTMUX_SIRC:
            freq = TEST_SIRC_NOMINAL_HZ;
            break;
        default:
            freq = 0U;
            break;
    }

    return freq;
}

/**
 * @brief  Record one check (stage 1).
 * @param  name: check description.
 * @param  expect: expected value.
 * @param  actual: value read back.
 * @retval None
 */
static void CkAdd(const char *name, uint32 expect, uint32 actual)
{
    if (g_check_n < TEST_CHECK_MAX)
    {
        g_check[g_check_n].name   = name;
        g_check[g_check_n].expect = expect;
        g_check[g_check_n].actual = actual;
        g_check_n++;
    }
    else
    {
        g_setup_fail++;
    }
}

/**
 * @brief  Print one check and return the number of failures it contributes.
 * @param  ck: check to print.
 * @retval uint32: 0 when the check passed, 1 otherwise.
 */
static uint32 CkPrint(const SMU_CheckTypeDef *ck)
{
    uint32 fail = 0U;

    if (ck->expect == ck->actual)
    {
        printf("  [PASS] %s : expect 0x%08X, read 0x%08X\r\n",
               ck->name, PRINT_U32(ck->expect), PRINT_U32(ck->actual));
    }
    else
    {
        printf("  [FAIL] %s : expect 0x%08X, read 0x%08X\r\n",
               ck->name, PRINT_U32(ck->expect), PRINT_U32(ck->actual));
        fail = 1U;
    }

    return fail;
}

/**
 * @brief  Print the clock tree returned by HAL_SMU_GetClocksFreq().
 * @param  tag: label printed in front of the values.
 * @param  clk: clock tree to print.
 * @retval None
 */
static void PrintClocks(const char *tag, const SMU_ClocksTypeDef *clk)
{
    printf("  %s: AXIBus0 (core) = %u Hz\r\n", tag, PRINT_U32(clk->AXIBus0_Frequency));
    printf("  %s: AXIBus1        = %u Hz\r\n", tag, PRINT_U32(clk->AXIBus1_Frequency));
    printf("  %s: AXIBus3        = %u Hz\r\n", tag, PRINT_U32(clk->AXIBus3_Frequency));
    printf("  %s: APBBus0        = %u Hz\r\n", tag, PRINT_U32(clk->APBBus0_Frequency));
    printf("  %s: APBBus1        = %u Hz\r\n", tag, PRINT_U32(clk->APBBus1_Frequency));
    printf("  %s: CANCLKx2       = %u Hz\r\n", tag, PRINT_U32(clk->CANCLKx2_Frequency));
}

/*****END OF FILE*****/
