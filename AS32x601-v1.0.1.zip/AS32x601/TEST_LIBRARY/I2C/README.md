# I2C（IIC）应用与测试参考

供 skill 按用户需求定位 AS32x601 HAL I2C（IIC） 示例，共 12 个独立用例。

HAL 依据：[头文件](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_i2c.h)、[实现](../../HAL_LIBRARY/peripherals/src/as32x601_hal_i2c.c)。按所选案例核对当前驱动，不以接口索引代替实现依据。

## 实例与可选引脚

下表列出 AS32x601 LQFP144 封装的 I2C 引脚，可对照 [GPIO AF 定义](../../HAL_LIBRARY/peripherals/inc/as32x601_hal_gpio.h)。资料使用 FIIC、驱动使用 I2C、GPIO 宏使用 IIC。功能编号与 HAL 编码应分别核对，不能直接把文档中的“功能1”当作数值 1 传入。

| 实例 | 信号 | 可选引脚（封装脚号） | 功能编号 | HAL AF |
|---|---|---|---|---|
| I2C0 | SCL | PE7（136） | 功能1 | `GPIO_AF_IIC0_M1`（0x02） |
| I2C0 | SCL | PE3（124） | 功能3 | `GPIO_AF_IIC0_M3`（0x04） |
| I2C0 | SDA | PG1（138） | 功能1 | `GPIO_AF_IIC0_M1`（0x02） |
| I2C0 | SDA | PE2（123） | 功能3 | `GPIO_AF_IIC0_M3`（0x04） |
| I2C1 | SCL | PF15（142） | 功能1 | `GPIO_AF_IIC1`（0x02） |
| I2C1 | SDA | PF13（2） | 功能1 | `GPIO_AF_IIC1`（0x02） |
| I2C2 | SCL | PA14（34） | 功能3 | `GPIO_AF_IIC2`（0x04） |
| I2C2 | SDA | PA13（35） | 功能3 | `GPIO_AF_IIC2`（0x04） |
| I2C3 | SCL | PH5（71） | 功能1 | `GPIO_AF_IIC3`（0x02） |
| I2C3 | SDA | PH4（72） | 功能1 | `GPIO_AF_IIC3`（0x02） |

SCL、SDA 按信号分别列出，各自配置对应 AF；本表不规定必须成对选择。案例实际组合见下文，其他组合仍需核对芯片路由约束并验证。其他封装需另查引出情况。

PA13 默认复用 QSPI_DIO3；PE2/PE3 与 MAC、USART、比较器，PE7/PG1 与定时器等存在复用关系，实际冲突按当前工程和完整引脚表检查。

## 生成前需确认的参数

用户指定 IIC0 仅确定实例，不能据此确定接线。已有工程或板级资料已明确的参数直接复用；其余影响实现的选择通过参数卡确认并等待答复，先完成参数确认再提交生成方案。

| 参数 | 需要确认的情况 | 依据与处理 |
|---|---|---|
| 实例、SCL 与 SDA 引脚 | 实例未指定，或实际接线未知 | 分别确认两根信号的引脚及 AF，核对组合可用性；案例接线不作为板级默认值 |
| 主机 / 从机与对端器件 | 任务未说明通信角色、器件或协议 | 确认器件型号、寄存器读写时序及是否需要重复起始 |
| 地址 | 地址缺失，或不清楚是 7 位地址还是读写地址字节 | 当前 HAL 接收未移位的 7 位地址；用户已给出时直接复用 |
| 总线速率 | 对端、板级电气条件或用户要求尚未明确 | 按器件限制和实际外设时钟计算分频，案例 DIV 不能直接沿用 |
| 上拉与电平 | 外接接线、电压或上拉来源不明 | 确认公共地、上拉电源及器件与 MCU 的电平兼容性 |
| 测量换算参数 | 接入传感器且结果依赖外部电路 | 例如 INA226 电流校准需实际分流电阻及量程；不以案例常量代替 |

## 按需求选择

按目标行为选择，再核对完整源码；组合需求可阅读多个用例，不直接合并多个 main。

| 用户需求 / 检索关键词 | 推荐用例 | 选择条件 / 需要补充的逻辑 |
|---|---|---|
| IIC / I2C 主机阻塞发送；100 / 400 kHz | [001](I2C_IT_DRV_001.c) | I2C1；向 7 位地址 0x55 发送 64 字节，需从机 |
| IIC / I2C 主机阻塞接收；100 / 400 kHz | [002](I2C_IT_DRV_002.c) | I2C1；需从机提供数据 |
| I2C 从机发送；100 kHz | [003](I2C_IT_DRV_003.c) | 需外部主机发起读操作 |
| I2C 从机接收；100 kHz | [004](I2C_IT_DRV_004.c) | 需外部主机发起写操作 |
| I2C 主机中断发送；TXE | [005](I2C_IT_DRV_005.c) | 应用低层状态机和 PLIC 配置需一起参考 |
| I2C 主机中断接收；RXE | [006](I2C_IT_DRV_006.c) | 不是 DMA 接收模板，需保留 ACK 和结束条件 |
| I2C1 先读后写；100 kHz | [007](I2C_IT_DRV_007.c) | 两阶段传输，不能直接当作传感器寄存器读或 repeated-start 模板 |
| NACK / 不应答错误中断 | [008](I2C_IT_DRV_008.c) | 访问预期无人应答的 0x54；错误是此用例的目标条件 |
| I2C0 先读后写；400 kHz | [009](I2C_IT_DRV_009.c) | 地址 0x55，核对对应实例引脚与中断 |
| I2C2 先读后写；400 kHz | [010](I2C_IT_DRV_010.c) | 地址 0x55，核对对应实例引脚与中断 |
| I2C3 先读后写；400 kHz | [011](I2C_IT_DRV_011.c) | 地址 0x55，核对对应实例引脚与中断 |
| 默认值、初始化、参数、中断配置、低层 API 自检 | [012](I2C_IT_DRV_012.c) | 无对端自检；传输 API 主要检查拒绝非法参数，不能证明真实通信通过 |

## 案例实际配置

摘录各源码宏定义；总线速度、地址及对端协议仍需阅读完整用例。

| 用例 | 实例 | SCL | SDA |
|---|---|---|---|
| 001～008、012 | I2C1 | PF15 | PF13 |
| [009](I2C_IT_DRV_009.c) | I2C0 | PE3 | PE2 |
| [010](I2C_IT_DRV_010.c) | I2C2 | PA14 | PA13 |
| [011](I2C_IT_DRV_011.c) | I2C3 | PH5 | PH4 |

## 实现要点

IIC 与 I2C 在本文指同一总线，目录与 API 使用 I2C。001/002 是阻塞主机接口；003/004 是从机模式；005～011 是应用驱动低层总线时序和中断状态机，不要套用其他芯片 HAL 的中断 API 名称或缓冲区语义。

连接对应 SCL/SDA、公共地与适配电压的上拉，确认主从角色、7 位地址和目标器件协议。001/002 使用 0x55；008 特意访问 0x54 制造 NACK，该地址应无人应答。名义 100/400 kHz 的分频依赖当前时钟树，最终 SCL 用逻辑分析仪验证。

007/009～011 先读 64 字节，再关闭并重新启用控制器后写入 0x00～0x3F。这是两个阶段，不是通用“写寄存器地址后重复起始读取”的完整模板。EEPROM、传感器寄存器、DMA、总线恢复及多主仲裁应用需要另外设计。

低层 GenerateStart / GenerateStop / StartClear / Send7bitAddress / AcknowledgeConfig / SendData / ReceiveData 等接口按源码设计可在中断中使用；保留状态、NACK、停止和超时退出逻辑。001 的 summary 只统计配置检查，无从机时可能传输失败但 failures=0；应同时核对传输日志、实际 ACK、数据和 SCL 波形。012 无对端自检并不证明真实收发通过。

当前 SDK 的 `HAL_I2C_Master_Transmit()`、`HAL_I2C_Master_Receive()`、`HAL_I2C_Send7bitAddress()` 接收未移位的 7 位地址（0x00～0x7F），内部完成左移并加入方向位。目标 0x55 应传 0x55，不能传 0xAA；初始化从机地址也按 7 位填写。

005 等中断用例使用按循环次数计量的等待预算，不是精确毫秒超时；迁移时钟、优化等级或任务环境后应重新设计等待期限。

## 验证方法与适用边界

每个用例是独立测试程序。选定后核对实例、引脚或地址、时钟、配置、主循环、中断与回调，按目标板调整测试初值、日志和故障制造逻辑。综合接口自检只提供对应行为参考，不代表完整产品需求已覆盖。

本次为源码静态整理，未重新编译或上板；源码已有记录、预期结果与本次验证状态分别判断。

| 验证对象 | 检查方式 | 判断依据 |
|---|---|---|
| 初始化与参数 | 配置回读、状态与错误码 | 确认当前实例、引脚和分频已生效 |
| 实际通信 | 对端 ACK、收发数据与错误日志 | 不能仅用 summary 的 failures=0 判断成功 |
| 时序与电气 | 逻辑分析仪或示波器 | 检查 SCL 频率、起停条件、ACK 与上拉电平 |
| 异常恢复 | 无对端、NACK、超时后再次通信 | 失败可见，退出等待后能恢复后续传输 |

## 按接口与辅助宏检索

索引来自去除注释和字符串后的源码调用或定义，包含本模块 HAL、锁助手、寄存器及参数校验宏。MSP、IRQ、回调可能是定义或转发入口，需结合完整实现阅读；出现不代表所有分支都已验证。

| 接口 / 宏 | 参考用例 |
|---|---|
| `HAL_I2C_AcknowledgeConfig` | [005](I2C_IT_DRV_005.c)、[006](I2C_IT_DRV_006.c)、[007](I2C_IT_DRV_007.c)、[009](I2C_IT_DRV_009.c)、[010](I2C_IT_DRV_010.c)、[011](I2C_IT_DRV_011.c)、[012](I2C_IT_DRV_012.c) |
| `HAL_I2C_CheckStatus` | [005](I2C_IT_DRV_005.c)、[006](I2C_IT_DRV_006.c)、[007](I2C_IT_DRV_007.c)、[008](I2C_IT_DRV_008.c)、[009](I2C_IT_DRV_009.c)、[010](I2C_IT_DRV_010.c)、[011](I2C_IT_DRV_011.c)、[012](I2C_IT_DRV_012.c) |
| `HAL_I2C_ClearITPendingBit` | [005](I2C_IT_DRV_005.c)、[006](I2C_IT_DRV_006.c)、[007](I2C_IT_DRV_007.c)、[008](I2C_IT_DRV_008.c)、[009](I2C_IT_DRV_009.c)、[010](I2C_IT_DRV_010.c)、[011](I2C_IT_DRV_011.c)、[012](I2C_IT_DRV_012.c) |
| `HAL_I2C_Cmd` | [007](I2C_IT_DRV_007.c)、[009](I2C_IT_DRV_009.c)、[010](I2C_IT_DRV_010.c)、[011](I2C_IT_DRV_011.c)、[012](I2C_IT_DRV_012.c) |
| `HAL_I2C_DeInit` | [001](I2C_IT_DRV_001.c)、[002](I2C_IT_DRV_002.c)、[003](I2C_IT_DRV_003.c)、[004](I2C_IT_DRV_004.c)、[012](I2C_IT_DRV_012.c) |
| `HAL_I2C_GenerateStart` | [005](I2C_IT_DRV_005.c)、[006](I2C_IT_DRV_006.c)、[007](I2C_IT_DRV_007.c)、[008](I2C_IT_DRV_008.c)、[009](I2C_IT_DRV_009.c)、[010](I2C_IT_DRV_010.c)、[011](I2C_IT_DRV_011.c)、[012](I2C_IT_DRV_012.c) |
| `HAL_I2C_GenerateStop` | [005](I2C_IT_DRV_005.c)、[006](I2C_IT_DRV_006.c)、[007](I2C_IT_DRV_007.c)、[008](I2C_IT_DRV_008.c)、[009](I2C_IT_DRV_009.c)、[010](I2C_IT_DRV_010.c)、[011](I2C_IT_DRV_011.c)、[012](I2C_IT_DRV_012.c) |
| `HAL_I2C_GetError` | [001](I2C_IT_DRV_001.c)、[002](I2C_IT_DRV_002.c)、[003](I2C_IT_DRV_003.c)、[004](I2C_IT_DRV_004.c)、[005](I2C_IT_DRV_005.c)、[006](I2C_IT_DRV_006.c)、[007](I2C_IT_DRV_007.c)、[009](I2C_IT_DRV_009.c)、[010](I2C_IT_DRV_010.c)、[011](I2C_IT_DRV_011.c)、[012](I2C_IT_DRV_012.c) |
| `HAL_I2C_GetFlagStatus` | [012](I2C_IT_DRV_012.c) |
| `HAL_I2C_GetITStatus` | [012](I2C_IT_DRV_012.c) |
| `HAL_I2C_GetState` | [001](I2C_IT_DRV_001.c)、[002](I2C_IT_DRV_002.c)、[003](I2C_IT_DRV_003.c)、[004](I2C_IT_DRV_004.c)、[005](I2C_IT_DRV_005.c)、[006](I2C_IT_DRV_006.c)、[007](I2C_IT_DRV_007.c)、[008](I2C_IT_DRV_008.c)、[009](I2C_IT_DRV_009.c)、[010](I2C_IT_DRV_010.c)、[011](I2C_IT_DRV_011.c)、[012](I2C_IT_DRV_012.c) |
| `HAL_I2C_ITInit` | [005](I2C_IT_DRV_005.c)、[006](I2C_IT_DRV_006.c)、[007](I2C_IT_DRV_007.c)、[008](I2C_IT_DRV_008.c)、[009](I2C_IT_DRV_009.c)、[010](I2C_IT_DRV_010.c)、[011](I2C_IT_DRV_011.c)、[012](I2C_IT_DRV_012.c) |
| `HAL_I2C_ITStructInit` | [005](I2C_IT_DRV_005.c)、[006](I2C_IT_DRV_006.c)、[007](I2C_IT_DRV_007.c)、[008](I2C_IT_DRV_008.c)、[009](I2C_IT_DRV_009.c)、[010](I2C_IT_DRV_010.c)、[011](I2C_IT_DRV_011.c)、[012](I2C_IT_DRV_012.c) |
| `HAL_I2C_Init` | [001](I2C_IT_DRV_001.c)、[002](I2C_IT_DRV_002.c)、[003](I2C_IT_DRV_003.c)、[004](I2C_IT_DRV_004.c)、[005](I2C_IT_DRV_005.c)、[006](I2C_IT_DRV_006.c)、[007](I2C_IT_DRV_007.c)、[008](I2C_IT_DRV_008.c)、[009](I2C_IT_DRV_009.c)、[010](I2C_IT_DRV_010.c)、[011](I2C_IT_DRV_011.c)、[012](I2C_IT_DRV_012.c) |
| `HAL_I2C_Master_Receive` | [002](I2C_IT_DRV_002.c)、[012](I2C_IT_DRV_012.c) |
| `HAL_I2C_Master_Transmit` | [001](I2C_IT_DRV_001.c)、[012](I2C_IT_DRV_012.c) |
| `HAL_I2C_MspDeInit` | [001](I2C_IT_DRV_001.c)、[002](I2C_IT_DRV_002.c)、[003](I2C_IT_DRV_003.c)、[004](I2C_IT_DRV_004.c)、[005](I2C_IT_DRV_005.c)、[006](I2C_IT_DRV_006.c)、[007](I2C_IT_DRV_007.c)、[008](I2C_IT_DRV_008.c)、[009](I2C_IT_DRV_009.c)、[010](I2C_IT_DRV_010.c)、[011](I2C_IT_DRV_011.c)、[012](I2C_IT_DRV_012.c) |
| `HAL_I2C_MspInit` | [001](I2C_IT_DRV_001.c)、[002](I2C_IT_DRV_002.c)、[003](I2C_IT_DRV_003.c)、[004](I2C_IT_DRV_004.c)、[005](I2C_IT_DRV_005.c)、[006](I2C_IT_DRV_006.c)、[007](I2C_IT_DRV_007.c)、[008](I2C_IT_DRV_008.c)、[009](I2C_IT_DRV_009.c)、[010](I2C_IT_DRV_010.c)、[011](I2C_IT_DRV_011.c)、[012](I2C_IT_DRV_012.c) |
| `HAL_I2C_ReceiveData` | [005](I2C_IT_DRV_005.c)、[006](I2C_IT_DRV_006.c)、[007](I2C_IT_DRV_007.c)、[009](I2C_IT_DRV_009.c)、[010](I2C_IT_DRV_010.c)、[011](I2C_IT_DRV_011.c)、[012](I2C_IT_DRV_012.c) |
| `HAL_I2C_Send7bitAddress` | [005](I2C_IT_DRV_005.c)、[006](I2C_IT_DRV_006.c)、[007](I2C_IT_DRV_007.c)、[008](I2C_IT_DRV_008.c)、[009](I2C_IT_DRV_009.c)、[010](I2C_IT_DRV_010.c)、[011](I2C_IT_DRV_011.c)、[012](I2C_IT_DRV_012.c) |
| `HAL_I2C_SendData` | [005](I2C_IT_DRV_005.c)、[006](I2C_IT_DRV_006.c)、[007](I2C_IT_DRV_007.c)、[009](I2C_IT_DRV_009.c)、[010](I2C_IT_DRV_010.c)、[011](I2C_IT_DRV_011.c)、[012](I2C_IT_DRV_012.c) |
| `HAL_I2C_Slave_Receive` | [004](I2C_IT_DRV_004.c)、[012](I2C_IT_DRV_012.c) |
| `HAL_I2C_Slave_Transmit` | [003](I2C_IT_DRV_003.c)、[012](I2C_IT_DRV_012.c) |
| `HAL_I2C_StartClear` | [005](I2C_IT_DRV_005.c)、[006](I2C_IT_DRV_006.c)、[007](I2C_IT_DRV_007.c)、[008](I2C_IT_DRV_008.c)、[009](I2C_IT_DRV_009.c)、[010](I2C_IT_DRV_010.c)、[011](I2C_IT_DRV_011.c)、[012](I2C_IT_DRV_012.c) |
| `HAL_I2C_StructInit` | [012](I2C_IT_DRV_012.c) |
| `I2C_CheckState` | [012](I2C_IT_DRV_012.c) |
| `I2C_LockHandle` | [012](I2C_IT_DRV_012.c) |
| `I2C_UnlockHandle` | [012](I2C_IT_DRV_012.c) |

