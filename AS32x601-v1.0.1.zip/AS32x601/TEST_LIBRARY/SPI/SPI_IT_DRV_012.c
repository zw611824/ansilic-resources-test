/**
 * @file    SPI_IT_DRV_012.c
 * @brief   HAL SPI integration test case 012 (master / slave full duplex).
 *
 * HAL library port of the original AS32x601 standard-library test case
 * SPI_IT_DRV_012.c, which drives SPI3 and lets the operator choose between
 * master and slave mode on the console, then exchanges 64 frames. Only HAL
 * library APIs are used.
 *
 * Tested functionality:
 *   HAL_SPI_StructInit()
 *   HAL_SPI_Init()
 *   HAL_SPI_ResetFIFO()
 *   HAL_SPI_NSSConfig()         (asserts SPI_Slave0 around every transfer)
 *   HAL_SPI_TransmitReceive()   (blocking, master and slave, 64 frames)
 *   HAL_SPI_GetState() / HAL_SPI_GetError()
 *   HAL_SPI_MspInit()           (overridden: clock gate, reset pulse, pins)
 *
 * Test procedure:
 *   For both modes of the table (master, slave):
 *     1. initialize SPI3 with that mode (8 bit, Motorola mode 0, normal
 *        transmission, divider /2 for the slave as in the reference case);
 *     2. exchange 64 frames in full duplex;
 *     3. check the transfer status, the handle state and the error code, and
 *        print the first received bytes for observation.
 *
 * Expected behaviour:
 *   - in master mode the transfer completes with HAL_OK (the master generates
 *     the clock itself) and the handle returns to READY with the error code
 *     NONE;
 *   - in slave mode the transfer completes with HAL_OK only when an external
 *     master clocks the frames; without one it ends in HAL_TIMEOUT and the
 *     handle reports the TIMEOUT state, which the case reports instead of
 *     hanging;
 *   - every check prints [PASS] and "summary : failures = 0" when the required
 *     peer is present.
 *
 * Note:
 *   - External stimulus is required for the slave half of the case: an SPI
 *     master must clock the 64 frames.
 *   - The reference test case printed "please enter 0-1" (correct) but its
 *     comment spoke of 0..3, and it forced the slave select to SPI_Slave0 even
 *     though it had a variable for it; the sweep replaces the console input and
 *     the selection is taken from the configuration of each pass.
 *   - The reference case did not compare the received data either; the bytes
 *     are printed here, the data comparison belongs to the peer.
 */

/* Includes ----------------------------------------------------------------*/
#include "as32x601_hal.h"
#include "as32x601_delay.h"
#include "as32x601_print.h"

/* Private define ------------------------------------------------------------*/
/* Console: USART0 on GPIOD pin 8 (TX) / pin 9 (RX), 115200 8N1 */
#define TEST_BAUDRATE                   (115200U)

/* Device under test: SPI3 (as in the reference test case)
 *   CS0  = PC10   SCK  = PD3   MOSI = PD1   MISO = PD2
 */
#define TEST_SPI                        SPI3
#define TEST_CS_PORT                    GPIOC
#define TEST_CS_PIN                     GPIO_PIN_10
#define TEST_CS_SOURCE                  GPIO_PinSource10
#define TEST_SCK_PORT                   GPIOD
#define TEST_SCK_PIN                    GPIO_PIN_3
#define TEST_SCK_SOURCE                 GPIO_PinSource3
#define TEST_MOSI_PORT                  GPIOD
#define TEST_MOSI_PIN                   GPIO_PIN_1
#define TEST_MOSI_SOURCE                GPIO_PinSource1
#define TEST_MISO_PORT                  GPIOD
#define TEST_MISO_PIN                   GPIO_PIN_2
#define TEST_MISO_SOURCE                GPIO_PinSource2
#define TEST_PIN_AF                     GPIO_AF_SPI3

/* Frame geometry, timeouts and the mode table */
#define FRAME_COUNT                     (64U)
#define TRANSFER_TIMEOUT_MS             (2000U)
#define MODE_COUNT                      (2U)
#define RETRY_PERIOD_MS                 (1000U)

/* Private variables ---------------------------------------------------------*/
static SPI_HandleTypeDef hspi_dev;              /*!< device under test      */
static HAL_SMU_HandleTypeDef hsmu_clk;          /*!< SMU handle (clock tree) */
static uint8 tx_data[FRAME_COUNT];              /*!< transmit pattern        */
static uint8 rx_data[FRAME_COUNT];              /*!< received frames         */
static volatile uint32 check_failures = 0U;     /*!< failed check counter    */

/* Mode register value, its name and the divider used with it */
static const uint32 mode_reg[MODE_COUNT]  = { SPI_Mode_Master, SPI_Mode_Slave };
static const char * const mode_name[MODE_COUNT] = { "master mode", "slave mode" };
static const uint32 mode_div[MODE_COUNT]  = { SPI_CLKDiv512, SPI_CLKDiv2 };

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Init(void);
static void BufferInit(void);
static void Check(const char *name, uint32 condition);
static void Summary(void);

/**
 * @brief  Main program.
 * @param  None
 * @retval None
 */
int main(void)
{
    SPI_InitTypeDef spi_init;
    HAL_StatusTypeDef status;
    uint32 index;
    uint32 mode_index;
    uint32 cr0_mstr;

    /* Initialize the HAL library (mcycle based 1 ms time base) */
    HAL_Init();

    /* Configure the system clock tree */
    SystemClock_Init();

    /* Initialize the delay module: fac_us = core clock in MHz */
    delay_init(SystemCoreClock / 1000000U);

    /* Initialize the console USART (USART0 on GPIOD pin 8 / pin 9) */
    User_Print_Init(TEST_BAUDRATE);
    printf("\r\n=== SPI_IT_DRV_012 : master / slave full duplex (SPI3) ===\r\n");

    BufferInit();
    __HAL_CLEAR_STRUCT(&hspi_dev);

    for (mode_index = 0U; mode_index < MODE_COUNT; mode_index++)
    {
        printf("\r\n-- %s (divider %s) --\r\n", mode_name[mode_index],
               ((mode_index == 0U) ? "/512" : "/2"));

        /* Step 1: initialize the device under test with the mode of this pass */
        HAL_SPI_StructInit(&spi_init);
        spi_init.SPI_CLKDiv       = mode_div[mode_index];
        spi_init.SPI_Mode         = mode_reg[mode_index];
        spi_init.SPI_FrameSize    = SPI_FrameSize_8b;
        spi_init.SPI_MotorolaMode = SPI_Motorola_Mode0;
        spi_init.SPI_TransMode    = SPI_TransNor;

        hspi_dev.Instance = TEST_SPI;
        hspi_dev.Init     = spi_init;

        status = HAL_SPI_Init(&hspi_dev);
        /* The slave select is not part of the initialization: SSR
         * resets to 0 (no slave selected) and HAL_SPI_Init() does not
         * touch it, so the selection has to be programmed here. */
        if (mode_reg[mode_index] == SPI_Mode_Master)
        {
            HAL_SPI_ResetFIFO(&hspi_dev, SPI_RESETFIFO_TXANDRX);
            HAL_SPI_NSSConfig(&hspi_dev, SPI_Slave0, SPI_ENABLE);
        }
        Check("HAL_SPI_Init returns HAL_OK", (uint32)((status == HAL_OK) ? 1U : 0U));
        Check("state after init is READY",
              (uint32)((HAL_SPI_GetState(&hspi_dev) == HAL_SPI_STATE_READY) ? 1U : 0U));

        /* The master bit of CR0 must follow the requested mode */
        cr0_mstr = (uint32)TEST_SPI->CR0 & SPI_CR0_MSTR;
        printf("CR0          : 0x%08X (MSTR %u) %s\r\n",
               PRINT_U32((uint32)TEST_SPI->CR0),
               PRINT_U32(cr0_mstr),
               ((((mode_reg[mode_index] & SPI_Mode_Master) != 0U) ==
                 (cr0_mstr != 0U)) ? "[PASS]" : "[FAIL]"));
        if (((mode_reg[mode_index] & SPI_Mode_Master) != 0U) != (cr0_mstr != 0U))
        {
            check_failures++;
        }

        for (index = 0U; index < FRAME_COUNT; index++)
        {
            rx_data[index] = 0x00U;
        }

        /* Step 2: full duplex exchange */
        status = HAL_SPI_TransmitReceive(&hspi_dev, tx_data, rx_data,
                                         FRAME_COUNT, TRANSFER_TIMEOUT_MS);
        Check("HAL_SPI_TransmitReceive returns HAL_OK",
              (uint32)((status == HAL_OK) ? 1U : 0U));
        if (status != HAL_OK)
        {
            printf("transfer status : %u (4 = HAL_TIMEOUT)\r\n",
                   PRINT_U32((uint32)status));
            printf("state           : %u (7 = TIMEOUT)\r\n",
                   PRINT_U32((uint32)HAL_SPI_GetState(&hspi_dev)));
            printf("error code      : 0x%08X\r\n",
                   PRINT_U32(HAL_SPI_GetError(&hspi_dev)));
        }

        /* Step 3: state and error code after the exchange */
        Check("error code is NONE (or FLAG after a missing peer)",
              (uint32)(((HAL_SPI_GetError(&hspi_dev) == HAL_SPI_ERROR_NONE) ||
                        (HAL_SPI_GetError(&hspi_dev) == HAL_SPI_ERROR_FLAG)) ?
                       1U : 0U));

        printf("rx[0..7]     : ");
        for (index = 0U; index < 8U; index++)
        {
            printf("0x%02X ", PRINT_U32(rx_data[index]));
        }
        printf("...\r\n");

        if ((mode_index == 1U) && (status != HAL_OK))
        {
            printf("note         : a slave needs an external master to clock the\n");
            printf("               64 frames; without it the case reports TIMEOUT\n");
        }

        delay_ms(RETRY_PERIOD_MS);
    }

    /* Release the slave select, so the lines are not left asserted */
    HAL_SPI_NSSConfig(&hspi_dev, SPI_Slave0, SPI_DISABLE);

    Summary();

    while (1)
    {
        delay_ms(1000U);
    }
}

/**
 * @brief  Fill the transmit buffer with 0x00 .. 0x3F.
 * @param  None
 * @retval None
 */
static void BufferInit(void)
{
    uint32 index;

    for (index = 0U; index < FRAME_COUNT; index++)
    {
        tx_data[index] = (uint8)index;
        rx_data[index] = 0x00U;
    }
}

/**
 * @brief  Report the result of one check.
 * @param  name: short description of the check.
 * @param  condition: 0 = FAIL, non zero = PASS.
 * @retval None
 */
static void Check(const char *name, uint32 condition)
{
    if (condition != 0U)
    {
        printf("%-46s : [PASS]\r\n", name);
    }
    else
    {
        check_failures++;
        printf("%-46s : [FAIL]\r\n", name);
    }
}

/**
 * @brief  Print the accumulated failure counter.
 * @param  None
 * @retval None
 */
static void Summary(void)
{
    printf("\r\nsummary : failures = %u\r\n", PRINT_U32(check_failures));
}

/**
 * @brief  MSP initialization of the device under test.
 * @note   Strong override of the weak driver callback. The data output line
 *         (MISO) is open drain, which works both as a master input and as a
 *         slave output.
 * @param  hspi: SPI handle of the device under test.
 * @retval None
 */
void HAL_SPI_MspInit(SPI_HandleTypeDef *hspi)
{
    GPIO_InitTypeDef gpio;

    if (hspi->Instance != TEST_SPI)
    {
        return;
    }

    /* Peripheral clock gate and reset pulse */
    __HAL_SMU_SPI3_CLK_ENABLE();
    __HAL_SMU_SPI3_FORCE_RESET();
    __HAL_SMU_SPI3_RELEASE_RESET();

    /* Port clock gates used by this case */
    __HAL_SMU_GPIOC_CLK_ENABLE();
    __HAL_SMU_GPIOD_CLK_ENABLE();

    __HAL_CLEAR_STRUCT(&gpio);
    gpio.Size         = sizeof(gpio);
    gpio.Version      = GPIO_INIT_VERSION;
    gpio.Pull         = GPIO_NOPULL;
    gpio.DriveCurrent = GPIO_DRIVE_CURRENT_MEDIUM;
    gpio.Alternate    = TEST_PIN_AF;

    /* CS0: driven by the SSR register in master mode, driven by the external
     * master in slave mode; mapped to the SPI function either way */
    HAL_GPIO_PinAFConfig(TEST_CS_PORT, TEST_CS_SOURCE, TEST_PIN_AF);
    gpio.Pin  = TEST_CS_PIN;
    gpio.Mode = GPIO_MODE_AF_PP;
    HAL_GPIO_Init(TEST_CS_PORT, &gpio);

    /* SCK and MOSI: outputs in master mode, inputs in slave mode. Both are
     * mapped to the alternate function, so the direction follows the mode. */
    HAL_GPIO_PinAFConfig(TEST_SCK_PORT, TEST_SCK_SOURCE, TEST_PIN_AF);
    gpio.Pin = TEST_SCK_PIN;
    HAL_GPIO_Init(TEST_SCK_PORT, &gpio);

    HAL_GPIO_PinAFConfig(TEST_MOSI_PORT, TEST_MOSI_SOURCE, TEST_PIN_AF);
    gpio.Pin = TEST_MOSI_PIN;
    HAL_GPIO_Init(TEST_MOSI_PORT, &gpio);

    /* MISO: alternate function, open drain */
    HAL_GPIO_PinAFConfig(TEST_MISO_PORT, TEST_MISO_SOURCE, TEST_PIN_AF);
    gpio.Pin  = TEST_MISO_PIN;
    gpio.Mode = GPIO_MODE_AF_OD;
    HAL_GPIO_Init(TEST_MISO_PORT, &gpio);
}

/**
 * @brief  Configure the system clock tree through the HAL SMU driver.
 * @note   Same clock tree as the CLINT / CMU / MPU / USART integration tests.
 * @param  None
 * @retval None
 */
static void SystemClock_Init(void)
{
    SMU_OscInitTypeDef   SMU_OscInitStruct;
    SMU_ClockInitTypeDef SMU_ClockInitStruct;
    SMU_ClocksTypeDef    SMU_ClocksStruct;
    HAL_PMU_HandleTypeDef hpmu;

    /* Bus clock gates (the same set the reference test case opens) */
    __HAL_SMU_AXIBUS3_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB0_CLK_ENABLE();
    __HAL_SMU_APBBUS0_CLK_ENABLE();
    __HAL_SMU_AXI4TOAPB1_CLK_ENABLE();
    __HAL_SMU_APBBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS1_CLK_ENABLE();
    __HAL_SMU_AXILITEBUS2_CLK_ENABLE();
    __HAL_SMU_EFLASH_CLK_ENABLE();
    __HAL_SMU_PLIC_CLK_ENABLE();

    /* Initialize the PMU before the voltage scaling calls (PMU_CheckState) */
    __HAL_CLEAR_STRUCT(&hpmu);
    hpmu.Instance = PMU;
    (void)HAL_PMU_Init(&hpmu);
    HAL_PMU_LDO2v5VOLSca(&hpmu, PMU_VO25_2V78);
    HAL_PMU_LDO1v2VOLSca(&hpmu, PMU_VO12_1V34);

    /* Initialize the SMU handle (bare metal test: no RTOS mutex) */
    __HAL_CLEAR_STRUCT(&hsmu_clk);
    hsmu_clk.Instance = SMU;
    (void)HAL_SMU_Init(&hsmu_clk);

    /* Oscillator / PLL parameters (VCO 180 MHz) */
    SMU_OscInitStruct.OscillatorType       = SMU_OSCILLATORTYPE_OSC;
    SMU_OscInitStruct.FIRCState            = SMU_FIRC_ON;
    SMU_OscInitStruct.FIRCCalibrationValue = 0x00U;
    SMU_OscInitStruct.PLL.PLLState         = SMU_PLL_ON;
    SMU_OscInitStruct.PLL.PLLSource        = SMU_PLLSOURCE_OSC;
    SMU_OscInitStruct.PLL.PLLDivR          = 0x04U;
    SMU_OscInitStruct.PLL.PLLDivQ          = 0x01U;
    SMU_OscInitStruct.PLL.PLLDivN          = 0x14U;
    SMU_OscInitStruct.PLL.PLLDivF          = 0xB4U;
    SMU_OscInitStruct.SYSCLKSelect         = SMU_SYSCLKSOURCE_PLL;

    SMU_ClockInitStruct.AXI4Bus3CLKDiv = SMU_AXI4BUS3CLK_DIV2;
    SMU_ClockInitStruct.APBBus0CLKDiv  = SMU_APBBUS0CLK_DIV2;
    SMU_ClockInitStruct.APBBus1CLKDiv  = SMU_APBBUS1CLK_DIV2;
    SMU_ClockInitStruct.CANX2CLKDiv    = SMU_CANX2CLK_DIV8;

    (void)HAL_SMU_ClockConfig(&hsmu_clk, &SMU_ClockInitStruct);
    (void)HAL_SMU_OscConfig(&hsmu_clk, &SMU_OscInitStruct, SMU_TIMEOUT_DEFAULT);

    (void)HAL_SMU_GetClocksFreq(&SMU_ClocksStruct);
}

/*****END OF FILE*****/
