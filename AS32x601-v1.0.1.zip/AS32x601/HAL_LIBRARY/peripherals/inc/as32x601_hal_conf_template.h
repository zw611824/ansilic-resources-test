/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_conf_template.h
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.6
 * Date:   2026/10/12
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/11     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.1     split the file into a
 *                                                       common macro section
 *                                                       (safe to be included
 *                                                       by the assembly
 *                                                       startup / trapentry
 *                                                       files) and a C-only
 *                                                       section; derive the
 *                                                       dedicated interrupt
 *                                                       stack size
 *                                                       (HAL_INTERRUPT_STACK_
 *                                                       SIZE) from USE_RTOS
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.2     drop the "U" suffix on
 *                                                       HAL_INTERRUPT_STACK_
 *                                                       SIZE for maximum
 *                                                       assembly-directive
 *                                                       compatibility (.space /
 *                                                       DS8)
 *     ANSILIC APPLICATION GROUP  2026/09/07     1.3     enable the module
 *                                                       switches of every
 *                                                       driver that had been
 *                                                       added to the library
 *                                                       up to that date (PLIC,
 *                                                       CLINT, GPIO, CMU, SMU,
 *                                                       PMU, TIM, DMA, RTC,
 *                                                       IWDG, WWDG, ADC, DAC,
 *                                                       USART, SPI, I2C, CANFD,
 *                                                       QSPI, MAC, FLASH, FCU,
 *                                                       CRC, MPU, PKA, SPACC)
 *                                                       and include their HAL
 *                                                       headers
 *     ANSILIC APPLICATION GROUP  2026/09/20     1.4     enable the TRNG module switch as
 *                                                       well, so that the enabled set
 *                                                       covers every module implemented in
 *                                                       the library; declare the type source
 *                                                       of the assert_failed prototype in the
 *                                                       C-only section - the core layer
 *                                                       header, where uint8 / uint32 are
 *                                                       defined - so that the prototype stays
 *                                                       valid with every module switch
 *                                                       disabled and in a C++ translation
 *                                                       unit as well (HAL-REQ-022); add the
 *                                                       HAL_TICK_FREQ_HZ system parameter;
 *                                                       align the version number with the
 *                                                       rest of the common layer
 *     ANSILIC APPLICATION GROUP  2026/10/08     1.5     guard HAL_TICK_FREQ_HZ with a presence
 *                                                       check so that a build option can override
 *                                                       it, and add the zero check to the assembly
 *                                                       safe section so that the startup and trap
 *                                                       entry units report a missing or zero
 *                                                       frequency at assembly time
 *     ANSILIC APPLICATION GROUP  2026/10/12     1.6     add the GPIO configuration section with
 *                                                       HAL_GPIO_DEINIT_PROTECT_DEFAULT_FUNC, which keeps
 *                                                       HAL_GPIO_DeInit() from resetting the pins whose reset default
 *                                                       function is multiplexed (QSPI / JTAG / BOOT / FlexBus)
 * Description:     This file is the HAL configuration template file for the
 *                  AS32x601 HAL library. It shall be copied to the
 *                  application folder and renamed to "as32x601_hal_conf.h",
 *                  then the module switches and system parameters can be
 *                  tuned to fit the application requirements.
 *
 *                  The file is split into two sections:
 *                    - "common macro section": pure preprocessor macros that
 *                      are safe to be included by the assembly files
 *                      (as32x601_startup_*.S / as32x601_trapentry_*.S), which
 *                      auto-include "as32x601_hal_conf.h" through
 *                      __has_include when the file is found on the include
 *                      path.  In particular HAL_INTERRUPT_STACK_SIZE (the
 *                      dedicated interrupt stack size) is derived from
 *                      USE_RTOS, so a dedicated interrupt stack is enabled
 *                      automatically for RTOS applications.
 *                    - "C-only section": guarded by "#ifndef __ASSEMBLER__",
 *                      skipped during assembly preprocessing (C headers,
 *                      module header includes, assert selection).
 */
#ifndef __AS32X601_HAL_CONF_H
#define __AS32X601_HAL_CONF_H

#ifdef __cplusplus
extern "C" {
#endif

/******************************************************************************
 *  COMMON MACRO SECTION (assembly-safe pure macros)
 *****************************************************************************/

/******************************************************************************
 *  MODULE SELECTION
 *****************************************************************************/
/**
 * @brief Master switch of the HAL library.
 * @note  This definition is checked by the HAL master header to verify that
 *        the configuration file has been included before it.
 */
#define HAL_MODULE_ENABLED

/**
 * @brief Module switches. Comment out a switch to exclude the corresponding
 *        module from the compilation (reduces the code size).
 * @note  These macros are evaluated with "#ifdef HAL_xxx_MODULE_ENABLED"
 *        in the HAL master header.
 * @note  The switches enabled below are exactly the modules that are
 *        implemented in this HAL library (a driver source file plus its
 *        header exist under peripherals/src + peripherals/inc). Every
 *        enabled switch has its module header included in the C-only
 *        section further down, therefore the default configuration
 *        compiles. A module may still be commented out to trim the code
 *        size; a switch of a module that is NOT implemented shall stay
 *        commented, otherwise the include below fails at compile time
 *        (HAL-REQ-019).
 */

/* RISC-V core related modules */
#define HAL_PLIC_MODULE_ENABLED
#define HAL_CLINT_MODULE_ENABLED

/* System modules */
#define HAL_GPIO_MODULE_ENABLED
#define HAL_CMU_MODULE_ENABLED
#define HAL_SMU_MODULE_ENABLED
#define HAL_PMU_MODULE_ENABLED

/* Timer & DMA modules */
#define HAL_TIM_MODULE_ENABLED
#define HAL_DMA_MODULE_ENABLED
#define HAL_RTC_MODULE_ENABLED
#define HAL_IWDG_MODULE_ENABLED
#define HAL_WWDG_MODULE_ENABLED

/* Analog modules */
#define HAL_ADC_MODULE_ENABLED
#define HAL_DAC_MODULE_ENABLED

/* Communication modules */
#define HAL_USART_MODULE_ENABLED
#define HAL_SPI_MODULE_ENABLED
#define HAL_I2C_MODULE_ENABLED
#define HAL_CANFD_MODULE_ENABLED
#define HAL_QSPI_MODULE_ENABLED
#define HAL_MAC_MODULE_ENABLED

/* Storage modules */
#define HAL_FLASH_MODULE_ENABLED
#define HAL_FCU_MODULE_ENABLED

/* Security modules */
#define HAL_TRNG_MODULE_ENABLED
#define HAL_CRC_MODULE_ENABLED
#define HAL_MPU_MODULE_ENABLED
#define HAL_PKA_MODULE_ENABLED
#define HAL_SPACC_MODULE_ENABLED

/******************************************************************************
 *  SYSTEM CONFIGURATION
 *****************************************************************************/
/**
 * @brief System configuration: RTOS or bare-metal.
 * @note  0 = bare-metal application (default).  1 = RTOS application.
 *        In RTOS mode the HAL lock primitives use an RTOS-aware mutex
 *        (see as32x601_hal_def.h) and the trap entry uses a dedicated
 *        interrupt stack (see HAL_INTERRUPT_STACK_SIZE below).
 */
#define USE_RTOS                     0U

/**
 * @brief Dedicated interrupt stack size, in bytes.
 * @note  Derived from USE_RTOS: 0 (no dedicated stack) for bare-metal,
 *        a default of 2048 bytes for RTOS.  The value is consumed by the
 *        startup / trapentry assembly files (they auto-include this file),
 *        which define the stack region and perform the mscratch stack swap.
 *        It can be overridden by a build option -DHAL_INTERRUPT_STACK_SIZE=xxx
 *        or by editing the value here.
 * @warning The value here and any -D override MUST be identical for the
 *          startup and the trapentry files (they are compiled separately).
 * @note  The value is written WITHOUT a "U" suffix so that it is accepted
 *        by every assembly directive that consumes it (.space / DS8), both
 *        for the GCC and the IAR assemblers.
 */
#if (USE_RTOS == 1U)
    #if !defined(HAL_INTERRUPT_STACK_SIZE)
        #define HAL_INTERRUPT_STACK_SIZE    2048    /*!< ISR stack size in bytes (RTOS) */
    #endif /* HAL_INTERRUPT_STACK_SIZE */
#else
    #define HAL_INTERRUPT_STACK_SIZE    0         /*!< No dedicated ISR stack (bare-metal) */
#endif /* (USE_RTOS == 1U) */

/**
 * @brief This is the HAL system configuration section.
 */
#define VDD_VALUE                    3300U    /*!< Value of VDD in mV */

/**
 * @brief Frequency of the HAL time base, in Hz.
 * @note  The default value gives the 1 ms time base that HAL_InitTick()
 *        builds from the CPU mcycle counter. HAL_InitTick() and
 *        HAL_GetTickFreq() share this single value, so the frequency
 *        reported to the application always matches the frequency the time
 *        base is actually built with. An application that builds its own
 *        time base with another frequency shall update this parameter
 *        together with its HAL_InitTick() implementation.
 * @note  SystemCoreClock shall be an integer multiple of this value and at
 *        least equal to it, otherwise HAL_InitTick() returns HAL_ERROR.
 * @note  The value is guarded so that a build option -DHAL_TICK_FREQ_HZ=xxx
 *        can override it without a redefinition; the master header keeps its
 *        own fallback for a configuration file that predates the parameter.
 * @note  The zero check below lives in the assembly safe section on purpose:
 *        the startup and trap entry units include this file directly, so a
 *        missing or zero frequency is reported by the assembler as well, at
 *        the earliest possible point.
 */
#ifndef HAL_TICK_FREQ_HZ
    #define HAL_TICK_FREQ_HZ         1000U     /*!< Time base frequency in Hz (1 ms tick) */
#endif /* HAL_TICK_FREQ_HZ */

#if (HAL_TICK_FREQ_HZ < 1U)
    #error "as32x601_hal_conf.h: HAL_TICK_FREQ_HZ must be greater than zero (the time base needs a positive frequency)."
#endif /* HAL_TICK_FREQ_HZ < 1U */

/******************************************************************************
 *  GPIO CONFIGURATION
 *****************************************************************************/
/**
 * @brief Protection of the pins whose reset default function is multiplexed.
 * @note  When enabled (default), HAL_GPIO_DeInit() leaves the pins whose
 *        reset default function is a multiplexed function untouched: those
 *        pins come out of reset already driving a specific interface, so
 *        resetting them to the plain GPIO default would drop that function.
 *        The protected pins of each port are listed in the extension header
 *        (GPIOx_PIN_DEFAULT_FUNC):
 *          GPIOA Pin8..Pin13   QSPI    (CSN / SCK / DIO0 .. DIO3)
 *          GPIOB Pin5..Pin9    JTAG    (RSTN / TDO / TCK / TDI / TMS)
 *          GPIOC Pin13..Pin15  FlexBus (TCK / RST / TMSC0)
 *          GPIOF Pin0..Pin9    FlexBus (TMSC1 .. TMSC4 / FR0 .. FR4 / MS)
 *          GPIOH Pin0..Pin1    BOOT0 / BOOT1
 * @note  Set it to 0 only when the application does not use those interfaces
 *        and wants HAL_GPIO_DeInit() to reset those pins like any other pin.
 *        HAL_GPIO_Init() is not restricted by this parameter either way.
 * @note  The value is guarded so that a build option
 *        -DHAL_GPIO_DEINIT_PROTECT_DEFAULT_FUNC=0 can override it without a
 *        redefinition; the GPIO extension header keeps its own fallback for a
 *        configuration file that predates the parameter and applies the
 *        protection by default.
 */
#ifndef HAL_GPIO_DEINIT_PROTECT_DEFAULT_FUNC
    #define HAL_GPIO_DEINIT_PROTECT_DEFAULT_FUNC  1U   /*!< 1: protect, 0: reset them too */
#endif /* HAL_GPIO_DEINIT_PROTECT_DEFAULT_FUNC */

#if (HAL_GPIO_DEINIT_PROTECT_DEFAULT_FUNC > 1U)
    #error "as32x601_hal_conf.h: HAL_GPIO_DEINIT_PROTECT_DEFAULT_FUNC must be 0 or 1."
#endif /* (HAL_GPIO_DEINIT_PROTECT_DEFAULT_FUNC > 1U) */


/******************************************************************************
 *  CLOCK SOURCE VALUES ADAPTATION
 *****************************************************************************/
/**
 * @brief Value of the external oscillator (OSC), in Hz.
 * @note  Used by the SMU/CMU HAL module to compute the system frequency when
 *        the external oscillator is used as the system clock source
 *        (directly or through the PLL).
 */
#if !defined(OSC_VALUE)
    #define OSC_VALUE    20000000U   /*!< Value of the external oscillator in Hz */
#endif /* OSC_VALUE */

#if !defined(OSC_STARTUP_TIMEOUT)
    #define OSC_STARTUP_TIMEOUT    100U   /*!< Time out for OSC start up, in ms */
#endif /* OSC_STARTUP_TIMEOUT */

/**
 * @brief Value of the fast internal RC oscillator (FIRC), in Hz.
 * @note  Used by the SMU/CMU HAL module to compute the system frequency when
 *        the FIRC is used as the system clock source.
 */
#if !defined(FIRC_VALUE)
    #define FIRC_VALUE    16000000U   /*!< Value of the internal oscillator in Hz */
#endif /* FIRC_VALUE */

/**
 * @brief Value of the internal low speed RC oscillator (RC32K), in Hz.
 */
#if !defined(RC32K_VALUE)
    #define RC32K_VALUE    32768U     /*!< RC32K Typical Value in Hz */
#endif /* RC32K_VALUE */

/******************************************************************************
 *  C-ONLY SECTION (skipped by the assembly preprocessing)
 *****************************************************************************/
#ifndef __ASSEMBLER__
#include <stdint.h>
/* Type source of the assert_failed() prototype declared below (HAL-REQ-022).
 * The core layer header is where uint8 / uint32 are defined, and of the two
 * headers that provide them it is the lightweight one: the register
 * qualifiers and the base types only, without the register structures and
 * their layout assertions of the device layer header. It is therefore
 * sufficient here, it keeps those types visible whichever module switches
 * are enabled, and it compiles as C as well as C++. */
#include "core_riscv.h"

#ifdef HAL_GPIO_MODULE_ENABLED
#include "as32x601_hal_gpio.h"
#endif
#ifdef HAL_PLIC_MODULE_ENABLED
#include "as32x601_hal_plic.h"
#endif
#ifdef HAL_CLINT_MODULE_ENABLED
#include "as32x601_hal_clint.h"
#endif
#ifdef HAL_CMU_MODULE_ENABLED
#include "as32x601_hal_cmu.h"
#endif
#ifdef HAL_SMU_MODULE_ENABLED
#include "as32x601_hal_smu.h"
#endif
#ifdef HAL_PMU_MODULE_ENABLED
#include "as32x601_hal_pmu.h"
#endif
#ifdef HAL_TIM_MODULE_ENABLED
#include "as32x601_hal_tim.h"
#endif
#ifdef HAL_DMA_MODULE_ENABLED
#include "as32x601_hal_dma.h"
#endif
#ifdef HAL_RTC_MODULE_ENABLED
#include "as32x601_hal_rtc.h"
#endif
#ifdef HAL_IWDG_MODULE_ENABLED
#include "as32x601_hal_iwdg.h"
#endif
#ifdef HAL_WWDG_MODULE_ENABLED
#include "as32x601_hal_wwdg.h"
#endif
#ifdef HAL_ADC_MODULE_ENABLED
#include "as32x601_hal_adc.h"
#endif
#ifdef HAL_DAC_MODULE_ENABLED
#include "as32x601_hal_dac.h"
#endif
#ifdef HAL_USART_MODULE_ENABLED
#include "as32x601_hal_usart.h"
#endif
#ifdef HAL_SPI_MODULE_ENABLED
#include "as32x601_hal_spi.h"
#endif
#ifdef HAL_I2C_MODULE_ENABLED
#include "as32x601_hal_i2c.h"
#endif
#ifdef HAL_CANFD_MODULE_ENABLED
#include "as32x601_hal_canfd.h"
#endif
#ifdef HAL_QSPI_MODULE_ENABLED
#include "as32x601_hal_qspi.h"
#endif
#ifdef HAL_MAC_MODULE_ENABLED
#include "as32x601_hal_mac.h"
#endif
#ifdef HAL_FLASH_MODULE_ENABLED
#include "as32x601_hal_flash.h"
#endif
#ifdef HAL_FCU_MODULE_ENABLED
#include "as32x601_hal_fcu.h"
#endif
#ifdef HAL_TRNG_MODULE_ENABLED
#include "as32x601_hal_trng.h"
#endif
#ifdef HAL_CRC_MODULE_ENABLED
#include "as32x601_hal_crc.h"
#endif
#ifdef HAL_MPU_MODULE_ENABLED
#include "as32x601_hal_mpu.h"
#endif
#ifdef HAL_PKA_MODULE_ENABLED
#include "as32x601_hal_pka.h"
#endif
#ifdef HAL_SPACC_MODULE_ENABLED
#include "as32x601_hal_spacc.h"
#endif

#ifdef USE_FULL_ASSERT
    #define assert_param(expr) ((expr) ? (void)0 : assert_failed((uint8 *)__FILE__, __LINE__))
    void assert_failed(uint8* file, uint32 line);
#else
    #define assert_param(expr) ((void)0)
#endif /* USE_FULL_ASSERT */
#endif /* __ASSEMBLER__ */

#ifdef __cplusplus
}
#endif

#endif /* __AS32X601_HAL_CONF_H */

/*****END OF FILE*****/
