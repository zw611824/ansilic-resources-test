/*
 *   __ _   _ __    ___  (_) | | (_)   ___
 *  / _` | | '_ \  / __| | | | | | |  / __|
 * | (_| | | | | | \__ \ | | | | | | | (__
 *  \__,_| |_| |_| |___/ |_| |_| |_|  \___|
 *
 * Copyright (C):   Xiamen Guoke Anxin Technology Co., LTD
 * FileName:      as32x601_hal_canfd.c
 * Author:          ANSILIC APPLICATION GROUP
 * Version:         V1.4
 * Date:   2026/09/17
 * History:
 *               <author>           <time>    <version >      <desc>
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.0     build this module
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.1     fix the transmit data-word
 *                                                       packing in HAL_CANFD_
 *                                                       Transmit / LoopbackTransmit:
 *                                                       widen each byte to uint32
 *                                                       before the shift (a bare
 *                                                       uint8 << 24 is undefined
 *                                                       behaviour for values >= 0x80)
 *                                                       and zero-pad the last word so
 *                                                       that lengths not multiple of
 *                                                       four no longer read past the
 *                                                       end of the data buffer
 *     ANSILIC APPLICATION GROUP  2026/08/18     1.2     version aligned with the
 *                                                       header V1.2 (status flag
 *                                                       bit positions fixed in the
 *                                                       header; no source change)
 *     ANSILIC APPLICATION GROUP  2026/09/01     1.3     add the handle lock
 *                                                       mechanism: the shared
 *                                                       CANFD_LockHandle /
 *                                                       CANFD_UnlockHandle
 *                                                       functions are declared
 *                                                       in the header, every
 *                                                       register writing
 *                                                       function takes the lock
 *                                                       and releases it on all
 *                                                       return paths, the read
 *                                                       only functions stay
 *                                                       unlocked, and the RTOS
 *                                                       branch refers to the
 *                                                       LockMutex member of the
 *                                                       handle
 *     ANSILIC APPLICATION GROUP  2026/09/17     1.4     architecture
 *                                                       compliance rework of
 *                                                       the resource lock and
 *                                                       RTOS chapters: the MSP
 *                                                       callbacks now run
 *                                                       outside the locked
 *                                                       region (LOCK-06 /
 *                                                       ARCH-CONST-04: MspInit
 *                                                       before the lock in
 *                                                       HAL_CANFD_Init,
 *                                                       MspDeInit after the
 *                                                       unlock in
 *                                                       HAL_CANFD_DeInit);
 *                                                       CANFD_LockHandle()
 *                                                       takes a Timeout
 *                                                       parameter and reports a
 *                                                       missing RTOS mutex
 *                                                       (RTOS-11) instead of
 *                                                       waiting forever;
 *                                                       HAL_CANFD_NormalStatus()
 *                                                       and the transmit
 *                                                       functions take a Timeout
 *                                                       parameter, the normal
 *                                                       mode wait is measured
 *                                                       with HAL_GetTick() and
 *                                                       yields the CPU from the
 *                                                       polling loop (POLL-01 /
 *                                                       POLL-02 / POLL-03,
 *                                                       RTOS-04 / RTOS-05); the
 *                                                       public APIs no longer
 *                                                       call each other while
 *                                                       the lock is held
 *                                                       (LOCK-05: private Tier 3
 *                                                       helpers added for the
 *                                                       send channel request,
 *                                                       the RX read index and
 *                                                       the normal mode wait);
 *                                                       the error code is
 *                                                       cleared at the transmit
 *                                                       entry points
 *                                                       (ARCH-CONST-10); the
 *                                                       handle state machine
 *                                                       gains the BUSY and
 *                                                       TIMEOUT states and the
 *                                                       ARCH-CONST-09 state gate
 *                                                       (STATE-03 / STATE-04);
 *                                                       the blocking functions
 *                                                       are tagged (BLOCKING)
 *                                                       (POLL-04)
 * Description:     This file provides firmware functions to manage the
 *                  functionalities of the Controller Area Network Flexible
 *                  Data-rate (CAN FD) interface:
 *                  - Initialization and de-initialization;
 *                  - Mode control (normal / sleep / loopback / snoop);
 *                  - Configuration switches (BRS, auto retransmission,
 *                    protocol exception, bus-off recovery, TDC);
 *                  - Filtering (acceptance mask / ID pairs);
 *                  - Frame transmit (single / loopback) and receive
 *                    (data / info retrieval);
 *                  - Interrupt control;
 *                  - Status and error reporting.
 */
#include "as32x601_hal.h"          /* module switch from as32x601_hal_conf.h */
#include "as32x601_hal_canfd.h"    /* CANFD HAL API and register macros      */

/* The HAL_CANFD_MODULE_ENABLED switch is provided by the user configuration
 * file (as32x601_hal_conf.h, included above through as32x601_hal.h): the
 * whole implementation is compiled only while the module is enabled. */
#ifdef HAL_CANFD_MODULE_ENABLED

/* Private constants ---------------------------------------------------------*/
/* DLC code to 32-bit word count conversion (index = DLC code). */
static const uint8 Can_Dlc2Reglen[16] = {0U, 1U, 1U, 1U, 1U, 2U, 2U, 2U, 2U, 3U, 4U, 5U, 6U, 8U, 12U, 16U};
/* DLC code to data byte count conversion (index = DLC code). */
static const uint8 Can_Dlc2DataLen[16] = {0U, 1U, 2U, 3U, 4U, 5U, 6U, 7U, 8U, 12U, 16U, 20U, 24U, 32U, 48U, 64U};
/* Data byte count to DLC code conversion (index = byte count, 0..64). */
static const uint8 Can_DataLen2Dlc[65] = {0U, 1U, 2U, 3U, 4U, 5U, 6U, 7U, 8U,
                                          9U, 9U, 9U, 9U, 10U, 10U, 10U, 10U,
                                          11U, 11U, 11U, 11U, 12U, 12U, 12U, 12U,
                                          13U, 13U, 13U, 13U, 13U, 13U, 13U, 13U,
                                          14U, 14U, 14U, 14U, 14U, 14U, 14U, 14U,
                                          14U, 14U, 14U, 14U, 14U, 14U, 14U, 14U,
                                          15U, 15U, 15U, 15U, 15U, 15U, 15U, 15U,
                                          15U, 15U, 15U, 15U, 15U, 15U, 15U, 15U};

/* Private function prototypes -----------------------------------------------*/
static HAL_StatusTypeDef CANFD_CheckState(CANFD_HandleTypeDef *hcanfd);
static HAL_StatusTypeDef CANFD_WaitNormalStatus(CANFD_HandleTypeDef *hcanfd, uint32 Timeout);
static uint32 CANFD_GetRxReadIndex(CANFD_HandleTypeDef *hcanfd);
static void CANFD_SetRxIncReadIndex(CANFD_HandleTypeDef *hcanfd);
static void CANFD_SetSendChannel(CANFD_HandleTypeDef *hcanfd, uint32 SendTb);

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  Check whether the handle accepts a modifying operation
 *         (ARCH-CONST-09).
 * @note   A busy handle refuses a new operation (HAL_BUSY); a handle that was
 *         never initialized, or that has been de-initialized, refuses it too
 *         (HAL_ERROR), so that HAL_CANFD_Init() is called first. The
 *         recoverable ERROR / TIMEOUT states accept a new operation directly
 *         (STATE-04 / STATE-06), so that no DeInit / Init round trip is
 *         required after a timeout.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK (accepted) / HAL_BUSY / HAL_ERROR.
 */
static HAL_StatusTypeDef CANFD_CheckState(CANFD_HandleTypeDef *hcanfd)
{
    if (hcanfd->State == HAL_CANFD_STATE_BUSY)
    {
        return HAL_BUSY;
    }

    if (hcanfd->State == HAL_CANFD_STATE_RESET)
    {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
 * @brief  Wait until the CAN FD core reports normal mode. (BLOCKING)
 * @note   The wait is bounded by the caller supplied Timeout, measured with
 *         the HAL 1 ms time base (HAL_GetTick()), so that a core which never
 *         reaches normal mode cannot hang the MCU. HAL_MAX_DELAY waits
 *         forever; 0 gives the hardware a single chance (no waiting).
 * @note   The CPU is yielded to the other tasks while polling (RTOS-04 /
 *         RTOS-05: HAL_RTOS_Yield() is an empty macro in a bare-metal build,
 *         so the code path stays the same in both configurations).
 * @note   This is a Tier 3 helper: the caller owns the handle lock, so the
 *         helper does not lock the handle itself.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  Timeout: maximum wait time in ms.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT.
 */
static HAL_StatusTypeDef CANFD_WaitNormalStatus(CANFD_HandleTypeDef *hcanfd, uint32 Timeout)
{
    uint32 tickstart = HAL_GetTick();

    while ((hcanfd->Instance->SR & CANFD_STATUS_NORMAL) == 0U)
    {
        if (Timeout != HAL_MAX_DELAY)
        {
            if ((HAL_GetTick() - tickstart) > Timeout)
            {
                return HAL_TIMEOUT;
            }
        }

        HAL_RTOS_Yield();
    }

    return HAL_OK;
}

/**
 * @brief  Return the read index of the RX FIFO (Tier 3).
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval uint32: RX FIFO read index.
 */
static uint32 CANFD_GetRxReadIndex(CANFD_HandleTypeDef *hcanfd)
{
    return ((uint32)((hcanfd->Instance->RFSR & CANFD_RFSR_RI) >> CANFD_RFSR_RI_Pos));
}

/**
 * @brief  Increment the RX FIFO read index, i.e. release the current message
 *         (Tier 3).
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval None
 */
static void CANFD_SetRxIncReadIndex(CANFD_HandleTypeDef *hcanfd)
{
    /* Set the release / increment read index flag */
    hcanfd->Instance->RFSR |= ((uint32)CANFD_RFSR_IRI);
}

/**
 * @brief  Request the transmission of the selected transmit buffers (Tier 3).
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  SendTb: transmit buffer bitmask.
 * @retval None
 */
static void CANFD_SetSendChannel(CANFD_HandleTypeDef *hcanfd, uint32 SendTb)
{
    hcanfd->Instance->TRR = SendTb;
}

/**
 * @brief  Lock the handle (RTOS mutex or single-core lock flag).
 * @note   The RTOS branch uses the LockMutex handle of the handle structure,
 *         which shall have been created by the user porting layer (e.g. in
 *         HAL_CANFD_MspInit()). The bare-metal branch uses the Lock flag.
 * @note   RTOS-11: the Timeout parameter prevents a task from blocking forever
 *         on a shared peripheral; when the mutex is not acquired before the
 *         Timeout expires, HAL_TIMEOUT is returned. The value is passed to
 *         HAL_MutexAcquire() as is (RTOS ticks; with the usual 1 ms tick it is
 *         the same quantity as the millisecond Timeout of the public API, and
 *         HAL_MAX_DELAY means an infinite wait).
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  Timeout: maximum time to wait for the lock, in ms / RTOS ticks.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_TIMEOUT (RTOS) / HAL_ERROR (RTOS,
 *         mutex not created) / HAL_BUSY (bare metal, already locked).
 */
HAL_StatusTypeDef CANFD_LockHandle(CANFD_HandleTypeDef *hcanfd, uint32 Timeout)
{
#if (USE_RTOS == 1)
    if (hcanfd->LockMutex == NULL_PTR)
    {
        /* The porting layer did not create the mutex (e.g. HAL_CANFD_MspInit()
         * was not overridden): report it instead of calling the RTOS with a
         * NULL handle */
        return HAL_ERROR;
    }

    return HAL_MutexAcquire(hcanfd->LockMutex, Timeout);
#else
    /* Prevent unused argument compilation warning: the bare-metal lock flag
     * either succeeds immediately or reports HAL_BUSY, it never waits */
    UNUSED(Timeout);

    if (hcanfd->Lock == HAL_LOCKED)
    {
        return HAL_BUSY;
    }

    hcanfd->Lock = HAL_LOCKED;

    return HAL_OK;
#endif /* USE_RTOS */
}

/**
 * @brief  Unlock the handle.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval None
 */
void CANFD_UnlockHandle(CANFD_HandleTypeDef *hcanfd)
{
#if (USE_RTOS == 1)
    (void)HAL_MutexRelease(hcanfd->LockMutex);
#else
    hcanfd->Lock = HAL_UNLOCKED;
#endif /* USE_RTOS */
}

/* Exported functions --------------------------------------------------------*/

/** @addtogroup CANFD_Exported_Functions
  * @{
  */

/** @addtogroup CANFD_Exported_Functions_Group1 Initialization and de-initialization functions
  * @{
  */

/**
 * @brief  Fills each CANFD_InitStruct member with its default value. (NON-BLOCKING)
 * @param  CANFD_InitStruct: pointer to a CANFD_InitTypeDef structure which
 *         will be initialized.
 * @retval None
 */
void HAL_CANFD_StructInit(CANFD_InitTypeDef *CANFD_InitStruct)
{
    /* Check the parameter */
    if (CANFD_InitStruct == NULL_PTR)
    {
        return;
    }

    /* Reset the CANFD init structure parameters values */
    CANFD_InitStruct->Size                 = sizeof(CANFD_InitTypeDef);    /*!< sizeof struct */
    CANFD_InitStruct->Version              = CANFD_INIT_VERSION;           /*!< V1            */
    CANFD_InitStruct->CANFD_SRR            = CANFD_SRR_RESET;           /*!< Software reset */
    CANFD_InitStruct->CANFD_APBRPR         = CANFD_APBRPR_PRESCALER(1);   /*!< Arbitration
                                                                        prescaler 1 */
    CANFD_InitStruct->CANFD_APBTR_APTS1    = CANFD_APBTR_TS1_VALUE(1);  /*!< Arbitration TS1 1 */
    CANFD_InitStruct->CANFD_APBTR_APTS2    = CANFD_APBTR_TS2_VALUE(1);  /*!< Arbitration TS2 1 */
    CANFD_InitStruct->CANFD_APBTR_APSJW    = CANFD_APBTR_SJW_VALUE(1);  /*!< Arbitration SJW 1 */
    CANFD_InitStruct->CANFD_DPBRPR         = CANFD_DPBRPR_PRESCALER(1); /*!< Data prescaler 1 */
    CANFD_InitStruct->CANFD_DPBTR_DPTS1    = CANFD_DPBTR_TS1_VALUE(1);  /*!< Data TS1 1 */
    CANFD_InitStruct->CANFD_DPBTR_DPTS2    = CANFD_DPBTR_TS2_VALUE(1);  /*!< Data TS2 1 */
    CANFD_InitStruct->CANFD_DPBTR_DPSJW    = CANFD_DPBTR_SJW_VALUE(1);  /*!< Data SJW 1 */
    CANFD_InitStruct->Reserved[0]          = 0U;                         /*!< Reserved */
    CANFD_InitStruct->Reserved[1]          = 0U;                         /*!< Reserved */
}

/**
 * @brief  Initializes the CAN FD according to the specified parameters in (NON-BLOCKING)
 *         the CANFD_InitStruct of the handle. (NON-BLOCKING)
 * @note   The CAN FD clock gating and the pin multiplexing must be
 *         configured by the user in HAL_CANFD_MspInit().
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR
 */
HAL_StatusTypeDef HAL_CANFD_Init(CANFD_HandleTypeDef *hcanfd)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));
    assert_param(IS_CANFD_SRR(hcanfd->Init.CANFD_SRR));
    assert_param(IS_CANFD_APBRPR(hcanfd->Init.CANFD_APBRPR));
    assert_param(IS_CANFD_APBTR_TS1(hcanfd->Init.CANFD_APBTR_APTS1));
    assert_param(IS_CANFD_APBTR_TS2(hcanfd->Init.CANFD_APBTR_APTS2));
    assert_param(IS_CANFD_APBTR_SJW(hcanfd->Init.CANFD_APBTR_APSJW));
    assert_param(IS_CANFD_DPBRPR(hcanfd->Init.CANFD_DPBRPR));
    assert_param(IS_CANFD_DPBTR_TS1(hcanfd->Init.CANFD_DPBTR_DPTS1));
    assert_param(IS_CANFD_DPBTR_TS2(hcanfd->Init.CANFD_DPBTR_DPTS2));
    assert_param(IS_CANFD_DPBTR_SJW(hcanfd->Init.CANFD_DPBTR_DPSJW));

    if (hcanfd->State == HAL_CANFD_STATE_RESET)
    {
        /* Allocate the lock resource before the first use, so that a handle
         * which was never initialized cannot report HAL_BUSY from a stale
         * Lock field */
        hcanfd->Lock = HAL_UNLOCKED;

        /* Initialize the low level hardware (CAN FD clock gating and the pin
         * multiplexing). LOCK-06 / ARCH-CONST-04: the MSP callback runs
         * BEFORE the handle is locked, because the user override may call
         * other HAL APIs of this library (HAL_GPIO_Init() and the like) */
        HAL_CANFD_MspInit(hcanfd);
    }

    /* Process locked */
    if (CANFD_LockHandle(hcanfd, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return HAL_BUSY;
    }

    /* Software reset / enable request */
    hcanfd->Instance->SRR = hcanfd->Init.CANFD_SRR;

    /* Arbitration phase prescaler */
    hcanfd->Instance->APBRPR = hcanfd->Init.CANFD_APBRPR;

    /* Arbitration phase bit timing: TS1 / TS2 / SJW combined in one write */
    hcanfd->Instance->APBTR = ((uint32)(((hcanfd->Init.CANFD_APBTR_APTS1) << CANFD_APBTR_TS1_Pos) |
                                        ((hcanfd->Init.CANFD_APBTR_APTS2) << CANFD_APBTR_TS2_Pos) |
                                        ((hcanfd->Init.CANFD_APBTR_APSJW) << CANFD_APBTR_SJW_Pos)));

    /* Data phase prescaler */
    hcanfd->Instance->DPBRPR = hcanfd->Init.CANFD_DPBRPR;

    /* Data phase bit timing: TS1 / TS2 / SJW combined in one write */
    hcanfd->Instance->DPBTR = ((uint32)(((hcanfd->Init.CANFD_DPBTR_DPTS1) << CANFD_DPBTR_DP_TS1_Pos) |
                                        ((hcanfd->Init.CANFD_DPBTR_DPTS2) << CANFD_DPBTR_DP_TS2_Pos) |
                                        ((hcanfd->Init.CANFD_DPBTR_DPSJW) << CANFD_DPBTR_DP_SJW_Pos)));

    /* Reset the CANFD error code and set the state to ready */
    hcanfd->ErrorCode = HAL_CANFD_ERROR_NONE;
    hcanfd->State     = HAL_CANFD_STATE_READY;

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);

    return HAL_OK;
}

/**
 * @brief  De-initializes the CAN FD peripheral. (NON-BLOCKING)
 * @note   The low level de-initialization is performed by
 *         HAL_CANFD_MspDeInit() OUTSIDE the locked region, so that the user
 *         override may call other HAL APIs (LOCK-06 / ARCH-CONST-04).
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY / HAL_TIMEOUT
 *         (RTOS, the handle lock was not acquired).
 */
HAL_StatusTypeDef HAL_CANFD_DeInit(CANFD_HandleTypeDef *hcanfd)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    /* Process locked */
    if (CANFD_LockHandle(hcanfd, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return HAL_BUSY;
    }

    /* Reset the CAN FD core */
    hcanfd->Instance->SRR = CANFD_SRR_SRST;

    /* Reset the handle state */
    hcanfd->State     = HAL_CANFD_STATE_RESET;
    hcanfd->ErrorCode = HAL_CANFD_ERROR_NONE;

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);

    /* LOCK-06 / ARCH-CONST-04: the low level de-initialization runs OUTSIDE
     * the locked region, as the architecture specification requires for the
     * MSP callbacks ("MspDeInit is called after the unlock"); the user
     * override may call other HAL APIs of this library (HAL_GPIO_DeInit()
     * and the like) */
    HAL_CANFD_MspDeInit(hcanfd);

    return HAL_OK;
}

/**
 * @brief  Initializes the CAN FD MSP. Weak empty function; the user
 *         implements the low level hardware initialization.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_CANFD_MspInit(CANFD_HandleTypeDef *hcanfd)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hcanfd);
}

/**
 * @brief  De-initializes the CAN FD MSP. Weak empty function; the user
 *         implements the low level hardware de-initialization.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval None
 */
__weak void HAL_CANFD_MspDeInit(CANFD_HandleTypeDef *hcanfd)
{
    /* Prevent unused argument compilation warning */
    UNUSED(hcanfd);
}

/**
  * @}
  */

/** @addtogroup CANFD_Exported_Functions_Group2 Mode control functions
  * @{
  */

/**
 * @brief  Requests the CAN FD core to enter sleep mode. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval None
 */
void HAL_CANFD_Sleep(CANFD_HandleTypeDef *hcanfd)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    /* ARCH-CONST-09: only a handle that has been initialized accepts a
     * modifying operation (the recoverable ERROR / TIMEOUT states accept it
     * so that no DeInit / Init round trip is required) */
    if (CANFD_CheckState(hcanfd) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (CANFD_LockHandle(hcanfd, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return;
    }

    hcanfd->Instance->SRR &= ~((uint32)CANFD_SRR_CEN);
    hcanfd->Instance->MSR &= ~((uint32)(CANFD_MSR_SNOOP | CANFD_MSR_LBACK));
    hcanfd->Instance->MSR |= ((uint32)CANFD_MSR_SLEEP);
    hcanfd->Instance->SRR |= CANFD_SRR_CEN;

    hcanfd->State = HAL_CANFD_STATE_SLEEP;

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);
}

/**
 * @brief  Wakes up the CAN FD core from sleep mode. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval None
 */
void HAL_CANFD_WakeUp(CANFD_HandleTypeDef *hcanfd)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    /* ARCH-CONST-09: only a handle that has been initialized accepts a
     * modifying operation (the recoverable ERROR / TIMEOUT states accept it
     * so that no DeInit / Init round trip is required) */
    if (CANFD_CheckState(hcanfd) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (CANFD_LockHandle(hcanfd, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return;
    }

    hcanfd->Instance->SRR &= ~((uint32)CANFD_SRR_CEN);
    hcanfd->Instance->MSR &= ~((uint32)CANFD_MSR_SLEEP);
    hcanfd->Instance->SRR |= CANFD_SRR_CEN;

    hcanfd->State = HAL_CANFD_STATE_READY;

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);
}

/**
 * @brief  Requests the CAN FD core to enter loopback mode. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval None
 */
void HAL_CANFD_SetLoopback(CANFD_HandleTypeDef *hcanfd)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    /* ARCH-CONST-09: only a handle that has been initialized accepts a
     * modifying operation (the recoverable ERROR / TIMEOUT states accept it
     * so that no DeInit / Init round trip is required) */
    if (CANFD_CheckState(hcanfd) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (CANFD_LockHandle(hcanfd, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return;
    }

    hcanfd->Instance->SRR &= ~((uint32)CANFD_SRR_CEN);
    hcanfd->Instance->MSR &= ~((uint32)(CANFD_MSR_SNOOP | CANFD_MSR_SLEEP));
    hcanfd->Instance->MSR |= ((uint32)CANFD_MSR_LBACK);
    hcanfd->Instance->SRR |= CANFD_SRR_CEN;

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);
}

/**
 * @brief  Requests the CAN FD core to leave loopback mode. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval None
 */
void HAL_CANFD_CloseLoopback(CANFD_HandleTypeDef *hcanfd)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    /* ARCH-CONST-09: only a handle that has been initialized accepts a
     * modifying operation (the recoverable ERROR / TIMEOUT states accept it
     * so that no DeInit / Init round trip is required) */
    if (CANFD_CheckState(hcanfd) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (CANFD_LockHandle(hcanfd, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return;
    }

    hcanfd->Instance->SRR &= ~((uint32)CANFD_SRR_CEN);
    hcanfd->Instance->MSR &= ~((uint32)CANFD_MSR_LBACK);
    hcanfd->Instance->SRR |= CANFD_SRR_CEN;

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);
}

/**
 * @brief  Requests the CAN FD core to enter snoop mode. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval None
 */
void HAL_CANFD_SetSnoop(CANFD_HandleTypeDef *hcanfd)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    /* ARCH-CONST-09: only a handle that has been initialized accepts a
     * modifying operation (the recoverable ERROR / TIMEOUT states accept it
     * so that no DeInit / Init round trip is required) */
    if (CANFD_CheckState(hcanfd) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (CANFD_LockHandle(hcanfd, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return;
    }

    hcanfd->Instance->SRR &= ~((uint32)CANFD_SRR_CEN);
    hcanfd->Instance->MSR &= ~((uint32)(CANFD_MSR_LBACK | CANFD_MSR_SLEEP));
    hcanfd->Instance->MSR |= ((uint32)CANFD_MSR_SNOOP);
    hcanfd->Instance->SRR |= CANFD_SRR_CEN;

    hcanfd->State = HAL_CANFD_STATE_LISTEN;

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);
}

/**
 * @brief  Requests the CAN FD core to leave snoop mode. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval None
 */
void HAL_CANFD_CloseSnoop(CANFD_HandleTypeDef *hcanfd)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    /* ARCH-CONST-09: only a handle that has been initialized accepts a
     * modifying operation (the recoverable ERROR / TIMEOUT states accept it
     * so that no DeInit / Init round trip is required) */
    if (CANFD_CheckState(hcanfd) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (CANFD_LockHandle(hcanfd, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return;
    }

    hcanfd->Instance->SRR &= ~((uint32)CANFD_SRR_CEN);
    hcanfd->Instance->MSR &= ~((uint32)CANFD_MSR_SNOOP);
    hcanfd->Instance->SRR |= CANFD_SRR_CEN;

    hcanfd->State = HAL_CANFD_STATE_READY;

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);
}

/**
 * @brief  Waits until the CAN FD core is in normal mode. (BLOCKING)
 * @note   The wait is bounded by the Timeout parameter and measured with the
 *         HAL 1 ms time base (HAL_GetTick()); the CPU is yielded to the other
 *         tasks while polling (RTOS-04). Use HAL_MAX_DELAY to wait forever.
 * @note   On timeout HAL_TIMEOUT is returned, HAL_CANFD_ERROR_TIMEOUT is
 *         accumulated into the error code and the state becomes
 *         HAL_CANFD_STATE_TIMEOUT (POLL-03). The timeout state is
 *         recoverable: a new operation may be called directly (STATE-04).
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  Timeout: maximum wait time in ms (HAL_MAX_DELAY waits forever,
 *         0 does not wait). The same value bounds the wait for the handle
 *         lock in RTOS builds.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR (NULL handle) / HAL_BUSY /
 *         HAL_TIMEOUT.
 */
HAL_StatusTypeDef HAL_CANFD_NormalStatus(CANFD_HandleTypeDef *hcanfd, uint32 Timeout)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    /* ARCH-CONST-09: a de-initialized handle has no clocked core to poll and
     * a busy handle owns the peripheral, so both are refused before the wait */
    status = CANFD_CheckState(hcanfd);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    status = CANFD_LockHandle(hcanfd, Timeout);
    if (status != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return status;
    }

    /* Wait for the core to report normal mode */
    status = CANFD_WaitNormalStatus(hcanfd, Timeout);
    if (status != HAL_OK)
    {
        /* POLL-03: report the timeout through the error code and the state */
        hcanfd->ErrorCode |= HAL_CANFD_ERROR_TIMEOUT;
        hcanfd->State      = HAL_CANFD_STATE_TIMEOUT;
    }

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);

    return status;
}

/**
  * @}
  */

/** @addtogroup CANFD_Exported_Functions_Group3 Configuration functions
  * @{
  */

/**
 * @brief  Enables or disables the CAN FD bit rate switch (BRSD override). (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  NewState: CANFD_ENABLE or CANFD_DISABLE.
 * @retval None
 */
void HAL_CANFD_BitRateConfig(CANFD_HandleTypeDef *hcanfd, uint32 NewState)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    /* ARCH-CONST-09: only a handle that has been initialized accepts a
     * modifying operation (the recoverable ERROR / TIMEOUT states accept it
     * so that no DeInit / Init round trip is required) */
    if (CANFD_CheckState(hcanfd) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (CANFD_LockHandle(hcanfd, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return;
    }

    hcanfd->Instance->SRR &= ~((uint32)CANFD_SRR_CEN);
    if (NewState != CANFD_DISABLE)
    {
        /* Enable BRS: clear the BRSD override */
        hcanfd->Instance->MSR &= ~((uint32)CANFD_MSR_BRSD);
    }
    else
    {
        /* Disable BRS: set the BRSD override */
        hcanfd->Instance->MSR |= ((uint32)CANFD_MSR_BRSD);
    }
    hcanfd->Instance->SRR |= CANFD_SRR_CEN;

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);
}

/**
 * @brief  Enables or disables the CAN FD auto retransmission. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  NewState: CANFD_ENABLE or CANFD_DISABLE.
 * @retval None
 */
void HAL_CANFD_AutoRetransConfig(CANFD_HandleTypeDef *hcanfd, uint32 NewState)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    /* ARCH-CONST-09: only a handle that has been initialized accepts a
     * modifying operation (the recoverable ERROR / TIMEOUT states accept it
     * so that no DeInit / Init round trip is required) */
    if (CANFD_CheckState(hcanfd) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (CANFD_LockHandle(hcanfd, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return;
    }

    hcanfd->Instance->SRR &= ~((uint32)CANFD_SRR_CEN);
    if (NewState != CANFD_DISABLE)
    {
        /* Enable auto retransmission: clear the DAR disable bit */
        hcanfd->Instance->MSR &= ~((uint32)CANFD_MSR_DAR);
    }
    else
    {
        /* Disable auto retransmission: set the DAR disable bit */
        hcanfd->Instance->MSR |= ((uint32)CANFD_MSR_DAR);
    }
    hcanfd->Instance->SRR |= CANFD_SRR_CEN;

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);
}

/**
 * @brief  Enables or disables the CAN FD protocol exception event detection. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  NewState: CANFD_ENABLE or CANFD_DISABLE.
 * @retval None
 */
void HAL_CANFD_ProtExcConfig(CANFD_HandleTypeDef *hcanfd, uint32 NewState)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    /* ARCH-CONST-09: only a handle that has been initialized accepts a
     * modifying operation (the recoverable ERROR / TIMEOUT states accept it
     * so that no DeInit / Init round trip is required) */
    if (CANFD_CheckState(hcanfd) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (CANFD_LockHandle(hcanfd, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return;
    }

    hcanfd->Instance->SRR &= ~((uint32)CANFD_SRR_CEN);
    if (NewState != CANFD_DISABLE)
    {
        /* Enable PEE: clear the DPEE disable bit */
        hcanfd->Instance->MSR &= ~((uint32)CANFD_MSR_DPEE);
    }
    else
    {
        /* Disable PEE: set the DPEE disable bit */
        hcanfd->Instance->MSR |= ((uint32)CANFD_MSR_DPEE);
    }
    hcanfd->Instance->SRR |= CANFD_SRR_CEN;

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);
}

/**
 * @brief  Starts the CAN FD bus-off recovery request. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval None
 */
void HAL_CANFD_SetBusOff(CANFD_HandleTypeDef *hcanfd)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    /* ARCH-CONST-09: only a handle that has been initialized accepts a
     * modifying operation (the recoverable ERROR / TIMEOUT states accept it
     * so that no DeInit / Init round trip is required) */
    if (CANFD_CheckState(hcanfd) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (CANFD_LockHandle(hcanfd, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return;
    }

    hcanfd->Instance->SRR &= ~((uint32)CANFD_SRR_CEN);
    hcanfd->Instance->MSR |= ((uint32)CANFD_MSR_SBR);
    hcanfd->Instance->SRR |= CANFD_SRR_CEN;

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);
}

/**
 * @brief  Enables or disables the CAN FD auto bus-off recovery. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  NewState: CANFD_ENABLE or CANFD_DISABLE.
 * @retval None
 */
void HAL_CANFD_AutoBusOffRecoConfig(CANFD_HandleTypeDef *hcanfd, uint32 NewState)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    /* ARCH-CONST-09: only a handle that has been initialized accepts a
     * modifying operation (the recoverable ERROR / TIMEOUT states accept it
     * so that no DeInit / Init round trip is required) */
    if (CANFD_CheckState(hcanfd) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (CANFD_LockHandle(hcanfd, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return;
    }

    hcanfd->Instance->SRR &= ~((uint32)CANFD_SRR_CEN);
    if (NewState != CANFD_DISABLE)
    {
        hcanfd->Instance->MSR |= ((uint32)CANFD_MSR_ABR);
    }
    else
    {
        hcanfd->Instance->MSR &= ~((uint32)CANFD_MSR_ABR);
    }
    hcanfd->Instance->SRR |= CANFD_SRR_CEN;

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);
}

/**
 * @brief  Configures the CAN FD transmitter delay compensation. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  NewState: CANFD_ENABLE or CANFD_DISABLE.
 * @param  TDC_OFFSET: TDC offset value (0..63).
 * @retval None
 */
void HAL_CANFD_TDCConfig(CANFD_HandleTypeDef *hcanfd, uint32 NewState, uint8 TDC_OFFSET)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));
    assert_param(IS_CANFD_TDC_OFFSET(TDC_OFFSET));

    /* ARCH-CONST-09: only a handle that has been initialized accepts a
     * modifying operation (the recoverable ERROR / TIMEOUT states accept it
     * so that no DeInit / Init round trip is required) */
    if (CANFD_CheckState(hcanfd) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (CANFD_LockHandle(hcanfd, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return;
    }

    /* Clear the TDC enable and offset fields, then write the new values */
    hcanfd->Instance->DPBRPR &= ~((uint32)(CANFD_DPBRPR_TDCOFF | CANFD_DPBRPR_TDC));
    if (NewState != CANFD_DISABLE)
    {
        hcanfd->Instance->DPBRPR |= ((uint32)(CANFD_DPBRPR_TDC | ((uint32)TDC_OFFSET << CANFD_DPBRPR_TDCOFF_Pos)));
    }

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);
}

/**
  * @}
  */

/** @addtogroup CANFD_Exported_Functions_Group4 Filtering functions
  * @{
  */

/**
 * @brief  Configures a CAN FD acceptance filter (mask / ID pair) and (NON-BLOCKING)
 *         activates it. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  CANFD_FilterConfig: pointer to a CANFD_FilterConfigTypeDef
 *         structure containing the filter configuration.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR
 */
HAL_StatusTypeDef HAL_CANFD_FilterInit(CANFD_HandleTypeDef *hcanfd, CANFD_FilterConfigTypeDef *CANFD_FilterConfig)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the CANFD peripheral handle and the filter configuration */
    if ((hcanfd == NULL_PTR) || (CANFD_FilterConfig == NULL_PTR))
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));
    assert_param(IS_CANFD_FILTER_SPACE(CANFD_FilterConfig->CANFD_FilterNumber));

    /* ARCH-CONST-09: only the recoverable states accept a new modifying
     * operation */
    status = CANFD_CheckState(hcanfd);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    status = CANFD_LockHandle(hcanfd, HAL_MAX_DELAY);
    if (status != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return status;
    }

    if (CANFD_FilterConfig->CANFD_FilterCmd != CANFD_DISABLE)
    {
        /* Write the acceptance filter mask and ID pair */
        hcanfd->Instance->Rxfiltering[CANFD_FilterConfig->CANFD_FilterNumber].AFMR =
            CANFD_FilterConfig->CANFD_FilterMask;
        hcanfd->Instance->Rxfiltering[CANFD_FilterConfig->CANFD_FilterNumber].AFIR = CANFD_FilterConfig->CANFD_FilterID;
        /* Activate the filter */
        hcanfd->Instance->AFR |= ((uint32)(0x01UL << CANFD_FilterConfig->CANFD_FilterNumber));
    }
    else
    {
        /* Deactivate the filter */
        hcanfd->Instance->AFR &= ~((uint32)(0x01UL << CANFD_FilterConfig->CANFD_FilterNumber));
    }

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);

    return HAL_OK;
}

/**
 * @brief  Configures the CAN FD to receive all messages (mask / ID filters (NON-BLOCKING)
 *         cleared and the acceptance filter control set to all-pass). (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  NewState: CANFD_ENABLE (receive all) or CANFD_DISABLE.
 * @retval None
 */
void HAL_CANFD_ReceiveAll(CANFD_HandleTypeDef *hcanfd, uint32 NewState)
{
    uint32 rb = 0U;

    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    /* ARCH-CONST-09: only a handle that has been initialized accepts a
     * modifying operation (the recoverable ERROR / TIMEOUT states accept it
     * so that no DeInit / Init round trip is required) */
    if (CANFD_CheckState(hcanfd) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (CANFD_LockHandle(hcanfd, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return;
    }

    /* All-pass acceptance filter control */
    if (NewState != CANFD_DISABLE)
    {
        hcanfd->Instance->AFR = 0xFFFFFFFFU;
    }
    else
    {
        hcanfd->Instance->AFR = 0x00000000U;
    }

    /* Clear all the acceptance filter mask / ID pairs */
    for (rb = 0U; rb < 32U; rb++)
    {
        hcanfd->Instance->Rxfiltering[rb].AFMR = 0x00000000U;
        hcanfd->Instance->Rxfiltering[rb].AFIR = 0x00000000U;
    }

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);
}

/**
  * @}
  */

/** @addtogroup CANFD_Exported_Functions_Group5 Frame and transmit functions
  * @{
  */

/**
 * @brief  Fills each CANFD_TXFrameStruct member with its default value. (NON-BLOCKING)
 * @param  CANFD_TXFrameStruct: pointer to a CANFD_TXFrameTypeDef structure
 *         which will be initialized.
 * @retval None
 */
void HAL_CANFD_FrameStructInit(CANFD_TXFrameTypeDef *CANFD_TXFrameStruct)
{
    /* Check the parameter */
    if (CANFD_TXFrameStruct == NULL_PTR)
    {
        return;
    }

    /* Reset the frame structure parameters values */
    CANFD_TXFrameStruct->CANFD_TX_PROTOCOL = CANFD_PROTOCOL_CAN;       /*!< Frame protocol */
    CANFD_TXFrameStruct->CANFD_TX_FORMAT   = CANFD_FORMAT_STANDARD;    /*!< Frame format   */
    CANFD_TXFrameStruct->CANFD_TX_TYPE     = CANFD_TYPE_DATA;          /*!< Frame type     */
    CANFD_TXFrameStruct->CANFD_Frame_ID    = 0U;                       /*!< Frame ID       */
}

/**
 * @brief  Configures a transmit buffer frame settings (identifier, format, (NON-BLOCKING)
 *         type and protocol). (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  TxBuffer: transmit buffer index, 0..31.
 * @param  CANFD_TXFrameStruct: pointer to a CANFD_TXFrameTypeDef structure.
 * @retval None
 */
void HAL_CANFD_FrameInit(CANFD_HandleTypeDef *hcanfd, uint32 TxBuffer, CANFD_TXFrameTypeDef *CANFD_TXFrameStruct)
{
    uint32 tmpreg = 0U;

    /* Check the CANFD peripheral handle and the frame structure */
    if ((hcanfd == NULL_PTR) || (CANFD_TXFrameStruct == NULL_PTR))
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));
    assert_param(IS_CANFD_TB_NUMBER(TxBuffer));
    assert_param(IS_CANFD_FORMAT(CANFD_TXFrameStruct->CANFD_TX_FORMAT));
    assert_param(IS_CANFD_PROTOCOL(CANFD_TXFrameStruct->CANFD_TX_PROTOCOL));
    assert_param(IS_CANFD_TYPE(CANFD_TXFrameStruct->CANFD_TX_TYPE));

    /* ARCH-CONST-09: only a handle that has been initialized accepts a
     * modifying operation (the recoverable ERROR / TIMEOUT states accept it
     * so that no DeInit / Init round trip is required) */
    if (CANFD_CheckState(hcanfd) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (CANFD_LockHandle(hcanfd, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return;
    }

    /* Configure the identifier field */
    if (CANFD_TXFrameStruct->CANFD_TX_FORMAT == CANFD_FORMAT_EXTENDED)
    {
        /* Extended frame: low 18 bits into EM_ID, high 11 bits into ID */
        tmpreg = hcanfd->Instance->TxMessage[TxBuffer].TB_ID;
        tmpreg &= ~((uint32)(CANFD_TB_ID_ID | CANFD_TB_ID_EM_ID));
        tmpreg |= ((CANFD_TXFrameStruct->CANFD_Frame_ID & 0x3FFFFU) << CANFD_TB_ID_EM_ID_Pos);
        tmpreg |= (((CANFD_TXFrameStruct->CANFD_Frame_ID >> 18U) & 0x7FFU) << CANFD_TB_ID_ID_Pos);
        hcanfd->Instance->TxMessage[TxBuffer].TB_ID = tmpreg;

        /* Set the SRR / IDE bits (CAN FD: SRR + IDE always set) */
        tmpreg = hcanfd->Instance->TxMessage[TxBuffer].TB_ID;
        tmpreg &= ~((uint32)(CANFD_TB_ID_SRR | CANFD_TB_ID_IDE | CANFD_TB_ID_RTR));
        if (CANFD_TXFrameStruct->CANFD_TX_PROTOCOL == CANFD_PROTOCOL_CAN)
        {
            /* Classic CAN extended frame: RTR carries the frame type */
            tmpreg |= (CANFD_TB_ID_SRR | CANFD_TB_ID_IDE | (CANFD_TXFrameStruct->CANFD_TX_TYPE << CANFD_TB_ID_RTR_Pos));
        }
        else
        {
            /* CAN FD extended frame: no RTR bit */
            tmpreg |= (CANFD_TB_ID_SRR | CANFD_TB_ID_IDE);
        }
        hcanfd->Instance->TxMessage[TxBuffer].TB_ID = tmpreg;
    }
    else
    {
        /* Standard frame: 11-bit identifier */
        tmpreg = hcanfd->Instance->TxMessage[TxBuffer].TB_ID;
        tmpreg &= ~((uint32)CANFD_TB_ID_ID);
        tmpreg |= (CANFD_TXFrameStruct->CANFD_Frame_ID << CANFD_TB_ID_ID_Pos);
        hcanfd->Instance->TxMessage[TxBuffer].TB_ID = tmpreg;

        /* Set the SRR / IDE bits */
        tmpreg = hcanfd->Instance->TxMessage[TxBuffer].TB_ID;
        tmpreg &= ~((uint32)(CANFD_TB_ID_SRR | CANFD_TB_ID_IDE | CANFD_TB_ID_RTR));
        if (CANFD_TXFrameStruct->CANFD_TX_PROTOCOL == CANFD_PROTOCOL_CAN)
        {
            /* Classic CAN standard frame: SRR carries the frame type */
            tmpreg |= (CANFD_TXFrameStruct->CANFD_TX_TYPE << CANFD_TB_ID_SRR_Pos);
        }
        hcanfd->Instance->TxMessage[TxBuffer].TB_ID = tmpreg;
    }

    /* Configure the protocol in the DLC register: BRS / EDL fields */
    hcanfd->Instance->TxMessage[TxBuffer].TB_DLC &= ~((uint32)(CANFD_TB_DLC_BRS | CANFD_TB_DLC_EDL));
    hcanfd->Instance->TxMessage[TxBuffer].TB_DLC = ((CANFD_TXFrameStruct->CANFD_TX_PROTOCOL) << CANFD_TB_DLC_BRS_Pos);

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);
}

/**
 * @brief  Writes the transmit data into a transmit buffer and requests the
 *         transmission (normal mode). (BLOCKING)
 * @note   The function waits until the core reports normal mode before it
 *         requests the transmission; the wait is bounded by the Timeout
 *         parameter and yields the CPU while polling (RTOS-04). On timeout
 *         HAL_TIMEOUT is returned and the state becomes
 *         HAL_CANFD_STATE_TIMEOUT (recoverable, STATE-04).
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  TxBuffer: transmit buffer index, 0..31.
 * @param  pData: pointer to the data buffer (0..64 bytes, length must be a
 *         valid CAN FD length).
 * @param  Length: number of bytes in the data buffer.
 * @param  Timeout: maximum time to wait for the normal mode, in ms
 *         (HAL_MAX_DELAY waits forever, 0 does not wait). The same value
 *         bounds the wait for the handle lock in RTOS builds.
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY / HAL_TIMEOUT.
 */
HAL_StatusTypeDef HAL_CANFD_Transmit(CANFD_HandleTypeDef *hcanfd, uint32 TxBuffer, uint8 *pData, uint32 Length,
                                     uint32 Timeout)
{
    volatile uint32 *txaddress = NULL_PTR;
    uint32 bytecounter = 0U;
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));
    assert_param(IS_CANFD_TB_NUMBER(TxBuffer));
    assert_param(pData != NULL_PTR);
    assert_param(IS_CANFD_DATA_LENGTH(Length));

    /* Runtime check of the transfer parameters (the assert_param macro may
     * be compiled out) */
    if ((pData == NULL_PTR) || (Length > 64U))
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: only the recoverable states accept a new transmission */
    status = CANFD_CheckState(hcanfd);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    status = CANFD_LockHandle(hcanfd, Timeout);
    if (status != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return status;
    }

    /* ARCH-CONST-10: a new transfer starts from a clean error code, and
     * STATE-03: the transfer is marked busy while it runs */
    hcanfd->ErrorCode = HAL_CANFD_ERROR_NONE;
    hcanfd->State     = HAL_CANFD_STATE_BUSY;

    /* Set the DLC code from the data length */
    hcanfd->Instance->TxMessage[TxBuffer].TB_DLC &= ~((uint32)CANFD_TB_DLC_DLC);
    hcanfd->Instance->TxMessage[TxBuffer].TB_DLC |= ((uint32)(Can_DataLen2Dlc[Length] << CANFD_TB_DLC_DLC_Pos));

    /* Write the data words (big-endian byte order: MSB first).  Each byte
     * is widened to uint32 before the shift (a bare uint8 << 24 is undefined
     * behaviour for byte values >= 0x80) and the last word is zero-padded
     * so that lengths that are not a multiple of four never read past the
     * end of the buffer. */
    txaddress = (volatile uint32 *)&hcanfd->Instance->TxMessage[TxBuffer].TB_DW0;
    for (bytecounter = 0U; bytecounter < Length; bytecounter += 4U)
    {
        uint32 word = 0U;
        uint32 i = 0U;

        for (i = 0U; i < 4U; i++)
        {
            if ((bytecounter + i) < Length)
            {
                word |= ((uint32)pData[bytecounter + i]) << (24U - 8U * i);
            }
        }
        *txaddress++ = word;
    }

    /* Wait for normal mode and request the transmission */
    status = CANFD_WaitNormalStatus(hcanfd, Timeout);
    if (status != HAL_OK)
    {
        /* POLL-03: report the timeout through the error code and the state */
        hcanfd->ErrorCode |= HAL_CANFD_ERROR_TIMEOUT;
        hcanfd->State      = HAL_CANFD_STATE_TIMEOUT;
    }
    else
    {
        CANFD_SetSendChannel(hcanfd, (uint32)(1UL << TxBuffer));
        hcanfd->State = HAL_CANFD_STATE_READY;
    }

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);

    return status;
}

/**
 * @brief  Writes the transmit data into a transmit buffer and requests the
 *         transmission (loopback mode). (NON-BLOCKING)
 * @note   The loopback transmission does not wait for the core mode, so the
 *         function returns as soon as the request has been issued; the
 *         Timeout parameter only bounds the wait for the handle lock in RTOS
 *         builds.
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  TxBuffer: transmit buffer index, 0..31.
 * @param  pData: pointer to the data buffer.
 * @param  Length: number of bytes in the data buffer.
 * @param  Timeout: maximum time to wait for the handle lock, in ms
 *         (HAL_MAX_DELAY waits forever).
 * @retval HAL_StatusTypeDef: HAL_OK / HAL_ERROR / HAL_BUSY / HAL_TIMEOUT.
 */
HAL_StatusTypeDef HAL_CANFD_LoopbackTransmit(CANFD_HandleTypeDef *hcanfd, uint32 TxBuffer, uint8 *pData,
                                             uint32 Length, uint32 Timeout)
{
    volatile uint32 *txaddress = NULL_PTR;
    uint32 bytecounter = 0U;
    HAL_StatusTypeDef status = HAL_OK;

    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return HAL_ERROR;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));
    assert_param(IS_CANFD_TB_NUMBER(TxBuffer));
    assert_param(pData != NULL_PTR);
    assert_param(IS_CANFD_DATA_LENGTH(Length));

    /* Runtime check of the transfer parameters */
    if ((pData == NULL_PTR) || (Length > 64U))
    {
        return HAL_ERROR;
    }

    /* ARCH-CONST-09: only the recoverable states accept a new transmission */
    status = CANFD_CheckState(hcanfd);
    if (status != HAL_OK)
    {
        return status;
    }

    /* Process locked */
    status = CANFD_LockHandle(hcanfd, Timeout);
    if (status != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return status;
    }

    /* ARCH-CONST-10: a new transfer starts from a clean error code, and
     * STATE-03: the transfer is marked busy while it runs */
    hcanfd->ErrorCode = HAL_CANFD_ERROR_NONE;
    hcanfd->State     = HAL_CANFD_STATE_BUSY;

    /* Set the DLC code from the data length */
    hcanfd->Instance->TxMessage[TxBuffer].TB_DLC &= ~((uint32)CANFD_TB_DLC_DLC);
    hcanfd->Instance->TxMessage[TxBuffer].TB_DLC |= ((uint32)(Can_DataLen2Dlc[Length] << CANFD_TB_DLC_DLC_Pos));

    /* Write the data words (big-endian byte order: MSB first, zero-padded
     * tail, uint32 widening before the shift - see HAL_CANFD_Transmit). */
    txaddress = (volatile uint32 *)&hcanfd->Instance->TxMessage[TxBuffer].TB_DW0;
    for (bytecounter = 0U; bytecounter < Length; bytecounter += 4U)
    {
        uint32 word = 0U;
        uint32 i = 0U;

        for (i = 0U; i < 4U; i++)
        {
            if ((bytecounter + i) < Length)
            {
                word |= ((uint32)pData[bytecounter + i]) << (24U - 8U * i);
            }
        }
        *txaddress++ = word;
    }

    /* Request the transmission (loopback mode: the core delivers the
     * message back to the RX FIFO) */
    CANFD_SetSendChannel(hcanfd, (uint32)(1UL << TxBuffer));

    hcanfd->State = HAL_CANFD_STATE_READY;

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);

    return HAL_OK;
}

/**
 * @brief  Requests the transmission of the selected transmit buffers. (NON-BLOCKING)
 * @note   The function takes the handle lock: a request is refused while
 *         another operation holds the handle. HAL_CANFD_Transmit() and
 *         HAL_CANFD_LoopbackTransmit() issue their request through the
 *         private Tier 3 helper while they already own the lock (LOCK-05).
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  SendTb: transmit buffer bitmask (bit N selects buffer N, or
 *         CANFD_SEND_ALL).
 * @retval None
 */
void HAL_CANFD_SetSendChannel(CANFD_HandleTypeDef *hcanfd, uint32 SendTb)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    /* ARCH-CONST-09: only a handle that has been initialized accepts a
     * modifying operation */
    if (CANFD_CheckState(hcanfd) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (CANFD_LockHandle(hcanfd, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return;
    }

    CANFD_SetSendChannel(hcanfd, SendTb);

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);
}

/**
 * @brief  Checks whether the selected transmit buffer(s) have completed (NON-BLOCKING)
 *         the transmission. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  SendTb: transmit buffer bitmask.
 * @retval 1 if the selected buffers are ready (transmission complete),
 *         0 otherwise.
 */
uint32 HAL_CANFD_GetSendCmpStatus(CANFD_HandleTypeDef *hcanfd, uint32 SendTb)
{
    uint32 bitstatus = 0U;

    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    if (((hcanfd->Instance->TRR) & SendTb) != 0U)
    {
        bitstatus = 1U;
    }

    return bitstatus;
}

/**
 * @brief  Cancels the transmission of the selected transmit buffers. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  TcrTb: transmit buffer bitmask to cancel.
 * @retval None
 */
void HAL_CANFD_CancelTransmit(CANFD_HandleTypeDef *hcanfd, uint32 TcrTb)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    /* ARCH-CONST-09: only a handle that has been initialized accepts a
     * modifying operation (the recoverable ERROR / TIMEOUT states accept it
     * so that no DeInit / Init round trip is required) */
    if (CANFD_CheckState(hcanfd) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (CANFD_LockHandle(hcanfd, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return;
    }

    hcanfd->Instance->TCR = TcrTb;

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);
}

/**
  * @}
  */

/** @addtogroup CANFD_Exported_Functions_Group6 Receive functions
  * @{
  */

/**
 * @brief  Returns the number of messages pending in the RX FIFO. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval uint32: RX FIFO fill level.
 */
uint32 HAL_CANFD_GetRxFillLevel(CANFD_HandleTypeDef *hcanfd)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    return ((uint32)((hcanfd->Instance->RFSR & CANFD_RFSR_FL) >> CANFD_RFSR_FL_Pos));
}

/**
 * @brief  Returns the read index of the RX FIFO. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval uint32: RX FIFO read index.
 */
uint32 HAL_CANFD_GetRxReadIndex(CANFD_HandleTypeDef *hcanfd)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    return ((uint32)((hcanfd->Instance->RFSR & CANFD_RFSR_RI) >> CANFD_RFSR_RI_Pos));
}

/**
 * @brief  Increments the RX FIFO read index (release the current message). (NON-BLOCKING)
 * @note   This is the standalone entry point for releasing a message, so it
 *         takes the handle lock; HAL_CANFD_GetReceiveData() does not need the
 *         standalone entry and releases the message through the private
 *         Tier 3 helper (LOCK-05).
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval None
 */
void HAL_CANFD_SetRxIncReadIndex(CANFD_HandleTypeDef *hcanfd)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    /* ARCH-CONST-09: only a handle that has been initialized accepts a
     * modifying operation */
    if (CANFD_CheckState(hcanfd) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (CANFD_LockHandle(hcanfd, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return;
    }

    CANFD_SetRxIncReadIndex(hcanfd);

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);
}

/**
 * @brief  Returns the data length (in bytes) of the current RX message. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval uint32: data length in bytes (0,1,...,8,12,16,...,64).
 */
uint32 HAL_CANFD_GetReceiveBytes(CANFD_HandleTypeDef *hcanfd)
{
    uint32 dlc = 0U;
    uint32 value = 0U;

    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    /* DLC code of the current RX message */
    dlc =
        ((uint32)((hcanfd->Instance->RxMessage[CANFD_GetRxReadIndex(hcanfd)].RB_DLC & CANFD_RB_DLC_DLC) >>
                  CANFD_RB_DLC_DLC_Pos));
    value = (uint32)Can_Dlc2DataLen[dlc];

    return value;
}

/**
 * @brief  Reads the current RX message data into the given buffer and (NON-BLOCKING)
 *         releases the message (increments the read index). (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  pData: pointer to the data buffer (up to 64 bytes).
 * @retval uint32: number of bytes read.
 */
uint32 HAL_CANFD_GetReceiveData(CANFD_HandleTypeDef *hcanfd, uint8 *pData)
{
    uint32 rxri = 0U;
    uint32 datalength = 0U;
    uint32 receive_len = 0U;
    uint32 buffx = 0U;
    uint32 rxfl = 0U;

    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));
    assert_param(pData != NULL_PTR);

    /* Runtime check of the transfer parameters */
    if (pData == NULL_PTR)
    {
        return 0U;
    }

    rxfl = ((uint32)((hcanfd->Instance->RFSR & CANFD_RFSR_FL) >> CANFD_RFSR_FL_Pos));
    if (rxfl != 0U)
    {
        rxri = CANFD_GetRxReadIndex(hcanfd);
        datalength = (uint32)Can_Dlc2Reglen[((hcanfd->Instance->RxMessage[rxri].RB_DLC >> 28U) & 0xFU)];
        receive_len = (uint32)Can_Dlc2DataLen[((hcanfd->Instance->RxMessage[rxri].RB_DLC >> 28U) & 0xFU)];

        /* Read only the DLC-valid bytes; the final message word can contain
         * padding bytes that do not belong to the received frame. */
        for (buffx = 0U; buffx < receive_len; buffx++)
        {
            uint32 wordIndex = buffx / 4U;
            uint32 byteIndex = buffx % 4U;
            uint32 word = *((const volatile uint32 *)(&hcanfd->Instance->RxMessage[rxri].RB_DW0) + wordIndex);

            if (wordIndex >= datalength)
            {
                break;
            }
            *pData++ = (uint8)(word >> (24U - (byteIndex * 8U)));
        }

        /* Release the current message (through the Tier 3 helper: this read
         * path is intentionally lock free, so that it stays usable from the
         * user receive interrupt) */
        CANFD_SetRxIncReadIndex(hcanfd);
    }

    return receive_len;
}

/**
 * @brief  Returns the info of the current RX message (identifier, format, (NON-BLOCKING)
 *         type, protocol, DLC and pending count). (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  CANFD_RXInfoStruct: pointer to the structure that will hold the
 *         message info.
 * @retval None
 */
void HAL_CANFD_GetReceiveInfo(CANFD_HandleTypeDef *hcanfd, CANFD_RXInfoTypeDef *CANFD_RXInfoStruct)
{
    uint32 rxri = 0U;
    uint32 tempreg = 0U;

    /* Check the CANFD peripheral handle */
    if ((hcanfd == NULL_PTR) || (CANFD_RXInfoStruct == NULL_PTR))
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    /* Get the pending message count */
    CANFD_RXInfoStruct->CANFD_Message_Count = ((uint8)((hcanfd->Instance->RFSR & CANFD_RFSR_FL) >> CANFD_RFSR_FL_Pos));
    if (CANFD_RXInfoStruct->CANFD_Message_Count == 0U)
    {
        CANFD_RXInfoStruct->CANFD_CurrentMessage_DLC = 0U;
        CANFD_RXInfoStruct->CANFD_CurrentFrame_ID = 0U;
        CANFD_RXInfoStruct->CANFD_CurrentMessage_FORMAT = 0U;
        CANFD_RXInfoStruct->CANFD_CurrentMessage_TYPE = 0U;
        CANFD_RXInfoStruct->CANFD_CurrentMessage_PROTOCOL = 0U;
        return;
    }

    rxri = CANFD_GetRxReadIndex(hcanfd);

    /* Get the data length code */
    tempreg = ((uint32)((hcanfd->Instance->RxMessage[rxri].RB_DLC & CANFD_RB_DLC_DLC) >> CANFD_RB_DLC_DLC_Pos));
    CANFD_RXInfoStruct->CANFD_CurrentMessage_DLC = (uint32)Can_Dlc2DataLen[tempreg];

    /* Get the frame format and identifier */
    if ((hcanfd->Instance->RxMessage[rxri].RB_ID & CANFD_RB_ID_IDE) != 0U)
    {
        CANFD_RXInfoStruct->CANFD_CurrentMessage_FORMAT = CANFD_FORMAT_EXTENDED;
        CANFD_RXInfoStruct->CANFD_CurrentFrame_ID =
            (((hcanfd->Instance->RxMessage[rxri].RB_ID >> CANFD_RB_ID_ID_Pos) & 0x7FFU) << 18U) +
            (((hcanfd->Instance->RxMessage[rxri].RB_ID >> CANFD_RB_ID_EM_ID_Pos) & 0x3FFFFU));
        if ((hcanfd->Instance->RxMessage[rxri].RB_ID & CANFD_RB_ID_RTR) != 0U)
        {
            CANFD_RXInfoStruct->CANFD_CurrentMessage_TYPE = CANFD_TYPE_REMOTE;
        }
        else
        {
            CANFD_RXInfoStruct->CANFD_CurrentMessage_TYPE = CANFD_TYPE_DATA;
        }
    }
    else
    {
        CANFD_RXInfoStruct->CANFD_CurrentMessage_FORMAT = CANFD_FORMAT_STANDARD;
        CANFD_RXInfoStruct->CANFD_CurrentFrame_ID =
            ((hcanfd->Instance->RxMessage[rxri].RB_ID >> CANFD_RB_ID_ID_Pos) & 0x7FFU);
        if ((hcanfd->Instance->RxMessage[rxri].RB_ID & CANFD_RB_ID_SRR) != 0U)
        {
            CANFD_RXInfoStruct->CANFD_CurrentMessage_TYPE = CANFD_TYPE_REMOTE;
        }
        else
        {
            CANFD_RXInfoStruct->CANFD_CurrentMessage_TYPE = CANFD_TYPE_DATA;
        }
    }

    /* Get the frame protocol from the BRS / EDL field */
    if (((hcanfd->Instance->RxMessage[rxri].RB_DLC >> CANFD_RB_DLC_BRS_Pos) & 0x03U) == 0x03U)
    {
        CANFD_RXInfoStruct->CANFD_CurrentMessage_PROTOCOL = CANFD_PROTOCOL_CANFD_BRS;
    }
    else if (((hcanfd->Instance->RxMessage[rxri].RB_DLC >> CANFD_RB_DLC_BRS_Pos) & 0x03U) == 0x02U)
    {
        CANFD_RXInfoStruct->CANFD_CurrentMessage_PROTOCOL = CANFD_PROTOCOL_CANFD;
    }
    else
    {
        CANFD_RXInfoStruct->CANFD_CurrentMessage_PROTOCOL = CANFD_PROTOCOL_CAN;
    }
}

/**
  * @}
  */

/** @addtogroup CANFD_Exported_Functions_Group7 Interrupt functions
  * @{
  */

/**
 * @brief  Enables or disables the specified CAN FD interrupt source(s). (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  ITType: interrupt source bitmask (CANFD_IT_xxx).
 * @param  NewState: CANFD_ENABLE or CANFD_DISABLE.
 * @retval None
 */
void HAL_CANFD_ITConfig(CANFD_HandleTypeDef *hcanfd, uint32 ITType, uint32 NewState)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    /* ARCH-CONST-09: only a handle that has been initialized accepts a
     * modifying operation (the recoverable ERROR / TIMEOUT states accept it
     * so that no DeInit / Init round trip is required) */
    if (CANFD_CheckState(hcanfd) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (CANFD_LockHandle(hcanfd, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return;
    }

    if (NewState != CANFD_DISABLE)
    {
        hcanfd->Instance->IER |= ITType;
    }
    else
    {
        hcanfd->Instance->IER &= ~((uint32)ITType);
    }

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);
}

/**
 * @brief  Enables or disables the TX buffer ready request served interrupt. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  Cleartb: transmit buffer bitmask.
 * @param  NewState: CANFD_ENABLE or CANFD_DISABLE.
 * @retval None
 */
void HAL_CANFD_SetBufferReadyIT(CANFD_HandleTypeDef *hcanfd, uint32 Cleartb, uint32 NewState)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    /* ARCH-CONST-09: only a handle that has been initialized accepts a
     * modifying operation (the recoverable ERROR / TIMEOUT states accept it
     * so that no DeInit / Init round trip is required) */
    if (CANFD_CheckState(hcanfd) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (CANFD_LockHandle(hcanfd, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return;
    }

    if (NewState != CANFD_DISABLE)
    {
        hcanfd->Instance->ERRS |= Cleartb;
    }
    else
    {
        hcanfd->Instance->ERRS &= ~((uint32)Cleartb);
    }

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);
}

/**
 * @brief  Enables or disables the TX buffer cancellation served interrupt. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  EcrsTb: transmit buffer bitmask.
 * @param  NewState: CANFD_ENABLE or CANFD_DISABLE.
 * @retval None
 */
void HAL_CANFD_TxBufferCancelIT(CANFD_HandleTypeDef *hcanfd, uint32 EcrsTb, uint32 NewState)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    /* ARCH-CONST-09: only a handle that has been initialized accepts a
     * modifying operation (the recoverable ERROR / TIMEOUT states accept it
     * so that no DeInit / Init round trip is required) */
    if (CANFD_CheckState(hcanfd) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (CANFD_LockHandle(hcanfd, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return;
    }

    if (NewState != CANFD_DISABLE)
    {
        hcanfd->Instance->ECRS |= EcrsTb;
    }
    else
    {
        hcanfd->Instance->ECRS &= ~((uint32)EcrsTb);
    }

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);
}

/**
 * @brief  Checks whether the specified CAN FD interrupt flag is set. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  Flag: interrupt flag bitmask (CANFD_IT_xxx).
 * @retval 1 if the flag is set, 0 otherwise.
 */
uint32 HAL_CANFD_GetITStatus(CANFD_HandleTypeDef *hcanfd, uint32 Flag)
{
    uint32 bitstatus = 0U;

    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    if ((hcanfd->Instance->ISR & Flag) != 0U)
    {
        bitstatus = 1U;
    }

    return bitstatus;
}

/**
 * @brief  Clears the specified CAN FD interrupt pending bit(s). (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  ClearIT: interrupt flag bitmask to clear.
 * @retval None
 */
void HAL_CANFD_ClearITPendingBit(CANFD_HandleTypeDef *hcanfd, uint32 ClearIT)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    /* ARCH-CONST-09: only a handle that has been initialized accepts a
     * modifying operation (the recoverable ERROR / TIMEOUT states accept it
     * so that no DeInit / Init round trip is required) */
    if (CANFD_CheckState(hcanfd) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (CANFD_LockHandle(hcanfd, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return;
    }

    hcanfd->Instance->ICR = ClearIT;

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);
}

/**
  * @}
  */

/** @addtogroup CANFD_Exported_Functions_Group8 Status and error functions
  * @{
  */

/**
 * @brief  Returns the value of the given CAN FD status flag. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  Status: the status flag to check (CANFD_STATUS_xxx).
 * @retval 1 if the flag is set, 0 otherwise; for the ESTAT (2 bits) and
 *         TDCV (7 bits) flags the raw field value is returned.
 */
uint32 HAL_CANFD_GetStatus(CANFD_HandleTypeDef *hcanfd, uint32 Status)
{
    uint32 state_data = 0U;

    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    if ((hcanfd->Instance->SR) & Status & 0x0000167FU)
    {
        state_data = 1U;
    }
    else
    {
        state_data = 0U;
    }

    /* ESTAT: 2-bit field at bit 7 */
    if (Status & 0x00000180U)
    {
        state_data = (((hcanfd->Instance->SR) >> 7U) & 0x03U);
    }
    /* TDCV: 7-bit field at bit 16 */
    if (Status & 0x007F0000U)
    {
        state_data = (((hcanfd->Instance->SR) >> 16U) & 0x7FU);
    }

    return state_data;
}

/**
 * @brief  Checks whether the given CAN FD error status flag is set. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @param  ErrorState: the error flag to check (CANFD_ERRSTAT_xxx).
 * @retval 1 if the error flag is set, 0 otherwise.
 */
uint32 HAL_CANFD_GetErrorStatus(CANFD_HandleTypeDef *hcanfd, uint32 ErrorState)
{
    uint32 bitstatus = 0U;

    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    if ((hcanfd->Instance->ESR & ErrorState) != 0U)
    {
        bitstatus = 1U;
    }

    return bitstatus;
}

/**
 * @brief  Returns the CAN FD receive error counter. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval uint32: receive error count.
 */
uint32 HAL_CANFD_GetRXErrorCount(CANFD_HandleTypeDef *hcanfd)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    return ((uint32)((hcanfd->Instance->ECR & CANFD_ECR_REC) >> CANFD_ECR_REC_Pos));
}

/**
 * @brief  Returns the CAN FD transmit error counter. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval uint32: transmit error count.
 */
uint32 HAL_CANFD_GetTXErrorCount(CANFD_HandleTypeDef *hcanfd)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    return ((uint32)((hcanfd->Instance->ECR & CANFD_ECR_TEC) >> CANFD_ECR_TEC_Pos));
}

/**
 * @brief  Returns the CAN FD timestamp counter value. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval uint32: timestamp counter value.
 */
uint32 HAL_CANFD_GetTimestampValue(CANFD_HandleTypeDef *hcanfd)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return 0U;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    return ((uint32)(hcanfd->Instance->TSR >> CANFD_TSR_TIMESTAMP_CNT_Pos));
}

/**
 * @brief  Clears the CAN FD timestamp counter. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval None
 */
void HAL_CANFD_ClearTimestamp(CANFD_HandleTypeDef *hcanfd)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return;
    }

    /* Check the parameters */
    assert_param(IS_CANFD_ALL_PERIPH(hcanfd->Instance));

    /* ARCH-CONST-09: only a handle that has been initialized accepts a
     * modifying operation (the recoverable ERROR / TIMEOUT states accept it
     * so that no DeInit / Init round trip is required) */
    if (CANFD_CheckState(hcanfd) != HAL_OK)
    {
        return;
    }

    /* Process locked */
    if (CANFD_LockHandle(hcanfd, HAL_MAX_DELAY) != HAL_OK)
    {
        /* LOCK-02: the lock was NOT acquired on this path, so no unlock is
         * required */
        return;
    }

    hcanfd->Instance->TSR |= ((uint32)CANFD_TSR_CTS);

    /* Release Lock */
    CANFD_UnlockHandle(hcanfd);
}

/**
 * @brief  Returns the CAN FD handle state. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval HAL_CANFD_StateTypeDef: the current handle state.
 */
HAL_CANFD_StateTypeDef HAL_CANFD_GetState(CANFD_HandleTypeDef *hcanfd)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return HAL_CANFD_STATE_RESET;
    }

    return hcanfd->State;
}

/**
 * @brief  Returns the CAN FD error code. (NON-BLOCKING)
 * @param  hcanfd: pointer to a CANFD_HandleTypeDef structure.
 * @retval uint32: the CAN FD error code (HAL_CANFD_ERROR_xxx).
 */
uint32 HAL_CANFD_GetError(CANFD_HandleTypeDef *hcanfd)
{
    /* Check the CANFD peripheral handle */
    if (hcanfd == NULL_PTR)
    {
        return HAL_CANFD_ERROR_NONE;
    }

    return hcanfd->ErrorCode;
}

/**
  * @}
  */

/**
  * @}
  */

#endif /* HAL_CANFD_MODULE_ENABLED */

/*****END OF FILE*****/
